# FAQ Update System

A checksum-centric FAQ regeneration detection and tracking system.

## 🎯 Purpose

Detect which content changes require FAQ regeneration, track FAQ-to-content mappings, and manage FAQ lifecycle with minimal overhead.

## 📁 Project Structure

```
FAQ_update/
├── data/                                   # Test data (CSV files)
│   ├── test_content_repo.csv              # ✅ Sample content pages
│   ├── test_faq_questions.csv             # ✅ Sample FAQ questions
│   └── test_faq_answers.csv               # ✅ Sample FAQ answers
│
├── databases/                              # SQLite databases
│   └── faq_update.db                      # Main tracking database
│
├── schema/                                 # Database schema
│   └── faq_update_schema.sql              # ✅ Complete schema DDL
│
├── src/                                    # Source code
│   ├── detectors/                          # Change detection
│   │   ├── faq_regeneration_detector.py   # ✅ Checksum-centric FAQ detector
│   │   ├── faq_to_changes_adapter.py      # ✅ Adapter for downstream components
│   │   └── change_detector.py             # Full change detector (legacy)
│   │
│   ├── processors/                         # Data processing
│   │   ├── change_processor.py            # ✅ Records changes to database
│   │   ├── faq_mapper.py                  # ✅ Updates FAQ mappings
│   │   └── __init__.py
│   │
│   ├── reporters/                          # Analytics & reporting
│   │   ├── impact_reporter.py             # ✅ Generates impact reports
│   │   └── __init__.py
│   │
│   ├── formatters/                         # Output formatting
│   │   ├── diff_formatter.py              # Formats diffs for LLMs
│   │   └── __init__.py
│   │
│   ├── validators/                         # Data validation
│   │   ├── content_validator.py           # FK validation
│   │   └── __init__.py
│   │
│   ├── utils/                              # Utilities
│   │   ├── test_data_loader.py            # ✅ Loads CSV test data
│   │   ├── checksum_utils.py              # Checksum calculation
│   │   ├── timestamp_utils.py             # Time handling
│   │   ├── logging_config.py              # Logging setup
│   │   └── notebook_utils.py              # Notebook helpers
│   │
│   ├── content_diff.py                    # Diff generation
│   └── __init__.py
│
├── notebooks/                              # Jupyter notebooks
│   ├── 0_validate_database.ipynb          # ✅ Database validation & health check
│   ├── 1_setup_tables_STREAMLINED.ipynb   # ✅ USE THIS - Clean setup (200 lines)
│   ├── 2_content_edit.ipynb               # ✅ Simulate content changes
│   ├── 3_update_detector.ipynb            # ✅ Detect FAQ regeneration needs
│   │
│   └── 1_setup_tables.ipynb               # 📚 Reference only (9,208 lines - deprecated)
│
├── populate_faq_mappings.py               # Standalone FAQ mapping script
├── CLAUDE.md                               # Instructions for Claude Code
└── README.md                               # ✅ This file

```

## 🚀 Quick Start

### Step 1: Setup Database

```bash
jupyter notebook notebooks/1_setup_tables_STREAMLINED.ipynb
```

**Creates:** Database schema, loads test data, creates FAQ-content mappings

### Step 2: Validate Setup

```bash
jupyter notebook notebooks/0_validate_database.ipynb
```

**Verifies:** Schema integrity, data validity, FK constraints, triggers, views

### Step 3: Run Workflows

```bash
# Simulate content changes
jupyter notebook notebooks/2_content_edit.ipynb

# Detect FAQ regeneration needs
jupyter notebook notebooks/3_update_detector.ipynb
```

**Processes:** Change detection, FAQ mapping updates, impact reporting

## 📒 Notebooks Overview

### When to Use Each Notebook

| Notebook | Purpose | When to Run | Output |
|----------|---------|-------------|--------|
| **[0_validate_database.ipynb](notebooks/0_validate_database.ipynb)** | Comprehensive database health check | After setup, after changes, before deployment, when debugging | Validation report with PASS/WARN/FAIL |
| **[1_setup_tables_STREAMLINED.ipynb](notebooks/1_setup_tables_STREAMLINED.ipynb)** | Initialize database with schema and test data | Once at project start, or to reset database | Fresh database with test data |
| **[2_content_edit.ipynb](notebooks/2_content_edit.ipynb)** | Simulate content changes for testing | During development to test detection logic | Updated content_repo records |
| **[3_update_detector.ipynb](notebooks/3_update_detector.ipynb)** | Detect and process FAQ regeneration needs | After content changes (scheduled or on-demand) | Change log, updated FAQ mappings, reports |

### Notebook Details

#### 0_validate_database.ipynb - Database Validation

**Purpose:** Run comprehensive validation checks on database health and integrity

**What It Checks:**
- ✅ Schema structure (tables, views, indexes, triggers)
- ✅ Timestamp format compliance (ISO-8601 UTC)
- ✅ Checksum validity (SHA-256 format)
- ✅ Foreign key integrity
- ✅ Trigger functionality
- ✅ View accessibility
- ✅ Business logic compliance
- ✅ Performance optimization

**Output:**
- Color-coded results (🟢 PASS, 🟡 WARN, 🔴 FAIL)
- Summary dashboard with health score
- Exported text report: `databases/validation_report_YYYY-MM-DD_HHMMSS.txt`

**When to Run:**
1. **After Setup** - Verify `1_setup_tables_STREAMLINED.ipynb` completed successfully
2. **After Schema Changes** - Ensure migrations didn't break anything
3. **Before Deployment** - Validate database is production-ready
4. **When Debugging** - Identify data integrity issues
5. **Periodically** - Ongoing health monitoring during development

**Example Output:**
```
📊 Overall Results:
  Total Checks:    45
  ✅ PASS:         43 (95.6%)
  ⚠️  WARN:         2 (4.4%)
  ❌ FAIL:         0 (0.0%)

🏥 Database Health Score: 95.6%
   Status: 🟢 EXCELLENT
```

#### 1_setup_tables_STREAMLINED.ipynb - Database Setup

**Purpose:** Initialize FAQ tracking database with schema and test data

**What It Does:**
1. Creates database schema (8 tables, 9 views, 1 trigger)
2. Loads test data from CSV files (`data/*.csv`)
3. Tests foreign key constraint enforcement
4. Creates FAQ-content mappings (6 mappings: 3 pages × 2 FAQs)
5. Verifies final setup

**Structure:**
- 📄 14 cells (~200 lines)
- ⚡ Fast execution (~5 seconds)
- ✅ Idempotent (safe to re-run)

**Test Data Sources:**
- `data/test_content_repo.csv` - 3 pages, 22 columns
- `data/test_faq_questions.csv` - 10 questions, 21 columns
- `data/test_faq_answers.csv` - 10 answers, 23 columns

**Final Output:**
```
📋 Final Database State:
  content_repo                     3 records
  faq_questions                   10 records
  faq_answers                     10 records
  faq_content_map                  6 records
  content_change_log               0 records

✅ All foreign key constraints valid
✅ DATABASE SETUP COMPLETE
```

**Next Step:** Run `0_validate_database.ipynb` to verify setup

## 📊 Key Components

### ✅ **Active Files** (Use These)

| File | Purpose | Lines | Status |
|------|---------|-------|--------|
| `notebooks/0_validate_database.ipynb` | Database validation | ~250 | ✅ **NEW** |
| `notebooks/1_setup_tables_STREAMLINED.ipynb` | Database setup | ~200 | ✅ **USE THIS** |
| `notebooks/2_content_edit.ipynb` | Simulate changes | ~400 | ✅ **ACTIVE** |
| `notebooks/3_update_detector.ipynb` | FAQ detection workflow | ~800 | ✅ **ACTIVE** |
| `src/detectors/faq_regeneration_detector.py` | FAQ detection logic | ~430 | ✅ **ACTIVE** |
| `src/detectors/faq_to_changes_adapter.py` | Format adapter | ~180 | ✅ **ACTIVE** |
| `src/processors/faq_mapper.py` | FAQ mapping | ~310 | ✅ **ACTIVE** |
| `src/utils/test_data_loader.py` | CSV loader | ~80 | ✅ **ACTIVE** |
| `data/test_*.csv` | Test data | 22-23 cols | ✅ **EDITABLE** |

### 📚 **Reference Files** (Keep for History)

| File | Purpose | Lines | Status |
|------|---------|-------|--------|
| `notebooks/1_setup_tables.ipynb` | Original setup | 9,208 | 📚 **DEPRECATED** |
| `src/detectors/change_detector.py` | Full detector | Large | 📚 **LEGACY** |

## 🎯 Architecture Overview

### Checksum-Centric Detection Model

**Key Question:** "Is this checksum new to this file?"

```
For each content_id with recent changes:
  ├─ Get current checksum (from extracted_markdown_file_path)
  ├─ Load baseline = Set of all checksums ever seen in this file
  └─ Decision:
      ├─ If checksum NOT in baseline → New/modified content → REGENERATE FAQ
      └─ If checksum IN baseline → Content reused → NO REGENERATION
```

**Benefits:**
- ✅ Page reordering doesn't trigger regeneration
- ✅ Content duplication is detected (reuses existing FAQs)
- ✅ Only truly new/modified content triggers regeneration
- ✅ Simple, fast (O(1) set membership check)

### Data Flow

```
FAQRegenerationDetector.detect()
  ↓
  {regenerate_faq: [...], no_action_needed: [...]}
  ↓
FAQToChangesAdapter.adapt()
  ↓
  {content_edits: [], position_changes: [...], new_content: [...]}
  ↓
ChangeProcessor.process_changes() → Records to database
  ↓
FAQMapper.update_faq_mappings() → Updates FAQ mappings
  ↓
ImpactReporter.generate_impact_report() → Analytics
```

## 📋 Database Schema

### Core Tables

| Table | Purpose | Key Fields |
|-------|---------|------------|
| `content_repo` | Source documents | content_checksum, raw_file_nme, raw_file_page_nbr |
| `faq_questions` | FAQ questions | question_id, question_txt |
| `faq_answers` | FAQ answers | answer_id, question_id, faq_answer_txt |
| `faq_content_map` | FAQ-content links | content_checksum, question_id, is_valid |
| `content_change_log` | Change history | change_type, content_checksum, detected_at |
| `content_diffs` | Diff storage | change_id, unified_diff_gzip, similarity_score |

### Important Notes

- **`content_checksum`**: SHA256 hash of page content (identity)
- **`raw_file_page_nbr`**: Page position (metadata only - not used for detection)
- **`ud_source_file_id`**: Stable page entity identifier
- **`is_valid`**: FAQ validity flag (0 = invalidated, 1 = valid)

## 🔧 Configuration

### Test Data Location

Edit CSV files in `data/` directory:

```bash
# Add new content pages
vim data/test_content_repo.csv

# Add new FAQ questions
vim data/test_faq_questions.csv

# Add new FAQ answers
vim data/test_faq_answers.csv
```

### Detection Parameters

In `notebooks/3_update_detector.ipynb`:

```python
# Detect changes since specific date
SINCE_DATE = '2025-01-15T00:00:00Z'

# Or detect since last run
# SINCE_DATE = get_last_detection_date()

# Or process all content
# SINCE_DATE = '1970-01-01T00:00:00Z'
```

## 🧪 Testing

### Unit Testing (Manual)

Each notebook cell is designed to be idempotent:
- Run multiple times without side effects
- Clear separation of concerns
- Comprehensive logging

### Integration Testing

Run notebooks in sequence:
1. `1_setup_tables_STREAMLINED.ipynb` - Setup
2. `2_content_edit.ipynb` - Simulate changes
3. `3_update_detector.ipynb` - Detect and process

## 📖 Design Principles

### 1. Checksum-Centric
- Detection is based on content checksums, not page positions
- Page number is metadata only (for human reference)
- Baseline = Set of all checksums ever seen in a file

### 2. Simplified Model
- No tracking of old_checksum per content_id
- No tracking of previous_page
- Two categories: "regenerate" or "skip"

### 3. Many-to-Many Relationships
- One checksum → Multiple FAQs
- One FAQ → Multiple checksums
- Flexible, scalable architecture

### 4. Idempotent Operations
- Re-running detection doesn't create duplicates
- Database constraints prevent invalid states
- Graceful handling of edge cases

## 🔍 Troubleshooting

### Issue: FAQ counts showing 0

**Cause:** No mappings in `faq_content_map` table

**Solution:**
```bash
# Run Step 4 in 1_setup_tables_STREAMLINED.ipynb
# Or run standalone script:
python populate_faq_mappings.py
```

### Issue: Notebook cells fail with import errors

**Cause:** Python path not set correctly

**Solution:**
```python
# First cell should have:
sys.path.insert(0, str(SRC_DIR))
```

### Issue: Database locked

**Cause:** Multiple connections open

**Solution:**
```python
# Close all connections
# Restart Jupyter kernel
```

## 📚 Additional Documentation

- **`CLAUDE.md`** - Full project documentation for Claude Code
- **`CHUNKING_MODULE_SUMMARY.md`** - Chunking system details
- **Inline docstrings** - All modules have comprehensive docstrings

## 🤝 Contributing

When modifying:
1. ✅ Update CSV files (not inline code)
2. ✅ Use `test_data_loader.py` (not custom generators)
3. ✅ Keep notebooks clean and focused
4. ✅ Update this README if structure changes

## 📝 Version History

- **v2.0** (2025-01-15) - Streamlined with CSV data loading
- **v1.0** (2025-01-10) - Initial checksum-centric implementation

---

**Note:** This is a Databricks-compatible system designed for production FAQ lifecycle management. All notebooks can run in Databricks or local Jupyter environments.
