## 4. Sick Leave
Employees are entitled to sick leave as follows:
- 10 days of paid sick leave per year
- Medical certificate required for absences over 3 consecutive days
- Unused sick leave does not carry over

## 5. Parental Leave
- 12 weeks of paid parental leave for primary caregiver
- 4 weeks of paid parental leave for secondary caregiver
