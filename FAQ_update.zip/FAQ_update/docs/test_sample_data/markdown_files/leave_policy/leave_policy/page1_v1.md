# Employee Leave Policy

## 1. Purpose
This policy establishes guidelines for employee leave requests and approvals.

## 2. Scope
This policy applies to all full-time employees.

## 3. Annual Leave
- Employees accrue 15 days of annual leave per year
- Leave must be requested at least 2 weeks in advance
- Maximum carryover: 5 days to next year
