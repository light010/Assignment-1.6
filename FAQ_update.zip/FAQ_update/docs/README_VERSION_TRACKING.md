# Content Version Tracking System - Documentation

## 📋 Overview

This system tracks content evolution and manages FAQ lifecycle without modifying existing tables. It provides:

1. ✅ **Version History Tracking** - Links content versions in a chain
2. ✅ **FAQ-Content Association** - Links FAQs to specific content versions
3. ✅ **Automated Deprecation** - Marks FAQs as invalid when content changes
4. ✅ **Impact Analysis** - Tracks which FAQs are affected by changes
5. ✅ **Audit Trail** - Complete history of validations and changes

---

## 🗂️ Database Schema

### Core Tables

#### 1. `content_version_history`
Tracks the version chain for each piece of content.

**Key Fields:**
- `content_id` → Points to content_repo.ud_source_file_id (FK to actual content record)
- `previous_version_id` → Points to content_version_history.version_history_id (self-referential FK)
- `version_sequence` → Sequential version number (1, 2, 3...)
- `content_checksum` → SHA-256 hash of content for THIS version
- `change_type` → 'initial', 'minor', 'major', 'breaking'
- `content_diff` → JSON diff between versions

**IMPORTANT:** This table stores version METADATA only. Actual content lives in markdown files at paths stored in `content_repo.extracted_markdown_file_path`.

**Sample Record:**
```json
{
  "version_history_id": 2,
  "content_id": 3001,
  "previous_version_id": 1,
  "version_sequence": 2,
  "file_name": "TCI FEDERAL PTO POLICY.pdf",
  "page_number": 1,
  "content_checksum": "a8c3f21b9d5e7a34b2f8e91c0d6a4f7b8e2c9d1a5f3b7e4a8c6d2f9e1b5a7c3d",
  "change_type": "major",
  "change_summary": "PTO accrual increased from 10 to 15 hours/month"
}
```

#### 2. `faq_content_link`
Links FAQs to specific content versions and tracks validity.

**Key Fields:**
- `question_id` → Points to faq_questions.question_id
- `answer_id` → Points to faq_answers.answer_id
- `content_id` → Points to content_repo.ud_source_file_id
- `version_history_id` → Points to content_version_history
- `valid_from_version` → First version this FAQ is valid for
- `valid_until_version` → Last version (NULL = still valid)
- `is_currently_valid` → Boolean flag
- `superseded_by_link_id` → Points to newer FAQ

**Sample Record:**
```json
{
  "link_id": 1,
  "question_id": 1013,
  "answer_id": "0542c37a-2cf5-11f0-87f9-b9ea131128c3",
  "content_id": 100,
  "version_history_id": 1,
  "valid_from_version": 1,
  "valid_until_version": 1,
  "is_currently_valid": false,
  "deprecated_reason": "content_updated",
  "superseded_by_link_id": 2
}
```

#### 3. `faq_validation_history`
Audit trail of all FAQ validations and reviews.

**Key Fields:**
- `link_id` → Points to faq_content_link
- `validation_type` → Type of review
- `validation_status` → approved/needs_revision/deprecated
- `validated_by` → Who performed validation
- `findings` → Review findings

#### 4. `content_change_impact`
Tracks impact of content changes on FAQs.

**Key Fields:**
- `version_history_id` → The version that changed
- `total_faqs_affected` → Count of impacted FAQs
- `faqs_auto_deprecated` → Auto-deprecated count
- `impact_severity` → none/low/medium/high/critical
- `auto_actions_performed` → JSON log of automated actions

---

## 📊 Sample Data Story

### Scenario: PTO Policy Update

**Initial State (March 2025):**
- File: "TCI FEDERAL PTO POLICY.pdf", Page 1
- Content ID: 100
- Policy: "PTO accrues at 10 hours/month"
- Question 1013: "What happens to my unused time off?"
- Answer: "...10 hours per month"
- Link ID: 1 (valid_from_version: 1, is_currently_valid: TRUE)

**Change Event (September 2025):**
- Policy updated: "PTO accrues at 15 hours/month"
- New content created: ID 3001 (new row in content_repo)
- New markdown file created at extracted_markdown_file_path with updated content
- Version history created:
  - content_id: 3001 (points to new content_repo row)
  - previous_version_id: 1 (points to version_history_id=1, which tracks content_id=100)
  - version_sequence: 2
  - change_type: "major"

**Automated Actions:**
1. Link ID 1 marked:
   - is_currently_valid: FALSE
   - valid_until_version: 1
   - deprecated_reason: "content_updated"

2. New FAQ generated:
   - New answer: "...15 hours per month"
   - New link created: Link ID 2
   - valid_from_version: 2
   - supersedes Link ID 1

3. Impact record created:
   - total_faqs_affected: 2
   - faqs_auto_deprecated: 2
   - impact_severity: "high"

---

## 🔄 Your Pipeline Implementation

### Input: `last_modified_dt` filter

**Note**: The following code assumes you've already loaded data from databases:
- `content_repo` DataFrame loaded from `content_repo.db`
- `content_version_history` DataFrame loaded from `version_tracking.db`
- `faq_content_link` DataFrame loaded from `version_tracking.db`
- `faq_questions` DataFrame loaded from `faq_question.db`
- `faq_answers` DataFrame loaded from `faq_answer.db`

```python
def version_tracking_pipeline(last_modified_dt: str):
    """
    Track content versions and FAQs for updated content.

    NOTE: This pipeline compares ADJACENT versions (v2 vs v1, v3 vs v2).
    To get full version history (v1 → v2 → v3), use get_full_version_chain().

    Assumes DataFrames are already loaded from databases.
    """

    # 1. Find updated content from content_repo (loaded from database)
    updated_content = content_repo[
        content_repo['last_modified_dt'] > last_modified_dt
    ]

    # 2. For each updated content
    for content in updated_content:

        # 3. Look up version history for this content
        current_version_record = content_version_history[
            content_version_history['content_id'] == content['ud_source_file_id']
        ].iloc[0]

        # 4. Get previous version (if exists) by following previous_version_id
        previous_version_record = None
        previous_content = None
        if pd.notna(current_version_record['previous_version_id']):
            # Get the previous version history record
            previous_version_record = content_version_history[
                content_version_history['version_history_id'] == current_version_record['previous_version_id']
            ].iloc[0]

            # Get the actual content from content_repo
            previous_content = content_repo[
                content_repo['ud_source_file_id'] == previous_version_record['content_id']
            ].iloc[0]

            # Get previous version's FAQs
            previous_faqs = faq_content_link[
                (faq_content_link['version_history_id'] == previous_version_record['version_history_id']) &
                (faq_content_link['is_currently_valid'] == False)
            ]
        else:
            previous_faqs = pd.DataFrame()

        # 6. Get current version's FAQs
        current_faqs = faq_content_link[
            (faq_content_link['version_history_id'] == current_version_record['version_history_id']) &
            (faq_content_link['is_currently_valid'] == True)
        ]

        # 7. Build comparison view
        comparison = {
            'file_name': current_version_record['file_name'],
            'page_number': current_version_record['page_number'],

            'previous_version': {
                'version_history_id': previous_version_record['version_history_id'] if previous_version_record is not None else None,
                'content_id': previous_version_record['content_id'] if previous_version_record is not None else None,
                'version_number': previous_version_record['version_sequence'] if previous_version_record is not None else None,
                'markdown_file_path': previous_content['extracted_markdown_file_path'] if previous_content is not None else None,
                'checksum': previous_version_record['content_checksum'] if previous_version_record is not None else None,
                'faqs': build_faq_details(previous_faqs)
            },

            'current_version': {
                'version_history_id': current_version_record['version_history_id'],
                'content_id': content['ud_source_file_id'],
                'version_number': current_version_record['version_sequence'],
                'markdown_file_path': content['extracted_markdown_file_path'],
                'checksum': current_version_record['content_checksum'],
                'faqs': build_faq_details(current_faqs)
            },

            'changes': {
                'change_type': current_version_record['change_type'],
                'change_summary': current_version_record['change_summary'],
                'diff': json.loads(current_version_record['content_diff']) if current_version_record['content_diff'] else {},
                'faq_impact': get_impact_summary(current_version_record['version_history_id'])
            }
        }

        yield comparison

def build_faq_details(faq_links):
    """Build Q&A pairs from faq_content_link records"""
    qa_pairs = []

    for _, link in faq_links.iterrows():
        question = faq_questions[
            faq_questions['question_id'] == link['question_id']
        ].iloc[0]

        if link['answer_id']:
            answer = faq_answers[
                faq_answers['answer_id'] == link['answer_id']
            ].iloc[0]
            answer_txt = answer['faq_answer_txt']
        else:
            answer_txt = None

        qa_pairs.append({
            'question_id': link['question_id'],
            'question': question['question_txt'],
            'answer_id': link['answer_id'],
            'answer': answer_txt,
            'is_valid': link['is_currently_valid'],
            'deprecated_reason': link['deprecated_reason'],
            'confidence_score': link['confidence_score']
        })

    return qa_pairs


def get_full_version_chain(version_history_id: int):
    """
    Get the complete version chain for a given version.

    This function traverses the linked list backwards from the given version
    to the initial version, returning all versions in chronological order.

    Args:
        version_history_id: The version_history_id to start from (typically latest)

    Returns:
        List of version history records in chronological order (v1, v2, v3, ...)

    Example:
        >>> versions = get_full_version_chain(version_history_id=2)
        >>> # Returns: [v1_record, v2_record]
        >>> for v in versions:
        ...     print(f"Version {v['version_sequence']}: {v['change_summary']}")
    """
    versions = []

    # Start with the given version
    current_version = content_version_history[
        content_version_history['version_history_id'] == version_history_id
    ].iloc[0]
    versions.append(current_version)

    # Walk backwards through the chain
    while pd.notna(current_version['previous_version_id']):
        prev_id = current_version['previous_version_id']
        current_version = content_version_history[
            content_version_history['version_history_id'] == prev_id
        ].iloc[0]
        versions.append(current_version)

    # Reverse to get chronological order (v1, v2, v3 instead of v3, v2, v1)
    return versions[::-1]


def get_version_with_content(version_history_id: int):
    """
    Get version metadata along with actual content from the markdown file.

    Args:
        version_history_id: The version to retrieve

    Returns:
        Dictionary with version metadata and actual content text

    Example:
        >>> version_data = get_version_with_content(version_history_id=2)
        >>> print(version_data['content'])  # Actual markdown content
        >>> print(version_data['checksum'])  # SHA-256 hash
    """
    # Get version record
    version_record = content_version_history[
        content_version_history['version_history_id'] == version_history_id
    ].iloc[0]

    # Get content_repo record
    content_record = content_repo[
        content_repo['ud_source_file_id'] == version_record['content_id']
    ].iloc[0]

    # Read actual content from markdown file
    markdown_path = content_record['extracted_markdown_file_path']
    with open(markdown_path, 'r', encoding='utf-8') as f:
        content_text = f.read()

    return {
        'version_history_id': version_record['version_history_id'],
        'version_number': version_record['version_sequence'],
        'content_id': version_record['content_id'],
        'file_name': version_record['file_name'],
        'page_number': version_record['page_number'],
        'checksum': version_record['content_checksum'],
        'change_type': version_record['change_type'],
        'change_summary': version_record['change_summary'],
        'markdown_file_path': markdown_path,
        'content': content_text,  # Actual content!
        'created_at': version_record['version_created_at']
    }
```

---

## 📈 Query Examples

### 1. Get all current valid FAQs for a file+page
```sql
SELECT
    fcl.question_id,
    fq.question_txt,
    fcl.answer_id,
    fa.faq_answer_txt,
    cvh.version_sequence,
    cvh.file_name,
    cvh.page_number
FROM faq_content_link fcl
JOIN content_version_history cvh ON fcl.version_history_id = cvh.version_history_id
JOIN faq_questions fq ON fcl.question_id = fq.question_id
LEFT JOIN faq_answers fa ON fcl.answer_id = fa.answer_id
WHERE cvh.file_name = 'TCI FEDERAL PTO POLICY.pdf'
  AND cvh.page_number = 1
  AND cvh.is_latest_version = TRUE
  AND fcl.is_currently_valid = TRUE;
```

### 2. Get version history for a specific page
```sql
SELECT
    cvh.version_sequence,
    cvh.content_id,
    cvh.content_checksum,
    cvh.change_type,
    cvh.change_summary,
    cvh.version_created_at,
    COUNT(fcl.link_id) as faq_count
FROM content_version_history cvh
LEFT JOIN faq_content_link fcl ON cvh.version_history_id = fcl.version_history_id
WHERE cvh.file_name = 'TCI FEDERAL PTO POLICY.pdf'
  AND cvh.page_number = 1
GROUP BY cvh.version_history_id
ORDER BY cvh.version_sequence;
```

### 3. Find FAQs that need regeneration
```sql
SELECT
    fcl.link_id,
    fcl.question_id,
    fq.question_txt,
    cvh.file_name,
    cvh.page_number,
    cvh.change_type,
    cvh.change_summary,
    fcl.deprecated_reason
FROM faq_content_link fcl
JOIN content_version_history cvh ON fcl.version_history_id = cvh.version_history_id
JOIN faq_questions fq ON fcl.question_id = fq.question_id
WHERE fcl.is_currently_valid = FALSE
  AND fcl.superseded_by_link_id IS NULL
  AND fcl.deprecated_reason = 'content_updated';
```

### 4. Get side-by-side comparison (your use case!)
```sql
WITH current_version AS (
    SELECT
        cvh.*,
        cr.extracted_markdown_file_path as current_markdown_path
    FROM content_version_history cvh
    JOIN content_repo cr ON cvh.content_id = cr.ud_source_file_id
    WHERE cvh.file_name = 'TCI FEDERAL PTO POLICY.pdf'
      AND cvh.page_number = 1
      AND cvh.is_latest_version = TRUE
),
previous_version AS (
    SELECT
        prev_cvh.*,
        cr.extracted_markdown_file_path as previous_markdown_path
    FROM current_version cv
    JOIN content_version_history prev_cvh ON cv.previous_version_id = prev_cvh.version_history_id
    JOIN content_repo cr ON prev_cvh.content_id = cr.ud_source_file_id
)
SELECT
    cv.file_name,
    cv.page_number,

    -- Previous version info
    pv.version_sequence as prev_version_number,
    pv.content_id as prev_content_id,
    pv.previous_markdown_path as prev_markdown_path,
    pv.content_checksum as prev_checksum,
    pv.change_summary as prev_change_summary,

    -- Current version info
    cv.version_sequence as current_version_number,
    cv.content_id as current_content_id,
    cv.current_markdown_path as current_markdown_path,
    cv.content_checksum as current_checksum,
    cv.change_summary as current_change_summary,

    -- Change info
    cv.change_type,
    cv.content_diff
FROM current_version cv
LEFT JOIN previous_version pv ON 1=1;
```

---

## 🔧 Design Clarifications & Important Notes

### Where is the Actual Content?

**CRITICAL:** The `content_version_history` table does NOT store actual content text. It stores:
- **Metadata** about versions (version number, change type, timestamps)
- **Checksums** (SHA-256 hashes) for change detection
- **References** to content_repo where actual files live

**Actual content** is stored in **markdown files** on disk at paths like:
```
/Volumes/onedata_us_east_1_unstructured_fit/ssot_transform_policy_assist/
  ssot_transform_policy_assist/G3EG8P2BG2FM7SFD/TCI FEDERAL PTO POLICY.pdf_page1_v1.md
```

To get actual content, you must:
1. Look up `content_repo.ud_source_file_id` using `content_version_history.content_id`
2. Read file at `content_repo.extracted_markdown_file_path`

**Example:**
```python
# Get version metadata
version = content_version_history[
    content_version_history['version_history_id'] == 2
].iloc[0]

# Get content record
content = content_repo[
    content_repo['ud_source_file_id'] == version['content_id']
].iloc[0]

# Read actual content
with open(content['extracted_markdown_file_path'], 'r') as f:
    actual_content = f.read()  # THIS is the content!
```

### Version Chain: Self-Referential Design

The `previous_version_id` field creates a **linked list** within the `content_version_history` table:

```
content_version_history:
  version_history_id=1, content_id=100,  previous_version_id=NULL  ← v1 (initial)
  version_history_id=2, content_id=3001, previous_version_id=1     ← v2 (points to v1)
  version_history_id=3, content_id=3010, previous_version_id=2     ← v3 (points to v2)
```

This is **different from** pointing to `content_repo`:
- ✅ `previous_version_id` → `content_version_history.version_history_id` (self-reference)
- ❌ NOT: `previous_content_id` → `content_repo.ud_source_file_id`

**Why this design?**
- Clearer semantics: "previous version" points to version table, not content table
- Easier traversal: Follow chain within one table
- Less redundancy: Don't duplicate checksums

### Multi-Version Support

The schema supports **unlimited versions** (v1, v2, v3, v4, ...) via the linked list.

**However**, the basic pipeline only compares **adjacent versions**:
- When v3 is created, pipeline compares v3 vs v2
- To see full history (v1 → v2 → v3), use `get_full_version_chain()`

**Example:**
```python
# Basic pipeline: shows v3 vs v2 only
comparison = next(version_tracking_pipeline('2025-12-01'))
# comparison['previous_version']['version_number'] = 2
# comparison['current_version']['version_number'] = 3

# Full history: shows all versions v1 → v2 → v3
all_versions = get_full_version_chain(version_history_id=3)
# Returns: [v1_record, v2_record, v3_record]
```

### Key Design Decisions

**Issue 1 (Fixed):** Removed redundant `content_checksum_previous` column
- Old: Stored checksum twice (once in row 1, once in row 2)
- New: Each row has one `content_checksum` for its version only

**Issue 2 (Fixed):** Self-referential FK instead of content_repo FK
- Old: `previous_content_id` → `content_repo.ud_source_file_id`
- New: `previous_version_id` → `content_version_history.version_history_id`

**Issue 3 (Fixed):** Clarified field naming
- Old: `current_content_id`, `content_checksum_current` (misleading)
- New: `content_id`, `content_checksum` (clearer)

**Issue 4 (Documented):** Adjacent vs full version comparison
- Pipeline compares v(n) vs v(n-1) by default
- Use helper functions for full version chain traversal

---

## 🎯 Benefits of This Approach

### ✅ Non-Invasive
- No changes to existing `content_repo`, `faq_questions`, or `faq_answers` tables
- Existing workflows continue unchanged
- New tables are purely additive

### ✅ Complete Audit Trail
- Every FAQ validation is logged
- Every content change is tracked
- Every deprecation is documented

### ✅ Automated FAQ Management
- Auto-deprecate FAQs when content changes
- Track which FAQs need regeneration
- Link old FAQs to new replacements

### ✅ Version-Aware Queries
- Query FAQs for specific versions
- Compare versions side-by-side
- Track FAQ evolution over time

---

## 🗄️ Database Structure

### Directory Organization
```
FAQ/
├── databases/              ← All SQLite databases
│   ├── content_repo.db         (Content repository data)
│   ├── faq_question.db         (FAQ questions)
│   ├── faq_answer.db           (FAQ answers)
│   └── version_tracking.db     (Version history tracking)
├── Docs/                   ← Source files and schemas
│   ├── content_repo.csv.xlsx
│   ├── faq_question.csv.xlsx
│   ├── faq_answer.csv.xlsx
│   └── schema_content_version_tracking.sql
└── notebooks/
    ├── setup_databases.ipynb           (Initialize all databases)
    ├── daily_version_tracking_pipeline.ipynb
    └── version_tracking_implementation.ipynb
```

### Database Separation Rationale

**Why separate databases?**
1. **Modularity**: Each domain (content, questions, answers, versioning) is independent
2. **Performance**: Smaller databases are faster for specific queries
3. **Maintenance**: Easier to backup/restore individual components
4. **Scalability**: Can move databases to different systems if needed

### Database Connections

```python
import sqlite3
from pathlib import Path

# Database paths
DATABASES_DIR = Path('../databases')
CONTENT_REPO_DB = DATABASES_DIR / 'content_repo.db'
FAQ_QUESTION_DB = DATABASES_DIR / 'faq_question.db'
FAQ_ANSWER_DB = DATABASES_DIR / 'faq_answer.db'
VERSION_TRACKING_DB = DATABASES_DIR / 'version_tracking.db'

# Connect to databases
conn_content = sqlite3.connect(CONTENT_REPO_DB)
conn_question = sqlite3.connect(FAQ_QUESTION_DB)
conn_answer = sqlite3.connect(FAQ_ANSWER_DB)
conn_version = sqlite3.connect(VERSION_TRACKING_DB)

# Load data
content_repo = pd.read_sql("SELECT * FROM content_repo", conn_content)
faq_questions = pd.read_sql("SELECT * FROM faq_questions", conn_question)
faq_answers = pd.read_sql("SELECT * FROM faq_answers", conn_answer)
version_history = pd.read_sql("SELECT * FROM content_version_history", conn_version)

# Always close connections
conn_content.close()
conn_question.close()
conn_answer.close()
conn_version.close()
```

---

## 🚀 Implementation Steps

### Phase 1: Initial Setup (First Time Only)
Run the setup notebook to create all databases from Excel files:

```bash
# Run in Jupyter
notebooks/setup_databases.ipynb
```

This will:
1. Create `databases/` directory
2. Create `content_repo.db` from `Docs/content_repo.csv.xlsx`
3. Create `faq_question.db` from `Docs/faq_question.csv.xlsx`
4. Create `faq_answer.db` from `Docs/faq_answer.csv.xlsx`
5. Create `version_tracking.db` with empty schema

### Phase 2: Daily Pipeline
Run the daily version tracking pipeline:

```bash
# Run in Jupyter
notebooks/daily_version_tracking_pipeline.ipynb
```

**Prerequisites**: Requires all 4 databases to exist (created by setup_databases.ipynb)

This will:
1. Read content metadata from `content_repo.db` (NOT CSV!)
2. Calculate checksums from actual markdown files (using paths from database)
3. Load existing version history from `version_tracking.db`
4. Load FAQ data from `faq_question.db` and `faq_answer.db`
5. Detect new/updated content by comparing checksums
6. Create version records in `version_tracking.db`
7. Deprecate affected FAQs in `faq_content_link` table

### Phase 3: Explore Version History
Use the implementation notebook to explore and query version chains:

```bash
# Run in Jupyter
notebooks/version_tracking_implementation.ipynb
```

**Prerequisites**:
- Requires all 4 databases to exist (created by setup_databases.ipynb)
- Requires version history data to exist (populated by daily_version_tracking_pipeline.ipynb)

**Important**: This notebook is READ-ONLY. It does not create databases or insert data. It only queries existing data for educational purposes.

---

## 🔄 Daily Workflow

### Step-by-Step Daily Process

**1. Content Updates** (Automated upstream process)
- New PDFs extracted to markdown files
- Content metadata stored in `content_repo.db`
- `last_modified_dt` in database reflects change timestamp

**2. Run Version Tracking Pipeline**
```python
# In daily_version_tracking_pipeline.ipynb
# Automatically:
# - Reads content metadata from content_repo.db
# - Filters by last_modified_dt > last_run_date
# - Calculates checksums from actual markdown files (using paths from database)
# - Loads existing versions from version_tracking.db
# - Loads FAQ data from faq_question.db and faq_answer.db
# - Detects new/updated pages by comparing checksums
# - Creates version records in version_tracking.db
# - Deprecates FAQs in faq_content_link table
```

**3. Review Results**
```python
# Query latest versions created
SELECT * FROM content_version_history
WHERE detected_at = '2025-10-03T10:00:00.000Z'
ORDER BY version_history_id DESC;

# Check deprecated FAQs
SELECT * FROM faq_content_link
WHERE deprecated_at = '2025-10-03T10:00:00.000Z'
AND is_currently_valid = 0;
```

**4. Regenerate FAQs** (Separate process)
- Use deprecated FAQ list
- Generate new Q&A with updated content
- Create new faq_content_link records

---

## 📊 Database Schema Details

### version_tracking.db Tables

All version tracking tables are in a single database for transactional consistency:

1. **content_version_history** - Version metadata and checksums
2. **faq_content_link** - Links FAQs to content versions
3. **faq_validation_history** - Audit trail of validations
4. **content_change_impact** - Impact analysis records

### Cross-Database Queries

When you need data from multiple databases:

```python
# Load from multiple databases
conn_content = sqlite3.connect(CONTENT_REPO_DB)
conn_version = sqlite3.connect(VERSION_TRACKING_DB)

content_repo = pd.read_sql("SELECT * FROM content_repo", conn_content)
version_history = pd.read_sql("SELECT * FROM content_version_history", conn_version)

# Join in pandas
merged = version_history.merge(
    content_repo,
    left_on='content_id',
    right_on='ud_source_file_id',
    how='left'
)

conn_content.close()
conn_version.close()
```

---

## 🔧 Maintenance

### Refreshing Base Data

To refresh content_repo, faq_question, or faq_answer databases:

```bash
# Update Excel files in Docs/, then run:
notebooks/setup_databases.ipynb
```

⚠️ **Warning**: This will REPLACE existing databases. Version tracking database is NOT affected.

### Backing Up Databases

```bash
# Backup all databases
cp -r databases/ databases_backup_2025-10-03/

# Or individual databases
cp databases/version_tracking.db backups/version_tracking_2025-10-03.db
```

### Resetting Version History

```bash
# Delete version tracking database to start fresh
rm databases/version_tracking.db

# Run pipeline to recreate
notebooks/daily_version_tracking_pipeline.ipynb
```

---

## 🎯 Pipeline Code Example
```python
# Your pipeline from earlier (compares adjacent versions)
results = version_tracking_pipeline(since_date="2025-09-01T00:00:00.000Z")

for comparison in results:
    print(f"\n{'='*80}")
    print(f"File: {comparison['file_name']}, Page: {comparison['page_number']}")
    print(f"{'='*80}")

    if comparison['previous_version']['version_number'] is not None:
        print(f"\nPrevious Version {comparison['previous_version']['version_number']}:")
        print(f"  Content ID: {comparison['previous_version']['content_id']}")
        print(f"  Markdown Path: {comparison['previous_version']['markdown_file_path']}")
        print(f"  Checksum: {comparison['previous_version']['checksum'][:16]}...")
        print(f"  FAQs: {len(comparison['previous_version']['faqs'])}")
        for faq in comparison['previous_version']['faqs']:
            print(f"    Q: {faq['question'][:60]}...")
            print(f"    A: {faq['answer'][:60] if faq['answer'] else 'N/A'}...")
    else:
        print("\nNo previous version (this is version 1)")

    print(f"\nCurrent Version {comparison['current_version']['version_number']}:")
    print(f"  Content ID: {comparison['current_version']['content_id']}")
    print(f"  Markdown Path: {comparison['current_version']['markdown_file_path']}")
    print(f"  Checksum: {comparison['current_version']['checksum'][:16]}...")
    print(f"  FAQs: {len(comparison['current_version']['faqs'])}")
    for faq in comparison['current_version']['faqs']:
        print(f"    Q: {faq['question'][:60]}...")
        print(f"    A: {faq['answer'][:60] if faq['answer'] else 'N/A'}...")

    print(f"\nChanges:")
    print(f"  Type: {comparison['changes']['change_type']}")
    print(f"  Summary: {comparison['changes']['change_summary']}")

# Get full version history for a specific version
print(f"\n{'='*80}")
print("Full Version History for PTO Policy Page 1")
print(f"{'='*80}")

all_versions = get_full_version_chain(version_history_id=2)  # Latest version
for v in all_versions:
    print(f"\nVersion {v['version_sequence']} (ID: {v['version_history_id']})")
    print(f"  Content ID: {v['content_id']}")
    print(f"  Change Type: {v['change_type']}")
    print(f"  Summary: {v['change_summary']}")
    print(f"  Created: {v['version_created_at']}")

# Get version with actual content
print(f"\n{'='*80}")
print("Version with Actual Content")
print(f"{'='*80}")

version_data = get_version_with_content(version_history_id=2)
print(f"Version {version_data['version_number']}")
print(f"File: {version_data['file_name']}, Page: {version_data['page_number']}")
print(f"Checksum: {version_data['checksum']}")
print(f"\nActual Content (first 200 chars):")
print(version_data['content'][:200])
```

---

## 📁 Files Included

1. `schema_content_version_tracking.sql` - Complete SQL schema
2. `sample_data_content_version_history.csv` - Version history samples
3. `sample_data_faq_content_link.csv` - FAQ-content links samples
4. `sample_data_faq_validation_history.csv` - Validation history samples
5. `sample_data_content_change_impact.csv` - Impact analysis samples
6. `sample_data_new_content_versions.csv` - New content versions (to add to content_repo)
7. `sample_data_new_faq_answers.csv` - New answers (to add to faq_answers)
8. `README_VERSION_TRACKING.md` - This documentation

---

## 💡 Next Steps

1. **Review the schema** - Make sure it fits your needs
2. **Test with sample data** - Load the CSVs and run queries
3. **Adapt your pipeline** - Use the code examples above
4. **Integrate with existing system** - Connect to your content ingestion process
5. **Build automation** - Auto-detect changes and update version tables

Your idea was excellent - this implementation makes it production-ready! 🎯
