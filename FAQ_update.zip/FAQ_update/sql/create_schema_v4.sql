-- ============================================================================
-- FAQ UPDATE DATABASE - UNIFIED SCHEMA (SINGLE DATABASE ARCHITECTURE)
-- Version: 4.0 (Simplified Checksum-Centric Architecture)
-- Database: faq_update.db
-- Purpose: Complete schema for content, FAQs, and version tracking in ONE database
-- Date: 2025-10-19
-- Last Updated: 2025-10-19 (v4 Simplified Schema - Binary Decision + JSON Metadata)
-- ============================================================================
-- ⚠️  WARNING: This script DROPS and RECREATES tables for v4 schema migration
-- - No backward compatibility - for DEV use only
-- - All existing data in content_change_log and faq_content_map will be LOST
-- - Wraps changes in transaction for safety (atomic all-or-nothing)
-- ============================================================================
--
-- V4 SCHEMA CHANGES (Simplified Checksum-Centric Architecture):
--
-- content_change_log:
--   REMOVED: change_type, page_number, previous_*, change_trigger, effective_date, processed_at, detected_by, notes
--   ADDED: requires_faq_regeneration (BOOLEAN), metadata (JSON), source_modified_at, existing_faq_count, detection_run_id, since_date
--
-- faq_content_map:
--   REMOVED: current_page_number, original_page_number
--   ADDED: current_metadata (JSON), original_metadata (JSON)
--
-- REMOVED: content_diffs table (entire table)
--
-- KEY IMPROVEMENTS:
-- - Binary decision model: requires_faq_regeneration (0/1) vs complex change_type
-- - JSON metadata: All optional fields in flexible JSON columns
-- - Checksum-centric: Page numbers are metadata, not primary identity
-- - Architectural consistency: Both tables use same JSON metadata pattern
-- - Built-in telemetry: Detection metrics included (no separate reporter)
-- ============================================================================

-- ============================================================================
-- PREREQUISITES
-- ============================================================================
-- SQLite JSON1 extension required for json_object() and json_extract() functions.
-- The JSON1 extension is included by default in SQLite 3.38.0+ (2022-02-22).
-- For older versions, ensure SQLite is compiled with SQLITE_ENABLE_JSON1.
--
-- Verify JSON1 is available:
-- SELECT json('{"test":true}'); -- Should return: {"test":true}
-- ============================================================================

-- ============================================================================
-- TRANSACTION START (Atomic schema changes)
-- ============================================================================
-- Disable foreign keys temporarily to allow table drops/recreation
PRAGMA foreign_keys = OFF;

BEGIN TRANSACTION;

-- ============================================================================
-- DROP OLD V3 TABLES (if they exist from previous schema)
-- ============================================================================
-- These tables will be recreated with v4 schema below
-- WARNING: All data in these tables will be LOST

DROP TABLE IF EXISTS content_diffs;  -- Removed in v4 (not needed)
DROP TABLE IF EXISTS content_change_log;  -- Will be recreated with v4 schema
DROP TABLE IF EXISTS faq_content_map;  -- Will be recreated with v4 schema

-- ============================================================================
-- DROP OLD V3 VIEWS (if they exist)
-- ============================================================================
-- These views referenced old schema columns and will be recreated

DROP VIEW IF EXISTS v_document_structure_changes;  -- Used old change_type
DROP VIEW IF EXISTS v_content_changes_with_diffs;  -- Used content_diffs table
DROP VIEW IF EXISTS v_pending_diffs;  -- Used content_diffs table
DROP VIEW IF EXISTS v_diff_processing_stats;  -- Used content_diffs table

-- ============================================================================
-- DROP OLD V3 INDEXES (will be recreated with v4 definitions)
-- ============================================================================
-- Content change log indexes
DROP INDEX IF EXISTS idx_ccl_content;
DROP INDEX IF EXISTS idx_ccl_checksum;
DROP INDEX IF EXISTS idx_ccl_file_page;
DROP INDEX IF EXISTS idx_ccl_type;
DROP INDEX IF EXISTS idx_ccl_dates;
DROP INDEX IF EXISTS idx_ccl_latest;
DROP INDEX IF EXISTS idx_ccl_idempotent;
DROP INDEX IF EXISTS idx_ccl_checksum_page;

-- FAQ content map indexes
DROP INDEX IF EXISTS idx_fcm_checksum;
DROP INDEX IF EXISTS idx_fcm_question;
DROP INDEX IF EXISTS idx_fcm_answer;
DROP INDEX IF EXISTS idx_fcm_valid;
DROP INDEX IF EXISTS idx_fcm_current_content;
DROP INDEX IF EXISTS idx_fcm_original_content;
DROP INDEX IF EXISTS idx_fcm_valid_from;
DROP INDEX IF EXISTS idx_fcm_checksum_valid;
DROP INDEX IF EXISTS idx_fcm_current_file_page;
DROP INDEX IF EXISTS idx_fcm_unique_active_mapping;

-- ============================================================================
-- BASE TABLES (Source Data)
-- ============================================================================

-- ============================================================================
-- Table 1: content_repo
-- ============================================================================
-- Purpose: Source content repository (documents, pages, markdown extracts)
-- This is the foundation table - all content tracking references this
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_repo (
    -- Primary key
    ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Organization and context
    domain TEXT,
    service TEXT,
    orgoid TEXT,
    associateoid TEXT,

    -- File identification
    raw_file_nme TEXT NOT NULL,
    raw_file_type TEXT,
    raw_file_version_nbr INTEGER DEFAULT 1,
    raw_file_page_nbr INTEGER NOT NULL CHECK(raw_file_page_nbr > 0),

    -- Source information
    source_url_txt TEXT,
    parent_location_txt TEXT,
    raw_file_path TEXT,

    -- Content paths
    extracted_markdown_file_path TEXT,
    extracted_layout_file_path TEXT,

    -- Content metadata
    title_nme TEXT,
    breadcrumb_txt TEXT,
    content_tags_txt TEXT,
    version_nbr INTEGER DEFAULT 1,
    content_checksum TEXT CHECK(content_checksum IS NULL OR length(content_checksum) = 64),
    file_status TEXT CHECK(file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived')),

    -- Timestamps (ISO-8601 UTC: YYYY-MM-DDTHH:MM:SSZ)
    created_dt TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    last_modified_dt TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),

    -- Unique constraint: one record per file-page combination
    UNIQUE(raw_file_nme, raw_file_page_nbr, version_nbr)
);

-- Indexes for content_repo
CREATE INDEX IF NOT EXISTS idx_repo_file ON content_repo(raw_file_nme);
CREATE INDEX IF NOT EXISTS idx_repo_file_page ON content_repo(raw_file_nme, raw_file_page_nbr);
CREATE INDEX IF NOT EXISTS idx_repo_modified ON content_repo(last_modified_dt);
CREATE INDEX IF NOT EXISTS idx_repo_status ON content_repo(file_status);
CREATE INDEX IF NOT EXISTS idx_repo_checksum ON content_repo(content_checksum);
CREATE INDEX IF NOT EXISTS idx_repo_domain_service ON content_repo(domain, service);
CREATE INDEX IF NOT EXISTS idx_repo_orgoid ON content_repo(orgoid);

-- ============================================================================
-- Table 2: faq_questions
-- ============================================================================
-- Purpose: FAQ questions master table
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_questions (
    -- Primary key
    question_id INTEGER PRIMARY KEY,

    -- Question versions and history
    prev_recommended_question_txt TEXT,
    prev_question_txt TEXT,
    recommeded_question_txt TEXT,
    question_txt TEXT NOT NULL,

    -- Source information
    source TEXT,
    src_file_name TEXT,
    src_id TEXT,
    src_page_number INTEGER,
    prev_src TEXT,

    -- Organization and context
    domain TEXT,
    service TEXT,
    product TEXT,
    orgid TEXT,

    -- Timestamps
    created TEXT,
    created_by TEXT,
    modified TEXT,
    modified_by TEXT,

    -- Metadata
    version TEXT,
    status TEXT,
    metadata TEXT

);

-- Indexes for faq_questions
CREATE INDEX IF NOT EXISTS idx_questions_txt ON faq_questions(question_txt);
CREATE INDEX IF NOT EXISTS idx_questions_source ON faq_questions(src_file_name, src_page_number);
CREATE INDEX IF NOT EXISTS idx_questions_domain ON faq_questions(domain, service);
CREATE INDEX IF NOT EXISTS idx_questions_orgid ON faq_questions(orgid);
CREATE INDEX IF NOT EXISTS idx_questions_status ON faq_questions(status);

-- ============================================================================
-- Table 3: faq_answers
-- ============================================================================
-- Purpose: FAQ answers master table
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answers (
    -- Primary key
    answer_id INTEGER PRIMARY KEY,

    -- Foreign key to question (constraint defined at end of table)
    question_id INTEGER NOT NULL,

    -- Answer versions and history
    prev_recommended_answer_txt TEXT,
    recommended_answer_txt TEXT,
    prev_faq_answer_txt TEXT,
    faq_answer_txt TEXT NOT NULL,
    user_feedback_txt TEXT,

    -- Source information
    source TEXT,
    src_file_name TEXT,
    src_id TEXT,
    src_page_number INTEGER,
    prev_src TEXT,

    -- Organization and context
    domain TEXT,
    service TEXT,
    product TEXT,
    orgid TEXT,

    -- Timestamps
    created TEXT,
    created_by TEXT,
    modified TEXT,
    modified_by TEXT,

    -- Metadata
    version TEXT,
    status TEXT,
    metadata TEXT,

    -- Foreign key constraint
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE
);

-- Indexes for faq_answers
CREATE INDEX IF NOT EXISTS idx_answers_question ON faq_answers(question_id);
CREATE INDEX IF NOT EXISTS idx_answers_source ON faq_answers(src_file_name, src_page_number);
CREATE INDEX IF NOT EXISTS idx_answers_domain ON faq_answers(domain, service);
CREATE INDEX IF NOT EXISTS idx_answers_orgid ON faq_answers(orgid);
CREATE INDEX IF NOT EXISTS idx_answers_status ON faq_answers(status);

-- ============================================================================
-- TRACKING TABLES (Version History and Change Management)
-- ============================================================================

-- ============================================================================
-- Table 4: content_change_log
-- ============================================================================
-- Purpose: Single source of truth for all content changes
-- Replaces: content_version_history (eliminates linked list complexity)
-- ✅ NOW WITH REAL FOREIGN KEYS (single database!)
-- ============================================================================

CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ============================================================================
    -- CORE IDENTITY (Dual Identity Model)
    -- ============================================================================
    -- content_id: WHERE the content lives (physical location in content_repo)
    --   - Links to specific content_repo row for markdown file lookup
    --   - Required for retrieving content for FAQ generation
    --
    -- content_checksum: WHAT the content is (logical content identity)
    --   - Used for FAQ-to-content mapping (checksum is primary identity)
    --   - Determines FAQ regeneration need (new checksum → regenerate)
    --
    -- Relationship: Many content_ids → One checksum (content reused in multiple locations)
    -- ============================================================================
    content_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL CHECK(length(content_checksum) = 64),
    file_name TEXT NOT NULL,

    -- ============================================================================
    -- DETECTION RESULT (Binary Decision)
    -- ============================================================================
    -- Simple binary question: "Should we regenerate FAQ for this checksum?"
    --   1 = Checksum NOT in baseline → Regenerate FAQ (new/modified content)
    --   0 = Checksum IN baseline → Reuse existing FAQ (content unchanged)
    --
    -- This replaces complex change_type classification (edit/move/insert/delete)
    -- ============================================================================
    requires_faq_regeneration BOOLEAN NOT NULL CHECK(requires_faq_regeneration IN (0,1)),

    -- ============================================================================
    -- METADATA (Flexible JSON Storage)
    -- ============================================================================
    -- All descriptive/contextual fields stored as JSON for maximum flexibility:
    --   {
    --     "page": 2,              // Optional (NULL for HTML/XML/single-page docs)
    --     "title": "...",
    --     "domain": "HR",
    --     "service": "Policy",
    --     "breadcrumb": "...",
    --     "tags": "leave;sick;medical",
    --     "version": 1,
    --     "orgoid": "ORG001",
    --     "associateoid": "ASSOC001",
    --     ... any other content_repo fields
    --   }
    --
    -- Design Rationale:
    --   - Flexibility: Add new fields without ALTER TABLE
    --   - Optional: Fields may not exist for all content types
    --   - Extensible: Future content types supported without schema changes
    --   - Clean: No NULL columns for unused fields
    --   - Human-Readable: For debugging/display, NOT business logic
    -- ============================================================================
    metadata JSON,

    -- ============================================================================
    -- TIMESTAMPS (ISO-8601 UTC)
    -- ============================================================================
    detected_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    source_modified_at TEXT NOT NULL,  -- From content_repo.last_modified_dt

    -- ============================================================================
    -- FAQ IMPACT METRICS
    -- ============================================================================
    existing_faq_count INTEGER DEFAULT 0,  -- How many FAQs exist for this checksum

    -- ============================================================================
    -- DETECTION CONTEXT (Batch Tracking)
    -- ============================================================================
    detection_run_id TEXT,  -- ISO timestamp of detection run (groups batch detections)
    since_date TEXT,        -- Detection period start (for audit/debug)

    -- ============================================================================
    -- CONSTRAINTS
    -- ============================================================================
    -- Prevent duplicate detections for same content_id in same run
    UNIQUE(content_id, detection_run_id),

    -- Foreign key to content_repo (enforced since both in same database)
    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE
);

-- ============================================================================
-- Indexes for content_change_log (Simplified Checksum-Centric Architecture)
-- ============================================================================

-- ============================================================================
-- PRIMARY LOOKUP INDEXES
-- ============================================================================

-- Content ID lookup (for retrieving markdown from content_repo)
CREATE INDEX IF NOT EXISTS idx_ccl_content ON content_change_log(content_id);

-- Checksum lookup (primary identity for FAQ regeneration logic)
CREATE INDEX IF NOT EXISTS idx_ccl_checksum ON content_change_log(content_checksum);

-- File name lookup (for file-level operations)
CREATE INDEX IF NOT EXISTS idx_ccl_file ON content_change_log(file_name);

-- Regeneration decision lookup (filter pages needing FAQ regeneration)
CREATE INDEX IF NOT EXISTS idx_ccl_requires_regen ON content_change_log(requires_faq_regeneration);

-- Combined file + regeneration (common query: "which pages in this file need FAQ regen?")
CREATE INDEX IF NOT EXISTS idx_ccl_file_regen ON content_change_log(
    file_name,
    requires_faq_regeneration
);

-- ============================================================================
-- TEMPORAL INDEXES
-- ============================================================================

-- Detection timestamp (for batch tracking and temporal queries)
CREATE INDEX IF NOT EXISTS idx_ccl_detected ON content_change_log(detected_at);

-- Source modification timestamp (for change timeline analysis)
CREATE INDEX IF NOT EXISTS idx_ccl_source_modified ON content_change_log(source_modified_at);

-- Combined temporal index (common query: "changes detected in period X from sources modified in period Y")
CREATE INDEX IF NOT EXISTS idx_ccl_dates ON content_change_log(
    detected_at,
    source_modified_at
);

-- ============================================================================
-- BATCH TRACKING INDEXES
-- ============================================================================

-- Detection run lookup (for batch-level operations and reporting)
CREATE INDEX IF NOT EXISTS idx_ccl_run ON content_change_log(detection_run_id);

-- Since date lookup (for incremental processing queries)
CREATE INDEX IF NOT EXISTS idx_ccl_since ON content_change_log(since_date);

-- Combined run context (for batch analytics)
CREATE INDEX IF NOT EXISTS idx_ccl_run_context ON content_change_log(
    detection_run_id,
    since_date,
    requires_faq_regeneration
);

-- ============================================================================
-- FAQ IMPACT INDEXES
-- ============================================================================

-- FAQ count lookup (for impact analysis and prioritization)
CREATE INDEX IF NOT EXISTS idx_ccl_faq_count ON content_change_log(existing_faq_count);

-- Combined impact index (find high-impact regenerations: "pages with many FAQs needing regen")
CREATE INDEX IF NOT EXISTS idx_ccl_impact ON content_change_log(
    requires_faq_regeneration,
    existing_faq_count DESC  -- DESC for high-impact-first ordering
) WHERE requires_faq_regeneration = 1;

-- ============================================================================
-- METADATA QUERY INDEXES (JSON extraction)
-- ============================================================================

-- Page number extraction from JSON (for backward compatibility queries)
-- Uses SQLite JSON1 extension: json_extract(metadata, '$.page')
-- Example: WHERE json_extract(metadata, '$.page') = 42
CREATE INDEX IF NOT EXISTS idx_ccl_metadata_page ON content_change_log(
    json_extract(metadata, '$.page')
) WHERE json_extract(metadata, '$.page') IS NOT NULL;

-- Combined file + page from JSON (for file-page lookups)
CREATE INDEX IF NOT EXISTS idx_ccl_file_json_page ON content_change_log(
    file_name,
    json_extract(metadata, '$.page')
) WHERE json_extract(metadata, '$.page') IS NOT NULL;

-- ============================================================================
-- Table 5: faq_content_map
-- ============================================================================
-- Purpose: Link FAQs to content by checksum (not version!)
-- Key Innovation: FAQs follow content, not page positions
-- ✅ NOW WITH REAL FOREIGN KEYS (single database!)
-- ✅ Consistent with content_change_log: page numbers in metadata JSON
-- ============================================================================

CREATE TABLE faq_content_map (
    map_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ============================================================================
    -- FAQ IDENTIFICATION (✅ NOW WITH FK!)
    -- ============================================================================
    question_id INTEGER NOT NULL,
    answer_id INTEGER,

    -- ============================================================================
    -- CONTENT LINKING (Checksum-Centric)
    -- ============================================================================
    -- content_checksum: PRIMARY identity for FAQ-to-content mapping
    -- This is the key to FAQ validity - if checksum changes, FAQ is invalidated
    content_checksum TEXT NOT NULL CHECK(length(content_checksum) = 64),

    -- ============================================================================
    -- CURRENT LOCATION (Physical Location for Retrieval)
    -- ============================================================================
    -- current_content_id: FK to content_repo for retrieving markdown content
    -- current_file_name: For file-level queries and display
    current_content_id INTEGER NOT NULL,
    current_file_name TEXT NOT NULL,

    -- ============================================================================
    -- ORIGINAL CONTEXT (Audit Trail)
    -- ============================================================================
    -- Tracks where the FAQ was originally created (for audit/debugging)
    original_content_id INTEGER NOT NULL,
    created_for_version INTEGER NOT NULL DEFAULT 1,

    -- ============================================================================
    -- METADATA (Flexible JSON Storage - Consistent with content_change_log)
    -- ============================================================================
    -- Current location metadata (optional fields for all content types):
    --   {
    --     "current_page": 2,        // Optional (NULL for HTML/XML/single-page)
    --     "current_title": "...",
    --     "current_domain": "HR",
    --     "current_service": "Policy",
    --     "current_breadcrumb": "...",
    --     ... any other display/context fields
    --   }
    --
    -- Original location metadata (for audit trail):
    --   {
    --     "original_page": 2,       // Optional (NULL for HTML/XML/single-page)
    --     "original_title": "...",
    --     "original_domain": "HR",
    --     ... any other original context fields
    --   }
    --
    -- Design Rationale (same as content_change_log):
    --   - Architectural Consistency: Both tables handle optional page the same way
    --   - Flexibility: Add new fields without ALTER TABLE
    --   - Optional: Fields may not exist for all content types
    --   - Extensible: Future content types (sections, paragraphs) without schema changes
    --   - Clean: No NULL columns for unused fields
    --   - Human-Readable: For debugging/display, NOT business logic
    -- ============================================================================
    current_metadata JSON,
    original_metadata JSON,

    -- ============================================================================
    -- VALIDITY MANAGEMENT
    -- ============================================================================
    is_valid BOOLEAN NOT NULL DEFAULT 1 CHECK(is_valid IN (0,1)),

    -- ISO-8601 UTC timestamps: YYYY-MM-DDTHH:MM:SSZ
    valid_from TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    valid_until TEXT,

    -- ============================================================================
    -- INVALIDATION TRACKING (✅ NOW WITH FK!)
    -- ============================================================================
    invalidation_reason TEXT CHECK(
        invalidation_reason IS NULL OR
        invalidation_reason IN (
            'content_edited',          -- Content changed (checksum changed)
            'content_deleted',         -- Content removed
            'manual_invalidation',     -- Human decision
            'accuracy_issue',          -- Found incorrect
            'question_deprecated'      -- Question no longer relevant
        )
    ),
    invalidated_by_change_id INTEGER,
    replaced_by_map_id INTEGER,

    -- ============================================================================
    -- QUALITY METRICS
    -- ============================================================================
    confidence_score REAL CHECK(confidence_score IS NULL OR confidence_score BETWEEN 0 AND 1),
    generation_method TEXT,

    -- ============================================================================
    -- TIMESTAMPS (ISO-8601 UTC)
    -- ============================================================================
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    last_validated_at TEXT,

    -- ============================================================================
    -- FOREIGN KEY CONSTRAINTS (✅ REAL FKs - single database!)
    -- ============================================================================
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE,
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id) ON DELETE SET NULL,
    FOREIGN KEY (current_content_id) REFERENCES content_repo(ud_source_file_id) ON DELETE CASCADE,
    FOREIGN KEY (original_content_id) REFERENCES content_repo(ud_source_file_id) ON DELETE CASCADE,
    FOREIGN KEY (invalidated_by_change_id) REFERENCES content_change_log(change_id) ON DELETE SET NULL,
    FOREIGN KEY (replaced_by_map_id) REFERENCES faq_content_map(map_id) ON DELETE SET NULL,

    -- ============================================================================
    -- VALIDITY CONSTRAINT
    -- ============================================================================
    CHECK((is_valid = 1 AND valid_until IS NULL) OR (is_valid = 0 AND valid_until IS NOT NULL))
);

-- ============================================================================
-- Indexes for faq_content_map (Consistent with content_change_log)
-- ============================================================================

-- ============================================================================
-- PRIMARY LOOKUP INDEXES
-- ============================================================================

-- Checksum lookup (primary identity for FAQ-to-content mapping)
CREATE INDEX IF NOT EXISTS idx_fcm_checksum_valid ON faq_content_map(content_checksum, is_valid);

-- Question ID lookup
CREATE INDEX IF NOT EXISTS idx_fcm_question ON faq_content_map(question_id, is_valid);

-- Content ID lookup (for retrieving markdown)
CREATE INDEX IF NOT EXISTS idx_fcm_current ON faq_content_map(current_content_id, is_valid);

-- File name lookup (for file-level queries)
CREATE INDEX IF NOT EXISTS idx_fcm_file ON faq_content_map(current_file_name, is_valid);

-- ============================================================================
-- VALIDITY INDEXES
-- ============================================================================

-- Validity timeline queries
CREATE INDEX IF NOT EXISTS idx_fcm_validity ON faq_content_map(is_valid, valid_from, valid_until);

-- Invalidation tracking
CREATE INDEX IF NOT EXISTS idx_fcm_invalidation ON faq_content_map(invalidated_by_change_id)
    WHERE invalidated_by_change_id IS NOT NULL;

-- ============================================================================
-- METADATA QUERY INDEXES (JSON extraction - Consistent with content_change_log)
-- ============================================================================

-- Page number extraction from current_metadata JSON
-- Uses SQLite JSON1 extension: json_extract(current_metadata, '$.current_page')
-- Example: WHERE json_extract(current_metadata, '$.current_page') = 42
CREATE INDEX IF NOT EXISTS idx_fcm_current_page ON faq_content_map(
    json_extract(current_metadata, '$.current_page')
) WHERE json_extract(current_metadata, '$.current_page') IS NOT NULL AND is_valid = 1;

-- Combined file + page from JSON (common query: "get FAQs for file X, page Y")
-- Partial index for valid FAQs only (reduces index size)
CREATE INDEX IF NOT EXISTS idx_fcm_file_page ON faq_content_map(
    current_file_name,
    json_extract(current_metadata, '$.current_page'),
    content_checksum  -- Include for covering index (avoids table lookups)
) WHERE json_extract(current_metadata, '$.current_page') IS NOT NULL AND is_valid = 1;

-- ============================================================================
-- REMOVED: content_diffs table and related structures
-- ============================================================================
-- Reason: content_diffs relied on change_type classification (content_edit)
-- which has been removed in the simplified checksum-centric architecture.
-- The binary decision model (requires_faq_regeneration) doesn't track
-- edit types or previous versions, making diff storage unnecessary.
--
-- If detailed diff tracking is needed in the future, it should be implemented
-- as a separate offline process that compares checksums across detection runs.
-- ============================================================================

-- ============================================================================
-- VIEWS (Derived Data and Analytics)
-- ============================================================================
-- NOTE: Views updated for simplified checksum-centric architecture
-- Removed fields: change_type, page_number (top-level), previous_*, last_modified_dt
-- Uses JSON extraction for optional fields like page numbers
-- ============================================================================

-- ============================================================================
-- VIEW: v_current_valid_faqs
-- ============================================================================
-- Purpose: Current valid FAQs with latest detection context
-- Shows active FAQs with information about their associated content
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_current_valid_faqs AS
WITH latest_detections AS (
    SELECT
        content_checksum,
        change_id,
        content_id,
        file_name,
        requires_faq_regeneration,
        source_modified_at,
        detected_at,
        existing_faq_count,
        detection_run_id,
        metadata,
        ROW_NUMBER() OVER (
            PARTITION BY content_checksum
            ORDER BY detected_at DESC, change_id DESC
        ) as rn
    FROM content_change_log
)
SELECT
    fcm.map_id,
    fcm.question_id,
    fcm.answer_id,
    fcm.content_checksum,
    fcm.current_content_id,
    fcm.current_file_name,
    fcm.current_metadata,
    fcm.original_content_id,
    fcm.original_metadata,
    fcm.is_valid,
    fcm.valid_from,
    fcm.confidence_score,
    fcm.generation_method,
    fcm.created_at,
    fcm.last_validated_at,
    -- Latest detection context
    ld.requires_faq_regeneration as content_requires_regeneration,
    ld.source_modified_at as content_last_modified,
    ld.detected_at as content_last_detected,
    ld.detection_run_id as last_detection_run,
    ld.file_name as content_file_name,
    ld.metadata as content_metadata
FROM faq_content_map fcm
LEFT JOIN latest_detections ld
    ON fcm.content_checksum = ld.content_checksum
    AND ld.rn = 1
WHERE fcm.is_valid = 1;

-- ============================================================================
-- VIEW: v_faq_validity_timeline
-- ============================================================================
-- Purpose: FAQ validity timeline (for audit and reporting)
-- Extracts page numbers from JSON metadata for display
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_faq_validity_timeline AS
SELECT
    question_id,
    answer_id,
    content_checksum,
    current_file_name,
    json_extract(current_metadata, '$.current_page') as current_page_number,
    is_valid,
    valid_from,
    valid_until,
    invalidation_reason,
    CASE
        WHEN is_valid = 1 THEN 'Active'
        ELSE 'Invalidated'
    END as status,
    -- Calculate validity duration in days
    julianday(COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now'))) -
    julianday(valid_from) as validity_duration_days,
    created_at,
    last_validated_at,
    current_metadata,
    original_metadata
FROM faq_content_map;

-- ============================================================================
-- VIEW: v_faqs_needing_review
-- ============================================================================
-- Purpose: Identify FAQs that need review after being invalidated
-- Shows invalidated FAQs that haven't been replaced yet
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_faqs_needing_review AS
SELECT
    fcm.map_id,
    fcm.question_id,
    fcm.answer_id,
    fcm.content_checksum,
    fcm.current_file_name,
    json_extract(fcm.current_metadata, '$.current_page') as current_page_number,
    fcm.invalidation_reason,
    fcm.invalidated_by_change_id,
    fcm.valid_until as invalidated_at,
    -- Detection context for invalidating change
    ccl.requires_faq_regeneration,
    ccl.source_modified_at as content_changed_at,
    ccl.detected_at as change_detected_at,
    ccl.detection_run_id,
    ccl.existing_faq_count as faqs_affected,
    -- Calculate days since invalidation
    julianday(strftime('%Y-%m-%dT%H:%M:%SZ','now')) - julianday(fcm.valid_until) as days_since_invalidation
FROM faq_content_map fcm
LEFT JOIN content_change_log ccl
    ON fcm.invalidated_by_change_id = ccl.change_id
WHERE fcm.is_valid = 0
  AND fcm.replaced_by_map_id IS NULL  -- Not yet replaced
ORDER BY days_since_invalidation DESC;

-- ============================================================================
-- VIEW: v_content_detection_summary
-- ============================================================================
-- Purpose: Summary of content detections by file and regeneration requirement
-- Replaces v_content_change_summary (updated for simplified schema)
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_content_detection_summary AS
SELECT
    file_name,
    requires_faq_regeneration,
    COUNT(*) as detection_count,
    MIN(source_modified_at) as earliest_modification,
    MAX(source_modified_at) as latest_modification,
    MIN(detected_at) as first_detection,
    MAX(detected_at) as last_detection,
    COUNT(DISTINCT content_checksum) as unique_checksums,
    SUM(existing_faq_count) as total_faqs_affected,
    COUNT(DISTINCT detection_run_id) as detection_runs
FROM content_change_log
GROUP BY file_name, requires_faq_regeneration;

-- ============================================================================
-- VIEW: v_latest_content_checksums
-- ============================================================================
-- Purpose: Latest checksum for each file (with optional page from JSON)
-- Replaces v_latest_content_state (updated for simplified schema)
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_latest_content_checksums AS
WITH latest_detections AS (
    SELECT
        content_id,
        file_name,
        json_extract(metadata, '$.page') as page_number,
        content_checksum,
        requires_faq_regeneration,
        source_modified_at,
        detected_at,
        existing_faq_count,
        metadata,
        ROW_NUMBER() OVER (
            PARTITION BY content_id
            ORDER BY detected_at DESC, change_id DESC
        ) as rn
    FROM content_change_log
)
SELECT
    content_id,
    file_name,
    page_number,
    content_checksum,
    requires_faq_regeneration,
    source_modified_at as last_modified_at,
    detected_at as last_detected_at,
    existing_faq_count,
    metadata
FROM latest_detections
WHERE rn = 1;

-- ============================================================================
-- VIEW: v_regeneration_queue
-- ============================================================================
-- Purpose: Content requiring FAQ regeneration (processing queue)
-- Ordered by impact (existing FAQ count) and modification time
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_regeneration_queue AS
SELECT
    ccl.change_id,
    ccl.content_id,
    ccl.content_checksum,
    ccl.file_name,
    json_extract(ccl.metadata, '$.page') as page_number,
    ccl.source_modified_at,
    ccl.detected_at,
    ccl.existing_faq_count,
    ccl.detection_run_id,
    ccl.metadata,
    -- Priority score (higher = more urgent)
    -- Weighted by FAQ impact and recency
    (ccl.existing_faq_count * 100) +
    (julianday('now') - julianday(ccl.source_modified_at)) as priority_score
FROM content_change_log ccl
WHERE ccl.requires_faq_regeneration = 1
ORDER BY priority_score DESC, ccl.detected_at DESC;

-- ============================================================================
-- VIEW: v_detection_run_stats
-- ============================================================================
-- Purpose: Statistics for each detection run (batch analytics)
-- Helps track detection performance and results over time
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_detection_run_stats AS
SELECT
    detection_run_id,
    MIN(detected_at) as run_started_at,
    MAX(detected_at) as run_completed_at,
    COUNT(*) as total_pages_analyzed,
    SUM(CASE WHEN requires_faq_regeneration = 1 THEN 1 ELSE 0 END) as pages_requiring_regeneration,
    SUM(CASE WHEN requires_faq_regeneration = 0 THEN 1 ELSE 0 END) as pages_not_requiring_regeneration,
    SUM(existing_faq_count) as total_existing_faqs,
    SUM(CASE WHEN requires_faq_regeneration = 1 THEN existing_faq_count ELSE 0 END) as faqs_to_invalidate,
    COUNT(DISTINCT file_name) as files_processed,
    COUNT(DISTINCT content_checksum) as unique_checksums_detected,
    MIN(since_date) as detection_period_start
FROM content_change_log
WHERE detection_run_id IS NOT NULL
GROUP BY detection_run_id
ORDER BY run_started_at DESC;

-- ============================================================================
-- SCHEMA VERSION TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS schema_version (
    version_id INTEGER PRIMARY KEY,
    schema_version TEXT NOT NULL,
    applied_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    description TEXT,
    applied_by TEXT DEFAULT 'system'
);

-- Insert schema version (idempotent)
INSERT OR IGNORE INTO schema_version (version_id, schema_version, description)
VALUES (1, '4.0', 'Single database architecture with REAL foreign keys - All tables in faq_update.db');

-- ============================================================================
-- DESIGN NOTES & ENHANCEMENTS
-- ============================================================================
/*
KEY IMPROVEMENTS IN VERSION 4.0 (SINGLE DATABASE ARCHITECTURE):

1. ✅ ALL TABLES IN ONE DATABASE (faq_update.db)
   - content_repo, faq_questions, faq_answers (base tables)
   - content_change_log, faq_content_map, content_diffs (tracking tables)
   - schema_version (metadata)

2. ✅ REAL FOREIGN KEY CONSTRAINTS
   - SQLite can enforce ALL FK constraints within same database
   - No more application-level validation needed
   - ON DELETE CASCADE/SET NULL for referential integrity
   - Database guarantees consistency

3. ✅ ACID TRANSACTIONS
   - All changes atomic across all tables
   - No risk of orphaned records
   - Simpler error handling

4. ✅ SIMPLER QUERIES
   - No ATTACH DATABASE statements needed
   - Direct JOINs across all tables
   - Better query optimizer performance

5. ✅ PREVIOUS FEATURES RETAINED
   - Content diff storage and analysis (v3.1)
   - VIEW-based structural changes (v3.0)
   - Idempotency guarantees (v3.0)
   - Enhanced indexes (v3.0)
   - Proper time semantics (v3.0)
   - Race condition prevention (v3.0)

FOREIGN KEY CHAIN:
content_repo (ud_source_file_id)
    ↓ FK
content_change_log (content_id, previous_content_id)
    ↓ FK
content_diffs (change_id)

faq_questions (question_id)
    ↓ FK
faq_answers (question_id) ──────┐
                               │
faq_questions (question_id) ←──┤
                               ├─ FK
faq_answers (answer_id) ←──────┤
                               ↓
                        faq_content_map
                               ↓ FK
                        content_repo (current_content_id, original_content_id)
                               ↑ FK
                        content_change_log (invalidated_by_change_id)

MIGRATION FROM V3.X:
- Combine separate databases into single faq_update.db
- Add content_repo, faq_questions, faq_answers tables
- Update content_change_log with FK constraints
- Update faq_content_map with FK constraints
- Run PRAGMA foreign_key_check to verify integrity
- Test CASCADE/SET NULL behavior

IMPORTANT NOTES:
- PRAGMA foreign_keys = ON must be set for EVERY connection
- All timestamps use strftime('%Y-%m-%dT%H:%M:%SZ','now')
- Idempotent inserts use UNIQUE constraint on (content_id, detection_run_id)
- JSON metadata uses json_extract() for queries
- No content_diffs table in v4 (removed for simplicity)
*/

-- ============================================================================
-- TRANSACTION COMMIT AND RE-ENABLE FOREIGN KEYS
-- ============================================================================

COMMIT;

PRAGMA foreign_keys = ON;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
-- Run these to verify schema was created successfully

SELECT '✅ Schema v4 applied successfully!' as status;

SELECT 'Tables created:' as info;
SELECT name as table_name FROM sqlite_master
WHERE type='table' AND name IN (
    'content_repo', 'faq_questions', 'faq_answers',
    'content_change_log', 'faq_content_map', 'schema_version'
)
ORDER BY name;

SELECT 'Views created:' as info;
SELECT name as view_name FROM sqlite_master
WHERE type='view' AND name LIKE 'v_%'
ORDER BY name;

-- Verify content_change_log has v4 schema
SELECT '✅ content_change_log schema check:' as info;
PRAGMA table_info(content_change_log);

-- Verify faq_content_map has v4 schema
SELECT '✅ faq_content_map schema check:' as info;
PRAGMA table_info(faq_content_map);

-- Verify content_diffs is removed
SELECT '✅ content_diffs removed:' as info;
SELECT COUNT(*) as should_be_zero FROM sqlite_master
WHERE type='table' AND name='content_diffs';

SELECT '⚠️  Note: All data in content_change_log and faq_content_map was DROPPED' as warning;
SELECT 'Ready for fresh FAQ regeneration detection!' as next_step;
