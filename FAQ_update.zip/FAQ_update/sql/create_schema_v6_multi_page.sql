-- ============================================================================
-- FAQ UPDATE DATABASE - PRODUCTION SCHEMA V6.0
-- ============================================================================
-- Architecture: Multi-Page FAQ Support with Granular Provenance Tracking
-- Date: 2025-10-21
-- Author: Principal Application Architect
-- Target: Databricks Unity Catalog (DBR 10.4+)
--
-- KEY ARCHITECTURAL CHANGES FROM V5:
-- 1. ✅ Supports FAQs referencing MULTIPLE pages (many-to-many relationship)
-- 2. ✅ Separate tracking for question sources vs answer sources
-- 3. ✅ Partial invalidation support (some pages changed, not all)
-- 4. ✅ Contribution weighting (which pages matter most)
-- 5. ✅ page_number is now REQUIRED (not nullable) in content_repo
-- ============================================================================

-- ============================================================================
-- SETUP
-- ============================================================================
-- USE CATALOG your_catalog_name;
-- USE SCHEMA your_schema_name;

-- Drop existing objects
DROP VIEW IF EXISTS v_active_faqs_with_sources;
DROP VIEW IF EXISTS v_faqs_needing_review;
DROP VIEW IF EXISTS v_content_changes_summary;
DROP VIEW IF EXISTS v_faq_regeneration_queue;

DROP TABLE IF EXISTS faq_audit_log;
DROP TABLE IF EXISTS faq_answer_sources;
DROP TABLE IF EXISTS faq_question_sources;
DROP TABLE IF EXISTS content_change_log;
DROP TABLE IF EXISTS faq_answers;
DROP TABLE IF EXISTS faq_questions;
DROP TABLE IF EXISTS content_repo;

-- ============================================================================
-- TABLE 1: content_repo
-- ============================================================================
-- Purpose: Source content repository - ONE ROW PER PAGE
-- Each page has its own checksum, representing a unique content version
-- ============================================================================

CREATE TABLE content_repo (
    -- Primary Key
    content_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Content Identity (immutable once set)
    content_checksum STRING NOT NULL COMMENT 'SHA-256 hash of THIS PAGE content (64 chars)',

    -- File Identification
    file_name STRING NOT NULL COMMENT 'Source file name (e.g., employee_handbook.pdf)',
    file_type STRING COMMENT 'File type (PDF, DOCX, HTML, XML)',

    -- Page Identity (REQUIRED - each row represents ONE page)
    page_number INT NOT NULL COMMENT 'Page number within the file (always present)',

    -- File Paths
    source_file_path STRING COMMENT 'Original file path or URL',
    markdown_file_path STRING NOT NULL COMMENT 'Extracted markdown for THIS PAGE',

    -- Content Metadata
    title STRING COMMENT 'Page/section title',
    breadcrumb STRING COMMENT 'Navigation breadcrumb',

    -- Organization Context
    domain STRING COMMENT 'Business domain (HR, IT, Finance, etc.)',
    service STRING COMMENT 'Service area (Policy, Benefits, Payroll, etc.)',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, inactive, deleted, archived',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Last content modification',

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'Source content repository - ONE ROW PER PAGE with unique checksum'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);

-- Constraints
ALTER TABLE content_repo ADD CONSTRAINT pk_content_repo PRIMARY KEY (content_id);
ALTER TABLE content_repo ADD CONSTRAINT chk_content_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_repo ADD CONSTRAINT chk_content_status CHECK (status IN ('active', 'inactive', 'deleted', 'archived'));
ALTER TABLE content_repo ADD CONSTRAINT chk_page_number_positive CHECK (page_number > 0);

-- Business constraint: One checksum per file+page combination at any time
-- (A page can have different checksums over time as content changes, but not simultaneously)
ALTER TABLE content_repo ADD CONSTRAINT unique_file_page_active
    UNIQUE (file_name, page_number, status);

-- Enable column defaults
ALTER TABLE content_repo SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 2: faq_questions
-- ============================================================================
-- Purpose: FAQ questions (content-agnostic - just the question text)
-- ============================================================================

CREATE TABLE faq_questions (
    -- Primary Key
    question_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Question Content
    question_text STRING NOT NULL COMMENT 'The actual FAQ question',

    -- Generation Metadata
    source_type STRING COMMENT 'from_documents, from_user_queries, from_manual, from_validation',
    generation_method STRING COMMENT 'llm_generated, human_written, extracted',

    -- Organization Context (for multi-tenancy)
    domain STRING COMMENT 'Business domain',
    service STRING COMMENT 'Service area',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ questions - content-agnostic'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_questions ADD CONSTRAINT pk_faq_questions PRIMARY KEY (question_id);
ALTER TABLE faq_questions ADD CONSTRAINT chk_question_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));

-- Enable column defaults
ALTER TABLE faq_questions SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 3: faq_question_sources
-- ============================================================================
-- Purpose: MANY-TO-MANY - Links questions to the pages that inspired them
-- A question can be inspired by multiple pages
-- ============================================================================

CREATE TABLE faq_question_sources (
    -- Primary Key
    source_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Keys
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',
    content_id BIGINT NOT NULL COMMENT 'FK to content_repo (which page inspired this question)',
    content_checksum STRING NOT NULL COMMENT 'Checksum at time of generation (immutable)',

    -- Contribution Tracking
    is_primary_source BOOLEAN DEFAULT FALSE COMMENT 'Is this the primary page for this question?',
    contribution_weight DOUBLE COMMENT 'How much this page contributed (0.0 to 1.0)',

    -- Validity Tracking
    is_valid BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this source still valid?',
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP COMMENT 'When this source was invalidated (NULL if still valid)',

    -- Invalidation Details
    invalidation_reason STRING COMMENT 'content_changed, content_deleted, manual',
    invalidated_by_change_id BIGINT COMMENT 'FK to content_change_log',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Question provenance - which pages inspired each question'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_question_sources ADD CONSTRAINT pk_faq_question_sources PRIMARY KEY (source_id);
ALTER TABLE faq_question_sources ADD CONSTRAINT chk_qsrc_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE faq_question_sources ADD CONSTRAINT chk_qsrc_contribution CHECK (
    contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
);

-- Prevent duplicate sources for same question
ALTER TABLE faq_question_sources ADD CONSTRAINT unique_question_content
    UNIQUE (question_id, content_id, content_checksum);

-- Enable column defaults
ALTER TABLE faq_question_sources SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 4: faq_answers
-- ============================================================================
-- Purpose: FAQ answers (1:1 with questions, but sources tracked separately)
-- ============================================================================

CREATE TABLE faq_answers (
    -- Primary Key
    answer_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key to Question (1:1 relationship)
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',

    -- Answer Content
    answer_text STRING NOT NULL COMMENT 'The FAQ answer (HTML or Markdown)',
    answer_format STRING DEFAULT 'html' COMMENT 'html, markdown, plain',

    -- Quality Metrics
    confidence_score DOUBLE COMMENT 'Generation confidence (0.0 to 1.0)',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ answers - linked to questions (1:1), sources tracked separately'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_answers ADD CONSTRAINT pk_faq_answers PRIMARY KEY (answer_id);
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_format CHECK (answer_format IN ('html', 'markdown', 'plain'));
ALTER TABLE faq_answers ADD CONSTRAINT chk_confidence_score CHECK (
    confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0)
);

-- Enable column defaults
ALTER TABLE faq_answers SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 5: faq_answer_sources
-- ============================================================================
-- Purpose: MANY-TO-MANY - Links answers to the pages that provided the content
-- An answer can synthesize information from MULTIPLE pages
-- ============================================================================

CREATE TABLE faq_answer_sources (
    -- Primary Key
    source_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Keys
    answer_id BIGINT NOT NULL COMMENT 'FK to faq_answers',
    content_id BIGINT NOT NULL COMMENT 'FK to content_repo (which page provided answer content)',
    content_checksum STRING NOT NULL COMMENT 'Checksum at time of generation (immutable)',

    -- Contribution Tracking
    is_primary_source BOOLEAN DEFAULT FALSE COMMENT 'Is this the primary page for this answer?',
    contribution_weight DOUBLE COMMENT 'How much this page contributed (0.0 to 1.0, should sum to 1.0)',

    -- Context Employment (optional - if you track which parts of the page were used)
    context_employed STRING COMMENT 'JSON: which sections/paragraphs were used',

    -- Validity Tracking
    is_valid BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this source still valid?',
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP COMMENT 'When this source was invalidated (NULL if still valid)',

    -- Invalidation Details
    invalidation_reason STRING COMMENT 'content_changed, content_deleted, manual',
    invalidated_by_change_id BIGINT COMMENT 'FK to content_change_log',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Answer provenance - which pages provided content for each answer'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_answer_sources ADD CONSTRAINT pk_faq_answer_sources PRIMARY KEY (source_id);
ALTER TABLE faq_answer_sources ADD CONSTRAINT chk_asrc_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE faq_answer_sources ADD CONSTRAINT chk_asrc_contribution CHECK (
    contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
);

-- Prevent duplicate sources for same answer
ALTER TABLE faq_answer_sources ADD CONSTRAINT unique_answer_content
    UNIQUE (answer_id, content_id, content_checksum);

-- Enable column defaults
ALTER TABLE faq_answer_sources SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 6: content_change_log
-- ============================================================================
-- Purpose: Detection log - tracks content changes and regeneration decisions
-- ============================================================================

CREATE TABLE content_change_log (
    -- Primary Key
    change_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Content Identity
    content_id BIGINT NOT NULL COMMENT 'FK to content_repo',
    content_checksum STRING NOT NULL COMMENT 'NEW checksum after change',
    previous_checksum STRING COMMENT 'OLD checksum before change (NULL for new content)',

    file_name STRING NOT NULL,
    page_number INT NOT NULL,

    -- Detection Decision (Binary)
    requires_faq_regeneration BOOLEAN NOT NULL COMMENT 'TRUE = new/modified, FALSE = unchanged',

    -- Change Classification
    change_type STRING COMMENT 'new_content, modified_content, unchanged_content, deleted_content',

    -- FAQ Impact Metrics
    affected_question_count INT NOT NULL DEFAULT 0 COMMENT 'How many questions reference this page',
    affected_answer_count INT NOT NULL DEFAULT 0 COMMENT 'How many answers reference this page',
    total_affected_faqs INT NOT NULL DEFAULT 0 COMMENT 'Total unique FAQs affected',

    -- Detection Context
    detection_run_id STRING NOT NULL COMMENT 'Unique identifier for detection batch',
    detection_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    detection_period_start TIMESTAMP COMMENT 'since_date parameter used in detection',

    -- Source Metadata
    source_modified_at TIMESTAMP COMMENT 'When the source content was last modified',

    -- Organization Context
    domain STRING,
    service STRING
)
COMMENT 'Content change detection log - tracks regeneration decisions per page'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE content_change_log ADD CONSTRAINT pk_content_change_log PRIMARY KEY (change_id);
ALTER TABLE content_change_log ADD CONSTRAINT chk_ccl_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_change_log ADD CONSTRAINT chk_ccl_prev_checksum_len CHECK (
    previous_checksum IS NULL OR LENGTH(previous_checksum) = 64
);
ALTER TABLE content_change_log ADD CONSTRAINT chk_change_type CHECK (
    change_type IS NULL OR
    change_type IN ('new_content', 'modified_content', 'unchanged_content', 'deleted_content')
);

-- Enable column defaults
ALTER TABLE content_change_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Prevent duplicate detections for same content in same run
ALTER TABLE content_change_log ADD CONSTRAINT unique_content_detection
    UNIQUE (content_id, detection_run_id);

-- ============================================================================
-- TABLE 7: faq_audit_log
-- ============================================================================
-- Purpose: Complete audit trail for all FAQ operations
-- ============================================================================

CREATE TABLE faq_audit_log (
    -- Primary Key
    audit_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- What Changed
    table_name STRING NOT NULL COMMENT 'Table affected',
    record_id BIGINT NOT NULL COMMENT 'Primary key of affected record',

    -- Action Details
    action STRING NOT NULL COMMENT 'INSERT, UPDATE, DELETE, INVALIDATE, RESTORE',

    -- Change Details
    old_values STRING COMMENT 'JSON snapshot before change',
    new_values STRING COMMENT 'JSON snapshot after change',

    -- Context
    detection_run_id STRING COMMENT 'Related detection run (if applicable)',
    change_reason STRING COMMENT 'Why this change was made',

    -- Who & When
    performed_by STRING NOT NULL DEFAULT 'system',
    performed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Complete audit trail for all FAQ operations'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_audit_log ADD CONSTRAINT pk_faq_audit_log PRIMARY KEY (audit_id);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_table CHECK (
    table_name IN ('faq_questions', 'faq_answers', 'faq_question_sources', 'faq_answer_sources', 'content_repo')
);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_action CHECK (
    action IN ('INSERT', 'UPDATE', 'DELETE', 'INVALIDATE', 'RESTORE')
);

-- Enable column defaults
ALTER TABLE faq_audit_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- VIEWS - Common Query Patterns
-- ============================================================================

-- ============================================================================
-- VIEW: v_active_faqs_with_sources
-- ============================================================================
-- Purpose: All active FAQs with their source pages (question and answer)
-- ============================================================================

CREATE OR REPLACE VIEW v_active_faqs_with_sources AS
SELECT
    q.question_id,
    q.question_text,
    a.answer_id,
    a.answer_text,
    a.answer_format,
    a.confidence_score,

    -- Question sources (aggregated)
    CONCAT_WS(', ', COLLECT_LIST(DISTINCT qsrc.content_id)) as question_source_content_ids,
    CONCAT_WS(', ', COLLECT_LIST(DISTINCT qsrc.content_checksum)) as question_source_checksums,
    COUNT(DISTINCT qsrc.source_id) as question_source_count,
    SUM(CASE WHEN qsrc.is_valid = TRUE THEN 1 ELSE 0 END) as question_sources_valid_count,

    -- Answer sources (aggregated)
    CONCAT_WS(', ', COLLECT_LIST(DISTINCT asrc.content_id)) as answer_source_content_ids,
    CONCAT_WS(', ', COLLECT_LIST(DISTINCT asrc.content_checksum)) as answer_source_checksums,
    COUNT(DISTINCT asrc.source_id) as answer_source_count,
    SUM(CASE WHEN asrc.is_valid = TRUE THEN 1 ELSE 0 END) as answer_sources_valid_count,

    -- Overall validity
    CASE
        WHEN SUM(CASE WHEN qsrc.is_valid = FALSE OR asrc.is_valid = FALSE THEN 1 ELSE 0 END) = 0 THEN 'fully_valid'
        WHEN SUM(CASE WHEN qsrc.is_valid = FALSE OR asrc.is_valid = FALSE THEN 1 ELSE 0 END) > 0
         AND SUM(CASE WHEN qsrc.is_valid = TRUE AND asrc.is_valid = TRUE THEN 1 ELSE 0 END) > 0 THEN 'partially_valid'
        ELSE 'invalid'
    END as validity_status,

    q.domain,
    q.service,
    q.created_at as question_created_at,
    a.created_at as answer_created_at

FROM faq_questions q
INNER JOIN faq_answers a ON q.question_id = a.question_id
LEFT JOIN faq_question_sources qsrc ON q.question_id = qsrc.question_id
LEFT JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
WHERE q.status = 'active'
  AND a.status = 'active'
GROUP BY
    q.question_id, q.question_text, a.answer_id, a.answer_text,
    a.answer_format, a.confidence_score, q.domain, q.service,
    q.created_at, a.created_at;

-- ============================================================================
-- VIEW: v_faqs_needing_review
-- ============================================================================
-- Purpose: FAQs with partially invalidated sources (need human review)
-- ============================================================================

CREATE OR REPLACE VIEW v_faqs_needing_review AS
SELECT
    q.question_id,
    q.question_text,
    a.answer_id,

    -- Invalid question sources
    COUNT(DISTINCT CASE WHEN qsrc.is_valid = FALSE THEN qsrc.source_id END) as invalid_question_sources,
    COUNT(DISTINCT CASE WHEN qsrc.is_valid = TRUE THEN qsrc.source_id END) as valid_question_sources,

    -- Invalid answer sources
    COUNT(DISTINCT CASE WHEN asrc.is_valid = FALSE THEN asrc.source_id END) as invalid_answer_sources,
    COUNT(DISTINCT CASE WHEN asrc.is_valid = TRUE THEN asrc.source_id END) as valid_answer_sources,

    -- Invalidation reasons
    CONCAT_WS(', ', COLLECT_SET(qsrc.invalidation_reason)) as question_invalidation_reasons,
    CONCAT_WS(', ', COLLECT_SET(asrc.invalidation_reason)) as answer_invalidation_reasons,

    -- Most recent invalidation
    MAX(GREATEST(COALESCE(qsrc.valid_until, '1900-01-01'), COALESCE(asrc.valid_until, '1900-01-01'))) as last_invalidation_time,

    q.domain,
    q.service

FROM faq_questions q
INNER JOIN faq_answers a ON q.question_id = a.question_id
LEFT JOIN faq_question_sources qsrc ON q.question_id = qsrc.question_id
LEFT JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
WHERE q.status = 'active'
  AND a.status = 'active'
  AND (qsrc.is_valid = FALSE OR asrc.is_valid = FALSE)
GROUP BY q.question_id, q.question_text, a.answer_id, q.domain, q.service
ORDER BY last_invalidation_time DESC;

-- ============================================================================
-- VIEW: v_content_changes_summary
-- ============================================================================
-- Purpose: Summary of content changes by detection run
-- ============================================================================

CREATE OR REPLACE VIEW v_content_changes_summary AS
SELECT
    detection_run_id,
    MIN(detection_timestamp) as detection_started_at,
    MAX(detection_timestamp) as detection_completed_at,
    COUNT(*) as total_pages_analyzed,
    SUM(CASE WHEN requires_faq_regeneration = TRUE THEN 1 ELSE 0 END) as pages_requiring_regeneration,
    SUM(CASE WHEN requires_faq_regeneration = FALSE THEN 1 ELSE 0 END) as pages_unchanged,
    SUM(total_affected_faqs) as total_faqs_impacted,
    SUM(affected_question_count) as total_questions_affected,
    SUM(affected_answer_count) as total_answers_affected,
    COUNT(DISTINCT file_name) as unique_files,
    COUNT(DISTINCT content_checksum) as unique_checksums,
    COUNT(DISTINCT CASE WHEN change_type = 'new_content' THEN content_id END) as new_pages,
    COUNT(DISTINCT CASE WHEN change_type = 'modified_content' THEN content_id END) as modified_pages,
    COUNT(DISTINCT CASE WHEN change_type = 'deleted_content' THEN content_id END) as deleted_pages
FROM content_change_log
GROUP BY detection_run_id
ORDER BY detection_started_at DESC;

-- ============================================================================
-- VIEW: v_faq_regeneration_queue
-- ============================================================================
-- Purpose: Processing queue for FAQ regeneration (prioritized by impact)
-- ============================================================================

CREATE OR REPLACE VIEW v_faq_regeneration_queue AS
SELECT
    ccl.change_id,
    ccl.content_id,
    ccl.content_checksum,
    ccl.previous_checksum,
    ccl.file_name,
    ccl.page_number,
    ccl.total_affected_faqs,
    ccl.affected_question_count,
    ccl.affected_answer_count,
    ccl.detection_run_id,
    ccl.detection_timestamp,
    ccl.source_modified_at,
    c.title,
    c.domain,
    c.service,
    c.markdown_file_path,

    -- Priority calculation (higher = more urgent)
    -- Weighted by FAQ impact (100 points per FAQ) and recency (1 point per day old)
    (ccl.total_affected_faqs * 100) +
    DATEDIFF(CURRENT_TIMESTAMP(), ccl.source_modified_at) as priority_score

FROM content_change_log ccl
INNER JOIN content_repo c ON ccl.content_id = c.content_id
WHERE ccl.requires_faq_regeneration = TRUE
  AND c.status = 'active'
ORDER BY priority_score DESC, ccl.detection_timestamp DESC;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- SELECT '✅ Schema V6.0 deployed successfully!' as status;
-- SHOW TABLES;
-- SHOW VIEWS;

-- ============================================================================
-- END OF SCHEMA V6.0
-- ============================================================================