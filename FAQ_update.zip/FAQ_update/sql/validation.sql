-- ============================================================================
-- CONTENT VERSION TRACKING - VALIDATION & HEALTH CHECKS
-- Version: 3.0
-- Purpose: Comprehensive validation queries to ensure data integrity
-- Date: 2025-10-06
-- ============================================================================

-- ============================================================================
-- SECTION 1: SCHEMA VALIDATION
-- ============================================================================

-- 1.1: Verify all required tables exist
-- Expected: All tables should exist (including content_diffs)
SELECT
    'Schema Check' as check_category,
    'Required tables exist' as check_name,
    CASE
        WHEN COUNT(*) = 3 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as found_count,
    3 as expected_count,
    GROUP_CONCAT(name, ', ') as found_tables
FROM sqlite_master
WHERE type = 'table'
  AND name IN ('content_change_log', 'faq_content_map', 'content_diffs', 'schema_version');

-- 1.2: Verify all required views exist
-- Expected: All views should exist (including diff-related views)
SELECT
    'Schema Check' as check_category,
    'Required views exist' as check_name,
    CASE
        WHEN COUNT(*) = 8 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as found_count,
    8 as expected_count,
    GROUP_CONCAT(name, ', ') as found_views
FROM sqlite_master
WHERE type = 'view'
  AND name IN (
      'v_document_structure_changes',
      'v_current_valid_faqs',
      'v_faq_validity_timeline',
      'v_faqs_needing_review',
      'v_latest_content_state',
      'v_content_changes_with_diffs',
      'v_pending_diffs',
      'v_diff_processing_stats'
  );

-- 1.3: Verify all required indexes exist
-- Expected: All critical indexes should exist
SELECT
    'Schema Check' as check_category,
    'Critical indexes exist' as check_name,
    CASE
        WHEN COUNT(*) >= 10 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as found_count,
    'At least 10' as expected_count,
    GROUP_CONCAT(name, ', ') as found_indexes
FROM sqlite_master
WHERE type = 'index'
  AND name LIKE 'idx_%';

-- ============================================================================
-- SECTION 2: TIMESTAMP FORMAT VALIDATION (CRITICAL)
-- ============================================================================

-- 2.1: Verify detected_at timestamps use ISO-8601 format with 'Z'
-- Expected: All timestamps should end with 'Z' (UTC indicator)
-- CRITICAL: Timestamps MUST use strftime('%Y-%m-%dT%H:%M:%SZ','now') format
SELECT
    'Timestamp Check' as check_category,
    'detected_at has ISO-8601 UTC format (ends with Z)' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count,
    CASE
        WHEN invalid_count > 0 THEN 'Some timestamps missing Z suffix'
        ELSE 'All timestamps valid'
    END as details
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN detected_at NOT LIKE '%Z' THEN 1 ELSE 0 END) as invalid_count
    FROM content_change_log
);

-- 2.2: Verify effective_date timestamps use ISO-8601 format
-- Expected: All timestamps should be valid ISO-8601 (can have or not have Z)
SELECT
    'Timestamp Check' as check_category,
    'effective_date has valid ISO-8601 format' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count,
    CASE
        WHEN invalid_count > 0 THEN 'Some timestamps have invalid format'
        ELSE 'All timestamps valid'
    END as details
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE
            WHEN effective_date NOT LIKE '____-__-__T__:__:%'
                AND effective_date NOT LIKE '____-__-__ __:__:%'
            THEN 1
            ELSE 0
        END) as invalid_count
    FROM content_change_log
);

-- 2.3: Verify valid_from timestamps in faq_content_map
SELECT
    'Timestamp Check' as check_category,
    'faq_content_map.valid_from has ISO-8601 UTC format' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN valid_from NOT LIKE '%Z' THEN 1 ELSE 0 END) as invalid_count
    FROM faq_content_map
);

-- 2.4: Verify created_at timestamps in faq_content_map
SELECT
    'Timestamp Check' as check_category,
    'faq_content_map.created_at has ISO-8601 UTC format' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN created_at NOT LIKE '%Z' THEN 1 ELSE 0 END) as invalid_count
    FROM faq_content_map
);

-- 2.5: Verify diff_generated_at timestamps in content_diffs
SELECT
    'Timestamp Check' as check_category,
    'content_diffs.diff_generated_at has ISO-8601 UTC format' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN diff_generated_at NOT LIKE '%Z' THEN 1 ELSE 0 END) as invalid_count
    FROM content_diffs
);

-- ============================================================================
-- SECTION 3: CHECKSUM VALIDATION
-- ============================================================================

-- 3.1: Verify all content checksums are valid SHA-256 (64 hex chars)
-- Expected: All checksums should be exactly 64 characters
SELECT
    'Checksum Check' as check_category,
    'content_checksum is valid SHA-256' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count,
    CASE
        WHEN invalid_count > 0 THEN 'Some checksums are not 64 chars'
        ELSE 'All checksums valid'
    END as details
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN length(content_checksum) != 64 THEN 1 ELSE 0 END) as invalid_count
    FROM content_change_log
);

-- 3.2: Verify faq_content_map checksums
SELECT
    'Checksum Check' as check_category,
    'faq_content_map.content_checksum is valid SHA-256' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN length(content_checksum) != 64 THEN 1 ELSE 0 END) as invalid_count
    FROM faq_content_map
);

-- 3.3: Verify content_diffs checksums (old_checksum)
SELECT
    'Checksum Check' as check_category,
    'content_diffs.old_checksum is valid SHA-256' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN length(old_checksum) != 64 THEN 1 ELSE 0 END) as invalid_count
    FROM content_diffs
);

-- 3.4: Verify content_diffs checksums (new_checksum)
SELECT
    'Checksum Check' as check_category,
    'content_diffs.new_checksum is valid SHA-256' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    total_count as total_records,
    invalid_count
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN length(new_checksum) != 64 THEN 1 ELSE 0 END) as invalid_count
    FROM content_diffs
);

-- 3.5: Identify checksums with non-hex characters
-- Expected: All checksums should contain only hex chars (0-9, a-f)
SELECT
    'Checksum Check' as check_category,
    'Checksums contain only hex characters' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    'Checksums should only contain 0-9 and a-f' as expected
FROM (
    SELECT
        COUNT(*) as invalid_count
    FROM content_change_log
    WHERE content_checksum GLOB '*[^0-9a-fA-F]*'
);

-- ============================================================================
-- SECTION 4: IDEMPOTENCY VALIDATION (Fix 8)
-- ============================================================================

-- 4.1: Check for duplicate change records (should be prevented by idx_ccl_idempotent)
-- Expected: No duplicates
SELECT
    'Idempotency Check' as check_category,
    'No duplicate change records' as check_name,
    CASE
        WHEN duplicate_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    duplicate_count,
    'idx_ccl_idempotent should prevent duplicates' as note
FROM (
    SELECT COUNT(*) as duplicate_count
    FROM (
        SELECT
            file_name,
            page_number,
            content_checksum,
            change_type,
            effective_date,
            COUNT(*) as occurrences
        FROM content_change_log
        GROUP BY file_name, page_number, content_checksum, change_type, effective_date
        HAVING COUNT(*) > 1
    )
);

-- 4.2: List any duplicate records if found (for debugging)
SELECT
    'Idempotency Check' as check_category,
    'Duplicate records detail' as check_name,
    file_name,
    page_number,
    content_checksum,
    change_type,
    effective_date,
    COUNT(*) as duplicate_count
FROM content_change_log
GROUP BY file_name, page_number, content_checksum, change_type, effective_date
HAVING COUNT(*) > 1;

-- ============================================================================
-- SECTION 5: DATA INTEGRITY CHECKS
-- ============================================================================

-- 5.1: Verify page numbers are positive
SELECT
    'Data Integrity' as check_category,
    'All page numbers are positive' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    total_count as total_records
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN page_number <= 0 THEN 1 ELSE 0 END) as invalid_count
    FROM content_change_log
);

-- 5.2: Verify change_type values are valid
SELECT
    'Data Integrity' as check_category,
    'All change_type values are valid' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT
        COUNT(*) as invalid_count
    FROM content_change_log
    WHERE change_type NOT IN (
        'initial_creation', 'content_edit', 'position_change',
        'page_inserted', 'page_deleted'
    )
);

-- 5.3: Verify confidence scores are between 0 and 1
SELECT
    'Data Integrity' as check_category,
    'Confidence scores in valid range [0,1]' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    total_count as total_records
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE
            WHEN confidence_score IS NOT NULL
                AND (confidence_score < 0 OR confidence_score > 1)
            THEN 1
            ELSE 0
        END) as invalid_count
    FROM faq_content_map
);

-- 5.4: Verify validity constraint (is_valid vs valid_until consistency)
-- Expected: If is_valid=1, valid_until should be NULL
--           If is_valid=0, valid_until should NOT be NULL
SELECT
    'Data Integrity' as check_category,
    'FAQ validity constraint enforced' as check_name,
    CASE
        WHEN inconsistent_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    inconsistent_count,
    'is_valid=1 must have NULL valid_until, is_valid=0 must have non-NULL valid_until' as rule
FROM (
    SELECT
        COUNT(*) as inconsistent_count
    FROM faq_content_map
    WHERE (is_valid = 1 AND valid_until IS NOT NULL)
       OR (is_valid = 0 AND valid_until IS NULL)
);

-- 5.5: Verify invalidation_reason is set when is_valid=0
SELECT
    'Data Integrity' as check_category,
    'Invalidation reason set for invalid FAQs' as check_name,
    CASE
        WHEN missing_reason_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    missing_reason_count,
    'Invalid FAQs should have invalidation_reason' as rule
FROM (
    SELECT
        COUNT(*) as missing_reason_count
    FROM faq_content_map
    WHERE is_valid = 0
      AND invalidation_reason IS NULL
);

-- ============================================================================
-- SECTION 6: FOREIGN KEY VALIDATION
-- ============================================================================

-- 6.1: Check for orphaned FAQ mappings (invalidated_by_change_id)
-- Expected: All non-NULL invalidated_by_change_id should reference valid change_id
SELECT
    'Foreign Key Check' as check_category,
    'No orphaned invalidated_by_change_id references' as check_name,
    CASE
        WHEN orphaned_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    orphaned_count
FROM (
    SELECT COUNT(*) as orphaned_count
    FROM faq_content_map fcm
    WHERE fcm.invalidated_by_change_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM content_change_log ccl
          WHERE ccl.change_id = fcm.invalidated_by_change_id
      )
);

-- 6.2: Check for orphaned replaced_by_map_id references
SELECT
    'Foreign Key Check' as check_category,
    'No orphaned replaced_by_map_id references' as check_name,
    CASE
        WHEN orphaned_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    orphaned_count
FROM (
    SELECT COUNT(*) as orphaned_count
    FROM faq_content_map fcm1
    WHERE fcm1.replaced_by_map_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM faq_content_map fcm2
          WHERE fcm2.map_id = fcm1.replaced_by_map_id
      )
);

-- 6.3: Note about cross-database FKs (informational)
-- This is a reminder that content_id validation must be done in application code
SELECT
    'Foreign Key Check' as check_category,
    'Cross-database FK validation (INFO)' as check_name,
    'N/A' as status,
    'Cross-DB FKs (content_id, current_content_id, original_content_id) validated in app code' as note,
    'See validate_content_id() in application' as reference;

-- ============================================================================
-- SECTION 7: RACE CONDITION CHECKS (Fix 9)
-- ============================================================================

-- 7.1: Verify latest state queries are deterministic
-- Check for ambiguous "latest" records (same detected_at, same checksum)
-- FIXED: Use change_id as tiebreaker
SELECT
    'Race Condition Check' as check_category,
    'Latest change queries are deterministic' as check_name,
    CASE
        WHEN ambiguous_count = 0 THEN 'PASS'
        ELSE 'WARN'
    END as status,
    ambiguous_count,
    'Multiple changes with same detected_at for same checksum (use change_id tiebreaker)' as note
FROM (
    SELECT COUNT(*) as ambiguous_count
    FROM (
        SELECT
            content_checksum,
            detected_at,
            COUNT(*) as same_time_count
        FROM content_change_log
        GROUP BY content_checksum, detected_at
        HAVING COUNT(*) > 1
    )
);

-- 7.2: Verify page state queries are deterministic
SELECT
    'Race Condition Check' as check_category,
    'Latest page state queries are deterministic' as check_name,
    CASE
        WHEN ambiguous_count = 0 THEN 'PASS'
        ELSE 'WARN'
    END as status,
    ambiguous_count
FROM (
    SELECT COUNT(*) as ambiguous_count
    FROM (
        SELECT
            file_name,
            page_number,
            detected_at,
            COUNT(*) as same_time_count
        FROM content_change_log
        GROUP BY file_name, page_number, detected_at
        HAVING COUNT(*) > 1
    )
);

-- ============================================================================
-- SECTION 8: CHANGE CLASSIFICATION VALIDATION
-- ============================================================================

-- 8.1: Verify position changes have previous_page_number set
SELECT
    'Change Classification' as check_category,
    'Position changes have previous_page_number' as check_name,
    CASE
        WHEN missing_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    missing_count
FROM (
    SELECT COUNT(*) as missing_count
    FROM content_change_log
    WHERE change_type = 'position_change'
      AND previous_page_number IS NULL
);

-- 8.2: Verify content edits have previous_checksum set
SELECT
    'Change Classification' as check_category,
    'Content edits have previous_checksum' as check_name,
    CASE
        WHEN missing_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    missing_count
FROM (
    SELECT COUNT(*) as missing_count
    FROM content_change_log
    WHERE change_type = 'content_edit'
      AND previous_checksum IS NULL
);

-- 8.3: Verify initial_creation has no previous fields
SELECT
    'Change Classification' as check_category,
    'Initial creations have no previous fields' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_change_log
    WHERE change_type = 'initial_creation'
      AND (previous_content_id IS NOT NULL
           OR previous_page_number IS NOT NULL
           OR previous_checksum IS NOT NULL)
);

-- ============================================================================
-- SECTION 9: FAQ VALIDITY BUSINESS RULES
-- ============================================================================

-- 9.1: Verify FAQs are invalidated for content edits
-- Check that content_edit changes have corresponding FAQ invalidations
SELECT
    'FAQ Validity Rules' as check_category,
    'Content edits trigger FAQ invalidation' as check_name,
    'INFO' as status,
    COUNT(DISTINCT ccl.change_id) as content_edit_count,
    COUNT(DISTINCT fcm.invalidated_by_change_id) as invalidated_faq_count,
    'Check if invalidated count matches edit count' as note
FROM content_change_log ccl
LEFT JOIN faq_content_map fcm
    ON ccl.change_id = fcm.invalidated_by_change_id
    AND fcm.invalidation_reason = 'content_edited'
WHERE ccl.change_type = 'content_edit';

-- 9.2: Verify FAQs remain valid for position changes
-- FAQs linked by checksum should stay valid when content moves
SELECT
    'FAQ Validity Rules' as check_category,
    'FAQs remain valid for position changes' as check_name,
    'INFO' as status,
    COUNT(DISTINCT ccl.content_checksum) as moved_content_count,
    SUM(CASE WHEN fcm.is_valid = 1 THEN 1 ELSE 0 END) as still_valid_faq_count,
    'Valid FAQs should persist across position changes' as note
FROM content_change_log ccl
JOIN faq_content_map fcm
    ON ccl.content_checksum = fcm.content_checksum
WHERE ccl.change_type = 'position_change';

-- 9.3: Check for FAQs that should have been relocated but weren't
SELECT
    'FAQ Validity Rules' as check_category,
    'FAQ locations updated for position changes' as check_name,
    CASE
        WHEN outdated_count = 0 THEN 'PASS'
        ELSE 'WARN'
    END as status,
    outdated_count,
    'FAQs should be relocated when content moves' as note
FROM (
    SELECT COUNT(*) as outdated_count
    FROM faq_content_map fcm
    JOIN (
        SELECT
            content_checksum,
            page_number as latest_page,
            ROW_NUMBER() OVER (
                PARTITION BY content_checksum
                ORDER BY detected_at DESC, change_id DESC
            ) as rn
        FROM content_change_log
        WHERE change_type = 'position_change'
    ) latest
        ON fcm.content_checksum = latest.content_checksum
        AND latest.rn = 1
    WHERE fcm.is_valid = 1
      AND fcm.current_page_number != latest.latest_page
);

-- ============================================================================
-- SECTION 10: VIEW VALIDATION
-- ============================================================================

-- 10.1: Verify v_document_structure_changes view works
SELECT
    'View Check' as check_category,
    'v_document_structure_changes is queryable' as check_name,
    CASE
        WHEN COUNT(*) >= 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as structural_change_count
FROM v_document_structure_changes;

-- 10.2: Verify v_current_valid_faqs view works
SELECT
    'View Check' as check_category,
    'v_current_valid_faqs is queryable' as check_name,
    CASE
        WHEN COUNT(*) >= 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as valid_faq_count
FROM v_current_valid_faqs;

-- 10.3: Verify v_latest_content_state view works
SELECT
    'View Check' as check_category,
    'v_latest_content_state is queryable' as check_name,
    CASE
        WHEN COUNT(*) >= 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as active_page_count
FROM v_latest_content_state;

-- 10.4: Verify v_content_changes_with_diffs view works
SELECT
    'View Check' as check_category,
    'v_content_changes_with_diffs is queryable' as check_name,
    CASE
        WHEN COUNT(*) >= 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as content_edits_count
FROM v_content_changes_with_diffs;

-- 10.5: Verify v_pending_diffs view works
SELECT
    'View Check' as check_category,
    'v_pending_diffs is queryable' as check_name,
    CASE
        WHEN COUNT(*) >= 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    COUNT(*) as pending_diffs_count
FROM v_pending_diffs;

-- 10.6: Verify v_diff_processing_stats view works
SELECT
    'View Check' as check_category,
    'v_diff_processing_stats is queryable' as check_name,
    'PASS' as status,
    total_content_edits,
    diffs_generated,
    pending_diffs
FROM v_diff_processing_stats;

-- ============================================================================
-- SECTION 11: CONTENT DIFFS VALIDATION (NEW)
-- ============================================================================

-- 11.1: Verify diffs exist only for content_edit changes
-- Expected: All diffs should be for content_edit type
SELECT
    'Content Diffs Check' as check_category,
    'Diffs only for content_edit changes' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    'Trigger should prevent diffs for other change types' as note
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_diffs cd
    JOIN content_change_log ccl ON cd.change_id = ccl.change_id
    WHERE ccl.change_type != 'content_edit'
);

-- 11.2: Verify similarity scores are in valid range [0, 1]
SELECT
    'Content Diffs Check' as check_category,
    'Similarity scores in valid range' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    total_count as total_diffs
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE
            WHEN similarity_score < 0 OR similarity_score > 1
            THEN 1 ELSE 0
        END) as invalid_count
    FROM content_diffs
);

-- 11.3: Verify char counts are non-negative
SELECT
    'Content Diffs Check' as check_category,
    'Character counts are non-negative' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_diffs
    WHERE chars_added < 0 OR chars_removed < 0
);

-- 11.4: Verify line counts are non-negative
SELECT
    'Content Diffs Check' as check_category,
    'Line counts are non-negative' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_diffs
    WHERE lines_added < 0 OR lines_removed < 0
);

-- 11.5: Verify unified_diff_gzip is not null
SELECT
    'Content Diffs Check' as check_category,
    'Unified diffs are present' as check_name,
    CASE
        WHEN missing_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    missing_count,
    total_count as total_diffs
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN unified_diff_gzip IS NULL THEN 1 ELSE 0 END) as missing_count
    FROM content_diffs
);

-- 11.6: Verify is_minor_change is boolean (0 or 1)
SELECT
    'Content Diffs Check' as check_category,
    'is_minor_change is valid boolean' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_diffs
    WHERE is_minor_change NOT IN (0, 1)
);

-- 11.7: Verify processing_time_ms is non-negative when present
SELECT
    'Content Diffs Check' as check_category,
    'Processing time is non-negative' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count
FROM (
    SELECT COUNT(*) as invalid_count
    FROM content_diffs
    WHERE processing_time_ms IS NOT NULL AND processing_time_ms < 0
);

-- 11.8: Check semantic_summary JSON validity
-- Expected: semantic_summary should be valid JSON when present
SELECT
    'Content Diffs Check' as check_category,
    'Semantic summary JSON is valid' as check_name,
    CASE
        WHEN invalid_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    invalid_count,
    total_with_summary as total_with_summary
FROM (
    SELECT
        COUNT(*) as total_with_summary,
        SUM(CASE
            WHEN json_valid(semantic_summary) = 0 THEN 1
            ELSE 0
        END) as invalid_count
    FROM content_diffs
    WHERE semantic_summary IS NOT NULL
);

-- 11.9: Verify old_checksum matches previous_checksum in content_change_log
SELECT
    'Content Diffs Check' as check_category,
    'Checksums match content_change_log' as check_name,
    CASE
        WHEN mismatch_count = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as status,
    mismatch_count
FROM (
    SELECT COUNT(*) as mismatch_count
    FROM content_diffs cd
    JOIN content_change_log ccl ON cd.change_id = ccl.change_id
    WHERE cd.old_checksum != ccl.previous_checksum
       OR cd.new_checksum != ccl.content_checksum
);

-- 11.10: Check for content edits missing diffs (pending processing)
SELECT
    'Content Diffs Check' as check_category,
    'Diff coverage for content edits' as check_name,
    'INFO' as status,
    total_edits,
    diffs_generated,
    pending_diffs,
    ROUND(100.0 * diffs_generated / NULLIF(total_edits, 0), 2) as coverage_percent
FROM (
    SELECT
        COUNT(*) as total_edits,
        SUM(CASE WHEN cd.change_id IS NOT NULL THEN 1 ELSE 0 END) as diffs_generated,
        SUM(CASE WHEN cd.change_id IS NULL THEN 1 ELSE 0 END) as pending_diffs
    FROM content_change_log ccl
    LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
    WHERE ccl.change_type = 'content_edit'
);

-- 11.11: Check diff processing errors
SELECT
    'Content Diffs Check' as check_category,
    'Diffs with processing errors' as check_name,
    CASE
        WHEN error_count = 0 THEN 'PASS'
        ELSE 'WARN'
    END as status,
    error_count,
    total_count as total_diffs
FROM (
    SELECT
        COUNT(*) as total_count,
        SUM(CASE WHEN error_message IS NOT NULL THEN 1 ELSE 0 END) as error_count
    FROM content_diffs
);

-- 11.12: Verify change magnitude classification consistency
-- Minor changes should have high similarity scores
SELECT
    'Content Diffs Check' as check_category,
    'Change magnitude classification consistency' as check_name,
    CASE
        WHEN inconsistent_count = 0 THEN 'PASS'
        ELSE 'WARN'
    END as status,
    inconsistent_count,
    'Minor changes (is_minor_change=1) should have similarity >= 0.9' as rule
FROM (
    SELECT COUNT(*) as inconsistent_count
    FROM content_diffs
    WHERE is_minor_change = 1 AND similarity_score < 0.9
);

-- ============================================================================
-- SECTION 12: PERFORMANCE & INDEX USAGE
-- ============================================================================

-- 12.1: Analyze index usage for common queries
-- Check if idx_fcm_lookup is being used
EXPLAIN QUERY PLAN
SELECT *
FROM faq_content_map
WHERE current_file_name = 'test.pdf'
  AND current_page_number = 1
  AND is_valid = 1;

-- 12.2: Check if idx_ccl_latest is being used
EXPLAIN QUERY PLAN
SELECT *
FROM content_change_log
WHERE file_name = 'test.pdf'
ORDER BY detected_at DESC
LIMIT 10;

-- 12.3: Check if idx_ccl_idempotent prevents duplicates efficiently
EXPLAIN QUERY PLAN
SELECT *
FROM content_change_log
WHERE file_name = 'test.pdf'
  AND page_number = 1
  AND content_checksum = 'abc123...'
  AND change_type = 'content_edit'
  AND effective_date = '2025-01-01T00:00:00Z';

-- 12.4: Check if idx_diffs_checksums is being used
EXPLAIN QUERY PLAN
SELECT *
FROM content_diffs
WHERE old_checksum = 'abc123...'
  AND new_checksum = 'def456...';

-- 12.5: Check if idx_diffs_similarity is being used
EXPLAIN QUERY PLAN
SELECT *
FROM content_diffs
WHERE similarity_score < 0.5
ORDER BY similarity_score ASC;

-- 12.6: Check if idx_diffs_minor partial index is being used
EXPLAIN QUERY PLAN
SELECT *
FROM content_diffs
WHERE is_minor_change = 0;

-- ============================================================================
-- SECTION 13: SUMMARY STATISTICS
-- ============================================================================

-- 13.1: Overall data statistics (including content_diffs)
SELECT
    'Summary Statistics' as category,
    'Overall counts' as metric,
    (SELECT COUNT(*) FROM content_change_log) as total_changes,
    (SELECT COUNT(*) FROM faq_content_map) as total_faq_mappings,
    (SELECT COUNT(*) FROM faq_content_map WHERE is_valid = 1) as valid_faqs,
    (SELECT COUNT(*) FROM faq_content_map WHERE is_valid = 0) as invalidated_faqs,
    (SELECT COUNT(*) FROM content_diffs) as total_diffs;

-- 13.2: Change type distribution
SELECT
    'Summary Statistics' as category,
    change_type,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM content_change_log), 2) as percentage
FROM content_change_log
GROUP BY change_type
ORDER BY count DESC;

-- 13.3: Invalidation reason distribution
SELECT
    'Summary Statistics' as category,
    COALESCE(invalidation_reason, 'N/A (still valid)') as reason,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM faq_content_map), 2) as percentage
FROM faq_content_map
GROUP BY invalidation_reason
ORDER BY count DESC;

-- 13.4: Files with most changes
SELECT
    'Summary Statistics' as category,
    file_name,
    COUNT(*) as change_count,
    COUNT(DISTINCT change_type) as change_type_count,
    MIN(effective_date) as first_change,
    MAX(effective_date) as last_change
FROM content_change_log
GROUP BY file_name
ORDER BY change_count DESC
LIMIT 10;

-- 13.5: Diff processing statistics by change magnitude
SELECT
    'Summary Statistics' as category,
    CASE
        WHEN similarity_score >= 0.9 THEN 'Minor (0.9-1.0)'
        WHEN similarity_score >= 0.7 THEN 'Moderate (0.7-0.9)'
        WHEN similarity_score >= 0.3 THEN 'Significant (0.3-0.7)'
        ELSE 'Major (0.0-0.3)'
    END as change_magnitude,
    COUNT(*) as diff_count,
    ROUND(AVG(chars_added), 2) as avg_chars_added,
    ROUND(AVG(chars_removed), 2) as avg_chars_removed,
    ROUND(AVG(processing_time_ms), 2) as avg_processing_ms
FROM content_diffs
GROUP BY change_magnitude
ORDER BY MIN(similarity_score) DESC;

-- 13.6: Semantic change statistics
SELECT
    'Summary Statistics' as category,
    'Semantic changes detected' as metric,
    COUNT(*) as total_diffs_with_semantic,
    SUM(CAST(json_extract(semantic_summary, '$.total_changes') AS INTEGER)) as total_semantic_changes,
    ROUND(AVG(CAST(json_extract(semantic_summary, '$.total_changes') AS INTEGER)), 2) as avg_changes_per_diff,
    SUM(CAST(json_extract(semantic_summary, '$.stats.headers_changed') AS INTEGER)) as total_headers_changed,
    SUM(CAST(json_extract(semantic_summary, '$.stats.paragraphs_changed') AS INTEGER)) as total_paragraphs_changed,
    SUM(CAST(json_extract(semantic_summary, '$.stats.list_items_changed') AS INTEGER)) as total_list_items_changed
FROM content_diffs
WHERE semantic_summary IS NOT NULL;

-- ============================================================================
-- VALIDATION COMPLETE
-- ============================================================================

SELECT
    '============================================' as separator,
    'VALIDATION COMPLETE' as message,
    strftime('%Y-%m-%dT%H:%M:%SZ','now') as completed_at;
