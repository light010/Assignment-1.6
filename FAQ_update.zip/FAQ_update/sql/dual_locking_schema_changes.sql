-- ============================================================================
-- DUAL LOCKING SCHEMA CHANGES - FAQ Update System V8.1
-- ============================================================================
-- Purpose: Add support for dual locking strategy (distributed + optimistic)
-- Author: FAQ Services Team
-- Date: 2025-10-21
-- Version: 8.1
--
-- CHANGES:
-- 1. Add detection_run_locks table (distributed locking)
-- 2. Add version columns to faq_questions and faq_answers (optimistic locking)
-- 3. Add indexes for performance
-- 4. Add monitoring views
-- ============================================================================

-- ============================================================================
-- 1. DISTRIBUTED LOCKING TABLE
-- ============================================================================
-- Purpose: Coordinate concurrent detection runs across workers
-- Prevents multiple processes from working on same file simultaneously
-- ============================================================================

CREATE TABLE IF NOT EXISTS detection_run_locks (
    -- Lock Identity
    resource_id STRING NOT NULL COMMENT 'Unique resource identifier (e.g., "file:handbook.pdf")',
    owner_id STRING NOT NULL COMMENT 'Lock owner identifier (e.g., detection_run_id)',

    -- Lock Timing
    acquired_at TIMESTAMP NOT NULL COMMENT 'When lock was acquired',
    expires_at TIMESTAMP NOT NULL COMMENT 'When lock auto-expires (default: 30 minutes)',

    -- Debugging Info (optional)
    hostname STRING COMMENT 'Hostname of lock owner',
    process_id INT COMMENT 'Process ID of lock owner',
    databricks_job_id STRING COMMENT 'Databricks job ID (if applicable)',
    databricks_run_id STRING COMMENT 'Databricks run ID (if applicable)',

    -- Metadata
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Distributed locks for concurrent detection run coordination (Layer 1: Pessimistic)'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Primary key: one lock per resource
ALTER TABLE detection_run_locks ADD CONSTRAINT pk_detection_run_locks
    PRIMARY KEY (resource_id);

-- Index for cleanup queries
CREATE INDEX IF NOT EXISTS idx_detection_run_locks_expires
    ON detection_run_locks(expires_at);

-- Index for monitoring
CREATE INDEX IF NOT EXISTS idx_detection_run_locks_owner
    ON detection_run_locks(owner_id);


-- ============================================================================
-- 2. OPTIMISTIC LOCKING COLUMNS
-- ============================================================================
-- Purpose: Detect concurrent modifications at row level
-- Version number increments with each update
-- ============================================================================

-- Add version column to faq_questions
ALTER TABLE faq_questions
ADD COLUMN IF NOT EXISTS version BIGINT DEFAULT 0
COMMENT 'Version number for optimistic locking (incremented on each update)';

-- Add version column to faq_answers
ALTER TABLE faq_answers
ADD COLUMN IF NOT EXISTS version BIGINT DEFAULT 0
COMMENT 'Version number for optimistic locking (incremented on each update)';

-- Initialize versions for existing rows (if not already set)
UPDATE faq_questions SET version = 0 WHERE version IS NULL;
UPDATE faq_answers SET version = 0 WHERE version IS NULL;

-- Add NOT NULL constraint after initialization
-- (Databricks doesn't support NOT NULL in ADD COLUMN, so do it separately)
-- ALTER TABLE faq_questions ALTER COLUMN version SET NOT NULL;
-- ALTER TABLE faq_answers ALTER COLUMN version SET NOT NULL;


-- ============================================================================
-- 3. PERFORMANCE INDEXES
-- ============================================================================

-- Index for version-based queries (used in optimistic locking)
CREATE INDEX IF NOT EXISTS idx_faq_questions_version
    ON faq_questions(question_id, version);

CREATE INDEX IF NOT EXISTS idx_faq_answers_version
    ON faq_answers(answer_id, version);

-- Index for status queries (frequently filtered)
CREATE INDEX IF NOT EXISTS idx_faq_questions_status
    ON faq_questions(status, modified_at);

CREATE INDEX IF NOT EXISTS idx_faq_answers_status
    ON faq_answers(status, modified_at);


-- ============================================================================
-- 4. MONITORING VIEWS
-- ============================================================================

-- ============================================================================
-- VIEW: v_active_locks
-- ============================================================================
-- Purpose: Monitor currently active locks
-- ============================================================================

CREATE OR REPLACE VIEW v_active_locks AS
SELECT
    resource_id,
    owner_id,
    acquired_at,
    expires_at,
    CAST((UNIX_TIMESTAMP(expires_at) - UNIX_TIMESTAMP(CURRENT_TIMESTAMP())) / 60 AS INT) as minutes_remaining,
    CAST((UNIX_TIMESTAMP(CURRENT_TIMESTAMP()) - UNIX_TIMESTAMP(acquired_at)) / 60 AS INT) as minutes_held,
    hostname,
    process_id,
    databricks_job_id,
    databricks_run_id,
    CASE
        WHEN expires_at < CURRENT_TIMESTAMP() THEN 'STALE'
        WHEN expires_at < TIMESTAMPADD(MINUTE, 5, CURRENT_TIMESTAMP()) THEN 'EXPIRING_SOON'
        ELSE 'ACTIVE'
    END as lock_status
FROM detection_run_locks
ORDER BY acquired_at DESC;

COMMENT ON VIEW v_active_locks IS 'Monitor active distributed locks';


-- ============================================================================
-- VIEW: v_stale_locks
-- ============================================================================
-- Purpose: Identify stale locks that should be cleaned up
-- ============================================================================

CREATE OR REPLACE VIEW v_stale_locks AS
SELECT
    resource_id,
    owner_id,
    acquired_at,
    expires_at,
    CAST((UNIX_TIMESTAMP(CURRENT_TIMESTAMP()) - UNIX_TIMESTAMP(expires_at)) / 60 AS INT) as minutes_overdue,
    hostname,
    databricks_job_id,
    databricks_run_id
FROM detection_run_locks
WHERE expires_at < CURRENT_TIMESTAMP()
ORDER BY expires_at ASC;

COMMENT ON VIEW v_stale_locks IS 'Stale locks that need cleanup';


-- ============================================================================
-- VIEW: v_faq_version_history
-- ============================================================================
-- Purpose: Track FAQ version changes over time (requires change data feed)
-- ============================================================================

CREATE OR REPLACE VIEW v_faq_version_history AS
SELECT
    q.question_id,
    q.question_text,
    q.version as current_version,
    q.status,
    q.modified_at as last_modified,
    q.modified_by,
    COUNT(DISTINCT qs.invalidated_by_change_id) as times_invalidated
FROM faq_questions q
LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id
WHERE qs.is_valid = FALSE
GROUP BY q.question_id, q.question_text, q.version, q.status, q.modified_at, q.modified_by
ORDER BY q.version DESC, q.modified_at DESC;

COMMENT ON VIEW v_faq_version_history IS 'FAQ version history and invalidation counts';


-- ============================================================================
-- VIEW: v_optimistic_lock_conflicts
-- ============================================================================
-- Purpose: Detect patterns in optimistic lock conflicts
-- Requires audit logging to be enabled
-- ============================================================================

CREATE OR REPLACE VIEW v_optimistic_lock_conflicts AS
SELECT
    DATE(performed_at) as conflict_date,
    table_name,
    COUNT(*) as conflict_count,
    COUNT(DISTINCT record_id) as unique_faqs_affected,
    COUNT(DISTINCT detection_run_id) as detection_runs_involved
FROM faq_audit_log
WHERE action = 'SELECTIVE_INVALIDATE'
  AND change_reason LIKE '%conflict%'
GROUP BY DATE(performed_at), table_name
ORDER BY conflict_date DESC;

COMMENT ON VIEW v_optimistic_lock_conflicts IS 'Track optimistic locking conflicts over time';


-- ============================================================================
-- 5. MAINTENANCE PROCEDURES
-- ============================================================================

-- ============================================================================
-- PROCEDURE: cleanup_stale_locks
-- ============================================================================
-- Purpose: Remove expired locks (run periodically via scheduled job)
-- Frequency: Every 5-10 minutes
-- ============================================================================

CREATE OR REPLACE PROCEDURE cleanup_stale_locks()
LANGUAGE SQL
AS
BEGIN
    DECLARE deleted_count INT;

    -- Delete expired locks
    DELETE FROM detection_run_locks
    WHERE expires_at < CURRENT_TIMESTAMP();

    -- Get count of deleted locks
    SET deleted_count = ROW_COUNT();

    -- Log cleanup
    IF deleted_count > 0 THEN
        INSERT INTO faq_audit_log (
            table_name,
            action,
            change_reason,
            performed_by,
            performed_at
        ) VALUES (
            'detection_run_locks',
            'DELETE',
            CONCAT('Cleaned up ', deleted_count, ' stale lock(s)'),
            'system:cleanup_job',
            CURRENT_TIMESTAMP()
        );
    END IF;

    -- Return result
    SELECT
        deleted_count as locks_cleaned,
        CURRENT_TIMESTAMP() as cleanup_time;
END;

COMMENT ON PROCEDURE cleanup_stale_locks IS 'Remove expired distributed locks';


-- ============================================================================
-- PROCEDURE: force_break_lock
-- ============================================================================
-- Purpose: Manually break a stuck lock (use with caution!)
-- Usage: CALL force_break_lock('file:handbook.pdf')
-- ============================================================================

CREATE OR REPLACE PROCEDURE force_break_lock(
    IN p_resource_id STRING
)
LANGUAGE SQL
AS
BEGIN
    DECLARE lock_owner STRING;

    -- Get current owner
    SELECT owner_id INTO lock_owner
    FROM detection_run_locks
    WHERE resource_id = p_resource_id;

    -- Delete lock
    DELETE FROM detection_run_locks
    WHERE resource_id = p_resource_id;

    -- Log action
    INSERT INTO faq_audit_log (
        table_name,
        action,
        change_reason,
        performed_by,
        performed_at
    ) VALUES (
        'detection_run_locks',
        'DELETE',
        CONCAT('Force broke lock on ', p_resource_id, ' (was held by ', lock_owner, ')'),
        'admin:manual',
        CURRENT_TIMESTAMP()
    );

    -- Return result
    SELECT
        p_resource_id as resource_id,
        lock_owner as previous_owner,
        'Lock forcibly broken' as status;
END;

COMMENT ON PROCEDURE force_break_lock IS 'Manually break a stuck lock (use with caution)';


-- ============================================================================
-- 6. VERIFICATION QUERIES
-- ============================================================================

-- Verify tables exist
SELECT '✅ Tables verified' as status;
DESCRIBE TABLE detection_run_locks;
DESCRIBE TABLE faq_questions;
DESCRIBE TABLE faq_answers;

-- Verify columns exist
SELECT '✅ Version columns verified' as status;
SELECT version FROM faq_questions LIMIT 1;
SELECT version FROM faq_answers LIMIT 1;

-- Verify indexes exist
SELECT '✅ Indexes verified' as status;
SHOW INDEXES ON detection_run_locks;
SHOW INDEXES ON faq_questions;
SHOW INDEXES ON faq_answers;

-- Verify views exist
SELECT '✅ Views verified' as status;
SHOW VIEWS LIKE 'v_active_locks';
SHOW VIEWS LIKE 'v_stale_locks';
SHOW VIEWS LIKE 'v_faq_version_history';
SHOW VIEWS LIKE 'v_optimistic_lock_conflicts';


-- ============================================================================
-- 7. USAGE EXAMPLES
-- ============================================================================

/*
-- Example 1: Monitor active locks
SELECT * FROM v_active_locks;

-- Example 2: Cleanup stale locks manually
CALL cleanup_stale_locks();

-- Example 3: Force break a stuck lock (emergency only!)
CALL force_break_lock('file:handbook.pdf');

-- Example 4: Check FAQ versions
SELECT question_id, question_text, version, status, modified_at
FROM faq_questions
WHERE version > 5
ORDER BY version DESC;

-- Example 5: Find FAQs with frequent version changes (potential conflicts)
SELECT
    question_id,
    question_text,
    version,
    times_invalidated,
    last_modified
FROM v_faq_version_history
WHERE version > 10  -- Changed many times
ORDER BY version DESC
LIMIT 20;

-- Example 6: Analyze conflict patterns
SELECT * FROM v_optimistic_lock_conflicts
WHERE conflict_date >= CURRENT_DATE() - INTERVAL 7 DAYS;

-- Example 7: Find long-running locks (potential issues)
SELECT
    resource_id,
    owner_id,
    minutes_held,
    minutes_remaining,
    lock_status
FROM v_active_locks
WHERE minutes_held > 20  -- Held for more than 20 minutes
ORDER BY minutes_held DESC;
*/


-- ============================================================================
-- 8. ROLLBACK SCRIPT (IF NEEDED)
-- ============================================================================
-- Use this if you need to rollback the changes

/*
-- Drop monitoring views
DROP VIEW IF EXISTS v_optimistic_lock_conflicts;
DROP VIEW IF EXISTS v_faq_version_history;
DROP VIEW IF EXISTS v_stale_locks;
DROP VIEW IF EXISTS v_active_locks;

-- Drop procedures
DROP PROCEDURE IF EXISTS force_break_lock;
DROP PROCEDURE IF EXISTS cleanup_stale_locks;

-- Drop indexes
DROP INDEX IF EXISTS idx_faq_answers_status;
DROP INDEX IF EXISTS idx_faq_questions_status;
DROP INDEX IF EXISTS idx_faq_answers_version;
DROP INDEX IF EXISTS idx_faq_questions_version;
DROP INDEX IF EXISTS idx_detection_run_locks_owner;
DROP INDEX IF EXISTS idx_detection_run_locks_expires;

-- Remove version columns
ALTER TABLE faq_answers DROP COLUMN IF EXISTS version;
ALTER TABLE faq_questions DROP COLUMN IF EXISTS version;

-- Drop lock table
DROP TABLE IF EXISTS detection_run_locks;

SELECT '✅ Rollback complete' as status;
*/


-- ============================================================================
-- END OF SCHEMA CHANGES
-- ============================================================================

SELECT '✅ Dual locking schema changes applied successfully!' as status;
SELECT 'Next step: Run race_condition_fix_dual_locking.py to test the implementation' as next_step;