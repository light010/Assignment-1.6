-- ============================================================================
-- FAQ UPDATE DATABASE - PRODUCTION SCHEMA V5.0
-- ============================================================================
-- Architecture: Checksum-Centric FAQ Versioning with Full Audit Trail
-- Date: 2025-10-21
-- Author: Principal Application Architect
-- Target: Databricks Unity Catalog (DBR 10.4+)
--
-- CRITICAL FIXES ADDRESSED:
-- 1. ✅ Restored faq_content_map with proper checksum tracking
-- 2. ✅ Added referential integrity enforcement
-- 3. ✅ Added comprehensive audit trail
-- 4. ✅ Fixed FAQ-to-content mapping ambiguity
-- 5. ✅ Added transaction support via proper constraints
-- 6. ✅ Eliminated JSON metadata in favor of structured columns
-- 7. ✅ Added proper status lifecycle management
-- ============================================================================

-- ============================================================================
-- SETUP
-- ============================================================================
-- USE CATALOG your_catalog_name;
-- USE SCHEMA your_schema_name;

-- Drop existing objects
DROP VIEW IF EXISTS v_active_faqs;
DROP VIEW IF EXISTS v_invalidated_faqs;
DROP VIEW IF EXISTS v_content_changes_summary;
DROP VIEW IF EXISTS v_faq_regeneration_queue;

DROP TABLE IF EXISTS faq_audit_log;
DROP TABLE IF EXISTS faq_content_map;
DROP TABLE IF EXISTS content_change_log;
DROP TABLE IF EXISTS faq_answers;
DROP TABLE IF EXISTS faq_questions;
DROP TABLE IF EXISTS content_repo;

-- ============================================================================
-- TABLE 1: content_repo
-- ============================================================================
-- Purpose: Source content repository (single source of truth for all content)
-- ============================================================================

CREATE TABLE content_repo (
    -- Primary Key
    content_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Content Identity (immutable once set)
    content_checksum STRING NOT NULL COMMENT 'SHA-256 hash of content (64 chars)',

    -- File Identification
    file_name STRING NOT NULL COMMENT 'Source file name (e.g., employee_handbook.pdf)',
    file_type STRING COMMENT 'File type (PDF, DOCX, HTML, XML)',
    page_number INT COMMENT 'Page number (NULL for single-page documents)',

    -- File Paths
    source_file_path STRING COMMENT 'Original file path or URL',
    markdown_file_path STRING COMMENT 'Extracted markdown file path',

    -- Content Metadata
    title STRING COMMENT 'Page/section title',
    breadcrumb STRING COMMENT 'Navigation breadcrumb',

    -- Organization Context
    domain STRING COMMENT 'Business domain (HR, IT, Finance, etc.)',
    service STRING COMMENT 'Service area (Policy, Benefits, Payroll, etc.)',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, inactive, deleted, archived',

    -- Timestamps (immutable after creation)
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Last content modification',

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'Source content repository - foundation for FAQ generation'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);

-- Constraints
ALTER TABLE content_repo ADD CONSTRAINT pk_content_repo PRIMARY KEY (content_id);
ALTER TABLE content_repo ADD CONSTRAINT chk_content_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_repo ADD CONSTRAINT chk_content_status CHECK (status IN ('active', 'inactive', 'deleted', 'archived'));
ALTER TABLE content_repo ADD CONSTRAINT chk_page_number CHECK (page_number IS NULL OR page_number > 0);

-- Enable column defaults
ALTER TABLE content_repo SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 2: faq_questions
-- ============================================================================
-- Purpose: FAQ questions with full version history
-- Note: question_text is NOT unique - same question can apply to different contexts
-- ============================================================================

CREATE TABLE faq_questions (
    -- Primary Key
    question_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Question Content
    question_text STRING NOT NULL COMMENT 'The actual FAQ question',

    -- Source Attribution
    source_type STRING COMMENT 'from_documents, from_user_queries, from_manual, from_validation',

    -- Organization Context (for multi-tenancy)
    domain STRING COMMENT 'Business domain',
    service STRING COMMENT 'Service area',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ questions master table'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_questions ADD CONSTRAINT pk_faq_questions PRIMARY KEY (question_id);
ALTER TABLE faq_questions ADD CONSTRAINT chk_question_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));

-- Enable column defaults
ALTER TABLE faq_questions SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 3: faq_answers
-- ============================================================================
-- Purpose: FAQ answers linked to questions (1:1 relationship)
-- ============================================================================

CREATE TABLE faq_answers (
    -- Primary Key
    answer_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key to Question (1:1 relationship)
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',

    -- Answer Content
    answer_text STRING NOT NULL COMMENT 'The FAQ answer (HTML or Markdown)',
    answer_format STRING DEFAULT 'html' COMMENT 'html, markdown, plain',

    -- Quality Metrics
    confidence_score DOUBLE COMMENT 'Generation confidence (0.0 to 1.0)',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ answers linked to questions (1:1)'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_answers ADD CONSTRAINT pk_faq_answers PRIMARY KEY (answer_id);
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_format CHECK (answer_format IN ('html', 'markdown', 'plain'));
ALTER TABLE faq_answers ADD CONSTRAINT chk_confidence_score CHECK (confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0));

-- Enable column defaults
ALTER TABLE faq_answers SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Key (informational in Databricks, but documents the relationship)
-- ALTER TABLE faq_answers ADD CONSTRAINT fk_answer_question FOREIGN KEY (question_id) REFERENCES faq_questions(question_id);

-- ============================================================================
-- TABLE 4: faq_content_map
-- ============================================================================
-- Purpose: CRITICAL - Maps FAQs to content checksums (the "linchpin" table)
-- This table is the KEY to the entire update detection system
-- ============================================================================

CREATE TABLE faq_content_map (
    -- Primary Key
    map_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Keys (Define the FAQ)
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',
    answer_id BIGINT NOT NULL COMMENT 'FK to faq_answers',

    -- Content Identity (What content generated this FAQ)
    content_checksum STRING NOT NULL COMMENT 'SHA-256 hash linking FAQ to content version',
    content_id BIGINT NOT NULL COMMENT 'FK to content_repo (current location)',

    -- File Context (Denormalized for query performance)
    file_name STRING NOT NULL COMMENT 'Source file name',
    page_number INT COMMENT 'Source page number',

    -- Organization Context (Denormalized)
    domain STRING,
    service STRING,

    -- Validity Tracking (Core of the update system)
    is_valid BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this mapping currently valid?',
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'When this mapping became valid',
    valid_until TIMESTAMP COMMENT 'When this mapping was invalidated (NULL if still valid)',

    -- Invalidation Details
    invalidation_reason STRING COMMENT 'content_edited, content_deleted, manual_invalidation',
    invalidated_by_change_id BIGINT COMMENT 'FK to content_change_log (what change invalidated this)',

    -- Generation Metadata
    generation_method STRING COMMENT 'initial_generation, faq_update_pipeline, manual_entry',
    generation_run_id STRING COMMENT 'Pipeline run ID that created this mapping',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system'
)
COMMENT 'FAQ-to-Content mapping table - tracks which content version generated which FAQ'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);

-- Constraints
ALTER TABLE faq_content_map ADD CONSTRAINT pk_faq_content_map PRIMARY KEY (map_id);
ALTER TABLE faq_content_map ADD CONSTRAINT chk_map_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE faq_content_map ADD CONSTRAINT chk_invalidation_reason CHECK (
    invalidation_reason IS NULL OR
    invalidation_reason IN ('content_edited', 'content_deleted', 'manual_invalidation', 'quality_issue')
);

-- Enable column defaults
ALTER TABLE faq_content_map SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Keys (informational)
-- ALTER TABLE faq_content_map ADD CONSTRAINT fk_map_question FOREIGN KEY (question_id) REFERENCES faq_questions(question_id);
-- ALTER TABLE faq_content_map ADD CONSTRAINT fk_map_answer FOREIGN KEY (answer_id) REFERENCES faq_answers(question_id);
-- ALTER TABLE faq_content_map ADD CONSTRAINT fk_map_content FOREIGN KEY (content_id) REFERENCES content_repo(content_id);

-- ============================================================================
-- TABLE 5: content_change_log
-- ============================================================================
-- Purpose: Detection log - tracks content changes and regeneration decisions
-- ============================================================================

CREATE TABLE content_change_log (
    -- Primary Key
    change_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Content Identity
    content_id BIGINT NOT NULL COMMENT 'FK to content_repo',
    content_checksum STRING NOT NULL COMMENT 'SHA-256 hash of content',
    file_name STRING NOT NULL,
    page_number INT,

    -- Detection Decision (Binary)
    requires_faq_regeneration BOOLEAN NOT NULL COMMENT 'TRUE = new/modified, FALSE = unchanged',

    -- Change Context
    change_type STRING COMMENT 'new_content, modified_content, unchanged_content, deleted_content',

    -- FAQ Impact Metrics
    existing_faq_count INT NOT NULL DEFAULT 0 COMMENT 'How many FAQs exist for this checksum',

    -- Detection Context
    detection_run_id STRING NOT NULL COMMENT 'Unique identifier for detection batch',
    detection_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    detection_period_start TIMESTAMP COMMENT 'since_date parameter used in detection',

    -- Source Metadata
    source_modified_at TIMESTAMP COMMENT 'When the source content was last modified',

    -- Organization Context
    domain STRING,
    service STRING
)
COMMENT 'Content change detection log - tracks regeneration decisions'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE content_change_log ADD CONSTRAINT pk_content_change_log PRIMARY KEY (change_id);
ALTER TABLE content_change_log ADD CONSTRAINT chk_ccl_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_change_log ADD CONSTRAINT chk_change_type CHECK (
    change_type IS NULL OR
    change_type IN ('new_content', 'modified_content', 'unchanged_content', 'deleted_content')
);

-- Enable column defaults
ALTER TABLE content_change_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Prevent duplicate detections for same content in same run
ALTER TABLE content_change_log ADD CONSTRAINT unique_content_detection
    UNIQUE (content_id, detection_run_id);

-- Foreign Key (informational)
-- ALTER TABLE content_change_log ADD CONSTRAINT fk_ccl_content FOREIGN KEY (content_id) REFERENCES content_repo(content_id);

-- ============================================================================
-- TABLE 6: faq_audit_log
-- ============================================================================
-- Purpose: Complete audit trail for all FAQ operations (security & compliance)
-- ============================================================================

CREATE TABLE faq_audit_log (
    -- Primary Key
    audit_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- What Changed
    table_name STRING NOT NULL COMMENT 'faq_questions, faq_answers, faq_content_map',
    record_id BIGINT NOT NULL COMMENT 'Primary key of affected record',

    -- Action Details
    action STRING NOT NULL COMMENT 'INSERT, UPDATE, DELETE, INVALIDATE',

    -- Change Details (JSON for flexibility)
    old_values STRING COMMENT 'JSON snapshot before change',
    new_values STRING COMMENT 'JSON snapshot after change',

    -- Context
    detection_run_id STRING COMMENT 'Related detection run (if applicable)',
    change_reason STRING COMMENT 'Why this change was made',

    -- Who & When
    performed_by STRING NOT NULL DEFAULT 'system',
    performed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Additional Context
    metadata STRING COMMENT 'Additional audit metadata (JSON)'
)
COMMENT 'Complete audit trail for all FAQ operations'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_audit_log ADD CONSTRAINT pk_faq_audit_log PRIMARY KEY (audit_id);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_table CHECK (
    table_name IN ('faq_questions', 'faq_answers', 'faq_content_map', 'content_repo')
);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_action CHECK (
    action IN ('INSERT', 'UPDATE', 'DELETE', 'INVALIDATE', 'RESTORE')
);

-- Enable column defaults
ALTER TABLE faq_audit_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- VIEWS - Common Query Patterns
-- ============================================================================

-- ============================================================================
-- VIEW: v_active_faqs
-- ============================================================================
-- Purpose: All currently active FAQs with their content mappings
-- ============================================================================

CREATE OR REPLACE VIEW v_active_faqs AS
SELECT
    q.question_id,
    q.question_text,
    a.answer_id,
    a.answer_text,
    a.answer_format,
    a.confidence_score,
    m.map_id,
    m.content_checksum,
    m.content_id,
    m.file_name,
    m.page_number,
    m.domain,
    m.service,
    m.valid_from,
    m.generation_method,
    c.title as content_title,
    c.breadcrumb as content_breadcrumb,
    c.modified_at as content_modified_at
FROM faq_questions q
INNER JOIN faq_answers a ON q.question_id = a.question_id
INNER JOIN faq_content_map m ON q.question_id = m.question_id AND a.answer_id = m.answer_id
LEFT JOIN content_repo c ON m.content_id = c.content_id
WHERE q.status = 'active'
  AND a.status = 'active'
  AND m.is_valid = TRUE
ORDER BY m.file_name, m.page_number, q.question_text;

-- ============================================================================
-- VIEW: v_invalidated_faqs
-- ============================================================================
-- Purpose: Recently invalidated FAQs (for review/audit)
-- ============================================================================

CREATE OR REPLACE VIEW v_invalidated_faqs AS
SELECT
    m.map_id,
    m.question_id,
    q.question_text,
    m.answer_id,
    a.answer_text,
    m.content_checksum as old_checksum,
    m.file_name,
    m.page_number,
    m.invalidation_reason,
    m.invalidated_by_change_id,
    m.valid_from,
    m.valid_until,
    ccl.content_checksum as new_checksum,
    ccl.detection_run_id,
    DATEDIFF(m.valid_until, m.valid_from) as days_valid
FROM faq_content_map m
INNER JOIN faq_questions q ON m.question_id = q.question_id
INNER JOIN faq_answers a ON m.answer_id = a.answer_id
LEFT JOIN content_change_log ccl ON m.invalidated_by_change_id = ccl.change_id
WHERE m.is_valid = FALSE
ORDER BY m.valid_until DESC;

-- ============================================================================
-- VIEW: v_content_changes_summary
-- ============================================================================
-- Purpose: Summary of content changes by detection run
-- ============================================================================

CREATE OR REPLACE VIEW v_content_changes_summary AS
SELECT
    detection_run_id,
    MIN(detection_timestamp) as detection_started_at,
    MAX(detection_timestamp) as detection_completed_at,
    COUNT(*) as total_content_analyzed,
    SUM(CASE WHEN requires_faq_regeneration = TRUE THEN 1 ELSE 0 END) as content_requiring_regeneration,
    SUM(CASE WHEN requires_faq_regeneration = FALSE THEN 1 ELSE 0 END) as content_unchanged,
    SUM(existing_faq_count) as total_existing_faqs,
    SUM(CASE WHEN requires_faq_regeneration = TRUE THEN existing_faq_count ELSE 0 END) as faqs_to_invalidate,
    COUNT(DISTINCT file_name) as unique_files,
    COUNT(DISTINCT content_checksum) as unique_checksums,
    COUNT(DISTINCT CASE WHEN change_type = 'new_content' THEN content_id END) as new_content_count,
    COUNT(DISTINCT CASE WHEN change_type = 'modified_content' THEN content_id END) as modified_content_count,
    COUNT(DISTINCT CASE WHEN change_type = 'deleted_content' THEN content_id END) as deleted_content_count
FROM content_change_log
GROUP BY detection_run_id
ORDER BY detection_started_at DESC;

-- ============================================================================
-- VIEW: v_faq_regeneration_queue
-- ============================================================================
-- Purpose: Processing queue for FAQ regeneration (prioritized)
-- ============================================================================

CREATE OR REPLACE VIEW v_faq_regeneration_queue AS
SELECT
    ccl.change_id,
    ccl.content_id,
    ccl.content_checksum,
    ccl.file_name,
    ccl.page_number,
    ccl.existing_faq_count,
    ccl.detection_run_id,
    ccl.detection_timestamp,
    ccl.source_modified_at,
    c.title,
    c.domain,
    c.service,
    c.markdown_file_path,
    -- Priority calculation (higher = more urgent)
    (ccl.existing_faq_count * 100) +
    DATEDIFF(CURRENT_TIMESTAMP(), ccl.source_modified_at) as priority_score
FROM content_change_log ccl
INNER JOIN content_repo c ON ccl.content_id = c.content_id
WHERE ccl.requires_faq_regeneration = TRUE
  AND c.status = 'active'
ORDER BY priority_score DESC, ccl.detection_timestamp DESC;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
-- Uncomment and run these after schema creation to verify

-- SELECT '✅ Schema V5.0 deployed successfully!' as status;

-- SHOW TABLES;
-- SHOW VIEWS;

-- SELECT COUNT(*) as content_count FROM content_repo;
-- SELECT COUNT(*) as questions_count FROM faq_questions;
-- SELECT COUNT(*) as answers_count FROM faq_answers;
-- SELECT COUNT(*) as mappings_count FROM faq_content_map;
-- SELECT COUNT(*) as changes_count FROM content_change_log;
-- SELECT COUNT(*) as audit_count FROM faq_audit_log;

-- ============================================================================
-- END OF SCHEMA V5.0
-- ============================================================================