# Databricks Unity Catalog Deployment Guide

## Overview

This guide explains how to deploy the FAQ Update schema to Databricks Unity Catalog. The original SQLite schema has been converted to Databricks-compatible SQL.

## Files

- **create_schema.sql** - Original SQLite schema (DO NOT use in Databricks)
- **create_schema_databricks.sql** - Databricks Unity Catalog compatible schema (USE THIS)

## Prerequisites

1. **Access Requirements:**
   - Databricks workspace access
   - Unity Catalog enabled
   - CREATE CATALOG or USE CATALOG privilege
   - CREATE SCHEMA privilege
   - CREATE TABLE privilege

2. **Unity Catalog Namespace:**
   - Catalog: `<your_catalog_name>` (e.g., `faq_catalog`, `onedata_us_east_1_shared_prod`)
   - Schema: `<your_schema_name>` (e.g., `faq_schema`, `faq_update`)
   - Tables will be: `catalog.schema.table_name`

## Step-by-Step Deployment

### Option 1: Deploy Using Databricks SQL Editor (Recommended)

#### Step 1: Set Up Catalog and Schema

```sql
-- Create or use existing catalog
-- CREATE CATALOG IF NOT EXISTS faq_catalog;
USE CATALOG your_catalog_name;

-- Create schema for FAQ tables
-- CREATE SCHEMA IF NOT EXISTS faq_schema;
USE SCHEMA your_schema_name;
```

#### Step 2: Open SQL Editor
1. Navigate to **SQL Editor** in Databricks workspace
2. Connect to a SQL Warehouse (not cluster)
3. Ensure you're using Unity Catalog-enabled warehouse

#### Step 3: Execute Schema Script
1. Open `create_schema_databricks.sql`
2. **IMPORTANT:** Update the catalog/schema names at the top of the file if using fully qualified names
3. Copy the entire script
4. Paste into SQL Editor
5. Run the script (Execute All or run statement by statement)

#### Step 4: Verify Deployment
```sql
-- Check tables were created
SHOW TABLES;

-- Verify table schemas
DESCRIBE EXTENDED content_repo;
DESCRIBE EXTENDED faq_questions;
DESCRIBE EXTENDED faq_answers;
DESCRIBE EXTENDED content_change_log;

-- Check views
SHOW VIEWS;
```

### Option 2: Deploy Using Databricks Notebook (Recommended for Complex Deployments)

#### Step 1: Import Notebook

A complete, production-ready notebook is available at:
**`FAQ_update/sql/databricks_notebook.py`**

Features:
- ✅ Robust SQL parsing (handles comments correctly)
- ✅ Handles multi-line statements properly
- ✅ Detailed error reporting
- ✅ Automatic verification
- ✅ Built-in optimization
- ✅ Progress tracking

#### Step 2: Configure and Run

1. **Import** `databricks_notebook.py` into your Databricks workspace
2. **Update** configuration in cell 3:
   ```python
   CATALOG_NAME = "your_catalog_name"
   SCHEMA_NAME = "your_schema_name"
   ```
3. **Paste SQL** in cell 6 (copy entire `create_schema_databricks.sql`)
4. **Run all cells** sequentially
5. **Review** execution summary and verification results

#### Step 3: Key Features

The notebook includes:
- **Smart SQL parsing**: Removes comments without breaking statements
- **Statement-by-statement execution**: Shows progress for each step
- **Error collection**: Continues execution and reports all errors at end
- **Automatic verification**: Checks tables, views, and schemas
- **Optimization**: Runs ZORDER BY for query performance
- **Detailed reporting**: Success/failure counts and error details

See `databricks_notebook.py` for the complete implementation.

### Option 3: Deploy Using Python Script (Automated)

```python
from databricks import sql
import os

# Connection parameters
host = os.getenv("DATABRICKS_HOST")
token = os.getenv("DATABRICKS_TOKEN")
http_path = os.getenv("DATABRICKS_HTTP_PATH")

# Unity Catalog namespace
catalog = "your_catalog_name"
schema = "your_schema_name"

# Read SQL file
with open("create_schema_databricks.sql", "r") as f:
    sql_script = f.read()

# Connect to Databricks
connection = sql.connect(
    server_hostname=host,
    http_path=http_path,
    access_token=token
)

cursor = connection.cursor()

try:
    # Set catalog and schema
    cursor.execute(f"USE CATALOG {catalog}")
    cursor.execute(f"USE SCHEMA {schema}")

    # Execute statements
    statements = [s.strip() for s in sql_script.split(';') if s.strip()]

    for stmt in statements:
        if stmt.startswith('--') or not stmt:
            continue
        cursor.execute(stmt)
        print(f"✅ Executed successfully")

    print("🎉 Schema deployment complete!")

finally:
    cursor.close()
    connection.close()
```

## Key Differences from SQLite

### 1. Data Types
| SQLite | Databricks | Notes |
|--------|-----------|-------|
| `TEXT` | `STRING` | String data |
| `INTEGER` | `BIGINT` or `INT` | Primary keys use BIGINT |
| `INTEGER PRIMARY KEY AUTOINCREMENT` | `BIGINT GENERATED ALWAYS AS IDENTITY` | Auto-increment |
| `BOOLEAN` | `BOOLEAN` | Same name, different syntax |
| `JSON` | `STRING` | Store JSON as STRING, query with get_json_object() |

### 2. Timestamps
- SQLite: `strftime('%Y-%m-%dT%H:%M:%SZ','now')`
- Databricks: `CURRENT_TIMESTAMP()`

### 3. JSON Queries
- SQLite: `json_extract(metadata, '$.page')`
- Databricks: `get_json_object(metadata, '$.page')`

### 4. Date Calculations
- SQLite: `julianday(date1) - julianday(date2)`
- Databricks: `DATEDIFF(date1, date2)`

### 5. Indexes
- SQLite: `CREATE INDEX idx_name ON table(column)`
- Databricks: Use **Z-ordering** and **partitioning** instead

### 6. Transactions
- SQLite: `BEGIN TRANSACTION; ... COMMIT;`
- Databricks: Not supported for DDL; use notebooks for orchestration

### 7. Foreign Keys
- Both support foreign keys, but enforcement differs
- Databricks enforces at constraint level, not PRAGMA level

## Post-Deployment: Performance Optimization

### Z-Ordering (Run Periodically)

```sql
-- Optimize content_repo for common queries
OPTIMIZE content_repo ZORDER BY (raw_file_nme, content_checksum, last_modified_dt);

-- Optimize faq_questions
OPTIMIZE faq_questions ZORDER BY (question_txt, domain, service);

-- Optimize faq_answers
OPTIMIZE faq_answers ZORDER BY (question_id, domain, service);

-- Optimize content_change_log (most important!)
OPTIMIZE content_change_log ZORDER BY (
    content_checksum,
    file_name,
    requires_faq_regeneration,
    detected_at
);
```

### Table Partitioning (Optional)

For very large tables, consider partitioning:

```sql
-- Example: Partition content_change_log by detection date
CREATE TABLE content_change_log_partitioned (
    -- same columns as before
)
PARTITIONED BY (detected_date DATE)
AS SELECT
    *,
    CAST(detected_at AS DATE) as detected_date
FROM content_change_log;
```

## Maintenance Commands

### Analyze Tables (Update Statistics)

```sql
ANALYZE TABLE content_repo COMPUTE STATISTICS;
ANALYZE TABLE faq_questions COMPUTE STATISTICS;
ANALYZE TABLE faq_answers COMPUTE STATISTICS;
ANALYZE TABLE content_change_log COMPUTE STATISTICS;
```

### Vacuum Old Files

```sql
-- Remove old data files (retention default: 7 days)
VACUUM content_repo RETAIN 168 HOURS;  -- 7 days
VACUUM content_change_log RETAIN 168 HOURS;
```

### Check Table History

```sql
DESCRIBE HISTORY content_change_log;
```

## Querying JSON Metadata

### Extract JSON Fields

```sql
-- Extract page number from metadata
SELECT
    change_id,
    file_name,
    get_json_object(metadata, '$.page') as page_number,
    get_json_object(metadata, '$.domain') as domain,
    get_json_object(metadata, '$.title') as title
FROM content_change_log;
```

### Parse Entire JSON Object

```sql
-- Parse JSON into struct
SELECT
    change_id,
    from_json(
        metadata,
        'page INT, domain STRING, title STRING, orgoid STRING'
    ) as metadata_struct
FROM content_change_log;

-- Access struct fields
SELECT
    change_id,
    metadata_struct.page,
    metadata_struct.domain
FROM (
    SELECT
        change_id,
        from_json(
            metadata,
            'page INT, domain STRING, title STRING, orgoid STRING'
        ) as metadata_struct
    FROM content_change_log
);
```

## Common Queries

### 1. Get All Changes Requiring Regeneration

```sql
SELECT
    change_id,
    content_id,
    file_name,
    get_json_object(metadata, '$.page') as page_number,
    content_checksum,
    existing_faq_count,
    detected_at
FROM content_change_log
WHERE requires_faq_regeneration = true
ORDER BY existing_faq_count DESC, detected_at DESC;
```

### 2. Get Latest Content State

```sql
SELECT * FROM v_latest_content_checksums
ORDER BY last_detected_at DESC;
```

### 3. Get Regeneration Queue

```sql
SELECT * FROM v_regeneration_queue
LIMIT 100;
```

### 4. Detection Run Statistics

```sql
SELECT * FROM v_detection_run_stats
ORDER BY run_started_at DESC
LIMIT 10;
```

## Integration with Existing FAQ Pipeline

### Update Your Hydra Configs

Based on your project structure, update the pipeline configs to use Unity Catalog:

```yaml
# settings/sors/analytics_assist_config/analytics_assist_config.yaml
databases:
  faq_update:
    catalog: "your_catalog_name"
    schema: "your_schema_name"
    connection_type: "unity_catalog"
```

### Access from PySpark

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Read from Unity Catalog tables
content_changes = spark.table("your_catalog.your_schema.content_change_log")

# Filter for regeneration
needs_regen = content_changes.filter("requires_faq_regeneration = true")

# Get latest checksums view
latest_checksums = spark.table("your_catalog.your_schema.v_latest_content_checksums")
```

### Access from Python (Databricks SQL Connector)

```python
from databricks import sql
import os

connection = sql.connect(
    server_hostname=os.getenv("DATABRICKS_HOST"),
    http_path=os.getenv("DATABRICKS_HTTP_PATH"),
    access_token=os.getenv("DATABRICKS_TOKEN")
)

cursor = connection.cursor()

# Query content changes
cursor.execute("""
    SELECT * FROM your_catalog.your_schema.content_change_log
    WHERE requires_faq_regeneration = true
    LIMIT 100
""")

results = cursor.fetchall()
for row in results:
    print(row)

cursor.close()
connection.close()
```

## Troubleshooting

### Error: "Catalog does not exist"
```sql
-- List available catalogs
SHOW CATALOGS;

-- Create catalog if needed
CREATE CATALOG IF NOT EXISTS your_catalog_name;
```

### Error: "Schema does not exist"
```sql
-- List schemas in catalog
SHOW SCHEMAS IN your_catalog_name;

-- Create schema
CREATE SCHEMA IF NOT EXISTS your_catalog_name.your_schema_name;
```

### Error: "GENERATED ALWAYS AS IDENTITY not supported"
- Check your Databricks Runtime version (DBR)
- Requires DBR 10.4 LTS or higher
- Alternative: Use `BIGINT` without IDENTITY and generate IDs in application

### Error: "Foreign key constraint violation"
- Ensure parent table exists before child table
- Check if referenced rows exist
- Verify constraint names don't conflict

### Performance Issues
- Run `OPTIMIZE` with `ZORDER BY` on frequently queried columns
- Run `ANALYZE TABLE` to update statistics
- Check query plans with `EXPLAIN` command
- Consider partitioning large tables

## Security Best Practices

### Grant Permissions

```sql
-- Grant read access to FAQ users
GRANT SELECT ON TABLE content_repo TO `faq_users`;
GRANT SELECT ON TABLE faq_questions TO `faq_users`;
GRANT SELECT ON TABLE faq_answers TO `faq_users`;
GRANT SELECT ON TABLE content_change_log TO `faq_users`;

-- Grant write access to FAQ service account
GRANT INSERT, UPDATE, DELETE ON TABLE content_change_log TO `faq_service_account`;

-- Grant view access
GRANT SELECT ON VIEW v_regeneration_queue TO `faq_users`;
```

### Row-Level Security (Optional)

```sql
-- Example: Filter by orgoid
CREATE FUNCTION filter_by_org(orgid STRING)
RETURN orgid = current_user();

ALTER TABLE content_repo SET ROW FILTER filter_by_org ON (orgoid);
```

## Backup and Recovery

### Create Backups

```sql
-- Create backup using DEEP CLONE
CREATE TABLE content_change_log_backup
DEEP CLONE content_change_log;
```

### Restore from Backup

```sql
-- Restore from backup
CREATE OR REPLACE TABLE content_change_log
AS SELECT * FROM content_change_log_backup;
```

### Time Travel Queries

```sql
-- Query table as of timestamp
SELECT * FROM content_change_log
VERSION AS OF 10;

-- Query table as of timestamp
SELECT * FROM content_change_log
TIMESTAMP AS OF '2025-01-15T10:00:00Z';
```

## Next Steps

1. **Deploy schema** using one of the methods above
2. **Test queries** to ensure everything works
3. **Optimize tables** with Z-ordering
4. **Update Python code** to use Unity Catalog tables
5. **Update Hydra configs** with new table paths
6. **Set up permissions** for users and service accounts
7. **Schedule OPTIMIZE** jobs for maintenance
8. **Monitor performance** using Databricks SQL query history

## Support

For issues or questions:
1. Check Databricks documentation: https://docs.databricks.com/
2. Review Unity Catalog best practices
3. Check query execution plans with `EXPLAIN`
4. Review table properties with `SHOW TBLPROPERTIES`
