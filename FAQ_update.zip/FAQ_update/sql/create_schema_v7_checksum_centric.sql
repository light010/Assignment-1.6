-- ============================================================================
-- FAQ UPDATE DATABASE - PRODUCTION SCHEMA V7.0
-- ============================================================================
-- Architecture: PURE CHECKSUM-CENTRIC (Content Identity vs Location Separation)
-- Date: 2025-10-21
-- Author: Principal Application Architect
-- Target: Databricks Unity Catalog (DBR 10.4+)
--
-- CORE PHILOSOPHY:
-- - Checksum = Content Identity (WHAT the content is - immutable)
-- - Location = Presentation Metadata (WHERE it appears - mutable)
-- - FAQs link to checksums (content), NOT locations (page numbers)
--
-- WHY V7 (Critical Design Fix):
-- Problem: Page insertion shifts page numbers but content unchanged
--   Before: Page 2 = "Sick Leave" (checksum abc222)
--   After:  Page 3 = "Sick Leave" (checksum abc222) ← Same content, new location!
--
-- V6 Behavior: Regenerate FAQ for "new page 3" ❌ (waste of resources)
-- V7 Behavior: Checksum abc222 unchanged → FAQ still valid ✅
--
-- ARCHITECTURAL CHANGES FROM V6:
-- 1. ✅ Checksum is the PRIMARY identity (not content_id)
-- 2. ✅ Location metadata (file_name, page_number) separated from content
-- 3. ✅ page_number is NULLABLE (not all content has pages)
-- 4. ✅ One checksum can have multiple locations over time
-- 5. ✅ Detection compares checksums globally (not per-file)
-- ============================================================================

-- ============================================================================
-- SETUP
-- ============================================================================
-- USE CATALOG your_catalog_name;
-- USE SCHEMA your_schema_name;

-- Drop existing objects (reverse dependency order)
DROP VIEW IF EXISTS v_active_faqs_with_locations;
DROP VIEW IF EXISTS v_faqs_needing_review;
DROP VIEW IF EXISTS v_content_changes_summary;
DROP VIEW IF EXISTS v_faq_regeneration_queue;
DROP VIEW IF EXISTS v_current_content_locations;

DROP TABLE IF EXISTS faq_audit_log;
DROP TABLE IF EXISTS faq_answer_sources;
DROP TABLE IF EXISTS faq_question_sources;
DROP TABLE IF EXISTS content_change_log;
DROP TABLE IF EXISTS content_locations;
DROP TABLE IF EXISTS faq_answers;
DROP TABLE IF EXISTS faq_questions;
DROP TABLE IF EXISTS content_checksums;

-- ============================================================================
-- TABLE 1: content_checksums (IMMUTABLE CONTENT IDENTITY)
-- ============================================================================
-- Purpose: Master table of unique content identities
-- One row per unique content (regardless of where it appears)
-- ============================================================================

CREATE TABLE content_checksums (
    -- Primary Key (Natural Key - this IS the identity)
    content_checksum STRING NOT NULL COMMENT 'SHA-256 hash - THE content identity (64 chars)',

    -- Content Type (helps with processing)
    file_type STRING COMMENT 'pdf, html, docx, xml, confluence, etc.',
    content_format STRING COMMENT 'markdown, html, plain_text',

    -- Content Metadata (intrinsic to the content itself)
    title STRING COMMENT 'Extracted title/heading from content',
    word_count INT COMMENT 'Number of words in content',
    char_count INT COMMENT 'Number of characters',

    -- Organization Context (business classification)
    domain STRING COMMENT 'Business domain (HR, IT, Finance, etc.)',
    service STRING COMMENT 'Service area (Policy, Benefits, Payroll, etc.)',

    -- Lifecycle
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, archived, deleted',

    -- Timestamps (immutable after creation)
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'When this content first appeared',
    first_seen_at TIMESTAMP COMMENT 'When we first detected this checksum',

    -- File Path (the original markdown extraction)
    markdown_file_path STRING COMMENT 'Path to extracted markdown file'
)
COMMENT 'Master table of unique content identities (checksum = primary key)'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);

-- Constraints
ALTER TABLE content_checksums ADD CONSTRAINT pk_content_checksums PRIMARY KEY (content_checksum);
ALTER TABLE content_checksums ADD CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_checksums ADD CONSTRAINT chk_content_status CHECK (
    status IN ('active', 'archived', 'deleted')
);

-- Enable column defaults
ALTER TABLE content_checksums SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 2: content_locations (MUTABLE LOCATION METADATA)
-- ============================================================================
-- Purpose: Tracks WHERE content appears (can change over time)
-- One checksum can have MULTIPLE locations (e.g., same content on multiple pages)
-- One location can have MULTIPLE checksums over time (e.g., page 2 content changes)
-- ============================================================================

CREATE TABLE content_locations (
    -- Primary Key
    location_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key to Content Identity
    content_checksum STRING NOT NULL COMMENT 'FK to content_checksums',

    -- Location Identification (varies by file type)
    file_name STRING NOT NULL COMMENT 'Source file name (e.g., employee_handbook.pdf)',
    page_number INT COMMENT 'Page number (NULL for non-paginated content like HTML)',
    section_name STRING COMMENT 'Section/chapter name (optional)',
    url STRING COMMENT 'URL (for web content like Confluence)',
    breadcrumb STRING COMMENT 'Navigation breadcrumb',

    -- Location Status
    is_current_location BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this the current location for this checksum?',

    -- Validity Period (when this checksum was at this location)
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP COMMENT 'NULL = still at this location',

    -- Source File Metadata
    source_file_path STRING COMMENT 'Original file path',
    file_version STRING COMMENT 'File version number',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Tracks WHERE content appears (mutable - locations can change over time)'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE content_locations ADD CONSTRAINT pk_content_locations PRIMARY KEY (location_id);

-- A location (file+page) can only have ONE current checksum at a time
-- (But over time, that location can have had many different checksums)
ALTER TABLE content_locations ADD CONSTRAINT unique_current_location
    UNIQUE (file_name, page_number, section_name, is_current_location)
    -- This allows: file='handbook.pdf', page=2 to have multiple historical checksums
    -- But only ONE can be is_current_location=TRUE at any time

-- Enable column defaults
ALTER TABLE content_locations SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Key (informational)
-- ALTER TABLE content_locations ADD CONSTRAINT fk_location_checksum
--     FOREIGN KEY (content_checksum) REFERENCES content_checksums(content_checksum);

-- ============================================================================
-- TABLE 3: faq_questions
-- ============================================================================
-- Purpose: FAQ questions (content-agnostic - just the question text)
-- ============================================================================

CREATE TABLE faq_questions (
    -- Primary Key
    question_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Question Content
    question_text STRING NOT NULL COMMENT 'The actual FAQ question',

    -- Generation Metadata
    source_type STRING COMMENT 'from_documents, from_user_queries, from_manual, from_validation',
    generation_method STRING COMMENT 'llm_generated, human_written, extracted',

    -- Organization Context (for multi-tenancy)
    domain STRING COMMENT 'Business domain',
    service STRING COMMENT 'Service area',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ questions - content-agnostic'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_questions ADD CONSTRAINT pk_faq_questions PRIMARY KEY (question_id);
ALTER TABLE faq_questions ADD CONSTRAINT chk_question_status CHECK (
    status IN ('active', 'invalidated', 'archived', 'deleted')
);

-- Enable column defaults
ALTER TABLE faq_questions SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- TABLE 4: faq_question_sources
-- ============================================================================
-- Purpose: Links questions to content checksums (MANY-TO-MANY)
-- Question can reference multiple content pieces (checksums)
-- ============================================================================

CREATE TABLE faq_question_sources (
    -- Primary Key
    source_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Keys
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',
    content_checksum STRING NOT NULL COMMENT 'FK to content_checksums (which content inspired this question)',

    -- Contribution Tracking
    is_primary_source BOOLEAN DEFAULT FALSE COMMENT 'Is this the primary content for this question?',
    contribution_weight DOUBLE COMMENT 'How much this content contributed (0.0 to 1.0)',

    -- Validity Tracking
    is_valid BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this source still valid?',
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP COMMENT 'When this source was invalidated (NULL if still valid)',

    -- Invalidation Details
    invalidation_reason STRING COMMENT 'content_changed, content_deleted, quality_issue, manual',
    invalidated_by_change_id BIGINT COMMENT 'FK to content_change_log',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Question provenance - which content (checksums) inspired each question'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_question_sources ADD CONSTRAINT pk_faq_question_sources PRIMARY KEY (source_id);
ALTER TABLE faq_question_sources ADD CONSTRAINT chk_qsrc_contribution CHECK (
    contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
);

-- Prevent duplicate sources for same question
ALTER TABLE faq_question_sources ADD CONSTRAINT unique_question_checksum
    UNIQUE (question_id, content_checksum);

-- Enable column defaults
ALTER TABLE faq_question_sources SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Keys (informational)
-- ALTER TABLE faq_question_sources ADD CONSTRAINT fk_qsrc_question
--     FOREIGN KEY (question_id) REFERENCES faq_questions(question_id);
-- ALTER TABLE faq_question_sources ADD CONSTRAINT fk_qsrc_checksum
--     FOREIGN KEY (content_checksum) REFERENCES content_checksums(content_checksum);

-- ============================================================================
-- TABLE 5: faq_answers
-- ============================================================================
-- Purpose: FAQ answers (1:1 with questions, sources tracked separately)
-- ============================================================================

CREATE TABLE faq_answers (
    -- Primary Key
    answer_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key to Question (1:1 relationship)
    question_id BIGINT NOT NULL COMMENT 'FK to faq_questions',

    -- Answer Content
    answer_text STRING NOT NULL COMMENT 'The FAQ answer (HTML or Markdown)',
    answer_format STRING DEFAULT 'html' COMMENT 'html, markdown, plain',

    -- Quality Metrics
    confidence_score DOUBLE COMMENT 'Generation confidence (0.0 to 1.0)',

    -- Lifecycle Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),

    -- Audit Fields
    created_by STRING DEFAULT 'system',
    modified_by STRING DEFAULT 'system'
)
COMMENT 'FAQ answers - linked to questions (1:1), sources tracked separately'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_answers ADD CONSTRAINT pk_faq_answers PRIMARY KEY (answer_id);
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_status CHECK (
    status IN ('active', 'invalidated', 'archived', 'deleted')
);
ALTER TABLE faq_answers ADD CONSTRAINT chk_answer_format CHECK (
    answer_format IN ('html', 'markdown', 'plain')
);
ALTER TABLE faq_answers ADD CONSTRAINT chk_confidence_score CHECK (
    confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0)
);

-- Enable column defaults
ALTER TABLE faq_answers SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Key (informational)
-- ALTER TABLE faq_answers ADD CONSTRAINT fk_answer_question
--     FOREIGN KEY (question_id) REFERENCES faq_questions(question_id);

-- ============================================================================
-- TABLE 6: faq_answer_sources
-- ============================================================================
-- Purpose: Links answers to content checksums (MANY-TO-MANY)
-- Answer can synthesize from multiple content pieces (checksums)
-- ============================================================================

CREATE TABLE faq_answer_sources (
    -- Primary Key
    source_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Keys
    answer_id BIGINT NOT NULL COMMENT 'FK to faq_answers',
    content_checksum STRING NOT NULL COMMENT 'FK to content_checksums (which content provided answer info)',

    -- Contribution Tracking
    is_primary_source BOOLEAN DEFAULT FALSE COMMENT 'Is this the primary content for this answer?',
    contribution_weight DOUBLE COMMENT 'How much this content contributed (0.0 to 1.0, should sum to ~1.0)',

    -- Context Employment (optional - if you track which parts were used)
    context_employed STRING COMMENT 'JSON: which sections/paragraphs were used',

    -- Validity Tracking
    is_valid BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Is this source still valid?',
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP COMMENT 'When this source was invalidated (NULL if still valid)',

    -- Invalidation Details
    invalidation_reason STRING COMMENT 'content_changed, content_deleted, quality_issue, manual',
    invalidated_by_change_id BIGINT COMMENT 'FK to content_change_log',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Answer provenance - which content (checksums) provided info for each answer'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_answer_sources ADD CONSTRAINT pk_faq_answer_sources PRIMARY KEY (source_id);
ALTER TABLE faq_answer_sources ADD CONSTRAINT chk_asrc_contribution CHECK (
    contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
);

-- Prevent duplicate sources for same answer
ALTER TABLE faq_answer_sources ADD CONSTRAINT unique_answer_checksum
    UNIQUE (answer_id, content_checksum);

-- Enable column defaults
ALTER TABLE faq_answer_sources SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Foreign Keys (informational)
-- ALTER TABLE faq_answer_sources ADD CONSTRAINT fk_asrc_answer
--     FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id);
-- ALTER TABLE faq_answer_sources ADD CONSTRAINT fk_asrc_checksum
--     FOREIGN KEY (content_checksum) REFERENCES content_checksums(content_checksum);

-- ============================================================================
-- TABLE 7: content_change_log
-- ============================================================================
-- Purpose: Detection log - tracks when new checksums appear or locations change
-- ============================================================================

CREATE TABLE content_change_log (
    -- Primary Key
    change_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Content Identity
    content_checksum STRING NOT NULL COMMENT 'The checksum being detected/changed',
    previous_checksum STRING COMMENT 'Previous checksum at this location (NULL for new locations)',

    -- Location Context (where this checksum was found)
    file_name STRING NOT NULL,
    page_number INT COMMENT 'Nullable - not all content has pages',
    section_name STRING COMMENT 'Optional section identifier',

    -- Detection Decision
    requires_faq_regeneration BOOLEAN NOT NULL COMMENT 'TRUE = new checksum (content), FALSE = existing checksum',

    -- Change Classification
    change_type STRING COMMENT 'new_content, modified_content, unchanged_content, deleted_content, location_change',

    -- FAQ Impact Metrics (computed at detection time)
    affected_question_count INT NOT NULL DEFAULT 0 COMMENT 'Questions referencing this checksum',
    affected_answer_count INT NOT NULL DEFAULT 0 COMMENT 'Answers referencing this checksum',
    total_affected_faqs INT NOT NULL DEFAULT 0 COMMENT 'Total unique FAQs affected',

    -- Detection Context
    detection_run_id STRING NOT NULL COMMENT 'Unique identifier for detection batch',
    detection_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    detection_period_start TIMESTAMP COMMENT 'since_date parameter used in detection',

    -- Source Metadata
    source_modified_at TIMESTAMP COMMENT 'When the source file was last modified',

    -- Organization Context
    domain STRING,
    service STRING
)
COMMENT 'Content change detection log - tracks new checksums and location changes'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE content_change_log ADD CONSTRAINT pk_content_change_log PRIMARY KEY (change_id);
ALTER TABLE content_change_log ADD CONSTRAINT chk_ccl_checksum_len CHECK (LENGTH(content_checksum) = 64);
ALTER TABLE content_change_log ADD CONSTRAINT chk_ccl_prev_checksum_len CHECK (
    previous_checksum IS NULL OR LENGTH(previous_checksum) = 64
);
ALTER TABLE content_change_log ADD CONSTRAINT chk_change_type CHECK (
    change_type IS NULL OR
    change_type IN ('new_content', 'modified_content', 'unchanged_content', 'deleted_content', 'location_change')
);

-- Enable column defaults
ALTER TABLE content_change_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- Prevent duplicate detections
ALTER TABLE content_change_log ADD CONSTRAINT unique_location_detection
    UNIQUE (file_name, page_number, section_name, detection_run_id);

-- Foreign Key (informational)
-- ALTER TABLE content_change_log ADD CONSTRAINT fk_ccl_checksum
--     FOREIGN KEY (content_checksum) REFERENCES content_checksums(content_checksum);

-- ============================================================================
-- TABLE 8: faq_audit_log
-- ============================================================================
-- Purpose: Complete audit trail for all FAQ operations
-- ============================================================================

CREATE TABLE faq_audit_log (
    -- Primary Key
    audit_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- What Changed
    table_name STRING NOT NULL COMMENT 'Table affected',
    record_id BIGINT COMMENT 'Primary key of affected record',

    -- For checksum-based tables
    content_checksum STRING COMMENT 'Checksum affected (for content_checksums table)',

    -- Action Details
    action STRING NOT NULL COMMENT 'INSERT, UPDATE, DELETE, INVALIDATE, RESTORE',

    -- Change Details
    old_values STRING COMMENT 'JSON snapshot before change',
    new_values STRING COMMENT 'JSON snapshot after change',

    -- Context
    detection_run_id STRING COMMENT 'Related detection run (if applicable)',
    change_reason STRING COMMENT 'Why this change was made',

    -- Who & When
    performed_by STRING NOT NULL DEFAULT 'system',
    performed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Complete audit trail for all FAQ operations'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Constraints
ALTER TABLE faq_audit_log ADD CONSTRAINT pk_faq_audit_log PRIMARY KEY (audit_id);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_table CHECK (
    table_name IN ('content_checksums', 'content_locations', 'faq_questions', 'faq_answers',
                   'faq_question_sources', 'faq_answer_sources')
);
ALTER TABLE faq_audit_log ADD CONSTRAINT chk_audit_action CHECK (
    action IN ('INSERT', 'UPDATE', 'DELETE', 'INVALIDATE', 'RESTORE')
);

-- Enable column defaults
ALTER TABLE faq_audit_log SET TBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported');

-- ============================================================================
-- VIEWS - Query Patterns for Checksum-Centric Architecture
-- ============================================================================

-- ============================================================================
-- VIEW: v_current_content_locations
-- ============================================================================
-- Purpose: Current locations of all active content (denormalized for queries)
-- ============================================================================

CREATE OR REPLACE VIEW v_current_content_locations AS
SELECT
    cc.content_checksum,
    cc.title,
    cc.file_type,
    cc.domain,
    cc.service,
    cc.word_count,
    cc.status as content_status,
    cc.created_at as content_created_at,
    cl.location_id,
    cl.file_name,
    cl.page_number,
    cl.section_name,
    cl.url,
    cl.breadcrumb,
    cl.source_file_path,
    cl.valid_from as location_valid_from,
    cc.markdown_file_path
FROM content_checksums cc
INNER JOIN content_locations cl ON cc.content_checksum = cl.content_checksum
WHERE cc.status = 'active'
  AND cl.is_current_location = TRUE
  AND cl.valid_until IS NULL;

-- ============================================================================
-- VIEW: v_active_faqs_with_locations
-- ============================================================================
-- Purpose: Active FAQs with their source checksums AND current locations
-- ============================================================================

CREATE OR REPLACE VIEW v_active_faqs_with_locations AS
SELECT
    q.question_id,
    q.question_text,
    a.answer_id,
    a.answer_text,
    a.answer_format,
    a.confidence_score,

    -- Question sources (checksums)
    CONCAT_WS(', ', COLLECT_SET(DISTINCT qs.content_checksum)) as question_checksums,
    COUNT(DISTINCT qs.source_id) as question_source_count,
    SUM(CASE WHEN qs.is_valid = TRUE THEN 1 ELSE 0 END) as question_sources_valid,

    -- Answer sources (checksums)
    CONCAT_WS(', ', COLLECT_SET(DISTINCT asrc.content_checksum)) as answer_checksums,
    COUNT(DISTINCT asrc.source_id) as answer_source_count,
    SUM(CASE WHEN asrc.is_valid = TRUE THEN 1 ELSE 0 END) as answer_sources_valid,

    -- Current locations (WHERE the checksums currently appear)
    CONCAT_WS(', ', COLLECT_SET(DISTINCT CONCAT(qcl.file_name, ':', CAST(qcl.page_number AS STRING)))) as question_locations,
    CONCAT_WS(', ', COLLECT_SET(DISTINCT CONCAT(acl.file_name, ':', CAST(acl.page_number AS STRING)))) as answer_locations,

    -- Overall validity
    CASE
        WHEN SUM(CASE WHEN qs.is_valid = FALSE OR asrc.is_valid = FALSE THEN 1 ELSE 0 END) = 0 THEN 'fully_valid'
        WHEN SUM(CASE WHEN qs.is_valid = FALSE OR asrc.is_valid = FALSE THEN 1 ELSE 0 END) > 0
         AND SUM(CASE WHEN qs.is_valid = TRUE AND asrc.is_valid = TRUE THEN 1 ELSE 0 END) > 0 THEN 'partially_valid'
        ELSE 'invalid'
    END as validity_status,

    q.domain,
    q.service,
    q.created_at as question_created_at,
    a.created_at as answer_created_at

FROM faq_questions q
INNER JOIN faq_answers a ON q.question_id = a.question_id
LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id
LEFT JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
LEFT JOIN content_locations qcl ON qs.content_checksum = qcl.content_checksum AND qcl.is_current_location = TRUE
LEFT JOIN content_locations acl ON asrc.content_checksum = acl.content_checksum AND acl.is_current_location = TRUE
WHERE q.status = 'active'
  AND a.status = 'active'
GROUP BY
    q.question_id, q.question_text, a.answer_id, a.answer_text,
    a.answer_format, a.confidence_score, q.domain, q.service,
    q.created_at, a.created_at;

-- ============================================================================
-- VIEW: v_faqs_needing_review
-- ============================================================================
-- Purpose: FAQs with invalidated sources (partial or full)
-- ============================================================================

CREATE OR REPLACE VIEW v_faqs_needing_review AS
SELECT
    q.question_id,
    q.question_text,
    a.answer_id,

    -- Invalid sources
    COUNT(DISTINCT CASE WHEN qs.is_valid = FALSE THEN qs.content_checksum END) as invalid_question_checksums,
    COUNT(DISTINCT CASE WHEN qs.is_valid = TRUE THEN qs.content_checksum END) as valid_question_checksums,
    COUNT(DISTINCT CASE WHEN asrc.is_valid = FALSE THEN asrc.content_checksum END) as invalid_answer_checksums,
    COUNT(DISTINCT CASE WHEN asrc.is_valid = TRUE THEN asrc.content_checksum END) as valid_answer_checksums,

    -- Invalidation reasons
    CONCAT_WS(', ', COLLECT_SET(qs.invalidation_reason)) as question_invalidation_reasons,
    CONCAT_WS(', ', COLLECT_SET(asrc.invalidation_reason)) as answer_invalidation_reasons,

    -- Most recent invalidation
    MAX(GREATEST(COALESCE(qs.valid_until, '1900-01-01'), COALESCE(asrc.valid_until, '1900-01-01'))) as last_invalidation_time,

    q.domain,
    q.service

FROM faq_questions q
INNER JOIN faq_answers a ON q.question_id = a.question_id
LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id
LEFT JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
WHERE q.status = 'active'
  AND a.status = 'active'
  AND (qs.is_valid = FALSE OR asrc.is_valid = FALSE)
GROUP BY q.question_id, q.question_text, a.answer_id, q.domain, q.service
ORDER BY last_invalidation_time DESC;

-- ============================================================================
-- VIEW: v_content_changes_summary
-- ============================================================================
-- Purpose: Summary of content changes by detection run
-- ============================================================================

CREATE OR REPLACE VIEW v_content_changes_summary AS
SELECT
    detection_run_id,
    MIN(detection_timestamp) as detection_started_at,
    MAX(detection_timestamp) as detection_completed_at,
    COUNT(*) as total_locations_analyzed,
    SUM(CASE WHEN requires_faq_regeneration = TRUE THEN 1 ELSE 0 END) as new_checksums_detected,
    SUM(CASE WHEN requires_faq_regeneration = FALSE THEN 1 ELSE 0 END) as existing_checksums,
    SUM(total_affected_faqs) as total_faqs_impacted,
    SUM(affected_question_count) as total_questions_affected,
    SUM(affected_answer_count) as total_answers_affected,
    COUNT(DISTINCT file_name) as unique_files,
    COUNT(DISTINCT content_checksum) as unique_checksums,
    COUNT(DISTINCT CASE WHEN change_type = 'new_content' THEN content_checksum END) as new_content_checksums,
    COUNT(DISTINCT CASE WHEN change_type = 'modified_content' THEN content_checksum END) as modified_content_checksums,
    COUNT(DISTINCT CASE WHEN change_type = 'location_change' THEN content_checksum END) as location_changes_only,
    COUNT(DISTINCT CASE WHEN change_type = 'deleted_content' THEN content_checksum END) as deleted_content
FROM content_change_log
GROUP BY detection_run_id
ORDER BY detection_started_at DESC;

-- ============================================================================
-- VIEW: v_faq_regeneration_queue
-- ============================================================================
-- Purpose: Checksums requiring FAQ regeneration (prioritized)
-- ============================================================================

CREATE OR REPLACE VIEW v_faq_regeneration_queue AS
SELECT
    ccl.change_id,
    ccl.content_checksum,
    ccl.previous_checksum,
    ccl.file_name,
    ccl.page_number,
    ccl.section_name,
    ccl.total_affected_faqs,
    ccl.affected_question_count,
    ccl.affected_answer_count,
    ccl.detection_run_id,
    ccl.detection_timestamp,
    ccl.source_modified_at,
    cc.title,
    cc.domain,
    cc.service,
    cc.markdown_file_path,

    -- Priority calculation (higher = more urgent)
    (ccl.total_affected_faqs * 100) +
    DATEDIFF(CURRENT_TIMESTAMP(), ccl.source_modified_at) as priority_score

FROM content_change_log ccl
INNER JOIN content_checksums cc ON ccl.content_checksum = cc.content_checksum
WHERE ccl.requires_faq_regeneration = TRUE
  AND cc.status = 'active'
ORDER BY priority_score DESC, ccl.detection_timestamp DESC;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- SELECT '✅ Schema V7.0 (Checksum-Centric) deployed successfully!' as status;
-- SHOW TABLES;
-- SHOW VIEWS;

-- ============================================================================
-- EXAMPLE USAGE: Page Insertion Scenario
-- ============================================================================

-- SCENARIO: Page inserted, shifting page numbers
-- Before: Page 2 = "Sick Leave" (checksum abc222)
-- After:  Page 3 = "Sick Leave" (checksum abc222) - same content, new location!

-- Step 1: Checksum abc222 already exists (created before)
-- SELECT * FROM content_checksums WHERE content_checksum = 'abc222';

-- Step 2: Old location marked as no longer current
-- UPDATE content_locations
-- SET is_current_location = FALSE, valid_until = CURRENT_TIMESTAMP()
-- WHERE file_name = 'handbook.pdf' AND page_number = 2;

-- Step 3: New location created for SAME checksum
-- INSERT INTO content_locations (content_checksum, file_name, page_number)
-- VALUES ('abc222', 'handbook.pdf', 3);

-- Step 4: Detection finds checksum abc222 at new location
-- INSERT INTO content_change_log (content_checksum, file_name, page_number,
--                                  requires_faq_regeneration, change_type)
-- VALUES ('abc222', 'handbook.pdf', 3, FALSE, 'location_change');
--        ^^^^^ FALSE = No FAQ regeneration needed!

-- Step 5: FAQs linked to checksum abc222 remain valid (no invalidation)
-- SELECT * FROM v_active_faqs_with_locations
-- WHERE question_checksums LIKE '%abc222%' OR answer_checksums LIKE '%abc222%';
-- Result: FAQ still valid, now shows "Page 3" instead of "Page 2" in locations

-- ============================================================================
-- END OF SCHEMA V7.0
-- ============================================================================