# LLM Prompt Templates for FAQ Generation

This document provides templates for using content diff information in LLM prompts for FAQ regeneration.

---

## Template 1: FAQ Regeneration from Content Changes

Use this template when you need to regenerate FAQs based on content modifications.

### Prompt Template

```
You are an expert FAQ writer tasked with updating FAQs based on content changes.

## Content Change Information

{LLM_CONTEXT_FROM_DIFF_FORMATTER}

## Your Task

Based on the content changes above:

1. **Identify impacted topics**: Which sections/policies were modified?
2. **Generate updated FAQs**: Create 3-5 frequently asked questions that address:
   - New information added
   - Policy changes
   - Clarifications needed due to modifications
3. **Provide clear answers**: Each answer should be 2-3 sentences, using information from the updated content.

## Output Format

For each FAQ, provide:
- **Question**: [Natural language question users might ask]
- **Answer**: [Clear, concise answer based on updated content]
- **Confidence**: [High/Medium/Low - how confident are you this is a common question]
- **Related Changes**: [Which specific changes this FAQ addresses]

Generate FAQs now:
```

### Example Usage

```python
from formatters.diff_formatter import DiffFormatter

formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')

# Get LLM-optimized context for a specific change
change_id = 4
llm_context = formatter.get_llm_prompt_context(change_id)

# Build the prompt
prompt = f"""
You are an expert FAQ writer tasked with updating FAQs based on content changes.

## Content Change Information

{llm_context}

## Your Task

Based on the content changes above:
...
"""

# Send to LLM
response = your_llm_client.generate(prompt)
```

---

## Template 2: Batch FAQ Review

Use this when reviewing multiple changes at once.

### Prompt Template

```
You are reviewing multiple content changes to determine FAQ generation priorities.

## All Content Changes

{BATCH_SUMMARY_FROM_DIFF_FORMATTER}

## Your Task

1. **Prioritize changes**: Rank changes by FAQ generation priority (High/Medium/Low)
2. **Identify themes**: Group related changes
3. **Suggest FAQ topics**: For each high-priority change, suggest 2-3 FAQ topics

## Priority Criteria

- **High**: Major policy changes, new benefits, compliance updates
- **Medium**: Clarifications, minor policy tweaks, process changes
- **Low**: Formatting updates, typo fixes, minor wording changes

Analyze and provide recommendations:
```

### Example Usage

```python
formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')

# Get batch summary
batch_summary = formatter.get_batch_summary(since_date='2025-10-01')

prompt = f"""
You are reviewing multiple content changes to determine FAQ generation priorities.

## All Content Changes

{batch_summary}

## Your Task
...
"""
```

---

## Template 3: Detailed FAQ Generation with Full Context

Use this when you need comprehensive FAQ generation with full diff visibility.

### Prompt Template

```
You are generating comprehensive FAQs for updated policy documentation.

## Full Change Summary

{HUMAN_READABLE_SUMMARY_FROM_DIFF_FORMATTER}

## Background Context

- Document: [Document name]
- Audience: [Target audience - employees, managers, HR, etc.]
- Purpose: [Purpose of FAQ - onboarding, self-service, compliance, etc.]

## Requirements

1. Generate 5-10 high-quality FAQs
2. Cover all major changes indicated in the diff
3. Use natural language questions employees would actually ask
4. Provide accurate answers based solely on the updated content
5. Flag any ambiguities or areas needing SME review

## FAQ Categories

Organize FAQs into these categories:
- Policy Changes (what changed and why)
- Eligibility (who qualifies)
- Process (how to request/apply)
- Compliance (legal/regulatory requirements)
- Edge Cases (special situations)

Generate comprehensive FAQs:
```

### Example Usage

```python
formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')

# Get comprehensive summary
full_summary = formatter.get_human_readable_summary(change_id=4)

prompt = f"""
You are generating comprehensive FAQs for updated policy documentation.

## Full Change Summary

{full_summary}

## Background Context

- Document: Employee Leave Policy
- Audience: All employees
- Purpose: Self-service HR portal

...
"""
```

---

## Template 4: Change Impact Assessment

Use this for assessing whether FAQ regeneration is warranted.

### Prompt Template

```
You are assessing whether content changes require FAQ regeneration.

## Change Details

{LLM_CONTEXT_FROM_DIFF_FORMATTER}

## Assessment Criteria

Evaluate the change against these criteria:

1. **User Impact**: Do users need to know about this?
   - [ ] Yes - affects user actions/decisions
   - [ ] No - internal/formatting change

2. **Complexity**: Is the change confusing or ambiguous?
   - [ ] High - likely to generate questions
   - [ ] Medium - some clarification may help
   - [ ] Low - self-explanatory

3. **Frequency**: How often will users encounter this?
   - [ ] High - daily/weekly usage
   - [ ] Medium - monthly/occasional
   - [ ] Low - rare edge case

## Your Decision

Based on the above:
- **Regenerate FAQs**: [Yes/No]
- **Reasoning**: [1-2 sentences explaining decision]
- **Recommended FAQ Count**: [If yes, how many FAQs to generate]
- **Suggested Topics**: [If yes, list 2-3 specific topics]

Provide your assessment:
```

---

## Template 5: FAQ Validation and Quality Check

Use this to validate generated FAQs against actual content changes.

### Prompt Template

```
You are validating FAQs against actual content changes to ensure accuracy.

## Original Change

{LLM_CONTEXT_FROM_DIFF_FORMATTER}

## Proposed FAQ

**Q**: {generated_question}
**A**: {generated_answer}

## Validation Checklist

Check the FAQ against these criteria:

1. **Accuracy**: Does the answer correctly reflect the changed content?
   - [ ] Fully accurate
   - [ ] Partially accurate (note issues)
   - [ ] Inaccurate (explain)

2. **Completeness**: Does it address the key aspects of the change?
   - [ ] Complete
   - [ ] Missing context (specify what)

3. **Clarity**: Is the language clear and unambiguous?
   - [ ] Clear
   - [ ] Needs improvement (suggest edits)

4. **Relevance**: Is this a question users would actually ask?
   - [ ] Highly relevant
   - [ ] Somewhat relevant
   - [ ] Not relevant (explain why)

## Your Verdict

- **Approved**: [Yes/No/With Changes]
- **Issues Found**: [List any problems]
- **Recommended Changes**: [Specific edits if needed]

Validate the FAQ:
```

---

## API Integration Examples

### Using with OpenAI API

```python
import openai
from formatters.diff_formatter import DiffFormatter

def generate_faqs_for_change(change_id: int, api_key: str) -> dict:
    """Generate FAQs using OpenAI API with diff context."""

    # Get formatted context
    formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')
    llm_context = formatter.get_llm_prompt_context(change_id)

    # Build prompt
    prompt = f"""
You are an expert FAQ writer for HR policies.

## Content Change

{llm_context}

## Task

Generate 3-5 FAQs that employees would ask about these changes.
Format as JSON array with: question, answer, confidence, related_change
"""

    # Call OpenAI
    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert FAQ writer."},
            {"role": "user", "content": prompt}
        ],
        response_format={"type": "json_object"}
    )

    return response.choices[0].message.content
```

### Using with Anthropic Claude API

```python
import anthropic
from formatters.diff_formatter import DiffFormatter

def generate_faqs_with_claude(change_id: int, api_key: str) -> str:
    """Generate FAQs using Claude API with diff context."""

    formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')
    llm_context = formatter.get_llm_prompt_context(change_id)

    prompt = f"""
You are an expert FAQ writer for HR policies.

<content_change>
{llm_context}
</content_change>

Based on the content change above, generate 3-5 frequently asked questions with clear answers.

Format each FAQ as:
Q: [question]
A: [answer]
Confidence: [High/Medium/Low]
"""

    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model="claude-3-sonnet-20240229",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )

    return message.content[0].text
```

---

## Best Practices

### 1. Context Selection

- **For Single Changes**: Use `get_llm_prompt_context()` - most concise
- **For Multiple Changes**: Use `get_batch_summary()` - good overview
- **For Deep Analysis**: Use `get_human_readable_summary()` - full details

### 2. Prompt Engineering Tips

- **Be specific** about output format (JSON, markdown, etc.)
- **Provide examples** of good FAQs in your prompt
- **Set constraints** (e.g., "2-3 sentences per answer")
- **Include audience context** (employees, managers, etc.)
- **Request confidence scores** to filter low-quality outputs

### 3. Quality Control

- Always validate LLM-generated FAQs against actual content
- Use Template 5 (Validation) as a second pass
- Have SMEs review FAQs for technical accuracy
- A/B test FAQ wording with users when possible

### 4. Batch Processing

```python
def process_all_changes_in_batch():
    """Process all recent changes for FAQ generation."""
    formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')

    # Get all changes from last 7 days
    from datetime import datetime, timedelta
    since_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT%H:%M:%SZ')

    batch_summary = formatter.get_batch_summary(since_date=since_date, max_changes=50)

    # Send to LLM for prioritization
    llm_response = your_llm_client.generate(template_2_prompt + batch_summary)

    # Then process high-priority changes individually
    for high_priority_change_id in extracted_high_priority_ids:
        llm_context = formatter.get_llm_prompt_context(high_priority_change_id)
        faqs = your_llm_client.generate(template_1_prompt + llm_context)
        # Store FAQs in database
```

---

## Output Examples

### Expected FAQ Format

```markdown
**Q: How many sick leave days do employees get now?**
A: Employees are now entitled to 15 days of paid sick leave per year, increased from the previous 10 days. Unused sick leave can carry over up to 3 days to the following year.
Confidence: High
Related Changes: Sick Leave policy update (increased from 10 to 15 days, new carry-over provision)

**Q: When do I need a medical certificate for sick leave?**
A: A medical certificate is now required for absences over 2 consecutive days, changed from the previous requirement of 3 days. This helps us better support employees while maintaining appropriate documentation.
Confidence: High
Related Changes: Sick Leave medical certificate requirement (reduced from 3 to 2 days)

**Q: Can I take remote work during parental leave?**
A: Yes, employees may request flexible remote work arrangements during the final 4 weeks of parental leave, subject to manager and HR approval and based on business needs and role requirements.
Confidence: Medium
Related Changes: New Remote Work During Parental Leave section added
```

---

## Troubleshooting

### Issue: LLM generates inaccurate FAQs

**Solution**: Use `get_human_readable_summary()` instead of `get_llm_prompt_context()` for more complete diff information.

### Issue: Too many FAQs generated

**Solution**: Add explicit constraints in prompt: "Generate exactly 3 FAQs" or "Limit to most impactful changes only"

### Issue: FAQs too technical/jargon-heavy

**Solution**: Add audience guidance: "Write for employees with no HR background" or "Use plain language, avoid legal jargon"

### Issue: Can't find change_id to use

**Solution**: Query database first:
```python
import sqlite3
conn = sqlite3.connect('databases/faq_update.db')
cursor = conn.cursor()
cursor.execute("SELECT change_id, file_name, page_number FROM content_change_log WHERE change_type = 'content_edit' ORDER BY detected_at DESC LIMIT 10")
print(cursor.fetchall())
```

---

## Related Documentation

- [DiffFormatter API Reference](src/formatters/diff_formatter.py)
- [Content Diff Processor](src/content_diff.py)
- [Workflow Implementation Guide](WORKFLOW_IMPLEMENTATION_COMPLETE.md)
