# Content Diff Integration - Implementation Guide

## Overview

This guide explains how to integrate content diff functionality into the existing FAQ content tracking system. The content diff system captures **what changed** between content versions, not just **that** it changed.

## What is Content Diff?

Currently, when content is edited, the system:
- ✅ Detects that content changed (different checksum)
- ✅ Invalidates affected FAQs
- ❌ **MISSING**: Doesn't capture WHAT changed

The diff system will add:
- **Unified Diff**: Line-by-line comparison (stored compressed)
- **Similarity Score**: How similar old vs new content (0.0 = completely different, 1.0 = identical)
- **Change Metrics**: Characters/lines added/removed
- **Semantic Analysis**: Which headers, paragraphs, lists changed

## Why This Matters

### Use Cases
1. **Human Review**: "Show me what changed in Employee Leave Policy page 3"
2. **Impact Assessment**: "Was this a typo fix or major rewrite?"
3. **FAQ Re-validation**: "Do the changes affect FAQ-relevant sections?"
4. **Audit Trail**: "Who changed what and when?"


## Architecture


**Key Design Decisions**:
1. **1:1 Relationship**: One diff per `content_edit` change
2. **Trigger Enforcement**: Only allows diffs for `content_edit` changes (not moves/deletions)
3. **Compressed Storage**: Diffs stored as gzipped BLOBs (saves space)
4. **Quick Metrics**: Pre-computed scores for fast filtering


## Testing the Implementation

### 1. Test Diff Generation
```python
# Create test content
old_content = """# Employee Leave Policy

Employees can take up to 10 days of leave per year.

## Approval Process
All requests must be approved by manager."""

new_content = """# Employee Leave Policy

Employees can take up to 15 days of leave per year.
All leave requests must be submitted 2 weeks in advance.

## Approval Process
All requests must be approved by manager."""

# Test diff generation
processor = ContentDiffProcessor(content_db, tracking_db)
diff_data = processor._generate_diff(
    old_content, new_content,
    'abc123...', 'def456...'
)

print(f"Similarity: {diff_data['similarity_score']:.2f}")
print(f"Chars added: {diff_data['chars_added']}")
print(f"Lines added: {diff_data['lines_added']}")
print(f"Is minor: {diff_data['is_minor_change']}")
```

### 2. Test Semantic Analysis
```python
processor = EnhancedContentDiffProcessor(content_db, tracking_db)
semantic = processor._generate_semantic_diff(old_content, new_content)

print(f"Total changes: {semantic['total_changes']}")
print(f"Headers changed: {semantic['stats']['headers_changed']}")
print("\nSummary:")
for change in semantic['summary']:
    print(f"  - {change}")
```

### 3. Test End-to-End
```python
# Run pipeline with diff processing
pipeline = ContentTrackingPipeline(content_db, tracking_db)
results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')

# Check diff results
print(results['impact_report']['diff_processing'])
```

## Documentation Updates

All documentation changes go in `comprehensive-implementation-readme.md`:

1. **Table of Contents** (line 10) - Add entry:
   ```markdown
   9. [Content Diff Storage & Analysis](#content-diff-storage-analysis)
   ```

2. **Database Schema** (line 269) - Add content_diffs table

3. **New Section** (line 346) - Add complete "Content Diff Storage & Analysis" section

4. **Migration SQL** (line 721) - Add content_diffs to migration script

5. **Performance Section** (line 3145) - Add diff indexes

6. **Troubleshooting** (line 3309) - Add diff debugging

7. **Testing Section** (line 2980) - Add diff test cases

## Migration Strategy

### Phase 1: Add Schema (Day 1)
```sql
-- Run migration to add content_diffs table
-- See: sql/migration_001_create_tracking_schema.sql
```

### Phase 2: Deploy Code (Day 2)
- Add ContentDiffProcessor classes to production_pipeline.py
- Add integration to process_daily_updates
- Deploy but keep diff processing **optional** initially

### Phase 3: Backfill Diffs (Day 3-7)
```python
# Process historical content_edits
processor = ContentDiffProcessor(content_db, tracking_db)

# Process in batches
while True:
    results = processor.process_pending_diffs(max_records=100)
    if results['diffs_generated'] == 0:
        break
    print(f"Processed batch: {results['diffs_generated']} diffs")
    time.sleep(1)  # Rate limit
```

### Phase 4: Enable Full Integration (Day 8+)
- Make diff processing mandatory in pipeline
- Monitor performance and storage

## Success Metrics

After implementation, you should be able to:

1. ✅ View diff for any content edit:
   ```sql
   SELECT
       ccl.file_name,
       ccl.page_number,
       cd.similarity_score,
       cd.chars_added,
       cd.chars_removed,
       json_extract(cd.semantic_summary, '$.total_changes') as changes
   FROM content_change_log ccl
   JOIN content_diffs cd ON ccl.change_id = cd.change_id
   WHERE ccl.change_type = 'content_edit'
   ORDER BY ccl.detected_at DESC
   LIMIT 10;
   ```

2. ✅ Find major rewrites vs minor edits:
   ```sql
   SELECT file_name, page_number, similarity_score
   FROM v_content_changes_with_diffs
   WHERE similarity_score < 0.5  -- Major changes
   ORDER BY similarity_score;
   ```

3. ✅ Monitor diff coverage:
   ```sql
   SELECT
       COUNT(*) as total_edits,
       COUNT(cd.change_id) as diffs_generated,
       COUNT(*) - COUNT(cd.change_id) as pending_diffs
   FROM content_change_log ccl
   LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
   WHERE ccl.change_type = 'content_edit';
   ```

## Next Steps

1. **Review this guide** - Make sure you understand the architecture
2. **Start with Step 1** - Add helper method to ContentTrackingPipeline
3. **Add Step 2** - Create ContentDiffProcessor classes
4. **Test locally** - Use the test cases above
5. **Update documentation** - Add to comprehensive-implementation-readme.md
6. **Run migration** - Add content_diffs table to database
7. **Deploy and monitor** - Watch for errors and performance

## Questions to Consider

Before implementing, think about:

1. **Storage**: Diffs can be large - is compression sufficient?
2. **Performance**: Should diff processing be asynchronous?
3. **Retention**: Do we keep diffs forever or expire old ones?
4. **Retrieval**: Do we need a UI to view diffs?
5. **Semantic Analysis**: Is the markdown parser sufficient?

## Summary

The content diff integration adds **visibility into content changes** without changing the core architecture. It's:
- **Non-invasive**: Separate table, optional processing
- **Backward compatible**: Works with existing change tracking
- **Incrementally deployable**: Can backfill historical data
- **Valuable**: Enables human review and impact assessment

The implementation requires:
- **~200 lines of Python code** (2 classes + integration)
- **~100 lines of SQL** (table + indexes + triggers)
- **~500 lines of documentation** (comprehensive-implementation-readme.md updates)

Total effort: **1-2 days** for complete implementation and testing.