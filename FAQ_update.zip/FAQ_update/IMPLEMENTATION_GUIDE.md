# Implementation Guide: Remaining Points from Line 2697 Onwards

This guide explains where to implement each remaining concept from the comprehensive implementation readme (lines 2697-3753).

## Overview

You have already created the core Python files:
- ✅ `src/migrate_faq_links.py` - FAQ migration logic
- ✅ `src/parallel_tracking.py` - Parallel tracking pipeline
- ✅ `src/production_pipeline.py` - Production pipeline

**What remains:** Supporting infrastructure, utilities, tests, and integration points.

---

## 1. Idempotency Guarantees (Lines 2697-2798)

### What It Is
Ensures that running the pipeline multiple times with the same data doesn't create duplicates.

### Already Implemented In
- ✅ `production_pipeline.py` - `_record_change_idempotent()` method (lines 52-100+)
- ✅ Database schema - `idx_ccl_idempotent` UNIQUE index in SQL files

### Still Needed
**File:** `src/utils/idempotency_helpers.py` (NEW)
```python
"""
Idempotency testing and validation utilities.
"""
from typing import Dict, List
import sqlite3

def test_idempotent_insert(pipeline, change_data: Dict) -> Dict:
    """
    Test that duplicate inserts are ignored.
    Returns: {'first_id': int, 'second_id': None, 'count': 1}
    """
    pass

def validate_no_duplicates(tracking_db: str) -> List[Dict]:
    """
    Scan database for any duplicate change records.
    Returns list of duplicate groups if found.
    """
    pass
```

**Where to use:** In test files and validation scripts.

---

## 2. Race Condition Prevention (Lines 2801-2928)

### What It Is
Ensures consistent change classification even with duplicate content or concurrent processing.

### Already Implemented In
- ✅ `parallel_tracking.py` - Has partial implementation in `_run_enhanced_change_detection()`
- ✅ `production_pipeline.py` - Uses ordered analysis

### Still Needed

**File:** `src/production_pipeline.py` - **ADD these methods:**

```python
def _build_document_states(self, current_state: pd.DataFrame,
                           content_df: pd.DataFrame) -> Tuple[Dict, Dict]:
    """
    Build complete document state dictionaries for race-free analysis (Fix 9).
    Returns (old_data, new_data) with by_page and by_checksum indexes.
    """
    # Implementation from lines 2833-2851 of comprehensive readme
    pass

def _find_checksum_matches(self, old_data: Dict, new_data: Dict) -> List[Dict]:
    """
    Find all checksum matches between old and new states (Fix 9).
    Uses greedy nearest-neighbor matching for duplicates.
    """
    # Implementation from lines 2856-2877 of comprehensive readme
    pass
```

**Action:** Copy the full implementations from lines 2241-2336 of comprehensive readme into `production_pipeline.py`.

---

## 3. Time Field Semantics (Lines 2930-3014)

### What It Is
Clear definitions and usage of `effective_date`, `detected_at`, and `processed_at`.

### Already Implemented In
- ✅ `parallel_tracking.py` - `TimeSemantics` class and `format_timestamp()` function
- ✅ Database schema - All timestamp fields use ISO-8601 format

### Still Needed

**File:** `src/production_pipeline.py` - **ADD imports at top:**
```python
from parallel_tracking import TimeSemantics, format_timestamp
```

**Action:** Import and use the `TimeSemantics` class from `parallel_tracking.py` in `production_pipeline.py`.

**File:** `docs/TIME_SEMANTICS_GUIDE.md` (NEW)
```markdown
# Time Field Usage Guide

## Field Definitions
- **effective_date**: When change occurred in source (from `last_modified_dt`)
- **detected_at**: When pipeline detected it (use `format_timestamp(datetime.now())`)
- **processed_at**: When record was written to DB

## Common Pitfalls
❌ WRONG: `effective_date = datetime.now()`
✅ CORRECT: `effective_date = source_row['last_modified_dt']`

❌ WRONG: `detected_at = source_row['last_modified_dt']`
✅ CORRECT: `detected_at = format_timestamp(datetime.now())`
```

---

## 4. Migration Strategy & Controller (Lines 3016-3082)

### What It Is
Orchestration logic for executing the full migration safely.

### Where to Implement

**File:** `src/migration_controller.py` (NEW)
```python
"""
Orchestrates the complete migration process with safety checks and rollback.
"""
import sqlite3
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict

from migrate_faq_links import FAQLinkMigration
from parallel_tracking import ParallelTrackingPipeline
from production_pipeline import ContentTrackingPipeline

class MigrationController:
    """
    Orchestrates the complete migration process.
    Implementation from lines 3030-3080 of comprehensive readme.
    """

    def __init__(self, content_db: str, old_tracking_db: str, new_tracking_db: str):
        self.content_db = content_db
        self.old_tracking_db = old_tracking_db
        self.new_tracking_db = new_tracking_db

    def execute_migration(self):
        """Execute complete migration with safety checks."""
        # Copy full implementation from lines 3036-3065
        pass

    def pre_migration_checks(self) -> bool:
        """Verify system is ready for migration."""
        # Copy from lines 3067-3075
        pass

    def backup_databases(self) -> str:
        """Create timestamped backup."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = Path(f'backups/migration_{timestamp}')
        backup_dir.mkdir(parents=True, exist_ok=True)

        # Copy databases
        shutil.copy2(self.old_tracking_db, backup_dir / 'old_tracking.db')
        shutil.copy2(self.content_db, backup_dir / 'content_repo.db')

        return str(backup_dir)

    def rollback_migration(self, backup_path: str):
        """Rollback to pre-migration state."""
        # Copy from lines 3077-3080
        pass
```

---

## 5. Testing & Validation (Lines 3085-3210)

### Where to Implement

**File:** `tests/test_change_detection.py` (NEW)
```python
"""
Unit tests for change detection logic.
Implementation from lines 3090-3143 of comprehensive readme.
"""
import unittest
import tempfile
import sqlite3
from datetime import datetime

from production_pipeline import ContentTrackingPipeline

class TestChangeDetection(unittest.TestCase):
    """Test change detection logic."""

    def setUp(self):
        """Create test databases."""
        # Copy from lines 3099-3103
        pass

    def test_content_edit_detection(self):
        """Test that content edits are properly detected."""
        # Copy from lines 3105-3132
        pass

    def test_position_change_detection(self):
        """Test that position changes are properly detected."""
        pass

    def test_page_insertion_detection(self):
        """Test that page insertions with cascading moves are detected."""
        pass
```

**File:** `tests/test_faq_validity.py` (NEW)
```python
"""
Integration tests for FAQ validity management.
Implementation from lines 3148-3165 of comprehensive readme.
"""
import unittest
from production_pipeline import ContentTrackingPipeline

class TestFAQValidity(unittest.TestCase):
    """Test FAQ validity management."""

    def test_faq_remains_valid_on_move(self):
        """Test that FAQs remain valid when content moves."""
        pass

    def test_faq_invalidated_on_edit(self):
        """Test that FAQs are invalidated when content changes."""
        pass
```

**File:** `sql/validation_queries.sql` (NEW or ADD TO EXISTING)
```sql
-- Validation queries from lines 3167-3210

-- Verify no orphaned FAQs
SELECT COUNT(*) as orphaned_count
FROM faq_content_map fcm
LEFT JOIN content_change_log ccl
    ON fcm.content_checksum = ccl.content_checksum
WHERE ccl.change_id IS NULL;

-- Check for duplicate checksums with different content_ids
SELECT content_checksum, COUNT(DISTINCT content_id) as id_count
FROM content_change_log
GROUP BY content_checksum
HAVING id_count > 1;

-- Verify all page moves have matching FAQ updates
WITH latest_moves AS (
    SELECT
        content_checksum,
        content_id,
        page_number,
        previous_page_number,
        detected_at,
        ROW_NUMBER() OVER (
            PARTITION BY content_checksum
            ORDER BY detected_at DESC, change_id DESC
        ) as rn
    FROM content_change_log
    WHERE change_type = 'position_change'
)
SELECT
    lm.content_id,
    lm.page_number as current_page,
    lm.previous_page_number as previous_page,
    COUNT(fcm.map_id) as faq_count
FROM latest_moves lm
LEFT JOIN faq_content_map fcm
    ON lm.content_checksum = fcm.content_checksum
WHERE lm.rn = 1
  AND fcm.current_page_number != lm.page_number
GROUP BY lm.content_id;
```

---

## 6. Rollback Procedures (Lines 3213-3258)

### Where to Implement

**File:** `scripts/rollback_migration.py` (NEW)
```python
"""
Rollback scripts for migration failures.
Implementation from lines 3218-3257 of comprehensive readme.
"""
import sqlite3
from datetime import datetime
from typing import Optional

def immediate_rollback(tracking_db: str, backup_path: str):
    """
    Immediate rollback (< 1 hour) - restore from backup.
    Implementation from lines 3218-3230.
    """
    # Drop new schema and restore from backup
    with sqlite3.connect(tracking_db) as conn:
        conn.execute("DROP VIEW IF EXISTS v_document_structure_changes")
        conn.execute("DROP TABLE IF EXISTS faq_content_map")
        conn.execute("DROP TABLE IF EXISTS content_change_log")
        conn.commit()

    # Restore from backup
    import shutil
    shutil.copy2(backup_path, tracking_db)

def gradual_rollback(tracking_db: str, cutoff_time: str):
    """
    Gradual rollback (1-24 hours) - rollback changes after cutoff.
    Implementation from lines 3235-3257.
    """
    with sqlite3.connect(tracking_db) as conn:
        # Mark post-cutoff FAQs as invalid
        conn.execute("""
            UPDATE faq_content_map
            SET is_valid = 0,
                invalidation_reason = 'rollback'
            WHERE created_at > ?
        """, [cutoff_time])

        # Remove post-cutoff change records
        conn.execute("""
            DELETE FROM content_change_log
            WHERE detected_at > ?
        """, [cutoff_time])

        conn.commit()
```

---

## 7. Performance Monitoring (Lines 3261-3340)

### Where to Implement

**File:** `scripts/performance_monitoring.py` (NEW)
```python
"""
Performance monitoring and optimization utilities.
Implementation from lines 3264-3339 of comprehensive readme.
"""
import sqlite3
import pandas as pd
from typing import Dict, List

def monitor_table_sizes(tracking_db: str) -> pd.DataFrame:
    """
    Monitor table sizes.
    Implementation from lines 3318-3326.
    """
    with sqlite3.connect(tracking_db) as conn:
        query = """
        SELECT 'content_change_log' as table_name, COUNT(*) as row_count
        FROM content_change_log
        UNION ALL
        SELECT 'faq_content_map', COUNT(*)
        FROM faq_content_map
        UNION ALL
        SELECT 'v_document_structure_changes (VIEW)', COUNT(*)
        FROM v_document_structure_changes
        """
        return pd.read_sql(query, conn)

def analyze_query_performance(tracking_db: str, queries: List[str]) -> Dict:
    """
    Analyze query performance with EXPLAIN QUERY PLAN.
    Implementation from lines 3328-3339.
    """
    results = {}
    with sqlite3.connect(tracking_db) as conn:
        for query in queries:
            plan = conn.execute(f"EXPLAIN QUERY PLAN {query}").fetchall()
            results[query] = plan
    return results
```

**File:** `sql/performance_indexes.sql` (NEW or ADD TO EXISTING)
```sql
-- Enhanced index strategy from lines 3275-3306

-- For FAQ lookups by page (most common query)
CREATE INDEX IF NOT EXISTS idx_fcm_lookup ON faq_content_map(
    current_file_name,
    current_page_number,
    is_valid,
    content_checksum
) WHERE is_valid = 1;

-- For latest changes queries (timeline analysis)
CREATE INDEX IF NOT EXISTS idx_ccl_latest ON content_change_log(
    file_name,
    detected_at DESC,
    page_number
);

-- For idempotent writes (prevents duplicates)
CREATE UNIQUE INDEX IF NOT EXISTS idx_ccl_idempotent ON content_change_log(
    file_name,
    page_number,
    content_checksum,
    change_type,
    effective_date
);

-- Additional supporting indexes
CREATE INDEX IF NOT EXISTS idx_checksum_page ON content_change_log(content_checksum, page_number);
CREATE INDEX IF NOT EXISTS idx_fcm_checksum_valid ON faq_content_map(content_checksum, is_valid);
CREATE INDEX IF NOT EXISTS idx_change_dates ON content_change_log(effective_date, detected_at);
```

---

## 8. Troubleshooting Utilities (Lines 3342-3477)

### Where to Implement

**File:** `src/utils/troubleshooting.py` (NEW)
```python
"""
Troubleshooting and debugging utilities.
Implementation from lines 3348-3464 of comprehensive readme.
"""
import sqlite3
import hashlib
from typing import Optional, Dict

def debug_checksum(file_path: str):
    """
    Debug checksum calculation issues.
    Implementation from lines 3350-3367.
    """
    try:
        with open(file_path, 'rb') as f:
            content = f.read()

        checksum = hashlib.sha256(content).hexdigest()

        print(f"File: {file_path}")
        print(f"Size: {len(content)} bytes")
        print(f"Checksum: {checksum}")
        print(f"First 100 bytes: {content[:100]}")

    except Exception as e:
        print(f"Error: {e}")

def debug_content_id_validation(content_id: int, content_db: str):
    """
    Debug content_id validation failures.
    Implementation from lines 3416-3442.
    """
    print(f"\n=== Debugging content_id: {content_id} ===")

    with sqlite3.connect(content_db) as conn:
        result = conn.execute(
            "SELECT * FROM content_repo WHERE ud_source_file_id = ?",
            (content_id,)
        ).fetchone()

        if result:
            print(f"✓ Found in content_repo: {result}")
        else:
            print(f"✗ NOT found in content_repo")

            # Search for similar IDs
            similar = conn.execute("""
                SELECT ud_source_file_id, raw_file_nme, raw_file_page_nbr
                FROM content_repo
                WHERE ud_source_file_id BETWEEN ? AND ?
                LIMIT 5
            """, (content_id - 10, content_id + 10)).fetchall()

            print(f"\nSimilar content_ids:")
            for row in similar:
                print(f"  {row}")

def analyze_performance(tracking_db: str):
    """
    Identify performance bottlenecks.
    Implementation from lines 3392-3411.
    """
    with sqlite3.connect(tracking_db) as conn:
        conn.execute("PRAGMA query_only = ON")

        queries = [
            "SELECT * FROM faq_content_map WHERE content_checksum = 'test'",
            "SELECT * FROM content_change_log WHERE file_name = 'test.pdf'",
        ]

        for query in queries:
            plan = conn.execute(f"EXPLAIN QUERY PLAN {query}").fetchall()
            print(f"\nQuery: {query}")
            print("Plan:")
            for row in plan:
                print(f"  {row}")

def find_missing_faqs(old_db: str, new_db: str):
    """
    Find FAQs that didn't migrate.
    Implementation from SQL in lines 3371-3388.
    """
    # Use ATTACH DATABASE to query both
    with sqlite3.connect(new_db) as conn:
        conn.execute(f"ATTACH DATABASE '{old_db}' AS old_system")

        query = """
        WITH old_faqs AS (
            SELECT question_id, content_id
            FROM old_system.faq_content_link
            WHERE is_currently_valid = 1
        ),
        new_faqs AS (
            SELECT question_id, original_content_id
            FROM faq_content_map
            WHERE is_valid = 1
        )
        SELECT o.*
        FROM old_faqs o
        LEFT JOIN new_faqs n
            ON o.question_id = n.question_id
            AND o.content_id = n.original_content_id
        WHERE n.question_id IS NULL
        """

        import pandas as pd
        return pd.read_sql(query, conn)
```

---

## 9. Success Criteria & Monitoring (Lines 3481-3490)

### Where to Implement

**File:** `scripts/validate_migration_success.py` (NEW)
```python
"""
Validate migration success against defined criteria.
Implementation from lines 3482-3490.
"""
import sqlite3
import pandas as pd
from typing import Dict, List
import time

def validate_migration_success(content_db: str, old_db: str, new_db: str) -> Dict:
    """
    Check all success criteria.
    Returns dict with pass/fail status for each criterion.
    """
    results = {}

    # 1. All FAQs are accessible
    results['faqs_accessible'] = check_faqs_accessible(old_db, new_db)

    # 2. Correct validity states
    results['validity_states'] = check_validity_states(new_db)

    # 3. Page tracking accurate
    results['page_tracking'] = check_page_tracking(content_db, new_db)

    # 4. Performance maintained
    results['performance'] = check_performance(new_db)

    # 5. Audit trail complete
    results['audit_trail'] = check_audit_trail(new_db)

    return results

def check_faqs_accessible(old_db: str, new_db: str) -> Dict:
    """Criterion 1: All FAQs are accessible."""
    with sqlite3.connect(new_db) as conn:
        conn.execute(f"ATTACH DATABASE '{old_db}' AS old_system")

        old_count = pd.read_sql(
            "SELECT COUNT(*) as cnt FROM old_system.faq_content_link WHERE is_currently_valid = 1",
            conn
        ).iloc[0]['cnt']

        new_count = pd.read_sql(
            "SELECT COUNT(*) as cnt FROM faq_content_map WHERE is_valid = 1",
            conn
        ).iloc[0]['cnt']

        return {
            'passed': old_count == new_count,
            'old_count': old_count,
            'new_count': new_count,
            'missing': old_count - new_count
        }

def check_validity_states(new_db: str) -> Dict:
    """Criterion 2: FAQs invalidated only for content changes."""
    with sqlite3.connect(new_db) as conn:
        # Check that invalidated FAQs have proper reasons
        invalid_without_reason = pd.read_sql("""
            SELECT COUNT(*) as cnt
            FROM faq_content_map
            WHERE is_valid = 0 AND invalidation_reason IS NULL
        """, conn).iloc[0]['cnt']

        return {
            'passed': invalid_without_reason == 0,
            'invalid_without_reason': invalid_without_reason
        }

def check_page_tracking(content_db: str, new_db: str) -> Dict:
    """Criterion 3: Current locations match content_repo."""
    # Compare faq_content_map.current_page_number with content_repo
    with sqlite3.connect(new_db) as new_conn:
        new_conn.execute(f"ATTACH DATABASE '{content_db}' AS content_db")

        mismatches = pd.read_sql("""
            SELECT COUNT(*) as cnt
            FROM faq_content_map fcm
            JOIN content_db.content_repo cr
                ON fcm.current_content_id = cr.ud_source_file_id
            WHERE fcm.current_page_number != cr.raw_file_page_nbr
              AND fcm.is_valid = 1
        """, new_conn).iloc[0]['cnt']

        return {
            'passed': mismatches == 0,
            'mismatches': mismatches
        }

def check_performance(new_db: str) -> Dict:
    """Criterion 4: Query times <= previous system."""
    test_queries = [
        "SELECT * FROM faq_content_map WHERE current_file_name = 'test.pdf' AND current_page_number = 5 AND is_valid = 1",
        "SELECT * FROM content_change_log WHERE content_checksum = 'abc123' LIMIT 10"
    ]

    timings = {}
    with sqlite3.connect(new_db) as conn:
        for query in test_queries:
            start = time.time()
            conn.execute(query).fetchall()
            elapsed = time.time() - start
            timings[query[:50]] = elapsed

    return {
        'passed': all(t < 0.1 for t in timings.values()),  # All queries < 100ms
        'timings': timings
    }

def check_audit_trail(new_db: str) -> Dict:
    """Criterion 5: All changes have proper context."""
    with sqlite3.connect(new_db) as conn:
        # Check for changes without proper metadata
        incomplete_changes = pd.read_sql("""
            SELECT COUNT(*) as cnt
            FROM content_change_log
            WHERE change_type IS NULL
               OR content_checksum IS NULL
               OR effective_date IS NULL
        """, conn).iloc[0]['cnt']

        return {
            'passed': incomplete_changes == 0,
            'incomplete_changes': incomplete_changes
        }
```

---

## 10. Complete Schema DDL (Lines 3493-3739)

### Where to Implement

**File:** `sql/create_new_schema_complete.sql` (NEW or UPDATE EXISTING)

This is the final, complete schema with all corrections. Copy the entire SQL from lines 3495-3739 of the comprehensive readme.

**Key sections to include:**
- Prerequisites and JSON1 check
- `content_change_log` table with all indexes
- `faq_content_map` table with all indexes
- `v_document_structure_changes` VIEW
- Utility views (`v_current_valid_faqs`, `v_faq_validity_timeline`)

**Action:** Copy lines 3495-3739 into `sql/create_new_schema_complete.sql`.

---

## 11. Main Entry Points & CLI

### Where to Implement

**File:** `src/main.py` (NEW)
```python
"""
Main entry point for running the FAQ tracking system.
"""
import argparse
from pathlib import Path
from migration_controller import MigrationController
from production_pipeline import ContentTrackingPipeline

def main():
    parser = argparse.ArgumentParser(description='FAQ Content Tracking System')
    parser.add_argument('command', choices=['migrate', 'track', 'validate'])
    parser.add_argument('--content-db', required=True, help='Path to content_repo.db')
    parser.add_argument('--tracking-db', required=True, help='Path to tracking database')
    parser.add_argument('--old-db', help='Path to old tracking database (for migration)')
    parser.add_argument('--since', help='Process changes since date (ISO-8601)')

    args = parser.parse_args()

    if args.command == 'migrate':
        if not args.old_db:
            parser.error('--old-db required for migration')

        controller = MigrationController(
            content_db=args.content_db,
            old_tracking_db=args.old_db,
            new_tracking_db=args.tracking_db
        )
        controller.execute_migration()

    elif args.command == 'track':
        pipeline = ContentTrackingPipeline(
            content_db=args.content_db,
            tracking_db=args.tracking_db
        )

        since_date = args.since or '2025-01-01T00:00:00Z'
        results = pipeline.process_daily_updates(since_date)

        print(f"Processing complete:")
        print(f"  Changes detected: {results['impact_report']['summary']['total_changes']}")
        print(f"  FAQs impacted: {results['impact_report']['summary']['faqs_impacted']}")

    elif args.command == 'validate':
        from scripts.validate_migration_success import validate_migration_success

        results = validate_migration_success(
            args.content_db,
            args.old_db,
            args.tracking_db
        )

        print("Validation Results:")
        for criterion, result in results.items():
            status = "✓ PASS" if result['passed'] else "✗ FAIL"
            print(f"  {criterion}: {status}")

if __name__ == '__main__':
    main()
```

---

## Summary: File Structure

Here's where everything should go:

```
FAQ_update/
├── src/
│   ├── migrate_faq_links.py          ✅ EXISTS
│   ├── parallel_tracking.py          ✅ EXISTS
│   ├── production_pipeline.py        ✅ EXISTS (needs additions)
│   ├── migration_controller.py       ❌ CREATE NEW
│   ├── main.py                       ❌ CREATE NEW
│   └── utils/
│       ├── idempotency_helpers.py    ❌ CREATE NEW
│       └── troubleshooting.py        ❌ CREATE NEW
├── scripts/
│   ├── rollback_migration.py         ❌ CREATE NEW
│   ├── performance_monitoring.py     ❌ CREATE NEW
│   └── validate_migration_success.py ❌ CREATE NEW
├── tests/
│   ├── test_change_detection.py      ❌ CREATE NEW
│   └── test_faq_validity.py          ❌ CREATE NEW
├── sql/
│   ├── create_new_schema_complete.sql ❌ CREATE/UPDATE
│   ├── validation_queries.sql         ❌ CREATE/UPDATE
│   └── performance_indexes.sql        ❌ CREATE NEW
└── docs/
    └── TIME_SEMANTICS_GUIDE.md        ❌ CREATE NEW
```

---

## Priority Implementation Order

1. **CRITICAL (Do First):**
   - Add missing methods to `production_pipeline.py` (race condition fixes)
   - Create `sql/create_new_schema_complete.sql` (complete schema)
   - Create `src/migration_controller.py` (orchestration)

2. **HIGH (Do Next):**
   - Create `scripts/validate_migration_success.py` (validation)
   - Create `src/main.py` (CLI entry point)
   - Create `sql/validation_queries.sql` (testing)

3. **MEDIUM (Before Production):**
   - Create test files (`tests/test_*.py`)
   - Create `scripts/rollback_migration.py` (safety)
   - Create `src/utils/troubleshooting.py` (debugging)

4. **LOW (Nice to Have):**
   - Create `scripts/performance_monitoring.py`
   - Create `docs/TIME_SEMANTICS_GUIDE.md`
   - Create `src/utils/idempotency_helpers.py`

---

## Next Steps

1. Review this guide carefully
2. Ask questions about any unclear sections
3. Start with Priority 1 (CRITICAL) items
4. Test each component as you build it
5. Use the comprehensive readme as reference for full implementations

Each section above includes:
- ✅ What's already done
- ❌ What needs to be created
- 📄 Exact file paths
- 🔗 Line number references to comprehensive readme
- 💡 Implementation guidance