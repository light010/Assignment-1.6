# Content Change Log - CORRECTED Analysis After Deep Understanding

**Date**: 2025-10-20
**Status**: CORRECTED - Based on actual data model understanding
**Previous Analysis**: PARTIALLY WRONG - Did not understand content_repo versioning model

---

## 🔴 **CRITICAL CORRECTIONS TO PREVIOUS ANALYSIS**

### **My Mistake #1: Misunderstood content_repo Role**

**I Proposed**: Create separate `content_baseline` table

**Reality**: `content_repo` **ALREADY IS THE BASELINE**
- It stores ALL versions of ALL pages (historical + current)
- Each row = one page at one point in time
- `version_nbr` tracks version evolution
- **No separate baseline table needed!**

---

### **My Mistake #2: Misunderstood How "Previous Checksum" Works**

**I Said**: Track `previous_checksum → current_checksum` transitions

**Reality**: The system **INSERTS NEW ROWS**, not updates
- Page 2 v1: Row with id=1002, checksum=ABC, version=1
- Page 2 v2: NEW row with id=1004, checksum=DEF, version=2
- Previous checksum = Query: `WHERE page=2 AND version=1`
- Current checksum = Query: `WHERE page=2 AND version=2`
- **Transition is implicit in the data structure!**

---

## 🎯 **ACTUAL DATA MODEL** (Now I Understand)

### **How Content Actually Works**

```
Physical Reality:
  Employee_Leave_Policy.pdf (single PDF file)
    ↓ Extraction Process
  Page 1 → markdown → checksum_A
  Page 2 → markdown → checksum_B
  Page 3 → markdown → checksum_C

content_repo Storage (Version 1):
  ┌────────┬─────────────┬──────┬─────────┬─────────────┐
  │ id     │ file        │ page │ version │ checksum    │
  ├────────┼─────────────┼──────┼─────────┼─────────────┤
  │ 1001   │ policy.pdf  │ 1    │ 1       │ checksum_A  │
  │ 1002   │ policy.pdf  │ 2    │ 1       │ checksum_B  │
  │ 1003   │ policy.pdf  │ 3    │ 1       │ checksum_C  │
  └────────┴─────────────┴──────┴─────────┴─────────────┘

File Updated (only page 2 content changed):
  Page 1 → markdown → checksum_A (SAME)
  Page 2 → markdown → checksum_D (CHANGED!)
  Page 3 → markdown → checksum_C (SAME)

content_repo Storage (After Update):
  ┌────────┬─────────────┬──────┬─────────┬─────────────┬────────┐
  │ id     │ file        │ page │ version │ checksum    │ status │
  ├────────┼─────────────┼──────┼─────────┼─────────────┼────────┤
  │ 1001   │ policy.pdf  │ 1    │ 1       │ checksum_A  │ Active │ ← Unchanged
  │ 1002   │ policy.pdf  │ 2    │ 1       │ checksum_B  │ Active │ ← OLD version
  │ 1003   │ policy.pdf  │ 3    │ 1       │ checksum_C  │ Active │ ← Unchanged
  │ 1004   │ policy.pdf  │ 2    │ 2       │ checksum_D  │ Active │ ← NEW version
  └────────┴─────────────┴──────┴─────────┴─────────────┴────────┘
```

**Key Insight**:
- **content_repo = Slowly Changing Dimension Type 2** (SCD2)
- History is preserved by inserting new rows
- Old rows remain (they might still be referenced by FAQs!)
- No UPDATE of checksums, only INSERT

---

## 🔍 **RE-ANALYSIS: What content_change_log SHOULD Do**

### **Given This Reality, What's Missing?**

#### **Current content_change_log Design**:
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,
    content_id INTEGER NOT NULL,        -- Which content_repo row?
    content_checksum TEXT NOT NULL,     -- What checksum was detected?
    requires_faq_regeneration BOOLEAN,  -- Should we regenerate FAQ?
    detected_at TEXT,
    detection_run_id TEXT,
    ...
);
```

#### **Problem 1: No Link Between Old and New Versions**

**Scenario**:
```
Detection Run on Day 2:
  - Detects id=1004 (page 2 v2, checksum_D)
  - Inserts into content_change_log:
      content_id: 1004
      content_checksum: checksum_D
      requires_faq_regeneration: 1

Question: What changed?
  - We know checksum_D is new
  - But we DON'T know it replaced checksum_B (id=1002)
  - Cannot compute diff (no previous content to compare)
  - Cannot determine change magnitude
```

**What's Missing**: Link to previous version
```sql
-- Need to add:
previous_content_id INTEGER,  -- Links to id=1002 (old version)

-- Then can compute:
SELECT
    new.content_checksum as current,
    old.content_checksum as previous,
    diff(old.markdown, new.markdown) as changes
FROM content_change_log ccl
JOIN content_repo new ON ccl.content_id = new.ud_source_file_id
JOIN content_repo old ON ccl.previous_content_id = old.ud_source_file_id
```

---

#### **Problem 2: How to Determine "Previous" Version?**

**Challenge**: Multiple dimensions of "previous"

**Dimension 1: Previous by VERSION**
```sql
-- Page 2, version sequence
SELECT * FROM content_repo
WHERE raw_file_nme = 'policy.pdf'
  AND raw_file_page_nbr = 2
ORDER BY version_nbr;

-- Result:
-- id=1002, version=1, checksum=B
-- id=1004, version=2, checksum=D

-- Previous of id=1004 = id=1002 (version-1)
```

**Dimension 2: Previous by TIME**
```sql
-- Page 2, chronological
SELECT * FROM content_repo
WHERE raw_file_nme = 'policy.pdf'
  AND raw_file_page_nbr = 2
ORDER BY created_dt;

-- Might differ if pages inserted out of order!
```

**Dimension 3: Previous by DETECTION**
```sql
-- What was the last detected state?
SELECT content_id FROM content_change_log
WHERE file_name = 'policy.pdf'
  AND json_extract(metadata, '$.page') = 2
ORDER BY detected_at DESC
LIMIT 1 OFFSET 1;  -- 2nd most recent = previous detection
```

**Question**: Which "previous" do we mean?

**Answer**: Depends on use case:
- **For diff computation**: Previous by VERSION (most accurate)
- **For baseline comparison**: Previous by DETECTION (what we last checked)
- **For timeline**: Previous by TIME (chronological)

---

#### **Problem 3: Change Detection Logic Gap**

**Current Detection Algorithm** (implied):
```python
def detect_changes(detection_run_id):
    # Get all current content
    current_content = load_all_from_content_repo()

    # Get baseline (but HOW?)
    baseline = ???  # WHERE DOES THIS COME FROM?

    # Compare
    for page in current_content:
        if page.checksum not in baseline:
            # New or changed
            content_change_log.insert({
                'content_id': page.id,
                'content_checksum': page.checksum,
                'requires_faq_regeneration': 1
            })
        else:
            # Unchanged
            content_change_log.insert({
                'content_id': page.id,
                'content_checksum': page.checksum,
                'requires_faq_regeneration': 0  # WHY LOG THIS?
            })
```

**Two Approaches**:

**Approach A: Baseline = Last Detection Run**
```python
# Baseline is "what we last detected"
baseline_checksums = set(
    row['content_checksum']
    for row in db.query('''
        SELECT DISTINCT content_checksum
        FROM content_change_log
        WHERE detection_run_id = ?
    ''', last_run_id)
)

# Problem: Must track which run_id was last
# Problem: First run has no baseline (all are "new")
```

**Approach B: Baseline = All Historical Checksums**
```python
# Baseline is "everything we've ever seen"
baseline_checksums = set(
    row['content_checksum']
    for row in db.query('''
        SELECT DISTINCT content_checksum
        FROM content_change_log
    ''')
)

# Better: No need to track runs
# Problem: Old deleted content checksums remain in baseline forever
```

**Approach C: Baseline = content_repo (Current Active)**
```python
# Baseline is "current active content"
baseline_checksums = set(
    row['content_checksum']
    for row in db.query('''
        SELECT content_checksum
        FROM content_repo
        WHERE file_status = 'Active'
    ''')
)

# Problem: Circular dependency
# - content_repo has NEW content
# - We're detecting if it's new vs baseline
# - But baseline IS content_repo!
# - MAKES NO SENSE
```

**Approach D: Baseline = content_repo (Previous Version)** ❌ **WRONG!**
```python
# Baseline is "previous versions in content_repo"
# For each current page, find its previous version

for current_page in current_content:
    previous = db.query('''
        SELECT * FROM content_repo
        WHERE raw_file_nme = ?
          AND raw_file_page_nbr = ?
          AND version_nbr = ? - 1
    ''', current_page.file, current_page.page, current_page.version)

    if previous and previous.checksum != current_page.checksum:
        # CHANGED
        content_change_log.insert({
            'content_id': current_page.id,
            'previous_content_id': previous.id,  # NEW FIELD
            'content_checksum': current_page.checksum,
            'requires_faq_regeneration': 1
        })
```

**🚨 CRITICAL FLAW**: This breaks on page insertion/deletion!

**Problem Scenario - Page Insertion**:
```
Day 1:
  Page 1: id=1001, version=1, checksum=AAA
  Page 2: id=1002, version=1, checksum=BBB
  Page 3: id=1003, version=1, checksum=CCC

Day 2 (NEW page inserted as page 2):
  Page 1: id=1001, version=1, checksum=AAA (unchanged)
  Page 2: id=1004, version=2, checksum=XXX (NEW content)
  Page 3: id=1005, version=2, checksum=BBB (SAME content, shifted)
  Page 4: id=1006, version=2, checksum=CCC (SAME content, shifted)

Wrong Logic:
  current = id=1005, page=3, version=2, checksum=BBB
  previous = query(page=3, version=1) → id=1003, checksum=CCC

  Compare: BBB != CCC → MARKS AS CHANGED! ❌

  Reality: BBB content is identical, just moved from page 2→3
  Should NOT regenerate FAQ!
```

**Problem Scenario - Page Deletion**:
```
Day 1:
  Page 1: id=1001, checksum=AAA
  Page 2: id=1002, checksum=BBB
  Page 3: id=1003, checksum=CCC

Day 2 (Page 2 deleted):
  Page 1: id=1001, checksum=AAA (unchanged)
  Page 2: id=1004, checksum=CCC (shifted from page 3)

Wrong Logic:
  current = id=1004, page=2, checksum=CCC
  previous = query(page=2, version=1) → id=1002, checksum=BBB

  Compare: CCC != BBB → MARKS AS CHANGED! ❌

  Reality: CCC content is identical to old page 3
  Should detect as PAGE MOVE, not content change!
```

**Fundamental Error**: Comparing by PAGE NUMBER assumes pages are stable identifiers.
- But page numbers change when pages inserted/deleted
- Same content appears at different page numbers
- System incorrectly flags as "modified"

---

**Approach E: CHECKSUM-CENTRIC Comparison** ✅ **CORRECT**
```python
# CORRECT: Compare by CHECKSUM (content identity), not page number

def detect_changes(file_name, previous_version, current_version):
    """
    Detect actual content changes by comparing checksums across versions.

    Key Insight: CHECKSUM is content identity, not page number!
    """

    # Get all checksums from previous version
    prev_checksums = db.query('''
        SELECT ud_source_file_id, content_checksum, raw_file_page_nbr
        FROM content_repo
        WHERE raw_file_nme = ?
          AND version_nbr = ?
    ''', file_name, previous_version)

    prev_checksum_map = {
        row.content_checksum: row
        for row in prev_checksums
    }

    # Get all checksums from current version
    curr_checksums = db.query('''
        SELECT ud_source_file_id, content_checksum, raw_file_page_nbr
        FROM content_repo
        WHERE raw_file_nme = ?
          AND version_nbr = ?
    ''', file_name, current_version)

    curr_checksum_map = {
        row.content_checksum: row
        for row in curr_checksums
    }

    changes = []

    # Analyze each current checksum
    for curr_checksum, curr_row in curr_checksum_map.items():
        if curr_checksum not in prev_checksum_map:
            # NEW CONTENT
            changes.append({
                'change_type': 'new_content',
                'previous_content_id': None,
                'current_content_id': curr_row.ud_source_file_id,
                'previous_checksum': None,
                'current_checksum': curr_checksum,
                'requires_faq_regeneration': 1,
                'change_reason': 'checksum_not_in_baseline'
            })
        else:
            prev_row = prev_checksum_map[curr_checksum]

            if prev_row.raw_file_page_nbr != curr_row.raw_file_page_nbr:
                # SAME CONTENT, DIFFERENT PAGE (MOVED)
                changes.append({
                    'change_type': 'page_renumbered',
                    'previous_content_id': prev_row.ud_source_file_id,
                    'current_content_id': curr_row.ud_source_file_id,
                    'previous_checksum': curr_checksum,
                    'current_checksum': curr_checksum,
                    'requires_faq_regeneration': 0,  # Content unchanged!
                    'change_reason': f'page_moved_{prev_row.raw_file_page_nbr}_to_{curr_row.raw_file_page_nbr}'
                })
            else:
                # SAME CONTENT, SAME PAGE (UNCHANGED)
                # DO NOT LOG (no change)
                pass

    # Detect DELETED content
    for prev_checksum, prev_row in prev_checksum_map.items():
        if prev_checksum not in curr_checksum_map:
            # CONTENT DELETED
            changes.append({
                'change_type': 'content_deleted',
                'previous_content_id': prev_row.ud_source_file_id,
                'current_content_id': None,
                'previous_checksum': prev_checksum,
                'current_checksum': None,
                'requires_faq_regeneration': 1,  # Invalidate FAQs for deleted content
                'change_reason': 'checksum_removed_from_current_version'
            })

    return changes
```

**Why This Works**:
- ✅ Compares CHECKSUMS (content identity), not page numbers
- ✅ Detects NEW content (checksum appears for first time)
- ✅ Detects DELETED content (checksum disappears)
- ✅ Detects PAGE MOVES (same checksum, different page number)
- ✅ Ignores unchanged content (same checksum, same page)

**Example - Page Insertion**:
```
Previous version checksums: {AAA, BBB, CCC}
Current version checksums: {AAA, XXX, BBB, CCC}

Analysis:
  AAA: in both → unchanged (no log)
  XXX: only in current → NEW CONTENT (log)
  BBB: in both, page 2→3 → PAGE MOVE (log as requires_faq_regeneration=0)
  CCC: in both, page 3→4 → PAGE MOVE (log as requires_faq_regeneration=0)

Result: Only 1 real change (XXX), not 3!
```

**Correct Answer**: **Approach E** (checksum-centric comparison)

---

## 🏗️ **CORRECTED PROPOSAL**

### **Principle**: Use What Already Exists

**Don't Create**:
- ❌ `content_baseline` table (content_repo already is the baseline)
- ❌ `previous_checksum` field (can query from content_repo)

**Do Create**:
- ✅ `previous_content_id` field (links to previous version row)
- ✅ `change_type` classification
- ✅ `content_diffs` table (for storing actual diffs)
- ✅ Processing state fields

---

### **Schema: content_change_log (CORRECTED)**

```sql
-- ============================================================================
-- Table: content_change_log (CORRECTED DESIGN)
-- ============================================================================
-- Purpose: Log of DETECTED CHANGES (not all detections)
-- Stores: Only pages where checksum differs from previous version
-- ============================================================================

CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- VERSION TRANSITION (previous → current)
    -- ========================================================================
    previous_content_id INTEGER,
        -- FK to content_repo row representing PREVIOUS version
        -- NULL for new content (no previous version exists)
        -- Example: id=1002 (page 2 v1)

    current_content_id INTEGER NOT NULL,
        -- FK to content_repo row representing CURRENT version
        -- Example: id=1004 (page 2 v2)

    -- Denormalized for query convenience (can be derived from content_repo)
    file_name TEXT NOT NULL,
    page_number INTEGER,  -- NULL for non-paginated content
    version_number INTEGER NOT NULL,

    -- ========================================================================
    -- CHECKSUMS (Denormalized from content_repo for quick access)
    -- ========================================================================
    previous_checksum TEXT CHECK(
        length(previous_checksum) = 64 OR previous_checksum IS NULL
    ),
        -- Checksum of previous version
        -- NULL for new content

    current_checksum TEXT NOT NULL CHECK(length(current_checksum) = 64),
        -- Checksum of current version

    -- ========================================================================
    -- CHANGE CLASSIFICATION
    -- ========================================================================
    change_type TEXT NOT NULL CHECK(change_type IN (
        'new_content',       -- No previous version exists
        'content_modified',  -- Checksum changed
        'content_deleted',   -- Marked as Inactive in content_repo
        'content_restored',  -- Reverted to older version checksum
        'page_renumbered',   -- Same checksum, different page number
        'metadata_only'      -- Content same, but title/tags changed
    )),

    change_trigger TEXT CHECK(change_trigger IN (
        'scheduled_scan',
        'manual_import',
        'file_upload',
        'api_update'
    )),

    -- ========================================================================
    -- CHANGE MAGNITUDE (NULL for new_content)
    -- ========================================================================
    similarity_score REAL CHECK(
        similarity_score IS NULL OR similarity_score BETWEEN 0 AND 1
    ),
        -- Cosine/Jaccard similarity: 1.0 = identical, 0.0 = completely different
        -- NULL if no previous version to compare

    edit_distance INTEGER,
        -- Levenshtein distance (character-level)

    lines_added INTEGER DEFAULT 0,
    lines_deleted INTEGER DEFAULT 0,
    lines_modified INTEGER DEFAULT 0,

    change_magnitude TEXT AS (
        CASE
            WHEN previous_checksum IS NULL THEN 'new'
            WHEN similarity_score >= 0.95 THEN 'minor'
            WHEN similarity_score >= 0.70 THEN 'moderate'
            WHEN similarity_score >= 0.40 THEN 'major'
            ELSE 'complete_rewrite'
        END
    ) STORED,

    -- ========================================================================
    -- FAQ REGENERATION DECISION
    -- ========================================================================
    requires_faq_regeneration BOOLEAN NOT NULL CHECK(requires_faq_regeneration IN (0,1)),

    regeneration_priority INTEGER CHECK(regeneration_priority BETWEEN 1 AND 5),
        -- 5 = critical, 1 = low
        -- Auto-set based on change_magnitude + existing_faq_count

    regeneration_reason TEXT,
        -- Human-readable: "major_policy_change", "typo_fix", "section_added"

    -- ========================================================================
    -- FAQ IMPACT (snapshot at detection time)
    -- ========================================================================
    existing_faq_count INTEGER DEFAULT 0,
        -- How many FAQs reference this checksum (at detection time)
        -- Used for prioritization

    -- ========================================================================
    -- TEMPORAL TRACKING
    -- ========================================================================
    change_occurred_at TEXT NOT NULL,
        -- Best estimate of when change happened
        -- Source: current_content_id.last_modified_dt from content_repo

    change_detected_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        -- When detection algorithm ran and found this change

    detection_lag_seconds INTEGER AS (
        (julianday(change_detected_at) - julianday(change_occurred_at)) * 86400
    ) STORED,

    -- ========================================================================
    -- DETECTION CONTEXT
    -- ========================================================================
    detection_run_id TEXT NOT NULL,
        -- Batch ID for this detection run

    detection_method TEXT,
        -- "scheduled_scan", "incremental_scan", "manual_trigger"

    since_date TEXT,
        -- Detection scope: "check for changes since this date"

    -- ========================================================================
    -- PROCESSING STATE
    -- ========================================================================
    processing_status TEXT NOT NULL DEFAULT 'pending' CHECK(processing_status IN (
        'pending',
        'processing',
        'completed',
        'failed',
        'skipped',
        'requires_review'
    )),

    processing_started_at TEXT,
    processing_completed_at TEXT,

    faqs_regenerated_count INTEGER DEFAULT 0,
    faqs_invalidated_count INTEGER DEFAULT 0,

    -- ========================================================================
    -- ERROR TRACKING
    -- ========================================================================
    error_message TEXT,
    error_code TEXT,
    retry_count INTEGER DEFAULT 0,

    -- ========================================================================
    -- AUDIT
    -- ========================================================================
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    -- Must be actual change (different checksums)
    CHECK(
        previous_checksum IS NULL OR
        previous_checksum != current_checksum
    ),

    -- New content must have NULL previous
    CHECK(
        (change_type = 'new_content' AND previous_content_id IS NULL) OR
        (change_type != 'new_content' AND previous_content_id IS NOT NULL)
    ),

    -- Foreign Keys
    FOREIGN KEY (previous_content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE SET NULL,
    FOREIGN KEY (current_content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE
);
```

---

### **Key Differences from Original**

| Aspect | Original Proposal | CORRECTED Design |
|--------|------------------|------------------|
| **Baseline** | Separate `content_baseline` table | Use `content_repo` (already has versions) |
| **Previous State** | `previous_checksum` field only | `previous_content_id` FK to actual row |
| **Change Tracking** | Abstract checksum transition | Concrete version transition (v1→v2) |
| **Diff Computation** | Proposed complex logic | Simple: JOIN previous_content_id |
| **Semantics** | "Detection log" (all detections) | "Change log" (only changes) |

---

## 🔧 **How Change Detection Would Work**

### **Detection Algorithm (CHECKSUM-CENTRIC - CORRECT)**

```python
def detect_changes_for_file(file_name, previous_version, current_version):
    """
    Detect changes by comparing CHECKSUMS across versions.

    CRITICAL: Uses checksum-centric comparison to handle page insertion/deletion correctly.

    Key Principle:
        - CHECKSUM = Content identity (not page number!)
        - Compare sets of checksums between versions
        - NEW checksum = new content
        - MISSING checksum = deleted content
        - SAME checksum at different page = page move (no regeneration needed)
    """
    detection_run_id = generate_run_id()

    # Get all checksums from PREVIOUS version
    prev_checksums = db.query('''
        SELECT
            ud_source_file_id,
            content_checksum,
            raw_file_page_nbr,
            extracted_markdown_file_path
        FROM content_repo
        WHERE raw_file_nme = ?
          AND raw_file_version_nbr = ?
          AND file_status = 'Active'
    ''', file_name, previous_version)

    prev_map = {row.content_checksum: row for row in prev_checksums}

    # Get all checksums from CURRENT version
    curr_checksums = db.query('''
        SELECT
            ud_source_file_id,
            content_checksum,
            raw_file_page_nbr,
            extracted_markdown_file_path,
            last_modified_dt
        FROM content_repo
        WHERE raw_file_nme = ?
          AND raw_file_version_nbr = ?
          AND file_status = 'Active'
    ''', file_name, current_version)

    curr_map = {row.content_checksum: row for row in curr_checksums}

    changes_detected = []

    # === PHASE 1: Analyze CURRENT checksums ===
    for curr_checksum, curr_row in curr_map.items():
        if curr_checksum not in prev_map:
            # ===  NEW CONTENT (checksum didn't exist before) ===
            changes_detected.append({
                'change_type': 'new_content',
                'previous_content_id': None,
                'current_content_id': curr_row.ud_source_file_id,
                'previous_checksum': None,
                'current_checksum': curr_checksum,
                'requires_faq_regeneration': 1,
                'regeneration_priority': 3,  # Medium priority
                'change_reason': f'new_checksum_at_page_{curr_row.raw_file_page_nbr}',
                'file_name': file_name,
                'page_number': curr_row.raw_file_page_nbr,
                'change_occurred_at': curr_row.last_modified_dt
            })
        else:
            prev_row = prev_map[curr_checksum]

            if prev_row.raw_file_page_nbr != curr_row.raw_file_page_nbr:
                # === PAGE RENUMBERED (same content, different page) ===
                # This happens on page insertion/deletion
                changes_detected.append({
                    'change_type': 'page_renumbered',
                    'previous_content_id': prev_row.ud_source_file_id,
                    'current_content_id': curr_row.ud_source_file_id,
                    'previous_checksum': curr_checksum,
                    'current_checksum': curr_checksum,
                    'requires_faq_regeneration': 0,  # Content unchanged!
                    'regeneration_priority': None,
                    'change_reason': f'page_moved_{prev_row.raw_file_page_nbr}_to_{curr_row.raw_file_page_nbr}',
                    'file_name': file_name,
                    'page_number': curr_row.raw_file_page_nbr,
                    'change_occurred_at': curr_row.last_modified_dt
                })
            else:
                # === UNCHANGED (same checksum, same page) ===
                # DO NOT LOG - no change at all
                pass

    # === PHASE 2: Detect DELETED content ===
    for prev_checksum, prev_row in prev_map.items():
        if prev_checksum not in curr_map:
            # === CONTENT DELETED (checksum disappeared) ===
            changes_detected.append({
                'change_type': 'content_deleted',
                'previous_content_id': prev_row.ud_source_file_id,
                'current_content_id': None,
                'previous_checksum': prev_checksum,
                'current_checksum': None,
                'requires_faq_regeneration': 1,  # Invalidate FAQs
                'regeneration_priority': 4,  # High priority (need to invalidate)
                'change_reason': f'checksum_removed_from_page_{prev_row.raw_file_page_nbr}',
                'file_name': file_name,
                'page_number': None,  # No current page
                'change_occurred_at': now()  # Deletion detected now
            })

    # === PHASE 3: Compute diffs for new content ===
    for change in changes_detected:
        if change['change_type'] == 'new_content' and change['previous_content_id']:
            # Has previous version, can compute diff
            prev_content = load_markdown(
                prev_map[change['previous_checksum']].extracted_markdown_file_path
            )
            curr_content = load_markdown(
                curr_map[change['current_checksum']].extracted_markdown_file_path
            )

            diff_result = compute_diff(prev_content, curr_content)
            change['similarity_score'] = compute_similarity(prev_content, curr_content)
            change['edit_distance'] = diff_result.edit_distance
            change['lines_added'] = diff_result.lines_added
            change['lines_deleted'] = diff_result.lines_deleted

            # Adjust priority based on magnitude
            if change['similarity_score'] >= 0.95:
                change['regeneration_priority'] = 2  # Low (minor edit)
            elif change['similarity_score'] >= 0.70:
                change['regeneration_priority'] = 3  # Medium
            else:
                change['regeneration_priority'] = 5  # High (major rewrite)

    # === PHASE 4: Insert into change log ===
    for change in changes_detected:
        change['detection_run_id'] = detection_run_id
        change['change_detected_at'] = now()

        change_id = content_change_log.insert(change)

        # Store diff if available
        if 'diff_result' in change and change['diff_result']:
            content_diffs.insert({
                'change_id': change_id,
                'diff_text': change['diff_result'].unified_diff,
                'diff_stats': json.dumps(change['diff_result'].stats)
            })

    return {
        'detection_run_id': detection_run_id,
        'file_name': file_name,
        'total_changes': len(changes_detected),
        'new_content_count': sum(1 for c in changes_detected if c['change_type'] == 'new_content'),
        'deleted_count': sum(1 for c in changes_detected if c['change_type'] == 'content_deleted'),
        'page_moves_count': sum(1 for c in changes_detected if c['change_type'] == 'page_renumbered'),
        'requires_regeneration': sum(1 for c in changes_detected if c['requires_faq_regeneration'] == 1)
    }


def detect_changes_all_files():
    """
    Detect changes across all files in content_repo.
    """
    # Get all files with version changes
    files_with_versions = db.query('''
        SELECT
            raw_file_nme,
            MAX(raw_file_version_nbr) as latest_version
        FROM content_repo
        WHERE file_status = 'Active'
        GROUP BY raw_file_nme
        HAVING MAX(raw_file_version_nbr) > 1
    ''')

    all_results = []

    for file_row in files_with_versions:
        file_name = file_row.raw_file_nme
        current_version = file_row.latest_version
        previous_version = current_version - 1

        result = detect_changes_for_file(
            file_name,
            previous_version,
            current_version
        )

        all_results.append(result)

    return {
        'detection_run_id': all_results[0]['detection_run_id'] if all_results else None,
        'files_processed': len(all_results),
        'total_changes': sum(r['total_changes'] for r in all_results),
        'total_requiring_regeneration': sum(r['requires_regeneration'] for r in all_results),
        'by_file': all_results
    }
```

---

### **Example: Detecting Page Update**

**Setup**:
```
content_repo:
  id=1002, file=policy.pdf, page=2, version=1, checksum=ABC
  id=1004, file=policy.pdf, page=2, version=2, checksum=DEF
```

**Detection Logic**:
```python
# Current version
current = {id: 1004, page: 2, version: 2, checksum: 'DEF'}

# Find previous
previous = query("SELECT * FROM content_repo WHERE file=? AND page=? AND version=?",
                 'policy.pdf', 2, 1)
# Returns: {id: 1002, page: 2, version: 1, checksum: 'ABC'}

# Compare
if previous.checksum != current.checksum:  # ABC != DEF
    # CHANGE DETECTED
    content_change_log.insert({
        'previous_content_id': 1002,
        'current_content_id': 1004,
        'previous_checksum': 'ABC',
        'current_checksum': 'DEF',
        'change_type': 'content_modified',
        'requires_faq_regeneration': 1
    })
```

**Result**:
```sql
SELECT * FROM content_change_log;

change_id | prev_id | curr_id | prev_checksum | curr_checksum | change_type
----------|---------|---------|---------------|---------------|----------------
1         | 1002    | 1004    | ABC...        | DEF...        | content_modified
```

**Now can compute diff**:
```sql
SELECT
    prev.extracted_markdown_file_path as prev_file,
    curr.extracted_markdown_file_path as curr_file
FROM content_change_log ccl
JOIN content_repo prev ON ccl.previous_content_id = prev.ud_source_file_id
JOIN content_repo curr ON ccl.current_content_id = curr.ud_source_file_id
WHERE ccl.change_id = 1;

-- Can diff(prev_file, curr_file) to show actual changes!
```

---

## 📋 **CORRECTED TODO LIST**

### **Phase 1: Schema Updates** (1 week)

#### Task 1.1: Update content_change_log Schema
**Priority**: 🔴 CRITICAL
**Duration**: 2 days

**Changes**:
1. Add `previous_content_id` field (FK to content_repo)
2. Add `current_content_id` field (rename from `content_id`)
3. Add `previous_checksum` field
4. Rename `content_checksum` → `current_checksum`
5. Add change classification fields (change_type, similarity_score, etc.)
6. Add processing state fields
7. Remove idempotency constraint (or make it optional)

**Migration SQL**:
```sql
-- Backup
CREATE TABLE content_change_log_v4_backup AS SELECT * FROM content_change_log;

-- Drop and recreate
DROP TABLE content_change_log;

CREATE TABLE content_change_log (
    -- ... new schema from above
);

-- Migrate data (if any exists)
-- Note: Cannot populate previous_content_id from v4 data (not tracked)
-- Must start fresh or manually reconstruct
```

---

#### Task 1.2: Restore content_diffs Table
**Priority**: 🟡 HIGH
**Duration**: 0.5 days

```sql
CREATE TABLE content_diffs (
    diff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    change_id INTEGER NOT NULL,

    diff_format TEXT CHECK(diff_format IN ('unified', 'context', 'word')),
    diff_text TEXT,
    diff_text_compressed BLOB,

    lines_added INTEGER,
    lines_deleted INTEGER,

    diff_generated_at TEXT NOT NULL,

    FOREIGN KEY (change_id) REFERENCES content_change_log(change_id)
        ON DELETE CASCADE
);
```

---

### **Phase 2: Update Detection Logic** (2 weeks)

#### Task 2.1: Rewrite Change Detector
**Priority**: 🔴 CRITICAL
**Duration**: 5 days

**Current Code** (assumed):
```python
# WRONG: Compares to "baseline" (all historical checksums)
baseline = get_all_historical_checksums()
for page in current_pages:
    if page.checksum not in baseline:
        log_change(page)
```

**New Code**:
```python
# CORRECT: Compares to previous VERSION
for current_page in get_current_pages():
    previous_page = get_previous_version(current_page)

    if previous_page is None:
        # New content
        log_change(
            change_type='new_content',
            previous_id=None,
            current_id=current_page.id
        )
    elif previous_page.checksum != current_page.checksum:
        # Modified content
        similarity = compute_similarity(previous_page, current_page)
        diff = compute_diff(previous_page, current_page)

        log_change(
            change_type='content_modified',
            previous_id=previous_page.id,
            current_id=current_page.id,
            similarity=similarity
        )

        store_diff(diff)
```

**Files to Update**:
- `src/detectors/faq_regeneration_detector.py`
- `src/processors/change_processor.py`

---

#### Task 2.2: Implement Diff Computation
**Priority**: 🟡 MEDIUM
**Duration**: 3 days

**Implement**:
1. Similarity scoring (cosine/Jaccard)
2. Diff generation (unified format)
3. Diff compression (gzip)
4. Change magnitude classification

**Deliverables**:
- `src/utils/diff_utils.py`
- Unit tests for diff computation

---

### **Phase 3: Update Invalidation Logic** (1 week)

#### Task 3.1: Use New Schema in FAQ Invalidation
**Priority**: 🔴 CRITICAL
**Duration**: 3 days

**Old Query**:
```sql
-- Get changes
SELECT * FROM content_change_log
WHERE requires_faq_regeneration = 1;
```

**New Query**:
```sql
-- Get changes with previous/current context
SELECT
    ccl.*,
    prev.raw_file_nme as prev_file,
    prev.raw_file_page_nbr as prev_page,
    curr.raw_file_nme as curr_file,
    curr.raw_file_page_nbr as curr_page,
    ccl.change_magnitude
FROM content_change_log ccl
LEFT JOIN content_repo prev ON ccl.previous_content_id = prev.ud_source_file_id
JOIN content_repo curr ON ccl.current_content_id = curr.ud_source_file_id
WHERE ccl.requires_faq_regeneration = 1
  AND ccl.processing_status = 'pending'
ORDER BY ccl.regeneration_priority DESC;
```

**Update**:
- `src/processors/faq_mapper.py`

---

### **Phase 4: Testing** (1 week)

#### Task 4.1: Integration Testing
**Priority**: 🔴 CRITICAL
**Duration**: 3 days

**Test Scenarios**:
1. **New content**: First version of page
2. **Minor edit**: 95% similar to previous
3. **Major rewrite**: <50% similar to previous
4. **Page deletion**: Marked inactive
5. **Page insertion**: New page shifts others
6. **Multiple runs**: Ensure idempotency

**Verify**:
- `previous_content_id` correctly links to previous version
- Diffs are stored and retrievable
- Change magnitude correctly computed
- No unchanged pages in change_log

---

### **Phase 5: Deployment** (1 week)

Same as before, but simpler:
- No separate baseline table to manage
- Just update content_change_log schema
- Update detection logic
- Deploy and monitor

---

## 📊 **CORRECTED Effort Estimate**

| Phase | Original Estimate | Corrected Estimate | Savings |
|-------|------------------|--------------------|---------|
| Schema Design | 10 days | 3 days | -7 days |
| Code Changes | 30 days | 15 days | -15 days |
| Testing | 15 days | 10 days | -5 days |
| **TOTAL** | **91 days** | **45 days** | **-46 days** |

**Why Much Faster**:
- ✅ No separate baseline table (use content_repo)
- ✅ Simpler versioning logic (already in content_repo)
- ✅ Less migration complexity
- ✅ Fewer tables to manage

**Revised Timeline**: **6 weeks** (down from 8)

---

## 🎯 **ANSWERS TO YOUR QUESTIONS**

### **Question 1**: Isn't content_baseline same as content_repo?

**Answer**: **YES! You're absolutely right.**

I misunderstood the data model. `content_repo` ALREADY:
- Stores all versions (via `version_nbr`)
- Has checksums
- Has timestamps
- Preserves history

**No separate baseline table needed!**

The "baseline" is simply:
```sql
-- Current baseline = latest version of each page
SELECT * FROM content_repo cr
WHERE version_nbr = (
    SELECT MAX(version_nbr)
    FROM content_repo
    WHERE raw_file_nme = cr.raw_file_nme
      AND raw_file_page_nbr = cr.raw_file_page_nbr
);
```

---

### **Question 2**: How to track previous → current checksum when we split into pages?

**Answer**: The system **already does this** via `version_nbr`!

**How it works**:
```
1. Day 1: Extract policy.pdf
   → Page 2 gets: id=1002, version=1, checksum=ABC

2. Day 2: Policy updated, re-extract
   → Page 2 gets: id=1004, version=2, checksum=DEF

3. To find "previous" checksum:
   SELECT content_checksum FROM content_repo
   WHERE raw_file_nme = 'policy.pdf'
     AND raw_file_page_nbr = 2
     AND version_nbr = 1;
   -- Returns: ABC

4. To find "current" checksum:
   SELECT content_checksum FROM content_repo
   WHERE raw_file_nme = 'policy.pdf'
     AND raw_file_page_nbr = 2
     AND version_nbr = 2;
   -- Returns: DEF

5. Transition: ABC → DEF (version 1 → version 2)
```

**The key insight**: `previous_content_id` is just a **shortcut FK** pointing to the row with `version_nbr - 1`. Makes queries easier.

---

## 🚀 **SIMPLIFIED IMPLEMENTATION**

### **What Actually Needs to Change**

**Minimal Changes** (2 weeks):
1. ✅ Add `previous_content_id` to content_change_log
2. ✅ Update detection to compute version transitions
3. ✅ Store only actual changes (not all detections)
4. ✅ Add change classification (minor/major)

**Optional Enhancements** (4 more weeks):
5. 🟢 Add diff storage (content_diffs table)
6. 🟢 Add processing state tracking
7. 🟢 Add retry logic
8. 🟢 Add analytics views

**You choose scope based on priorities!**

---

## 📌 **KEY TAKEAWAY**

**My Original Analysis**: 50% wrong because I didn't understand your data model.

**Corrected Understanding**:
- `content_repo` = Already has versioning and history
- Don't need separate baseline table
- Just need to link previous→current versions in change_log
- Much simpler than I thought!

**Effort Reduced**: 91 days → 45 days (50% savings)

---

**What do you think? Does this corrected analysis make sense now?**

---

## 🔄 **UPDATE AFTER IMPLEMENTATION REVIEW**

**Date**: 2025-10-20
**Status**: IMPLEMENTATION IS BETTER THAN ANALYSIS

After comparing the logic proposed in this analysis document (Approach E) with the actual implementation in [3_update_detector.ipynb](notebooks/3_update_detector.ipynb) and [faq_regeneration_detector.py](src/detectors/faq_regeneration_detector.py), **THE IMPLEMENTATION IS SUPERIOR**.

### Key Finding

**Approach E (Version Diff) is OVER-ENGINEERED for FAQ regeneration.**

The implementation uses a simpler and better approach:

**Approach F: BASELINE MEMBERSHIP Check**
- Baseline = Set of all checksums that existed BEFORE since_date  
- If checksum IN baseline → no_action_needed (preserve FAQ)
- If checksum NOT IN baseline → regenerate_faq (new content)

### Why Approach F (Implementation) is Better

| Aspect | Approach E (This Document) | Approach F (Implementation) |
|--------|---------------------------|----------------------------|
| **Complexity** | High (4 change types) | Low (2 categories) |
| **Code Lines** | ~150 lines | ~80 lines (50% less) |
| **Schema** | Requires version_nbr | Uses last_modified_dt (exists) |
| **Business Fit** | Granular change tracking | Direct FAQ decision |
| **Noise** | Logs page moves (unnecessary) | No noise (only FAQ impact) |
| **Model** | Version-based (v1→v2) | Temporal (before/after date) |

### Example Comparison

```
Scenario: Page inserted, causing subsequent pages to renumber

Initial:
  Page 1: AAA
  Page 2: BBB  
  Page 3: CCC

Updated:
  Page 1: AAA
  Page 2: XXX (NEW)
  Page 3: BBB (moved)
  Page 4: CCC (moved)

Approach E (This Document):
  - Logs: new_content (XXX) ✅
  - Logs: page_renumbered (BBB) ❌ Noise  
  - Logs: page_renumbered (CCC) ❌ Noise
  Total: 3 log entries

Approach F (Implementation):
  Baseline: {AAA, BBB, CCC}
  - XXX NOT in baseline → regenerate_faq ✅
  - BBB in baseline → no_action_needed ✅
  - CCC in baseline → no_action_needed ✅
  Total: 2 categories (100% signal)
```

### Critical Issues with Approach E

1. ❌ **Requires version_nbr field** (schema doesn't have it)
2. ❌ **Creates noise** (logs page moves even when FAQ unchanged)
3. ❌ **Complex schema** (needs previous_content_id, current_content_id, change_type)
4. ❌ **Version dependency** (breaks if version numbers inconsistent)
5. ❌ **Not aligned with business goal** (FAQ regeneration is binary decision)

### Recommendation

✅ **USE IMPLEMENTATION APPROACH (Approach F)** - Already complete, simpler, better

❌ **DO NOT implement Approach E** - Over-engineered, requires schema changes, adds complexity

### When to Use Each Approach

- **Approach F (Baseline Membership)**: FAQ regeneration, content change triggers, binary decisions ✅ *YOUR CASE*
- **Approach E (Version Diff)**: Document version control, audit trails, compliance tracking

### Detailed Analysis

See [LOGIC_COMPARISON_ANALYSIS.md](LOGIC_COMPARISON_ANALYSIS.md) for comprehensive comparison.

**Effort Saved**: 45 person-days (implementation already complete!) 🎉

---

**FINAL ANSWER**: The implementation is correct and superior. No changes needed.
