-- ============================================================================
-- CONTENT VERSION TRACKING SCHEMA (ENHANCED)
-- Version: 2.0
-- Purpose: Track content versions and FAQ relationships with robust integrity
-- Date: 2025-10-04
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Table: content_version_history
-- Purpose: Track the evolution of content over time with strong integrity
-- Links to: content_repo.ud_source_file_id
--
-- IMPORTANT: This table stores VERSION METADATA only, not actual content!
-- Actual content lives in files at paths stored in content_repo.extracted_markdown_file_path
-- ----------------------------------------------------------------------------
CREATE TABLE content_version_history (
    version_history_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Link to content in content_repo
    content_id INTEGER NOT NULL,  -- FK to content_repo.ud_source_file_id

    -- Link to previous version in THIS table (self-referential FK)
    previous_version_id INTEGER,  -- FK to content_version_history.version_history_id

    -- Version metadata
    version_sequence INTEGER NOT NULL CHECK(version_sequence > 0),  -- Sequential version number (1, 2, 3...)
    is_latest_version BOOLEAN DEFAULT TRUE CHECK(is_latest_version IN (0, 1)),

    -- File and page identification (denormalized for query performance)
    file_name TEXT NOT NULL,
    page_number INTEGER NOT NULL CHECK(page_number > 0),

    -- Change tracking
    content_checksum TEXT NOT NULL CHECK(length(content_checksum) = 64),  -- SHA-256 hash is exactly 64 hex chars

    change_type TEXT CHECK(change_type IN ('initial', 'minor', 'major', 'breaking')),
    change_summary TEXT,
    content_diff TEXT,  -- JSON text: Structured diff between versions

    -- Temporal tracking (UTC timestamps)
    version_created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),  -- ISO 8601 with milliseconds
    detected_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),

    -- Metadata
    created_by TEXT DEFAULT 'system',
    notes TEXT,

    -- Constraints
    UNIQUE(content_id, version_sequence),  -- Each content has unique version sequences
    UNIQUE(file_name, page_number, version_sequence),  -- Unique version per page
    CHECK(
        (version_sequence = 1 AND previous_version_id IS NULL) OR
        (version_sequence > 1 AND previous_version_id IS NOT NULL)
    ),  -- First version has no previous, others must have previous

    -- Foreign key constraints
    FOREIGN KEY (previous_version_id) REFERENCES content_version_history(version_history_id)
);

-- Indexes for performance
CREATE INDEX idx_cvh_content ON content_version_history(content_id);
CREATE INDEX idx_cvh_previous_version ON content_version_history(previous_version_id);
CREATE INDEX idx_cvh_file_page ON content_version_history(file_name, page_number);
CREATE INDEX idx_cvh_latest ON content_version_history(content_id, is_latest_version);
CREATE INDEX idx_cvh_checksum ON content_version_history(content_checksum);
CREATE INDEX idx_cvh_created_at ON content_version_history(version_created_at);

-- ----------------------------------------------------------------------------
-- Table: faq_content_link
-- Purpose: Link FAQs to specific content versions
-- Links to: faq_questions.question_id, content_repo.ud_source_file_id
-- ----------------------------------------------------------------------------
CREATE TABLE faq_content_link (
    link_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- FAQ reference
    question_id INTEGER NOT NULL,  -- FK to faq_questions.question_id
    answer_id TEXT,  -- FK to faq_answers.answer_id (optional, can be NULL initially)

    -- Content version reference
    content_id INTEGER NOT NULL,  -- FK to content_repo.ud_source_file_id
    version_history_id INTEGER NOT NULL,  -- FK to content_version_history.version_history_id

    -- Version range this FAQ is valid for
    valid_from_version INTEGER NOT NULL CHECK(valid_from_version > 0),  -- First version this FAQ applies to
    valid_until_version INTEGER CHECK(valid_until_version IS NULL OR valid_until_version >= valid_from_version),  -- Last version (NULL = still valid)

    -- Validity tracking
    is_currently_valid BOOLEAN DEFAULT TRUE CHECK(is_currently_valid IN (0, 1)),

    -- Generation metadata
    generated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),
    generation_method TEXT CHECK(generation_method IN ('auto_llm', 'manual', 'hybrid', 'rule_based')),
    confidence_score REAL CHECK(confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0)),

    -- Deprecation tracking
    deprecated_at TEXT,
    deprecated_reason TEXT CHECK(deprecated_reason IN (
        'content_updated',
        'content_removed',
        'answer_incorrect',
        'question_outdated',
        'superseded_by_newer_faq'
    )),
    superseded_by_link_id INTEGER,  -- FK to faq_content_link.link_id

    -- Metadata
    created_by TEXT DEFAULT 'system',
    notes TEXT,

    -- Constraints
    UNIQUE(question_id, version_history_id),  -- One link per question-version pair
    CHECK(
        (is_currently_valid = 1 AND deprecated_at IS NULL) OR
        (is_currently_valid = 0 AND deprecated_at IS NOT NULL)
    ),  -- Validity matches deprecation status

    -- Foreign key constraints
    FOREIGN KEY (version_history_id) REFERENCES content_version_history(version_history_id),
    FOREIGN KEY (superseded_by_link_id) REFERENCES faq_content_link(link_id)
);

-- Indexes for performance
CREATE INDEX idx_fcl_question ON faq_content_link(question_id);
CREATE INDEX idx_fcl_content ON faq_content_link(content_id);
CREATE INDEX idx_fcl_version_hist ON faq_content_link(version_history_id);
CREATE INDEX idx_fcl_valid ON faq_content_link(is_currently_valid, content_id);
CREATE INDEX idx_fcl_version_range ON faq_content_link(valid_from_version, valid_until_version);
CREATE INDEX idx_fcl_generated_at ON faq_content_link(generated_at);

-- ----------------------------------------------------------------------------
-- Table: faq_validation_history
-- Purpose: Track validation and review history of FAQs over time
-- Links to: faq_content_link.link_id
-- ----------------------------------------------------------------------------
CREATE TABLE faq_validation_history (
    validation_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Link to FAQ-content relationship
    link_id INTEGER NOT NULL,  -- FK to faq_content_link.link_id

    -- Validation details
    validation_type TEXT NOT NULL CHECK(validation_type IN (
        'initial_review',
        'content_change_review',
        'periodic_audit',
        'user_feedback',
        'automated_check'
    )),

    validation_status TEXT NOT NULL CHECK(validation_status IN (
        'approved',
        'needs_revision',
        'deprecated',
        'flagged_for_review'
    )),

    -- Validator information
    validated_by TEXT NOT NULL,
    validated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),

    -- Validation findings
    findings TEXT,
    suggested_changes TEXT,  -- JSON text

    -- Action taken
    action_taken TEXT,
    action_taken_at TEXT,

    -- Foreign key constraints
    FOREIGN KEY (link_id) REFERENCES faq_content_link(link_id) ON DELETE CASCADE
);

CREATE INDEX idx_fvh_link ON faq_validation_history(link_id);
CREATE INDEX idx_fvh_status ON faq_validation_history(validation_status);
CREATE INDEX idx_fvh_date ON faq_validation_history(validated_at);
CREATE INDEX idx_fvh_validator ON faq_validation_history(validated_by);

-- ----------------------------------------------------------------------------
-- Table: content_change_impact
-- Purpose: Track which FAQs are impacted when content changes
-- Links to: content_version_history.version_history_id
-- ----------------------------------------------------------------------------
CREATE TABLE content_change_impact (
    impact_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Version that changed
    version_history_id INTEGER NOT NULL,  -- FK to content_version_history.version_history_id

    -- Impact assessment
    total_faqs_affected INTEGER DEFAULT 0 CHECK(total_faqs_affected >= 0),
    faqs_auto_deprecated INTEGER DEFAULT 0 CHECK(faqs_auto_deprecated >= 0),
    faqs_flagged_for_review INTEGER DEFAULT 0 CHECK(faqs_flagged_for_review >= 0),
    faqs_still_valid INTEGER DEFAULT 0 CHECK(faqs_still_valid >= 0),

    -- Change severity
    impact_severity TEXT CHECK(impact_severity IN ('none', 'low', 'medium', 'high', 'critical')),

    -- Actions taken
    auto_actions_performed TEXT,  -- JSON text: List of automated actions
    manual_review_required BOOLEAN DEFAULT FALSE CHECK(manual_review_required IN (0, 1)),

    -- Processing metadata
    analyzed_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),
    analysis_method TEXT CHECK(analysis_method IN ('rule_based', 'llm_based', 'hybrid', 'manual')),

    -- Constraints
    CHECK(total_faqs_affected = faqs_auto_deprecated + faqs_flagged_for_review + faqs_still_valid),

    -- Foreign key constraints
    FOREIGN KEY (version_history_id) REFERENCES content_version_history(version_history_id) ON DELETE CASCADE
);

CREATE INDEX idx_cci_version ON content_change_impact(version_history_id);
CREATE INDEX idx_cci_severity ON content_change_impact(impact_severity);
CREATE INDEX idx_cci_review ON content_change_impact(manual_review_required, impact_severity);
CREATE INDEX idx_cci_analyzed_at ON content_change_impact(analyzed_at);

-- ----------------------------------------------------------------------------
-- Table: pipeline_run_metadata
-- Purpose: Track pipeline execution history and state
-- NEW TABLE for better operational visibility
-- ----------------------------------------------------------------------------
CREATE TABLE pipeline_run_metadata (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Run identification
    run_type TEXT NOT NULL CHECK(run_type IN ('initial', 'incremental', 'full_refresh', 'manual')),
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),
    completed_at TEXT,

    -- Processing stats
    total_records_processed INTEGER DEFAULT 0 CHECK(total_records_processed >= 0),
    new_versions_created INTEGER DEFAULT 0 CHECK(new_versions_created >= 0),
    versions_updated INTEGER DEFAULT 0 CHECK(versions_updated >= 0),
    faqs_deprecated INTEGER DEFAULT 0 CHECK(faqs_deprecated >= 0),
    errors_encountered INTEGER DEFAULT 0 CHECK(errors_encountered >= 0),

    -- Status
    run_status TEXT NOT NULL CHECK(run_status IN ('running', 'completed', 'failed', 'partial')),
    error_message TEXT,

    -- Filter criteria
    last_modified_dt_filter TEXT,  -- ISO 8601 timestamp used for filtering
    content_ids_processed TEXT,  -- JSON array of content_ids

    -- Execution context
    executed_by TEXT DEFAULT 'system',
    execution_environment TEXT,  -- 'databricks', 'local', 'jupyter', etc.

    -- Metadata
    notes TEXT,

    CHECK(
        (run_status = 'completed' AND completed_at IS NOT NULL) OR
        (run_status != 'completed')
    )
);

CREATE INDEX idx_prm_started_at ON pipeline_run_metadata(started_at);
CREATE INDEX idx_prm_status ON pipeline_run_metadata(run_status);
CREATE INDEX idx_prm_type ON pipeline_run_metadata(run_type);

-- ============================================================================
-- TRIGGERS FOR DATA INTEGRITY
-- ============================================================================

-- Trigger: Ensure only one latest version per content
CREATE TRIGGER trg_cvh_single_latest_version
BEFORE INSERT ON content_version_history
WHEN NEW.is_latest_version = 1
BEGIN
    UPDATE content_version_history
    SET is_latest_version = 0
    WHERE content_id = NEW.content_id
      AND is_latest_version = 1
      AND version_history_id != NEW.version_history_id;
END;

-- Trigger: Validate version chain integrity
CREATE TRIGGER trg_cvh_validate_chain
BEFORE INSERT ON content_version_history
WHEN NEW.previous_version_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'Previous version must belong to same content_id')
    WHERE NOT EXISTS (
        SELECT 1 FROM content_version_history
        WHERE version_history_id = NEW.previous_version_id
          AND content_id = NEW.content_id
    );
END;

-- Trigger: Auto-deprecate FAQs when content is updated
CREATE TRIGGER trg_cvh_auto_deprecate_faqs
AFTER INSERT ON content_version_history
WHEN NEW.version_sequence > 1 AND NEW.change_type IN ('major', 'breaking')
BEGIN
    UPDATE faq_content_link
    SET is_currently_valid = 0,
        deprecated_at = strftime('%Y-%m-%dT%H:%M:%f', 'now'),
        deprecated_reason = 'content_updated'
    WHERE content_id = NEW.content_id
      AND is_currently_valid = 1
      AND valid_until_version IS NULL;
END;

-- Trigger: Validate deprecation consistency
CREATE TRIGGER trg_fcl_deprecation_consistency
BEFORE UPDATE ON faq_content_link
WHEN NEW.is_currently_valid = 0 AND OLD.is_currently_valid = 1
BEGIN
    SELECT RAISE(ABORT, 'Must set deprecated_at and deprecated_reason when marking invalid')
    WHERE NEW.deprecated_at IS NULL OR NEW.deprecated_reason IS NULL;
END;

-- Trigger: Update pipeline completion timestamp
CREATE TRIGGER trg_prm_completion
BEFORE UPDATE ON pipeline_run_metadata
WHEN NEW.run_status = 'completed' AND OLD.run_status = 'running'
BEGIN
    UPDATE pipeline_run_metadata
    SET completed_at = strftime('%Y-%m-%dT%H:%M:%f', 'now')
    WHERE run_id = NEW.run_id;
END;

-- ============================================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================================

-- View: Current valid FAQs with version info
CREATE VIEW v_current_valid_faqs AS
SELECT
    fcl.link_id,
    fcl.question_id,
    fcl.answer_id,
    fcl.content_id,
    cvh.file_name,
    cvh.page_number,
    cvh.version_sequence,
    cvh.content_checksum,
    cvh.is_latest_version,
    fcl.valid_from_version,
    fcl.valid_until_version,
    fcl.confidence_score,
    fcl.generation_method,
    fcl.generated_at
FROM faq_content_link fcl
JOIN content_version_history cvh ON fcl.version_history_id = cvh.version_history_id
WHERE fcl.is_currently_valid = 1;

-- View: Version history with change summary and FAQ counts
CREATE VIEW v_version_history_summary AS
SELECT
    cvh.version_history_id,
    cvh.content_id,
    cvh.file_name,
    cvh.page_number,
    cvh.version_sequence,
    cvh.change_type,
    cvh.change_summary,
    cvh.content_checksum,
    cvh.version_created_at,
    cvh.is_latest_version,
    COUNT(fcl.link_id) as total_faqs,
    SUM(CASE WHEN fcl.is_currently_valid = 1 THEN 1 ELSE 0 END) as valid_faqs,
    SUM(CASE WHEN fcl.is_currently_valid = 0 THEN 1 ELSE 0 END) as deprecated_faqs
FROM content_version_history cvh
LEFT JOIN faq_content_link fcl ON cvh.version_history_id = fcl.version_history_id
GROUP BY cvh.version_history_id;

-- View: FAQs needing review after content changes
CREATE VIEW v_faqs_needing_review AS
SELECT
    fcl.link_id,
    fcl.question_id,
    fcl.answer_id,
    cvh.file_name,
    cvh.page_number,
    cvh.version_sequence as deprecated_at_version,
    cvh.change_type,
    cvh.change_summary,
    cvh.version_created_at,
    fcl.deprecated_reason,
    fcl.deprecated_at,
    fcl.superseded_by_link_id
FROM faq_content_link fcl
JOIN content_version_history cvh ON fcl.version_history_id = cvh.version_history_id
WHERE fcl.is_currently_valid = 0
  AND fcl.deprecated_at IS NOT NULL
  AND fcl.superseded_by_link_id IS NULL;

-- View: Version chain (recursive - shows full history for each content)
CREATE VIEW v_version_chains AS
WITH RECURSIVE version_chain(
    version_history_id,
    content_id,
    version_sequence,
    file_name,
    page_number,
    change_type,
    content_checksum,
    version_created_at,
    chain_depth
) AS (
    -- Base case: latest versions
    SELECT
        version_history_id,
        content_id,
        version_sequence,
        file_name,
        page_number,
        change_type,
        content_checksum,
        version_created_at,
        0 as chain_depth
    FROM content_version_history
    WHERE is_latest_version = 1

    UNION ALL

    -- Recursive case: previous versions
    SELECT
        cvh.version_history_id,
        cvh.content_id,
        cvh.version_sequence,
        cvh.file_name,
        cvh.page_number,
        cvh.change_type,
        cvh.content_checksum,
        cvh.version_created_at,
        vc.chain_depth + 1
    FROM content_version_history cvh
    JOIN version_chain vc ON cvh.version_history_id = vc.previous_version_id
    WHERE vc.previous_version_id IS NOT NULL
)
SELECT * FROM version_chain
ORDER BY content_id, version_sequence;

-- View: Pipeline execution summary
CREATE VIEW v_pipeline_execution_summary AS
SELECT
    run_id,
    run_type,
    started_at,
    completed_at,
    run_status,
    total_records_processed,
    new_versions_created,
    versions_updated,
    faqs_deprecated,
    errors_encountered,
    CAST((julianday(completed_at) - julianday(started_at)) * 24 * 60 AS INTEGER) as duration_minutes,
    executed_by
FROM pipeline_run_metadata
ORDER BY started_at DESC;

-- View: Content with pending FAQ reviews
CREATE VIEW v_content_pending_reviews AS
SELECT
    cvh.content_id,
    cvh.file_name,
    cvh.page_number,
    cvh.version_sequence,
    cvh.change_type,
    cvh.version_created_at,
    COUNT(fcl.link_id) as faqs_needing_review,
    cci.impact_severity
FROM content_version_history cvh
LEFT JOIN faq_content_link fcl ON cvh.version_history_id = fcl.version_history_id
    AND fcl.is_currently_valid = 0
    AND fcl.superseded_by_link_id IS NULL
LEFT JOIN content_change_impact cci ON cvh.version_history_id = cci.version_history_id
WHERE cvh.is_latest_version = 1
  AND cvh.version_sequence > 1
GROUP BY cvh.version_history_id
HAVING COUNT(fcl.link_id) > 0
ORDER BY cci.impact_severity DESC, faqs_needing_review DESC;

-- ============================================================================
-- UTILITY FUNCTIONS (Stored as documentation - implement in application)
-- ============================================================================

/*
-- Python function to get full version chain:
def get_full_version_chain(conn, version_history_id):
    query = """
    WITH RECURSIVE chain AS (
        SELECT * FROM content_version_history WHERE version_history_id = ?
        UNION ALL
        SELECT cvh.* FROM content_version_history cvh
        JOIN chain c ON cvh.version_history_id = c.previous_version_id
    )
    SELECT * FROM chain ORDER BY version_sequence;
    """
    return pd.read_sql(query, conn, params=[version_history_id])

-- Python function to deprecate FAQs:
def deprecate_faqs_for_content(conn, content_id, reason='content_updated'):
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE faq_content_link
        SET is_currently_valid = 0,
            deprecated_at = datetime('now'),
            deprecated_reason = ?
        WHERE content_id = ? AND is_currently_valid = 1
    """, [reason, content_id])
    conn.commit()
    return cursor.rowcount
*/

-- ============================================================================
-- SCHEMA METADATA AND VERSION
-- ============================================================================

CREATE TABLE schema_version (
    version_id INTEGER PRIMARY KEY,
    schema_version TEXT NOT NULL,
    applied_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%f', 'now')),
    description TEXT
);

INSERT INTO schema_version (version_id, schema_version, description)
VALUES (1, '2.0', 'Enhanced version with triggers, pipeline metadata, and robust constraints');

-- ============================================================================
-- DESIGN NOTES
-- ============================================================================

/*
ENHANCEMENTS FROM v1.0:
1. ✅ Added CHECK constraints for data validation
2. ✅ Added FOREIGN KEY constraints with CASCADE rules
3. ✅ Fixed UNIQUE constraints (removed incorrect content_id unique)
4. ✅ Added proper version sequence constraints per content
5. ✅ Added triggers for automatic data integrity
6. ✅ Added pipeline_run_metadata table for operational tracking
7. ✅ Changed TIMESTAMP to TEXT with ISO 8601 format (SQLite best practice)
8. ✅ Added millisecond precision to timestamps
9. ✅ Added comprehensive indexes including composite indexes
10. ✅ Added recursive CTE view for version chains
11. ✅ Added checksum validation (must be 64 hex chars for SHA-256)
12. ✅ Added confidence score validation (0.0 to 1.0)
13. ✅ Added impact calculation CHECK constraint
14. ✅ Added schema_version table for migration tracking

BREAKING CHANGES FROM v1.0:
- TIMESTAMP columns now TEXT (ISO 8601 format)
- UNIQUE(content_id) removed from content_version_history
- UNIQUE(content_id, version_sequence) added
- JSON columns explicitly marked as TEXT
- BOOLEAN now uses CHECK(col IN (0,1)) for strict validation

MIGRATION STRATEGY:
- This is a new schema, not a migration
- For existing data: export to CSV, recreate DB with new schema, reimport
- Or use ALTER TABLE to add constraints incrementally
*/
