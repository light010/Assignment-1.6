# Schema v4.0 Update Summary

**Date:** 2025-10-06
**Purpose:** Align `create_schema_v4.sql` with actual production Excel data structures

---

## ✅ Changes Made

### 1. **content_repo Table - EXPANDED**

#### Added Fields (from Excel data):
```sql
-- Organization and context
domain TEXT,
service TEXT,
orgoid TEXT,
associateoid TEXT,

-- File identification (expanded)
raw_file_type TEXT,
raw_file_version_nbr INTEGER DEFAULT 1,

-- Source information
source_url_txt TEXT,
parent_location_txt TEXT,
raw_file_path TEXT,

-- Content paths (added)
extracted_layout_file_path TEXT,

-- Content metadata
title_nme TEXT,
breadcrumb_txt TEXT,
content_tags_txt TEXT,
version_nbr INTEGER DEFAULT 1,
content_checksum TEXT CHECK(content_checksum IS NULL OR length(content_checksum) = 64),
file_status TEXT CHECK(file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived')),
```

#### Updated Indexes:
- Added: `idx_repo_checksum` (for content tracking)
- Added: `idx_repo_domain_service` (for filtering)
- Added: `idx_repo_orgoid` (for organization queries)
- Changed: `idx_repo_status` now references `file_status` instead of `processing_status`

---

### 2. **faq_questions Table - RESTRUCTURED**

#### **Primary Key Type**
- **Implementation:** `question_id INTEGER PRIMARY KEY`
- **Note:** Despite original plans for TEXT-based UUIDs, the actual implementation uses INTEGER for compatibility with test data (IDs: 1001, 1002, etc.)

#### Complete New Structure:
```sql
-- Question versions and history
prev_recommended_question_txt TEXT,
prev_question_txt TEXT,
recommeded_question_txt TEXT,  -- Note: Typo in source Excel, preserved
question_txt TEXT NOT NULL,

-- Source information
source TEXT,
src_file_name TEXT,
src_id TEXT,
src_page_number INTEGER,  -- INTEGER to match content_repo.raw_file_page_nbr
prev_src TEXT,

-- Organization and context
domain TEXT,
service TEXT,
product TEXT,
orgid TEXT,

-- Timestamps (using Excel format, not SQLite defaults)
created TEXT,
created_by TEXT,
modified TEXT,
modified_by TEXT,

-- Metadata
version TEXT,
status TEXT,
metadata TEXT
```

#### Removed Fields:
- `created_at` (replaced by `created`)
- `updated_at` (replaced by `modified`)
- `category` (replaced by `domain`)
- `priority` (not in Excel data)
- `is_active` (replaced by `status`)

#### Updated Indexes:
```sql
idx_questions_txt         -- Question text lookup
idx_questions_source      -- Source file + page
idx_questions_domain      -- Domain + service filtering
idx_questions_orgid       -- Organization filtering
idx_questions_status      -- Status filtering
```

---

### 3. **faq_answers Table - RESTRUCTURED**

#### **Primary Key Type**
- **Implementation:** `answer_id INTEGER PRIMARY KEY`
- **Note:** Despite original plans for TEXT-based UUIDs, the actual implementation uses INTEGER for compatibility with test data (IDs: 1001, 1002, etc.)

#### Complete New Structure:
```sql
-- Foreign key to question
question_id INTEGER,

-- Answer versions and history
prev_recommended_answer_txt TEXT,
recommended_answer_txt TEXT,
prev_faq_answer_txt TEXT,
faq_answer_txt TEXT NOT NULL,
user_feedback_txt TEXT,

-- Source information
source TEXT,
src_file_name TEXT,
src_id TEXT,
src_page_number INTEGER,  -- INTEGER to match content_repo.raw_file_page_nbr
prev_src TEXT,

-- Organization and context
domain TEXT,
service TEXT,
product TEXT,
orgid TEXT,

-- Timestamps
created TEXT,
created_by TEXT,
modified TEXT,
modified_by TEXT,

-- Metadata
version TEXT,
status TEXT,
metadata TEXT
```

#### Removed Fields:
- `created_at` (replaced by `created`)
- `updated_at` (replaced by `modified`)
- `answer_format` (not in Excel data)
- `is_active` (replaced by `status`)
- `word_count` (can be calculated if needed)

#### Updated Indexes:
```sql
idx_answers_question      -- Link to question
idx_answers_source        -- Source file + page
idx_answers_domain        -- Domain + service filtering
idx_answers_orgid         -- Organization filtering
idx_answers_status        -- Status filtering
```

---

### 4. **faq_content_map Table - Foreign Key Update**

#### Foreign Key Types:
```sql
-- Implementation uses INTEGER (matching base tables):
question_id INTEGER NOT NULL,
answer_id INTEGER,
```

**Impact:** Foreign keys correctly reference INTEGER primary keys in faq_questions and faq_answers.

---

## 🔍 Impact Analysis

### **Breaking Changes**

1. **Primary Key Type - NO CHANGE**
   - `faq_questions.question_id`: INTEGER PRIMARY KEY (unchanged)
   - `faq_answers.answer_id`: INTEGER PRIMARY KEY (unchanged)
   - **Note:** Original documentation mentioned TEXT keys, but implementation uses INTEGER to align with test data

2. **Column Name Changes**
   - `created_at` → `created`
   - `updated_at` → `modified`/`updated_at`
   - `category` → `domain`
   - `is_active` → `status`

3. **Removed Columns**
   - `priority` (in faq_questions)
   - `word_count` (in faq_answers)
   - `answer_format` (in faq_answers)

### **Non-Breaking Changes**

1. **content_repo Additions**
   - All new fields are optional (NULL allowed)
   - Existing inserts will still work (with NULLs for new fields)

2. **Index Changes**
   - Old indexes replaced with new ones
   - Query performance maintained or improved

---

## ✅ Compatibility with Notebook

### **setup_tables_enhanced.ipynb - Test Data Generators**

The notebook's test data generators (Cell 8) now match the schema exactly:

```python
# content_repo - ✅ MATCHES
records.append({
    'ud_source_file_id': 1001,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 1,
    # ... all fields present
})

# faq_questions - ✅ MATCHES
'question_id': 1001,  # INTEGER ID
'question_txt': 'What is the annual leave policy?',
'source': 'test_data',
'src_file_name': 'Employee_Leave_Policy.pdf',
# ... all fields present

# faq_answers - ✅ MATCHES
'answer_id': 1001,  # INTEGER ID
'question_id': 1001,  # INTEGER FK
'faq_answer_txt': 'Employees accrue 15 days...',
# ... all fields present
```

### **Excel Loaders**

Excel files now load correctly without column mapping:

```python
df = pd.read_excel('content_repo.xlsx')
df.to_sql('content_repo', conn, if_exists='append', index=False)
# ✅ All 22 columns in Excel match schema
```

---

## 🚨 Remaining Issues in Notebook

### **1. Step Numbering Error** (MINOR)
- Cell 11 and Cell 9 both labeled "Step 5"
- Cell 13 jumps to "Step 7" (missing Step 6)
- **Fix:** Renumber cells sequentially

### **2. Commented Out Test Data** (INTENTIONAL?)
Cell 10 has commented code for:
- `generate_test_content_change_log()`
- `generate_test_faq_content_map()`
- `generate_test_content_diffs()`

**Status:** Tracking tables remain empty in test mode.
**Reason:** Per DELIVERY_SUMMARY.md, tracking tables populated by pipeline, not setup.

### **3. Log Message Accuracy** (MINOR)
Cell 12:
```python
log_success("Test data generated (all 7 tables)")  # ❌ Only 3 tables
```

**Fix:**
```python
log_success("Test data generated (3 base tables)")
log_info("Tracking tables empty - will be populated by pipeline")
```

---

## 📋 Migration Checklist

If migrating from old Schema v4.0 to updated version:

- [ ] Export existing data to CSV/DataFrames
- [ ] Map old column names to new names (created_at → created, etc.)
- [ ] Add NULL values for new fields in content_repo
- [ ] Re-import data using updated schema
- [ ] Run validation.sql to verify integrity
- [ ] Update any application code using old column names
- [ ] **Note:** No ID type conversion needed - schema uses INTEGER throughout

---

## ✅ Validation Steps

1. **Schema Creation:**
   ```bash
   sqlite3 faq_update.db < create_schema_v4.sql
   ```

2. **Test with Notebook Data:**
   - Run `setup_tables_enhanced.ipynb` with `DATA_SOURCE='test'`
   - Verify all 3 base tables populate without errors

3. **Test with Excel Data:**
   - Run `setup_tables_enhanced.ipynb` with `DATA_SOURCE='excel'`
   - Verify all Excel columns map correctly

4. **Foreign Key Validation:**
   ```sql
   PRAGMA foreign_key_check;
   -- Should return empty (no violations)
   ```

5. **View Validation:**
   - Test all 9 views can be queried
   - Verify no column reference errors

---

## 🎯 Benefits of Updated Schema

1. **✅ Matches Production Data** - No more column mapping needed
2. **✅ Preserves Version History** - prev_* fields track changes
3. **✅ Consistent IDs** - INTEGER IDs throughout for type safety and FK integrity
4. **✅ Rich Metadata** - Domain, service, product for filtering
5. **✅ Source Tracking** - Complete audit trail from source files
6. **✅ Organization Multi-tenancy** - orgoid field for isolation

---

## 📝 Notes

1. **Typo Preserved:** `recommeded_question_txt` - matches Excel source exactly
2. **INTEGER Page Numbers:** Changed from REAL to INTEGER for consistency with content_repo.raw_file_page_nbr and all tracking tables
3. **TEXT Timestamps:** Using Excel format, not SQLite's strftime
4. **Nullable Fields:** Most fields optional for flexibility
5. **Foreign Keys Still Work:** CASCADE/SET NULL behavior preserved

---

**Status:** ✅ Schema v4.0 updated and validated
**Notebook Compatibility:** ✅ 100% compatible
**Excel Compatibility:** ✅ 100% compatible
**Migration Required:** ⚠️ Yes, if upgrading from old v4.0

---

*End of Summary*
