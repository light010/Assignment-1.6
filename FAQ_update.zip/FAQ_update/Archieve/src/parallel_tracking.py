# parallel_tracking.py
import sqlite3
import pandas as pd
import hashlib
import json
from datetime import datetime
from pathlib import Path
import logging

class TimeSemantics:
    """
    Clear definitions for all temporal fields in the system.
    All times stored as ISO-8601 UTC strings: YYYY-MM-DDTHH:MM:SSZ
    """

    # When the change actually happened in the source system
    EFFECTIVE_AT = "effective_date"

    # When our pipeline detected/noticed the change
    DETECTED_AT = "detected_at"

    # When we wrote the record to our tracking database
    PROCESSED_AT = "processed_at"

def format_timestamp(dt: datetime) -> str:
    """Convert datetime to ISO-8601 UTC string."""
    if isinstance(dt, str):
        # Parse and reformat to ensure consistency
        dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')

class ParallelTrackingPipeline:
    """
    Runs new tracking system in parallel with existing system.
    Logs discrepancies for validation before cutover.
    """
    
    def __init__(self, content_db: str, old_tracking_db: str, new_tracking_db: str):
        self.content_db = content_db
        self.old_tracking_db = old_tracking_db
        self.new_tracking_db = new_tracking_db
        self.logger = self._setup_logging()
        
    def _setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('parallel_tracking.log'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)

    def validate_content_id(self, content_id: int) -> bool:
        """
        Validate content_id exists in content_repo.
        Required for cross-database foreign key enforcement.
        """
        with sqlite3.connect(self.content_db) as conn:
            result = conn.execute(
                "SELECT 1 FROM content_repo WHERE ud_source_file_id = ? LIMIT 1",
                (content_id,)
            ).fetchone()
            return result is not None

    def run_parallel_tracking(self, since_date: str):
        """Main entry point for parallel tracking."""
        self.logger.info(f"Starting parallel tracking since {since_date}")
        
        try:
            # 1. Load recent content changes
            recent_content = self._load_recent_content(since_date)
            
            # 2. Run old system (existing logic)
            old_results = self._run_old_system(recent_content)
            
            # 3. Run new system
            new_results = self._run_new_system(recent_content)
            
            # 4. Compare results
            discrepancies = self._compare_results(old_results, new_results)
            
            # 5. Log findings
            self._log_findings(discrepancies)
            
            return {
                'old_results': old_results,
                'new_results': new_results,
                'discrepancies': discrepancies,
                'status': 'completed'
            }
            
        except Exception as e:
            self.logger.error(f"Parallel tracking failed: {e}")
            raise
    
    def _load_recent_content(self, since_date: str) -> pd.DataFrame:
        """Load content modified since given date."""
        with sqlite3.connect(self.content_db) as conn:
            query = """
                SELECT * FROM content_repo
                WHERE last_modified_dt > ?
                ORDER BY last_modified_dt, raw_file_nme, raw_file_page_nbr
            """
            df = pd.read_sql(query, conn, params=[since_date])
            
        # Calculate checksums from actual files
        for idx, row in df.iterrows():
            if pd.notna(row['extracted_markdown_file_path']):
                checksum = self._calculate_checksum(row['extracted_markdown_file_path'])
                df.at[idx, 'calculated_checksum'] = checksum
                
        return df
    
    def _calculate_checksum(self, file_path: str) -> str:
        """Calculate SHA-256 checksum of file content."""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        except Exception as e:
            self.logger.warning(f"Failed to calculate checksum for {file_path}: {e}")
            return None
    
    def _run_new_system(self, content_df: pd.DataFrame) -> dict:
        """
        Run new tracking logic that properly classifies changes.
        """
        changes = {
            'content_edits': [],
            'position_changes': [],
            'new_content': [],
            'deletions': [],
            'structural_changes': []
        }
        
        # Group by file for document-level analysis
        for file_name, file_group in content_df.groupby('raw_file_nme'):
            file_changes = self._analyze_file_changes(file_name, file_group)
            
            # Aggregate results
            for change_type, items in file_changes.items():
                changes[change_type].extend(items)
                
        # Record in new database
        self._record_new_changes(changes)
        
        return changes
    
def _analyze_file_changes(self, file_name: str, content_df: pd.DataFrame) -> Dict:
    """
    Analyze changes for a single file with enhanced duplicate handling and 
    precise edit detection.
    """
    from collections import defaultdict
    
    # 0) Preflight hygiene - validate checksums
    for _, row in content_df.iterrows():
        checksum = row.get('calculated_checksum')
        if checksum and not self._validate_checksum_format(checksum):
            self.logger.warning(f"Invalid checksum format: {checksum}")
            
    # Load current state from tracking database
    with sqlite3.connect(self.tracking_db) as conn:
        current_state = pd.read_sql("""
            WITH latest_changes AS (
                SELECT
                    content_id,
                    page_number,
                    content_checksum,
                    change_type,
                    ROW_NUMBER() OVER (
                        PARTITION BY page_number
                        ORDER BY detected_at DESC, change_id DESC
                    ) as rn
                FROM content_change_log
                WHERE file_name = ?
            )
            SELECT content_id, page_number, content_checksum, change_type
            FROM latest_changes
            WHERE rn = 1 AND change_type != 'page_deleted'
        """, conn, params=[file_name])
    
    # Convert to lists for algorithm
    old_checksums = []  # Current state checksums by page index
    old_content_map = {}  # page_num -> content info
    
    # Build old state
    max_page = max(current_state['page_number'].max() if len(current_state) > 0 else 0,
                   content_df['raw_file_page_nbr'].max() if len(content_df) > 0 else 0)
    
    for page in range(1, max_page + 1):
        page_data = current_state[current_state['page_number'] == page]
        if len(page_data) > 0:
            checksum = page_data.iloc[0]['content_checksum']
            old_checksums.append(checksum)
            old_content_map[page] = page_data.iloc[0].to_dict()
        else:
            old_checksums.append(None)
    
    # Build new state
    new_checksums = []
    new_content_map = {}
    
    for page in range(1, max_page + 1):
        page_data = content_df[content_df['raw_file_page_nbr'] == page]
        if len(page_data) > 0:
            checksum = page_data.iloc[0]['calculated_checksum']
            new_checksums.append(checksum)
            new_content_map[page] = page_data.iloc[0].to_dict()
        else:
            new_checksums.append(None)
    
    # Run enhanced algorithm
    changes = self._run_enhanced_change_detection(
        old_checksums, 
        new_checksums, 
        old_content_map, 
        new_content_map,
        file_name
    )
    
    return changes

def _run_enhanced_change_detection(self, old: List, new: List, 
                                   old_map: Dict, new_map: Dict, 
                                   file_name: str) -> Dict:
    """
    Enhanced change detection with duplicate handling and precise classification.
    """
    from collections import defaultdict
    
    changes = {
        'content_edits': [],
        'position_changes': [],
        'new_content': [],
        'deletions': [],
        'structural_changes': []
    }
    
    # 1) Build multiset indices (support duplicates)
    old_idx = defaultdict(list)  # checksum -> [positions...]
    new_idx = defaultdict(list)  # checksum -> [positions...]
    
    for i, checksum in enumerate(old):
        if checksum:
            old_idx[checksum].append(i + 1)  # Convert to 1-based page numbers
            
    for j, checksum in enumerate(new):
        if checksum:
            new_idx[checksum].append(j + 1)
    
    # 2) Greedy nearest matching for duplicates
    matches = []
    
    for checksum in sorted(set(old_idx) & set(new_idx)):
        old_positions = sorted(old_idx[checksum])
        new_positions = sorted(new_idx[checksum])
        
        # Greedy nearest-neighbor matching
        i = j = 0
        while i < len(old_positions) and j < len(new_positions):
            o = old_positions[i]
            n = new_positions[j]
            
            # Look ahead to see if next positions are closer
            go_next_old = (i + 1 < len(old_positions) and 
                          abs(old_positions[i + 1] - n) < abs(o - n))
            go_next_new = (j + 1 < len(new_positions) and 
                          abs(o - new_positions[j + 1]) < abs(o - n))
            
            if go_next_old:
                i += 1
                continue
            if go_next_new:
                j += 1
                continue
                
            matches.append((o, n, checksum))
            i += 1
            j += 1
    
    # 3) Classify matches
    for old_page, new_page, checksum in matches:
        if old_page == new_page:
            # UNCHANGED - no action needed
            pass
        else:
            # POSITION_CHANGE
            old_info = old_map.get(old_page, {})
            new_info = new_map.get(new_page, {})
            
            changes['position_changes'].append({
                'content_id': new_info.get('ud_source_file_id'),
                'checksum': checksum,
                'from_page': old_page,
                'to_page': new_page,
                'file_name': file_name,
                'detected_at': new_info.get('last_modified_dt', datetime.now().isoformat())
            })
    
    # 4) Account for pure deletes/inserts
    matched_old = {o for o, _, _ in matches}
    matched_new = {n for _, n, _ in matches}

    # FIXED: Detect true deletions - only if checksum is completely gone from new document
    # Build set of all checksums that still exist in new document
    new_checksums = set(new_idx.keys())

    # Only mark as deleted if checksum doesn't exist anywhere in new document
    for checksum in set(old_idx) - new_checksums:
        for page in old_idx[checksum]:
            old_info = old_map.get(page, {})
            changes['deletions'].append({
                'content_id': old_info.get('content_id'),
                'page_number': page,
                'checksum': checksum,
                'file_name': file_name,
                'detected_at': datetime.now().isoformat()
            })
    
    # Checksums that exist only in new (insertions)
    for checksum in set(new_idx) - set(old_idx):
        for page in new_idx[checksum]:
            if page not in matched_new:
                new_info = new_map.get(page, {})
                changes['new_content'].append({
                    'content_id': new_info.get('ud_source_file_id'),
                    'page_number': page,
                    'checksum': checksum,
                    'file_name': file_name,
                    'detected_at': new_info.get('last_modified_dt', datetime.now().isoformat())
                })
    
    # 5) Detect true edits
    m = min(len(old), len(new))
    for p in range(1, m + 1):
        c_old = old[p - 1]  # Convert to 0-based
        c_new = new[p - 1]
        
        if c_old == c_new or not c_old or not c_new:
            continue
            
        # Check if old checksum still exists anywhere in new
        if c_old in new_idx:
            # Old content moved elsewhere, not an edit
            continue
            
        # Check if new checksum already existed in old
        if c_new in old_idx:
            # Content moved here from elsewhere, not an edit
            continue
            
        # True edit: old content gone, new content is brand new
        old_info = old_map.get(p, {})
        new_info = new_map.get(p, {})
        
        changes['content_edits'].append({
            'content_id': new_info.get('ud_source_file_id'),
            'page_number': p,
            'old_checksum': c_old,
            'new_checksum': c_new,
            'previous_content_id': old_info.get('content_id'),
            'file_name': file_name,
            'detected_at': new_info.get('last_modified_dt', datetime.now().isoformat())
        })
    
    # 6) Detect and compress bulk operations
    if changes['position_changes']:
        bulk_ops = self._detect_bulk_operations(changes['position_changes'])
        if bulk_ops:
            changes['structural_changes'].extend(bulk_ops)
    
    return changes

def _detect_bulk_operations(self, position_changes: List[Dict]) -> List[Dict]:
    """
    Detect bulk operations like page insertions causing cascading moves.
    """
    structural_changes = []
    
    # Group moves by their delta (to_page - from_page)
    delta_groups = defaultdict(list)
    for move in position_changes:
        delta = move['to_page'] - move['from_page']
        delta_groups[delta].append(move)
    
    # Look for patterns
    for delta, moves in delta_groups.items():
        if len(moves) >= 3:  # At least 3 pages moving by same amount
            # Sort by original position
            moves_sorted = sorted(moves, key=lambda x: x['from_page'])
            
            # Check if they form a contiguous sequence
            is_contiguous = all(
                moves_sorted[i + 1]['from_page'] - moves_sorted[i]['from_page'] == 1
                for i in range(len(moves_sorted) - 1)
            )
            
            if is_contiguous:
                # This looks like a bulk operation
                if delta > 0:
                    # Pages moved forward - likely insertion before them
                    structural_changes.append({
                        'type': 'page_insertion',
                        'file_name': moves[0]['file_name'],
                        'inserted_at': moves_sorted[0]['from_page'],
                        'pages_shifted': len(moves),
                        'shift_amount': delta,
                        'cascading_moves': moves_sorted,
                        'detected_at': moves[0]['detected_at']
                    })
                elif delta < 0:
                    # Pages moved backward - likely deletion before them
                    structural_changes.append({
                        'type': 'page_deletion', 
                        'file_name': moves[0]['file_name'],
                        'deleted_at': moves_sorted[0]['from_page'] + delta,
                        'pages_shifted': len(moves),
                        'shift_amount': delta,
                        'cascading_moves': moves_sorted,
                        'detected_at': moves[0]['detected_at']
                    })
    
    # Use LIS for more complex reordering detection
    if len(position_changes) > 5:
        lis_result = self._find_lis_in_moves(position_changes)
        if lis_result and lis_result['reordered_count'] > 3:
            structural_changes.append({
                'type': 'pages_reordered',
                'file_name': position_changes[0]['file_name'],
                'total_pages_affected': len(position_changes),
                'pages_maintaining_order': len(lis_result['lis']),
                'pages_reordered': lis_result['reordered_count'],
                'detected_at': position_changes[0]['detected_at']
            })
    
    return structural_changes

def _find_lis_in_moves(self, moves: List[Dict]) -> Optional[Dict]:
    """
    Find Longest Increasing Subsequence in page moves to detect reordering.
    """
    # Sort by original position
    sorted_moves = sorted(moves, key=lambda x: x['from_page'])
    
    # Extract new positions in order of old positions
    new_positions = [m['to_page'] for m in sorted_moves]
    
    # Find LIS
    n = len(new_positions)
    if n == 0:
        return None
        
    # Dynamic programming for LIS
    dp = [1] * n
    parent = [-1] * n
    
    for i in range(1, n):
        for j in range(i):
            if new_positions[j] < new_positions[i] and dp[j] + 1 > dp[i]:
                dp[i] = dp[j] + 1
                parent[i] = j
    
    # Find the longest
    max_length = max(dp)
    max_idx = dp.index(max_length)
    
    # Reconstruct LIS
    lis = []
    idx = max_idx
    while idx != -1:
        lis.append(sorted_moves[idx])
        idx = parent[idx]
    lis.reverse()
    
    return {
        'lis': lis,
        'lis_length': max_length,
        'total_moves': len(moves),
        'reordered_count': len(moves) - max_length
    }

def _validate_checksum_format(self, checksum: str) -> bool:
    """Validate checksum is proper SHA-256 format."""
    return (
        checksum and 
        len(checksum) == 64 and 
        all(c in '0123456789abcdef' for c in checksum.lower())
    )

    def _record_change_idempotent(self, conn: sqlite3.Connection,
                                   change_type: str, change_data: dict):
        """
        Record change with idempotency guarantee (Fix 8).
        Uses INSERT OR IGNORE to handle duplicates gracefully.

        IMPORTANT: Proper time semantics:
        - effective_date = when change occurred in source (from last_modified_dt)
        - detected_at = when pipeline detected it (use format_timestamp(datetime.now()))
        """
        # Use INSERT OR IGNORE to handle duplicates gracefully
        query = """
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_content_id, previous_page_number,
                previous_checksum, change_trigger, effective_date, detected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        # Get current timestamp for detected_at (when we're detecting this NOW)
        detected_at_now = format_timestamp(datetime.now())

        cursor = conn.execute(query, (
            change_data['content_id'],
            change_data['file_name'],
            change_data['page_number'],
            change_data.get('checksum') or change_data.get('new_checksum'),
            change_type,
            change_data.get('previous_content_id'),
            change_data.get('previous_page_number') or change_data.get('from_page'),
            change_data.get('previous_checksum') or change_data.get('old_checksum'),
            change_data.get('change_trigger', 'automated'),
            change_data.get('effective_date', change_data.get('detected_at')),  # Prefer effective_date
            detected_at_now  # When pipeline is detecting it NOW
        ))

        # Check if insert was successful or ignored
        if cursor.rowcount == 0:
            self.logger.debug(
                f"Duplicate change ignored: {change_type} for "
                f"{change_data['file_name']} page {change_data['page_number']}"
            )
            return None

        change_id = cursor.lastrowid

        # If this is a deletion, invalidate affected FAQ mappings
        if change_type == 'page_deleted' and change_id:
            checksum = change_data.get('checksum') or change_data.get('previous_checksum')
            if checksum:
                conn.execute("""
                    UPDATE faq_content_map
                    SET is_valid = 0,
                        valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                        invalidation_reason = 'content_deleted',
                        invalidated_by_change_id = ?
                    WHERE content_checksum = ?
                      AND is_valid = 1
                """, (change_id, checksum))

        return change_id

    def _record_change_with_validation(self, conn: sqlite3.Connection, change_data: dict):
        """
        Record change with cross-DB validation.
        Validates content_id exists in content_repo before inserting.

        IMPORTANT: Proper time semantics:
        - effective_date = when change occurred in source (from last_modified_dt)
        - detected_at = when pipeline detected it (set to now())
        """
        # Validate FK constraint in code (since cross-DB FK not supported)
        if not self.validate_content_id(change_data['content_id']):
            raise ValueError(f"Invalid content_id: {change_data['content_id']}")

        # Get current time for detected_at (when we're recording this)
        detected_at_now = format_timestamp(datetime.now())

        # Proceed with insert based on change type
        if change_data['change_type'] == 'content_edit':
            conn.execute("""
                INSERT INTO content_change_log (
                    content_id, file_name, page_number, content_checksum,
                    change_type, previous_content_id, previous_checksum,
                    effective_date, detected_at
                ) VALUES (?, ?, ?, ?, 'content_edit', ?, ?, ?, ?)
            """, (
                change_data['content_id'], change_data['file_name'],
                change_data['page_number'], change_data['new_checksum'],
                change_data['previous_content_id'], change_data['old_checksum'],
                change_data['effective_date'],  # From source last_modified_dt
                detected_at_now  # When pipeline detected it
            ))
        elif change_data['change_type'] == 'position_change':
            conn.execute("""
                INSERT INTO content_change_log (
                    content_id, file_name, page_number, content_checksum,
                    change_type, previous_page_number,
                    effective_date, detected_at
                ) VALUES (?, ?, ?, ?, 'position_change', ?, ?, ?)
            """, (
                change_data['content_id'], change_data['file_name'],
                change_data['to_page'], change_data['checksum'],
                change_data['from_page'],
                change_data['effective_date'],  # From source last_modified_dt
                detected_at_now  # When pipeline detected it
            ))
        elif change_data['change_type'] == 'initial_creation':
            conn.execute("""
                INSERT INTO content_change_log (
                    content_id, file_name, page_number, content_checksum,
                    change_type, effective_date, detected_at
                ) VALUES (?, ?, ?, ?, 'initial_creation', ?, ?)
            """, (
                change_data['content_id'], change_data['file_name'],
                change_data['page_number'], change_data['checksum'],
                change_data['effective_date'],  # From source last_modified_dt
                detected_at_now  # When pipeline detected it
            ))

    def _record_new_changes(self, changes: dict):
        """
        Record changes in new tracking database.

        IMPORTANT: Proper time semantics:
        - effective_date = when change occurred in source (from last_modified_dt in change data)
        - detected_at = when pipeline detected it (set to now())
        """
        detected_at_now = format_timestamp(datetime.now())

        with sqlite3.connect(self.new_tracking_db) as conn:
            # Record content edits
            for edit in changes['content_edits']:
                conn.execute("""
                    INSERT INTO content_change_log (
                        content_id, file_name, page_number, content_checksum,
                        change_type, previous_content_id, previous_checksum,
                        effective_date, detected_at
                    ) VALUES (?, ?, ?, ?, 'content_edit', ?, ?, ?, ?)
                """, (
                    edit['content_id'], edit['file_name'], edit['page_number'],
                    edit['new_checksum'], edit['previous_content_id'],
                    edit['old_checksum'],
                    edit.get('effective_date', edit.get('detected_at')),  # Prefer effective_date
                    detected_at_now  # When we're detecting it NOW
                ))

            # Record position changes
            for move in changes['position_changes']:
                conn.execute("""
                    INSERT INTO content_change_log (
                        content_id, file_name, page_number, content_checksum,
                        change_type, previous_page_number,
                        effective_date, detected_at
                    ) VALUES (?, ?, ?, ?, 'position_change', ?, ?, ?)
                """, (
                    move['content_id'], move['file_name'], move['to_page'],
                    move['checksum'], move['from_page'],
                    move.get('effective_date', move.get('detected_at')),  # Prefer effective_date
                    detected_at_now  # When we're detecting it NOW
                ))

            # Record new content
            for new in changes['new_content']:
                conn.execute("""
                    INSERT INTO content_change_log (
                        content_id, file_name, page_number, content_checksum,
                        change_type, effective_date, detected_at
                    ) VALUES (?, ?, ?, ?, 'initial_creation', ?, ?)
                """, (
                    new['content_id'], new['file_name'], new['page_number'],
                    new['checksum'],
                    new.get('effective_date', new.get('detected_at')),  # Prefer effective_date
                    detected_at_now  # When we're detecting it NOW
                ))

            # Record deletions
            for deletion in changes.get('deletions', []):
                # Insert the deletion record
                cursor = conn.execute("""
                    INSERT INTO content_change_log (
                        content_id, file_name, page_number, content_checksum,
                        change_type, previous_content_id, previous_page_number,
                        previous_checksum, change_trigger, effective_date, detected_at
                    ) VALUES (?, ?, ?, ?, 'page_deleted', ?, ?, ?, ?, ?, ?)
                """, (
                    deletion.get('content_id'),
                    deletion['file_name'],
                    deletion['page_number'],
                    deletion['checksum'],
                    deletion.get('previous_content_id'),
                    deletion.get('previous_page_number'),
                    deletion.get('previous_checksum'),
                    deletion.get('change_trigger', 'automated'),
                    deletion.get('effective_date', deletion.get('detected_at')),
                    detected_at_now
                ))
                change_id = cursor.lastrowid

                # Invalidate affected FAQ mappings (content disappeared)
                conn.execute("""
                    UPDATE faq_content_map
                    SET is_valid = 0,
                        valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                        invalidation_reason = 'content_deleted',
                        invalidated_by_change_id = ?
                    WHERE content_checksum = ?
                      AND is_valid = 1
                """, (change_id, deletion['checksum']))

            # Note: Structural changes are now derived via v_document_structure_changes VIEW
            # No need to explicitly record them - they're automatically computed from
            # position_change records in content_change_log
            # The VIEW aggregates cascading moves into bulk operations (insertions/deletions)

            conn.commit()
    
    def _compare_results(self, old_results: dict, new_results: dict) -> list:
        """Compare results between old and new systems."""
        discrepancies = []
        
        # Compare version creation counts
        old_versions_created = len(old_results.get('new_versions', []))
        new_changes_recorded = (
            len(new_results['content_edits']) +
            len(new_results['new_content'])
        )
        
        if old_versions_created != new_changes_recorded:
            discrepancies.append({
                'type': 'version_count_mismatch',
                'old_system': old_versions_created,
                'new_system': new_changes_recorded,
                'details': 'Different number of versions created'
            })
        
        # Check for position changes (new system tracks, old doesn't)
        if new_results['position_changes']:
            discrepancies.append({
                'type': 'position_tracking',
                'count': len(new_results['position_changes']),
                'details': 'New system tracks position changes, old system does not'
            })
        
        return discrepancies
    
    def _log_findings(self, discrepancies: list):
        """Log comparison findings."""
        if not discrepancies:
            self.logger.info("No discrepancies found between old and new systems")
        else:
            self.logger.warning(f"Found {len(discrepancies)} discrepancies:")
            for d in discrepancies:
                self.logger.warning(f"  - {d['type']}: {d['details']}")


# Usage
if __name__ == "__main__":
    pipeline = ParallelTrackingPipeline(
        content_db='content_repo.db',
        old_tracking_db='version_tracking.db',
        new_tracking_db='version_tracking_new.db'
    )
    
    results = pipeline.run_parallel_tracking('2025-01-01T00:00:00Z')
    print(f"Parallel tracking completed with {len(results['discrepancies'])} discrepancies")