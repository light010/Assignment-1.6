# migrate_faq_links.py
import sqlite3
import pandas as pd
import logging
from datetime import datetime

class FAQLinkMigration:
    """
    Migrate FAQ links from version-based to checksum-based tracking.
    """
    
    def __init__(self, old_db: str, new_db: str, content_db: str):
        self.old_db = old_db
        self.new_db = new_db
        self.content_db = content_db
        self.logger = logging.getLogger(__name__)
        
    def migrate_all_links(self, batch_size: int = 1000):
        """Migrate all FAQ links to new schema."""
        self.logger.info("Starting FAQ link migration")
        
        # Get total count
        with sqlite3.connect(self.old_db) as conn:
            total_count = pd.read_sql(
                "SELECT COUNT(*) as count FROM faq_content_link", 
                conn
            ).iloc[0]['count']
            
        self.logger.info(f"Migrating {total_count} FAQ links")
        
        # Process in batches
        migrated = 0
        failed = 0
        
        for offset in range(0, total_count, batch_size):
            batch_result = self._migrate_batch(offset, batch_size)
            migrated += batch_result['success']
            failed += batch_result['failed']
            
            self.logger.info(
                f"Progress: {migrated + failed}/{total_count} "
                f"(Success: {migrated}, Failed: {failed})"
            )
        
        self.logger.info(
            f"Migration completed. "
            f"Success: {migrated}, Failed: {failed}"
        )
        
        return {
            'total': total_count,
            'migrated': migrated,
            'failed': failed
        }
    
    def _migrate_batch(self, offset: int, limit: int) -> dict:
        """Migrate a batch of FAQ links."""
        # Load batch from old system
        with sqlite3.connect(self.old_db) as old_conn:
            query = """
                SELECT 
                    fcl.*,
                    cvh.content_id,
                    cvh.file_name,
                    cvh.page_number,
                    cvh.content_checksum
                FROM faq_content_link fcl
                JOIN content_version_history cvh 
                    ON fcl.version_history_id = cvh.version_history_id
                LIMIT ? OFFSET ?
            """
            batch = pd.read_sql(query, old_conn, params=[limit, offset])
        
        success = 0
        failed = 0
        
        with sqlite3.connect(self.new_db) as new_conn:
            for _, row in batch.iterrows():
                try:
                    # Get current location from content_repo
                    current_info = self._get_current_location(
                        row['file_name'], 
                        row['page_number']
                    )
                    
                    # Insert into new schema
                    new_conn.execute("""
                        INSERT INTO faq_content_map (
                            question_id, answer_id, content_checksum,
                            current_content_id, current_page_number, current_file_name,
                            original_content_id, original_page_number,
                            created_for_version,
                            is_valid, valid_from, valid_until,
                            invalidation_reason,
                            confidence_score, generation_method,
                            created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        row['question_id'],
                        row['answer_id'],
                        row['content_checksum'],
                        current_info['content_id'] if current_info else row['content_id'],
                        current_info['page_number'] if current_info else row['page_number'],
                        row['file_name'],
                        row['content_id'],
                        row['page_number'],
                        row['valid_from_version'],
                        1 if row['is_currently_valid'] else 0,
                        row['generated_at'],
                        row['deprecated_at'],
                        row['deprecated_reason'],
                        row['confidence_score'],
                        row['generation_method'],
                        row['generated_at']
                    ))
                    success += 1
                    
                except Exception as e:
                    self.logger.error(
                        f"Failed to migrate link_id {row['link_id']}: {e}"
                    )
                    failed += 1
            
            new_conn.commit()
        
        return {'success': success, 'failed': failed}
    
    def _get_current_location(self, file_name: str, page_number: int) -> dict:
        """Get current location of content."""
        with sqlite3.connect(self.content_db) as conn:
            query = """
                SELECT ud_source_file_id as content_id, raw_file_page_nbr as page_number
                FROM content_repo
                WHERE raw_file_nme = ? 
                AND raw_file_page_nbr = ?
                AND file_status = 'Active'
                ORDER BY last_modified_dt DESC
                LIMIT 1
            """
            result = pd.read_sql(query, conn, params=[file_name, page_number])
            
            if len(result) > 0:
                return result.iloc[0].to_dict()
            return None
    
    def validate_migration(self):
        """Validate the migration was successful."""
        validations = []
        
        # Check record counts
        with sqlite3.connect(self.old_db) as old_conn:
            old_count = pd.read_sql(
                "SELECT COUNT(*) as count FROM faq_content_link",
                old_conn
            ).iloc[0]['count']
            
        with sqlite3.connect(self.new_db) as new_conn:
            new_count = pd.read_sql(
                "SELECT COUNT(*) as count FROM faq_content_map",
                new_conn
            ).iloc[0]['count']
            
        validations.append({
            'check': 'record_count',
            'old_system': old_count,
            'new_system': new_count,
            'passed': old_count == new_count
        })
        
        # Check checksum integrity
        with sqlite3.connect(self.new_db) as conn:
            invalid_checksums = pd.read_sql("""
                SELECT COUNT(*) as count
                FROM faq_content_map
                WHERE length(content_checksum) != 64
            """, conn).iloc[0]['count']
            
        validations.append({
            'check': 'checksum_integrity',
            'invalid_count': invalid_checksums,
            'passed': invalid_checksums == 0
        })
        
        return validations