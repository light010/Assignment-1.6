# Complete Implementation Plan: setup_tables_enhanced.ipynb

## 📋 Executive Summary

This document details the complete implementation of `setup_tables_enhanced.ipynb` - a production-ready notebook that combines:
- Schema v4.0 (single database architecture)
- Dual data source system (excel + test)
- Comprehensive data validation
- All features from setup_databases.ipynb
- Enhanced error handling and logging

---

## 🎯 Complete Cell Structure (22 Cells)

### **Cell 1: Introduction (Markdown)**
✅ **DONE** - Comprehensive overview with benefits table

### **Cell 2: Configuration (Code)**
✅ **DONE** - All paths, DATA_SOURCE config, display settings

### **Cell 3: Utility Functions (Code)**
✅ **DONE** - calculate_checksum, format_timestamp, create_markdown_file, compress_diff, etc.

---

### **Cell 4: Excel Data Loaders (Code)** ⏳ TODO

```python
# ============================================================================
# 📊 EXCEL DATA LOADERS
# ============================================================================

def load_content_repo_from_excel() -> pd.DataFrame:
    \"\"\"
    Load content_repo from Excel file with validation.

    Expected columns from old schema (map to new):
    - ud_source_file_id
    - raw_file_nme
    - raw_file_page_nbr
    - extracted_markdown_file_path
    - last_modified_dt
    - created_dt
    - file_size_bytes (optional)
    - content_type (optional, default='pdf')
    - processing_status (optional, default='completed')
    \"\"\"
    log_info(f\"Loading {CONTENT_REPO_XLSX.name}...\")

    if not CONTENT_REPO_XLSX.exists():
        log_error(f\"File not found: {CONTENT_REPO_XLSX}\")\n        raise FileNotFoundError(f\"Excel file not found: {CONTENT_REPO_XLSX}\")\n
    df = pd.read_excel(CONTENT_REPO_XLSX)
    log_success(f\"Loaded {len(df)} records from Excel\")\n
    # Validate required columns
    required_cols = ['ud_source_file_id', 'raw_file_nme', 'raw_file_page_nbr']
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        log_error(f\"Missing required columns: {missing}\")\n        raise ValueError(f\"Missing columns: {missing}\")\n
    # Add defaults for optional columns
    if 'content_type' not in df.columns:
        df['content_type'] = 'pdf'
    if 'processing_status' not in df.columns:
        df['processing_status'] = 'completed'
    if 'created_dt' not in df.columns:
        df['created_dt'] = format_timestamp()
    if 'last_modified_dt' not in df.columns:
        df['last_modified_dt'] = format_timestamp()

    log_success(f\"Validated content_repo data: {len(df)} records ready\")\n    return df

def load_faq_questions_from_excel() -> pd.DataFrame:
    \"\"\"
    Load faq_questions from Excel with deduplication.

    Maps old schema to new:
    - question_id (keep if exists, generate if not)
    - question_txt (required)
    - category (from domain)
    - priority (default=0)
    - is_active (default=1)
    - created_at (from created or now)
    \"\"\"
    log_info(f\"Loading {FAQ_QUESTION_XLSX.name}...\")

    if not FAQ_QUESTION_XLSX.exists():
        log_error(f\"File not found: {FAQ_QUESTION_XLSX}\")\n        raise FileNotFoundError(f\"Excel file not found: {FAQ_QUESTION_XLSX}\")\n
    df = pd.read_excel(FAQ_QUESTION_XLSX)
    log_success(f\"Loaded {len(df)} records from Excel\")\n
    # Map columns
    result = pd.DataFrame()

    # Required fields
    if 'question_txt' in df.columns:
        result['question_txt'] = df['question_txt']
    else:
        log_error(\"Missing required column: question_txt\")\n        raise ValueError(\"question_txt column required\")\n
    # Optional fields with defaults
    result['question_id'] = df['question_id'] if 'question_id' in df.columns else range(1, len(df) + 1)
    result['category'] = df.get('domain', df.get('category', None))
    result['priority'] = df.get('priority', 0)
    result['is_active'] = 1
    result['created_at'] = df.get('created', format_timestamp())
    result['updated_at'] = df.get('modified', None)
    result['created_by'] = df.get('created_by', 'excel_import')

    # Deduplicate by question_txt
    before = len(result)
    result = result.drop_duplicates(subset=['question_txt'], keep='first')
    after = len(result)
    if before > after:
        log_warning(f\"Removed {before - after} duplicate questions\")\n
    log_success(f\"Validated faq_questions data: {after} unique records ready\")\n    return result

def load_faq_answers_from_excel() -> pd.DataFrame:
    \"\"\"
    Load faq_answers from Excel.

    Maps old schema to new:
    - answer_id
    - faq_answer_txt (required)
    - answer_format (default='text')
    - is_active (default=1)
    - word_count (calculate if not provided)
    \"\"\"
    log_info(f\"Loading {FAQ_ANSWER_XLSX.name}...\")

    if not FAQ_ANSWER_XLSX.exists():
        log_error(f\"File not found: {FAQ_ANSWER_XLSX}\")\n        raise FileNotFoundError(f\"Excel file not found: {FAQ_ANSWER_XLSX}\")\n
    df = pd.read_excel(FAQ_ANSWER_XLSX)
    log_success(f\"Loaded {len(df)} records from Excel\")\n
    # Map columns
    result = pd.DataFrame()

    if 'faq_answer_txt' in df.columns:
        result['faq_answer_txt'] = df['faq_answer_txt']
    else:
        log_error(\"Missing required column: faq_answer_txt\")\n        raise ValueError(\"faq_answer_txt column required\")\n
    result['answer_id'] = df['answer_id'] if 'answer_id' in df.columns else range(1, len(df) + 1)
    result['answer_format'] = df.get('answer_format', 'text')
    result['is_active'] = 1
    result['word_count'] = result['faq_answer_txt'].str.split().str.len()
    result['created_at'] = df.get('created', format_timestamp())
    result['updated_at'] = df.get('modified', None)
    result['created_by'] = df.get('created_by', 'excel_import')

    log_success(f\"Validated faq_answers data: {len(result)} records ready\")\n    return result

log_success(\"Excel loader functions defined\")
```

---

### **Cell 5: Test Data Generators - Base Tables (Code)** ⏳ TODO

```python
# ============================================================================
# 🧪 TEST DATA GENERATORS - BASE TABLES
# ============================================================================

def generate_test_content_repo() -> pd.DataFrame:
    \"\"\"
    Generate comprehensive test data for content_repo with real markdown files.
    Creates 3 pages from Employee Leave Policy with checksums.
    \"\"\"
    log_info(\"Generating test data for content_repo...\")

    # Create markdown directory
    markdown_dir = TEST_DATA_DIR / 'markdown_files' / 'leave_policy'
    markdown_dir.mkdir(parents=True, exist_ok=True)

    # Policy content (realistic)
    policy_pages = {
        1: \"\"\"# Employee Leave Policy

## 1. Purpose
This policy establishes guidelines for employee leave requests and approvals.

## 2. Scope
This policy applies to all full-time employees.

## 3. Annual Leave
- Employees accrue 15 days of annual leave per year
- Leave must be requested at least 2 weeks in advance
- Maximum carryover: 5 days to next year
\"\"\",
        2: \"\"\"## 4. Sick Leave
Employees are entitled to sick leave as follows:
- 10 days of paid sick leave per year
- Medical certificate required for absences over 3 consecutive days
- Unused sick leave does not carry over

## 5. Parental Leave
- 12 weeks of paid parental leave for primary caregiver
- 4 weeks of paid parental leave for secondary caregiver
\"\"\",
        3: \"\"\"## 6. Bereavement Leave
- 5 days for immediate family member
- 2 days for extended family member
- No documentation required

## 7. Leave Request Process
1. Submit request via HR portal
2. Manager approval required
3. Confirmation sent within 48 hours
\"\"\"
    }

    # Create records
    records = []
    base_time = datetime(2025, 1, 1, 10, 0, 0)

    for page_num, content in policy_pages.items():
        # Create markdown file
        md_path = markdown_dir / f'page{page_num}_v1.md'
        checksum = create_markdown_file(md_path, content)

        records.append({
            'ud_source_file_id': 1000 + page_num,
            'raw_file_nme': 'Employee_Leave_Policy.pdf',
            'raw_file_page_nbr': page_num,
            'extracted_markdown_file_path': str(md_path.absolute()),
            'last_modified_dt': format_timestamp(base_time),
            'created_dt': format_timestamp(base_time),
            'file_size_bytes': len(content),
            'content_type': 'pdf',
            'processing_status': 'completed'
        })

    df = pd.DataFrame(records)
    log_success(f\"Generated {len(df)} content_repo records with markdown files\")\n    return df

def generate_test_faq_questions() -> pd.DataFrame:
    \"\"\"
    Generate 10 comprehensive test questions covering all 3 pages.
    \"\"\"
    log_info(\"Generating test data for faq_questions...\")

    now = format_timestamp()

    questions = [
        # Page 1 questions (Annual Leave)
        (1, 'What is the annual leave policy?', 'Leave', 1, 1),
        (2, 'How many annual leave days do I get per year?', 'Leave', 1, 1),
        (3, 'Can I carry over unused annual leave to next year?', 'Leave', 1, 1),

        # Page 2 questions (Sick + Parental Leave)
        (4, 'How many sick leave days do employees get?', 'Leave', 2, 2),
        (5, 'When do I need a medical certificate for sick leave?', 'Leave', 2, 2),
        (6, 'What is the parental leave policy?', 'Leave', 3, 2),
        (7, 'How much parental leave do primary caregivers get?', 'Leave', 3, 2),

        # Page 3 questions (Bereavement + Process)
        (8, 'What is the bereavement leave policy?', 'Leave', 3, 3),
        (9, 'How do I request leave?', 'Leave', 1, 3),
        (10, 'How long does it take to get leave approval?', 'Leave', 1, 3),
    ]

    records = []
    for q_id, q_txt, cat, priority, page in questions:
        records.append({
            'question_id': q_id,
            'question_txt': q_txt,
            'category': cat,
            'priority': priority,
            'is_active': 1,
            'created_at': now,
            'updated_at': None,
            'created_by': 'test_generator'
        })

    df = pd.DataFrame(records)
    log_success(f\"Generated {len(df)} faq_questions (covering all pages)\")\n    return df

def generate_test_faq_answers() -> pd.DataFrame:
    \"\"\"
    Generate 10 comprehensive test answers matching questions.
    \"\"\"
    log_info(\"Generating test data for faq_answers...\")

    now = format_timestamp()

    answers = [
        (1, 'Employees accrue 15 days of annual leave per year. Leave must be requested at least 2 weeks in advance, and a maximum of 5 days can be carried over to the next year.'),
        (2, 'All full-time employees accrue 15 days of annual leave per year.'),
        (3, 'Yes, you can carry over unused annual leave to the next year, with a maximum carryover of 5 days.'),
        (4, 'Employees are entitled to 10 days of paid sick leave per year. A medical certificate is required for absences over 3 consecutive days.'),
        (5, 'A medical certificate is required for sick leave absences that exceed 3 consecutive days.'),
        (6, 'Primary caregivers receive 12 weeks of paid parental leave, while secondary caregivers receive 4 weeks of paid parental leave.'),
        (7, 'Primary caregivers are entitled to 12 weeks of paid parental leave.'),
        (8, 'Bereavement leave provides 5 days for immediate family members and 2 days for extended family members. No documentation is required.'),
        (9, 'To request leave: 1) Submit request via HR portal, 2) Obtain manager approval, 3) Receive confirmation within 48 hours.'),
        (10, 'Leave approval confirmation is sent within 48 hours of submission, after manager approval.'),
    ]

    records = []
    for a_id, a_txt in answers:
        records.append({
            'answer_id': a_id,
            'faq_answer_txt': a_txt,
            'answer_format': 'text',
            'is_active': 1,
            'word_count': len(a_txt.split()),
            'created_at': now,
            'updated_at': None,
            'created_by': 'test_generator'
        })

    df = pd.DataFrame(records)
    log_success(f\"Generated {len(df)} faq_answers\")\n    return df

log_success(\"Test data generator functions (base tables) defined\")
```

---

This is getting very long. Would you like me to:

1. **Continue with the complete 22-cell detailed spec** (will be ~5000+ lines)
2. **Create a working enhanced notebook** with all cells implemented
3. **Create a comprehensive README** showing what each cell does

Which approach would be most valuable for you?