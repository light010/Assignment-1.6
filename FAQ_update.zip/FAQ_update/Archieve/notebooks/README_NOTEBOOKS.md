# Version Tracking Notebooks

This directory contains Jupyter notebooks for working with the content version tracking system. Each notebook serves a specific purpose in the workflow.

## ⚠️ Important Data Source Clarification

**The system uses databases ONLY (no CSV files in daily operations):**

### Data Flow:
1. ✅ **Excel → Databases** (via setup_databases.ipynb - ONE TIME):
   - content_repo.xlsx → content_repo.db
   - faq_question.xlsx → faq_question.db
   - faq_answer.xlsx → faq_answer.db
   - schema_content_version_tracking.sql → version_tracking.db (empty schema)

2. ✅ **Daily Pipeline** (daily_version_tracking_pipeline.ipynb):
   - Reads from content_repo.db (NOT CSV!)
   - Calculates checksums from actual markdown files
   - Loads existing versions from version_tracking.db
   - Loads FAQ data from faq_question.db and faq_answer.db
   - Compares checksums → detects changes → writes to version_tracking.db

### How Daily Pipeline Works:
1. Reads **metadata** from content_repo.db (file names, page numbers, last_modified_dt, markdown file paths)
2. Calculates **checksums** from actual markdown files (NOT from database!)
3. Loads **existing versions** from version_tracking.db
4. Loads **FAQ data** from faq_question.db and faq_answer.db
5. Compares checksums → detects changes → writes to version_tracking.db

---

## Notebooks Overview

### 1. setup_databases.ipynb (Initial Setup)
**Purpose**: One-time database initialization from Excel files

**Use this when you want to:**
- Set up the project for the first time
- Refresh base data (content_repo, faq_question, faq_answer)
- Reset databases to clean state
- Create all database structures from source Excel files

**Key Features:**
- Creates `databases/` directory structure
- Loads data from Excel files in `Docs/`
- Creates separate databases:
  - `content_repo.db` (from content_repo.csv.xlsx)
  - `faq_question.db` (from faq_question.csv.xlsx)
  - `faq_answer.db` (from faq_answer.csv.xlsx)
  - `version_tracking.db` (empty schema only)
- Verifies data integrity and counts
- Displays database sizes and summary

**When to run:**
- ✅ First time project setup
- ✅ After updating source Excel files
- ✅ When resetting databases for testing
- ❌ NOT during daily operations (only setup/refresh)

**Output:**
```
databases/
├── content_repo.db     (e.g., 250 KB, 150 records)
├── faq_question.db     (e.g., 45 KB, 89 records)
├── faq_answer.db       (e.g., 180 KB, 67 records)
└── version_tracking.db (e.g., 20 KB, empty schema)
```

---

### 2. version_tracking_implementation.ipynb (Educational)
**Purpose**: Educational notebook to understand version tracking concepts

**Prerequisites**:
- ✅ Must run [setup_databases.ipynb](setup_databases.ipynb) first (creates databases)
- ✅ Must run [daily_version_tracking_pipeline.ipynb](daily_version_tracking_pipeline.ipynb) to have version data

**Use this when you want to:**
- Learn how the version tracking system works
- Explore version chains and queries
- Validate existing data integrity
- Test SQL queries for retrieving version history
- Understand the linked list design

**Key Features:**
- Connects to existing databases (no schema creation)
- Loads version data populated by daily pipeline
- Demonstrates version chain traversal
- Shows example queries (latest versions, full history, breaking changes)
- Includes data validation checks
- Read-only operations (no data modifications)

**Notebook Steps:**
1. Setup and Imports
2. Connect to Databases (checks databases exist)
3. Load Version Tracking Data (from version_tracking.db)
4. Understanding the Data Model (linked list design)
5. Helper Functions (get_full_version_chain, build_faq_details)
6. Test Full Version Chain Traversal
7. Query Examples (7.1-7.4: current FAQs, version history, FAQs needing regeneration, side-by-side comparison)
8. Implement the Version Tracking Pipeline
9. Run the Pipeline
10. Advanced Usage - Full Version History
11. Impact Analysis
12. Create Simulation Data
13. Validation and Data Quality Checks

**When NOT to use:**
- ❌ Initial database setup (use setup_databases.ipynb)
- ❌ Daily production workflows (use daily_version_tracking_pipeline.ipynb)
- ❌ Automated version detection
- ❌ Creating new version records

---

### 3. daily_version_tracking_pipeline.ipynb (Production)
**Purpose**: Production-ready daily pipeline for automated version detection

**Use this when you want to:**
- Run the daily version tracking workflow
- Detect new and updated content automatically
- Populate version_history table with new versions
- Track content changes over time
- Deprecate FAQs when source content changes

**Prerequisites:**
- ✅ Must run [setup_databases.ipynb](setup_databases.ipynb) first to create all 4 databases

**Data Sources (What Reads What):**
- 🗄️ **content_repo.db** → Content metadata (file names, page numbers, last_modified_dt, markdown file paths)
- 📁 **Actual markdown files** → Calculate checksums (NOT from database checksum column!)
- 🗄️ **version_tracking.db** → Existing version history (to compare against)
- 🗄️ **faq_question.db** → FAQ questions (for impact analysis)
- 🗄️ **faq_answer.db** → FAQ answers (for impact analysis)

**Key Features:**
- Reads content metadata from content_repo.db database
- Calculates checksums from actual markdown files at paths specified in database
- Loads existing version history from version_tracking.db
- Loads FAQ data from faq_question.db and faq_answer.db
- Detects new content, updated content, and unchanged content by comparing checksums
- Creates version records in version_tracking.db
- Tracks last_run_date for incremental processing
- Updates is_latest_version flags
- Generates FAQ deprecation list

**Workflow:**
1. Read content metadata from content_repo.db
2. Filter by last_modified_dt > last_run_date (incremental)
3. Calculate checksums from actual markdown files (using paths from database)
4. Load existing version history from version_tracking.db
5. Load FAQ data from faq_question.db and faq_answer.db
6. Compare calculated checksums to detect changes
7. Create version records in version_tracking.db
8. Mark affected FAQs for review

---

## 🗄️ Database Structure

### Why Separate Databases?

The system uses **4 separate SQLite databases** for better modularity:

1. **content_repo.db** - Content repository metadata
   - Source: `Docs/content_repo.csv.xlsx`
   - Table: `content_repo`
   - Purpose: File paths, page numbers, metadata

2. **faq_question.db** - FAQ questions
   - Source: `Docs/faq_question.csv.xlsx`
   - Table: `faq_questions`
   - Purpose: Question text and metadata

3. **faq_answer.db** - FAQ answers
   - Source: `Docs/faq_answer.csv.xlsx`
   - Table: `faq_answers`
   - Purpose: Answer text and metadata

4. **version_tracking.db** - Version history tracking
   - Source: Schema only (populated by pipeline)
   - Tables: `content_version_history`, `faq_content_link`, `faq_validation_history`, `content_change_impact`
   - Purpose: Track content changes and FAQ validity

### Benefits:
- ✅ **Modularity**: Independent backup/restore
- ✅ **Performance**: Faster queries on smaller databases
- ✅ **Maintenance**: Update base data without affecting version history
- ✅ **Scalability**: Can move to different systems independently

### Database Connections

All notebooks use this pattern:

```python
from pathlib import Path
import sqlite3

DATABASES_DIR = Path('../databases')
CONTENT_REPO_DB = DATABASES_DIR / 'content_repo.db'
FAQ_QUESTION_DB = DATABASES_DIR / 'faq_question.db'
FAQ_ANSWER_DB = DATABASES_DIR / 'faq_answer.db'
VERSION_TRACKING_DB = DATABASES_DIR / 'version_tracking.db'

# Connect as needed
conn_content = sqlite3.connect(CONTENT_REPO_DB)
conn_version = sqlite3.connect(VERSION_TRACKING_DB)
```

---

## Important: Checksum Calculation

### Why Calculate Checksums Instead of Using CSV?

The daily pipeline **calculates checksums from actual markdown files** rather than using the `content_checksum` column from `content_repo_temp.csv`.

**Reasons:**
- CSV checksums may be stale or incorrect
- Direct file calculation ensures accuracy
- Detects content changes reliably
- Independent verification of content state

**How it works:**
```python
def calculate_file_checksum(file_path):
    """Calculate SHA-256 checksum from actual file content."""
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
            return hashlib.sha256(content).hexdigest()
    except FileNotFoundError:
        print(f"⚠️ Warning: File not found: {file_path}")
        return None

# Applied to all content records
for idx, row in content_repo.iterrows():
    markdown_path = row['extracted_markdown_file_path']
    if pd.notna(markdown_path):
        checksum = calculate_file_checksum(markdown_path)
        content_repo.at[idx, 'calculated_checksum'] = checksum
```

**What gets used from CSV:**
- ✅ `ud_source_file_id` → `content_id`
- ✅ `raw_file_nme` → `file_name`
- ✅ `raw_file_page_nbr` → `page_number`
- ✅ `version_nbr` → reference only
- ✅ `extracted_markdown_file_path` → used to calculate checksum
- ✅ `last_modified_dt` → incremental filtering
- ❌ `content_checksum` → NOT USED (calculated instead)

---

## Complete Workflow

### Initial Setup (One Time)

**Step 1: Run setup_databases.ipynb**
```python
# What it does:
1. Create databases/ directory
2. Read ../Docs/content_repo.xlsx → create content_repo.db
3. Read ../Docs/faq_question.xlsx → create faq_question.db
4. Read ../Docs/faq_answer.xlsx → create faq_answer.db
5. Execute schema_content_version_tracking.sql → create version_tracking.db (empty tables)
```

**Step 2: First Pipeline Run**
```python
# Run daily_version_tracking_pipeline.ipynb
# What it does:
1. Read content metadata from content_repo.db
2. Calculate checksums from actual markdown files (paths from database)
3. Load existing version history from version_tracking.db (empty on first run)
4. Load FAQ data from faq_question.db and faq_answer.db
5. Detect all as NEW (no existing versions)
6. Create initial version records (version_sequence=1) in version_tracking.db
7. Store last_run_date in databases/last_run_date.txt
```

### Daily Operations

**Daily Pipeline Run**
```python
# Run daily_version_tracking_pipeline.ipynb
# What it does:
1. Read content metadata from content_repo.db
2. Filter by last_modified_dt > last_run_date (incremental)
3. Calculate checksums from actual markdown files (paths from database)
4. Load existing version history from version_tracking.db
5. Load FAQ data from faq_question.db and faq_answer.db
6. Detect changes by comparing checksums:
   - New content (no existing version) → create version_sequence=1
   - Updated content (checksum changed) → create version_sequence=n+1
   - Unchanged content (checksum same) → skip
7. Update is_latest_version flags in version_tracking.db
8. Deprecate affected FAQs in faq_content_link table
9. Update last_run_date in databases/last_run_date.txt
```

---

## Data Flow

### Content Repository → Version History
```
databases/content_repo.db
  ├→ Read content metadata (file paths, page numbers, last_modified_dt)
  ├→ Filter by last_modified_dt > last_run_date
  └→ Use file paths to calculate checksums from actual markdown files
      ↓
  Load from databases/:
    ├→ version_tracking.db (existing version history)
    ├→ faq_question.db (FAQ questions)
    └→ faq_answer.db (FAQ answers)
      ↓
  Compare calculated checksums with existing versions
      ↓
  Detect: New | Updated | Unchanged
      ↓
  Write to version_tracking.db:
    ├→ Create version records
    ├→ Update is_latest_version flags
    └→ Deprecate affected FAQs
      ↓
  Update databases/last_run_date.txt
```

### Version Chain Structure
```
Version 1 (initial)
    ↑ previous_version_id
Version 2 (minor update)
    ↑ previous_version_id
Version 3 (major update)
    ↑ previous_version_id
Version 4 (breaking change)
```

---

## Example Scenarios

### Scenario 1: New Document Added
```
INPUT: databases/content_repo.db
- ud_source_file_id: 500
- raw_file_nme: "New_Policy.pdf"
- raw_file_page_nbr: 1
- last_modified_dt: 2025-10-03
- extracted_markdown_file_path: "/path/to/new_policy_p1.md"

Pipeline Action:
✅ Read metadata from content_repo.db
✅ Calculate checksum from /path/to/new_policy_p1.md (actual file)
✅ Query version_tracking.db: No existing version found → NEW CONTENT
✅ Create version_sequence=1, change_type='initial'

WRITE TO: version_tracking.db
version_history_id: 25
content_id: 500
previous_version_id: NULL
version_sequence: 1
content_checksum: abc123... (from actual file)
change_type: initial
```

### Scenario 2: Document Updated
```
INPUT: databases/content_repo.db
- ud_source_file_id: 100
- last_modified_dt: 2025-10-03
- extracted_markdown_file_path: "/path/to/pto_policy_p1.md"

LOAD FROM: version_tracking.db (existing version)
version_history_id: 10
content_id: 100
content_checksum: old_hash_xyz

Pipeline Action:
✅ Read metadata from content_repo.db
✅ Calculate checksum from /path/to/pto_policy_p1.md (actual file) → new_hash_abc
✅ Compare: new_hash_abc ≠ old_hash_xyz → UPDATED CONTENT
✅ Create version_sequence=2, previous_version_id=10

WRITE TO: version_tracking.db
- New record:
  version_history_id: 26
  content_id: 100
  previous_version_id: 10  ← points to version_history_id=10
  version_sequence: 2
  content_checksum: new_hash_abc (from actual file)
  change_type: major
- Update existing:
  version_history_id=10: is_latest_version=FALSE
  version_history_id=26: is_latest_version=TRUE
```

### Scenario 3: Document Unchanged
```
INPUT: databases/content_repo.db
- ud_source_file_id: 200
- last_modified_dt: 2025-10-03 (database metadata changed, not actual content)
- extracted_markdown_file_path: "/path/to/handbook_p5.md"

Pipeline Action:
✅ Read metadata from content_repo.db
✅ Calculate checksum from /path/to/handbook_p5.md (actual file) → same_hash_def
✅ Load from version_tracking.db: existing checksum = same_hash_def
✅ Compare: same_hash_def = same_hash_def → UNCHANGED
⏭️ Skip (no new version created)

WRITE TO: version_tracking.db
No changes
```

---

## Troubleshooting

### Issue: File Not Found Errors
**Symptom**: `⚠️ Warning: File not found: /path/to/file.md`

**Causes:**
- extracted_markdown_file_path is incorrect
- File was moved or deleted
- Path is relative instead of absolute

**Solutions:**
- Verify file paths in content_repo.db
- Check if markdown extraction step completed
- Ensure paths are absolute (not relative)

### Issue: No Versions Detected
**Symptom**: Pipeline runs but creates no version records

**Causes:**
- last_modified_dt filter excludes all records
- Checksums match (no actual changes)
- Database empty or malformed

**Solutions:**
- Check last_run_date in databases/last_run_date.txt
- Verify last_modified_dt values in content_repo.db
- Delete last_run_date.txt to reprocess all records
- Validate database structure

### Issue: Duplicate Versions Created
**Symptom**: Multiple version records for same content+sequence

**Causes:**
- Pipeline run multiple times on same date
- Database transaction not committed properly
- Checksum calculation inconsistent

**Solutions:**
- Check last_run_date in databases/last_run_date.txt
- Add unique constraint on (content_id, version_sequence)
- Verify checksum calculation is deterministic

### Issue: FAQ Deprecation List Empty
**Symptom**: Content updated but no FAQs marked for review

**Causes:**
- No FAQs linked to updated content
- faq_content_link table empty or incorrect
- content_id mismatch

**Solutions:**
- Verify faq_content_link.content_id matches content_version_history.content_id
- Check if FAQs exist for the updated content
- Validate foreign key relationships

### Issue: Database Not Found
**Symptom**: `No such file or directory: '../databases/content_repo.db'`

**Causes:**
- Haven't run setup_databases.ipynb yet
- Wrong working directory

**Solutions:**
- Run setup_databases.ipynb first
- Verify you're in the notebooks/ directory
- Check that databases/ folder exists at project root

---

## Configuration

### Database Locations
All databases are in `databases/` directory:

```python
DATABASES_DIR = Path('../databases')
CONTENT_REPO_DB = DATABASES_DIR / 'content_repo.db'
FAQ_QUESTION_DB = DATABASES_DIR / 'faq_question.db'
FAQ_ANSWER_DB = DATABASES_DIR / 'faq_answer.db'
VERSION_TRACKING_DB = DATABASES_DIR / 'version_tracking.db'
```

### Input Data Source
Content metadata read from: `databases/content_repo.db`

### Incremental Processing
Controlled by `last_run_date.txt` in `databases/` directory:
- Filters content by `last_modified_dt > last_run_date`
- Automatically updated after each pipeline run

To reprocess all content:
```bash
# Delete the last run date file
rm databases/last_run_date.txt
# Or on Windows:
del databases\last_run_date.txt
```

---

## Related Files

### Source Files (Docs/)
- **Schema**: `schema_content_version_tracking.sql`
- **Documentation**: `README_VERSION_TRACKING.md`
- **Sample Data**: `sample_data_*.csv` files
- **Source Excel**: `content_repo.xlsx`, `faq_question.xlsx`, `faq_answer.xlsx` (one-time setup only)

### Databases (databases/)
- **Content**: `content_repo.db`
- **Questions**: `faq_question.db`
- **Answers**: `faq_answer.db`
- **Versions**: `version_tracking.db`
- **Pipeline State**: `last_run_date.txt`

---

## Quick Reference

### Which Notebook Should I Use?

| Task | Notebook | Frequency | Mode |
|------|----------|-----------|------|
| Initial project setup | setup_databases.ipynb | Once | Setup |
| Refresh base data from Excel | setup_databases.ipynb | As needed | Setup |
| Learn version tracking concepts | version_tracking_implementation.ipynb | As needed | Educational |
| Query existing version data | version_tracking_implementation.ipynb | As needed | Educational |
| Run daily version detection | daily_version_tracking_pipeline.ipynb | Daily | Production |
| Create new version records | daily_version_tracking_pipeline.ipynb | Daily | Production |
| Validate data integrity | version_tracking_implementation.ipynb | As needed | Educational |
| Deprecate outdated FAQs | daily_version_tracking_pipeline.ipynb | Daily | Production |

### Setup Workflow (First Time)

**⚠️ Important: Run notebooks in this exact order!**

```bash
# Step 1: Setup databases (ONCE) - Creates all 4 databases from Excel
notebooks/setup_databases.ipynb

# Step 2: Run first pipeline (ONCE) - Populates version_tracking.db with initial data
notebooks/daily_version_tracking_pipeline.ipynb

# Step 3: Explore (OPTIONAL) - Educational queries and analysis
notebooks/version_tracking_implementation.ipynb
```

**Why this order?**
1. **setup_databases.ipynb** creates the database structure
2. **daily_version_tracking_pipeline.ipynb** populates version data
3. **version_tracking_implementation.ipynb** requires populated data to demonstrate concepts

### Daily Workflow

```bash
# Every day (automated):
notebooks/daily_version_tracking_pipeline.ipynb

# Optional exploration:
notebooks/version_tracking_implementation.ipynb
```

### Key Functions

**Setup Notebook:**
- Creates all databases from Excel files
- Verifies data integrity
- Shows database statistics

**Educational Notebook:**
- `get_full_version_chain(version_history_id)` - Retrieve complete version history
- Validation queries for data integrity
- Example SQL queries

**Production Pipeline:**
- `calculate_file_checksum(file_path)` - Calculate SHA-256 from file
- `create_initial_version(content)` - Create first version record
- `create_updated_version(content, previous_version)` - Create subsequent version
- `deprecate_affected_faqs(content_ids)` - Mark FAQs for review
