# Database Setup - Modular Approach

## Overview

The [setup_databases.ipynb](setup_databases.ipynb) notebook has been redesigned to provide **flexible data source switching** between Excel spreadsheets and programmatically generated test data.

## Quick Start

### 1. Choose Your Data Source

Open [setup_databases.ipynb](setup_databases.ipynb) and set the `DATA_SOURCE` variable in **Step 1**:

```python
DATA_SOURCE = 'excel'  # Options: 'excel' or 'test'
```

### 2. Run All Cells

Execute all cells to create databases from the selected source.

## Data Sources

### Excel (Production Data)
- **Source:** Excel files in `Docs/` directory
- **Files:**
  - `content_repo.xlsx` → content_repo.db
  - `faq_question.xlsx` → faq_question.db
  - `faq_answer.xlsx` → faq_answer.db
- **Use Case:** Production setup, real data analysis

```python
DATA_SOURCE = 'excel'
```

### Test (Generated Examples)
- **Source:** Programmatically generated test data
- **Content:** Employee Leave Policy examples (3 pages)
- **Use Case:** Testing pipelines, development, version tracking validation
- **Features:**
  - Realistic HR policy content
  - Consistent structure for testing
  - Markdown files created in `test_data_version_tracking/`

```python
DATA_SOURCE = 'test'
```

## Architecture

### Modular Design Principles

1. **Single Configuration Point**
   - Change `DATA_SOURCE` variable to switch between sources
   - No code duplication

2. **Unified Data Loading**
   - `load_data(data_type)` function handles both sources
   - Automatic routing based on `DATA_SOURCE`

3. **Reusable Database Creation**
   - `create_database()` function for all databases
   - Consistent error handling and verification

4. **No Duplicate Logic**
   - Excel loaders: `load_*_excel()` functions
   - Test generators: `generate_test_*()` functions
   - Single code path for database creation

## Key Features

### ✅ Easy Source Switching
```python
# Switch to Excel data
DATA_SOURCE = 'excel'

# Switch to test data
DATA_SOURCE = 'test'
```

### ✅ Consistent Structure
All databases created with identical structure regardless of source:
- `databases/content_repo.db`
- `databases/faq_question.db`
- `databases/faq_answer.db`
- `databases/version_tracking.db`

### ✅ Validation & Verification
- Automatic record counts
- Sample data display
- Source tracking in summary

### ✅ Error Handling
- Permission error handling
- File lock detection
- Schema validation

## Generated Test Data Details

When `DATA_SOURCE = 'test'`, the notebook generates:

### Content Repository (3 pages)
- **Page 1:** Employee Leave Policy - Purpose, Scope, Annual Leave
- **Page 2:** Sick Leave, Parental Leave
- **Page 3:** Bereavement Leave, Leave Request Process

### FAQ Questions (2 questions)
- Q1001: "What is the annual leave policy?"
- Q1002: "How many sick leave days do employees get?"

### FAQ Answers (2 answers)
- A1001: Annual leave details with carryover rules
- A1002: Sick leave entitlements and requirements

### Markdown Files
- Located in: `test_data_version_tracking/markdown_files/`
- Policy content stored as `.md` files
- SHA-256 checksums calculated for version tracking

## Database Summary Output

The notebook provides a comprehensive summary:

```
================================================================================
📊 DATABASE SETUP SUMMARY - Source: EXCEL (or TEST)
================================================================================

📁 Database Directory: ../databases

✅ content_repo.db
   Content repository
   Size: 96.0 KB | Status: 127 records

✅ faq_question.db
   FAQ questions
   Size: 8.0 KB | Status: 8 records

✅ faq_answer.db
   FAQ answers
   Size: 8.0 KB | Status: 5 records

✅ version_tracking.db
   Version tracking
   Size: 156.0 KB | Status: 5 tables created
```

## Integration with Other Notebooks

All notebooks can use the same database connection pattern:

```python
import sqlite3
import pandas as pd
from pathlib import Path

# Database paths
DATABASES_DIR = Path('../databases')
CONTENT_REPO_DB = DATABASES_DIR / 'content_repo.db'

# Connect
conn = sqlite3.connect(CONTENT_REPO_DB)
content_repo = pd.read_sql("SELECT * FROM content_repo", conn)
conn.close()
```

### Verifying Data Source

Check which source was used to create databases:

```python
# For test data
df = pd.read_sql("SELECT * FROM faq_questions WHERE source='test_data'", conn)

# For Excel data
df = pd.read_sql("SELECT DISTINCT source FROM faq_questions", conn)
```

## Comparison with Previous Approach

### Before (Duplicated Code)
- Separate cells for each database
- Excel loading logic repeated multiple times
- No test data support
- Manual path management

### After (Modular)
- Single configuration variable
- Reusable loading functions
- Built-in test data generation
- Centralized database creation
- Zero code duplication

## Related Files

- **Notebook:** [setup_databases.ipynb](setup_databases.ipynb) - Main database setup
- **Test Data Generator:** [../generate_version_tracking_test_data.py](../generate_version_tracking_test_data.py) - Standalone test data script
- **Schema:** [../Docs/schema_content_version_tracking.sql](../Docs/schema_content_version_tracking.sql) - Version tracking schema

## Workflow Examples

### Example 1: Testing a New Pipeline
```python
# Use test data
DATA_SOURCE = 'test'
# Run all cells → creates databases with test data
# Test your pipeline with known data
```

### Example 2: Production Setup
```python
# Use Excel data
DATA_SOURCE = 'excel'
# Run all cells → creates databases with production data
# Deploy or analyze real data
```

### Example 3: Quick Switching
```python
# Test with examples
DATA_SOURCE = 'test'
# Run cells...

# Switch to production
DATA_SOURCE = 'excel'
# Run cells again → databases replaced with Excel data
```

## Benefits

1. **Development Speed** - Quickly generate test data without Excel files
2. **Testing** - Consistent test data for pipeline validation
3. **Flexibility** - Switch sources with one variable change
4. **Maintainability** - Single codebase for both sources
5. **No Duplication** - Reusable functions eliminate redundancy

## Notes

- The `generate_version_tracking_test_data.py` script can still be used standalone
- Test data generation is now integrated into the notebook for convenience
- Both approaches generate identical database structures
- Markdown files are created for test data to support content-based tracking
