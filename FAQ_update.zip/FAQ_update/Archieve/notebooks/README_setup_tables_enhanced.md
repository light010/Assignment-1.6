# 📘 Complete Guide: setup_tables_enhanced.ipynb

## 🎯 Overview

**setup_tables_enhanced.ipynb** is a production-ready Jupyter notebook that creates and populates the **faq_update.db** database with **Schema v4.0** (Single Database Architecture).

### ✨ Key Features

| Feature | Description | Benefit |
|---------|-------------|---------|
| **Dual Data Sources** | Switch between `'excel'` and `'test'` | Flexibility for dev/prod |
| **Schema v4.0** | Single database with REAL FKs | Database enforces integrity |
| **7 Tables** | All base + tracking tables | Complete system in one file |
| **8 Views** | Analytics and monitoring | Built-in insights |
| **Data Validation** | Pre-insert checks + FK validation | Data quality guaranteed |
| **Comprehensive Testing** | FK, trigger, view tests | Confidence in setup |
| **Error Handling** | Graceful failures with clear messages | Easy debugging |
| **Progress Tracking** | Detailed logging throughout | Visibility into process |

---

## 📊 Complete Cell Structure (22 Cells)

### 🟢 **Foundation Cells (1-3)** ✅ IMPLEMENTED

#### **Cell 1: Introduction (Markdown)**
- Purpose and benefits
- Schema v4.0 features
- When to run
- Comparison table (Multi-DB vs Single-DB)

#### **Cell 2: Configuration (Code)**
- `DATA_SOURCE = 'test'` or `'excel'`
- All path configurations
- Directory creation
- Display settings

#### **Cell 3: Utility Functions (Code)**
- `calculate_checksum()` - SHA-256 for content
- `calculate_file_checksum()` - SHA-256 for files
- `format_timestamp()` - ISO-8601 UTC with 'Z'
- `validate_checksum()` - 64 hex char validation
- `create_markdown_file()` - Create file + return checksum
- `compress_diff()` / `decompress_diff()` - Gzip utilities
- `preview_dataframe()` - Display data preview
- Logging functions: `log_success()`, `log_info()`, `log_warning()`, `log_error()`

---

### 🔵 **Data Loading Cells (4-7)** 🔨 TO IMPLEMENT

#### **Cell 4: Excel Data Loaders (Code)**

**Purpose**: Load and validate data from Excel files (production path)

**Functions**:

```python
def load_content_repo_from_excel() -> pd.DataFrame:
    \"\"\"
    Load content_repo from Excel with validation.

    Required columns:
    - ud_source_file_id
    - raw_file_nme
    - raw_file_page_nbr
    - extracted_markdown_file_path

    Optional columns (with defaults):
    - last_modified_dt (default: now)
    - created_dt (default: now)
    - file_size_bytes (default: None)
    - content_type (default: 'pdf')
    - processing_status (default: 'completed')

    Returns:
    - Validated DataFrame ready for insertion

    Raises:
    - FileNotFoundError if Excel file missing
    - ValueError if required columns missing
    \"\"\"

def load_faq_questions_from_excel() -> pd.DataFrame:
    \"\"\"
    Load faq_questions from Excel with deduplication.

    Maps old schema → new schema:
    - question_txt (required)
    - category (from domain or category column)
    - priority (default: 0)
    - is_active (default: 1)
    - created_at (from created or now)

    Deduplicates by question_txt (keeps first)

    Returns:
    - Validated DataFrame with unique questions
    \"\"\"

def load_faq_answers_from_excel() -> pd.DataFrame:
    \"\"\"
    Load faq_answers from Excel with word count calculation.

    Maps old schema → new schema:
    - faq_answer_txt (required)
    - answer_format (default: 'text')
    - is_active (default: 1)
    - word_count (calculated from text)

    Returns:
    - Validated DataFrame with calculated metrics
    \"\"\"
```

**Error Handling**:
- File existence check
- Required column validation
- Data type validation
- Clear error messages with file paths

**Output**:
- Success log: "✅ Validated content_repo data: 100 records ready"
- Warning log: "⚠️ Removed 5 duplicate questions"
- Error log: "❌ Missing required column: question_txt"

---

#### **Cell 5: Test Data Generators - Base Tables (Code)**

**Purpose**: Generate comprehensive, realistic test data for development/testing

**Functions**:

```python
def generate_test_content_repo() -> pd.DataFrame:
    \"\"\"
    Generate 3-page Employee Leave Policy with:
    - Real markdown files created on disk
    - SHA-256 checksums calculated
    - Realistic metadata
    - ISO-8601 timestamps

    Creates directory structure:
    test_data_version_tracking/
      markdown_files/
        leave_policy/
          page1_v1.md  (Annual Leave section)
          page2_v1.md  (Sick + Parental Leave)
          page3_v1.md  (Bereavement + Process)

    Returns 3 records with:
    - ud_source_file_id: 1001, 1002, 1003
    - raw_file_nme: 'Employee_Leave_Policy.pdf'
    - raw_file_page_nbr: 1, 2, 3
    - content_checksum: Real SHA-256 from file
    \"\"\"

def generate_test_faq_questions() -> pd.DataFrame:
    \"\"\"
    Generate 10 questions covering all 3 pages:
    - Page 1: 3 questions (Annual Leave)
    - Page 2: 4 questions (Sick + Parental Leave)
    - Page 3: 3 questions (Bereavement + Process)

    Each question has:
    - Unique question_id (1-10)
    - Realistic question text
    - Category assignment
    - Priority levels (1-3)
    - Metadata tracking
    \"\"\"

def generate_test_faq_answers() -> pd.DataFrame:
    \"\"\"
    Generate 10 answers matching questions 1:1:
    - answer_id matches question_id
    - Comprehensive, policy-accurate answers
    - Calculated word counts
    - answer_format = 'text'

    Examples:
    - Q1: "What is the annual leave policy?"
      A1: "Employees accrue 15 days of annual leave per year..."
    \"\"\"
```

**Key Features**:
- Real file I/O (not just data)
- Checksums from actual content
- Page-question mapping for later FAQ testing
- Realistic content lengths and formatting

---

#### **Cell 6: Test Data Generators - Tracking Tables (Code)**

**Purpose**: Generate change history and FAQ mappings with realistic scenarios

**Functions**:

```python
def generate_test_content_change_log(content_df: pd.DataFrame) -> pd.DataFrame:
    \"\"\"
    Generate change history showing:
    1. Initial creation of all 3 pages (change_type='initial_creation')
    2. Content edit on page 2 (change_type='content_edit')
       - Old checksum: page2_v1
       - New checksum: page2_v2 (15 days → 20 days annual leave)
    3. Position change example (optional)

    Returns 4+ change records demonstrating:
    - All change_type values
    - FK relationships to content_repo
    - Proper timestamp ordering
    - previous_content_id, previous_checksum tracking
    \"\"\"

def generate_test_faq_content_map(
    content_df: pd.DataFrame,
    questions_df: pd.DataFrame,
    answers_df: pd.DataFrame,
    changes_df: pd.DataFrame
) -> pd.DataFrame:
    \"\"\"
    Generate FAQ-content mappings showing:
    1. Valid FAQs (5 records):
       - Q1-Q3 on page 1 (still valid)
       - Q5 on page 3 (still valid)
       - Q8 on page 3 (still valid)

    2. Invalidated FAQs (2 records):
       - Q4 on page 2 (invalidated by content_edit, change_id=4)
       - Q7 on page 2 (invalidated by content_edit, change_id=4)

    Demonstrates:
    - is_valid=1 for unchanged content
    - is_valid=0 for edited content
    - valid_until timestamp set on invalidation
    - invalidation_reason='content_edited'
    - invalidated_by_change_id FK working
    \"\"\"

def generate_test_content_diffs(changes_df: pd.DataFrame) -> pd.DataFrame:
    \"\"\"
    Generate diff for content_edit change (change_id=4):

    Creates realistic unified diff:
    ```
    --- old/page_2.md
    +++ new/page_2.md
    @@ -1,5 +1,5 @@
     # Leave Policy

    -Employees are entitled to 15 days of annual leave.
    +Employees are entitled to 20 days of annual leave.
    ```

    Includes:
    - unified_diff_gzip: Compressed BLOB
    - similarity_score: 0.95 (minor change)
    - chars_added: 1, chars_removed: 1
    - lines_added: 1, lines_removed: 1
    - is_minor_change: 1
    - semantic_summary: JSON with structured analysis
    - processing_time_ms: Simulated processing time

    Returns 1 record showing complete diff workflow
    \"\"\"
```

**Scenarios Demonstrated**:
1. **Initial State**: All content created, all FAQs valid
2. **Content Edit**: Page 2 modified (15 → 20 days)
3. **FAQ Invalidation**: Q4, Q7 invalidated automatically
4. **Diff Storage**: Compressed diff with metrics stored

---

#### **Cell 7: Unified Data Loader (Code)**

**Purpose**: Single interface for loading all data based on DATA_SOURCE

```python
def load_all_data(source: str = DATA_SOURCE) -> dict:
    \"\"\"
    Load all datasets based on configured source.

    Args:
        source: 'excel' or 'test'

    Returns:
        dict with keys:
        - 'content_repo': DataFrame
        - 'faq_questions': DataFrame
        - 'faq_answers': DataFrame
        - 'content_change_log': DataFrame (test only)
        - 'faq_content_map': DataFrame (test only)
        - 'content_diffs': DataFrame (test only)
        - 'source': str ('excel' or 'test')

    Note: Excel loads only base tables (repo, questions, answers)
          Test generates full dataset including tracking tables
    \"\"\"
    log_info(f\"Loading data from {source.upper()} source...\")

    data = {'source': source}

    if source == 'excel':
        # Load base tables from Excel
        data['content_repo'] = load_content_repo_from_excel()
        data['faq_questions'] = load_faq_questions_from_excel()
        data['faq_answers'] = load_faq_answers_from_excel()

        log_success(\"Excel data loaded (base tables only)\")\n        log_info(\"Tracking tables will remain empty (populate via pipeline)\")\n
    elif source == 'test':
        # Generate complete test dataset
        data['content_repo'] = generate_test_content_repo()
        data['faq_questions'] = generate_test_faq_questions()
        data['faq_answers'] = generate_test_faq_answers()
        data['content_change_log'] = generate_test_content_change_log(data['content_repo'])
        data['faq_content_map'] = generate_test_faq_content_map(
            data['content_repo'],
            data['faq_questions'],
            data['faq_answers'],
            data['content_change_log']
        )
        data['content_diffs'] = generate_test_content_diffs(data['content_change_log'])

        log_success(\"Test data generated (all 7 tables)\")\n
    else:
        raise ValueError(f\"Invalid DATA_SOURCE: {source}. Must be 'excel' or 'test'\")

    return data

# Execute unified loader
print(\"\\n\" + \"=\"*80)
print(\"LOADING DATA\")
print(\"=\"*80)

all_data = load_all_data()

# Display summary
print(f\"\\n📊 Data Summary (Source: {all_data['source'].upper()}):\")
for table_name, df in all_data.items():
    if table_name != 'source' and df is not None:
        print(f\"  - {table_name:25} {len(df):5} records\")
```

---

### 🟣 **Database Setup Cells (8-10)** 🔨 TO IMPLEMENT

#### **Cell 8: Remove Existing Database (Code)**

```python
print(\"\\n\" + \"=\"*80)
print(\"DATABASE CLEANUP\")
print(\"=\"*80)

if DB_PATH.exists():
    log_info(f\"Removing existing database: {DB_PATH.name}\")
    try:
        DB_PATH.unlink()
        log_success(\"Existing database removed\")
    except PermissionError:
        log_error(\"Cannot remove database (file in use)\")
        log_error(\"Close all connections and try again\")
        raise
else:
    log_info(\"No existing database to remove\")
```

---

#### **Cell 9: Verify JSON1 Extension (Code)**

```python
print(\"\\n\" + \"=\"*80)
print(\"JSON1 EXTENSION CHECK\")
print(\"=\"*80)

with sqlite3.connect(DB_PATH) as conn:
    try:
        result = conn.execute(\"SELECT json('{\\\"test\\\":true}')\").fetchone()[0]
        log_success(\"JSON1 extension is available\")
        log_info(f\"Test result: {result}\")
    except sqlite3.OperationalError as e:
        log_error(\"JSON1 extension NOT available\")
        log_error(f\"Error: {e}\")
        log_error(\"Schema v4.0 requires JSON1 for semantic_summary field\")
        log_error(\"Upgrade SQLite to 3.38.0+ or recompile with SQLITE_ENABLE_JSON1\")
        raise
```

---

#### **Cell 10: Create Schema from SQL File (Code)**

```python
print(\"\\n\" + \"=\"*80)
print(\"SCHEMA CREATION\")
print(\"=\"*80)

log_info(f\"Reading schema from: {SCHEMA_FILE.name}\")

if not SCHEMA_FILE.exists():
    log_error(f\"Schema file not found: {SCHEMA_FILE}\")
    raise FileNotFoundError(f\"Schema file missing: {SCHEMA_FILE}\")

with open(SCHEMA_FILE, 'r', encoding='utf-8') as f:
    schema_sql = f.read()

log_success(f\"Schema loaded ({len(schema_sql):,} characters)\")

with sqlite3.connect(DB_PATH) as conn:
    log_info(\"Executing schema creation...\")
    conn.executescript(schema_sql)
    log_success(\"Schema created successfully\")

    # Verify FK enabled
    fk_status = conn.execute(\"PRAGMA foreign_keys\").fetchone()[0]
    if fk_status:
        log_success(f\"Foreign keys ENABLED (CRITICAL for v4.0)\")
    else:
        log_warning(\"Foreign keys NOT enabled\")
        conn.execute(\"PRAGMA foreign_keys = ON\")
        log_success(\"Foreign keys enabled manually\")
```

---

### 🟡 **Data Insertion Cells (11-16)** 🔨 TO IMPLEMENT

Each cell follows this pattern:
1. Log table name
2. Enable FK constraints
3. Insert data from `all_data` dict
4. Verify row count
5. Show sample (first 3-5 rows)

#### **Cell 11: Insert content_repo**
#### **Cell 12: Insert faq_questions**
#### **Cell 13: Insert faq_answers**
#### **Cell 14: Insert content_change_log** (test mode only)
#### **Cell 15: Insert faq_content_map** (test mode only)
#### **Cell 16: Insert content_diffs** (test mode only)

---

### 🔴 **Testing Cells (17-20)** 🔨 TO IMPLEMENT

#### **Cell 17: Verify Schema Components (Code)**

Shows counts of:
- Tables (expect 7)
- Views (expect 8)
- Triggers (expect 1)
- Indexes (expect 15+)
- Schema version

---

#### **Cell 18: Test Foreign Key Constraints (Code)**

3 tests:
1. Try insert with invalid content_id (should FAIL)
2. Try insert with invalid question_id (should FAIL)
3. Run `PRAGMA foreign_key_check` (should be empty)

---

#### **Cell 19: Test Trigger (Code)**

Try insert diff for non-edit change (should FAIL with trigger error)

---

#### **Cell 20: Test Views (Code)**

Query all 8 views and show record counts

---

### 🟢 **Summary Cells (21-22)** 🔨 TO IMPLEMENT

#### **Cell 21: Comprehensive Summary (Code)**

Display:
- Database path and size
- Schema version
- Table record counts
- View availability
- FK status
- Data source used
- Execution time

---

#### **Cell 22: Next Steps (Markdown)**

Instructions for:
- Using the database in other notebooks
- Running pipelines
- Switching data sources
- Troubleshooting

---

## 🎯 Usage Examples

### **Scenario 1: Development with Test Data**

```python
# Cell 2: Set configuration
DATA_SOURCE = 'test'

# Run all cells → Get complete database with sample data
# All 7 tables populated
# Sample changes and invalidations included
```

### **Scenario 2: Production with Excel Data**

```python
# Cell 2: Set configuration
DATA_SOURCE = 'excel'

# Run all cells → Get database with base tables
# Only content_repo, faq_questions, faq_answers populated
# Tracking tables empty (filled by pipeline later)
```

### **Scenario 3: Switching Sources**

```python
# Change DATA_SOURCE in Cell 2
DATA_SOURCE = 'excel'  # was 'test'

# Run all cells again
# Database recreated with new source
```

---

## 🛠️ Key Implementation Details

### **Error Handling Pattern**

```python
try:
    # Operation
    log_success(\"Operation completed\")
except FileNotFoundError as e:
    log_error(f\"File not found: {e}\")
    raise
except ValueError as e:
    log_error(f\"Validation failed: {e}\")
    raise
except sqlite3.IntegrityError as e:
    log_error(f\"Database constraint violated: {e}\")
    raise
```

### **Data Validation Pattern**

```python
# Before insertion
if 'required_column' not in df.columns:
    log_error(\"Missing required column\")
    raise ValueError(\"Missing required column: required_column\")

# After insertion
actual_count = conn.execute(\"SELECT COUNT(*) FROM table\").fetchone()[0]
if actual_count != expected_count:
    log_warning(f\"Count mismatch: expected {expected_count}, got {actual_count}\")
```

### **FK Constraint Testing Pattern**

```python
try:
    # Try invalid insert
    conn.execute(\"INSERT INTO table (fk_col) VALUES (?)\", (99999,))
    log_error(\"FK constraint NOT working (insert succeeded)\")
except sqlite3.IntegrityError:
    log_success(\"FK constraint working (insert blocked)\")
```

---

## 📚 Dependencies

```python
import sqlite3
import pandas as pd
import hashlib
import gzip
import json
from pathlib import Path
from datetime import datetime, timedelta
```

---

## 🎓 Learning Outcomes

After running this notebook, you will have:

✅ A complete single-database system with enforced FKs
✅ Understanding of dual data source patterns
✅ Data validation techniques
✅ FK constraint testing methods
✅ Test data generation strategies
✅ Comprehensive error handling examples

---

## 🚀 Next Steps After Setup

1. **Run Pipeline**: `daily_version_tracking_pipeline.ipynb`
2. **Analyze Data**: `data_exploration.ipynb`
3. **Run Validation**: Execute `../sql/validation.sql`
4. **Check Views**: Query the 8 analytical views

---

## 📞 Support

For issues:
1. Check cell outputs for error messages
2. Verify DATA_SOURCE setting
3. Confirm Excel files exist (if using 'excel')
4. Check FK constraints are enabled
5. Review `../sql/create_schema_v4.sql` for schema details
