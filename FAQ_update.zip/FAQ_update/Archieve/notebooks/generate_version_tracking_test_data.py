"""
Version Tracking Test Data Generator V2

Creates a SINGLE database with incremental entries covering 2 ACTIVE scenarios:
- SCENARIO 1: Modify content (same page, version +1, checksum changes)
- SCENARIO 2: Insert new page (subsequent pages shift +1, version +1)
- SCENARIO 3: Delete page (COMMENTED OUT - can be enabled later)

All data in one content_repo.db table with entries added incrementally.
Database name: content_repo.db (same as production for easy switching)

To switch between test and production:
- Test: Run this script → creates content_repo.db with test data
- Production: Run setup_databases.ipynb → creates content_repo.db with real data
"""

import pandas as pd
import sqlite3
import hashlib
import json
from pathlib import Path
from datetime import datetime, timedelta

# Configuration
TEST_DATA_DIR = Path('test_data_version_tracking')
MARKDOWN_DIR = TEST_DATA_DIR / 'markdown_files'
DATABASE_DIR = Path('databases')

# Create directories
MARKDOWN_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_DIR.mkdir(parents=True, exist_ok=True)

def calculate_checksum(content: str) -> str:
    """Calculate SHA-256 checksum from content"""
    return hashlib.sha256(content.encode('utf-8')).hexdigest()

def create_markdown_file(file_path: Path, content: str) -> str:
    """Create markdown file and return checksum"""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return calculate_checksum(content)

# ==============================================================================
# SAMPLE MARKDOWN CONTENT
# ==============================================================================

POLICY_CONTENT = {
    # Original content (Day 1)
    'page1_v1': """# Employee Leave Policy

## 1. Purpose
This policy establishes guidelines for employee leave requests and approvals.

## 2. Scope
This policy applies to all full-time employees.

## 3. Annual Leave
- Employees accrue 15 days of annual leave per year
- Leave must be requested at least 2 weeks in advance
- Maximum carryover: 5 days to next year
""",

    'page2_v1': """## 4. Sick Leave
Employees are entitled to sick leave as follows:
- 10 days of paid sick leave per year
- Medical certificate required for absences over 3 consecutive days
- Unused sick leave does not carry over

## 5. Parental Leave
- 12 weeks of paid parental leave for primary caregiver
- 4 weeks of paid parental leave for secondary caregiver
""",

    'page3_v1': """## 6. Bereavement Leave
- 5 days for immediate family member
- 2 days for extended family member
- No documentation required

## 7. Leave Request Process
1. Submit request via HR portal
2. Manager approval required
3. Confirmation sent within 48 hours
""",

}

# ==============================================================================
# TIMELINE SETUP
# ==============================================================================

BASE_TIME = datetime(2025, 1, 1, 10, 0, 0)

def get_timestamp(days_offset: int, hours_offset: int = 0) -> str:
    """Generate ISO timestamp with offset"""
    dt = BASE_TIME + timedelta(days=days_offset, hours=hours_offset)
    return dt.strftime('%Y-%m-%dT%H:%M:%S.000Z')

# ==============================================================================
# ALL RECORDS IN CHRONOLOGICAL ORDER
# ==============================================================================

all_records = []

print("📅 Generating test data timeline...")

# ----------------------------------------------------------------------------
# DAY 1: INITIAL STATE (3 pages inserted)
# ----------------------------------------------------------------------------

print("\n📅 DAY 1 (2025-01-01): Initial state - 3 pages created")

# Create markdown files
md_path_p1_v1 = MARKDOWN_DIR / 'leave_policy' / 'page1_v1.md'
checksum_p1_v1 = create_markdown_file(md_path_p1_v1, POLICY_CONTENT['page1_v1'])

md_path_p2_v1 = MARKDOWN_DIR / 'leave_policy' / 'page2_v1.md'
checksum_p2_v1 = create_markdown_file(md_path_p2_v1, POLICY_CONTENT['page2_v1'])

md_path_p3_v1 = MARKDOWN_DIR / 'leave_policy' / 'page3_v1.md'
checksum_p3_v1 = create_markdown_file(md_path_p3_v1, POLICY_CONTENT['page3_v1'])

# Page 1 (v1) - INSERT on Day 1
all_records.append({
    'ud_source_file_id': 1001,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 1,
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p1_v1.absolute()),
    'extracted_layout_file_path': 'layout_p1.txt',
    'raw_file_page_nbr': 1,
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 1,
    'content_checksum': checksum_p1_v1,
    'file_status': 'Active',
    'created_dt': get_timestamp(0),
    'last_modified_dt': get_timestamp(0),
    'operation': 'INSERT',  # Track operation type for documentation
    'operation_date': '2025-01-01'
})

# Page 2 (v1) - INSERT on Day 1
all_records.append({
    'ud_source_file_id': 1002,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 1,
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p2_v1.absolute()),
    'extracted_layout_file_path': 'layout_p2.txt',
    'raw_file_page_nbr': 2,
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 1,
    'content_checksum': checksum_p2_v1,
    'file_status': 'Active',
    'created_dt': get_timestamp(0),
    'last_modified_dt': get_timestamp(0),
    'operation': 'INSERT',
    'operation_date': '2025-01-01'
})

# Page 3 (v1) - INSERT on Day 1
all_records.append({
    'ud_source_file_id': 1003,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 1,
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p3_v1.absolute()),
    'extracted_layout_file_path': 'layout_p3.txt',
    'raw_file_page_nbr': 3,
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 1,
    'content_checksum': checksum_p3_v1,
    'file_status': 'Active',
    'created_dt': get_timestamp(0),
    'last_modified_dt': get_timestamp(0),
    'operation': 'INSERT',
    'operation_date': '2025-01-01'
})

print(f"  ✅ Inserted 3 pages (id=1001, 1002, 1003)")


# ==============================================================================
# CREATE SINGLE DATABASE
# ==============================================================================

print("\n📊 Creating content_repo.db with all entries...")

# Convert to DataFrame
df_all = pd.DataFrame(all_records)

# Create database
conn = sqlite3.connect(DATABASE_DIR / 'content_repo.db')

# Create table
conn.execute("""
CREATE TABLE IF NOT EXISTS content_repo (
    ud_source_file_id INTEGER,
    domain TEXT,
    service TEXT,
    orgoid TEXT,
    associateoid TEXT,
    raw_file_nme TEXT,
    raw_file_type TEXT,
    raw_file_version_nbr INTEGER,
    source_url_txt TEXT,
    parent_location_txt TEXT,
    raw_file_path TEXT,
    extracted_markdown_file_path TEXT,
    extracted_layout_file_path TEXT,
    raw_file_page_nbr INTEGER,
    title_nme TEXT,
    breadcrumb_txt TEXT,
    content_tags_txt TEXT,
    version_nbr INTEGER,
    content_checksum TEXT,
    file_status TEXT,
    created_dt TEXT,
    last_modified_dt TEXT,
    operation TEXT,
    operation_date TEXT
)
""")

# Drop operation columns for final table (keep in df for documentation)
df_final = df_all.drop(columns=['operation', 'operation_date'])
df_final.to_sql('content_repo', conn, if_exists='replace', index=False)

conn.commit()

# Also keep the full version with operation tracking for reference
df_all.to_sql('content_repo_with_operations', conn, if_exists='replace', index=False)

conn.commit()

print(f"  ✅ Created content_repo table with {len(df_all)} entries")
print(f"  ✅ Created content_repo_with_operations table (with operation tracking)")

# ==============================================================================
# CREATE DOCUMENTATION
# ==============================================================================

documentation = f"""
# Version Tracking Test Data V2 - Single Database

## What Changed from V1

**V1 Approach (Multiple Tables):**
- Separate tables: content_repo_day1, content_repo_day2, etc.
- Each table was a complete snapshot
- Good for comparing states, but not realistic

**V2 Approach (Single Table - THIS VERSION):**
- Single content_repo table with all entries
- Entries inserted/updated chronologically
- Simulates real-world database operations
- **THIS IS HOW YOUR ACTUAL DATABASE WORKS**

## Database Structure

```
databases/
  content_repo.db
    Tables:
      - content_repo                    # Main table (same as production)
      - content_repo_with_operations    # Same + operation tracking columns
```

## Entry Timeline

The content_repo table contains **{len(df_all)} entries** representing operations over 4 days:

### DAY 1 (2025-01-01): Initial State
**Operations:** 3 INSERT statements

| ud_source_file_id | page_nbr | version | operation | last_modified_dt |
|-------------------|----------|---------|-----------|------------------|
| 1001 | 1 | 1 | INSERT | 2025-01-01T10:00:00.000Z |
| 1002 | 2 | 1 | INSERT | 2025-01-01T10:00:00.000Z |
| 1003 | 3 | 1 | INSERT | 2025-01-01T10:00:00.000Z |

**State after Day 1:** 3 active pages

---



## Final State Summary

### All Entries in content_repo (chronological order):

```
Entry | ID   | Page | Ver | Status   | Operation | Date       | Checksum
------|------|------|-----|----------|-----------|------------|----------
1     | 1001 | 1    | 1   | Active   | INSERT    | 2025-01-01 | {checksum_p1_v1[:16]}...
2     | 1002 | 2    | 1   | Active   | INSERT    | 2025-01-01 | {checksum_p2_v1[:16]}...
3     | 1003 | 3    | 1   | Active   | INSERT    | 2025-01-01 | {checksum_p3_v1[:16]}...
4     | 1002 | 2    | 2   | Active   | UPDATE    | 2025-01-02 |
5     | 1004 | 3    | 1   | Active   | INSERT    | 2025-01-03 |
6     | 1003 | 4    | 2   | Active   | UPDATE    | 2025-01-03 |
7     | 1002 | 2    | 2   | Inactive | DELETE    | 2025-01-04 |
8     | 1004 | 2    | 2   | Active   | UPDATE    | 2025-01-04 |
9     | 1003 | 3    | 3   | Active   | UPDATE    | 2025-01-04 |
```

**Total entries:** {len(df_all)}

---

## How to Use This Data

### Approach 1: Process All at Once
```python
import sqlite3
import pandas as pd

conn = sqlite3.connect('databases/content_repo.db')

# Load all entries
content_repo = pd.read_sql("SELECT * FROM content_repo", conn)

# Your pipeline processes this data
# It should detect all changes by comparing:
# - Multiple entries with same ud_source_file_id
# - Different last_modified_dt timestamps
# - Changed checksums, page numbers, versions
```

### Approach 2: Process Incrementally (Simulates Daily Pipeline)
```python
# Day 1: Process entries from 2025-01-01
day1_content = pd.read_sql(\"\"\"
    SELECT * FROM content_repo
    WHERE last_modified_dt = '2025-01-01T10:00:00.000Z'
\"\"\", conn)
# -> Should create 3 initial version records (v1 for each page)

# Day 2: Process entries from 2025-01-02
day2_content = pd.read_sql(\"\"\"
    SELECT * FROM content_repo
    WHERE last_modified_dt = '2025-01-02T10:00:00.000Z'
\"\"\", conn)
# -> Should create 1 version record (v2 for id=1002)

# Day 3: Process entries from 2025-01-03
day3_content = pd.read_sql(\"\"\"
    SELECT * FROM content_repo
    WHERE last_modified_dt = '2025-01-03T10:00:00.000Z'
\"\"\", conn)
# -> Should create 2 version records (v1 for id=1004, v2 for id=1003)

# Day 4: Process entries from 2025-01-04
day4_content = pd.read_sql(\"\"\"
    SELECT * FROM content_repo
    WHERE last_modified_dt = '2025-01-04T10:00:00.000Z'
\"\"\", conn)
# -> Should create 2 version records (v2 for id=1004, v3 for id=1003)
# -> Should deprecate FAQs for id=1002
```

### Approach 3: Query Latest State Per Content ID
```python
# Get latest entry for each content_id
latest_state = pd.read_sql(\"\"\"
    SELECT * FROM content_repo
    WHERE (ud_source_file_id, last_modified_dt) IN (
        SELECT ud_source_file_id, MAX(last_modified_dt)
        FROM content_repo
        GROUP BY ud_source_file_id
    )
    ORDER BY raw_file_page_nbr
\"\"\", conn)

# This shows final state:
# - id=1001: page 1, v1, Active
# - id=1002: page 2, v2, Inactive (deleted)
# - id=1004: page 2, v2, Active
# - id=1003: page 3, v3, Active
```

---

## Testing Your Pipeline

### Test 1: Detect Content Modification (Scenario 1)
```python
# Compare entries for id=1002
entry1 = content_repo[
    (content_repo['ud_source_file_id'] == 1002) &
    (content_repo['last_modified_dt'] == '2025-01-01T10:00:00.000Z')
].iloc[0]

entry2 = content_repo[
    (content_repo['ud_source_file_id'] == 1002) &
    (content_repo['last_modified_dt'] == '2025-01-02T10:00:00.000Z')
].iloc[0]

assert entry1['content_checksum'] != entry2['content_checksum']  # Content changed
assert entry1['raw_file_page_nbr'] == entry2['raw_file_page_nbr']  # Page same
assert entry2['version_nbr'] == entry1['version_nbr'] + 1  # Version incremented
```

### Test 2: Detect Page Insertion (Scenario 2)
```python
# Check for new content_id=1004 on Day 3
new_page = content_repo[
    (content_repo['ud_source_file_id'] == 1004) &
    (content_repo['last_modified_dt'] == '2025-01-03T10:00:00.000Z')
].iloc[0]

assert new_page['version_nbr'] == 1  # New page starts at v1
assert new_page['raw_file_page_nbr'] == 3  # Inserted at position 3

# Check that id=1003 shifted
shifted_page = content_repo[
    (content_repo['ud_source_file_id'] == 1003) &
    (content_repo['last_modified_dt'] == '2025-01-03T10:00:00.000Z')
].iloc[0]

assert shifted_page['raw_file_page_nbr'] == 4  # Shifted from 3 to 4
assert shifted_page['version_nbr'] == 2  # Version incremented
```

### Test 3: Detect Page Deletion (Scenario 3)
```python
# Check id=1002 marked inactive on Day 4
deleted_page = content_repo[
    (content_repo['ud_source_file_id'] == 1002) &
    (content_repo['last_modified_dt'] == '2025-01-04T10:00:00.000Z')
].iloc[0]

assert deleted_page['file_status'] == 'Inactive'

# Check that id=1004 and id=1003 shifted down
for content_id, expected_page, expected_version in [(1004, 2, 2), (1003, 3, 3)]:
    shifted = content_repo[
        (content_repo['ud_source_file_id'] == content_id) &
        (content_repo['last_modified_dt'] == '2025-01-04T10:00:00.000Z')
    ].iloc[0]

    assert shifted['raw_file_page_nbr'] == expected_page
    assert shifted['version_nbr'] == expected_version
```

---

## Expected Version Tracking Results

After processing the entire content_repo table, your version_history should contain **8 records**:

| version_history_id | content_id | page_number | version_sequence | change_type | previous_version_id |
|-------------------|------------|-------------|------------------|-------------|---------------------|
| 1 | 1001 | 1 | 1 | initial | NULL |
| 2 | 1002 | 2 | 1 | initial | NULL |
| 3 | 1003 | 3 | 1 | initial | NULL |
| 4 | 1002 | 2 | 2 | major | 2 |
| 5 | 1004 | 3 | 1 | initial | NULL |
| 6 | 1003 | 4 | 2 | minor | 3 |
| 7 | 1004 | 2 | 2 | minor | 5 |
| 8 | 1003 | 3 | 3 | minor | 6 |

**Version progression by content_id:**
- **1001**: 1 version (unchanged throughout)
- **1002**: 2 versions (v1 initial, v2 modified, then deleted)
- **1003**: 3 versions (v1 page 3, v2 page 4 after insert, v3 page 3 after delete)
- **1004**: 2 versions (v1 page 3 new insert, v2 page 2 after delete)

---

## Checksums Reference


---

## Key Differences from V1

1. **Single table** instead of separate day tables
2. **Multiple entries** for same content_id (representing updates)
3. **Realistic operation flow** (INSERT, UPDATE, DELETE via file_status)
4. **Timestamp-based filtering** to simulate incremental processing
5. **Operation tracking** (in content_repo_with_operations table)

This approach **mirrors your actual production database** where:
- Same content_id can appear multiple times
- last_modified_dt indicates when change occurred
- You need to identify latest state per content_id
- Changes detected by comparing entries with same content_id
"""

doc_path = TEST_DATA_DIR / 'README_SINGLE_DB.md'
with open(doc_path, 'w', encoding='utf-8') as f:
    f.write(documentation)

conn.close()

# ==============================================================================
# SUMMARY
# ==============================================================================

print("\n" + "="*80)
print("✅ TEST DATA GENERATION COMPLETE (V2 - Single Database)")
print("="*80)

print(f"\n📁 Files created:")
print(f"  - {len(list(MARKDOWN_DIR.glob('**/*.md')))} markdown files")
print(f"  - {DATABASE_DIR / 'content_repo.db'} (SINGLE DATABASE)")
print(f"  - {doc_path}")

print(f"\n📊 Database tables:")
print(f"  - content_repo ({len(df_all)} entries)")
print(f"  - content_repo_with_operations ({len(df_all)} entries with operation tracking)")

print(f"\n📄 Entries breakdown:")
entry_counts = df_all.groupby('operation_date').size()
for date, count in entry_counts.items():
    print(f"  - {date}: {count} entries")

print(f"\n📖 Documentation: {doc_path.name}")

print(f"\n🔍 Content IDs and their entries:")
for content_id in sorted(df_all['ud_source_file_id'].unique()):
    entries = df_all[df_all['ud_source_file_id'] == content_id]
    versions = entries['version_nbr'].tolist()
    operations = entries['operation'].tolist()
    print(f"  - ID {content_id}: {len(entries)} entries, versions {versions}, operations {operations}")

print("\n🎯 Next steps:")
print("  1. Review the single database: databases/content_repo.db")
print("  2. Query entries by timestamp to simulate daily processing")
print("  3. Test version tracking with realistic data flow")
print("  4. Verify all 3 scenarios are correctly detected")

print("\n" + "="*80)
