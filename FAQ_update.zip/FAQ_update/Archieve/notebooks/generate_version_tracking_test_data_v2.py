"""
Version Tracking Test Data Generator V2

Creates a SINGLE database with incremental entries covering 2 ACTIVE scenarios:
- SCENARIO 1: Modify content (same page, version +1, checksum changes)
- SCENARIO 2: Insert new page (subsequent pages shift +1, version +1)
- SCENARIO 3: Delete page (COMMENTED OUT - can be enabled later)

All data in one content_repo.db table with entries added incrementally.
Database name: content_repo.db (same as production for easy switching)

To switch between test and production:
- Test: Run this script → creates content_repo.db with test data
- Production: Run setup_databases.ipynb → creates content_repo.db with real data
"""

import pandas as pd
import sqlite3
import hashlib
import json
from pathlib import Path
from datetime import datetime, timedelta

# Configuration
TEST_DATA_DIR = Path('test_data_version_tracking')
MARKDOWN_DIR = TEST_DATA_DIR / 'markdown_files'
DATABASE_DIR = Path('databases')

# Create directories
MARKDOWN_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_DIR.mkdir(parents=True, exist_ok=True)

def calculate_checksum(content: str) -> str:
    """Calculate SHA-256 checksum from content"""
    return hashlib.sha256(content.encode('utf-8')).hexdigest()

def create_markdown_file(file_path: Path, content: str) -> str:
    """Create markdown file and return checksum"""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return calculate_checksum(content)

# ==============================================================================
# SAMPLE MARKDOWN CONTENT
# ==============================================================================

POLICY_CONTENT = {
    # SCENARIO 1: Modified content (page 2 updated on Day 2)
    'page2_v2': """## 4. Sick Leave (UPDATED)
Employees are entitled to sick leave as follows:
- **15 days** of paid sick leave per year (INCREASED FROM 10)
- Medical certificate required for absences over **2 consecutive days** (CHANGED FROM 3)
- Unused sick leave **can carry over up to 3 days** (NEW POLICY)

## 5. Parental Leave
- 12 weeks of paid parental leave for primary caregiver
- 4 weeks of paid parental leave for secondary caregiver
- **NEW: Additional 2 weeks unpaid leave available upon request**
""",

    # SCENARIO 2: New page inserted (becomes page 3 on Day 3, others shift)
    'page3_new': """## 5B. Remote Work During Parental Leave (NEW SECTION)
- Employees may request flexible remote work arrangements
- Available during final 4 weeks of parental leave
- Must be approved by manager and HR
- Subject to business needs and role requirements

## 5C. Parental Leave Return-to-Work Support
- Gradual return schedule available (min 20 hours/week)
- Lactation room access and break times provided
- Career development catch-up sessions offered
""",

    # Original page 3 (becomes page 4 on Day 3)
    'page3_v1': """## 6. Bereavement Leave
    - 5 days for immediate family member
    - 2 days for extended family member
    - No documentation required

    ## 7. Leave Request Process
    1. Submit request via HR portal
    2. Manager approval required
    3. Confirmation sent within 48 hours
    """,
}

# ==============================================================================
# TIMELINE SETUP
# ==============================================================================

BASE_TIME = datetime(2025, 1, 1, 10, 0, 0)

def get_timestamp(days_offset: int, hours_offset: int = 0) -> str:
    """Generate ISO timestamp with offset"""
    dt = BASE_TIME + timedelta(days=days_offset, hours=hours_offset)
    return dt.strftime('%Y-%m-%dT%H:%M:%S.000Z')

# ==============================================================================
# ALL RECORDS IN CHRONOLOGICAL ORDER
# ==============================================================================

all_records = []

print("📅 Generating test data timeline...")


# ----------------------------------------------------------------------------
# DAY 2: SCENARIO 1 - UPDATE PAGE 2 (content modification)
# ----------------------------------------------------------------------------

print("\n📅 DAY 2 (2025-01-02): SCENARIO 1 - Update page 2 content")

md_path_p2_v2 = MARKDOWN_DIR / 'leave_policy' / 'page2_v2.md'
checksum_p2_v2 = create_markdown_file(md_path_p2_v2, POLICY_CONTENT['page2_v2'])

# Page 2 (v2) - UPDATE on Day 2 (same id, modified content)
all_records.append({
    'ud_source_file_id': 1004,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 2,  # Version incremented
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p2_v2.absolute()),
    'extracted_layout_file_path': 'layout_p2_v2.txt',
    'raw_file_page_nbr': 2,  # SAME page number
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 2,  # Version incremented
    'content_checksum': checksum_p2_v2,  # NEW checksum
    'file_status': 'Active',
    'created_dt': get_timestamp(0),  # Original creation date
    'last_modified_dt': get_timestamp(1),  # Day 2
    'operation': 'UPDATE',
    'operation_date': '2025-01-02'
})

print(f"  ✅ Updated page 2 (id=1002): v1→v2, checksum changed")

# ----------------------------------------------------------------------------
# DAY 3: SCENARIO 2 - INSERT NEW PAGE 3 (shifts subsequent pages)
# ----------------------------------------------------------------------------

print("\n📅 DAY 3 (2025-01-03): SCENARIO 2 - Insert new page at position 3")

md_path_p3_v2 = MARKDOWN_DIR / 'leave_policy' / 'page3_v2.md'
checksum_p3_v2 = create_markdown_file(md_path_p3_v2, POLICY_CONTENT['page3_new'])

# New page 3 (v1) - INSERT on Day 3
all_records.append({
    'ud_source_file_id': 1005,  # NEW ID
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 2,
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p3_v2.absolute()),
    'extracted_layout_file_path': 'layout_p3_new.txt',
    'raw_file_page_nbr': 3,  # Inserted at position 3
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 2,  #
    'content_checksum': checksum_p3_v2,
    'file_status': 'Active',
    'created_dt': get_timestamp(2),
    'last_modified_dt': get_timestamp(2),  # Day 3
    'operation': 'INSERT',
    'operation_date': '2025-01-03'
})

print(f"  ✅ Inserted new page 3 (id=1004)")


md_path_p3_v1 = MARKDOWN_DIR / 'leave_policy' / 'page3_v1.md'
checksum_p3_v1 = create_markdown_file(md_path_p3_v1, POLICY_CONTENT['page3_v1'])

# Old page 3 → page 4 - UPDATE on Day 3 (position shift)
all_records.append({
    'ud_source_file_id': 1006,
    'domain': 'HR',
    'service': 'Policy Management',
    'orgoid': 'ORG001',
    'associateoid': 'ASSOC001',
    'raw_file_nme': 'Employee_Leave_Policy.pdf',
    'raw_file_type': '.pdf',
    'raw_file_version_nbr': 1,
    'source_url_txt': None,
    'parent_location_txt': None,
    'raw_file_path': '/test/Employee_Leave_Policy.pdf',
    'extracted_markdown_file_path': str(md_path_p3_v1.absolute()),  # SAME file
    'extracted_layout_file_path': 'layout_p3.txt',
    'raw_file_page_nbr': 4,
    'title_nme': 'Employee Leave Policy',
    'breadcrumb_txt': None,
    'content_tags_txt': None,
    'version_nbr': 1,
    'content_checksum': checksum_p3_v1,  # SAME checksum (content unchanged)
    'file_status': 'Active',
    'created_dt': get_timestamp(0),  # Original creation
    'last_modified_dt': get_timestamp(2),  # Day 3
    'operation': 'UPDATE',
    'operation_date': '2025-01-03'
})

print(f"  ✅ Shifted old page 3 to page 4 (id=1003): page 3→4, v1→v2")

# ----------------------------------------------------------------------------
# DAY 4: SCENARIO 3 - DELETE PAGE 2 (shifts subsequent pages)
# COMMENTED OUT - Can be enabled later for delete scenario testing
# ----------------------------------------------------------------------------

# print("\n📅 DAY 4 (2025-01-04): SCENARIO 3 - Delete page 2")

# # Page 2 deleted - UPDATE to mark Inactive
# all_records.append({
#     'ud_source_file_id': 1002,  # SAME ID
#     'domain': 'HR',
#     'service': 'Policy Management',
#     'orgoid': 'ORG001',
#     'associateoid': 'ASSOC001',
#     'raw_file_nme': 'Employee_Leave_Policy.pdf',
#     'raw_file_type': '.pdf',
#     'raw_file_version_nbr': 2,
#     'source_url_txt': None,
#     'parent_location_txt': None,
#     'raw_file_path': '/test/Employee_Leave_Policy.pdf',
#     'extracted_markdown_file_path': str(md_path_p2_v2.absolute()),
#     'extracted_layout_file_path': 'layout_p2_v2.txt',
#     'raw_file_page_nbr': 2,
#     'title_nme': 'Employee Leave Policy',
#     'breadcrumb_txt': None,
#     'content_tags_txt': None,
#     'version_nbr': 2,
#     'content_checksum': checksum_p2_v2,
#     'file_status': 'Inactive',  # DELETED
#     'created_dt': get_timestamp(0),
#     'last_modified_dt': get_timestamp(3),  # Day 4
#     'operation': 'DELETE',
#     'operation_date': '2025-01-04'
# })

# print(f"  ✅ Deleted page 2 (id=1002): marked Inactive")

# # Old page 3 → page 2 - UPDATE on Day 4
# all_records.append({
#     'ud_source_file_id': 1004,  # SAME ID
#     'domain': 'HR',
#     'service': 'Policy Management',
#     'orgoid': 'ORG001',
#     'associateoid': 'ASSOC001',
#     'raw_file_nme': 'Employee_Leave_Policy.pdf',
#     'raw_file_type': '.pdf',
#     'raw_file_version_nbr': 2,  # Version incremented
#     'source_url_txt': None,
#     'parent_location_txt': None,
#     'raw_file_path': '/test/Employee_Leave_Policy.pdf',
#     'extracted_markdown_file_path': str(md_path_p3_new_v1.absolute()),  # SAME file
#     'extracted_layout_file_path': 'layout_p3_new.txt',
#     'raw_file_page_nbr': 2,  # Page number shifted -1 (was 3, now 2)
#     'title_nme': 'Employee Leave Policy',
#     'breadcrumb_txt': None,
#     'content_tags_txt': None,
#     'version_nbr': 2,  # Version incremented
#     'content_checksum': checksum_p3_new_v1,  # SAME checksum
#     'file_status': 'Active',
#     'created_dt': get_timestamp(2),
#     'last_modified_dt': get_timestamp(3),  # Day 4
#     'operation': 'UPDATE',
#     'operation_date': '2025-01-04'
# })

# print(f"  ✅ Shifted page 3→2 (id=1004): page 3→2, v1→v2")

# # Old page 4 → page 3 - UPDATE on Day 4
# all_records.append({
#     'ud_source_file_id': 1003,  # SAME ID
#     'domain': 'HR',
#     'service': 'Policy Management',
#     'orgoid': 'ORG001',
#     'associateoid': 'ASSOC001',
#     'raw_file_nme': 'Employee_Leave_Policy.pdf',
#     'raw_file_type': '.pdf',
#     'raw_file_version_nbr': 3,  # Version incremented
#     'source_url_txt': None,
#     'parent_location_txt': None,
#     'raw_file_path': '/test/Employee_Leave_Policy.pdf',
#     'extracted_markdown_file_path': str(md_path_p3_v1.absolute()),  # SAME file
#     'extracted_layout_file_path': 'layout_p3.txt',
#     'raw_file_page_nbr': 3,  # Page number shifted -1 (was 4, now 3)
#     'title_nme': 'Employee Leave Policy',
#     'breadcrumb_txt': None,
#     'content_tags_txt': None,
#     'version_nbr': 3,  # Version incremented
#     'content_checksum': checksum_p3_v1,  # SAME checksum
#     'file_status': 'Active',
#     'created_dt': get_timestamp(0),
#     'last_modified_dt': get_timestamp(3),  # Day 4
#     'operation': 'UPDATE',
#     'operation_date': '2025-01-04'
# })

# print(f"  ✅ Shifted page 4→3 (id=1003): page 4→3, v2→v3")

print("\n⚠️  Scenario 3 (DELETE) is commented out - Enable by uncommenting above section")

# ==============================================================================
# CREATE SINGLE DATABASE
# ==============================================================================

print("\n📊 Creating content_repo.db with all entries...")

# Convert to DataFrame
df_all = pd.DataFrame(all_records)

# Create database
conn = sqlite3.connect(DATABASE_DIR / 'content_repo.db')

# Create table
conn.execute("""
CREATE TABLE IF NOT EXISTS content_repo (
    ud_source_file_id INTEGER,
    domain TEXT,
    service TEXT,
    orgoid TEXT,
    associateoid TEXT,
    raw_file_nme TEXT,
    raw_file_type TEXT,
    raw_file_version_nbr INTEGER,
    source_url_txt TEXT,
    parent_location_txt TEXT,
    raw_file_path TEXT,
    extracted_markdown_file_path TEXT,
    extracted_layout_file_path TEXT,
    raw_file_page_nbr INTEGER,
    title_nme TEXT,
    breadcrumb_txt TEXT,
    content_tags_txt TEXT,
    version_nbr INTEGER,
    content_checksum TEXT,
    file_status TEXT,
    created_dt TEXT,
    last_modified_dt TEXT,
    operation TEXT,
    operation_date TEXT
)
""")

# Drop operation columns for final table (keep in df for documentation)
df_final = df_all.drop(columns=['operation', 'operation_date'])
df_final.to_sql('content_repo', conn, if_exists='append', index=False)

conn.commit()

# Also keep the full version with operation tracking for reference
df_all.to_sql('content_repo_with_operations', conn, if_exists='append', index=False)

conn.commit()

print(f"  ✅ Created content_repo table with {len(df_all)} entries")
print(f"  ✅ Created content_repo_with_operations table (with operation tracking)")