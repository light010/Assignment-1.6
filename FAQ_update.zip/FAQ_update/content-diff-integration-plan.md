# Content Diff Integration Plan

## Overview
This document provides a detailed plan for integrating content diff functionality into the comprehensive-implementation-readme.md file.

## Integration Points

### 1. Table of Contents (Line 3-18)
**Action:** Add new section entry
**Location:** After line 14 (Content Diff Storage & Analysis)
```markdown
9. [Content Diff Storage & Analysis](#content-diff-storage-analysis)
```

### 2. Database Schema Section (Lines 112-346)
**Action:** Add content_diffs table after faq_content_map (after line 269)
**Content to add:**

```sql
#### 3. content_diffs
-- Purpose: Store detailed diffs for content edits (1:1 with content_change_log)
-- Key Innovation: Semantic understanding of what actually changed
CREATE TABLE content_diffs (
    change_id INTEGER PRIMARY KEY
        REFERENCES content_change_log(change_id) ON DELETE CASCADE,

    -- Checksums for validation
    old_checksum TEXT NOT NULL CHECK(length(old_checksum) = 64),
    new_checksum TEXT NOT NULL CHECK(length(new_checksum) = 64),

    -- The actual diff (compressed)
    unified_diff_gzip BLOB NOT NULL,

    -- Metrics for quick assessment
    similarity_score REAL NOT NULL CHECK(similarity_score BETWEEN 0 AND 1),
    chars_added INTEGER NOT NULL,
    chars_removed INTEGER NOT NULL,
    lines_added INTEGER NOT NULL,
    lines_removed INTEGER NOT NULL,
    is_minor_change BOOLEAN NOT NULL CHECK(is_minor_change IN (0,1)),

    -- Semantic analysis (JSON)
    semantic_summary TEXT,  -- JSON: {summary: [...], total_changes: N, stats: {...}}

    -- Processing metadata
    diff_generated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    processing_time_ms INTEGER,
    error_message TEXT
);

-- Trigger to enforce diffs only for content_edit changes
CREATE TRIGGER trg_content_diffs_only_for_edits
BEFORE INSERT ON content_diffs
WHEN (
    SELECT change_type
    FROM content_change_log
    WHERE change_id = NEW.change_id
) <> 'content_edit'
BEGIN
  SELECT RAISE(ABORT, 'content_diffs only allowed for content_edit changes');
END;

-- Performance indexes
CREATE INDEX idx_diffs_checksums ON content_diffs(old_checksum, new_checksum);
CREATE INDEX idx_diffs_similarity ON content_diffs(similarity_score);
CREATE INDEX idx_diffs_minor ON content_diffs(is_minor_change) WHERE is_minor_change = 0;
```

### 3. New Section: Content Diff Storage & Analysis (After line 346)
**Action:** Add completely new section
**Content:**

```markdown
## Content Diff Storage & Analysis

### Purpose

The content diff system provides detailed change analysis for content edits, enabling:
1. **Human-readable diffs** - See exactly what changed between versions
2. **Semantic understanding** - Know which headers, paragraphs, lists were modified
3. **Change magnitude assessment** - Distinguish minor typo fixes from major rewrites
4. **FAQ impact analysis** - Determine if changes affect FAQ-relevant sections

### Design Principles

1. **1:1 Relationship**: One diff per content_edit change
2. **Compressed Storage**: Unified diffs stored as gzipped BLOBs
3. **Quick Metrics**: Pre-calculated similarity scores and change counts
4. **Semantic Analysis**: JSON summary of structural changes
5. **On-Demand Processing**: Diffs generated asynchronously after change detection

### Schema Details

See `content_diffs` table in Database Schema section.

### Key Features

#### Similarity Scoring
- **0.0 - 0.3**: Major rewrite (likely new content)
- **0.3 - 0.7**: Significant changes (review recommended)
- **0.7 - 0.9**: Moderate changes (minor updates)
- **0.9 - 1.0**: Minor changes (typos, formatting)

#### Semantic Summary Structure
```json
{
  "summary": [
    "Removed Header: \"Old Title\"",
    "Added Header: \"New Title\"",
    "Paragraph P3: appended \"additional text\""
  ],
  "total_changes": 15,
  "stats": {
    "headers_changed": 2,
    "paragraphs_changed": 3,
    "list_items_changed": 0,
    "links_changed": 1
  }
}
```

#### Unified Diff Format
Standard unified diff format (gzip compressed):
```diff
--- old_content
+++ new_content
@@ -1,5 +1,6 @@
 # Security Policy

-Our security guidelines apply to all employees.
+Our enhanced security guidelines apply to all employees and contractors.
+
+## New Section: Multi-Factor Authentication
```

### Implementation

See ContentDiffProcessor and EnhancedContentDiffProcessor classes in Implementation Steps section.
```

### 4. Migration SQL Scripts (After line 721)
**Action:** Add content_diffs to migration_001_create_tracking_schema.sql
**Location:** After faq_content_map creation, before VIEW creation

```sql
-- Table 3: Content diffs (detailed change analysis)
CREATE TABLE content_diffs (
    change_id INTEGER PRIMARY KEY
        REFERENCES content_change_log(change_id) ON DELETE CASCADE,
    old_checksum TEXT NOT NULL CHECK(length(old_checksum) = 64),
    new_checksum TEXT NOT NULL CHECK(length(new_checksum) = 64),
    unified_diff_gzip BLOB NOT NULL,
    similarity_score REAL NOT NULL CHECK(similarity_score BETWEEN 0 AND 1),
    chars_added INTEGER NOT NULL,
    chars_removed INTEGER NOT NULL,
    lines_added INTEGER NOT NULL,
    lines_removed INTEGER NOT NULL,
    is_minor_change BOOLEAN NOT NULL CHECK(is_minor_change IN (0,1)),
    semantic_summary TEXT,
    diff_generated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    processing_time_ms INTEGER,
    error_message TEXT
);

-- Trigger to enforce diffs only for content_edit changes
CREATE TRIGGER trg_content_diffs_only_for_edits
BEFORE INSERT ON content_diffs
WHEN (
    SELECT change_type
    FROM content_change_log
    WHERE change_id = NEW.change_id
) <> 'content_edit'
BEGIN
  SELECT RAISE(ABORT, 'content_diffs only allowed for content_edit changes');
END;

CREATE INDEX idx_diffs_checksums ON content_diffs(old_checksum, new_checksum);
CREATE INDEX idx_diffs_similarity ON content_diffs(similarity_score);
CREATE INDEX idx_diffs_minor ON content_diffs(is_minor_change) WHERE is_minor_change = 0;
```

### 5. Implementation Steps - Add ContentDiffProcessor Class
**Action:** Add after ParallelTrackingPipeline class (after line 1503)
**Content:** Full ContentDiffProcessor and EnhancedContentDiffProcessor implementations

### 6. Update ContentTrackingPipeline.process_daily_updates()
**Action:** Add diff processing step (around line 1830)
**Location:** After _update_faq_mappings call

```python
# 4. Process content diffs
diff_processor = ContentDiffProcessor(self.content_db, self.tracking_db)
diff_results = diff_processor.process_pending_diffs()

# 5. Generate impact report (updated to include diff results)
impact_report = self._generate_impact_report(changes, faq_results, diff_results)
```

### 7. Add Diff Helper Methods to ContentTrackingPipeline
**Action:** Add after _calculate_file_checksum (after line 2484)

```python
def _get_content_by_checksum(self, checksum: str) -> Optional[str]:
    """Retrieve content text by checksum for diff generation."""
    with sqlite3.connect(self.content_db) as conn:
        result = conn.execute("""
            SELECT extracted_markdown_file_path
            FROM content_repo
            WHERE content_checksum = ?
            LIMIT 1
        """, (checksum,)).fetchone()

        if result and result[0]:
            try:
                with open(result[0], 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                self.logger.error(f"Failed to read content: {e}")
        return None
```

### 8. Performance Considerations Section Updates
**Action:** Add after existing indexes (after line 3145)

```sql
-- Content diff indexes
CREATE INDEX idx_diffs_checksums ON content_diffs(old_checksum, new_checksum);
CREATE INDEX idx_diffs_similarity ON content_diffs(similarity_score);
CREATE INDEX idx_diffs_minor ON content_diffs(is_minor_change) WHERE is_minor_change = 0;
```

**Action:** Add monitoring queries (after line 3171)

```sql
-- Monitor diff processing
SELECT
    COUNT(*) as total_edits,
    COUNT(cd.change_id) as diffs_generated,
    COUNT(*) - COUNT(cd.change_id) as pending_diffs,
    AVG(cd.processing_time_ms) as avg_processing_ms,
    COUNT(CASE WHEN cd.is_minor_change = 1 THEN 1 END) as minor_changes,
    COUNT(CASE WHEN cd.similarity_score < 0.5 THEN 1 END) as major_changes
FROM content_change_log ccl
LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
WHERE ccl.change_type = 'content_edit';

-- Find slowest diff generations
SELECT
    ccl.file_name,
    ccl.page_number,
    ccl.effective_date,
    cd.processing_time_ms,
    cd.chars_added + cd.chars_removed as total_chars_changed
FROM content_diffs cd
JOIN content_change_log ccl ON cd.change_id = ccl.change_id
ORDER BY cd.processing_time_ms DESC
LIMIT 10;
```

### 9. Troubleshooting Guide Updates
**Action:** Add after "Cross-Database Foreign Key Validation Errors" (after line 3309)

```markdown
#### 5. Diff Processing Issues

**Problem:** Diffs not being generated for content edits
```python
# Check for pending diffs
with sqlite3.connect(tracking_db) as conn:
    pending = pd.read_sql("""
        SELECT ccl.change_id, ccl.file_name, ccl.page_number
        FROM content_change_log ccl
        LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
        WHERE ccl.change_type = 'content_edit'
          AND cd.change_id IS NULL
        LIMIT 10
    """, conn)
    print(f"Pending diffs: {len(pending)}")
```

**Problem:** Diff generation failing
```python
# Debug diff generation
processor = ContentDiffProcessor(content_db, tracking_db)
try:
    result = processor._generate_diff(old_content, new_content, old_checksum, new_checksum)
    print(f"Diff generated: {result['chars_added']} chars added, {result['chars_removed']} removed")
except Exception as e:
    print(f"Diff generation failed: {e}")
    import traceback
    traceback.print_exc()
```

**Problem:** Semantic summary not parsing
```sql
-- Test JSON parsing
SELECT
    change_id,
    json_extract(semantic_summary, '$.total_changes') as total_changes,
    json_extract(semantic_summary, '$.stats') as stats
FROM content_diffs
WHERE semantic_summary IS NOT NULL
LIMIT 5;
```
```

### 10. Appendix: Complete Schema DDL Updates
**Action:** Add content_diffs table (after line 3449, after faq_content_map)

```sql
-- ============================================================================
-- Table 3: Content Diffs (detailed change analysis)
-- ============================================================================
CREATE TABLE content_diffs (
    change_id INTEGER PRIMARY KEY
        REFERENCES content_change_log(change_id) ON DELETE CASCADE,
    old_checksum TEXT NOT NULL CHECK(length(old_checksum) = 64),
    new_checksum TEXT NOT NULL CHECK(length(new_checksum) = 64),
    unified_diff_gzip BLOB NOT NULL,
    similarity_score REAL NOT NULL CHECK(similarity_score BETWEEN 0 AND 1),
    chars_added INTEGER NOT NULL,
    chars_removed INTEGER NOT NULL,
    lines_added INTEGER NOT NULL,
    lines_removed INTEGER NOT NULL,
    is_minor_change BOOLEAN NOT NULL CHECK(is_minor_change IN (0,1)),
    semantic_summary TEXT,  -- JSON
    diff_generated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    processing_time_ms INTEGER,
    error_message TEXT
);

-- Trigger to enforce diffs only for content_edit changes
CREATE TRIGGER trg_content_diffs_only_for_edits
BEFORE INSERT ON content_diffs
WHEN (
    SELECT change_type
    FROM content_change_log
    WHERE change_id = NEW.change_id
) <> 'content_edit'
BEGIN
  SELECT RAISE(ABORT, 'content_diffs only allowed for content_edit changes');
END;

CREATE INDEX idx_diffs_checksums ON content_diffs(old_checksum, new_checksum);
CREATE INDEX idx_diffs_similarity ON content_diffs(similarity_score);
CREATE INDEX idx_diffs_minor ON content_diffs(is_minor_change) WHERE is_minor_change = 0;
```

**Action:** Add utility views (after line 3554)

```sql
-- View: Content changes with diff analysis
CREATE VIEW v_content_changes_with_diffs AS
SELECT
    ccl.change_id,
    ccl.file_name,
    ccl.page_number,
    ccl.effective_date,
    ccl.content_checksum as new_checksum,
    ccl.previous_checksum as old_checksum,
    cd.similarity_score,
    cd.chars_added,
    cd.chars_removed,
    cd.lines_added,
    cd.lines_removed,
    cd.is_minor_change,
    CASE
        WHEN cd.similarity_score >= 0.9 THEN 'Minor'
        WHEN cd.similarity_score >= 0.7 THEN 'Moderate'
        WHEN cd.similarity_score >= 0.3 THEN 'Significant'
        ELSE 'Major'
    END as change_magnitude,
    json_extract(cd.semantic_summary, '$.stats.headers_changed') as headers_changed,
    json_extract(cd.semantic_summary, '$.stats.paragraphs_changed') as paragraphs_changed,
    json_extract(cd.semantic_summary, '$.total_changes') as total_semantic_changes
FROM content_change_log ccl
LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
WHERE ccl.change_type = 'content_edit';
```

### 11. Success Criteria Updates
**Action:** Add to success criteria (after line 3321)

```markdown
6. **Diff coverage complete** - All content edits have corresponding diffs
7. **Semantic analysis accurate** - Structural changes correctly identified
```

### 12. Testing & Validation Updates
**Action:** Add test cases (after line 2980)

```python
def test_diff_generation(self):
    """Test that diffs are generated for content edits."""
    # Create content edit
    old_content = "# Header\n\nOriginal text"
    new_content = "# Header\n\nModified text with additions"

    processor = ContentDiffProcessor(content_db, tracking_db)
    diff_data = processor._generate_diff(
        old_content, new_content,
        'abc123...', 'def456...'
    )

    # Verify diff metrics
    self.assertGreater(diff_data['chars_added'], 0)
    self.assertTrue(0 <= diff_data['similarity_score'] <= 1)
    self.assertIsNotNone(diff_data['unified_diff'])

def test_semantic_diff_detection(self):
    """Test semantic markdown analysis."""
    old_md = "# Title\n\nParagraph one.\n\n- Item 1"
    new_md = "# New Title\n\nParagraph one modified.\n\n- Item 1\n- Item 2"

    processor = EnhancedContentDiffProcessor(content_db, tracking_db)
    result = processor._generate_semantic_diff(old_md, new_md)

    # Verify semantic summary
    self.assertGreater(result['stats']['headers_changed'], 0)
    self.assertGreater(result['stats']['list_items_changed'], 0)
    self.assertGreater(result['total_changes'], 0)
```

## Implementation Order

1. ✅ **Table of Contents** - Simple text addition
2. ✅ **Database Schema Section** - Add content_diffs table documentation
3. ✅ **New Section** - Add Content Diff Storage & Analysis
4. ✅ **Migration SQL** - Add content_diffs to migration script
5. ✅ **Code Implementation** - Add ContentDiffProcessor classes
6. ✅ **Pipeline Integration** - Update process_daily_updates
7. ✅ **Performance Section** - Add indexes and monitoring
8. ✅ **Troubleshooting** - Add diff debugging procedures
9. ✅ **Appendix DDL** - Update complete schema
10. ✅ **Testing** - Add test cases
11. ✅ **Success Criteria** - Update validation criteria

## Validation Checklist

- [ ] All code blocks have proper syntax highlighting
- [ ] All cross-references are updated
- [ ] No duplicate section numbers
- [ ] All SQL is valid SQLite syntax
- [ ] Python code follows existing style
- [ ] Time semantics consistent (ISO-8601 UTC)
- [ ] Foreign key constraints documented
- [ ] Indexes match query patterns
- [ ] Error handling comprehensive
- [ ] Examples are complete and runnable

## Risk Assessment

**Low Risk:**
- Adding new table (doesn't affect existing tables)
- New section additions (informational only)
- Adding indexes (performance improvement)

**Medium Risk:**
- Modifying process_daily_updates (adds new step)
- Adding trigger constraint (must validate logic)

**Mitigation:**
- Test all SQL in isolated database first
- Verify trigger logic before deployment
- Make process_daily_updates diff processing optional initially
- Ensure rollback scripts include DROP TRIGGER statements
