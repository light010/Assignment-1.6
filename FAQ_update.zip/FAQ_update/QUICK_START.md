# Quick Start Guide - Granular Impact Analysis

## Installation

```bash
# Navigate to the module directory
cd FAQ_update

# Install dependencies
pip install -r requirements.txt

# Optional: Install embedding support
pip install sentence-transformers torch
```

## Basic Usage

### 1. Simple Similarity Comparison

```python
from granular_impact.similarity import HybridSimilarityCalculator

# Initialize calculator
calc = HybridSimilarityCalculator()

# Compare two texts
old_text = "Employees must submit expense reports within 30 days."
new_text = "Employees must submit expense reports within 45 days."

result = calc.compute_similarity(old_text, new_text)

print(f"Similarity Score: {result.score:.3f}")
print(f"Processing Time: {result.processing_time_ms:.2f}ms")
print(f"Individual Scores: {result.metadata['individual_scores']}")
```

### 2. Full Impact Analysis

```python
from granular_impact.config import GranularImpactConfig, Environment
from granular_impact.similarity import HybridSimilarityCalculator
from granular_impact.diff import DiffEngine, SemanticDetector
from granular_impact.impact import ImpactAnalyzer

# Load configuration
config = GranularImpactConfig.from_environment(Environment.DIT)

# Initialize components
similarity_calc = HybridSimilarityCalculator()
diff_engine = DiffEngine()
semantic_detector = SemanticDetector()

# Create analyzer
analyzer = ImpactAnalyzer(config, similarity_calc, diff_engine, semantic_detector)

# Analyze impact
result = analyzer.analyze_impact(
    faq_id="faq_001",
    content_id="content_123",
    old_content="Old content here...",
    new_content="New content here...",
    old_checksum="abc123",
    new_checksum="def456"
)

print(f"Impact Decision: {result.impact_decision}")
print(f"Overall Score: {result.overall_impact_score:.3f}")
print(f"Similarity: {result.similarity_score:.3f}")
print(f"Diff Magnitude: {result.diff_magnitude:.3f}")
print(f"Semantic Importance: {result.semantic_importance:.3f}")
```

### 3. Databricks Workflow

#### Step 1: Set up schema
Run notebook `notebooks/01_schema_setup.py` in Databricks

#### Step 2: Test algorithms
Run notebook `notebooks/02_test_similarity.py` to validate

#### Step 3: Run detection
Execute `notebooks/03_run_detection.py` on your data

#### Step 4: Analyze results
Review results with `notebooks/04_analyze_results.py`

## Configuration

### Environment Presets

```python
from granular_impact.config import Environment

# Development
config = GranularImpactConfig.from_environment(Environment.DIT)

# Production
config = GranularImpactConfig.from_environment(Environment.PROD)

# Local testing
config = GranularImpactConfig.from_environment(Environment.LOCAL)
```

### Custom Configuration

```python
# Override specific settings
config = GranularImpactConfig.from_environment(
    Environment.DIT,
    similarity_algorithm="hybrid",
    similarity_weights={
        "jaccard": 0.2,
        "tfidf": 0.4,
        "bm25": 0.4
    }
)
```

## Testing Individual Algorithms

```python
from granular_impact.similarity import (
    JaccardSimilarityCalculator,
    TfidfSimilarityCalculator,
    BM25SimilarityCalculator
)

text1 = "Sample text one"
text2 = "Sample text two"

# Jaccard
jaccard = JaccardSimilarityCalculator()
result = jaccard.compute_similarity(text1, text2)
print(f"Jaccard: {result.score:.3f}")

# TF-IDF
tfidf = TfidfSimilarityCalculator()
result = tfidf.compute_similarity(text1, text2)
print(f"TF-IDF: {result.score:.3f}")

# BM25
bm25 = BM25SimilarityCalculator()
result = bm25.compute_similarity(text1, text2)
print(f"BM25: {result.score:.3f}")
```

## Monitoring & Metrics

```python
from granular_impact.utils import MetricsCollector

metrics = MetricsCollector()

# Track operation
with metrics.track_operation("similarity_computation"):
    result = calc.compute_similarity(text1, text2)

# Get summary
summary = metrics.get_summary()
print(f"Total operations: {summary['total_operations']}")
print(f"Average duration: {summary['average_duration_ms']:.2f}ms")
```

## Next Steps

1. Read [README.md](granular_impact/README.md) for detailed documentation
2. Review [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) for architecture
3. Run tests: `pytest tests/`
4. Deploy to Databricks and run notebooks

## Support

For questions or issues, contact the Analytics Assist team.
