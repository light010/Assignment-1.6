"""
Demo: Human-Readable Diff Output for LLM Prompts

This script demonstrates how to use the DiffFormatter to generate
LLM-ready output from content changes.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / 'src'))

from formatters.diff_formatter import DiffFormatter

# Initialize formatter
db_path = 'databases/faq_update.db'
formatter = DiffFormatter(db_path, db_path)

print("="*100)
print("DEMO: HUMAN-READABLE DIFF OUTPUT FOR LLM PROMPTS")
print("="*100)

print("\n" + "="*100)
print("SCENARIO 1: Quick FAQ Generation (Single Change)")
print("="*100)

# Get concise LLM-ready context
change_id = 4
llm_context = formatter.get_llm_prompt_context(change_id)

print("\n📤 What you send to LLM:\n")
print("-"*100)
prompt = f"""You are an expert FAQ writer. Based on the following content change,
generate 3 frequently asked questions with clear, concise answers.

{llm_context}

Format as:
Q: [question]
A: [answer]
"""
print(prompt)
print("-"*100)

print("\n💡 Use case: Direct FAQ generation from API")
print("   → Copy the text above and send to ChatGPT/Claude")
print("   → Or use OpenAI/Anthropic API programmatically")

print("\n" + "="*100)
print("SCENARIO 2: Batch Review (Multiple Changes)")
print("="*100)

# Get batch summary
batch_summary = formatter.get_batch_summary()

print("\n📊 Batch Summary for Content Team:\n")
print("-"*100)
print(batch_summary)
print("-"*100)

print("\n💡 Use case: Daily digest email to content team")
print("   → Shows all changes at a glance")
print("   → Helps prioritize which need FAQs")

print("\n" + "="*100)
print("SCENARIO 3: Comprehensive Analysis (Full Context)")
print("="*100)

# Get detailed summary
full_summary = formatter.get_human_readable_summary(change_id)

print("\n📋 Full Summary for Deep Analysis:\n")
print("-"*100)
print(full_summary[:1000])  # First 1000 chars
print("\n... (truncated, see full output in notebook)")
print("-"*100)

print("\n💡 Use case: SME review, detailed documentation")
print("   → Includes full diff with before/after")
print("   → Shows interpretation and metrics")

print("\n" + "="*100)
print("SCENARIO 4: LLM API Integration Example")
print("="*100)

print("""
# Example: Using with OpenAI API

import openai
from formatters.diff_formatter import DiffFormatter

def generate_faqs_openai(change_id: int, api_key: str):
    # Get context
    formatter = DiffFormatter('databases/faq_update.db', 'databases/faq_update.db')
    context = formatter.get_llm_prompt_context(change_id)

    # Build prompt
    prompt = f'''
You are an expert FAQ writer for HR policies.

{context}

Generate 3-5 FAQs that employees would ask about these changes.
Format as JSON array with: question, answer, confidence
'''

    # Call OpenAI
    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert FAQ writer."},
            {"role": "user", "content": prompt}
        ],
        response_format={"type": "json_object"}
    )

    return response.choices[0].message.content

# Usage
# faqs = generate_faqs_openai(change_id=4, api_key=YOUR_API_KEY)
# print(faqs)
""")

print("\n💡 Use case: Automated FAQ generation pipeline")
print("   → Runs nightly for all new changes")
print("   → Stores generated FAQs in database")

print("\n" + "="*100)
print("COMPARISON: Before vs After")
print("="*100)

print("\n❌ BEFORE (Raw Database Output - NOT LLM-Ready):\n")
print("""
change_id                 file_name  page  similarity_score  chars_added  chars_removed
        4 Employee_Leave_Policy.pdf     2          0.661905          146              0
""")

print("\n✅ AFTER (Human-Readable Output - LLM-Ready):\n")
print(llm_context[:300] + "...\n")

print("\n" + "="*100)
print("KEY BENEFITS")
print("="*100)

print("""
1. ✅ Natural language descriptions
2. ✅ Context-rich bullet points
3. ✅ Clear change magnitude indicators
4. ✅ Ready for direct LLM consumption
5. ✅ No manual formatting needed
6. ✅ Consistent output format
7. ✅ Includes all relevant context
8. ✅ Optimized for prompt injection
""")

print("\n" + "="*100)
print("NEXT STEPS")
print("="*100)

print("""
1. Run notebooks/3_update_detector.ipynb to see output in action
2. Try the examples in LLM_PROMPT_TEMPLATES.md
3. Integrate with your LLM API (OpenAI, Claude, etc.)
4. Customize prompt templates for your use case
5. Set up automated FAQ generation pipeline

See HUMAN_READABLE_DIFFS_COMPLETE.md for full documentation.
""")

print("\n" + "="*100)
print("✅ DEMO COMPLETE")
print("="*100)
