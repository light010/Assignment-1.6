# Hydra-Based FAQ Update Pipeline - Final Design Document V2

**Date:** 2025-10-20
**Author:** Senior Code Architect
**Version:** 2.0 (Revised with Confirmed Requirements)
**Status:** Ready for Implementation

---

## 📋 Executive Summary

This document outlines the **production-ready Hydra-based FAQ Update Pipeline** that intelligently detects content changes and updates FAQs accordingly. The pipeline uses a **multi-tier checksum-centric approach** with intelligent question-level similarity matching to minimize unnecessary regeneration while ensuring FAQ accuracy.

**Key Innovation:** Two-phase detection system that distinguishes between "Modified Content" (incremental updates) and "Different Content" (new topics), applying different update strategies for each.

---

## 🎯 Core Architecture: Multi-Tier Checksum-Centric

### Tier 1: Content-Level Detection (Checksum Comparison)
```
Content Checksum Match?
├─ YES → Preserve existing FAQs (no regeneration needed)
└─ NO → Proceed to Tier 2 (content changed or new)
```

### Tier 2: Question-Level Analysis (Similarity Matching)
```
Calculate percentage_match = (similar_questions / total_old_faqs)

IF percentage_match > 50%:
    → PATH A: Modified Content (incremental update)
ELSE:
    → PATH B: Different Content (new topics)
```

### Tier 3: Answer-Level Validation (Quality Check)
```
For matched questions:
    Compare old_answer with new_answer
    IF similarity > 0.9:
        → Evaluate quality and decide (keep old vs replace)
    ELSE:
        → Update answer (content changed)
```

---

## 📊 Detailed Pipeline Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                   FAQ UPDATE PIPELINE WORKFLOW                       │
└─────────────────────────────────────────────────────────────────────┘

PHASE 1: CONTENT DETECTION
───────────────────────────
[1] Load Recent Content Changes
    ├─ Query content_repo WHERE last_modified_dt > since_date
    ├─ Calculate checksum for each content
    └─ Output: List[Document] with content metadata

[2] Compare with Baseline
    ├─ Load baseline checksums (all previous checksums for file)
    ├─ Decision: checksum IN baseline? → Skip / Continue
    └─ Output: Documents enriched with requires_faq_regeneration flag

[3] Log Detection Results
    ├─ Insert to content_change_log (idempotent)
    └─ Track: content_id, checksum, requires_faq_regeneration

PHASE 2: QUESTION GENERATION & MATCHING
────────────────────────────────────────
[4] MultiPipeline Split (Based on requires_faq_regeneration):

    ┌─────────────────────────────────────────────────────────────┐
    │ Pipeline A: Preserve Existing FAQs (requires_regen = 0)     │
    ├─────────────────────────────────────────────────────────────┤
    │ [5] Load Existing FAQs for Checksums                        │
    │     ├─ Query: faq_questions WHERE src_id = content_id      │
    │     │         AND status = 'Active'                         │
    │     └─ Output: Existing validated FAQs                      │
    └─────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────────┐
    │ Pipeline B: Process Changed Content (requires_regen = 1)    │
    ├─────────────────────────────────────────────────────────────┤
    │ [6] Load Markdown Content                                   │
    │     └─ Read from extracted_markdown_file_path               │
    │                                                              │
    │ [7] Generate New Questions                                  │
    │     ├─ Use LLM to generate questions from content          │
    │     └─ Output: List of candidate questions                  │
    │                                                              │
    │ [8] Load Existing FAQs for File                            │
    │     ├─ Query: faq_questions WHERE src_file_name = file     │
    │     │         AND status = 'Active'                         │
    │     └─ Output: All active FAQs for this file                │
    │                                                              │
    │ [9] Calculate Similarity Frequency                          │
    │     ├─ For each new_question:                              │
    │     │   ├─ Find best matching old_question (score > 0.95)  │
    │     │   ├─ Generate answer for new_question                │
    │     │   ├─ Compare with old_answer                         │
    │     │   └─ If ans_sim > 0.9: increment count for src_id   │
    │     ├─ Calculate percentage_match per src_id               │
    │     │   = match_count / total_active_faqs_for_src_id       │
    │     └─ Find dominant src_id (highest percentage)           │
    │                                                              │
    │ [10] Decision Branch (percentage_match > 50%?)              │
    │                                                              │
    │      ┌──────────────────────────────────────────┐          │
    │      │ PATH A: Modified Content (>50% match)    │          │
    │      ├──────────────────────────────────────────┤          │
    │      │ [11] Calculate Content Diff               │          │
    │      │      └─ compare(old_content, new_content) │          │
    │      │                                            │          │
    │      │ [12] Identify Impacted FAQs (Hybrid)      │          │
    │      │      ├─ Extract keywords from diff        │          │
    │      │      ├─ Rule-based filtering              │          │
    │      │      └─ LLM verification (batched)        │          │
    │      │                                            │          │
    │      │ [13] Process Matched Questions            │          │
    │      │      ├─ For each (new_q, old_q) pair:    │          │
    │      │      │   ├─ If impacted: UPDATE           │          │
    │      │      │   └─ If not: KEEP                  │          │
    │      │      ├─ For unmatched new: CREATE         │          │
    │      │      └─ For unmatched old: RECONCILE      │          │
    │      └──────────────────────────────────────────┘          │
    │                                                              │
    │      ┌──────────────────────────────────────────┐          │
    │      │ PATH B: Different Content (≤50% match)   │          │
    │      ├──────────────────────────────────────────┤          │
    │      │ [14] Process Each New Question           │          │
    │      │      ├─ Find best match (adaptive thresh)│          │
    │      │      ├─ If matched & ans_sim > 0.9:      │          │
    │      │      │   └─ Evaluate quality → KEEP/REPLACE│        │
    │      │      ├─ If matched & ans_sim ≤ 0.9:      │          │
    │      │      │   └─ UPDATE_ANSWER                 │          │
    │      │      └─ If no match:                      │          │
    │      │          └─ CREATE new FAQ                │          │
    │      │                                            │          │
    │      │ [15] Reconcile Unmatched Old FAQs        │          │
    │      │      └─ Flag for review or deprecate     │          │
    │      └──────────────────────────────────────────┘          │
    └─────────────────────────────────────────────────────────────┘

[16] Merge Pipelines
     └─ DocumentsConcat (Pipeline A + Pipeline B)

PHASE 3: CONTEXT ENRICHMENT (Same as test2.yaml)
─────────────────────────────────────────────────
[17] Generate Embeddings
     └─ For questions (if not already embedded)

[18] Retrieve Context (OpenSearch)
     ├─ WeightedOpensearchRetriever
     └─ Dual vector similarity (content + query)

[19] Deduplicate Context
     └─ Remove duplicate chunks by hash_id

[20] Filter Context Quality
     └─ Minimum chunk count, relevance thresholds

[21] Get Context Employed
     └─ Track which context chunks were actually used

[22] Compute Semantic Distances
     └─ Question-context, answer-context, Q-A distances

[23] Filter by Distance Thresholds
     └─ Quality gates (configurable per metric)

PHASE 4: OUTPUT & PERSISTENCE
───────────────────────────────
[24] Update faq_questions Table
     ├─ CREATE: Insert new questions
     ├─ UPDATE: Modify existing questions/answers
     ├─ DEPRECATE: Mark removed topics as Deprecated
     └─ KEEP: No action (already current)

[25] Format HTML
     └─ Enforce allowed tags, clean markup

[26] Add Pipeline Metadata
     ├─ pipeline_step: "faq_update"
     ├─ detection_run_id: ${job.run_id}
     └─ version, timestamp, etc.

[27] Save to QA Bank (Partitioned Dataset)
     └─ By execution_date and pipeline_step

[28] Save to CSV (Backup)
     └─ Full audit trail

[29] Save to Label Studio (Validation)
     └─ Only newly created/updated FAQs

[30] Final Visualization
     └─ Debug output (optional)
```

---

## 🔧 Custom Components Specification

### 1. ContentRepoLoader

**File:** `src/faq_services/settings/sors/analytics_assist_config/components/content_repo_loader.py`

```python
"""
Content Repository Loader for FAQ Update Pipeline.

Loads content changes from content_repo database table based on modification date.
Calculates checksums and prepares documents for FAQ regeneration detection.
"""

import sqlite3
from pathlib import Path
from typing import Iterator, Optional
from collections.abc import Iterator as CollectionsIterator

from oneailib.core.document_loaders.base import Loader
from oneailib.core.documents.base import Document
from pydantic import Field
from loguru import logger

# Import from FAQ_update module
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent.parent / "FAQ_update" / "src"))
from utils.checksum_utils import calculate_file_checksum


class ContentRepoLoader(Loader):
    """
    Load content from content_repo table for FAQ update detection.

    This loader reads content records modified since a specified date,
    calculates checksums for each content piece, and prepares them for
    FAQ regeneration detection.

    Attributes:
        db_path: Path to the unified faq_update.db database
        since_date: ISO timestamp - only load content modified after this date
        file_name: Optional file name filter (None = all files)
        content_column: Column to use as document page_content (default: md_content)
        calculate_checksums: Whether to calculate checksums from file paths (default: True)

    Example:
        >>> loader = ContentRepoLoader(
        ...     db_path="/path/to/faq_update.db",
        ...     since_date="2025-01-01T00:00:00Z",
        ...     file_name="policy.pdf"  # Optional
        ... )
        >>> documents = loader.load()
    """

    db_path: str = Field(
        ...,
        description="Path to the unified faq_update.db database"
    )
    since_date: str = Field(
        ...,
        description="ISO timestamp - only load content modified after this date"
    )
    file_name: Optional[str] = Field(
        default=None,
        description="Optional file name filter (None = all files)"
    )
    content_column: str = Field(
        default="md_content",
        description="Column to use as document page_content"
    )
    calculate_checksums: bool = Field(
        default=True,
        description="Whether to calculate checksums from file paths"
    )

    def lazy_load(self, path: str | Path = None) -> Iterator[Document]:
        """
        Load content from content_repo table.

        Yields:
            Document objects with metadata from content_repo
        """
        if not Path(self.db_path).exists():
            raise FileNotFoundError(f"Database not found: {self.db_path}")

        logger.info(f"Loading content from {self.db_path} since {self.since_date}")

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            # Build query
            if self.file_name:
                query = """
                    SELECT * FROM content_repo
                    WHERE last_modified_dt > ? AND raw_file_nme = ?
                    ORDER BY raw_file_nme, raw_file_page_nbr
                """
                params = (self.since_date, self.file_name)
            else:
                query = """
                    SELECT * FROM content_repo
                    WHERE last_modified_dt > ?
                    ORDER BY raw_file_nme, raw_file_page_nbr
                """
                params = (self.since_date,)

            cursor = conn.execute(query, params)

            for row in cursor:
                # Convert row to dict
                row_dict = dict(row)

                # Calculate checksum if needed
                if self.calculate_checksums and row_dict.get('extracted_markdown_file_path'):
                    try:
                        checksum = calculate_file_checksum(
                            row_dict['extracted_markdown_file_path']
                        )
                        row_dict['calculated_checksum'] = checksum
                    except Exception as e:
                        logger.warning(
                            f"Failed to calculate checksum for {row_dict['raw_file_nme']} "
                            f"page {row_dict['raw_file_page_nbr']}: {e}"
                        )
                        row_dict['calculated_checksum'] = None
                else:
                    row_dict['calculated_checksum'] = row_dict.get('content_checksum')

                # Get page content
                page_content = row_dict.get(self.content_column, "")

                # Create document
                yield Document(
                    page_content=page_content,
                    metadata=row_dict
                )

        logger.info(f"Finished loading content from {self.db_path}")
```

---

### 2. FAQRegenerationDetectorTransformer

**File:** `src/faq_services/settings/sors/analytics_assist_config/components/faq_regeneration_detector.py`

```python
"""
FAQ Regeneration Detector Transformer.

Wrapper for FAQRegenerationDetector as a oneailib DocumentTransformer.
Enriches documents with regeneration decision metadata.
"""

import sqlite3
from pathlib import Path
from typing import List, Set, Optional

from oneailib.core.document_transformers.base import DocumentTransformer
from oneailib.core.documents.base import Document
from pydantic import Field
from loguru import logger


class FAQRegenerationDetectorTransformer(DocumentTransformer):
    """
    Detect which content changes require FAQ regeneration.

    This transformer implements the checksum-centric detection logic:
    - Compare content checksum with baseline (all previous checksums for file)
    - If checksum in baseline → No regeneration needed
    - If checksum not in baseline → Regeneration required

    Enriches each document with:
        - requires_faq_regeneration: 0 or 1
        - existing_faq_count: Number of active FAQs for this checksum
        - baseline_checksums_count: Size of baseline for this file

    Attributes:
        db_path: Path to the unified faq_update.db database
        since_date: Detection period start (for baseline calculation)
        file_name: Optional file name filter

    Example:
        >>> transformer = FAQRegenerationDetectorTransformer(
        ...     db_path="/path/to/faq_update.db",
        ...     since_date="2025-01-01T00:00:00Z"
        ... )
        >>> enriched_docs = transformer.transform(documents)
    """

    db_path: str = Field(..., description="Path to faq_update.db")
    since_date: str = Field(..., description="Detection period start")
    file_name: Optional[str] = Field(default=None, description="Optional file filter")

    def transform(self, documents: List[Document]) -> List[Document]:
        """
        Enrich documents with FAQ regeneration decision.

        Args:
            documents: List of documents from ContentRepoLoader

        Returns:
            Same documents enriched with regeneration metadata
        """
        logger.info(f"Starting FAQ regeneration detection for {len(documents)} documents")

        # Group documents by file
        file_groups = {}
        for doc in documents:
            file_name = doc.metadata.get('raw_file_nme')
            if file_name not in file_groups:
                file_groups[file_name] = []
            file_groups[file_name].append(doc)

        # Process each file
        for file_name, file_docs in file_groups.items():
            logger.info(f"Processing file: {file_name} ({len(file_docs)} documents)")

            # Load baseline for this file
            baseline_checksums = self._load_baseline_checksums(file_name)
            logger.info(f"Baseline for {file_name}: {len(baseline_checksums)} checksums")

            # Process each document
            for doc in file_docs:
                checksum = doc.metadata.get('calculated_checksum')

                if not checksum:
                    logger.warning(f"No checksum for document: {doc.metadata.get('ud_source_file_id')}")
                    doc.metadata['requires_faq_regeneration'] = 1  # Regenerate if no checksum
                    doc.metadata['existing_faq_count'] = 0
                    doc.metadata['baseline_checksums_count'] = len(baseline_checksums)
                    continue

                # Key decision: Is checksum in baseline?
                if checksum in baseline_checksums:
                    # Known content - no regeneration needed
                    doc.metadata['requires_faq_regeneration'] = 0
                    doc.metadata['existing_faq_count'] = self._count_faqs_for_checksum(checksum)
                    doc.metadata['baseline_checksums_count'] = len(baseline_checksums)

                    logger.debug(
                        f"No regeneration needed: {file_name} content_id "
                        f"{doc.metadata.get('ud_source_file_id')} "
                        f"(checksum {checksum[:8]}... in baseline)"
                    )
                else:
                    # New/modified content - regeneration required
                    doc.metadata['requires_faq_regeneration'] = 1
                    doc.metadata['existing_faq_count'] = 0  # New checksum = no existing FAQs
                    doc.metadata['baseline_checksums_count'] = len(baseline_checksums)

                    logger.info(
                        f"Regeneration required: {file_name} content_id "
                        f"{doc.metadata.get('ud_source_file_id')} "
                        f"(checksum {checksum[:8]}... NOT in baseline)"
                    )

        logger.info(f"Detection complete. Summary:")
        regenerate_count = sum(1 for d in documents if d.metadata.get('requires_faq_regeneration') == 1)
        preserve_count = sum(1 for d in documents if d.metadata.get('requires_faq_regeneration') == 0)
        logger.info(f"  - Requiring regeneration: {regenerate_count}")
        logger.info(f"  - Preserving existing: {preserve_count}")

        return documents

    def _load_baseline_checksums(self, file_name: str) -> Set[str]:
        """
        Load baseline checksums for a file.

        Baseline = all checksums that existed BEFORE the since_date.

        Args:
            file_name: Name of the file

        Returns:
            Set of checksums
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT DISTINCT content_checksum
                FROM content_repo
                WHERE raw_file_nme = ?
                  AND last_modified_dt <= ?
                  AND file_status = 'Active'
                  AND content_checksum IS NOT NULL
            """, (file_name, self.since_date))

            return {row[0] for row in cursor.fetchall()}

    def _count_faqs_for_checksum(self, checksum: str) -> int:
        """
        Count active FAQs for a checksum.

        Args:
            checksum: Content checksum

        Returns:
            Number of active FAQs
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT COUNT(*)
                FROM faq_questions
                WHERE src_id IN (
                    SELECT ud_source_file_id
                    FROM content_repo
                    WHERE content_checksum = ?
                )
                AND status = 'Active'
            """, (checksum,))

            return cursor.fetchone()[0]
```

---

### 3. ChangeLoggerTransformer

**File:** `src/faq_services/settings/sors/analytics_assist_config/components/change_logger.py`

```python
"""
Change Logger Transformer.

Logs FAQ regeneration detection results to content_change_log table.
"""

import sqlite3
import json
from datetime import datetime
from typing import List
from pathlib import Path

from oneailib.core.document_transformers.base import DocumentTransformer
from oneailib.core.documents.base import Document
from pydantic import Field
from loguru import logger


class ChangeLoggerTransformer(DocumentTransformer):
    """
    Log detection results to content_change_log table.

    This is a pass-through transformer that logs detection results
    as a side effect while returning documents unchanged.

    Attributes:
        db_path: Path to faq_update.db
        detection_run_id: Unique batch identifier (typically job.run_id)

    Example:
        >>> transformer = ChangeLoggerTransformer(
        ...     db_path="/path/to/faq_update.db",
        ...     detection_run_id="20250120-123456"
        ... )
        >>> docs = transformer.transform(documents)  # Logs to DB, returns same docs
    """

    db_path: str = Field(..., description="Path to faq_update.db")
    detection_run_id: str = Field(..., description="Unique batch identifier")

    def transform(self, documents: List[Document]) -> List[Document]:
        """
        Log detection results to database.

        Args:
            documents: Documents with detection metadata

        Returns:
            Same documents (pass-through)
        """
        logger.info(f"Logging {len(documents)} detection results to content_change_log")

        records_inserted = 0
        records_skipped = 0

        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA foreign_keys = ON")

            for doc in documents:
                # Extract required fields
                content_id = doc.metadata.get('ud_source_file_id')
                checksum = doc.metadata.get('calculated_checksum')
                file_name = doc.metadata.get('raw_file_nme')
                requires_regen = doc.metadata.get('requires_faq_regeneration')
                source_modified_at = doc.metadata.get('last_modified_dt')
                existing_faq_count = doc.metadata.get('existing_faq_count', 0)

                if not all([content_id, checksum, file_name]):
                    logger.warning(f"Skipping log entry: missing required fields")
                    continue

                # Build metadata JSON
                metadata = self._build_metadata_json(doc)

                # Insert (idempotent: UNIQUE on content_id + detection_run_id)
                try:
                    cursor = conn.execute("""
                        INSERT OR IGNORE INTO content_change_log (
                            content_id,
                            content_checksum,
                            file_name,
                            requires_faq_regeneration,
                            metadata,
                            source_modified_at,
                            existing_faq_count,
                            detection_run_id,
                            since_date
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        content_id,
                        checksum,
                        file_name,
                        requires_regen,
                        metadata,
                        source_modified_at,
                        existing_faq_count,
                        self.detection_run_id,
                        doc.metadata.get('since_date')  # Pass-through from config
                    ))

                    if cursor.rowcount > 0:
                        records_inserted += 1
                    else:
                        records_skipped += 1
                        logger.debug(f"Duplicate skipped: content_id={content_id}")

                except Exception as e:
                    logger.error(f"Failed to log content_id {content_id}: {e}")

            conn.commit()

        logger.info(
            f"Logging complete: {records_inserted} inserted, "
            f"{records_skipped} duplicates skipped"
        )

        return documents

    def _build_metadata_json(self, doc: Document) -> str:
        """
        Build metadata JSON from document.

        Includes all optional fields from content_repo for flexibility.

        Args:
            doc: Document with metadata

        Returns:
            JSON string
        """
        core_fields = {
            'ud_source_file_id', 'calculated_checksum', 'raw_file_nme',
            'requires_faq_regeneration', 'existing_faq_count', 'last_modified_dt'
        }

        metadata = {}
        for key, value in doc.metadata.items():
            if key not in core_fields and value is not None:
                metadata[key] = value

        return json.dumps(metadata) if metadata else None
```

---

### 4. QuestionSimilarityMatcherTransformer

**File:** `src/faq_services/settings/sors/analytics_assist_config/components/question_similarity_matcher.py`

```python
"""
Question Similarity Matcher Transformer.

Implements the intelligent question matching logic with percentage_match calculation
and two-path processing (Modified Content vs Different Content).
"""

import sqlite3
from typing import List, Dict, Set, Tuple, Optional
from pathlib import Path
import numpy as np
from difflib import SequenceMatcher

from oneailib.core.document_transformers.base import DocumentTransformer
from oneailib.core.documents.base import Document
from oneailib.embedding_models.azure_openai import AzureOpenAIEmbedding
from pydantic import Field, PrivateAttr
from loguru import logger


class QuestionSimilarityMatcherTransformer(DocumentTransformer):
    """
    Match new questions with existing questions using adaptive similarity thresholds.

    This transformer implements the two-phase matching strategy:

    Phase 1: Calculate similarity frequency
        - For each new question, find best matching old question
        - Track matches per src_id (content_id)
        - Calculate percentage_match = match_count / total_active_faqs_for_src_id

    Phase 2: Branch based on percentage_match
        - If dominant src_id has percentage_match > 50%:
            → Modified Content path (use LLM diff analysis)
        - Else:
            → Different Content path (simple match/update logic)

    Attributes:
        db_path: Path to faq_update.db
        embedding_model: Embedding model for similarity calculation
        base_question_threshold: Base threshold for question similarity (default: 0.95)
        base_answer_threshold: Base threshold for answer similarity (default: 0.90)
        modified_content_threshold: Percentage to trigger Modified Content path (default: 0.50)
        use_adaptive_thresholds: Whether to use adaptive thresholds (default: True)
    """

    db_path: str = Field(..., description="Path to faq_update.db")
    embedding_model: AzureOpenAIEmbedding = Field(..., description="Embedding model")
    base_question_threshold: float = Field(default=0.95, ge=0.0, le=1.0)
    base_answer_threshold: float = Field(default=0.90, ge=0.0, le=1.0)
    modified_content_threshold: float = Field(default=0.50, ge=0.0, le=1.0)
    use_adaptive_thresholds: bool = Field(default=True)

    _embedding_cache: Dict[str, List[float]] = PrivateAttr(default_factory=dict)

    def transform(self, documents: List[Document]) -> List[Document]:
        """
        Match new questions with existing questions and enrich metadata.

        Args:
            documents: Documents with generated questions

        Returns:
            Documents enriched with matching metadata
        """
        logger.info(f"Starting question similarity matching for {len(documents)} documents")

        enriched_docs = []

        for doc in documents:
            file_name = doc.metadata.get('raw_file_nme')
            new_questions = doc.metadata.get('generated_questions', [])

            if not new_questions:
                logger.warning(f"No generated questions for {file_name}")
                enriched_docs.append(doc)
                continue

            logger.info(f"Processing {len(new_questions)} new questions for {file_name}")

            # Load existing questions for this file
            old_questions = self._load_existing_questions(file_name)

            if not old_questions:
                # No existing questions - all new
                doc.metadata['matching_strategy'] = 'all_new'
                doc.metadata['percentage_match'] = 0.0
                doc.metadata['matched_questions'] = []
                enriched_docs.append(doc)
                continue

            # Phase 1: Calculate similarity frequency
            similarity_freq, question_matches = self._calculate_similarity_frequency(
                new_questions,
                old_questions
            )

            # Find dominant src_id
            if similarity_freq:
                dominant_src_id, dominant_data = max(
                    similarity_freq.items(),
                    key=lambda x: x[1]['percentage_match']
                )
                max_percentage = dominant_data['percentage_match']
            else:
                dominant_src_id = None
                max_percentage = 0.0

            # Enrich document with matching results
            doc.metadata['similarity_frequency'] = similarity_freq
            doc.metadata['question_matches'] = question_matches
            doc.metadata['dominant_src_id'] = dominant_src_id
            doc.metadata['percentage_match'] = max_percentage

            # Phase 2: Determine processing path
            if max_percentage > self.modified_content_threshold:
                doc.metadata['matching_strategy'] = 'modified_content'
                logger.info(
                    f"{file_name}: Modified content detected "
                    f"(percentage_match={max_percentage:.2%})"
                )
            else:
                doc.metadata['matching_strategy'] = 'different_content'
                logger.info(
                    f"{file_name}: Different content detected "
                    f"(percentage_match={max_percentage:.2%})"
                )

            enriched_docs.append(doc)

        return enriched_docs

    def _load_existing_questions(self, file_name: str) -> List[Dict]:
        """
        Load existing active questions for a file.

        Args:
            file_name: Source file name

        Returns:
            List of question dicts with id, text, answer, src_id
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("""
                SELECT
                    q.question_id,
                    q.question_txt,
                    a.faq_answer_txt,
                    q.src_id
                FROM faq_questions q
                LEFT JOIN faq_answers a ON q.question_id = a.question_id
                WHERE q.src_file_name = ?
                  AND q.status = 'Active'
                ORDER BY q.question_id
            """, (file_name,))

            return [dict(row) for row in cursor.fetchall()]

    def _calculate_similarity_frequency(
        self,
        new_questions: List[str],
        old_questions: List[Dict]
    ) -> Tuple[Dict, List[Dict]]:
        """
        Calculate similarity frequency per src_id.

        Args:
            new_questions: List of new question texts
            old_questions: List of old question dicts

        Returns:
            Tuple of (similarity_freq dict, question_matches list)
        """
        similarity_freq = {}  # {src_id: {match_count, total_active, percentage_match}}
        question_matches = []  # List of match details

        for new_q in new_questions:
            # Find best matching old question
            best_match = self._find_best_match(new_q, old_questions)

            if not best_match:
                continue

            old_q = best_match['old_question']
            q_sim = best_match['question_similarity']

            # Generate answer for new question (placeholder - actual generation happens later)
            # For now, we'll use the new question text as proxy
            new_answer = f"[Generated answer for: {new_q}]"

            # Compare with old answer
            ans_sim = self._calculate_similarity(
                new_answer,
                old_q.get('faq_answer_txt', '')
            )

            # Track match
            match_record = {
                'new_question': new_q,
                'old_question_id': old_q['question_id'],
                'old_question': old_q['question_txt'],
                'old_answer': old_q.get('faq_answer_txt'),
                'question_similarity': q_sim,
                'answer_similarity': ans_sim,
                'src_id': old_q['src_id']
            }
            question_matches.append(match_record)

            # Update frequency count
            src_id = old_q['src_id']

            if src_id not in similarity_freq:
                # Count total active FAQs for this src_id
                total_active = self._count_active_faqs_for_src_id(src_id)

                similarity_freq[src_id] = {
                    'match_count': 0,
                    'total_active': total_active,
                    'percentage_match': 0.0
                }

            # Increment count if both question and answer similarity are high
            if ans_sim > self.base_answer_threshold:
                similarity_freq[src_id]['match_count'] += 1  # FIX: was += 0

        # Calculate percentages
        for src_id, data in similarity_freq.items():
            if data['total_active'] > 0:
                data['percentage_match'] = data['match_count'] / data['total_active']

        return similarity_freq, question_matches

    def _find_best_match(
        self,
        new_question: str,
        old_questions: List[Dict]
    ) -> Optional[Dict]:
        """
        Find best matching old question for a new question.

        Uses adaptive threshold based on question length.

        Args:
            new_question: New question text
            old_questions: List of old question dicts

        Returns:
            Match dict or None
        """
        if not old_questions:
            return None

        # Calculate adaptive threshold
        threshold = self._calculate_adaptive_threshold(new_question)

        best_score = 0.0
        best_match = None

        for old_q in old_questions:
            score = self._calculate_similarity(new_question, old_q['question_txt'])

            if score > best_score and score >= threshold:
                best_score = score
                best_match = {
                    'old_question': old_q,
                    'question_similarity': score
                }

        return best_match

    def _calculate_adaptive_threshold(self, question: str) -> float:
        """
        Calculate adaptive threshold based on question characteristics.

        Args:
            question: Question text

        Returns:
            Adjusted threshold
        """
        if not self.use_adaptive_thresholds:
            return self.base_question_threshold

        word_count = len(question.split())

        # Shorter questions need higher threshold (more likely false positives)
        if word_count < 5:
            return min(self.base_question_threshold + 0.03, 1.0)

        # Longer questions can use slightly lower threshold
        elif word_count > 20:
            return max(self.base_question_threshold - 0.03, 0.0)

        return self.base_question_threshold

    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate semantic similarity between two texts.

        Uses embeddings for semantic similarity.

        Args:
            text1: First text
            text2: Second text

        Returns:
            Similarity score (0.0 to 1.0)
        """
        # Get or compute embeddings
        emb1 = self._get_embedding(text1)
        emb2 = self._get_embedding(text2)

        # Cosine similarity
        similarity = np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))

        return float(similarity)

    def _get_embedding(self, text: str) -> List[float]:
        """Get or compute embedding for text with caching."""
        if text not in self._embedding_cache:
            self._embedding_cache[text] = self.embedding_model.embed_query(text)
        return self._embedding_cache[text]

    def _count_active_faqs_for_src_id(self, src_id: int) -> int:
        """
        Count total active FAQs for a src_id.

        Args:
            src_id: Content ID (from content_repo)

        Returns:
            Count of active FAQs
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT COUNT(*)
                FROM faq_questions
                WHERE src_id = ? AND status = 'Active'
            """, (src_id,))

            return cursor.fetchone()[0]
```

---

## 📝 Reusable Blocks (YAML Files)

### 1. Load Content Repo

**File:** `reusable_blocks/loaders/load_content_repo.yaml`

```yaml
steps:
  - # load_content_repo
    _target_: content_repo_loader.ContentRepoLoader
    db_path: ${faq_update_db_path}
    since_date: ${faq_update_since_date}
    file_name: ${faq_update_file_filter}  # null for all files
    content_column: "md_content"
    calculate_checksums: true
```

---

### 2. Detect FAQ Regeneration

**File:** `reusable_blocks/detectors/detect_faq_regeneration.yaml`

```yaml
steps:
  - # detect_faq_regeneration
    _target_: faq_regeneration_detector.FAQRegenerationDetectorTransformer
    db_path: ${faq_update_db_path}
    since_date: ${faq_update_since_date}
    file_name: ${faq_update_file_filter}
```

---

### 3. Log Detection Results

**File:** `reusable_blocks/transformers/log_detection_results.yaml`

```yaml
steps:
  - # log_detection_results
    _target_: change_logger.ChangeLoggerTransformer
    db_path: ${faq_update_db_path}
    detection_run_id: ${job.run_id}
```

---

### 4. Match Questions with Existing

**File:** `reusable_blocks/transformers/match_questions_with_existing.yaml`

```yaml
steps:
  - # match_questions_similarity
    _target_: question_similarity_matcher.QuestionSimilarityMatcherTransformer
    db_path: ${faq_update_db_path}
    embedding_model:
      _target_: oneailib.embedding_models.azure_openai.AzureOpenAIEmbedding
      api_base_url: ${api_base_url}
      api_key: ${api_key}
      deployment_name: ${embedding_deployment_name}
      model_name: ${embedding_model_name}
    base_question_threshold: 0.95
    base_answer_threshold: 0.90
    modified_content_threshold: 0.50
    use_adaptive_thresholds: true
```

---

## 🎛️ Configuration Parameters

Add to `analytics_assist_config.yaml`:

```yaml
# FAQ Update Pipeline Configuration
faq_update:
  # Database
  faq_update_db_path: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/faq_update/databases/faq_update.db

  # Detection parameters
  faq_update_since_date: "2025-01-01T00:00:00.000Z"
  faq_update_file_filter: null  # null = all files

  # Processing
  faq_update_run_id: "${job.run_id}"

  # Thresholds
  question_similarity_threshold: 0.95
  answer_similarity_threshold: 0.90
  modified_content_percentage_threshold: 0.50

  # Features
  use_adaptive_thresholds: true
  enable_llm_diff_analysis: true
  enable_reconciliation: true

  # Output
  path_debug_export: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/faq_update/debug_output
```

---

## 📊 Database Schema Notes

### Key Tables Used:

**content_repo:**
- `ud_source_file_id` (PRIMARY KEY) = content_id = src_id in faq_questions
- `content_checksum` = SHA-256 hash of content
- `raw_file_nme` = file name
- `raw_file_page_nbr` = page number (optional metadata)
- `extracted_markdown_file_path` = path to markdown file
- `last_modified_dt` = modification timestamp

**content_change_log:**
- `content_id` = FK to content_repo.ud_source_file_id
- `content_checksum` = content hash
- `requires_faq_regeneration` = 0 or 1 (BOOLEAN)
- `metadata` = JSON (page, title, domain, etc.)
- `detection_run_id` = batch tracking

**faq_questions:**
- `question_id` (PRIMARY KEY)
- `question_txt` = question text
- `src_id` = FK to content_repo.ud_source_file_id
- `src_file_name` = file name (for file-level queries)
- `status` = 'Active', 'Deprecated', etc.

**faq_answers:**
- `answer_id` (PRIMARY KEY)
- `question_id` = FK to faq_questions
- `faq_answer_txt` = answer text

---

## 🚀 Implementation Checklist

### Week 1: Core Components
- [ ] ContentRepoLoader
  - [ ] Database connection
  - [ ] Checksum calculation
  - [ ] Document generation
  - [ ] Unit tests
- [ ] FAQRegenerationDetectorTransformer
  - [ ] Baseline loading
  - [ ] Checksum comparison
  - [ ] Metadata enrichment
  - [ ] Unit tests
- [ ] ChangeLoggerTransformer
  - [ ] Database insertion
  - [ ] Idempotency (UNIQUE constraint)
  - [ ] JSON metadata building
  - [ ] Unit tests

### Week 2: Matching Logic
- [ ] QuestionSimilarityMatcherTransformer
  - [ ] Existing question loading
  - [ ] Similarity frequency calculation
  - [ ] Adaptive thresholds
  - [ ] Modified vs Different detection
  - [ ] Unit tests
- [ ] Integration tests
  - [ ] End-to-end with sample data
  - [ ] Edge cases (no existing FAQs, 100% match, 0% match)

### Week 3: Remaining Components
- [ ] HybridImpactAnalyzerTransformer (LLM + rules)
- [ ] FAQReconciliationTransformer (unmatched old FAQs)
- [ ] FAQQualityEvaluatorTransformer (keep old vs replace)
- [ ] FAQDatabaseWriterParser (update faq_questions table)

### Week 4: Pipeline Assembly
- [ ] Create main faq_update.yaml
- [ ] Wire all reusable blocks
- [ ] Add debug visualizations
- [ ] Test with real data

### Week 5: Production Deployment
- [ ] Deploy to Databricks DEV
- [ ] Configure widgets
- [ ] Performance tuning
- [ ] Deploy to PROD

---

## ✅ Success Criteria

1. ✅ Correctly identifies unchanged content (checksum match) → Skip regeneration
2. ✅ Distinguishes Modified (>50% match) vs Different (<50% match) content
3. ✅ Uses adaptive thresholds based on question characteristics
4. ✅ Handles unmatched old FAQs (reconciliation)
5. ✅ Hybrid LLM + rule-based impact analysis (cost-effective)
6. ✅ Evaluates quality (don't blindly ignore similar questions)
7. ✅ All operations idempotent (safe re-runs)
8. ✅ Complete audit trail in content_change_log

---

**END OF DESIGN DOCUMENT V2**

*This design is now aligned with your confirmed requirements and ready for implementation.*
