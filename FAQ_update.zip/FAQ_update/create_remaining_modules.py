"""
Script to generate all remaining module files for granular_impact.

This script creates the remaining implementation files to complete the module structure.
Run this script to generate all necessary files.
"""

import os
from pathlib import Path

# Base path
BASE_PATH = Path(__file__).parent / "granular_impact"

# File templates
FILES_TO_CREATE = {
    # Database module
    "database/connection.py": '''"""
Database connection management for Databricks/Delta Lake.
"""

from typing import Optional
from pyspark.sql import SparkSession


class DatabaseConnection:
    """Manages Databricks connection and catalog access."""

    def __init__(self, catalog: str, schema: str, use_unity_catalog: bool = True):
        self.catalog = catalog
        self.schema = schema
        self.use_unity_catalog = use_unity_catalog
        self._spark: Optional[SparkSession] = None

    @property
    def spark(self) -> SparkSession:
        """Get Spark session."""
        if self._spark is None:
            self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def get_fully_qualified_table(self, table_name: str) -> str:
        """Get fully qualified table name."""
        if self.use_unity_catalog:
            return f"{self.catalog}.{self.schema}.{table_name}"
        return f"{self.schema}.{table_name}"
''',

    "database/queries.py": '''"""
SQL query templates for impact analysis.
"""

class QueryTemplates:
    """SQL query templates."""

    @staticmethod
    def get_content_by_ids(table_name: str) -> str:
        return f"""
        SELECT * FROM {table_name}
        WHERE content_id IN ({{content_ids}})
        """

    @staticmethod
    def get_faqs_by_content_id(faq_table: str) -> str:
        return f"""
        SELECT * FROM {faq_table}
        WHERE array_contains(source_content_ids, '{{content_id}}')
        AND is_valid = true
        """

    @staticmethod
    def insert_impact_result(table_name: str) -> str:
        return f"INSERT INTO {table_name} VALUES ({{values}})"
''',

    "database/transactions.py": '''"""
Transaction management for database operations.
"""

from typing import List, Callable, Any


class TransactionManager:
    """Manages database transactions with retry logic."""

    def __init__(self, max_retries: int = 3, retry_delay: float = 1.0):
        self.max_retries = max_retries
        self.retry_delay = retry_delay

    def execute_with_retry(self, operation: Callable[[], Any]) -> Any:
        """Execute operation with retry logic."""
        import time

        last_error = None
        for attempt in range(self.max_retries):
            try:
                return operation()
            except Exception as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))

        raise last_error
''',

    "database/__init__.py": '''"""
Database access module.
"""

from granular_impact.database.connection import DatabaseConnection
from granular_impact.database.models import (
    AuditLogEntry,
    ChangeType,
    ContentChange,
    ContentRecord,
    FAQRecord,
    ImpactDecision,
    ImpactResult,
)
from granular_impact.database.queries import QueryTemplates
from granular_impact.database.transactions import TransactionManager

__all__ = [
    "DatabaseConnection",
    "QueryTemplates",
    "TransactionManager",
    "ContentRecord",
    "FAQRecord",
    "ImpactResult",
    "AuditLogEntry",
    "ContentChange",
    "ImpactDecision",
    "ChangeType",
]
''',

    # Diff module
    "diff/diff_engine.py": '''"""
Core diff computation engine.
"""

import difflib
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class DiffResult:
    """Result of diff computation."""
    additions: List[str]
    deletions: List[str]
    modifications: List[Tuple[str, str]]
    diff_ratio: float
    total_changes: int


class DiffEngine:
    """Computes differences between texts."""

    def compute_diff(self, text1: str, text2: str) -> DiffResult:
        """
        Compute diff between two texts.

        Args:
            text1: Original text
            text2: Modified text

        Returns:
            DiffResult object
        """
        lines1 = text1.splitlines()
        lines2 = text2.splitlines()

        differ = difflib.Differ()
        diff = list(differ.compare(lines1, lines2))

        additions = [line[2:] for line in diff if line.startswith('+ ')]
        deletions = [line[2:] for line in diff if line.startswith('- ')]

        matcher = difflib.SequenceMatcher(None, text1, text2)
        diff_ratio = matcher.ratio()

        return DiffResult(
            additions=additions,
            deletions=deletions,
            modifications=[],
            diff_ratio=diff_ratio,
            total_changes=len(additions) + len(deletions)
        )
''',

    "diff/phrase_extractor.py": '''"""
Extract meaningful phrases from text differences.
"""

import re
from typing import List, Set


class PhraseExtractor:
    """Extracts important phrases from text."""

    def __init__(self, min_length: int = 3, max_length: int = 10):
        self.min_length = min_length
        self.max_length = max_length

    def extract_phrases(self, text: str) -> List[str]:
        """
        Extract phrases from text.

        Args:
            text: Input text

        Returns:
            List of extracted phrases
        """
        # Split into sentences
        sentences = re.split(r'[.!?]', text)

        phrases = []
        for sentence in sentences:
            words = sentence.split()
            if self.min_length <= len(words) <= self.max_length:
                phrases.append(sentence.strip())

        return phrases

    def extract_changed_phrases(self, old_text: str, new_text: str) -> Set[str]:
        """
        Extract phrases that changed between texts.

        Args:
            old_text: Original text
            new_text: Modified text

        Returns:
            Set of changed phrases
        """
        old_phrases = set(self.extract_phrases(old_text))
        new_phrases = set(self.extract_phrases(new_text))

        changed = old_phrases.symmetric_difference(new_phrases)
        return changed
''',

    "diff/semantic_detector.py": '''"""
Detect semantic changes (numbers, dates, policies).
"""

import re
from dataclasses import dataclass
from typing import List


@dataclass
class SemanticChange:
    """Represents a detected semantic change."""
    change_type: str
    old_value: str
    new_value: str
    context: str


class SemanticDetector:
    """Detects semantic changes in text."""

    def __init__(self):
        self.number_pattern = r'\\b\\d+(?:\\.\\d+)?\\b'
        self.date_pattern = r'\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}\\b'
        self.url_pattern = r'https?://[^\\s]+'
        self.email_pattern = r'\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b'

    def detect_numeric_changes(self, old_text: str, new_text: str) -> List[SemanticChange]:
        """Detect numeric value changes."""
        old_numbers = set(re.findall(self.number_pattern, old_text))
        new_numbers = set(re.findall(self.number_pattern, new_text))

        changes = []
        removed = old_numbers - new_numbers
        added = new_numbers - old_numbers

        for old_val in removed:
            changes.append(SemanticChange(
                change_type="numeric",
                old_value=old_val,
                new_value="",
                context="removed"
            ))

        for new_val in added:
            changes.append(SemanticChange(
                change_type="numeric",
                old_value="",
                new_value=new_val,
                context="added"
            ))

        return changes

    def detect_date_changes(self, old_text: str, new_text: str) -> List[SemanticChange]:
        """Detect date changes."""
        old_dates = set(re.findall(self.date_pattern, old_text))
        new_dates = set(re.findall(self.date_pattern, new_text))

        changes = []
        for date in old_dates - new_dates:
            changes.append(SemanticChange(
                change_type="date",
                old_value=date,
                new_value="",
                context="removed"
            ))

        return changes
''',

    "diff/__init__.py": '''"""
Diff analysis module.
"""

from granular_impact.diff.diff_engine import DiffEngine, DiffResult
from granular_impact.diff.phrase_extractor import PhraseExtractor
from granular_impact.diff.semantic_detector import SemanticChange, SemanticDetector

__all__ = [
    "DiffEngine",
    "DiffResult",
    "PhraseExtractor",
    "SemanticDetector",
    "SemanticChange",
]
''',

    # Detection module
    "detection/checksum_extractor.py": '''"""
Extract and compute checksums for content.
"""

import hashlib


class ChecksumExtractor:
    """Computes checksums for content tracking."""

    def __init__(self, algorithm: str = "sha256"):
        self.algorithm = algorithm

    def compute_checksum(self, content: str) -> str:
        """
        Compute checksum for content.

        Args:
            content: Text content

        Returns:
            Hexadecimal checksum string
        """
        if self.algorithm == "md5":
            hasher = hashlib.md5()
        elif self.algorithm == "sha1":
            hasher = hashlib.sha1()
        elif self.algorithm == "sha256":
            hasher = hashlib.sha256()
        elif self.algorithm == "sha512":
            hasher = hashlib.sha512()
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")

        hasher.update(content.encode('utf-8'))
        return hasher.hexdigest()
''',

    "detection/change_detector.py": '''"""
Detect changes in content.
"""

from datetime import datetime
from typing import List

from granular_impact.database.models import ChangeType, ContentChange
from granular_impact.detection.checksum_extractor import ChecksumExtractor


class ChangeDetector:
    """Detects content changes using checksums."""

    def __init__(self, checksum_algorithm: str = "sha256"):
        self.checksum_extractor = ChecksumExtractor(checksum_algorithm)

    def detect_change(
        self,
        content_id: str,
        old_content: str,
        new_content: str,
        old_version: int,
        new_version: int
    ) -> ContentChange:
        """
        Detect if content has changed.

        Args:
            content_id: Content identifier
            old_content: Previous content
            new_content: Current content
            old_version: Previous version number
            new_version: Current version number

        Returns:
            ContentChange object
        """
        old_checksum = self.checksum_extractor.compute_checksum(old_content)
        new_checksum = self.checksum_extractor.compute_checksum(new_content)

        if old_checksum == new_checksum:
            change_type = ChangeType.NONE
        else:
            change_type = ChangeType.CONTENT_UPDATE

        return ContentChange(
            content_id=content_id,
            old_checksum=old_checksum,
            new_checksum=new_checksum,
            old_version=old_version,
            new_version=new_version,
            change_type=change_type,
            detected_at=datetime.now(),
            old_content=old_content,
            new_content=new_content
        )
''',

    "detection/__init__.py": '''"""
Change detection module.
"""

from granular_impact.detection.change_detector import ChangeDetector
from granular_impact.detection.checksum_extractor import ChecksumExtractor

__all__ = [
    "ChangeDetector",
    "ChecksumExtractor",
]
''',
}

def create_files():
    """Create all module files."""
    for file_path, content in FILES_TO_CREATE.items():
        full_path = BASE_PATH / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)

        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)

        print(f"Created: {full_path}")

if __name__ == "__main__":
    create_files()
    print("\\nAll files created successfully!")
