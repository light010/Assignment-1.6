# FAQ Update System - Architecture v4 (Simplified Checksum-Centric)

## Overview

This document describes the simplified checksum-centric architecture implemented in schema v4, which eliminates complexity while maintaining all essential functionality for FAQ regeneration detection and management.

## Key Design Principles

### 1. Checksum-Centric Identity
- **Checksums are primary identity** for FAQ mapping, not page positions
- Page numbers are metadata only (for human reference)
- FAQ invalidation operates on checksums, not content_id values
- Enables detection of content reuse and duplication

### 2. Binary Decision Model
- Replaced complex `change_type` enum with simple `requires_faq_regeneration` BOOLEAN (0/1)
- Only two outcomes: regenerate FAQ or preserve existing FAQ
- Simplified business logic: "Should we regenerate FAQ for this page?"
- No need for nuanced change classification (content_edit vs position_change, etc.)

### 3. JSON Metadata Storage
- All optional/descriptive fields stored in flexible JSON columns
- Easy schema evolution without ALTER TABLE statements
- Indexed JSON extraction for common queries
- Architectural consistency between `content_change_log` and `faq_content_map`

### 4. Direct Processing
- No adapter layer needed between detection and persistence
- Detection results map directly to database schema
- Fewer moving parts, less room for bugs
- Simpler code paths

### 5. Built-in Telemetry
- Detection process includes comprehensive metrics in result
- No separate reporter class needed
- All operational metrics available immediately
- Supports monitoring and debugging

## Schema Changes from v3 to v4

### content_change_log Table

**Removed Fields**:
- `change_type` TEXT - Replaced with binary `requires_faq_regeneration`
- `page_number` INTEGER - Moved to JSON `metadata`
- `previous_content_id` INTEGER - Not needed (checksum-centric)
- `previous_page_number` INTEGER - Not needed
- `previous_checksum` TEXT - Not needed (baseline comparison instead)
- `change_trigger` TEXT - Not needed

**Added Fields**:
- `requires_faq_regeneration` BOOLEAN NOT NULL CHECK (0 or 1)
- `metadata` JSON - Flexible storage for optional fields
- `source_modified_at` TEXT NOT NULL - Renamed from `last_modified_dt`
- `since_date` TEXT - For query reproducibility
- `detection_run_id` TEXT - For batch tracking and idempotency

**Key Design Changes**:
1. **Binary decision**: Simple 0/1 instead of enum
2. **JSON metadata**: All descriptive fields in one place
3. **Dual identity maintained**: `content_id` (WHERE) + `checksum` (WHAT)
4. **Idempotency**: UNIQUE constraint on (content_id, detection_run_id)

### faq_content_map Table

**Removed Fields**:
- `current_page_number` INTEGER - Moved to `current_metadata` JSON
- `original_page_number` INTEGER - Moved to `original_metadata` JSON

**Added Fields**:
- `current_metadata` JSON - Current location metadata
- `original_metadata` JSON - Original location metadata

**Key Design Changes**:
1. **Architectural consistency**: Matches `content_change_log` JSON pattern
2. **Flexible metadata**: Easy to add new tracking fields
3. **Page numbers optional**: Handles single-page docs gracefully

### Removed Tables

**content_diffs** - Entire table removed
- Diff tracking was complex and rarely used
- Diffs can be generated on-demand if needed
- Simplified schema maintenance
- Reduced storage requirements

### Updated VIEWS

**Removed VIEWS**:
- `v_document_structure_changes` - Based on removed `change_type`
- `v_content_changes_with_diffs` - Based on removed `content_diffs`
- `v_pending_diffs` - Based on removed `content_diffs`
- `v_diff_processing_stats` - Based on removed `content_diffs`

**New/Updated VIEWS**:

1. **v_regeneration_queue** - Prioritized list of pages requiring FAQ regeneration
   - Filters by `requires_faq_regeneration = 1`
   - Extracts page from JSON metadata
   - Priority score: (FAQ count * 100) + days since modification

2. **v_checksum_faq_stats** - FAQ statistics by checksum
   - Groups FAQs by checksum
   - Shows valid vs invalid counts
   - Useful for understanding FAQ reuse

3. **v_recent_detections** - Recent detection runs
   - Extracts metadata from JSON
   - Shows detection context and results
   - Useful for debugging

## Component Architecture

### Detection Layer

**FAQRegenerationDetector** (No changes - already simplified)
- Input: `since_date` parameter
- Output: Detection result with `regenerate_faq`, `no_action_needed`, and `telemetry`
- Logic: Checksum baseline comparison
- Built-in metrics: Comprehensive telemetry in result

### Processing Layer

**ChangeLogger** (New - replaces ChangeProcessor)
- Purpose: Log detection results to `content_change_log`
- Input: Detection result from `FAQRegenerationDetector`
- Processing:
  - Extracts `regenerate_faq` list → `requires_faq_regeneration = 1`
  - Extracts `no_action_needed` list → `requires_faq_regeneration = 0`
  - Builds JSON metadata from page data
  - Writes to `content_change_log`
- Idempotency: UNIQUE constraint on (content_id, detection_run_id)
- No adapter needed: Direct processing of detection result

**FAQUpdater** (New - replaces FAQMapper)
- Purpose: Update FAQ mappings based on detection results
- Input: Detection result from `FAQRegenerationDetector`
- Processing:
  - For pages requiring regeneration: Invalidate all FAQs with that checksum
  - For preserved pages: Update metadata (current location) if needed
- Checksum-based: Single invalidation per checksum
- No adapter needed: Direct processing of detection result

### Removed Components

**FAQToChangesAdapter** - Deleted
- No longer needed with direct processing
- Detection results map directly to schema
- Simplified code flow

**ChangeProcessor** - Deprecated (marked with warnings)
- Replaced by `ChangeLogger`
- Still exists but warns users to migrate
- Will be removed in future version

**FAQMapper** - Deprecated (marked with warnings)
- Replaced by `FAQUpdater`
- Still exists but warns users to migrate
- Will be removed in future version

**ContentDiffProcessor** - Deleted
- No longer needed without `content_diffs` table
- Diffs can be generated on-demand if needed

**ImpactReporter** - Deprecated
- Detection telemetry provides same metrics
- No separate reporter needed
- Simpler architecture

## Workflow Comparison

### Old Workflow (v3 Schema)
```
1. Detection: FAQRegenerationDetector.detect()
   ↓ (detection_result with regenerate_faq/no_action_needed)
2. Adapter: FAQToChangesAdapter.adapt()
   ↓ (changes dict with content_edits/position_changes/new_content)
3. Change Processing: ChangeProcessor.process_changes()
   ↓ (writes to content_change_log with change_type)
4. Diff Generation: ContentDiffProcessor.process_pending_diffs()
   ↓ (writes to content_diffs)
5. FAQ Updates: FAQMapper.update_faq_mappings()
   ↓ (updates faq_content_map)
6. Impact Report: ImpactReporter.generate_impact_report()
   ↓ (separate metrics)
```

### New Workflow (v4 Schema)
```
1. Detection: FAQRegenerationDetector.detect()
   ↓ (detection_result with regenerate_faq/no_action_needed + telemetry)
2. Change Logging: ChangeLogger.log_detection_results()
   ↓ (writes to content_change_log with requires_faq_regeneration + JSON metadata)
3. FAQ Updates: FAQUpdater.process_detection_results()
   ↓ (updates faq_content_map based on checksums)
4. Done! (telemetry already in detection_result)
```

**Complexity Reduction**:
- 6 steps → 3 steps
- 5 components → 3 components
- No adapter layer
- No diff generation step
- No separate reporting step
- Built-in telemetry

## JSON Metadata Structure

### content_change_log.metadata

```json
{
  "page": 2,
  "domain": "HR",
  "service": "Policy Management",
  "orgoid": "ORG001",
  "associateoid": "ASSOC001",
  "raw_file_type": ".pdf",
  "raw_file_version_nbr": 2,
  "source_url_txt": "https://intranet.example.com/policies/leave",
  "parent_location_txt": "/policies",
  "raw_file_path": "/test/Employee_Leave_Policy.pdf",
  "extracted_markdown_file_path": "c:\\path\\to\\page2_v2.md",
  "extracted_layout_file_path": "layout_p2_v2.txt",
  "title_nme": "Employee Leave Policy - Sick Leave",
  "breadcrumb_txt": "Policies > HR > Leave Management",
  "content_tags_txt": "leave;sick;medical;absence",
  "version_nbr": 2,
  "file_status": "Active",
  "created_dt": "2025-01-01T10:00:00.000Z"
}
```

### faq_content_map.current_metadata / original_metadata

```json
{
  "current_page": 2,
  "current_title": "Employee Leave Policy - Sick Leave"
}
```

## Querying JSON Metadata

### Basic Extraction
```sql
SELECT
    change_id,
    file_name,
    json_extract(metadata, '$.page') as page,
    json_extract(metadata, '$.title_nme') as title,
    json_extract(metadata, '$.domain') as domain
FROM content_change_log
```

### Filtering by JSON Fields
```sql
SELECT *
FROM content_change_log
WHERE json_extract(metadata, '$.domain') = 'HR'
  AND json_extract(metadata, '$.page') > 1
```

### Numeric Comparisons
```sql
SELECT *
FROM content_change_log
WHERE CAST(json_extract(metadata, '$.page') AS INTEGER) BETWEEN 1 AND 10
ORDER BY file_name, CAST(json_extract(metadata, '$.page') AS INTEGER)
```

### Grouping by JSON Fields
```sql
SELECT
    json_extract(metadata, '$.domain') as domain,
    requires_faq_regeneration,
    COUNT(*) as count
FROM content_change_log
WHERE json_extract(metadata, '$.domain') IS NOT NULL
GROUP BY domain, requires_faq_regeneration
```

## Migration Path

### For Existing Databases

1. **Backup current database**
   ```bash
   cp faq_update.db faq_update_v3_backup.db
   ```

2. **Apply schema v4**
   - Run `sql/create_schema_v4.sql` on new database
   - Or use migration script (if provided)

3. **Update code**
   - Replace `ChangeProcessor` with `ChangeLogger`
   - Replace `FAQMapper` with `FAQUpdater`
   - Remove `FAQToChangesAdapter` usage
   - Remove `ContentDiffProcessor` usage
   - Remove `ImpactReporter` usage (use telemetry instead)

4. **Update notebooks**
   - Remove adapter cells
   - Remove diff generation cells
   - Remove impact reporter cells
   - Update verification queries (no `change_type`, use JSON extraction)

### Deprecation Warnings

Old classes still exist but emit deprecation warnings:
```python
# This will work but warn you to migrate
change_processor = ChangeProcessor(content_db, tracking_db)  # DeprecationWarning

# Migrate to this
change_logger = ChangeLogger(db_path)  # New simplified version
```

## Benefits of v4 Architecture

### Simplicity
- **50% fewer components** (6 → 3 in workflow)
- **No adapter layer** - direct processing
- **Binary decisions** - easy to understand
- **Fewer tables** - no content_diffs

### Flexibility
- **JSON metadata** - easy schema evolution
- **Optional fields** - no NULL column issues
- **Consistent patterns** - same approach across tables

### Performance
- **Fewer steps** - less processing overhead
- **Checksum-based invalidation** - single operation per content
- **Indexed JSON** - fast metadata queries
- **Batch idempotency** - safe re-runs

### Maintainability
- **Less code** - fewer classes and files
- **Clear intent** - binary decisions vs complex classification
- **Self-documenting** - telemetry built-in
- **Easier testing** - simpler code paths

### Operational Benefits
- **Built-in metrics** - no separate reporting
- **Idempotent detection** - safe to re-run
- **Batch tracking** - detection_run_id for auditing
- **Reproducible queries** - since_date stored

## Future Enhancements

Possible improvements to consider:

1. **Async Processing**
   - Decouple detection from logging/updates
   - Process large batches in background

2. **Change Notifications**
   - Webhook/event system for FAQ regeneration triggers
   - Integration with FAQ generation pipeline

3. **Advanced Prioritization**
   - ML-based priority scoring
   - User engagement metrics

4. **Audit Trail**
   - Full history of FAQ invalidations
   - Rollback capability

5. **Multi-Database Support**
   - PostgreSQL/MySQL adapters
   - Cloud database integration

## References

- **Schema**: `sql/create_schema_v4.sql`
- **ChangeLogger**: `src/processors/change_processor.py` (lines 41-329)
- **FAQUpdater**: `src/processors/faq_mapper.py` (lines 41-310)
- **Detector**: `src/detectors/faq_regeneration_detector.py`
- **Example Notebook**: `notebooks/3_update_detector.ipynb`
- **Backup**: `databases/content_change_log_backup.json`

---

**Document Version**: 1.0
**Schema Version**: v4
**Last Updated**: 2025-10-19
