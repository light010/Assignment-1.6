import sqlite3
import pandas as pd

conn = sqlite3.connect('databases/my_database.db')

print("=" * 80)
print("CONTENT_CHECKSUMS TABLE ANALYSIS")
print("=" * 80)

# Check content_checksums by file
df = pd.read_sql_query('''
    SELECT file_name, COUNT(*) as count, MIN(created_at) as first_created, MAX(created_at) as last_created
    FROM content_checksums
    WHERE status="active"
    GROUP BY file_name
    ORDER BY first_created
''', conn)
print("\nContent Checksums by File:")
print(df.to_string(index=False))

print("\n" + "=" * 80)
print("CONTENT_REPO TABLE ANALYSIS")
print("=" * 80)

# Check content_repo
df2 = pd.read_sql_query('''
    SELECT raw_file_nme, raw_file_version_nbr, last_modified_dt, created_dt
    FROM content_repo
    WHERE file_status = "Active"
    ORDER BY raw_file_nme, raw_file_version_nbr
''', conn)
print("\nContent Repo Files:")
print(df2.to_string(index=False))

conn.close()
