# Hydra-Based FAQ Update Pipeline - Comprehensive Design Document

**Date:** 2025-10-20
**Author:** Senior Code Architect
**Version:** 1.0
**Status:** Design Phase - Ready for Implementation

---

## 📋 Executive Summary

This document outlines the comprehensive design for building a **Hydra-based FAQ Update Pipeline** that mirrors the architecture of the existing `test2.yaml` pipeline but focuses on FAQ regeneration based on content changes rather than initial FAQ generation. The pipeline will seamlessly integrate with oneailib, follow existing design patterns, and leverage the checksum-centric FAQ update detection system developed in the notebooks.

**Key Objective:** Transform the notebook-based FAQ update workflow (`3_update_detector.ipynb`) into a production-ready Hydra pipeline that can be deployed on Databricks.

---

## 🎯 Core Design Principles

### 1. **Architectural Consistency**
- Mirror the structure and patterns of `test2.yaml`
- Reuse existing reusable blocks where possible
- Follow oneailib conventions for all components
- Maintain Hydra configuration hierarchy

### 2. **Checksum-Centric Philosophy**
- Content identity based on checksums (not page numbers)
- Binary decision model: `requires_faq_regeneration` (0/1)
- JSON metadata storage for flexibility
- Simplified architecture (no complex change classification)

### 3. **Production Readiness**
- Databricks-compatible (volume paths, widgets, secrets)
- Comprehensive error handling
- Built-in telemetry and monitoring
- Idempotent operations (safe re-runs)

### 4. **Modularity & Reusability**
- All new components as custom components in `analytics_assist_config/components/`
- Reusable blocks for each logical step
- Clear separation of concerns

---

## 🏗️ Architecture Overview

### High-Level Pipeline Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                   FAQ UPDATE PIPELINE WORKFLOW                       │
└─────────────────────────────────────────────────────────────────────┘

Phase 1: DETECTION
──────────────────
[1] Load Content Repo          → Load recent content changes from DB
[2] Detect FAQ Regeneration    → Checksum-centric change detection
[3] Visualize Detection        → Debug output (optional)

Phase 2: LOGGING
─────────────────
[4] Log Detection Results      → Persist to content_change_log
[5] Visualize Logged Changes   → Debug output (optional)

Phase 3: FAQ PROCESSING
────────────────────────
[6] MultiPipeline Split:
    ├─ Pipeline A: Load Existing Valid FAQs → From faq_question (by src_file_name)
    └─ Pipeline B: Process Regeneration Required
        ├─ [7] Filter Regeneration Required
        ├─ [8] Load Markdown Content
        ├─ [9] Generate Embeddings
        ├─ [10] Retrieve Context (OpenSearch)
        ├─ [11] Deduplicate Context
        ├─ [12] Filter Context Quality
        ├─ [13] Generate Answers (LLM)
        ├─ [14] Filter Invalid Answers
        ├─ [15] Get Context Employed
        └─ [16] Sort by Distance

[17] Concat Pipelines          → Merge existing + new FAQs

Phase 4: FAQ UPDATES
─────────────────────
[18] Invalidate Old FAQs       → Mark FAQs with changed checksums
[19] Create New FAQ Mappings   → Insert to faq_content_map
[20] Visualize FAQ Updates     → Debug output (optional)

Phase 5: OUTPUT
────────────────
[21] Format HTML               → Enforce formatting rules
[22] Add Metadata              → Enrich with pipeline context
[23] Compute Distances         → Semantic similarity metrics
[24] Filter by Distance        → Quality thresholds
[25] Save to QA Bank           → Partitioned dataset
[26] Save to CSV               → Backup/audit trail
[27] Save to Label Studio      → Human validation queue
[28] Final Visualization       → Summary report
```

---

## 📊 Component Inventory

### Phase 1: Custom Components (New Development)

These components need to be created in `analytics_assist_config/components/`:

#### 1.1 **ContentRepoLoader**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/content_repo_loader.py

from oneailib.core.document_loaders.base import Loader
from oneailib.core.documents.base import Document
```

**Purpose:** Load content from `content_repo` table based on modification date
**Input Parameters:**
- `db_path`: Path to faq_update.db
- `since_date`: ISO timestamp for incremental loading
- `file_name`: Optional filter by file

**Output:** List of Document objects with metadata from content_repo

**Key Features:**
- Reads from SQLite database
- Converts DB rows to Document objects
- Loads markdown content from `extracted_markdown_file_path`
- Includes all content_repo fields in metadata

---

#### 1.2 **FAQRegenerationDetectorTransformer**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/faq_regeneration_detector.py

from oneailib.core.document_transformers.base import DocumentTransformer
```

**Purpose:** Wrapper for FAQRegenerationDetector as a oneailib transformer
**Input Parameters:**
- `db_path`: Path to faq_update.db (content + tracking)
- `since_date`: Detection period start

**Processing Logic:**
1. For each document, check if checksum exists in file's baseline
2. Add `requires_faq_regeneration` to metadata (0/1)
3. Add `existing_faq_count` to metadata
4. Preserve all detection telemetry

**Output:** Documents enriched with regeneration decision metadata

---

#### 1.3 **ChangeLoggerTransformer**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/change_logger.py

from oneailib.core.document_transformers.base import DocumentTransformer
```

**Purpose:** Log detection results to content_change_log
**Input Parameters:**
- `db_path`: Path to faq_update.db
- `detection_run_id`: Unique batch identifier

**Processing Logic:**
1. Extract detection metadata from documents
2. Insert to content_change_log (idempotent: UNIQUE on content_id + detection_run_id)
3. Store metadata as JSON

**Output:** Pass-through documents (logging is side effect)

---

#### 1.4 **FAQUpdaterTransformer**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/faq_updater.py

from oneailib.core.document_transformers.base import DocumentTransformer
```

**Purpose:** Update faq_content_map based on detection results
**Input Parameters:**
- `db_path`: Path to faq_update.db
- `detection_run_id`: Batch identifier

**Processing Logic:**
1. For documents with `requires_faq_regeneration=1`:
   - Invalidate existing FAQs by checksum
   - Set `is_valid=0`, `valid_until=now()`, `invalidation_reason='content_edited'`
2. For documents with `requires_faq_regeneration=0`:
   - Update `current_metadata` JSON with new location info

**Output:** Pass-through documents

---

#### 1.5 **FAQContentMapWriter**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/faq_content_map_writer.py

from oneailib.output_parsers.base import OutputParser
```

**Purpose:** Create new FAQ mappings in faq_content_map
**Input Parameters:**
- `db_path`: Path to faq_update.db
- `generation_method`: "regeneration" vs "initial"

**Processing Logic:**
1. Extract question/answer from document metadata
2. Get question_id (insert to faq_questions if new)
3. Get answer_id (insert to faq_answers if new)
4. Insert to faq_content_map with:
   - `content_checksum` (primary identity)
   - `current_content_id`, `original_content_id`
   - `current_metadata`, `original_metadata` (JSON)
   - `is_valid=1`, `valid_from=now()`

**Output:** Pass-through documents

---

#### 1.6 **MarkdownContentLoader**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/markdown_content_loader.py

from oneailib.core.document_transformers.base import DocumentTransformer
```

**Purpose:** Load markdown content from file paths in metadata
**Input Parameters:**
- None (uses `extracted_markdown_file_path` from metadata)

**Processing Logic:**
1. Read markdown file from path in metadata
2. Set as `page_content` of document
3. Preserve all existing metadata

**Output:** Documents with loaded markdown content

---

#### 1.7 **FAQQuestionLoaderByFile**
```python
# File: src/faq_services/settings/sors/analytics_assist_config/components/faq_question_loader.py

from oneailib.core.document_loaders.base import Loader
from oneailib.core.documents.base import Document
```

**Purpose:** Load existing FAQs from `faq_question` table based on file names from detection phase

**Input Parameters:**
- `db_path`: Path to faq_update.db
- `file_names`: List of file names (raw_file_nme) from modified content

**Processing Logic:**
1. Query `faq_questions` WHERE `src_file_name` IN (file_names)
2. JOIN with `faq_answers` ON `faq_questions.question_id = faq_answers.question_id`
3. Convert each row to Document object with:
   - `page_content`: `question_txt` (the question text)
   - `metadata`: All fields from both faq_questions and faq_answers tables

**SQL Query:**
```sql
SELECT
    fq.question_id,
    fq.question_txt,
    fq.prev_recommended_question_txt,
    fq.prev_question_txt,
    fq.recommeded_question_txt,
    fq.source,
    fq.src_file_name,
    fq.src_id,
    fq.src_page_number,
    fq.prev_src,
    fq.domain,
    fq.service,
    fq.product,
    fq.orgid,
    fq.created,
    fq.created_by,
    fq.modified,
    fq.modified_by,
    fq.version,
    fq.status,
    fq.metadata,
    fa.answer_id,
    fa.faq_answer_txt,
    fa.prev_recommended_answer_txt,
    fa.recommended_answer_txt,
    fa.prev_faq_answer_txt,
    fa.user_feedback_txt
FROM faq_questions fq
LEFT JOIN faq_answers fa ON fq.question_id = fa.question_id
WHERE fq.src_file_name IN (?)
```

**Output:** List of Document objects representing existing FAQs for files being processed

**Key Features:**
- Loads only FAQs associated with modified files
- Joins questions with their answers automatically
- Preserves all metadata from both tables for downstream processing
- Returns empty list if no FAQs exist for the files (graceful degradation)

---

### Phase 2: Reusable Blocks (YAML Configuration)

These YAML files will be created in `analytics_assist_config/reusable_blocks/`:

#### 2.1 **Loaders**
```
loaders/
├── load_content_repo.yaml              ← NEW: Load from content_repo table
├── load_existing_faqs_by_file.yaml     ← NEW: Load FAQs from faq_question by src_file_name
├── load_documents.yaml                 ← EXISTING: Reuse for baseline data
└── load_qa_bank_latest_ids_validated.yaml ← EXISTING: Load validated FAQs
```

#### 2.2 **Detectors** (NEW category)
```
detectors/
└── detect_faq_regeneration.yaml        ← NEW: Checksum-centric detection
```

#### 2.3 **Transformers**
```
transformers/
├── log_detection_results.yaml          ← NEW: Persist to content_change_log
├── update_faq_mappings.yaml            ← NEW: Invalidate + update mappings
├── load_markdown_content.yaml          ← NEW: Load content from file paths
├── generate_embedding.yaml             ← EXISTING: Reuse
├── filter_question_context.yaml        ← EXISTING: Reuse
├── filter_invalid_answers.yaml         ← EXISTING: Reuse
├── get_context_employed.yaml           ← EXISTING: Reuse
└── compute_semantic_distances.yaml     ← EXISTING: Reuse
```

#### 2.4 **Retrievers**
```
retrievers/
└── retrieve_context_by_question.yaml   ← EXISTING: Reuse (OpenSearch)
```

#### 2.5 **Generators**
```
generators/
├── generate_questions.yaml             ← EXISTING: Skip (questions from content)
└── generate_answers.yaml               ← EXISTING: Reuse
```

#### 2.6 **Output Parsers**
```
output_parsers/
├── write_faq_content_map.yaml          ← NEW: Insert to faq_content_map
├── save_to_qa_bank_partitioned.yaml    ← EXISTING: Reuse
├── save_to_csv.yaml                    ← EXISTING: Reuse
├── save_to_label_studio.yaml           ← EXISTING: Reuse
└── save_temporary.yaml                 ← EXISTING: Reuse (debugging)
```

---

## 🔧 Detailed Pipeline Configuration

### Main Pipeline File

**File:** `src/faq_services/settings/sors/analytics_assist_config/pipelines/faq_update.yaml`

```yaml
_target_: oneailib.core.utils.pipeline_base.Pipeline

steps:
    # ========================================================================
    # PHASE 1: DETECTION
    # ========================================================================

    - #load_content_repo:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/loaders/load_content_repo.yaml

    - #visualize_after_load_content:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "01_after_load_content_repo"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    - #detect_faq_regeneration:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/detectors/detect_faq_regeneration.yaml

    - #visualize_after_detection:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "02_after_faq_regeneration_detection"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # ========================================================================
    # PHASE 2: LOGGING
    # ========================================================================

    - #log_detection_results:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/log_detection_results.yaml

    - #visualize_after_logging:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "03_after_log_detection_results"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # ========================================================================
    # PHASE 3: FAQ PROCESSING (MultiPipeline)
    # ========================================================================

    - #multipipeline:
        _target_: oneailib.core.utils.pipeline_base.MultiPipeline
        steps:
            # Pipeline A: Load existing valid FAQs (to preserve)
            - # pipeline_existing_faqs:
                _target_: oneailib.core.utils.pipeline_base.Pipeline
                steps:
                    - # load_existing_valid_faqs:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/loaders/load_valid_faqs_by_checksums.yaml

                    - #visualize_existing_faqs:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "04a_existing_valid_faqs"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

            # Pipeline B: Process pages requiring FAQ regeneration
            - # pipeline_regeneration:
                _target_: oneailib.core.utils.pipeline_base.Pipeline
                steps:
                    # Filter to only pages requiring regeneration
                    - #filter_regeneration_required:
                        _target_: oneailib.document_transformers.metadata_transformers.DocumentInclusionConditionsMetadataTransformer
                        conditions: ["requires_faq_regeneration == 1"]

                    - #visualize_after_filter:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "04b_after_filter_regeneration_required"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Load markdown content from file paths
                    - #load_markdown_content:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/load_markdown_content.yaml

                    - #visualize_after_load_markdown:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "05_after_load_markdown_content"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Generate questions from content
                    - #generate_questions:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/generators/generate_questions.yaml

                    - #visualize_after_generate_questions:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "06_after_generate_questions"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Generate embeddings for questions
                    - #embedding_generator:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/generate_embedding.yaml

                    - #visualize_after_embedding:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "07_after_generate_embedding"
                        include_embeddings: true
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Retrieve context from OpenSearch
                    - #retriever:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/retrievers/retrieve_context_by_question.yaml

                    - #visualize_after_retriever:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "08_after_retrieve_context"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Deduplicate context
                    - #nested_deduplication:
                        _target_: custom_components.ContextMetadataDeduplicateTransformer
                        nested_key: "context_metadata"
                        subset: ["hash_id"]
                        keep: "first"
                        context_separator: ${response_separator}

                    - #visualize_after_dedup:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "09_after_nested_deduplication"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Filter question context quality
                    - #filter_questions_context:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/filter_question_context.yaml

                    - #visualize_after_filter_context:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "10_after_filter_question_context"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Generate answers using LLM
                    - #generate_answers:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/generators/generate_answers.yaml

                    - #visualize_after_generate_answers:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "11_after_generate_answers"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Filter invalid answers
                    - #filter_invalid_answers:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/filter_invalid_answers.yaml

                    - #visualize_after_filter_answers:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "12_after_filter_invalid_answers"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Get context employed
                    - #get_context_employed:
                        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/get_context_employed.yaml

                    - #visualize_after_context_employed:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "13_after_get_context_employed"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

                    # Sort by distance
                    - #sort_by_distance:
                        _target_: oneailib.document_transformers.metadata_transformers.SortDocumentsTransformer
                        keys: ["cosine_distance_question_context"]
                        sort_values_kwargs: { "ascending": True }

                    - #visualize_after_sort:
                        _target_: sample_output.DocumentVisualizerStep
                        step_name: "14_after_sort_by_distance"
                        include_embeddings: false
                        return_dict: true
                        output_dir: ${path_debug_export}

        # Merge both pipelines
        final_step:
            _target_: oneailib.document_transformers.joiner_transformers.DocumentsConcat

    - #visualize_after_multipipeline:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "15_after_multipipeline_merge"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # ========================================================================
    # PHASE 4: FAQ UPDATES
    # ========================================================================

    - #update_faq_mappings:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/update_faq_mappings.yaml

    - #visualize_after_faq_updates:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "16_after_update_faq_mappings"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # ========================================================================
    # PHASE 5: OUTPUT & QUALITY
    # ========================================================================

    - #formatting_enforcer:
        _target_: oneailib.document_transformers.metadata_html_formatting_transformers.MetadataKeyHTMLFormattingEnforcerTransformer
        allowed_tags: ["ul", "ol", "li", "a"]
        metadata_key: answer

    - #visualize_after_formatting:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "17_after_html_formatting_enforcer"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    - #add_question_answer_key:
        _target_: oneailib.document_transformers.metadata_transformers.AddMetadataTransformer
        keys: question_answer
        keys_to_replace: { question: "question", answer: "answer" }
        values: "{question} {answer}"

    - #visualize_after_add_qa:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "18_after_add_question_answer_key"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    - #compute_semantic_distances:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/transformers/compute_semantic_distances.yaml

    - #visualize_after_compute_distances:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "19_after_compute_semantic_distances"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Filter by semantic distance thresholds
    - #filter_by_question_distance:
        _target_: oneailib.document_transformers.metadata_transformers.DocumentInclusionConditionsMetadataTransformer
        conditions: ["self_cosine_distance_question > ${cosine_distance_question}"]

    - #visualize_after_filter_question_dist:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "20_after_filter_by_question_distance"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    - #filter_by_answer_distance:
        _target_: oneailib.document_transformers.metadata_transformers.DocumentInclusionConditionsMetadataTransformer
        conditions: ["self_cosine_distance_answer > ${cosine_distance_answer}"]

    - #visualize_after_filter_answer_dist:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "21_after_filter_by_answer_distance"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    - #filter_by_qa_distance:
        _target_: oneailib.document_transformers.metadata_transformers.DocumentInclusionConditionsMetadataTransformer
        conditions: ["self_cosine_distance_question_answer > ${cosine_distance_question_answer}"]

    - #visualize_after_filter_qa_dist:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "22_after_filter_by_question_answer_distance"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Add metadata for pipeline tracking
    - #add_pipeline_step_metadata:
        _target_: oneailib.document_transformers.metadata_transformers.AddMetadataTransformer
        keys: pipeline_step
        values: faq_update

    - #add_document_version:
        _target_: oneailib.document_transformers.metadata_transformers.AddDocumentVersionTransformer

    - #visualize_after_add_metadata:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "23_after_add_pipeline_metadata"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # ========================================================================
    # PHASE 6: PERSISTENCE
    # ========================================================================

    # Write to faq_content_map database
    - #write_faq_content_map:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/output_parsers/write_faq_content_map.yaml

    - #visualize_after_write_map:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "24_after_write_faq_content_map"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Save to partitioned QA bank
    - #save_qa_to_bank:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/output_parsers/save_to_qa_bank_partitioned.yaml

    - #visualize_after_save_bank:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "25_after_save_qa_to_bank"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Save to CSV backup
    - #save_qa_to_csv:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/output_parsers/save_to_csv.yaml

    # Filter only newly generated FAQs for Label Studio
    - #filter_for_label_studio:
        _target_: oneailib.document_transformers.metadata_transformers.DocumentInclusionConditionsMetadataTransformer
        conditions: ["requires_faq_regeneration == 1"]

    - #visualize_before_label_studio:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "26a_before_save_label_studio"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Convert HTML to Markdown for Label Studio
    - #html_to_markdown:
        _target_: oneailib.document_transformers.metadata_transformers.DocumentHTMLMarkdownTransformer
        transform_to_markdown: True
        metadata_field: answer

    - #visualize_after_html_to_md:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "26b_after_html_to_markdown"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}

    # Save to Label Studio for human validation
    - #save_to_label_studio:
        path: ../src/faq_services/settings/sors/analytics_assist_config/reusable_blocks/output_parsers/save_to_label_studio.yaml

    # Final visualization
    - #visualize_final_output:
        _target_: sample_output.DocumentVisualizerStep
        step_name: "27_final_pipeline_output"
        include_embeddings: false
        return_dict: true
        output_dir: ${path_debug_export}
```

---

## 📝 Reusable Block Specifications

### 1. Load Content Repo

**File:** `reusable_blocks/loaders/load_content_repo.yaml`

```yaml
steps:
  - # load_content_repo
    _target_: content_repo_loader.ContentRepoLoader
    db_path: ${faq_update_db_path}
    since_date: ${faq_update_since_date}
    file_name: ${faq_update_file_filter}  # Optional: null for all files
    content_column: "md_content"
    metadata_columns:
      - ud_source_file_id
      - domain
      - service
      - orgoid
      - associateoid
      - raw_file_nme
      - raw_file_type
      - raw_file_version_nbr
      - raw_file_page_nbr
      - source_url_txt
      - parent_location_txt
      - raw_file_path
      - extracted_markdown_file_path
      - extracted_layout_file_path
      - title_nme
      - breadcrumb_txt
      - content_tags_txt
      - version_nbr
      - content_checksum
      - file_status
      - created_dt
      - last_modified_dt
```

---

### 2. Detect FAQ Regeneration

**File:** `reusable_blocks/detectors/detect_faq_regeneration.yaml`

```yaml
steps:
  - # detect_faq_regeneration
    _target_: faq_regeneration_detector.FAQRegenerationDetectorTransformer
    db_path: ${faq_update_db_path}
    since_date: ${faq_update_since_date}
    file_name: ${faq_update_file_filter}  # Optional: null for all files
```

---

### 3. Log Detection Results

**File:** `reusable_blocks/transformers/log_detection_results.yaml`

```yaml
steps:
  - # log_detection_results
    _target_: change_logger.ChangeLoggerTransformer
    db_path: ${faq_update_db_path}
    detection_run_id: ${job.run_id}  # Databricks widget or timestamp
```

---

### 4. Load Existing FAQs by File

**File:** `reusable_blocks/loaders/load_existing_faqs_by_file.yaml`

```yaml
steps:
  - # load_existing_faqs_by_file
    _target_: faq_question_loader.FAQQuestionLoaderByFile
    db_path: ${faq_update_db_path}
    file_names: "${detected_file_names}"  # From detection phase (list of raw_file_nme)

    # SQL Query Logic:
    # 1. Get all file names from content_repo WHERE last_modified_dt >= since_date
    # 2. Query faq_questions WHERE src_file_name IN (file_names)
    # 3. JOIN with faq_answers ON faq_questions.question_id = faq_answers.question_id
    # 4. Convert to Document objects with question as page_content

    content_column: "question_txt"  # Use question as main content
    metadata_columns:
      # From faq_questions
      - question_id
      - prev_recommended_question_txt
      - prev_question_txt
      - recommeded_question_txt
      - source
      - src_file_name
      - src_id
      - src_page_number
      - prev_src
      - domain
      - service
      - product
      - orgid
      - created
      - created_by
      - modified
      - modified_by
      - version
      - status
      # From faq_answers (joined on question_id)
      - answer_id
      - faq_answer_txt
      - prev_recommended_answer_txt
      - recommended_answer_txt
      - prev_faq_answer_txt
      - user_feedback_txt
```

---

### 5. Load Markdown Content

**File:** `reusable_blocks/transformers/load_markdown_content.yaml`

```yaml
steps:
  - # load_markdown_content
    _target_: markdown_content_loader.MarkdownContentLoader
    path_field: "extracted_markdown_file_path"  # Field in metadata
    output_field: "page_content"  # Where to store loaded content
```

---

### 6. Update FAQ Mappings

**File:** `reusable_blocks/transformers/update_faq_mappings.yaml`

```yaml
steps:
  - # update_faq_mappings
    _target_: faq_updater.FAQUpdaterTransformer
    db_path: ${faq_update_db_path}
    detection_run_id: ${job.run_id}
    regeneration_flag_field: "requires_faq_regeneration"
```

---

### 7. Write FAQ Content Map

**File:** `reusable_blocks/output_parsers/write_faq_content_map.yaml`

```yaml
steps:
  - # write_faq_content_map
    _target_: faq_content_map_writer.FAQContentMapWriter
    db_path: ${faq_update_db_path}
    generation_method: "faq_update_pipeline"
    question_field: "question"
    answer_field: "answer"
    checksum_field: "content_checksum"
    content_id_field: "ud_source_file_id"
    file_name_field: "raw_file_nme"
```

---

## 🎛️ Configuration Parameters

### Environment-Specific Settings

**File:** `analytics_assist_config/analytics_assist_config.yaml` (add to existing)

```yaml
# FAQ Update Pipeline Configuration
faq_update:
  # Database paths
  faq_update_db_path: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/faq_update/databases/faq_update.db

  # Detection parameters
  faq_update_since_date: "2025-01-01T00:00:00.000Z"  # Override with widget
  faq_update_file_filter: null  # null = all files, or specific file name

  # Processing options
  faq_update_run_id: "${job.run_id}"  # Databricks job run ID
  faq_update_enable_visualizations: true

  # Quality thresholds (reuse existing)
  cosine_distance_question: ${cosine_distance_question}
  cosine_distance_answer: ${cosine_distance_answer}
  cosine_distance_question_answer: ${cosine_distance_question_answer}

  # OpenSearch (reuse existing)
  opensearch_host: ${opensearch_host}
  opensearch_index_name: ${opensearch_index_name}
  opensearch_score_threshold: ${opensearch_score_threshold}

  # LLM (reuse existing)
  model_name: ${model_name}
  api_base_url: ${api_base_url}
  temperature: ${temperature}

  # Output paths
  path_debug_export: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/faq_update/debug_output
  path_to_partitioned_qa_bank: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/qa_bank
  path_output_csv: /Volumes/onedata_us_east_1_shared_dit/faq_analytics_assist/faq_update/output
```

---

## 🧪 Testing Strategy

### Unit Tests (Component Level)

```python
# tests/test_content_repo_loader.py
def test_content_repo_loader_since_date():
    loader = ContentRepoLoader(
        db_path="test.db",
        since_date="2025-01-01T00:00:00Z"
    )
    docs = loader.load()
    assert all(doc.metadata['last_modified_dt'] > "2025-01-01T00:00:00Z" for doc in docs)

# tests/test_faq_regeneration_detector.py
def test_faq_regeneration_detector_checksum_logic():
    detector = FAQRegenerationDetectorTransformer(db_path="test.db")
    docs = [create_test_document()]
    result = detector.transform(docs)
    assert 'requires_faq_regeneration' in result[0].metadata
    assert result[0].metadata['requires_faq_regeneration'] in [0, 1]
```

### Integration Tests (Pipeline Level)

```python
# tests/integration/test_faq_update_pipeline.py
def test_faq_update_pipeline_end_to_end():
    # Setup test database with sample data
    setup_test_data()

    # Run pipeline
    result = run_hydra_pipeline("faq_update.yaml", overrides=[
        "faq_update_since_date=2025-01-01T00:00:00Z"
    ])

    # Verify outputs
    assert_detection_logged()
    assert_faq_mappings_updated()
    assert_qa_bank_written()
```

---

## 🚀 Implementation Roadmap

### Phase 1: Foundation (Week 1)
- [ ] Create custom components skeleton
  - [ ] ContentRepoLoader
  - [ ] FAQRegenerationDetectorTransformer
  - [ ] ChangeLoggerTransformer
  - [ ] FAQUpdaterTransformer
  - [ ] MarkdownContentLoader
  - [ ] FAQContentMapWriter
- [ ] Write unit tests for each component
- [ ] Test components individually with test database

### Phase 2: Reusable Blocks (Week 2)
- [ ] Create all reusable YAML blocks
  - [ ] Loaders (3 files)
  - [ ] Detectors (1 file)
  - [ ] Transformers (3 files)
  - [ ] Output Parsers (1 file)
- [ ] Test each block in isolation
- [ ] Document parameters and expected inputs/outputs

### Phase 3: Main Pipeline (Week 3)
- [ ] Create `faq_update.yaml` main pipeline
- [ ] Wire all components together
- [ ] Add debug visualizations
- [ ] Test pipeline with sample data locally

### Phase 4: Integration & Testing (Week 4)
- [ ] Deploy to Databricks DEV environment
- [ ] Configure widgets and secrets
- [ ] Run end-to-end test with real data
- [ ] Performance tuning and optimization
- [ ] Error handling refinement

### Phase 5: Production Readiness (Week 5)
- [ ] Create deployment documentation
- [ ] Set up monitoring and alerts
- [ ] Create runbook for operations
- [ ] Deploy to production
- [ ] Post-deployment validation

---

## 📊 Complete Data Flow Analysis - Step by Step

### **Database Tables Overview**

```
┌──────────────────────────────────────────────────────────┐
│               5 CORE TABLES IN faq_update.db              │
└──────────────────────────────────────────────────────────┘

1. content_repo
   ├─ ud_source_file_id (PK)
   ├─ raw_file_nme ◄───────────────┐ FILE NAME BRIDGE
   ├─ raw_file_page_nbr            │
   ├─ content_checksum ◄────────┐  │ CHECKSUM IDENTITY
   ├─ extracted_markdown_file_path │
   └─ last_modified_dt           │  │
                                 │  │
2. content_change_log            │  │
   ├─ change_id (PK)             │  │
   ├─ content_id (FK → content_repo.ud_source_file_id)
   ├─ content_checksum ◄─────────┘  │ DETECTION DECISION
   ├─ requires_faq_regeneration  │
   └─ detection_run_id           │  │
                                 │  │
3. faq_content_map (MAPPING)     │  │
   ├─ map_id (PK)                │  │
   ├─ question_id (FK)           │  │
   ├─ answer_id (FK)             │  │
   ├─ content_checksum ◄─────────┘  │ VALIDITY TRACKER
   ├─ is_valid                      │
   └─ invalidation_reason           │
                                    │
4. faq_questions                    │
   ├─ question_id (PK)              │
   ├─ question_txt                  │
   └─ src_file_name ◄───────────────┘ QUESTION-FILE LINK

5. faq_answers
   ├─ answer_id (PK)
   ├─ question_id (FK → faq_questions)
   └─ faq_answer_txt
```

### **Key Relationships**

1. **content_repo.raw_file_nme ↔ faq_questions.src_file_name**
   - FAQs are associated with files
   - Used to load existing FAQs when file changes

2. **content_repo.content_checksum ↔ faq_content_map.content_checksum**
   - Checksums identify specific content versions
   - When checksum changes → invalidate FAQ → regenerate

3. **faq_questions.question_id ↔ faq_answers.question_id**
   - One question can have one answer (current design)
   - LEFT JOIN allows questions without answers

---

### **DETAILED STEP-BY-STEP FLOW**

---

### **PHASE 1: DETECTION**

#### **Step 1.1: Load Content from content_repo**

**Input:**
- `since_date`: "2025-01-01T00:00:00Z"
- `db_path`: /path/to/faq_update.db

**SQL Query:**
```sql
SELECT *
FROM content_repo
WHERE last_modified_dt >= '2025-01-01T00:00:00Z'
  AND file_status = 'Active'
ORDER BY raw_file_nme, raw_file_page_nbr;
```

**Output:** 10 Document objects (example)

**Example:**
```python
Document(
    page_content="",  # Empty (loaded later)
    metadata={
        'ud_source_file_id': 12345,
        'raw_file_nme': 'employee_handbook.pdf',
        'raw_file_page_nbr': 42,
        'content_checksum': 'abc123...def456',  # SHA-256
        'extracted_markdown_file_path': '/path/page42.md',
        'last_modified_dt': '2025-01-15T10:30:00Z',
        ...
    }
)
```

**Files Loaded (example):**
- `employee_handbook.pdf` → pages 42, 43, 44
- `benefits_guide.pdf` → pages 15, 16, 17, 18
- `pto_policy.pdf` → pages 5, 6, 7

---

#### **Step 1.2: Detect FAQ Regeneration**

**For EACH document:**

**Step 1.2.1: Extract Current Checksum**
```python
current_checksum = doc.metadata['content_checksum']  # 'abc123...def456'
file_name = doc.metadata['raw_file_nme']  # 'employee_handbook.pdf'
```

**Step 1.2.2: Query Baseline (checksums BEFORE since_date)**
```sql
-- Get all checksums for this file BEFORE since_date
SELECT DISTINCT content_checksum
FROM content_repo
WHERE raw_file_nme = 'employee_handbook.pdf'
  AND last_modified_dt < '2025-01-01T00:00:00Z'
  AND file_status = 'Active';
```

**Result:** Baseline checksums: `['xyz789...', 'def456...', 'ghi012...']`

**Step 1.2.3: Checksum Comparison**
```python
if current_checksum in baseline_checksums:
    requires_faq_regeneration = 0  # UNCHANGED content
else:
    requires_faq_regeneration = 1  # NEW/MODIFIED content
```

**Step 1.2.4: Count Existing FAQs for This Checksum**
```sql
SELECT COUNT(*)
FROM faq_content_map
WHERE content_checksum = 'abc123...def456'
  AND is_valid = 1;
```

**Result:** `existing_faq_count = 5`

**Step 1.2.5: Enrich Document Metadata**
```python
doc.metadata['requires_faq_regeneration'] = 1
doc.metadata['existing_faq_count'] = 5
doc.metadata['detection_timestamp'] = '2025-01-21T14:30:00Z'
```

**Detection Summary (10 pages):**

| File | Page | Checksum | In Baseline? | Regen? | Existing FAQs |
|------|------|----------|--------------|--------|---------------|
| employee_handbook.pdf | 42 | abc123... | ❌ No | **1** | 5 |
| employee_handbook.pdf | 43 | abc124... | ✅ Yes | **0** | 8 |
| employee_handbook.pdf | 44 | abc125... | ❌ No | **1** | 0 |
| benefits_guide.pdf | 15 | def456... | ❌ No | **1** | 12 |
| benefits_guide.pdf | 16 | def457... | ✅ Yes | **0** | 6 |
| benefits_guide.pdf | 17 | def458... | ✅ Yes | **0** | 4 |
| benefits_guide.pdf | 18 | def459... | ❌ No | **1** | 0 |
| pto_policy.pdf | 5 | ghi012... | ❌ No | **1** | 3 |
| pto_policy.pdf | 6 | ghi013... | ✅ Yes | **0** | 2 |
| pto_policy.pdf | 7 | ghi014... | ✅ Yes | **0** | 1 |

**Result:**
- **5 pages require regeneration** (regen=1)
- **5 pages unchanged** (regen=0)
- **Total existing FAQs: 20** (sum of existing_faq_count where regen=1)

---

### **PHASE 2: LOGGING**

#### **Step 2.1: Log to content_change_log**

**For EACH document:**

```sql
INSERT INTO content_change_log (
    content_id,
    content_checksum,
    file_name,
    requires_faq_regeneration,
    metadata,
    detected_at,
    source_modified_at,
    existing_faq_count,
    detection_run_id,
    since_date
) VALUES (
    12345,
    'abc123...def456',
    'employee_handbook.pdf',
    1,  -- requires regeneration
    '{"page": 42, "title": "Sick Leave Policy"}',  -- JSON
    '2025-01-21T14:30:00Z',
    '2025-01-15T10:30:00Z',
    5,
    'RUN_2025_01_21_14_30_00',
    '2025-01-01T00:00:00Z'
)
ON CONFLICT (content_id, detection_run_id) DO NOTHING;
```

**content_change_log after logging:**

| change_id | content_id | checksum | file_name | requires_faq_regeneration | existing_faq_count |
|-----------|------------|----------|-----------|---------------------------|-------------------|
| 1 | 12345 | abc123... | employee_handbook.pdf | **1** | 5 |
| 2 | 12346 | abc124... | employee_handbook.pdf | **0** | 8 |
| 3 | 12347 | abc125... | employee_handbook.pdf | **1** | 0 |
| ... | ... | ... | ... | ... | ... |

---

### **PHASE 3: FAQ PROCESSING (MultiPipeline)**

---

#### **Pipeline A: Load Existing FAQs (By File Name)**

**Step A.1: Extract File Names from Detection**

From the 10 documents, extract unique file names:
```python
file_names = ['employee_handbook.pdf', 'benefits_guide.pdf', 'pto_policy.pdf']
```

**Step A.2: Query faq_questions + faq_answers (JOIN by file name)**

```sql
SELECT
    fq.question_id,
    fq.question_txt,
    fq.src_file_name,
    fq.src_page_number,
    fq.domain,
    fq.service,
    fq.status,
    fa.answer_id,
    fa.faq_answer_txt
FROM faq_questions fq
LEFT JOIN faq_answers fa ON fq.question_id = fa.question_id
WHERE fq.src_file_name IN (
    'employee_handbook.pdf',
    'benefits_guide.pdf',
    'pto_policy.pdf'
)
  AND fq.status = 'active';
```

**Result:** 45 Q&A pairs (example)

| question_id | question_txt | src_file_name | src_page_number | answer_id | faq_answer_txt |
|-------------|--------------|---------------|-----------------|-----------|----------------|
| Q001 | How many sick days do I get? | employee_handbook.pdf | 42 | A001 | You receive 10... |
| Q002 | Can I use sick leave for family? | employee_handbook.pdf | 42 | A002 | Yes, you can... |
| Q003 | What is the carryover policy? | employee_handbook.pdf | 43 | A003 | Sick days carry... |
| ... | ... | ... | ... | ... | ... |

**Step A.3: Convert to Document Objects**

```python
Document(
    page_content="How many sick days do I get?",  # question_txt
    metadata={
        'question_id': 'Q001',
        'answer_id': 'A001',
        'question': 'How many sick days do I get?',
        'answer': 'You receive 10 sick days per year...',
        'src_file_name': 'employee_handbook.pdf',
        'src_page_number': 42,
        'source': 'existing_faq',  # Mark as existing
        ...
    }
)
```

**Pipeline A Output:** **45 Document objects** (existing FAQs)

---

#### **Pipeline B: Regenerate FAQs (For Changed Content)**

**Step B.1: Filter Regeneration Required**

Filter documents where `requires_faq_regeneration == 1`:

**Input:** 10 documents
**Output:** 5 documents (pages 42, 44, 15, 18, 5)

---

**Step B.2: Load Markdown Content**

For each document, load actual markdown:

```python
path = doc.metadata['extracted_markdown_file_path']
with open(path, 'r') as f:
    doc.page_content = f.read()
```

**Example:**
```python
Document(
    page_content="""
# Sick Leave Policy

## Eligibility
All full-time employees receive 10 sick days per year.

## Usage
- Personal illness
- Medical appointments
- Family care (up to 5 days)
    """,
    metadata={'content_checksum': 'abc123...', ...}
)
```

---

**Step B.3: Generate Questions (LLM)**

**LLM Prompt:**
```
Based on the following content, generate 3-5 FAQs:

# Sick Leave Policy
...
```

**LLM Response:**
```json
[
    "How many sick days do employees receive?",
    "Can sick leave be used for family care?",
    "What is the sick day carryover limit?",
    "Are part-time employees eligible?"
]
```

**Transformation:** 1 document (page) → 4 documents (questions)

**Pipeline B after question generation:** ~20 questions (from 5 pages)

---

**Step B.4-B.7: Generate Embeddings, Retrieve Context, Filter**

(Standard oneailib pipeline steps - generate embeddings, retrieve from OpenSearch, deduplicate, filter)

---

**Step B.8: Generate Answers (LLM)**

**LLM Prompt:**
```
Question: How many sick days do employees receive?

Context:
- Full-time employees: 10 days/year
- Part-time: Pro-rated
...

Generate answer in HTML:
```

**LLM Response:**
```html
<p>Full-time employees receive <strong>10 sick days per year</strong>.</p>
```

**Document Update:**
```python
doc.metadata['question'] = "How many sick days do employees receive?"
doc.metadata['answer'] = "<p>Full-time employees receive...</p>"
doc.metadata['source'] = 'generated_from_content'
doc.metadata['content_checksum'] = 'abc123...def456'  # From original page
```

---

**Step B.9-B.11: Filter, Track Context, Sort**

(Filter invalid answers, track context employed, sort by distance)

**Pipeline B Output:** **~15 new Q&A pairs** (after filtering)

---

#### **Step 3.3: Merge Pipelines**

**Input:**
- Pipeline A: 45 existing FAQs
- Pipeline B: 15 new FAQs

**Output:** **60 total FAQs**

---

### **PHASE 4: FAQ UPDATES**

#### **Step 4.1: Update faq_content_map**

**For EACH FAQ in the merged list:**

**Scenario 1: Existing FAQ (from Pipeline A)**

**Step 4.1.1: Get FAQ's Current Checksum from faq_content_map**

```sql
SELECT content_checksum, map_id, is_valid
FROM faq_content_map
WHERE question_id = 'Q001'
  AND is_valid = 1;
```

**Result:** `content_checksum = 'old_xyz789...'`

**Step 4.1.2: Check if This Checksum Requires Regeneration**

```sql
SELECT requires_faq_regeneration
FROM content_change_log
WHERE content_checksum = 'old_xyz789...'
  AND detection_run_id = 'RUN_2025_01_21_14_30_00';
```

**Case A: Checksum Changed (requires_faq_regeneration = 1)**

```sql
-- Invalidate the old FAQ mapping
UPDATE faq_content_map
SET is_valid = 0,
    valid_until = strftime('%Y-%m-%dT%H:%M:%SZ','now'),
    invalidation_reason = 'content_edited',
    invalidated_by_change_id = (
        SELECT change_id
        FROM content_change_log
        WHERE content_checksum = 'new_abc123...'
          AND detection_run_id = 'RUN_2025_01_21_14_30_00'
    )
WHERE map_id = <map_id>;
```

**Case B: Checksum Unchanged (requires_faq_regeneration = 0)**

```sql
-- Just update current_metadata (page might have moved)
UPDATE faq_content_map
SET current_metadata = json_object(
    'current_page', 42,
    'current_title', 'Sick Leave Policy'
)
WHERE map_id = <map_id>;
```

---

**Scenario 2: New FAQ (from Pipeline B)**

**Will be inserted in Phase 6 (Write FAQ Content Map)**

---

**Update Summary:**

| Question | Old Checksum | New Checksum | Regen? | Action |
|----------|--------------|--------------|--------|--------|
| Q001: How many sick days? | xyz789... | abc123... | 1 | **Invalidate** (content changed) |
| Q002: Family sick leave? | xyz789... | abc123... | 1 | **Invalidate** (content changed) |
| Q003: Carryover policy? | xyz790... | xyz790... | 0 | **Update metadata only** |
| Q004: Benefits enrollment? | def456... | def999... | 1 | **Invalidate** (content changed) |

**Result:**
- **20 FAQ mappings invalidated** (set `is_valid = 0`)
- **25 FAQ mappings updated** (metadata refreshed)
- **15 new FAQs** ready to insert

---

### **PHASE 5: OUTPUT & QUALITY**

(Format HTML, add metadata, compute distances, filter by thresholds)

**After filtering:** **~55 Q&A pairs** (some filtered out by quality thresholds)

---

### **PHASE 6: PERSISTENCE**

#### **Step 6.1: Write FAQ Content Map**

**For EACH NEW FAQ:**

**Step 6.1.1: Insert into faq_questions (if new question)**

```sql
INSERT INTO faq_questions (
    question_id,
    question_txt,
    src_file_name,
    src_page_number,
    domain,
    service,
    created,
    created_by,
    status
) VALUES (
    'Q046',  -- Auto-generated ID
    'How many sick days do employees receive?',
    'employee_handbook.pdf',
    42,
    'HR',
    'Policy',
    strftime('%Y-%m-%dT%H:%M:%SZ','now'),
    'faq_update_pipeline',
    'active'
)
ON CONFLICT (question_txt) DO UPDATE SET modified = strftime('%Y-%m-%dT%H:%M:%SZ','now');
```

**Step 6.1.2: Insert into faq_answers**

```sql
INSERT INTO faq_answers (
    answer_id,
    question_id,
    faq_answer_txt,
    src_file_name,
    src_page_number,
    created,
    created_by,
    status
) VALUES (
    'A046',
    'Q046',
    '<p>Full-time employees receive...</p>',
    'employee_handbook.pdf',
    42,
    strftime('%Y-%m-%dT%H:%M:%SZ','now'),
    'faq_update_pipeline',
    'active'
);
```

**Step 6.1.3: Insert into faq_content_map**

```sql
INSERT INTO faq_content_map (
    question_id,
    answer_id,
    content_checksum,
    current_content_id,
    current_file_name,
    original_content_id,
    current_metadata,
    original_metadata,
    is_valid,
    valid_from,
    confidence_score,
    generation_method
) VALUES (
    'Q046',
    'A046',
    'abc123...def456',  -- ← CRITICAL: Checksum links FAQ to content
    12345,  -- ud_source_file_id
    'employee_handbook.pdf',
    12345,
    json_object('current_page', 42, 'title', 'Sick Leave Policy'),
    json_object('original_page', 42, 'title', 'Sick Leave Policy'),
    1,  -- is_valid = TRUE
    strftime('%Y-%m-%dT%H:%M:%SZ','now'),
    0.92,
    'faq_update_pipeline'
);
```

**Key Insight:**
- `content_checksum` in `faq_content_map` is the **linchpin**
- When content changes → checksum changes → FAQ invalidated
- One FAQ can have multiple mappings (to different checksums) over time

---

#### **Step 6.2-6.4: Save Outputs**

- QA Bank (partitioned by domain/service)
- CSV (backup/audit)
- Label Studio (only new FAQs with `requires_faq_regeneration == 1`)

---

## 📊 Data Flow Diagram (Summary)

```
┌─────────────────┐
│  content_repo   │ (Modified content since_date)
└────────┬────────┘
         │ Load (10 pages from 3 files)
         ▼
┌─────────────────┐
│   Documents     │ (with checksums)
└────────┬────────┘
         │ Detect (compare to baseline)
         ▼
┌─────────────────┐
│   Documents     │ (+ requires_faq_regeneration: 0/1)
│                 │ (+ existing_faq_count)
└────────┬────────┘
         │ Log to content_change_log
         ▼
┌──────────────────┐
│ content_change_  │ (10 records logged)
│      log         │
└────────┬─────────┘
         │
         ├─────────────────┬─────────────────┐
         │                 │                 │
         ▼                 ▼                 ▼
┌────────────────┐  ┌─────────────┐  ┌──────────────┐
│ Pipeline A:    │  │  Regen=0    │  │   Regen=1    │
│ Load Existing  │  │  (5 pages)  │  │  (5 pages)   │
│ FAQs by File   │  │  (skip)     │  │  (process)   │
│ (45 Q&A pairs) │  │             │  │              │
└────────┬───────┘  └─────────────┘  └──────┬───────┘
         │                                   │
         │                                   │ Load markdown
         │                                   │ Generate questions (20)
         │                                   │ Generate embeddings
         │                                   │ Retrieve context
         │                                   │ Generate answers (15)
         │                                   │
         └───────────────────────────────────┘
                           │ Merge (60 total)
                           ▼
                  ┌─────────────────┐
                  │  All FAQs       │ (45 existing + 15 new)
                  └────────┬────────┘
                           │ Update faq_content_map
                           │ (20 invalidated, 25 updated, 15 new)
                           ▼
         ┌─────────────────┼─────────────────┬─────────────────┐
         │                 │                 │                 │
         ▼                 ▼                 ▼                 ▼
┌────────────────┐  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐
│ faq_questions  │  │ faq_answers │  │faq_content_  │  │ Label Studio │
│ (insert 15)    │  │ (insert 15) │  │map (updated) │  │ (15 new)     │
└────────────────┘  └─────────────┘  └──────────────┘  └──────────────┘
```

---

## 🔍 Key Design Decisions

### 1. **Why Custom Components Instead of Standalone Scripts?**
- **Integration**: Seamless with oneailib document processing
- **Composability**: Can be mixed with existing transformers
- **Testing**: Easier to unit test with document fixtures
- **Consistency**: Follows same patterns as WeightedOpensearchRetriever

### 2. **Why Reusable Blocks Over Inline Configuration?**
- **Maintainability**: Changes in one place affect all pipelines
- **Readability**: Main pipeline YAML stays clean and high-level
- **Reusability**: Same blocks for update, validation, and initial generation
- **Testing**: Can test blocks independently

### 3. **Why MultiPipeline Split?**
- **Performance**: Avoid regenerating FAQs that haven't changed
- **Resource Optimization**: LLM calls only for truly new content
- **Clarity**: Separate logic for "preserve" vs "regenerate" paths
- **Mirroring**: Matches existing test2.yaml architecture

### 4. **Why JSON Metadata Instead of Top-Level Fields?**
- **Flexibility**: No schema changes needed for new content types
- **Simplicity**: Fewer NULL columns, cleaner database
- **Future-Proof**: Supports HTML, XML, sections, paragraphs without migration
- **Alignment**: Matches v4 simplified schema philosophy

---

## ⚠️ Risk Mitigation

### Risk 1: Database Locking (SQLite)
**Mitigation:**
- Use WAL mode: `PRAGMA journal_mode=WAL`
- Batch commits (reduce transaction frequency)
- Read-only connections where possible
- Consider migration to Postgres/MySQL for high concurrency

### Risk 2: Large File Processing (Memory)
**Mitigation:**
- Process files in batches (pagination)
- Stream documents through pipeline (don't load all at once)
- Monitor memory usage with telemetry
- Use `lazy_load()` methods where available

### Risk 3: LLM API Rate Limits
**Mitigation:**
- Exponential backoff retry logic (already in OpenAI components)
- Batch size tuning via configuration
- Queue system for large regeneration batches
- Cost monitoring and budget alerts

### Risk 4: Data Inconsistency (Race Conditions)
**Mitigation:**
- Idempotent operations (UNIQUE constraints)
- Atomic transactions (BEGIN...COMMIT)
- detection_run_id for batch tracking
- Version tracking in faq_content_map

---

## 📚 References & Dependencies

### OneAILib Components (Reused)
- `oneailib.core.utils.pipeline_base.Pipeline`
- `oneailib.core.utils.pipeline_base.MultiPipeline`
- `oneailib.document_transformers.metadata_transformers.*`
- `oneailib.document_loaders.csv.CSVLoader`
- `oneailib.output_parsers.partitioned_dataset_csv.PartitionedDatasetCSVOutputParser`
- `sample_output.DocumentVisualizerStep`

### Custom Components (Existing in analytics_assist_config)
- `opensearch_dita.WeightedOpensearchRetriever`
- `custom_components.AddDocumentHashIDTransformer`
- `custom_components.ContextMetadataDeduplicateTransformer`

### Notebook Components (To Adapt)
- `FAQRegenerationDetector` (from `src/detectors/`)
- `ChangeLogger` (from `src/processors/`)
- `FAQUpdater` (from `src/processors/`)

### Database Schema
- `create_schema_v4.sql` (unified faq_update.db)
- Tables: content_repo, content_change_log, faq_content_map, faq_questions, faq_answers

---

## 🎓 Learning & Documentation

### For New Developers
1. Read CLAUDE.md (project overview)
2. Review test2.yaml (reference pipeline)
3. Study WeightedOpensearchRetriever (custom component pattern)
4. Run 3_update_detector.ipynb (understand detection logic)
5. Review this design doc (implementation plan)

### Documentation to Create
- [ ] Component API documentation (docstrings)
- [ ] Pipeline configuration guide (parameters)
- [ ] Troubleshooting runbook (common errors)
- [ ] Performance tuning guide (optimization)
- [ ] Monitoring dashboard setup (Databricks)

---

## 🎯 Success Criteria

### Functional Requirements
- ✅ Pipeline correctly identifies pages requiring FAQ regeneration
- ✅ Only changed content triggers LLM calls (cost optimization)
- ✅ Existing FAQs are preserved when content unchanged
- ✅ FAQ mappings correctly updated in database
- ✅ All outputs (QA bank, CSV, Label Studio) generated correctly

### Non-Functional Requirements
- ✅ Pipeline completes within 30 minutes for 100 pages
- ✅ Memory usage stays under 8GB
- ✅ Idempotent (can re-run without side effects)
- ✅ Error handling with clear messages
- ✅ Telemetry captures all key metrics

### Quality Gates
- ✅ 90%+ test coverage for custom components
- ✅ Zero database corruption on failure scenarios
- ✅ Cost per FAQ regeneration < $0.10 (LLM + compute)
- ✅ Successful production run on 1000+ pages

---

## 📞 Appendix: Contact & Support

**Architecture Questions:** Review this document + CLAUDE.md
**Implementation Help:** Study existing components (WeightedOpensearchRetriever)
**Database Questions:** Review create_schema_v4.sql + ARCHITECTURE_V4_SIMPLIFIED.md
**Pipeline Questions:** Study test2.yaml + reusable_blocks/

---

**END OF DESIGN DOCUMENT**

*This comprehensive design provides a complete roadmap for implementing the Hydra-based FAQ update pipeline. All components, configurations, and workflows are specified in detail, following senior-level software engineering best practices.*
