# Databricks notebook source
"""
Test Similarity Algorithms Notebook

Test and compare different similarity algorithms on sample FAQ content.
"""

# COMMAND ----------

# MAGIC %md
# MAGIC # Test Similarity Algorithms
# MAGIC
# MAGIC Compare performance and results of different similarity algorithms:
# MAGIC - Jaccard
# MAGIC - Difflib
# MAGIC - TF-IDF
# MAGIC - BM25
# MAGIC - Hybrid

# COMMAND ----------

import sys
sys.path.append('/Workspace/path/to/granular_impact')  # Adjust path

from granular_impact.similarity import (
    JaccardSimilarityCalculator,
    DifflibSimilarityCalculator,
    TfidfSimilarityCalculator,
    BM25SimilarityCalculator,
    HybridSimilarityCalculator,
)

# COMMAND ----------

# Sample FAQ content pairs
test_pairs = [
    (
        "Employees must submit expense reports within 30 days of the expense date.",
        "Employees must submit expense reports within 45 days of the expense date."
    ),
    (
        "What is the company PTO policy?",
        "What is our paid time off policy?"
    ),
    (
        "The deadline for annual reviews is December 31st.",
        "The deadline for annual reviews is January 15th."
    ),
]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test Individual Algorithms

# COMMAND ----------

algorithms = {
    "Jaccard": JaccardSimilarityCalculator(),
    "Difflib": DifflibSimilarityCalculator(),
    "TF-IDF": TfidfSimilarityCalculator(),
    "BM25": BM25SimilarityCalculator(),
    "Hybrid": HybridSimilarityCalculator(),
}

results = []

for pair_idx, (text1, text2) in enumerate(test_pairs, 1):
    print(f"\\n{'='*80}")
    print(f"Pair {pair_idx}:")
    print(f"Text 1: {text1}")
    print(f"Text 2: {text2}")
    print(f"{'='*80}")

    for name, calc in algorithms.items():
        result = calc.compute_similarity(text1, text2)
        print(f"{name:15} Score: {result.score:.4f}  Time: {result.processing_time_ms:.2f}ms")
        results.append({
            "pair": pair_idx,
            "algorithm": name,
            "score": result.score,
            "time_ms": result.processing_time_ms,
        })

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualize Results

# COMMAND ----------

import pandas as pd

df_results = pd.DataFrame(results)
display(df_results.pivot(index='pair', columns='algorithm', values='score'))

# COMMAND ----------

print("\\nSimilarity testing complete!")
