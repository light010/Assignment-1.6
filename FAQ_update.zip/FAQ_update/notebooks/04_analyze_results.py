# Databricks notebook source
"""
Analyze Results Notebook

Analyze and visualize impact analysis results.
"""

# COMMAND ----------

# MAGIC %md
# MAGIC # Analyze Impact Results

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt

# Configuration
catalog = "onedata_us_east_1_shared_dit"
schema = "faq_service"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Results

# COMMAND ----------

results_df = spark.table(f"{catalog}.{schema}.faq_impact_results")
display(results_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Impact Distribution

# COMMAND ----------

impact_dist = results_df.groupBy("impact_decision").count().toPandas()
display(impact_dist)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Score Distribution

# COMMAND ----------

scores_df = results_df.select(
    "similarity_score",
    "diff_magnitude",
    "semantic_importance",
    "overall_impact_score"
).toPandas()

scores_df.hist(figsize=(12, 8), bins=20)
plt.tight_layout()
display(plt.gcf())

# COMMAND ----------

# MAGIC %md
# MAGIC ## FAQs Requiring Action

# COMMAND ----------

action_required = results_df.filter(
    (results_df.impact_decision == "invalidate") |
    (results_df.requires_manual_review == True)
)

print(f"FAQs requiring action: {action_required.count()}")
display(action_required.select("faq_id", "impact_decision", "overall_impact_score", "invalidation_reason"))

# COMMAND ----------

print("Analysis complete!")
