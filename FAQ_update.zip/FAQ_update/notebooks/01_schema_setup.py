# Databricks notebook source
"""
Schema Setup Notebook

Creates the necessary database tables for granular impact analysis.
Run this notebook first to set up the schema in your Databricks environment.
"""

# COMMAND ----------

# MAGIC %md
# MAGIC # Granular Impact Analysis - Schema Setup
# MAGIC
# MAGIC This notebook creates the required tables for the impact analysis system:
# MAGIC - content_repo: Stores source content with checksums
# MAGIC - faq_qa_bank: Stores FAQ question/answer pairs
# MAGIC - faq_impact_results: Stores impact analysis results
# MAGIC - faq_impact_audit_log: Stores audit trail

# COMMAND ----------

# Configuration
catalog = "onedata_us_east_1_shared_dit"  # Change for your environment
schema = "faq_service"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Content Repository Table

# COMMAND ----------

sql_create_content_repo = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.content_repo (
    content_id STRING NOT NULL,
    content_text STRING NOT NULL,
    content_checksum STRING NOT NULL,
    content_version INT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    metadata MAP<STRING, STRING>,
    source_system STRING,
    topic STRING,
    subtopic STRING
)
USING DELTA
PARTITIONED BY (content_id)
COMMENT 'Source content repository with version tracking'
"""

spark.sql(sql_create_content_repo)
print("✓ Created content_repo table")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create FAQ Q&A Bank Table

# COMMAND ----------

sql_create_faq_bank = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.faq_qa_bank (
    faq_id STRING NOT NULL,
    question STRING NOT NULL,
    answer STRING NOT NULL,
    source_content_ids ARRAY<STRING> NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_valid BOOLEAN NOT NULL DEFAULT true,
    validation_status STRING,
    validation_score DOUBLE,
    metadata MAP<STRING, STRING>
)
USING DELTA
COMMENT 'FAQ question and answer pairs'
"""

spark.sql(sql_create_faq_bank)
print("✓ Created faq_qa_bank table")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Impact Results Table

# COMMAND ----------

sql_create_impact_results = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.faq_impact_results (
    result_id STRING NOT NULL,
    faq_id STRING NOT NULL,
    content_id STRING NOT NULL,
    content_old_checksum STRING NOT NULL,
    content_new_checksum STRING NOT NULL,
    similarity_score DOUBLE NOT NULL,
    diff_magnitude DOUBLE NOT NULL,
    semantic_importance DOUBLE NOT NULL,
    overall_impact_score DOUBLE NOT NULL,
    impact_decision STRING NOT NULL,
    change_type STRING NOT NULL,
    analysis_timestamp TIMESTAMP NOT NULL,
    algorithm_used STRING NOT NULL,
    algorithm_metadata MAP<STRING, STRING>,
    detected_changes MAP<STRING, STRING>,
    invalidation_reason STRING,
    requires_manual_review BOOLEAN DEFAULT false,
    reviewed_by STRING,
    review_timestamp TIMESTAMP
)
USING DELTA
PARTITIONED BY (analysis_timestamp)
COMMENT 'Impact analysis results for FAQ content changes'
"""

spark.sql(sql_create_impact_results)
print("✓ Created faq_impact_results table")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Audit Log Table

# COMMAND ----------

sql_create_audit_log = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.faq_impact_audit_log (
    log_id STRING NOT NULL,
    operation STRING NOT NULL,
    entity_type STRING NOT NULL,
    entity_id STRING NOT NULL,
    user STRING NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    success BOOLEAN NOT NULL,
    details MAP<STRING, STRING>,
    error_message STRING
)
USING DELTA
PARTITIONED BY (timestamp)
COMMENT 'Audit log for all impact analysis operations'
"""

spark.sql(sql_create_audit_log)
print("✓ Created faq_impact_audit_log table")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify Schema

# COMMAND ----------

print("\\nVerifying tables created:")
print("=" * 50)
tables = spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()
for table in tables:
    if 'faq' in table.tableName or 'content_repo' in table.tableName:
        print(f"✓ {table.tableName}")

print("\\nSchema setup complete!")
