# Change Tracker Notebook - User Guide

## 📋 Overview

The `change_tracker.ipynb` notebook is a **comprehensive database explorer** that provides direct visibility into every table and VIEW in the FAQ update tracking system. Think of it as your "database browser" or "data viewer" for the system.

## 🎯 Purpose

Unlike `data_analysis.ipynb` which focuses on analytics and insights, `change_tracker.ipynb` is designed to:

- **Browse raw data** - See actual records in every table
- **Explore VIEWs** - Understand derived data
- **Search records** - Find specific content across tables
- **Export data** - Extract data for external tools
- **Learn the schema** - Understand table structures
- **Debug issues** - Investigate data problems

## 🔄 Comparison with Other Notebooks

| Notebook | Purpose | When to Use |
|----------|---------|-------------|
| **setup_tables.ipynb** | Create database schema | Initial setup, schema updates |
| **content_edit.ipynb** | Add test data | Testing, development |
| **update_detector.ipynb** | Detect & process changes | After content changes occur |
| **data_analysis.ipynb** | Analytics & insights | Understanding trends, metrics |
| **change_tracker.ipynb** ← | Browse & explore data | Viewing raw data, searching, debugging |

## 🏗️ Structure

### 9-Step Exploration Flow

```
Step 1: Configuration
   ↓ Setup display settings and paths

Step 2: Database Overview
   ↓ Tables, views, indexes summary

Step 3: content_repo
   ↓ Browse source content

Step 4: faq_questions & faq_answers
   ↓ Browse FAQ data

Step 5: content_change_log, faq_content_map, content_diffs
   ↓ Browse tracking tables

Step 6: All 9 VIEWs
   ↓ Explore derived data

Step 7: Search & Filter
   ↓ Find specific records

Step 8: Data Export
   ↓ Extract to CSV

Step 9: Quick Summary
   ↓ High-level stats
```

## 📊 Tables Covered

### Base Tables (Step 3-4)

#### 1. **content_repo**
- **Purpose**: Source content repository
- **What you'll see**: All documents, pages, versions
- **Key fields**: file name, page number, checksum, status
- **Extra info**: Schema, statistics, files breakdown

#### 2. **faq_questions**
- **Purpose**: FAQ questions master
- **What you'll see**: All questions with metadata
- **Key fields**: question text, source, domain, service
- **Extra info**: Schema, domain/service breakdown

#### 3. **faq_answers**
- **Purpose**: FAQ answers
- **What you'll see**: All answers linked to questions
- **Key fields**: answer text, question_id, feedback
- **Extra info**: Q&A pairing analysis

### Tracking Tables (Step 5)

#### 4. **content_change_log**
- **Purpose**: All content changes
- **What you'll see**: Every detected change
- **Key fields**: change type, file, page, dates
- **Extra info**: Change type breakdown, activity by file

#### 5. **faq_content_map**
- **Purpose**: FAQ-to-content linkages
- **What you'll see**: All FAQ mappings with validity
- **Key fields**: question/answer IDs, checksum, is_valid
- **Extra info**: Validity stats, invalidation reasons

#### 6. **content_diffs**
- **Purpose**: Detailed change diffs
- **What you'll see**: Diff metrics and analysis
- **Key fields**: similarity scores, chars/lines changed
- **Extra info**: Magnitude distribution, semantic summaries

### VIEWs (Step 6)

All 9 VIEWs from the schema are explored:

1. **v_content_change_summary** - Changes by file/type
2. **v_latest_content_state** - Current page states
3. **v_document_structure_changes** - Bulk operations
4. **v_current_valid_faqs** - Active FAQs
5. **v_faq_validity_timeline** - FAQ lifecycle
6. **v_faqs_needing_review** - Invalidated FAQs
7. **v_content_changes_with_diffs** - Changes with metrics
8. **v_pending_diffs** - Processing queue
9. **v_diff_processing_stats** - Performance metrics

## ⚙️ Configuration

At the top of the notebook, you can adjust:

```python
# Display settings
DEFAULT_ROW_LIMIT = 20      # Rows to show per table
VIEW_ROW_LIMIT = 15         # Rows to show per VIEW
SEARCH_LIMIT = 50           # Max search results

# Export directory
EXPORT_DIR = PROJECT_ROOT / 'exports'
```

### Adjusting Row Limits

**Show more rows:**
```python
DEFAULT_ROW_LIMIT = 50      # Show 50 rows instead of 20
VIEW_ROW_LIMIT = 30         # Show 30 rows for VIEWs
```

**Show fewer rows:**
```python
DEFAULT_ROW_LIMIT = 10      # Show only 10 rows
VIEW_ROW_LIMIT = 5          # Show only 5 rows for VIEWs
```

**Show ALL rows** (be careful with large tables):
```python
# Modify queries to remove LIMIT clause
# Or set very high limit
DEFAULT_ROW_LIMIT = 10000
```

## 🔍 Search Features

### 7.1 Search by File Name

Find all records related to a specific file:

```python
SEARCH_FILE_NAME = "Employee_Leave_Policy.pdf"
```

Searches across:
- content_repo
- content_change_log
- faq_content_map

### 7.2 Search by Page Number

Find everything about a specific page:

```python
SEARCH_FILE = "Employee_Leave_Policy.pdf"
SEARCH_PAGE = 2
```

Returns:
- Content record
- Change history
- Associated FAQs

### 7.3 Search by Date Range

Find all changes in a date range:

```python
START_DATE = "2025-01-01"
END_DATE = "2025-12-31"
```

Returns:
- Changes by date and type
- Summary statistics

## 📤 Export Features

### Exporting to CSV

Configure which tables/views to export:

```python
EXPORT_TABLES = [
    'content_change_log',
    'faq_content_map',
    'v_current_valid_faqs',
    'v_faqs_needing_review'
]
```

Exports include:
- Timestamped filenames
- All columns
- All rows (no limit)
- Saved to `exports/` directory

### Export File Naming

Format: `{table_name}_{timestamp}.csv`

Example: `content_change_log_20251007_010530.csv`

### Finding Exported Files

All exports go to:
```
FAQ_update/exports/
```

## 📊 What You'll See for Each Table

### Table Display Format

For each table, the notebook shows:

1. **Header**
   - Table name
   - Description
   - Record count

2. **Schema**
   - Column names
   - Data types
   - Constraints (PRIMARY KEY, NOT NULL)

3. **Recent Records**
   - Actual data rows
   - Most recent first
   - Configurable row limit

4. **Statistics**
   - Aggregated metrics
   - Summary counts
   - Breakdowns

5. **Related Data**
   - Cross-table summaries
   - Related record counts

### Example Output

```
════════════════════════════════════════════════════════════════════════════════
                              TABLE: content_change_log
════════════════════════════════════════════════════════════════════════════════

📊 Table: content_change_log
   Description: Single source of truth for all content changes
   Records: 350
────────────────────────────────────────────────────────────────────────────────

   Schema:
      • change_id                    INTEGER          NOT NULL [PRIMARY KEY]
      • content_id                   INTEGER          NOT NULL
      • file_name                    TEXT             NOT NULL
      • page_number                  INTEGER          NOT NULL
      • change_type                  TEXT             NOT NULL
      ...

📄 Recent Changes:
────────────────────────────────────────────────────────────────────────────────
change_id  content_id  file_name              page_number  change_type      ...
350        1006        Employee_Leave.pdf     4            position_change  ...
349        1005        Employee_Leave.pdf     3            page_inserted    ...
348        1004        Employee_Leave.pdf     2            content_edit     ...
...

   Showing first 20 of 350 rows

📊 Statistics:
   • total_changes: 350
   • unique_content: 125
   • unique_files: 5
   ...
```

## 🎯 Common Use Cases

### 1. **Browsing Content**

**Goal**: See what content is in the system

**Steps**:
1. Run notebook up to Step 3
2. Look at `content_repo` output
3. Review files breakdown table

### 2. **Finding a Specific File**

**Goal**: See all data for one file

**Steps**:
1. Go to Step 7.1 (Search by File Name)
2. Set `SEARCH_FILE_NAME = "your_file.pdf"`
3. Run cell
4. Review results from all tables

### 3. **Checking FAQ Status**

**Goal**: See which FAQs are valid/invalid

**Steps**:
1. Go to Step 5 (faq_content_map)
2. Look at validity breakdown
3. Or go to Step 6.4 (v_current_valid_faqs)
4. Or go to Step 6.6 (v_faqs_needing_review)

### 4. **Understanding Changes**

**Goal**: See what changed and when

**Steps**:
1. Go to Step 5 (content_change_log)
2. Review change type breakdown
3. Look at recent activity by file
4. Or go to Step 7.3 for date range

### 5. **Exporting Data**

**Goal**: Get data into Excel/external tool

**Steps**:
1. Go to Step 8
2. Configure `EXPORT_TABLES` list
3. Run cell
4. Find CSVs in `exports/` folder

### 6. **Debugging Issues**

**Goal**: Investigate data problems

**Steps**:
1. Use search features (Step 7)
2. Check schema (shown for each table)
3. Look at related tables
4. Export for detailed analysis

### 7. **Learning the System**

**Goal**: Understand database structure

**Steps**:
1. Run entire notebook
2. Read descriptions for each table
3. Look at schema sections
4. Examine relationships in queries

## 💡 Tips and Tricks

### Tip 1: Start with Overview

Always run Step 2 first to see what's in the database:
- How many records in each table
- Which tables are populated
- Which are empty

### Tip 2: Adjust Display Settings

If you see "Showing first N rows", you can:
- Increase `DEFAULT_ROW_LIMIT` to see more
- Or just know there's more data not shown

### Tip 3: Use VIEWs for Better Context

VIEWs combine data from multiple tables:
- Easier to understand than raw tables
- Already filtered and joined
- Purpose-built for common questions

### Tip 4: Search Before Export

Use search to find what you need first:
- Narrow down to specific files/pages
- Then export just what you need
- Saves time and file size

### Tip 5: Check Schema When Confused

Every table shows its schema:
- See what columns exist
- Understand data types
- Know which are primary keys

### Tip 6: Export for Complex Analysis

For complex analysis:
- Export to CSV
- Open in Excel/Pandas/R
- Use advanced filtering/pivoting
- Create custom visualizations

### Tip 7: Run After update_detector

For best results:
- Run `update_detector.ipynb` first
- Then run `change_tracker.ipynb`
- This ensures all data is current

## 🚨 Important Notes

### Read-Only Operations

The notebook only **reads** data:
- ✅ Safe to run anytime
- ✅ Won't modify database
- ✅ Won't delete anything
- ✅ Can run multiple times

### Performance Considerations

For large databases:
- **Queries may be slow** - Be patient
- **Limit row display** - Keep `DEFAULT_ROW_LIMIT` reasonable
- **Export carefully** - Large exports take time
- **Consider filters** - Use WHERE clauses if needed

### Empty Tables

If you see "No records found":
- Table exists but is empty
- May need to run `content_edit.ipynb` first
- Or `update_detector.ipynb` hasn't been run
- This is normal for new databases

### View Errors

If a VIEW query fails:
- View may not exist (check schema version)
- Underlying tables may be empty
- This is informational, not critical

## 🔧 Customization Examples

### Add Custom Query

Add a new cell after any section:

```python
print_header(\"CUSTOM QUERY\", level=2)

with sqlite3.connect(DB_PATH) as conn:
    df = pd.read_sql_query(\"\"\"\n",
        -- Your custom SQL here
        SELECT * FROM content_change_log
        WHERE change_type = 'content_edit'
        LIMIT 10
    \"\"\", conn)

    display_dataframe(df)
```

### Export Single Table

Add a cell:

```python
with sqlite3.connect(DB_PATH) as conn:
    df = pd.read_sql_query(\"SELECT * FROM your_table\", conn)
    export_to_csv(df, \"my_export.csv\")
```

### Filter Results

Modify any query:

```python
# Original
SELECT * FROM content_change_log

# Filtered
SELECT * FROM content_change_log
WHERE file_name = 'specific_file.pdf'
  AND change_type = 'content_edit'
```

### Show Specific Columns

Modify SELECT clause:

```python
# Original
SELECT * FROM content_repo

# Specific columns
SELECT raw_file_nme, raw_file_page_nbr, version_nbr
FROM content_repo
```

### Join Tables

Add custom join query:

```python
pd.read_sql_query(\"\"\"\n",
    SELECT \n",
        cr.raw_file_nme,
        cr.raw_file_page_nbr,
        ccl.change_type,
        ccl.detected_at
    FROM content_repo cr
    JOIN content_change_log ccl ON cr.ud_source_file_id = ccl.content_id
    WHERE cr.file_status = 'Active'
\"\"\", conn)
```

## 🆘 Troubleshooting

### Issue: "Database not found"

**Solution**:
```bash
# Run setup first
jupyter notebook setup_tables.ipynb
```

### Issue: "No records found" everywhere

**Solution**:
```bash
# Add test data
jupyter notebook content_edit.ipynb

# Then process changes
jupyter notebook update_detector.ipynb
```

### Issue: "VIEW not found"

**Solution**:
- Check schema version matches
- Verify `setup_tables.ipynb` completed successfully
- VIEWs are defined in schema SQL

### Issue: "Too slow"

**Solution**:
- Reduce `DEFAULT_ROW_LIMIT`
- Add WHERE clauses to filter
- Export smaller subsets
- Check database size

### Issue: Can't find exported files

**Solution**:
```python
# Check export directory
print(EXPORT_DIR.absolute())

# List exported files
import os
files = os.listdir(EXPORT_DIR)
for f in files:
    print(f)
```

## 📚 Related Documentation

- **Schema Reference**: [create_schema_v4.sql](../sql/create_schema_v4.sql)
- **Update Detector**: [UPDATE_DETECTOR_README.md](UPDATE_DETECTOR_README.md)
- **Data Analysis**: [DATA_ANALYSIS_README.md](DATA_ANALYSIS_README.md)

## 🔄 Typical Workflow

### Daily Exploration

```bash
# 1. Process any new changes
jupyter notebook update_detector.ipynb

# 2. Explore the results
jupyter notebook change_tracker.ipynb
```

### Debugging Workflow

```bash
# 1. Identify issue in data_analysis
jupyter notebook data_analysis.ipynb

# 2. Investigate raw data
jupyter notebook change_tracker.ipynb
   # Use search features to find problem records

# 3. Export for detailed analysis
   # Configure EXPORT_TABLES
   # Run export cell

# 4. Analyze exported CSVs externally
```

### Learning Workflow

```bash
# 1. Create schema
jupyter notebook setup_tables.ipynb

# 2. Add test data
jupyter notebook content_edit.ipynb

# 3. Process changes
jupyter notebook update_detector.ipynb

# 4. Explore ALL the data
jupyter notebook change_tracker.ipynb
   # Run entire notebook
   # Read descriptions
   # Examine each table

# 5. Understand patterns
jupyter notebook data_analysis.ipynb
```

## ✅ Success Criteria

After running the notebook, you should:

- ✅ See all table schemas
- ✅ View sample data from each table
- ✅ Understand what's in each VIEW
- ✅ Know how to search for records
- ✅ Be able to export data
- ✅ Have a clear picture of database contents

## 🎓 Learning Outcomes

By using this notebook, you'll learn:

1. **Database Structure** - What tables exist and their purpose
2. **Data Relationships** - How tables link together
3. **Schema Design** - Column names, types, constraints
4. **VIEWs Purpose** - What derived data is available
5. **Search Patterns** - How to find specific records
6. **Export Process** - How to get data out

## 🎉 Conclusion

The `change_tracker.ipynb` notebook is your **database explorer** - a powerful tool for:

- 👀 **Visibility** - See all your data
- 🔍 **Search** - Find specific records
- 📤 **Export** - Extract for external analysis
- 🐛 **Debug** - Investigate issues
- 📚 **Learn** - Understand the system

Use it whenever you need to **see what's actually in the database**!

**Happy Exploring! 🔍✨**
