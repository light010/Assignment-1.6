"""
Integration tests for chunk ingestion workflow.

Tests the full workflow:
1. Load content_repo data
2. Read markdown files
3. Chunk content
4. Ingest chunks into content_chunks table

This replaces the old content_checksums approach.
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path
import pandas as pd


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def temp_db_with_schema():
    """Create temporary database with content_repo and content_chunks schema."""
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.db') as f:
        db_path = f.name

    # Create schema matching actual database structure
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript("""
        -- Content repo table
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_type TEXT,
            raw_file_version_nbr INT DEFAULT 1,
            raw_file_path TEXT,
            extracted_markdown_file_path TEXT,
            title_nme TEXT,
            content_checksum TEXT,
            file_status TEXT,
            created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(raw_file_nme, raw_file_version_nbr),
            CONSTRAINT chk_content_checksum_length CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64),
            CONSTRAINT chk_file_status CHECK (file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived'))
        );

        -- Content chunks table
        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ud_source_file_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            chunk_page_number INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
                ON DELETE CASCADE,
            UNIQUE(ud_source_file_id, content_checksum),
            CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
            CONSTRAINT chk_chunk_status CHECK (status IN ('active', 'archived', 'deleted'))
        );

        CREATE INDEX IF NOT EXISTS idx_chunks_checksum
            ON content_chunks(content_checksum);

        CREATE INDEX IF NOT EXISTS idx_chunks_source_file
            ON content_chunks(ud_source_file_id);
    """)
    conn.commit()
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def sample_content_repo_data(temp_db_with_schema):
    """Insert sample content_repo data."""
    conn = sqlite3.connect(temp_db_with_schema)
    conn.execute("PRAGMA foreign_keys = ON")

    cursor = conn.execute("""
        INSERT INTO content_repo
        (raw_file_nme, raw_file_type, title_nme, extracted_markdown_file_path, file_status)
        VALUES (?, ?, ?, ?, ?)
    """, ('Benefits_Guide.pdf', 'pdf', 'Employee Benefits Overview',
          'data/markdown/Benefits_Guide_v1.md', 'Active'))

    file_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return file_id


# ============================================================================
# Test ChunkIngestion Class
# ============================================================================

class TestChunkIngestion:
    """Test the ChunkIngestion class."""

    def test_class_exists(self):
        """Test that ChunkIngestion can be imported."""
        from granular_impact.data_ingestion import ChunkIngestion
        assert ChunkIngestion is not None

    def test_init(self, temp_db_with_schema):
        """Test initialization with database path."""
        from granular_impact.data_ingestion import ChunkIngestion

        ingestion = ChunkIngestion(temp_db_with_schema)
        assert ingestion.db_path == temp_db_with_schema

    def test_ingest_chunks_for_file(self, temp_db_with_schema, sample_content_repo_data):
        """Test ingesting chunks for a specific file."""
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        file_id = sample_content_repo_data
        content = "Sample content for chunking. This is a test."

        # Chunk the content
        chunker = SimpleChunker(chunk_size=20)
        chunks_with_checksums = chunker.chunk_with_checksums(content)

        # Ingest chunks
        ingestion = ChunkIngestion(temp_db_with_schema)
        result = ingestion.ingest_chunks_for_file(
            ud_source_file_id=file_id,
            chunks_with_checksums=chunks_with_checksums
        )

        assert result['success'] is True
        assert result['rows_inserted'] == len(chunks_with_checksums)

    def test_foreign_key_validation(self, temp_db_with_schema):
        """Test that invalid file_id is rejected."""
        from granular_impact.data_ingestion import ChunkIngestion

        invalid_file_id = 9999
        chunks = [("Sample text", "a" * 64)]

        ingestion = ChunkIngestion(temp_db_with_schema)
        result = ingestion.ingest_chunks_for_file(
            ud_source_file_id=invalid_file_id,
            chunks_with_checksums=chunks
        )

        assert result['success'] is False
        assert 'foreign key' in result['message'].lower() or 'file not found' in result['message'].lower()

    def test_duplicate_checksum_per_file(self, temp_db_with_schema, sample_content_repo_data):
        """Test that duplicate checksums within same file are prevented."""
        from granular_impact.data_ingestion import ChunkIngestion

        file_id = sample_content_repo_data
        duplicate_chunks = [
            ("Same content", "a" * 64),
            ("Same content", "a" * 64),  # Duplicate checksum
        ]

        ingestion = ChunkIngestion(temp_db_with_schema)
        result = ingestion.ingest_chunks_for_file(
            ud_source_file_id=file_id,
            chunks_with_checksums=duplicate_chunks
        )

        assert result['success'] is False
        assert 'unique' in result['message'].lower() or 'duplicate' in result['message'].lower()

    def test_get_chunks_for_file(self, temp_db_with_schema, sample_content_repo_data):
        """Test retrieving chunks for a file."""
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        file_id = sample_content_repo_data
        content = "Content to chunk and retrieve."

        chunker = SimpleChunker(chunk_size=15)
        chunks_with_checksums = chunker.chunk_with_checksums(content)

        # Ingest
        ingestion = ChunkIngestion(temp_db_with_schema)
        ingestion.ingest_chunks_for_file(file_id, chunks_with_checksums)

        # Retrieve
        chunks = ingestion.get_chunks_for_file(file_id)

        assert len(chunks) == len(chunks_with_checksums)
        assert all('chunk_id' in chunk for chunk in chunks)
        assert all('content_checksum' in chunk for chunk in chunks)

    def test_clear_existing_chunks(self, temp_db_with_schema, sample_content_repo_data):
        """Test clearing existing chunks before re-ingestion."""
        from granular_impact.data_ingestion import ChunkIngestion

        file_id = sample_content_repo_data
        initial_chunks = [("Initial content", "a" * 64)]
        new_chunks = [("New content", "b" * 64)]

        ingestion = ChunkIngestion(temp_db_with_schema)

        # First ingestion
        ingestion.ingest_chunks_for_file(file_id, initial_chunks)
        chunks_before = ingestion.get_chunks_for_file(file_id)
        assert len(chunks_before) == 1

        # Re-ingest with clear_existing=True
        ingestion.ingest_chunks_for_file(file_id, new_chunks, clear_existing=True)
        chunks_after = ingestion.get_chunks_for_file(file_id)

        assert len(chunks_after) == 1
        assert chunks_after[0]['content_checksum'] == "b" * 64

    def test_get_stats(self, temp_db_with_schema, sample_content_repo_data):
        """Test getting statistics about chunks."""
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        file_id = sample_content_repo_data
        content = "Sample content for statistics."

        chunker = SimpleChunker(chunk_size=15)
        chunks_with_checksums = chunker.chunk_with_checksums(content)

        ingestion = ChunkIngestion(temp_db_with_schema)
        ingestion.ingest_chunks_for_file(file_id, chunks_with_checksums)

        stats = ingestion.get_stats()

        assert stats['total_chunks'] == len(chunks_with_checksums)
        assert stats['active_chunks'] == len(chunks_with_checksums)
        assert stats['files_with_chunks'] == 1


# ============================================================================
# Integration Test: Full Workflow
# ============================================================================

class TestChunkIngestionWorkflow:
    """Integration test for complete chunking workflow."""

    def test_full_notebook_workflow(self, temp_db_with_schema):
        """
        Test complete workflow from notebook:
        1. Load content_repo data
        2. Read markdown content (simulated)
        3. Chunk content
        4. Ingest into content_chunks table
        """
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        # Step 1: Create content_repo entries
        conn = sqlite3.connect(temp_db_with_schema)
        conn.execute("PRAGMA foreign_keys = ON")

        content_repo_data = [
            ('Employee_Handbook.pdf', 'pdf', 'Employee Handbook 2024', 'data/handbook_v1.md', 'Active'),
            ('Benefits_Guide.pdf', 'pdf', 'Benefits Overview', 'data/benefits_v1.md', 'Active'),
        ]

        file_ids = []
        for data in content_repo_data:
            cursor = conn.execute("""
                INSERT INTO content_repo
                (raw_file_nme, raw_file_type, title_nme, extracted_markdown_file_path, file_status)
                VALUES (?, ?, ?, ?, ?)
            """, data)
            file_ids.append(cursor.lastrowid)

        conn.commit()
        conn.close()

        # Step 2: Simulate markdown content for each file
        markdown_contents = [
            "# Employee Handbook\n\n## Vacation Policy\nEmployees get 10 days vacation.",
            "# Benefits Guide\n\n## Health Insurance\nWe offer comprehensive health coverage.",
        ]

        # Step 3 & 4: Chunk and ingest
        chunker = SimpleChunker(chunk_size=50)
        ingestion = ChunkIngestion(temp_db_with_schema)

        total_chunks_inserted = 0
        for file_id, content in zip(file_ids, markdown_contents):
            chunks_with_checksums = chunker.chunk_with_checksums(content)
            result = ingestion.ingest_chunks_for_file(file_id, chunks_with_checksums)

            assert result['success'] is True
            total_chunks_inserted += result['rows_inserted']

        # Verify final state
        stats = ingestion.get_stats()
        assert stats['total_chunks'] == total_chunks_inserted
        assert stats['files_with_chunks'] == 2

    def test_chunk_index_ordering(self, temp_db_with_schema, sample_content_repo_data):
        """Test that chunks maintain correct order via chunk_index."""
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        file_id = sample_content_repo_data
        content = "AAAA" * 30  # Will create multiple chunks

        chunker = SimpleChunker(chunk_size=20)
        chunks_with_checksums = chunker.chunk_with_checksums(content)

        ingestion = ChunkIngestion(temp_db_with_schema)
        ingestion.ingest_chunks_for_file(file_id, chunks_with_checksums)

        # Retrieve and verify order
        chunks = ingestion.get_chunks_for_file(file_id)

        # Verify chunk_index is sequential
        for i, chunk in enumerate(chunks):
            assert chunk['chunk_index'] == i

    def test_reconstruction_from_chunks(self, temp_db_with_schema, sample_content_repo_data):
        """Test that chunks can reconstruct original content."""
        from granular_impact.data_ingestion import ChunkIngestion
        from granular_impact.chunking import SimpleChunker

        file_id = sample_content_repo_data
        original_content = "The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs."

        chunker = SimpleChunker(chunk_size=25)
        chunks_with_checksums = chunker.chunk_with_checksums(original_content)

        ingestion = ChunkIngestion(temp_db_with_schema)
        ingestion.ingest_chunks_for_file(file_id, chunks_with_checksums)

        # Retrieve chunks
        chunks = ingestion.get_chunks_for_file(file_id)

        # Reconstruct content
        reconstructed = "".join([chunk['chunk_text'] for chunk in chunks])

        assert reconstructed == original_content
