"""
Test Notebook Integration

Simulates the workflow from 2_faq_generation_ingestion.ipynb to verify
that mock CSV data loads correctly and can be ingested into the database.
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "granular_impact"))

from faq_generation import QuestionGenerator, QuestionGeneratorConfig, DocumentLoader
from data_ingestion import FAQIngestion, FAQSourceIngestion


class TestNotebookWorkflow:
    """Test the complete notebook workflow with mock data."""

    def test_complete_notebook_workflow_with_mock_data(self):
        """
        Simulate the complete workflow from 2_faq_generation_ingestion.ipynb.

        This test verifies:
        1. QuestionGenerator loads CSV in mock mode
        2. DataFrames can be ingested into database
        3. Data is queryable after ingestion
        """
        # Create temporary database
        temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        db_path = temp_db.name
        temp_db.close()

        try:
            # Setup database schema
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            # Create faq_questions table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_questions (
                    question_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_text TEXT NOT NULL,
                    source_type TEXT,
                    generation_method TEXT,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_question_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'))
                )
            """)

            # Create faq_question_sources table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_question_sources (
                    source_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_id INTEGER NOT NULL,
                    content_checksum TEXT NOT NULL,
                    is_primary_source BOOLEAN DEFAULT FALSE,
                    contribution_weight DOUBLE,
                    is_valid BOOLEAN NOT NULL DEFAULT TRUE,
                    valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    valid_until TEXT,
                    invalidation_reason TEXT,
                    invalidated_by_change_id INTEGER,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_qsrc_contribution CHECK (
                        contribution_weight IS NULL OR
                        (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
                    )
                )
            """)
            conn.commit()
            conn.close()

            # WORKFLOW 1: Question Generation (from notebook)
            print("=" * 80)
            print("  SIMULATING NOTEBOOK WORKFLOW")
            print("=" * 80)

            # Step 1: Configure for mock mode
            config = QuestionGeneratorConfig(use_mock=True)
            question_generator = QuestionGenerator(config)

            # Step 2: Generate questions (loads from CSV in mock mode)
            # Note: documents parameter is ignored in mock mode, but required
            from faq_generation import Document
            mock_documents = [
                Document(
                    page_content="dummy",
                    metadata={"checksum": "abc", "title": "Test"}
                )
            ]

            df_questions, df_sources = question_generator.generate_and_map(
                documents=mock_documents,
                deduplicate=False
            )

            # Verify DataFrames have data
            assert len(df_questions) > 0, "Should have questions from CSV"
            assert len(df_sources) > 0, "Should have sources from CSV"

            print(f"\n✓ Loaded {len(df_questions)} questions from CSV")
            print(f"✓ Loaded {len(df_sources)} sources from CSV")

            # Step 3: Ingest into database
            faq_ingestion = FAQIngestion(db_path)
            source_ingestion = FAQSourceIngestion(db_path)

            # Ingest questions
            result = faq_ingestion.ingest_questions_from_dataframe(df_questions)
            assert result['success'], f"Question ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} questions")

            # Ingest question sources
            result = source_ingestion.ingest_question_sources_from_dataframe(df_sources)
            assert result['success'], f"Source ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} question sources")

            # Step 4: Verify data in database
            conn = sqlite3.connect(db_path)

            # Query questions
            questions_count = conn.execute("SELECT COUNT(*) FROM faq_questions").fetchone()[0]
            assert questions_count > 0, "No questions in database"
            print(f"\n✓ Verified {questions_count} questions in database")

            # Query sources
            sources_count = conn.execute("SELECT COUNT(*) FROM faq_question_sources").fetchone()[0]
            assert sources_count > 0, "No sources in database"
            print(f"✓ Verified {sources_count} sources in database")

            # Verify checksums are 64 characters (SHA-256)
            checksums = conn.execute("SELECT DISTINCT content_checksum FROM faq_question_sources").fetchall()
            for (checksum,) in checksums:
                assert len(checksum) == 64, f"Invalid checksum length: {len(checksum)}"
            print(f"✓ Verified all checksums are valid SHA-256")

            # Verify status values
            statuses = conn.execute("SELECT DISTINCT status FROM faq_questions").fetchall()
            valid_statuses = ["active", "invalidated", "archived", "deleted"]
            for (status,) in statuses:
                assert status in valid_statuses, f"Invalid status: {status}"
            print(f"✓ Verified all status values are valid")

            conn.close()

            print("\n" + "=" * 80)
            print("  NOTEBOOK WORKFLOW SIMULATION COMPLETE")
            print("=" * 80)

        finally:
            # Cleanup
            Path(db_path).unlink(missing_ok=True)
