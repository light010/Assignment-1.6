"""
Test Answer Generator Mock Data Loading

Tests for loading mock FAQ answers from CSV files when use_mock=True.

Test Strategy (TDD):
1. Test CSV file loading functionality
2. Test data conversion to DataFrames matching database schema
3. Test integration with question pipeline
4. Test error handling for missing CSV files
"""

import pytest
import pandas as pd
from pathlib import Path
import sys

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "granular_impact"))

from faq_generation import (
    AnswerGenerator,
    AnswerGeneratorConfig,
    QuestionGenerator,
    QuestionGeneratorConfig,
    Question,
    Document,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def data_folder():
    """Path to data folder with sample CSV files."""
    return Path(__file__).parent.parent / "granular_impact" / "data_ingestion" / "data"


@pytest.fixture
def sample_answer_csv(data_folder):
    """Path to sample_faq_answers.csv."""
    return data_folder / "sample_faq_answers.csv"


@pytest.fixture
def sample_answer_sources_csv(data_folder):
    """Path to sample_faq_answer_sources.csv."""
    return data_folder / "sample_faq_answer_sources.csv"


@pytest.fixture
def mock_questions():
    """Mock questions for testing."""
    return [
        Question(
            question_text="How many sick days are employees entitled to per year?",
            source_checksum="b54c22ec37e28c72f242c5c96ba13a0d582cf14ad4bba7b39f24466911546ca1",
            question_id=1
        ),
        Question(
            question_text="What are the standard work hours?",
            source_checksum="b54c22ec37e28c72f242c5c96ba13a0d582cf14ad4bba7b39f24466911546ca1",
            question_id=2
        ),
    ]


@pytest.fixture
def mock_documents():
    """Mock documents for testing."""
    return [
        Document(
            page_content="Sample content 1",
            metadata={
                "checksum": "b54c22ec37e28c72f242c5c96ba13a0d582cf14ad4bba7b39f24466911546ca1",
                "title": "Test Doc 1",
                "source_file": "test1.pdf",
            }
        ),
    ]


# ============================================================================
# Test CSV File Loading
# ============================================================================

class TestMockAnswerDataLoading:
    """Test loading mock answer data from CSV files."""

    def test_sample_answer_csv_files_exist(self, sample_answer_csv, sample_answer_sources_csv):
        """Test that sample answer CSV files exist in data folder."""
        assert sample_answer_csv.exists(), f"Missing {sample_answer_csv}"
        assert sample_answer_sources_csv.exists(), f"Missing {sample_answer_sources_csv}"

    def test_sample_answer_csv_files_have_correct_columns(self, sample_answer_csv, sample_answer_sources_csv):
        """Test that CSV files have required columns matching database schema."""
        # Load CSVs
        df_answers = pd.read_csv(sample_answer_csv)
        df_sources = pd.read_csv(sample_answer_sources_csv)

        # Check faq_answers columns
        required_a_cols = ["answer_id", "question_id", "answer_text", "answer_format", "confidence_score", "status"]
        for col in required_a_cols:
            assert col in df_answers.columns, f"Missing column: {col}"

        # Check faq_answer_sources columns
        required_s_cols = ["source_id", "answer_id", "content_checksum", "is_primary_source", "contribution_weight", "is_valid"]
        for col in required_s_cols:
            assert col in df_sources.columns, f"Missing column: {col}"

    def test_mock_mode_loads_csv_instead_of_generating_answers(self, mock_questions, mock_documents):
        """Test that use_mock=True loads CSV data instead of generating answers."""
        # Configure for mock mode
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        # Generate and map (should load from CSV)
        df_answers, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        # Verify DataFrames are returned
        assert isinstance(df_answers, pd.DataFrame)
        assert isinstance(df_sources, pd.DataFrame)

        # Verify they have data
        assert len(df_answers) > 0, "Should load answers from CSV"
        assert len(df_sources) > 0, "Should load sources from CSV"

    def test_mock_mode_returns_correct_answer_schema(self, mock_questions, mock_documents):
        """Test that loaded CSV data matches expected database schema."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        # Check faq_answers schema
        assert "question_id" in df_answers.columns
        assert "answer_text" in df_answers.columns
        assert "answer_format" in df_answers.columns
        assert "confidence_score" in df_answers.columns
        assert "status" in df_answers.columns

        # Check faq_answer_sources schema
        assert "answer_id" in df_sources.columns
        assert "content_checksum" in df_sources.columns
        assert "is_primary_source" in df_sources.columns
        assert "contribution_weight" in df_sources.columns
        assert "is_valid" in df_sources.columns

    def test_mock_mode_answer_checksums_are_64_char_sha256(self, mock_questions, mock_documents):
        """Test that checksums in sources are valid SHA-256 (64 hex characters)."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        _, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        # Verify all checksums are 64 characters (SHA-256)
        for checksum in df_sources["content_checksum"]:
            assert len(checksum) == 64, f"Invalid checksum length: {len(checksum)}"
            # Verify it's hexadecimal
            int(checksum, 16)  # Should not raise ValueError

    def test_mock_mode_answer_status_values_are_valid(self, mock_questions, mock_documents):
        """Test that status values match database constraints."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, _ = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        valid_statuses = ["active", "invalidated", "archived", "deleted"]
        for status in df_answers["status"]:
            assert status in valid_statuses, f"Invalid status: {status}"

    def test_mock_mode_answer_format_values_are_valid(self, mock_questions, mock_documents):
        """Test that answer_format values match database constraints."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, _ = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        valid_formats = ["html", "markdown", "plain"]
        for fmt in df_answers["answer_format"]:
            assert fmt in valid_formats, f"Invalid format: {fmt}"

    def test_mock_mode_confidence_scores_valid(self, mock_questions, mock_documents):
        """Test that confidence scores are between 0.0 and 1.0."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, _ = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        for score in df_answers["confidence_score"]:
            if pd.notna(score):  # NULL is allowed
                assert 0.0 <= score <= 1.0, f"Invalid confidence score: {score}"

    def test_mock_mode_answer_contribution_weights_valid(self, mock_questions, mock_documents):
        """Test that contribution weights are between 0.0 and 1.0."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        _, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        for weight in df_sources["contribution_weight"]:
            if pd.notna(weight):  # NULL is allowed
                assert 0.0 <= weight <= 1.0, f"Invalid weight: {weight}"


# ============================================================================
# Test Integration with Question Pipeline
# ============================================================================

class TestCompleteQuestionAnswerPipeline:
    """Test that questions and answers work together."""

    def test_complete_pipeline_questions_then_answers(self, mock_documents):
        """Test complete pipeline: Generate questions, then answers."""
        # Step 1: Generate questions
        q_config = QuestionGeneratorConfig(use_mock=True)
        q_gen = QuestionGenerator(q_config)
        df_questions, df_q_sources = q_gen.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Step 2: Generate answers (using loaded questions)
        a_config = AnswerGeneratorConfig(use_mock=True)
        a_gen = AnswerGenerator(a_config)
        a_gen.load_context_documents(mock_documents)

        # Convert questions DataFrame to Question objects
        questions = []
        for i, row in df_questions.iterrows():
            q_source = df_q_sources[df_q_sources['question_id'] == i + 1]
            source_checksum = q_source['content_checksum'].iloc[0] if len(q_source) > 0 else ''

            q = Question(
                question_text=row['question_text'],
                source_checksum=source_checksum,
                question_id=i + 1
            )
            questions.append(q)

        df_answers, df_a_sources = a_gen.generate_and_map(
            questions=questions,
            retrieve_context=False
        )

        # Verify results
        assert len(df_questions) > 0
        assert len(df_answers) > 0
        assert len(df_q_sources) > 0
        assert len(df_a_sources) > 0

        print(f"\n✓ Generated {len(df_questions)} questions")
        print(f"✓ Generated {len(df_answers)} answers")

    def test_dataframes_ready_for_ingestion(self, mock_questions, mock_documents):
        """Test that returned DataFrames are ready for database ingestion."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        # Verify answers DataFrame structure
        assert len(df_answers) > 0
        assert "answer_text" in df_answers.columns
        assert all(isinstance(a, str) for a in df_answers["answer_text"])
        assert all(len(a) > 0 for a in df_answers["answer_text"])

        # Verify sources DataFrame structure
        assert len(df_sources) > 0
        assert "content_checksum" in df_sources.columns
        assert all(isinstance(c, str) for c in df_sources["content_checksum"])

    def test_answer_ids_match_between_tables(self, mock_questions, mock_documents):
        """Test that answer_id references are consistent."""
        config = AnswerGeneratorConfig(use_mock=True)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        df_answers, df_sources = generator.generate_and_map(
            questions=mock_questions,
            retrieve_context=False
        )

        # Note: In the CSV, answer_ids are pre-assigned
        # Verify all source answer_ids exist (would be in answers after ingestion)
        assert len(df_sources) > 0
        assert "answer_id" in df_sources.columns


# ============================================================================
# Test Error Handling
# ============================================================================

class TestAnswerErrorHandling:
    """Test error handling for missing files or invalid data."""

    def test_missing_csv_files_handled_gracefully(self, tmp_path, monkeypatch, mock_questions):
        """Test that missing CSV files don't crash the generator."""
        # This will be tested after implementation
        pass


# ============================================================================
# Test Backward Compatibility
# ============================================================================

class TestAnswerBackwardCompatibility:
    """Test interaction with existing generation logic."""

    def test_non_mock_mode_still_works(self, mock_questions, mock_documents):
        """Test that use_mock=False still uses original generation logic."""
        config = AnswerGeneratorConfig(use_mock=False)
        generator = AnswerGenerator(config)
        generator.load_context_documents(mock_documents)

        # This should raise NotImplementedError (original behavior)
        with pytest.raises(NotImplementedError):
            generator.generate_and_map(questions=mock_questions)
