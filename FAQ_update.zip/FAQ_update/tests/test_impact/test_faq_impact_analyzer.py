"""
Test suite for FaqImpactAnalyzer - FAQ-specific impact analysis.

TDD approach: Tests written first, implementation follows.

This module tests the separation of FAQ impact analysis from core similarity.
FaqImpactAnalyzer wraps similarity calculators and provides database integration.
"""

import pytest
from granular_impact.similarity import JaccardSimilarityCalculator
from granular_impact.similarity.base import SimilarityResult
from granular_impact.impact.faq_impact_analyzer import FaqImpactAnalyzer
from tests.fixtures.similarity_fixtures import V8_NUMERIC_CHANGE, IDENTICAL_TEXT


class TestFaqImpactAnalyzerInitialization:
    """Test FaqImpactAnalyzer initialization and configuration."""

    def test_analyzer_initialization_with_defaults(self):
        """Test analyzer initializes with default thresholds."""
        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        assert analyzer.calculator is not None
        assert analyzer.thresholds is not None
        assert 'critical' in analyzer.thresholds
        assert 'high' in analyzer.thresholds
        assert 'medium' in analyzer.thresholds
        assert 'low' in analyzer.thresholds

    def test_analyzer_initialization_with_custom_thresholds(self):
        """Test analyzer accepts custom impact thresholds."""
        

        calc = JaccardSimilarityCalculator()
        custom_thresholds = {
            'critical': 0.9,
            'high': 0.7,
            'medium': 0.5,
            'low': 0.3
        }

        analyzer = FaqImpactAnalyzer(calc, impact_thresholds=custom_thresholds)

        assert analyzer.thresholds['critical'] == 0.9
        assert analyzer.thresholds['high'] == 0.7
        assert analyzer.thresholds['medium'] == 0.5
        assert analyzer.thresholds['low'] == 0.3

    def test_analyzer_validates_threshold_ranges(self):
        """Test analyzer validates thresholds are between 0 and 1."""
        

        calc = JaccardSimilarityCalculator()
        invalid_thresholds = {
            'critical': 1.5,  # Invalid: > 1.0
            'high': 0.6,
            'medium': 0.4,
            'low': 0.2
        }

        with pytest.raises(ValueError, match="Threshold.*must be between 0.0 and 1.0"):
            FaqImpactAnalyzer(calc, impact_thresholds=invalid_thresholds)


class TestImpactLevelComputation:
    """Test impact level computation from dissimilarity scores."""

    def test_compute_impact_level_critical(self):
        """Test CRITICAL impact level for high dissimilarity."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        # Dissimilarity 0.85 should be CRITICAL
        impact_level = analyzer.compute_impact_level(0.85)

        assert impact_level == "HIGH"  # ImpactLevel.HIGH

    def test_compute_impact_level_medium(self):
        """Test MEDIUM impact level for moderate dissimilarity."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        # Dissimilarity 0.45 should be MEDIUM
        impact_level = analyzer.compute_impact_level(0.45)

        assert impact_level == "MEDIUM"

    def test_compute_impact_level_none(self):
        """Test NONE impact level for minimal dissimilarity."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        # Dissimilarity 0.05 should be NONE
        impact_level = analyzer.compute_impact_level(0.05)

        assert impact_level == "NONE"


class TestFaqImpactAnalysisConversion:
    """Test conversion of similarity results to FAQImpactAnalysis objects."""

    def test_to_faq_impact_analysis_basic(self):
        """Test basic conversion of similarity result to impact analysis."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        # Convert to FAQImpactAnalysis
        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        assert impact is not None
        assert impact.change_id == 1
        assert impact.question_id == 100
        assert 0.0 <= impact.overall_impact_score <= 1.0

    def test_impact_analysis_uses_dissimilarity(self):
        """Test that impact analysis uses dissimilarity (1 - similarity)."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = IDENTICAL_TEXT
        result = calc.compute_similarity(text1, text2)

        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        # Identical text: similarity=1.0, dissimilarity=0.0
        assert impact.overall_impact_score == pytest.approx(0.0, abs=0.01)
        assert impact.is_affected is False

    def test_impact_analysis_threshold_logic(self):
        """Test is_affected flag based on threshold."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        # With low threshold (0.1), should be affected
        impact_low = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.1
        )

        # With high threshold (0.9), should NOT be affected
        impact_high = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.9
        )

        assert impact_low.is_affected is True
        assert impact_high.is_affected is False

    def test_impact_analysis_includes_metadata(self):
        """Test that impact analysis preserves similarity metadata."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        assert impact.metadata is not None
        assert isinstance(impact.metadata, dict)


class TestBatchFaqImpactAnalysis:
    """Test batch conversion of similarity results."""

    def test_batch_to_faq_impact_analysis(self):
        """Test batch conversion of similarity results to impact analyses."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text_pairs = [V8_NUMERIC_CHANGE, IDENTICAL_TEXT]
        batch_result = calc.compute_batch_similarity(text_pairs)

        question_ids = [100, 101]
        impacts = analyzer.batch_to_faq_impact_analysis(
            batch_result=batch_result,
            change_id=1,
            question_ids=question_ids,
            threshold=0.3
        )

        assert len(impacts) == 2
        assert impacts[0].question_id == 100
        assert impacts[1].question_id == 101

    def test_batch_impact_length_mismatch_raises_error(self):
        """Test that mismatched question_ids length raises error."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text_pairs = [V8_NUMERIC_CHANGE, IDENTICAL_TEXT]
        batch_result = calc.compute_batch_similarity(text_pairs)

        question_ids = [100]  # Wrong length

        with pytest.raises(ValueError, match="question_ids length.*must match"):
            analyzer.batch_to_faq_impact_analysis(
                batch_result=batch_result,
                change_id=1,
                question_ids=question_ids,
                threshold=0.3
            )

    def test_batch_impact_filtering_by_affected(self):
        """Test filtering batch results by is_affected flag."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text_pairs = [V8_NUMERIC_CHANGE, IDENTICAL_TEXT]
        batch_result = calc.compute_batch_similarity(text_pairs)

        question_ids = [100, 101]
        impacts = analyzer.batch_to_faq_impact_analysis(
            batch_result=batch_result,
            change_id=1,
            question_ids=question_ids,
            threshold=0.3
        )

        # Filter only affected FAQs
        affected = [imp for imp in impacts if imp.is_affected]

        assert len(affected) >= 1  # At least the numeric change should be affected


class TestDatabaseCompatibility:
    """Test database compatibility and schema alignment."""

    def test_impact_analysis_to_dict_for_database(self):
        """Test that impact analysis converts to dict for database insertion."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        # Should have to_dict() method for database
        impact_dict = impact.to_dict()

        assert isinstance(impact_dict, dict)
        assert 'change_id' in impact_dict
        assert 'question_id' in impact_dict
        assert 'overall_impact_score' in impact_dict
        assert 'is_affected' in impact_dict

    def test_jaccard_uses_lexical_overlap_score(self):
        """Test that Jaccard results populate lexical_overlap_score field."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        # Jaccard should populate lexical_overlap_score
        assert impact.lexical_overlap_score is not None
        assert 0.0 <= impact.lexical_overlap_score <= 1.0


class TestAlgorithmMapping:
    """Test mapping of similarity algorithms to analysis methods."""

    def test_jaccard_maps_to_lexical_overlap_method(self):
        """Test that Jaccard algorithm maps to LEXICAL_OVERLAP analysis method."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        impact = analyzer.to_faq_impact_analysis(
            similarity_result=result,
            change_id=1,
            question_id=100,
            threshold=0.3
        )

        # Should map to LEXICAL_OVERLAP or RULE_BASED
        assert impact.analysis_method is not None


class TestConfigurableThresholds:
    """Test that thresholds are configurable and respected."""

    def test_custom_thresholds_affect_impact_level(self):
        """Test that custom thresholds change impact level classification."""
        

        calc = JaccardSimilarityCalculator()

        # Strict thresholds
        strict_analyzer = FaqImpactAnalyzer(calc, impact_thresholds={
            'critical': 0.9,
            'high': 0.7,
            'medium': 0.5,
            'low': 0.3
        })

        # Lenient thresholds
        lenient_analyzer = FaqImpactAnalyzer(calc, impact_thresholds={
            'critical': 0.6,
            'high': 0.4,
            'medium': 0.2,
            'low': 0.1
        })

        # Same dissimilarity score (0.5)
        strict_level = strict_analyzer.compute_impact_level(0.5)
        lenient_level = lenient_analyzer.compute_impact_level(0.5)

        # Should classify differently
        assert strict_level != lenient_level or strict_level == "MEDIUM"


class TestValidationAndErrorHandling:
    """Test validation and error handling."""

    def test_analyzer_validates_similarity_result_schema(self):
        """Test that analyzer validates similarity result before conversion."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        # Invalid result (missing required fields)
        invalid_result = SimilarityResult(
            score=0.5,
            text1="test",
            text2="test2",
            algorithm="test",
            metadata={},
            processing_time_ms=1.0
        )

        # Should validate successfully (has all required fields)
        is_valid = analyzer.validate_similarity_result(invalid_result)
        assert is_valid is True

    def test_threshold_parameter_validation(self):
        """Test that threshold parameter is validated."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text1, text2 = V8_NUMERIC_CHANGE
        result = calc.compute_similarity(text1, text2)

        # Invalid threshold (> 1.0)
        with pytest.raises(ValueError, match="threshold must be between 0.0 and 1.0"):
            analyzer.to_faq_impact_analysis(
                similarity_result=result,
                change_id=1,
                question_id=100,
                threshold=1.5
            )


class TestPerformanceMetrics:
    """Test performance tracking for FAQ impact analysis."""

    def test_batch_performance_statistics(self):
        """Test that batch processing tracks performance metrics."""
        

        calc = JaccardSimilarityCalculator()
        analyzer = FaqImpactAnalyzer(calc)

        text_pairs = [V8_NUMERIC_CHANGE, IDENTICAL_TEXT] * 5
        batch_result = calc.compute_batch_similarity(text_pairs)

        question_ids = list(range(100, 110))
        impacts = analyzer.batch_to_faq_impact_analysis(
            batch_result=batch_result,
            change_id=1,
            question_ids=question_ids,
            threshold=0.3
        )

        # Should complete efficiently
        assert len(impacts) == 10