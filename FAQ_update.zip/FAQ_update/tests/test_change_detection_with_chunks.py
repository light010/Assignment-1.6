"""
Tests for 4_change_detection.ipynb workflow using content_chunks table.

This module tests the complete change detection workflow with the NEW architecture:
1. Load modified content from content_repo (v2 files)
2. Chunk and ingest into content_chunks table with FK to content_repo
3. Load baseline chunks from content_chunks (v1 files)
4. Detect changes by comparing v1 vs v2 chunks
5. Store results in content_change_log

Uses in-memory SQLite database for isolation.

Key Changes from test_change_detection_notebook.py:
- Uses content_chunks table (NOT content_checksums)
- Uses ChunkIngestion (NOT ChecksumIngestion)
- Properly handles FK relationships via ud_source_file_id
- Compares versions using content_repo.raw_file_version_nbr
"""

import sqlite3
import tempfile
from pathlib import Path
from datetime import datetime, timedelta
import pytest
import pandas as pd

from granular_impact.chunking import SimpleChunker
from granular_impact.data_ingestion import ChunkIngestion
from granular_impact.detection.checksum_extractor import ChecksumExtractor
from granular_impact.detection.content_change_detector import ContentChangeDetector
from granular_impact.detection.database_queries import ChangeDetectionQueries
from granular_impact.database.models import ChangeType
from granular_impact.database.adapters import create_adapter
from granular_impact.database.dialect import DatabaseDialect
from granular_impact.database.schema_manager import SchemaManager


@pytest.fixture
def temp_db_path():
    """Create temporary database file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.db', delete=False) as f:
        temp_path = Path(f.name)
    yield temp_path
    # Cleanup (Windows-safe)
    try:
        if temp_path.exists():
            temp_path.unlink()
    except PermissionError:
        pass  # File still in use on Windows, will be cleaned by OS


@pytest.fixture
def db_with_schema(temp_db_path):
    """Create database with schema."""
    adapter = create_adapter(DatabaseDialect.SQLITE, database_path=str(temp_db_path))
    manager = SchemaManager(adapter=adapter)
    manager.create_schema()
    return temp_db_path


@pytest.fixture
def db_with_sample_data(db_with_schema, tmp_path):
    """
    Create database with sample content using content_chunks table.

    Setup:
    - Version 1: "10 sick days per year"
    - Version 2: "12 sick days per year" (MODIFIED)
    - Version 2: New benefits content (NEW)
    """
    # Create sample markdown files
    md_dir = tmp_path / "markdown"
    md_dir.mkdir()

    content_v1 = "# Employee Policy\n\nEmployees are entitled to 10 sick days per calendar year."
    content_v2 = "# Employee Policy\n\nEmployees are entitled to 12 sick days per calendar year."
    content_v3 = "# Benefits\n\nFull-time employees receive comprehensive health insurance coverage."

    (md_dir / "handbook_v1.md").write_text(content_v1)
    (md_dir / "handbook_v2.md").write_text(content_v2)
    (md_dir / "benefits_v2.md").write_text(content_v3)

    # Insert into content_repo
    base_time = datetime.now() - timedelta(days=10)
    recent_time = datetime.now() - timedelta(hours=1)

    with sqlite3.connect(db_with_schema) as conn:
        conn.execute("PRAGMA foreign_keys = ON")

        # Version 1 content (baseline)
        cursor = conn.execute("""
            INSERT INTO content_repo (
                raw_file_nme, raw_file_type, raw_file_version_nbr,
                extracted_markdown_file_path, title_nme,
                file_status, created_dt, last_modified_dt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'handbook.pdf', 'pdf', 1,
            str(md_dir / "handbook_v1.md"), 'Employee Policy v1',
            'Active', base_time.isoformat(), base_time.isoformat()
        ))
        v1_file_id = cursor.lastrowid

        # Version 2 content (modified)
        cursor = conn.execute("""
            INSERT INTO content_repo (
                raw_file_nme, raw_file_type, raw_file_version_nbr,
                extracted_markdown_file_path, title_nme,
                file_status, created_dt, last_modified_dt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'handbook.pdf', 'pdf', 2,
            str(md_dir / "handbook_v2.md"), 'Employee Policy v2',
            'Active', recent_time.isoformat(), recent_time.isoformat()
        ))
        v2_file_id = cursor.lastrowid

        # New file (separate document added in v2 timeframe)
        cursor = conn.execute("""
            INSERT INTO content_repo (
                raw_file_nme, raw_file_type, raw_file_version_nbr,
                extracted_markdown_file_path, title_nme,
                file_status, created_dt, last_modified_dt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'benefits.pdf', 'pdf', 1,  # New file, so version 1
            str(md_dir / "benefits_v2.md"), 'Benefits',
            'Active', recent_time.isoformat(), recent_time.isoformat()
        ))
        v2_new_file_id = cursor.lastrowid

        conn.commit()

    return db_with_schema, v1_file_id, v2_file_id, v2_new_file_id, md_dir, base_time


class TestChangeDetectionWithChunks:
    """Test complete change detection workflow using content_chunks table."""

    def test_step1_load_modified_content_from_repo(self, db_with_sample_data):
        """Test loading v2 content from content_repo."""
        db_path, v1_id, v2_id, v2_new_id, md_dir, base_time = db_with_sample_data
        since_date = (base_time + timedelta(hours=1)).isoformat()

        with sqlite3.connect(db_path) as conn:
            df = pd.read_sql_query("""
                SELECT ud_source_file_id, raw_file_nme, raw_file_version_nbr,
                       extracted_markdown_file_path
                FROM content_repo
                WHERE last_modified_dt > ? AND file_status = 'Active'
                ORDER BY ud_source_file_id
            """, conn, params=[since_date])

        assert len(df) == 2  # Modified v2 + New benefits file
        # Both files were modified recently, but different versions
        assert df.iloc[0]['ud_source_file_id'] == v2_id  # handbook v2
        assert df.iloc[1]['ud_source_file_id'] == v2_new_id  # benefits v1

    def test_step2_chunk_and_ingest_v1(self, db_with_sample_data):
        """Test chunking v1 content and ingesting into content_chunks."""
        db_path, v1_id, _, _, md_dir, _ = db_with_sample_data

        # Load v1 file
        with sqlite3.connect(db_path) as conn:
            result = conn.execute("""
                SELECT ud_source_file_id, extracted_markdown_file_path
                FROM content_repo
                WHERE ud_source_file_id = ?
            """, (v1_id,)).fetchone()

        file_id, markdown_path = result
        content = Path(markdown_path).read_text()

        # Chunk the content
        chunker = SimpleChunker(chunk_size=1000)
        chunks_with_checksums = chunker.chunk_with_checksums(content)

        assert len(chunks_with_checksums) > 0

        # Ingest chunks
        chunk_ingestion = ChunkIngestion(str(db_path))
        result = chunk_ingestion.ingest_chunks_for_file(
            ud_source_file_id=file_id,
            chunks_with_checksums=chunks_with_checksums,
            clear_existing=True
        )

        assert result['success'] is True
        assert result['rows_inserted'] == len(chunks_with_checksums)

        # Verify chunks in database
        with sqlite3.connect(db_path) as conn:
            chunks_df = pd.read_sql_query("""
                SELECT chunk_id, ud_source_file_id, content_checksum, chunk_text
                FROM content_chunks
                WHERE ud_source_file_id = ? AND status = 'active'
            """, conn, params=[file_id])

        assert len(chunks_df) == len(chunks_with_checksums)
        assert chunks_df.iloc[0]['ud_source_file_id'] == file_id

    def test_step3_chunk_and_ingest_v2(self, db_with_sample_data):
        """Test chunking v2 content and ingesting into content_chunks."""
        db_path, _, v2_id, v2_new_id, md_dir, base_time = db_with_sample_data
        since_date = (base_time + timedelta(hours=1)).isoformat()

        # Load v2 files
        with sqlite3.connect(db_path) as conn:
            v2_files = pd.read_sql_query("""
                SELECT ud_source_file_id, extracted_markdown_file_path
                FROM content_repo
                WHERE last_modified_dt > ? AND file_status = 'Active'
            """, conn, params=[since_date])

        chunker = SimpleChunker(chunk_size=1000)
        chunk_ingestion = ChunkIngestion(str(db_path))

        for _, row in v2_files.iterrows():
            content = Path(row['extracted_markdown_file_path']).read_text()
            chunks_with_checksums = chunker.chunk_with_checksums(content)

            result = chunk_ingestion.ingest_chunks_for_file(
                ud_source_file_id=row['ud_source_file_id'],
                chunks_with_checksums=chunks_with_checksums,
                clear_existing=True
            )

            assert result['success'] is True

        # Verify recently modified chunks exist (handbook v2 + benefits v1)
        with sqlite3.connect(db_path) as conn:
            recent_chunks = pd.read_sql_query("""
                SELECT cc.chunk_id, cc.ud_source_file_id, cr.raw_file_nme, cr.raw_file_version_nbr
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.last_modified_dt > ? AND cc.status = 'active'
            """, conn, params=[since_date])

        assert len(recent_chunks) >= 2  # At least 2 chunks from both files

    def test_step4_load_baseline_chunks(self, db_with_sample_data):
        """Test loading baseline (v1) chunks from content_chunks."""
        db_path, v1_id, _, _, md_dir, _ = db_with_sample_data

        # First ingest v1 chunks (setup)
        content = Path(md_dir / "handbook_v1.md").read_text()
        chunker = SimpleChunker(chunk_size=1000)
        chunks = chunker.chunk_with_checksums(content)

        chunk_ingestion = ChunkIngestion(str(db_path))
        chunk_ingestion.ingest_chunks_for_file(v1_id, chunks, clear_existing=True)

        # Load baseline chunks for v1
        with sqlite3.connect(db_path) as conn:
            baseline_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 1
                  AND cc.status = 'active'
                  AND cr.file_status = 'Active'
            """, conn)

        assert len(baseline_df) == len(chunks)
        assert baseline_df.iloc[0]['raw_file_nme'] == 'handbook.pdf'

    def test_step5_detect_changes_between_versions(self, db_with_sample_data):
        """Test change detection by comparing v1 vs v2 chunks."""
        db_path, v1_id, v2_id, v2_new_id, md_dir, _ = db_with_sample_data

        # Ingest v1 chunks (baseline)
        content_v1 = Path(md_dir / "handbook_v1.md").read_text()
        chunker = SimpleChunker(chunk_size=1000)
        chunks_v1 = chunker.chunk_with_checksums(content_v1)

        chunk_ingestion = ChunkIngestion(str(db_path))
        chunk_ingestion.ingest_chunks_for_file(v1_id, chunks_v1, clear_existing=True)

        # Ingest v2 chunks (current)
        content_v2 = Path(md_dir / "handbook_v2.md").read_text()
        content_v3 = Path(md_dir / "benefits_v2.md").read_text()

        chunks_v2 = chunker.chunk_with_checksums(content_v2)
        chunks_v3 = chunker.chunk_with_checksums(content_v3)

        chunk_ingestion.ingest_chunks_for_file(v2_id, chunks_v2, clear_existing=True)
        chunk_ingestion.ingest_chunks_for_file(v2_new_id, chunks_v3, clear_existing=True)

        # Load baseline (v1) and current (v2) chunks
        with sqlite3.connect(db_path) as conn:
            baseline_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 1 AND cc.status = 'active'
            """, conn)

            current_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 2 AND cc.status = 'active'
            """, conn)

        # Prepare data for detector
        previous_data = {}
        for _, row in baseline_df.iterrows():
            previous_data[row['content_checksum']] = {
                'content_text': row['chunk_text'],
                'file_name': row['raw_file_nme']
            }

        current_data = {}
        for _, row in current_df.iterrows():
            current_data[row['content_checksum']] = {
                'text': row['chunk_text'],
                'file_name': row['raw_file_nme']
            }

        # Detect changes
        detector = ContentChangeDetector(
            similarity_threshold=0.8,
            compute_llm_diffs=True
        )

        changes = detector.detect_changes(
            file_name='handbook.pdf',
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id='test_run_chunks'
        )

        # Assertions
        assert len(changes) >= 1  # At least MODIFIED change

        # Should detect MODIFIED (10 -> 12 sick days)
        modified = [c for c in changes if c.change_type == ChangeType.MODIFIED_CONTENT]
        assert len(modified) >= 1
        assert modified[0].similarity_score >= 0.8

        # Note: Benefits file is a separate file (benefits.pdf v1), not part of this comparison
        # This test only compares handbook.pdf v1 vs v2

    def test_step6_store_results(self, db_with_sample_data):
        """Test storing detection results in content_change_log."""
        db_path, _, _, _, _, _ = db_with_sample_data

        extractor = ChecksumExtractor()
        old_checksum = extractor.compute_checksum("Old content")
        new_checksum = extractor.compute_checksum("New content")

        from granular_impact.database.models import ContentChange

        changes = [
            ContentChange(
                old_checksum=old_checksum,
                new_checksum=new_checksum,
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name='handbook.pdf',
                old_content="Old content",
                new_content="New content",
                similarity_score=0.92
            )
        ]

        # Store results
        with sqlite3.connect(db_path) as conn:
            inserted_count = ChangeDetectionQueries.store_change_detection_results(
                conn=conn,
                changes=changes,
                detection_run_id='test_chunks_run',
                use_spark=False
            )

        assert inserted_count == 1

        # Verify storage
        with sqlite3.connect(db_path) as conn:
            result = conn.execute("""
                SELECT change_type, similarity_score, file_name, detection_run_id
                FROM content_change_log
                WHERE detection_run_id = 'test_chunks_run'
            """).fetchone()

        assert result is not None
        assert result[0] == 'modified_content'
        assert result[1] == 0.92
        assert result[2] == 'handbook.pdf'
        assert result[3] == 'test_chunks_run'

    def test_complete_workflow_with_chunks(self, db_with_sample_data):
        """Test complete end-to-end workflow using content_chunks."""
        db_path, v1_id, v2_id, v2_new_id, md_dir, base_time = db_with_sample_data
        since_date = (base_time + timedelta(hours=1)).isoformat()
        detection_run_id = 'e2e_chunks_test'

        # Step 1: Chunk and ingest v1 (baseline)
        content_v1 = Path(md_dir / "handbook_v1.md").read_text()
        chunker = SimpleChunker(chunk_size=1000)
        chunks_v1 = chunker.chunk_with_checksums(content_v1)

        chunk_ingestion = ChunkIngestion(str(db_path))
        result = chunk_ingestion.ingest_chunks_for_file(v1_id, chunks_v1, clear_existing=True)
        assert result['success']

        # Step 2: Load modified content from content_repo
        with sqlite3.connect(db_path) as conn:
            modified_df = pd.read_sql_query("""
                SELECT ud_source_file_id, extracted_markdown_file_path, raw_file_nme
                FROM content_repo
                WHERE last_modified_dt > ? AND file_status = 'Active'
            """, conn, params=[since_date])

        assert len(modified_df) == 2

        # Step 3: Chunk and ingest v2 files
        for _, row in modified_df.iterrows():
            content = Path(row['extracted_markdown_file_path']).read_text()
            chunks = chunker.chunk_with_checksums(content)
            result = chunk_ingestion.ingest_chunks_for_file(
                row['ud_source_file_id'], chunks, clear_existing=True
            )
            assert result['success']

        # Step 4: Load baseline and current chunks
        with sqlite3.connect(db_path) as conn:
            baseline_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 1 AND cc.status = 'active'
            """, conn)

            current_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 2 AND cc.status = 'active'
            """, conn)

        # Step 5: Prepare data structures
        previous_data = {
            row['content_checksum']: {
                'content_text': row['chunk_text'],
                'file_name': row['raw_file_nme']
            }
            for _, row in baseline_df.iterrows()
        }

        current_data = {
            row['content_checksum']: {
                'text': row['chunk_text'],
                'file_name': row['raw_file_nme']
            }
            for _, row in current_df.iterrows()
        }

        # Step 6: Detect changes
        detector = ContentChangeDetector(similarity_threshold=0.8, compute_llm_diffs=True)
        changes = detector.detect_changes(
            file_name='handbook.pdf',
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=detection_run_id
        )

        assert len(changes) >= 2

        # Step 7: Store results
        with sqlite3.connect(db_path) as conn:
            inserted_count = ChangeDetectionQueries.store_change_detection_results(
                conn=conn,
                changes=changes,
                detection_run_id=detection_run_id,
                use_spark=False
            )

        assert inserted_count == len(changes)

        # Step 8: Verify complete workflow
        with sqlite3.connect(db_path) as conn:
            verification_df = pd.read_sql_query("""
                SELECT change_type, COUNT(*) as count
                FROM content_change_log
                WHERE detection_run_id = ?
                GROUP BY change_type
            """, conn, params=[detection_run_id])

        assert len(verification_df) > 0
        assert verification_df['count'].sum() == len(changes)

        # Verify we have both MODIFIED and NEW changes
        change_types = set(verification_df['change_type'])
        assert 'modified_content' in change_types or 'new_content' in change_types


class TestEdgeCasesWithChunks:
    """Test edge cases with content_chunks architecture."""

    def test_no_v2_content(self, db_with_schema):
        """Test when no v2 content exists."""
        since_date = datetime.now().isoformat()

        with sqlite3.connect(db_with_schema) as conn:
            df = pd.read_sql_query("""
                SELECT * FROM content_repo
                WHERE last_modified_dt > ? AND file_status = 'Active'
            """, conn, params=[since_date])

        assert len(df) == 0

    def test_no_v1_baseline(self, db_with_sample_data):
        """Test when no v1 baseline exists (all NEW)."""
        db_path, _, _, _, _, _ = db_with_sample_data

        # Query for v1 chunks (should be 0 initially)
        with sqlite3.connect(db_path) as conn:
            baseline_df = pd.read_sql_query("""
                SELECT cc.* FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 1
            """, conn)

        # Initially no chunks are ingested, only content_repo entries exist
        assert len(baseline_df) == 0

    def test_identical_chunks_unchanged(self, db_with_schema, tmp_path):
        """Test when v2 has identical chunks to v1 (UNCHANGED)."""
        md_dir = tmp_path / "markdown"
        md_dir.mkdir()

        same_content = "# Policy\n\nThis content is exactly the same."
        (md_dir / "v1.md").write_text(same_content)
        (md_dir / "v2.md").write_text(same_content)

        with sqlite3.connect(db_with_schema) as conn:
            conn.execute("PRAGMA foreign_keys = ON")

            # Insert v1
            cursor = conn.execute("""
                INSERT INTO content_repo (
                    raw_file_nme, raw_file_type, raw_file_version_nbr,
                    extracted_markdown_file_path, title_nme, file_status,
                    created_dt, last_modified_dt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, ('file.pdf', 'pdf', 1, str(md_dir / "v1.md"), 'Same', 'Active',
                  datetime.now().isoformat(), datetime.now().isoformat()))
            v1_id = cursor.lastrowid

            # Insert v2
            cursor = conn.execute("""
                INSERT INTO content_repo (
                    raw_file_nme, raw_file_type, raw_file_version_nbr,
                    extracted_markdown_file_path, title_nme, file_status,
                    created_dt, last_modified_dt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, ('file.pdf', 'pdf', 2, str(md_dir / "v2.md"), 'Same', 'Active',
                  datetime.now().isoformat(), datetime.now().isoformat()))
            v2_id = cursor.lastrowid

            conn.commit()

        # Chunk and ingest both versions
        chunker = SimpleChunker(chunk_size=1000)
        chunk_ingestion = ChunkIngestion(str(db_with_schema))

        chunks = chunker.chunk_with_checksums(same_content)
        chunk_ingestion.ingest_chunks_for_file(v1_id, chunks, clear_existing=True)
        chunk_ingestion.ingest_chunks_for_file(v2_id, chunks, clear_existing=True)

        # Detect changes
        with sqlite3.connect(db_with_schema) as conn:
            v1_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 1
            """, conn)

            v2_df = pd.read_sql_query("""
                SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
                FROM content_chunks cc
                JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                WHERE cr.raw_file_version_nbr = 2
            """, conn)

        # Checksums should be identical
        assert set(v1_df['content_checksum']) == set(v2_df['content_checksum'])

        # Run detector
        detector = ContentChangeDetector()
        changes = detector.detect_changes(
            file_name='file.pdf',
            current_checksums_data={
                row['content_checksum']: {'text': row['chunk_text'], 'file_name': row['raw_file_nme']}
                for _, row in v2_df.iterrows()
            },
            previous_checksums_data={
                row['content_checksum']: {'content_text': row['chunk_text'], 'file_name': row['raw_file_nme']}
                for _, row in v1_df.iterrows()
            },
            detection_run_id='test'
        )

        # Should detect UNCHANGED
        unchanged = [c for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT]
        assert len(unchanged) >= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
