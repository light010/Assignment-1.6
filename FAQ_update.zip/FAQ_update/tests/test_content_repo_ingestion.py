"""
Tests for content_repo data ingestion.

Following TDD approach:
1. Write tests that define expected behavior
2. Implement minimal code to pass tests
3. Refactor while keeping tests green

Schema Ground Truth: 00_content_repo.sql
- Required: raw_file_nme (TEXT NOT NULL)
- Optional: raw_file_type, raw_file_version_nbr, raw_file_path,
            extracted_markdown_file_path, title_nme, content_checksum, file_status
- Timestamps: created_dt, last_modified_dt (auto-generated)
"""

import sqlite3
from datetime import datetime
from pathlib import Path
import tempfile
import pytest
import pandas as pd

# Import the module we're testing
from granular_impact.data_ingestion import ContentRepoIngestion


@pytest.fixture
def temp_db():
    """Create a temporary database with schema for testing."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Create schema matching 00_content_repo.sql (ground truth)
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_type TEXT,
            raw_file_version_nbr INT DEFAULT 1,
            raw_file_path TEXT,
            extracted_markdown_file_path TEXT,
            title_nme TEXT,
            content_checksum TEXT,
            file_status TEXT,
            created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64),
            CHECK (file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived'))
        );
    """)
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def sample_csv_data():
    """Sample content repo data as CSV string (schema-compliant)."""
    return """raw_file_nme,raw_file_type,raw_file_version_nbr,raw_file_path,extracted_markdown_file_path,title_nme,content_checksum,file_status
handbook.pdf,pdf,1,/volumes/data/handbook.pdf,/volumes/markdown/handbook_v1.md,Employee Handbook - Version 1,a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2,Active
handbook.pdf,pdf,2,/volumes/data/handbook.pdf,/volumes/markdown/handbook_v2.md,Employee Handbook - Version 2,b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3,Active
security_guide.pdf,pdf,1,/volumes/data/security.pdf,/volumes/markdown/security_v1.md,IT Security Guidelines,c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4,Active
"""


@pytest.fixture
def sample_dataframe():
    """Sample content repo data as pandas DataFrame (schema-compliant)."""
    return pd.DataFrame([
        {
            "raw_file_nme": "payroll_guide.pdf",
            "raw_file_type": "pdf",
            "raw_file_version_nbr": 1,
            "raw_file_path": "/volumes/data/payroll_guide.pdf",
            "extracted_markdown_file_path": "/volumes/markdown/payroll_v1.md",
            "title_nme": "Payroll Processing Guide",
            "content_checksum": "d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5",
            "file_status": "Active",
        },
        {
            "raw_file_nme": "benefits_overview.pdf",
            "raw_file_type": "pdf",
            "raw_file_version_nbr": 1,
            "raw_file_path": "/volumes/data/benefits.pdf",
            "extracted_markdown_file_path": "/volumes/markdown/benefits_v1.md",
            "title_nme": "Employee Benefits Overview",
            "content_checksum": "e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6",
            "file_status": "Active",
        }
    ])


class TestContentRepoIngestion:
    """Test suite for ContentRepoIngestion class."""

    def test_init(self, temp_db):
        """Test initialization with database path."""
        ingestion = ContentRepoIngestion(temp_db)
        assert ingestion.db_path == temp_db

    def test_ingest_from_csv_file(self, temp_db, sample_csv_data):
        """Test ingesting from CSV file."""
        # Create temp CSV file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write(sample_csv_data)

        try:
            ingestion = ContentRepoIngestion(temp_db)
            result = ingestion.ingest_from_csv(csv_path)

            # Verify result
            assert result['success'] is True
            assert result['rows_inserted'] == 3
            assert 'Successfully inserted' in result['message']

            # Verify database
            conn = sqlite3.connect(temp_db)
            count = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]
            assert count == 3

            # Verify data integrity
            row = conn.execute(
                "SELECT raw_file_nme, title_nme, content_checksum, file_status FROM content_repo WHERE raw_file_version_nbr = 1 AND raw_file_nme = 'handbook.pdf'"
            ).fetchone()
            assert row[0] == 'handbook.pdf'
            assert row[1] == 'Employee Handbook - Version 1'
            assert len(row[2]) == 64  # Valid SHA256 checksum
            assert row[3] == 'Active'
            conn.close()

        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_ingest_from_dataframe(self, temp_db, sample_dataframe):
        """Test ingesting from pandas DataFrame."""
        ingestion = ContentRepoIngestion(temp_db)
        result = ingestion.ingest_from_dataframe(sample_dataframe)

        # Verify result
        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify database
        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]
        assert count == 2

        # Verify data
        row = conn.execute(
            "SELECT raw_file_nme, raw_file_type, title_nme FROM content_repo WHERE title_nme = 'Payroll Processing Guide'"
        ).fetchone()
        assert row[0] == 'payroll_guide.pdf'
        assert row[1] == 'pdf'
        assert row[2] == 'Payroll Processing Guide'
        conn.close()

    def test_validate_checksums(self, temp_db):
        """Test checksum validation (must be 64 chars)."""
        ingestion = ContentRepoIngestion(temp_db)

        # Valid checksum (64 chars)
        valid_df = pd.DataFrame([{
            "raw_file_nme": "test.pdf",
            "content_checksum": "a" * 64,
        }])
        result = ingestion.ingest_from_dataframe(valid_df)
        assert result['success'] is True

        # Invalid checksum (wrong length)
        invalid_df = pd.DataFrame([{
            "raw_file_nme": "test2.pdf",
            "content_checksum": "short",
        }])
        result = ingestion.ingest_from_dataframe(invalid_df)
        assert result['success'] is False
        assert 'checksum' in result['message'].lower()

    def test_validate_file_status(self, temp_db):
        """Test file_status validation (must be Active, Inactive, or Archived)."""
        ingestion = ContentRepoIngestion(temp_db)

        # Valid statuses
        for status in ['Active', 'Inactive', 'Archived']:
            valid_df = pd.DataFrame([{
                "raw_file_nme": f"test_{status}.pdf",
                "file_status": status,
            }])
            result = ingestion.ingest_from_dataframe(valid_df)
            assert result['success'] is True, f"Should accept {status}"

        # Invalid status
        invalid_df = pd.DataFrame([{
            "raw_file_nme": "test_invalid.pdf",
            "file_status": "Pending",
        }])
        result = ingestion.ingest_from_dataframe(invalid_df)
        assert result['success'] is False
        assert 'file_status' in result['message'].lower()

    def test_required_fields(self, temp_db):
        """Test that raw_file_nme is required."""
        ingestion = ContentRepoIngestion(temp_db)

        # Missing raw_file_nme - should fail
        invalid_df = pd.DataFrame([{
            "title_nme": "Some Title",
        }])
        result = ingestion.ingest_from_dataframe(invalid_df)
        assert result['success'] is False
        assert 'required' in result['message'].lower()

        # Null raw_file_nme - should fail
        invalid_df2 = pd.DataFrame([{
            "raw_file_nme": None,
        }])
        result2 = ingestion.ingest_from_dataframe(invalid_df2)
        assert result2['success'] is False

    def test_default_values(self, temp_db):
        """Test that default values are applied correctly."""
        ingestion = ContentRepoIngestion(temp_db)

        minimal_df = pd.DataFrame([{
            "raw_file_nme": "minimal.pdf",
        }])
        result = ingestion.ingest_from_dataframe(minimal_df)
        assert result['success'] is True

        # Verify defaults
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT raw_file_version_nbr, created_dt, last_modified_dt "
            "FROM content_repo WHERE raw_file_nme = 'minimal.pdf'"
        ).fetchone()

        assert row[0] == 1  # raw_file_version_nbr default
        assert row[1] is not None  # created_dt default
        assert row[2] is not None  # last_modified_dt default
        conn.close()

    def test_ignore_extra_columns(self, temp_db):
        """Test that extra columns not in schema are ignored."""
        ingestion = ContentRepoIngestion(temp_db)

        # DataFrame with extra columns (domain, service, page_nbr, etc.)
        df_with_extras = pd.DataFrame([{
            "raw_file_nme": "test.pdf",
            "domain": "HR",  # Not in schema
            "service": "Policy",  # Not in schema
            "raw_file_page_nbr": 1,  # Not in schema
            "version_nbr": 2,  # Not in schema
            "orgoid": "ORG001",  # Not in schema
            "title_nme": "Test Document",  # In schema
        }])
        result = ingestion.ingest_from_dataframe(df_with_extras)
        assert result['success'] is True

        # Verify only schema columns were inserted
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT raw_file_nme, title_nme FROM content_repo WHERE raw_file_nme = 'test.pdf'"
        ).fetchone()
        assert row[0] == 'test.pdf'
        assert row[1] == 'Test Document'

        # Verify extra columns don't exist in table
        cursor = conn.execute("PRAGMA table_info(content_repo)")
        columns = [col[1] for col in cursor.fetchall()]
        assert 'domain' not in columns
        assert 'raw_file_page_nbr' not in columns
        assert 'version_nbr' not in columns
        conn.close()

    def test_batch_insert_performance(self, temp_db):
        """Test that batch insert is used for efficiency."""
        # Create large dataset
        large_df = pd.DataFrame([
            {
                "raw_file_nme": f"file_{i}.pdf",
                "content_checksum": f"{i:064d}",
            }
            for i in range(100)
        ])

        ingestion = ContentRepoIngestion(temp_db)
        result = ingestion.ingest_from_dataframe(large_df)

        assert result['success'] is True
        assert result['rows_inserted'] == 100

        # Verify all records inserted
        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]
        assert count == 100
        conn.close()

    def test_get_ingestion_stats(self, temp_db, sample_dataframe):
        """Test getting ingestion statistics."""
        ingestion = ContentRepoIngestion(temp_db)
        ingestion.ingest_from_dataframe(sample_dataframe)

        stats = ingestion.get_stats()

        assert stats['total_records'] == 2
        assert stats['unique_files'] == 2  # Two different files
        assert 'file_types' in stats
        assert 'pdf' in stats['file_types']
        assert 'statuses' in stats
        assert 'Active' in stats['statuses']

    def test_clear_table(self, temp_db, sample_dataframe):
        """Test clearing the content_repo table."""
        ingestion = ContentRepoIngestion(temp_db)
        ingestion.ingest_from_dataframe(sample_dataframe)

        # Verify data exists
        conn = sqlite3.connect(temp_db)
        count_before = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]
        conn.close()
        assert count_before == 2

        # Clear table
        result = ingestion.clear()
        assert result['success'] is True

        # Verify table is empty
        conn = sqlite3.connect(temp_db)
        count_after = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]
        conn.close()
        assert count_after == 0

    def test_csv_file_not_found(self, temp_db):
        """Test error handling when CSV file doesn't exist."""
        ingestion = ContentRepoIngestion(temp_db)
        result = ingestion.ingest_from_csv("nonexistent.csv")

        assert result['success'] is False
        assert 'not found' in result['message'].lower()

    def test_multiple_versions_same_file(self, temp_db):
        """Test ingesting multiple versions of the same file."""
        ingestion = ContentRepoIngestion(temp_db)

        # Version 1
        v1_df = pd.DataFrame([{
            "raw_file_nme": "policy.pdf",
            "raw_file_version_nbr": 1,
            "title_nme": "Policy Version 1",
            "content_checksum": "a" * 64,
        }])
        result1 = ingestion.ingest_from_dataframe(v1_df)
        assert result1['success'] is True

        # Version 2 (same file, different version)
        v2_df = pd.DataFrame([{
            "raw_file_nme": "policy.pdf",
            "raw_file_version_nbr": 2,
            "title_nme": "Policy Version 2 - Updated",
            "content_checksum": "b" * 64,
        }])
        result2 = ingestion.ingest_from_dataframe(v2_df)
        assert result2['success'] is True

        # Verify both versions exist
        conn = sqlite3.connect(temp_db)
        count = conn.execute(
            "SELECT COUNT(*) FROM content_repo WHERE raw_file_nme = 'policy.pdf'"
        ).fetchone()[0]
        assert count == 2
        conn.close()
