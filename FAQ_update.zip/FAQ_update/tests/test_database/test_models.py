"""
Tests for database models (7-table schema).

Test coverage:
- Core models (7 tables)
- Model validation
- Enum values
- Helper models
"""

import pytest
from datetime import datetime
from granular_impact.database.models import (
    # Core models
    ContentChecksum,
    FAQQuestion,
    FAQAnswer,
    FAQQuestionSource,
    FAQAnswerSource,
    ContentChangeLog,
    AuditLogEntry,
    ContentChange,
    # Enums
    ContentStatus,
    FAQStatus,
    SourceType,
    GenerationMethod,
    ChangeType,
    InvalidationReason,
    AnswerFormat,
)


class TestContentChecksum:
    """Test ContentChecksum model (table 1)."""

    def test_create_content_checksum(self):
        """Test creating valid ContentChecksum."""
        checksum = ContentChecksum(
            content_checksum="a" * 64,
            status=ContentStatus.ACTIVE,
            file_name="handbook.pdf",
        )

        assert checksum.content_checksum == "a" * 64
        assert checksum.status == ContentStatus.ACTIVE
        assert checksum.file_name == "handbook.pdf"
        assert checksum.created_at is not None

    def test_checksum_length_validation(self):
        """Test that checksum must be 64 characters."""
        with pytest.raises(ValueError, match="64 chars"):
            ContentChecksum(content_checksum="abc")

    def test_to_dict(self):
        """Test conversion to dictionary."""
        checksum = ContentChecksum(
            content_checksum="a" * 64,
            status=ContentStatus.ACTIVE,
        )
        data = checksum.to_dict()

        assert data["content_checksum"] == "a" * 64
        assert data["status"] == "active"
        assert "created_at" in data


class TestFAQQuestion:
    """Test FAQQuestion model (table 2)."""

    def test_create_faq_question(self):
        """Test creating valid FAQ question."""
        question = FAQQuestion(
            question_text="How many sick days?",
            source_type=SourceType.FROM_DOCUMENTS,
            generation_method=GenerationMethod.LLM_GENERATED,
            status=FAQStatus.ACTIVE,
        )

        assert question.question_text == "How many sick days?"
        assert question.source_type == SourceType.FROM_DOCUMENTS
        assert question.generation_method == GenerationMethod.LLM_GENERATED
        assert question.status == FAQStatus.ACTIVE

    def test_to_dict(self):
        """Test conversion to dictionary."""
        question = FAQQuestion(question_text="Test?")
        data = question.to_dict()

        assert data["question_text"] == "Test?"
        assert "created_at" in data


class TestFAQAnswer:
    """Test FAQAnswer model (table 3)."""

    def test_create_faq_answer(self):
        """Test creating valid FAQ answer."""
        answer = FAQAnswer(
            question_id=123,
            answer_text="<p>12 sick days</p>",
            answer_format=AnswerFormat.HTML,
            confidence_score=0.95,
            status=FAQStatus.ACTIVE,
        )

        assert answer.question_id == 123
        assert answer.answer_text == "<p>12 sick days</p>"
        assert answer.answer_format == AnswerFormat.HTML
        assert answer.confidence_score == 0.95

    def test_confidence_score_validation(self):
        """Test confidence score must be 0.0-1.0."""
        with pytest.raises(ValueError, match="0.0-1.0"):
            FAQAnswer(
                question_id=1,
                answer_text="Test",
                confidence_score=1.5,  # Invalid
            )


class TestFAQQuestionSource:
    """Test FAQQuestionSource model (table 4)."""

    def test_create_question_source(self):
        """Test creating valid question source."""
        source = FAQQuestionSource(
            question_id=123,
            content_checksum="a" * 64,
            is_primary_source=True,
            contribution_weight=1.0,
            is_valid=True,
        )

        assert source.question_id == 123
        assert source.content_checksum == "a" * 64
        assert source.is_primary_source is True
        assert source.is_valid is True

    def test_contribution_weight_validation(self):
        """Test contribution weight must be 0.0-1.0."""
        with pytest.raises(ValueError, match="0.0-1.0"):
            FAQQuestionSource(
                question_id=1,
                content_checksum="a" * 64,
                contribution_weight=1.5,  # Invalid
            )

    def test_invalidation(self):
        """Test invalidation workflow."""
        source = FAQQuestionSource(
            question_id=123,
            content_checksum="a" * 64,
            is_valid=True,
        )

        # Invalidate
        source.is_valid = False
        source.valid_until = datetime.now()
        source.invalidation_reason = InvalidationReason.SELECTIVE_IMPACT
        source.invalidated_by_change_id = 789

        assert source.is_valid is False
        assert source.valid_until is not None
        assert source.invalidation_reason == InvalidationReason.SELECTIVE_IMPACT


class TestFAQAnswerSource:
    """Test FAQAnswerSource model (table 5)."""

    def test_create_answer_source(self):
        """Test creating valid answer source."""
        source = FAQAnswerSource(
            answer_id=456,
            content_checksum="b" * 64,
            is_primary_source=False,
            contribution_weight=0.8,
            is_valid=True,
        )

        assert source.answer_id == 456
        assert source.contribution_weight == 0.8


class TestContentChangeLog:
    """Test ContentChangeLog model (table 6)."""

    def test_create_content_change_log(self):
        """Test creating valid content change log."""
        change = ContentChangeLog(
            content_checksum="b" * 64,
            previous_checksum="a" * 64,
            file_name="handbook.pdf",
            requires_faq_regeneration=True,
            change_type=ChangeType.MODIFIED_CONTENT,
            similarity_score=0.92,
            similarity_method="bm25",
            total_faqs_at_risk=10,
            affected_question_count=1,
            affected_answer_count=1,
            detection_run_id="RUN_001",
        )

        assert change.content_checksum == "b" * 64
        assert change.previous_checksum == "a" * 64
        assert change.change_type == ChangeType.MODIFIED_CONTENT
        assert change.total_faqs_at_risk == 10
        assert change.affected_question_count == 1

    def test_checksum_validation(self):
        """Test checksum length validation."""
        with pytest.raises(ValueError, match="64 chars"):
            ContentChangeLog(
                content_checksum="abc",  # Too short
                file_name="test.pdf",
                requires_faq_regeneration=False,
                detection_run_id="TEST",
            )

    def test_similarity_score_validation(self):
        """Test similarity score must be 0.0-1.0."""
        with pytest.raises(ValueError, match="0.0-1.0"):
            ContentChangeLog(
                content_checksum="a" * 64,
                file_name="test.pdf",
                requires_faq_regeneration=False,
                detection_run_id="TEST",
                similarity_score=1.5,  # Invalid
            )


class TestAuditLogEntry:
    """Test AuditLogEntry model (table 7)."""

    def test_create_audit_log_entry(self):
        """Test creating valid audit log entry."""
        audit = AuditLogEntry(
            change_id=123,
            question_id=456,
            answer_id=789,
            detection_run_id="RUN_001",
        )

        assert audit.change_id == 123
        assert audit.question_id == 456
        assert audit.answer_id == 789
        assert audit.created_at is not None


class TestContentChange:
    """Test ContentChange helper model (not persisted)."""

    def test_create_content_change(self):
        """Test creating content change (transient model)."""
        change = ContentChange(
            old_checksum="a" * 64,
            new_checksum="b" * 64,
            change_type=ChangeType.MODIFIED_CONTENT,
            file_name="test.pdf",
            similarity_score=0.85,
        )

        assert change.old_checksum == "a" * 64
        assert change.new_checksum == "b" * 64
        assert change.change_type == ChangeType.MODIFIED_CONTENT
        assert change.detected_at is not None


class TestEnums:
    """Test enum values."""

    def test_content_status_values(self):
        """Test ContentStatus enum."""
        assert ContentStatus.ACTIVE.value == "active"
        assert ContentStatus.ARCHIVED.value == "archived"
        assert ContentStatus.DELETED.value == "deleted"

    def test_faq_status_values(self):
        """Test FAQStatus enum."""
        assert FAQStatus.ACTIVE.value == "active"
        assert FAQStatus.INVALIDATED.value == "invalidated"
        assert FAQStatus.ARCHIVED.value == "archived"

    def test_change_type_values(self):
        """Test ChangeType enum."""
        assert ChangeType.NEW_CONTENT.value == "new_content"
        assert ChangeType.MODIFIED_CONTENT.value == "modified_content"
        assert ChangeType.UNCHANGED_CONTENT.value == "unchanged_content"
        assert ChangeType.DELETED_CONTENT.value == "deleted_content"

    def test_answer_format_values(self):
        """Test AnswerFormat enum."""
        assert AnswerFormat.HTML.value == "html"
        assert AnswerFormat.MARKDOWN.value == "markdown"
        assert AnswerFormat.PLAIN.value == "plain"
