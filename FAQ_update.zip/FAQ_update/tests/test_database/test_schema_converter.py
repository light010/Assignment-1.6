"""
Tests for SchemaConverter - converts Databricks SQL to SQLite SQL.

TDD approach:
1. Write failing tests first (Red)
2. Implement minimal code to pass (Green)
3. Refactor for simplicity (Refactor)

Test coverage:
- Type conversions (STRING→TEXT, BIGINT→INTEGER, TIMESTAMP→TEXT)
- Comment removal
- TBLPROPERTIES removal
- Timestamp function conversion
- Identity column conversion
- Constraint conversion (ALTER TABLE → inline)
"""

import pytest
from granular_impact.database.schema_converter import SchemaConverter


class TestSchemaConverterTypeConversions:
    """Test data type conversions."""

    def test_convert_string_to_text(self):
        """Test STRING → TEXT conversion."""
        databricks_sql = "CREATE TABLE test (name STRING NOT NULL);"
        expected = "CREATE TABLE test (name TEXT NOT NULL);"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "STRING" not in result
        assert "TEXT" in result

    def test_convert_bigint_to_integer(self):
        """Test BIGINT → INTEGER conversion."""
        databricks_sql = "CREATE TABLE test (id BIGINT);"
        expected = "CREATE TABLE test (id INTEGER);"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "BIGINT" not in result
        assert "INTEGER" in result

    def test_convert_timestamp_to_text(self):
        """Test TIMESTAMP → TEXT conversion."""
        databricks_sql = "CREATE TABLE test (created_at TIMESTAMP);"
        expected = "CREATE TABLE test (created_at TEXT);"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "TIMESTAMP" not in result
        assert "created_at TEXT" in result

    def test_convert_int_remains_int(self):
        """Test that INT remains INT (common type)."""
        databricks_sql = "CREATE TABLE test (version INT);"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "version INT" in result


class TestSchemaConverterCommentRemoval:
    """Test COMMENT clause removal."""

    def test_remove_simple_comment(self):
        """Test removing simple COMMENT clause."""
        databricks_sql = "name STRING NOT NULL COMMENT 'User name'"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "COMMENT" not in result
        assert "name TEXT NOT NULL" in result

    def test_remove_multiple_comments(self):
        """Test removing multiple COMMENT clauses."""
        databricks_sql = """
        CREATE TABLE test (
            name STRING COMMENT 'Name',
            email STRING COMMENT 'Email address'
        );
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "COMMENT" not in result
        assert result.count("STRING") == 0  # All converted to TEXT

    def test_preserve_comment_in_table_level(self):
        """Test that table-level COMMENT is removed."""
        databricks_sql = """
        CREATE TABLE test (id BIGINT)
        COMMENT 'Test table';
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "COMMENT 'Test table'" not in result


class TestSchemaConverterTableProperties:
    """Test TBLPROPERTIES removal."""

    def test_remove_tblproperties(self):
        """Test removing TBLPROPERTIES block."""
        databricks_sql = """
        CREATE TABLE test (id BIGINT)
        TBLPROPERTIES (
            'delta.enableChangeDataFeed' = 'true',
            'delta.autoOptimize.optimizeWrite' = 'true'
        );
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "TBLPROPERTIES" not in result
        assert "delta" not in result
        assert result.strip().endswith(");")

    def test_tblproperties_multiline(self):
        """Test removing multiline TBLPROPERTIES."""
        databricks_sql = """
        CREATE TABLE content_checksums (
            content_checksum STRING NOT NULL
        )
        COMMENT 'Master table'
        TBLPROPERTIES (
            'delta.enableChangeDataFeed' = 'true',
            'delta.autoOptimize.optimizeWrite' = 'true',
            'delta.autoOptimize.autoCompact' = 'true',
            'delta.deletedFileRetentionDuration' = 'interval 30 days'
        );
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "TBLPROPERTIES" not in result
        assert "delta" not in result


class TestSchemaConverterTimestampFunctions:
    """Test timestamp function conversions."""

    def test_convert_current_timestamp_function(self):
        """Test CURRENT_TIMESTAMP() → CURRENT_TIMESTAMP."""
        databricks_sql = "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "CURRENT_TIMESTAMP()" not in result
        assert "CURRENT_TIMESTAMP" in result

    def test_multiple_current_timestamp(self):
        """Test converting multiple CURRENT_TIMESTAMP() calls."""
        databricks_sql = """
        CREATE TABLE test (
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
        );
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "CURRENT_TIMESTAMP()" not in result
        assert result.count("CURRENT_TIMESTAMP") == 2


class TestSchemaConverterIdentityColumns:
    """Test identity column conversions."""

    def test_convert_generated_identity(self):
        """Test GENERATED ALWAYS AS IDENTITY → AUTOINCREMENT."""
        databricks_sql = "id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "GENERATED ALWAYS AS IDENTITY" not in result
        assert "INTEGER PRIMARY KEY AUTOINCREMENT" in result

    def test_identity_with_comment(self):
        """Test identity conversion with COMMENT."""
        databricks_sql = "question_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY COMMENT 'Primary key'"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "GENERATED ALWAYS AS IDENTITY" not in result
        assert "COMMENT" not in result
        assert "INTEGER PRIMARY KEY AUTOINCREMENT" in result


class TestSchemaConverterConstraints:
    """Test constraint conversions."""

    def test_remove_alter_table_primary_key(self):
        """Test removing ALTER TABLE PRIMARY KEY statements."""
        databricks_sql = """
        CREATE TABLE test (id BIGINT);

        ALTER TABLE test ADD CONSTRAINT IF NOT EXISTS pk_test
            PRIMARY KEY (id);
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        # SQLite requires inline primary key for AUTOINCREMENT
        # So ALTER TABLE PK statements should be removed
        assert "ALTER TABLE test ADD CONSTRAINT" not in result

    def test_convert_check_constraints_to_inline(self):
        """Test converting CHECK constraints to inline."""
        databricks_sql = """
        CREATE TABLE test (
            checksum STRING NOT NULL
        );

        ALTER TABLE test ADD CONSTRAINT IF NOT EXISTS chk_length
            CHECK (LENGTH(checksum) = 64);
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        # Check constraint should be inline
        assert "CHECK" in result
        assert "LENGTH(checksum) = 64" in result or "length(checksum) = 64" in result


class TestSchemaConverterFullTableConversion:
    """Test complete table conversions."""

    def test_convert_simple_table(self):
        """Test converting a simple table."""
        databricks_sql = """
        CREATE TABLE IF NOT EXISTS users (
            user_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,
            name STRING NOT NULL COMMENT 'User full name',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
        )
        COMMENT 'Users table';

        ALTER TABLE users ADD CONSTRAINT IF NOT EXISTS pk_users
            PRIMARY KEY (user_id);
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        # Verify conversions
        assert "CREATE TABLE IF NOT EXISTS users" in result
        assert "INTEGER PRIMARY KEY AUTOINCREMENT" in result
        assert "TEXT NOT NULL" in result
        assert "TEXT DEFAULT CURRENT_TIMESTAMP" in result
        assert "COMMENT" not in result
        assert "BIGINT" not in result
        assert "STRING" not in result

    def test_convert_content_repo_table(self):
        """Test converting content_repo table (real example)."""
        databricks_sql = """
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY COMMENT 'Auto-incrementing primary key',
            raw_file_nme STRING NOT NULL COMMENT 'Raw file name',
            raw_file_type STRING COMMENT 'File type',
            raw_file_version_nbr INT DEFAULT 1 COMMENT 'Version number',
            content_checksum STRING COMMENT 'SHA-256 hash (64 chars)',
            file_status STRING COMMENT 'Active, Inactive, or Archived',
            created_dt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation timestamp',
            last_modified_dt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Last modification'
        )
        COMMENT 'Repository of source content files'
        TBLPROPERTIES (
            'delta.enableChangeDataFeed' = 'true'
        );

        ALTER TABLE content_repo ADD CONSTRAINT IF NOT EXISTS pk_content_repo
            PRIMARY KEY (ud_source_file_id);

        ALTER TABLE content_repo ADD CONSTRAINT IF NOT EXISTS chk_checksum
            CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64);
        """

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        # Verify structure
        assert "CREATE TABLE IF NOT EXISTS content_repo" in result
        assert "ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT" in result
        assert "raw_file_nme TEXT NOT NULL" in result
        assert "raw_file_type TEXT" in result
        assert "raw_file_version_nbr INT DEFAULT 1" in result
        assert "content_checksum TEXT" in result
        assert "file_status TEXT" in result
        assert "created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP" in result

        # Verify removals
        assert "COMMENT" not in result
        assert "TBLPROPERTIES" not in result
        assert "delta" not in result
        assert "GENERATED ALWAYS AS IDENTITY" not in result

        # Verify CHECK constraints are preserved
        assert "CHECK" in result
        assert "LENGTH(content_checksum) = 64" in result or "length(content_checksum) = 64" in result


class TestSchemaConverterEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_sql(self):
        """Test converting empty SQL."""
        result = SchemaConverter.databricks_to_sqlite("")
        assert result == ""

    def test_sql_without_conversions_needed(self):
        """Test SQL that doesn't need conversion."""
        databricks_sql = "-- Just a comment\nSELECT 1;"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "SELECT 1" in result

    def test_preserve_if_not_exists(self):
        """Test that IF NOT EXISTS is preserved."""
        databricks_sql = "CREATE TABLE IF NOT EXISTS test (id BIGINT);"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "IF NOT EXISTS" in result

    def test_case_insensitive_keywords(self):
        """Test that conversion works with different cases."""
        databricks_sql = "name string NOT NULL comment 'Name'"

        result = SchemaConverter.databricks_to_sqlite(databricks_sql)

        assert "TEXT" in result or "text" in result
        assert "comment" not in result.lower() or "COMMENT" not in result
