"""Tests for TransactionManager class."""

import pytest
import time
from unittest.mock import Mock
from granular_impact.database.transactions import TransactionManager


class TestTransactionManager:
    """Test TransactionManager class."""

    def test_initialization(self):
        """Test transaction manager initialization."""
        manager = TransactionManager(max_retries=5, retry_delay=2.0)

        assert manager.max_retries == 5
        assert manager.retry_delay == 2.0

    def test_initialization_defaults(self):
        """Test default initialization values."""
        manager = TransactionManager()

        assert manager.max_retries == 3
        assert manager.retry_delay == 1.0

    def test_execute_with_retry_success(self):
        """Test successful operation execution."""
        manager = TransactionManager()

        operation = Mock(return_value="success")
        result = manager.execute_with_retry(operation)

        assert result == "success"
        operation.assert_called_once()

    def test_execute_with_retry_eventual_success(self):
        """Test operation that fails once then succeeds."""
        manager = TransactionManager(retry_delay=0.01)

        # Fail once, then succeed
        operation = Mock(side_effect=[Exception("Transient error"), "success"])

        result = manager.execute_with_retry(operation)

        assert result == "success"
        assert operation.call_count == 2

    def test_execute_with_retry_all_failures(self):
        """Test operation that fails all attempts."""
        manager = TransactionManager(max_retries=3, retry_delay=0.01)

        error = Exception("Persistent error")
        operation = Mock(side_effect=error)

        with pytest.raises(Exception, match="Persistent error"):
            manager.execute_with_retry(operation)

        assert operation.call_count == 3

    def test_exponential_backoff(self):
        """Test that retry delay increases exponentially."""
        manager = TransactionManager(max_retries=3, retry_delay=0.1)

        operation = Mock(side_effect=[
            Exception("Error 1"),
            Exception("Error 2"),
            "success"
        ])

        start = time.time()
        result = manager.execute_with_retry(operation)
        elapsed = time.time() - start

        assert result == "success"
        assert operation.call_count == 3

        # Exponential backoff: 0.1 * (2^0) = 0.1s (1st retry), 0.1 * (2^1) = 0.2s (2nd retry)
        # Total minimum delay: 0.3s
        assert elapsed >= 0.3

    def test_last_exception_is_raised(self):
        """Test that the last exception is raised when all retries fail."""
        manager = TransactionManager(max_retries=2, retry_delay=0.01)

        error1 = Exception("First error")
        error2 = Exception("Last error")

        operation = Mock(side_effect=[error1, error2])

        with pytest.raises(Exception, match="Last error"):
            manager.execute_with_retry(operation)

        assert operation.call_count == 2
