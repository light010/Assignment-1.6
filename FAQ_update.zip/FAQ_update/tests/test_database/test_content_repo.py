"""
Tests for ContentRepo model and content_repo table.

Tests cover:
- Model validation
- Table creation
- CRUD operations
- Constraints (checksum length, file_status)
- Timestamps
"""

import pytest
from datetime import datetime

from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)
from granular_impact.database.models import ContentRepo, FileStatus


class TestContentRepoModel:
    """Test ContentRepo dataclass model."""

    def test_create_minimal_content_repo(self):
        """Test creating ContentRepo with minimal required fields."""
        repo = ContentRepo(raw_file_nme="handbook.pdf")

        assert repo.raw_file_nme == "handbook.pdf"
        assert repo.raw_file_version_nbr == 1  # Default value
        assert repo.ud_source_file_id is None  # Auto-assigned by DB
        assert repo.file_status is None
        assert isinstance(repo.created_dt, datetime)
        assert isinstance(repo.last_modified_dt, datetime)

    def test_create_full_content_repo(self):
        """Test creating ContentRepo with all fields."""
        repo = ContentRepo(
            raw_file_nme="benefits.pdf",
            raw_file_type="pdf",
            raw_file_version_nbr=2,
            raw_file_path="/volumes/data/benefits.pdf",
            extracted_markdown_file_path="/volumes/markdown/benefits.md",
            title_nme="Employee Benefits Guide",
            content_checksum="a" * 64,
            file_status=FileStatus.ACTIVE,
        )

        assert repo.raw_file_nme == "benefits.pdf"
        assert repo.raw_file_type == "pdf"
        assert repo.raw_file_version_nbr == 2
        assert repo.raw_file_path == "/volumes/data/benefits.pdf"
        assert repo.extracted_markdown_file_path == "/volumes/markdown/benefits.md"
        assert repo.title_nme == "Employee Benefits Guide"
        assert repo.content_checksum == "a" * 64
        assert repo.file_status == FileStatus.ACTIVE

    def test_content_checksum_validation_valid(self):
        """Test valid content_checksum (64 chars)."""
        repo = ContentRepo(
            raw_file_nme="test.pdf",
            content_checksum="a" * 64
        )
        assert len(repo.content_checksum) == 64

    def test_content_checksum_validation_invalid(self):
        """Test invalid content_checksum length raises ValueError."""
        with pytest.raises(ValueError, match="content_checksum must be 64 chars"):
            ContentRepo(
                raw_file_nme="test.pdf",
                content_checksum="abc123"  # Too short
            )

    def test_content_checksum_none_allowed(self):
        """Test that content_checksum can be None."""
        repo = ContentRepo(
            raw_file_nme="test.pdf",
            content_checksum=None
        )
        assert repo.content_checksum is None

    def test_to_dict(self):
        """Test converting ContentRepo to dictionary."""
        repo = ContentRepo(
            raw_file_nme="handbook.pdf",
            raw_file_type="pdf",
            title_nme="Employee Handbook",
            file_status=FileStatus.ACTIVE
        )

        data = repo.to_dict()

        assert data["raw_file_nme"] == "handbook.pdf"
        assert data["raw_file_type"] == "pdf"
        assert data["title_nme"] == "Employee Handbook"
        assert data["file_status"] == "Active"  # Enum value
        assert data["raw_file_version_nbr"] == 1
        assert isinstance(data["created_dt"], datetime)

    def test_file_status_enum_values(self):
        """Test FileStatus enum values."""
        assert FileStatus.ACTIVE.value == "Active"
        assert FileStatus.INACTIVE.value == "Inactive"
        assert FileStatus.ARCHIVED.value == "Archived"


class TestContentRepoTable:
    """Test content_repo table in database."""

    @pytest.fixture
    def adapter(self):
        """Create in-memory SQLite adapter."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        yield adapter
        adapter.close()

    @pytest.fixture
    def manager(self, adapter):
        """Create SchemaManager with adapter."""
        return SchemaManager(adapter=adapter)

    def test_table_creation(self, manager, adapter):
        """Test creating content_repo table."""
        manager.create_schema(specific_tables=["content_repo"])

        # Verify table exists
        tables = adapter.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='content_repo'"
        )
        assert len(tables) == 1
        assert tables[0][0] == "content_repo"

    def test_table_creation_with_all_tables(self, manager, adapter):
        """Test that content_repo is included when creating all tables."""
        manager.create_schema()

        # Verify content_repo exists
        tables = adapter.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='content_repo'"
        )
        assert len(tables) == 1

    def test_insert_minimal(self, manager, adapter):
        """Test inserting minimal content_repo record."""
        manager.create_schema(specific_tables=["content_repo"])

        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
            ("handbook.pdf",)
        )
        adapter.commit()

        results = adapter.fetchall("SELECT * FROM content_repo")
        assert len(results) == 1
        assert results[0][1] == "handbook.pdf"  # raw_file_nme

    def test_insert_full(self, manager, adapter):
        """Test inserting full content_repo record."""
        manager.create_schema(specific_tables=["content_repo"])

        adapter.execute(
            """INSERT INTO content_repo (
                raw_file_nme, raw_file_type, raw_file_version_nbr,
                raw_file_path, extracted_markdown_file_path,
                title_nme, content_checksum, file_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                "benefits.pdf",
                "pdf",
                2,
                "/volumes/data/benefits.pdf",
                "/volumes/markdown/benefits.md",
                "Employee Benefits",
                "a" * 64,
                "Active"
            )
        )
        adapter.commit()

        results = adapter.fetchall(
            "SELECT raw_file_nme, raw_file_type, title_nme, file_status FROM content_repo"
        )
        assert len(results) == 1
        row = results[0]
        assert row[0] == "benefits.pdf"
        assert row[1] == "pdf"
        assert row[2] == "Employee Benefits"
        assert row[3] == "Active"

    def test_autoincrement_primary_key(self, manager, adapter):
        """Test that ud_source_file_id auto-increments."""
        manager.create_schema(specific_tables=["content_repo"])

        adapter.execute("INSERT INTO content_repo (raw_file_nme) VALUES (?)", ("file1.pdf",))
        adapter.execute("INSERT INTO content_repo (raw_file_nme) VALUES (?)", ("file2.pdf",))
        adapter.commit()

        results = adapter.fetchall("SELECT ud_source_file_id FROM content_repo ORDER BY ud_source_file_id")
        assert results[0][0] == 1
        assert results[1][0] == 2

    def test_checksum_length_constraint(self, manager, adapter):
        """Test that content_checksum must be 64 chars or NULL."""
        manager.create_schema(specific_tables=["content_repo"])

        # NULL is allowed
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, content_checksum) VALUES (?, ?)",
            ("file1.pdf", None)
        )
        adapter.commit()

        # 64 chars is allowed
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, content_checksum) VALUES (?, ?)",
            ("file2.pdf", "a" * 64)
        )
        adapter.commit()

        # Invalid length should fail
        with pytest.raises(Exception):  # SQLite raises integrity error
            adapter.execute(
                "INSERT INTO content_repo (raw_file_nme, content_checksum) VALUES (?, ?)",
                ("file3.pdf", "abc123")  # Too short
            )
            adapter.commit()

    def test_file_status_constraint(self, manager, adapter):
        """Test that file_status must be Active, Inactive, or Archived."""
        manager.create_schema(specific_tables=["content_repo"])

        # Valid values
        for status in ["Active", "Inactive", "Archived"]:
            adapter.execute(
                "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
                (f"file_{status}.pdf", status)
            )
        adapter.commit()

        # NULL is allowed
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ("file_null.pdf", None)
        )
        adapter.commit()

        # Invalid value should fail
        with pytest.raises(Exception):  # SQLite raises integrity error
            adapter.execute(
                "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
                ("file_invalid.pdf", "InvalidStatus")
            )
            adapter.commit()

    def test_default_timestamps(self, manager, adapter):
        """Test that created_dt and last_modified_dt have default values."""
        manager.create_schema(specific_tables=["content_repo"])

        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
            ("handbook.pdf",)
        )
        adapter.commit()

        results = adapter.fetchall(
            "SELECT created_dt, last_modified_dt FROM content_repo"
        )
        assert len(results) == 1
        created_dt, last_modified_dt = results[0]
        assert created_dt is not None
        assert last_modified_dt is not None

    def test_update_record(self, manager, adapter):
        """Test updating content_repo record."""
        manager.create_schema(specific_tables=["content_repo"])

        # Insert
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ("handbook.pdf", "Active")
        )
        adapter.commit()

        # Update
        adapter.execute(
            "UPDATE content_repo SET file_status = ? WHERE raw_file_nme = ?",
            ("Archived", "handbook.pdf")
        )
        adapter.commit()

        # Verify
        results = adapter.fetchall(
            "SELECT file_status FROM content_repo WHERE raw_file_nme = ?",
            ("handbook.pdf",)
        )
        assert results[0][0] == "Archived"

    def test_delete_record(self, manager, adapter):
        """Test deleting content_repo record."""
        manager.create_schema(specific_tables=["content_repo"])

        # Insert
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
            ("handbook.pdf",)
        )
        adapter.commit()

        # Delete
        adapter.execute(
            "DELETE FROM content_repo WHERE raw_file_nme = ?",
            ("handbook.pdf",)
        )
        adapter.commit()

        # Verify
        results = adapter.fetchall("SELECT * FROM content_repo")
        assert len(results) == 0

    def test_query_by_file_status(self, manager, adapter):
        """Test querying by file_status."""
        manager.create_schema(specific_tables=["content_repo"])

        # Insert multiple records
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ("file1.pdf", "Active")
        )
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ("file2.pdf", "Active")
        )
        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ("file3.pdf", "Archived")
        )
        adapter.commit()

        # Query active files
        results = adapter.fetchall(
            "SELECT raw_file_nme FROM content_repo WHERE file_status = ? ORDER BY raw_file_nme",
            ("Active",)
        )
        assert len(results) == 2
        assert results[0][0] == "file1.pdf"
        assert results[1][0] == "file2.pdf"

    def test_default_version_number(self, manager, adapter):
        """Test that raw_file_version_nbr defaults to 1."""
        manager.create_schema(specific_tables=["content_repo"])

        adapter.execute(
            "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
            ("handbook.pdf",)
        )
        adapter.commit()

        results = adapter.fetchall(
            "SELECT raw_file_version_nbr FROM content_repo"
        )
        assert results[0][0] == 1
