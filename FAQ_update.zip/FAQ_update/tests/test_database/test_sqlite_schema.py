"""
Tests for SQLite schema and multi-dialect support.

Test coverage:
- SQLite adapter functionality
- SQLite schema creation
- Multi-dialect schema manager
- Database portability
"""

import pytest
from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)


class TestSQLiteAdapter:
    """Test SQLite database adapter."""

    def test_create_sqlite_adapter_in_memory(self):
        """Test creating in-memory SQLite adapter."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)

        assert adapter.dialect == DatabaseDialect.SQLITE
        assert adapter.database_path == ":memory:"
        assert adapter.enable_foreign_keys is True

    def test_sqlite_foreign_keys_enabled(self):
        """Test that foreign keys are enabled by default."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        adapter.connect()

        # Check PRAGMA foreign_keys
        result = adapter.fetchall("PRAGMA foreign_keys")
        assert result[0][0] == 1  # 1 = enabled

    def test_sqlite_execute_and_fetchall(self):
        """Test basic SQL execution."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)

        # Create a simple table
        adapter.execute("CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT)")
        adapter.execute("INSERT INTO test (name) VALUES ('Alice')")
        adapter.commit()

        # Fetch results
        results = adapter.fetchall("SELECT * FROM test")
        assert len(results) == 1
        assert results[0][1] == "Alice"  # name column

    def test_sqlite_context_manager(self):
        """Test SQLite adapter as context manager."""
        with create_adapter(DatabaseDialect.SQLITE, in_memory=True) as adapter:
            adapter.execute("CREATE TABLE test (id INTEGER)")
            adapter.execute("INSERT INTO test VALUES (1)")
            # Commit happens automatically on __exit__

        # Adapter should be closed after context

    def test_sqlite_parameterized_queries(self):
        """Test parameterized queries for SQL injection safety."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        adapter.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT)")

        # Use parameters
        adapter.execute("INSERT INTO users (email) VALUES (?)", ("user@example.com",))
        adapter.commit()

        results = adapter.fetchall("SELECT email FROM users WHERE email = ?", ("user@example.com",))
        assert len(results) == 1
        assert results[0][0] == "user@example.com"


class TestSchemaManager:
    """Test multi-dialect schema manager."""

    def test_init_with_sqlite(self):
        """Test initializing schema manager with SQLite."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)

        assert manager.dialect == DatabaseDialect.SQLITE
        assert manager.dependency_graph is not None
        assert len(manager.dependency_graph.get("tables", {})) == 8

    def test_create_sqlite_schema(self):
        """Test creating complete SQLite schema."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)

        # Create all tables
        result = manager.create_schema()

        assert "tables" in result
        assert len(result["tables"]) == 8

        # Verify all tables exist
        expected_tables = [
            "content_repo",
            "content_checksums",
            "faq_questions",
            "faq_answers",
            "faq_question_sources",
            "faq_answer_sources",
            "content_change_log",
            "faq_audit_log",
        ]

        for table in expected_tables:
            tables = adapter.fetchall(
                f"SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table,),
            )
            assert len(tables) == 1, f"Table {table} not created"

    def test_foreign_key_constraints_work(self):
        """Test that foreign key constraints are enforced."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Try to insert answer without question (should fail)
        with pytest.raises(Exception):  # Foreign key violation
            adapter.execute(
                "INSERT INTO faq_answers (question_id, answer_text) VALUES (99999, 'test')"
            )

    def test_cascade_delete_works(self):
        """Test ON DELETE CASCADE functionality."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Insert question
        adapter.execute(
            "INSERT INTO faq_questions (question_text) VALUES ('Test question?')"
        )
        question_id = adapter.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert answer
        adapter.execute(
            f"INSERT INTO faq_answers (question_id, answer_text) VALUES ({question_id}, 'Test answer')"
        )
        adapter.commit()

        # Verify answer exists
        answers = adapter.fetchall(f"SELECT * FROM faq_answers WHERE question_id = {question_id}")
        assert len(answers) == 1

        # Delete question (should cascade to answer)
        adapter.execute(f"DELETE FROM faq_questions WHERE question_id = {question_id}")
        adapter.commit()

        # Verify answer was deleted
        answers = adapter.fetchall(f"SELECT * FROM faq_answers WHERE question_id = {question_id}")
        assert len(answers) == 0

    def test_check_constraints_work(self):
        """Test CHECK constraints are enforced."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Try to insert content with invalid checksum length (should fail)
        with pytest.raises(Exception):  # CHECK constraint violation
            adapter.execute(
                "INSERT INTO content_checksums (content_checksum) VALUES ('too_short')"
            )

        # Try to insert invalid status (should fail)
        with pytest.raises(Exception):
            adapter.execute(
                f"INSERT INTO content_checksums (content_checksum, status) "
                f"VALUES ('{'a' * 64}', 'invalid_status')"
            )

    def test_schema_validation_sqlite(self):
        """Test schema validation for SQLite."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Validate schema
        result = manager.validate_schema()

        assert result.is_valid is True
        assert len(result.missing_tables) == 0
        assert len(result.errors) == 0

    def test_dry_run_mode(self):
        """Test dry-run mode doesn't create tables."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)

        # Dry run
        result = manager.create_schema(dry_run=True)

        assert len(result["tables"]) == 8  # Should report 8 tables

        # Verify NO tables were actually created
        tables = adapter.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
        assert len(tables) == 0

    def test_specific_tables_creation(self):
        """Test creating only specific tables with dependencies."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)

        # Create only faq_answers (should also create faq_questions due to dependency)
        result = manager.create_schema(specific_tables=["faq_answers"])

        assert "faq_answers" in result["tables"]
        assert "faq_questions" in result["tables"]  # Dependency
        assert len(result["tables"]) == 2


class TestDataTypeMappings:
    """Test data type mappings are correct."""

    def test_sqlite_autoincrement_works(self):
        """Test SQLite AUTOINCREMENT for primary keys."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Insert two questions
        adapter.execute("INSERT INTO faq_questions (question_text) VALUES ('Q1')")
        adapter.execute("INSERT INTO faq_questions (question_text) VALUES ('Q2')")
        adapter.commit()

        # Verify auto-incrementing IDs
        questions = adapter.fetchall("SELECT question_id FROM faq_questions ORDER BY question_id")
        assert questions[0][0] == 1
        assert questions[1][0] == 2

    def test_sqlite_timestamp_defaults(self):
        """Test SQLite timestamp defaults work."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Insert question
        adapter.execute("INSERT INTO faq_questions (question_text) VALUES ('Test')")
        adapter.commit()

        # Verify created_at was set
        result = adapter.fetchall("SELECT created_at FROM faq_questions")
        assert result[0][0] is not None  # Timestamp should exist

    def test_sqlite_boolean_as_integer(self):
        """Test SQLite stores booleans as integers."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # Insert with is_valid = TRUE (stored as 1)
        adapter.execute("INSERT INTO content_checksums (content_checksum) VALUES (?)", ("a" * 64,))
        checksum = "a" * 64
        adapter.execute("INSERT INTO faq_questions (question_text) VALUES ('Test')")
        q_id = adapter.execute("SELECT last_insert_rowid()").fetchone()[0]

        adapter.execute(
            f"INSERT INTO faq_question_sources (question_id, content_checksum, is_valid) "
            f"VALUES ({q_id}, '{checksum}', 1)"
        )
        adapter.commit()

        # Verify is_valid is stored as 1
        result = adapter.fetchall("SELECT is_valid FROM faq_question_sources")
        assert result[0][0] == 1  # Should be integer 1, not boolean


class TestSchemaIntegrity:
    """Test overall schema integrity."""

    def test_full_workflow(self):
        """Test a complete FAQ workflow in SQLite."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema()

        # 1. Insert content
        checksum = "a" * 64
        adapter.execute(
            f"INSERT INTO content_checksums (content_checksum, file_name) "
            f"VALUES ('{checksum}', 'handbook.pdf')"
        )

        # 2. Insert question
        adapter.execute("INSERT INTO faq_questions (question_text) VALUES ('How many sick days?')")
        q_id = adapter.execute("SELECT last_insert_rowid()").fetchone()[0]

        # 3. Insert answer
        adapter.execute(
            f"INSERT INTO faq_answers (question_id, answer_text) "
            f"VALUES ({q_id}, '12 sick days')"
        )
        a_id = adapter.execute("SELECT last_insert_rowid()").fetchone()[0]

        # 4. Link question to content
        adapter.execute(
            f"INSERT INTO faq_question_sources (question_id, content_checksum) "
            f"VALUES ({q_id}, '{checksum}')"
        )

        # 5. Link answer to content
        adapter.execute(
            f"INSERT INTO faq_answer_sources (answer_id, content_checksum) "
            f"VALUES ({a_id}, '{checksum}')"
        )

        adapter.commit()

        # Verify full chain exists
        result = adapter.fetchall(
            f"""
            SELECT q.question_text, a.answer_text, c.file_name
            FROM faq_questions q
            JOIN faq_answers a ON q.question_id = a.question_id
            JOIN faq_question_sources qs ON q.question_id = qs.question_id
            JOIN content_checksums c ON qs.content_checksum = c.content_checksum
            WHERE q.question_id = {q_id}
            """
        )

        assert len(result) == 1
        assert result[0][0] == "How many sick days?"
        assert result[0][1] == "12 sick days"
        assert result[0][2] == "handbook.pdf"
