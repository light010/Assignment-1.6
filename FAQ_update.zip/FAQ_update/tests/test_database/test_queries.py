"""
Tests for QueryTemplates.

Test coverage:
- SQL file loading
- Query template generation
- Parameter substitution
- Batch query helpers
"""

import pytest
from pathlib import Path
from granular_impact.database.queries import QueryTemplates


class TestQueryTemplates:
    """Test QueryTemplates functionality."""

    def test_get_faqs_requiring_regeneration(self):
        """Test FAQs requiring regeneration query generation."""
        sql = QueryTemplates.get_faqs_requiring_regeneration(
            catalog="test_catalog",
            schema="test_schema",
            detection_run_id="RUN_001",
        )

        # Verify catalog/schema substitution
        assert "test_catalog.test_schema" in sql

        # Verify detection run filter
        assert 'detection_run_id = "RUN_001"' in sql

        # Verify query structure
        assert "SELECT DISTINCT" in sql
        assert "content_change_log" in sql
        assert "faq_question_sources" in sql
        assert "requires_faq_regeneration = TRUE" in sql

    def test_get_faqs_requiring_regeneration_no_filter(self):
        """Test FAQs query without detection run filter."""
        sql = QueryTemplates.get_faqs_requiring_regeneration(
            catalog="prod",
            schema="faq",
        )

        # Should not have detection run filter
        assert 'detection_run_id =' not in sql or 'AND ccl.detection_run_id' not in sql

        # But should have catalog/schema
        assert "prod.faq" in sql

    def test_get_content_changes_summary(self):
        """Test content changes summary query."""
        sql = QueryTemplates.get_content_changes_summary(
            catalog="test_catalog",
            schema="test_schema",
            detection_run_id="RUN_002",
        )

        assert "test_catalog.test_schema" in sql
        assert 'detection_run_id = "RUN_002"' in sql

    def test_get_content_changes_summary_no_filter(self):
        """Test content changes summary without filter."""
        sql = QueryTemplates.get_content_changes_summary(
            catalog="prod",
            schema="faq",
        )

        assert "prod.faq" in sql

    def test_get_detection_run_summary(self):
        """Test detection run summary query."""
        sql = QueryTemplates.get_detection_run_summary(
            catalog="test_catalog",
            schema="test_schema",
            limit=5,
        )

        assert "test_catalog.test_schema" in sql
        assert "5" in sql  # Limit should be in SQL

    def test_get_active_faqs_with_sources(self):
        """Test active FAQs with sources query."""
        sql = QueryTemplates.get_active_faqs_with_sources(
            catalog="test_catalog",
            schema="test_schema",
            faq_id=123,
        )

        assert "test_catalog.test_schema" in sql
        assert "question_id = 123" in sql

    def test_get_active_faqs_with_sources_no_filter(self):
        """Test active FAQs query without FAQ filter."""
        sql = QueryTemplates.get_active_faqs_with_sources(
            catalog="prod",
            schema="faq",
        )

        assert "prod.faq" in sql
        # Should not have question_id filter
        assert "question_id =" not in sql or "AND q.question_id" not in sql

    def test_get_faqs_by_checksums_batch(self):
        """Test batch FAQ lookup by checksums."""
        template = QueryTemplates.get_faqs_by_checksums_batch(
            catalog="test_catalog",
            schema="test_schema",
        )

        # Verify it's a template with placeholder
        assert "{checksums}" in template
        assert "test_catalog.test_schema" in template
        assert "faq_question_sources" in template
        assert "faq_answer_sources" in template
        assert "UNION ALL" in template

        # Test placeholder substitution
        checksums = ["abc123", "def456"]
        checksum_list = ", ".join(f"'{c}'" for c in checksums)
        sql = template.format(checksums=checksum_list)

        assert "'abc123'" in sql
        assert "'def456'" in sql
        assert "{checksums}" not in sql

    def test_invalidate_faq_sources_batch(self):
        """Test batch invalidation query."""
        template = QueryTemplates.invalidate_faq_sources_batch(
            catalog="test_catalog",
            schema="test_schema",
        )

        # Verify template structure
        assert "{change_id}" in template
        assert "{checksum}" in template
        assert "test_catalog.test_schema" in template
        assert "faq_question_sources" in template
        assert "faq_answer_sources" in template
        assert "UPDATE" in template
        assert "is_valid = FALSE" in template

        # Test substitution
        sql = template.format(change_id=123, checksum="'abc123'")
        assert "123" in sql
        assert "'abc123'" in sql

    def test_insert_audit_log(self):
        """Test audit log insertion query."""
        template = QueryTemplates.insert_audit_log(
            catalog="test_catalog",
            schema="test_schema",
        )

        assert "INSERT INTO test_catalog.test_schema.faq_audit_log" in template
        assert "{change_id}" in template
        assert "{question_id}" in template
        assert "{answer_id}" in template
        assert "{detection_run_id}" in template


class TestQueryTemplatesSQLFileLoading:
    """Test SQL file loading functionality."""

    def test_load_sql_file_not_found(self):
        """Test loading non-existent SQL file raises error."""
        with pytest.raises(FileNotFoundError):
            QueryTemplates.load_sql_file("nonexistent/file.sql")

    def test_sql_dir_exists(self):
        """Test that SQL directory path is valid."""
        assert QueryTemplates.SQL_DIR.exists()
        assert QueryTemplates.SQL_DIR.is_dir()

    def test_query_files_exist(self):
        """Test that expected query SQL files exist."""
        expected_files = [
            "queries/get_faqs_requiring_regeneration.sql",
            "queries/get_content_diffs_summary.sql",
            "queries/get_detection_run_summary.sql",
            "queries/get_active_faqs_with_sources.sql",
        ]

        for file_path in expected_files:
            full_path = QueryTemplates.SQL_DIR / file_path
            assert full_path.exists(), f"Missing SQL file: {file_path}"


class TestQueryParameterSubstitution:
    """Test query parameter substitution edge cases."""

    def test_multiple_substitutions(self):
        """Test multiple parameter substitutions in same query."""
        sql = QueryTemplates.get_faqs_requiring_regeneration(
            catalog="cat1",
            schema="sch1",
            detection_run_id="run1",
        )

        # All substitutions should be present
        assert "cat1.sch1" in sql
        assert "run1" in sql

    def test_special_characters_in_params(self):
        """Test handling of special characters in parameters."""
        sql = QueryTemplates.get_detection_run_summary(
            catalog="my_catalog",
            schema="my_schema",
            limit=10,
        )

        assert "my_catalog.my_schema" in sql
        assert "10" in sql
