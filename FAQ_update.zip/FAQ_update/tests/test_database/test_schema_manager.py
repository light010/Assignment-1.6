"""
Tests for SchemaManager.

Test coverage:
- Dependency graph loading
- Schema creation with components
- Schema validation
- Dependency resolution
- Dry-run mode
"""

import pytest
import yaml
from pathlib import Path
from unittest.mock import Mock, MagicMock
from granular_impact.database.schema_manager import (
    SchemaManager,
    SchemaComponent,
    DeploymentMode,
    SchemaValidationResult,
)
from granular_impact.database.dialect import DatabaseDialect
from granular_impact.database.adapters import DatabaseAdapter


class MockAdapter(DatabaseAdapter):
    """Mock adapter for testing."""

    def __init__(self):
        super().__init__(DatabaseDialect.SQLITE)
        self.executed_queries = []

    def connect(self):
        return Mock()

    def execute(self, sql, params=None):
        self.executed_queries.append(sql)
        return Mock()

    def fetchall(self, sql, params=None):
        return []

    def commit(self):
        pass

    def close(self):
        pass


class TestSchemaManager:
    """Test SchemaManager functionality."""

    @pytest.fixture
    def mock_adapter(self):
        """Create mock database adapter."""
        return MockAdapter()

    @pytest.fixture
    def mock_dependency_graph(self):
        """Create mock dependency graph."""
        return {
            "tables": {
                "content_checksums": {
                    "file": "tables/01_content_checksums.sql",
                    "dependencies": [],
                    "order": 1,
                },
                "faq_questions": {
                    "file": "tables/02_faq_questions.sql",
                    "dependencies": [],
                    "order": 2,
                },
                "faq_answers": {
                    "file": "tables/03_faq_answers.sql",
                    "dependencies": ["faq_questions"],
                    "order": 3,
                },
            },
        }

    def test_init(self, mock_adapter, tmp_path):
        """Test SchemaManager initialization."""
        # Create mock dependency graph file
        meta_dir = tmp_path / "_meta"
        meta_dir.mkdir()
        graph_file = meta_dir / "dependency_graph.yaml"
        graph_file.write_text("tables: {}\n")

        manager = SchemaManager(
            adapter=mock_adapter,
            schema_dir=tmp_path,
        )

        assert manager.adapter == mock_adapter
        assert manager.dialect == DatabaseDialect.SQLITE

    def test_resolve_dependencies(self, mock_adapter, tmp_path, mock_dependency_graph):
        """Test dependency resolution."""
        # Setup
        meta_dir = tmp_path / "_meta"
        meta_dir.mkdir()
        graph_file = meta_dir / "dependency_graph.yaml"
        graph_file.write_text(yaml.dump(mock_dependency_graph))

        manager = SchemaManager(
            adapter=mock_adapter,
            schema_dir=tmp_path,
        )

        # Test: Resolve dependencies for faq_answers
        resolved = manager._resolve_dependencies(
            ["faq_answers"], mock_dependency_graph["tables"]
        )

        # Should include both faq_answers and its dependency faq_questions
        assert "faq_answers" in resolved
        assert "faq_questions" in resolved
        assert len(resolved) == 2

    def test_resolve_dependencies_no_duplicates(self, mock_adapter, tmp_path, mock_dependency_graph):
        """Test dependency resolution doesn't create duplicates."""
        meta_dir = tmp_path / "_meta"
        meta_dir.mkdir()

        graph_file = meta_dir / "dependency_graph.yaml"
        graph_file.write_text(yaml.dump(mock_dependency_graph))

        manager = SchemaManager(
            adapter=mock_adapter,
            schema_dir=tmp_path,
        )

        # Request same table multiple times
        resolved = manager._resolve_dependencies(
            ["faq_answers", "faq_answers", "faq_questions"],
            mock_dependency_graph["tables"],
        )

        # Should not have duplicates
        assert len(resolved) == len(set(resolved))

    def test_create_schema_dry_run(self, mock_adapter, tmp_path, mock_dependency_graph):
        """Test schema creation in dry-run mode."""
        # Setup
        meta_dir = tmp_path / "_meta"
        meta_dir.mkdir()

        graph_file = meta_dir / "dependency_graph.yaml"
        graph_file.write_text(yaml.dump(mock_dependency_graph))

        # Create mock SQL files
        tables_dir = tmp_path / "tables"
        tables_dir.mkdir()
        (tables_dir / "01_content_checksums.sql").write_text("CREATE TABLE content_checksums")
        (tables_dir / "02_faq_questions.sql").write_text("CREATE TABLE faq_questions")
        (tables_dir / "03_faq_answers.sql").write_text("CREATE TABLE faq_answers")

        manager = SchemaManager(
            adapter=mock_adapter,
            schema_dir=tmp_path,
        )

        # Execute dry run
        result = manager.create_schema(
            components=[SchemaComponent.TABLES],
            dry_run=True,
        )

        # Adapter execute should NOT be called in dry-run mode
        assert len(mock_adapter.executed_queries) == 0

        # Should return created tables list
        assert "tables" in result
        assert len(result["tables"]) == 3

    def test_schema_validation_result_str(self):
        """Test SchemaValidationResult string representation."""
        result = SchemaValidationResult(
            is_valid=False,
            missing_tables=["table1", "table2"],
            errors=["Error 1"],
            warnings=["Warning 1"],
        )

        str_result = str(result)
        assert "INVALID" in str_result
        assert "table1" in str_result
        assert "table2" in str_result
        assert "Error 1" in str_result
        assert "Warning 1" in str_result

    def test_schema_validation_result_valid(self):
        """Test valid schema validation result."""
        result = SchemaValidationResult(is_valid=True)

        str_result = str(result)
        assert "VALID" in str_result


class TestSchemaComponent:
    """Test SchemaComponent enum."""

    def test_enum_values(self):
        """Test SchemaComponent enum values."""
        assert SchemaComponent.TABLES.value == "tables"
        assert SchemaComponent.CONSTRAINTS.value == "constraints"
        assert SchemaComponent.INDEXES.value == "indexes"
        assert SchemaComponent.VIEWS.value == "views"
        assert SchemaComponent.ALL.value == "all"


class TestDeploymentMode:
    """Test DeploymentMode enum."""

    def test_enum_values(self):
        """Test DeploymentMode enum values."""
        assert DeploymentMode.CREATE.value == "create"
        assert DeploymentMode.UPDATE.value == "update"
        assert DeploymentMode.MIGRATE.value == "migrate"
        assert DeploymentMode.VALIDATE.value == "validate"
