"""Tests for DatabaseConnection class."""

import pytest
from unittest.mock import Mock, patch

# Skip all tests if pyspark is not available
pytest.importorskip("pyspark")

from granular_impact.database.connection import DatabaseConnection


class TestDatabaseConnection:
    """Test DatabaseConnection class."""

    @patch("granular_impact.database.connection.SparkSession")
    def test_initialization(self, mock_spark_session):
        """Test connection initialization."""
        conn = DatabaseConnection(
            catalog="test_catalog",
            schema="test_schema",
        )

        assert conn.catalog == "test_catalog"
        assert conn.schema == "test_schema"
        assert conn.use_unity_catalog is True

    @patch("granular_impact.database.connection.SparkSession")
    def test_get_fully_qualified_table_with_unity_catalog(self, mock_spark_session):
        """Test fully qualified table name with Unity Catalog."""
        conn = DatabaseConnection(
            catalog="prod",
            schema="faq",
            use_unity_catalog=True,
        )

        table = conn.get_fully_qualified_table("faq_questions")
        assert table == "prod.faq.faq_questions"

    @patch("granular_impact.database.connection.SparkSession")
    def test_get_fully_qualified_table_without_unity_catalog(self, mock_spark_session):
        """Test fully qualified table name without Unity Catalog."""
        conn = DatabaseConnection(
            catalog="prod",
            schema="faq",
            use_unity_catalog=False,
        )

        table = conn.get_fully_qualified_table("faq_questions")
        assert table == "faq.faq_questions"

    @patch("granular_impact.database.connection.SparkSession")
    def test_spark_session_lazy_initialization(self, mock_spark_session):
        """Test that Spark session is created on first access."""
        mock_builder = Mock()
        mock_spark_session.builder = mock_builder
        mock_builder.getOrCreate.return_value = Mock()

        conn = DatabaseConnection(catalog="test", schema="test")

        # Spark session should not be created yet
        assert conn._spark is None

        # Access spark property
        spark = conn.spark

        # Now it should be created
        assert spark is not None
        mock_builder.getOrCreate.assert_called_once()

    @patch("granular_impact.database.connection.SparkSession")
    def test_spark_session_cached(self, mock_spark_session):
        """Test that Spark session is cached after first access."""
        mock_builder = Mock()
        mock_spark_session.builder = mock_builder
        mock_session = Mock()
        mock_builder.getOrCreate.return_value = mock_session

        conn = DatabaseConnection(catalog="test", schema="test")

        # Access spark twice
        spark1 = conn.spark
        spark2 = conn.spark

        # Should return same instance
        assert spark1 is spark2

        # Builder should only be called once
        mock_builder.getOrCreate.assert_called_once()
