"""
Test suite for simplified base similarity module.

Tests core functionality with minimal complexity:
- SimilarityResult dataclass
- BaseSimilarityCalculator ABC
- Simple preprocessing and tokenization
"""

import pytest
from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)
from granular_impact.similarity import JaccardSimilarityCalculator


class TestSimilarityResult:
    """Test SimilarityResult dataclass."""

    def test_similarity_result_creation(self):
        """Test creating SimilarityResult with required fields."""
        result = SimilarityResult(
            score=0.75,
            text1="hello world",
            text2="hello there",
            algorithm="test",
            metadata={"key": "value"}
        )

        assert result.score == 0.75
        assert result.text1 == "hello world"
        assert result.text2 == "hello there"
        assert result.algorithm == "test"
        assert result.metadata == {"key": "value"}

    def test_similarity_result_validates_score_range(self):
        """Test that score must be between 0.0 and 1.0."""
        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            SimilarityResult(
                score=1.5,
                text1="a",
                text2="b",
                algorithm="test",
                metadata={}
            )

        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            SimilarityResult(
                score=-0.1,
                text1="a",
                text2="b",
                algorithm="test",
                metadata={}
            )

    def test_similarity_result_is_similar(self):
        """Test is_similar threshold comparison."""
        result = SimilarityResult(
            score=0.8,
            text1="a",
            text2="b",
            algorithm="test",
            metadata={}
        )

        assert result.is_similar(0.7) is True
        assert result.is_similar(0.8) is True
        assert result.is_similar(0.9) is False

    def test_similarity_result_to_dict(self):
        """Test converting result to dictionary."""
        result = SimilarityResult(
            score=0.5,
            text1="test1",
            text2="test2",
            algorithm="algo",
            metadata={"foo": "bar"}
        )

        d = result.to_dict()

        assert d["score"] == 0.5
        assert d["text1"] == "test1"
        assert d["text2"] == "test2"
        assert d["algorithm"] == "algo"
        assert d["metadata"] == {"foo": "bar"}


class TestBaseSimilarityCalculator:
    """Test BaseSimilarityCalculator ABC."""

    def test_cannot_instantiate_abstract_class(self):
        """Test that abstract base class cannot be instantiated."""
        with pytest.raises(TypeError):
            BaseSimilarityCalculator()

    def test_concrete_implementation_required_methods(self):
        """Test that concrete implementations must implement required methods."""
        calc = JaccardSimilarityCalculator()

        # Must have compute_similarity
        assert hasattr(calc, "compute_similarity")
        assert callable(calc.compute_similarity)

        # Must have get_algorithm_name
        assert hasattr(calc, "get_algorithm_name")
        assert callable(calc.get_algorithm_name)

        # Must return string
        assert isinstance(calc.get_algorithm_name(), str)


class TestSimplePreprocessing:
    """Test simplified preprocessing (no spacy, no caching, no lemmatization)."""

    def test_preprocess_text_lowercase(self):
        """Test lowercase normalization."""
        calc = JaccardSimilarityCalculator(lowercase=True)

        processed = calc.preprocess_text("HELLO World")

        assert processed == "hello world"

    def test_preprocess_text_no_lowercase(self):
        """Test preserving case when disabled."""
        calc = JaccardSimilarityCalculator(lowercase=False)

        processed = calc.preprocess_text("HELLO World")

        assert processed == "HELLO World"

    def test_preprocess_text_remove_punctuation(self):
        """Test punctuation removal."""
        calc = JaccardSimilarityCalculator(
            lowercase=False,
            remove_punctuation=True
        )

        processed = calc.preprocess_text("Hello, world!")

        assert processed == "Hello world"

    def test_preprocess_text_keep_punctuation(self):
        """Test preserving punctuation when disabled."""
        calc = JaccardSimilarityCalculator(
            lowercase=False,
            remove_punctuation=False
        )

        processed = calc.preprocess_text("Hello, world!")

        assert processed == "Hello, world!"

    def test_preprocess_handles_none(self):
        """Test that None input returns empty string."""
        calc = JaccardSimilarityCalculator()

        processed = calc.preprocess_text(None)

        assert processed == ""

    def test_preprocess_normalizes_whitespace(self):
        """Test that extra whitespace is normalized."""
        calc = JaccardSimilarityCalculator()

        processed = calc.preprocess_text("hello    world   test")

        assert processed == "hello world test"


class TestSimpleTokenization:
    """Test simplified tokenization (basic split, no spacy, no caching)."""

    def test_tokenize_basic_split(self):
        """Test basic whitespace tokenization."""
        calc = JaccardSimilarityCalculator()

        tokens = calc.tokenize("hello world test")

        assert tokens == ["hello", "world", "test"]

    def test_tokenize_filters_by_min_length(self):
        """Test minimum token length filtering."""
        calc = JaccardSimilarityCalculator(min_token_length=3)

        tokens = calc.tokenize("i am a developer")

        # Only "developer" has length >= 3
        assert "developer" in tokens
        assert "i" not in tokens
        assert "am" not in tokens
        assert "a" not in tokens

    def test_tokenize_empty_string(self):
        """Test tokenizing empty string."""
        calc = JaccardSimilarityCalculator()

        tokens = calc.tokenize("")

        assert tokens == []

    def test_tokenize_single_word(self):
        """Test tokenizing single word."""
        calc = JaccardSimilarityCalculator()

        tokens = calc.tokenize("hello")

        assert tokens == ["hello"]


class TestSimplifiedInitialization:
    """Test simplified initialization (3 params instead of 12)."""

    def test_default_initialization(self):
        """Test default parameter values."""
        calc = JaccardSimilarityCalculator()

        assert calc.lowercase is True
        assert calc.remove_punctuation is True
        assert calc.min_token_length == 1

    def test_custom_initialization(self):
        """Test custom parameter values."""
        calc = JaccardSimilarityCalculator(
            lowercase=False,
            remove_punctuation=False,
            min_token_length=3
        )

        assert calc.lowercase is False
        assert calc.remove_punctuation is False
        assert calc.min_token_length == 3


class TestRemovedFeatures:
    """Test that overcomplicated features are removed."""

    def test_no_spacy_integration(self):
        """Test that spacy integration is removed."""
        calc = JaccardSimilarityCalculator()

        # Should not have spacy-related attributes
        assert not hasattr(calc, "use_spacy")
        assert not hasattr(calc, "spacy_model")
        assert not hasattr(calc, "lemmatize")
        assert not hasattr(calc, "_nlp")

    def test_no_caching(self):
        """Test that caching is removed."""
        calc = JaccardSimilarityCalculator()

        # Should not have caching attributes
        assert not hasattr(calc, "enable_cache")
        assert not hasattr(calc, "cache_size")
        assert not hasattr(calc, "_tokenize_cached")

    def test_no_stopwords(self):
        """Test that stopword removal is removed."""
        calc = JaccardSimilarityCalculator()

        # Should not have stopword attributes
        assert not hasattr(calc, "remove_stopwords")
        assert not hasattr(calc, "stopwords_language")
        assert not hasattr(calc, "custom_stopwords")
        assert not hasattr(calc, "_stopwords")

    def test_no_batch_similarity_in_base(self):
        """Test that batch processing is removed from base."""
        calc = JaccardSimilarityCalculator()

        # Concrete implementations can add batch if needed
        # But base class should not have it
        # (We'll check this in base module directly)

    def test_no_unicode_normalization(self):
        """Test that unicode normalization is removed."""
        calc = JaccardSimilarityCalculator()

        # Should not have unicode normalization
        assert not hasattr(calc, "normalize_unicode")

    def test_no_dos_protection(self):
        """Test that DoS protection (max_text_length) is removed."""
        calc = JaccardSimilarityCalculator()

        # Should not have max_text_length
        assert not hasattr(calc, "max_text_length")

        # Should not have validate_texts method
        assert not hasattr(calc, "validate_texts")


class TestSimilarityResultSimplification:
    """Test that SimilarityResult is simplified."""

    def test_no_tokens_fields(self):
        """Test that tokens1 and tokens2 fields are removed."""
        result = SimilarityResult(
            score=0.8,
            text1="a",
            text2="b",
            algorithm="test",
            metadata={}
        )

        # Should not have token fields
        assert not hasattr(result, "tokens1")
        assert not hasattr(result, "tokens2")

    def test_no_processing_time(self):
        """Test that processing_time_ms field is removed (or optional)."""
        result = SimilarityResult(
            score=0.8,
            text1="a",
            text2="b",
            algorithm="test",
            metadata={}
        )

        # Either removed or optional - both are acceptable
        # If kept, it should be optional
        pass


class TestBackwardCompatibilityBreaking:
    """Test that breaking changes are acceptable (as per requirements)."""

    def test_old_initialization_fails(self):
        """Test that old initialization with removed params fails."""
        # This SHOULD fail - breaking changes are acceptable
        with pytest.raises(TypeError):
            JaccardSimilarityCalculator(
                use_spacy=True,
                lemmatize=True,
                remove_stopwords=True
            )

    def test_batch_result_class_removed(self):
        """Test that BatchSimilarityResult class is removed."""
        # This should fail when we try to import it
        try:
            from granular_impact.similarity.base import BatchSimilarityResult
            # If import succeeds, the class still exists (should be removed)
            pytest.fail("BatchSimilarityResult should be removed")
        except ImportError:
            # Expected - class should not exist
            pass
