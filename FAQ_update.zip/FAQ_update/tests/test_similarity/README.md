# Similarity Module Tests

Concise, effective test suite for the simplified similarity module.

## Test Structure

```
tests/test_similarity/
├── README.md                      # This file
├── __init__.py                    # Package marker
├── test_base.py                   # Base module tests (SimilarityResult, preprocessing, tokenization)
├── test_jaccard_sim.py            # Jaccard algorithm tests
├── test_difflib_sim.py            # Difflib algorithm tests
├── test_bm25_sim.py               # BM25 algorithm tests
└── test_hybrid.py                 # Hybrid multi-algorithm tests
```

## Test Coverage

### Base Module ([test_base.py](test_base.py))

Tests core functionality with minimal complexity:
- **SimilarityResult dataclass**: Score validation, threshold comparison, dictionary conversion
- **BaseSimilarityCalculator ABC**: Abstract class enforcement, required methods
- **Simple preprocessing**: Lowercase, punctuation removal, whitespace normalization
- **Simple tokenization**: Whitespace split, minimum length filtering
- **Removed features verification**: No spacy, no caching, no batch processing, no stopwords

### Jaccard Algorithm ([test_jaccard_sim.py](test_jaccard_sim.py))

Tests Jaccard set-based similarity:
- **Basic functionality**: Initialization, algorithm name, validation
- **Factory methods**: `for_faq_content()` optimized configuration
- **Compute similarity**: Identical texts (1.0), different texts (0.0), partial overlap
- **Metadata**: Intersection size, union size, set sizes, n-gram configuration
- **N-gram support**: Unigrams, bigrams, trigrams, character n-grams
- **Preprocessing**: Lowercase, punctuation removal, number preservation
- **Weighted Jaccard**: Custom token weights, domain-specific emphasis
- **FAQ content detection**: Numeric changes, date changes, identical/different FAQs
- **Removed features verification**: No batch processing, no caching, no performance tracking

### Difflib Algorithm ([test_difflib_sim.py](test_difflib_sim.py))

Tests sequence matching similarity:
- Character-level and token-level comparison
- Autojunk parameter handling
- Real-world FAQ scenarios (numeric changes, date changes)

### BM25 Algorithm ([test_bm25_sim.py](test_bm25_sim.py))

Tests BM25 ranking function:
- Document frequency calculation
- IDF scoring
- Corpus initialization
- FAQ content optimization

### Hybrid Multi-Algorithm ([test_hybrid.py](test_hybrid.py))

Tests weighted combination of algorithms:
- **Basic functionality**: Default weights, custom weights, validation
- **Compute similarity**: Identical texts, different texts, numeric changes
- **Metadata**: Individual algorithm scores, weights, early exit information
- **Early exit optimization**: Trigger conditions, disabled by default, performance benefits
- **Factory methods**: `for_modification_detection()`, `for_general_similarity()`
- **Algorithm breakdown**: Detailed score breakdown from each algorithm
- **PolicyContentSimilarity**: Specialized policy classifier, `is_modification()`, `classify_change()`
- **Real-world scenarios**: Date changes, number changes, major rewrites
- **Removed features verification**: No batch processing, no caching, no performance tracking

## Running Tests

### Run All Similarity Tests

```bash
# From project root
pytest tests/test_similarity/ -v

# With coverage
pytest tests/test_similarity/ --cov=granular_impact.similarity --cov-report=html
```

### Run Specific Test Files

```bash
# Base module tests
pytest tests/test_similarity/test_base.py -v

# Jaccard tests
pytest tests/test_similarity/test_jaccard_sim.py -v

# Difflib tests
pytest tests/test_similarity/test_difflib_sim.py -v

# BM25 tests
pytest tests/test_similarity/test_bm25_sim.py -v

# Hybrid tests
pytest tests/test_similarity/test_hybrid.py -v
```

### Run Specific Test Classes

```bash
# Test Jaccard calculator
pytest tests/test_similarity/test_jaccard_sim.py::TestJaccardBasicFunctionality -v

# Test hybrid early exit
pytest tests/test_similarity/test_hybrid.py::TestHybridEarlyExit -v

# Test policy classifier
pytest tests/test_similarity/test_hybrid.py::TestPolicyContentSimilarity -v
```

## Design Principles

### Simplicity Over Complexity
- Removed spacy integration (complex NLP dependency)
- Removed caching (premature optimization)
- Removed batch processing (not needed for current use case)
- Removed async/parallel processing (unnecessary complexity)
- Removed performance tracking (can be added when needed)

### Focused Test Coverage
- Each test validates one specific behavior
- Clear test names describe what is tested
- Minimal fixtures and dependencies
- Fast execution (all tests run in <5 seconds)

### Clean Architecture
- No redundant test files or versioned copies
- No deprecated features tested
- Tests match current implementation
- Easy to understand and maintain

## Test Categories

### Unit Tests
- Individual algorithm implementations (Jaccard, Difflib, BM25)
- Core functionality (preprocessing, tokenization, validation)
- Edge cases (empty strings, None values, extreme values)

### Integration Tests
- Hybrid algorithm combining multiple calculators
- Factory methods with pre-configured settings
- Real-world FAQ scenarios

### Feature Verification Tests
- **Removed Features**: Verify that deprecated complexity is removed
- **Simplified Features**: Verify that simplified implementations work correctly

## Key Differences from Previous Versions

### Removed (Deprecated)
- ❌ `test_base.py` - V2 with spacy, caching, batch processing
- ❌ `test_base_v3_batch.py` - V3 batch processing features
- ❌ `test_base_v3_caching.py` - V3 caching features
- ❌ `test_base_v3_spacy.py` - V3 spacy integration
- ❌ `test_jaccard.py` - Old Jaccard with removed features
- ❌ `test_hybrid_v8.py` - Old hybrid with complex features
- ❌ `test_no_embeddings.py` - Embedding tests (embeddings removed)
- ❌ `test_performance.py` - Performance benchmarks (moved to profiling)

### Kept (Current)
- ✅ `test_base.py` - Clean base module tests
- ✅ `test_jaccard_sim.py` - Jaccard algorithm tests
- ✅ `test_difflib_sim.py` - Difflib algorithm tests
- ✅ `test_bm25_sim.py` - BM25 algorithm tests
- ✅ `test_hybrid.py` - Hybrid multi-algorithm tests

## Coverage Requirements

- **Minimum Line Coverage**: 85%
- **Critical Paths**: 100% coverage required for:
  - Input validation
  - Algorithm core logic
  - Factory methods
  - Early exit optimization

### Generate Coverage Report

```bash
# HTML report
pytest tests/test_similarity/ --cov=granular_impact.similarity --cov-report=html

# Terminal report
pytest tests/test_similarity/ --cov=granular_impact.similarity --cov-report=term-missing
```

## Adding New Tests

### Checklist

1. [ ] Create test in appropriate file (`test_<algorithm>.py` or `test_<algorithm>_sim.py`)
2. [ ] Follow naming convention: `test_<what_is_tested>`
3. [ ] Include docstring explaining what is tested
4. [ ] Use descriptive assertion messages
5. [ ] Keep test simple and focused on one behavior
6. [ ] Run test to ensure it passes
7. [ ] Check coverage impact

### Example New Test

```python
import pytest
from granular_impact.similarity import JaccardSimilarityCalculator

class TestNewFeature:
    """Test suite for new feature."""

    def test_new_functionality(self):
        """Test that new functionality works correctly."""
        # Arrange
        calc = JaccardSimilarityCalculator()

        # Act
        result = calc.compute_similarity("text1", "text2")

        # Assert
        assert result.score >= 0.0, "Score should be non-negative"
```

## Troubleshooting

### Test Failures

```bash
# Run with verbose output
pytest tests/test_similarity/test_jaccard_sim.py::test_failing_test -vvs

# Run with debugging
pytest tests/test_similarity/test_jaccard_sim.py::test_failing_test --pdb
```

### Import Errors

```bash
# Ensure module is installed
pip install -e .

# Check PYTHONPATH
echo $PYTHONPATH
```

## Contributing

1. Write tests following the simplicity principles
2. Ensure all tests pass
3. Check coverage (must be ≥85%)
4. Update README if adding new test categories
5. Follow existing patterns and naming conventions

## References

- [Pytest Documentation](https://docs.pytest.org/)
- [Similarity Module README](../../granular_impact/similarity/README.md)
- [Python Testing Best Practices](https://docs.python-guide.org/writing/tests/)