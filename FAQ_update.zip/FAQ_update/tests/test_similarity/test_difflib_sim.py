"""
Test suite for simplified difflib similarity calculators.

Tests core difflib functionality:
- Character-level similarity computation
- Token-level similarity computation
- Diff block generation
- Unified diff output
- Factory functions for common use cases
"""

import pytest
from granular_impact.similarity.difflib_sim import (
    DifflibSimilarityCalculator,
    TokenBasedDifflibCalculator,
    DiffBlock,
    create_faq_modification_detector,
    create_character_level_analyzer,
    create_fast_diff_calculator,
)
from granular_impact.similarity.base import SimilarityResult


class TestDifflibBasicFunctionality:
    """Test basic difflib calculator functionality."""

    def test_identical_text(self):
        """Test that identical texts return score ~1.0."""
        calc = DifflibSimilarityCalculator()

        result = calc.compute_similarity(
            "This is a test",
            "This is a test"
        )

        assert isinstance(result, SimilarityResult)
        assert result.score >= 0.99
        assert result.algorithm == "difflib"

    def test_completely_different_texts(self):
        """Test that completely different texts return low score."""
        calc = DifflibSimilarityCalculator()

        result = calc.compute_similarity(
            "apple orange banana",
            "car truck motorcycle"
        )

        assert result.score < 0.3

    def test_numeric_change_detection(self):
        """Test detection of numeric changes like '10' -> '12'."""
        calc = DifflibSimilarityCalculator(remove_punctuation=False)

        result = calc.compute_similarity(
            "Employees receive 10 sick days per year",
            "Employees receive 12 sick days per year"
        )

        # Should detect high similarity but not perfect
        assert 0.85 <= result.score <= 0.98

    def test_date_change_detection(self):
        """Test detection of date changes."""
        calc = DifflibSimilarityCalculator(remove_punctuation=False)

        result = calc.compute_similarity(
            "Policy effective January 1, 2025",
            "Policy effective February 1, 2025"
        )

        # High similarity but with detected change
        assert 0.80 <= result.score <= 0.95
        assert result.metadata["operations"]["replace"] > 0


class TestDifflibMetadata:
    """Test metadata in difflib results."""

    def test_metadata_includes_core_fields(self):
        """Test that metadata includes all expected fields."""
        calc = DifflibSimilarityCalculator()

        result = calc.compute_similarity(
            "hello world",
            "hello there"
        )

        # Core metadata
        assert "ratio" in result.metadata
        assert "matching_blocks" in result.metadata
        assert "matching_characters" in result.metadata
        assert "text1_length" in result.metadata
        assert "text2_length" in result.metadata

        # Operations
        assert "operations" in result.metadata
        ops = result.metadata["operations"]
        assert all(key in ops for key in ["replace", "delete", "insert", "equal"])


class TestDiffBlockGeneration:
    """Test diff block generation functionality."""

    def test_get_diff_blocks(self):
        """Test generating diff blocks."""
        calc = DifflibSimilarityCalculator()

        diff_blocks = calc.get_diff_blocks(
            "The employee receives 10 days",
            "The employee receives 12 days"
        )

        assert isinstance(diff_blocks, list)
        assert len(diff_blocks) > 0
        assert all(isinstance(block, DiffBlock) for block in diff_blocks)

    def test_diff_block_structure(self):
        """Test that diff blocks have correct structure."""
        calc = DifflibSimilarityCalculator()

        diff_blocks = calc.get_diff_blocks("abc", "adc")

        for block in diff_blocks:
            assert block.tag in ["replace", "delete", "insert", "equal"]
            assert hasattr(block, "i1") and hasattr(block, "i2")
            assert hasattr(block, "j1") and hasattr(block, "j2")
            assert hasattr(block, "text1") and hasattr(block, "text2")


class TestUnifiedDiff:
    """Test unified diff generation."""

    def test_unified_diff_format(self):
        """Test generating unified diff output."""
        calc = DifflibSimilarityCalculator()

        unified = calc.get_unified_diff(
            "Line 1\nLine 2\nLine 3",
            "Line 1\nLine 2 modified\nLine 3",
            context_lines=1
        )

        assert isinstance(unified, list)
        assert len(unified) > 0

    def test_unified_diff_with_context(self):
        """Test unified diff with different context line counts."""
        calc = DifflibSimilarityCalculator()

        diff_1 = calc.get_unified_diff(
            "A\nB\nC\nD\nE",
            "A\nB\nX\nD\nE",
            context_lines=1
        )
        diff_3 = calc.get_unified_diff(
            "A\nB\nC\nD\nE",
            "A\nB\nX\nD\nE",
            context_lines=3
        )

        # More context should result in more or equal lines
        assert len(diff_3) >= len(diff_1)


class TestTokenBasedDifflib:
    """Test token-based (word-level) difflib similarity."""

    def test_token_based_similarity(self):
        """Test token-based comparison."""
        calc = TokenBasedDifflibCalculator()

        result = calc.compute_similarity(
            "The quick brown fox",
            "The fast brown fox"
        )

        assert isinstance(result, SimilarityResult)
        assert result.algorithm == "difflib_token"
        assert 0.0 <= result.score <= 1.0

    def test_token_based_vs_character_based(self):
        """Test that token-based differs from character-based for word changes."""
        char_calc = DifflibSimilarityCalculator()
        token_calc = TokenBasedDifflibCalculator()

        char_result = char_calc.compute_similarity(
            "The employee works here",
            "The staff works here"
        )
        token_result = token_calc.compute_similarity(
            "The employee works here",
            "The staff works here"
        )

        # Token-based should recognize full word replacement
        # Character-based sees more character-level similarity
        assert token_result.score != char_result.score

    def test_token_based_metadata(self):
        """Test token-based metadata includes token counts."""
        calc = TokenBasedDifflibCalculator()

        result = calc.compute_similarity(
            "hello world",
            "hello there"
        )

        assert "matching_tokens" in result.metadata
        assert "tokens1_count" in result.metadata
        assert "tokens2_count" in result.metadata
        assert result.metadata["tokens1_count"] > 0

    def test_token_diff_blocks(self):
        """Test generating token-level diff blocks."""
        calc = TokenBasedDifflibCalculator()

        diff_blocks = calc.get_token_diff_blocks(
            "quick brown fox",
            "fast brown fox"
        )

        assert isinstance(diff_blocks, list)
        assert len(diff_blocks) > 0


class TestDifflibConfiguration:
    """Test configuration options."""

    def test_autojunk_parameter(self):
        """Test autojunk parameter."""
        calc_with = DifflibSimilarityCalculator(autojunk=True)
        calc_without = DifflibSimilarityCalculator(autojunk=False)

        result_with = calc_with.compute_similarity("hello world", "hello there")
        result_without = calc_without.compute_similarity("hello world", "hello there")

        assert result_with.score >= 0
        assert result_without.score >= 0

    def test_quick_ratio_mode(self):
        """Test quick_ratio mode for faster computation."""
        calc = DifflibSimilarityCalculator(use_quick_ratio=True)

        result = calc.compute_similarity("hello world", "hello there")

        assert result.score >= 0

    def test_punctuation_removal_option(self):
        """Test that punctuation removal can be controlled."""
        calc_remove = DifflibSimilarityCalculator(remove_punctuation=True)
        calc_keep = DifflibSimilarityCalculator(remove_punctuation=False)

        result_remove = calc_remove.compute_similarity("Hello, world!", "Hello world")
        result_keep = calc_keep.compute_similarity("Hello, world!", "Hello world")

        # Without punctuation, should be more similar
        assert result_remove.score >= result_keep.score


class TestFactoryFunctions:
    """Test factory functions for common use cases."""

    def test_faq_modification_detector(self):
        """Test FAQ modification detector factory."""
        calc = create_faq_modification_detector()

        result = calc.compute_similarity(
            "Employees get 10 sick days",
            "Employees get 12 sick days"
        )

        # Should detect the numeric change with high similarity
        assert 0.85 <= result.score <= 0.97

    def test_character_level_analyzer(self):
        """Test character-level analyzer factory."""
        calc = create_character_level_analyzer()

        result = calc.compute_similarity("ABC123", "ABC456")

        # Should detect character-level differences
        assert 0.0 < result.score < 1.0

    def test_fast_diff_calculator(self):
        """Test fast diff calculator factory."""
        calc = create_fast_diff_calculator()

        result = calc.compute_similarity("hello world", "hello there")

        assert result.score >= 0


class TestValidation:
    """Test input validation."""

    def test_empty_text_raises_error(self):
        """Test that empty texts raise error."""
        calc = DifflibSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("", "test")

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("test", "")

    def test_none_text_raises_error(self):
        """Test that None texts raise error."""
        calc = DifflibSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity(None, "test")

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity("test", None)

    def test_whitespace_only_text_raises_error(self):
        """Test that whitespace-only texts raise error."""
        calc = DifflibSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("   ", "test")

    def test_single_character_texts(self):
        """Test handling of single character texts."""
        calc = DifflibSimilarityCalculator()

        result = calc.compute_similarity("a", "b")
        assert result.score == 0.0

        result = calc.compute_similarity("a", "a")
        assert result.score == 1.0


class TestFAQScenarios:
    """Test real-world FAQ scenarios."""

    def test_detects_policy_number_changes(self):
        """Test detection of policy number changes."""
        calc = DifflibSimilarityCalculator(remove_punctuation=False)

        result = calc.compute_similarity(
            "Employees receive 15 vacation days and 10 sick days per year",
            "Employees receive 15 vacation days and 12 sick days per year"
        )

        # Should be high similarity but detect the change
        assert result.score >= 0.90
        assert result.metadata["operations"]["replace"] > 0

    def test_preserves_dates(self):
        """Test that dates are preserved when punctuation removal is disabled."""
        calc = DifflibSimilarityCalculator(
            remove_punctuation=False,
            lowercase=False
        )

        result = calc.compute_similarity(
            "Effective date: January 1, 2025",
            "Effective date: January 15, 2025"
        )

        # Should detect the date change
        assert result.score < 1.0
        ops = result.metadata["operations"]
        has_change = ops["replace"] > 0 or ops["insert"] > 0 or ops["delete"] > 0
        assert has_change


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
