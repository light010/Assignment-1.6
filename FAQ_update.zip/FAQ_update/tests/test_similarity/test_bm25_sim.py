"""
Test suite for simplified BM25 similarity calculator.

Tests core BM25 functionality with minimal complexity:
- BM25 algorithm correctness
- Factory methods for FAQ detection
- Normalization to [0, 1]
- Simple preprocessing and tokenization
- No batch processing, no persistence, no caching
"""

import pytest
import math
from granular_impact.similarity.bm25_sim import BM25SimilarityCalculator
from granular_impact.similarity.base import SimilarityResult


class TestBM25BasicFunctionality:
    """Test basic BM25 calculator functionality."""

    def test_initialization_default_params(self):
        """Test default initialization parameters."""
        calc = BM25SimilarityCalculator()

        assert calc.k1 == 1.5
        assert calc.b == 0.75
        assert calc.lowercase is True
        assert calc.remove_punctuation is True
        assert calc.min_token_length == 1

    def test_initialization_custom_params(self):
        """Test custom initialization parameters."""
        calc = BM25SimilarityCalculator(
            k1=1.2,
            b=0.5,
            lowercase=False,
            remove_punctuation=False,
            min_token_length=2,
        )

        assert calc.k1 == 1.2
        assert calc.b == 0.5
        assert calc.lowercase is False
        assert calc.remove_punctuation is False
        assert calc.min_token_length == 2

    def test_get_algorithm_name(self):
        """Test algorithm name."""
        calc = BM25SimilarityCalculator()

        assert calc.get_algorithm_name() == "bm25"


class TestBM25FactoryMethods:
    """Test factory methods for FAQ-optimized configurations."""

    def test_for_faq_modification_detection(self):
        """Test FAQ modification detection factory method."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        assert calc.k1 == 1.5
        assert calc.b == 0.75
        assert calc.lowercase is True
        assert calc.remove_punctuation is False  # Preserves numbers, dates
        assert calc.min_token_length == 1

    def test_faq_factory_detects_numeric_changes(self):
        """Test that FAQ factory method detects numeric changes."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        result = calc.compute_similarity(
            "Employees receive 10 vacation days",
            "Employees receive 15 vacation days",
        )

        # Should detect the number change (10 vs 15)
        # Similarity should be high but not perfect
        assert 0.5 < result.score < 1.0
        assert result.score < 0.99  # Not identical


class TestBM25ComputeSimilarity:
    """Test compute_similarity method."""

    def test_identical_texts(self):
        """Test that identical texts have high similarity (BM25 with 2-doc corpus)."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity(
            "hello world test",
            "hello world test",
        )

        # BM25 with small corpus doesn't give perfect score for identical texts
        # This is expected behavior since IDF is low when both docs have same words
        assert result.score > 0.5  # Reasonable similarity for BM25
        assert result.text1 == "hello world test"
        assert result.text2 == "hello world test"
        assert result.algorithm == "bm25"

    def test_completely_different_texts(self):
        """Test that completely different texts have low similarity."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity(
            "apple orange banana",
            "car truck motorcycle",
        )

        assert result.score < 0.6  # Low similarity

    def test_similar_texts(self):
        """Test texts with high overlap."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity(
            "the quick brown fox jumps",
            "the quick brown dog runs",
        )

        # 3 common words: the, quick, brown
        assert 0.5 < result.score < 0.95

    def test_returns_similarity_result(self):
        """Test that result is a SimilarityResult object."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        assert isinstance(result, SimilarityResult)
        assert hasattr(result, "score")
        assert hasattr(result, "text1")
        assert hasattr(result, "text2")
        assert hasattr(result, "algorithm")
        assert hasattr(result, "metadata")


class TestBM25Metadata:
    """Test metadata in BM25 results."""

    def test_metadata_contains_bm25_info(self):
        """Test that metadata contains BM25-specific information."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("hello world", "hello there")

        assert "bm25_raw_score" in result.metadata
        assert "k1" in result.metadata
        assert "b" in result.metadata
        assert "avgdl" in result.metadata
        assert "doc_length" in result.metadata
        assert "query_length" in result.metadata

    def test_metadata_values_are_correct(self):
        """Test that metadata values are correct."""
        calc = BM25SimilarityCalculator(k1=1.2, b=0.5)

        result = calc.compute_similarity("a b c", "d e f g")

        assert result.metadata["k1"] == 1.2
        assert result.metadata["b"] == 0.5
        assert result.metadata["query_length"] == 3  # a, b, c
        assert result.metadata["doc_length"] == 4  # d, e, f, g
        assert result.metadata["avgdl"] == 3.5  # (3 + 4) / 2

    def test_raw_score_is_positive(self):
        """Test that raw BM25 score is positive for overlapping terms."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("hello world", "hello there")

        # "hello" is in both, so raw score should be positive
        assert result.metadata["bm25_raw_score"] > 0


class TestBM25Normalization:
    """Test score normalization to [0, 1]."""

    def test_score_is_between_0_and_1(self):
        """Test that normalized score is always between 0 and 1."""
        calc = BM25SimilarityCalculator()

        # Test various text pairs
        test_cases = [
            ("hello", "world"),
            ("same text", "same text"),
            ("a b c", "d e f"),
            ("the quick brown fox", "the lazy brown dog"),
        ]

        for text1, text2 in test_cases:
            result = calc.compute_similarity(text1, text2)
            assert 0.0 <= result.score <= 1.0

    def test_sigmoid_normalization(self):
        """Test that normalization uses sigmoid function."""
        calc = BM25SimilarityCalculator()

        # For identical texts, raw score should be high
        result = calc.compute_similarity("test", "test")

        raw_score = result.metadata["bm25_raw_score"]
        expected_normalized = 1.0 / (1.0 + math.exp(-raw_score / 2.0))

        assert abs(result.score - expected_normalized) < 0.001


class TestBM25Validation:
    """Test input validation."""

    def test_raises_on_none_text1(self):
        """Test that None text1 raises ValueError."""
        calc = BM25SimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity(None, "test")

    def test_raises_on_none_text2(self):
        """Test that None text2 raises ValueError."""
        calc = BM25SimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity("test", None)

    def test_raises_on_empty_text1(self):
        """Test that empty text1 raises ValueError."""
        calc = BM25SimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("", "test")

    def test_raises_on_empty_text2(self):
        """Test that empty text2 raises ValueError."""
        calc = BM25SimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("test", "")

    def test_handles_whitespace_only_texts(self):
        """Test that whitespace-only texts raise ValueError."""
        calc = BM25SimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("   ", "test")


class TestBM25EdgeCases:
    """Test edge cases."""

    def test_single_character_texts(self):
        """Test texts with single characters."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("a", "a")

        # BM25 with 2-doc corpus gives moderate score even for identical text
        assert result.score > 0.5

    def test_texts_with_no_overlap(self):
        """Test texts with no common tokens."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("abc", "xyz")

        # No overlap, but still gets normalized score
        assert 0.0 <= result.score < 0.6

    def test_very_long_vs_short_text(self):
        """Test BM25 length normalization with different length texts."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity(
            "test",
            "test " + " ".join(["word"] * 100),
        )

        # Should handle length normalization properly
        assert 0.0 <= result.score <= 1.0

    def test_all_tokens_filtered_out(self):
        """Test when all tokens are filtered out by min_token_length."""
        calc = BM25SimilarityCalculator(min_token_length=10)

        # Short words will be filtered out
        result = calc.compute_similarity("a b c", "d e f")

        # Should return 0 similarity
        assert result.score == 0.0
        assert result.metadata["bm25_raw_score"] == 0.0


class TestBM25Preprocessing:
    """Test preprocessing integration."""

    def test_lowercase_normalization(self):
        """Test that lowercase normalization works."""
        calc = BM25SimilarityCalculator(lowercase=True)

        result = calc.compute_similarity("HELLO", "hello")

        # Should be identical after lowercasing (BM25 2-doc corpus behavior)
        assert result.score > 0.5

    def test_punctuation_removal(self):
        """Test that punctuation removal works."""
        calc = BM25SimilarityCalculator(remove_punctuation=True)

        result = calc.compute_similarity("hello!", "hello")

        # Should be identical after punctuation removal (BM25 2-doc corpus behavior)
        assert result.score > 0.5

    def test_preserves_numbers_when_configured(self):
        """Test that numbers are preserved when remove_punctuation=False."""
        calc = BM25SimilarityCalculator(remove_punctuation=False)

        result = calc.compute_similarity("test123", "test456")

        # Numbers should be different tokens
        assert result.score < 0.99


class TestBM25AlgorithmCorrectness:
    """Test BM25 algorithm correctness."""

    def test_bm25_formula_term_frequency(self):
        """Test that term frequency affects score."""
        calc = BM25SimilarityCalculator()

        # Document with term appearing once
        result1 = calc.compute_similarity("test", "test document")

        # Document with term appearing multiple times
        result2 = calc.compute_similarity("test", "test test test")

        # More occurrences should give higher score (but with saturation)
        assert result2.score >= result1.score

    def test_k1_parameter_affects_saturation(self):
        """Test that k1 parameter controls term frequency saturation."""
        # Higher k1 = slower saturation
        calc_high_k1 = BM25SimilarityCalculator(k1=2.0)
        calc_low_k1 = BM25SimilarityCalculator(k1=0.5)

        # Same texts
        text1 = "test"
        text2 = "test test test test test"

        result_high_k1 = calc_high_k1.compute_similarity(text1, text2)
        result_low_k1 = calc_low_k1.compute_similarity(text1, text2)

        # Both should give high scores, but might differ slightly
        assert result_high_k1.score > 0.5
        assert result_low_k1.score > 0.5

    def test_b_parameter_affects_length_normalization(self):
        """Test that b parameter controls document length normalization."""
        # b=0 means no length normalization
        calc_no_norm = BM25SimilarityCalculator(b=0.0)
        # b=1 means full length normalization
        calc_full_norm = BM25SimilarityCalculator(b=1.0)

        text1 = "test"
        text2 = "test " + " ".join(["word"] * 50)

        result_no_norm = calc_no_norm.compute_similarity(text1, text2)
        result_full_norm = calc_full_norm.compute_similarity(text1, text2)

        # Both should work, scores might differ
        assert 0.0 <= result_no_norm.score <= 1.0
        assert 0.0 <= result_full_norm.score <= 1.0


class TestRemovedFeatures:
    """Test that unnecessary features are removed."""

    def test_no_batch_processing(self):
        """Test that batch processing is removed."""
        calc = BM25SimilarityCalculator()

        # Should not have batch methods
        assert not hasattr(calc, "compute_batch_similarity")
        assert not hasattr(calc, "fit_corpus")

    def test_no_performance_tracking(self):
        """Test that performance tracking is removed."""
        calc = BM25SimilarityCalculator()

        # Should not have performance tracking
        assert not hasattr(calc, "_total_comparisons")
        assert not hasattr(calc, "_total_processing_time_ms")
        assert not hasattr(calc, "get_performance_stats")

    def test_no_corpus_persistence(self):
        """Test that corpus persistence methods are removed."""
        calc = BM25SimilarityCalculator()

        # Should not have persistence methods
        assert not hasattr(calc, "get_idf_vector")
        assert not hasattr(calc, "get_idf_data")
        assert not hasattr(calc, "load_idf_data")
        assert not hasattr(calc, "reset_corpus")
        assert not hasattr(calc, "is_fitted")

    def test_no_explainability_methods(self):
        """Test that complex explainability methods are removed."""
        calc = BM25SimilarityCalculator()

        # Should not have explain_score (metadata is sufficient)
        assert not hasattr(calc, "explain_score")

    def test_no_stopwords_parameter(self):
        """Test that stopwords parameter is removed from __init__."""
        # This should NOT raise TypeError - stopwords removed
        calc = BM25SimilarityCalculator(
            lowercase=True,
            remove_punctuation=True,
            min_token_length=1,
        )

        # Should not have stopwords attributes
        assert not hasattr(calc, "remove_stopwords")

    def test_similarity_result_simplified(self):
        """Test that SimilarityResult doesn't include tokens or processing_time."""
        calc = BM25SimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        # Should not have tokens
        assert not hasattr(result, "tokens1")
        assert not hasattr(result, "tokens2")

        # Should not have processing_time_ms
        assert not hasattr(result, "processing_time_ms")


class TestFAQChangeDetection:
    """Test real-world FAQ change detection scenarios."""

    def test_detects_numeric_change_in_policy(self):
        """Test detecting numeric changes in FAQ content."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        result = calc.compute_similarity(
            "Employees must submit expense reports within 30 days",
            "Employees must submit expense reports within 45 days",
        )

        # Moderate similarity (BM25 with 2-doc corpus, 1 word difference)
        assert 0.5 < result.score < 0.99

    def test_detects_date_change(self):
        """Test detecting date changes."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        result = calc.compute_similarity(
            "Deadline is January 15, 2024",
            "Deadline is January 20, 2024",
        )

        # Should detect date difference (BM25 with 2-doc corpus)
        assert 0.5 < result.score < 0.99

    def test_identical_faq_content(self):
        """Test that identical FAQ content has reasonable similarity."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        faq = "What is the maximum vacation days allowed per year?"

        result = calc.compute_similarity(faq, faq)

        # BM25 with 2-doc corpus gives moderate scores even for identical text
        assert result.score > 0.6

    def test_completely_different_faqs(self):
        """Test that different FAQs have low similarity."""
        calc = BM25SimilarityCalculator.for_faq_modification_detection()

        result = calc.compute_similarity(
            "How do I request vacation time?",
            "What are the parking lot hours?",
        )

        assert result.score < 0.6
