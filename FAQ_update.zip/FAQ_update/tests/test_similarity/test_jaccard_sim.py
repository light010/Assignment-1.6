"""
Test suite for simplified Jaccard similarity calculator.

Tests core Jaccard functionality with minimal complexity:
- Jaccard coefficient calculation
- Factory methods for FAQ content
- N-gram support (unigrams, bigrams, character-level)
- Weighted Jaccard variant
- No batch processing, no caching, no performance tracking
"""

import pytest
from granular_impact.similarity.jaccard_sim import (
    JaccardSimilarityCalculator,
    WeightedJaccardSimilarityCalculator,
)
from granular_impact.similarity.base import SimilarityResult


class TestJaccardBasicFunctionality:
    """Test basic Jaccard calculator functionality."""

    def test_initialization_default_params(self):
        """Test default initialization parameters."""
        calc = JaccardSimilarityCalculator()

        assert calc.ngram_size == 1
        assert calc.use_character_ngrams is False
        assert calc.lowercase is True
        assert calc.remove_punctuation is True
        assert calc.min_token_length == 1

    def test_initialization_custom_params(self):
        """Test custom initialization parameters."""
        calc = JaccardSimilarityCalculator(
            ngram_size=2,
            use_character_ngrams=True,
            lowercase=False,
            remove_punctuation=False,
            min_token_length=3,
        )

        assert calc.ngram_size == 2
        assert calc.use_character_ngrams is True
        assert calc.lowercase is False
        assert calc.remove_punctuation is False
        assert calc.min_token_length == 3

    def test_raises_on_invalid_ngram_size(self):
        """Test that invalid ngram_size raises ValueError."""
        with pytest.raises(ValueError, match="ngram_size must be >= 1"):
            JaccardSimilarityCalculator(ngram_size=0)

    def test_get_algorithm_name(self):
        """Test algorithm name."""
        calc = JaccardSimilarityCalculator()

        assert calc.get_algorithm_name() == "jaccard"


class TestJaccardFactoryMethods:
    """Test factory methods."""

    def test_for_faq_content(self):
        """Test FAQ content factory method."""
        calc = JaccardSimilarityCalculator.for_faq_content()

        assert calc.ngram_size == 1
        assert calc.use_character_ngrams is False
        assert calc.lowercase is True
        assert calc.remove_punctuation is False  # Preserves numbers, dates
        assert calc.min_token_length == 1


class TestJaccardComputeSimilarity:
    """Test compute_similarity method."""

    def test_identical_texts(self):
        """Test that identical texts have similarity 1.0."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity(
            "hello world test",
            "hello world test",
        )

        assert result.score == 1.0
        assert result.text1 == "hello world test"
        assert result.text2 == "hello world test"
        assert result.algorithm == "jaccard"

    def test_completely_different_texts(self):
        """Test that completely different texts have similarity 0.0."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity(
            "apple orange banana",
            "car truck motorcycle",
        )

        assert result.score == 0.0

    def test_partial_overlap(self):
        """Test texts with partial overlap."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity(
            "the quick brown fox",
            "the lazy brown dog",
        )

        # "the" and "brown" overlap = 2 common, 6 total unique
        # J = 2/6 = 0.333...
        assert abs(result.score - 2 / 6) < 0.001

    def test_returns_similarity_result(self):
        """Test that result is a SimilarityResult object."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        assert isinstance(result, SimilarityResult)
        assert hasattr(result, "score")
        assert hasattr(result, "text1")
        assert hasattr(result, "text2")
        assert hasattr(result, "algorithm")
        assert hasattr(result, "metadata")


class TestJaccardMetadata:
    """Test metadata in Jaccard results."""

    def test_metadata_contains_jaccard_info(self):
        """Test that metadata contains Jaccard-specific information."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity("hello world", "hello there")

        assert "intersection_size" in result.metadata
        assert "union_size" in result.metadata
        assert "set1_size" in result.metadata
        assert "set2_size" in result.metadata
        assert "ngram_size" in result.metadata
        assert "use_character_ngrams" in result.metadata

    def test_metadata_values_are_correct(self):
        """Test that metadata values are correct."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity("a b c", "b c d")

        # Sets: {a, b, c} and {b, c, d}
        # Intersection: {b, c} = 2
        # Union: {a, b, c, d} = 4
        assert result.metadata["intersection_size"] == 2
        assert result.metadata["union_size"] == 4
        assert result.metadata["set1_size"] == 3
        assert result.metadata["set2_size"] == 3
        assert result.metadata["ngram_size"] == 1
        assert result.metadata["use_character_ngrams"] is False


class TestJaccardValidation:
    """Test input validation."""

    def test_raises_on_none_text1(self):
        """Test that None text1 raises ValueError."""
        calc = JaccardSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity(None, "test")

    def test_raises_on_none_text2(self):
        """Test that None text2 raises ValueError."""
        calc = JaccardSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity("test", None)

    def test_raises_on_empty_text1(self):
        """Test that empty text1 raises ValueError."""
        calc = JaccardSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("", "test")

    def test_raises_on_empty_text2(self):
        """Test that empty text2 raises ValueError."""
        calc = JaccardSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("test", "")

    def test_handles_whitespace_only_texts(self):
        """Test that whitespace-only texts raise ValueError."""
        calc = JaccardSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("   ", "test")


class TestJaccardEdgeCases:
    """Test edge cases."""

    def test_both_empty_sets(self):
        """Test that filtering all tokens results in similarity 1.0 (both empty)."""
        calc = JaccardSimilarityCalculator(min_token_length=100)

        result = calc.compute_similarity("a b c", "d e f")

        # Both sets empty after filtering -> 1.0
        assert result.score == 1.0

    def test_one_empty_set(self):
        """Test that one empty set results in similarity 0.0."""
        calc = JaccardSimilarityCalculator(min_token_length=5)

        # "test" is filtered out, "verylongword" is kept
        result = calc.compute_similarity("test", "verylongword")

        assert result.score == 0.0

    def test_single_character_texts(self):
        """Test texts with single characters."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity("a", "a")

        assert result.score == 1.0


class TestJaccardNgrams:
    """Test n-gram functionality."""

    def test_unigrams(self):
        """Test unigram (default) behavior."""
        calc = JaccardSimilarityCalculator(ngram_size=1)

        result = calc.compute_similarity("a b c", "b c d")

        # Unigrams: {a, b, c} vs {b, c, d}
        # Intersection: {b, c} = 2, Union: {a, b, c, d} = 4
        assert result.score == 0.5

    def test_bigrams(self):
        """Test bigram n-grams."""
        calc = JaccardSimilarityCalculator(ngram_size=2)

        result = calc.compute_similarity("a b c", "b c d")

        # Bigrams: {"a b", "b c"} vs {"b c", "c d"}
        # Intersection: {"b c"} = 1, Union: {"a b", "b c", "c d"} = 3
        assert result.score == 1 / 3

    def test_trigrams(self):
        """Test trigram n-grams."""
        calc = JaccardSimilarityCalculator(ngram_size=3)

        result = calc.compute_similarity("a b c d", "b c d e")

        # Trigrams: {"a b c", "b c d"} vs {"b c d", "c d e"}
        # Intersection: {"b c d"} = 1, Union: {"a b c", "b c d", "c d e"} = 3
        assert result.score == 1 / 3

    def test_character_ngrams_unigrams(self):
        """Test character-level unigrams."""
        calc = JaccardSimilarityCalculator(ngram_size=1, use_character_ngrams=True)

        result = calc.compute_similarity("abc", "acd")

        # Character unigrams: {a, b, c} vs {a, c, d}
        # Intersection: {a, c} = 2, Union: {a, b, c, d} = 4
        assert result.score == 0.5

    def test_character_ngrams_bigrams(self):
        """Test character-level bigrams."""
        calc = JaccardSimilarityCalculator(ngram_size=2, use_character_ngrams=True)

        result = calc.compute_similarity("abc", "bcd")

        # Character bigrams: {ab, bc} vs {bc, cd}
        # Intersection: {bc} = 1, Union: {ab, bc, cd} = 3
        assert result.score == 1 / 3

    def test_character_ngrams_with_short_text(self):
        """Test character n-grams with text shorter than ngram_size."""
        calc = JaccardSimilarityCalculator(ngram_size=5, use_character_ngrams=True)

        result = calc.compute_similarity("ab", "ab")

        # Text shorter than ngram_size -> uses whole text
        assert result.score == 1.0


class TestJaccardPreprocessing:
    """Test preprocessing integration."""

    def test_lowercase_normalization(self):
        """Test that lowercase normalization works."""
        calc = JaccardSimilarityCalculator(lowercase=True)

        result = calc.compute_similarity("HELLO WORLD", "hello world")

        assert result.score == 1.0

    def test_punctuation_removal(self):
        """Test that punctuation removal works."""
        calc = JaccardSimilarityCalculator(remove_punctuation=True)

        result = calc.compute_similarity("hello!", "hello")

        assert result.score == 1.0

    def test_preserves_numbers_when_configured(self):
        """Test that numbers are preserved when remove_punctuation=False."""
        calc = JaccardSimilarityCalculator(remove_punctuation=False)

        result = calc.compute_similarity("test 123", "test 456")

        # "test", "123" vs "test", "456"
        # Intersection: {"test"} = 1, Union: {"test", "123", "456"} = 3
        assert abs(result.score - 1 / 3) < 0.001


class TestWeightedJaccard:
    """Test weighted Jaccard variant."""

    def test_initialization(self):
        """Test weighted Jaccard initialization."""
        weights = {"important": 5.0, "critical": 10.0}
        calc = WeightedJaccardSimilarityCalculator(
            token_weights=weights,
            default_weight=1.0,
        )

        assert calc.token_weights == weights
        assert calc.default_weight == 1.0

    def test_get_algorithm_name(self):
        """Test weighted Jaccard algorithm name."""
        calc = WeightedJaccardSimilarityCalculator()

        assert calc.get_algorithm_name() == "weighted_jaccard"

    def test_equal_weights_same_as_regular_jaccard(self):
        """Test that equal weights give same result as regular Jaccard."""
        regular_calc = JaccardSimilarityCalculator()
        weighted_calc = WeightedJaccardSimilarityCalculator(default_weight=1.0)

        text1 = "a b c"
        text2 = "b c d"

        regular_result = regular_calc.compute_similarity(text1, text2)
        weighted_result = weighted_calc.compute_similarity(text1, text2)

        assert abs(regular_result.score - weighted_result.score) < 0.001

    def test_weighted_emphasizes_important_tokens(self):
        """Test that weights emphasize important tokens."""
        weights = {"critical": 10.0}
        calc = WeightedJaccardSimilarityCalculator(
            token_weights=weights,
            default_weight=1.0,
        )

        # "critical test" vs "critical data"
        # Without weights: {critical, test} vs {critical, data}
        # Intersection: {critical} = 1, Union: 3, J = 1/3 = 0.333
        #
        # With weights:
        # Weighted intersection: 10.0 (critical)
        # Weighted union: 10.0 (critical) + 1.0 (test) + 1.0 (data) = 12.0
        # Weighted J = 10/12 = 0.833
        result = calc.compute_similarity("critical test", "critical data")

        assert abs(result.score - 10 / 12) < 0.001

    def test_weighted_metadata_contains_weighted_sums(self):
        """Test that weighted Jaccard metadata includes weighted sums."""
        weights = {"important": 5.0}
        calc = WeightedJaccardSimilarityCalculator(
            token_weights=weights,
            default_weight=1.0,
        )

        result = calc.compute_similarity("important test", "important data")

        assert "weighted_intersection" in result.metadata
        assert "weighted_union" in result.metadata
        assert "num_custom_weights" in result.metadata

        assert result.metadata["weighted_intersection"] == 5.0  # "important"
        assert result.metadata["weighted_union"] == 7.0  # 5 + 1 + 1
        assert result.metadata["num_custom_weights"] == 1

    def test_weighted_jaccard_with_no_custom_weights(self):
        """Test weighted Jaccard with empty token_weights dict."""
        calc = WeightedJaccardSimilarityCalculator(default_weight=2.0)

        result = calc.compute_similarity("a b", "a c")

        # All weights are 2.0
        # Intersection: {a} = 2.0, Union: {a, b, c} = 6.0
        # Weighted J = 2/6 = 0.333
        assert abs(result.score - 1 / 3) < 0.001


class TestRemovedFeatures:
    """Test that unnecessary features are removed."""

    def test_no_batch_processing(self):
        """Test that batch processing is removed."""
        calc = JaccardSimilarityCalculator()

        assert not hasattr(calc, "compute_batch_similarity")

    def test_no_performance_tracking(self):
        """Test that performance tracking is removed."""
        calc = JaccardSimilarityCalculator()

        assert not hasattr(calc, "_total_comparisons")
        assert not hasattr(calc, "_total_processing_time_ms")
        assert not hasattr(calc, "get_performance_stats")

    def test_no_caching(self):
        """Test that caching is removed."""
        calc = JaccardSimilarityCalculator()

        assert not hasattr(calc, "enable_cache")
        assert not hasattr(calc, "cache_size")
        assert not hasattr(calc, "_tokenize_cached")

    def test_no_stopwords_parameter(self):
        """Test that stopwords parameter is removed."""
        calc = JaccardSimilarityCalculator()

        assert not hasattr(calc, "remove_stopwords")

    def test_similarity_result_simplified(self):
        """Test that SimilarityResult doesn't include removed fields."""
        calc = JaccardSimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        # Should not have tokens or processing_time
        assert not hasattr(result, "tokens1")
        assert not hasattr(result, "tokens2")
        assert not hasattr(result, "processing_time_ms")


class TestFAQContentDetection:
    """Test real-world FAQ content scenarios."""

    def test_detects_numeric_change(self):
        """Test detecting numeric changes in FAQ content."""
        calc = JaccardSimilarityCalculator.for_faq_content()

        result = calc.compute_similarity(
            "Employees receive 10 vacation days per year",
            "Employees receive 15 vacation days per year",
        )

        # 6 tokens overlap: Employees, receive, vacation, days, per, year
        # 2 unique: 10, 15
        # Total: 8 tokens
        # Jaccard: 6/8 = 0.75
        assert abs(result.score - 6 / 8) < 0.001

    def test_detects_date_change(self):
        """Test detecting date changes."""
        calc = JaccardSimilarityCalculator.for_faq_content()

        result = calc.compute_similarity(
            "Deadline is January 15, 2024",
            "Deadline is January 20, 2024",
        )

        # Overlap: Deadline, is, January, ,, 2024 = 5
        # BUT commas might be removed depending on remove_punctuation=False tokenization
        # Intersection: 4-5, Union: 6-7
        # Jaccard: 4/6 = 0.666 or 5/7 = 0.714
        assert 0.6 < result.score < 0.8

    def test_identical_faq_content(self):
        """Test that identical FAQ content has similarity 1.0."""
        calc = JaccardSimilarityCalculator.for_faq_content()

        faq = "What is the maximum vacation days allowed per year?"

        result = calc.compute_similarity(faq, faq)

        assert result.score == 1.0

    def test_completely_different_faqs(self):
        """Test that different FAQs have low similarity."""
        calc = JaccardSimilarityCalculator.for_faq_content()

        result = calc.compute_similarity(
            "How do I request vacation time?",
            "What are the parking lot hours?",
        )

        # Very few overlapping words
        assert result.score < 0.3