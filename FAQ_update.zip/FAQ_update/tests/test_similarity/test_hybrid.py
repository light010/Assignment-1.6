"""
Test suite for simplified hybrid similarity calculator.

Tests core hybrid functionality with minimal complexity:
- Weighted combination of Jaccard, Difflib, and BM25
- Early exit optimization
- Factory methods for common use cases
- PolicyContentSimilarity classifier
"""

import pytest
from granular_impact.similarity.hybrid import (
    HybridSimilarityCalculator,
    PolicyContentSimilarity,
)
from granular_impact.similarity.base import SimilarityResult


class TestHybridBasicFunctionality:
    """Test basic hybrid calculator functionality."""

    def test_initialization_default_weights(self):
        """Test default initialization parameters."""
        calc = HybridSimilarityCalculator()

        assert calc.weights == {"jaccard": 0.25, "difflib": 0.25, "bm25": 0.50}
        assert calc.early_exit_threshold == 0.0

    def test_initialization_custom_weights(self):
        """Test custom weight initialization."""
        weights = {"jaccard": 0.5, "difflib": 0.3, "bm25": 0.2}
        calc = HybridSimilarityCalculator(weights=weights)

        assert calc.weights == weights

    def test_raises_on_invalid_weights_sum(self):
        """Test that invalid weight sum raises ValueError."""
        with pytest.raises(ValueError, match="must sum to 1.0"):
            HybridSimilarityCalculator(weights={"jaccard": 0.5, "difflib": 0.3})

    def test_get_algorithm_name(self):
        """Test algorithm name."""
        calc = HybridSimilarityCalculator()
        assert calc.get_algorithm_name() == "hybrid"


class TestHybridComputeSimilarity:
    """Test compute_similarity method."""

    def test_identical_texts(self):
        """Test that identical texts have similarity close to 1.0."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity(
            "hello world test",
            "hello world test",
        )

        assert result.score >= 0.95
        assert result.algorithm == "hybrid"

    def test_completely_different_texts(self):
        """Test that completely different texts have low similarity."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity(
            "apple orange banana",
            "car truck motorcycle",
        )

        assert result.score < 0.3

    def test_numeric_change_detection(self):
        """Test detecting numeric changes in content."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity(
            "Employees receive 10 vacation days per year",
            "Employees receive 15 vacation days per year",
        )

        # Should have high similarity (only number changed)
        assert result.score > 0.7

    def test_returns_similarity_result(self):
        """Test that result is a SimilarityResult object."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        assert isinstance(result, SimilarityResult)
        assert hasattr(result, "score")
        assert hasattr(result, "metadata")


class TestHybridMetadata:
    """Test metadata in hybrid results."""

    def test_metadata_contains_individual_scores(self):
        """Test that metadata contains individual algorithm scores."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity("hello world", "hello there")

        assert "individual_scores" in result.metadata
        assert "jaccard" in result.metadata["individual_scores"]
        assert "difflib" in result.metadata["individual_scores"]
        assert "bm25" in result.metadata["individual_scores"]

    def test_metadata_contains_weights(self):
        """Test that metadata contains algorithm weights."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity("test one", "test two")

        assert "weights" in result.metadata
        assert result.metadata["weights"] == calc.weights

    def test_metadata_contains_early_exit_info(self):
        """Test that metadata contains early exit information."""
        calc = HybridSimilarityCalculator(early_exit_threshold=0.5)

        result = calc.compute_similarity("hello", "goodbye")

        assert "early_exit" in result.metadata
        assert "early_exit_threshold" in result.metadata
        assert result.metadata["early_exit_threshold"] == 0.5


class TestHybridEarlyExit:
    """Test early exit optimization."""

    def test_early_exit_triggers_for_different_texts(self):
        """Test that early exit triggers for very different texts."""
        calc = HybridSimilarityCalculator(early_exit_threshold=0.5)

        result = calc.compute_similarity(
            "apple orange banana",
            "car truck motorcycle",
        )

        # Early exit should trigger
        assert result.metadata["early_exit"] is True
        assert result.score == 0.0

    def test_early_exit_disabled_by_default(self):
        """Test that early exit is disabled by default."""
        calc = HybridSimilarityCalculator()

        result = calc.compute_similarity("apple", "car")

        # Early exit should not trigger (threshold is 0.0)
        assert result.metadata["early_exit"] is False

    def test_early_exit_does_not_trigger_for_similar_texts(self):
        """Test that early exit doesn't trigger for similar texts."""
        calc = HybridSimilarityCalculator(early_exit_threshold=0.5)

        result = calc.compute_similarity(
            "hello world test",
            "hello world example",
        )

        # Early exit should not trigger (Jaccard > 0.5)
        assert result.metadata["early_exit"] is False
        assert result.score > 0.0


class TestHybridValidation:
    """Test input validation."""

    def test_raises_on_none_text1(self):
        """Test that None text1 raises ValueError."""
        calc = HybridSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity(None, "test")

    def test_raises_on_none_text2(self):
        """Test that None text2 raises ValueError."""
        calc = HybridSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be None"):
            calc.compute_similarity("test", None)

    def test_raises_on_empty_text1(self):
        """Test that empty text1 raises ValueError."""
        calc = HybridSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("", "test")

    def test_raises_on_empty_text2(self):
        """Test that empty text2 raises ValueError."""
        calc = HybridSimilarityCalculator()

        with pytest.raises(ValueError, match="cannot be empty"):
            calc.compute_similarity("test", "")


class TestHybridFactoryMethods:
    """Test factory methods."""

    def test_for_modification_detection(self):
        """Test modification detection factory method."""
        calc = HybridSimilarityCalculator.for_modification_detection()

        assert calc.weights == {"jaccard": 0.20, "difflib": 0.50, "bm25": 0.30}
        assert calc.early_exit_threshold == 0.3

    def test_for_general_similarity(self):
        """Test general similarity factory method."""
        calc = HybridSimilarityCalculator.for_general_similarity()

        assert calc.weights == {"jaccard": 0.33, "difflib": 0.33, "bm25": 0.34}
        assert calc.early_exit_threshold == 0.0


class TestAlgorithmBreakdown:
    """Test get_algorithm_breakdown method."""

    def test_breakdown_returns_individual_scores(self):
        """Test that breakdown returns all algorithm scores."""
        calc = HybridSimilarityCalculator()

        breakdown = calc.get_algorithm_breakdown("hello world", "hello there")

        assert isinstance(breakdown, dict)
        assert "jaccard" in breakdown
        assert "difflib" in breakdown
        assert "bm25" in breakdown
        assert all(0.0 <= score <= 1.0 for score in breakdown.values())


class TestPolicyContentSimilarity:
    """Test PolicyContentSimilarity specialized calculator."""

    def test_initialization(self):
        """Test PolicyContentSimilarity initialization."""
        calc = PolicyContentSimilarity()

        assert calc.weights == {"jaccard": 0.20, "difflib": 0.50, "bm25": 0.30}
        assert calc.early_exit_threshold == 0.3

    def test_get_algorithm_name(self):
        """Test policy similarity algorithm name."""
        calc = PolicyContentSimilarity()
        assert calc.get_algorithm_name() == "policy_similarity"

    def test_is_modification_returns_true_for_modifications(self):
        """Test that is_modification returns True for actual modifications."""
        calc = PolicyContentSimilarity()

        result = calc.is_modification(
            "Employees receive 10 vacation days",
            "Employees receive 15 vacation days",
        )

        assert result is True

    def test_is_modification_returns_false_for_new_content(self):
        """Test that is_modification returns False for new content."""
        calc = PolicyContentSimilarity()

        result = calc.is_modification(
            "Sick leave policy",
            "Parking regulations",
        )

        assert result is False

    def test_is_modification_custom_threshold(self):
        """Test is_modification with custom threshold."""
        calc = PolicyContentSimilarity()

        # With very high threshold, should fail
        result = calc.is_modification(
            "Employees receive 10 vacation days",
            "Employees receive 15 vacation days",
            threshold=0.95,
        )

        assert result is False

    def test_classify_change_identical(self):
        """Test classify_change returns 'identical' for identical text."""
        calc = PolicyContentSimilarity()

        change_type, score, details = calc.classify_change(
            "test content",
            "test content",
        )

        assert change_type == "identical"
        assert score >= 0.95
        assert "breakdown" in details

    def test_classify_change_minor_modification(self):
        """Test classify_change returns 'minor_modification' for small changes."""
        calc = PolicyContentSimilarity()

        change_type, score, details = calc.classify_change(
            "Employees receive 10 vacation days per year",
            "Employees receive 12 vacation days per year",
        )

        assert change_type in ["identical", "minor_modification", "major_modification"]
        assert 0.0 <= score <= 1.0

    def test_classify_change_new_content(self):
        """Test classify_change returns 'new_content' for unrelated text."""
        calc = PolicyContentSimilarity()

        change_type, score, details = calc.classify_change(
            "Sick leave policy details",
            "Vehicle parking regulations",
        )

        assert change_type in ["new_content", "significant_change"]
        assert score < 0.7

    def test_classify_change_details_structure(self):
        """Test that classify_change returns proper details structure."""
        calc = PolicyContentSimilarity()

        change_type, score, details = calc.classify_change(
            "test one",
            "test two",
        )

        assert "similarity_score" in details
        assert "breakdown" in details
        assert "early_exit" in details
        assert isinstance(details["breakdown"], dict)


class TestRealWorldScenarios:
    """Test real-world FAQ scenarios."""

    def test_date_change_detection(self):
        """Test detecting date changes."""
        calc = HybridSimilarityCalculator.for_modification_detection()

        result = calc.compute_similarity(
            "Deadline is January 15, 2024",
            "Deadline is February 15, 2024",
        )

        # Should detect as modification (high similarity)
        assert result.score > 0.7

    def test_number_change_detection(self):
        """Test detecting numeric changes."""
        calc = HybridSimilarityCalculator.for_modification_detection()

        result = calc.compute_similarity(
            "Policy allows 30 days notice",
            "Policy allows 45 days notice",
        )

        assert result.score > 0.7

    def test_major_rewrite_detection(self):
        """Test detecting major rewrites."""
        calc = HybridSimilarityCalculator.for_modification_detection()

        result = calc.compute_similarity(
            "Employee sick leave policy details",
            "Vehicle parking regulations and procedures",
        )

        # Should detect as new content (low similarity)
        assert result.score < 0.5


class TestRemovedFeatures:
    """Test that unnecessary features are removed."""

    def test_no_batch_processing(self):
        """Test that batch processing is removed."""
        calc = HybridSimilarityCalculator()

        assert not hasattr(calc, "compute_batch_similarity")

    def test_no_caching(self):
        """Test that caching is removed."""
        calc = HybridSimilarityCalculator()

        assert not hasattr(calc, "enable_cache")
        assert not hasattr(calc, "cache_size")

    def test_no_performance_tracking(self):
        """Test that performance tracking is removed."""
        calc = HybridSimilarityCalculator()

        assert not hasattr(calc, "_total_comparisons")
        assert not hasattr(calc, "get_performance_stats")