"""
Test Question Generator Mock Data Loading

Tests for loading mock FAQ questions from CSV files when use_mock=True.

Test Strategy (TDD):
1. Test CSV file loading functionality
2. Test data conversion to DataFrames matching database schema
3. Test integration with existing pipeline
4. Test error handling for missing CSV files
"""

import pytest
import pandas as pd
from pathlib import Path
import sys

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "granular_impact"))

from faq_generation import (
    QuestionGenerator,
    QuestionGeneratorConfig,
    Document,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def data_folder():
    """Path to data folder with sample CSV files."""
    return Path(__file__).parent.parent / "granular_impact" / "data_ingestion" / "data"


@pytest.fixture
def sample_question_csv(data_folder):
    """Path to sample_faq_questions.csv."""
    return data_folder / "sample_faq_questions.csv"


@pytest.fixture
def sample_question_sources_csv(data_folder):
    """Path to sample_faq_question_sources.csv."""
    return data_folder / "sample_faq_question_sources.csv"


@pytest.fixture
def mock_documents():
    """Mock documents for testing."""
    return [
        Document(
            page_content="Sample content 1",
            metadata={
                "checksum": "b54c22ec37e28c72f242c5c96ba13a0d582cf14ad4bba7b39f24466911546ca1",
                "title": "Test Doc 1",
                "source_file": "test1.pdf",
            }
        ),
        Document(
            page_content="Sample content 2",
            metadata={
                "checksum": "21f1d25d4f2dc7ce53d72cc050c32738362e1e12536d0b1a0fe14a1d691dfc37",
                "title": "Test Doc 2",
                "source_file": "test2.pdf",
            }
        ),
    ]


# ============================================================================
# Test CSV File Loading
# ============================================================================

class TestMockDataLoading:
    """Test loading mock data from CSV files."""

    def test_sample_csv_files_exist(self, sample_question_csv, sample_question_sources_csv):
        """Test that sample CSV files exist in data folder."""
        assert sample_question_csv.exists(), f"Missing {sample_question_csv}"
        assert sample_question_sources_csv.exists(), f"Missing {sample_question_sources_csv}"

    def test_sample_csv_files_have_correct_columns(self, sample_question_csv, sample_question_sources_csv):
        """Test that CSV files have required columns matching database schema."""
        # Load CSVs
        df_questions = pd.read_csv(sample_question_csv)
        df_sources = pd.read_csv(sample_question_sources_csv)

        # Check faq_questions columns
        required_q_cols = ["question_id", "question_text", "source_type", "generation_method", "status"]
        for col in required_q_cols:
            assert col in df_questions.columns, f"Missing column: {col}"

        # Check faq_question_sources columns
        required_s_cols = ["source_id", "question_id", "content_checksum", "is_primary_source", "contribution_weight", "is_valid"]
        for col in required_s_cols:
            assert col in df_sources.columns, f"Missing column: {col}"

    def test_mock_mode_loads_csv_instead_of_generating(self, mock_documents):
        """Test that use_mock=True loads CSV data instead of generating questions."""
        # Configure for mock mode
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        # Generate and map (should load from CSV)
        df_questions, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Verify DataFrames are returned
        assert isinstance(df_questions, pd.DataFrame)
        assert isinstance(df_sources, pd.DataFrame)

        # Verify they have data
        assert len(df_questions) > 0, "Should load questions from CSV"
        assert len(df_sources) > 0, "Should load sources from CSV"

    def test_mock_mode_returns_correct_schema(self, mock_documents):
        """Test that loaded CSV data matches expected database schema."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        df_questions, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Check faq_questions schema
        assert "question_text" in df_questions.columns
        assert "source_type" in df_questions.columns
        assert "generation_method" in df_questions.columns
        assert "status" in df_questions.columns

        # Check faq_question_sources schema
        assert "question_id" in df_sources.columns
        assert "content_checksum" in df_sources.columns
        assert "is_primary_source" in df_sources.columns
        assert "contribution_weight" in df_sources.columns
        assert "is_valid" in df_sources.columns

    def test_mock_mode_checksums_are_64_char_sha256(self, mock_documents):
        """Test that checksums in sources are valid SHA-256 (64 hex characters)."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        _, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Verify all checksums are 64 characters (SHA-256)
        for checksum in df_sources["content_checksum"]:
            assert len(checksum) == 64, f"Invalid checksum length: {len(checksum)}"
            # Verify it's hexadecimal
            int(checksum, 16)  # Should not raise ValueError

    def test_mock_mode_status_values_are_valid(self, mock_documents):
        """Test that status values match database constraints."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        df_questions, _ = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        valid_statuses = ["active", "invalidated", "archived", "deleted"]
        for status in df_questions["status"]:
            assert status in valid_statuses, f"Invalid status: {status}"

    def test_mock_mode_contribution_weights_valid(self, mock_documents):
        """Test that contribution weights are between 0.0 and 1.0."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        _, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        for weight in df_sources["contribution_weight"]:
            if pd.notna(weight):  # NULL is allowed
                assert 0.0 <= weight <= 1.0, f"Invalid weight: {weight}"


# ============================================================================
# Test Integration with Notebook Workflow
# ============================================================================

class TestNotebookIntegration:
    """Test that mock data works with notebook ingestion workflow."""

    def test_dataframes_ready_for_ingestion(self, mock_documents):
        """Test that returned DataFrames are ready for database ingestion."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        df_questions, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Verify questions DataFrame structure
        assert len(df_questions) > 0
        assert "question_text" in df_questions.columns
        assert all(isinstance(q, str) for q in df_questions["question_text"])
        assert all(len(q) > 0 for q in df_questions["question_text"])

        # Verify sources DataFrame structure
        assert len(df_sources) > 0
        assert "content_checksum" in df_sources.columns
        assert all(isinstance(c, str) for c in df_sources["content_checksum"])

    def test_question_ids_match_between_tables(self, mock_documents):
        """Test that question_id references are consistent."""
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        df_questions, df_sources = generator.generate_and_map(
            documents=mock_documents,
            deduplicate=False
        )

        # Note: In the CSV, question_ids are pre-assigned
        # Verify all source question_ids exist (would be in questions after ingestion)
        # This is a weak test but ensures referential structure
        assert len(df_sources) > 0
        assert "question_id" in df_sources.columns


# ============================================================================
# Test Error Handling
# ============================================================================

class TestErrorHandling:
    """Test error handling for missing files or invalid data."""

    def test_missing_csv_files_handled_gracefully(self, tmp_path, monkeypatch):
        """Test that missing CSV files don't crash the generator."""
        # Monkey patch the data folder to point to empty temp directory
        config = QuestionGeneratorConfig(use_mock=True)
        generator = QuestionGenerator(config)

        # This should handle missing files gracefully
        # (implementation will fall back to empty DataFrames or raise clear error)
        # For now, we'll test this after implementation


# ============================================================================
# Test Backward Compatibility (Breaking Changes OK)
# ============================================================================

class TestBackwardCompatibility:
    """Test interaction with existing generation logic."""

    def test_non_mock_mode_still_works(self, mock_documents):
        """Test that use_mock=False still uses original generation logic."""
        config = QuestionGeneratorConfig(use_mock=False)
        generator = QuestionGenerator(config)

        # This should raise NotImplementedError (original behavior)
        with pytest.raises(NotImplementedError):
            generator.generate_and_map(documents=mock_documents)
