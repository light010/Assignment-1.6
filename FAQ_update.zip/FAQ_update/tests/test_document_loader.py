"""
Tests for DocumentLoader with content_chunks table.

Tests loading documents from content_chunks with FK to content_repo.
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def temp_db_with_chunks():
    """Create temporary database with content_repo and content_chunks."""
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.db') as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_type TEXT,
            raw_file_version_nbr INT DEFAULT 1,
            title_nme TEXT,
            extracted_markdown_file_path TEXT,
            file_status TEXT,
            created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ud_source_file_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
                ON DELETE CASCADE,
            UNIQUE(ud_source_file_id, content_checksum),
            CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
            CONSTRAINT chk_chunk_status CHECK (status IN ('active', 'archived', 'deleted'))
        );
    """)
    conn.commit()
    conn.close()

    yield db_path

    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def sample_chunks_data(temp_db_with_chunks):
    """Insert sample content_repo and content_chunks data."""
    conn = sqlite3.connect(temp_db_with_chunks)
    conn.execute("PRAGMA foreign_keys = ON")

    # Insert content_repo
    cursor = conn.execute("""
        INSERT INTO content_repo
        (raw_file_nme, raw_file_type, title_nme, file_status)
        VALUES (?, ?, ?, ?)
    """, ('handbook.pdf', 'pdf', 'Employee Handbook', 'Active'))
    file_id = cursor.lastrowid

    # Insert chunks
    chunks = [
        (file_id, 0, 'a' * 64, 'First chunk of content about vacation policy.', 'active'),
        (file_id, 1, 'b' * 64, 'Second chunk about remote work guidelines.', 'active'),
        (file_id, 2, 'c' * 64, 'Third chunk about benefits overview.', 'archived'),
    ]

    conn.executemany("""
        INSERT INTO content_chunks
        (ud_source_file_id, chunk_index, content_checksum, chunk_text, status)
        VALUES (?, ?, ?, ?, ?)
    """, chunks)

    conn.commit()
    conn.close()

    return temp_db_with_chunks


# ============================================================================
# Test DocumentLoader
# ============================================================================

class TestDocumentLoader:
    """Test DocumentLoader with content_chunks table."""

    def test_class_exists(self):
        """Test that DocumentLoader can be imported."""
        from granular_impact.faq_generation import DocumentLoader
        assert DocumentLoader is not None

    def test_init(self, temp_db_with_chunks):
        """Test initialization with database path."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(temp_db_with_chunks)
        assert loader.db_path == temp_db_with_chunks

    def test_load_documents_active_only(self, sample_chunks_data):
        """Test loading active chunks only."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)
        documents = loader.load_documents(status_filter="active")

        # Should load 2 active chunks
        assert len(documents) == 2
        assert all(hasattr(doc, 'page_content') for doc in documents)
        assert all(hasattr(doc, 'metadata') for doc in documents)

    def test_load_documents_all_statuses(self, sample_chunks_data):
        """Test loading all chunks regardless of status."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)
        documents = loader.load_documents(status_filter="all")

        # Should load all 3 chunks
        assert len(documents) == 3

    def test_document_content(self, sample_chunks_data):
        """Test that document content matches chunk_text."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)
        documents = loader.load_documents(status_filter="active")

        assert documents[0].page_content == 'First chunk of content about vacation policy.'
        assert documents[1].page_content == 'Second chunk about remote work guidelines.'

    def test_document_metadata(self, sample_chunks_data):
        """Test that document metadata includes necessary fields."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)
        documents = loader.load_documents(status_filter="active")

        doc = documents[0]
        assert 'checksum' in doc.metadata
        assert 'chunk_id' in doc.metadata
        assert 'chunk_index' in doc.metadata
        assert 'source_file' in doc.metadata
        assert 'title' in doc.metadata
        assert 'file_type' in doc.metadata
        assert 'status' in doc.metadata

        # Verify values
        assert doc.metadata['checksum'] == 'a' * 64
        assert doc.metadata['chunk_index'] == 0
        assert doc.metadata['source_file'] == 'handbook.pdf'
        assert doc.metadata['title'] == 'Employee Handbook'
        assert doc.metadata['file_type'] == 'pdf'
        assert doc.metadata['status'] == 'active'

    def test_get_document_count(self, sample_chunks_data):
        """Test getting document count."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)

        active_count = loader.get_document_count(status_filter="active")
        assert active_count == 2

        all_count = loader.get_document_count(status_filter="all")
        assert all_count == 3

    def test_empty_database(self, temp_db_with_chunks):
        """Test loading from empty database."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(temp_db_with_chunks)
        documents = loader.load_documents()

        assert len(documents) == 0

    def test_join_with_content_repo(self, sample_chunks_data):
        """Test that loader properly joins content_chunks with content_repo."""
        from granular_impact.faq_generation import DocumentLoader

        loader = DocumentLoader(sample_chunks_data)
        documents = loader.load_documents(status_filter="all")

        # All documents should have title from content_repo
        assert all(doc.metadata['title'] == 'Employee Handbook' for doc in documents)
        assert all(doc.metadata['source_file'] == 'handbook.pdf' for doc in documents)


class TestDocumentClass:
    """Test Document class."""

    def test_document_creation(self):
        """Test creating Document with content and metadata."""
        from granular_impact.faq_generation import Document

        doc = Document(
            page_content="Sample content",
            metadata={"checksum": "abc123", "title": "Test"}
        )

        assert doc.page_content == "Sample content"
        assert doc.metadata["checksum"] == "abc123"
        assert doc.metadata["title"] == "Test"

    def test_document_repr(self):
        """Test Document string representation."""
        from granular_impact.faq_generation import Document

        doc = Document(
            page_content="A" * 100,
            metadata={"key1": "value1", "key2": "value2"}
        )

        repr_str = repr(doc)
        assert "Document" in repr_str
        assert "content_len=100" in repr_str
        assert "metadata=" in repr_str
