"""
Test FAQ Generation Pipeline

Tests for the oneailib-based FAQ generation pipeline that produces data
suitable for the granular impact database schema.

Test Strategy (TDD):
1. Test document-to-FAQ transformation
2. Test schema compliance
3. Test source provenance tracking
4. Test deduplication and filtering
5. Test database ingestion mapping
6. Test loading documents from checksum_table
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any
import pandas as pd
import sys

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "granular_impact"))

from faq_generation import (
    Document,
    DocumentLoader,
    QuestionGenerator,
    AnswerGenerator,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def temp_db():
    """Create temporary database with checksum_table schema."""
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    db_path = temp_file.name
    temp_file.close()

    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")

    # Create content_checksums table (simplified schema)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS content_checksums (
            content_checksum TEXT NOT NULL PRIMARY KEY,
            file_type TEXT,
            content_format TEXT,
            title TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            file_name TEXT,
            url TEXT,
            source_file_path TEXT,
            file_version TEXT,
            markdown_file_path TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CHECK (LENGTH(content_checksum) = 64),
            CHECK (status IN ('active', 'archived', 'deleted'))
        )
    """)
    conn.commit()
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def temp_markdown_files(tmp_path):
    """Create temporary markdown files for testing."""
    content1 = "Employees are entitled to 10 days of paid vacation per year. After 5 years of service, this increases to 15 days."
    content2 = "Remote work is available for eligible employees. Must have manager approval and reliable internet connection."

    file1 = tmp_path / "vacation_policy.md"
    file2 = tmp_path / "remote_work.md"

    file1.write_text(content1, encoding="utf-8")
    file2.write_text(content2, encoding="utf-8")

    return {
        "file1": file1,
        "content1": content1,
        "file2": file2,
        "content2": content2,
    }


@pytest.fixture
def sample_checksums_data(temp_markdown_files):
    """Sample checksum data for content_checksums table."""
    import hashlib

    checksum1 = hashlib.sha256(temp_markdown_files["content1"].encode("utf-8")).hexdigest()
    checksum2 = hashlib.sha256(temp_markdown_files["content2"].encode("utf-8")).hexdigest()

    return [
        {
            "content_checksum": checksum1,
            "file_type": "pdf",
            "content_format": "markdown",
            "title": "Vacation Policy",
            "status": "active",
            "file_name": "Employee_Handbook.pdf",
            "markdown_file_path": str(temp_markdown_files["file1"]),
        },
        {
            "content_checksum": checksum2,
            "file_type": "pdf",
            "content_format": "markdown",
            "title": "Remote Work Guidelines",
            "status": "active",
            "file_name": "Remote_Work_Policy.pdf",
            "markdown_file_path": str(temp_markdown_files["file2"]),
        },
    ]


@pytest.fixture
def sample_documents():
    """Sample documents for FAQ generation."""
    return [
        {
            "content": "Employees are entitled to 10 days of paid vacation per year. "
                      "After 5 years of service, this increases to 15 days.",
            "metadata": {
                "source_file": "Employee_Handbook.pdf",
                "title": "Vacation Policy",
                "checksum": "abc123def456",
            }
        },
        {
            "content": "Remote work is available for eligible employees. "
                      "Must have manager approval and reliable internet connection.",
            "metadata": {
                "source_file": "Remote_Work_Policy.pdf",
                "title": "Remote Work Guidelines",
                "checksum": "def789ghi012",
            }
        },
    ]


@pytest.fixture
def sample_generated_questions():
    """Sample generated questions from oneailib pipeline."""
    return [
        {
            "question": "How many vacation days do employees get?",
            "source_checksum": "abc123def456",
            "generation_method": "llm_generated",
        },
        {
            "question": "Can I work remotely?",
            "source_checksum": "def789ghi012",
            "generation_method": "llm_generated",
        },
    ]


@pytest.fixture
def sample_generated_answers():
    """Sample generated answers with context tracking."""
    return [
        {
            "question": "How many vacation days do employees get?",
            "answer": "Employees are entitled to <ol><li>10 days of paid vacation per year</li>"
                     "<li>15 days after 5 years of service</li></ol>",
            "context_indexes": [0],
            "context_checksums": ["abc123def456"],
            "confidence_score": 0.95,
        },
        {
            "question": "Can I work remotely?",
            "answer": "Remote work is available for eligible employees with manager approval "
                     "and reliable internet connection.",
            "context_indexes": [0],
            "context_checksums": ["def789ghi012"],
            "confidence_score": 0.92,
        },
    ]


# ============================================================================
# Test Schema Compliance
# ============================================================================

class TestSchemaCompliance:
    """Test that generated FAQs comply with database schema."""

    def test_question_schema_fields(self, sample_generated_questions):
        """Test that questions have all required fields for faq_questions table."""
        for q in sample_generated_questions:
            # Required fields
            assert "question" in q
            assert isinstance(q["question"], str)
            assert len(q["question"]) > 0

            # Metadata fields
            assert "source_checksum" in q
            assert "generation_method" in q

            # Implied fields (would be added during ingestion)
            # - question_id (AUTO_INCREMENT)
            # - status (DEFAULT 'active')
            # - created_at (DEFAULT CURRENT_TIMESTAMP)

    def test_answer_schema_fields(self, sample_generated_answers):
        """Test that answers have all required fields for faq_answers table."""
        for a in sample_generated_answers:
            # Required fields
            assert "question" in a
            assert "answer" in a
            assert isinstance(a["answer"], str)
            assert len(a["answer"]) > 0

            # Quality metrics
            assert "confidence_score" in a
            assert 0.0 <= a["confidence_score"] <= 1.0

            # Context tracking
            assert "context_checksums" in a
            assert isinstance(a["context_checksums"], list)

    def test_answer_format_html(self, sample_generated_answers):
        """Test that answers use allowed HTML tags only."""
        allowed_tags = ["<ol>", "<ul>", "<li>", "<a"]

        for a in sample_generated_answers:
            answer = a["answer"]

            # Check for HTML tags
            if "<" in answer:
                # Verify only allowed tags are used
                for tag in ["<ol>", "<ul>", "<li>", "<a"]:
                    if tag in answer:
                        assert tag in allowed_tags

                # Ensure no prohibited tags
                prohibited = ["<p>", "<div>", "<span>", "<br>", "<h1>", "<b>", "<i>"]
                for tag in prohibited:
                    assert tag not in answer, f"Prohibited tag {tag} found in answer"

    def test_question_source_schema(self, sample_generated_questions):
        """Test that question sources comply with faq_question_sources schema."""
        for q in sample_generated_questions:
            # Source tracking
            assert "source_checksum" in q
            assert isinstance(q["source_checksum"], str)
            assert len(q["source_checksum"]) > 0

            # These would be added during ingestion:
            # - is_primary_source (DEFAULT FALSE)
            # - contribution_weight (NULL or 0.0-1.0)
            # - is_valid (DEFAULT TRUE)
            # - valid_from (DEFAULT CURRENT_TIMESTAMP)

    def test_answer_source_schema(self, sample_generated_answers):
        """Test that answer sources comply with faq_answer_sources schema."""
        for a in sample_generated_answers:
            # Context tracking
            assert "context_checksums" in a
            assert isinstance(a["context_checksums"], list)
            assert len(a["context_checksums"]) > 0

            # Verify all checksums are strings
            for checksum in a["context_checksums"]:
                assert isinstance(checksum, str)
                assert len(checksum) > 0


# ============================================================================
# Test FAQ Generation Logic
# ============================================================================

class TestFAQGeneration:
    """Test FAQ generation transformation logic."""

    def test_question_generation_from_documents(self, sample_documents):
        """Test that questions can be generated from documents."""
        # This would use oneailib.chat_models.AzureOpenAIChatModel
        # with the generate_questions.yaml configuration

        # Mock the generation process
        questions = []
        for doc in sample_documents:
            # Simulate LLM question generation
            if "vacation" in doc["content"].lower():
                questions.append({
                    "question": "How many vacation days do employees get?",
                    "source_checksum": doc["metadata"]["checksum"],
                    "generation_method": "llm_generated",
                })

        assert len(questions) > 0
        assert all("question" in q for q in questions)
        assert all("source_checksum" in q for q in questions)

    def test_answer_generation_with_context(self, sample_generated_questions, sample_documents):
        """Test that answers are generated with context tracking."""
        # This would use oneailib.chat_models.AzureOpenAIChatModel
        # with the generate_answers.yaml configuration

        # Mock answer generation
        answers = []
        for q in sample_generated_questions:
            # Find matching document
            matching_doc = next(
                (doc for doc in sample_documents
                 if doc["metadata"]["checksum"] == q["source_checksum"]),
                None
            )

            if matching_doc:
                answers.append({
                    "question": q["question"],
                    "answer": "Generated answer based on context",
                    "context_checksums": [q["source_checksum"]],
                    "confidence_score": 0.9,
                })

        assert len(answers) > 0
        assert all("answer" in a for a in answers)
        assert all("context_checksums" in a for a in answers)
        assert all(len(a["context_checksums"]) > 0 for a in answers)

    def test_deduplication_by_similarity(self):
        """Test that duplicate/similar questions are deduplicated."""
        questions = [
            {"question": "How many vacation days do I get?", "embedding": [0.1, 0.2, 0.3]},
            {"question": "How many vacation days do employees get?", "embedding": [0.1, 0.2, 0.3]},
            {"question": "Can I work remotely?", "embedding": [0.9, 0.8, 0.7]},
        ]

        # Mock deduplication (would use semantic distance computation)
        def cosine_similarity(a, b):
            """Simple similarity for testing."""
            import math
            dot_product = sum(x * y for x, y in zip(a, b))
            norm_a = math.sqrt(sum(x * x for x in a))
            norm_b = math.sqrt(sum(y * y for y in b))
            return dot_product / (norm_a * norm_b) if norm_a and norm_b else 0.0

        unique_questions = []
        for q in questions:
            # Check similarity with existing questions
            is_duplicate = False
            for existing in unique_questions:
                sim = cosine_similarity(q["embedding"], existing["embedding"])
                if sim > 0.95:  # Threshold for duplicates
                    is_duplicate = True
                    break

            if not is_duplicate:
                unique_questions.append(q)

        assert len(unique_questions) == 2  # Two duplicates removed (same embedding)

    def test_filtering_by_confidence(self, sample_generated_answers):
        """Test that low-confidence answers are filtered out."""
        threshold = 0.9

        filtered = [a for a in sample_generated_answers if a["confidence_score"] >= threshold]

        # Should keep high-confidence answers
        assert len(filtered) >= 1
        assert all(a["confidence_score"] >= threshold for a in filtered)


# ============================================================================
# Test Database Mapping
# ============================================================================

class TestDatabaseMapping:
    """Test mapping from oneailib output to database schema."""

    def test_map_question_to_db_row(self, sample_generated_questions):
        """Test mapping question to faq_questions table row."""
        for q in sample_generated_questions:
            # Map to DB row
            db_row = {
                "question_text": q["question"],
                "source_type": "document",
                "generation_method": q["generation_method"],
                "status": "active",
            }

            # Verify mapping
            assert "question_text" in db_row
            assert "generation_method" in db_row
            assert "status" in db_row
            assert db_row["status"] in ["active", "invalidated", "archived", "deleted"]

    def test_map_answer_to_db_row(self, sample_generated_answers):
        """Test mapping answer to faq_answers table row."""
        for a in sample_generated_answers:
            # Map to DB row
            db_row = {
                "question_id": 1,  # Would come from inserted question
                "answer_text": a["answer"],
                "answer_format": "html",
                "confidence_score": a["confidence_score"],
                "status": "active",
            }

            # Verify mapping
            assert "answer_text" in db_row
            assert "answer_format" in db_row
            assert db_row["answer_format"] in ["html", "markdown", "plain"]
            assert "confidence_score" in db_row
            assert 0.0 <= db_row["confidence_score"] <= 1.0

    def test_map_question_source_to_db_row(self, sample_generated_questions):
        """Test mapping to faq_question_sources table."""
        for q in sample_generated_questions:
            # Map to DB row
            db_row = {
                "question_id": 1,  # Would come from inserted question
                "content_checksum": q["source_checksum"],
                "is_primary_source": True,
                "contribution_weight": 1.0,
                "is_valid": True,
            }

            # Verify mapping
            assert "content_checksum" in db_row
            assert "is_primary_source" in db_row
            assert "contribution_weight" in db_row
            assert 0.0 <= db_row["contribution_weight"] <= 1.0

    def test_map_answer_source_to_db_rows(self, sample_generated_answers):
        """Test mapping to faq_answer_sources table (can have multiple sources)."""
        for a in sample_generated_answers:
            # Map each context checksum to a separate row
            db_rows = []
            for i, checksum in enumerate(a["context_checksums"]):
                db_rows.append({
                    "answer_id": 1,  # Would come from inserted answer
                    "content_checksum": checksum,
                    "is_primary_source": (i == 0),  # First is primary
                    "contribution_weight": 1.0 / len(a["context_checksums"]),
                    "is_valid": True,
                })

            # Verify mapping
            assert len(db_rows) == len(a["context_checksums"])
            assert any(row["is_primary_source"] for row in db_rows)
            assert abs(sum(row["contribution_weight"] for row in db_rows) - 1.0) < 0.01


# ============================================================================
# Test Source Provenance Tracking
# ============================================================================

class TestSourceProvenance:
    """Test source provenance and temporal validity tracking."""

    def test_question_links_to_source_document(self, sample_generated_questions):
        """Test that questions maintain link to source documents."""
        for q in sample_generated_questions:
            assert "source_checksum" in q
            # In real system, this would link to content_checksums table

    def test_answer_links_to_context_documents(self, sample_generated_answers):
        """Test that answers track all context documents used."""
        for a in sample_generated_answers:
            assert "context_checksums" in a
            assert len(a["context_checksums"]) > 0
            # Each checksum would link to content_checksums table

    def test_temporal_validity_fields(self):
        """Test that temporal validity fields are properly set."""
        # Mock a source record
        source_record = {
            "question_id": 1,
            "content_checksum": "abc123",
            "is_valid": True,
            "valid_from": datetime.utcnow().isoformat(),
            "valid_until": None,  # Still valid
        }

        assert source_record["is_valid"] is True
        assert source_record["valid_from"] is not None
        assert source_record["valid_until"] is None

    def test_invalidation_when_content_changes(self):
        """Test that sources are invalidated when content changes."""
        # Mock invalidation
        old_source = {
            "question_id": 1,
            "content_checksum": "old_checksum",
            "is_valid": True,
            "valid_from": "2025-01-01T00:00:00",
            "valid_until": None,
        }

        # Simulate content change
        new_checksum = "new_checksum"
        if old_source["content_checksum"] != new_checksum:
            # Invalidate old source
            old_source["is_valid"] = False
            old_source["valid_until"] = datetime.utcnow().isoformat()
            old_source["invalidation_reason"] = "content_changed"

            # Create new source
            new_source = {
                "question_id": 1,
                "content_checksum": new_checksum,
                "is_valid": True,
                "valid_from": datetime.utcnow().isoformat(),
                "valid_until": None,
            }

            assert old_source["is_valid"] is False
            assert old_source["valid_until"] is not None
            assert new_source["is_valid"] is True


# ============================================================================
# Integration Test
# ============================================================================

class TestEndToEndPipeline:
    """Test end-to-end FAQ generation pipeline."""

    def test_complete_pipeline_flow(self, sample_documents):
        """Test complete flow from documents to database-ready FAQs."""
        # 1. Load documents
        documents = sample_documents
        assert len(documents) > 0

        # 2. Generate questions (mock)
        questions = []
        for doc in documents:
            questions.append({
                "question": f"Question about {doc['metadata']['title']}",
                "source_checksum": doc["metadata"]["checksum"],
                "generation_method": "llm_generated",
            })
        assert len(questions) == len(documents)

        # 3. Generate embeddings (mock)
        for q in questions:
            q["embedding"] = [0.1, 0.2, 0.3]  # Mock embedding

        # 4. Retrieve context (mock - would use OpenSearch)
        for q in questions:
            q["context"] = [doc for doc in documents
                          if doc["metadata"]["checksum"] == q["source_checksum"]]

        # 5. Generate answers (mock)
        answers = []
        for q in questions:
            answers.append({
                "question": q["question"],
                "answer": "Generated answer",
                "context_checksums": [q["source_checksum"]],
                "confidence_score": 0.95,
            })
        assert len(answers) == len(questions)

        # 6. Filter by confidence
        filtered_answers = [a for a in answers if a["confidence_score"] >= 0.9]
        assert len(filtered_answers) > 0

        # 7. Map to database schema
        db_questions = []
        db_answers = []
        db_question_sources = []
        db_answer_sources = []

        for i, (q, a) in enumerate(zip(questions, filtered_answers), 1):
            # Map question
            db_questions.append({
                "question_id": i,
                "question_text": q["question"],
                "generation_method": q["generation_method"],
                "status": "active",
            })

            # Map answer
            db_answers.append({
                "answer_id": i,
                "question_id": i,
                "answer_text": a["answer"],
                "confidence_score": a["confidence_score"],
                "status": "active",
            })

            # Map question source
            db_question_sources.append({
                "question_id": i,
                "content_checksum": q["source_checksum"],
                "is_primary_source": True,
                "is_valid": True,
            })

            # Map answer sources
            for checksum in a["context_checksums"]:
                db_answer_sources.append({
                    "answer_id": i,
                    "content_checksum": checksum,
                    "is_primary_source": True,
                    "is_valid": True,
                })

        # Verify all mappings
        assert len(db_questions) == len(db_answers)
        assert len(db_question_sources) == len(db_questions)
        assert len(db_answer_sources) >= len(db_answers)

        # Verify schema compliance
        for q in db_questions:
            assert "question_text" in q
            assert "status" in q

        for a in db_answers:
            assert "answer_text" in a
            assert "confidence_score" in a
            assert 0.0 <= a["confidence_score"] <= 1.0


# ============================================================================
# Test Loading Documents from Checksum Table
# ============================================================================

class TestLoadDocumentsFromChecksumTable:
    """Test loading documents from content_checksums table instead of CSV."""

    def test_load_documents_from_empty_checksum_table(self, temp_db):
        """Test loading from empty checksum_table returns empty list."""
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents()

        assert isinstance(documents, list)
        assert len(documents) == 0

    def test_load_documents_from_checksum_table_with_data(
        self, temp_db, sample_checksums_data, temp_markdown_files
    ):
        """Test loading documents from checksum_table with data."""
        # Insert sample data into checksum_table
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(sample_checksums_data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents using DocumentLoader
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents()

        # Verify documents loaded
        assert len(documents) == 2
        assert all(isinstance(doc, Document) for doc in documents)

        # Verify document content
        assert any("vacation" in doc.page_content.lower() for doc in documents)
        assert any("remote work" in doc.page_content.lower() for doc in documents)

        # Verify metadata
        for doc in documents:
            assert "checksum" in doc.metadata
            assert "title" in doc.metadata
            assert "source_file" in doc.metadata
            assert len(doc.metadata["checksum"]) == 64  # SHA-256 checksum

    def test_load_documents_filters_active_status_only(
        self, temp_db, sample_checksums_data, temp_markdown_files
    ):
        """Test that only active content is loaded (not archived or deleted)."""
        # Modify one record to be archived
        data = sample_checksums_data.copy()
        data[1]["status"] = "archived"

        # Insert data
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents(status_filter="active")

        # Should only load active documents
        assert len(documents) == 1
        assert documents[0].metadata["title"] == "Vacation Policy"

    def test_load_documents_handles_missing_markdown_file(
        self, temp_db, sample_checksums_data
    ):
        """Test that missing markdown files are skipped with warning."""
        # Modify markdown paths to non-existent files
        data = sample_checksums_data.copy()
        data[0]["markdown_file_path"] = "/nonexistent/path/file1.md"
        data[1]["markdown_file_path"] = "/nonexistent/path/file2.md"

        # Insert data
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents()

        # Should return empty list (all files missing)
        assert len(documents) == 0

    def test_load_documents_checksum_matches_content(
        self, temp_db, sample_checksums_data, temp_markdown_files
    ):
        """Test that loaded documents have correct checksums matching content."""
        # Insert data
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(sample_checksums_data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents()

        # Verify checksums match
        for doc in documents:
            # Recompute checksum from content
            import hashlib
            computed_checksum = hashlib.sha256(doc.page_content.encode("utf-8")).hexdigest()
            assert doc.metadata["checksum"] == computed_checksum

    def test_load_documents_preserves_all_metadata(
        self, temp_db, sample_checksums_data, temp_markdown_files
    ):
        """Test that all relevant metadata is preserved from checksum_table."""
        # Insert data
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(sample_checksums_data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents()

        # Verify metadata fields
        for doc in documents:
            assert "checksum" in doc.metadata
            assert "title" in doc.metadata
            assert "source_file" in doc.metadata
            assert "file_type" in doc.metadata
            assert "content_format" in doc.metadata

    def test_run_complete_pipeline_with_checksum_table(
        self, temp_db, sample_checksums_data, temp_markdown_files
    ):
        """Test complete pipeline using question and answer generators with checksum_table."""
        # Insert data into checksum_table
        conn = sqlite3.connect(temp_db)
        df = pd.DataFrame(sample_checksums_data)
        df.to_sql("content_checksums", conn, if_exists="append", index=False)
        conn.close()

        # Load documents from database
        loader = DocumentLoader(db_path=temp_db)
        documents = loader.load_documents(status_filter="active")

        # Generate questions
        question_generator = QuestionGenerator()
        df_questions, df_question_sources = question_generator.generate_and_map(
            documents=documents,
            deduplicate=True
        )

        # Generate answers
        answer_generator = AnswerGenerator()
        answer_generator.load_context_documents(documents)

        # Convert questions DataFrame to Question objects for answer generation
        from faq_generation import Question
        questions = []
        for i, row in df_questions.iterrows():
            # Get source checksum from question sources
            q_source = df_question_sources[df_question_sources['question_id'] == i + 1]
            source_checksum = q_source['content_checksum'].iloc[0] if len(q_source) > 0 else ''

            q = Question(
                question_text=row['question_text'],
                source_checksum=source_checksum,
            )
            questions.append(q)

        df_answers, df_answer_sources = answer_generator.generate_and_map(
            questions=questions,
            retrieve_context=True
        )

        # Verify results
        assert len(df_questions) > 0
        assert len(df_answers) > 0
        assert len(df_question_sources) > 0
        assert len(df_answer_sources) > 0

        # Verify checksums in sources are 64 characters (SHA-256)
        for checksum in df_question_sources["content_checksum"]:
            assert len(checksum) == 64
        for checksum in df_answer_sources["content_checksum"]:
            assert len(checksum) == 64
