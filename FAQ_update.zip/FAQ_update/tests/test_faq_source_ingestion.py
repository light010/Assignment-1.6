"""
Tests for FAQ source data ingestion (question and answer sources).

Following TDD approach:
1. Write tests that define expected behavior
2. Implement minimal code to pass tests
3. Refactor while keeping tests green

Schema Ground Truth:
- 04_faq_question_sources.sql: source_id (PK), question_id (FK NOT NULL),
  content_checksum (NOT NULL), is_primary_source, contribution_weight (CHECK 0.0-1.0),
  is_valid (NOT NULL DEFAULT TRUE), valid_from, valid_until, invalidation_reason,
  invalidated_by_change_id, created_at
- 05_faq_answer_sources.sql: Same as question sources + context_employed field
"""

import sqlite3
from pathlib import Path
import tempfile
import pytest
import pandas as pd

# Import the module we're testing (will create this)
from granular_impact.data_ingestion import FAQSourceIngestion


@pytest.fixture
def temp_db():
    """Create a temporary database with schema for testing."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Create schema matching SQL files (ground truth)
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE faq_questions (
            question_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_text TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active'
        );

        CREATE TABLE faq_answers (
            answer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            answer_text TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE
        );

        CREATE TABLE faq_question_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source BOOLEAN DEFAULT FALSE,
            contribution_weight DOUBLE,
            is_valid BOOLEAN NOT NULL DEFAULT TRUE,
            valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            valid_until TEXT,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0))
        );

        CREATE TABLE faq_answer_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            answer_id INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source BOOLEAN DEFAULT FALSE,
            contribution_weight DOUBLE,
            context_employed TEXT,
            is_valid BOOLEAN NOT NULL DEFAULT TRUE,
            valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            valid_until TEXT,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0))
        );
    """)
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def setup_faq_data(temp_db):
    """Setup basic FAQ questions and answers for testing sources."""
    conn = sqlite3.connect(temp_db)
    conn.executescript("""
        INSERT INTO faq_questions (question_id, question_text) VALUES
            (1, 'How many sick days?'),
            (2, 'What are password requirements?');

        INSERT INTO faq_answers (answer_id, question_id, answer_text) VALUES
            (1, 1, 'You get 10 sick days.'),
            (2, 2, 'Password must be 8+ chars.');
    """)
    conn.commit()
    conn.close()


@pytest.fixture
def sample_question_sources():
    """Sample question sources as DataFrame."""
    return pd.DataFrame([
        {
            "question_id": 1,
            "content_checksum": "a" * 64,
            "is_primary_source": True,
            "contribution_weight": 1.0,
            "is_valid": True,
        },
        {
            "question_id": 2,
            "content_checksum": "b" * 64,
            "is_primary_source": True,
            "contribution_weight": 0.8,
            "is_valid": True,
        },
    ])


@pytest.fixture
def sample_answer_sources():
    """Sample answer sources as DataFrame."""
    return pd.DataFrame([
        {
            "answer_id": 1,
            "content_checksum": "a" * 64,
            "is_primary_source": True,
            "contribution_weight": 1.0,
            "context_employed": "Time Off Policy section",
            "is_valid": True,
        },
        {
            "answer_id": 2,
            "content_checksum": "b" * 64,
            "is_primary_source": True,
            "contribution_weight": 0.9,
            "context_employed": "Password Standards section",
            "is_valid": True,
        },
    ])


class TestFAQSourceIngestion:
    """Test suite for FAQSourceIngestion class."""

    def test_init(self, temp_db):
        """Test initialization with database path."""
        ingestion = FAQSourceIngestion(temp_db)
        assert ingestion.db_path == temp_db

    def test_ingest_question_sources_from_csv(self, temp_db, setup_faq_data):
        """Test ingesting question sources from CSV file."""
        csv_data = f"""question_id,content_checksum,is_primary_source,contribution_weight,is_valid
1,{'a' * 64},1,1.0,1
2,{'b' * 64},1,0.8,1"""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write(csv_data)

        try:
            ingestion = FAQSourceIngestion(temp_db)
            result = ingestion.ingest_question_sources_from_csv(csv_path)

            assert result['success'] is True
            assert result['rows_inserted'] == 2

            # Verify database
            conn = sqlite3.connect(temp_db)
            count = conn.execute("SELECT COUNT(*) FROM faq_question_sources").fetchone()[0]
            assert count == 2
            conn.close()

        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_ingest_question_sources_from_dataframe(self, temp_db, setup_faq_data, sample_question_sources):
        """Test ingesting question sources from DataFrame."""
        ingestion = FAQSourceIngestion(temp_db)
        result = ingestion.ingest_question_sources_from_dataframe(sample_question_sources)

        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify data
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT question_id, content_checksum, is_primary_source, contribution_weight "
            "FROM faq_question_sources WHERE question_id = 1"
        ).fetchone()
        assert row[0] == 1
        assert row[1] == "a" * 64
        assert row[2] == 1  # True -> 1 in SQLite
        assert row[3] == 1.0
        conn.close()

    def test_ingest_answer_sources_from_csv(self, temp_db, setup_faq_data):
        """Test ingesting answer sources from CSV file."""
        csv_data = f"""answer_id,content_checksum,is_primary_source,contribution_weight,context_employed,is_valid
1,{'a' * 64},1,1.0,Time Off Policy,1
2,{'b' * 64},1,0.9,Password Standards,1"""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write(csv_data)

        try:
            ingestion = FAQSourceIngestion(temp_db)
            result = ingestion.ingest_answer_sources_from_csv(csv_path)

            assert result['success'] is True
            assert result['rows_inserted'] == 2

            # Verify database
            conn = sqlite3.connect(temp_db)
            count = conn.execute("SELECT COUNT(*) FROM faq_answer_sources").fetchone()[0]
            assert count == 2
            conn.close()

        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_ingest_answer_sources_from_dataframe(self, temp_db, setup_faq_data, sample_answer_sources):
        """Test ingesting answer sources from DataFrame."""
        ingestion = FAQSourceIngestion(temp_db)
        result = ingestion.ingest_answer_sources_from_dataframe(sample_answer_sources)

        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify data
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT answer_id, content_checksum, context_employed, contribution_weight "
            "FROM faq_answer_sources WHERE answer_id = 1"
        ).fetchone()
        assert row[0] == 1
        assert row[1] == "a" * 64
        assert row[2] == "Time Off Policy section"
        assert row[3] == 1.0
        conn.close()

    def test_validate_contribution_weight(self, temp_db, setup_faq_data):
        """Test contribution weight validation (must be 0.0-1.0 or NULL)."""
        ingestion = FAQSourceIngestion(temp_db)

        # Valid weights
        for weight in [0.0, 0.5, 1.0, None]:
            df = pd.DataFrame([{
                "question_id": 1,
                "content_checksum": "a" * 64,
                "contribution_weight": weight,
            }])
            # Clear previous
            conn = sqlite3.connect(temp_db)
            conn.execute("DELETE FROM faq_question_sources WHERE question_id = 1")
            conn.commit()
            conn.close()

            result = ingestion.ingest_question_sources_from_dataframe(df)
            assert result['success'] is True, f"Should accept weight {weight}"

        # Invalid weights
        for weight in [-0.1, 1.1, 2.0]:
            df = pd.DataFrame([{
                "question_id": 1,
                "content_checksum": "a" * 64,
                "contribution_weight": weight,
            }])
            result = ingestion.ingest_question_sources_from_dataframe(df)
            assert result['success'] is False
            assert 'contribution' in result['message'].lower() or 'weight' in result['message'].lower()

    def test_validate_checksum_length(self, temp_db, setup_faq_data):
        """Test that checksums must be 64 characters (SHA256)."""
        ingestion = FAQSourceIngestion(temp_db)

        # Valid checksum
        df = pd.DataFrame([{
            "question_id": 1,
            "content_checksum": "a" * 64,
        }])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is True

        # Invalid checksum (wrong length)
        df = pd.DataFrame([{
            "question_id": 1,
            "content_checksum": "short",
        }])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is False
        assert 'checksum' in result['message'].lower()

    def test_required_fields(self, temp_db, setup_faq_data):
        """Test that required fields are enforced."""
        ingestion = FAQSourceIngestion(temp_db)

        # Missing question_id
        df = pd.DataFrame([{"content_checksum": "a" * 64}])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is False
        assert 'required' in result['message'].lower()

        # Missing content_checksum
        df = pd.DataFrame([{"question_id": 1}])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is False
        assert 'required' in result['message'].lower()

    def test_multiple_sources_per_question(self, temp_db, setup_faq_data):
        """Test that a question can have multiple sources."""
        ingestion = FAQSourceIngestion(temp_db)

        df = pd.DataFrame([
            {
                "question_id": 1,
                "content_checksum": "a" * 64,
                "is_primary_source": True,
                "contribution_weight": 0.6,
            },
            {
                "question_id": 1,
                "content_checksum": "b" * 64,
                "is_primary_source": False,
                "contribution_weight": 0.4,
            },
        ])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify both sources exist
        conn = sqlite3.connect(temp_db)
        count = conn.execute(
            "SELECT COUNT(*) FROM faq_question_sources WHERE question_id = 1"
        ).fetchone()[0]
        assert count == 2
        conn.close()

    def test_temporal_validity_fields(self, temp_db, setup_faq_data):
        """Test temporal validity fields (is_valid, valid_from, valid_until)."""
        ingestion = FAQSourceIngestion(temp_db)

        df = pd.DataFrame([{
            "question_id": 1,
            "content_checksum": "a" * 64,
            "is_valid": True,
        }])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is True

        # Verify temporal fields
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT is_valid, valid_from, valid_until FROM faq_question_sources WHERE question_id = 1"
        ).fetchone()
        assert row[0] == 1  # is_valid = True
        assert row[1] is not None  # valid_from has default
        assert row[2] is None  # valid_until is NULL by default
        conn.close()

    def test_get_stats(self, temp_db, setup_faq_data, sample_question_sources, sample_answer_sources):
        """Test getting source statistics."""
        ingestion = FAQSourceIngestion(temp_db)
        ingestion.ingest_question_sources_from_dataframe(sample_question_sources)
        ingestion.ingest_answer_sources_from_dataframe(sample_answer_sources)

        stats = ingestion.get_stats()

        assert stats['total_question_sources'] == 2
        assert stats['total_answer_sources'] == 2
        assert stats['valid_question_sources'] == 2
        assert stats['valid_answer_sources'] == 2

    def test_clear_tables(self, temp_db, setup_faq_data, sample_question_sources, sample_answer_sources):
        """Test clearing source tables."""
        ingestion = FAQSourceIngestion(temp_db)
        ingestion.ingest_question_sources_from_dataframe(sample_question_sources)
        ingestion.ingest_answer_sources_from_dataframe(sample_answer_sources)

        # Clear question sources
        result = ingestion.clear_question_sources()
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM faq_question_sources").fetchone()[0]
        assert count == 0
        conn.close()

        # Clear answer sources
        result = ingestion.clear_answer_sources()
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM faq_answer_sources").fetchone()[0]
        assert count == 0
        conn.close()

    def test_default_values(self, temp_db, setup_faq_data):
        """Test that default values are applied correctly."""
        ingestion = FAQSourceIngestion(temp_db)

        # Minimal source record
        df = pd.DataFrame([{
            "question_id": 1,
            "content_checksum": "a" * 64,
        }])
        result = ingestion.ingest_question_sources_from_dataframe(df)
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT is_primary_source, is_valid, valid_from, created_at "
            "FROM faq_question_sources WHERE question_id = 1"
        ).fetchone()
        assert row[0] == 0  # is_primary_source default FALSE
        assert row[1] == 1  # is_valid default TRUE
        assert row[2] is not None  # valid_from
        assert row[3] is not None  # created_at
        conn.close()
