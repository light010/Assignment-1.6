"""
Tests for FAQ data ingestion (questions and answers).

Following TDD approach:
1. Write tests that define expected behavior
2. Implement minimal code to pass tests
3. Refactor while keeping tests green

Schema Ground Truth:
- 02_faq_questions.sql: question_id (PK), question_text (NOT NULL), source_type,
  generation_method, status (NOT NULL, CHECK), created_at, modified_at
- 03_faq_answers.sql: answer_id (PK), question_id (FK NOT NULL), answer_text (NOT NULL),
  answer_format (CHECK), confidence_score (CHECK 0.0-1.0), status (NOT NULL, CHECK),
  created_at, modified_at
"""

import sqlite3
from pathlib import Path
import tempfile
import pytest
import pandas as pd

# Import the module we're testing (will create this)
from granular_impact.data_ingestion import FAQIngestion


@pytest.fixture
def temp_db():
    """Create a temporary database with schema for testing."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Create schema matching SQL files (ground truth)
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE faq_questions (
            question_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_text TEXT NOT NULL,
            source_type TEXT,
            generation_method TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'))
        );

        CREATE TABLE faq_answers (
            answer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            answer_text TEXT NOT NULL,
            answer_format TEXT DEFAULT 'html',
            confidence_score DOUBLE,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (status IN ('active', 'invalidated', 'archived', 'deleted')),
            CHECK (answer_format IN ('html', 'markdown', 'plain')),
            CHECK (confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0)),
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE
        );
    """)
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def sample_questions_data():
    """Sample FAQ questions as DataFrame."""
    return pd.DataFrame([
        {
            "question_id": 1,
            "question_text": "How many sick days are employees entitled to?",
            "source_type": "document",
            "generation_method": "llm_generated",
            "status": "active",
        },
        {
            "question_id": 2,
            "question_text": "What are the password requirements?",
            "source_type": "document",
            "generation_method": "llm_generated",
            "status": "active",
        },
    ])


@pytest.fixture
def sample_answers_data():
    """Sample FAQ answers as DataFrame."""
    return pd.DataFrame([
        {
            "answer_id": 1,
            "question_id": 1,
            "answer_text": "Employees are entitled to 10 sick days per year.",
            "answer_format": "html",
            "confidence_score": 0.95,
            "status": "active",
        },
        {
            "answer_id": 2,
            "question_id": 2,
            "answer_text": "Passwords must be at least 8 characters long.",
            "answer_format": "html",
            "confidence_score": 0.98,
            "status": "active",
        },
    ])


class TestFAQIngestion:
    """Test suite for FAQIngestion class."""

    def test_init(self, temp_db):
        """Test initialization with database path."""
        ingestion = FAQIngestion(temp_db)
        assert ingestion.db_path == temp_db

    def test_ingest_questions_from_csv(self, temp_db):
        """Test ingesting questions from CSV file."""
        csv_data = """question_text,source_type,generation_method,status
What is the vacation policy?,document,llm_generated,active
How do I enroll in benefits?,document,llm_generated,active"""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write(csv_data)

        try:
            ingestion = FAQIngestion(temp_db)
            result = ingestion.ingest_questions_from_csv(csv_path)

            assert result['success'] is True
            assert result['rows_inserted'] == 2

            # Verify database
            conn = sqlite3.connect(temp_db)
            count = conn.execute("SELECT COUNT(*) FROM faq_questions").fetchone()[0]
            assert count == 2
            conn.close()

        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_ingest_questions_from_dataframe(self, temp_db, sample_questions_data):
        """Test ingesting questions from DataFrame."""
        ingestion = FAQIngestion(temp_db)
        result = ingestion.ingest_questions_from_dataframe(sample_questions_data)

        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify data
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT question_text, source_type, status FROM faq_questions WHERE question_id = 1"
        ).fetchone()
        assert row[0] == "How many sick days are employees entitled to?"
        assert row[1] == "document"
        assert row[2] == "active"
        conn.close()

    def test_ingest_answers_from_csv(self, temp_db, sample_questions_data):
        """Test ingesting answers from CSV file."""
        # First insert questions
        ingestion = FAQIngestion(temp_db)
        ingestion.ingest_questions_from_dataframe(sample_questions_data)

        csv_data = """question_id,answer_text,answer_format,confidence_score,status
1,Employees get 10 sick days per year.,html,0.95,active
2,Password must be 8+ characters.,html,0.98,active"""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write(csv_data)

        try:
            result = ingestion.ingest_answers_from_csv(csv_path)

            assert result['success'] is True
            assert result['rows_inserted'] == 2

            # Verify database
            conn = sqlite3.connect(temp_db)
            count = conn.execute("SELECT COUNT(*) FROM faq_answers").fetchone()[0]
            assert count == 2
            conn.close()

        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_ingest_answers_from_dataframe(self, temp_db, sample_questions_data, sample_answers_data):
        """Test ingesting answers from DataFrame."""
        ingestion = FAQIngestion(temp_db)

        # First insert questions
        ingestion.ingest_questions_from_dataframe(sample_questions_data)

        # Then insert answers
        result = ingestion.ingest_answers_from_dataframe(sample_answers_data)

        assert result['success'] is True
        assert result['rows_inserted'] == 2

        # Verify data
        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT answer_text, confidence_score, status FROM faq_answers WHERE question_id = 1"
        ).fetchone()
        assert row[0] == "Employees are entitled to 10 sick days per year."
        assert row[1] == 0.95
        assert row[2] == "active"
        conn.close()

    def test_validate_question_status(self, temp_db):
        """Test question status validation (must be valid enum)."""
        ingestion = FAQIngestion(temp_db)

        # Valid statuses
        for status in ['active', 'invalidated', 'archived', 'deleted']:
            df = pd.DataFrame([{
                "question_text": f"Question with {status} status?",
                "status": status,
            }])
            result = ingestion.ingest_questions_from_dataframe(df)
            assert result['success'] is True, f"Should accept {status}"

        # Invalid status
        df = pd.DataFrame([{
            "question_text": "Invalid status question?",
            "status": "pending",
        }])
        result = ingestion.ingest_questions_from_dataframe(df)
        assert result['success'] is False
        assert 'status' in result['message'].lower()

    def test_validate_answer_format(self, temp_db, sample_questions_data):
        """Test answer format validation (must be html, markdown, or plain)."""
        ingestion = FAQIngestion(temp_db)
        ingestion.ingest_questions_from_dataframe(sample_questions_data)

        # Valid formats
        for fmt in ['html', 'markdown', 'plain']:
            df = pd.DataFrame([{
                "question_id": 1,
                "answer_text": f"Answer in {fmt} format",
                "answer_format": fmt,
            }])
            # Clear previous answers for question_id 1
            conn = sqlite3.connect(temp_db)
            conn.execute("DELETE FROM faq_answers WHERE question_id = 1")
            conn.commit()
            conn.close()

            result = ingestion.ingest_answers_from_dataframe(df)
            assert result['success'] is True, f"Should accept {fmt}"

        # Invalid format
        df = pd.DataFrame([{
            "question_id": 1,
            "answer_text": "Invalid format answer",
            "answer_format": "pdf",
        }])
        result = ingestion.ingest_answers_from_dataframe(df)
        assert result['success'] is False
        assert 'format' in result['message'].lower()

    def test_validate_confidence_score(self, temp_db, sample_questions_data):
        """Test confidence score validation (must be 0.0-1.0)."""
        ingestion = FAQIngestion(temp_db)
        ingestion.ingest_questions_from_dataframe(sample_questions_data)

        # Valid scores
        for score in [0.0, 0.5, 1.0, None]:
            df = pd.DataFrame([{
                "question_id": 1,
                "answer_text": "Valid score answer",
                "confidence_score": score,
            }])
            # Clear previous
            conn = sqlite3.connect(temp_db)
            conn.execute("DELETE FROM faq_answers WHERE question_id = 1")
            conn.commit()
            conn.close()

            result = ingestion.ingest_answers_from_dataframe(df)
            assert result['success'] is True, f"Should accept score {score}"

        # Invalid scores
        for score in [-0.1, 1.1, 2.0]:
            df = pd.DataFrame([{
                "question_id": 1,
                "answer_text": "Invalid score answer",
                "confidence_score": score,
            }])
            result = ingestion.ingest_answers_from_dataframe(df)
            assert result['success'] is False
            assert 'confidence' in result['message'].lower() or 'score' in result['message'].lower()

    def test_foreign_key_constraint(self, temp_db):
        """Test that answers require valid question_id (FK constraint)."""
        ingestion = FAQIngestion(temp_db)

        # Try to insert answer without corresponding question
        df = pd.DataFrame([{
            "question_id": 999,  # Non-existent question
            "answer_text": "This should fail",
        }])
        result = ingestion.ingest_answers_from_dataframe(df)
        assert result['success'] is False
        assert 'foreign key' in result['message'].lower() or 'question' in result['message'].lower()

    def test_required_fields(self, temp_db):
        """Test that required fields are enforced."""
        ingestion = FAQIngestion(temp_db)

        # Question without question_text
        df = pd.DataFrame([{"source_type": "document"}])
        result = ingestion.ingest_questions_from_dataframe(df)
        assert result['success'] is False
        assert 'required' in result['message'].lower()

        # Answer without answer_text
        df = pd.DataFrame([{"question_id": 1}])
        result = ingestion.ingest_answers_from_dataframe(df)
        assert result['success'] is False
        assert 'required' in result['message'].lower()

    def test_get_stats(self, temp_db, sample_questions_data, sample_answers_data):
        """Test getting FAQ statistics."""
        ingestion = FAQIngestion(temp_db)
        ingestion.ingest_questions_from_dataframe(sample_questions_data)
        ingestion.ingest_answers_from_dataframe(sample_answers_data)

        stats = ingestion.get_stats()

        assert stats['total_questions'] == 2
        assert stats['total_answers'] == 2
        assert stats['answered_questions'] == 2
        assert stats['unanswered_questions'] == 0

    def test_clear_tables(self, temp_db, sample_questions_data, sample_answers_data):
        """Test clearing FAQ tables."""
        ingestion = FAQIngestion(temp_db)
        ingestion.ingest_questions_from_dataframe(sample_questions_data)
        ingestion.ingest_answers_from_dataframe(sample_answers_data)

        # Clear answers first (due to FK)
        result = ingestion.clear_answers()
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM faq_answers").fetchone()[0]
        assert count == 0
        conn.close()

        # Clear questions
        result = ingestion.clear_questions()
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        count = conn.execute("SELECT COUNT(*) FROM faq_questions").fetchone()[0]
        assert count == 0
        conn.close()

    def test_default_values(self, temp_db):
        """Test that default values are applied correctly."""
        ingestion = FAQIngestion(temp_db)

        # Minimal question
        df = pd.DataFrame([{"question_text": "Minimal question?"}])
        result = ingestion.ingest_questions_from_dataframe(df)
        assert result['success'] is True

        conn = sqlite3.connect(temp_db)
        row = conn.execute(
            "SELECT status, created_at, modified_at FROM faq_questions WHERE question_id = 1"
        ).fetchone()
        assert row[0] == 'active'  # default status
        assert row[1] is not None  # created_at
        assert row[2] is not None  # modified_at
        conn.close()
