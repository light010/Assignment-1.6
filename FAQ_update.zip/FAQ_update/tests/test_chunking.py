"""
Tests for the chunking module.

Simple character-based chunking for computing content checksums.
Tests drive the minimal design - no overengineering.
"""

import pytest
from pathlib import Path


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def sample_content():
    """Sample markdown content for testing."""
    return """# Employee Handbook

## Vacation Policy

Employees are entitled to 10 days of paid vacation per year.
After 5 years of service, this increases to 15 days.

## Remote Work Policy

Remote work is available for eligible employees with manager approval."""


@pytest.fixture
def short_content():
    """Short content (less than default chunk size)."""
    return "Short content."


@pytest.fixture
def exact_chunk_size_content():
    """Content exactly matching chunk size."""
    return "A" * 100  # Exactly 100 characters


# ============================================================================
# Test Simple Chunker
# ============================================================================

class TestSimpleChunker:
    """Test the simple character-based chunker."""

    def test_chunker_exists(self):
        """Test that SimpleChunker can be imported."""
        from granular_impact.chunking import SimpleChunker
        assert SimpleChunker is not None

    def test_default_chunk_size(self):
        """Test default chunk size is 1000 characters."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker()
        assert chunker.chunk_size == 1000

    def test_custom_chunk_size(self):
        """Test custom chunk size can be set."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=500)
        assert chunker.chunk_size == 500

    def test_chunk_short_content(self, short_content):
        """Test chunking content shorter than chunk size."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=100)
        chunks = chunker.chunk(short_content)

        assert len(chunks) == 1
        assert chunks[0] == short_content

    def test_chunk_exact_size_content(self, exact_chunk_size_content):
        """Test chunking content exactly matching chunk size."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=100)
        chunks = chunker.chunk(exact_chunk_size_content)

        assert len(chunks) == 1
        assert chunks[0] == exact_chunk_size_content

    def test_chunk_longer_content(self, sample_content):
        """Test chunking content longer than chunk size."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=50)
        chunks = chunker.chunk(sample_content)

        # Should split into multiple chunks
        assert len(chunks) > 1

        # Each chunk except last should be exactly chunk_size
        for chunk in chunks[:-1]:
            assert len(chunk) == 50

        # Last chunk can be shorter
        assert len(chunks[-1]) <= 50

    def test_chunks_concatenate_to_original(self, sample_content):
        """Test that joining chunks recreates original content."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=50)
        chunks = chunker.chunk(sample_content)

        reconstructed = "".join(chunks)
        assert reconstructed == sample_content

    def test_empty_content(self):
        """Test chunking empty content."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker()
        chunks = chunker.chunk("")

        assert chunks == []

    def test_chunk_preserves_content(self):
        """Test that chunking doesn't modify content."""
        from granular_impact.chunking import SimpleChunker

        content = "Hello\nWorld\n\nNew paragraph."
        chunker = SimpleChunker(chunk_size=10)
        chunks = chunker.chunk(content)

        # Verify no data loss
        assert "".join(chunks) == content

    def test_chunk_size_validation(self):
        """Test that chunk_size must be positive."""
        from granular_impact.chunking import SimpleChunker

        with pytest.raises(ValueError):
            SimpleChunker(chunk_size=0)

        with pytest.raises(ValueError):
            SimpleChunker(chunk_size=-100)


# ============================================================================
# Test Chunk with Checksum Computation
# ============================================================================

class TestChunkWithChecksum:
    """Test chunking with checksum computation."""

    def test_compute_chunk_checksums(self, sample_content):
        """Test computing checksums for chunks."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=50)
        chunks_with_checksums = chunker.chunk_with_checksums(sample_content)

        # Should return list of (chunk_text, checksum) tuples
        assert isinstance(chunks_with_checksums, list)
        assert all(isinstance(item, tuple) for item in chunks_with_checksums)
        assert all(len(item) == 2 for item in chunks_with_checksums)

        # Verify checksums are 64-character hex strings (SHA-256)
        for chunk_text, checksum in chunks_with_checksums:
            assert isinstance(checksum, str)
            assert len(checksum) == 64
            assert all(c in '0123456789abcdef' for c in checksum)

    def test_same_content_same_checksum(self):
        """Test that same content produces same checksum."""
        from granular_impact.chunking import SimpleChunker

        content = "Test content for checksum"
        chunker = SimpleChunker(chunk_size=100)

        result1 = chunker.chunk_with_checksums(content)
        result2 = chunker.chunk_with_checksums(content)

        assert result1[0][1] == result2[0][1]  # Same checksum

    def test_different_content_different_checksum(self):
        """Test that different content produces different checksums."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=100)

        result1 = chunker.chunk_with_checksums("Content A")
        result2 = chunker.chunk_with_checksums("Content B")

        assert result1[0][1] != result2[0][1]  # Different checksums

    def test_empty_content_checksums(self):
        """Test checksums for empty content."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker()
        result = chunker.chunk_with_checksums("")

        assert result == []


# ============================================================================
# Integration Test
# ============================================================================

class TestChunkingIntegration:
    """Integration tests for chunking workflow."""

    def test_full_workflow(self, sample_content):
        """Test complete workflow: chunk content and compute checksums."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=100)

        # Get chunks with checksums
        results = chunker.chunk_with_checksums(sample_content)

        # Verify we got results
        assert len(results) > 0

        # Verify structure
        for chunk_text, checksum in results:
            assert isinstance(chunk_text, str)
            assert isinstance(checksum, str)
            assert len(chunk_text) <= 100
            assert len(checksum) == 64

        # Verify content integrity
        reconstructed = "".join([chunk for chunk, _ in results])
        assert reconstructed == sample_content

    def test_chunk_metadata_mapping(self, sample_content):
        """Test that chunk metadata can be mapped to database schema."""
        from granular_impact.chunking import SimpleChunker

        chunker = SimpleChunker(chunk_size=100)
        results = chunker.chunk_with_checksums(sample_content)

        # Simulate mapping to content_checksums table
        for i, (chunk_text, checksum) in enumerate(results):
            row = {
                'content_checksum': checksum,  # Primary key
                'file_type': 'markdown',
                'content_format': 'markdown',
                'title': f'Chunk {i+1}',
                'status': 'active',
                'markdown_file_path': f'/path/to/chunk_{i+1}.md',
            }

            # Verify required fields
            assert 'content_checksum' in row
            assert len(row['content_checksum']) == 64
            assert row['status'] in ['active', 'archived', 'deleted']
