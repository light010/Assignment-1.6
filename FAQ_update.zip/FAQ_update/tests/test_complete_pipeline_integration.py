"""
Test Complete Pipeline Integration (Questions + Answers)

Simulates the complete workflow from 2_faq_generation_ingestion.ipynb to verify
that both questions and answers load from CSV and can be ingested end-to-end.
"""

import pytest
import sqlite3
import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "granular_impact"))

from faq_generation import (
    QuestionGenerator,
    QuestionGeneratorConfig,
    AnswerGenerator,
    AnswerGeneratorConfig,
    Question,
    Document,
)
from data_ingestion import FAQIngestion, FAQSourceIngestion


class TestCompletePipelineIntegration:
    """Test the complete end-to-end pipeline with mock data."""

    def test_complete_questions_and_answers_workflow(self):
        """
        Simulate the complete workflow: Questions → Answers → Database

        This test verifies:
        1. QuestionGenerator loads questions from CSV
        2. AnswerGenerator loads answers from CSV
        3. Both DataFrames can be ingested into database
        4. Data is queryable after ingestion
        5. Foreign key relationships are maintained
        """
        # Create temporary database
        temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        db_path = temp_db.name
        temp_db.close()

        try:
            # Setup database schema
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            # Create all required tables
            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_questions (
                    question_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_text TEXT NOT NULL,
                    source_type TEXT,
                    generation_method TEXT,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_question_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'))
                )
            """)

            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_question_sources (
                    source_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_id INTEGER NOT NULL,
                    content_checksum TEXT NOT NULL,
                    is_primary_source BOOLEAN DEFAULT FALSE,
                    contribution_weight DOUBLE,
                    is_valid BOOLEAN NOT NULL DEFAULT TRUE,
                    valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    valid_until TEXT,
                    invalidation_reason TEXT,
                    invalidated_by_change_id INTEGER,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_qsrc_contribution CHECK (
                        contribution_weight IS NULL OR
                        (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
                    )
                )
            """)

            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_answers (
                    answer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_id INTEGER NOT NULL,
                    answer_text TEXT NOT NULL,
                    answer_format TEXT DEFAULT 'html',
                    confidence_score DOUBLE,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_answer_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted')),
                    CONSTRAINT chk_answer_format CHECK (answer_format IN ('html', 'markdown', 'plain')),
                    CONSTRAINT chk_confidence_score CHECK (confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0))
                )
            """)

            conn.execute("""
                CREATE TABLE IF NOT EXISTS faq_answer_sources (
                    source_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    answer_id INTEGER NOT NULL,
                    content_checksum TEXT NOT NULL,
                    is_primary_source BOOLEAN DEFAULT FALSE,
                    contribution_weight DOUBLE,
                    context_employed TEXT,
                    is_valid BOOLEAN NOT NULL DEFAULT TRUE,
                    valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    valid_until TEXT,
                    invalidation_reason TEXT,
                    invalidated_by_change_id INTEGER,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT chk_asrc_contribution CHECK (
                        contribution_weight IS NULL OR
                        (contribution_weight >= 0.0 AND contribution_weight <= 1.0)
                    )
                )
            """)

            conn.commit()
            conn.close()

            # ================================================================
            # COMPLETE WORKFLOW SIMULATION
            # ================================================================
            print("=" * 80)
            print("  COMPLETE FAQ PIPELINE SIMULATION (QUESTIONS + ANSWERS)")
            print("=" * 80)

            # Mock documents (not actually used in mock mode, but required)
            mock_documents = [
                Document(
                    page_content="dummy",
                    metadata={"checksum": "abc", "title": "Test"}
                )
            ]

            # ----------------------------------------
            # STEP 1: Generate Questions (Mock Mode)
            # ----------------------------------------
            q_config = QuestionGeneratorConfig(use_mock=True)
            q_gen = QuestionGenerator(q_config)

            df_questions, df_q_sources = q_gen.generate_and_map(
                documents=mock_documents,
                deduplicate=False
            )

            assert len(df_questions) > 0, "Should have questions from CSV"
            assert len(df_q_sources) > 0, "Should have question sources from CSV"

            print(f"\n✓ Loaded {len(df_questions)} questions from CSV")
            print(f"✓ Loaded {len(df_q_sources)} question sources from CSV")

            # ----------------------------------------
            # STEP 2: Ingest Questions into Database
            # ----------------------------------------
            faq_ingestion = FAQIngestion(db_path)
            source_ingestion = FAQSourceIngestion(db_path)

            result = faq_ingestion.ingest_questions_from_dataframe(df_questions)
            assert result['success'], f"Question ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} questions")

            result = source_ingestion.ingest_question_sources_from_dataframe(df_q_sources)
            assert result['success'], f"Source ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} question sources")

            # ----------------------------------------
            # STEP 3: Generate Answers (Mock Mode)
            # ----------------------------------------
            a_config = AnswerGeneratorConfig(use_mock=True)
            a_gen = AnswerGenerator(a_config)
            a_gen.load_context_documents(mock_documents)

            # Convert questions DataFrame to Question objects
            questions = []
            for i, row in df_questions.iterrows():
                q_source = df_q_sources[df_q_sources['question_id'] == i + 1]
                source_checksum = q_source['content_checksum'].iloc[0] if len(q_source) > 0 else ''

                q = Question(
                    question_text=row['question_text'],
                    source_checksum=source_checksum,
                    question_id=i + 1
                )
                questions.append(q)

            df_answers, df_a_sources = a_gen.generate_and_map(
                questions=questions,
                retrieve_context=False
            )

            assert len(df_answers) > 0, "Should have answers from CSV"
            assert len(df_a_sources) > 0, "Should have answer sources from CSV"

            print(f"\n✓ Loaded {len(df_answers)} answers from CSV")
            print(f"✓ Loaded {len(df_a_sources)} answer sources from CSV")

            # ----------------------------------------
            # STEP 4: Ingest Answers into Database
            # ----------------------------------------
            result = faq_ingestion.ingest_answers_from_dataframe(df_answers)
            assert result['success'], f"Answer ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} answers")

            result = source_ingestion.ingest_answer_sources_from_dataframe(df_a_sources)
            assert result['success'], f"Source ingestion failed: {result['message']}"
            print(f"✓ Ingested {result['rows_inserted']} answer sources")

            # ----------------------------------------
            # STEP 5: Verify Database Contents
            # ----------------------------------------
            conn = sqlite3.connect(db_path)

            # Verify questions
            questions_count = conn.execute("SELECT COUNT(*) FROM faq_questions").fetchone()[0]
            assert questions_count > 0, "No questions in database"
            print(f"\n✓ Verified {questions_count} questions in database")

            # Verify answers
            answers_count = conn.execute("SELECT COUNT(*) FROM faq_answers").fetchone()[0]
            assert answers_count > 0, "No answers in database"
            print(f"✓ Verified {answers_count} answers in database")

            # Verify question sources
            q_sources_count = conn.execute("SELECT COUNT(*) FROM faq_question_sources").fetchone()[0]
            assert q_sources_count > 0, "No question sources in database"
            print(f"✓ Verified {q_sources_count} question sources in database")

            # Verify answer sources
            a_sources_count = conn.execute("SELECT COUNT(*) FROM faq_answer_sources").fetchone()[0]
            assert a_sources_count > 0, "No answer sources in database"
            print(f"✓ Verified {a_sources_count} answer sources in database")

            # Verify foreign key relationships (question_id matches between questions and answers)
            fk_check = conn.execute("""
                SELECT COUNT(*) FROM faq_answers a
                JOIN faq_questions q ON a.question_id = q.question_id
            """).fetchone()[0]
            assert fk_check == answers_count, "Foreign key mismatch"
            print(f"✓ Verified foreign key relationships")

            # Verify checksums are valid SHA-256
            checksums = conn.execute("SELECT DISTINCT content_checksum FROM faq_question_sources").fetchall()
            for (checksum,) in checksums:
                assert len(checksum) == 64, f"Invalid checksum length: {len(checksum)}"
            print(f"✓ Verified all question checksums are valid SHA-256")

            checksums = conn.execute("SELECT DISTINCT content_checksum FROM faq_answer_sources").fetchall()
            for (checksum,) in checksums:
                assert len(checksum) == 64, f"Invalid checksum length: {len(checksum)}"
            print(f"✓ Verified all answer checksums are valid SHA-256")

            # Verify status values
            statuses = conn.execute("SELECT DISTINCT status FROM faq_questions").fetchall()
            valid_statuses = ["active", "invalidated", "archived", "deleted"]
            for (status,) in statuses:
                assert status in valid_statuses, f"Invalid question status: {status}"
            print(f"✓ Verified all question status values are valid")

            statuses = conn.execute("SELECT DISTINCT status FROM faq_answers").fetchall()
            for (status,) in statuses:
                assert status in valid_statuses, f"Invalid answer status: {status}"
            print(f"✓ Verified all answer status values are valid")

            # Verify answer formats
            formats = conn.execute("SELECT DISTINCT answer_format FROM faq_answers").fetchall()
            valid_formats = ["html", "markdown", "plain"]
            for (fmt,) in formats:
                assert fmt in valid_formats, f"Invalid answer format: {fmt}"
            print(f"✓ Verified all answer formats are valid")

            conn.close()

            print("\n" + "=" * 80)
            print("  COMPLETE PIPELINE SIMULATION SUCCESS")
            print(f"    Questions: {questions_count}")
            print(f"    Answers: {answers_count}")
            print(f"    Question Sources: {q_sources_count}")
            print(f"    Answer Sources: {a_sources_count}")
            print("=" * 80)

        finally:
            # Cleanup
            Path(db_path).unlink(missing_ok=True)
