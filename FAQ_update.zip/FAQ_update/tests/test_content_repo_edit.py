"""
Tests for content_repo_edit module.

Following TDD approach:
1. Red: Write tests that fail
2. Green: Implement code to pass
3. Refactor: Improve while keeping tests green

Tests cover:
- Version auto-increment
- Status management (deactivating old versions)
- Version history tracking
- Version comparison
"""

import sqlite3
from pathlib import Path
import tempfile
import pytest
import pandas as pd

from granular_impact.data_ingestion.content_repo_edit import ContentRepoEditIngestion


@pytest.fixture
def temp_db():
    """Create a temporary database with schema for testing."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Create schema matching 00_content_repo.sql
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_type TEXT,
            raw_file_version_nbr INT DEFAULT 1,
            raw_file_path TEXT,
            extracted_markdown_file_path TEXT,
            title_nme TEXT,
            content_checksum TEXT,
            file_status TEXT,
            created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64),
            CHECK (file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived'))
        );
    """)
    conn.close()

    yield db_path

    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def base_data_v1():
    """Base version 1 data."""
    return pd.DataFrame([
        {
            "raw_file_nme": "handbook.pdf",
            "raw_file_type": "pdf",
            "raw_file_version_nbr": 1,
            "title_nme": "Employee Handbook - 10 sick days",
            "content_checksum": "a" * 64,
            "file_status": "Active",
        },
        {
            "raw_file_nme": "remote_policy.pdf",
            "raw_file_type": "pdf",
            "raw_file_version_nbr": 1,
            "title_nme": "Remote Work Policy - 2 days/week",
            "content_checksum": "b" * 64,
            "file_status": "Active",
        }
    ])


@pytest.fixture
def edited_data_v2():
    """Edited version 2 data (content changed)."""
    return pd.DataFrame([
        {
            "raw_file_nme": "handbook.pdf",
            "raw_file_type": "pdf",
            "title_nme": "Employee Handbook - 12 sick days",
            "content_checksum": "c" * 64,  # Different checksum
        },
        {
            "raw_file_nme": "remote_policy.pdf",
            "raw_file_type": "pdf",
            "title_nme": "Remote Work Policy - 3 days/week",
            "content_checksum": "d" * 64,  # Different checksum
        }
    ])


class TestContentRepoEditIngestion:
    """Test suite for ContentRepoEditIngestion class."""

    def test_init(self, temp_db):
        """Test initialization."""
        ingestion = ContentRepoEditIngestion(temp_db)
        assert ingestion.db_path == temp_db

    def test_ingest_first_version(self, temp_db):
        """Test ingesting first version (no previous version exists)."""
        ingestion = ContentRepoEditIngestion(temp_db)

        df = pd.DataFrame([{
            "raw_file_nme": "new_policy.pdf",
            "title_nme": "New Policy v1",
            "content_checksum": "e" * 64,
        }])

        result = ingestion.ingest_edited_dataframe(df)

        assert result['success'] is True
        assert result['rows_inserted'] == 1
        assert len(result['version_updates']) == 1
        assert result['version_updates'][0]['new_version'] == 1
        assert result['version_updates'][0]['old_version'] is None

    def test_auto_increment_version(self, temp_db, base_data_v1, edited_data_v2):
        """Test automatic version increment."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Ingest v1
        result_v1 = ingestion.ingest_from_dataframe(base_data_v1)
        assert result_v1['success'] is True

        # Ingest edited version (should auto-increment to v2)
        result_v2 = ingestion.ingest_edited_dataframe(edited_data_v2)

        assert result_v2['success'] is True
        assert result_v2['rows_inserted'] == 2

        # Verify versions
        for update in result_v2['version_updates']:
            assert update['old_version'] == 1
            assert update['new_version'] == 2

        # Verify in database
        conn = sqlite3.connect(temp_db)
        count = conn.execute(
            "SELECT COUNT(*) FROM content_repo WHERE raw_file_version_nbr = 2"
        ).fetchone()[0]
        assert count == 2
        conn.close()

    def test_deactivate_previous_versions(self, temp_db, base_data_v1, edited_data_v2):
        """Test that previous versions are marked as Inactive."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Ingest v1
        ingestion.ingest_from_dataframe(base_data_v1)

        # Ingest v2 with deactivation
        result = ingestion.ingest_edited_dataframe(
            edited_data_v2,
            deactivate_previous=True
        )

        assert result['success'] is True

        # Verify v1 is Inactive
        conn = sqlite3.connect(temp_db)
        v1_statuses = conn.execute(
            "SELECT file_status FROM content_repo WHERE raw_file_version_nbr = 1"
        ).fetchall()

        for status in v1_statuses:
            assert status[0] == 'Inactive'

        # Verify v2 is Active
        v2_statuses = conn.execute(
            "SELECT file_status FROM content_repo WHERE raw_file_version_nbr = 2"
        ).fetchall()

        for status in v2_statuses:
            assert status[0] == 'Active'

        conn.close()

    def test_keep_previous_active(self, temp_db, base_data_v1, edited_data_v2):
        """Test keeping previous versions Active (deactivate_previous=False)."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Ingest v1
        ingestion.ingest_from_dataframe(base_data_v1)

        # Ingest v2 without deactivation
        result = ingestion.ingest_edited_dataframe(
            edited_data_v2,
            deactivate_previous=False
        )

        assert result['success'] is True

        # Verify v1 remains Active
        conn = sqlite3.connect(temp_db)
        v1_statuses = conn.execute(
            "SELECT file_status FROM content_repo WHERE raw_file_version_nbr = 1"
        ).fetchall()

        for status in v1_statuses:
            assert status[0] == 'Active'

        conn.close()

    def test_manual_version_numbers(self, temp_db):
        """Test using manual version numbers (auto_increment=False)."""
        ingestion = ContentRepoEditIngestion(temp_db)

        df = pd.DataFrame([{
            "raw_file_nme": "manual.pdf",
            "raw_file_version_nbr": 5,  # Manual version
            "title_nme": "Manual Version 5",
            "content_checksum": "f" * 64,
        }])

        result = ingestion.ingest_edited_dataframe(
            df,
            auto_increment_version=False
        )

        assert result['success'] is True

        # Verify version is 5 (not auto-incremented)
        conn = sqlite3.connect(temp_db)
        version = conn.execute(
            "SELECT raw_file_version_nbr FROM content_repo WHERE raw_file_nme = 'manual.pdf'"
        ).fetchone()[0]

        assert version == 5
        conn.close()

    def test_get_version_history(self, temp_db):
        """Test retrieving version history for a file."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Create 3 versions
        for i in range(1, 4):
            df = pd.DataFrame([{
                "raw_file_nme": "evolving.pdf",
                "raw_file_version_nbr": i,
                "title_nme": f"Version {i}",
                "content_checksum": chr(96 + i) * 64,  # a, b, c
                "file_status": "Active" if i == 3 else "Inactive",
            }])
            ingestion.ingest_from_dataframe(df)

        # Get history
        history = ingestion.get_version_history("evolving.pdf")

        assert len(history) == 3
        # Should be sorted newest first
        assert history[0]['version'] == 3
        assert history[1]['version'] == 2
        assert history[2]['version'] == 1

        # Verify latest is Active
        assert history[0]['status'] == 'Active'
        assert history[1]['status'] == 'Inactive'

    def test_compare_versions(self, temp_db, base_data_v1, edited_data_v2):
        """Test comparing two versions of a file."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Ingest v1 and v2
        ingestion.ingest_from_dataframe(base_data_v1)
        ingestion.ingest_edited_dataframe(edited_data_v2)

        # Compare versions
        comparison = ingestion.compare_versions("handbook.pdf", 1, 2)

        assert comparison['exists'] is True
        assert comparison['file_name'] == "handbook.pdf"
        assert comparison['old_version']['version'] == 1
        assert comparison['new_version']['version'] == 2

        # Verify changes detected
        assert comparison['changes']['checksum_changed'] is True
        assert comparison['changes']['content_changed'] is True
        assert comparison['changes']['title_changed'] is True

        # Verify checksums
        assert comparison['old_version']['checksum'] == "a" * 64
        assert comparison['new_version']['checksum'] == "c" * 64

    def test_compare_nonexistent_versions(self, temp_db):
        """Test comparing versions that don't exist."""
        ingestion = ContentRepoEditIngestion(temp_db)

        comparison = ingestion.compare_versions("missing.pdf", 1, 2)

        assert comparison['exists'] is False
        assert 'not found' in comparison['message'].lower()

    def test_multiple_edits_same_file(self, temp_db):
        """Test multiple sequential edits (v1 -> v2 -> v3)."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Version 1
        v1 = pd.DataFrame([{
            "raw_file_nme": "policy.pdf",
            "title_nme": "Policy v1",
            "content_checksum": "a" * 64,
        }])
        ingestion.ingest_from_dataframe(v1)

        # Version 2 (edited)
        v2 = pd.DataFrame([{
            "raw_file_nme": "policy.pdf",
            "title_nme": "Policy v2",
            "content_checksum": "b" * 64,
        }])
        result2 = ingestion.ingest_edited_dataframe(v2)
        assert result2['version_updates'][0]['new_version'] == 2

        # Version 3 (edited again)
        v3 = pd.DataFrame([{
            "raw_file_nme": "policy.pdf",
            "title_nme": "Policy v3",
            "content_checksum": "c" * 64,
        }])
        result3 = ingestion.ingest_edited_dataframe(v3)
        assert result3['version_updates'][0]['new_version'] == 3

        # Verify all 3 versions exist
        conn = sqlite3.connect(temp_db)
        count = conn.execute(
            "SELECT COUNT(*) FROM content_repo WHERE raw_file_nme = 'policy.pdf'"
        ).fetchone()[0]
        assert count == 3

        # Only v3 should be Active
        active_count = conn.execute(
            "SELECT COUNT(*) FROM content_repo WHERE raw_file_nme = 'policy.pdf' AND file_status = 'Active'"
        ).fetchone()[0]
        assert active_count == 1

        active_version = conn.execute(
            "SELECT raw_file_version_nbr FROM content_repo WHERE raw_file_nme = 'policy.pdf' AND file_status = 'Active'"
        ).fetchone()[0]
        assert active_version == 3

        conn.close()

    def test_ingest_from_csv_file(self, temp_db, base_data_v1):
        """Test ingesting edited version from CSV file."""
        ingestion = ContentRepoEditIngestion(temp_db)

        # Ingest base version
        ingestion.ingest_from_dataframe(base_data_v1)

        # Create CSV for v2
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            csv_path = f.name
            f.write("raw_file_nme,title_nme,content_checksum\n")
            f.write("handbook.pdf,Handbook v2 Edited,c" + "c" * 63 + "\n")

        try:
            result = ingestion.ingest_edited_version(csv_path)

            assert result['success'] is True
            assert result['rows_inserted'] == 1
            assert result['version_updates'][0]['new_version'] == 2

        finally:
            Path(csv_path).unlink(missing_ok=True)
