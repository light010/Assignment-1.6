"""
Tests for ChangeDetectionQueries.

Validates database query functionality for change detection using V8.2 schema.
"""

import pytest
from datetime import datetime, timedelta
from granular_impact.detection import ChangeDetectionQueries, ChecksumExtractor
from granular_impact.database.models import ChangeType, ContentChange


class TestChangeDetectionQueries:
    """Test suite for ChangeDetectionQueries (V8.2 schema)."""

    def test_get_previous_checksums_for_file_empty(self, temp_database):
        """Test querying checksums for file with no previous data."""
        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=temp_database,
            file_name="handbook.pdf",
            use_spark=False,
        )

        assert isinstance(checksums, dict)
        assert len(checksums) == 0

    def test_get_previous_checksums_for_file(self, populated_database):
        """Test querying checksums for file with existing data."""
        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=populated_database,
            file_name="handbook.pdf",
            use_spark=False,
        )

        assert isinstance(checksums, dict)
        assert len(checksums) >= 1

        # Verify data structure
        for checksum, data in checksums.items():
            assert len(checksum) == 64  # SHA-256
            assert "file_name" in data
            assert data["file_name"] == "handbook.pdf"

    def test_get_previous_checksums_with_since_date(self, populated_database):
        """Test querying checksums with date filtering."""
        # Query with future date (should return all data since all data is "before" future)
        future_date = datetime.now() + timedelta(days=1)

        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=populated_database,
            file_name="handbook.pdf",
            since_date=future_date,
            use_spark=False,
        )

        # Since_date means "created BEFORE this date", future date should return existing data
        assert len(checksums) >= 1

        # Query with past date (should return nothing - no data created before past date)
        past_date = datetime.now() - timedelta(days=365)

        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=populated_database,
            file_name="handbook.pdf",
            since_date=past_date,
            use_spark=False,
        )

        # No data should be older than 1 year ago
        assert len(checksums) == 0

    def test_store_change_detection_results(self, temp_database):
        """Test storing change detection results."""
        extractor = ChecksumExtractor()

        changes = [
            ContentChange(
                old_checksum="",
                new_checksum=extractor.compute_checksum("New content"),
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="handbook.pdf",
                page_number=1,
                new_content="New content",
                old_content=None,
                similarity_score=0.0,
            ),
            ContentChange(
                old_checksum=extractor.compute_checksum("Old content"),
                new_checksum=extractor.compute_checksum("Modified content"),
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name="handbook.pdf",
                page_number=2,
                old_content="Old content",
                new_content="Modified content",
                similarity_score=0.85,
            ),
        ]

        inserted = ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="TEST_RUN_001",
            use_spark=False,
        )

        assert inserted == 2

        # Verify data was inserted
        cursor = temp_database.execute(
            """
            SELECT COUNT(*) as count
            FROM content_change_log
            WHERE detection_run_id = 'TEST_RUN_001'
            """
        )
        result = cursor.fetchone()
        assert result[0] == 2

    def test_store_change_detection_results_sets_requires_regeneration(
        self, temp_database
    ):
        """Test that requires_faq_regeneration flag is set correctly."""
        extractor = ChecksumExtractor()

        changes = [
            ContentChange(
                old_checksum="",
                new_checksum=extractor.compute_checksum("New"),
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                page_number=1,
                similarity_score=0.0,
            ),
            ContentChange(
                old_checksum=extractor.compute_checksum("Unchanged"),
                new_checksum=extractor.compute_checksum("Unchanged"),
                change_type=ChangeType.UNCHANGED_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                page_number=2,
                similarity_score=1.0,
            ),
        ]

        ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="TEST_REGEN",
            use_spark=False,
        )

        # Verify NEW requires regeneration
        cursor = temp_database.execute(
            """
            SELECT requires_faq_regeneration
            FROM content_change_log
            WHERE change_type = 'new_content'
            """
        )
        result = cursor.fetchone()
        assert result[0] == 1  # TRUE

        # Verify UNCHANGED does not require regeneration
        cursor = temp_database.execute(
            """
            SELECT requires_faq_regeneration
            FROM content_change_log
            WHERE change_type = 'unchanged_content'
            """
        )
        result = cursor.fetchone()
        assert result[0] == 0  # FALSE

    def test_get_faqs_for_checksum_no_faqs(self, temp_database):
        """Test querying FAQs for checksum with no results."""
        faqs = ChangeDetectionQueries.get_faqs_for_checksum(
            conn=temp_database,
            checksum="a" * 64,  # Non-existent checksum
            use_spark=False,
        )

        assert isinstance(faqs, list)
        assert len(faqs) == 0

    def test_get_faqs_for_checksum_with_question_source(self, populated_database):
        """Test querying FAQs linked via question source."""
        # Get the checksum from populated database
        cursor = populated_database.execute(
            "SELECT content_checksum FROM faq_question_sources LIMIT 1"
        )
        result = cursor.fetchone()
        checksum = result[0]

        faqs = ChangeDetectionQueries.get_faqs_for_checksum(
            conn=populated_database,
            checksum=checksum,
            use_spark=False,
        )

        assert len(faqs) >= 1

        # Verify structure
        for faq in faqs:
            assert "question_id" in faq
            assert "question_text" in faq or "question_txt" in faq
            assert "source_type" in faq

    def test_get_faqs_for_checksum_with_answer_source(self, populated_database):
        """Test querying FAQs linked via answer source."""
        # Get the checksum from populated database
        cursor = populated_database.execute(
            "SELECT content_checksum FROM faq_answer_sources LIMIT 1"
        )
        result = cursor.fetchone()
        checksum = result[0]

        faqs = ChangeDetectionQueries.get_faqs_for_checksum(
            conn=populated_database,
            checksum=checksum,
            use_spark=False,
        )

        assert len(faqs) >= 1

        # Should include answer-linked FAQs
        answer_faqs = [f for f in faqs if f["source_type"] == "answer"]
        assert len(answer_faqs) >= 1

    def test_store_and_retrieve_round_trip(self, temp_database):
        """Test storing changes and retrieving checksums (round trip) - V8.2 schema."""
        extractor = ChecksumExtractor()

        # Step 1: Store a change
        new_checksum = extractor.compute_checksum("Test content")

        changes = [
            ContentChange(
                old_checksum="",
                new_checksum=new_checksum,
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                page_number=1,
                similarity_score=0.0,
            )
        ]

        # First, insert into content_checksums (V8.2 schema)
        temp_database.execute(
            """
            INSERT INTO content_checksums (
                content_checksum,
                file_name,
                page_number,
                content_text,
                status
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (new_checksum, "test.pdf", 1, "Test content", "active"),
        )
        temp_database.commit()

        ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="ROUND_TRIP",
            use_spark=False,
        )

        # Step 2: Retrieve checksums
        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=temp_database,
            file_name="test.pdf",
            use_spark=False,
        )

        # Should find the checksum we just stored
        assert new_checksum in checksums

    def test_query_handles_multiple_files(self, temp_database):
        """Test that queries are scoped to specific file - V8.2 schema."""
        extractor = ChecksumExtractor()

        # Insert content for multiple files into content_checksums (V8.2)
        temp_database.execute(
            """
            INSERT INTO content_checksums (
                content_checksum,
                file_name,
                page_number,
                content_text,
                status
            ) VALUES
                (?, 'file1.pdf', 1, 'File 1 content', 'active'),
                (?, 'file2.pdf', 1, 'File 2 content', 'active')
            """,
            (
                extractor.compute_checksum("File 1 content"),
                extractor.compute_checksum("File 2 content"),
            ),
        )
        temp_database.commit()

        # Query for file1 only
        checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
            conn=temp_database,
            file_name="file1.pdf",
            use_spark=False,
        )

        # Should only return file1 checksums
        assert len(checksums) == 1
        for checksum, data in checksums.items():
            assert data["file_name"] == "file1.pdf"

    def test_store_change_with_diff_data(self, temp_database):
        """Test that diff_data (LLM-friendly diff) is persisted to database."""
        extractor = ChecksumExtractor()

        # Create a change with llm_friendly_diff populated
        llm_diff_json = '{"total_changes": "Found 1 change", "all_changes": [{"change_num": 1, "before": "Old text", "after": "New text", "what_changed": [{"replaced": "Old -> New"}]}]}'

        changes = [
            ContentChange(
                old_checksum=extractor.compute_checksum("Old text"),
                new_checksum=extractor.compute_checksum("New text"),
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                page_number=1,
                old_content="Old text",
                new_content="New text",
                similarity_score=0.85,
                llm_friendly_diff=llm_diff_json,
            ),
        ]

        # Store the change
        inserted = ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="TEST_DIFF_DATA",
            use_spark=False,
        )

        assert inserted == 1

        # Verify diff_data was stored
        cursor = temp_database.execute(
            """
            SELECT diff_data, change_type, similarity_score
            FROM content_change_log
            WHERE detection_run_id = 'TEST_DIFF_DATA'
            """
        )
        result = cursor.fetchone()

        assert result is not None, "Change record not found"
        stored_diff_data = result[0]
        stored_change_type = result[1]
        stored_similarity = result[2]

        # Verify diff_data is not NULL and contains the LLM-friendly diff
        assert stored_diff_data is not None, "diff_data should not be NULL"
        assert stored_diff_data == llm_diff_json, "diff_data should match the llm_friendly_diff"
        assert stored_change_type == "modified_content"
        assert stored_similarity == 0.85

    def test_store_change_diff_data_null_for_new_content(self, temp_database):
        """Test that diff_data is NULL for NEW content (no previous version to diff)."""
        extractor = ChecksumExtractor()

        changes = [
            ContentChange(
                old_checksum="",
                new_checksum=extractor.compute_checksum("Brand new content"),
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="new.pdf",
                page_number=1,
                old_content=None,
                new_content="Brand new content",
                similarity_score=0.0,
                llm_friendly_diff=None,
            ),
        ]

        inserted = ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="TEST_NEW_CONTENT",
            use_spark=False,
        )

        assert inserted == 1

        # Verify diff_data is NULL for new content
        cursor = temp_database.execute(
            """
            SELECT diff_data, change_type
            FROM content_change_log
            WHERE detection_run_id = 'TEST_NEW_CONTENT'
            """
        )
        result = cursor.fetchone()

        assert result is not None
        stored_diff_data = result[0]
        stored_change_type = result[1]

        assert stored_diff_data is None, "diff_data should be NULL for new content"
        assert stored_change_type == "new_content"

    def test_store_change_with_json_diff_data(self, temp_database):
        """Test that diff_data is stored as valid JSON with correct structure."""
        import json
        extractor = ChecksumExtractor()

        # Create a change with JSON diff_data (simplified structure)
        json_diff = json.dumps({
            "total_changes": 1,
            "change_types": {"replace": 1, "insert": 0, "delete": 0},
            "changes": [{
                "change_num": 1,
                "change_type": "replace",
                "before": "Employees get 12 sick days per year",
                "after": "Employees get 10 sick days per year",
                "token_changes": [{
                    "type": "replace",
                    "old_value": "12",
                    "new_value": "10"
                }]
            }]
        })

        changes = [
            ContentChange(
                old_checksum=extractor.compute_checksum("Employees get 12 sick days per year"),
                new_checksum=extractor.compute_checksum("Employees get 10 sick days per year"),
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name="handbook.pdf",
                page_number=5,
                old_content="Employees get 12 sick days per year",
                new_content="Employees get 10 sick days per year",
                similarity_score=0.92,
                llm_friendly_diff=json_diff,
            ),
        ]

        # Store the change
        inserted = ChangeDetectionQueries.store_change_detection_results(
            conn=temp_database,
            changes=changes,
            detection_run_id="TEST_JSON_DIFF",
            use_spark=False,
        )

        assert inserted == 1

        # Verify JSON structure is preserved
        cursor = temp_database.execute(
            """
            SELECT diff_data, change_type, similarity_score
            FROM content_change_log
            WHERE detection_run_id = 'TEST_JSON_DIFF'
            """
        )
        result = cursor.fetchone()

        assert result is not None
        stored_diff_data = result[0]
        stored_change_type = result[1]
        stored_similarity = result[2]

        # Verify it's valid JSON
        assert stored_diff_data is not None, "diff_data should not be NULL"
        diff_obj = json.loads(stored_diff_data)

        # Verify JSON structure (simplified - no format_version, flat structure)
        assert "total_changes" in diff_obj
        assert diff_obj["total_changes"] == 1
        assert "change_types" in diff_obj
        assert diff_obj["change_types"]["replace"] == 1
        assert "changes" in diff_obj
        assert len(diff_obj["changes"]) == 1

        # Verify change details
        change = diff_obj["changes"][0]
        assert change["change_num"] == 1
        assert change["change_type"] == "replace"
        assert change["before"] == "Employees get 12 sick days per year"
        assert change["after"] == "Employees get 10 sick days per year"

        # Verify token-level changes
        assert "token_changes" in change
        assert len(change["token_changes"]) == 1
        token_change = change["token_changes"][0]
        assert token_change["type"] == "replace"
        assert token_change["old_value"] == "12"
        assert token_change["new_value"] == "10"

        # Verify other fields
        assert stored_change_type == "modified_content"
        assert stored_similarity == 0.92
