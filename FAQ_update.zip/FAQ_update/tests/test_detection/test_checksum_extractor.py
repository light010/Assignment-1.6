"""
Tests for ChecksumExtractor.

Validates checksum computation for different algorithms.
"""

import pytest
from granular_impact.detection import ChecksumExtractor


class TestChecksumExtractor:
    """Test suite for ChecksumExtractor."""

    def test_init_default_algorithm(self):
        """Test initialization with default SHA-256 algorithm."""
        extractor = ChecksumExtractor()
        assert extractor.algorithm == "sha256"

    def test_init_custom_algorithm(self):
        """Test initialization with custom algorithm."""
        extractor = ChecksumExtractor(algorithm="sha512")
        assert extractor.algorithm == "sha512"

    def test_compute_checksum_sha256(self):
        """Test SHA-256 checksum computation."""
        extractor = ChecksumExtractor(algorithm="sha256")
        content = "Employees receive 10 sick days per year."
        checksum = extractor.compute_checksum(content)

        # SHA-256 produces 64 hex characters
        assert len(checksum) == 64
        assert isinstance(checksum, str)
        assert all(c in "0123456789abcdef" for c in checksum)

    def test_compute_checksum_deterministic(self):
        """Test that same content produces same checksum."""
        extractor = ChecksumExtractor()
        content = "Test content for deterministic hashing"

        checksum1 = extractor.compute_checksum(content)
        checksum2 = extractor.compute_checksum(content)

        assert checksum1 == checksum2

    def test_compute_checksum_different_content(self):
        """Test that different content produces different checksums."""
        extractor = ChecksumExtractor()
        content1 = "Employees receive 10 sick days per year."
        content2 = "Employees receive 12 sick days per year."

        checksum1 = extractor.compute_checksum(content1)
        checksum2 = extractor.compute_checksum(content2)

        assert checksum1 != checksum2

    def test_compute_checksum_empty_string(self):
        """Test checksum computation for empty string."""
        extractor = ChecksumExtractor()
        checksum = extractor.compute_checksum("")

        # Should still produce valid checksum
        assert len(checksum) == 64
        assert isinstance(checksum, str)

    def test_compute_checksum_whitespace_sensitive(self):
        """Test that checksums are sensitive to whitespace differences."""
        extractor = ChecksumExtractor()
        content1 = "Test content"
        content2 = "Test  content"  # Extra space

        checksum1 = extractor.compute_checksum(content1)
        checksum2 = extractor.compute_checksum(content2)

        assert checksum1 != checksum2

    def test_compute_checksum_case_sensitive(self):
        """Test that checksums are case-sensitive."""
        extractor = ChecksumExtractor()
        content1 = "Test Content"
        content2 = "test content"

        checksum1 = extractor.compute_checksum(content1)
        checksum2 = extractor.compute_checksum(content2)

        assert checksum1 != checksum2

    def test_compute_checksum_unicode(self):
        """Test checksum computation with Unicode characters."""
        extractor = ChecksumExtractor()
        content = "Caf\u00e9 r\u00e9sum\u00e9 \u4e2d\u6587 \u0645\u0631\u062d\u0628\u0627"  # café résumé 中文 مرحبا

        checksum = extractor.compute_checksum(content)

        # Should handle Unicode correctly
        assert len(checksum) == 64
        assert isinstance(checksum, str)

    @pytest.mark.parametrize(
        "algorithm,expected_length",
        [
            ("md5", 32),
            ("sha1", 40),
            ("sha256", 64),
            ("sha512", 128),
        ],
    )
    def test_algorithms(self, algorithm, expected_length):
        """Test different hashing algorithms."""
        extractor = ChecksumExtractor(algorithm=algorithm)
        content = "Test content"
        checksum = extractor.compute_checksum(content)

        assert len(checksum) == expected_length
        assert isinstance(checksum, str)

    def test_unsupported_algorithm(self):
        """Test that unsupported algorithm raises error."""
        extractor = ChecksumExtractor(algorithm="invalid_algorithm")
        content = "Test content"

        with pytest.raises(ValueError, match="Unsupported algorithm"):
            extractor.compute_checksum(content)

    def test_multiline_content(self):
        """Test checksum computation with multiline content."""
        extractor = ChecksumExtractor()
        content = """This is a multiline
        content with multiple lines
        and different indentation."""

        checksum = extractor.compute_checksum(content)

        # Should produce valid checksum
        assert len(checksum) == 64
        assert isinstance(checksum, str)

    def test_compute_checksum_real_world_example(self):
        """Test with real-world policy content."""
        extractor = ChecksumExtractor()
        content = """
        ## Sick Leave Policy

        Employees are entitled to sick leave for illness, injury, or medical appointments.

        ### Eligibility
        - Full-time employees: 10 sick days per year
        - Part-time employees: Pro-rated based on hours worked

        ### Accrual
        Sick days accrue at a rate of 0.83 days per month, effective January 1, 2024.
        """

        checksum = extractor.compute_checksum(content)

        # Should produce valid checksum
        assert len(checksum) == 64
        # Verify it's deterministic
        assert checksum == extractor.compute_checksum(content)