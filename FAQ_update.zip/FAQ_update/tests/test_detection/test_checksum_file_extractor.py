"""
Tests for ChecksumFileExtractor.

Validates checksum extraction from various file sources.
"""

import csv
import json
import pytest
from pathlib import Path
from granular_impact.detection import ChecksumExtractor, ChecksumFileExtractor


class TestChecksumFileExtractor:
    """Test suite for ChecksumFileExtractor."""

    def test_init_default(self):
        """Test initialization with default settings."""
        extractor = ChecksumFileExtractor()
        assert extractor.checksum_extractor.algorithm == "sha256"

    def test_init_custom_algorithm(self):
        """Test initialization with custom algorithm."""
        extractor = ChecksumFileExtractor(checksum_algorithm="sha512")
        assert extractor.checksum_extractor.algorithm == "sha512"

    def test_extract_from_markdown_files(self, tmp_path):
        """Test extracting checksums from markdown files."""
        # Create test markdown files
        md_dir = tmp_path / "markdown"
        md_dir.mkdir()

        (md_dir / "page1.md").write_text("Content for page 1")
        (md_dir / "page2.md").write_text("Content for page 2")
        (md_dir / "subdir").mkdir()
        (md_dir / "subdir" / "page3.md").write_text("Content for page 3")

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_markdown_files(md_dir)

        # Should extract 2 files (not recursive by default with *.md)
        assert len(checksums_data) >= 2

        # Verify data structure
        for checksum, data in checksums_data.items():
            assert len(checksum) == 64  # SHA-256
            assert "text" in data
            assert "markdown_path" in data
            assert "file_name" in data
            assert data["text"] in ["Content for page 1", "Content for page 2", "Content for page 3"]

    def test_extract_from_markdown_files_with_pattern(self, tmp_path):
        """Test extracting with glob pattern."""
        md_dir = tmp_path / "markdown"
        md_dir.mkdir()

        (md_dir / "handbook_page_1.md").write_text("Page 1")
        (md_dir / "handbook_page_2.md").write_text("Page 2")
        (md_dir / "other.md").write_text("Other")

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_markdown_files(md_dir, file_name_pattern="handbook_*.md")

        # Should only extract handbook files
        assert len(checksums_data) == 2

    def test_extract_page_number_from_filename(self):
        """Test page number extraction from filename patterns."""
        extractor = ChecksumFileExtractor()

        # Test various patterns
        assert extractor._extract_page_number("handbook_page_5") == 5
        assert extractor._extract_page_number("handbook_p42") == 42
        assert extractor._extract_page_number("handbook_123") == 123
        assert extractor._extract_page_number("handbook") is None

    def test_extract_from_markdown_directory_not_found(self, tmp_path):
        """Test error handling for non-existent directory."""
        extractor = ChecksumFileExtractor()

        with pytest.raises(FileNotFoundError, match="Markdown directory not found"):
            extractor.extract_from_markdown_files(tmp_path / "nonexistent")

    def test_extract_from_csv(self, tmp_path):
        """Test extracting checksums from CSV file."""
        csv_path = tmp_path / "content.csv"

        # Create test CSV
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f, fieldnames=["content_text", "file_name", "page_number"]
            )
            writer.writeheader()
            writer.writerow(
                {
                    "content_text": "Content for page 1",
                    "file_name": "handbook.pdf",
                    "page_number": "1",
                }
            )
            writer.writerow(
                {
                    "content_text": "Content for page 2",
                    "file_name": "handbook.pdf",
                    "page_number": "2",
                }
            )

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_csv(csv_path)

        assert len(checksums_data) == 2

        for checksum, data in checksums_data.items():
            assert len(checksum) == 64
            assert "content_text" in data
            assert "file_name" in data
            assert "page_number" in data
            assert data["file_name"] == "handbook.pdf"
            assert data["page_number"] in [1, 2]

    def test_extract_from_csv_with_pre_computed_checksum(self, tmp_path):
        """Test CSV extraction with pre-computed checksums."""
        csv_path = tmp_path / "content.csv"
        extractor_for_checksum = ChecksumExtractor()

        content = "Test content"
        expected_checksum = extractor_for_checksum.compute_checksum(content)

        # Create CSV with pre-computed checksum
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f, fieldnames=["content_text", "content_checksum", "page_number"]
            )
            writer.writeheader()
            writer.writerow(
                {
                    "content_text": content,
                    "content_checksum": expected_checksum,
                    "page_number": "1",
                }
            )

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_csv(csv_path)

        assert expected_checksum in checksums_data

    def test_extract_from_csv_file_not_found(self, tmp_path):
        """Test error handling for non-existent CSV."""
        extractor = ChecksumFileExtractor()

        with pytest.raises(FileNotFoundError, match="CSV file not found"):
            extractor.extract_from_csv(tmp_path / "nonexistent.csv")

    def test_extract_from_dict_list(self):
        """Test extracting from list of dictionaries."""
        data = [
            {"content_text": "Page 1 content", "page_number": 1},
            {"content_text": "Page 2 content", "page_number": 2},
        ]

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_dict_list(data)

        assert len(checksums_data) == 2

        for checksum, record in checksums_data.items():
            assert len(checksum) == 64
            assert "text" in record
            assert "content_text" in record
            assert record["text"] == record["content_text"]

    def test_extract_from_dict_list_custom_field(self):
        """Test extracting with custom content field name."""
        data = [
            {"body": "Content 1", "id": 1},
            {"body": "Content 2", "id": 2},
        ]

        extractor = ChecksumFileExtractor()
        checksums_data = extractor.extract_from_dict_list(data, content_field="body")

        assert len(checksums_data) == 2

        for checksum, record in checksums_data.items():
            assert record["text"] in ["Content 1", "Content 2"]

    def test_export_to_csv(self, tmp_path):
        """Test exporting checksums to CSV."""
        extractor = ChecksumExtractor()

        checksums_data = {
            extractor.compute_checksum("Content 1"): {
                "text": "Content 1",
                "page_num": 1,
                "file_name": "test.pdf",
            },
            extractor.compute_checksum("Content 2"): {
                "text": "Content 2",
                "page_num": 2,
                "file_name": "test.pdf",
            },
        }

        output_path = tmp_path / "output.csv"
        file_extractor = ChecksumFileExtractor()
        file_extractor.export_to_csv(checksums_data, output_path, include_content=True)

        # Verify file was created
        assert output_path.exists()

        # Verify content
        with open(output_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            assert len(rows) == 2
            assert "content_checksum" in rows[0]
            assert "text" in rows[0]

    def test_export_to_csv_without_content(self, tmp_path):
        """Test exporting checksums without full content text."""
        extractor = ChecksumExtractor()

        checksums_data = {
            extractor.compute_checksum("Content 1"): {
                "text": "Content 1",
                "page_num": 1,
            },
        }

        output_path = tmp_path / "output.csv"
        file_extractor = ChecksumFileExtractor()
        file_extractor.export_to_csv(checksums_data, output_path, include_content=False)

        # Verify file was created
        assert output_path.exists()

        # Verify content text is not included
        with open(output_path, "r", encoding="utf-8") as f:
            content = f.read()
            assert "Content 1" not in content

    def test_export_to_json(self, tmp_path):
        """Test exporting checksums to JSON."""
        extractor = ChecksumExtractor()

        checksums_data = {
            extractor.compute_checksum("Content 1"): {
                "text": "Content 1",
                "page_num": 1,
            },
        }

        output_path = tmp_path / "output.json"
        file_extractor = ChecksumFileExtractor()
        file_extractor.export_to_json(checksums_data, output_path)

        # Verify file was created
        assert output_path.exists()

        # Verify content
        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            assert len(data) == 1
            for checksum, record in data.items():
                assert len(checksum) == 64
                assert record["text"] == "Content 1"

    def test_export_creates_parent_directories(self, tmp_path):
        """Test that export creates parent directories if needed."""
        output_path = tmp_path / "subdir" / "nested" / "output.csv"
        extractor = ChecksumExtractor()

        checksums_data = {
            extractor.compute_checksum("Test"): {"text": "Test"},
        }

        file_extractor = ChecksumFileExtractor()
        file_extractor.export_to_csv(checksums_data, output_path)

        assert output_path.exists()
        assert output_path.parent.exists()