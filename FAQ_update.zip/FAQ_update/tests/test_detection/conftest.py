"""
Test fixtures for detection module tests.

Provides sample data for testing change detection, checksum extraction, and similarity matching.
Uses V8.2 schema only (tables from granular_impact/database/sql/schema/tables/).
"""

import pytest
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path


@pytest.fixture
def sample_content_texts():
    """Sample content texts for testing similarity."""
    return {
        "original": "Employees receive 10 sick days per year effective January 1, 2024.",
        "minor_modification": "Employees receive 12 sick days per year effective January 1, 2024.",
        "major_modification": "Employees receive 12 sick days and 5 personal days per year.",
        "completely_different": "The vacation policy allows for 15 days off annually.",
    }


@pytest.fixture
def sample_checksums_data(tmp_path, sample_content_texts):
    """Sample checksum data dictionaries for testing."""
    # Create temporary markdown files
    md_dir = tmp_path / "markdown"
    md_dir.mkdir()

    original_file = md_dir / "page1_v1.md"
    original_file.write_text(sample_content_texts["original"])

    modified_file = md_dir / "page1_v2.md"
    modified_file.write_text(sample_content_texts["minor_modification"])

    # Compute checksums (simple approach for testing)
    from granular_impact.detection import ChecksumExtractor

    extractor = ChecksumExtractor()

    original_checksum = extractor.compute_checksum(sample_content_texts["original"])
    modified_checksum = extractor.compute_checksum(sample_content_texts["minor_modification"])
    new_checksum = extractor.compute_checksum(sample_content_texts["completely_different"])

    return {
        "previous": {
            original_checksum: {
                "content_text": sample_content_texts["original"],
                "file_name": "handbook.pdf",
                "page_number": 1,
                "created_at": "2024-01-01T00:00:00Z",
            }
        },
        "current_minor_change": {
            modified_checksum: {
                "text": sample_content_texts["minor_modification"],
                "file_name": "handbook.pdf",
                "page_num": 1,
                "markdown_path": str(modified_file),
            }
        },
        "current_new_content": {
            new_checksum: {
                "text": sample_content_texts["completely_different"],
                "file_name": "handbook.pdf",
                "page_num": 2,
                "markdown_path": str(md_dir / "page2_v1.md"),
            }
        },
        "current_unchanged": {
            original_checksum: {
                "text": sample_content_texts["original"],
                "file_name": "handbook.pdf",
                "page_num": 1,
                "markdown_path": str(original_file),
            }
        },
    }


@pytest.fixture
def temp_database():
    """Create a temporary SQLite database with V8.2 schema."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)

    # Create V8.2 schema tables (simplified for SQLite)
    conn.executescript(
        """
        -- V8.2 Schema: content_checksums table
        CREATE TABLE content_checksums (
            content_checksum TEXT PRIMARY KEY,
            file_type TEXT,
            content_format TEXT,
            title TEXT,
            word_count INTEGER,
            char_count INTEGER,
            domain TEXT,
            service TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            file_name TEXT,
            page_number INTEGER,
            section_name TEXT,
            url TEXT,
            breadcrumb TEXT,
            source_file_path TEXT,
            file_version TEXT,
            markdown_file_path TEXT,
            content_text TEXT,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
        );

        -- V8.2 Schema: content_change_log table
        CREATE TABLE content_change_log (
            change_id INTEGER PRIMARY KEY AUTOINCREMENT,
            content_checksum TEXT NOT NULL,
            previous_checksum TEXT,
            file_name TEXT NOT NULL,
            page_number INTEGER,
            section_name TEXT,
            requires_faq_regeneration BOOLEAN NOT NULL,
            change_type TEXT,
            similarity_score REAL,
            similarity_method TEXT,
            diff_data TEXT,
            total_faqs_at_risk INTEGER NOT NULL DEFAULT 0,
            affected_question_count INTEGER NOT NULL DEFAULT 0,
            affected_answer_count INTEGER NOT NULL DEFAULT 0,
            detection_run_id TEXT NOT NULL,
            detection_timestamp TEXT NOT NULL,
            detection_period_start TEXT,
            source_modified_at TEXT,
            domain TEXT,
            service TEXT
        );

        -- V8.2 Schema: faq_questions table
        CREATE TABLE faq_questions (
            question_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_text TEXT NOT NULL,
            source_type TEXT,
            generation_method TEXT,
            domain TEXT,
            service TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            modified_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            created_by TEXT DEFAULT 'system',
            modified_by TEXT DEFAULT 'system'
        );

        -- V8.2 Schema: faq_answers table
        CREATE TABLE faq_answers (
            answer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            answer_text TEXT NOT NULL,
            answer_format TEXT DEFAULT 'html',
            confidence_score REAL,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            modified_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            created_by TEXT DEFAULT 'system',
            modified_by TEXT DEFAULT 'system',
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        );

        -- V8.2 Schema: faq_question_sources table
        CREATE TABLE faq_question_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source BOOLEAN DEFAULT FALSE,
            contribution_weight REAL,
            is_valid BOOLEAN NOT NULL DEFAULT TRUE,
            valid_from TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            valid_until TEXT,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        );

        -- V8.2 Schema: faq_answer_sources table
        CREATE TABLE faq_answer_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            answer_id INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source BOOLEAN DEFAULT FALSE,
            contribution_weight REAL,
            context_employed TEXT,
            is_valid BOOLEAN NOT NULL DEFAULT TRUE,
            valid_from TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            valid_until TEXT,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
            FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        );
        """
    )

    conn.commit()

    yield conn

    conn.close()
    Path(db_path).unlink()


@pytest.fixture
def populated_database(temp_database, sample_checksums_data):
    """Database with sample content and FAQs for testing - V8.2 schema."""
    conn = temp_database

    from granular_impact.detection import ChecksumExtractor

    extractor = ChecksumExtractor()

    # Get checksums
    prev_data = sample_checksums_data["previous"]
    prev_checksum = list(prev_data.keys())[0]
    prev_text = prev_data[prev_checksum]["content_text"]

    # Insert sample content into content_checksums (V8.2)
    conn.execute(
        """
        INSERT INTO content_checksums (
            content_checksum,
            file_name,
            page_number,
            section_name,
            content_text,
            status
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (prev_checksum, "handbook.pdf", 1, "Sick Leave Policy", prev_text, "active"),
    )

    # Insert sample FAQ question
    conn.execute(
        """
        INSERT INTO faq_questions (question_id, question_text, status)
        VALUES (1, 'How many sick days do employees get?', 'active')
        """
    )

    # Insert sample FAQ answer
    conn.execute(
        """
        INSERT INTO faq_answers (answer_id, question_id, answer_text, status)
        VALUES (1, 1, 'Employees receive 10 sick days per year.', 'active')
        """
    )

    # Link FAQ to content checksum (question source)
    conn.execute(
        """
        INSERT INTO faq_question_sources (question_id, content_checksum, is_valid)
        VALUES (1, ?, TRUE)
        """,
        (prev_checksum,),
    )

    # Link FAQ to content checksum (answer source)
    conn.execute(
        """
        INSERT INTO faq_answer_sources (answer_id, content_checksum, is_valid)
        VALUES (1, ?, TRUE)
        """,
        (prev_checksum,),
    )

    conn.commit()

    return conn