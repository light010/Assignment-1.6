"""
Tests for ContentChangeDetector.

Validates the V8.2 checksum-centric change detection algorithm including:
- Set operations on checksums
- Similarity matching for modification detection
- Edge case handling (splits, merges)
- Threshold-based classification
"""

import pytest
from datetime import datetime
from granular_impact.detection import ContentChangeDetector, ChecksumExtractor
from granular_impact.database.models import ChangeType


class TestContentChangeDetector:
    """Test suite for ContentChangeDetector (V8.2 algorithm)."""

    def test_init_default(self):
        """Test initialization with default settings."""
        detector = ContentChangeDetector()
        assert detector.checksum_extractor.algorithm == "sha256"
        assert detector.similarity_threshold == 0.8
        assert detector.similarity_calculator is not None

    def test_init_uses_correct_similarity_weights(self):
        """Test that default similarity calculator uses correct weights from pseudo code."""
        detector = ContentChangeDetector()

        # Verify weights match pseudo code (Jaccard=0.20, Difflib=0.50, BM25=0.30)
        weights = detector.similarity_calculator.weights
        assert weights["jaccard"] == 0.20
        assert weights["difflib"] == 0.50
        assert weights["bm25"] == 0.30

    def test_detect_changes_minor_modification(self, sample_content_texts):
        """Test detection of minor content modification (high similarity)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        # Original: "10 sick days"
        # Modified: "12 sick days"
        old_text = sample_content_texts["original"]
        new_text = sample_content_texts["minor_modification"]

        old_checksum = extractor.compute_checksum(old_text)
        new_checksum = extractor.compute_checksum(new_text)

        current_checksums_data = {
            new_checksum: {
                "text": new_text,
                "page_num": 1,
                "file_name": "handbook.pdf",
            }
        }

        previous_checksums_data = {
            old_checksum: {
                "content_text": old_text,
                "page_number": 1,
                "file_name": "handbook.pdf",
            }
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect ONE change: MODIFIED
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.MODIFIED_CONTENT
        assert changes[0].old_checksum == old_checksum
        assert changes[0].new_checksum == new_checksum
        assert changes[0].similarity_score >= 0.8  # High similarity

    def test_detect_changes_completely_different_content(self, sample_content_texts):
        """Test detection of completely different content (low similarity)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        old_text = sample_content_texts["original"]
        new_text = sample_content_texts["completely_different"]

        old_checksum = extractor.compute_checksum(old_text)
        new_checksum = extractor.compute_checksum(new_text)

        current_checksums_data = {
            new_checksum: {
                "text": new_text,
                "page_num": 2,
            }
        }

        previous_checksums_data = {
            old_checksum: {
                "content_text": old_text,
                "page_number": 1,
            }
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect TWO changes: NEW + DELETED
        assert len(changes) == 2

        new_changes = [c for c in changes if c.change_type == ChangeType.NEW_CONTENT]
        deleted_changes = [c for c in changes if c.change_type == ChangeType.DELETED_CONTENT]

        assert len(new_changes) == 1
        assert len(deleted_changes) == 1
        assert new_changes[0].similarity_score < 0.8  # Low similarity

    def test_detect_changes_unchanged_content(self, sample_content_texts):
        """Test detection of unchanged content (identical checksum)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        text = sample_content_texts["original"]
        checksum = extractor.compute_checksum(text)

        current_checksums_data = {
            checksum: {
                "text": text,
                "page_num": 1,
            }
        }

        previous_checksums_data = {
            checksum: {
                "content_text": text,
                "page_number": 1,
            }
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect ONE change: UNCHANGED
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.UNCHANGED_CONTENT
        assert changes[0].similarity_score == 1.0

    def test_detect_changes_new_content_only(self, sample_content_texts):
        """Test detection when only new content exists (no previous)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        new_text = sample_content_texts["original"]
        new_checksum = extractor.compute_checksum(new_text)

        current_checksums_data = {
            new_checksum: {
                "text": new_text,
                "page_num": 1,
            }
        }

        previous_checksums_data = {}  # No previous content

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect ONE change: NEW
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.NEW_CONTENT
        assert changes[0].old_checksum == ""
        assert changes[0].similarity_score == 0.0

    def test_detect_changes_deleted_content_only(self, sample_content_texts):
        """Test detection when content was deleted (no current)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        old_text = sample_content_texts["original"]
        old_checksum = extractor.compute_checksum(old_text)

        current_checksums_data = {}  # No current content

        previous_checksums_data = {
            old_checksum: {
                "content_text": old_text,
                "page_number": 1,
            }
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect ONE change: DELETED
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.DELETED_CONTENT
        assert changes[0].new_checksum == ""
        assert changes[0].similarity_score == 0.0

    def test_detect_changes_content_split_edge_case(self, sample_content_texts):
        """Test detection of content split (one page → multiple pages)."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        # Original: Full policy text
        old_text = sample_content_texts["original"]
        old_checksum = extractor.compute_checksum(old_text)

        # Split into two similar but slightly modified pieces
        new_text1 = sample_content_texts["minor_modification"][:40]
        new_text2 = sample_content_texts["minor_modification"][40:]

        new_checksum1 = extractor.compute_checksum(new_text1)
        new_checksum2 = extractor.compute_checksum(new_text2)

        current_checksums_data = {
            new_checksum1: {"text": new_text1, "page_num": 1},
            new_checksum2: {"text": new_text2, "page_num": 2},
        }

        previous_checksums_data = {
            old_checksum: {"content_text": old_text, "page_number": 1}
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect content split
        # (May detect as 2 new + 1 deleted depending on similarity)
        assert len(changes) >= 2

    def test_detect_changes_multiple_files_mixed(self, sample_content_texts):
        """Test detection with multiple pages showing various change types."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        # Page 1: Unchanged
        unchanged_text = sample_content_texts["original"]
        unchanged_checksum = extractor.compute_checksum(unchanged_text)

        # Page 2: Modified
        old_text2 = "Old policy content for page 2"
        new_text2 = "Updated policy content for page 2"
        old_checksum2 = extractor.compute_checksum(old_text2)
        new_checksum2 = extractor.compute_checksum(new_text2)

        # Page 3: New
        new_text3 = "Brand new policy for page 3"
        new_checksum3 = extractor.compute_checksum(new_text3)

        # Page 4: Deleted
        old_text4 = "Old policy that was removed"
        old_checksum4 = extractor.compute_checksum(old_text4)

        current_checksums_data = {
            unchanged_checksum: {"text": unchanged_text, "page_num": 1},
            new_checksum2: {"text": new_text2, "page_num": 2},
            new_checksum3: {"text": new_text3, "page_num": 3},
        }

        previous_checksums_data = {
            unchanged_checksum: {"content_text": unchanged_text, "page_number": 1},
            old_checksum2: {"content_text": old_text2, "page_number": 2},
            old_checksum4: {"content_text": old_text4, "page_number": 4},
        }

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data=previous_checksums_data,
            detection_run_id="TEST_RUN",
        )

        # Should detect all change types
        change_types = [c.change_type for c in changes]
        assert ChangeType.UNCHANGED_CONTENT in change_types
        assert ChangeType.MODIFIED_CONTENT in change_types or ChangeType.NEW_CONTENT in change_types
        assert ChangeType.NEW_CONTENT in change_types
        assert ChangeType.DELETED_CONTENT in change_types

    def test_detect_simple_change_backward_compatibility(self, sample_content_texts):
        """Test simple change detection method (backward compatibility API)."""
        detector = ContentChangeDetector()

        old_text = sample_content_texts["original"]
        new_text = sample_content_texts["minor_modification"]

        change = detector.detect_simple_change(
            content_id="123",
            old_content=old_text,
            new_content=new_text,
        )

        assert change.change_type == ChangeType.MODIFIED_CONTENT
        assert change.similarity_score >= 0.8

    def test_detect_simple_change_unchanged(self, sample_content_texts):
        """Test simple change detection with unchanged content."""
        detector = ContentChangeDetector()

        text = sample_content_texts["original"]

        change = detector.detect_simple_change(
            content_id="123",
            old_content=text,
            new_content=text,
        )

        assert change.change_type == ChangeType.UNCHANGED_CONTENT
        assert change.similarity_score == 1.0

    def test_similarity_threshold_customization(self, sample_content_texts):
        """Test that similarity threshold affects classification."""
        # Strict threshold (0.95)
        strict_detector = ContentChangeDetector(similarity_threshold=0.95)

        # Loose threshold (0.5)
        loose_detector = ContentChangeDetector(similarity_threshold=0.5)

        old_text = sample_content_texts["original"]
        new_text = sample_content_texts["major_modification"]

        # Same content, different thresholds
        strict_change = strict_detector.detect_simple_change("123", old_text, new_text)
        loose_change = loose_detector.detect_simple_change("123", old_text, new_text)

        # May be classified differently depending on actual similarity
        # This tests that threshold is being used
        assert strict_change.similarity_score == loose_change.similarity_score
        # But classification may differ if similarity is between 0.5 and 0.95

    def test_get_config(self):
        """Test getting detector configuration."""
        detector = ContentChangeDetector(
            checksum_algorithm="sha512",
            similarity_threshold=0.85,
        )

        config = detector.get_config()

        assert config["checksum_algorithm"] == "sha512"
        assert config["similarity_threshold"] == 0.85
        assert "similarity_weights" in config
        assert "similarity_algorithm" in config

    def test_detect_changes_preserves_metadata(self, sample_content_texts):
        """Test that file names and page numbers are preserved in changes."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        new_text = sample_content_texts["original"]
        new_checksum = extractor.compute_checksum(new_text)

        current_checksums_data = {
            new_checksum: {
                "text": new_text,
                "page_num": 42,
                "file_name": "employee_handbook.pdf",
            }
        }

        changes = detector.detect_changes(
            file_name="employee_handbook.pdf",
            current_checksums_data=current_checksums_data,
            previous_checksums_data={},
            detection_run_id="TEST_2025_01_22",
        )

        assert len(changes) == 1
        assert changes[0].file_name == "employee_handbook.pdf"
        assert changes[0].page_number == 42

    def test_detect_changes_empty_current_and_previous(self):
        """Test detection with both empty sets."""
        detector = ContentChangeDetector()

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data={},
            previous_checksums_data={},
            detection_run_id="TEST_RUN",
        )

        # Should return empty list
        assert len(changes) == 0

    def test_detect_changes_performance_tracking(self, sample_content_texts):
        """Test that detection tracks processing time."""
        detector = ContentChangeDetector()
        extractor = ChecksumExtractor()

        # Create larger dataset for performance testing
        checksums = {}
        for i in range(10):
            text = f"{sample_content_texts['original']} Page {i}"
            checksum = extractor.compute_checksum(text)
            checksums[checksum] = {"text": text, "page_num": i}

        changes = detector.detect_changes(
            file_name="handbook.pdf",
            current_checksums_data=checksums,
            previous_checksums_data={},
            detection_run_id="PERF_TEST",
        )

        # Should complete successfully
        assert len(changes) == 10
        # All should be new content
        assert all(c.change_type == ChangeType.NEW_CONTENT for c in changes)