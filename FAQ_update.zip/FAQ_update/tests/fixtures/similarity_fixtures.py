"""
Test data fixtures for similarity module testing.

Contains ONLY reusable test data - no test logic.
Actual test cases are in tests/test_similarity/.
"""

from typing import List, Tuple, Dict


# V8 Algorithm Example Data
V8_NUMERIC_CHANGE = (
    "Employees receive 10 sick days per year",
    "Employees receive 12 sick days per year"
)

V8_DATE_CHANGE = (
    "Policy effective January 1, 2025",
    "Policy effective February 1, 2025"
)

V8_MAJOR_REWRITE = (
    "Sick leave policy for full-time employees",
    "Vacation policy for part-time contractors"
)


# Policy Content Examples
POLICY_VACATION_CHANGE = (
    "Employees are entitled to 15 vacation days annually",
    "Employees are entitled to 20 vacation days annually"
)

POLICY_DEADLINE_CHANGE = (
    "Submit expense reports within 30 days of purchase",
    "Submit expense reports within 45 days of purchase"
)

POLICY_PROBATION_CHANGE = (
    "Probation period is 90 days for new hires",
    "Probation period is 180 days for new hires"
)

POLICY_REVIEW_MONTH_CHANGE = (
    "Annual performance reviews occur in March",
    "Annual performance reviews occur in September"
)


# Minor Edits
MINOR_SYNONYM_CHANGE = (
    "All full-time employees are eligible for benefits",
    "All full-time staff members are eligible for benefits"
)

MINOR_PHRASE_CHANGE = (
    "Employees must complete the training program",
    "Employees are required to complete the training program"
)

MINOR_ABBREVIATION_EXPANSION = (
    "Submit forms to HR department by end of month",
    "Submit forms to Human Resources department by end of month"
)


# Major Rewrites (should NOT be modifications)
MAJOR_REWRITE_DIFFERENT_TOPIC = (
    "Sick leave benefits for permanent staff",
    "Vacation time allocation for temporary workers"
)

MAJOR_REWRITE_UNRELATED = (
    "Employee handbook section on dress code requirements",
    "Company vehicle usage policy and procedures"
)


# Edge Cases
IDENTICAL_TEXT = (
    "Policy effective immediately",
    "Policy effective immediately"
)

COMPLETELY_DIFFERENT = (
    "The quick brown fox jumps over the lazy dog",
    "Python programming language syntax and semantics"
)

SINGLE_CHAR = ("a", "b")

USA_ABBREVIATION = (
    "Policy applies to employees working in the United States of America",
    "Policy applies to employees working in the USA"
)


# Database-compatible test records
DATABASE_TEST_RECORDS = [
    {
        "content_id": "POL-001",
        "content_version": "v1",
        "content_text": "Employees receive 10 sick days per year",
        "content_hash": "abc123",
        "created_at": "2024-01-01",
    },
    {
        "content_id": "POL-001",
        "content_version": "v2",
        "content_text": "Employees receive 12 sick days per year",
        "content_hash": "def456",
        "created_at": "2024-06-01",
    },
    {
        "content_id": "POL-002",
        "content_version": "v1",
        "content_text": "Policy effective January 1, 2025",
        "content_hash": "ghi789",
        "created_at": "2024-01-01",
    },
    {
        "content_id": "POL-002",
        "content_version": "v2",
        "content_text": "Policy effective February 1, 2025",
        "content_hash": "jkl012",
        "created_at": "2024-06-01",
    },
]


# Performance test data (various lengths)
SHORT_TEXT_PAIR = (
    "Benefits for employees",
    "Benefits for staff members"
)

MEDIUM_TEXT_PAIR = (
    "All full-time employees are eligible for comprehensive health insurance coverage including medical, dental, and vision benefits.",
    "All full-time staff members are eligible for comprehensive health insurance coverage including medical, dental, and vision benefits."
)

LONG_TEXT_PAIR = (
    "The company provides a comprehensive benefits package for all full-time employees, including health insurance (medical, dental, vision), retirement savings plans with company matching contributions, paid time off (vacation, sick leave, holidays), life insurance, disability insurance, and professional development opportunities.",
    "The company provides a comprehensive benefits package for all full-time staff members, including health insurance (medical, dental, vision), retirement savings plans with company matching contributions, paid time off (vacation, sick leave, holidays), life insurance, disability insurance, and professional development opportunities."
)

# Additional FAQ-specific test data
POLICY_VACATION_CHANGE = (
    "Employees receive 10 vacation days per year",
    "Employees receive 15 vacation days per year"
)