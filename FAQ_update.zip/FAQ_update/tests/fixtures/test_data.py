"""Test data generator."""

class TestDataGenerator:
    @staticmethod
    def generate_sample_faq_pair():
        return (
            "What is the deadline for submitting expense reports?",
            "Expense reports must be submitted within 30 days of the expense date."
        )

    @staticmethod
    def generate_sample_content_pair():
        old = "Employees must submit expense reports within 30 days."
        new = "Employees must submit expense reports within 45 days."
        return old, new
