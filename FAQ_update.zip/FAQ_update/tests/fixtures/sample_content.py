"""Sample content for testing."""

SAMPLE_FAQ_1 = {
    "question": "What is the company's PTO policy?",
    "answer": "Employees receive 15 days of PTO per year."
}

SAMPLE_CONTENT_1 = "All employees are entitled to 15 days of paid time off annually."
SAMPLE_CONTENT_2 = "All employees are entitled to 20 days of paid time off annually."
