# FAQ Content Version Tracking - Architecture Overview

## System Components Map

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DATABASES (SQLite)                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐        │
│  │  content_repo.db │   │ old_tracking.db  │   │ new_tracking.db  │        │
│  ├──────────────────┤   ├──────────────────┤   ├──────────────────┤        │
│  │ • content_repo   │   │ • content_       │   │ • content_       │        │
│  │   - file_path    │   │   version_       │   │   change_log     │        │
│  │   - page_nbr     │   │   history        │   │                  │        │
│  │   - checksum     │   │ • faq_content_   │   │ • faq_content_   │        │
│  │   - modified_dt  │   │   link           │   │   map            │        │
│  │                  │   │                  │   │                  │        │
│  │ (EXISTING)       │   │ (LEGACY)         │   │ • v_document_    │        │
│  │                  │   │                  │   │   structure_     │        │
│  │                  │   │                  │   │   changes (VIEW) │        │
│  └──────────────────┘   └──────────────────┘   └──────────────────┘        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      CORE PIPELINE CLASSES                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │  ParallelTrackingPipeline (parallel_tracking.py)              │         │
│  ├────────────────────────────────────────────────────────────────┤         │
│  │  Purpose: Run new system alongside old for validation         │         │
│  │                                                                │         │
│  │  • _load_recent_content(since_date)                           │         │
│  │  • _run_old_system(content_df) → old_results                  │         │
│  │  • _run_new_system(content_df) → new_results                  │         │
│  │  • _compare_results(old, new) → discrepancies                 │         │
│  │  • _analyze_file_changes() → categorized changes              │         │
│  │  • _run_enhanced_change_detection() → accurate classification │         │
│  │  • validate_content_id() → cross-DB FK validation             │         │
│  └────────────────────────────────────────────────────────────────┘         │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │  ContentTrackingPipeline (production_pipeline.py)             │         │
│  ├────────────────────────────────────────────────────────────────┤         │
│  │  Purpose: Production pipeline for daily change tracking       │         │
│  │                                                                │         │
│  │  • process_daily_updates(since_date) → impact_report          │         │
│  │  • _detect_changes() → categorized changes                    │         │
│  │  • _analyze_file_changes() → per-file analysis                │         │
│  │  • _process_changes() → record to DB                          │         │
│  │  • _update_faq_mappings() → invalidate/relocate FAQs          │         │
│  │  • _record_change_idempotent() → safe duplicate handling      │         │
│  │  • validate_content_id() → cross-DB FK validation             │         │
│  │                                                                │         │
│  │  MISSING (to add):                                             │         │
│  │  • _build_document_states() → race-free state building        │         │
│  │  • _find_checksum_matches() → greedy matching algorithm       │         │
│  └────────────────────────────────────────────────────────────────┘         │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │  FAQLinkMigration (migrate_faq_links.py)                      │         │
│  ├────────────────────────────────────────────────────────────────┤         │
│  │  Purpose: Migrate FAQ links from old to new schema            │         │
│  │                                                                │         │
│  │  • migrate_all_links(batch_size) → migration_stats            │         │
│  │  • _migrate_batch() → batch processing                        │         │
│  │  • _get_current_location() → lookup current page              │         │
│  │  • validate_migration() → post-migration checks               │         │
│  └────────────────────────────────────────────────────────────────┘         │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                   ORCHESTRATION & UTILITIES (TO CREATE)                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────┐         │
│  │  MigrationController (migration_controller.py) - TO CREATE     │         │
│  ├────────────────────────────────────────────────────────────────┤         │
│  │  Purpose: Orchestrate complete migration with safety checks    │         │
│  │                                                                │         │
│  │  • execute_migration()                                         │         │
│  │    1. pre_migration_checks()                                   │         │
│  │    2. backup_databases()                                       │         │
│  │    3. create_new_schema()                                      │         │
│  │    4. migrate_data()                                           │         │
│  │    5. validate_migration()                                     │         │
│  │    6. switch_to_new_system()                                   │         │
│  │  • rollback_migration(backup_path)                             │         │
│  └────────────────────────────────────────────────────────────────┘         │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │  Utility Modules (src/utils/) - TO CREATE                    │           │
│  ├──────────────────────────────────────────────────────────────┤           │
│  │  • idempotency_helpers.py                                    │           │
│  │    - test_idempotent_insert()                                │           │
│  │    - validate_no_duplicates()                                │           │
│  │                                                              │           │
│  │  • troubleshooting.py                                        │           │
│  │    - debug_checksum()                                        │           │
│  │    - debug_content_id_validation()                           │           │
│  │    - analyze_performance()                                   │           │
│  │    - find_missing_faqs()                                     │           │
│  └──────────────────────────────────────────────────────────────┘           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      SUPPORTING SCRIPTS (TO CREATE)                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  scripts/                                                                    │
│  ├── rollback_migration.py                                                  │
│  │   • immediate_rollback() - Drop new schema, restore backup               │
│  │   • gradual_rollback() - Rollback changes after cutoff time              │
│  │                                                                           │
│  ├── performance_monitoring.py                                              │
│  │   • monitor_table_sizes()                                                │
│  │   • analyze_query_performance()                                          │
│  │                                                                           │
│  └── validate_migration_success.py                                          │
│      • validate_migration_success()                                         │
│      • check_faqs_accessible()                                              │
│      • check_validity_states()                                              │
│      • check_page_tracking()                                                │
│      • check_performance()                                                  │
│      • check_audit_trail()                                                  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                          TEST SUITE (TO CREATE)                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  tests/                                                                      │
│  ├── test_change_detection.py                                               │
│  │   • test_content_edit_detection()                                        │
│  │   • test_position_change_detection()                                     │
│  │   • test_page_insertion_detection()                                      │
│  │                                                                           │
│  └── test_faq_validity.py                                                   │
│      • test_faq_remains_valid_on_move()                                     │
│      • test_faq_invalidated_on_edit()                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      SQL SCRIPTS & SCHEMAS (TO CREATE)                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  sql/                                                                        │
│  ├── create_new_schema_complete.sql                                         │
│  │   • Complete schema with all fixes and enhancements                      │
│  │   • Tables: content_change_log, faq_content_map                          │
│  │   • Views: v_document_structure_changes, v_current_valid_faqs            │
│  │   • Indexes: Optimized for performance and idempotency                   │
│  │                                                                           │
│  ├── validation_queries.sql                                                 │
│  │   • Verify no orphaned FAQs                                              │
│  │   • Check for duplicate checksums                                        │
│  │   • Verify page moves have FAQ updates                                   │
│  │                                                                           │
│  └── performance_indexes.sql                                                │
│      • Enhanced covering indexes                                            │
│      • Unique idempotency constraints                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow: Change Detection & FAQ Management

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DAILY PIPELINE FLOW                                  │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: DETECT CHANGES
┌──────────────────────────────────────────────────────────────┐
│  content_repo.db (modified since last run)                   │
│  ↓                                                            │
│  ContentTrackingPipeline._detect_changes(since_date)         │
│  ↓                                                            │
│  For each file:                                              │
│    • Load current state from content_change_log              │
│    • Build old/new document states                           │
│    • Find checksum matches (greedy algorithm)                │
│    • Classify changes in order:                              │
│      1. Position changes (same checksum, different page)     │
│      2. New content (new checksums)                          │
│      3. Deletions (checksums completely gone)                │
│      4. Edits (same page, checksums not found elsewhere)     │
└──────────────────────────────────────────────────────────────┘
                              ↓
Step 2: CATEGORIZE RESULTS
┌──────────────────────────────────────────────────────────────┐
│  changes = {                                                 │
│    'content_edits': [...],      ← Invalidate FAQs           │
│    'position_changes': [...],   ← Update FAQ locations      │
│    'new_content': [...],        ← No action needed          │
│    'deletions': [...],          ← Invalidate FAQs           │
│    'structural_changes': [...]  ← Derived from VIEW         │
│  }                                                           │
└──────────────────────────────────────────────────────────────┘
                              ↓
Step 3: RECORD CHANGES
┌──────────────────────────────────────────────────────────────┐
│  _process_changes(changes)                                   │
│  ↓                                                            │
│  For each change:                                            │
│    • Validate content_id exists (cross-DB FK check)          │
│    • INSERT OR IGNORE into content_change_log                │
│      (idempotent - duplicates automatically ignored)         │
│    • If deletion: invalidate FAQs immediately                │
└──────────────────────────────────────────────────────────────┘
                              ↓
Step 4: UPDATE FAQ MAPPINGS
┌──────────────────────────────────────────────────────────────┐
│  _update_faq_mappings(changes)                               │
│  ↓                                                            │
│  For content_edits:                                          │
│    UPDATE faq_content_map                                    │
│    SET is_valid = 0,                                         │
│        valid_until = NOW(),                                  │
│        invalidation_reason = 'content_edited'                │
│    WHERE content_checksum = old_checksum                     │
│                                                              │
│  For position_changes:                                       │
│    UPDATE faq_content_map                                    │
│    SET current_page_number = new_page,                       │
│        current_content_id = new_content_id                   │
│    WHERE content_checksum = checksum                         │
│    (FAQ remains valid!)                                      │
└──────────────────────────────────────────────────────────────┘
                              ↓
Step 5: GENERATE IMPACT REPORT
┌──────────────────────────────────────────────────────────────┐
│  impact_report = {                                           │
│    'summary': {                                              │
│      'total_changes': 42,                                    │
│      'files_affected': 5,                                    │
│      'faqs_impacted': 15                                     │
│    },                                                        │
│    'details': {                                              │
│      'content_modifications': 3,  ← FAQs invalidated         │
│      'page_movements': 38,        ← FAQs relocated           │
│      'new_pages': 1,                                         │
│      'structural_changes': 2      ← From VIEW                │
│    },                                                        │
│    'severity': 'low'                                         │
│  }                                                           │
└──────────────────────────────────────────────────────────────┘
```

---

## Key Design Decisions

### 1. Content Identity = Checksum (NOT Page Number)
```
Old System (WRONG):
  FAQ → version_history_id → (file, page, version)
  Problem: Page movements create new versions, invalidating FAQs

New System (CORRECT):
  FAQ → content_checksum → tracks content wherever it moves
  Benefit: Page movements DON'T invalidate FAQs
```

### 2. Cross-Database Foreign Keys → Application Validation
```
Cannot Use (SQLite limitation):
  FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)

Solution:
  def validate_content_id(content_id):
      # Check in content_repo.db before inserting
      # Prevents orphaned references
```

### 3. Idempotency → UNIQUE Index + INSERT OR IGNORE
```
Index:
  CREATE UNIQUE INDEX idx_ccl_idempotent ON content_change_log(
      file_name, page_number, content_checksum, change_type, effective_date
  )

Insert:
  INSERT OR IGNORE INTO content_change_log ...
  -- Duplicates silently ignored, no errors
```

### 4. Structural Changes → Derived VIEW (Not Stored)
```
Old Approach: Store in document_structure_changes table
  Problem: Duplication, sync issues

New Approach: v_document_structure_changes VIEW
  Benefit: Auto-computed from position_change patterns
  No duplication, always up-to-date
```

### 5. Time Field Semantics → Explicit Naming
```
effective_date  = When change occurred in source (last_modified_dt)
detected_at     = When pipeline detected it (pipeline run time)
processed_at    = When record was written to DB

Why: Prevents confusion, enables accurate auditing
```

---

## Migration Strategy

```
Phase 1: PARALLEL TRACKING (Days 1-7)
  ├── Run ParallelTrackingPipeline
  ├── Compare old vs new results
  ├── Log discrepancies
  └── Validate behavior

Phase 2: DATA MIGRATION (Day 8)
  ├── Backup databases
  ├── Create new schema
  ├── Run FAQLinkMigration
  ├── Validate migration
  └── Keep old system as backup

Phase 3: CUTOVER (Day 9+)
  ├── Switch to ContentTrackingPipeline
  ├── Monitor for 48 hours
  └── Decommission old system

Rollback Plan:
  • Immediate (<1hr): Restore from backup
  • Gradual (1-24hr): Revert changes after cutoff time
```

---

## File Organization Summary

```
FAQ_update/
├── src/
│   ├── ✅ migrate_faq_links.py          (EXISTS - migration logic)
│   ├── ✅ parallel_tracking.py          (EXISTS - validation)
│   ├── ⚠️  production_pipeline.py       (EXISTS - needs additions)
│   ├── ❌ migration_controller.py       (CREATE - orchestration)
│   ├── ❌ main.py                       (CREATE - CLI entry point)
│   └── utils/
│       ├── ❌ idempotency_helpers.py    (CREATE)
│       └── ❌ troubleshooting.py        (CREATE)
│
├── scripts/
│   ├── ❌ rollback_migration.py         (CREATE)
│   ├── ❌ performance_monitoring.py     (CREATE)
│   └── ❌ validate_migration_success.py (CREATE)
│
├── tests/
│   ├── ❌ test_change_detection.py      (CREATE)
│   └── ❌ test_faq_validity.py          (CREATE)
│
├── sql/
│   ├── ❌ create_new_schema_complete.sql (CREATE/UPDATE)
│   ├── ❌ validation_queries.sql         (CREATE/UPDATE)
│   └── ❌ performance_indexes.sql        (CREATE)
│
└── docs/
    └── ❌ TIME_SEMANTICS_GUIDE.md        (CREATE)

Legend:
  ✅ = Implemented
  ⚠️  = Partial (needs additions)
  ❌ = Not yet created
```

---

## Next Actions

1. **Review IMPLEMENTATION_GUIDE.md** - Detailed instructions for each component
2. **Start with Priority 1 (CRITICAL)** items from the guide
3. **Test each component** as you build it
4. **Ask questions** about any unclear parts

The comprehensive implementation readme (lines 2697-3753) provides full code samples for everything marked ❌ above.