"""
FAQ Update Detection System - Race Condition Fix with Dual Locking Strategy
============================================================================

This module implements a production-grade solution to prevent race conditions
in the granular FAQ impact analysis system (V8).

PROBLEM:
--------
Multiple concurrent detection runs can:
- Process the same file simultaneously (wasted computation)
- Modify the same FAQs concurrently (data corruption)
- Create inconsistent audit trails (lost updates)

SOLUTION:
---------
Two-layer locking strategy:

LAYER 1: Distributed Locking (Pessimistic)
    - Prevents duplicate work at the RESOURCE level (file-level)
    - Coordinates multiple workers/jobs/retries
    - Ensures only ONE detection run per file at a time

LAYER 2: Optimistic Locking (Version-based)
    - Prevents data corruption at the ROW level (FAQ-level)
    - Detects concurrent modifications by external processes
    - Catches edge cases and bugs in distributed locking

WHY BOTH?
---------
They protect against DIFFERENT failure modes:
- Distributed lock: Prevents inefficiency (duplicate work)
- Optimistic lock: Prevents incorrectness (data corruption)
- Neither alone is sufficient for production safety

ARCHITECTURE:
-------------
    ┌─────────────────────────────────────────────────────────┐
    │  Detection Run (Process A)                              │
    ├─────────────────────────────────────────────────────────┤
    │                                                          │
    │  1. Acquire Distributed Lock on "file:handbook.pdf"     │
    │     └─ Blocks other processes from starting duplicate   │
    │        work on same file                                │
    │                                                          │
    │  2. Detect content changes (checksum comparison)        │
    │                                                          │
    │  3. Compute diffs (line-by-line analysis)               │
    │                                                          │
    │  4. Analyze FAQ impact (score computation)              │
    │                                                          │
    │  5. Invalidate affected FAQs WITH version check         │
    │     └─ Optimistic lock catches external modifications   │
    │        during steps 2-4                                 │
    │                                                          │
    │  6. Release Distributed Lock                            │
    │                                                          │
    └─────────────────────────────────────────────────────────┘

USAGE:
------
    from race_condition_fix_dual_locking import run_granular_faq_update_detection

    result = run_granular_faq_update_detection(
        file_name="handbook.pdf",
        detection_run_id="RUN_2025_10_21_001"
    )

    print(f"Changes detected: {result['changes_detected']}")
    print(f"FAQs saved from regeneration: {result['total_faqs_saved']}")

DEPENDENCIES:
-------------
- Database with Delta Lake support (Databricks Unity Catalog)
- Schema V8 with content_checksums, faq_questions, faq_answers, etc.
- Additional tables: detection_run_locks (see SQL schema below)
- Additional columns: faq_questions.version, faq_answers.version

Author: FAQ Services Team
Date: 2025-10-21
Version: 1.0
"""

import time
import hashlib
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from contextlib import contextmanager
import traceback

# Logging
from loguru import logger


# ============================================================================
# CONFIGURATION
# ============================================================================

class LockConfig:
    """Configuration for locking mechanisms."""

    # Distributed Lock Settings
    DISTRIBUTED_LOCK_TIMEOUT_SECONDS = 300  # 5 minutes to acquire lock
    DISTRIBUTED_LOCK_EXPIRES_MINUTES = 30   # Lock auto-expires after 30 minutes
    DISTRIBUTED_LOCK_RETRY_INTERVAL = 2     # Check lock availability every 2 seconds

    # Optimistic Lock Settings
    OPTIMISTIC_LOCK_MAX_RETRIES = 3
    OPTIMISTIC_LOCK_RETRY_DELAY = 1  # Wait 1 second between retries

    # Monitoring
    STALE_LOCK_CLEANUP_ENABLED = True
    LOG_CONFLICTS = True


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class LockAcquisitionError(Exception):
    """Raised when distributed lock cannot be acquired."""
    resource_id: str
    owner_id: str
    timeout_seconds: int
    current_owner: Optional[str] = None

    def __str__(self):
        msg = f"Failed to acquire lock on '{self.resource_id}' after {self.timeout_seconds}s"
        if self.current_owner:
            msg += f" (currently held by: {self.current_owner})"
        return msg


@dataclass
class OptimisticLockConflict:
    """Represents a conflict detected by optimistic locking."""
    question_id: int
    answer_id: Optional[int]
    expected_version: int
    actual_version: int
    reason: str
    timestamp: datetime


@dataclass
class InvalidationResult:
    """Result of selective FAQ invalidation."""
    affected_count: int
    conflicts: List[OptimisticLockConflict]
    skipped: List[Dict[str, Any]]
    total_attempted: int

    @property
    def success_rate(self) -> float:
        """Percentage of successful invalidations."""
        if self.total_attempted == 0:
            return 100.0
        return (self.affected_count / self.total_attempted) * 100.0


@dataclass
class DetectionRunResult:
    """Result of complete detection run."""
    file_name: str
    detection_run_id: str
    changes_detected: int
    total_faqs_analyzed: int
    total_faqs_affected: int
    total_faqs_saved: int
    optimistic_conflicts: int
    status: str  # 'success', 'locked', 'partial', 'failed'
    duration_seconds: float
    error_message: Optional[str] = None


# ============================================================================
# LAYER 1: DISTRIBUTED LOCK MANAGER (Pessimistic Locking)
# ============================================================================

class DistributedLockManager:
    """
    Manages distributed locks using database table.

    Prevents multiple processes from working on the same resource simultaneously.
    Uses database as coordination mechanism (works across Databricks workers).

    Lock Lifecycle:
    ---------------
    1. acquire_lock(): Attempt to insert lock record
    2. (work happens)
    3. release_lock(): Delete lock record
    4. Auto-expiry: Stale locks cleaned up automatically

    Table Schema:
    -------------
    CREATE TABLE detection_run_locks (
        resource_id STRING NOT NULL PRIMARY KEY,
        owner_id STRING NOT NULL,
        acquired_at TIMESTAMP NOT NULL,
        expires_at TIMESTAMP NOT NULL
    );
    """

    def __init__(self, db_connection):
        """
        Initialize lock manager.

        Args:
            db_connection: Database connection object with execute() method
        """
        self.db = db_connection
        self.lock_timeout = timedelta(minutes=LockConfig.DISTRIBUTED_LOCK_EXPIRES_MINUTES)

        # Ensure lock table exists
        self._ensure_lock_table_exists()

    def _ensure_lock_table_exists(self):
        """Create lock table if it doesn't exist."""
        try:
            self.db.execute("""
                CREATE TABLE IF NOT EXISTS detection_run_locks (
                    resource_id STRING NOT NULL,
                    owner_id STRING NOT NULL,
                    acquired_at TIMESTAMP NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    hostname STRING,
                    process_id INT,
                    CONSTRAINT pk_detection_run_locks PRIMARY KEY (resource_id)
                ) COMMENT 'Distributed locks for concurrent detection run coordination'
            """)
            logger.debug("Verified detection_run_locks table exists")
        except Exception as e:
            logger.warning(f"Could not verify lock table existence: {e}")

    def acquire_lock(
        self,
        resource_id: str,
        owner_id: str,
        timeout_seconds: int = LockConfig.DISTRIBUTED_LOCK_TIMEOUT_SECONDS
    ) -> bool:
        """
        Acquire exclusive lock on resource.

        Args:
            resource_id: Unique identifier for resource (e.g., "file:handbook.pdf")
            owner_id: Identifier for lock owner (e.g., detection_run_id)
            timeout_seconds: How long to wait for lock acquisition

        Returns:
            True if lock acquired, False otherwise

        Raises:
            LockAcquisitionError: If lock cannot be acquired within timeout
        """
        deadline = datetime.now() + timedelta(seconds=timeout_seconds)
        attempt = 0

        logger.info(f"Attempting to acquire lock: resource='{resource_id}', owner='{owner_id}'")

        while datetime.now() < deadline:
            attempt += 1

            # Clean up stale locks first
            if LockConfig.STALE_LOCK_CLEANUP_ENABLED:
                self._cleanup_stale_locks()

            try:
                # Attempt to insert lock record
                expires_at = datetime.now() + self.lock_timeout

                self.db.execute("""
                    INSERT INTO detection_run_locks (
                        resource_id,
                        owner_id,
                        acquired_at,
                        expires_at
                    ) VALUES (?, ?, CURRENT_TIMESTAMP(), ?)
                """, [resource_id, owner_id, expires_at])

                logger.info(
                    f"🔒 Lock acquired: resource='{resource_id}', "
                    f"owner='{owner_id}', expires_at={expires_at}"
                )
                return True

            except Exception as e:
                # Lock already exists (unique constraint violation)
                # Check who holds it and if it's stale

                existing_lock = self._get_lock_info(resource_id)

                if existing_lock:
                    time_remaining = (existing_lock['expires_at'] - datetime.now()).total_seconds()

                    if time_remaining <= 0:
                        # Stale lock - will be cleaned up on next iteration
                        logger.warning(
                            f"Found stale lock on '{resource_id}' "
                            f"(held by {existing_lock['owner_id']}), breaking it"
                        )
                        self._force_release_lock(resource_id)
                        continue

                    logger.debug(
                        f"Lock held by '{existing_lock['owner_id']}' "
                        f"({time_remaining:.0f}s remaining). Waiting... (attempt {attempt})"
                    )

                # Wait before retrying
                time.sleep(LockConfig.DISTRIBUTED_LOCK_RETRY_INTERVAL)

        # Timeout reached
        existing_lock = self._get_lock_info(resource_id)
        current_owner = existing_lock['owner_id'] if existing_lock else None

        raise LockAcquisitionError(
            resource_id=resource_id,
            owner_id=owner_id,
            timeout_seconds=timeout_seconds,
            current_owner=current_owner
        )

    def release_lock(self, resource_id: str, owner_id: str) -> bool:
        """
        Release lock on resource.

        Args:
            resource_id: Resource identifier
            owner_id: Owner identifier (must match acquiring owner)

        Returns:
            True if lock released, False if lock not found or not owned
        """
        try:
            result = self.db.execute("""
                DELETE FROM detection_run_locks
                WHERE resource_id = ? AND owner_id = ?
            """, [resource_id, owner_id])

            if result.rowcount > 0:
                logger.info(f"🔓 Lock released: resource='{resource_id}', owner='{owner_id}'")
                return True
            else:
                logger.warning(
                    f"Could not release lock on '{resource_id}' "
                    f"(not found or not owned by '{owner_id}')"
                )
                return False

        except Exception as e:
            logger.error(f"Error releasing lock on '{resource_id}': {e}")
            return False

    def _get_lock_info(self, resource_id: str) -> Optional[Dict[str, Any]]:
        """Get information about current lock holder."""
        try:
            result = self.db.execute("""
                SELECT resource_id, owner_id, acquired_at, expires_at
                FROM detection_run_locks
                WHERE resource_id = ?
            """, [resource_id]).fetchone()

            if result:
                return dict(result)
            return None

        except Exception as e:
            logger.error(f"Error querying lock info for '{resource_id}': {e}")
            return None

    def _force_release_lock(self, resource_id: str):
        """Force release a lock (use for stale locks only)."""
        try:
            self.db.execute("""
                DELETE FROM detection_run_locks
                WHERE resource_id = ?
            """, [resource_id])
            logger.info(f"Forcibly released lock on '{resource_id}'")
        except Exception as e:
            logger.error(f"Error force-releasing lock on '{resource_id}': {e}")

    def _cleanup_stale_locks(self):
        """Clean up expired locks."""
        try:
            result = self.db.execute("""
                DELETE FROM detection_run_locks
                WHERE expires_at < CURRENT_TIMESTAMP()
            """)

            if result.rowcount > 0:
                logger.info(f"Cleaned up {result.rowcount} stale lock(s)")

        except Exception as e:
            logger.debug(f"Error cleaning up stale locks: {e}")

    @contextmanager
    def with_lock(
        self,
        resource_id: str,
        owner_id: str,
        timeout_seconds: int = LockConfig.DISTRIBUTED_LOCK_TIMEOUT_SECONDS
    ):
        """
        Context manager for lock acquisition.

        Usage:
            with lock_manager.with_lock("file:handbook.pdf", "RUN_001"):
                # Do work with exclusive access
                process_file()

        Args:
            resource_id: Resource identifier
            owner_id: Owner identifier
            timeout_seconds: Lock acquisition timeout

        Raises:
            LockAcquisitionError: If lock cannot be acquired
        """
        acquired = False

        try:
            # Acquire lock
            acquired = self.acquire_lock(resource_id, owner_id, timeout_seconds)

            if not acquired:
                raise LockAcquisitionError(
                    resource_id=resource_id,
                    owner_id=owner_id,
                    timeout_seconds=timeout_seconds
                )

            # Yield control to caller
            yield

        finally:
            # Always release lock, even if exception occurred
            if acquired:
                self.release_lock(resource_id, owner_id)


# ============================================================================
# LAYER 2: OPTIMISTIC LOCK MANAGER (Version-based Locking)
# ============================================================================

class OptimisticLockManager:
    """
    Manages optimistic locking using version columns.

    Detects concurrent modifications at write time by checking version numbers.
    Allows concurrent reads but prevents conflicting writes.

    Version Lifecycle:
    ------------------
    1. Read FAQ with current version (e.g., version=5)
    2. Do work (compute impact scores, etc.)
    3. Write with version check:
       UPDATE ... WHERE question_id=? AND version=5
    4. If version changed → conflict detected
       If version unchanged → increment version

    Required Schema:
    ----------------
    ALTER TABLE faq_questions ADD COLUMN version BIGINT DEFAULT 0;
    ALTER TABLE faq_answers ADD COLUMN version BIGINT DEFAULT 0;
    """

    def __init__(self, db_connection):
        """
        Initialize optimistic lock manager.

        Args:
            db_connection: Database connection object
        """
        self.db = db_connection

        # Ensure version columns exist
        self._ensure_version_columns_exist()

    def _ensure_version_columns_exist(self):
        """Ensure version columns exist on FAQ tables."""
        try:
            # Check if version columns exist
            self.db.execute("SELECT version FROM faq_questions LIMIT 1")
            self.db.execute("SELECT version FROM faq_answers LIMIT 1")
            logger.debug("Verified version columns exist")

        except Exception as e:
            logger.warning(f"Version columns may not exist: {e}")
            logger.warning("Run schema migration: ALTER TABLE faq_questions ADD COLUMN version BIGINT DEFAULT 0")

    def selective_invalidate_faqs(
        self,
        change_id: int,
        impact_results: List[Dict[str, Any]],
        detection_run_id: str
    ) -> InvalidationResult:
        """
        Selectively invalidate FAQs with optimistic locking.

        Only invalidates FAQs marked as affected in impact analysis.
        Uses version check to detect concurrent modifications.

        Args:
            change_id: ID of content change
            impact_results: List of impact analysis results
            detection_run_id: Detection run identifier

        Returns:
            InvalidationResult with counts and conflicts
        """
        affected_faqs = [r for r in impact_results if r['is_affected']]

        conflicts = []
        skipped = []
        affected_count = 0

        logger.info(f"Invalidating {len(affected_faqs)} affected FAQs (out of {len(impact_results)} total)")

        for faq in affected_faqs:
            question_id = faq['question_id']
            answer_id = faq.get('answer_id')

            try:
                # Attempt invalidation with version check
                success, conflict = self._invalidate_single_faq(
                    change_id=change_id,
                    question_id=question_id,
                    answer_id=answer_id,
                    detection_run_id=detection_run_id
                )

                if success:
                    affected_count += 1
                elif conflict:
                    conflicts.append(conflict)
                else:
                    skipped.append({
                        'question_id': question_id,
                        'answer_id': answer_id,
                        'reason': 'already_invalidated'
                    })

            except Exception as e:
                logger.error(f"Error invalidating FAQ {question_id}: {e}")
                skipped.append({
                    'question_id': question_id,
                    'answer_id': answer_id,
                    'reason': f'error: {str(e)}'
                })

        result = InvalidationResult(
            affected_count=affected_count,
            conflicts=conflicts,
            skipped=skipped,
            total_attempted=len(affected_faqs)
        )

        # Log conflicts
        if conflicts and LockConfig.LOG_CONFLICTS:
            logger.warning(f"Detected {len(conflicts)} optimistic lock conflicts:")
            for conflict in conflicts:
                logger.warning(
                    f"  - FAQ {conflict.question_id}: "
                    f"expected v{conflict.expected_version}, found v{conflict.actual_version} "
                    f"({conflict.reason})"
                )

        return result

    def _invalidate_single_faq(
        self,
        change_id: int,
        question_id: int,
        answer_id: Optional[int],
        detection_run_id: str
    ) -> Tuple[bool, Optional[OptimisticLockConflict]]:
        """
        Invalidate a single FAQ with optimistic lock check.

        Returns:
            (success: bool, conflict: OptimisticLockConflict or None)
        """
        # Step 1: Get current version and status
        current = self.db.execute("""
            SELECT version, status, modified_at
            FROM faq_questions
            WHERE question_id = ?
        """, [question_id]).fetchone()

        if not current:
            logger.warning(f"FAQ {question_id} not found (deleted?)")
            return (False, None)

        current_version = current['version']
        current_status = current['status']

        # Step 2: Check if already invalidated
        if current_status != 'active':
            logger.debug(f"FAQ {question_id} already invalidated (status: {current_status})")
            return (False, None)

        # Step 3: Invalidate question sources with version check
        sources_updated = self.db.execute("""
            UPDATE faq_question_sources
            SET is_valid = FALSE,
                valid_until = CURRENT_TIMESTAMP(),
                invalidation_reason = 'selective_impact',
                invalidated_by_change_id = ?
            WHERE question_id = ?
              AND is_valid = TRUE
        """, [change_id, question_id])

        # Step 4: Invalidate answer sources (if answer exists)
        if answer_id:
            self.db.execute("""
                UPDATE faq_answer_sources
                SET is_valid = FALSE,
                    valid_until = CURRENT_TIMESTAMP(),
                    invalidation_reason = 'selective_impact',
                    invalidated_by_change_id = ?
                WHERE answer_id = ?
                  AND is_valid = TRUE
            """, [change_id, answer_id])

        # Step 5: Update question status WITH VERSION CHECK (optimistic lock)
        updated_rows = self.db.execute("""
            UPDATE faq_questions
            SET status = 'invalidated',
                version = version + 1,
                modified_at = CURRENT_TIMESTAMP(),
                modified_by = ?
            WHERE question_id = ?
              AND version = ?
        """, [f"detection_run:{detection_run_id}", question_id, current_version])

        # Step 6: Check if update succeeded
        if updated_rows.rowcount == 0:
            # Version changed - concurrent modification detected!
            actual = self.db.execute("""
                SELECT version FROM faq_questions WHERE question_id = ?
            """, [question_id]).fetchone()

            actual_version = actual['version'] if actual else -1

            conflict = OptimisticLockConflict(
                question_id=question_id,
                answer_id=answer_id,
                expected_version=current_version,
                actual_version=actual_version,
                reason='concurrent_modification',
                timestamp=datetime.now()
            )

            return (False, conflict)

        # Step 7: Update answer status (if exists)
        if answer_id:
            self.db.execute("""
                UPDATE faq_answers
                SET status = 'invalidated',
                    version = version + 1,
                    modified_at = CURRENT_TIMESTAMP(),
                    modified_by = ?
                WHERE answer_id = ?
            """, [f"detection_run:{detection_run_id}", answer_id])

        # Step 8: Log audit trail
        self._log_invalidation_audit(
            change_id=change_id,
            question_id=question_id,
            answer_id=answer_id,
            detection_run_id=detection_run_id
        )

        return (True, None)

    def _log_invalidation_audit(
        self,
        change_id: int,
        question_id: int,
        answer_id: Optional[int],
        detection_run_id: str
    ):
        """Log invalidation to audit table."""
        try:
            self.db.execute("""
                INSERT INTO faq_audit_log (
                    table_name,
                    record_id,
                    action,
                    change_reason,
                    detection_run_id,
                    performed_by,
                    performed_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP())
            """, [
                'faq_questions',
                question_id,
                'SELECTIVE_INVALIDATE',
                f'Affected by change_id={change_id}',
                detection_run_id,
                'system'
            ])
        except Exception as e:
            logger.warning(f"Could not log audit trail: {e}")


# ============================================================================
# MAIN DETECTION WORKFLOW (Dual Locking Strategy)
# ============================================================================

def run_granular_faq_update_detection(
    file_name: str,
    detection_run_id: str,
    db_connection,
    since_date: Optional[datetime] = None
) -> DetectionRunResult:
    """
    Execute granular FAQ update detection with dual locking strategy.

    LAYER 1: Distributed lock prevents duplicate work on same file
    LAYER 2: Optimistic lock prevents data corruption from concurrent modifications

    Args:
        file_name: Name of file to process (e.g., "handbook.pdf")
        detection_run_id: Unique identifier for this detection run
        db_connection: Database connection object
        since_date: Only detect changes after this date

    Returns:
        DetectionRunResult with metrics and status

    Raises:
        LockAcquisitionError: If distributed lock cannot be acquired
        Exception: For other errors during detection
    """
    start_time = time.time()

    # Initialize lock managers
    distributed_lock = DistributedLockManager(db_connection)
    optimistic_lock = OptimisticLockManager(db_connection)

    resource_id = f"file:{file_name}"

    try:
        # LAYER 1: Acquire distributed lock
        logger.info(f"[{detection_run_id}] Starting granular detection for '{file_name}'")

        with distributed_lock.with_lock(resource_id, detection_run_id):
            logger.info(f"[{detection_run_id}] 🔒 Acquired exclusive lock on '{file_name}'")

            # Phase 1: Detect content changes
            changes = detect_content_changes(
                file_name=file_name,
                detection_run_id=detection_run_id,
                db_connection=db_connection,
                since_date=since_date
            )

            logger.info(f"[{detection_run_id}] Found {len(changes)} changes in '{file_name}'")

            if len(changes) == 0:
                duration = time.time() - start_time
                return DetectionRunResult(
                    file_name=file_name,
                    detection_run_id=detection_run_id,
                    changes_detected=0,
                    total_faqs_analyzed=0,
                    total_faqs_affected=0,
                    total_faqs_saved=0,
                    optimistic_conflicts=0,
                    status='success',
                    duration_seconds=duration
                )

            # Process each change
            total_faqs_analyzed = 0
            total_faqs_affected = 0
            total_faqs_saved = 0
            total_conflicts = 0

            for idx, change in enumerate(changes, 1):
                logger.info(f"[{detection_run_id}] Processing change {idx}/{len(changes)}")

                if change['change_type'] != 'modified_content':
                    logger.debug(f"Skipping change type: {change['change_type']}")
                    continue

                # Phase 2: Compute diff
                diff_data = compute_content_diff(
                    old_text=change['old_text'],
                    new_text=change['new_text'],
                    db_connection=db_connection
                )

                # Phase 3: Store change log + diff
                with db_connection.transaction():
                    change_id = store_change_log(
                        change=change,
                        diff_data=diff_data,
                        detection_run_id=detection_run_id,
                        db_connection=db_connection
                    )

                    diff_id = store_content_diff(
                        change_id=change_id,
                        diff_data=diff_data,
                        db_connection=db_connection
                    )

                # Phase 4: Analyze FAQ impact
                impact_results = analyze_faq_impact(
                    change=change,
                    diff_data=diff_data,
                    detection_run_id=detection_run_id,
                    db_connection=db_connection
                )

                total_faqs_analyzed += len(impact_results)
                affected_count = sum(1 for r in impact_results if r['is_affected'])

                # Phase 5: Store impact analysis
                with db_connection.transaction():
                    store_impact_analysis(
                        change_id=change_id,
                        diff_id=diff_id,
                        impact_results=impact_results,
                        detection_run_id=detection_run_id,
                        db_connection=db_connection
                    )

                    # Phase 6: LAYER 2 - Selective invalidation with optimistic locking
                    invalidation_result = optimistic_lock.selective_invalidate_faqs(
                        change_id=change_id,
                        impact_results=impact_results,
                        detection_run_id=detection_run_id
                    )

                    # Update change log with actual counts
                    db_connection.execute("""
                        UPDATE content_change_log
                        SET total_faqs_at_risk = ?,
                            affected_question_count = ?,
                            affected_answer_count = ?
                        WHERE change_id = ?
                    """, [
                        len(impact_results),
                        invalidation_result.affected_count,
                        invalidation_result.affected_count,  # Same for now
                        change_id
                    ])

                # Metrics
                saved_count = len(impact_results) - affected_count
                total_faqs_affected += invalidation_result.affected_count
                total_faqs_saved += saved_count
                total_conflicts += len(invalidation_result.conflicts)

                logger.info(f"  Change {change_id} results:")
                logger.info(f"    FAQs analyzed: {len(impact_results)}")
                logger.info(f"    FAQs affected: {invalidation_result.affected_count}")
                logger.info(f"    FAQs SAVED: {saved_count} ✅")
                logger.info(f"    Optimistic conflicts: {len(invalidation_result.conflicts)}")
                logger.info(f"    Skipped: {len(invalidation_result.skipped)}")

            # Success
            duration = time.time() - start_time

            logger.info(f"[{detection_run_id}] ✅ Detection complete for '{file_name}'")
            logger.info(f"[{detection_run_id}] Total FAQs analyzed: {total_faqs_analyzed}")
            logger.info(f"[{detection_run_id}] Total FAQs affected: {total_faqs_affected}")
            logger.info(f"[{detection_run_id}] Total FAQs SAVED: {total_faqs_saved} ✅")
            logger.info(f"[{detection_run_id}] Duration: {duration:.2f}s")

            return DetectionRunResult(
                file_name=file_name,
                detection_run_id=detection_run_id,
                changes_detected=len(changes),
                total_faqs_analyzed=total_faqs_analyzed,
                total_faqs_affected=total_faqs_affected,
                total_faqs_saved=total_faqs_saved,
                optimistic_conflicts=total_conflicts,
                status='success',
                duration_seconds=duration
            )

    except LockAcquisitionError as e:
        # Could not acquire distributed lock
        duration = time.time() - start_time

        logger.error(
            f"[{detection_run_id}] ❌ Could not acquire lock on '{file_name}' - "
            f"another process is working on it"
        )

        return DetectionRunResult(
            file_name=file_name,
            detection_run_id=detection_run_id,
            changes_detected=0,
            total_faqs_analyzed=0,
            total_faqs_affected=0,
            total_faqs_saved=0,
            optimistic_conflicts=0,
            status='locked',
            duration_seconds=duration,
            error_message=str(e)
        )

    except Exception as e:
        # Other error
        duration = time.time() - start_time

        logger.exception(f"[{detection_run_id}] ❌ Detection failed for '{file_name}': {e}")

        return DetectionRunResult(
            file_name=file_name,
            detection_run_id=detection_run_id,
            changes_detected=0,
            total_faqs_analyzed=0,
            total_faqs_affected=0,
            total_faqs_saved=0,
            optimistic_conflicts=0,
            status='failed',
            duration_seconds=duration,
            error_message=f"{type(e).__name__}: {str(e)}"
        )


# ============================================================================
# PLACEHOLDER FUNCTIONS (To be implemented with actual logic)
# ============================================================================
# These functions are referenced above but contain actual implementation logic
# from your existing FAQ detection system. Replace with your real implementations.

def detect_content_changes(
    file_name: str,
    detection_run_id: str,
    db_connection,
    since_date: Optional[datetime]
) -> List[Dict[str, Any]]:
    """
    Detect content changes for a file.

    PLACEHOLDER - Replace with your actual implementation from granular_impact_algorithm_v8.md
    """
    # Your existing implementation here
    return []


def compute_content_diff(
    old_text: str,
    new_text: str,
    db_connection
) -> Dict[str, Any]:
    """
    Compute detailed diff between old and new content.

    PLACEHOLDER - Replace with your actual implementation
    """
    # Your existing implementation here
    return {
        'changed_phrases': [],
        'chunks': [],
        'change_percentage': 0.0
    }


def store_change_log(
    change: Dict[str, Any],
    diff_data: Dict[str, Any],
    detection_run_id: str,
    db_connection
) -> int:
    """
    Store change to content_change_log table.

    PLACEHOLDER - Replace with your actual implementation
    """
    # Your existing implementation here
    return 0


def store_content_diff(
    change_id: int,
    diff_data: Dict[str, Any],
    db_connection
) -> int:
    """
    Store diff to content_diffs table.

    PLACEHOLDER - Replace with your actual implementation
    """
    # Your existing implementation here
    return 0


def analyze_faq_impact(
    change: Dict[str, Any],
    diff_data: Dict[str, Any],
    detection_run_id: str,
    db_connection
) -> List[Dict[str, Any]]:
    """
    Analyze which FAQs are affected by this change.

    PLACEHOLDER - Replace with your actual implementation from granular_impact_algorithm_v8.md
    """
    # Your existing implementation here
    return []


def store_impact_analysis(
    change_id: int,
    diff_id: int,
    impact_results: List[Dict[str, Any]],
    detection_run_id: str,
    db_connection
):
    """
    Store impact analysis results to faq_impact_analysis table.

    PLACEHOLDER - Replace with your actual implementation
    """
    # Your existing implementation here
    pass


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def cleanup_stale_locks(db_connection):
    """
    Cleanup stale locks (run periodically as maintenance job).

    Usage:
        # Run every 5 minutes via scheduled job
        cleanup_stale_locks(db)
    """
    lock_manager = DistributedLockManager(db_connection)
    lock_manager._cleanup_stale_locks()


def get_active_locks(db_connection) -> List[Dict[str, Any]]:
    """Get list of currently active locks."""
    try:
        results = db_connection.execute("""
            SELECT
                resource_id,
                owner_id,
                acquired_at,
                expires_at,
                CAST((UNIX_TIMESTAMP(expires_at) - UNIX_TIMESTAMP(CURRENT_TIMESTAMP())) / 60 AS INT) as minutes_remaining
            FROM detection_run_locks
            WHERE expires_at > CURRENT_TIMESTAMP()
            ORDER BY acquired_at DESC
        """).fetchall()

        return [dict(r) for r in results]

    except Exception as e:
        logger.error(f"Error querying active locks: {e}")
        return []


def force_break_lock(db_connection, resource_id: str):
    """
    Force break a lock (use with caution!).

    Only use this if a lock is stuck and you're sure no process is using it.
    """
    logger.warning(f"Force breaking lock on '{resource_id}'")

    try:
        db_connection.execute("""
            DELETE FROM detection_run_locks
            WHERE resource_id = ?
        """, [resource_id])

        logger.info(f"Lock on '{resource_id}' forcibly broken")

    except Exception as e:
        logger.error(f"Error breaking lock: {e}")


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    """
    Example usage of dual locking strategy.
    """

    # Mock database connection (replace with your actual DB connection)
    class MockDB:
        def execute(self, query, params=None):
            class Result:
                rowcount = 1
            return Result()

        def transaction(self):
            from contextlib import contextmanager
            @contextmanager
            def transaction():
                yield
            return transaction()

    db = MockDB()

    # Run detection with dual locking
    result = run_granular_faq_update_detection(
        file_name="handbook.pdf",
        detection_run_id="RUN_2025_10_21_001",
        db_connection=db
    )

    print("\n" + "="*80)
    print("DETECTION RUN RESULTS")
    print("="*80)
    print(f"File: {result.file_name}")
    print(f"Status: {result.status}")
    print(f"Changes detected: {result.changes_detected}")
    print(f"FAQs analyzed: {result.total_faqs_analyzed}")
    print(f"FAQs affected: {result.total_faqs_affected}")
    print(f"FAQs SAVED: {result.total_faqs_saved} ✅")
    print(f"Optimistic conflicts: {result.optimistic_conflicts}")
    print(f"Duration: {result.duration_seconds:.2f}s")
    print("="*80)
