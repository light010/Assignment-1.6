# Granular FAQ Impact Detection V8 - Complete Implementation TODO

## Executive Summary

This is a comprehensive implementation plan for the V8 Granular FAQ Impact Detection System. The implementation involves database schema deployment, Python algorithm implementation, critical bug fixes, testing, and validation.

**Estimated Timeline:** 3-4 weeks (senior developer, full-time)
**Critical Path:** Schema → Core Logic → Bug Fixes → Testing → Deployment

---

## PHASE 1: DATABASE SCHEMA & FOUNDATION (Week 1, Days 1-2)

### 1.1 Schema Analysis & Preparation
- [ ] **Review schema dependencies and constraints**
  - Location: `FAQ_update/sql/create_schema_v8_granular_impact.sql`
  - Verify all foreign key references are correct
  - Check constraint logic for edge cases
  - Validate default values and auto-increment settings

- [ ] **Create schema migration strategy**
  - Determine if this is greenfield or migration from V7
  - Plan for data backfill if migrating from V7
  - Create rollback plan in case of issues
  - Document breaking changes from V7 to V8

- [ ] **Test schema in isolated environment**
  - Create test catalog/schema in Databricks
  - Run schema creation script
  - Verify all tables, views, constraints created successfully
  - Test CASCADE behaviors with sample data

### 1.2 Schema Deployment
- [ ] **Deploy to Databricks Unity Catalog**
  - Choose target catalog and schema
  - Execute `create_schema_v8_granular_impact.sql`
  - Verify deployment with: `SHOW TABLES; SHOW VIEWS;`
  - Document catalog/schema paths in config

- [ ] **Create indexes for performance**
  ```sql
  -- Not in original schema, but critical for production
  CREATE INDEX idx_ccl_detection_run ON content_change_log(detection_run_id);
  CREATE INDEX idx_ccl_checksum ON content_change_log(content_checksum);
  CREATE INDEX idx_qs_checksum ON faq_question_sources(content_checksum);
  CREATE INDEX idx_as_checksum ON faq_answer_sources(content_checksum);
  CREATE INDEX idx_fia_change ON faq_impact_analysis(change_id);
  CREATE INDEX idx_fia_question ON faq_impact_analysis(question_id);
  ```

- [ ] **Set up Delta Lake optimization**
  - Configure auto-optimize settings
  - Set up Z-ordering on frequently queried columns
  - Schedule VACUUM jobs for old versions

---

## PHASE 2: CRITICAL BUG FIXES (Week 1, Days 3-4)

### 2.1 Fix SQL Query Bug in FAQ Impact Retrieval

**CRITICAL:** The query in `granular_impact_algorithm_v8.md:531-546` has THREE BUGS that will cause incorrect results.

- [ ] **Bug 1: Fix LEFT JOIN semantic violation**
  - **Problem:** `WHERE qs.is_valid = TRUE` filters out NULL rows from LEFT JOIN
  - **Impact:** FAQs without question sources are silently dropped
  - **Fix:** Move condition to JOIN ON clause OR use `(qs.is_valid = TRUE OR qs.is_valid IS NULL)`

- [ ] **Bug 2: Add missing answer source validation**
  - **Problem:** No `asrc.is_valid = TRUE` filter
  - **Impact:** Returns FAQs with invalidated answer sources (stale data!)
  - **Fix:** Add symmetric validation for answer sources

- [ ] **Bug 3: Separate question vs answer impact logic**
  - **Problem:** `WHERE (qs.content_checksum = ? OR asrc.content_checksum = ?)` returns mixed cases
  - **Impact:** Treats "Q uses old checksum" same as "A uses old checksum" same as "both use old checksum"
  - **Fix:** Use UNION with separate CTEs for question-impacted vs answer-impacted FAQs

- [ ] **Implement corrected query architecture**
  ```sql
  -- CORRECTED QUERY (replaces lines 531-546)
  WITH question_impacted AS (
      SELECT DISTINCT
          q.question_id,
          q.question_text,
          a.answer_id,
          a.answer_text,
          'question' as impact_type,
          qs.source_id as impacted_source_id,
          qs.content_checksum as impacted_checksum
      FROM faq_questions q
      INNER JOIN faq_question_sources qs
          ON q.question_id = qs.question_id
          AND qs.is_valid = TRUE  -- Only valid sources
      LEFT JOIN faq_answers a
          ON q.question_id = a.question_id
          AND a.status = 'active'
      WHERE qs.content_checksum = ?
        AND q.status = 'active'
  ),
  answer_impacted AS (
      SELECT DISTINCT
          q.question_id,
          q.question_text,
          a.answer_id,
          a.answer_text,
          'answer' as impact_type,
          asrc.source_id as impacted_source_id,
          asrc.content_checksum as impacted_checksum
      FROM faq_questions q
      INNER JOIN faq_answers a
          ON q.question_id = a.question_id
          AND a.status = 'active'
      INNER JOIN faq_answer_sources asrc
          ON a.answer_id = asrc.answer_id
          AND asrc.is_valid = TRUE  -- Symmetric validation!
      WHERE asrc.content_checksum = ?
        AND q.status = 'active'
  )
  -- Return with impact type tracking
  SELECT
      question_id,
      question_text,
      answer_id,
      answer_text,
      CASE
          WHEN COUNT(DISTINCT impact_type) > 1 THEN 'both'
          ELSE MAX(impact_type)
      END as impact_type,
      COLLECT_SET(impacted_source_id) as impacted_sources,
      COLLECT_SET(impacted_checksum) as impacted_checksums
  FROM (
      SELECT * FROM question_impacted
      UNION ALL
      SELECT * FROM answer_impacted
  )
  GROUP BY question_id, question_text, answer_id, answer_text;
  ```

- [ ] **Document edge cases handled by fix**
  - FAQ uses same source for both Q&A (returns as "both")
  - Multiple sources per FAQ component (lists all affected sources)
  - Question without answer (returns with answer_id = NULL)
  - Inactive answers (excluded via status filter)

- [ ] **Create test cases for bug validation**
  - Test Case 1: FAQ with invalid answer source (should be excluded)
  - Test Case 2: FAQ without question source (behavior depends on use case)
  - Test Case 3: FAQ with mixed checksums (should track impact_type correctly)
  - Test Case 4: FAQ with same checksum for Q&A (should return once with type='both')

---

## PHASE 3: PYTHON MODULE STRUCTURE (Week 1, Days 4-5)

### 3.1 Design Module Architecture

- [ ] **Create directory structure**
  ```
  FAQ_update/
  ├── granular_impact/
  │   ├── __init__.py
  │   ├── config.py                  # Configuration management
  │   ├── similarity/
  │   │   ├── __init__.py
  │   │   ├── base.py                # Abstract similarity interface
  │   │   ├── jaccard.py             # Jaccard similarity
  │   │   ├── difflib_sim.py         # Difflib SequenceMatcher
  │   │   ├── tfidf_sim.py           # TF-IDF cosine similarity
  │   │   ├── embedding_sim.py       # Sentence embedding similarity (optional)
  │   │   ├── bm25_sim.py            # BM25 similarity (optional)
  │   │   └── hybrid.py              # Hybrid multi-level approach
  │   ├── diff/
  │   │   ├── __init__.py
  │   │   ├── diff_engine.py         # Core diff computation
  │   │   ├── phrase_extractor.py    # Extract meaningful phrases
  │   │   └── semantic_detector.py   # Detect numeric/date/policy changes
  │   ├── impact/
  │   │   ├── __init__.py
  │   │   ├── impact_analyzer.py     # Core impact analysis logic
  │   │   ├── scoring.py             # Individual scoring methods
  │   │   └── decision.py            # Impact decision logic
  │   ├── database/
  │   │   ├── __init__.py
  │   │   ├── connection.py          # Databricks connection
  │   │   ├── queries.py             # SQL query templates
  │   │   ├── models.py              # Data models (dataclasses)
  │   │   └── transactions.py        # Transaction management
  │   ├── detection/
  │   │   ├── __init__.py
  │   │   ├── change_detector.py     # Phase 1: Content change detection
  │   │   └── checksum_extractor.py  # Extract checksums from files
  │   ├── workflow/
  │   │   ├── __init__.py
  │   │   ├── orchestrator.py        # Main workflow orchestration
  │   │   └── invalidator.py         # Selective invalidation logic
  │   └── utils/
  │       ├── __init__.py
  │       ├── logging_utils.py       # Logging setup
  │       ├── metrics.py             # Performance metrics
  │       └── validators.py          # Data validation
  ├── tests/
  │   ├── __init__.py
  │   ├── test_similarity/
  │   ├── test_diff/
  │   ├── test_impact/
  │   ├── test_database/
  │   ├── test_integration/
  │   └── fixtures/
  │       ├── test_data.py           # Test data generator
  │       └── sample_content.py      # Sample content for testing
  └── notebooks/
      ├── 01_schema_setup.py         # Databricks notebook for schema setup
      ├── 02_test_similarity.py      # Test similarity algorithms
      ├── 03_run_detection.py        # Run detection workflow
      └── 04_analyze_results.py      # Analyze impact results
  ```

- [ ] **Define data models using dataclasses**
  ```python
  # database/models.py
  from dataclasses import dataclass
  from typing import Optional, List, Dict
  from datetime import datetime

  @dataclass
  class ContentChecksum:
      content_checksum: str
      content_text: str
      file_type: Optional[str] = None
      title: Optional[str] = None
      word_count: Optional[int] = None
      status: str = 'active'
      created_at: Optional[datetime] = None

  @dataclass
  class ContentChange:
      old_checksum: Optional[str]
      new_checksum: str
      old_text: Optional[str]
      new_text: str
      change_type: str  # 'new_content', 'modified_content', 'deleted_content'
      similarity_score: float
      similarity_method: Optional[str] = None
      page_number: Optional[int] = None

  @dataclass
  class ContentDiff:
      chunks: List[Dict]
      changed_phrases: List[str]
      additions_count: int
      deletions_count: int
      change_percentage: float
      contains_numeric_changes: bool
      contains_date_changes: bool
      contains_policy_changes: bool
      contains_eligibility_changes: bool
      diff_data: Dict

  @dataclass
  class FAQ:
      question_id: int
      question_text: str
      answer_id: Optional[int]
      answer_text: Optional[str]
      impact_type: str  # 'question', 'answer', 'both', 'question_only'
      impacted_sources: List[int]
      impacted_checksums: List[str]

  @dataclass
  class ImpactScore:
      overall_score: float
      lexical_score: float
      keyword_score: float
      semantic_score: float
      phrase_score: float
      matched_phrases: List[str]

  @dataclass
  class ImpactResult:
      question_id: int
      answer_id: Optional[int]
      overall_impact_score: float
      lexical_overlap_score: float
      keyword_match_score: float
      semantic_similarity_score: float
      phrase_match_score: float
      is_affected: bool
      impact_level: str  # 'high', 'medium', 'low', 'none'
      impact_reason: str
      matched_changes: Dict
  ```

### 3.2 Configuration Management

- [ ] **Create configuration file with all tunable parameters**
  ```python
  # config.py
  from dataclasses import dataclass
  from typing import Dict

  @dataclass
  class SimilarityConfig:
      """Configuration for similarity computation"""
      threshold: float = 0.8  # Similarity threshold for modification detection
      jaccard_weight: float = 0.2
      difflib_weight: float = 0.5
      tfidf_weight: float = 0.3
      embedding_weight: float = 0.0  # Disabled by default (slow)
      early_exit_threshold: float = 0.3  # Jaccard early exit

  @dataclass
  class ImpactConfig:
      """Configuration for impact analysis"""
      high_threshold: float = 0.7
      medium_threshold: float = 0.4
      low_threshold: float = 0.2

      # Score weights
      lexical_weight: float = 0.3
      keyword_weight: float = 0.3
      semantic_weight: float = 0.2
      phrase_weight: float = 0.2

      # Enable/disable features
      use_embeddings: bool = False  # Slow but accurate
      use_critical_overlap: bool = True  # Numeric/policy change detection

  @dataclass
  class DatabaseConfig:
      """Databricks connection configuration"""
      catalog: str
      schema: str
      workspace_url: str
      token_secret_scope: str
      token_secret_key: str

  @dataclass
  class GranularImpactConfig:
      """Master configuration"""
      similarity: SimilarityConfig
      impact: ImpactConfig
      database: DatabaseConfig

      # Operational settings
      batch_size: int = 100  # Process FAQs in batches
      max_comparisons: int = 10000  # Safety limit for N×M comparisons
      enable_audit_logging: bool = True
      enable_performance_metrics: bool = True

  # Load from YAML or environment
  def load_config(config_path: str = None) -> GranularImpactConfig:
      """Load configuration from file or use defaults"""
      if config_path:
          # Load from YAML (use Hydra if available)
          pass
      return GranularImpactConfig(
          similarity=SimilarityConfig(),
          impact=ImpactConfig(),
          database=DatabaseConfig(
              catalog='your_catalog',
              schema='your_schema',
              workspace_url='https://your-workspace.databricks.com',
              token_secret_scope='your_scope',
              token_secret_key='your_key'
          )
      )
  ```

---

## PHASE 4: CORE ALGORITHM IMPLEMENTATION (Week 2)

### 4.1 Similarity Computation Module

- [ ] **Implement base similarity interface**
  ```python
  # similarity/base.py
  from abc import ABC, abstractmethod

  class SimilarityMethod(ABC):
      """Abstract base class for similarity methods"""

      @abstractmethod
      def compute(self, text1: str, text2: str) -> float:
          """Compute similarity between two texts (0.0 to 1.0)"""
          pass

      @property
      @abstractmethod
      def name(self) -> str:
          """Method name for logging"""
          pass
  ```

- [ ] **Implement Jaccard similarity**
  ```python
  # similarity/jaccard.py
  from .base import SimilarityMethod

  class JaccardSimilarity(SimilarityMethod):
      """Token-based Jaccard similarity"""

      def compute(self, text1: str, text2: str) -> float:
          tokens1 = set(text1.lower().split())
          tokens2 = set(text2.lower().split())

          if not tokens1 or not tokens2:
              return 0.0

          intersection = tokens1 & tokens2
          union = tokens1 | tokens2

          return len(intersection) / len(union)

      @property
      def name(self) -> str:
          return "jaccard"
  ```

- [ ] **Implement Difflib similarity**
  ```python
  # similarity/difflib_sim.py
  import difflib
  from .base import SimilarityMethod

  class DifflibSimilarity(SimilarityMethod):
      """Difflib SequenceMatcher similarity"""

      def compute(self, text1: str, text2: str) -> float:
          # Normalize whitespace
          text1_clean = ' '.join(text1.split())
          text2_clean = ' '.join(text2.split())

          return difflib.SequenceMatcher(
              None,
              text1_clean,
              text2_clean
          ).ratio()

      @property
      def name(self) -> str:
          return "difflib"
  ```

- [ ] **Implement TF-IDF cosine similarity**
  ```python
  # similarity/tfidf_sim.py
  from sklearn.feature_extraction.text import TfidfVectorizer
  from sklearn.metrics.pairwise import cosine_similarity
  from .base import SimilarityMethod

  class TfidfCosineSimilarity(SimilarityMethod):
      """TF-IDF cosine similarity"""

      def __init__(self, max_features: int = 1000):
          self.max_features = max_features

      def compute(self, text1: str, text2: str) -> float:
          try:
              vectorizer = TfidfVectorizer(
                  lowercase=True,
                  stop_words='english',
                  max_features=self.max_features,
                  ngram_range=(1, 2)
              )

              tfidf_matrix = vectorizer.fit_transform([text1, text2])
              similarity = cosine_similarity(
                  tfidf_matrix[0:1],
                  tfidf_matrix[1:2]
              )[0][0]

              return similarity
          except:
              return 0.0  # Fallback if text too short

      @property
      def name(self) -> str:
          return "tfidf_cosine"
  ```

- [ ] **Implement embedding similarity (optional, for max accuracy)**
  ```python
  # similarity/embedding_sim.py
  from typing import Optional
  from .base import SimilarityMethod

  class EmbeddingSimilarity(SimilarityMethod):
      """Sentence embedding similarity using sentence-transformers"""

      def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
          self.model_name = model_name
          self._model = None

      @property
      def model(self):
          """Lazy load model (expensive operation)"""
          if self._model is None:
              try:
                  from sentence_transformers import SentenceTransformer
                  self._model = SentenceTransformer(self.model_name)
              except ImportError:
                  raise ImportError(
                      "sentence-transformers not installed. "
                      "Install with: pip install sentence-transformers"
                  )
          return self._model

      def compute(self, text1: str, text2: str) -> float:
          try:
              from sentence_transformers import util

              emb1 = self.model.encode(text1, convert_to_tensor=True)
              emb2 = self.model.encode(text2, convert_to_tensor=True)

              similarity = util.cos_sim(emb1, emb2).item()
              return similarity
          except Exception as e:
              print(f"Warning: Embedding similarity failed: {e}")
              return 0.0

      @property
      def name(self) -> str:
          return f"embedding_{self.model_name}"
  ```

- [ ] **Implement hybrid similarity combiner**
  ```python
  # similarity/hybrid.py
  from typing import List, Dict
  from .base import SimilarityMethod
  from .jaccard import JaccardSimilarity
  from .difflib_sim import DifflibSimilarity
  from .tfidf_sim import TfidfCosineSimilarity
  from ..config import SimilarityConfig

  class HybridSimilarity:
      """Hybrid multi-level similarity computation"""

      def __init__(self, config: SimilarityConfig):
          self.config = config
          self.jaccard = JaccardSimilarity()
          self.difflib = DifflibSimilarity()
          self.tfidf = TfidfCosineSimilarity()

      def compute(self, text1: str, text2: str) -> Dict[str, float]:
          """
          Compute hybrid similarity with early exit.
          Returns dict with individual scores and combined score.
          """
          # Level 1: Jaccard (fast filter)
          jaccard_score = self.jaccard.compute(text1, text2)

          # Early exit if too different
          if jaccard_score < self.config.early_exit_threshold:
              return {
                  'jaccard': jaccard_score,
                  'difflib': 0.0,
                  'tfidf': 0.0,
                  'combined': 0.0,
                  'early_exit': True
              }

          # Level 2: Difflib (word-level changes)
          difflib_score = self.difflib.compute(text1, text2)

          # Level 3: TF-IDF (semantic weighting)
          tfidf_score = self.tfidf.compute(text1, text2)

          # Weighted combination
          combined_score = (
              jaccard_score * self.config.jaccard_weight +
              difflib_score * self.config.difflib_weight +
              tfidf_score * self.config.tfidf_weight
          )

          return {
              'jaccard': jaccard_score,
              'difflib': difflib_score,
              'tfidf': tfidf_score,
              'combined': combined_score,
              'early_exit': False
          }
  ```

### 4.2 Content Diff Computation Module

- [ ] **Implement diff engine**
  ```python
  # diff/diff_engine.py
  import difflib
  from typing import List, Dict
  from ..database.models import ContentDiff

  class DiffEngine:
      """Compute granular diffs between content versions"""

      def compute_diff(self, old_text: str, new_text: str) -> ContentDiff:
          """Compute comprehensive diff"""
          from diff_match_patch import diff_match_patch

          # Word-level diff
          dmp = diff_match_patch()
          word_diffs = dmp.diff_main(old_text, new_text)
          dmp.diff_cleanupSemantic(word_diffs)

          # Extract chunks
          chunks = self._extract_chunks(word_diffs)

          # Extract changed phrases
          from .phrase_extractor import PhraseExtractor
          extractor = PhraseExtractor()
          changed_phrases = extractor.extract_from_chunks(chunks)

          # Compute statistics
          additions = sum(1 for op, _ in word_diffs if op == 1)
          deletions = sum(1 for op, _ in word_diffs if op == -1)
          total_words = len(new_text.split())
          change_pct = ((additions + deletions) / total_words * 100) if total_words > 0 else 0

          # Detect semantic changes
          from .semantic_detector import SemanticChangeDetector
          detector = SemanticChangeDetector()
          semantic_flags = detector.detect(chunks)

          return ContentDiff(
              chunks=chunks,
              changed_phrases=changed_phrases,
              additions_count=additions,
              deletions_count=deletions,
              change_percentage=change_pct,
              contains_numeric_changes=semantic_flags['numeric'],
              contains_date_changes=semantic_flags['date'],
              contains_policy_changes=semantic_flags['policy'],
              contains_eligibility_changes=semantic_flags['eligibility'],
              diff_data={'word_diffs': word_diffs}
          )

      def _extract_chunks(self, word_diffs: List) -> List[Dict]:
          """Extract change chunks from diff"""
          chunks = []
          for i, (op, text) in enumerate(word_diffs):
              if op != 0:  # Not equal
                  chunks.append({
                      'type': 'added' if op == 1 else 'deleted' if op == -1 else 'modified',
                      'text': text,
                      'position': i
                  })
          return chunks
  ```

- [ ] **Implement phrase extractor**
  ```python
  # diff/phrase_extractor.py
  from typing import List, Dict

  class PhraseExtractor:
      """Extract meaningful phrases from changed text"""

      def __init__(self, min_words: int = 2, max_words: int = 5):
          self.min_words = min_words
          self.max_words = max_words

      def extract_from_chunks(self, chunks: List[Dict]) -> List[str]:
          """Extract n-grams from chunks"""
          phrases = set()

          for chunk in chunks:
              text = chunk['text']
              phrases.update(self._extract_ngrams(text))

          return list(phrases)

      def _extract_ngrams(self, text: str) -> List[str]:
          """Extract n-grams (2-5 words)"""
          # Try with nltk first, fallback to simple split
          try:
              from nltk import ngrams
              words = text.split()
              phrases = []

              for n in range(self.min_words, min(self.max_words + 1, len(words) + 1)):
                  phrases.extend([' '.join(gram) for gram in ngrams(words, n)])

              return phrases
          except ImportError:
              # Simple fallback without nltk
              words = text.split()
              phrases = []
              for n in range(self.min_words, min(self.max_words + 1, len(words) + 1)):
                  for i in range(len(words) - n + 1):
                      phrases.append(' '.join(words[i:i+n]))
              return phrases
  ```

- [ ] **Implement semantic change detector**
  ```python
  # diff/semantic_detector.py
  import re
  from typing import List, Dict

  class SemanticChangeDetector:
      """Detect semantic types of changes (numeric, dates, policy, etc.)"""

      def __init__(self):
          self.date_patterns = [
              r'\d{1,2}/\d{1,2}/\d{2,4}',  # MM/DD/YYYY
              r'\d{4}-\d{2}-\d{2}',         # YYYY-MM-DD
              r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2}',
              r'\d{1,2}\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)'
          ]

          self.policy_keywords = [
              'must', 'shall', 'required', 'mandatory',
              'prohibited', 'allowed', 'eligible'
          ]

          self.eligibility_terms = [
              'all employees', 'full-time', 'part-time',
              'eligible', 'qualified', 'enrolled'
          ]

      def detect(self, chunks: List[Dict]) -> Dict[str, bool]:
          """Detect types of semantic changes"""
          return {
              'numeric': self._detect_numeric(chunks),
              'date': self._detect_dates(chunks),
              'policy': self._detect_policy(chunks),
              'eligibility': self._detect_eligibility(chunks)
          }

      def _detect_numeric(self, chunks: List[Dict]) -> bool:
          """Check if any chunks contain numeric changes"""
          for chunk in chunks:
              if re.search(r'\d+', chunk['text']):
                  return True
          return False

      def _detect_dates(self, chunks: List[Dict]) -> bool:
          """Check if chunks contain date-related changes"""
          for chunk in chunks:
              for pattern in self.date_patterns:
                  if re.search(pattern, chunk['text'], re.IGNORECASE):
                      return True
          return False

      def _detect_policy(self, chunks: List[Dict]) -> bool:
          """Check if policy-related keywords changed"""
          for chunk in chunks:
              text_lower = chunk['text'].lower()
              if any(keyword in text_lower for keyword in self.policy_keywords):
                  return True
          return False

      def _detect_eligibility(self, chunks: List[Dict]) -> bool:
          """Check if eligibility terms changed"""
          for chunk in chunks:
              text_lower = chunk['text'].lower()
              if any(term in text_lower for term in self.eligibility_terms):
                  return True
          return False
  ```

### 4.3 FAQ Impact Analysis Module

- [ ] **Implement individual scoring methods**
  ```python
  # impact/scoring.py
  from typing import List, Dict, Tuple

  class ImpactScoring:
      """Individual scoring methods for FAQ impact"""

      @staticmethod
      def compute_lexical_overlap(faq_text: str, changed_phrases: List[str]) -> float:
          """Jaccard similarity between FAQ tokens and changed phrases"""
          faq_tokens = set(faq_text.lower().split())
          changed_tokens = set(' '.join(changed_phrases).lower().split())

          if not faq_tokens or not changed_tokens:
              return 0.0

          intersection = faq_tokens & changed_tokens
          union = faq_tokens | changed_tokens

          return len(intersection) / len(union)

      @staticmethod
      def compute_keyword_match(faq_text: str, changed_phrases: List[str]) -> float:
          """Count how many changed phrases appear in FAQ"""
          if not changed_phrases:
              return 0.0

          faq_lower = faq_text.lower()
          matches = sum(1 for phrase in changed_phrases if phrase.lower() in faq_lower)

          return matches / len(changed_phrases)

      @staticmethod
      def compute_phrase_match(faq_text: str, changed_phrases: List[str]) -> Tuple[float, List[str]]:
          """Find exact phrase matches in FAQ"""
          if not changed_phrases:
              return 0.0, []

          faq_lower = faq_text.lower()
          matched = [phrase for phrase in changed_phrases if phrase.lower() in faq_lower]

          score = len(matched) / len(changed_phrases)
          return score, matched

      @staticmethod
      def compute_semantic_similarity(faq_text: str, diff_chunks: List[Dict]) -> float:
          """
          Compute semantic similarity using embeddings.
          Optional - requires sentence-transformers.
          """
          try:
              from sentence_transformers import SentenceTransformer, util
              model = SentenceTransformer('all-MiniLM-L6-v2')

              # Embed FAQ text
              faq_embedding = model.encode(faq_text, convert_to_tensor=True)

              # Embed changed text chunks
              changed_texts = [chunk['text'] for chunk in diff_chunks]
              if not changed_texts:
                  return 0.0

              chunk_embeddings = model.encode(changed_texts, convert_to_tensor=True)

              # Max similarity (FAQ to any changed chunk)
              similarities = util.cos_sim(faq_embedding, chunk_embeddings)
              max_similarity = float(similarities.max())

              return max_similarity
          except:
              return 0.0  # Fallback if embeddings not available

      @staticmethod
      def has_critical_overlap(faq_text: str, diff_data: Dict) -> bool:
          """Check if FAQ contains critical terms that changed (numbers, etc.)"""
          import re

          # Extract numbers from diff
          diff_numbers = set()
          for chunk in diff_data.get('chunks', []):
              numbers = re.findall(r'\d+', chunk['text'])
              diff_numbers.update(numbers)

          # Check if FAQ contains same numbers
          faq_numbers = set(re.findall(r'\d+', faq_text))

          return bool(diff_numbers & faq_numbers)
  ```

- [ ] **Implement impact decision logic**
  ```python
  # impact/decision.py
  from typing import Tuple
  from ..config import ImpactConfig
  from ..database.models import ImpactScore, ContentDiff

  class ImpactDecision:
      """Determine if FAQ is affected based on scores"""

      def __init__(self, config: ImpactConfig):
          self.config = config

      def decide(
          self,
          scores: ImpactScore,
          diff_data: ContentDiff,
          faq_text: str
      ) -> Tuple[bool, str, str]:
          """
          Decide if FAQ is affected.
          Returns: (is_affected, impact_level, impact_reason)
          """
          overall_score = scores.overall_score

          # Base decision on threshold
          if overall_score >= self.config.high_threshold:
              is_affected = True
              impact_level = 'high'
              reason = (
                  f"FAQ text strongly overlaps with changes (score: {overall_score:.2f}). "
                  f"Matched phrases: {scores.matched_phrases}"
              )
          elif overall_score >= self.config.medium_threshold:
              is_affected = True
              impact_level = 'medium'
              reason = (
                  f"FAQ text moderately overlaps with changes (score: {overall_score:.2f}). "
                  f"Review recommended."
              )
          elif overall_score >= self.config.low_threshold:
              is_affected = False
              impact_level = 'low'
              reason = (
                  f"Minimal overlap (score: {overall_score:.2f}). "
                  f"Likely unaffected but flagged for review."
              )
          else:
              is_affected = False
              impact_level = 'none'
              reason = f"No significant overlap with changes (score: {overall_score:.2f})"

          # Override for critical changes
          if self.config.use_critical_overlap:
              if diff_data.contains_numeric_changes or diff_data.contains_policy_changes:
                  from .scoring import ImpactScoring
                  if ImpactScoring.has_critical_overlap(faq_text, diff_data.__dict__):
                      is_affected = True
                      impact_level = 'high'
                      reason = f"Critical content change detected (numeric/policy). {reason}"

          return is_affected, impact_level, reason
  ```

- [ ] **Implement main impact analyzer**
  ```python
  # impact/impact_analyzer.py
  from typing import List, Dict
  from ..database.models import FAQ, ContentDiff, ImpactResult, ImpactScore
  from ..config import ImpactConfig
  from .scoring import ImpactScoring
  from .decision import ImpactDecision

  class ImpactAnalyzer:
      """Analyze which FAQs are affected by content changes"""

      def __init__(self, config: ImpactConfig):
          self.config = config
          self.scoring = ImpactScoring()
          self.decision = ImpactDecision(config)

      def analyze_faqs(
          self,
          faqs: List[FAQ],
          diff_data: ContentDiff
      ) -> List[ImpactResult]:
          """Analyze impact for all FAQs"""
          results = []

          for faq in faqs:
              result = self._analyze_single_faq(faq, diff_data)
              results.append(result)

          return results

      def _analyze_single_faq(self, faq: FAQ, diff_data: ContentDiff) -> ImpactResult:
          """Analyze impact for a single FAQ"""
          # Combine question + answer text
          faq_full_text = f"{faq.question_text} {faq.answer_text or ''}"

          # Compute individual scores
          lexical_score = self.scoring.compute_lexical_overlap(
              faq_full_text,
              diff_data.changed_phrases
          )

          keyword_score = self.scoring.compute_keyword_match(
              faq_full_text,
              diff_data.changed_phrases
          )

          phrase_score, matched_phrases = self.scoring.compute_phrase_match(
              faq_full_text,
              diff_data.changed_phrases
          )

          semantic_score = 0.0
          if self.config.use_embeddings:
              semantic_score = self.scoring.compute_semantic_similarity(
                  faq_full_text,
                  diff_data.chunks
              )

          # Combine scores
          overall_score = (
              lexical_score * self.config.lexical_weight +
              keyword_score * self.config.keyword_weight +
              semantic_score * self.config.semantic_weight +
              phrase_score * self.config.phrase_weight
          )

          scores = ImpactScore(
              overall_score=overall_score,
              lexical_score=lexical_score,
              keyword_score=keyword_score,
              semantic_score=semantic_score,
              phrase_score=phrase_score,
              matched_phrases=matched_phrases
          )

          # Make decision
          is_affected, impact_level, impact_reason = self.decision.decide(
              scores,
              diff_data,
              faq_full_text
          )

          # Build matched changes detail
          question_matches = self._find_matches(faq.question_text, diff_data.changed_phrases)
          answer_matches = self._find_matches(faq.answer_text or '', diff_data.changed_phrases)

          return ImpactResult(
              question_id=faq.question_id,
              answer_id=faq.answer_id,
              overall_impact_score=overall_score,
              lexical_overlap_score=lexical_score,
              keyword_match_score=keyword_score,
              semantic_similarity_score=semantic_score,
              phrase_match_score=phrase_score,
              is_affected=is_affected,
              impact_level=impact_level,
              impact_reason=impact_reason,
              matched_changes={
                  'matched_phrases': matched_phrases,
                  'question_matches': question_matches,
                  'answer_matches': answer_matches
              }
          )

      @staticmethod
      def _find_matches(text: str, phrases: List[str]) -> List[str]:
          """Find which phrases appear in text"""
          text_lower = text.lower()
          return [phrase for phrase in phrases if phrase.lower() in text_lower]
  ```

---

## PHASE 5: DATABASE ACCESS LAYER (Week 2, Days 3-4)

### 5.1 Database Connection & Queries

- [ ] **Implement Databricks connection manager**
  ```python
  # database/connection.py
  from typing import Optional
  from pyspark.sql import SparkSession
  import os

  class DatabricksConnection:
      """Manage Databricks database connection"""

      def __init__(self, catalog: str, schema: str):
          self.catalog = catalog
          self.schema = schema
          self._spark: Optional[SparkSession] = None

      @property
      def spark(self) -> SparkSession:
          """Get or create Spark session"""
          if self._spark is None:
              self._spark = SparkSession.builder \
                  .appName("GranularFAQImpact") \
                  .getOrCreate()

              # Set catalog and schema
              self._spark.sql(f"USE CATALOG {self.catalog}")
              self._spark.sql(f"USE SCHEMA {self.schema}")

          return self._spark

      def execute(self, query: str, params: Optional[List] = None):
          """Execute SQL query"""
          if params:
              # Use parameterized query (Spark SQL doesn't support ? placeholders)
              # Need to format manually or use DataFrame API
              for i, param in enumerate(params):
                  query = query.replace('?', f"'{param}'", 1)

          return self.spark.sql(query)

      def close(self):
          """Close connection"""
          if self._spark:
              self._spark.stop()
              self._spark = None
  ```

- [ ] **Implement SQL query templates with FIXED bugs**
  ```python
  # database/queries.py
  from typing import List

  class SQLQueries:
      """SQL query templates for granular impact system"""

      # ============================================================
      # CRITICAL FIX: Corrected FAQ retrieval query
      # ============================================================
      GET_IMPACTED_FAQS = """
      WITH question_impacted AS (
          SELECT DISTINCT
              q.question_id,
              q.question_text,
              a.answer_id,
              a.answer_text,
              'question' as impact_type,
              qs.source_id as impacted_source_id,
              qs.content_checksum as impacted_checksum
          FROM faq_questions q
          INNER JOIN faq_question_sources qs
              ON q.question_id = qs.question_id
              AND qs.is_valid = TRUE  -- BUG FIX 1 & 2: Explicit INNER JOIN + validation
          LEFT JOIN faq_answers a
              ON q.question_id = a.question_id
              AND a.status = 'active'
          WHERE qs.content_checksum = '{old_checksum}'
            AND q.status = 'active'
      ),
      answer_impacted AS (
          SELECT DISTINCT
              q.question_id,
              q.question_text,
              a.answer_id,
              a.answer_text,
              'answer' as impact_type,
              asrc.source_id as impacted_source_id,
              asrc.content_checksum as impacted_checksum
          FROM faq_questions q
          INNER JOIN faq_answers a
              ON q.question_id = a.question_id
              AND a.status = 'active'
          INNER JOIN faq_answer_sources asrc
              ON a.answer_id = asrc.answer_id
              AND asrc.is_valid = TRUE  -- BUG FIX 2: Symmetric validation!
          WHERE asrc.content_checksum = '{old_checksum}'
            AND q.status = 'active'
      )
      -- BUG FIX 3: Separate tracking of question vs answer impact
      SELECT
          question_id,
          question_text,
          answer_id,
          answer_text,
          CASE
              WHEN COUNT(DISTINCT impact_type) > 1 THEN 'both'
              ELSE MAX(impact_type)
          END as impact_type,
          COLLECT_SET(impacted_source_id) as impacted_sources,
          COLLECT_SET(impacted_checksum) as impacted_checksums
      FROM (
          SELECT * FROM question_impacted
          UNION ALL
          SELECT * FROM answer_impacted
      )
      GROUP BY question_id, question_text, answer_id, answer_text
      """

      # Other queries...
      INSERT_CHANGE_LOG = """
      INSERT INTO content_change_log (
          content_checksum,
          previous_checksum,
          file_name,
          page_number,
          section_name,
          requires_faq_regeneration,
          change_type,
          similarity_score,
          similarity_method,
          total_faqs_at_risk,
          detection_run_id,
          detection_timestamp,
          domain,
          service
      ) VALUES (
          '{new_checksum}',
          '{old_checksum}',
          '{file_name}',
          {page_number},
          '{section_name}',
          {requires_faq_regen},
          '{change_type}',
          {similarity_score},
          '{similarity_method}',
          {total_faqs_at_risk},
          '{detection_run_id}',
          CURRENT_TIMESTAMP(),
          '{domain}',
          '{service}'
      )
      """

      INSERT_CONTENT_DIFF = """
      INSERT INTO content_diffs (
          change_id,
          old_checksum,
          new_checksum,
          diff_type,
          diff_algorithm,
          additions_count,
          deletions_count,
          modifications_count,
          total_changes,
          change_percentage,
          diff_data,
          contains_numeric_changes,
          contains_date_changes,
          contains_policy_changes,
          contains_eligibility_changes,
          changed_phrases,
          computed_at
      ) VALUES (
          {change_id},
          '{old_checksum}',
          '{new_checksum}',
          'word_diff',
          'diff_match_patch',
          {additions_count},
          {deletions_count},
          {modifications_count},
          {total_changes},
          {change_percentage},
          '{diff_data_json}',
          {contains_numeric},
          {contains_date},
          {contains_policy},
          {contains_eligibility},
          '{changed_phrases_json}',
          CURRENT_TIMESTAMP()
      )
      """

      INSERT_IMPACT_ANALYSIS = """
      INSERT INTO faq_impact_analysis (
          change_id,
          diff_id,
          question_id,
          answer_id,
          overall_impact_score,
          lexical_overlap_score,
          keyword_match_score,
          semantic_similarity_score,
          phrase_match_score,
          is_affected,
          impact_level,
          confidence,
          impact_reason,
          matched_changes,
          analysis_method,
          analysis_version,
          analyzed_at
      ) VALUES (
          {change_id},
          {diff_id},
          {question_id},
          {answer_id},
          {overall_impact_score},
          {lexical_overlap_score},
          {keyword_match_score},
          {semantic_similarity_score},
          {phrase_match_score},
          {is_affected},
          '{impact_level}',
          {confidence},
          '{impact_reason}',
          '{matched_changes_json}',
          '{analysis_method}',
          '{analysis_version}',
          CURRENT_TIMESTAMP()
      )
      """

      UPDATE_FAQ_SOURCE_INVALIDATE = """
      UPDATE faq_question_sources
      SET is_valid = FALSE,
          valid_until = CURRENT_TIMESTAMP(),
          invalidation_reason = 'selective_impact',
          invalidated_by_change_id = {change_id}
      WHERE question_id = {question_id}
        AND is_valid = TRUE
      """

      UPDATE_ANSWER_SOURCE_INVALIDATE = """
      UPDATE faq_answer_sources
      SET is_valid = FALSE,
          valid_until = CURRENT_TIMESTAMP(),
          invalidation_reason = 'selective_impact',
          invalidated_by_change_id = {change_id}
      WHERE answer_id = {answer_id}
        AND is_valid = TRUE
      """

      GET_AFFECTED_FAQS_FOR_INVALIDATION = """
      SELECT question_id, answer_id
      FROM faq_impact_analysis
      WHERE change_id = {change_id}
        AND is_affected = TRUE
      """

      INSERT_AUDIT_LOG = """
      INSERT INTO faq_audit_log (
          table_name,
          record_id,
          content_checksum,
          action,
          old_values,
          new_values,
          detection_run_id,
          change_reason,
          performed_by,
          performed_at
      ) VALUES (
          '{table_name}',
          {record_id},
          '{content_checksum}',
          '{action}',
          '{old_values_json}',
          '{new_values_json}',
          '{detection_run_id}',
          '{change_reason}',
          '{performed_by}',
          CURRENT_TIMESTAMP()
      )
      """
  ```

- [ ] **Implement transaction management**
  ```python
  # database/transactions.py
  from typing import Callable, Any
  from .connection import DatabricksConnection

  class TransactionManager:
      """Manage database transactions with rollback support"""

      def __init__(self, connection: DatabricksConnection):
          self.connection = connection

      def execute_in_transaction(self, func: Callable[[], Any]) -> Any:
          """
          Execute function in transaction.
          Note: Delta Lake has limited transaction support.
          Use optimistic concurrency control instead.
          """
          try:
              result = func()
              # Delta Lake auto-commits, no explicit commit needed
              return result
          except Exception as e:
              # Log error for investigation
              print(f"Transaction failed: {e}")
              # Delta Lake doesn't support rollback in traditional sense
              # Changes are atomic at table level
              raise
  ```

---

## PHASE 6: WORKFLOW ORCHESTRATION (Week 2, Days 4-5)

### 6.1 Main Orchestration

- [ ] **Implement main workflow orchestrator**
  ```python
  # workflow/orchestrator.py
  from typing import List, Dict
  import json
  from datetime import datetime
  from ..config import GranularImpactConfig
  from ..database.connection import DatabricksConnection
  from ..database.queries import SQLQueries
  from ..database.models import ContentChange, FAQ, ContentDiff, ImpactResult
  from ..detection.change_detector import ChangeDetector
  from ..diff.diff_engine import DiffEngine
  from ..impact.impact_analyzer import ImpactAnalyzer
  from ..workflow.invalidator import SelectiveInvalidator

  class GranularImpactOrchestrator:
      """Main workflow orchestrator for granular FAQ impact detection"""

      def __init__(self, config: GranularImpactConfig):
          self.config = config
          self.db = DatabricksConnection(
              config.database.catalog,
              config.database.schema
          )
          self.change_detector = ChangeDetector(config.similarity)
          self.diff_engine = DiffEngine()
          self.impact_analyzer = ImpactAnalyzer(config.impact)
          self.invalidator = SelectiveInvalidator(self.db, config)

      def run_detection(
          self,
          file_name: str,
          detection_run_id: str
      ) -> Dict[str, Any]:
          """
          Run complete granular impact detection workflow.

          Phases:
          1. Detect content changes
          2. Compute diffs for each change
          3. Analyze FAQ impact
          4. Selective invalidation

          Returns summary statistics.
          """
          print(f"Starting granular detection for {file_name}...")
          print(f"Detection run ID: {detection_run_id}")

          # Phase 1: Detect content changes
          changes = self.change_detector.detect_changes(
              file_name,
              detection_run_id
          )
          print(f"Found {len(changes)} changes")

          total_faqs_saved = 0
          total_faqs_at_risk = 0
          total_affected = 0

          for change in changes:
              if change.change_type != 'modified_content':
                  continue  # Only analyze modifications

              # Phase 2: Compute diff
              diff_data = self.diff_engine.compute_diff(
                  change.old_text,
                  change.new_text
              )

              # Store change in database
              change_id = self._store_change_log(change, diff_data, detection_run_id)
              diff_id = self._store_content_diff(change_id, diff_data)

              print(f"  Change {change_id}: {diff_data.change_percentage:.1f}% of content changed")
              print(f"    Changed phrases: {diff_data.changed_phrases[:5]}...")

              # Get FAQs linked to old checksum (FIXED QUERY!)
              faqs = self._get_impacted_faqs(change.old_checksum)

              if not faqs:
                  print(f"    No FAQs linked to old checksum")
                  continue

              print(f"    FAQs at risk: {len(faqs)}")

              # Phase 3: Analyze FAQ impact
              impact_results = self.impact_analyzer.analyze_faqs(faqs, diff_data)

              # Phase 4: Store impact analysis
              self._store_impact_analysis(change_id, diff_id, impact_results)

              # Phase 5: Selective invalidation
              affected_count = self.invalidator.invalidate_affected_faqs(
                  change_id,
                  detection_run_id
              )

              saved_count = len(faqs) - affected_count

              print(f"    FAQs actually affected: {affected_count}")
              print(f"    FAQs SAVED: {saved_count} ✅")

              total_faqs_at_risk += len(faqs)
              total_affected += affected_count
              total_faqs_saved += saved_count

          print(f"\n✅ Detection complete!")
          print(f"Total FAQs at risk: {total_faqs_at_risk}")
          print(f"Total FAQs affected: {total_affected}")
          print(f"Total FAQs saved from unnecessary regeneration: {total_faqs_saved}")

          if total_faqs_at_risk > 0:
              savings_pct = (total_faqs_saved / total_faqs_at_risk) * 100
              print(f"Savings: {savings_pct:.1f}%")

          return {
              'detection_run_id': detection_run_id,
              'file_name': file_name,
              'changes_detected': len(changes),
              'total_faqs_at_risk': total_faqs_at_risk,
              'total_faqs_affected': total_affected,
              'total_faqs_saved': total_faqs_saved,
              'savings_percentage': (total_faqs_saved / total_faqs_at_risk * 100) if total_faqs_at_risk > 0 else 0
          }

      def _get_impacted_faqs(self, old_checksum: str) -> List[FAQ]:
          """Get FAQs linked to old checksum using FIXED query"""
          query = SQLQueries.GET_IMPACTED_FAQS.format(old_checksum=old_checksum)
          df = self.db.execute(query)

          faqs = []
          for row in df.collect():
              faqs.append(FAQ(
                  question_id=row.question_id,
                  question_text=row.question_text,
                  answer_id=row.answer_id,
                  answer_text=row.answer_text,
                  impact_type=row.impact_type,
                  impacted_sources=row.impacted_sources,
                  impacted_checksums=row.impacted_checksums
              ))

          return faqs

      def _store_change_log(
          self,
          change: ContentChange,
          diff_data: ContentDiff,
          detection_run_id: str
      ) -> int:
          """Store change in content_change_log"""
          query = SQLQueries.INSERT_CHANGE_LOG.format(
              new_checksum=change.new_checksum,
              old_checksum=change.old_checksum or 'NULL',
              file_name=change.page_number or 'NULL',  # Placeholder
              page_number=change.page_number or 'NULL',
              section_name='NULL',
              requires_faq_regen='TRUE',
              change_type=change.change_type,
              similarity_score=change.similarity_score,
              similarity_method=change.similarity_method or 'NULL',
              total_faqs_at_risk=0,  # Updated later
              detection_run_id=detection_run_id,
              domain='NULL',
              service='NULL'
          )

          self.db.execute(query)

          # Get last inserted ID (Spark SQL approach)
          result = self.db.execute(
              "SELECT MAX(change_id) as change_id FROM content_change_log"
          ).collect()[0]

          return result.change_id

      def _store_content_diff(self, change_id: int, diff_data: ContentDiff) -> int:
          """Store diff in content_diffs"""
          query = SQLQueries.INSERT_CONTENT_DIFF.format(
              change_id=change_id,
              old_checksum=diff_data.old_checksum,  # Need to add to ContentDiff model
              new_checksum=diff_data.new_checksum,  # Need to add
              additions_count=diff_data.additions_count,
              deletions_count=diff_data.deletions_count,
              modifications_count=0,  # Compute this
              total_changes=diff_data.additions_count + diff_data.deletions_count,
              change_percentage=diff_data.change_percentage,
              diff_data_json=json.dumps(diff_data.diff_data).replace("'", "''"),
              contains_numeric=diff_data.contains_numeric_changes,
              contains_date=diff_data.contains_date_changes,
              contains_policy=diff_data.contains_policy_changes,
              contains_eligibility=diff_data.contains_eligibility_changes,
              changed_phrases_json=json.dumps(diff_data.changed_phrases).replace("'", "''")
          )

          self.db.execute(query)

          # Get last inserted ID
          result = self.db.execute(
              "SELECT MAX(diff_id) as diff_id FROM content_diffs"
          ).collect()[0]

          return result.diff_id

      def _store_impact_analysis(
          self,
          change_id: int,
          diff_id: int,
          impact_results: List[ImpactResult]
      ):
          """Store impact analysis results"""
          for result in impact_results:
              query = SQLQueries.INSERT_IMPACT_ANALYSIS.format(
                  change_id=change_id,
                  diff_id=diff_id,
                  question_id=result.question_id,
                  answer_id=result.answer_id or 'NULL',
                  overall_impact_score=result.overall_impact_score,
                  lexical_overlap_score=result.lexical_overlap_score,
                  keyword_match_score=result.keyword_match_score,
                  semantic_similarity_score=result.semantic_similarity_score,
                  phrase_match_score=result.phrase_match_score,
                  is_affected=result.is_affected,
                  impact_level=result.impact_level,
                  confidence=0.8,  # TODO: Compute confidence
                  impact_reason=result.impact_reason.replace("'", "''"),
                  matched_changes_json=json.dumps(result.matched_changes).replace("'", "''"),
                  analysis_method='hybrid',
                  analysis_version='v1.0'
              )

              self.db.execute(query)
  ```

- [ ] **Implement selective invalidator**
  ```python
  # workflow/invalidator.py
  from typing import List
  from ..database.connection import DatabricksConnection
  from ..database.queries import SQLQueries
  from ..config import GranularImpactConfig

  class SelectiveInvalidator:
      """Selective FAQ invalidation based on impact analysis"""

      def __init__(self, db: DatabricksConnection, config: GranularImpactConfig):
          self.db = db
          self.config = config

      def invalidate_affected_faqs(
          self,
          change_id: int,
          detection_run_id: str
      ) -> int:
          """
          Invalidate ONLY the FAQs that are affected by this change.
          Returns count of affected FAQs.
          """
          # Get affected FAQs from impact analysis
          query = SQLQueries.GET_AFFECTED_FAQS_FOR_INVALIDATION.format(
              change_id=change_id
          )
          affected_faqs = self.db.execute(query).collect()

          if not affected_faqs:
              return 0

          # Invalidate question and answer sources
          for faq in affected_faqs:
              # Invalidate question sources
              query_q = SQLQueries.UPDATE_FAQ_SOURCE_INVALIDATE.format(
                  change_id=change_id,
                  question_id=faq.question_id
              )
              self.db.execute(query_q)

              # Invalidate answer sources (if answer exists)
              if faq.answer_id:
                  query_a = SQLQueries.UPDATE_ANSWER_SOURCE_INVALIDATE.format(
                      change_id=change_id,
                      answer_id=faq.answer_id
                  )
                  self.db.execute(query_a)

          # Audit log
          if self.config.enable_audit_logging:
              audit_query = SQLQueries.INSERT_AUDIT_LOG.format(
                  table_name='faq_answer_sources',
                  record_id='NULL',
                  content_checksum='',
                  action='SELECTIVE_INVALIDATE',
                  old_values_json='{}',
                  new_values_json='{}',
                  detection_run_id=detection_run_id,
                  change_reason=f'Selective invalidation: {len(affected_faqs)} FAQs affected by change_id {change_id}',
                  performed_by='system'
              )
              self.db.execute(audit_query)

          return len(affected_faqs)
  ```

---

## PHASE 7: TESTING & VALIDATION (Week 3)

### 7.1 Test Data Generation

- [ ] **Create comprehensive test data generator**
  - Generate realistic FAQ content with known relationships
  - Create content changes with varying similarity scores
  - Generate edge cases (no answer, multiple sources, etc.)

- [ ] **Populate test database with fixtures**
  - Insert test content_checksums
  - Insert test faq_questions and faq_answers
  - Insert test source relationships
  - Document expected behavior for each test case

### 7.2 Unit Tests

- [ ] **Write unit tests for similarity algorithms**
  - Test Jaccard with known inputs/outputs
  - Test Difflib with numeric changes ("10" → "12")
  - Test TF-IDF with policy text
  - Test hybrid combiner with weights
  - Validate early exit behavior

- [ ] **Write unit tests for diff computation**
  - Test phrase extraction
  - Test semantic change detection (numeric, dates, policy)
  - Test edge cases (empty text, identical text)

- [ ] **Write unit tests for impact scoring**
  - Test lexical overlap calculation
  - Test keyword matching
  - Test phrase matching
  - Test critical overlap detection

- [ ] **Write unit tests for impact decision logic**
  - Test threshold-based decisions
  - Test critical change overrides
  - Validate impact_level assignment

### 7.3 Integration Tests

- [ ] **Write integration tests for database operations**
  - Test FIXED FAQ retrieval query with all edge cases
  - Test change log insertion
  - Test diff storage with JSON serialization
  - Test impact analysis storage
  - Test selective invalidation

- [ ] **Write end-to-end workflow tests**
  - Test complete workflow with known data
  - Validate savings calculation
  - Test rollback on errors
  - Test audit logging

### 7.4 Validation Suite

- [ ] **Create validation scenarios**
  - Scenario 1: "10 days" → "12 days" (should affect Q1 only)
  - Scenario 2: Major rewrite (should affect all FAQs)
  - Scenario 3: Typo fix (should affect none)
  - Scenario 4: Policy keyword change (high impact)

- [ ] **Run validation and compare to expected results**
  - Document actual vs expected for each scenario
  - Tune thresholds based on validation results
  - Create confusion matrix (precision/recall)

---

## PHASE 8: DEPLOYMENT & MONITORING (Week 3-4)

### 8.1 Production Deployment

- [ ] **Create Databricks notebooks for production**
  - Notebook 1: Schema setup and migration
  - Notebook 2: Run detection workflow
  - Notebook 3: Analyze results and generate reports
  - Notebook 4: Manual review and tuning

- [ ] **Set up scheduling**
  - Configure Databricks jobs for periodic detection
  - Set up alerts for failures
  - Configure retry logic

### 8.2 Monitoring & Metrics

- [ ] **Implement performance monitoring**
  - Track execution time per phase
  - Track similarity computation time (N×M)
  - Track database query performance
  - Log memory usage for large files

- [ ] **Implement business metrics**
  - Track savings percentage over time
  - Track false positive rate (FAQs incorrectly affected)
  - Track false negative rate (FAQs missed)
  - Track SME review time reduction

### 8.3 Documentation

- [ ] **Create operations documentation**
  - How to run detection workflow
  - How to interpret results
  - How to tune thresholds
  - How to handle edge cases
  - Troubleshooting guide

- [ ] **Create algorithm tuning guide**
  - How to adjust similarity thresholds
  - How to adjust impact thresholds
  - How to add new semantic detectors
  - How to validate changes

---

## CRITICAL PATH & DEPENDENCIES

```
Schema Deployment (1.1 → 1.2)
    ↓
Bug Fixes (2.1) ← CRITICAL!
    ↓
Python Module Structure (3.1, 3.2)
    ↓
Core Algorithm Implementation (4.1, 4.2, 4.3) ← Can parallelize 4.1, 4.2, 4.3
    ↓
Database Access Layer (5.1)
    ↓
Workflow Orchestration (6.1)
    ↓
Testing (7.1, 7.2, 7.3, 7.4) ← Iterate based on results
    ↓
Deployment & Monitoring (8.1, 8.2, 8.3)
```

---

## RISK MITIGATION

### High-Risk Areas

1. **SQL Query Bugs (Phase 2.1)** - MUST fix before production
   - Risk: Incorrect results, data corruption
   - Mitigation: Extensive testing with edge cases

2. **Similarity Threshold Tuning (Phase 4.1)** - Affects accuracy
   - Risk: Too strict → miss modifications; Too loose → false positives
   - Mitigation: Validation with historical data

3. **Performance at Scale (Phase 8.2)** - N×M comparisons
   - Risk: Timeouts, OOM errors for large files
   - Mitigation: Batch processing, early exit, max_comparisons limit

4. **Database Transaction Management (Phase 5.1)** - Delta Lake limitations
   - Risk: Partial writes on failure
   - Mitigation: Idempotent operations, change_id tracking

---

## SUCCESS CRITERIA

- [ ] Schema deployed successfully to Databricks
- [ ] All SQL query bugs fixed and validated
- [ ] All unit tests passing (>90% coverage)
- [ ] All integration tests passing
- [ ] Validation scenarios match expected results (>95% accuracy)
- [ ] Production workflow runs successfully on real data
- [ ] Savings >50% compared to V7 (blanket invalidation)
- [ ] False positive rate <5%
- [ ] False negative rate <2%
- [ ] Performance <5 seconds per change for typical file
- [ ] Documentation complete and reviewed

---

## ESTIMATED EFFORT

**Total:** 15-20 days (senior developer, full-time)

- Phase 1 (Schema): 2 days
- Phase 2 (Bug Fixes): 2 days ← CRITICAL
- Phase 3 (Module Structure): 1 day
- Phase 4 (Core Algorithm): 4 days
- Phase 5 (Database Layer): 2 days
- Phase 6 (Orchestration): 2 days
- Phase 7 (Testing): 4 days
- Phase 8 (Deployment): 3 days

**Buffer:** +5 days for iterations, tuning, unexpected issues

---

## NEXT STEPS

1. **IMMEDIATE:** Review this implementation plan
2. **CRITICAL:** Validate SQL query bug fixes (Phase 2.1)
3. **PRIORITY 1:** Deploy schema to test environment (Phase 1.2)
4. **PRIORITY 2:** Implement similarity module (Phase 4.1)
5. **PRIORITY 3:** Create test data generator (Phase 7.1)

---

## NOTES

- This is a PRODUCTION-CRITICAL system - thorough testing is essential
- The SQL query bugs are SEVERE - fix before any production use
- Similarity threshold tuning will require iteration with real data
- Consider enabling embeddings (optional) for maximum accuracy
- Plan for ongoing monitoring and threshold adjustments
- Document all assumptions and edge case handling

---

**END OF IMPLEMENTATION PLAN**