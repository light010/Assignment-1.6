# Content Change Log Schema - Senior Data Architect Analysis

**Date**: 2025-10-20
**Analyst**: Senior Data Architecture Review
**Scope**: content_change_log table deep analysis for temporal, semantic, and architectural issues
**Priority**: 🟡 **HIGH** - Multiple design issues that limit functionality and cause confusion

---

## 📋 Executive Summary

### Current State: **MIXED**
The `content_change_log` table has a **fundamentally confused identity**. It's named as a "change log" but functions as a "detection results log." This semantic confusion leads to:

1. **Temporal gaps** - Cannot reconstruct change timeline
2. **History loss** - No previous state tracking
3. **Baseline confusion** - No clear distinction between baseline and changes
4. **Idempotency issues** - Constraint prevents legitimate re-detections
5. **Mixed semantics** - Stores both "changes" and "no changes" (detection results)

### What It Should Be
Two distinct tables with clear responsibilities:
- `content_baseline` - **State table** (current/historical checksums)
- `content_change_log` - **Event table** (actual change events only)

OR

Single unified table with:
- Clear temporal model (previous → current state transitions)
- Change sequencing
- Baseline identification
- True change-only storage (not detection results)

### Impact: 🟡 **MEDIUM-HIGH**
- Analytics are limited (cannot track change frequency, patterns)
- Debugging is hard (cannot reconstruct "what happened when")
- Business questions unanswerable ("how often does policy X change?")
- Confusion for developers ("why are unchanged pages in change_log?")

---

## 🔍 Deep Analysis: 10 Critical Issues

### Issue #1: **Semantic Confusion - Detection vs Change**

#### Current Reality
**Table Name**: `content_change_log`
**Actual Contents**: Detection results (both changes AND non-changes)

**Code Evidence**:
```python
# From detection logic
for page in all_pages_detected:
    content_change_log.insert({
        'content_id': page.content_id,
        'content_checksum': page.checksum,
        'requires_faq_regeneration': 0 if page.checksum in baseline else 1,
        # ... even if requires_faq_regeneration = 0 (NO CHANGE)
    })
```

**Problem**: Table stores **100% of detected content**, not just changes.

**Example Data**:
```
change_id | content_id | checksum  | requires_faq_regeneration
----------|------------|-----------|------------------------
1         | 1001       | abc123... | 0  ← NO CHANGE (why in change log?)
2         | 1002       | def456... | 1  ← CHANGE (belongs here)
3         | 1003       | ghi789... | 0  ← NO CHANGE (why in change log?)
```

**Consequences**:
- **Confusion**: "Why are non-changes in a change log?"
- **Storage waste**: 90% of records might be "no change" detections
- **Query complexity**: Must always filter `WHERE requires_faq_regeneration = 1` to get actual changes
- **Business misalignment**: Business asks "how many changes?" - table has detections, not changes

**Better Names** (if keeping current behavior):
- `content_detection_log` (what it actually is)
- `content_scan_results` (more accurate)
- `faq_regeneration_queue` (purpose-driven)

**OR Change Behavior**: Only insert when `requires_faq_regeneration = 1` (actual changes only)

---

### Issue #2: **No Change History / Temporal Continuity**

#### Missing: Previous State Tracking

**Current Schema**:
```sql
CREATE TABLE content_change_log (
    content_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,  -- Current checksum
    -- ❌ MISSING: previous_checksum
    -- ❌ MISSING: change_sequence
    -- ❌ MISSING: change_detected_date vs change_occurred_date
    ...
);
```

**Cannot Answer**:
```sql
-- Question: "What was the content before this change?"
-- Current: IMPOSSIBLE - no previous_checksum field

-- Question: "How many times has this content changed?"
-- Current: Requires complex query with ROW_NUMBER, unreliable

-- Question: "Show me the change timeline for this page"
-- Current: detection_run_id gives runs, not actual change sequence
```

**Real-World Scenario**:
```
Timeline:
  2025-01-01: Page created, checksum = A
  2025-02-01: Page edited,  checksum = B
  2025-03-01: Page edited,  checksum = C
  2025-04-01: Detection runs (discovers checksum = C)

Current table after detection:
  change_id: 123
  content_checksum: C
  source_modified_at: 2025-03-01
  detected_at: 2025-04-01

Questions:
  - What was checksum B? (LOST)
  - What was checksum A? (LOST)
  - When did A→B happen? (UNKNOWN)
  - When did B→C happen? (ONLY know final modified_at)

  Missing Information: Entire change history except last change!
```

**Business Impact**:
- Cannot track "how frequently does content change?"
- Cannot detect "content churning" (frequent changes)
- Cannot reconstruct "audit trail" for compliance
- Cannot answer "what triggered this FAQ update?"

---

### Issue #3: **Baseline Management is Implicit**

#### No Explicit Baseline Identification

**Current Design** (implied from code):
```python
# Baseline is "all checksums in content_change_log"
baseline_checksums = set(
    row['content_checksum']
    for row in db.query('SELECT content_checksum FROM content_change_log')
)

# New content if checksum NOT in baseline
is_new_content = current_checksum not in baseline_checksums
```

**Problems**:

**Problem 3.1: No Baseline Snapshot**
```
Scenario: First detection run on 2025-01-01

Result:
  - All pages inserted with requires_faq_regeneration = 1 (NEW!)
  - But they're not "changes" - they're the BASELINE
  - Cannot distinguish "initial state" from "actual changes"

Business Question: "How many pages changed this month?"
Answer: Includes initial baseline (WRONG!)
```

**Problem 3.2: Baseline Drift**
```
Scenario: Database is deleted/recreated

Result:
  - All baseline checksums LOST
  - Next detection treats ALL content as "new"
  - Thousands of FAQs incorrectly marked for regeneration

No way to export/import baseline independently
No baseline versioning
```

**Problem 3.3: Multi-Environment Baseline**
```
Environments: DEV, FIT, PROD

Question: Should they share baseline?
  - Option A: Shared baseline (DIT changes don't trigger PROD regen)
  - Option B: Separate baselines (each env independent)

Current Schema: Cannot support either cleanly
  - No baseline_environment field
  - No baseline versioning
  - No baseline import/export mechanism
```

**Better Design**:
```sql
CREATE TABLE content_baseline (
    baseline_id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,
    baseline_version TEXT NOT NULL,  -- "v1.0", "2025-01-01", etc.
    environment TEXT,  -- "PROD", "DIT", "ALL"
    established_at TEXT NOT NULL,
    established_by TEXT,  -- "initial_load", "detection_run_123", "manual_import"
    is_active BOOLEAN NOT NULL DEFAULT 1,

    UNIQUE(content_id, baseline_version, environment)
);
```

---

### Issue #4: **Idempotency Constraint Limits Functionality**

#### Constraint: `UNIQUE(content_id, detection_run_id)`

**Intent**: Prevent duplicate detections in same run

**Problems**:

**Problem 4.1: Cannot Reprocess**
```
Scenario: Detection run fails halfway

Desired behavior:
  - Delete partial results
  - Re-run detection with SAME run_id (for consistency)

Current Schema:
  ❌ UNIQUE constraint violation
  ❌ Must use NEW run_id (creates confusion)
  ❌ Orphaned records from failed run remain
```

**Problem 4.2: Cannot Handle Mid-Run Changes**
```
Scenario: Long-running detection (10,000 pages, takes 2 hours)

Reality:
  - Some content changes DURING the detection run
  - Page X: Detected at 10:00 AM (checksum = A)
  - Page X: Modified at 10:30 AM (checksum = B)
  - Page X: Re-detected at 11:00 AM (checksum = B)

Current Schema:
  ❌ Cannot insert second detection (same content_id + run_id)
  ❌ First detection (checksum A) remains (STALE)
  ❌ Actual current state (checksum B) not recorded
```

**Problem 4.3: Cannot Re-Validate**
```
Scenario: Want to re-check specific page without full run

Desired:
  INSERT INTO content_change_log (content_id, detection_run_id, ...)
  VALUES (1001, 'current_run', ...)

Current:
  ❌ Error if page 1001 already processed in 'current_run'
  ❌ Must create new run_id just for one page (messy)
```

**Better Constraint**:
```sql
-- Option A: Add timestamp to uniqueness
UNIQUE(content_id, detection_run_id, detected_at)

-- Option B: Use composite key with sequence
UNIQUE(content_id, detection_run_id, detection_sequence)

-- Option C: Remove constraint, use (change_id PK) only
-- Let application handle duplicates if needed
```

---

### Issue #5: **Temporal Model Confusion**

#### Three Different Time Concepts

**Current Fields**:
```sql
detected_at TEXT NOT NULL,        -- When detection algorithm ran
source_modified_at TEXT NOT NULL, -- When content file was last modified
-- ❌ MISSING: change_occurred_at (when checksum actually changed)
```

**Confusion Matrix**:

| Timestamp | Meaning | Use Case | Reliable? |
|-----------|---------|----------|-----------|
| `detected_at` | When we discovered the state | Batch tracking | ✅ Yes |
| `source_modified_at` | File system timestamp | Audit trail | ⚠️ Maybe (file copy changes this) |
| `change_occurred_at` | When checksum changed | Change timeline | ❌ MISSING |

**Real-World Problem**:
```
Timeline:
  2025-01-15 09:00: Content modified (checksum A → B)
  2025-01-15 09:30: Content modified (checksum B → C)
  2025-01-15 10:00: File copied to new location
  2025-01-16 14:00: Detection runs

File system shows:
  last_modified_dt: 2025-01-15 10:00 (file copy time, NOT edit time)

Detection inserts:
  content_checksum: C
  source_modified_at: 2025-01-15 10:00 (WRONG - not when C was created)
  detected_at: 2025-01-16 14:00

Lost Information:
  - When did A→B happen? (2025-01-15 09:00) ← LOST
  - When did B→C happen? (2025-01-15 09:30) ← LOST
  - Why does timestamp = file copy time? (MISLEADING)
```

**Business Impact**:
```sql
-- Query: "Show content changes from last week"
SELECT * FROM content_change_log
WHERE source_modified_at >= date('now', '-7 days')

-- Problem: source_modified_at might be file copy time, not change time
-- Result: INACCURATE change timeline
```

**Better Model**:
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Clear temporal fields
    change_occurred_at TEXT NOT NULL,    -- Best estimate of actual change time
    change_detected_at TEXT NOT NULL,    -- When we discovered it
    change_confirmed_at TEXT,            -- When confirmed by analyst (if manual review)

    -- Source timestamps (for reference, not primary)
    source_file_modified_at TEXT,        -- File system timestamp
    source_last_edit_timestamp TEXT,     -- From version control if available

    -- Temporal metadata
    detection_lag_seconds INTEGER AS (
        (julianday(change_detected_at) - julianday(change_occurred_at)) * 86400
    ) STORED,  -- How long until we detected the change

    ...
);
```

---

### Issue #6: **No Change Classification**

#### Binary Decision is Too Simple

**Current Model**:
```sql
requires_faq_regeneration BOOLEAN  -- 0 or 1
```

**Problems**:

**Problem 6.1: Lost Change Context**
```
All changes are treated equally:
  - Typo fix (1 character changed) → requires_faq_regeneration = 1
  - Complete rewrite (100% different) → requires_faq_regeneration = 1
  - Section added (30% new content) → requires_faq_regeneration = 1
  - Content deleted entirely → requires_faq_regeneration = 1

Business needs:
  - Prioritize major rewrites over typos
  - Handle deletions differently from edits
  - Track "significance" of changes
```

**Problem 6.2: Cannot Implement Smart Regeneration**
```
Desired Logic:
  IF change_type == 'minor_edit' AND similarity > 0.95:
      existing_faq_might_still_be_valid()
  ELIF change_type == 'deletion':
      invalidate_faq_but_dont_regenerate()
  ELIF change_type == 'major_rewrite':
      high_priority_regeneration()

Current Schema:
  ❌ All changes are binary (regenerate: yes/no)
  ❌ No change_type field
  ❌ No similarity_score field
  ❌ No change_magnitude field
```

**Problem 6.3: Analytics Limitations**
```sql
-- Desired Query: "How many MAJOR changes vs MINOR changes?"
-- Current: IMPOSSIBLE - all changes are just "requires_faq_regeneration = 1"

-- Desired Query: "Show me pages with frequent major rewrites"
-- Current: IMPOSSIBLE - no change classification

-- Desired Query: "What % of changes are typo fixes?"
-- Current: IMPOSSIBLE - no change magnitude tracking
```

**Better Design**:
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Binary decision (keep for backward compatibility)
    requires_faq_regeneration BOOLEAN NOT NULL,

    -- Change classification (NEW)
    change_type TEXT CHECK(change_type IN (
        'new_content',       -- Content never seen before
        'minor_edit',        -- < 10% changed
        'moderate_edit',     -- 10-50% changed
        'major_rewrite',     -- > 50% changed
        'deletion',          -- Content removed
        'move',              -- Same content, different location
        'metadata_only'      -- Title/tags changed, content same
    )),

    -- Change magnitude (NEW)
    similarity_score REAL CHECK(similarity_score BETWEEN 0 AND 1),
        -- 1.0 = identical, 0.0 = completely different
        -- NULL for new_content or deletion

    changed_char_count INTEGER,
    changed_word_count INTEGER,
    changed_line_count INTEGER,

    -- Priority (NEW)
    regeneration_priority INTEGER CHECK(regeneration_priority BETWEEN 1 AND 5),
        -- 5 = urgent (major rewrite), 1 = low (typo fix)

    ...
);
```

---

### Issue #7: **No Diff Storage (Regression from v3)**

#### v3 Schema Had `content_diffs` Table

**What v3 Had**:
```sql
CREATE TABLE content_diffs (
    diff_id INTEGER PRIMARY KEY,
    change_id INTEGER REFERENCES content_change_log(change_id),
    diff_text_compressed BLOB,  -- Actual diff stored
    diff_format TEXT,            -- 'unified', 'context', 'json'
    diff_stats JSON,             -- { "additions": 10, "deletions": 5, ... }
    ...
);
```

**v4 Removed This** with comment:
> "content_diffs relied on change_type classification which has been removed in the simplified checksum-centric architecture"

**Analysis**: **WRONG DECISION**

**Why Diffs Are Important**:

1. **Debugging**: "Why did FAQ X get regenerated?"
   - Without diff: "Content changed" (unhelpful)
   - With diff: "Added new section about remote work policy" (actionable)

2. **Human Review**: "Should we regenerate FAQ for this change?"
   - Without diff: Must manually compare checksums (impossible)
   - With diff: Review actual changes, make decision

3. **Change Analytics**: "What kind of changes happen most?"
   - Without diff: Unknown
   - With diff: Can analyze (e.g., "80% are metadata changes only")

4. **Audit Trail**: "What changed on this date?"
   - Without diff: Just checksums (meaningless hashes)
   - With diff: Actual content changes (readable)

5. **Rollback**: "Undo last change"
   - Without diff: Impossible
   - With diff: Can reconstruct previous state

**Counter-Argument** (from v4 design):
> "Diff storage requires change_type, which we removed"

**Rebuttal**:
- **FALSE**: Diffs can be computed from checksum comparison alone
- **Proof**: `git diff <commit1> <commit2>` doesn't need change classification

**Implementation**:
```python
# Compute diff WITHOUT change_type
def detect_change(content_id):
    current_checksum = get_current_checksum(content_id)
    previous_checksum = get_baseline_checksum(content_id)

    if current_checksum == previous_checksum:
        # No change
        return None

    # Get actual content
    current_content = load_markdown(content_id)
    previous_content = load_markdown_from_baseline(previous_checksum)

    # Compute diff (NO change_type needed!)
    diff = compute_diff(previous_content, current_content)

    return {
        'content_checksum': current_checksum,
        'previous_checksum': previous_checksum,
        'diff_text': diff,
        'diff_stats': compute_diff_stats(diff)
    }
```

**Recommendation**: **RESTORE content_diffs table** (modified design)

---

### Issue #8: **No Processing State Tracking**

#### Cannot Track "What Happened After Detection"

**Current Schema**:
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,
    requires_faq_regeneration BOOLEAN NOT NULL,
    -- ❌ MISSING: processed_at
    -- ❌ MISSING: processing_status
    -- ❌ MISSING: faq_generated_at
    -- ❌ MISSING: error_message
    ...
);
```

**Cannot Answer**:
```sql
-- Question: "Which detected changes have been processed?"
-- Current: No processed_at or status field

-- Question: "Which changes failed FAQ generation?"
-- Current: No error tracking

-- Question: "How long does FAQ generation take?"
-- Current: detected_at exists, but no completion timestamp
```

**Real-World Workflow**:
```
1. Detection runs (inserts into content_change_log)
   → requires_faq_regeneration = 1

2. FAQ generation pipeline picks up changes
   → WHERE requires_faq_regeneration = 1
   → Process each change

3. During processing:
   - Some succeed (FAQ generated)
   - Some fail (network error, LLM timeout, etc.)

4. How do we track which succeeded/failed?
   Current: NO MECHANISM
   Result: Might process same change twice, or miss failures
```

**Better Design**:
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Detection fields (existing)
    requires_faq_regeneration BOOLEAN NOT NULL,
    detected_at TEXT NOT NULL,

    -- Processing tracking (NEW)
    processing_status TEXT CHECK(processing_status IN (
        'pending',           -- Detected, not yet processed
        'processing',        -- Currently being processed
        'completed',         -- Successfully processed
        'failed',            -- Processing failed
        'skipped',           -- Manually skipped
        'requires_review'    -- Needs human review before processing
    )) DEFAULT 'pending',

    processing_started_at TEXT,
    processing_completed_at TEXT,
    processing_duration_seconds INTEGER AS (
        (julianday(processing_completed_at) - julianday(processing_started_at)) * 86400
    ) STORED,

    faq_regenerated_at TEXT,
    faqs_generated_count INTEGER DEFAULT 0,  -- How many FAQs created/updated

    -- Error tracking (NEW)
    error_message TEXT,
    error_code TEXT,
    retry_count INTEGER DEFAULT 0,
    last_retry_at TEXT,

    -- Audit (NEW)
    processed_by TEXT,  -- "faq_generation_pipeline_v2", "manual_admin_user"

    ...
);
```

**With this, can now query**:
```sql
-- Find pending changes
SELECT * FROM content_change_log
WHERE requires_faq_regeneration = 1
  AND processing_status = 'pending'
ORDER BY detected_at;

-- Find failed changes needing retry
SELECT * FROM content_change_log
WHERE processing_status = 'failed'
  AND retry_count < 3
ORDER BY detected_at;

-- Processing performance metrics
SELECT
    AVG(processing_duration_seconds) as avg_duration,
    MAX(processing_duration_seconds) as max_duration,
    SUM(CASE WHEN processing_status = 'failed' THEN 1 ELSE 0 END) as failure_count
FROM content_change_log
WHERE detected_at >= date('now', '-7 days');
```

---

### Issue #9: **Metadata JSON is Overloaded**

#### Everything Goes in `metadata` JSON

**Current Design**:
```sql
metadata JSON  -- Contains... everything?
```

**Example metadata** (from schema comments):
```json
{
  "page": 2,
  "title": "Employee Leave Policy - Sick Leave",
  "domain": "HR",
  "service": "Policy Management",
  "breadcrumb": "Policies > HR > Leave Management",
  "tags": "leave;sick;medical;absence",
  "version": 1,
  "orgoid": "ORG001",
  "associateoid": "ASSOC001"
}
```

**Problems**:

**Problem 9.1: No Schema Validation**
```
Risk: Inconsistent JSON structure
  - Some records have "page", others don't
  - Some have "title", others "title_nme"
  - No validation that required fields exist
  - Typos not detected ("servce" vs "service")

Result: Queries break or return unexpected NULLs
```

**Problem 9.2: Query Performance**
```sql
-- Query: Find all HR content
SELECT * FROM content_change_log
WHERE json_extract(metadata, '$.domain') = 'HR';

-- Problem: Full table scan (even with JSON index)
-- Reason: JSON extraction is function call, optimizer limited

-- Better: domain as top-level column
SELECT * FROM content_change_log
WHERE domain = 'HR';  -- Can use index efficiently
```

**Problem 9.3: Display vs Business Logic Confusion**
```
Schema comment says:
  "For debugging/display, NOT business logic"

But schema has no other place for:
  - domain (needed for filtering)
  - service (needed for analytics)
  - page (needed for queries)

Result: JSON used for business logic despite comment
```

**Problem 9.4: Denormalization Without Benefit**
```
Metadata duplicates content_repo fields:
  - metadata.domain = content_repo.domain
  - metadata.title = content_repo.title_nme
  - metadata.orgoid = content_repo.orgoid

Issues:
  - Data duplication (storage waste)
  - Sync problems (what if content_repo.domain updates?)
  - No FK relationship (cannot JOIN efficiently)
```

**Better Design** (Hybrid Approach):

**Option A: Pull out frequently-queried fields**
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,

    -- Core identity
    content_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,

    -- Frequently queried fields (TOP-LEVEL for performance)
    domain TEXT,              -- Pulled out of JSON
    service TEXT,             -- Pulled out of JSON
    page_number INTEGER,      -- Pulled out of JSON

    -- Rarely queried fields (JSON for flexibility)
    display_metadata JSON,    -- { "title", "breadcrumb", "tags", ... }

    -- Or just use FK
    -- (Preferred: JOIN to content_repo instead of duplicating)
    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
);
```

**Option B: No JSON, just FK**
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,
    content_id INTEGER NOT NULL,

    -- Get all metadata via JOIN
    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
);

-- Query with metadata
SELECT
    ccl.*,
    cr.domain,
    cr.service,
    cr.title_nme,
    cr.raw_file_page_nbr as page
FROM content_change_log ccl
JOIN content_repo cr ON ccl.content_id = cr.ud_source_file_id;
```

**Recommendation**: **Option B** (simpler, more correct)
- Metadata lives in `content_repo` (single source of truth)
- `content_change_log` references via FK
- No duplication, no sync issues
- Better query performance (indexed columns vs JSON extraction)

---

### Issue #10: **`existing_faq_count` is Snapshot, Not Dynamic**

#### Field Becomes Stale

**Current Design**:
```sql
existing_faq_count INTEGER DEFAULT 0  -- How many FAQs exist for this checksum
```

**Problem**: This is a **snapshot at detection time**

**Staleness Scenario**:
```
Day 1 (10:00 AM): Detection runs
  - Checksum ABC has 5 FAQs
  - Inserts: existing_faq_count = 5

Day 1 (2:00 PM): 3 new FAQs generated for checksum ABC
  - Now checksum ABC has 8 FAQs total
  - But content_change_log still shows existing_faq_count = 5 (STALE)

Day 2 (10:00 AM): Query "high-impact changes"
  SELECT * FROM content_change_log
  WHERE existing_faq_count > 10
  ORDER BY existing_faq_count DESC;

  - Checksum ABC (8 FAQs) not returned (thinks it only has 5)
  - Prioritization is WRONG
```

**Two Options**:

**Option A: Make it dynamic** (computed field)
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,
    content_checksum TEXT NOT NULL,

    -- Remove existing_faq_count from table
    -- Add as VIEW or computed query
);

-- Query instead
SELECT
    ccl.*,
    COUNT(fcm.map_id) as current_faq_count  -- Real-time count
FROM content_change_log ccl
LEFT JOIN faq_content_map fcm
    ON ccl.content_checksum = fcm.content_checksum
    AND fcm.is_valid = 1
GROUP BY ccl.change_id;
```

**Option B: Keep snapshot, add refresh mechanism**
```sql
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,

    -- Keep snapshot
    existing_faq_count INTEGER DEFAULT 0,
    faq_count_as_of TEXT,  -- When count was last updated

    -- Add refresh tracking
    faq_count_stale BOOLEAN AS (
        julianday('now') - julianday(faq_count_as_of) > 1.0
    ) STORED,  -- TRUE if count older than 1 day
);

-- Periodic refresh job
UPDATE content_change_log
SET existing_faq_count = (
    SELECT COUNT(*) FROM faq_content_map
    WHERE content_checksum = content_change_log.content_checksum
      AND is_valid = 1
),
faq_count_as_of = strftime('%Y-%m-%dT%H:%M:%SZ','now')
WHERE faq_count_stale = 1;
```

**Recommendation**: **Option A** (dynamic via JOIN)
- Always accurate
- No refresh jobs needed
- Simpler to understand
- "Existing FAQ count" is a property of checksum, not of change detection

---

## 🏗️ Proposed Redesign: Two-Table Architecture

### Core Philosophy

**Separate Concerns**:
1. **State Table**: What checksums exist (baseline + current)
2. **Event Table**: What changed, when, and why

### Architecture Option 1: State + Events (Recommended)

```
┌─────────────────────┐         ┌──────────────────────┐
│  content_baseline   │         │  content_change_log  │
│  (STATE)            │         │  (EVENTS)            │
├─────────────────────┤         ├──────────────────────┤
│ baseline_id PK      │         │ change_id PK         │
│ content_id FK       │    ┌───>│ content_id FK        │
│ content_checksum    │    │    │ previous_checksum FK │
│ first_seen_at       │    │    │ current_checksum FK  │
│ last_seen_at        │    │    │ change_occurred_at   │
│ is_current BOOLEAN  │    │    │ change_detected_at   │
│ baseline_version    │    │    │ change_type          │
│ environment         │    │    │ similarity_score     │
└─────────────────────┘    │    │ requires_faq_regen   │
                           │    │ processing_status    │
content_repo ──────────────┘    │ processed_at         │
                                │ ...                  │
                                └──────────────────────┘
```

---

### Schema: `content_baseline` (State Table)

```sql
-- ============================================================================
-- Table: content_baseline
-- ============================================================================
-- Purpose: Track all known checksums (baseline + current state)
-- Type: STATE TABLE (not event log)
-- Pattern: Slowly Changing Dimension (Type 2)
-- ============================================================================

CREATE TABLE content_baseline (
    baseline_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- IDENTITY
    -- ========================================================================
    content_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL CHECK(length(content_checksum) = 64),

    -- ========================================================================
    -- TEMPORAL TRACKING
    -- ========================================================================
    first_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        -- When this checksum first appeared for this content_id

    last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        -- When this checksum was last detected (updated on each detection)

    retired_at TEXT,
        -- When this checksum was replaced by different checksum
        -- NULL = still current

    is_current BOOLEAN NOT NULL DEFAULT 1 CHECK(is_current IN (0,1)),
        -- TRUE if this is the current checksum for content_id
        -- Only one row per content_id can have is_current = 1

    -- ========================================================================
    -- BASELINE MANAGEMENT
    -- ========================================================================
    baseline_version TEXT NOT NULL,
        -- "v1.0", "2025-01-01", "prod-baseline-2025-q1"
        -- Groups checksums into baseline snapshots

    environment TEXT,
        -- "ALL", "PROD", "DIT", "FIT"
        -- Which environment this baseline applies to

    established_by TEXT,
        -- "initial_load", "detection_run_abc123", "manual_import", "admin_user"
        -- How this baseline was created

    -- ========================================================================
    -- METADATA REFERENCE
    -- ========================================================================
    -- Get metadata via FK to content_repo (no duplication)

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    UNIQUE(content_id, content_checksum, baseline_version, environment),

    -- Only one current checksum per content_id per environment
    UNIQUE(content_id, environment) WHERE is_current = 1,

    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE
);

-- ============================================================================
-- Indexes for content_baseline
-- ============================================================================

-- Primary lookups
CREATE INDEX idx_baseline_content ON content_baseline(content_id, is_current);
CREATE INDEX idx_baseline_checksum ON content_baseline(content_checksum);
CREATE INDEX idx_baseline_current ON content_baseline(is_current, environment);

-- Baseline version queries
CREATE INDEX idx_baseline_version ON content_baseline(baseline_version, environment);

-- Temporal queries
CREATE INDEX idx_baseline_temporal ON content_baseline(
    first_seen_at,
    last_seen_at,
    retired_at
);
```

**Usage**:
```sql
-- Get current baseline
SELECT content_id, content_checksum
FROM content_baseline
WHERE is_current = 1
  AND environment = 'PROD';

-- Check if checksum is in baseline
SELECT EXISTS(
    SELECT 1 FROM content_baseline
    WHERE content_checksum = ?
      AND environment = 'PROD'
);

-- Get baseline history for content
SELECT
    content_checksum,
    first_seen_at,
    retired_at,
    COALESCE(
        (julianday(retired_at) - julianday(first_seen_at)),
        (julianday('now') - julianday(first_seen_at))
    ) * 86400 as duration_seconds
FROM content_baseline
WHERE content_id = 1001
ORDER BY first_seen_at;
```

---

### Schema: `content_change_log` (Event Table - Redesigned)

```sql
-- ============================================================================
-- Table: content_change_log
-- ============================================================================
-- Purpose: Log of actual content changes (events only, no non-changes)
-- Type: EVENT LOG (append-only, immutable)
-- Pattern: Event Sourcing
-- ============================================================================

CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- CHANGE IDENTITY
    -- ========================================================================
    content_id INTEGER NOT NULL,

    -- State transition: previous → current
    previous_checksum TEXT CHECK(length(previous_checksum) = 64 OR previous_checksum IS NULL),
        -- NULL for new content (no previous state)
    current_checksum TEXT NOT NULL CHECK(length(current_checksum) = 64),

    -- Change sequence (for timeline reconstruction)
    change_sequence INTEGER NOT NULL,
        -- 1, 2, 3, ... (per content_id)
        -- Auto-computed: MAX(change_sequence) + 1

    -- ========================================================================
    -- TEMPORAL TRACKING (Multi-Timestamp Model)
    -- ========================================================================
    change_occurred_at TEXT NOT NULL,
        -- Best estimate of when change actually happened
        -- Source: content_repo.last_modified_dt or detection_time

    change_detected_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        -- When detection algorithm discovered the change

    change_confirmed_at TEXT,
        -- When analyst/system confirmed change is real (not noise)
        -- NULL = auto-confirmed, set if manual review

    -- Detection lag (computed)
    detection_lag_seconds INTEGER AS (
        (julianday(change_detected_at) - julianday(change_occurred_at)) * 86400
    ) STORED,

    -- ========================================================================
    -- CHANGE CLASSIFICATION
    -- ========================================================================
    change_type TEXT NOT NULL CHECK(change_type IN (
        'new_content',       -- Content never seen before (previous_checksum IS NULL)
        'minor_edit',        -- Similarity > 0.90
        'moderate_edit',     -- Similarity 0.50-0.90
        'major_rewrite',     -- Similarity < 0.50
        'deletion',          -- Content removed (current_checksum = special marker?)
        'restoration',       -- Reverted to previous checksum
        'metadata_only'      -- Content checksum unchanged, metadata changed
    )),

    change_trigger TEXT CHECK(change_trigger IN (
        'scheduled_detection',
        'on_demand_scan',
        'manual_import',
        'api_webhook',
        'file_watch'
    )),

    -- ========================================================================
    -- CHANGE MAGNITUDE
    -- ========================================================================
    similarity_score REAL CHECK(similarity_score IS NULL OR similarity_score BETWEEN 0 AND 1),
        -- Cosine similarity between previous and current
        -- 1.0 = identical, 0.0 = completely different
        -- NULL for new_content

    edit_distance INTEGER,
        -- Levenshtein distance (character-level)

    changed_char_count INTEGER,
    changed_word_count INTEGER,
    changed_line_count INTEGER,

    change_percentage REAL AS (
        CASE
            WHEN previous_checksum IS NULL THEN 100.0
            ELSE (1.0 - COALESCE(similarity_score, 0.0)) * 100.0
        END
    ) STORED,

    -- ========================================================================
    -- FAQ REGENERATION DECISION
    -- ========================================================================
    requires_faq_regeneration BOOLEAN NOT NULL CHECK(requires_faq_regeneration IN (0,1)),

    regeneration_priority INTEGER CHECK(regeneration_priority BETWEEN 1 AND 5),
        -- 5 = urgent, 1 = low
        -- Auto-computed based on change_type + existing_faq_count

    regeneration_reason TEXT,
        -- "major_rewrite", "new_policy_section", "compliance_update"

    -- ========================================================================
    -- PROCESSING STATE
    -- ========================================================================
    processing_status TEXT NOT NULL DEFAULT 'pending' CHECK(processing_status IN (
        'pending',
        'processing',
        'completed',
        'failed',
        'skipped',
        'requires_review'
    )),

    processing_started_at TEXT,
    processing_completed_at TEXT,

    processing_duration_seconds INTEGER AS (
        (julianday(processing_completed_at) - julianday(processing_started_at)) * 86400
    ) STORED,

    faqs_generated_count INTEGER DEFAULT 0,
    faqs_invalidated_count INTEGER DEFAULT 0,

    -- ========================================================================
    -- ERROR TRACKING
    -- ========================================================================
    error_message TEXT,
    error_code TEXT,
    retry_count INTEGER DEFAULT 0,
    last_retry_at TEXT,
    max_retries INTEGER DEFAULT 3,

    -- ========================================================================
    -- DETECTION CONTEXT
    -- ========================================================================
    detection_run_id TEXT NOT NULL,
    detection_batch_id TEXT,  -- Sub-batch within run (for parallel processing)

    -- ========================================================================
    -- AUDIT
    -- ========================================================================
    detected_by TEXT,   -- "faq_detector_v2", "manual_scan"
    processed_by TEXT,  -- "faq_generator_v1", "admin_user"

    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    -- Ensure previous != current (actual change)
    CHECK(previous_checksum IS NULL OR previous_checksum != current_checksum),

    -- Sequence must be unique per content
    UNIQUE(content_id, change_sequence),

    -- New content must have sequence = 1
    CHECK(
        (previous_checksum IS NULL AND change_sequence = 1) OR
        (previous_checksum IS NOT NULL AND change_sequence > 1)
    ),

    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE,
    FOREIGN KEY (previous_checksum) REFERENCES content_baseline(content_checksum)
        ON DELETE SET NULL,
    FOREIGN KEY (current_checksum) REFERENCES content_baseline(content_checksum)
        ON DELETE CASCADE
);

-- ============================================================================
-- Indexes for content_change_log
-- ============================================================================

-- Timeline reconstruction
CREATE INDEX idx_ccl_timeline ON content_change_log(
    content_id,
    change_sequence
);

-- Checksum lookups (for invalidation)
CREATE INDEX idx_ccl_current_checksum ON content_change_log(current_checksum);
CREATE INDEX idx_ccl_previous_checksum ON content_change_log(previous_checksum);

-- Processing queue
CREATE INDEX idx_ccl_queue ON content_change_log(
    requires_faq_regeneration,
    processing_status,
    regeneration_priority DESC
) WHERE processing_status = 'pending';

-- Temporal queries
CREATE INDEX idx_ccl_occurred ON content_change_log(change_occurred_at);
CREATE INDEX idx_ccl_detected ON content_change_log(change_detected_at);

-- Change type analytics
CREATE INDEX idx_ccl_type ON content_change_log(
    change_type,
    change_occurred_at
);

-- Detection batch queries
CREATE INDEX idx_ccl_detection ON content_change_log(
    detection_run_id,
    detection_batch_id
);

-- Error tracking
CREATE INDEX idx_ccl_errors ON content_change_log(processing_status, error_code)
    WHERE processing_status = 'failed';
```

---

### Schema: `content_diffs` (Restored and Enhanced)

```sql
-- ============================================================================
-- Table: content_diffs
-- ============================================================================
-- Purpose: Store actual content differences for debugging and analysis
-- Type: SUPPORTING TABLE (optional, can be purged periodically)
-- ============================================================================

CREATE TABLE content_diffs (
    diff_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- RELATIONSHIP
    -- ========================================================================
    change_id INTEGER NOT NULL,

    -- ========================================================================
    -- DIFF CONTENT
    -- ========================================================================
    diff_format TEXT NOT NULL CHECK(diff_format IN (
        'unified',      -- Unified diff (git-style)
        'context',      -- Context diff
        'json_patch',   -- JSON patch format
        'word_diff',    -- Word-level diff
        'char_diff'     -- Character-level diff
    )),

    diff_text TEXT,              -- Human-readable diff
    diff_text_compressed BLOB,   -- Compressed diff (for storage efficiency)

    -- ========================================================================
    -- DIFF STATISTICS
    -- ========================================================================
    diff_stats JSON,
        -- {
        --   "additions": 150,
        --   "deletions": 30,
        --   "modifications": 20,
        --   "unchanged_lines": 500,
        --   "total_hunks": 5
        -- }

    lines_added INTEGER,
    lines_deleted INTEGER,
    lines_modified INTEGER,

    -- ========================================================================
    -- DIFF METADATA
    -- ========================================================================
    diff_algorithm TEXT,  -- "myers", "patience", "histogram"
    diff_generated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    diff_generator TEXT,  -- "difflib", "git", "custom"

    -- ========================================================================
    -- RETENTION
    -- ========================================================================
    expires_at TEXT,  -- Auto-delete diffs older than N days

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    FOREIGN KEY (change_id) REFERENCES content_change_log(change_id)
        ON DELETE CASCADE
);

-- ============================================================================
-- Indexes for content_diffs
-- ============================================================================

CREATE INDEX idx_diffs_change ON content_diffs(change_id);
CREATE INDEX idx_diffs_expires ON content_diffs(expires_at);
```

---

## 📊 Data Examples

### Example 1: New Content Detection

**Scenario**: First time seeing page

**content_baseline**:
```sql
INSERT INTO content_baseline VALUES (
    1,        -- baseline_id
    1001,     -- content_id
    'abc123...', -- content_checksum
    '2025-01-01T10:00:00Z',  -- first_seen_at
    '2025-01-01T10:00:00Z',  -- last_seen_at
    NULL,     -- retired_at (still current)
    1,        -- is_current
    'v1.0',   -- baseline_version
    'PROD',   -- environment
    'initial_load'  -- established_by
);
```

**content_change_log**:
```sql
INSERT INTO content_change_log VALUES (
    1,        -- change_id
    1001,     -- content_id
    NULL,     -- previous_checksum (NEW content)
    'abc123...', -- current_checksum
    1,        -- change_sequence
    '2025-01-01T09:55:00Z',  -- change_occurred_at (file timestamp)
    '2025-01-01T10:00:00Z',  -- change_detected_at
    NULL,     -- change_confirmed_at
    300,      -- detection_lag_seconds (5 minutes)
    'new_content',  -- change_type
    'scheduled_detection',  -- change_trigger
    NULL,     -- similarity_score (N/A for new)
    0, 0, 0,  -- changed counts (N/A for new)
    100.0,    -- change_percentage (100% new)
    1,        -- requires_faq_regeneration
    3,        -- regeneration_priority (medium)
    'new_content_detected',  -- regeneration_reason
    'pending', -- processing_status
    ...
);
```

**No diff** (nothing to compare to)

---

### Example 2: Minor Edit (Typo Fix)

**Scenario**: Changed "10 days" → "15 days"

**content_baseline** (update existing + add new):
```sql
-- Mark old checksum as retired
UPDATE content_baseline
SET retired_at = '2025-02-01T14:30:00Z',
    is_current = 0
WHERE content_id = 1001
  AND content_checksum = 'abc123...';

-- Add new checksum
INSERT INTO content_baseline VALUES (
    2,        -- baseline_id
    1001,     -- content_id
    'def456...', -- NEW content_checksum
    '2025-02-01T14:30:00Z',  -- first_seen_at
    '2025-02-01T14:30:00Z',  -- last_seen_at
    NULL,     -- retired_at (current)
    1,        -- is_current
    'v1.0',   -- baseline_version (same baseline, updated)
    'PROD',   -- environment
    'detection_run_20250201'  -- established_by
);
```

**content_change_log**:
```sql
INSERT INTO content_change_log VALUES (
    2,        -- change_id
    1001,     -- content_id
    'abc123...', -- previous_checksum
    'def456...', -- current_checksum
    2,        -- change_sequence (2nd change for this content)
    '2025-02-01T14:25:00Z',  -- change_occurred_at
    '2025-02-01T14:30:00Z',  -- change_detected_at
    NULL,
    300,      -- detection_lag_seconds
    'minor_edit',  -- change_type
    'scheduled_detection',
    0.97,     -- similarity_score (97% similar)
    15,       -- edit_distance (15 characters changed)
    2, 2, 1,  -- changed_char_count, word_count, line_count
    3.0,      -- change_percentage (3% changed)
    1,        -- requires_faq_regeneration (business rule: always regenerate)
    2,        -- regeneration_priority (low - minor edit)
    'policy_value_changed',  -- regeneration_reason
    'pending',
    ...
);
```

**content_diffs**:
```sql
INSERT INTO content_diffs VALUES (
    1,        -- diff_id
    2,        -- change_id
    'unified', -- diff_format
    '--- a/page.md
+++ b/page.md
@@ -5,7 +5,7 @@
 ## Sick Leave
-Employees get 10 days of paid sick leave per year
+Employees get 15 days of paid sick leave per year
',         -- diff_text
    <compressed_blob>,  -- diff_text_compressed
    '{"additions": 1, "deletions": 1, "modifications": 1, "unchanged_lines": 50}',  -- diff_stats
    1, 1, 1,  -- lines_added, deleted, modified
    'myers',  -- diff_algorithm
    '2025-02-01T14:30:05Z',  -- diff_generated_at
    'difflib',
    '2025-05-01T00:00:00Z'   -- expires_at (3 months retention)
);
```

---

### Example 3: Major Rewrite

**Scenario**: Entire policy section rewritten

**content_change_log**:
```sql
INSERT INTO content_change_log VALUES (
    3,
    1001,
    'def456...',
    'ghi789...',
    3,        -- change_sequence = 3
    '2025-03-15T10:00:00Z',
    '2025-03-15T10:15:00Z',
    NULL,
    900,      -- 15 minute lag
    'major_rewrite',  -- change_type
    'scheduled_detection',
    0.35,     -- similarity_score (only 35% similar)
    450,      -- edit_distance
    200, 80, 30,  -- massive changes
    65.0,     -- change_percentage (65% changed)
    1,        -- requires_faq_regeneration
    5,        -- regeneration_priority (HIGH - major rewrite)
    'policy_overhaul',
    'pending',
    ...
);
```

**Diff** would show extensive changes (200+ lines)

---

## 📋 COMPREHENSIVE TODO LIST

### 🔴 **PHASE 1: REQUIREMENTS & DECISION** (Week 1)

#### Task 1.1: Validate Business Requirements
**Priority**: 🔴 CRITICAL
**Owner**: Product Manager + Data Architect
**Duration**: 2-3 days

**Questions to Answer**:
1. **Change History**: Do we need to track historical checksums?
   - Use case: "Show me all versions of this policy"
   - Use case: "How often does this content change?"
   - Decision: Yes/No/Partial

2. **Diff Storage**: Do we need actual content diffs?
   - Use case: "What changed on this date?"
   - Use case: "Review changes before regenerating FAQ"
   - Decision: Yes/No/Summary-only

3. **Baseline Management**: Multi-environment or single baseline?
   - Use case: DIT vs PROD baselines
   - Use case: Baseline versioning and rollback
   - Decision: Shared/Separate/Hybrid

4. **Processing Tracking**: Track FAQ generation status in this table?
   - Alternative: Separate processing_log table
   - Decision: In-table/Separate/None

5. **Retention**: How long to keep change history?
   - All history forever?
   - Rolling window (e.g., 90 days)?
   - Tiered (recent=full, old=summary)?

**Output**:
- ✅ Requirements document with answers
- ✅ Use case prioritization
- ✅ Scope definition (MVP vs full redesign)

---

#### Task 1.2: Technical Feasibility Assessment
**Priority**: 🔴 CRITICAL
**Owner**: Tech Lead + Data Architect
**Duration**: 1-2 days

**Assess**:
1. **Data Volume**:
   - Current: How many detections/day?
   - Projected: How many changes/day?
   - Storage: Can SQLite handle volume? (or need PostgreSQL?)

2. **Performance**:
   - Diff computation cost (CPU/time)
   - Compression overhead (CPU/storage tradeoff)
   - Query performance with 2-table model

3. **Backward Compatibility**:
   - Existing queries that break
   - Applications reading content_change_log
   - API contracts

4. **Migration Complexity**:
   - Convert existing detections → baseline + changes?
   - Or start fresh (acceptable for dev)?

**Output**:
- ✅ Feasibility report
- ✅ Risk assessment
- ✅ Performance benchmarks (if needed)
- ✅ Go/No-go recommendation

---

#### Task 1.3: Design Review Meeting
**Priority**: 🔴 CRITICAL
**Owner**: All stakeholders
**Duration**: 4 hours

**Agenda**:
1. Present this analysis document (2 hours)
2. Review business requirements (Task 1.1 results)
3. Review technical feasibility (Task 1.2 results)
4. Discuss design options:
   - **Option A**: Two-table (baseline + changes) - Recommended
   - **Option B**: Enhanced single table
   - **Option C**: Keep current, add missing fields only
5. Vote and decide
6. Define MVP scope

**Output**:
- ✅ Design decision (Option A/B/C)
- ✅ Approved schema
- ✅ MVP feature list
- ✅ Timeline estimate

---

### 🟡 **PHASE 2: SCHEMA DESIGN** (Week 2)

#### Task 2.1: Design `content_baseline` Table
**Priority**: 🟡 HIGH
**Owner**: Data Architect
**Duration**: 1 day

**If Option A selected**:
1. Finalize `content_baseline` schema
2. Define indexes
3. Design baseline versioning strategy
4. Write baseline management queries
5. Document baseline lifecycle

**Deliverables**:
- ✅ `content_baseline` CREATE TABLE statement
- ✅ Index definitions
- ✅ Baseline management procedures (SQL)
- ✅ Documentation

---

#### Task 2.2: Redesign `content_change_log` Table
**Priority**: 🟡 HIGH
**Owner**: Data Architect
**Duration**: 1 day

**Actions**:
1. Add missing fields (per Issue #1-10)
2. Add change classification fields
3. Add processing state fields
4. Add error tracking fields
5. Remove/deprecate obsolete fields
6. Define constraints and checks

**Deliverables**:
- ✅ Updated `content_change_log` CREATE TABLE
- ✅ Index definitions
- ✅ Constraint documentation

---

#### Task 2.3: Restore `content_diffs` Table (If Approved)
**Priority**: 🟢 MEDIUM
**Owner**: Data Architect
**Duration**: 0.5 days

**Actions**:
1. Design diff storage schema
2. Choose diff format(s)
3. Define retention policy
4. Add compression strategy
5. Design purge mechanism

**Deliverables**:
- ✅ `content_diffs` CREATE TABLE
- ✅ Retention policy doc
- ✅ Purge job spec

---

#### Task 2.4: Create Views for Common Queries
**Priority**: 🟢 MEDIUM
**Owner**: Data Architect
**Duration**: 1 day

**Views to Create**:
1. `v_current_content_state` (latest checksum per content)
2. `v_content_change_timeline` (chronological changes)
3. `v_pending_regenerations` (processing queue)
4. `v_change_statistics` (analytics)
5. `v_detection_runs` (batch summaries)

**Deliverables**:
- ✅ 5+ VIEW definitions
- ✅ Usage documentation

---

#### Task 2.5: Write Migration Script
**Priority**: 🔴 CRITICAL
**Owner**: Data Architect + DBA
**Duration**: 2 days

**Components**:
1. **Schema migration** (v4 → v5)
2. **Data migration** (if preserving data):
   - Extract baseline from existing detections
   - Infer change events from detection pairs
   - Compute diff if previous content available
3. **Rollback script**
4. **Validation queries**

**Deliverables**:
- ✅ `migrate_v4_to_v5.sql`
- ✅ `rollback_v5_to_v4.sql`
- ✅ Migration testing report

---

### 🟢 **PHASE 3: CODE CHANGES** (Week 3-4)

#### Task 3.1: Update Detection Logic
**Priority**: 🔴 CRITICAL
**Owner**: ML/Backend Engineer
**Duration**: 3-5 days

**Changes**:
1. **Baseline loading**: Query `content_baseline` instead of `content_change_log`
2. **Change detection**: Compare current vs baseline checksum
3. **Change classification**: Compute similarity, categorize change_type
4. **Diff generation**: Compute actual diffs (if enabled)
5. **Dual insert**:
   - Insert/update `content_baseline`
   - Insert `content_change_log` (only if change detected)
   - Insert `content_diffs` (if enabled)

**Code Locations**:
- `src/detectors/faq_regeneration_detector.py`
- `src/processors/change_processor.py` (ChangeLogger)

**Deliverables**:
- ✅ Updated detection code
- ✅ Unit tests
- ✅ Integration tests

---

#### Task 3.2: Update FAQ Invalidation Logic
**Priority**: 🔴 CRITICAL
**Owner**: Backend Engineer
**Duration**: 2-3 days

**Changes**:
1. **Query changes**: Use `content_change_log` only (no non-changes)
2. **Join to baseline**: Get current checksums from `content_baseline`
3. **Change type filtering**: Prioritize by change_type
4. **Error handling**: Handle processing_status = 'failed'

**Code Locations**:
- `src/processors/faq_mapper.py` (FAQUpdater)
- Invalidation queries

**Deliverables**:
- ✅ Updated invalidation code
- ✅ Tests covering change_type filtering

---

#### Task 3.3: Add Processing State Management
**Priority**: 🟡 MEDIUM
**Owner**: Backend Engineer
**Duration**: 2-3 days

**Implement**:
1. **Status transitions**: pending → processing → completed/failed
2. **Retry logic**: Increment retry_count, check max_retries
3. **Error logging**: Capture error_message and error_code
4. **Metrics**: Track processing_duration_seconds

**Deliverables**:
- ✅ Processing state machine
- ✅ Retry logic
- ✅ Error handling

---

#### Task 3.4: Implement Diff Generation (If Enabled)
**Priority**: 🟢 LOW
**Owner**: Backend Engineer
**Duration**: 2-3 days

**Implement**:
1. **Diff computation**: Use difflib or git-diff
2. **Compression**: zlib or gzip
3. **Statistics**: Count additions/deletions
4. **Storage**: Insert into `content_diffs`
5. **Retrieval**: Decompress and display

**Deliverables**:
- ✅ Diff generation module
- ✅ Compression utilities
- ✅ Diff viewer (UI or CLI)

---

#### Task 3.5: Update Analytics Queries
**Priority**: 🟢 MEDIUM
**Owner**: Data Analyst
**Duration**: 1-2 days

**Update**:
1. **Dashboard queries**: Use new schema
2. **Reports**: Change frequency, types, magnitude
3. **Metrics**: Detection lag, processing time, failure rate

**Deliverables**:
- ✅ Updated queries in notebooks
- ✅ New analytics views
- ✅ Dashboard refresh

---

### 🔵 **PHASE 4: TESTING** (Week 5)

#### Task 4.1: Unit Testing
**Priority**: 🔴 CRITICAL
**Owner**: QA Engineer + Dev
**Duration**: 2-3 days

**Test Cases**:
1. Baseline management (add, update, retire)
2. Change detection (new, minor, major)
3. Change sequence numbering
4. Diff generation and compression
5. Processing state transitions
6. Error handling and retry

**Deliverables**:
- ✅ 50+ unit tests
- ✅ >80% code coverage

---

#### Task 4.2: Integration Testing
**Priority**: 🔴 CRITICAL
**Owner**: QA Engineer
**Duration**: 3 days

**Test Scenarios**:
1. **Full detection workflow**: content_repo → baseline → changes → diffs
2. **FAQ invalidation**: changes → invalidate → regenerate
3. **Retry logic**: forced failures → retries → eventual success
4. **Baseline versioning**: Create v2 baseline, compare to v1
5. **Multi-environment**: Separate DIT/PROD baselines

**Deliverables**:
- ✅ Integration test suite
- ✅ Test execution report

---

#### Task 4.3: Performance Testing
**Priority**: 🟡 MEDIUM
**Owner**: Performance Engineer
**Duration**: 2 days

**Benchmarks**:
1. **Baseline query**: Time to load 10K baseline checksums
2. **Change detection**: Time to process 1K content items
3. **Diff generation**: Time to diff 100 large files
4. **Query performance**: All critical queries <100ms

**Deliverables**:
- ✅ Performance report
- ✅ Optimization recommendations

---

### 🟣 **PHASE 5: DEPLOYMENT** (Week 6)

#### Task 5.1: Database Migration
**Priority**: 🔴 CRITICAL
**Owner**: DBA + Dev Lead
**Duration**: 1 day

**Steps**:
1. Backup current database
2. Run migration script (dev → staging → prod)
3. Validate data integrity
4. Run verification queries
5. Monitor for 24 hours

**Deliverables**:
- ✅ Successful migration
- ✅ Validation report
- ✅ Rollback readiness

---

#### Task 5.2: Code Deployment
**Priority**: 🔴 CRITICAL
**Owner**: DevOps + Dev Lead
**Duration**: 1 day

**Steps**:
1. Deploy updated code
2. Enable feature flags
3. Monitor error logs
4. Gradual rollout (10% → 50% → 100%)

**Deliverables**:
- ✅ Deployed code
- ✅ Monitoring dashboard
- ✅ Post-deploy validation

---

#### Task 5.3: Documentation
**Priority**: 🟡 MEDIUM
**Owner**: Tech Writer + Architect
**Duration**: 2 days

**Documents**:
1. Schema documentation
2. API changes (if any)
3. Query examples
4. Runbooks
5. Troubleshooting guide

**Deliverables**:
- ✅ Updated docs
- ✅ Migration guide
- ✅ FAQ for users

---

### 🎯 **PHASE 6: POST-DEPLOYMENT** (Week 7-8)

#### Task 6.1: Monitor & Tune
**Priority**: 🟡 MEDIUM
**Owner**: SRE + Dev Team
**Duration**: 2 weeks

**Monitor**:
1. Query performance
2. Storage growth
3. Processing errors
4. Change detection accuracy

**Tune**:
1. Index optimization
2. Retention policies
3. Batch sizes
4. Thresholds (similarity, priority)

**Deliverables**:
- ✅ Monitoring dashboard
- ✅ Weekly performance reports
- ✅ Tuning recommendations

---

#### Task 6.2: Analytics & Insights
**Priority**: 🟢 LOW
**Owner**: Data Scientist
**Duration**: 1 week

**Analyze**:
1. Change patterns (frequency, types)
2. Content stability (which pages change often)
3. FAQ regeneration impact
4. Detection lag distribution

**Deliverables**:
- ✅ Analytics report
- ✅ Insights presentation
- ✅ Recommendations

---

## 📊 Summary Metrics

### Effort Estimation

| Phase | Duration | Team Size | Effort (person-days) |
|-------|----------|-----------|---------------------|
| Phase 1: Requirements | 1 week | 3 | 12 |
| Phase 2: Schema Design | 1 week | 2 | 10 |
| Phase 3: Code Changes | 2 weeks | 3 | 30 |
| Phase 4: Testing | 1 week | 3 | 15 |
| Phase 5: Deployment | 1 week | 3 | 12 |
| Phase 6: Post-Deploy | 2 weeks | 2 | 12 |
| **TOTAL** | **8 weeks** | **Varies** | **91 person-days** |

**Team Composition**:
- Data Architect (full-time, 6 weeks)
- Backend Engineers (2x, 4 weeks each)
- ML/RAG Engineer (part-time, 1 week)
- QA Engineer (full-time, 2 weeks)
- DBA (part-time, 1 week)
- Product Manager (part-time, 1 week)

---

### Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Requirements creep | MEDIUM | HIGH | Lock scope in Phase 1, defer extras to v2 |
| Performance degradation | LOW | MEDIUM | Benchmark in Phase 4, optimize indexes |
| Data migration issues | MEDIUM | CRITICAL | Extensive testing in staging, rollback plan |
| Backward compatibility breaks | HIGH | MEDIUM | Feature flags, gradual rollout |
| Storage explosion (diffs) | LOW | MEDIUM | Retention policy, compression |

---

## 🎯 Decision Framework

### Decision #1: Two-Table vs Single-Table Design?

**Option A: Two Tables (baseline + changes)** ✅ RECOMMENDED
- **Pros**: Clear separation of concerns, better performance, easier to understand
- **Cons**: More complex queries (JOINs), migration effort

**Option B: Enhanced Single Table**
- **Pros**: Simpler migration, fewer JOINs
- **Cons**: Semantic confusion remains, bloated table

**Recommendation**: **Option A** - Clarity > Convenience

---

### Decision #2: Store Diffs?

**Option A: Full Diffs** ✅ RECOMMENDED (with retention)
- **Pros**: Complete audit trail, debugging power
- **Cons**: Storage cost, computation overhead

**Option B: Summary Stats Only**
- **Pros**: Minimal storage
- **Cons**: Cannot reconstruct what changed

**Option C: No Diffs**
- **Pros**: Simplest
- **Cons**: Major debugging limitation

**Recommendation**: **Option A** with 90-day retention + compression

---

### Decision #3: Change Classification Complexity?

**Option A: Simple (new/minor/major)** ✅ RECOMMENDED for MVP
- **Pros**: Easy to understand, quick to implement
- **Cons**: Less granular

**Option B: Detailed (8 types as proposed)**
- **Pros**: Maximum granularity
- **Cons**: More complex, longer to implement

**Recommendation**: **Option A** for MVP, Option B for v2

---

## 📌 IMMEDIATE ACTION ITEMS (THIS WEEK)

### 🔥 **DO THESE NOW**:

1. **[ ] Schedule Design Review** (Task 1.3)
   - Get all stakeholders in one room
   - Present this document
   - Make decisions

2. **[ ] Answer 5 Key Questions** (Task 1.1)
   - Change history: Yes/No
   - Diff storage: Yes/No
   - Baseline: Multi/Single
   - Processing tracking: In-table/Separate
   - Retention: Policy

3. **[ ] Assess Current Pain Points**
   - What queries are slow?
   - What questions can't be answered?
   - What debugging is hard?

4. **[ ] Estimate Impact**
   - How many detections/day?
   - How many actual changes/day?
   - Storage: Current + projected

5. **[ ] Create Decision Log**
   - Document all decisions
   - Get sign-offs
   - Publish to team

---

## 📞 Next Steps

**After reading this document**:

1. **Review with team** (1-2 days)
2. **Schedule design meeting** (1 week out)
3. **Answer requirements questions** (before meeting)
4. **Decide on scope** (MVP vs full)
5. **Approve or reject redesign**

**Questions to Answer**:
- [ ] Is current schema causing real problems? (Or just theoretical?)
- [ ] Do we have budget for 8-week redesign?
- [ ] Can we defer to future release?
- [ ] Should we do phased rollout (baseline first, then changes)?

---

**END OF ANALYSIS**

**Document Version**: 1.0
**Last Updated**: 2025-10-20
**Status**: DRAFT - Awaiting stakeholder review
**Next Review**: After Phase 1 Task 1.3 (Design Review Meeting)
