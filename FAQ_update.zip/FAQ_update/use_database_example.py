#!/usr/bin/env python
"""
Example script showing how to use the created SQLite database.

This demonstrates basic CRUD operations with the granular impact database.

Prerequisites:
    Run create_database.py first to create the database.

Usage:
    python use_database_example.py
"""

import sys
from pathlib import Path
from datetime import datetime

# Ensure imports work
sys.path.insert(0, str(Path(__file__).parent))

from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    ContentChecksum,
    FAQQuestion,
    FAQAnswer,
    FAQQuestionSource,
    ContentStatus,
    FAQStatus,
    SourceType,
    GenerationMethod,
    AnswerFormat,
)


def main():
    """Demonstrate database usage."""
    # Connect to existing database
    db_path = Path(__file__).parent / "databases" / "granular_impact.db"

    if not db_path.exists():
        print("❌ Database not found!")
        print(f"   Expected: {db_path}")
        print()
        print("Run this first:")
        print("   python create_database.py")
        return 1

    print(f"📁 Connecting to: {db_path}")
    print()

    adapter = create_adapter(
        DatabaseDialect.SQLITE,
        database_path=str(db_path)
    )

    try:
        # Example 1: Insert a content checksum
        print("=" * 70)
        print("EXAMPLE 1: Insert Content Checksum")
        print("=" * 70)

        checksum = "a" * 64  # SHA-256 hash (64 chars)
        adapter.execute(
            """INSERT INTO content_checksums
               (content_checksum, file_name, file_type, title, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                checksum,
                "employee_handbook.pdf",
                "pdf",
                "Employee Handbook 2025",
                ContentStatus.ACTIVE.value,
                datetime.now().isoformat()
            )
        )
        adapter.commit()
        print(f"✅ Inserted content checksum: {checksum[:16]}...")
        print()

        # Example 2: Insert a FAQ question
        print("=" * 70)
        print("EXAMPLE 2: Insert FAQ Question")
        print("=" * 70)

        question_text = "How many sick days do employees get per year?"
        adapter.execute(
            """INSERT INTO faq_questions
               (question_text, source_type, generation_method, status, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (
                question_text,
                SourceType.FROM_DOCUMENTS.value,
                GenerationMethod.LLM_GENERATED.value,
                FAQStatus.ACTIVE.value,
                datetime.now().isoformat()
            )
        )
        adapter.commit()

        # Get the inserted question_id
        result = adapter.fetchall(
            "SELECT question_id FROM faq_questions WHERE question_text = ?",
            (question_text,)
        )
        question_id = result[0][0]
        print(f"✅ Inserted question (ID: {question_id}):")
        print(f"   {question_text}")
        print()

        # Example 3: Insert a FAQ answer
        print("=" * 70)
        print("EXAMPLE 3: Insert FAQ Answer")
        print("=" * 70)

        answer_text = "<p>Employees receive <strong>12 sick days</strong> per calendar year.</p>"
        adapter.execute(
            """INSERT INTO faq_answers
               (question_id, answer_text, answer_format, confidence_score, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                question_id,
                answer_text,
                AnswerFormat.HTML.value,
                0.95,
                FAQStatus.ACTIVE.value,
                datetime.now().isoformat()
            )
        )
        adapter.commit()
        print(f"✅ Inserted answer for question {question_id}")
        print()

        # Example 4: Link question to content (provenance)
        print("=" * 70)
        print("EXAMPLE 4: Link Question to Content (Provenance)")
        print("=" * 70)

        adapter.execute(
            """INSERT INTO faq_question_sources
               (question_id, content_checksum, is_primary_source,
                contribution_weight, is_valid, valid_from)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                question_id,
                checksum,
                1,  # True (SQLite uses 0/1 for boolean)
                1.0,
                1,  # True
                datetime.now().isoformat()
            )
        )
        adapter.commit()
        print(f"✅ Linked question {question_id} to content {checksum[:16]}...")
        print()

        # Example 5: Query data with JOIN
        print("=" * 70)
        print("EXAMPLE 5: Query FAQ with Source Information")
        print("=" * 70)

        results = adapter.fetchall(
            """
            SELECT
                q.question_id,
                q.question_text,
                a.answer_text,
                c.file_name,
                c.title,
                qs.contribution_weight
            FROM faq_questions q
            JOIN faq_answers a ON q.question_id = a.question_id
            JOIN faq_question_sources qs ON q.question_id = qs.question_id
            JOIN content_checksums c ON qs.content_checksum = c.content_checksum
            WHERE q.status = 'active'
            """
        )

        print(f"Found {len(results)} FAQ(s):")
        print()
        for row in results:
            qid, question, answer, fname, title, weight = row
            print(f"FAQ #{qid}:")
            print(f"  Question: {question}")
            print(f"  Answer: {answer[:80]}...")
            print(f"  Source: {fname} ({title})")
            print(f"  Weight: {weight}")
            print()

        # Example 6: Count statistics
        print("=" * 70)
        print("EXAMPLE 6: Database Statistics")
        print("=" * 70)

        stats = [
            ("Content Checksums", "content_checksums"),
            ("FAQ Questions", "faq_questions"),
            ("FAQ Answers", "faq_answers"),
            ("Question Sources", "faq_question_sources"),
            ("Answer Sources", "faq_answer_sources"),
            ("Change Log Entries", "content_change_log"),
            ("Audit Log Entries", "faq_audit_log"),
        ]

        for label, table in stats:
            count = adapter.fetchall(f"SELECT COUNT(*) FROM {table}")[0][0]
            print(f"  {label:.<25} {count:>5}")

        print()
        print("=" * 70)
        print("✅ ALL EXAMPLES COMPLETED SUCCESSFULLY!")
        print("=" * 70)

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1

    finally:
        # Always close the connection
        adapter.close()
        print()
        print("🔒 Database connection closed")

    return 0


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n❌ Interrupted by user")
        sys.exit(1)
