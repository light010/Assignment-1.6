"""
Script to create the 1_faq_ingestion.ipynb notebook programmatically.

This ensures proper JSON formatting and escaping.
"""

import json
from pathlib import Path

# Define all notebook cells
cells = [
    # Cell 1: Title and Overview
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "# FAQ Generation and Ingestion Pipeline\n",
            "\n",
            "This notebook generates FAQs from source documents using oneailib and ingests them into the granular impact database.\n",
            "\n",
            "## Pipeline Overview\n",
            "\n",
            "Based on **test2.yaml** pipeline with adaptations for local database ingestion:\n",
            "\n",
            "1. **Load Documents**: Load source content from markdown files\n",
            "2. **Generate Questions**: Use LLM to generate questions from documents\n",
            "3. **Add Metadata**: Add document IDs, versions, and hash IDs\n",
            "4. **Generate Answers**: Use LLM to generate answers with context\n",
            "5. **Filter & Validate**: Filter invalid answers and apply quality thresholds\n",
            "6. **Map to Database**: Transform oneailib output to database schema\n",
            "7. **Ingest to Database**: Insert into faq_questions, faq_answers, and source tables\n",
            "\n",
            "## Prerequisites\n",
            "\n",
            "- Database schema must be created\n",
            "- Content repository must be ingested (run `0_content_repo_ingestion.ipynb` first)\n",
            "- Azure OpenAI credentials configured (optional - can use mock mode)\n",
            "- oneailib installed and configured (optional - can use mock mode)"
        ]
    },

    # Cell 2: Setup Section
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## Setup and Configuration"]
    },

    # Cell 3: Imports
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "import sys\n",
            "from pathlib import Path\n",
            "import pandas as pd\n",
            "import sqlite3\n",
            "\n",
            "# Add parent directory to path for imports\n",
            "sys.path.append(str(Path.cwd().parent))\n",
            "\n",
            "# Import FAQ generation module\n",
            "from data_ingestion.faq_generation import (\n",
            "    FAQGenerator,\n",
            "    FAQGenerationConfig,\n",
            "    generate_faqs_from_csv,\n",
            ")\n",
            "from data_ingestion import FAQIngestion, FAQSourceIngestion\n",
            "\n",
            "# Display settings\n",
            "pd.set_option('display.max_columns', None)\n",
            "pd.set_option('display.max_colwidth', 100)\n",
            "pd.set_option('display.width', 1000)\n",
            "\n",
            "print(\"✓ Imports successful\")"
        ]
    },

    # Cell 4: Configuration
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Configuration\n",
            "PROJECT_ROOT = Path.cwd().parent if 'granular_impact' in str(Path.cwd()) else Path.cwd()\n",
            "DB_PATH = PROJECT_ROOT / \"databases\" / \"faq_update.db\"\n",
            "DATA_DIR = Path(\"data_ingestion/data\")\n",
            "MARKDOWN_DIR = DATA_DIR / \"markdown\"\n",
            "DEBUG_DIR = Path(\"debug_output\")\n",
            "DEBUG_DIR.mkdir(exist_ok=True)\n",
            "\n",
            "# FAQ Generation Configuration\n",
            "config = FAQGenerationConfig(\n",
            "    # LLM Settings (replace with actual values to use real LLM)\n",
            "    api_base_url=\"YOUR_AZURE_OPENAI_ENDPOINT\",  # Replace with actual endpoint\n",
            "    chat_model_name=\"gpt-4\",\n",
            "    use_mock=True,  # Set to False to use real LLM\n",
            "    \n",
            "    # Generation settings\n",
            "    n_questions_per_document=3,  # Max questions per document\n",
            "    temperature=0.0,\n",
            "    \n",
            "    # Filtering thresholds\n",
            "    confidence_threshold=0.85,\n",
            ")\n",
            "\n",
            "print(f\"Project Root: {PROJECT_ROOT}\")\n",
            "print(f\"Database: {DB_PATH}\")\n",
            "print(f\"Data Directory: {DATA_DIR}\")\n",
            "print(f\"Debug Output: {DEBUG_DIR}\")\n",
            "print(f\"\\nMode: {'MOCK' if config.use_mock else 'REAL LLM'}\")\n",
            "\n",
            "# Verify paths\n",
            "assert DB_PATH.exists(), f\"Database not found: {DB_PATH}\"\n",
            "assert DATA_DIR.exists(), f\"Data directory not found: {DATA_DIR}\"\n",
            "assert MARKDOWN_DIR.exists(), f\"Markdown directory not found: {MARKDOWN_DIR}\"\n",
            "\n",
            "print(\"\\n✓ All paths verified\")"
        ]
    },

    # Cell 5: Pipeline Execution Section
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "---\n",
            "## FAQ Generation Pipeline\n",
            "\n",
            "Run the complete FAQ generation pipeline."
        ]
    },

    # Cell 6: Run Pipeline
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Define paths\n",
            "csv_path = DATA_DIR / \"sample_content_repo.csv\"\n",
            "\n",
            "# Run complete pipeline\n",
            "print(\"\\n\" + \"=\"*80)\n",
            "print(\"  STARTING FAQ GENERATION PIPELINE\")\n",
            "print(\"=\"*80)\n",
            "\n",
            "df_questions, df_answers, df_question_sources, df_answer_sources = generate_faqs_from_csv(\n",
            "    csv_path=csv_path,\n",
            "    markdown_dir=MARKDOWN_DIR,\n",
            "    config=config,\n",
            "    save_debug=True,\n",
            "    debug_dir=DEBUG_DIR,\n",
            ")\n",
            "\n",
            "print(\"\\n✓ FAQ generation pipeline completed successfully\")"
        ]
    },

    # Cell 7: Display Results Section
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "---\n",
            "## Review Generated FAQs\n",
            "\n",
            "Review the generated questions and answers before ingestion."
        ]
    },

    # Cell 8: Display Questions
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  GENERATED QUESTIONS\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "\n",
            "print(f\"Total questions: {len(df_questions)}\\n\")\n",
            "print(df_questions.head(10))"
        ]
    },

    # Cell 9: Display Answers
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  GENERATED ANSWERS\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "\n",
            "print(f\"Total answers: {len(df_answers)}\\n\")\n",
            "print(df_answers[['answer_text', 'confidence_score', 'answer_format']].head(10))"
        ]
    },

    # Cell 10: Display Sources
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  SOURCE PROVENANCE\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "\n",
            "print(f\"Question sources: {len(df_question_sources)}\")\n",
            "print(f\"Answer sources: {len(df_answer_sources)}\\n\")\n",
            "\n",
            "print(\"Sample question sources:\")\n",
            "print(df_question_sources.head(5))\n",
            "\n",
            "print(\"\\nSample answer sources:\")\n",
            "print(df_answer_sources.head(5))"
        ]
    },

    # Cell 11: Database Ingestion Section
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "---\n",
            "## Database Ingestion\n",
            "\n",
            "Ingest the generated FAQs into the database."
        ]
    },

    # Cell 12: Ingest FAQs
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  DATABASE INGESTION\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "\n",
            "# Initialize ingestion classes\n",
            "faq_ingestion = FAQIngestion(str(DB_PATH))\n",
            "source_ingestion = FAQSourceIngestion(str(DB_PATH))\n",
            "\n",
            "# Get stats before ingestion\n",
            "print(\"Database stats BEFORE ingestion:\")\n",
            "stats_before = faq_ingestion.get_stats()\n",
            "for key, value in stats_before.items():\n",
            "    print(f\"  {key:30s}: {value}\")\n",
            "\n",
            "# Option: Clear existing data (uncomment if needed)\n",
            "# print(\"\\n⚠️  Clearing existing FAQ data...\")\n",
            "# faq_ingestion.clear()\n",
            "# source_ingestion.clear()"
        ]
    },

    # Cell 13: Ingest Questions
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Ingest questions\n",
            "print(\"\\nIngesting questions...\")\n",
            "result = faq_ingestion.ingest_questions_from_dataframe(df_questions)\n",
            "if result['success']:\n",
            "    print(f\"  ✓ {result['rows_inserted']} questions inserted\")\n",
            "else:\n",
            "    print(f\"  ✗ Error: {result['message']}\")\n",
            "    raise Exception(f\"Question ingestion failed: {result['message']}\")"
        ]
    },

    # Cell 14: Ingest Answers
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Ingest answers\n",
            "print(\"\\nIngesting answers...\")\n",
            "result = faq_ingestion.ingest_answers_from_dataframe(df_answers)\n",
            "if result['success']:\n",
            "    print(f\"  ✓ {result['rows_inserted']} answers inserted\")\n",
            "else:\n",
            "    print(f\"  ✗ Error: {result['message']}\")\n",
            "    raise Exception(f\"Answer ingestion failed: {result['message']}\")"
        ]
    },

    # Cell 15: Ingest Sources
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Ingest question sources\n",
            "print(\"\\nIngesting question sources...\")\n",
            "result = source_ingestion.ingest_question_sources_from_dataframe(df_question_sources)\n",
            "if result['success']:\n",
            "    print(f\"  ✓ {result['rows_inserted']} question sources inserted\")\n",
            "else:\n",
            "    print(f\"  ✗ Error: {result['message']}\")\n",
            "\n",
            "# Ingest answer sources\n",
            "print(\"\\nIngesting answer sources...\")\n",
            "result = source_ingestion.ingest_answer_sources_from_dataframe(df_answer_sources)\n",
            "if result['success']:\n",
            "    print(f\"  ✓ {result['rows_inserted']} answer sources inserted\")\n",
            "else:\n",
            "    print(f\"  ✗ Error: {result['message']}\")\n",
            "\n",
            "# Get stats after ingestion\n",
            "print(\"\\nDatabase stats AFTER ingestion:\")\n",
            "stats_after = faq_ingestion.get_stats()\n",
            "for key, value in stats_after.items():\n",
            "    print(f\"  {key:30s}: {value}\")"
        ]
    },

    # Cell 16: Verification Section
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "---\n",
            "## Verification\n",
            "\n",
            "Verify the ingested data with sample queries."
        ]
    },

    # Cell 17: Query FAQs
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  VERIFICATION QUERIES\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "\n",
            "conn = sqlite3.connect(str(DB_PATH))\n",
            "\n",
            "# Query 1: Questions with sources\n",
            "print(\"Query 1: Questions with their source documents\\n\")\n",
            "query = \"\"\"\n",
            "SELECT \n",
            "    q.question_id,\n",
            "    q.question_text,\n",
            "    q.generation_method,\n",
            "    qs.content_checksum,\n",
            "    qs.is_primary_source\n",
            "FROM faq_questions q\n",
            "LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id\n",
            "ORDER BY q.question_id\n",
            "LIMIT 5\n",
            "\"\"\"\n",
            "df_result = pd.read_sql_query(query, conn)\n",
            "print(df_result.to_string(index=False))"
        ]
    },

    # Cell 18: Query Answers
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Query 2: Answers with confidence scores\n",
            "print(\"\\n\\nQuery 2: Answers with confidence scores\\n\")\n",
            "query = \"\"\"\n",
            "SELECT \n",
            "    a.answer_id,\n",
            "    q.question_text,\n",
            "    a.answer_text,\n",
            "    a.confidence_score,\n",
            "    a.answer_format\n",
            "FROM faq_answers a\n",
            "JOIN faq_questions q ON a.question_id = q.question_id\n",
            "ORDER BY a.confidence_score DESC\n",
            "LIMIT 5\n",
            "\"\"\"\n",
            "df_result = pd.read_sql_query(query, conn)\n",
            "print(df_result.to_string(index=False))"
        ]
    },

    # Cell 19: Query Sources
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Query 3: Answer sources and provenance\n",
            "print(\"\\n\\nQuery 3: Answer sources and provenance\\n\")\n",
            "query = \"\"\"\n",
            "SELECT \n",
            "    asrc.answer_id,\n",
            "    q.question_text,\n",
            "    asrc.content_checksum,\n",
            "    asrc.is_primary_source,\n",
            "    asrc.contribution_weight,\n",
            "    asrc.is_valid\n",
            "FROM faq_answer_sources asrc\n",
            "JOIN faq_answers a ON asrc.answer_id = a.answer_id\n",
            "JOIN faq_questions q ON a.question_id = q.question_id\n",
            "ORDER BY asrc.answer_id\n",
            "LIMIT 5\n",
            "\"\"\"\n",
            "df_result = pd.read_sql_query(query, conn)\n",
            "print(df_result.to_string(index=False))\n",
            "\n",
            "conn.close()"
        ]
    },

    # Cell 20: Summary
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "---\n",
            "## Summary\n",
            "\n",
            "### Completed:\n",
            "✓ FAQs generated from source documents  \n",
            "✓ Questions and answers created with proper metadata  \n",
            "✓ Source provenance tracked (links to content checksums)  \n",
            "✓ Data ingested into database  \n",
            "✓ Schema compliance verified  \n",
            "\n",
            "### Next Steps:\n",
            "1. **Update Content**: Modify source documents to simulate changes\n",
            "2. **Run Change Detection**: Use the change detection module to identify changes\n",
            "3. **Impact Analysis**: Determine which FAQs are affected\n",
            "4. **Selective Invalidation**: Invalidate only affected FAQs\n",
            "5. **Regeneration**: Re-generate FAQs for changed content\n",
            "\n",
            "### Notes:\n",
            "- Pipeline can run in **MOCK mode** (no API calls) or **REAL LLM mode** (requires Azure OpenAI)\n",
            "- Debug outputs saved to `debug_output/` directory\n",
            "- Source provenance enables granular impact analysis\n",
            "- Temporal validity tracking allows regeneration without conflicts"
        ]
    },

    # Cell 21: Final Message
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "print(f\"\\n{'='*80}\")\n",
            "print(\"  FAQ GENERATION AND INGESTION COMPLETE\")\n",
            "print(f\"{'='*80}\\n\")\n",
            "print(\"✓ All data successfully generated and ingested\")\n",
            "print(\"✓ All relationships verified\")\n",
            "print(\"✓ Ready for change detection and impact analysis\")\n",
            "print(f\"\\n{'='*80}\")"
        ]
    },
]

# Create notebook structure
notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3"
        },
        "language_info": {
            "codemirror_mode": {"name": "ipython", "version": 3},
            "file_extension": ".py",
            "mimetype": "text/x-python",
            "name": "python",
            "nbconvert_exporter": "python",
            "pygments_lexer": "ipython3",
            "version": "3.11.0"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 4
}

# Write notebook
output_path = Path(__file__).parent / "1_faq_ingestion.ipynb"
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(notebook, f, indent=2, ensure_ascii=False)

print(f"✓ Notebook created: {output_path}")
print(f"✓ Total cells: {len(cells)}")
