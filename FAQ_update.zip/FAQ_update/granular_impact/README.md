# Granular Impact Analysis Module

A comprehensive production-grade system for detecting and analyzing content changes in FAQ systems, providing granular impact assessment for selective FAQ invalidation.

## Overview

This module provides a multi-tiered approach to analyzing how source content changes affect FAQ accuracy:

1. **Change Detection**: Identifies content changes using checksums
2. **Similarity Analysis**: Computes similarity using multiple algorithms
3. **Diff Analysis**: Extracts and analyzes specific changes
4. **Impact Scoring**: Combines multiple signals into impact assessment
5. **Decision Making**: Determines whether FAQs should be invalidated

## Architecture

```
granular_impact/
├── config.py                 # Configuration management
├── chunking.py               # Simple character-based chunking (NEW)
├── data_ingestion/           # Data ingestion
│   ├── __init__.py          # Ingestion exports
│   ├── A_content_repo_ingestion.py   # Content repo loader
│   ├── chunk_ingestion.py           # Chunk ingestion (content_chunks table)
│   ├── content_repo_edit.py         # Version tracking with auto-increment
│   ├── faq_ingestion.py             # FAQ loader
│   ├── faq_source_ingestion.py      # FAQ source loader
│   ├── faq_generation.py            # FAQ generation
│   ├── data/                # Sample data files
│   │   └── sample_content_repo.csv
│   └── README.md            # Ingestion documentation
├── similarity/               # Similarity algorithms
│   ├── base.py              # Abstract interface
│   ├── jaccard.py           # Jaccard similarity
│   ├── difflib_sim.py       # Difflib sequence matching
│   ├── tfidf_sim.py         # TF-IDF cosine similarity
│   ├── bm25_sim.py          # BM25 ranking (optional)
│   ├── embedding_sim.py     # Semantic embeddings (optional)
│   └── hybrid.py            # Weighted combination
├── diff/                     # Diff analysis
│   ├── diff_engine.py       # Core diff computation
│   ├── phrase_extractor.py  # Phrase extraction
│   └── semantic_detector.py # Semantic change detection
├── impact/                   # Impact analysis
│   ├── impact_analyzer.py   # Main analyzer
│   ├── scoring.py           # Scoring methods
│   └── decision.py          # Decision logic
├── database/                 # Data access
│   ├── models.py            # Data models
│   ├── connection.py        # DB connection
│   ├── queries.py           # SQL templates
│   └── transactions.py      # Transaction management
├── detection/                # Change detection (V8.2)
│   ├── content_change_detector.py  # V8.2 algorithm with similarity
│   ├── checksum_file_extractor.py  # File/database extraction
│   ├── database_queries.py         # Database utilities
│   └── checksum_extractor.py       # Core checksums
├── workflow/                 # Orchestration
│   ├── orchestrator.py      # Main workflow
│   └── invalidator.py       # Invalidation logic
└── utils/                    # Utilities
    ├── logging_utils.py     # Logging
    ├── metrics.py           # Performance metrics
    └── validators.py        # Validation
```

## Quick Start: Notebook Workflow

The recommended workflow for ingesting data and generating FAQs uses four sequential notebooks:

### 1. Content Repository Ingestion

**Notebook**: [0_content_repo_ingestion.ipynb](0_content_repo_ingestion.ipynb)

Ingests source documents into the `content_repo` table:

```python
from granular_impact.data_ingestion import ContentRepoIngestion

ingestion = ContentRepoIngestion(str(db_path))
result = ingestion.ingest_from_csv("data/sample_content_repo.csv")
```

**Output**: Source document metadata in `content_repo` table.

### 2. Content Chunk Ingestion

**Notebook**: [1_checksum_table_ingestion.ipynb](1_checksum_table_ingestion.ipynb)

Chunks documents and stores chunks with their checksums:

```python
from granular_impact.chunking import SimpleChunker
from granular_impact.data_ingestion import ChunkIngestion

# Chunk content
chunker = SimpleChunker(chunk_size=1000)
chunks_with_checksums = chunker.chunk_with_checksums(content)

# Ingest to content_chunks table (linked to content_repo)
chunk_ingestion = ChunkIngestion(str(db_path))
result = chunk_ingestion.ingest_chunks_for_file(
    ud_source_file_id=file_id,
    chunks_with_checksums=chunks_with_checksums
)
```

**Output**: Content chunks with checksums in `content_chunks` table.

### 3. FAQ Generation and Ingestion

**Notebook**: [2_faq_generation_ingestion.ipynb](2_faq_generation_ingestion.ipynb)

Generates FAQs from content checksums and ingests into database:

```python
from granular_impact.faq_generation import (
    DocumentLoader,
    QuestionGenerator,
    AnswerGenerator,
)
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion

# Load documents from database
loader = DocumentLoader(db_path=str(db_path))
documents = loader.load_documents(status_filter="active")

# Generate questions
question_generator = QuestionGenerator()
df_questions, df_question_sources = question_generator.generate_and_map(
    documents=documents,
    deduplicate=True
)

# Generate answers
answer_generator = AnswerGenerator()
answer_generator.load_context_documents(documents)
df_answers, df_answer_sources = answer_generator.generate_and_map(
    questions=questions,
    retrieve_context=True
)

# Ingest into database
faq_ingestion = FAQIngestion(str(db_path))
faq_ingestion.ingest_questions_from_dataframe(df_questions)
faq_ingestion.ingest_answers_from_dataframe(df_answers)

source_ingestion = FAQSourceIngestion(str(db_path))
source_ingestion.ingest_question_sources_from_dataframe(df_question_sources)
source_ingestion.ingest_answer_sources_from_dataframe(df_answer_sources)
```

**Output**:
- `faq_questions`: Generated questions
- `faq_answers`: Generated answers
- `faq_question_sources`: Question provenance (links to content checksums)
- `faq_answer_sources`: Answer provenance (links to content checksums)

### 4. Content Change Detection

**Notebook**: [4_change_detection.ipynb](4_change_detection.ipynb)

Detects content changes by comparing versions using the `content_chunks` table:

```python
from granular_impact.detection.content_change_detector import ContentChangeDetector
from granular_impact.detection.database_queries import ChangeDetectionQueries
from granular_impact.data_ingestion import ChunkIngestion
from granular_impact.chunking import SimpleChunker

# Set configuration
SINCE_DATE = '2025-01-01'  # Process content modified after this date
SIMILARITY_THRESHOLD = 0.8  # 80% similarity = MODIFIED

# Load modified content from content_repo
modified_content = load_content_since(SINCE_DATE)

# Chunk and ingest modified content into content_chunks
chunker = SimpleChunker(chunk_size=1000)
chunk_ingestion = ChunkIngestion(str(db_path))

for _, row in modified_content.iterrows():
    content = Path(row['extracted_markdown_file_path']).read_text()
    chunks = chunker.chunk_with_checksums(content)

    # Ingest with FK to content_repo
    chunk_ingestion.ingest_chunks_for_file(
        ud_source_file_id=row['ud_source_file_id'],
        chunks_with_checksums=chunks,
        clear_existing=True
    )

# Load baseline chunks (version 1)
baseline_df = pd.read_sql_query("""
    SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
    FROM content_chunks cc
    JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
    WHERE cr.raw_file_version_nbr = 1
      AND cc.status = 'active'
      AND cr.file_status = 'Active'
""", conn)

# Load current chunks (recently modified)
current_df = pd.read_sql_query("""
    SELECT cc.content_checksum, cc.chunk_text, cr.raw_file_nme
    FROM content_chunks cc
    JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
    WHERE cr.last_modified_dt > ?
      AND cc.status = 'active'
      AND cr.file_status = 'Active'
""", conn, params=[SINCE_DATE])

# Detect changes using hybrid similarity matching
detector = ContentChangeDetector(similarity_threshold=SIMILARITY_THRESHOLD)
changes = detector.detect_changes(
    file_name=file_name,
    current_checksums_data=current_data,
    previous_checksums_data=previous_data,
    detection_run_id=detection_run_id
)

# Store results in content_change_log
ChangeDetectionQueries.store_change_detection_results(
    conn=conn,
    changes=changes,
    detection_run_id=detection_run_id,
    use_spark=False
)
```

**Output**:
- Change detection results in `content_change_log` table
- Classification of changes: NEW, MODIFIED, DELETED, UNCHANGED
- Similarity scores and LLM-friendly diffs for MODIFIED content
- FAQ impact counts per change

**Key Features**:
- **Version-Based Comparison**: Compares v1 baseline vs v2+ current using `raw_file_version_nbr`
- **FK Relationships**: Chunks linked to `content_repo` via `ud_source_file_id`
- **Incremental Processing**: Only processes content modified after `since_date`
- **Checksum-Centric**: Uses SHA-256 checksums as primary content identity
- **Similarity Matching**: Hybrid algorithm (Jaccard + Difflib + BM25) detects modifications
- **FAQ Impact Tracking**: Counts how many FAQs will be affected by each change

### Design Principles

- **Separation of Concerns**: Question and answer generation are independent
- **Simplicity**: Direct use of QuestionGenerator and AnswerGenerator
- **Mock Mode**: Can run without LLM for testing/development (set `use_mock=True`)
- **Source Provenance**: Tracks which content chunks generated each FAQ
- **Temporal Validity**: Enables regeneration without conflicts

## Installation

### Basic Installation

```bash
pip install -r requirements.txt
```

### Optional: With Embedding Support

For semantic similarity using transformers:

```bash
pip install sentence-transformers torch
```

## Configuration

### Using Configuration Files

```python
from granular_impact.config import GranularImpactConfig
from pathlib import Path

# Load from YAML
config = GranularImpactConfig.from_yaml(Path("config.yaml"))

# Validate
config.validate()
```

### Using Environment Presets

```python
from granular_impact.config import GranularImpactConfig, Environment

# DIT environment
config = GranularImpactConfig.from_environment(Environment.DIT)

# Production environment
config = GranularImpactConfig.from_environment(
    Environment.PROD,
    workflow_dry_run=False  # Override specific settings
)
```

## Usage

### Data Ingestion (NEW)

Load content into the database from CSV files or DataFrames:

```python
from granular_impact.data_ingestion import ContentRepoIngestion
from pathlib import Path

# Initialize with database path
db_path = Path("FAQ_update/databases/faq_update.db")
ingestion = ContentRepoIngestion(str(db_path))

# Ingest from CSV
result = ingestion.ingest_from_csv("granular_impact/data_ingestion/data/sample_content_repo.csv")

if result['success']:
    print(f"✅ Inserted {result['rows_inserted']} rows")

    # Get statistics
    stats = ingestion.get_stats()
    print(f"Total records: {stats['total_records']}")
    print(f"Unique files: {stats['unique_files']}")
    print(f"Domains: {stats['domains']}")
else:
    print(f"❌ Error: {result['message']}")
```

See [data_ingestion/README.md](data_ingestion/README.md) for detailed documentation.

### Content Chunking (NEW)

Split content into fixed-size chunks for checksum computation:

```python
from granular_impact.chunking import SimpleChunker

# Initialize chunker (default: 1000 characters per chunk)
chunker = SimpleChunker(chunk_size=1000)

# Read content
content = Path("document.md").read_text()

# Option 1: Get chunks only
chunks = chunker.chunk(content)
print(f"Split into {len(chunks)} chunks")

# Option 2: Get chunks with SHA-256 checksums
chunks_with_checksums = chunker.chunk_with_checksums(content)

for i, (chunk_text, checksum) in enumerate(chunks_with_checksums, 1):
    print(f"Chunk {i}: {checksum[:16]}... ({len(chunk_text)} chars)")
```

**Use case**: Enables granular change detection by computing checksums at chunk level instead of whole document level.

### Basic Similarity Comparison

```python
from granular_impact.similarity import HybridSimilarityCalculator

calc = HybridSimilarityCalculator()

old_text = "Employees must submit reports within 30 days."
new_text = "Employees must submit reports within 45 days."

result = calc.compute_similarity(old_text, new_text)

print(f"Similarity: {result.score:.3f}")
print(f"Algorithm: {result.algorithm}")
print(f"Individual scores: {result.metadata['individual_scores']}")
```

### Complete Impact Analysis

```python
from granular_impact.config import GranularImpactConfig, Environment
from granular_impact.similarity import HybridSimilarityCalculator
from granular_impact.diff import DiffEngine, SemanticDetector
from granular_impact.impact import ImpactAnalyzer

# Initialize
config = GranularImpactConfig.from_environment(Environment.DIT)
similarity_calc = HybridSimilarityCalculator()
diff_engine = DiffEngine()
semantic_detector = SemanticDetector()

analyzer = ImpactAnalyzer(config, similarity_calc, diff_engine, semantic_detector)

# Analyze impact
result = analyzer.analyze_impact(
    faq_id="faq_12345",
    content_id="content_67890",
    old_content="Old content text...",
    new_content="New content text...",
    old_checksum="abc123",
    new_checksum="def456"
)

print(f"Impact Decision: {result.impact_decision}")
print(f"Overall Score: {result.overall_impact_score:.3f}")
print(f"Requires Review: {result.requires_manual_review}")
```

### Content Change Detection (V8.2)

```python
from granular_impact.detection import (
    ContentChangeDetector,
    ChecksumFileExtractor,
    ChangeDetectionQueries
)

# Initialize detector
detector = ContentChangeDetector(similarity_threshold=0.8)
extractor = ChecksumFileExtractor()

# Extract checksums from markdown files
current_checksums = extractor.extract_from_markdown_files(
    markdown_dir='/path/to/current/markdown',
    file_name_pattern='handbook_*.md'
)

# Get previous checksums from database
previous_checksums = ChangeDetectionQueries.get_previous_checksums_for_file(
    conn=conn,
    file_name='handbook.pdf',
    since_date=datetime(2025, 1, 1)
)

# Detect changes
changes = detector.detect_changes(
    file_name='handbook.pdf',
    current_checksums_data=current_checksums,
    previous_checksums_data=previous_checksums,
    detection_run_id='RUN_2025_01_22'
)

# Store results
ChangeDetectionQueries.store_change_detection_results(
    conn=conn,
    changes=changes,
    detection_run_id='RUN_2025_01_22'
)

print(f"Detected {len(changes)} changes")
for change in changes:
    print(f"  {change.change_type.value}: similarity={change.similarity_score:.3f}")
```

See [detection/README.md](detection/README.md) for complete documentation.

## Algorithms

### Similarity Algorithms

| Algorithm | Best For | Speed | Accuracy |
|-----------|----------|-------|----------|
| **Jaccard** | Token overlap, quick checks | Fast | Medium |
| **Difflib** | Character-level changes | Fast | Medium |
| **TF-IDF** | Semantic similarity, keywords | Medium | High |
| **BM25** | Document ranking, retrieval | Medium | High |
| **Embedding** | Semantic meaning, paraphrases | Slow | Very High |
| **Hybrid** | Production use, robust | Medium | Very High |

### Impact Scoring

Impact score is computed as weighted combination:

```
Impact = (1 - Similarity) × 0.4 + DiffMagnitude × 0.3 + SemanticImportance × 0.3
```

Thresholds (configurable):
- **None**: < 0.2
- **Low**: 0.2 - 0.5
- **Medium**: 0.5 - 0.75
- **High**: 0.75 - 0.9
- **Critical**: >= 0.9 (auto-invalidate)

## Testing

```bash
# Run tests
pytest tests/

# Run with coverage
pytest tests/ --cov=granular_impact --cov-report=html
```

## Code Quality

```bash
# Format code
black granular_impact/ --line-length 100
isort granular_impact/ --line-length 100

# Lint
flake8 granular_impact/

# Type checking
mypy granular_impact/
```

## Databricks Integration

See notebooks in `notebooks/`:
- `01_schema_setup.py`: Create database schema
- `02_test_similarity.py`: Test algorithms
- `03_run_detection.py`: Run detection workflow
- `04_analyze_results.py`: Analyze results

## Performance

Typical performance on modern hardware:

| Operation | Time (ms) | Throughput |
|-----------|-----------|------------|
| Jaccard similarity | 0.5 | 2000 pairs/sec |
| TF-IDF similarity | 2.0 | 500 pairs/sec |
| Hybrid similarity | 5.0 | 200 pairs/sec |
| Full impact analysis | 10.0 | 100 analyses/sec |

## Monitoring

```python
from granular_impact.utils import MetricsCollector

metrics = MetricsCollector()

with metrics.track_operation("impact_analysis"):
    result = analyzer.analyze_impact(...)

summary = metrics.get_summary()
print(f"Operations: {summary['total_operations']}")
print(f"Avg duration: {summary['average_duration_ms']:.2f}ms")
```

## Contributing

1. Follow PEP 8 style guide
2. Add type hints to all functions
3. Write docstrings for all public APIs
4. Add tests for new features
5. Run code quality checks before committing

## License

Internal use only - Analytics Assist Team

## Support

For questions or issues, contact the Analytics Assist development team.
