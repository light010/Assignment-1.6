"""
Debug script to understand the chunk and change detection data
"""
import sqlite3
import pandas as pd
from pathlib import Path

DATABASE_DIR = Path(__file__).parent.parent / "databases"
DB_PATH = DATABASE_DIR / "my_database.db"

print("=" * 100)
print("DEBUG: CHUNK AND CHANGE DETECTION ANALYSIS")
print("=" * 100)

# 1. Check content_repo records for Employee_Handbook.pdf
print("\n1. CONTENT_REPO RECORDS FOR Employee_Handbook.pdf:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    repo_df = pd.read_sql_query("""
        SELECT
            ud_source_file_id,
            raw_file_nme,
            raw_file_version_nbr,
            last_modified_dt,
            file_status
        FROM content_repo
        WHERE raw_file_nme = 'Employee_Handbook.pdf'
        ORDER BY raw_file_version_nbr
    """, conn)
    print(repo_df.to_string())
    print(f"\nTotal records: {len(repo_df)}")

# 2. Check ALL chunks for Employee_Handbook.pdf (any status)
print("\n\n2. ALL CHUNKS (including inactive) FOR Employee_Handbook.pdf:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    all_chunks_df = pd.read_sql_query("""
        SELECT
            cc.chunk_id,
            cc.ud_source_file_id,
            cr.raw_file_version_nbr,
            cc.chunk_index,
            cc.content_checksum,
            cc.status,
            LENGTH(cc.chunk_text) as chunk_length
        FROM content_chunks cc
        JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
        WHERE cr.raw_file_nme = 'Employee_Handbook.pdf'
        ORDER BY cr.raw_file_version_nbr, cc.chunk_index, cc.status
    """, conn)
    print(all_chunks_df.to_string())
    print(f"\nTotal chunks (all statuses): {len(all_chunks_df)}")

# 3. Check only ACTIVE chunks
print("\n\n3. ACTIVE CHUNKS ONLY FOR Employee_Handbook.pdf:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    active_chunks_df = pd.read_sql_query("""
        SELECT
            cc.chunk_id,
            cc.ud_source_file_id,
            cr.raw_file_version_nbr,
            cc.chunk_index,
            cc.content_checksum,
            LENGTH(cc.chunk_text) as chunk_length
        FROM content_chunks cc
        JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
        WHERE cr.raw_file_nme = 'Employee_Handbook.pdf'
          AND cc.status = 'active'
        ORDER BY cr.raw_file_version_nbr, cc.chunk_index
    """, conn)
    print(active_chunks_df.to_string())
    print(f"\nTotal active chunks: {len(active_chunks_df)}")

# 4. Get the latest detection run
print("\n\n4. LATEST DETECTION RUN:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    runs_df = pd.read_sql_query("""
        SELECT DISTINCT detection_run_id, created_dt
        FROM content_change_log
        ORDER BY created_dt DESC
        LIMIT 1
    """, conn)

    if len(runs_df) == 0:
        print("No detection runs found!")
        exit(0)

    latest_run = runs_df.iloc[0]['detection_run_id']
    print(f"Latest run: {latest_run}")
    print(f"Created: {runs_df.iloc[0]['created_dt']}")

# 5. What did the change detector analyze?
print("\n\n5. WHAT THE CHANGE DETECTOR SAW (from content_change_log):")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    changes_df = pd.read_sql_query("""
        SELECT
            change_type,
            current_checksum,
            previous_checksum,
            similarity_score,
            LENGTH(current_content) as current_length,
            LENGTH(previous_content) as previous_length
        FROM content_change_log
        WHERE detection_run_id = ?
          AND file_name = 'Employee_Handbook.pdf'
        ORDER BY change_type
    """, conn, params=[latest_run])
    print(changes_df.to_string())
    print(f"\nTotal change records: {len(changes_df)}")

# 6. Show unique checksums by version
print("\n\n6. UNIQUE CHECKSUMS BY VERSION:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    checksum_df = pd.read_sql_query("""
        SELECT
            cr.raw_file_version_nbr,
            COUNT(DISTINCT cc.content_checksum) as unique_checksums,
            GROUP_CONCAT(DISTINCT cc.content_checksum) as checksums
        FROM content_chunks cc
        JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
        WHERE cr.raw_file_nme = 'Employee_Handbook.pdf'
          AND cc.status = 'active'
        GROUP BY cr.raw_file_version_nbr
        ORDER BY cr.raw_file_version_nbr
    """, conn)
    print(checksum_df.to_string())

# 7. Show the actual text of chunks side by side
print("\n\n7. ACTUAL CHUNK TEXT:")
print("-" * 100)
with sqlite3.connect(DB_PATH) as conn:
    text_df = pd.read_sql_query("""
        SELECT
            cr.raw_file_version_nbr as version,
            cc.chunk_index,
            cc.content_checksum,
            cc.chunk_text
        FROM content_chunks cc
        JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
        WHERE cr.raw_file_nme = 'Employee_Handbook.pdf'
          AND cc.status = 'active'
        ORDER BY cr.raw_file_version_nbr, cc.chunk_index
    """, conn)

    for idx, row in text_df.iterrows():
        print(f"\n{'='*100}")
        print(f"VERSION {row['version']} | Chunk {row['chunk_index']} | Checksum: {row['content_checksum']}")
        print(f"{'='*100}")
        print(row['chunk_text'])

print("\n" + "=" * 100)
print("DEBUG COMPLETE")
print("=" * 100)
