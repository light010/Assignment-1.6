"""
Configuration management for Granular Impact Analysis.

Provides centralized configuration with validation, environment-based overrides,
and integration with Databricks secrets management.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from omegaconf import MISSING, OmegaConf


class SimilarityAlgorithm(str, Enum):
    """Supported similarity algorithms."""

    JACCARD = "jaccard"
    DIFFLIB = "difflib"
    BM25 = "bm25"
    # EMBEDDING removed in V9 - not suitable for change detection
    HYBRID = "hybrid"
    HYBRID_V8 = "hybrid_v8"  # V8: Optimized for modification detection
    POLICY_SIMILARITY = "policy_similarity_v8"  # V8: Policy content specialized


class ImpactLevel(str, Enum):
    """Impact severity levels."""

    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Environment(str, Enum):
    """Deployment environments."""

    DIT = "DIT"
    FIT = "FIT"
    PROD = "PROD"
    LOCAL = "LOCAL"


@dataclass
class SimilarityConfig:
    """Configuration for similarity algorithms."""

    # Primary algorithm to use
    algorithm: SimilarityAlgorithm = SimilarityAlgorithm.HYBRID_V8  # V8: Use optimized hybrid

    # Algorithm-specific thresholds (V8 updated)
    jaccard_threshold: float = 0.3
    difflib_threshold: float = 0.6
    bm25_threshold: float = 0.65
    # embedding_threshold removed in V9 - embeddings not suitable for change detection

    # V8: Modification detection threshold (recommended: 0.80-0.85)
    modification_threshold: float = 0.80

    # Hybrid algorithm weights (must sum to 1.0)
    # V8 DEFAULT: Balanced for general use with BM25 (TF-IDF deprecated - BM25 is strictly superior)
    hybrid_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "jaccard": 0.25,
            "difflib": 0.25,
            "bm25": 0.50,
        }
    )

    # V8: Modification detection weights (for HybridV8 or PolicyContentSimilarity)
    modification_detection_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "jaccard": 0.20,
            "difflib": 0.50,  # V8: Increased for "10"→"12" detection
            "bm25": 0.30,
        }
    )

    # V8: Early exit optimization
    early_exit_enabled: bool = True
    early_exit_threshold: float = 0.3  # Jaccard threshold for early exit

    # Embedding model configuration removed in V9 - embeddings not suitable for change detection
    # (Use BM25, Jaccard, and Difflib instead)

    # Text preprocessing
    lowercase: bool = True
    remove_punctuation: bool = True
    remove_stopwords: bool = True
    min_token_length: int = 2

    def __post_init__(self):
        """Validate configuration after initialization."""
        # Validate hybrid weights sum to 1.0
        if self.algorithm in [SimilarityAlgorithm.HYBRID, SimilarityAlgorithm.HYBRID_V8]:
            weight_sum = sum(self.hybrid_weights.values())
            if not (0.99 <= weight_sum <= 1.01):  # Allow small floating point error
                raise ValueError(
                    f"Hybrid weights must sum to 1.0, got {weight_sum}. "
                    f"Weights: {self.hybrid_weights}"
                )

        # V8: Validate modification detection weights
        mod_weight_sum = sum(self.modification_detection_weights.values())
        if not (0.99 <= mod_weight_sum <= 1.01):
            raise ValueError(
                f"Modification detection weights must sum to 1.0, got {mod_weight_sum}. "
                f"Weights: {self.modification_detection_weights}"
            )

        # Validate thresholds are in valid range
        for attr in [
            "jaccard_threshold",
            "difflib_threshold",
            "bm25_threshold",
            # "embedding_threshold" removed in V9 - embeddings not suitable for change detection
            "modification_threshold",
            "early_exit_threshold",
        ]:
            value = getattr(self, attr)
            if not (0.0 <= value <= 1.0):
                raise ValueError(f"{attr} must be between 0.0 and 1.0, got {value}")


@dataclass
class DiffConfig:
    """Configuration for diff analysis."""

    # Phrase extraction
    min_phrase_length: int = 3
    max_phrase_length: int = 10
    phrase_ngram_range: tuple = (1, 3)

    # Semantic detection patterns
    detect_numbers: bool = True
    detect_dates: bool = True
    detect_policies: bool = True
    detect_urls: bool = True
    detect_emails: bool = True

    # Change significance thresholds
    min_change_ratio: float = 0.05  # Minimum 5% change to be significant
    max_contextual_distance: int = 50  # Characters around a change to include as context


@dataclass
class ImpactConfig:
    """Configuration for impact analysis and scoring."""

    # Impact scoring weights
    similarity_weight: float = 0.40
    diff_magnitude_weight: float = 0.30
    semantic_importance_weight: float = 0.30

    # Impact level thresholds (cumulative score 0-1)
    none_threshold: float = 0.0
    low_threshold: float = 0.2
    medium_threshold: float = 0.5
    high_threshold: float = 0.75
    critical_threshold: float = 0.9

    # Auto-invalidation settings
    auto_invalidate_threshold: ImpactLevel = ImpactLevel.HIGH
    require_manual_review: bool = True

    def __post_init__(self):
        """Validate impact configuration."""
        # Validate weights sum to 1.0
        total_weight = (
            self.similarity_weight + self.diff_magnitude_weight + self.semantic_importance_weight
        )
        if not (0.99 <= total_weight <= 1.01):
            raise ValueError(f"Impact weights must sum to 1.0, got {total_weight}")


@dataclass
class DatabaseConfig:
    """Configuration for Databricks/Delta Lake database access."""

    # Catalog and schema
    catalog: str = MISSING
    schema: str = MISSING

    # Table names
    content_table: str = "content_repo"
    faq_table: str = "faq_qa_bank"
    impact_results_table: str = "faq_impact_results"
    audit_log_table: str = "faq_impact_audit_log"

    # Connection settings
    use_unity_catalog: bool = True
    enable_caching: bool = True
    cache_ttl_seconds: int = 300

    # Transaction settings
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    transaction_timeout_seconds: int = 300

    # Performance tuning
    batch_size: int = 1000
    partition_columns: List[str] = field(default_factory=lambda: ["content_id"])
    optimize_write: bool = True


@dataclass
class DetectionConfig:
    """Configuration for change detection."""

    # Checksum algorithm
    checksum_algorithm: str = "sha256"  # or "md5", "sha1"

    # Content tracking
    track_metadata_changes: bool = True
    track_content_changes: bool = True

    # Change detection window
    lookback_days: int = 30
    incremental_mode: bool = True


@dataclass
class WorkflowConfig:
    """Configuration for workflow orchestration."""

    # Execution mode
    dry_run: bool = False
    parallel_execution: bool = True
    max_workers: int = 4

    # Error handling
    fail_fast: bool = False
    continue_on_error: bool = True
    error_threshold: float = 0.1  # Max 10% error rate

    # Monitoring and logging
    enable_metrics: bool = True
    log_level: str = "INFO"
    log_to_file: bool = True
    log_to_databricks: bool = True


@dataclass
class GranularImpactConfig:
    """
    Main configuration class for Granular Impact Analysis.

    This class aggregates all configuration components and provides
    environment-based initialization and validation.
    """

    # Environment
    environment: Environment = Environment.LOCAL

    # Component configurations
    similarity: SimilarityConfig = field(default_factory=SimilarityConfig)
    diff: DiffConfig = field(default_factory=DiffConfig)
    impact: ImpactConfig = field(default_factory=ImpactConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    workflow: WorkflowConfig = field(default_factory=WorkflowConfig)

    # Databricks integration
    volume_base_path: Optional[str] = None
    secret_scope: Optional[str] = None

    @classmethod
    def from_yaml(cls, yaml_path: Path) -> "GranularImpactConfig":
        """
        Load configuration from YAML file.

        Args:
            yaml_path: Path to YAML configuration file

        Returns:
            GranularImpactConfig instance

        Raises:
            FileNotFoundError: If YAML file doesn't exist
            ValueError: If YAML is invalid
        """
        if not yaml_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {yaml_path}")

        conf = OmegaConf.load(yaml_path)
        return cls.from_omega_conf(conf)

    @classmethod
    def from_omega_conf(cls, conf: Any) -> "GranularImpactConfig":
        """
        Create configuration from OmegaConf object.

        Args:
            conf: OmegaConf configuration object

        Returns:
            GranularImpactConfig instance
        """
        # Convert OmegaConf to structured config
        schema = OmegaConf.structured(cls)
        merged = OmegaConf.merge(schema, conf)
        return OmegaConf.to_object(merged)

    @classmethod
    def from_environment(cls, env: Environment, **overrides) -> "GranularImpactConfig":
        """
        Create configuration for specific environment with optional overrides.

        Args:
            env: Target environment (DIT, FIT, PROD, LOCAL)
            **overrides: Additional configuration overrides

        Returns:
            GranularImpactConfig instance configured for environment
        """
        config = cls(environment=env)

        # Apply environment-specific defaults
        if env == Environment.DIT:
            config.database.catalog = "onedata_us_east_1_shared_dit"
            config.database.schema = "faq_service"
            config.volume_base_path = "/Volumes/onedata_us_east_1_shared_dit/faq_service"
            config.secret_scope = "faq_service_dit"
            config.workflow.log_level = "DEBUG"

        elif env == Environment.FIT:
            config.database.catalog = "onedata_us_east_1_shared_fit"
            config.database.schema = "faq_service"
            config.volume_base_path = "/Volumes/onedata_us_east_1_shared_fit/faq_service"
            config.secret_scope = "faq_service_fit"
            config.workflow.log_level = "INFO"

        elif env == Environment.PROD:
            config.database.catalog = "onedata_us_east_1_shared_prod"
            config.database.schema = "faq_service"
            config.volume_base_path = "/Volumes/onedata_us_east_1_shared_prod/faq_service"
            config.secret_scope = "faq_service_prod"
            config.workflow.log_level = "WARNING"
            config.workflow.fail_fast = True
            config.impact.require_manual_review = True

        elif env == Environment.LOCAL:
            config.database.catalog = "local_dev"
            config.database.schema = "faq_service"
            config.workflow.log_level = "DEBUG"
            config.workflow.dry_run = True

        # Apply overrides
        if overrides:
            config = cls._apply_overrides(config, overrides)

        return config

    @staticmethod
    def _apply_overrides(config: "GranularImpactConfig", overrides: Dict[str, Any]):
        """Apply dictionary overrides to configuration."""
        conf_dict = OmegaConf.structured(config)
        override_conf = OmegaConf.create(overrides)
        merged = OmegaConf.merge(conf_dict, override_conf)
        return OmegaConf.to_object(merged)

    def validate(self) -> None:
        """
        Validate the complete configuration.

        Raises:
            ValueError: If configuration is invalid
        """
        # Validate required database fields for non-local environments
        if self.environment != Environment.LOCAL:
            if self.database.catalog == MISSING:
                raise ValueError("database.catalog is required for non-local environments")
            if self.database.schema == MISSING:
                raise ValueError("database.schema is required for non-local environments")

        # Validate component configs
        self.similarity.__post_init__()
        self.impact.__post_init__()

        # Validate workflow settings
        if self.workflow.max_workers < 1:
            raise ValueError("workflow.max_workers must be >= 1")

        if not (0.0 <= self.workflow.error_threshold <= 1.0):
            raise ValueError("workflow.error_threshold must be between 0.0 and 1.0")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return OmegaConf.to_container(OmegaConf.structured(self), resolve=True)

    def save_yaml(self, output_path: Path) -> None:
        """
        Save configuration to YAML file.

        Args:
            output_path: Path where YAML should be saved
        """
        conf = OmegaConf.structured(self)
        with open(output_path, "w") as f:
            OmegaConf.save(conf, f)
