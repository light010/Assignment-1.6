"""
Tests for content_chunks table operations.

Test-driven development for the migration from content_checksums to content_chunks.
"""
import pytest
import sqlite3
import tempfile
from pathlib import Path
from datetime import datetime


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")  # Enable FK constraints

    # Create content_repo table (prerequisite for FK)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_version_nbr INTEGER NOT NULL,
            extracted_markdown_file_path TEXT,
            title_nme TEXT,
            file_status TEXT NOT NULL DEFAULT 'Active',
            created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create content_chunks table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ud_source_file_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            chunk_page_number INTEGER,
            chunk_start_char INTEGER,
            chunk_end_char INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
                ON DELETE CASCADE,
            UNIQUE(ud_source_file_id, content_checksum),
            CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
            CONSTRAINT chk_chunk_status CHECK (status IN ('active', 'archived', 'deleted'))
        )
    """)

    # Create indexes
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_chunks_checksum
        ON content_chunks(content_checksum)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_chunks_source_file
        ON content_chunks(ud_source_file_id)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_chunks_status
        ON content_chunks(status)
    """)

    conn.commit()
    yield db_path, conn
    conn.close()
    Path(db_path).unlink()


class TestContentChunksSchema:
    """Test content_chunks table schema."""

    def test_table_exists(self, temp_db):
        """Table content_chunks should exist."""
        db_path, conn = temp_db
        cursor = conn.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='content_chunks'
        """)
        assert cursor.fetchone() is not None

    def test_primary_key_is_chunk_id(self, temp_db):
        """Primary key should be chunk_id (auto-increment)."""
        db_path, conn = temp_db

        # Insert test file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert chunk without specifying chunk_id
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'test content')
        """, (file_id, 'a' * 64))

        # Verify auto-increment worked
        chunk_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        assert chunk_id == 1

    def test_foreign_key_to_content_repo(self, temp_db):
        """Should have foreign key to content_repo."""
        db_path, conn = temp_db

        # Try to insert chunk without valid file_id
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("""
                INSERT INTO content_chunks
                (ud_source_file_id, chunk_index, content_checksum, chunk_text)
                VALUES (999, 0, ?, 'test')
            """, ('a' * 64,))

    def test_unique_checksum_per_file_constraint(self, temp_db):
        """content_checksum should be unique per file (no duplicates within same file)."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert first chunk
        checksum = 'a' * 64
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'content 1')
        """, (file_id, checksum))
        conn.commit()

        # Try to insert chunk with same checksum in SAME file
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("""
                INSERT INTO content_chunks
                (ud_source_file_id, chunk_index, content_checksum, chunk_text)
                VALUES (?, 1, ?, 'content 2')
            """, (file_id, checksum))

    def test_same_checksum_allowed_across_files(self, temp_db):
        """Same checksum CAN appear in different files (shared boilerplate)."""
        db_path, conn = temp_db

        # Insert two different files
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('handbook.pdf', 1)
        """)
        file1_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('policy.pdf', 1)
        """)
        file2_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert chunk with same checksum in both files (shared boilerplate)
        shared_checksum = 'a' * 64
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'Confidential - Internal Use Only')
        """, (file1_id, shared_checksum))

        # This should succeed - same checksum in different file
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'Confidential - Internal Use Only')
        """, (file2_id, shared_checksum))
        conn.commit()

        # Verify both chunks exist
        count = conn.execute("""
            SELECT COUNT(*) FROM content_chunks WHERE content_checksum = ?
        """, (shared_checksum,)).fetchone()[0]
        assert count == 2

    def test_duplicate_chunk_index_allowed_with_different_checksums(self, temp_db):
        """Multiple chunks can have same index if checksums are different."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert chunk at index 0
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'content 1')
        """, (file_id, 'a' * 64))

        # Insert another chunk at index 0 with different checksum (this should succeed)
        # Note: This represents re-ingestion or overwriting chunks
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'content 2')
        """, (file_id, 'b' * 64))
        conn.commit()

        # Verify both chunks exist with same index
        count = conn.execute("""
            SELECT COUNT(*) FROM content_chunks
            WHERE ud_source_file_id = ? AND chunk_index = 0
        """, (file_id,)).fetchone()[0]
        assert count == 2

    def test_checksum_length_constraint(self, temp_db):
        """Checksum must be exactly 64 characters (SHA-256)."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Try short checksum
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("""
                INSERT INTO content_chunks
                (ud_source_file_id, chunk_index, content_checksum, chunk_text)
                VALUES (?, 0, 'short', 'content')
            """, (file_id,))

    def test_status_constraint(self, temp_db):
        """Status must be 'active', 'archived', or 'deleted'."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Try invalid status
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("""
                INSERT INTO content_chunks
                (ud_source_file_id, chunk_index, content_checksum, chunk_text, status)
                VALUES (?, 0, ?, 'content', 'invalid')
            """, (file_id, 'a' * 64))

    def test_cascade_delete(self, temp_db):
        """Deleting file should cascade delete chunks."""
        db_path, conn = temp_db

        # Insert file and chunk
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'content')
        """, (file_id, 'a' * 64))
        conn.commit()

        # Delete file
        conn.execute("DELETE FROM content_repo WHERE ud_source_file_id = ?", (file_id,))
        conn.commit()

        # Verify chunks deleted
        count = conn.execute("SELECT COUNT(*) FROM content_chunks").fetchone()[0]
        assert count == 0


class TestChunkIngestion:
    """Test chunk ingestion operations."""

    def test_insert_chunks_for_file(self, temp_db):
        """Should insert multiple chunks for a file."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('handbook.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert 3 chunks
        chunks = [
            (file_id, 0, 'a' * 64, 'Introduction text...'),
            (file_id, 1, 'b' * 64, 'Chapter 1 content...'),
            (file_id, 2, 'c' * 64, 'Chapter 2 content...'),
        ]

        for fid, idx, checksum, text in chunks:
            conn.execute("""
                INSERT INTO content_chunks
                (ud_source_file_id, chunk_index, content_checksum, chunk_text)
                VALUES (?, ?, ?, ?)
            """, (fid, idx, checksum, text))
        conn.commit()

        # Verify
        count = conn.execute("""
            SELECT COUNT(*) FROM content_chunks
            WHERE ud_source_file_id = ?
        """, (file_id,)).fetchone()[0]
        assert count == 3

    def test_retrieve_chunks_by_file_version(self, temp_db):
        """Should retrieve chunks for specific file version."""
        db_path, conn = temp_db

        # Insert v1 file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('handbook.pdf', 1)
        """)
        v1_file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert v2 file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('handbook.pdf', 2)
        """)
        v2_file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert chunks for v1
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'v1 content')
        """, (v1_file_id, 'a' * 64))

        # Insert chunks for v2
        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, 'v2 content')
        """, (v2_file_id, 'b' * 64))
        conn.commit()

        # Query v1 chunks
        v1_chunks = conn.execute("""
            SELECT cc.chunk_text
            FROM content_chunks cc
            JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
            WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 1
        """).fetchall()

        assert len(v1_chunks) == 1
        assert v1_chunks[0][0] == 'v1 content'

    def test_chunk_text_storage(self, temp_db):
        """Should store and retrieve chunk text accurately."""
        db_path, conn = temp_db

        # Insert file
        conn.execute("""
            INSERT INTO content_repo (raw_file_nme, raw_file_version_nbr)
            VALUES ('test.pdf', 1)
        """)
        file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Insert chunk with long text
        long_text = "Employee benefits include health insurance, dental, vision, 401k matching up to 5%, unlimited PTO, parental leave (16 weeks), mental health support, gym membership, and professional development budget of $2000/year."

        conn.execute("""
            INSERT INTO content_chunks
            (ud_source_file_id, chunk_index, content_checksum, chunk_text)
            VALUES (?, 0, ?, ?)
        """, (file_id, 'a' * 64, long_text))
        conn.commit()

        # Retrieve and verify
        retrieved = conn.execute("""
            SELECT chunk_text FROM content_chunks WHERE chunk_index = 0
        """).fetchone()[0]

        assert retrieved == long_text
