"""
Test script for the new LLM-friendly diff format.
Run this to see the difference between old and new formats.
"""

from granular_impact.similarity import DifflibSimilarityCalculator

# Sample FAQ texts
faq_original = """
# Employee Vacation Policy

## How many vacation days do employees receive?

Full-time employees receive **15 vacation days** per year. Vacation days accrue monthly
and can be used after 90 days of employment. Unused vacation days can be carried over
to the next year, up to a maximum of 5 days.
"""

faq_updated = """
# Employee Vacation Policy

## How many vacation days do employees receive?

Full-time employees receive **20 vacation days** per year. Vacation days accrue monthly
and can be used after 90 days of employment. Unused vacation days can be carried over
to the next year, up to a maximum of 10 days.
"""

# Create calculator
calc = DifflibSimilarityCalculator(lowercase=True, remove_punctuation=False)

print("=" * 80)
print("NEW LLM-FRIENDLY FORMAT")
print("=" * 80)
print()

# Character-level diff
llm_diff = calc.get_llm_friendly_diff(faq_original, faq_updated, max_context_chars=60)
print(llm_diff)

print("\n" + "=" * 80)
print("LINE-BASED LLM-FRIENDLY FORMAT")
print("=" * 80)
print()

# Line-level diff
llm_diff_lines = calc.get_llm_friendly_diff_line_based(faq_original, faq_updated, context_lines=1)
print(llm_diff_lines)

print("\n" + "=" * 80)
print("OLD UNIFIED DIFF FORMAT (for comparison)")
print("=" * 80)
print()

# Old format
unified_diff = calc.get_unified_diff(faq_original, faq_updated, context_lines=2)
for line in unified_diff:
    print(line)

print("\n" + "=" * 80)
print("WHICH ONE IS BETTER FOR LLM PROMPTS?")
print("=" * 80)
print("""
The LLM-friendly formats are much better because:
1. ✅ No confusing symbols (+, -, @@, etc.)
2. ✅ Clear BEFORE/AFTER labels
3. ✅ Shows only what changed with relevant context
4. ✅ Easy for humans AND LLMs to understand
5. ✅ Perfect for including in prompts

Use case: Pass this to an LLM to analyze policy changes, generate summaries,
or assess impact of modifications.
""")