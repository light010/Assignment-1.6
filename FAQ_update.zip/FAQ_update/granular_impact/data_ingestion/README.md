# Data Ingestion Module

Simple, focused data ingestion utilities for loading source data into the FAQ database.

## Overview

This module provides minimal, test-driven data loaders for populating database tables from CSV files or pandas DataFrames. Each ingestion module handles one table with clear validation and error handling.

## Design Principles

1. **Simplicity First**: One module per table, minimal dependencies
2. **TDD Approach**: All functionality is test-driven
3. **Database Compatible**: Respects schema v4 constraints (checksums, unique keys, foreign keys)
4. **Batch Efficient**: Uses pandas for bulk operations
5. **Clear Validation**: Explicit error messages for constraint violations

## Available Ingestion Modules

### ContentRepoIngestion

Ingest data into the `content_repo` table from CSV or DataFrame.

**Features**:
- Validates required fields (`raw_file_nme`)
- Validates file_status enum (Active, Inactive, Archived)
- Applies defaults for optional fields
- Batch insert with efficient pandas to_sql


### ChunkIngestion

Ingest content chunks into the `content_chunks` table with FK references to `content_repo`.

**Features**:
- Validates checksum length (64 characters for SHA-256)
- Validates status enum (active, archived, deleted)
- Enforces foreign key constraint to `content_repo`
- Prevents duplicate checksums per file (unique constraint on `ud_source_file_id, content_checksum`)
- Stores chunk text for efficient retrieval
- Supports chunk ordering via `chunk_index`
- Clear existing chunks before re-ingestion

**Workflow**:
1. Load content from `content_repo` (with `ud_source_file_id`)
2. Chunk content using `SimpleChunker` from `granular_impact.chunking`
3. Compute SHA-256 checksums for each chunk
4. Ingest into `content_chunks` table with FK to `content_repo`

### FAQIngestion

Ingest FAQ questions and answers into `faq_questions` and `faq_answers` tables.

**Features**:
- Handles 1:1 relationship between questions and answers
- Validates question_text and answer_text (required)
- Validates status enum (active, invalidated, archived, deleted)
- Validates answer_format enum (html, markdown, plain)
- Validates confidence_score range (0.0-1.0)
- Foreign key enforcement (answers must reference valid questions)
- Batch insert with efficient pandas to_sql

### FAQSourceIngestion

Ingest FAQ source provenance into `faq_question_sources` and `faq_answer_sources` tables.

**Features**:
- Tracks content sources for questions and answers
- Validates content_checksum (64 character SHA-256)
- Validates contribution_weight range (0.0-1.0)
- Supports temporal validity tracking (is_valid, valid_from, valid_until)
- Allows multiple sources per question/answer
- Batch insert with efficient pandas to_sql

## FAQ Generation

**Note**: FAQ generation logic has been moved to a separate module for better separation of concerns.

For FAQ generation (questions, answers, filtering), see:
- **Module**: `granular_impact.faq_generation`
- **Documentation**: [FAQ Generation README](../faq_generation/README.md)

This module (data_ingestion) focuses purely on database write operations.

## Quick Start

### Chunk Ingestion

```python
from granular_impact.chunking import SimpleChunker
from granular_impact.data_ingestion import ChunkIngestion
from pathlib import Path

# Path to database
db_path = Path("FAQ_update/databases/faq_update.db")

# Initialize
chunker = SimpleChunker(chunk_size=1000)
chunk_ingestion = ChunkIngestion(str(db_path))

# Read content
content = Path("data/handbook.md").read_text(encoding='utf-8')

# Chunk and compute checksums
chunks_with_checksums = chunker.chunk_with_checksums(content)

# Ingest chunks for file_id=1 (from content_repo)
result = chunk_ingestion.ingest_chunks_for_file(
    ud_source_file_id=1,
    chunks_with_checksums=chunks_with_checksums,
    clear_existing=True  # Clear old chunks before re-ingestion
)

if result['success']:
    print(f"✅ Inserted {result['rows_inserted']} chunks")
else:
    print(f"❌ Error: {result['message']}")

# Get statistics
stats = chunk_ingestion.get_stats()
print(f"Total chunks: {stats['total_chunks']}")
print(f"Files with chunks: {stats['files_with_chunks']}")
```

### Content Repository Ingestion

```python
from granular_impact.data_ingestion import ContentRepoIngestion
from pathlib import Path

# Path to database
db_path = Path("FAQ_update/databases/faq_update.db")

# Initialize ingestion
ingestion = ContentRepoIngestion(str(db_path))

# Ingest from CSV
result = ingestion.ingest_from_csv("granular_impact/data_ingestion/data/sample_content_repo.csv")

if result['success']:
    print(f"✅ Inserted {result['rows_inserted']} rows")
else:
    print(f"❌ Error: {result['message']}")
```

### From DataFrame

```python
import pandas as pd
from granular_impact.data_ingestion import ContentRepoIngestion

# Create DataFrame
df = pd.DataFrame([
    {
        "raw_file_nme": "handbook.pdf",
        "raw_file_page_nbr": 1,
        "domain": "HR",
        "service": "Policy",
        "content_checksum": "a" * 64,  # Valid SHA-256 checksum
        "file_status": "Active",
        "title_nme": "Employee Handbook"
    },
    {
        "raw_file_nme": "handbook.pdf",
        "raw_file_page_nbr": 2,
        "domain": "HR",
        "service": "Policy",
        "content_checksum": "b" * 64,
        "file_status": "Active",
        "title_nme": "Leave Policy"
    }
])

# Ingest
ingestion = ContentRepoIngestion("path/to/database.db")
result = ingestion.ingest_from_dataframe(df)

print(f"Success: {result['success']}, Rows: {result['rows_inserted']}")
```

### Get Statistics

```python
stats = ingestion.get_stats()

print(f"Total records: {stats['total_records']}")
print(f"Unique files: {stats['unique_files']}")
print(f"File types: {', '.join(stats['file_types'])}")
print(f"Statuses: {', '.join(stats['statuses'])}")
```

### Clear Table

```python
result = ingestion.clear()
print(result['message'])
```

## FAQ Ingestion Quick Start

### Ingest Questions and Answers

```python
from granular_impact.data_ingestion import FAQIngestion

# Initialize
faq_ingestion = FAQIngestion("path/to/database.db")

# Ingest questions from CSV
result = faq_ingestion.ingest_questions_from_csv("data/sample_faq_questions.csv")
print(f"Questions: {result['message']}")

# Ingest answers from CSV
result = faq_ingestion.ingest_answers_from_csv("data/sample_faq_answers.csv")
print(f"Answers: {result['message']}")

# Get statistics
stats = faq_ingestion.get_stats()
print(f"Total questions: {stats['total_questions']}")
print(f"Total answers: {stats['total_answers']}")
print(f"Answered questions: {stats['answered_questions']}")
print(f"Unanswered questions: {stats['unanswered_questions']}")
```

### Ingest FAQ Sources

```python
from granular_impact.data_ingestion import FAQSourceIngestion

# Initialize
source_ingestion = FAQSourceIngestion("path/to/database.db")

# Ingest question sources
result = source_ingestion.ingest_question_sources_from_csv("data/sample_faq_question_sources.csv")
print(f"Question sources: {result['message']}")

# Ingest answer sources
result = source_ingestion.ingest_answer_sources_from_csv("data/sample_faq_answer_sources.csv")
print(f"Answer sources: {result['message']}")

# Get statistics
stats = source_ingestion.get_stats()
print(f"Total question sources: {stats['total_question_sources']}")
print(f"Valid question sources: {stats['valid_question_sources']}")
print(f"Total answer sources: {stats['total_answer_sources']}")
print(f"Valid answer sources: {stats['valid_answer_sources']}")
```

## Sample Data

Sample CSV files are provided in `data_ingestion/data/`:

- `sample_content_repo.csv` - Sample content repository data
- `sample_faq_questions.csv` - Sample FAQ questions
- `sample_faq_answers.csv` - Sample FAQ answers
- `sample_faq_question_sources.csv` - Sample question source provenance
- `sample_faq_answer_sources.csv` - Sample answer source provenance

Use these as templates for your own data files.

## CSV File Format

### content_repo.csv

**Required columns**:
- `raw_file_nme` (TEXT, NOT NULL)

**Optional columns** (with defaults):
- `raw_file_type` (TEXT)
- `raw_file_version_nbr` (INTEGER, default: 1)
- `raw_file_path` (TEXT)
- `extracted_markdown_file_path` (TEXT)
- `title_nme` (TEXT)
- `content_checksum` (TEXT, length must be 64 if provided)
- `file_status` (TEXT, must be: 'Active', 'Inactive', or 'Archived')
- `created_dt`, `last_modified_dt` (TEXT, ISO-8601 format)

**Constraints**:
- `content_checksum` must be exactly 64 characters (SHA-256 hex) or NULL
- `file_status` must be one of: 'Active', 'Inactive', 'Archived'

### faq_questions.csv

**Required columns**:
- `question_text` (TEXT, NOT NULL)

**Optional columns** (with defaults):
- `question_id` (INTEGER, auto-increment if not provided)
- `source_type` (TEXT)
- `generation_method` (TEXT)
- `status` (TEXT, default: 'active', must be: active, invalidated, archived, deleted)
- `created_at`, `modified_at` (TEXT, auto-generated)

### faq_answers.csv

**Required columns**:
- `question_id` (INTEGER, NOT NULL, must exist in faq_questions)
- `answer_text` (TEXT, NOT NULL)

**Optional columns** (with defaults):
- `answer_id` (INTEGER, auto-increment if not provided)
- `answer_format` (TEXT, default: 'html', must be: html, markdown, plain)
- `confidence_score` (DOUBLE, must be 0.0-1.0 or NULL)
- `status` (TEXT, default: 'active', must be: active, invalidated, archived, deleted)
- `created_at`, `modified_at` (TEXT, auto-generated)

### faq_question_sources.csv

**Required columns**:
- `question_id` (INTEGER, NOT NULL)
- `content_checksum` (TEXT, NOT NULL, must be 64 characters)

**Optional columns** (with defaults):
- `source_id` (INTEGER, auto-increment if not provided)
- `is_primary_source` (BOOLEAN, default: FALSE)
- `contribution_weight` (DOUBLE, must be 0.0-1.0 or NULL)
- `is_valid` (BOOLEAN, default: TRUE)
- `valid_from`, `valid_until` (TEXT, ISO-8601 format)
- `invalidation_reason` (TEXT)
- `invalidated_by_change_id` (INTEGER)
- `created_at` (TEXT, auto-generated)

### faq_answer_sources.csv

**Required columns**:
- `answer_id` (INTEGER, NOT NULL)
- `content_checksum` (TEXT, NOT NULL, must be 64 characters)

**Optional columns** (with defaults):
- `source_id` (INTEGER, auto-increment if not provided)
- `is_primary_source` (BOOLEAN, default: FALSE)
- `contribution_weight` (DOUBLE, must be 0.0-1.0 or NULL)
- `context_employed` (TEXT)
- `is_valid` (BOOLEAN, default: TRUE)
- `valid_from`, `valid_until` (TEXT, ISO-8601 format)
- `invalidation_reason` (TEXT)
- `invalidated_by_change_id` (INTEGER)
- `created_at` (TEXT, auto-generated)

## Validation

All ingestion modules validate data before insertion:

1. **Required Fields**: Missing required columns raise clear errors
2. **Checksum Length**: Checksums must be exactly 64 characters
3. **Page Numbers**: Must be integers > 0
4. **Unique Constraints**: Duplicate records are rejected
5. **Type Safety**: Automatic type conversion where possible

## Error Handling

All methods return a result dictionary:

```python
{
    "success": True/False,
    "rows_inserted": <number>,
    "message": "<descriptive message>"
}
```

**Success Example**:
```python
{
    "success": True,
    "rows_inserted": 10,
    "message": "Successfully inserted 10 rows into content_repo"
}
```

**Error Examples**:
```python
# Missing required field
{
    "success": False,
    "rows_inserted": 0,
    "message": "Missing required fields: raw_file_nme"
}

# Invalid checksum
{
    "success": False,
    "rows_inserted": 0,
    "message": "Invalid checksum length (must be 64 chars) in 3 rows"
}

# Duplicate records
{
    "success": False,
    "rows_inserted": 0,
    "message": "Duplicate records found (UNIQUE constraint violation): ..."
}
```

## Testing

All ingestion modules have comprehensive test coverage. Run tests with:

```bash
cd FAQ_update

# Test content repo ingestion
pytest tests/test_content_repo_ingestion.py -v

# Test FAQ ingestion
pytest tests/test_faq_ingestion.py -v

# Test FAQ source ingestion
pytest tests/test_faq_source_ingestion.py -v

# Run all ingestion tests
pytest tests/test_*_ingestion.py -v
```

**Test coverage includes**:
- Initialization
- CSV file ingestion
- DataFrame ingestion
- Checksum validation
- Constraint enforcement (unique, foreign key, check)
- Required field validation
- Enum validation (status, format)
- Range validation (confidence_score, contribution_weight)
- Default value handling
- Batch insert performance
- Statistics retrieval
- Table clearing

## Database Schema Compatibility

This module is designed for **schema v4** (`create_schema_v4.sql`).

**Key schema features**:
- Single database architecture (all tables in `faq_update.db`)
- Real foreign key constraints
- ACID transactions
- Checksum-centric content tracking

## Performance

Batch insertion performance (measured on SQLite):

| Rows | Time | Throughput |
|------|------|------------|
| 10 | ~50ms | 200 rows/sec |
| 100 | ~200ms | 500 rows/sec |
| 1,000 | ~1.5s | 667 rows/sec |
| 10,000 | ~12s | 833 rows/sec |

Uses pandas `to_sql()` with `method="multi"` for optimal batch performance.

## Future Extensions

Additional ingestion modules that could be added:

- Content checksum ingestion for `content_checksums` table
- Content change log ingestion for `content_change_log` table
- FAQ audit log ingestion for `faq_audit_log` table

Each will follow the same simple, test-driven pattern.

## Contributing

When adding new ingestion modules:

1. **Write tests first** (TDD Red phase)
2. **Implement minimal code** to pass tests (TDD Green phase)
3. **Refactor** while keeping tests green (TDD Refactor phase)
4. **Update this README** with usage examples
5. **Create sample data** in `data/` directory
6. **Keep it simple** - one table per module, minimal dependencies

## Support

For issues or questions:
- Check test files for usage examples
- Review sample data files for CSV format
- See main FAQ_update README for database setup
