# Vacation Policy - Old Version

Employees accrue vacation time based on tenure.
0-2 years: 10 days per year.
3-5 years: 15 days per year.
6+ years: 20 days per year.
Vacation must be requested at least 2 weeks in advance.
Maximum carryover is 5 days per year.
Unused vacation is forfeited at year end.
Managers may deny requests during peak business periods.
