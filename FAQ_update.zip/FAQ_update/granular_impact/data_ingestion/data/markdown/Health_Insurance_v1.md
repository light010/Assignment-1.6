# Health Insurance Enrollment Policy

All full-time employees are eligible for health insurance benefits.
Enrollment period opens November 1st each year.
Coverage becomes effective on January 1st of the following year.
Employees may choose from three plan options: Basic, Standard, or Premium.
Dependents may be added to any plan for additional cost.
Pre-existing conditions are covered without waiting periods.
Claims should be submitted within 90 days of service.
Contact benefits@company.com for enrollment assistance.
