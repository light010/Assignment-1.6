# Employee Benefits Overview - Health Insurance

## Health Insurance Plans

Three plan options available: Basic, Standard, and Premium.

## Coverage

All plans include medical, dental, and vision coverage.

## Enrollment

Open enrollment period is November 1-30 each year.

## Dependents

Employees may add dependents to their health insurance plan.
