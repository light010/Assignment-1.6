# Business Travel Policy - Domestic and International

## Travel Approval

All business travel must be pre-approved by your manager.

## Airfare

Book economy class for domestic flights. Business class allowed for international flights over 6 hours.

## Hotels

Hotel accommodations should not exceed $200 per night domestic, $300 per night international.

## Meals

Meal reimbursement up to $50 per day for domestic travel, $75 per day for international travel.
