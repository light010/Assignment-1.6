# Annual Performance Review Process

## Review Cycle

Performance reviews are conducted annually in January.

## Self-Assessment

Employees complete self-assessment by January 15.

## Manager Review

Managers complete employee reviews by January 31.

## Review Meeting

One-on-one review meetings scheduled in February.

## Performance Ratings

Ratings: Exceeds Expectations, Meets Expectations, Needs Improvement.
