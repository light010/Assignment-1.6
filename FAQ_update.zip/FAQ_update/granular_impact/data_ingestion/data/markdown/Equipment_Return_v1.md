# Equipment Return Policy

All company equipment must be returned upon termination.
This includes laptops, monitors, keyboards, mice, and phones.
Equipment should be returned to IT within 3 business days.
Data will be wiped from all returned devices.
Failure to return equipment may result in final paycheck deduction.
Damaged equipment may be charged to the employee.
Remote employees should ship equipment to IT using prepaid labels.
Contact it@company.com for return instructions.
