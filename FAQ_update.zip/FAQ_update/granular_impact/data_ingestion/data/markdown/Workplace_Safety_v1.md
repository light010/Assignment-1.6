# Workplace Safety Guidelines - New Policy

## Safety First

Employee safety is our top priority.

## Emergency Procedures

Familiarize yourself with emergency exits and evacuation procedures.

## Incident Reporting

Report all workplace injuries or safety concerns to your manager immediately.

## Safety Training

All employees must complete annual safety training.

## Personal Protective Equipment

PPE must be worn in designated areas as posted.
