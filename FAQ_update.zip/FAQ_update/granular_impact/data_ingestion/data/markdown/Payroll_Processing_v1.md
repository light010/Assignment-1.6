# Payroll Processing Guide - Tax Withholding

## Pay Schedule

Employees are paid bi-weekly on Fridays.

## Tax Withholding

Federal, state, and local taxes are automatically withheld from paychecks.

## Direct Deposit

All employees must set up direct deposit for paycheck disbursement.

## Pay Stubs

Electronic pay stubs are available through the employee portal.
