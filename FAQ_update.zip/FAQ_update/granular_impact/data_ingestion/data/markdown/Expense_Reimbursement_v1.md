# Expense Reimbursement Policy - Submission Guidelines

## Expense Reports

Submit expense reports within 30 days of incurring the expense.

## Receipts Required

Receipts required for all expenses over $25.

## Approval Process

Expense reports must be approved by your direct manager.

## Reimbursement Timeline

Approved expenses are reimbursed within 2 weeks via direct deposit.
