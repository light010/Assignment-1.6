# Unlimited Vacation Policy - New Version

We are transitioning to an unlimited vacation policy.
Employees may take vacation time as needed with manager approval.
There is no accrual or carryover tracking.
We trust employees to manage their time responsibly.
Minimum recommended vacation is 3 weeks per year.
All vacation must be coordinated with your team.
Peak business periods may require restricted time off.
Policy effective March 1, 2025.
