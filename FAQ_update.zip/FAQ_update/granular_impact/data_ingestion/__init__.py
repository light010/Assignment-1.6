"""
Data ingestion module for granular impact analysis.

Provides simple, focused ingestion utilities for loading source data into the FAQ database.
Each ingestion module handles one or more related tables with minimal dependencies.

Modules:
- A_content_repo_ingestion: Load content_repo table from CSV/dataframe
- checksum_ingestion: Load content_checksums table (chunk checksums)
- content_repo_edit: Manage edited versions with automatic version tracking
- faq_ingestion: Load faq_questions and faq_answers tables from CSV/dataframe
- faq_source_ingestion: Load faq_question_sources and faq_answer_sources tables from CSV/dataframe
- faq_generation: Generate FAQs using oneailib pipeline (based on test2.yaml)
"""

from .A_content_repo_ingestion import ContentRepoIngestion
from .chunk_ingestion import ChunkIngestion
from .content_repo_edit import ContentRepoEditIngestion
from .faq_ingestion import FAQIngestion
from .faq_source_ingestion import FAQSourceIngestion

__all__ = [
    "ContentRepoIngestion",
    "ChunkIngestion",
    "ContentRepoEditIngestion",
    "FAQIngestion",
    "FAQSourceIngestion",
]
