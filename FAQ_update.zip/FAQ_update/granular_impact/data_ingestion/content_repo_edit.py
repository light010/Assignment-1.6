"""
Content repository edit ingestion - for managing updated/edited versions of content.

This module handles ingesting edited versions of content files, supporting the
change detection workflow where updated documents need version tracking.

Design Principles:
- Simplicity first: Builds on ContentRepoIngestion
- Version management: Increments version numbers automatically
- Status management: Marks old versions as Inactive, new as Active
- Change detection ready: Prepares data for comparison workflows

Typical Workflow:
1. Original file ingested: Employee_Handbook.pdf (v1, Active)
2. File is updated: Content changes
3. Use this script: Ingests v2, marks v1 as Inactive
4. Change detection: Compares v1 vs v2 checksums
"""

import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd

from .A_content_repo_ingestion import ContentRepoIngestion


class ContentRepoEditIngestion(ContentRepoIngestion):
    """
    Ingest edited versions of content files with version management.

    Extends ContentRepoIngestion to handle:
    - Automatic version increment
    - Status management (old=Inactive, new=Active)
    - Validation that base version exists
    """

    def ingest_edited_version(
        self,
        csv_path: str,
        auto_increment_version: bool = True,
        deactivate_previous: bool = True,
    ) -> Dict[str, Any]:
        """
        Ingest edited version of content from CSV.

        Args:
            csv_path: Path to CSV file with edited content
            auto_increment_version: If True, auto-increment raw_file_version_nbr
            deactivate_previous: If True, mark previous versions as Inactive

        Returns:
            Dict with success status, rows_inserted, version_updates, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_edited_dataframe(
                df,
                auto_increment_version=auto_increment_version,
                deactivate_previous=deactivate_previous,
            )
        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "version_updates": [],
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "version_updates": [],
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_edited_dataframe(
        self,
        df: pd.DataFrame,
        auto_increment_version: bool = True,
        deactivate_previous: bool = True,
    ) -> Dict[str, Any]:
        """
        Ingest edited version of content from DataFrame.

        Args:
            df: DataFrame with edited content
            auto_increment_version: If True, auto-increment raw_file_version_nbr
            deactivate_previous: If True, mark previous versions as Inactive

        Returns:
            Dict with success status, rows_inserted, version_updates, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "version_updates": [],
                    "message": validation_result["message"],
                }

            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                version_updates = []
                df_with_versions = df.copy()

                # Process each file
                if auto_increment_version:
                    for file_name in df["raw_file_nme"].unique():
                        # Get max version for this file
                        max_version = conn.execute(
                            "SELECT MAX(raw_file_version_nbr) FROM content_repo WHERE raw_file_nme = ?",
                            (file_name,)
                        ).fetchone()[0]

                        if max_version is None:
                            # File doesn't exist, treat as v1
                            new_version = 1
                        else:
                            new_version = max_version + 1

                        # Update version for this file in the dataframe
                        df_with_versions.loc[df_with_versions["raw_file_nme"] == file_name, "raw_file_version_nbr"] = new_version

                        version_updates.append({
                            "file_name": file_name,
                            "old_version": max_version,
                            "new_version": new_version,
                        })

                # Prepare DataFrame
                df_clean = self._prepare_dataframe(df_with_versions)

                # Ensure all new versions are Active
                df_clean["file_status"] = "Active"

                # Insert new versions
                df_clean.to_sql(
                    "content_repo",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)

                # Deactivate previous versions if requested
                if deactivate_previous:
                    for update in version_updates:
                        if update["old_version"] is not None:
                            conn.execute(
                                """UPDATE content_repo
                                   SET file_status = 'Inactive'
                                   WHERE raw_file_nme = ?
                                   AND raw_file_version_nbr < ?""",
                                (update["file_name"], update["new_version"])
                            )

                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "version_updates": version_updates,
                    "message": f"Successfully inserted {rows_inserted} edited versions",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "version_updates": [],
                    "message": f"Database constraint violation: {str(e)}",
                }
            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "version_updates": [],
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def get_version_history(self, file_name: str) -> List[Dict[str, Any]]:
        """
        Get version history for a specific file.

        Args:
            file_name: Name of the file to query

        Returns:
            List of version records sorted by version number (newest first)
        """
        conn = sqlite3.connect(self.db_path)

        try:
            cursor = conn.execute(
                """SELECT
                    raw_file_version_nbr,
                    title_nme,
                    content_checksum,
                    file_status,
                    created_dt,
                    last_modified_dt
                   FROM content_repo
                   WHERE raw_file_nme = ?
                   ORDER BY raw_file_version_nbr DESC""",
                (file_name,)
            )

            rows = cursor.fetchall()

            return [
                {
                    "version": row[0],
                    "title": row[1],
                    "checksum": row[2],
                    "status": row[3],
                    "created_at": row[4],
                    "modified_at": row[5],
                }
                for row in rows
            ]

        finally:
            conn.close()

    def compare_versions(
        self, file_name: str, old_version: int, new_version: int
    ) -> Dict[str, Any]:
        """
        Compare two versions of a file.

        Args:
            file_name: Name of the file
            old_version: Old version number
            new_version: New version number

        Returns:
            Dict with comparison data (checksums, titles, etc.)
        """
        conn = sqlite3.connect(self.db_path)

        try:
            old_record = conn.execute(
                """SELECT title_nme, content_checksum, file_status
                   FROM content_repo
                   WHERE raw_file_nme = ? AND raw_file_version_nbr = ?""",
                (file_name, old_version)
            ).fetchone()

            new_record = conn.execute(
                """SELECT title_nme, content_checksum, file_status
                   FROM content_repo
                   WHERE raw_file_nme = ? AND raw_file_version_nbr = ?""",
                (file_name, new_version)
            ).fetchone()

            if old_record is None or new_record is None:
                return {
                    "exists": False,
                    "message": "One or both versions not found",
                }

            checksum_changed = old_record[1] != new_record[1]
            title_changed = old_record[0] != new_record[0]

            return {
                "exists": True,
                "file_name": file_name,
                "old_version": {
                    "version": old_version,
                    "title": old_record[0],
                    "checksum": old_record[1],
                    "status": old_record[2],
                },
                "new_version": {
                    "version": new_version,
                    "title": new_record[0],
                    "checksum": new_record[1],
                    "status": new_record[2],
                },
                "changes": {
                    "checksum_changed": checksum_changed,
                    "title_changed": title_changed,
                    "content_changed": checksum_changed,  # Checksum change = content change
                },
            }

        finally:
            conn.close()
