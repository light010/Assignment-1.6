"""
FAQ data ingestion for questions and answers.

Simple, focused ingestion for faq_questions and faq_answers tables. Handles CSV files
and DataFrames with validation, batch inserts, and proper error handling.

Design Principles:
- Simplicity first: Handle Q&A pairs with proper FK relationships
- Database compatibility: Uses schema constraints (status, format, confidence checks)
- Validation: Required fields, enums, score ranges
- Batch efficiency: Uses pandas to_sql for performance
"""

import sqlite3
from pathlib import Path
from typing import Dict, Any
import pandas as pd


class FAQIngestion:
    """
    Ingest FAQ questions and answers from CSV or DataFrame.

    Validates data against schema constraints and provides simple batch insertion.
    Handles the 1:1 relationship between questions and answers.
    """

    def __init__(self, db_path: str):
        """
        Initialize ingestion with database path.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path

    # ============================================================================
    # QUESTIONS INGESTION
    # ============================================================================

    def ingest_questions_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest questions from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_questions_from_dataframe(df, clear_existing=clear_existing)

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_questions_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest questions from pandas DataFrame.

        Args:
            df: DataFrame with faq_questions columns
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_questions_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame
            df_clean = self._prepare_questions_dataframe(df)

            # Connect and insert
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute("DELETE FROM faq_questions")

                # Use pandas to_sql for efficient batch insert
                df_clean.to_sql(
                    "faq_questions",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)
                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} questions",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "check" in error_msg and "status" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid status (must be active, invalidated, archived, or deleted): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database constraint violation: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def _validate_questions_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate questions DataFrame against schema requirements.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str
        """
        # Check required fields
        required_fields = ["question_text"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate question_text is not null
        if df["question_text"].isna().any():
            return {
                "valid": False,
                "message": "question_text cannot be NULL",
            }

        # Validate status if present
        if "status" in df.columns:
            valid_statuses = ["active", "invalidated", "archived", "deleted"]
            invalid_status = df[
                df["status"].notna() & (~df["status"].isin(valid_statuses))
            ]
            if not invalid_status.empty:
                return {
                    "valid": False,
                    "message": f"Invalid status (must be active, invalidated, archived, or deleted) in {len(invalid_status)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_questions_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare questions DataFrame for insertion.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns
        """
        # Schema-valid columns
        schema_columns = [
            "question_id",
            "question_text",
            "source_type",
            "generation_method",
            "status",
            "created_at",
            "modified_at",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults
        if "status" not in df_clean.columns:
            df_clean["status"] = "active"
        elif df_clean["status"].isna().any():
            df_clean["status"] = df_clean["status"].fillna("active")

        return df_clean

    # ============================================================================
    # ANSWERS INGESTION
    # ============================================================================

    def ingest_answers_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest answers from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_answers_from_dataframe(df, clear_existing=clear_existing)

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_answers_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest answers from pandas DataFrame.

        Args:
            df: DataFrame with faq_answers columns
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_answers_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame
            df_clean = self._prepare_answers_dataframe(df)

            # Connect and insert
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute("DELETE FROM faq_answers")

                # Use pandas to_sql for efficient batch insert
                df_clean.to_sql(
                    "faq_answers",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)
                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} answers",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "foreign key" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid question_id (foreign key constraint): {str(e)}",
                    }
                elif "check" in error_msg and "status" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid status (must be active, invalidated, archived, or deleted): {str(e)}",
                    }
                elif "check" in error_msg and "format" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid answer_format (must be html, markdown, or plain): {str(e)}",
                    }
                elif "check" in error_msg and "confidence" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid confidence_score (must be 0.0-1.0): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database constraint violation: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def _validate_answers_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate answers DataFrame against schema requirements.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str
        """
        # Check required fields
        required_fields = ["question_id", "answer_text"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate required fields are not null
        if df["question_id"].isna().any():
            return {"valid": False, "message": "question_id cannot be NULL"}

        if df["answer_text"].isna().any():
            return {"valid": False, "message": "answer_text cannot be NULL"}

        # Validate status if present
        if "status" in df.columns:
            valid_statuses = ["active", "invalidated", "archived", "deleted"]
            invalid_status = df[
                df["status"].notna() & (~df["status"].isin(valid_statuses))
            ]
            if not invalid_status.empty:
                return {
                    "valid": False,
                    "message": f"Invalid status in {len(invalid_status)} rows",
                }

        # Validate answer_format if present
        if "answer_format" in df.columns:
            valid_formats = ["html", "markdown", "plain"]
            invalid_format = df[
                df["answer_format"].notna()
                & (~df["answer_format"].isin(valid_formats))
            ]
            if not invalid_format.empty:
                return {
                    "valid": False,
                    "message": f"Invalid answer_format (must be html, markdown, or plain) in {len(invalid_format)} rows",
                }

        # Validate confidence_score if present
        if "confidence_score" in df.columns:
            invalid_score = df[
                df["confidence_score"].notna()
                & ((df["confidence_score"] < 0.0) | (df["confidence_score"] > 1.0))
            ]
            if not invalid_score.empty:
                return {
                    "valid": False,
                    "message": f"Invalid confidence_score (must be 0.0-1.0) in {len(invalid_score)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_answers_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare answers DataFrame for insertion.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns
        """
        # Schema-valid columns
        schema_columns = [
            "answer_id",
            "question_id",
            "answer_text",
            "answer_format",
            "confidence_score",
            "status",
            "created_at",
            "modified_at",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults
        if "answer_format" not in df_clean.columns:
            df_clean["answer_format"] = "html"
        elif df_clean["answer_format"].isna().any():
            df_clean["answer_format"] = df_clean["answer_format"].fillna("html")

        if "status" not in df_clean.columns:
            df_clean["status"] = "active"
        elif df_clean["status"].isna().any():
            df_clean["status"] = df_clean["status"].fillna("active")

        return df_clean

    # ============================================================================
    # UTILITY METHODS
    # ============================================================================

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about ingested FAQs.

        Returns:
            Dict with stats: total_questions, total_answers, answered_questions, etc.
        """
        conn = sqlite3.connect(self.db_path)

        try:
            # Total questions
            total_questions = conn.execute(
                "SELECT COUNT(*) FROM faq_questions"
            ).fetchone()[0]

            # Total answers
            total_answers = conn.execute(
                "SELECT COUNT(*) FROM faq_answers"
            ).fetchone()[0]

            # Answered questions (questions with at least one answer)
            answered_questions = conn.execute(
                """
                SELECT COUNT(DISTINCT q.question_id)
                FROM faq_questions q
                INNER JOIN faq_answers a ON q.question_id = a.question_id
                """
            ).fetchone()[0]

            # Unanswered questions
            unanswered_questions = total_questions - answered_questions

            return {
                "total_questions": total_questions,
                "total_answers": total_answers,
                "answered_questions": answered_questions,
                "unanswered_questions": unanswered_questions,
            }

        finally:
            conn.close()

    def clear_questions(self) -> Dict[str, Any]:
        """
        Clear all records from faq_questions table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            conn.execute("DELETE FROM faq_questions")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared faq_questions table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }

    def clear_answers(self) -> Dict[str, Any]:
        """
        Clear all records from faq_answers table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            conn.execute("DELETE FROM faq_answers")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared faq_answers table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }
