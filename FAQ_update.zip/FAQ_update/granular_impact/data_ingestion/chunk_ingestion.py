"""
Content Chunks Ingestion

Simplified ingestion for content_chunks table.
Stores individual content chunks with their checksums and text.

Design Principles:
- Simplicity first: Direct chunk insertion with FK to content_repo
- No redundant storage: Links to content_repo instead of duplicating metadata
- Efficient: Stores chunk text to avoid re-chunking
"""

import sqlite3
from typing import Dict, Any, List, Tuple


class ChunkIngestion:
    """
    Ingest content chunks linked to files in content_repo.

    Stores chunks with their text content and checksums.
    """

    def __init__(self, db_path: str):
        """
        Initialize ingestion with database path.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path

    def ingest_chunks_for_file(
        self,
        ud_source_file_id: int,
        chunks_with_checksums: List[Tuple[str, str]],
        clear_existing: bool = False,
    ) -> Dict[str, Any]:
        """
        Ingest chunks for a specific file.

        Args:
            ud_source_file_id: Foreign key to content_repo
            chunks_with_checksums: List of (chunk_text, checksum) tuples
            clear_existing: If True, delete existing chunks for this file first

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute(
                        "DELETE FROM content_chunks WHERE ud_source_file_id = ?",
                        (ud_source_file_id,)
                    )

                # Insert chunks
                rows_inserted = 0
                for chunk_index, (chunk_text, checksum) in enumerate(chunks_with_checksums):
                    conn.execute("""
                        INSERT INTO content_chunks
                        (ud_source_file_id, chunk_index, content_checksum, chunk_text, status)
                        VALUES (?, ?, ?, ?, 'active')
                    """, (ud_source_file_id, chunk_index, checksum, chunk_text))
                    rows_inserted += 1

                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} chunks for file_id={ud_source_file_id}",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "foreign key" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid file_id {ud_source_file_id}: file not found in content_repo",
                    }
                elif "unique" in error_msg and "content_checksum" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Duplicate checksum found (content already exists): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database integrity error: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error: {str(e)}",
            }

    def get_chunks_for_file(
        self,
        ud_source_file_id: int,
        status: str = "active",
    ) -> List[Dict[str, Any]]:
        """
        Retrieve chunks for a specific file.

        Args:
            ud_source_file_id: Foreign key to content_repo
            status: Filter by status (default: 'active')

        Returns:
            List of dicts with chunk data
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row

        try:
            cursor = conn.execute("""
                SELECT
                    chunk_id,
                    ud_source_file_id,
                    chunk_index,
                    content_checksum,
                    chunk_text,
                    chunk_page_number,
                    created_at,
                    status
                FROM content_chunks
                WHERE ud_source_file_id = ? AND status = ?
                ORDER BY chunk_index
            """, (ud_source_file_id, status))

            return [dict(row) for row in cursor.fetchall()]

        finally:
            conn.close()

    def get_chunks_by_checksums(
        self,
        checksums: List[str],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Retrieve chunks by their checksums.

        Args:
            checksums: List of checksums to look up

        Returns:
            Dict mapping checksum to chunk data
        """
        if not checksums:
            return {}

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row

        try:
            placeholders = ','.join('?' * len(checksums))
            query = f"""
                SELECT
                    content_checksum,
                    chunk_text,
                    chunk_index,
                    ud_source_file_id
                FROM content_chunks
                WHERE content_checksum IN ({placeholders})
                  AND status = 'active'
            """

            cursor = conn.execute(query, checksums)
            return {row['content_checksum']: dict(row) for row in cursor.fetchall()}

        finally:
            conn.close()

    def clear_all_chunks(self) -> Dict[str, Any]:
        """
        Clear all chunks from table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("DELETE FROM content_chunks")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared content_chunks table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about stored chunks.

        Returns:
            Dict with counts and status breakdown
        """
        conn = sqlite3.connect(self.db_path)

        try:
            total = conn.execute("SELECT COUNT(*) FROM content_chunks").fetchone()[0]
            active = conn.execute(
                "SELECT COUNT(*) FROM content_chunks WHERE status = 'active'"
            ).fetchone()[0]

            files_with_chunks = conn.execute("""
                SELECT COUNT(DISTINCT ud_source_file_id)
                FROM content_chunks
                WHERE status = 'active'
            """).fetchone()[0]

            return {
                "total_chunks": total,
                "active_chunks": active,
                "files_with_chunks": files_with_chunks,
            }

        finally:
            conn.close()
