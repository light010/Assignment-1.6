"""
Content repository data ingestion.

Simple, focused ingestion for content_repo table. Handles CSV files and DataFrames
with validation, batch inserts, and proper error handling.

Design Principles:
- Simplicity first: One table, one responsibility
- Database compatibility: Uses schema v4 constraints
- Validation: Checksums, required fields, unique constraints
- Batch efficiency: Uses pandas to_sql for performance
"""

import sqlite3
from pathlib import Path
from typing import Dict, Any, Optional
import pandas as pd


class ContentRepoIngestion:
    """
    Ingest content_repo data from CSV or DataFrame.

    Validates data against schema v4 constraints and provides simple batch insertion.
    """

    def __init__(self, db_path: str):
        """
        Initialize ingestion with database path.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path

    def ingest_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest data from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_from_dataframe(df, clear_existing=clear_existing)

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest data from pandas DataFrame.

        Args:
            df: DataFrame with content_repo columns
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame
            df_clean = self._prepare_dataframe(df)

            # Connect and insert
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute("DELETE FROM content_repo")

                # Use pandas to_sql for efficient batch insert
                df_clean.to_sql(
                    "content_repo",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)
                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} rows into content_repo",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "unique" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Duplicate records found (UNIQUE constraint violation): {str(e)}",
                    }
                elif "check" in error_msg and "content_checksum" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid checksum length (must be 64 chars): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database constraint violation: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate DataFrame against schema requirements.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str
        """
        # Check required fields (per schema: only raw_file_nme is NOT NULL)
        required_fields = ["raw_file_nme"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate raw_file_nme is not null
        if df["raw_file_nme"].isna().any():
            return {
                "valid": False,
                "message": "raw_file_nme cannot be NULL",
            }

        # Validate checksums if present ('NA' is allowed as placeholder for pipeline computation)
        if "content_checksum" in df.columns:
            # Convert to string to avoid .str accessor issues with mixed types
            checksums = df["content_checksum"].astype(str)
            invalid_checksums = df[
                df["content_checksum"].notna()
                & (checksums != "NA")
                & (checksums != "nan")  # Handle NaN converted to string
                & (checksums.str.len() != 64)
            ]
            if not invalid_checksums.empty:
                return {
                    "valid": False,
                    "message": f"Invalid checksum length (must be 64 chars or 'NA') in {len(invalid_checksums)} rows",
                }

        # Validate file_status if present
        if "file_status" in df.columns:
            valid_statuses = ["Active", "Inactive", "Archived"]
            invalid_status = df[
                df["file_status"].notna()
                & (~df["file_status"].isin(valid_statuses))
            ]
            if not invalid_status.empty:
                return {
                    "valid": False,
                    "message": f"Invalid file_status (must be Active, Inactive, or Archived) in {len(invalid_status)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare DataFrame for insertion.

        Handles defaults, type conversions, and column ordering.
        Only keeps columns that exist in the schema.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns
        """
        # Schema-valid columns (from 00_content_repo.sql)
        schema_columns = [
            "raw_file_nme",
            "raw_file_type",
            "raw_file_version_nbr",
            "raw_file_path",
            "extracted_markdown_file_path",
            "title_nme",
            "content_checksum",
            "file_status",
            "created_dt",
            "last_modified_dt",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults for optional columns
        if "raw_file_version_nbr" not in df_clean.columns:
            df_clean["raw_file_version_nbr"] = 1
        elif df_clean["raw_file_version_nbr"].isna().any():
            df_clean["raw_file_version_nbr"] = df_clean["raw_file_version_nbr"].fillna(1)

        # Ensure timestamps are present (let DB handle defaults if missing)
        # We don't set them here - let the DB DEFAULT clause work

        return df_clean

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about ingested content.

        Returns:
            Dict with stats: total_records, unique_files, file_types, statuses
        """
        conn = sqlite3.connect(self.db_path)

        try:
            # Total records
            total = conn.execute("SELECT COUNT(*) FROM content_repo").fetchone()[0]

            # Unique files
            unique_files = conn.execute(
                "SELECT COUNT(DISTINCT raw_file_nme) FROM content_repo"
            ).fetchone()[0]

            # File types
            file_types_result = conn.execute(
                "SELECT DISTINCT raw_file_type FROM content_repo WHERE raw_file_type IS NOT NULL"
            ).fetchall()
            file_types = [row[0] for row in file_types_result]

            # File statuses
            statuses_result = conn.execute(
                "SELECT DISTINCT file_status FROM content_repo WHERE file_status IS NOT NULL"
            ).fetchall()
            statuses = [row[0] for row in statuses_result]

            return {
                "total_records": total,
                "unique_files": unique_files,
                "file_types": file_types,
                "statuses": statuses,
            }

        finally:
            conn.close()

    def clear(self) -> Dict[str, Any]:
        """
        Clear all records from content_repo table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            conn.execute("DELETE FROM content_repo")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared content_repo table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }
