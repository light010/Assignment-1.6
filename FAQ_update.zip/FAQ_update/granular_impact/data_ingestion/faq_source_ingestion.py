"""
FAQ source data ingestion for question and answer sources.

Simple, focused ingestion for faq_question_sources and faq_answer_sources tables.
Handles CSV files and DataFrames with validation, batch inserts, and proper error handling.

Design Principles:
- Simplicity first: Track provenance of questions and answers
- Database compatibility: Uses schema constraints (contribution weight 0.0-1.0, checksum length)
- Validation: Required fields, checksum format, weight ranges
- Temporal validity: Support for is_valid, valid_from, valid_until tracking
- Batch efficiency: Uses pandas to_sql for performance
"""

import sqlite3
from pathlib import Path
from typing import Dict, Any
import pandas as pd


class FAQSourceIngestion:
    """
    Ingest FAQ source provenance data from CSV or DataFrame.

    Validates data against schema constraints and provides simple batch insertion.
    Handles both question sources and answer sources with temporal validity tracking.
    """

    def __init__(self, db_path: str):
        """
        Initialize ingestion with database path.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path

    # ============================================================================
    # QUESTION SOURCES INGESTION
    # ============================================================================

    def ingest_question_sources_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest question sources from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_question_sources_from_dataframe(
                df, clear_existing=clear_existing
            )

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_question_sources_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest question sources from pandas DataFrame.

        Args:
            df: DataFrame with faq_question_sources columns
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_question_sources_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame
            df_clean = self._prepare_question_sources_dataframe(df)

            # Connect and insert
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute("DELETE FROM faq_question_sources")

                # Use pandas to_sql for efficient batch insert
                df_clean.to_sql(
                    "faq_question_sources",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)
                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} question sources",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "check" in error_msg and "contribution" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid contribution_weight (must be 0.0-1.0): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database constraint violation: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def _validate_question_sources_dataframe(
        self, df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        Validate question sources DataFrame against schema requirements.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str
        """
        # Check required fields
        required_fields = ["question_id", "content_checksum"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate required fields are not null
        if df["question_id"].isna().any():
            return {"valid": False, "message": "question_id cannot be NULL"}

        if df["content_checksum"].isna().any():
            return {"valid": False, "message": "content_checksum cannot be NULL"}

        # Validate checksum length (must be 64 chars for SHA256)
        invalid_checksums = df[
            df["content_checksum"].notna()
            & (df["content_checksum"].str.len() != 64)
        ]
        if not invalid_checksums.empty:
            return {
                "valid": False,
                "message": f"Invalid checksum length (must be 64 chars) in {len(invalid_checksums)} rows",
            }

        # Validate contribution_weight if present
        if "contribution_weight" in df.columns:
            invalid_weight = df[
                df["contribution_weight"].notna()
                & (
                    (df["contribution_weight"] < 0.0)
                    | (df["contribution_weight"] > 1.0)
                )
            ]
            if not invalid_weight.empty:
                return {
                    "valid": False,
                    "message": f"Invalid contribution_weight (must be 0.0-1.0) in {len(invalid_weight)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_question_sources_dataframe(
        self, df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Prepare question sources DataFrame for insertion.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns
        """
        # Schema-valid columns
        schema_columns = [
            "source_id",
            "question_id",
            "content_checksum",
            "is_primary_source",
            "contribution_weight",
            "is_valid",
            "valid_from",
            "valid_until",
            "invalidation_reason",
            "invalidated_by_change_id",
            "created_at",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults
        if "is_primary_source" not in df_clean.columns:
            df_clean["is_primary_source"] = False
        elif df_clean["is_primary_source"].isna().any():
            df_clean["is_primary_source"] = df_clean["is_primary_source"].fillna(
                False
            )

        if "is_valid" not in df_clean.columns:
            df_clean["is_valid"] = True
        elif df_clean["is_valid"].isna().any():
            df_clean["is_valid"] = df_clean["is_valid"].fillna(True)

        return df_clean

    # ============================================================================
    # ANSWER SOURCES INGESTION
    # ============================================================================

    def ingest_answer_sources_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest answer sources from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_answer_sources_from_dataframe(
                df, clear_existing=clear_existing
            )

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
            }

    def ingest_answer_sources_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest answer sources from pandas DataFrame.

        Args:
            df: DataFrame with faq_answer_sources columns
            clear_existing: If True, clear table before insert

        Returns:
            Dict with success status, rows_inserted, and message
        """
        try:
            # Validate required fields
            validation_result = self._validate_answer_sources_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame
            df_clean = self._prepare_answer_sources_dataframe(df)

            # Connect and insert
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            try:
                if clear_existing:
                    conn.execute("DELETE FROM faq_answer_sources")

                # Use pandas to_sql for efficient batch insert
                df_clean.to_sql(
                    "faq_answer_sources",
                    conn,
                    if_exists="append",
                    index=False,
                    method="multi",
                )

                rows_inserted = len(df_clean)
                conn.commit()

                return {
                    "success": True,
                    "rows_inserted": rows_inserted,
                    "message": f"Successfully inserted {rows_inserted} answer sources",
                }

            except sqlite3.IntegrityError as e:
                conn.rollback()
                error_msg = str(e).lower()

                if "check" in error_msg and "contribution" in error_msg:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Invalid contribution_weight (must be 0.0-1.0): {str(e)}",
                    }
                else:
                    return {
                        "success": False,
                        "rows_inserted": 0,
                        "message": f"Database constraint violation: {str(e)}",
                    }

            finally:
                conn.close()

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
            }

    def _validate_answer_sources_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate answer sources DataFrame against schema requirements.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str
        """
        # Check required fields
        required_fields = ["answer_id", "content_checksum"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate required fields are not null
        if df["answer_id"].isna().any():
            return {"valid": False, "message": "answer_id cannot be NULL"}

        if df["content_checksum"].isna().any():
            return {"valid": False, "message": "content_checksum cannot be NULL"}

        # Validate checksum length (must be 64 chars for SHA256)
        invalid_checksums = df[
            df["content_checksum"].notna()
            & (df["content_checksum"].str.len() != 64)
        ]
        if not invalid_checksums.empty:
            return {
                "valid": False,
                "message": f"Invalid checksum length (must be 64 chars) in {len(invalid_checksums)} rows",
            }

        # Validate contribution_weight if present
        if "contribution_weight" in df.columns:
            invalid_weight = df[
                df["contribution_weight"].notna()
                & (
                    (df["contribution_weight"] < 0.0)
                    | (df["contribution_weight"] > 1.0)
                )
            ]
            if not invalid_weight.empty:
                return {
                    "valid": False,
                    "message": f"Invalid contribution_weight (must be 0.0-1.0) in {len(invalid_weight)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_answer_sources_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare answer sources DataFrame for insertion.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns
        """
        # Schema-valid columns
        schema_columns = [
            "source_id",
            "answer_id",
            "content_checksum",
            "is_primary_source",
            "contribution_weight",
            "context_employed",
            "is_valid",
            "valid_from",
            "valid_until",
            "invalidation_reason",
            "invalidated_by_change_id",
            "created_at",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults
        if "is_primary_source" not in df_clean.columns:
            df_clean["is_primary_source"] = False
        elif df_clean["is_primary_source"].isna().any():
            df_clean["is_primary_source"] = df_clean["is_primary_source"].fillna(
                False
            )

        if "is_valid" not in df_clean.columns:
            df_clean["is_valid"] = True
        elif df_clean["is_valid"].isna().any():
            df_clean["is_valid"] = df_clean["is_valid"].fillna(True)

        return df_clean

    # ============================================================================
    # UTILITY METHODS
    # ============================================================================

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about ingested FAQ sources.

        Returns:
            Dict with stats: total sources, valid sources, etc.
        """
        conn = sqlite3.connect(self.db_path)

        try:
            # Question sources stats
            total_question_sources = conn.execute(
                "SELECT COUNT(*) FROM faq_question_sources"
            ).fetchone()[0]

            valid_question_sources = conn.execute(
                "SELECT COUNT(*) FROM faq_question_sources WHERE is_valid = 1"
            ).fetchone()[0]

            # Answer sources stats
            total_answer_sources = conn.execute(
                "SELECT COUNT(*) FROM faq_answer_sources"
            ).fetchone()[0]

            valid_answer_sources = conn.execute(
                "SELECT COUNT(*) FROM faq_answer_sources WHERE is_valid = 1"
            ).fetchone()[0]

            return {
                "total_question_sources": total_question_sources,
                "total_answer_sources": total_answer_sources,
                "valid_question_sources": valid_question_sources,
                "valid_answer_sources": valid_answer_sources,
            }

        finally:
            conn.close()

    def clear_question_sources(self) -> Dict[str, Any]:
        """
        Clear all records from faq_question_sources table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            conn.execute("DELETE FROM faq_question_sources")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared faq_question_sources table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }

    def clear_answer_sources(self) -> Dict[str, Any]:
        """
        Clear all records from faq_answer_sources table.

        Returns:
            Dict with success status and message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute("PRAGMA foreign_keys = ON")

            conn.execute("DELETE FROM faq_answer_sources")
            conn.commit()
            conn.close()

            return {
                "success": True,
                "message": "Successfully cleared faq_answer_sources table",
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Error clearing table: {str(e)}",
            }
