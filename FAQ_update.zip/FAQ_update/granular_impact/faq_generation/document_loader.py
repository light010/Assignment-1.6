"""
Document Loader for FAQ Generation

Loads documents from content_chunks table (with FK to content_repo) for FAQ generation.
Provides chunk-based document loading with metadata from source files.

Design Principles:
- Simple: Loads chunks directly from database
- Traceable: Each document links to source file via metadata
- Flexible: Supports status-based filtering

Author: Analytics Assist Team
Date: 2025-10-27
"""

import sqlite3
from pathlib import Path
from typing import List, Dict, Any

import pandas as pd


# ============================================================================
# Document Class
# ============================================================================


class Document:
    """Document class compatible with oneailib and FAQ generation."""

    def __init__(self, page_content: str, metadata: Dict[str, Any]):
        """
        Create a document with content and metadata.

        Args:
            page_content: The text content of the document
            metadata: Dictionary with checksum, source info, etc.
        """
        self.page_content = page_content
        self.metadata = metadata

    def __repr__(self):
        return f"Document(content_len={len(self.page_content)}, metadata={list(self.metadata.keys())})"


# ============================================================================
# Document Loader
# ============================================================================


class DocumentLoader:
    """
    Load documents from content_chunks table.

    Loads content chunks with metadata from content_repo via JOIN.
    Each chunk becomes a Document with:
    - page_content: The chunk text
    - metadata: checksum, source file info, chunk position, etc.

    Example:
        >>> loader = DocumentLoader(db_path="path/to/database.db")
        >>> documents = loader.load_documents(status_filter="active")
        >>> print(f"Loaded {len(documents)} chunks")
    """

    def __init__(self, db_path: str):
        """
        Initialize document loader.

        Args:
            db_path: Path to SQLite database with content_chunks table
        """
        self.db_path = db_path

    def load_documents(
        self,
        status_filter: str = "active",
    ) -> List[Document]:
        """
        Load documents from content_chunks table.

        Args:
            status_filter: Filter by status ('active', 'archived', 'deleted', or 'all')

        Returns:
            List of Document objects with chunk content and metadata

        Example:
            >>> loader = DocumentLoader("db.db")
            >>> docs = loader.load_documents(status_filter="active")
            >>> print(docs[0].page_content)
            'First chunk of content...'
            >>> print(docs[0].metadata['checksum'])
            'abc123...'
        """
        print(f"\n[DocumentLoader] Loading documents from content_chunks (status={status_filter})...")

        conn = sqlite3.connect(self.db_path)

        try:
            # Build query with JOIN to content_repo
            if status_filter == "all":
                query = """
                    SELECT
                        cc.chunk_id,
                        cc.chunk_index,
                        cc.content_checksum,
                        cc.chunk_text,
                        cc.status,
                        cr.raw_file_nme,
                        cr.raw_file_type,
                        cr.title_nme,
                        cr.raw_file_version_nbr
                    FROM content_chunks cc
                    JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                    ORDER BY cr.raw_file_nme, cc.chunk_index
                """
                df = pd.read_sql_query(query, conn)
            else:
                query = """
                    SELECT
                        cc.chunk_id,
                        cc.chunk_index,
                        cc.content_checksum,
                        cc.chunk_text,
                        cc.status,
                        cr.raw_file_nme,
                        cr.raw_file_type,
                        cr.title_nme,
                        cr.raw_file_version_nbr
                    FROM content_chunks cc
                    JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
                    WHERE cc.status = ?
                    ORDER BY cr.raw_file_nme, cc.chunk_index
                """
                df = pd.read_sql_query(query, conn, params=[status_filter])

            documents = []

            for _, row in df.iterrows():
                doc = Document(
                    page_content=row['chunk_text'],
                    metadata={
                        "checksum": row['content_checksum'],
                        "chunk_id": int(row['chunk_id']),
                        "chunk_index": int(row['chunk_index']),
                        "source_file": row['raw_file_nme'],
                        "title": row['title_nme'] if pd.notna(row['title_nme']) else 'Unknown',
                        "file_type": row['raw_file_type'] if pd.notna(row['raw_file_type']) else 'unknown',
                        "file_version": int(row['raw_file_version_nbr']),
                        "status": row['status'],
                    }
                )
                documents.append(doc)

            print(f"  ✓ Loaded {len(documents)} documents")
            return documents

        finally:
            conn.close()

    def get_document_count(self, status_filter: str = "active") -> int:
        """
        Get count of documents (chunks) in content_chunks table.

        Args:
            status_filter: Filter by status ('active', 'archived', 'deleted', or 'all')

        Returns:
            Number of chunks matching filter

        Example:
            >>> loader = DocumentLoader("db.db")
            >>> count = loader.get_document_count(status_filter="active")
            >>> print(f"Active chunks: {count}")
        """
        conn = sqlite3.connect(self.db_path)

        try:
            if status_filter == "all":
                query = "SELECT COUNT(*) FROM content_chunks"
                count = conn.execute(query).fetchone()[0]
            else:
                query = "SELECT COUNT(*) FROM content_chunks WHERE status = ?"
                count = conn.execute(query, [status_filter]).fetchone()[0]

            return count

        finally:
            conn.close()
