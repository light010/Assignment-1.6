# FAQ Generation Module

Generate FAQs from source documents using a multi-stage pipeline. This module is separate from data ingestion to support:
- Initial FAQ generation from new documents
- Re-generation after source document changes
- Bulk FAQ updates

## Overview

The FAQ generation module provides a clean separation between FAQ generation logic and database persistence. This is essential for:

1. **Initial Generation**: Generate FAQs when new documents are added
2. **Change Detection**: Re-generate FAQs when source documents change
3. **Bulk Updates**: Regenerate multiple FAQs efficiently
4. **Testing**: Test generation logic independently of database operations

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                   FAQ Generation Workflow                     │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  1. DocumentLoader                                            │
│     └─> Load from content_chunks table (JOIN content_repo)   │
│         └─> Each chunk becomes a Document                    │
│         └─> Filter by status (active/archived/deleted)       │
│                                                               │
│  2. FAQGenerator                                              │
│     ├─> Generate questions (Mock or LLM)                     │
│     ├─> Add metadata (IDs, versions, checksums)              │
│     ├─> Generate answers with context retrieval              │
│     ├─> Filter by confidence threshold                       │
│     └─> Map to database schema                               │
│                                                               │
│  3. FAQIngestion (data_ingestion module)                     │
│     └─> Persist to database (4 tables)                       │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

## Components

### DocumentLoader

Loads documents from `content_chunks` table with JOIN to `content_repo`.

**Key Changes**:
- ✅ Uses `content_chunks` table (not `content_checksums`)
- ✅ Each chunk is a Document with `chunk_text` as content
- ✅ Metadata includes FK to source file via `ud_source_file_id`

**Features**:
- Chunk-based document loading
- Status-based filtering (active, archived, deleted, all)
- Metadata from both `content_chunks` and `content_repo`
- JOIN ensures each chunk has source file context
- Ordered by file name and chunk index

### FAQGenerator

Generates questions and answers from documents.

**Pipeline Stages**:
1. **Generate Questions**: Create questions from document content (mock or LLM)
2. **Add Metadata**: Enrich with IDs, versions, and hash identifiers
3. **Generate Answers**: Create answers with context retrieval
4. **Filter & Validate**: Apply confidence thresholds and quality checks
5. **Map to Schema**: Convert to DataFrames for database ingestion

**Configuration Options**:
- LLM settings (model, temperature, tokens)
- Generation parameters (questions per document, mock mode)
- Filtering thresholds (confidence, length requirements)
- Database defaults (status, format)

### FAQGenerationConfig

Configuration dataclass for customizing generation behavior.

## Quick Start

### Complete Workflow (Questions + Answers)

```python
from granular_impact.faq_generation import (
    DocumentLoader,
    QuestionGenerator,
    AnswerGenerator,
)
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion

# Step 1: Load documents from database
db_path = "FAQ_update/databases/faq_update.db"
loader = DocumentLoader(db_path)
documents = loader.load_documents(status_filter="active")

# Step 2: Generate questions (returns DataFrames ready for ingestion)
q_gen = QuestionGenerator()
df_questions, df_q_sources = q_gen.generate_and_map(documents)

# Step 3: Generate answers (returns DataFrames ready for ingestion)
a_gen = AnswerGenerator()
a_gen.load_context_documents(documents)
# Need to reconstruct Question objects from df_questions for answer generation
from faq_generation import Question
questions = [
    Question(
        question_text=row['question_text'],
        source_checksum=df_q_sources[df_q_sources['question_id'] == i+1].iloc[0]['content_checksum']
    )
    for i, row in df_questions.iterrows()
]
df_answers, df_a_sources = a_gen.generate_and_map(questions)

# Step 4: Persist to database
faq_ingestion = FAQIngestion(db_path)
faq_source_ingestion = FAQSourceIngestion(db_path)

# Ingest questions
faq_ingestion.ingest_questions_from_dataframe(df_questions)
faq_source_ingestion.ingest_question_sources_from_dataframe(df_q_sources)

# Ingest answers
faq_ingestion.ingest_answers_from_dataframe(df_answers)
faq_source_ingestion.ingest_answer_sources_from_dataframe(df_a_sources)

print("✓ FAQs generated and ingested successfully")
```

### Question-Only Generation

```python
from granular_impact.faq_generation import DocumentLoader, QuestionGenerator
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion

# Load documents
loader = DocumentLoader(db_path)
documents = loader.load_documents()

# Generate questions only (no answers yet)
q_gen = QuestionGenerator()
df_questions, df_sources = q_gen.generate_and_map(documents)

# Ingest into database
faq_ing = FAQIngestion(db_path)
source_ing = FAQSourceIngestion(db_path)

faq_ing.ingest_questions_from_dataframe(df_questions)
source_ing.ingest_question_sources_from_dataframe(df_sources)

print(f"✓ Generated and stored {len(df_questions)} questions (answers deferred)")
```

### Answer-Only Generation (for existing questions)

```python
from granular_impact.faq_generation import AnswerGenerator, Question
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion

# Load existing questions from database
# (in real scenario, query from faq_questions table)
questions = [
    Question(
        question_id=1,
        question_text="What is the vacation policy?",
        source_checksum="abc123..."
    ),
    # ... more questions
]

# Generate answers
a_gen = AnswerGenerator()
a_gen.load_context_documents(documents)
df_answers, df_sources = a_gen.generate_and_map(questions)

# Ingest into database
faq_ing = FAQIngestion(db_path)
source_ing = FAQSourceIngestion(db_path)

faq_ing.ingest_answers_from_dataframe(df_answers)
source_ing.ingest_answer_sources_from_dataframe(df_sources)

print(f"✓ Generated {len(df_answers)} answers for existing questions")
```

### Re-generation After Document Changes

```python
from granular_impact.faq_generation import DocumentLoader, FAQGenerator
from granular_impact.detection import ContentChangeDetector

# Step 1: Detect changes
detector = ContentChangeDetector(db_path)
changes = detector.detect_changes_for_file("handbook.pdf")

# Step 2: Get affected content checksums
affected_checksums = [change.new_checksum for change in changes if change.requires_regeneration]

# Step 3: Load only affected documents
# (Would need to extend DocumentLoader to filter by checksums)
loader = DocumentLoader(db_path)
documents = loader.load_documents(status_filter="active")
affected_docs = [doc for doc in documents if doc.metadata['checksum'] in affected_checksums]

# Step 4: Re-generate FAQs for affected documents
generator = FAQGenerator()
results = generator.generate_faqs(affected_docs)

# Step 5: Update database
# (Invalidate old FAQs, insert new ones)
```

### Mock Mode (Loading from CSV)

Both QuestionGenerator and AnswerGenerator support mock mode, loading pre-generated FAQs from CSV files instead of making LLM calls:

#### Questions Only (Mock Mode)

```python
from granular_impact.faq_generation import QuestionGenerator, QuestionGeneratorConfig

# Configure for mock mode
config = QuestionGeneratorConfig(use_mock=True)
generator = QuestionGenerator(config)

# Load questions from CSV (documents parameter still required but ignored)
df_questions, df_sources = generator.generate_and_map(
    documents=documents,  # Ignored in mock mode
    deduplicate=False
)

# DataFrames are now ready for database ingestion
```

**CSV Files Used:**
- `granular_impact/data_ingestion/data/sample_faq_questions.csv` (14 questions)
- `granular_impact/data_ingestion/data/sample_faq_question_sources.csv` (17 sources)

#### Answers Only (Mock Mode)

```python
from granular_impact.faq_generation import AnswerGenerator, AnswerGeneratorConfig, Question

# Configure for mock mode
config = AnswerGeneratorConfig(use_mock=True)
generator = AnswerGenerator(config)
generator.load_context_documents(documents)

# Load answers from CSV (questions parameter still required but ignored)
df_answers, df_sources = generator.generate_and_map(
    questions=questions,  # Ignored in mock mode
    retrieve_context=False
)

# DataFrames are now ready for database ingestion
```

**CSV Files Used:**
- `granular_impact/data_ingestion/data/sample_faq_answers.csv` (14 answers)
- `granular_impact/data_ingestion/data/sample_faq_answer_sources.csv` (17 sources)

#### Complete Pipeline (Mock Mode)

```python
from granular_impact.faq_generation import (
    QuestionGenerator,
    QuestionGeneratorConfig,
    AnswerGenerator,
    AnswerGeneratorConfig,
    Question,
)
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion

# Step 1: Generate questions (mock mode)
q_config = QuestionGeneratorConfig(use_mock=True)
q_gen = QuestionGenerator(q_config)
df_questions, df_q_sources = q_gen.generate_and_map(documents)

# Step 2: Generate answers (mock mode)
a_config = AnswerGeneratorConfig(use_mock=True)
a_gen = AnswerGenerator(a_config)
a_gen.load_context_documents(documents)

# Convert DataFrame to Question objects
questions = [
    Question(
        question_text=row['question_text'],
        source_checksum=df_q_sources[df_q_sources['question_id'] == i+1].iloc[0]['content_checksum'],
        question_id=i+1
    )
    for i, row in df_questions.iterrows()
]

df_answers, df_a_sources = a_gen.generate_and_map(questions, retrieve_context=False)

# Step 3: Ingest into database
faq_ingestion = FAQIngestion(db_path)
source_ingestion = FAQSourceIngestion(db_path)

faq_ingestion.ingest_questions_from_dataframe(df_questions)
source_ingestion.ingest_question_sources_from_dataframe(df_q_sources)
faq_ingestion.ingest_answers_from_dataframe(df_answers)
source_ingestion.ingest_answer_sources_from_dataframe(df_a_sources)

print("✓ FAQs generated and ingested successfully")
```

**Benefits:**
- Fast testing without LLM API calls (instant results)
- Reproducible results for development
- Pre-validated data structure (14 Q&A pairs)
- Database-compatible schemas
- Ideal for CI/CD pipelines and local development

### Advanced Configuration

```python
from granular_impact.faq_generation import QuestionGeneratorConfig, QuestionGenerator

# Custom configuration for real LLM generation
config = QuestionGeneratorConfig(
    # LLM settings (for real LLM generation)
    api_base_url="https://your-openai-endpoint.com",
    chat_model_name="gpt-4",
    temperature=0.0,
    max_tokens=4000,

    # Generation settings
    n_questions_per_document=10,  # More questions per document
    use_mock=False,  # Use real LLM (when implemented)

    # Filtering thresholds
    min_question_length=10,
    max_question_length=500,
)

generator = QuestionGenerator(config=config)
```

### Debug Output

```python
from pathlib import Path

# Generate with debug output
generator = FAQGenerator()
results = generator.generate_faqs(documents)

# Save debug outputs
debug_dir = Path("debug_output")
generator.save_debug_outputs_to_file(debug_dir)

# Files created:
# - debug_output/01_after_generate_questions.json
# - debug_output/02_after_add_metadata.json
# - debug_output/03_after_generate_answers.json
# - debug_output/04_after_filter_and_validate.json
```

## Pipeline Stages Explained

### Stage 1: Generate Questions

Creates questions from document content using:
- **Mock mode**: Template-based questions for testing
- **LLM mode**: Real question generation using GPT-4 (TODO)

**Output**: Documents with `question` metadata

### Stage 2: Add Metadata

Enriches documents with:
- `document_id`: Sequential ID
- `version`: Version number (default: 1)
- `hash_id`: SHA-256 hash of question text

### Stage 3: Generate Answers

Creates answers using document context:
- Matches questions to source documents via checksums
- Retrieves full document content as context
- Generates answers (mock or LLM)
- Tracks context metadata for provenance

**Output**: Documents with `answer`, `confidence_score`, `context_metadata`

### Stage 4: Filter and Validate

Applies quality filters:
- Minimum answer length check
- Minimum question length check
- Confidence threshold check
- Invalid answer detection ("I do not have enough information")

**Output**: Filtered list of valid FAQ documents

### Stage 5: Map to Database Schema

Converts documents to DataFrames matching database schema:
- **faq_questions**: Question text, metadata
- **faq_answers**: Answer text, format, confidence
- **faq_question_sources**: Question-to-content provenance
- **faq_answer_sources**: Answer-to-content provenance with context

## Integration with Data Ingestion

The FAQ generation module produces DataFrames that are ready for ingestion:

```python
# Generate FAQs
from granular_impact.faq_generation import DocumentLoader, FAQGenerator
loader = DocumentLoader(db_path)
generator = FAQGenerator()
df_q, df_a, df_qs, df_as = generator.generate_faqs(loader.load_documents())

# Ingest results
from granular_impact.data_ingestion import FAQIngestion, FAQSourceIngestion
faq_ing = FAQIngestion(db_path)
source_ing = FAQSourceIngestion(db_path)

faq_ing.ingest_questions_from_dataframe(df_q)
faq_ing.ingest_answers_from_dataframe(df_a)
source_ing.ingest_question_sources_from_dataframe(df_qs)
source_ing.ingest_answer_sources_from_dataframe(df_as)
```

## Testing

The module includes comprehensive test coverage:

```bash
# Run FAQ generation tests
pytest tests/test_faq_generation_pipeline.py -v

# Run specific test class
pytest tests/test_faq_generation_pipeline.py::TestLoadDocumentsFromChecksumTable -v
```

## Design Principles

1. **Separation of Concerns**: Generation logic separate from persistence
2. **Reusability**: Use for initial generation and re-generation
3. **Testability**: Mock mode for fast testing without LLM calls
4. **Checksum-Centric**: Content identity based on SHA-256 checksums
5. **Schema Compliance**: Output ready for database ingestion
6. **Debugging**: Intermediate outputs saved for troubleshooting

## Future Enhancements

- [ ] Real LLM integration with oneailib
- [ ] Embedding generation for semantic search
- [ ] Context retrieval from OpenSearch
- [ ] Deduplication of similar questions
- [ ] Question ranking and prioritization
- [ ] Multi-document answer synthesis
- [ ] Answer quality scoring
- [ ] A/B testing support

## See Also

- [Data Ingestion Module](../data_ingestion/README.md) - For persisting generated FAQs
- [Detection Module](../detection/README.md) - For detecting content changes
- [Impact Module](../impact/README.md) - For analyzing FAQ impact after changes
