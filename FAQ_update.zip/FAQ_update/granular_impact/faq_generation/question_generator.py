"""
Question Generator

Generates questions from source content (documents, user queries, manual input).
Completely independent of answer generation.

Use Cases:
1. Generate questions from new documents
2. Generate questions from document changes
3. Process user-submitted questions
4. Handle manually curated questions

Outputs:
- List[Question]: Question objects for programmatic use
- OR DataFrames: Ready for database ingestion (faq_questions, faq_question_sources)

Author: Analytics Assist Team
Date: 2025-10-26
"""

import hashlib
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import pandas as pd

from .document_loader import Document


# ============================================================================
# Enums
# ============================================================================


class QuestionSource(str, Enum):
    """Source types for questions."""
    FROM_DOCUMENTS = "from_documents"
    FROM_USER_QUERIES = "from_user_queries"
    FROM_MANUAL = "from_manual"
    FROM_VALIDATION = "from_validation"


class GenerationMethod(str, Enum):
    """Question generation methods."""
    LLM_GENERATED = "llm_generated"
    HUMAN_WRITTEN = "human_written"
    EXTRACTED = "extracted"
    MOCK = "mock_generated"


# ============================================================================
# Configuration
# ============================================================================


@dataclass
class QuestionGeneratorConfig:
    """Configuration for question generation."""

    # LLM settings
    api_base_url: str = "YOUR_AZURE_OPENAI_ENDPOINT"
    chat_model_name: str = "gpt-4"
    temperature: float = 0.0
    max_tokens: int = 2000

    # Generation settings
    n_questions_per_document: int = 5
    use_mock: bool = True

    # Filtering
    min_question_length: int = 5
    max_question_length: int = 500

    # Metadata
    default_status: str = "active"
    source_type: QuestionSource = QuestionSource.FROM_DOCUMENTS


# ============================================================================
# Question Data Model
# ============================================================================


@dataclass
class Question:
    """
    Represents a generated question.

    Independent of answers - can exist without an answer.
    """
    question_text: str
    source_checksum: str  # Checksum of source content

    # Metadata
    question_id: Optional[int] = None  # Assigned later by database
    source_type: QuestionSource = QuestionSource.FROM_DOCUMENTS
    generation_method: GenerationMethod = GenerationMethod.LLM_GENERATED
    status: str = "active"
    confidence_score: Optional[float] = None

    # Provenance
    source_file: Optional[str] = None
    source_title: Optional[str] = None

    # Additional metadata
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "question_id": self.question_id,
            "question_text": self.question_text,
            "source_type": self.source_type.value,
            "generation_method": self.generation_method.value,
            "status": self.status,
            "source_checksum": self.source_checksum,
            "source_file": self.source_file,
            "source_title": self.source_title,
            "confidence_score": self.confidence_score,
        }

    def __repr__(self):
        return f"Question(text='{self.question_text[:50]}...', source={self.source_checksum[:8]})"


# ============================================================================
# Question Generator
# ============================================================================


class QuestionGenerator:
    """
    Generate questions from source content.

    Completely independent of answer generation. Questions can:
    - Be generated and stored without answers
    - Be answered later by AnswerGenerator
    - Come from different sources (documents, users, manual)
    """

    def __init__(self, config: Optional[QuestionGeneratorConfig] = None):
        """Initialize question generator."""
        self.config = config or QuestionGeneratorConfig()

    def compute_checksum(self, content: str) -> str:
        """Compute SHA-256 checksum."""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()

    # ------------------------------------------------------------------------
    # Generate from Documents
    # ------------------------------------------------------------------------

    def generate_from_documents(self, documents: List[Document]) -> List[Question]:
        """
        Generate questions from documents.

        Args:
            documents: List of Document objects

        Returns:
            List of Question objects (no answers)
        """
        print(f"\n[QuestionGenerator] Generating questions from {len(documents)} documents...")

        questions = []

        if self.config.use_mock:
            print("  ⚠️  Using MOCK question generation")
            questions = self._generate_mock_questions(documents)
        else:
            print("  ✓ Using real LLM question generation")
            questions = self._generate_llm_questions(documents)

        # Filter by length
        questions = self._filter_questions(questions)

        print(f"  ✓ Generated {len(questions)} questions")
        return questions

    def _generate_mock_questions(self, documents: List[Document]) -> List[Question]:
        """Generate mock questions for testing."""
        questions = []

        for doc in documents:
            title = doc.metadata.get('title', 'Unknown')
            checksum = doc.metadata.get('checksum')
            source_file = doc.metadata.get('source_file')

            # Generate mock questions
            mock_question_templates = [
                f"What is the policy for {title.lower()}?",
                f"How do I comply with {title.lower()}?",
                f"When should I follow {title.lower()}?",
                f"Who is responsible for {title.lower()}?",
                f"What are the requirements for {title.lower()}?",
            ]

            for i, template in enumerate(mock_question_templates[:self.config.n_questions_per_document]):
                question = Question(
                    question_text=template,
                    source_checksum=checksum,
                    source_type=self.config.source_type,
                    generation_method=GenerationMethod.MOCK,
                    source_file=source_file,
                    source_title=title,
                    confidence_score=0.9,
                    metadata={
                        "template_index": i,
                        "document_index": documents.index(doc),
                    }
                )
                questions.append(question)

        return questions

    def _generate_llm_questions(self, documents: List[Document]) -> List[Question]:
        """Generate questions using LLM."""
        # TODO: Implement real LLM generation
        raise NotImplementedError("Real LLM question generation not yet implemented")

    # ------------------------------------------------------------------------
    # Generate from User Queries
    # ------------------------------------------------------------------------

    def generate_from_user_queries(self, queries: List[str]) -> List[Question]:
        """
        Generate questions from user search queries.

        Args:
            queries: List of user queries

        Returns:
            List of Question objects
        """
        print(f"\n[QuestionGenerator] Processing {len(queries)} user queries...")

        questions = []

        for query in queries:
            # Compute checksum of the query itself
            query_checksum = self.compute_checksum(query)

            question = Question(
                question_text=query,
                source_checksum=query_checksum,
                source_type=QuestionSource.FROM_USER_QUERIES,
                generation_method=GenerationMethod.HUMAN_WRITTEN,
                confidence_score=1.0,  # User-written, high confidence
                metadata={"original_query": query}
            )
            questions.append(question)

        print(f"  ✓ Processed {len(questions)} user queries")
        return questions

    # ------------------------------------------------------------------------
    # Generate from Manual Input
    # ------------------------------------------------------------------------

    def generate_from_manual(
        self,
        questions_data: List[Dict[str, Any]]
    ) -> List[Question]:
        """
        Generate questions from manually curated input.

        Args:
            questions_data: List of dicts with question data

        Returns:
            List of Question objects
        """
        print(f"\n[QuestionGenerator] Processing {len(questions_data)} manual questions...")

        questions = []

        for data in questions_data:
            question_text = data.get('question_text')
            source_checksum = data.get('source_checksum')

            if not question_text or not source_checksum:
                print(f"  ⚠️  Skipping invalid question: {data}")
                continue

            question = Question(
                question_text=question_text,
                source_checksum=source_checksum,
                source_type=QuestionSource.FROM_MANUAL,
                generation_method=GenerationMethod.HUMAN_WRITTEN,
                source_file=data.get('source_file'),
                source_title=data.get('source_title'),
                confidence_score=1.0,
                metadata=data.get('metadata', {})
            )
            questions.append(question)

        print(f"  ✓ Processed {len(questions)} manual questions")
        return questions

    # ------------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------------

    def _filter_questions(self, questions: List[Question]) -> List[Question]:
        """
        Filter questions by quality criteria.

        Args:
            questions: List of questions to filter

        Returns:
            Filtered list of questions
        """
        initial_count = len(questions)

        valid_questions = []
        for q in questions:
            # Length check
            if len(q.question_text) < self.config.min_question_length:
                continue
            if len(q.question_text) > self.config.max_question_length:
                continue

            valid_questions.append(q)

        filtered_count = initial_count - len(valid_questions)
        if filtered_count > 0:
            print(f"  ✓ Filtered out {filtered_count} invalid questions")

        return valid_questions

    # ------------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------------

    def deduplicate_questions(
        self,
        questions: List[Question],
        similarity_threshold: float = 0.95
    ) -> List[Question]:
        """
        Deduplicate similar questions.

        Args:
            questions: List of questions
            similarity_threshold: Threshold for considering questions duplicates

        Returns:
            Deduplicated list of questions
        """
        print(f"\n[QuestionGenerator] Deduplicating {len(questions)} questions...")

        # Simple deduplication by exact text match
        # TODO: Implement semantic similarity deduplication
        seen_texts = set()
        unique_questions = []

        for q in questions:
            text_lower = q.question_text.lower().strip()
            if text_lower not in seen_texts:
                seen_texts.add(text_lower)
                unique_questions.append(q)

        duplicates = len(questions) - len(unique_questions)
        if duplicates > 0:
            print(f"  ✓ Removed {duplicates} duplicate questions")

        return unique_questions

    # ------------------------------------------------------------------------
    # Schema Mapping (for Database Ingestion)
    # ------------------------------------------------------------------------

    def to_dataframes(
        self,
        questions: List[Question]
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Convert questions to DataFrames for database ingestion.

        Returns TWO DataFrames:
        1. faq_questions: For faq_questions table
        2. faq_question_sources: For faq_question_sources table

        Args:
            questions: List of Question objects

        Returns:
            Tuple of (faq_questions_df, faq_question_sources_df)
        """
        print(f"\n[QuestionGenerator] Mapping {len(questions)} questions to database schema...")

        # Map to faq_questions table
        questions_data = []
        for q in questions:
            questions_data.append({
                'question_text': q.question_text,
                'source_type': q.source_type.value,
                'generation_method': q.generation_method.value,
                'status': q.status,
            })

        df_questions = pd.DataFrame(questions_data)

        # Map to faq_question_sources table
        sources_data = []
        for i, q in enumerate(questions, 1):
            if q.source_checksum:
                sources_data.append({
                    'question_id': i,  # Temporary ID (will be reassigned by DB)
                    'content_checksum': q.source_checksum,
                    'is_primary_source': True,
                    'contribution_weight': 1.0,
                    'is_valid': True,
                })

        df_sources = pd.DataFrame(sources_data)

        print(f"  ✓ faq_questions: {len(df_questions)} rows")
        print(f"  ✓ faq_question_sources: {len(df_sources)} rows")

        return df_questions, df_sources

    # ------------------------------------------------------------------------
    # Complete Pipeline (Questions → DataFrames)
    # ------------------------------------------------------------------------

    def generate_and_map(
        self,
        documents: List[Document],
        deduplicate: bool = True
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Complete pipeline: Generate questions AND map to DataFrames.

        This is the primary method for database ingestion workflow.

        When use_mock=True: Loads pre-generated questions from CSV files
        When use_mock=False: Generates questions using LLM

        Args:
            documents: List of Document objects
            deduplicate: Whether to deduplicate questions

        Returns:
            Tuple of (faq_questions_df, faq_question_sources_df)

        Example:
            >>> q_gen = QuestionGenerator()
            >>> df_questions, df_sources = q_gen.generate_and_map(documents)
            >>> # Ready for ingestion
            >>> faq_ingestion.ingest_questions_from_dataframe(df_questions)
            >>> faq_source_ingestion.ingest_question_sources_from_dataframe(df_sources)
        """
        print("\n" + "=" * 80)
        print("  QUESTION GENERATION PIPELINE")
        print("=" * 80)

        # MOCK MODE: Load from CSV files
        if self.config.use_mock:
            print("  ⚠️  MOCK MODE: Loading questions from CSV files")
            df_questions, df_sources = self._load_mock_csv_data()

            print("\n" + "=" * 80)
            print("  READY FOR DATABASE INGESTION (LOADED FROM CSV)")
            print(f"    faq_questions: {len(df_questions)} rows")
            print(f"    faq_question_sources: {len(df_sources)} rows")
            print("=" * 80)

            return df_questions, df_sources

        # REAL MODE: Generate using LLM
        # Generate questions
        questions = self.generate_from_documents(documents)

        # Deduplicate
        if deduplicate:
            questions = self.deduplicate_questions(questions)

        # Map to DataFrames
        df_questions, df_sources = self.to_dataframes(questions)

        print("\n" + "=" * 80)
        print("  READY FOR DATABASE INGESTION")
        print(f"    faq_questions: {len(df_questions)} rows")
        print(f"    faq_question_sources: {len(df_sources)} rows")
        print("=" * 80)

        return df_questions, df_sources

    def _load_mock_csv_data(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load mock FAQ data from CSV files.

        Loads from:
        - data/sample_faq_questions.csv
        - data/sample_faq_question_sources.csv

        Returns:
            Tuple of (faq_questions_df, faq_question_sources_df)
        """
        # Determine data folder path
        # Path: granular_impact/faq_generation -> granular_impact/data_ingestion/data
        current_dir = Path(__file__).parent
        data_folder = current_dir.parent / "data_ingestion" / "data"

        questions_csv = data_folder / "sample_faq_questions.csv"
        sources_csv = data_folder / "sample_faq_question_sources.csv"

        # Verify files exist
        if not questions_csv.exists():
            raise FileNotFoundError(
                f"Mock data file not found: {questions_csv}\n"
                f"Please ensure sample_faq_questions.csv exists in {data_folder}"
            )
        if not sources_csv.exists():
            raise FileNotFoundError(
                f"Mock data file not found: {sources_csv}\n"
                f"Please ensure sample_faq_question_sources.csv exists in {data_folder}"
            )

        print(f"  ✓ Loading questions from: {questions_csv.name}")
        print(f"  ✓ Loading sources from: {sources_csv.name}")

        # Load CSV files
        df_questions_raw = pd.read_csv(questions_csv)
        df_sources_raw = pd.read_csv(sources_csv)

        # Map to database schema (drop question_id from questions, keep for sources)
        # Database will auto-generate question_id on insert
        df_questions = df_questions_raw[["question_text", "source_type", "generation_method", "status"]].copy()

        # For sources, keep relevant columns (source_id will be auto-generated by DB)
        df_sources = df_sources_raw[[
            "question_id",
            "content_checksum",
            "is_primary_source",
            "contribution_weight",
            "is_valid"
        ]].copy()

        # Optional columns that may be in CSV
        if "invalidation_reason" in df_sources_raw.columns:
            df_sources["invalidation_reason"] = df_sources_raw["invalidation_reason"]
        if "invalidated_by_change_id" in df_sources_raw.columns:
            df_sources["invalidated_by_change_id"] = df_sources_raw["invalidated_by_change_id"]

        print(f"  ✓ Loaded {len(df_questions)} questions")
        print(f"  ✓ Loaded {len(df_sources)} question sources")

        return df_questions, df_sources
