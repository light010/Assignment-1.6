"""
FAQ Generation Module

Generates FAQs from source documents with separated question and answer generation.

Architecture:
- Question generation and answer generation are INDEPENDENT
- Use them separately for maximum flexibility
- Supports different workflows (initial generation, re-generation, etc.)

Key Components:
- DocumentLoader: Load documents from content_checksums table
- QuestionGenerator: Generate ONLY questions (no answers)
- AnswerGenerator: Generate ONLY answers (no questions)

Typical Workflows:

1. Question-Only Generation:
   from faq_generation import QuestionGenerator
   q_gen = QuestionGenerator()
   questions = q_gen.generate_from_documents(documents)

2. Answer-Only Generation:
   from faq_generation import AnswerGenerator
   a_gen = AnswerGenerator()
   a_gen.load_context_documents(documents)
   answers = a_gen.generate_answers(questions)

3. Complete FAQ Generation (Sequential):
   from faq_generation import QuestionGenerator, AnswerGenerator

   # Step 1: Generate questions
   q_gen = QuestionGenerator()
   questions = q_gen.generate_from_documents(documents)

   # Step 2: Generate answers
   a_gen = AnswerGenerator()
   a_gen.load_context_documents(documents)
   answers = a_gen.generate_answers(questions)

Author: Analytics Assist Team
Date: 2025-10-26
"""

from .document_loader import Document, DocumentLoader
from .question_generator import (
    QuestionGenerator,
    QuestionGeneratorConfig,
    Question,
    QuestionSource,
    GenerationMethod,
)
from .answer_generator import (
    AnswerGenerator,
    AnswerGeneratorConfig,
    Answer,
    AnswerFormat,
    Context,
)

__all__ = [
    # Document loading
    "Document",
    "DocumentLoader",
    # Question generation
    "QuestionGenerator",
    "QuestionGeneratorConfig",
    "Question",
    "QuestionSource",
    "GenerationMethod",
    # Answer generation
    "AnswerGenerator",
    "AnswerGeneratorConfig",
    "Answer",
    "AnswerFormat",
    "Context",
]
