# FAQ Generation Architecture

## Overview

The FAQ generation module follows a **separation of concerns** principle, with **completely independent** question and answer generation.

## Why Separate Question and Answer Generation?

### Different Lifecycles

```
Questions ─────────────┐
                       │
                       ├──► Questions can exist WITHOUT answers
                       │
                       ├──► Questions from DIFFERENT sources:
                       │    - Documents
                       │    - User queries
                       │    - Manual curation
                       │
Answers ───────────────┘

```

### Different Triggers

| Trigger | Question Generation | Answer Generation |
|---------|---------------------|-------------------|
| **New document added** | ✅ Generate questions | ✅ Generate answers |
| **Document changes** | ✅ Regenerate questions | ✅ Regenerate answers |
| **User submits question** | ❌ No generation needed | ✅ Generate answer only |
| **Improve answer quality** | ❌ No generation needed | ✅ Regenerate answers |
| **Defer answering** | ✅ Generate questions | ❌ Answer later |

### Real-World Scenarios

#### Scenario A: New Document Added
```python
# 1. Load new document
documents = loader.load_documents()

# 2. Generate questions
q_gen = QuestionGenerator()
questions = q_gen.generate_from_documents(documents)

# 3. Defer answer generation (batch later)
# Store questions in DB without answers
```

#### Scenario B: Document Changes
```python
# 1. Detect changed documents
changed_checksums = ["abc123...", "def456..."]

# 2. Regenerate questions for changed content
new_questions = q_gen.generate_from_documents(changed_documents)

# 3. Regenerate answers
a_gen = AnswerGenerator()
a_gen.load_context_documents(changed_documents)
new_answers = a_gen.generate_answers(new_questions)
```

#### Scenario C: User Question (No Document)
```python
# User submits: "What is the vacation policy?"
# NO document loading, NO question generation

# Just answer it
a_gen = AnswerGenerator()
a_gen.load_context_documents(all_documents)
answer = a_gen.answer_single_question(
    question_text="What is the vacation policy?",
    question_id=12345
)
```

#### Scenario D: Improve Answer Quality
```python
# Questions already exist, just regenerate answers

# 1. Load existing questions from DB
existing_questions = [...]  # From database

# 2. Regenerate answers with better context/model
a_gen = AnswerGenerator(config=improved_config)
a_gen.load_context_documents(documents)
new_answers = a_gen.generate_answers(existing_questions)
```

## Module Architecture

```
faq_generation/
├── document_loader.py       # Load from content_checksums
│   └── DocumentLoader
│
├── question_generator.py    # ONLY question generation
│   ├── QuestionGenerator
│   ├── Question (data model)
│   └── QuestionGeneratorConfig
│
├── answer_generator.py      # ONLY answer generation
│   ├── AnswerGenerator
│   ├── Answer (data model)
│   └── AnswerGeneratorConfig
│
├── orchestrator.py          # Convenience workflows
│   └── FAQOrchestrator
│
└── generator.py             # LEGACY (backward compatibility)
    └── FAQGenerator
```

## Design Principles

### 1. Independence

```python
# ✅ GOOD: Use independently
q_gen = QuestionGenerator()
questions = q_gen.generate_from_documents(docs)

a_gen = AnswerGenerator()
answers = a_gen.generate_answers(questions)

# ✅ ALSO GOOD: Use orchestrator for convenience
orchestrator = FAQOrchestrator()
questions, answers = orchestrator.generate_complete_faqs(docs)
```

### 2. Stateless Generators

```python
# Each generator is stateless
q_gen = QuestionGenerator()

# Can be reused
questions1 = q_gen.generate_from_documents(docs_batch1)
questions2 = q_gen.generate_from_documents(docs_batch2)
questions3 = q_gen.generate_from_user_queries(user_queries)
```

### 3. Clear Data Models

```python
# Question: Independent entity
@dataclass
class Question:
    question_text: str
    source_checksum: str
    # NO answer field
    # Can exist without answer

# Answer: References question
@dataclass
class Answer:
    answer_text: str
    question_text: str  # Reference
    source_checksums: List[str]  # Provenance
```

## Workflows

### Workflow 1: Complete Generation (Initial)

```python
from faq_generation import FAQOrchestrator, DocumentLoader

# Load documents
loader = DocumentLoader(db_path)
documents = loader.load_documents(status_filter="active")

# Generate both questions and answers
orchestrator = FAQOrchestrator()
questions, answers = orchestrator.generate_complete_faqs(documents)

# Persist to database
from data_ingestion import FAQIngestion, FAQSourceIngestion
faq_ing = FAQIngestion(db_path)
# ... ingest questions and answers
```

### Workflow 2: Question-Only (Deferred Answering)

```python
from faq_generation import QuestionGenerator

# Generate questions only
q_gen = QuestionGenerator()
questions = q_gen.generate_from_documents(documents)

# Store questions in DB without answers
# Answer later when ready
```

### Workflow 3: Answer-Only (User Question)

```python
from faq_generation import AnswerGenerator

# User asks question
user_question = "What is the vacation policy?"

# Generate answer only (no question generation)
a_gen = AnswerGenerator()
a_gen.load_context_documents(documents)
answer = a_gen.answer_single_question(
    question_text=user_question,
    question_id=None  # New question
)
```

### Workflow 4: Re-generation After Changes

```python
from faq_generation import FAQOrchestrator

# Documents changed
changed_checksums = detect_changes(...)

# Regenerate both
orchestrator = FAQOrchestrator()
new_questions, new_answers = orchestrator.regenerate_after_document_change(
    changed_checksums=changed_checksums,
    documents=new_documents
)

# Invalidate old FAQs, insert new ones
```

### Workflow 5: Batch Answer Generation

```python
# Many questions, expensive to answer
# Generate questions first, batch answer later

# Step 1: Generate ALL questions
questions = []
for doc_batch in document_batches:
    batch_questions = q_gen.generate_from_documents(doc_batch)
    questions.extend(batch_questions)

# Step 2: Batch answer generation (queue/async)
a_gen = AnswerGenerator()
a_gen.load_context_documents(all_documents)

# Process in batches
for question_batch in batch(questions, size=100):
    answers = a_gen.generate_answers(question_batch)
    # Store answers
```

## Benefits

### 1. **Flexibility**
- Use question generation without answer generation
- Use answer generation without question generation
- Combine as needed

### 2. **Scalability**
- Question generation: Lightweight, can generate thousands
- Answer generation: Heavy (LLM calls), can batch/queue
- Different scaling strategies for each

### 3. **Reusability**
- Same question generator for: documents, user queries, manual
- Same answer generator for: new questions, existing questions, re-generation

### 4. **Testability**
- Test question generation independently
- Test answer generation independently
- Mock one, test the other

### 5. **Cost Optimization**
- Generate questions cheaply
- Defer expensive answer generation
- Regenerate answers only when needed

## Data Flow

```
                    ┌──────────────────┐
                    │   Documents      │
                    │  (checksum_table)│
                    └────────┬─────────┘
                             │
                    ┌────────▼─────────┐
                    │ DocumentLoader   │
                    └────────┬─────────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
     ┌────────▼─────────┐        ┌─────────▼────────┐
     │QuestionGenerator │        │ User Queries     │
     └────────┬─────────┘        │ Manual Input     │
              │                  └─────────┬────────┘
              │                            │
              └──────────┬─────────────────┘
                         │
                  ┌──────▼──────┐
                  │  Questions  │ ◄── Can exist WITHOUT answers
                  │ (independent)│
                  └──────┬──────┘
                         │
                  ┌──────▼──────────┐
                  │ AnswerGenerator │
                  └──────┬──────────┘
                         │
                   ┌─────▼─────┐
                   │  Answers  │
                   │(+ sources)│
                   └───────────┘
```

## Legacy Support

The old `FAQGenerator` is still available for backward compatibility:

```python
# Legacy (still works)
from faq_generation import FAQGenerator
generator = FAQGenerator()
results = generator.generate_faqs(documents)

# But prefer new architecture:
from faq_generation import FAQOrchestrator
orchestrator = FAQOrchestrator()
questions, answers = orchestrator.generate_complete_faqs(documents)
```

## Future Enhancements

- [ ] Real LLM integration for both generators
- [ ] Semantic search for context retrieval
- [ ] Question deduplication using embeddings
- [ ] Answer quality scoring
- [ ] Multi-document answer synthesis
- [ ] A/B testing for generation strategies
- [ ] Async/batch processing for answers
- [ ] Question ranking and prioritization
