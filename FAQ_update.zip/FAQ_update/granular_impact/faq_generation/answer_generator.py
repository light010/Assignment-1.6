"""
Answer Generator

Generates answers for existing questions using context retrieval.
Completely independent of question generation.

Use Cases:
1. Generate answers for newly created questions
2. Regenerate answers when source documents change
3. Improve answer quality for existing questions
4. Answer user-submitted questions

Outputs:
- List[Answer]: Answer objects for programmatic use
- OR DataFrames: Ready for database ingestion (faq_answers, faq_answer_sources)

Author: Analytics Assist Team
Date: 2025-10-26
"""

import hashlib
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import pandas as pd

from .question_generator import Question
from .document_loader import Document


# ============================================================================
# Enums
# ============================================================================


class AnswerFormat(str, Enum):
    """Answer text formats."""
    HTML = "html"
    MARKDOWN = "markdown"
    PLAIN = "plain"


# ============================================================================
# Configuration
# ============================================================================


@dataclass
class AnswerGeneratorConfig:
    """Configuration for answer generation."""

    # LLM settings
    api_base_url: str = "YOUR_AZURE_OPENAI_ENDPOINT"
    chat_model_name: str = "gpt-4"
    temperature: float = 0.0
    max_tokens: int = 4000

    # Generation settings
    use_mock: bool = True
    default_answer_format: AnswerFormat = AnswerFormat.HTML

    # Context retrieval
    max_context_chunks: int = 5
    context_chunk_size: int = 1000

    # Filtering
    confidence_threshold: float = 0.85
    min_answer_length: int = 10
    max_answer_length: int = 5000

    # Metadata
    default_status: str = "active"


# ============================================================================
# Answer Data Model
# ============================================================================


@dataclass
class Answer:
    """
    Represents a generated answer.

    Linked to a Question via question_id/question_text.
    Tracks source provenance through content_checksums.
    """
    answer_text: str
    question_text: str  # For reference

    # IDs (assigned later)
    answer_id: Optional[int] = None
    question_id: Optional[int] = None

    # Quality metrics
    confidence_score: float = 0.9
    answer_format: AnswerFormat = AnswerFormat.HTML
    status: str = "active"

    # Provenance - which content was used
    source_checksums: List[str] = field(default_factory=list)
    context_employed: Optional[str] = None  # Actual context text used

    # Metadata
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "answer_id": self.answer_id,
            "question_id": self.question_id,
            "answer_text": self.answer_text,
            "answer_format": self.answer_format.value,
            "confidence_score": self.confidence_score,
            "status": self.status,
        }

    def get_sources_for_db(self) -> List[Dict[str, Any]]:
        """Get source provenance for faq_answer_sources table."""
        sources = []
        for i, checksum in enumerate(self.source_checksums):
            sources.append({
                "content_checksum": checksum,
                "is_primary_source": (i == 0),
                "contribution_weight": 1.0 / len(self.source_checksums) if self.source_checksums else 0.0,
                "context_employed": self.context_employed[:500] if i == 0 else None,  # First 500 chars
                "is_valid": True,
            })
        return sources

    def __repr__(self):
        return f"Answer(text='{self.answer_text[:50]}...', confidence={self.confidence_score})"


# ============================================================================
# Context Data Model
# ============================================================================


@dataclass
class Context:
    """Represents retrieved context for answering a question."""
    checksum: str
    content: str
    relevance_score: float = 1.0
    source_file: Optional[str] = None


# ============================================================================
# Answer Generator
# ============================================================================


class AnswerGenerator:
    """
    Generate answers for questions using context retrieval.

    Completely independent of question generation. Can:
    - Answer newly generated questions
    - Re-answer existing questions
    - Answer user-submitted questions
    - Use different context sources (documents, OpenSearch, etc.)
    """

    def __init__(self, config: Optional[AnswerGeneratorConfig] = None):
        """Initialize answer generator."""
        self.config = config or AnswerGeneratorConfig()
        self.documents: Dict[str, Document] = {}  # Checksum -> Document mapping

    def load_context_documents(self, documents: List[Document]):
        """
        Load documents to use as context for answering.

        Args:
            documents: List of Document objects
        """
        print(f"\n[AnswerGenerator] Loading {len(documents)} context documents...")
        self.documents = {
            doc.metadata['checksum']: doc
            for doc in documents
        }
        print(f"  ✓ Loaded {len(self.documents)} documents")

    # ------------------------------------------------------------------------
    # Context Retrieval
    # ------------------------------------------------------------------------

    def retrieve_context(
        self,
        question: Question,
        use_source_checksum: bool = True
    ) -> List[Context]:
        """
        Retrieve relevant context for a question.

        Args:
            question: Question to find context for
            use_source_checksum: If True, use question's source_checksum directly

        Returns:
            List of Context objects
        """
        contexts = []

        if use_source_checksum and question.source_checksum:
            # Direct lookup by source checksum
            doc = self.documents.get(question.source_checksum)
            if doc:
                contexts.append(Context(
                    checksum=question.source_checksum,
                    content=doc.page_content,
                    relevance_score=1.0,
                    source_file=doc.metadata.get('source_file')
                ))
        else:
            # TODO: Implement semantic search using OpenSearch/embeddings
            pass

        return contexts

    # ------------------------------------------------------------------------
    # Answer Generation
    # ------------------------------------------------------------------------

    def generate_answers(
        self,
        questions: List[Question],
        retrieve_context: bool = True
    ) -> List[Answer]:
        """
        Generate answers for a list of questions.

        Args:
            questions: List of Question objects
            retrieve_context: If True, retrieve context automatically

        Returns:
            List of Answer objects
        """
        print(f"\n[AnswerGenerator] Generating answers for {len(questions)} questions...")

        answers = []

        for question in questions:
            # Retrieve context
            if retrieve_context:
                contexts = self.retrieve_context(question)
            else:
                contexts = []

            # Generate answer
            if self.config.use_mock:
                answer = self._generate_mock_answer(question, contexts)
            else:
                answer = self._generate_llm_answer(question, contexts)

            if answer:
                answers.append(answer)

        # Filter by quality
        answers = self._filter_answers(answers)

        print(f"  ✓ Generated {len(answers)} answers")
        return answers

    def _generate_mock_answer(
        self,
        question: Question,
        contexts: List[Context]
    ) -> Optional[Answer]:
        """Generate mock answer for testing."""

        # Build context text
        context_text = ""
        source_checksums = []

        if contexts:
            context_text = contexts[0].content
            source_checksums = [ctx.checksum for ctx in contexts]

        # Generate mock answer
        title = question.source_title or "this topic"
        answer_text = (
            f"To comply with {title.lower()}, please follow the guidelines specified in the policy document. "
            f"<ol>"
            f"<li>Review the policy requirements</li>"
            f"<li>Ensure compliance with all provisions</li>"
            f"<li>Document your actions for audit purposes</li>"
            f"</ol>"
        )

        # Detect format
        answer_format = self._detect_format(answer_text)

        answer = Answer(
            answer_text=answer_text,
            question_text=question.question_text,
            confidence_score=0.92,
            answer_format=answer_format,
            source_checksums=source_checksums,
            context_employed=context_text[:500] if context_text else None,
            metadata={
                "generation_method": "mock",
                "contexts_used": len(contexts),
            }
        )

        return answer

    def _generate_llm_answer(
        self,
        question: Question,
        contexts: List[Context]
    ) -> Optional[Answer]:
        """Generate answer using LLM."""
        # TODO: Implement real LLM generation
        raise NotImplementedError("Real LLM answer generation not yet implemented")

    # ------------------------------------------------------------------------
    # Answer from Existing Question
    # ------------------------------------------------------------------------

    def answer_single_question(
        self,
        question_text: str,
        question_id: Optional[int] = None,
        source_checksum: Optional[str] = None
    ) -> Optional[Answer]:
        """
        Generate answer for a single question (e.g., user-submitted).

        Args:
            question_text: The question to answer
            question_id: Optional existing question ID
            source_checksum: Optional specific content to use

        Returns:
            Answer object or None
        """
        print(f"\n[AnswerGenerator] Answering single question: '{question_text[:50]}...'")

        # Create temporary Question object
        temp_question = Question(
            question_text=question_text,
            source_checksum=source_checksum or "",
            question_id=question_id
        )

        # Retrieve context
        if source_checksum:
            contexts = self.retrieve_context(temp_question)
        else:
            # TODO: Use semantic search to find relevant context
            contexts = []

        # Generate answer
        if self.config.use_mock:
            answer = self._generate_mock_answer(temp_question, contexts)
        else:
            answer = self._generate_llm_answer(temp_question, contexts)

        if answer:
            answer.question_id = question_id

        return answer

    # ------------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------------

    def _detect_format(self, answer_text: str) -> AnswerFormat:
        """Detect answer format from content."""
        if '<' in answer_text and '>' in answer_text:
            return AnswerFormat.HTML
        elif '#' in answer_text or '*' in answer_text:
            return AnswerFormat.MARKDOWN
        else:
            return AnswerFormat.PLAIN

    def _filter_answers(self, answers: List[Answer]) -> List[Answer]:
        """
        Filter answers by quality criteria.

        Args:
            answers: List of answers to filter

        Returns:
            Filtered list of answers
        """
        initial_count = len(answers)

        valid_answers = []
        for ans in answers:
            # Length check
            if len(ans.answer_text) < self.config.min_answer_length:
                continue
            if len(ans.answer_text) > self.config.max_answer_length:
                continue

            # Confidence check
            if ans.confidence_score < self.config.confidence_threshold:
                continue

            # Invalid answer detection
            if "I do not have enough information" in ans.answer_text:
                continue

            valid_answers.append(ans)

        filtered_count = initial_count - len(valid_answers)
        if filtered_count > 0:
            print(f"  ✓ Filtered out {filtered_count} invalid answers")

        return valid_answers

    # ------------------------------------------------------------------------
    # Re-generation
    # ------------------------------------------------------------------------

    def regenerate_answers_for_questions(
        self,
        question_ids: List[int],
        questions_data: List[Dict[str, Any]]
    ) -> List[Answer]:
        """
        Regenerate answers for existing questions.

        Use case: Source documents changed, need to update answers.

        Args:
            question_ids: List of question IDs to regenerate answers for
            questions_data: Question data (text, source_checksum, etc.)

        Returns:
            List of new Answer objects
        """
        print(f"\n[AnswerGenerator] Regenerating answers for {len(question_ids)} questions...")

        # Convert to Question objects
        questions = []
        for i, data in enumerate(questions_data):
            q = Question(
                question_id=question_ids[i],
                question_text=data['question_text'],
                source_checksum=data.get('source_checksum', '')
            )
            questions.append(q)

        # Generate new answers
        answers = self.generate_answers(questions)

        # Set question_ids
        for ans, qid in zip(answers, question_ids):
            ans.question_id = qid

        return answers

    # ------------------------------------------------------------------------
    # Schema Mapping (for Database Ingestion)
    # ------------------------------------------------------------------------

    def to_dataframes(
        self,
        answers: List[Answer]
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Convert answers to DataFrames for database ingestion.

        Returns TWO DataFrames:
        1. faq_answers: For faq_answers table
        2. faq_answer_sources: For faq_answer_sources table

        Args:
            answers: List of Answer objects

        Returns:
            Tuple of (faq_answers_df, faq_answer_sources_df)
        """
        print(f"\n[AnswerGenerator] Mapping {len(answers)} answers to database schema...")

        # Map to faq_answers table
        answers_data = []
        for i, ans in enumerate(answers, 1):
            answers_data.append({
                'question_id': i,  # Temporary ID (will be reassigned by DB)
                'answer_text': ans.answer_text,
                'answer_format': ans.answer_format.value,
                'confidence_score': ans.confidence_score,
                'status': ans.status,
            })

        df_answers = pd.DataFrame(answers_data)

        # Map to faq_answer_sources table
        sources_data = []
        for i, ans in enumerate(answers, 1):
            sources = ans.get_sources_for_db()
            for src in sources:
                src['answer_id'] = i  # Temporary ID
                sources_data.append(src)

        df_sources = pd.DataFrame(sources_data) if sources_data else pd.DataFrame()

        print(f"  ✓ faq_answers: {len(df_answers)} rows")
        print(f"  ✓ faq_answer_sources: {len(df_sources)} rows")

        return df_answers, df_sources

    # ------------------------------------------------------------------------
    # Complete Pipeline (Questions → Answers → DataFrames)
    # ------------------------------------------------------------------------

    def generate_and_map(
        self,
        questions: List[Question],
        retrieve_context: bool = True
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Complete pipeline: Generate answers AND map to DataFrames.

        This is the primary method for database ingestion workflow.

        When use_mock=True: Loads pre-generated answers from CSV files
        When use_mock=False: Generates answers using LLM

        Args:
            questions: List of Question objects
            retrieve_context: Whether to retrieve context automatically

        Returns:
            Tuple of (faq_answers_df, faq_answer_sources_df)

        Example:
            >>> a_gen = AnswerGenerator()
            >>> a_gen.load_context_documents(documents)
            >>> df_answers, df_sources = a_gen.generate_and_map(questions)
            >>> # Ready for ingestion
            >>> faq_ingestion.ingest_answers_from_dataframe(df_answers)
            >>> faq_source_ingestion.ingest_answer_sources_from_dataframe(df_sources)
        """
        print("\n" + "=" * 80)
        print("  ANSWER GENERATION PIPELINE")
        print("=" * 80)

        # MOCK MODE: Load from CSV files
        if self.config.use_mock:
            print("  ⚠️  MOCK MODE: Loading answers from CSV files")
            df_answers, df_sources = self._load_mock_csv_data()

            print("\n" + "=" * 80)
            print("  READY FOR DATABASE INGESTION (LOADED FROM CSV)")
            print(f"    faq_answers: {len(df_answers)} rows")
            print(f"    faq_answer_sources: {len(df_sources)} rows")
            print("=" * 80)

            return df_answers, df_sources

        # REAL MODE: Generate using LLM
        # Generate answers
        answers = self.generate_answers(questions, retrieve_context)

        # Map to DataFrames
        df_answers, df_sources = self.to_dataframes(answers)

        print("\n" + "=" * 80)
        print("  READY FOR DATABASE INGESTION")
        print(f"    faq_answers: {len(df_answers)} rows")
        print(f"    faq_answer_sources: {len(df_sources)} rows")
        print("=" * 80)

        return df_answers, df_sources

    def _load_mock_csv_data(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load mock FAQ answer data from CSV files.

        Loads from:
        - data/sample_faq_answers.csv
        - data/sample_faq_answer_sources.csv

        Returns:
            Tuple of (faq_answers_df, faq_answer_sources_df)
        """
        # Determine data folder path
        # Path: granular_impact/faq_generation -> granular_impact/data_ingestion/data
        current_dir = Path(__file__).parent
        data_folder = current_dir.parent / "data_ingestion" / "data"

        answers_csv = data_folder / "sample_faq_answers.csv"
        sources_csv = data_folder / "sample_faq_answer_sources.csv"

        # Verify files exist
        if not answers_csv.exists():
            raise FileNotFoundError(
                f"Mock data file not found: {answers_csv}\n"
                f"Please ensure sample_faq_answers.csv exists in {data_folder}"
            )
        if not sources_csv.exists():
            raise FileNotFoundError(
                f"Mock data file not found: {sources_csv}\n"
                f"Please ensure sample_faq_answer_sources.csv exists in {data_folder}"
            )

        print(f"  ✓ Loading answers from: {answers_csv.name}")
        print(f"  ✓ Loading sources from: {sources_csv.name}")

        # Load CSV files
        df_answers_raw = pd.read_csv(answers_csv)
        df_sources_raw = pd.read_csv(sources_csv)

        # Map to database schema (drop answer_id from answers, keep for sources)
        # Database will auto-generate answer_id on insert
        df_answers = df_answers_raw[["question_id", "answer_text", "answer_format", "confidence_score", "status"]].copy()

        # For sources, keep relevant columns (source_id will be auto-generated by DB)
        df_sources = df_sources_raw[[
            "answer_id",
            "content_checksum",
            "is_primary_source",
            "contribution_weight",
            "is_valid"
        ]].copy()

        # Optional columns that may be in CSV
        if "context_employed" in df_sources_raw.columns:
            df_sources["context_employed"] = df_sources_raw["context_employed"]
        if "invalidation_reason" in df_sources_raw.columns:
            df_sources["invalidation_reason"] = df_sources_raw["invalidation_reason"]
        if "invalidated_by_change_id" in df_sources_raw.columns:
            df_sources["invalidated_by_change_id"] = df_sources_raw["invalidated_by_change_id"]

        print(f"  ✓ Loaded {len(df_answers)} answers")
        print(f"  ✓ Loaded {len(df_sources)} answer sources")

        return df_answers, df_sources
