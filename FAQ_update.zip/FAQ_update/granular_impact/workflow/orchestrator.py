"""Main workflow orchestration."""
from typing import List
from granular_impact.database.models import ContentChange
from granular_impact.workflow.invalidator import SelectiveInvalidator


class WorkflowOrchestrator:
    def __init__(self, config, detector, analyzer, invalidator):
        self.config = config
        self.detector = detector
        self.analyzer = analyzer
        self.invalidator = invalidator

    def run(self, content_changes: List[ContentChange]):
        impact_results = []
        for change in content_changes:
            result = self.analyzer.analyze_impact(
                faq_id="example_faq",
                content_id=change.content_id,
                old_content=change.old_content,
                new_content=change.new_content,
                old_checksum=change.old_checksum,
                new_checksum=change.new_checksum
            )
            impact_results.append(result)

        invalidations = self.invalidator.determine_invalidations(impact_results)
        return impact_results, invalidations
