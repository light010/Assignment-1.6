# Workflow Module

Orchestrates the complete impact analysis workflow.

## Components

### WorkflowOrchestrator ([orchestrator.py](orchestrator.py))

Main workflow coordinator that runs the complete pipeline.

```python
from granular_impact.workflow import WorkflowOrchestrator
from granular_impact.config import GranularImpactConfig, Environment

config = GranularImpactConfig.from_environment(Environment.DIT)

orchestrator = WorkflowOrchestrator(
    config=config,
    detector=change_detector,
    analyzer=impact_analyzer,
    invalidator=selective_invalidator
)

# Run complete workflow
impact_results, invalidations = orchestrator.run(content_changes)

print(f'Analyzed: {len(impact_results)} changes')
print(f'To invalidate: {len(invalidations)} FAQs')
```

### SelectiveInvalidator ([invalidator.py](invalidator.py))

Determines which FAQs should be invalidated based on impact results.

```python
from granular_impact.workflow import SelectiveInvalidator
from granular_impact.database.models import ImpactDecision

invalidator = SelectiveInvalidator(config)

# Determine invalidations
faq_ids_to_invalidate = invalidator.determine_invalidations(impact_results)

print(f'FAQs to invalidate: {len(faq_ids_to_invalidate)}')

# Execute invalidations
for faq_id in faq_ids_to_invalidate:
    mark_faq_invalid(faq_id)
```

## Complete Workflow

```python
from granular_impact.config import GranularImpactConfig, Environment
from granular_impact.detection import ChangeDetector
from granular_impact.similarity import HybridSimilarityCalculator
from granular_impact.diff import DiffEngine, SemanticDetector
from granular_impact.impact import ImpactAnalyzer
from granular_impact.workflow import WorkflowOrchestrator, SelectiveInvalidator

# Initialize
config = GranularImpactConfig.from_environment(Environment.DIT)

detector = ChangeDetector()
analyzer = ImpactAnalyzer(
    config=config,
    similarity_calculator=HybridSimilarityCalculator(),
    diff_engine=DiffEngine(),
    semantic_detector=SemanticDetector()
)
invalidator = SelectiveInvalidator(config)

orchestrator = WorkflowOrchestrator(config, detector, analyzer, invalidator)

# Execute workflow
content_changes = load_content_changes()  # Your data loading logic
impact_results, invalidations = orchestrator.run(content_changes)

# Save results
save_impact_results(impact_results)
execute_invalidations(invalidations)
```

## Configuration

```python
from granular_impact.config import WorkflowConfig

workflow_config = WorkflowConfig(
    dry_run=False,                 # Set True to test without changes
    parallel_execution=True,        # Use multiprocessing
    max_workers=4,                  # Number of parallel workers
    fail_fast=False,                # Continue on errors
    continue_on_error=True,
    enable_metrics=True,
    log_level='INFO'
)
```
