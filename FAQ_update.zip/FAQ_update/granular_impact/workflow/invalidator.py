"""Selective invalidation logic."""
from typing import List
from granular_impact.database.models import ImpactResult, ImpactDecision


class SelectiveInvalidator:
    def __init__(self, config):
        self.config = config

    def determine_invalidations(self, impact_results: List[ImpactResult]) -> List[str]:
        faq_ids_to_invalidate = []
        for result in impact_results:
            if result.impact_decision == ImpactDecision.INVALIDATE:
                faq_ids_to_invalidate.append(result.faq_id)
        return list(set(faq_ids_to_invalidate))
