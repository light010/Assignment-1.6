# Time Off Policy

Employees are entitled to 10 sick days per year.