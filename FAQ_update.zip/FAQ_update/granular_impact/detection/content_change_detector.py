"""
Enhanced content change detection using pure checksum-centric approach with similarity matching.

This module implements the V8.2 change detection algorithm:
1. Pure checksum comparison (location-independent)
2. Similarity matching to detect modifications (not just new/deleted)
3. Edge case handling (splits, merges, moves)
4. Batch processing optimizations

Key Innovation: Uses set operations on checksums + similarity scoring to distinguish:
- NEW content (genuinely new)
- MODIFIED content (similar to deleted content, >80% match)
- DELETED content (no similar new content found)
- UNCHANGED content (checksum exists in both sets)

This is a PURE checksum-centric approach - location data is metadata only.
"""

import time
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from ..database.models import ChangeType, ContentChange
from .checksum_extractor import ChecksumExtractor
from ..similarity.hybrid import HybridSimilarityCalculator
from ..similarity.difflib_sim import DifflibSimilarityCalculator
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)


class ContentChangeDetector:
    """
    Enhanced change detector using pure checksum-centric approach with similarity matching.

    Implements the V8.2 algorithm from granular_impact_algorithm_v8.md:
    - Set operations on checksums (no location dependency)
    - Similarity matching for modification detection
    - Configurable similarity threshold (default: 0.8)
    - Edge case handling (splits, merges)
    """

    def __init__(
        self,
        checksum_algorithm: str = "sha256",
        similarity_threshold: float = 0.8,
        similarity_calculator: Optional[HybridSimilarityCalculator] = None,
        compute_llm_diffs: bool = True,
        diff_context_lines: int = 1,
    ):
        """
        Initialize content change detector.

        Args:
            checksum_algorithm: Hash algorithm for checksums (sha256, sha512, etc.)
            similarity_threshold: Threshold for detecting modifications (0.0-1.0, default: 0.8)
            similarity_calculator: Custom similarity calculator (if None, uses factory method)
            compute_llm_diffs: Whether to compute LLM-friendly diffs for MODIFIED content (default: True)
            diff_context_lines: Number of context lines for diffs (default: 1)
        """
        self.checksum_extractor = ChecksumExtractor(checksum_algorithm)
        self.similarity_threshold = similarity_threshold
        self.compute_llm_diffs = compute_llm_diffs
        self.diff_context_lines = diff_context_lines

        # Initialize similarity calculator using factory method for modification detection
        # Weights: Jaccard=0.20, Difflib=0.50, BM25=0.30 (matches pseudo code)
        # Early exit optimization at Jaccard < 0.3
        if similarity_calculator is None:
            self.similarity_calculator = HybridSimilarityCalculator.for_modification_detection()
        else:
            self.similarity_calculator = similarity_calculator

        # Initialize difflib calculator for LLM-friendly diffs
        if self.compute_llm_diffs:
            self.diff_calculator = DifflibSimilarityCalculator(
                autojunk=True,
                use_quick_ratio=False,
                lowercase=True,
                remove_punctuation=False,  # Keep numbers/dates intact
            )

        logger.info(
            f"ContentChangeDetector initialized: "
            f"algorithm={checksum_algorithm}, "
            f"similarity_threshold={similarity_threshold}, "
            f"compute_llm_diffs={compute_llm_diffs}, "
            f"similarity_weights={self.similarity_calculator.weights}"
        )

    def detect_changes(
        self,
        file_name: str,
        current_checksums_data: Dict[str, Dict],
        previous_checksums_data: Dict[str, Dict],
        detection_run_id: str,
    ) -> List[ContentChange]:
        """
        Detect content changes using PURE CHECKSUM COMPARISON with similarity matching.

        Strategy (from V8.2 algorithm):
        1. Get previous checksums for THIS FILE only (scoped, not global)
        2. Get current checksums for THIS FILE
        3. Find new checksums (not in previous set)
        4. Find deleted checksums (not in current set)
        5. Use SIMILARITY MATCHING to link new → deleted (modified content)

        Args:
            file_name: Name of file being analyzed
            current_checksums_data: Current file checksums
                Format: {checksum: {'text': '...', 'markdown_path': '...', 'page_num': 42}, ...}
            previous_checksums_data: Previous file checksums
                Format: {checksum: {'content_text': '...', 'page_number': 42}, ...}
            detection_run_id: Unique ID for this detection run

        Returns:
            List of ContentChange objects with change type and similarity scores
        """
        start_time = time.perf_counter()

        logger.info(f"🔍 Detecting changes for: {file_name}")
        logger.info(f"   Detection run: {detection_run_id}")

        # Step 1: Extract checksum sets
        current_checksums = set(current_checksums_data.keys())
        previous_checksums = set(previous_checksums_data.keys())

        # Step 2: Set operations (checksums only, NO location comparison!)
        new_checksums = current_checksums - previous_checksums
        deleted_checksums = previous_checksums - current_checksums
        unchanged_checksums = current_checksums & previous_checksums

        logger.info(f"📊 Checksum analysis for {file_name}:")
        logger.info(f"   Current:   {len(current_checksums)} checksums")
        logger.info(f"   Previous:  {len(previous_checksums)} checksums")
        logger.info(f"   New:       {len(new_checksums)} checksums")
        logger.info(f"   Deleted:   {len(deleted_checksums)} checksums")
        logger.info(f"   Unchanged: {len(unchanged_checksums)} checksums")

        # Step 3: SIMILARITY MATCHING (N × M where N and M are typically small)
        changes = []

        if new_checksums and deleted_checksums:
            logger.info(
                f"🧮 Running similarity matching "
                f"({len(new_checksums)} × {len(deleted_checksums)} = "
                f"{len(new_checksums) * len(deleted_checksums)} comparisons)..."
            )

            # Track matching for edge case detection (splits/merges)
            deleted_matched, new_matched = self._perform_similarity_matching(
                new_checksums=new_checksums,
                deleted_checksums=deleted_checksums,
                current_checksums_data=current_checksums_data,
                previous_checksums_data=previous_checksums_data,
                changes=changes,
            )

            # Handle edge cases
            self._detect_content_splits(deleted_matched)

        else:
            # No similarity matching needed
            logger.info("⚡ No similarity matching needed (no overlap between new/deleted)")

        # Step 4: Handle NEW content (no match found)
        for new_checksum in new_checksums:
            # Skip if already matched as modified
            if any(c.new_checksum == new_checksum for c in changes):
                continue

            changes.append(
                ContentChange(                    old_checksum="",
                    new_checksum=new_checksum,
                    change_type=ChangeType.NEW_CONTENT,
                    detected_at=datetime.now(),
                    file_name=file_name,
                    page_number=current_checksums_data[new_checksum].get("page_num"),
                    old_content=None,
                    new_content=current_checksums_data[new_checksum].get("text"),
                    similarity_score=0.0,
                )
            )

        # Step 5: Handle DELETED checksums (not matched to any new checksum)
        deleted_matched_set = set()
        for c in changes:
            if c.old_checksum:
                deleted_matched_set.add(c.old_checksum)

        for deleted_checksum in deleted_checksums:
            if deleted_checksum not in deleted_matched_set:
                # Truly DELETED content (no similar new content found)
                changes.append(
                    ContentChange(                        old_checksum=deleted_checksum,
                        new_checksum="",
                        change_type=ChangeType.DELETED_CONTENT,
                        detected_at=datetime.now(),
                        file_name=file_name,
                        page_number=previous_checksums_data[deleted_checksum].get("page_number"),
                        old_content=previous_checksums_data[deleted_checksum].get("content_text"),
                        new_content=None,
                        similarity_score=0.0,
                    )
                )

        # Step 6: Handle UNCHANGED content (for completeness in reporting)
        for unchanged_checksum in unchanged_checksums:
            changes.append(
                ContentChange(
                    old_checksum=unchanged_checksum,
                    new_checksum=unchanged_checksum,
                    change_type=ChangeType.UNCHANGED_CONTENT,
                    detected_at=datetime.now(),
                    file_name=file_name,
                    page_number=current_checksums_data.get(unchanged_checksum, {}).get("page_num"),
                    old_content=None,
                    new_content=None,
                    similarity_score=1.0,  # Perfect match
                )
            )

        end_time = time.perf_counter()
        processing_time_ms = (end_time - start_time) * 1000

        logger.info(f"✅ Changes detected: {len(changes)}")
        logger.info(f"   New:      {sum(1 for c in changes if c.change_type == ChangeType.NEW_CONTENT)}")
        logger.info(f"   Modified: {sum(1 for c in changes if c.change_type == ChangeType.MODIFIED_CONTENT)}")
        logger.info(f"   Deleted:  {sum(1 for c in changes if c.change_type == ChangeType.DELETED_CONTENT)}")
        logger.info(f"   Unchanged: {sum(1 for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT)}")
        logger.info(f"⏱️  Processing time: {processing_time_ms:.2f}ms")

        return changes

    def _perform_similarity_matching(
        self,
        new_checksums: Set[str],
        deleted_checksums: Set[str],
        current_checksums_data: Dict[str, Dict],
        previous_checksums_data: Dict[str, Dict],
        changes: List[ContentChange],
    ) -> Tuple[Dict[str, List], Dict[str, Tuple]]:
        """
        Perform similarity matching between new and deleted checksums.

        For each NEW checksum, finds best match in DELETED checksums using hybrid similarity.
        If similarity >= threshold, marks as MODIFIED; otherwise, marks as NEW.

        Args:
            new_checksums: Set of new checksums
            deleted_checksums: Set of deleted checksums
            current_checksums_data: Current file data
            previous_checksums_data: Previous file data
            changes: List to append changes to (mutated)

        Returns:
            Tuple of (deleted_matched dict, new_matched dict) for edge case detection
        """
        deleted_matched = {}  # {deleted_checksum: [(new_checksum, score), ...]}
        new_matched = {}  # {new_checksum: (deleted_checksum, score)}

        for new_checksum in new_checksums:
            new_text = current_checksums_data[new_checksum].get("text", "")

            if not new_text:
                logger.warning(f"⚠️  No text found for new checksum {new_checksum[:8]}...")
                continue

            best_match = None
            best_score = 0.0

            # Find best match among deleted checksums
            for deleted_checksum in deleted_checksums:
                deleted_text = previous_checksums_data[deleted_checksum].get("content_text", "")

                if not deleted_text:
                    continue

                # Compute hybrid similarity (combines multiple algorithms)
                result = self.similarity_calculator.compute_similarity(new_text, deleted_text)
                similarity = result.score

                if similarity > best_score:
                    best_score = similarity
                    best_match = deleted_checksum

            # Decision: Threshold check (default: 0.8 = 80% similarity)
            if best_score >= self.similarity_threshold and best_match:
                # This is MODIFIED content
                new_matched[new_checksum] = (best_match, best_score)

                if best_match not in deleted_matched:
                    deleted_matched[best_match] = []
                deleted_matched[best_match].append((new_checksum, best_score))

                # Compute LLM-friendly diff if enabled (JSON format)
                llm_diff = None
                if self.compute_llm_diffs:
                    old_text = previous_checksums_data[best_match].get("content_text", "")
                    if old_text and new_text:
                        try:
                            llm_diff = self.diff_calculator.get_llm_friendly_diff_json(
                                text1=old_text,
                                text2=new_text,
                                context_lines=self.diff_context_lines,
                                show_inline_changes=True,
                            )
                        except Exception as e:
                            logger.warning(
                                f"⚠️  Failed to compute LLM diff for {new_checksum[:8]}: {e}"
                            )

                changes.append(
                    ContentChange(
                        old_checksum=best_match,
                        new_checksum=new_checksum,
                        change_type=ChangeType.MODIFIED_CONTENT,
                        detected_at=datetime.now(),
                        file_name=current_checksums_data[new_checksum].get("file_name", ""),
                        page_number=current_checksums_data[new_checksum].get("page_num"),
                        old_content=previous_checksums_data[best_match].get("content_text"),
                        new_content=new_text,
                        similarity_score=best_score,
                        llm_friendly_diff=llm_diff,
                    )
                )

                logger.debug(
                    f"   ✓ MODIFIED: {best_match[:8]}→{new_checksum[:8]} "
                    f"(similarity: {best_score:.3f})"
                )
            # else: No good match - will be handled as NEW content in main flow

        return deleted_matched, new_matched

    def _detect_content_splits(self, deleted_matched: Dict[str, List]) -> None:
        """
        Detect content splits (one page became multiple pages).

        Edge case: Multiple new checksums match same deleted checksum.
        This indicates the content was split into multiple pieces.

        Args:
            deleted_matched: Dictionary of deleted checksums to their matches
        """
        for deleted_checksum, matches in deleted_matched.items():
            if len(matches) > 1:
                logger.warning(
                    f"⚠️  Content SPLIT detected: {deleted_checksum[:8]}... → "
                    f"{len(matches)} new checksums"
                )
                logger.warning(
                    f"   New checksums: {[m[0][:8] for m in matches]}"
                )
                logger.warning(
                    f"   Similarity scores: {[f'{m[1]:.3f}' for m in matches]}"
                )
                # All new checksums are already flagged for FAQ regeneration
                # (already in changes list as MODIFIED)

    def detect_simple_change(
        self,
        content_id: str,
        old_content: str,
        new_content: str,
        old_version: Optional[int] = None,
        new_version: Optional[int] = None,
    ) -> ContentChange:
        """
        Detect change for a single piece of content (simplified interface).

        This is the original simple API - kept for backward compatibility.
        For full change detection with similarity matching, use detect_changes().

        Args:
            content_id: Content identifier
            old_content: Previous content text
            new_content: Current content text
            old_version: Previous version number
            new_version: Current version number

        Returns:
            ContentChange object
        """
        old_checksum = self.checksum_extractor.compute_checksum(old_content)
        new_checksum = self.checksum_extractor.compute_checksum(new_content)

        if old_checksum == new_checksum:
            change_type = ChangeType.UNCHANGED_CONTENT
            similarity_score = 1.0
        else:
            # Compute similarity to determine if modified or completely new
            result = self.similarity_calculator.compute_similarity(old_content, new_content)
            similarity_score = result.score

            if similarity_score >= self.similarity_threshold:
                change_type = ChangeType.MODIFIED_CONTENT
            else:
                change_type = ChangeType.NEW_CONTENT

        return ContentChange(            old_checksum=old_checksum,
            new_checksum=new_checksum,
            change_type=change_type,
            detected_at=datetime.now(),
            old_content=old_content,
            new_content=new_content,
            similarity_score=similarity_score,
        )

    def get_config(self) -> dict:
        """Get detector configuration."""
        return {
            "checksum_algorithm": self.checksum_extractor.algorithm,
            "similarity_threshold": self.similarity_threshold,
            "similarity_weights": self.similarity_calculator.weights,
            "similarity_algorithm": self.similarity_calculator.get_algorithm_name(),
            "compute_llm_diffs": self.compute_llm_diffs,
            "diff_context_lines": self.diff_context_lines,
        }