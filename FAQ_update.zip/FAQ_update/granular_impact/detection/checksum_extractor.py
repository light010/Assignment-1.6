"""
Extract and compute checksums for content.
"""

import hashlib


class ChecksumExtractor:
    """Computes checksums for content tracking."""

    def __init__(self, algorithm: str = "sha256"):
        self.algorithm = algorithm

    def compute_checksum(self, content: str) -> str:
        """
        Compute checksum for content.

        Args:
            content: Text content

        Returns:
            Hexadecimal checksum string
        """
        if self.algorithm == "md5":
            hasher = hashlib.md5()
        elif self.algorithm == "sha1":
            hasher = hashlib.sha1()
        elif self.algorithm == "sha256":
            hasher = hashlib.sha256()
        elif self.algorithm == "sha512":
            hasher = hashlib.sha512()
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")

        hasher.update(content.encode('utf-8'))
        return hasher.hexdigest()
