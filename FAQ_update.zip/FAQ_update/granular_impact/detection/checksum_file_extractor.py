"""
Checksum extraction from file system for change detection.

This module provides utilities to extract checksums and content from:
- Markdown files (extracted content)
- CSV files (structured data)
- Delta tables (Databricks environment)
- In-memory data structures

Works with the content_change_detector to provide file-level checksums for comparison.
"""

import csv
import json
from pathlib import Path
from typing import Dict, List, Optional, Union

from .checksum_extractor import ChecksumExtractor
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)


class ChecksumFileExtractor:
    """
    Extract checksums and content from various file sources.

    Designed for integration with ContentChangeDetector for file-level change detection.
    """

    def __init__(self, checksum_algorithm: str = "sha256"):
        """
        Initialize checksum file extractor.

        Args:
            checksum_algorithm: Hash algorithm (sha256, sha512, etc.)
        """
        self.checksum_extractor = ChecksumExtractor(checksum_algorithm)
        logger.info(f"ChecksumFileExtractor initialized with {checksum_algorithm}")

    def extract_from_markdown_files(
        self, markdown_dir: Union[str, Path], file_name_pattern: str = "*.md"
    ) -> Dict[str, Dict]:
        """
        Extract checksums from markdown files in a directory.

        Each markdown file represents a piece of content (e.g., a page from a PDF).
        File naming convention: {file_name}_page_{page_num}.md

        Args:
            markdown_dir: Directory containing markdown files
            file_name_pattern: Glob pattern for files (default: *.md)

        Returns:
            Dictionary: {checksum: {'text': '...', 'markdown_path': '...', 'page_num': 42}, ...}
        """
        markdown_dir = Path(markdown_dir)

        if not markdown_dir.exists():
            raise FileNotFoundError(f"Markdown directory not found: {markdown_dir}")

        checksums_data = {}
        files = list(markdown_dir.glob(file_name_pattern))

        logger.info(f"📂 Extracting checksums from {len(files)} markdown files in {markdown_dir}")

        for md_file in files:
            try:
                # Read content
                with open(md_file, "r", encoding="utf-8") as f:
                    content = f.read()

                # Compute checksum
                checksum = self.checksum_extractor.compute_checksum(content)

                # Extract page number from filename (if present)
                page_num = self._extract_page_number(md_file.stem)

                checksums_data[checksum] = {
                    "text": content,
                    "markdown_path": str(md_file),
                    "file_name": md_file.name,
                    "page_num": page_num,
                }

                logger.debug(f"   ✓ {md_file.name} → {checksum[:8]}... (page {page_num})")

            except Exception as e:
                logger.error(f"   ✗ Error processing {md_file.name}: {e}")

        logger.info(f"✅ Extracted {len(checksums_data)} unique checksums")

        return checksums_data

    def extract_from_csv(self, csv_path: Union[str, Path]) -> Dict[str, Dict]:
        """
        Extract checksums from a CSV file containing content data.

        Expected columns:
        - content_text (required): The actual content
        - file_name (optional): Source file name
        - page_number (optional): Page number
        - content_checksum (optional): Pre-computed checksum (will verify)

        Args:
            csv_path: Path to CSV file

        Returns:
            Dictionary: {checksum: {'text': '...', 'file_name': '...', 'page_num': 42}, ...}
        """
        csv_path = Path(csv_path)

        if not csv_path.exists():
            raise FileNotFoundError(f"CSV file not found: {csv_path}")

        checksums_data = {}

        logger.info(f"📄 Extracting checksums from CSV: {csv_path}")

        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            for row_num, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                try:
                    content_text = row.get("content_text")

                    if not content_text:
                        logger.warning(f"   ⚠️  Row {row_num}: Missing content_text, skipping")
                        continue

                    # Compute checksum
                    checksum = self.checksum_extractor.compute_checksum(content_text)

                    # Verify pre-computed checksum if provided
                    if "content_checksum" in row and row["content_checksum"]:
                        if row["content_checksum"] != checksum:
                            logger.warning(
                                f"   ⚠️  Row {row_num}: Checksum mismatch! "
                                f"Provided: {row['content_checksum'][:8]}..., "
                                f"Computed: {checksum[:8]}..."
                            )

                    checksums_data[checksum] = {
                        "text": content_text,
                        "content_text": content_text,  # Alias for compatibility
                        "file_name": row.get("file_name", ""),
                        "page_number": int(row["page_number"]) if row.get("page_number") else None,
                        "page_num": int(row["page_number"]) if row.get("page_number") else None,  # Alias
                        "row_num": row_num,
                    }

                except Exception as e:
                    logger.error(f"   ✗ Row {row_num}: Error processing: {e}")

        logger.info(f"✅ Extracted {len(checksums_data)} unique checksums from CSV")

        return checksums_data

    def extract_from_dict_list(
        self, data: List[Dict], content_field: str = "content_text"
    ) -> Dict[str, Dict]:
        """
        Extract checksums from a list of dictionaries (e.g., from Spark DataFrame).

        Args:
            data: List of dictionaries containing content data
            content_field: Name of field containing text content

        Returns:
            Dictionary: {checksum: {'text': '...', ...original_fields}, ...}
        """
        checksums_data = {}

        logger.info(f"📊 Extracting checksums from {len(data)} records")

        for idx, record in enumerate(data):
            try:
                content_text = record.get(content_field)

                if not content_text:
                    logger.warning(f"   ⚠️  Record {idx}: Missing {content_field}, skipping")
                    continue

                # Compute checksum
                checksum = self.checksum_extractor.compute_checksum(content_text)

                # Include all fields from original record
                checksums_data[checksum] = {
                    **record,
                    "text": content_text,  # Standardized field
                    "content_text": content_text,  # Alias
                    "page_num": record.get("page_number"),  # Standardized field
                }

            except Exception as e:
                logger.error(f"   ✗ Record {idx}: Error processing: {e}")

        logger.info(f"✅ Extracted {len(checksums_data)} unique checksums")

        return checksums_data

    def extract_from_spark_dataframe(self, df, content_column: str = "content_text"):
        """
        Extract checksums from Spark DataFrame (Databricks environment).

        Args:
            df: Spark DataFrame containing content
            content_column: Name of column containing text content

        Returns:
            Dictionary: {checksum: {'text': '...', ...columns}, ...}

        Raises:
            ImportError: If pyspark is not available
        """
        try:
            from pyspark.sql import DataFrame
        except ImportError:
            raise ImportError(
                "pyspark not available. Install with: pip install pyspark"
            )

        if not isinstance(df, DataFrame):
            raise TypeError("df must be a Spark DataFrame")

        # Convert to list of dicts
        records = [row.asDict() for row in df.collect()]

        logger.info(f"🔥 Extracting checksums from Spark DataFrame ({len(records)} rows)")

        return self.extract_from_dict_list(records, content_field=content_column)

    def _extract_page_number(self, filename_stem: str) -> Optional[int]:
        """
        Extract page number from filename.

        Supports patterns:
        - {name}_page_{num}
        - {name}_p{num}
        - {name}_{num}

        Args:
            filename_stem: Filename without extension

        Returns:
            Page number or None if not found
        """
        import re

        # Pattern: _page_42, _p42, _42
        patterns = [
            r"_page_(\d+)$",  # handbook_page_5
            r"_p(\d+)$",  # handbook_p5
            r"_(\d+)$",  # handbook_5
        ]

        for pattern in patterns:
            match = re.search(pattern, filename_stem)
            if match:
                return int(match.group(1))

        return None

    def export_to_csv(
        self,
        checksums_data: Dict[str, Dict],
        output_path: Union[str, Path],
        include_content: bool = True,
    ) -> None:
        """
        Export checksums data to CSV file.

        Args:
            checksums_data: Dictionary of checksums and their data
            output_path: Path to output CSV file
            include_content: Whether to include full content text (can be large)
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"💾 Exporting {len(checksums_data)} checksums to {output_path}")

        # Collect all fields
        all_fields = {"content_checksum"}
        for data in checksums_data.values():
            all_fields.update(data.keys())

        if not include_content:
            all_fields.discard("text")
            all_fields.discard("content_text")

        fieldnames = sorted(all_fields)

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for checksum, data in checksums_data.items():
                row = {"content_checksum": checksum}

                for field in fieldnames:
                    if field == "content_checksum":
                        continue

                    value = data.get(field)

                    # Skip content if not included
                    if not include_content and field in ("text", "content_text"):
                        continue

                    row[field] = value

                writer.writerow(row)

        logger.info(f"✅ Exported to {output_path}")

    def export_to_json(
        self,
        checksums_data: Dict[str, Dict],
        output_path: Union[str, Path],
        indent: int = 2,
    ) -> None:
        """
        Export checksums data to JSON file.

        Args:
            checksums_data: Dictionary of checksums and their data
            output_path: Path to output JSON file
            indent: JSON indentation (default: 2)
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"💾 Exporting {len(checksums_data)} checksums to JSON: {output_path}")

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(checksums_data, f, indent=indent, default=str)

        logger.info(f"✅ Exported to {output_path}")