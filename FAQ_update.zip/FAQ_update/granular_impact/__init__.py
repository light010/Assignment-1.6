"""
Granular Impact Analysis Module

A comprehensive system for detecting and analyzing content changes in FAQ systems,
providing granular impact assessment for selective FAQ invalidation.

This module provides:
- Multi-algorithm similarity detection (Jaccard, Difflib, BM25, Hybrid)
  NOTE: Embedding similarity removed in V9 - not suitable for change detection
- Semantic diff analysis with phrase extraction
- Impact scoring and decision logic
- Database integration for Databricks/Delta Lake
- Change detection and selective invalidation workflows

Author: Analytics Assist Team
Version: 1.0.0 (V9: Embeddings removed)
"""

__version__ = "1.0.0"
__author__ = "Analytics Assist Team"

# Core module imports will be added as submodules are implemented
from granular_impact.config import GranularImpactConfig

__all__ = [
    "GranularImpactConfig",
    "__version__",
    "__author__",
]
