"""
Simplified base classes for similarity computation.

Clean, minimal interface for FAQ similarity algorithms.
All unnecessary complexity removed - no spacy, no caching, no parallelization.

Design Principles:
- Simplicity over features
- Clear separation of concerns
- Minimal dependencies (only numpy for helpers)
"""

import string
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class SimilarityResult:
    """
    Result of a similarity comparison between two texts.

    Attributes:
        score: Similarity score between 0.0 (different) and 1.0 (identical)
        text1: First text compared
        text2: Second text compared
        algorithm: Name of the algorithm used
        metadata: Additional algorithm-specific information
    """

    score: float
    text1: str
    text2: str
    algorithm: str
    metadata: Dict[str, Any]

    def __post_init__(self):
        """Validate similarity result."""
        if not (0.0 <= self.score <= 1.0):
            raise ValueError(f"Similarity score must be between 0.0 and 1.0, got {self.score}")

    def is_similar(self, threshold: float) -> bool:
        """
        Check if similarity exceeds threshold.

        Args:
            threshold: Minimum similarity score to be considered similar

        Returns:
            True if score >= threshold
        """
        return self.score >= threshold

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            "score": self.score,
            "text1": self.text1,
            "text2": self.text2,
            "algorithm": self.algorithm,
            "metadata": self.metadata,
        }


class BaseSimilarityCalculator(ABC):
    """
    Abstract base class for all similarity calculators.

    All similarity algorithms must inherit from this class and implement
    the required abstract methods.

    Simplified from v1 - removed spacy, caching, parallelization, batch processing.
    """

    def __init__(
        self,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        min_token_length: int = 1,
    ):
        """
        Initialize base similarity calculator.

        Args:
            lowercase: Whether to convert text to lowercase
            remove_punctuation: Whether to remove punctuation
            min_token_length: Minimum token length to keep
        """
        self.lowercase = lowercase
        self.remove_punctuation = remove_punctuation
        self.min_token_length = min_token_length

    @abstractmethod
    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute similarity between two texts.

        Args:
            text1: First text to compare
            text2: Second text to compare

        Returns:
            SimilarityResult object containing score and metadata

        Raises:
            ValueError: If texts are invalid (None, empty, etc.)
        """
        pass

    @abstractmethod
    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name string (e.g., "jaccard", "difflib", "bm25")
        """
        pass

    def preprocess_text(self, text: str) -> str:
        """
        Preprocess text according to configuration.

        Simple preprocessing: lowercasing, punctuation removal, whitespace normalization.
        No unicode normalization, no spacy, no caching.

        Args:
            text: Raw input text

        Returns:
            Preprocessed text
        """
        if text is None:
            return ""

        processed = text

        # Lowercase
        if self.lowercase:
            processed = processed.lower()

        # Remove punctuation
        if self.remove_punctuation:
            processed = processed.translate(str.maketrans("", "", string.punctuation))

        # Normalize whitespace
        processed = " ".join(processed.split())

        return processed

    def tokenize(self, text: str) -> list[str]:
        """
        Tokenize preprocessed text.

        Simple whitespace-based tokenization with minimum length filtering.
        No spacy, no lemmatization, no stopword removal, no caching.

        Args:
            text: Preprocessed text

        Returns:
            List of tokens
        """
        # Basic split on whitespace
        tokens = text.split()

        # Filter by minimum length
        if self.min_token_length > 1:
            tokens = [t for t in tokens if len(t) >= self.min_token_length]

        return tokens

    def __repr__(self) -> str:
        """String representation of calculator."""
        return f"{self.__class__.__name__}(algorithm='{self.get_algorithm_name()}')"