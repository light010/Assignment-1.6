"""
Quick example showing the new LLM-friendly diff formats.

This demonstrates the best way to format text differences for LLM prompts.
"""

from granular_impact.similarity import DifflibSimilarityCalculator

def print_section(title):
    """Print a formatted section header."""
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)
    print()

# Your FAQ example
faq_original = """
# Employee Vacation Policy

## How many vacation days do employees receive?

Full-time employees receive **15 vacation days** per year. Vacation days accrue monthly
and can be used after 90 days of employment. Unused vacation days can be carried over
to the next year, up to a maximum of 5 days.

### Eligibility

- Must be a full-time employee
- Must have completed 90-day probationary period
- Part-time employees receive prorated vacation days
"""

faq_minor_change = """
# Employee Vacation Policy

## How many vacation days do employees receive?

Full-time employees receive **20 vacation days** per year. Vacation days accrue monthly
and can be used after 90 days of employment. Unused vacation days can be carried over
to the next year, up to a maximum of 5 days.

### Eligibility

- Must be a full-time employee
- Must have completed 90-day probationary period
- Part-time employees receive prorated vacation days
"""

# Create calculator
calc = DifflibSimilarityCalculator(lowercase=True, remove_punctuation=False)

# ============================================================================
# EXAMPLE 1: Simple inline change
# ============================================================================
print_section("EXAMPLE 1: Simple Inline Change")
print("Scenario: Number changed in a sentence\n")

simple1 = "Employees receive 15 vacation days per year"
simple2 = "Employees receive 20 vacation days per year"

diff = calc.get_llm_friendly_diff(simple1, simple2, max_context_chars=50)
print(diff)

# ============================================================================
# EXAMPLE 2: Multiple changes in FAQ
# ============================================================================
print_section("EXAMPLE 2: Multiple Changes in FAQ Document")
print("Scenario: FAQ policy updated with new vacation day limits\n")

faq_with_multiple_changes = """
# Employee Vacation Policy

## How many vacation days do employees receive?

Full-time employees receive **20 vacation days** per year. Vacation days accrue monthly
and can be used after 90 days of employment. Unused vacation days can be carried over
to the next year, up to a maximum of 10 days.

### Eligibility

- Must be a full-time employee
- Must have completed 90-day probationary period
- Part-time employees receive prorated vacation days
"""

diff = calc.get_llm_friendly_diff_line_based(
    faq_original,
    faq_with_multiple_changes,
    context_lines=1,
    show_inline_changes=True
)
print(diff)

# ============================================================================
# EXAMPLE 3: Best format for LLM prompts
# ============================================================================
print_section("EXAMPLE 3: Recommended Format for LLM Prompts")
print("This is the BEST format to use when passing diffs to LLMs:\n")

# Use line-based with inline changes
line_diff = calc.get_llm_friendly_diff_line_based(
    faq_original,
    faq_minor_change,
    context_lines=1,
    show_inline_changes=True
)

# Create a complete LLM prompt
llm_prompt = f"""You are analyzing policy document changes.

CHANGES DETECTED:
{line_diff}

TASKS:
1. Summarize what changed in plain English
2. Identify who is affected by these changes
3. Assess the impact (positive/negative/neutral)
4. Suggest if employees should be notified

Provide your analysis in a structured format."""

print(llm_prompt)

# ============================================================================
# SUMMARY
# ============================================================================
print_section("SUMMARY: When to Use Each Method")

summary = """
1. get_llm_friendly_diff() - Character-level
   - Best for: Short text, inline changes, single-line comparisons
   - Shows: Context snippets with BEFORE/AFTER
   - Example: Detecting number changes in a sentence

2. get_llm_friendly_diff_line_based() - Line-based with inline highlighting ⭐ RECOMMENDED
   - Best for: Multi-line documents, FAQs, markdown, structured content
   - Shows: Full sentences in BEFORE/AFTER + "WHAT CHANGED" section
   - Example: Comparing FAQ documents, policy updates

KEY FEATURES:
✅ Full sentence/line in BEFORE and AFTER
✅ Separate "WHAT CHANGED" section showing exact differences
✅ Relevant context lines
✅ Clean format perfect for LLM prompts
✅ No confusing diff symbols (+, -, @@)

USAGE TIP:
Always use show_inline_changes=True (default) to get the "WHAT CHANGED" section.
This makes it crystal clear to the LLM what exactly changed!
"""

print(summary)