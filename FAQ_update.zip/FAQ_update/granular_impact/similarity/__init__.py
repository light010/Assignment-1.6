"""
Similarity calculation module.

Provides multiple algorithms for computing text similarity:
- Jaccard: Token set overlap
- Difflib: Sequence matching (Ratcliff/Obershelp)
- BM25: Probabilistic ranking function (supersedes TF-IDF)
- Hybrid: Weighted combination of multiple algorithms

NOTE: Embedding similarity has been removed as it is not suitable for
change detection. Embeddings optimize for semantic equivalence, while
change detection requires lexical difference detection. BM25, Jaccard,
and Difflib are scientifically superior for this use case.
"""

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)
from granular_impact.similarity.bm25_sim import BM25SimilarityCalculator
from granular_impact.similarity.difflib_sim import (
    DifflibSimilarityCalculator,
    TokenBasedDifflibCalculator,
)
from granular_impact.similarity.hybrid import (
    HybridSimilarityCalculator,
    PolicyContentSimilarity,
)
from granular_impact.similarity.jaccard_sim import (
    JaccardSimilarityCalculator,
    WeightedJaccardSimilarityCalculator,
)

# All available algorithms (embeddings removed)
__all_algorithms__ = [
    "JaccardSimilarityCalculator",
    "WeightedJaccardSimilarityCalculator",
    "DifflibSimilarityCalculator",
    "TokenBasedDifflibCalculator",
    "BM25SimilarityCalculator",
    "HybridSimilarityCalculator",
    "PolicyContentSimilarity",
]

# Backward compatibility alias
HybridV8SimilarityCalculator = HybridSimilarityCalculator

__all__ = [
    # Base classes
    "BaseSimilarityCalculator",
    "SimilarityResult",
    # Algorithms
    *__all_algorithms__,
    # Backward compatibility
    "HybridV8SimilarityCalculator",
]
