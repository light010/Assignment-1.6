"""
Simplified Jaccard similarity implementation.

Jaccard similarity measures the overlap between two sets:
    J(A, B) = |A ∩ B| / |A ∪ B|

Clean, minimal implementation - no batch processing, no caching, no performance tracking.

Design Principles:
- Simplicity over features
- Clear set-based algorithm
- Essential n-gram support
- FAQ-optimized factory methods
"""

from typing import List, Set

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)


class JaccardSimilarityCalculator(BaseSimilarityCalculator):
    """
    Simplified Jaccard similarity calculator using token-based set comparison.

    Measures similarity as intersection over union of token sets.
    """

    def __init__(
        self,
        ngram_size: int = 1,
        use_character_ngrams: bool = False,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        min_token_length: int = 1,
    ):
        """
        Initialize Jaccard similarity calculator.

        Args:
            ngram_size: Size of n-grams (1=unigrams, 2=bigrams, etc.)
            use_character_ngrams: Use character n-grams instead of word n-grams
            lowercase: Convert to lowercase
            remove_punctuation: Remove punctuation
            min_token_length: Minimum token length to keep
        """
        super().__init__(
            lowercase=lowercase,
            remove_punctuation=remove_punctuation,
            min_token_length=min_token_length,
        )
        self.ngram_size = ngram_size
        self.use_character_ngrams = use_character_ngrams

        if ngram_size < 1:
            raise ValueError(f"ngram_size must be >= 1, got {ngram_size}")

    @classmethod
    def for_faq_content(cls) -> "JaccardSimilarityCalculator":
        """
        Factory method for FAQ content analysis.

        Optimized for FAQ content with numbers, dates, and precise token matching.

        Returns:
            Configured JaccardSimilarityCalculator
        """
        return cls(
            ngram_size=1,
            use_character_ngrams=False,
            lowercase=True,
            remove_punctuation=False,  # Preserve numbers, dates
            min_token_length=1,
        )

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "jaccard"
        """
        return "jaccard"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute Jaccard similarity between two texts.

        Args:
            text1: First text to compare
            text2: Second text to compare

        Returns:
            SimilarityResult with Jaccard coefficient

        Raises:
            ValueError: If texts are invalid
        """
        # Validate inputs
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Preprocess
        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Generate sets
        if self.use_character_ngrams:
            set1 = self._get_character_ngrams(proc_text1)
            set2 = self._get_character_ngrams(proc_text2)
        else:
            tokens1 = self.tokenize(proc_text1)
            tokens2 = self.tokenize(proc_text2)
            set1 = self._get_word_ngrams(tokens1)
            set2 = self._get_word_ngrams(tokens2)

        # Compute Jaccard coefficient
        score = self._jaccard_coefficient(set1, set2)

        # Build metadata
        intersection = set1 & set2
        union = set1 | set2

        metadata = {
            "intersection_size": len(intersection),
            "union_size": len(union),
            "set1_size": len(set1),
            "set2_size": len(set2),
            "ngram_size": self.ngram_size,
            "use_character_ngrams": self.use_character_ngrams,
        }

        return SimilarityResult(
            score=score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def _jaccard_coefficient(self, set1: Set[str], set2: Set[str]) -> float:
        """
        Calculate Jaccard coefficient between two sets.

        Args:
            set1: First set
            set2: Second set

        Returns:
            Jaccard coefficient (0.0 to 1.0)
        """
        # Handle empty sets
        if len(set1) == 0 and len(set2) == 0:
            return 1.0  # Both empty = identical

        if len(set1) == 0 or len(set2) == 0:
            return 0.0  # One empty = completely different

        # Calculate Jaccard: |intersection| / |union|
        intersection = set1 & set2
        union = set1 | set2

        if len(union) == 0:
            return 0.0

        return len(intersection) / len(union)

    def _get_word_ngrams(self, tokens: List[str]) -> Set[str]:
        """
        Generate n-grams from word tokens.

        Args:
            tokens: List of word tokens

        Returns:
            Set of n-gram strings
        """
        if self.ngram_size == 1:
            return set(tokens)

        ngrams = []
        for i in range(len(tokens) - self.ngram_size + 1):
            ngram = " ".join(tokens[i : i + self.ngram_size])
            ngrams.append(ngram)

        return set(ngrams) if ngrams else set()

    def _get_character_ngrams(self, text: str) -> Set[str]:
        """
        Generate character-level n-grams.

        Args:
            text: Input text

        Returns:
            Set of character n-gram strings
        """
        if len(text) < self.ngram_size:
            return {text} if text else set()

        ngrams = []
        for i in range(len(text) - self.ngram_size + 1):
            ngram = text[i : i + self.ngram_size]
            ngrams.append(ngram)

        return set(ngrams)


class WeightedJaccardSimilarityCalculator(JaccardSimilarityCalculator):
    """
    Weighted Jaccard similarity for domain-specific term emphasis.

    Assigns different weights to tokens to emphasize important terms.
    """

    def __init__(
        self,
        token_weights: dict = None,
        default_weight: float = 1.0,
        ngram_size: int = 1,
        use_character_ngrams: bool = False,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        min_token_length: int = 1,
    ):
        """
        Initialize weighted Jaccard calculator.

        Args:
            token_weights: Dictionary mapping tokens to weights
            default_weight: Default weight for unlisted tokens
            ngram_size: Size of n-grams
            use_character_ngrams: Use character n-grams
            lowercase: Convert to lowercase
            remove_punctuation: Remove punctuation
            min_token_length: Minimum token length
        """
        super().__init__(
            ngram_size=ngram_size,
            use_character_ngrams=use_character_ngrams,
            lowercase=lowercase,
            remove_punctuation=remove_punctuation,
            min_token_length=min_token_length,
        )
        self.token_weights = token_weights or {}
        self.default_weight = default_weight

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "weighted_jaccard"
        """
        return "weighted_jaccard"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute weighted Jaccard similarity.

        Args:
            text1: First text
            text2: Second text

        Returns:
            SimilarityResult with weighted Jaccard coefficient

        Raises:
            ValueError: If texts are invalid
        """
        # Validate inputs
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Preprocess
        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Generate sets
        if self.use_character_ngrams:
            set1 = self._get_character_ngrams(proc_text1)
            set2 = self._get_character_ngrams(proc_text2)
        else:
            tokens1 = self.tokenize(proc_text1)
            tokens2 = self.tokenize(proc_text2)
            set1 = self._get_word_ngrams(tokens1)
            set2 = self._get_word_ngrams(tokens2)

        # Compute weighted Jaccard
        score = self._weighted_jaccard(set1, set2)

        # Build metadata
        intersection = set1 & set2
        union = set1 | set2

        metadata = {
            "intersection_size": len(intersection),
            "union_size": len(union),
            "set1_size": len(set1),
            "set2_size": len(set2),
            "weighted_intersection": sum(self._get_weight(t) for t in intersection),
            "weighted_union": sum(self._get_weight(t) for t in union),
            "ngram_size": self.ngram_size,
            "use_character_ngrams": self.use_character_ngrams,
            "num_custom_weights": len(self.token_weights),
        }

        return SimilarityResult(
            score=score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def _weighted_jaccard(self, set1: Set[str], set2: Set[str]) -> float:
        """
        Calculate weighted Jaccard coefficient.

        Args:
            set1: First set of tokens/ngrams
            set2: Second set of tokens/ngrams

        Returns:
            Weighted Jaccard coefficient
        """
        if len(set1) == 0 and len(set2) == 0:
            return 1.0

        if len(set1) == 0 or len(set2) == 0:
            return 0.0

        intersection = set1 & set2
        union = set1 | set2

        # Calculate weighted sums
        weighted_intersection = sum(self._get_weight(token) for token in intersection)
        weighted_union = sum(self._get_weight(token) for token in union)

        if weighted_union == 0:
            return 0.0

        return weighted_intersection / weighted_union

    def _get_weight(self, token: str) -> float:
        """
        Get weight for a token.

        Args:
            token: Token to get weight for

        Returns:
            Weight value
        """
        return self.token_weights.get(token, self.default_weight)


# Convenience exports
__all__ = [
    "JaccardSimilarityCalculator",
    "WeightedJaccardSimilarityCalculator",
]