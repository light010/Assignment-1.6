# Similarity Module

**Simplified** multi-algorithm text similarity computation for FAQ content analysis and change detection.

## Overview

This module provides clean, minimal similarity algorithms for comparing text content. All algorithms share a common interface.

**Design Philosophy:** Simplicity-first. No spacy, no caching, no batch processing, no parallelization. Just clean, straightforward similarity computation.

## Available Algorithms

### 1. Jaccard Similarity ([jaccard_sim.py](jaccard_sim.py))
**Best for:** Token-level overlap, quick comparisons, FAQ content changes

**Algorithm:** Intersection over union of token sets: `J(A,B) = |A ∩ B| / |A ∪ B|`

**Features:**
- N-gram support (unigrams, bigrams, trigrams)
- Character-level and word-level modes
- Weighted variant for domain-specific terms
- FAQ-optimized factory methods
- Performance tracking

**Example:**
```python
from granular_impact.similarity import JaccardSimilarityCalculator

# FAQ-optimized (preserves numbers, dates, all words)
calc = JaccardSimilarityCalculator.for_faq_content()

result = calc.compute_similarity(
    "Employees receive 10 vacation days per year",
    "Employees receive 15 vacation days per year"
)

print(f"Jaccard Score: {result.score:.3f}")  # ~0.88
print(f"Intersection: {result.metadata['intersection_size']}")  # 6 tokens
print(f"Union: {result.metadata['union_size']}")  # 7 tokens
```

### 2. Difflib Similarity ([difflib_sim.py](difflib_sim.py))
**Best for:** Character-level changes, minor edits, numeric/date changes

**Algorithm:** Ratcliff/Obershelp gestalt pattern matching

**Features:**
- Character-level and token-level variants
- Detailed diff blocks with operation types
- Unified diff output
- FAQ modification detection optimized

**Example:**
```python
from granular_impact.similarity import DifflibSimilarityCalculator

calc = DifflibSimilarityCalculator()

result = calc.compute_similarity(
    "Submit reports within 30 days",
    "Submit reports within 45 days"
)

print(f"Difflib Score: {result.score:.3f}")  # ~0.96
print(f"Operations: {result.metadata['operations']}")
```

### 3. BM25 Similarity ([bm25_sim.py](bm25_sim.py))
**Best for:** Document ranking, retrieval, handling variable lengths

**Algorithm:** Best Matching 25 probabilistic ranking function

**Features:**
- Term frequency saturation (k1 parameter)
- Document length normalization (b parameter)
- Sigmoid normalization to [0, 1]
- FAQ-optimized configurations
- Term contribution analysis

**Example:**
```python
from granular_impact.similarity import BM25SimilarityCalculator

# FAQ-optimized (preserves numbers, dates)
calc = BM25SimilarityCalculator.for_faq_modification_detection()

result = calc.compute_similarity(text1, text2)
print(f"BM25 Score: {result.score:.3f}")
```

### 4. Hybrid Similarity ([hybrid.py](hybrid.py))
**Best for:** Production use, robust analysis, multiple perspectives

**Algorithm:** Weighted combination of Jaccard, Difflib, and BM25

**Features:**
- Configurable weights
- Individual algorithm breakdowns
- Early exit optimization for performance
- Policy-specific classification

**Example:**
```python
from granular_impact.similarity import HybridSimilarityCalculator

calc = HybridSimilarityCalculator()

result = calc.compute_similarity(text1, text2)

print(f"Overall Score: {result.score:.3f}")
print("\nIndividual Scores:")
for algo, score in result.metadata['individual_scores'].items():
    print(f"  {algo}: {score:.3f}")
```

## Common Interface

All calculators implement `BaseSimilarityCalculator`:

```python
class BaseSimilarityCalculator(ABC):
    def compute_similarity(text1: str, text2: str) -> SimilarityResult
    def get_algorithm_name() -> str
    def preprocess_text(text: str) -> str
    def tokenize(text: str) -> list[str]
```

## Data Classes

### SimilarityResult
```python
@dataclass
class SimilarityResult:
    score: float                    # [0.0, 1.0]
    text1: str
    text2: str
    algorithm: str
    metadata: Dict[str, Any]

    def is_similar(threshold: float) -> bool
    def to_dict() -> Dict[str, Any]
```

## Configuration Options

All calculators support these simple preprocessing options:

```python
calc = SomeCalculator(
    lowercase=True,               # Convert to lowercase
    remove_punctuation=True,      # Remove punctuation
    min_token_length=1,          # Minimum token length
)
```

**Removed for Simplicity:**
- ❌ No spacy integration
- ❌ No stopword removal
- ❌ No caching
- ❌ No batch processing
- ❌ No parallelization
- ❌ No performance tracking

## FAQ Use Cases

### Content Change Detection
```python
from granular_impact.similarity import HybridSimilarityCalculator

calc = HybridSimilarityCalculator()

result = calc.compute_similarity(
    "Employees receive 10 sick days per year",
    "Employees receive 12 sick days per year"
)

# Compute dissimilarity: simply use (1 - similarity)
dissimilarity = 1.0 - result.score  # Higher = more different
```

### Database Integration
```python
# For database integration with FAQImpactAnalysis table,
# use FaqImpactAnalyzer from granular_impact.impact module

from granular_impact.similarity import JaccardSimilarityCalculator
from granular_impact.impact import FaqImpactAnalyzer

calc = JaccardSimilarityCalculator.for_faq_content()
analyzer = FaqImpactAnalyzer(calc)

# Create database-compatible impact record
impact = analyzer.to_faq_impact_analysis(
    similarity_result=result,
    change_id=content_change_id,
    question_id=faq_question_id,
    threshold=0.3
)

db.session.add(impact)
db.session.commit()
```

## Testing

```bash
# Run simplified Jaccard tests
pytest FAQ_update/tests/test_similarity/test_jaccard_simplified.py -v

# Run simplified BM25 tests
pytest FAQ_update/tests/test_similarity/test_bm25_simplified.py -v

# Run all simplified similarity tests
pytest FAQ_update/tests/test_similarity/test_base_simplified.py -v
```

**Test Status:**
- ✅ 43 Jaccard tests passing
- ✅ 39 BM25 tests passing
- ✅ All simplified modules tested

## API Reference

- [base.py](base.py) - Simplified abstract interface and result classes
- [jaccard_sim.py](jaccard_sim.py) - Simplified Jaccard similarity
- [difflib_sim.py](difflib_sim.py) - Simplified Difflib similarity
- [bm25_sim.py](bm25_sim.py) - Simplified BM25 ranking
- [hybrid.py](hybrid.py) - Simplified multi-algorithm combination

## Architecture

**Design Principle:** Simplicity-first

- Clean, minimal code
- No spacy, no caching, no batch processing
- No database dependencies in similarity module
- Database integration via `FaqImpactAnalyzer` in `granular_impact.impact`
- All algorithms share common interface
- Type-safe with dataclasses
- Essential features only

## Contributing

When adding new algorithms:
1. Inherit from `BaseSimilarityCalculator`
2. Implement required abstract methods
3. Return `SimilarityResult` objects
4. Include comprehensive metadata
5. Add type hints
6. Write docstrings
7. Add tests in `FAQ_update/tests/test_similarity/`