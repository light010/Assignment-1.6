"""
Simplified BM25 similarity implementation.

BM25 (Best Matching 25) is a probabilistic ranking function for information retrieval.
Clean, minimal implementation with essential BM25 features.

Design Principles:
- Simplicity over complexity
- Core BM25 algorithm preserved
- No batch processing, no persistence, no caching
- Factory methods for FAQ-optimized configs
"""

import math
from collections import Counter
from typing import Dict, List

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)


class BM25SimilarityCalculator(BaseSimilarityCalculator):
    """
    Simplified BM25 similarity calculator.

    Implements BM25 ranking function with clean, minimal code.
    Automatically fits corpus from the two input texts.
    """

    def __init__(
        self,
        k1: float = 1.5,
        b: float = 0.75,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        min_token_length: int = 1,
    ):
        """
        Initialize BM25 calculator.

        Args:
            k1: Term frequency saturation parameter (typical: 1.2-2.0)
            b: Document length normalization parameter (0-1, typical: 0.75)
            lowercase: Whether to convert text to lowercase
            remove_punctuation: Whether to remove punctuation
            min_token_length: Minimum token length to keep
        """
        super().__init__(
            lowercase=lowercase,
            remove_punctuation=remove_punctuation,
            min_token_length=min_token_length,
        )
        self.k1 = k1
        self.b = b

    @classmethod
    def for_faq_modification_detection(cls) -> "BM25SimilarityCalculator":
        """
        Factory method for FAQ modification detection.

        Optimized to detect numeric and date changes in FAQ content.
        Preserves numbers and dates for maximum sensitivity.

        Returns:
            Configured BM25 calculator for modification detection
        """
        return cls(
            k1=1.5,
            b=0.75,
            lowercase=True,
            remove_punctuation=False,  # Preserve numbers, dates
            min_token_length=1,
        )

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "bm25"
        """
        return "bm25"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute BM25 similarity between two texts.

        Treats text1 as query and text2 as document.
        Automatically fits BM25 corpus from both texts.

        Args:
            text1: Query text
            text2: Document text

        Returns:
            SimilarityResult with BM25 score normalized to [0, 1]

        Raises:
            ValueError: If texts are invalid (None, empty, etc.)
        """
        # Validate inputs
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Preprocess and tokenize
        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)
        tokens1 = self.tokenize(proc_text1)
        tokens2 = self.tokenize(proc_text2)

        if not tokens1 or not tokens2:
            # If no tokens after preprocessing, similarity is 0
            return SimilarityResult(
                score=0.0,
                text1=text1,
                text2=text2,
                algorithm=self.get_algorithm_name(),
                metadata={
                    "bm25_raw_score": 0.0,
                    "k1": self.k1,
                    "b": self.b,
                },
            )

        # Fit BM25 on the two texts
        corpus = [tokens1, tokens2]
        corpus_size = len(corpus)
        avgdl = sum(len(doc) for doc in corpus) / corpus_size

        # Calculate document frequencies and IDF
        doc_freqs = {}
        for doc in corpus:
            unique_tokens = set(doc)
            for token in unique_tokens:
                doc_freqs[token] = doc_freqs.get(token, 0) + 1

        idf = {}
        for term, freq in doc_freqs.items():
            # BM25 IDF formula
            idf[term] = math.log((corpus_size - freq + 0.5) / (freq + 0.5) + 1.0)

        # Compute BM25 score
        raw_score = self._bm25_score(tokens1, tokens2, idf, avgdl)

        # Normalize to [0, 1] using sigmoid
        score = self._normalize_score(raw_score)

        metadata = {
            "bm25_raw_score": raw_score,
            "k1": self.k1,
            "b": self.b,
            "avgdl": avgdl,
            "doc_length": len(tokens2),
            "query_length": len(tokens1),
        }

        return SimilarityResult(
            score=score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def _bm25_score(
        self,
        query_tokens: List[str],
        doc_tokens: List[str],
        idf: Dict[str, float],
        avgdl: float,
    ) -> float:
        """
        Calculate BM25 score.

        Args:
            query_tokens: Query tokens
            doc_tokens: Document tokens
            idf: Pre-computed IDF values
            avgdl: Average document length

        Returns:
            BM25 score (unbounded)
        """
        doc_len = len(doc_tokens)
        doc_freqs = Counter(doc_tokens)

        score = 0.0
        for term in query_tokens:
            if term not in idf:
                continue

            # Term frequency in document
            tf = doc_freqs.get(term, 0)

            # BM25 formula
            idf_score = idf[term]
            numerator = tf * (self.k1 + 1)
            denominator = tf + self.k1 * (1 - self.b + self.b * (doc_len / avgdl))

            score += idf_score * (numerator / denominator)

        return score

    def _normalize_score(self, raw_score: float) -> float:
        """
        Normalize BM25 score to [0, 1] range using sigmoid.

        Args:
            raw_score: Raw BM25 score

        Returns:
            Normalized score between 0 and 1
        """
        # Sigmoid normalization
        return 1.0 / (1.0 + math.exp(-raw_score / 2.0))