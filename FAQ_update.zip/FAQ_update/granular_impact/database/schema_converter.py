"""
Schema converter: Databricks SQL → SQLite SQL.

Design principles:
- Simple, single-purpose class
- Static methods (no state)
- Clear, readable conversions
- Preserves structure and logic

Usage:
    databricks_sql = Path("schema/tables/01_users.sql").read_text()
    sqlite_sql = SchemaConverter.databricks_to_sqlite(databricks_sql)
    Path("schema_sqlite/tables/01_users.sql").write_text(sqlite_sql)
"""

import re
from typing import Dict, List, Tuple


class SchemaConverter:
    """
    Converts Databricks SQL schemas to SQLite SQL.

    Handles:
    - Type conversions (STRING→TEXT, BIGINT→INTEGER, TIMESTAMP→TEXT)
    - Comment removal (COMMENT clauses)
    - TBLPROPERTIES removal
    - Timestamp functions (CURRENT_TIMESTAMP() → CURRENT_TIMESTAMP)
    - Identity columns (GENERATED ALWAYS AS IDENTITY → AUTOINCREMENT)
    - Constraint conversion (ALTER TABLE → inline)
    """

    # Type mappings: Databricks → SQLite
    TYPE_MAPPINGS = {
        r"\bSTRING\b": "TEXT",
        r"\bstring\b": "TEXT",
        r"\bBIGINT\b": "INTEGER",
        r"\bbigint\b": "INTEGER",
        r"\bTIMESTAMP\b": "TEXT",
        r"\btimestamp\b": "TEXT",
    }

    @classmethod
    def databricks_to_sqlite(cls, databricks_sql: str) -> str:
        """
        Convert Databricks SQL to SQLite SQL.

        Args:
            databricks_sql: Databricks SQL schema definition

        Returns:
            SQLite SQL schema definition

        Example:
            >>> sql = "CREATE TABLE test (id BIGINT, name STRING);"
            >>> SchemaConverter.databricks_to_sqlite(sql)
            'CREATE TABLE test (id INTEGER, name TEXT);'
        """
        if not databricks_sql or not databricks_sql.strip():
            return databricks_sql

        sqlite_sql = databricks_sql

        # Step 1: Convert data types
        sqlite_sql = cls._convert_types(sqlite_sql)

        # Step 2: Remove COMMENT clauses
        sqlite_sql = cls._remove_comments(sqlite_sql)

        # Step 3: Remove TBLPROPERTIES
        sqlite_sql = cls._remove_tblproperties(sqlite_sql)

        # Step 4: Convert timestamp functions
        sqlite_sql = cls._convert_timestamp_functions(sqlite_sql)

        # Step 5: Convert identity columns
        sqlite_sql = cls._convert_identity_columns(sqlite_sql)

        # Step 6: Convert/remove ALTER TABLE constraints
        sqlite_sql = cls._convert_constraints(sqlite_sql)

        # Step 7: Clean up whitespace
        sqlite_sql = cls._clean_whitespace(sqlite_sql)

        return sqlite_sql

    @classmethod
    def _convert_types(cls, sql: str) -> str:
        """Convert Databricks types to SQLite types."""
        for databricks_type, sqlite_type in cls.TYPE_MAPPINGS.items():
            sql = re.sub(databricks_type, sqlite_type, sql)
        return sql

    @classmethod
    def _remove_comments(cls, sql: str) -> str:
        """
        Remove COMMENT clauses.

        Handles:
        - Column comments: COMMENT 'text'
        - Table comments: COMMENT 'text' (at table level)
        """
        # Remove column-level COMMENT 'text' or COMMENT "text"
        sql = re.sub(r"\s*COMMENT\s+['\"][^'\"]*['\"]", "", sql, flags=re.IGNORECASE)
        return sql

    @classmethod
    def _remove_tblproperties(cls, sql: str) -> str:
        """
        Remove TBLPROPERTIES block.

        Handles multiline TBLPROPERTIES with nested properties.
        Also removes COMMENT clause before TBLPROPERTIES if present.
        """
        # Pattern: Remove COMMENT 'text' TBLPROPERTIES ( ... );
        # This handles the pattern: )\nCOMMENT 'text'\nTBLPROPERTIES (...);
        # Replace with just );
        sql = re.sub(
            r"\)\s*COMMENT\s+['\"][^'\"]*['\"]?\s*TBLPROPERTIES\s*\([^)]*\)\s*;",
            ");",
            sql,
            flags=re.DOTALL | re.IGNORECASE,
        )

        # Also handle case without COMMENT
        sql = re.sub(
            r"\s*TBLPROPERTIES\s*\([^)]*\)\s*;",
            ";",
            sql,
            flags=re.DOTALL | re.IGNORECASE,
        )
        return sql

    @classmethod
    def _convert_timestamp_functions(cls, sql: str) -> str:
        """Convert CURRENT_TIMESTAMP() to CURRENT_TIMESTAMP."""
        sql = re.sub(
            r"\bCURRENT_TIMESTAMP\(\)",
            "CURRENT_TIMESTAMP",
            sql,
            flags=re.IGNORECASE,
        )
        return sql

    @classmethod
    def _convert_identity_columns(cls, sql: str) -> str:
        """
        Convert GENERATED ALWAYS AS IDENTITY to AUTOINCREMENT.

        Databricks: id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY
        SQLite:     id INTEGER PRIMARY KEY AUTOINCREMENT

        Note: SQLite requires PRIMARY KEY for AUTOINCREMENT.
        """
        # Pattern: column_name INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY
        # Result:  column_name INTEGER PRIMARY KEY AUTOINCREMENT
        sql = re.sub(
            r"(\w+)\s+INTEGER\s+NOT\s+NULL\s+GENERATED\s+ALWAYS\s+AS\s+IDENTITY",
            r"\1 INTEGER PRIMARY KEY AUTOINCREMENT",
            sql,
            flags=re.IGNORECASE,
        )
        return sql

    @classmethod
    def _convert_constraints(cls, sql: str) -> str:
        """
        Convert or remove ALTER TABLE constraints.

        Strategy:
        - Remove ALTER TABLE PRIMARY KEY (SQLite uses inline PRIMARY KEY for AUTOINCREMENT)
        - Convert CHECK constraints to inline format
        """
        check_constraints: List[Tuple[str, str]] = []

        # First, remove ALTER TABLE PRIMARY KEY statements (can be multiline)
        sql = re.sub(
            r"ALTER\s+TABLE\s+\w+\s+ADD\s+CONSTRAINT\s+IF\s+NOT\s+EXISTS\s+\w+\s+PRIMARY\s+KEY\s+\([^)]+\)\s*;",
            "",
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )

        # Remove ALTER TABLE FOREIGN KEY statements (SQLite doesn't support adding FKs via ALTER TABLE)
        # Note: For proper SQLite support, FKs should be defined inline in CREATE TABLE
        sql = re.sub(
            r"ALTER\s+TABLE\s+\w+\s+ADD\s+CONSTRAINT\s+IF\s+NOT\s+EXISTS\s+\w+\s+FOREIGN\s+KEY\s+\([^)]+\)\s+REFERENCES\s+[^;]+;",
            "",
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )

        # Capture CHECK constraints from ALTER TABLE
        def extract_check(match):
            table_name = match.group(1)
            constraint_name = match.group(2)
            check_expr = match.group(3)
            check_constraints.append((constraint_name, check_expr))
            return ""  # Remove the ALTER TABLE statement

        sql = re.sub(
            r"ALTER\s+TABLE\s+(\w+)\s+ADD\s+CONSTRAINT\s+IF\s+NOT\s+EXISTS\s+(\w+)\s+CHECK\s+\((.*?)\)\s*;",
            extract_check,
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )

        # Insert CHECK constraints inline before closing CREATE TABLE
        if check_constraints:
            sql = cls._insert_inline_constraints(sql, check_constraints)

        return sql

    @classmethod
    def _insert_inline_constraints(cls, sql: str, constraints: List[Tuple[str, str]]) -> str:
        """
        Insert CHECK constraints inline in CREATE TABLE.

        Finds the closing ) of CREATE TABLE and inserts constraints before it.
        """
        # Strategy: Find CREATE TABLE ... and the last ) before the ;
        # We'll use a simpler approach: find CREATE TABLE, then find the last ) before first ;

        # Find the CREATE TABLE statement
        create_table_start = re.search(
            r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\w+\s+\(",
            sql,
            re.IGNORECASE
        )

        if not create_table_start:
            return sql

        # Find the closing ); after CREATE TABLE
        start_pos = create_table_start.end()
        end_marker_pos = sql.find(");", start_pos)

        if end_marker_pos == -1:
            return sql

        # Build constraint text
        constraint_lines = []
        for constraint_name, check_expr in constraints:
            constraint_lines.append(f"    CONSTRAINT {constraint_name} CHECK ({check_expr})")

        constraints_text = ",\n" + ",\n".join(constraint_lines) + "\n"

        # Insert constraints before the closing );
        # Original: ... last_column\n);
        # Result: ... last_column,\n CONSTRAINT...,\n CONSTRAINT...\n);
        new_sql = sql[:end_marker_pos] + constraints_text + sql[end_marker_pos:]

        return new_sql

    @classmethod
    def _clean_whitespace(cls, sql: str) -> str:
        """Clean up excessive whitespace."""
        # Remove multiple blank lines
        sql = re.sub(r"\n\n\n+", "\n\n", sql)

        # Remove trailing whitespace
        lines = [line.rstrip() for line in sql.split("\n")]
        sql = "\n".join(lines)

        return sql.strip() + "\n" if sql.strip() else ""
