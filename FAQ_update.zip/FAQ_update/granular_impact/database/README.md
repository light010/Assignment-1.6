# Database Module - Granular Impact Analysis

This module implements the granular impact schema for FAQ management, enabling selective invalidation of FAQs based on actual content changes rather than blanket invalidation.

## Overview

**Multi-Database Support**: Databricks Unity Catalog, SQLite (local dev/testing)

### Core Innovation (Granular Impact)

**Problem**: When content changes (e.g., "10 days" → "12 days"), traditional systems invalidate ALL FAQs linked to that page.

**Solution**: Granular impact analyzes WHICH specific FAQs are actually affected, saving unnecessary regeneration.

**Example**:
- Page has 10 FAQs
- Small edit: "10 sick days" → "12 sick days"
- Traditional: Invalidate ALL 10 FAQs → Regenerate ALL 10 ❌
- Granular: Detect only Q1 affected → Regenerate ONLY Q1 ✅

## Architecture

### Schema (8 Tables)

**Foundation Table**:
0. **content_repo** - Repository of source content files and metadata

**Core Tables**:
1. **content_checksums** - Master content table (checksum is THE identity)
2. **faq_questions** - FAQ questions (content-agnostic)
3. **faq_answers** - FAQ answers (1:1 with questions)

**Provenance Tables**:
4. **faq_question_sources** - Question provenance with temporal validity
5. **faq_answer_sources** - Answer provenance with temporal validity

**Change Detection & Audit**:
6. **content_change_log** - Change detection + diff data (JSON) + impact metrics
7. **faq_audit_log** - Minimal audit trail (FK references)

### Components

#### [schema_manager.py](schema_manager.py)
Unified schema manager supporting multiple database backends:
- Databricks Unity Catalog (Spark SQL + Delta Lake)
- SQLite (local development/testing)
- Dependency-aware table creation
- Fine-grained control (specific tables, dry-run mode)
- Schema validation

#### [adapters.py](adapters.py)
Database adapters providing unified interface:
- `SQLiteAdapter` - Local development/testing
- `DatabricksAdapter` - Production (Spark-based)
- `DatabaseAdapter` - Abstract base class

#### [dialect.py](dialect.py)
Multi-dialect support:
- Type mappings (STRING→TEXT, BIGINT→INTEGER, etc.)
- Feature detection (foreign keys, constraints, etc.)
- SQL rendering for different backends

#### [models.py](models.py)
Python dataclasses for all 7 tables with validation and enums.

#### [queries.py](queries.py)
SQL query templates with parameterization for common operations.

#### [transactions.py](transactions.py)
Transaction manager with exponential backoff retry logic.

#### [connection.py](connection.py)
Databricks Spark session management (optional, requires pyspark).

## Getting Started

### Prerequisites

**For Local Development (SQLite):**
- Python 3.8+
- No additional dependencies (SQLite is built-in)

**For Production (Databricks):**
- Python 3.8+
- PySpark (`pip install pyspark`)
- Databricks workspace access
- Unity Catalog enabled
- CREATE CATALOG/SCHEMA permissions

### Installation

```bash
cd FAQ_update
pip install -r requirements.txt  # or use poetry
```

## Quick Start

### Option 1: Use Pre-Built Script (Recommended)

The `create_database.py` script is **generic** - supports both SQLite and Databricks.

**SQLite** (local development):
```bash
# Default (creates databases/granular_impact.db)
python create_database.py

# Custom path
python create_database.py --path data/my_database.db

# Preview first (dry-run)
python create_database.py --dry-run
```

**Databricks** (production):
```bash
# Create in Unity Catalog
python create_database.py --databricks \
  --catalog onedata_us_east_1_shared_prod \
  --schema faq_granular_impact

# Preview first (dry-run)
python create_database.py --databricks \
  --catalog prod --schema faq --dry-run
```

**View help**:
```bash
python create_database.py --help
```

**Run examples** (SQLite only):
```bash
python use_database_example.py
```

### Option 2: In-Memory (Testing)

```python
from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)

# Create in-memory SQLite database
adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)

# Create schema (all 7 tables)
manager = SchemaManager(adapter=adapter)
manager.create_schema()

# Insert data
adapter.execute(
    "INSERT INTO content_checksums (content_checksum, file_name) VALUES (?, ?)",
    ("a" * 64, "handbook.pdf")
)
adapter.commit()

# Query data
questions = adapter.fetchall("SELECT * FROM faq_questions")
```

### Option 3: Persistent File (Development)

```python
from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)

# Connect to persistent database file
adapter = create_adapter(
    DatabaseDialect.SQLITE,
    database_path="databases/granular_impact.db"
)

# Use existing schema or create new
manager = SchemaManager(adapter=adapter)
manager.create_schema()  # Safe: uses IF NOT EXISTS

# Query data
results = adapter.fetchall("SELECT * FROM faq_questions WHERE status='active'")
for row in results:
    print(row)

adapter.close()
```

### Option 4: Databricks (Production)

**Using Script**:
```bash
python create_database.py --databricks --catalog prod --schema faq
```

**Using Python**:
```python
from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)

# Create adapter
adapter = create_adapter(
    DatabaseDialect.DATABRICKS,
    catalog="onedata_us_east_1_shared_prod",
    schema="faq_granular_impact"
)

# Create schema
manager = SchemaManager(adapter=adapter)
manager.create_schema()

# Or with config
from granular_impact.config import GranularImpactConfig, Environment

config = GranularImpactConfig.from_environment(Environment.DIT)
adapter = create_adapter(
    DatabaseDialect.DATABRICKS,
    catalog=config.database.catalog,
    schema=config.database.schema
)
```

### Using Query Templates

```python
from granular_impact.database.queries import QueryTemplates

# Get FAQs requiring regeneration
sql = QueryTemplates.get_faqs_requiring_regeneration(
    catalog="prod",
    schema="faq",
    detection_run_id="RUN_2025_01_21"
)

faqs = spark.sql(sql).collect()
```

## Data Models

### ContentRepo (Source File Repository)

```python
from granular_impact.database.models import ContentRepo, FileStatus

repo = ContentRepo(
    raw_file_nme="benefits.pdf",
    raw_file_type="pdf",
    raw_file_version_nbr=2,
    raw_file_path="/volumes/data/benefits.pdf",
    extracted_markdown_file_path="/volumes/markdown/benefits.md",
    title_nme="Employee Benefits Guide",
    content_checksum="a" * 64,  # SHA-256 hash (64 chars)
    file_status=FileStatus.ACTIVE,
)
```

**Key Concept**: Tracks raw source files and their extracted content. Serves as the source-of-truth for content ingestion pipeline.

### ContentChecksum (Master Content Table)

```python
from granular_impact.database.models import ContentChecksum, ContentStatus

content = ContentChecksum(
    content_checksum="a" * 64,  # SHA-256 hash (64 chars)
    file_type="pdf",
    title="Employee Benefits Handbook",
    status=ContentStatus.ACTIVE,
    file_name="benefits.pdf",  # Metadata only
)
```

**Key Concept**: `content_checksum` is THE identity. Location (file_name, url) is metadata for humans.

### FAQ Questions and Answers

```python
from granular_impact.database.models import (
    FAQQuestion, FAQAnswer, FAQStatus,
    SourceType, GenerationMethod, AnswerFormat
)

# Create question
question = FAQQuestion(
    question_text="How many sick days do employees get?",
    source_type=SourceType.FROM_DOCUMENTS,
    generation_method=GenerationMethod.LLM_GENERATED,
    status=FAQStatus.ACTIVE
)

# Create answer (1:1 relationship)
answer = FAQAnswer(
    question_id=question.question_id,
    answer_text="<p>Employees receive 12 sick days per year.</p>",
    answer_format=AnswerFormat.HTML,
    confidence_score=0.95,
    status=FAQStatus.ACTIVE
)
```

### Provenance Tracking (Temporal Validity)

```python
from granular_impact.database.models import (
    FAQQuestionSource,
    InvalidationReason
)
from datetime import datetime

# Link question to content
question_source = FAQQuestionSource(
    question_id=12345,
    content_checksum="abc" * 21 + "a",
    is_primary_source=True,
    contribution_weight=1.0,
    is_valid=True,
    valid_from=datetime(2025, 1, 1),
)

# When content changes, invalidate
question_source.is_valid = False
question_source.valid_until = datetime.now()
question_source.invalidation_reason = InvalidationReason.SELECTIVE_IMPACT
```

### Content Change Detection

```python
from granular_impact.database.models import ContentChangeLog, ChangeType
import json

change = ContentChangeLog(
    content_checksum="def" * 21 + "d",  # NEW checksum
    previous_checksum="abc" * 21 + "a",  # OLD checksum
    file_name="benefits.pdf",
    requires_faq_regeneration=True,
    change_type=ChangeType.MODIFIED_CONTENT,
    similarity_score=0.92,  # 92% similar
    total_faqs_at_risk=10,  # All FAQs linked
    affected_question_count=1,  # Only 1 affected
    affected_answer_count=1,
    # Result: 8 FAQs saved!
    diff_data=json.dumps({
        "chunks": [
            {
                "type": "modified",
                "old_text": "10 sick days",
                "new_text": "12 sick days"
            }
        ]
    })
)
```

## Schema Management

### Understanding Schema Files

#### Single Source of Truth Architecture

```
sql/
├── schema/              # 📌 CANONICAL (edit these!)
│   ├── tables/          # Databricks SQL definitions
│   │   ├── 00_content_repo.sql
│   │   └── ...
│   └── _meta/
│       └── dependency_graph.yaml
│
├── schema_sqlite/       # 🤖 AUTO-GENERATED (don't edit!)
│   ├── tables/          # Generated from Databricks
│   └── _meta/
│       └── dependency_graph.yaml
```

**Key Principle**: Databricks schemas are canonical. SQLite schemas are auto-generated.

#### Databricks vs SQLite SQL Differences

| Feature | Databricks | SQLite |
|---------|-----------|--------|
| String type | `STRING` | `TEXT` |
| Big integer | `BIGINT` | `INTEGER` |
| Timestamps | `TIMESTAMP` | `TEXT` (ISO8601) |
| Auto-increment | `GENERATED ALWAYS AS IDENTITY` | `AUTOINCREMENT` |
| Comments | `COMMENT 'text'` | Removed |
| Properties | `TBLPROPERTIES (...)` | Removed |
| Timestamp function | `CURRENT_TIMESTAMP()` | `CURRENT_TIMESTAMP` |
| Constraints | `ALTER TABLE ADD CONSTRAINT` | Inline in `CREATE TABLE` |

### Adding a New Table

#### Step 1: Create Databricks SQL File

Create `sql/schema/tables/08_my_table.sql`:

```sql
-- ============================================================================
-- TABLE: my_table
-- ============================================================================
-- Description: Brief description
-- Dependencies: List dependencies
-- Owner: Your Team
-- ============================================================================

CREATE TABLE IF NOT EXISTS my_table (
    -- Primary key
    id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY COMMENT 'Primary key',

    -- Columns
    name STRING NOT NULL COMMENT 'Name',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Created timestamp',

    -- Foreign key (if needed)
    content_checksum STRING COMMENT 'Reference to content_checksums'
)
COMMENT 'Table description'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Primary Key
ALTER TABLE my_table ADD CONSTRAINT IF NOT EXISTS pk_my_table
    PRIMARY KEY (id);

-- Foreign Key (if needed)
ALTER TABLE my_table ADD CONSTRAINT IF NOT EXISTS fk_my_table_content
    FOREIGN KEY (content_checksum) REFERENCES content_checksums(content_checksum)
    ON DELETE CASCADE;

-- Check Constraints (if needed)
ALTER TABLE my_table ADD CONSTRAINT IF NOT EXISTS chk_name_not_empty
    CHECK (LENGTH(name) > 0);
```

#### Step 2: Update Dependency Graph

Edit `sql/schema/_meta/dependency_graph.yaml`:

```yaml
tables:
  # ... existing tables ...

  my_table:
    file: "tables/08_my_table.sql"
    dependencies:
      - "content_checksums"  # List dependencies
    order: 8
    description: "Brief description"

# Update summary
# Total Objects: 9 tables
```

#### Step 3: Generate SQLite Schema

```bash
cd FAQ_update

# Auto-generate SQLite version
python -m granular_impact.database.generate_sqlite_schemas

# Validate (optional)
python -m granular_impact.database.generate_sqlite_schemas --validate
```

This automatically:
- Converts types (STRING→TEXT, BIGINT→INTEGER)
- Removes comments and TBLPROPERTIES
- Converts identity columns to AUTOINCREMENT
- Moves constraints inline
- Writes to `sql/schema_sqlite/tables/08_my_table.sql`

#### Step 4: Add Python Model

Edit `models.py`:

```python
@dataclass
class MyTable:
    """
    Description of the table.

    Maps to: my_table table
    """

    name: str
    created_at: datetime = field(default_factory=datetime.now)

    id: Optional[int] = None  # IDENTITY column
    content_checksum: Optional[str] = None

    def __post_init__(self):
        """Validate data."""
        if self.content_checksum and len(self.content_checksum) != 64:
            raise ValueError("content_checksum must be 64 chars")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "content_checksum": self.content_checksum,
            "created_at": self.created_at,
        }
```

#### Step 5: Write Tests

Create `tests/test_database/test_my_table.py`:

```python
"""Tests for MyTable model and table."""

import pytest
from granular_impact.database import create_adapter, DatabaseDialect, SchemaManager
from granular_impact.database.models import MyTable


class TestMyTableModel:
    """Test MyTable dataclass model."""

    def test_create_minimal(self):
        """Test creating with minimal fields."""
        obj = MyTable(name="test")
        assert obj.name == "test"
        assert obj.id is None

    def test_validation(self):
        """Test validation logic."""
        with pytest.raises(ValueError):
            MyTable(name="test", content_checksum="short")


class TestMyTableSchema:
    """Test my_table table in database."""

    def test_table_creation(self):
        """Test creating the table."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)

        manager.create_schema(specific_tables=["my_table"])

        # Verify table exists
        tables = adapter.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='my_table'"
        )
        assert len(tables) == 1

        adapter.close()

    def test_insert_and_query(self):
        """Test basic CRUD operations."""
        adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        manager = SchemaManager(adapter=adapter)
        manager.create_schema(specific_tables=["my_table"])

        # Insert
        adapter.execute(
            "INSERT INTO my_table (name) VALUES (?)",
            ("test_name",)
        )
        adapter.commit()

        # Query
        results = adapter.fetchall("SELECT * FROM my_table")
        assert len(results) == 1
        assert results[0][1] == "test_name"

        adapter.close()
```

#### Step 6: Test Locally

```bash
# Run tests
pytest tests/test_database/test_my_table.py -v

# Create local database with new table
python create_database.py

# Verify table exists
sqlite3 databases/granular_impact.db ".schema my_table"
```

## SQL Organization

Modular SQL structure with dialect-specific schemas:

```
sql/
├── schema/              # Databricks SQL
│   ├── tables/          # 8 table files
│   │   ├── 00_content_repo.sql
│   │   ├── 01_content_checksums.sql
│   │   ├── 02_faq_questions.sql
│   │   ├── ...
│   │   └── 07_faq_audit_log.sql
│   └── _meta/
│       └── dependency_graph.yaml
├── schema_sqlite/       # SQLite SQL (same structure)
│   ├── tables/
│   └── _meta/
└── queries/             # Query templates (4 files)
    └── ...
```

See [sql/schema/README.md](sql/schema/README.md) for detailed documentation.

## Common Operations

### Create Schema

```python
from granular_impact.database import SchemaManager

# Create all tables
manager = SchemaManager(adapter=adapter)
manager.create_schema()

# Create specific tables with dependencies
manager.create_schema(specific_tables=["faq_audit_log"])  # Auto-includes dependencies

# Dry-run to see execution plan
manager.create_schema(dry_run=True)
```

### Insert Content Repository Data

```python
from granular_impact.database import create_adapter, DatabaseDialect

# Connect to persistent database
adapter = create_adapter(
    DatabaseDialect.SQLITE,
    database_path="databases/granular_impact.db"
)

# Insert content file
adapter.execute(
    """INSERT INTO content_repo (
        raw_file_nme, raw_file_type, raw_file_path,
        extracted_markdown_file_path, title_nme, file_status
    ) VALUES (?, ?, ?, ?, ?, ?)""",
    (
        "benefits.pdf",
        "pdf",
        "/volumes/data/benefits.pdf",
        "/volumes/markdown/benefits.md",
        "Employee Benefits Guide",
        "Active"
    )
)

adapter.commit()
adapter.close()
```

### Insert FAQ Data

```python
from granular_impact.database import create_adapter, DatabaseDialect

# Connect to persistent database
adapter = create_adapter(
    DatabaseDialect.SQLITE,
    database_path="databases/granular_impact.db"
)

# Insert question
adapter.execute(
    """INSERT INTO faq_questions
       (question_text, source_type, generation_method, status)
       VALUES (?, ?, ?, ?)""",
    ("How many sick days?", "from_documents", "llm_generated", "active")
)

# Insert answer (question_id auto-generated, usually 1 for first question)
adapter.execute(
    """INSERT INTO faq_answers
       (question_id, answer_text, answer_format, status)
       VALUES (?, ?, ?, ?)""",
    (1, "<p>12 sick days per year.</p>", "html", "active")
)

adapter.commit()
adapter.close()
```

### Query FAQs with Source Provenance

```python
# Join FAQs with their source documents
faqs = adapter.fetchall("""
    SELECT
        q.question_text,
        a.answer_text,
        c.file_name,
        c.title
    FROM faq_questions q
    JOIN faq_answers a ON q.question_id = a.question_id
    JOIN faq_question_sources qs ON q.question_id = qs.question_id
    JOIN content_checksums c ON qs.content_checksum = c.content_checksum
    WHERE q.status = 'active' AND qs.is_valid = 1
""")

for question, answer, source_file, title in faqs:
    print(f"Q: {question}")
    print(f"A: {answer}")
    print(f"Source: {source_file} ({title})")
```

### Validate Schema

```python
result = manager.validate_schema()
print(result)  # Shows missing tables, warnings, etc.

if not result.is_valid:
    print("Missing:", result.missing_tables)
```

### Query FAQs Requiring Regeneration

```python
from granular_impact.database.queries import QueryTemplates

sql = QueryTemplates.get_faqs_requiring_regeneration(
    catalog="prod",
    schema="faq",
    detection_run_id="RUN_2025_01_21"
)

faqs = spark.sql(sql).collect()
```

### Get Detection Run Summary

```python
sql = QueryTemplates.get_detection_run_summary(
    catalog="prod",
    schema="faq",
    limit=5
)

summary = spark.sql(sql).collect()
for run in summary:
    print(f"FAQs at risk: {run.total_faqs_at_risk}")
    print(f"Actually affected: {run.questions_actually_affected}")
    print(f"Saved: {run.faqs_saved_from_regeneration}")
```

## Dialect Comparison

| Feature | Databricks | SQLite |
|---------|-----------|--------|
| **Primary Use** | Production | Local dev/test |
| **Setup** | High (cloud) | Low (built-in) |
| **Dependencies** | PySpark | None (stdlib) |
| **In-Memory** | No | Yes ✅ |
| **Performance (large data)** | Excellent | Limited |
| **Cost** | $$$$ | Free |
| **Foreign Keys** | ✅ | ✅ |
| **Constraints** | ✅ | ✅ |
| **JSON Support** | ✅ | ✅ |

### Type Mappings

| Canonical | Databricks | SQLite |
|-----------|-----------|--------|
| STRING | STRING | TEXT |
| BIGINT | BIGINT | INTEGER |
| DOUBLE | DOUBLE | REAL |
| BOOLEAN | BOOLEAN | INTEGER (0/1) |
| TIMESTAMP | TIMESTAMP | TEXT (ISO8601) |

### When to Use Each

**Databricks**: Production, large-scale data (TBs), Delta Lake features

**SQLite**: Local development, unit tests, CI/CD pipelines, offline work, prototyping

## Production Deployment (Databricks)

### Step 1: Determine Catalog and Schema Names

Follow your organization's naming convention:

```
Catalog: onedata_<region>_<env>
Schema:  <service>_<feature>

Examples:
- onedata_us_east_1_shared_dit.faq_granular_impact (Dev/Integration)
- onedata_us_east_1_shared_fit.faq_granular_impact (Functional Testing)
- onedata_us_east_1_shared_prod.faq_granular_impact (Production)
```

### Step 2: Create Catalog and Schema (if needed)

**In Databricks SQL Editor or Notebook:**

```sql
-- Create catalog (if it doesn't exist)
CREATE CATALOG IF NOT EXISTS onedata_us_east_1_shared_dit;

-- Use the catalog
USE CATALOG onedata_us_east_1_shared_dit;

-- Create schema
CREATE SCHEMA IF NOT EXISTS faq_granular_impact
COMMENT 'Granular Impact Analysis for FAQ Management';

-- Verify
SHOW SCHEMAS IN onedata_us_east_1_shared_dit;
```

### Step 3: Deploy Schema

**Option A: Using CLI Tool**

```bash
cd FAQ_update

# Dry-run first (preview)
python create_database.py \
  --databricks \
  --catalog onedata_us_east_1_shared_dit \
  --schema faq_granular_impact \
  --dry-run

# Actually create tables
python create_database.py \
  --databricks \
  --catalog onedata_us_east_1_shared_dit \
  --schema faq_granular_impact
```

**Option B: Using Python API**

```python
from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)

# Create adapter for Databricks
adapter = create_adapter(
    DatabaseDialect.DATABRICKS,
    catalog="onedata_us_east_1_shared_dit",
    schema="faq_granular_impact"
)

# Create schema
manager = SchemaManager(adapter=adapter)
manager.create_schema()

# Or specific tables
manager.create_schema(specific_tables=["content_repo", "content_checksums"])
```

**Option C: From Databricks Notebook**

Upload code to Databricks workspace, then:

```python
# In Databricks notebook
%python

import sys
sys.path.insert(0, '/Workspace/path/to/FAQ_update')

from granular_impact.database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)

catalog = "onedata_us_east_1_shared_dit"
schema = "faq_granular_impact"

adapter = create_adapter(DatabaseDialect.DATABRICKS, catalog=catalog, schema=schema)
manager = SchemaManager(adapter=adapter)

# Create all tables
manager.create_schema()

print(f"✅ Schema created: {catalog}.{schema}")
```

### Step 4: Verify Deployment

**In Databricks SQL Editor:**

```sql
USE CATALOG onedata_us_east_1_shared_dit;
USE SCHEMA faq_granular_impact;

-- List all tables
SHOW TABLES;

-- Check specific table
DESCRIBE TABLE EXTENDED content_repo;

-- Verify table structure
SHOW CREATE TABLE content_repo;

-- Check properties
SHOW TBLPROPERTIES content_repo;

-- Verify foreign keys
SELECT * FROM information_schema.table_constraints
WHERE table_schema = 'faq_granular_impact';
```

**Using Python:**

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# List tables
tables = spark.sql("""
    SHOW TABLES IN onedata_us_east_1_shared_dit.faq_granular_impact
""").collect()

for table in tables:
    print(f"✓ {table.tableName}")

# Check table exists and can query
df = spark.sql("""
    SELECT COUNT(*) as count
    FROM onedata_us_east_1_shared_dit.faq_granular_impact.content_repo
""")
df.show()
```

### Step 5: Set Permissions

```sql
-- Grant permissions to service principal or group
GRANT SELECT, INSERT, UPDATE ON SCHEMA faq_granular_impact TO `analytics_assist_sp`;

-- Grant table-level permissions
GRANT ALL PRIVILEGES ON TABLE content_repo TO `analytics_assist_sp`;

-- View permissions
SHOW GRANTS ON SCHEMA faq_granular_impact;
```

## Troubleshooting

### Issue 1: "Table already exists" Error

**Problem:** Trying to create tables that already exist

**Solution:**
```python
# Schema files use IF NOT EXISTS (safe to re-run)
# Or drop tables first
adapter.execute("DROP TABLE IF EXISTS content_repo CASCADE")
adapter.commit()

# Or use SchemaManager.drop_schema() (DANGEROUS!)
manager.drop_schema(cascade=True)  # Requires confirmation
```

### Issue 2: Foreign Key Constraint Violations

**Problem:** Cannot insert due to FK constraints

**Solution:**
```python
# Insert in dependency order:
# 1. content_repo, content_checksums (no dependencies)
# 2. faq_questions (no dependencies)
# 3. faq_answers (depends on questions)
# 4. faq_question_sources (depends on questions + checksums)
# etc.

# Or temporarily disable FK checks (SQLite only)
adapter.execute("PRAGMA foreign_keys = OFF")
# ... do operations ...
adapter.execute("PRAGMA foreign_keys = ON")
```

### Issue 3: "PySpark not installed" for Databricks

**Problem:** Cannot create Databricks database

**Solution:**
```bash
pip install pyspark

# Or in requirements.txt/pyproject.toml
pyspark>=3.3.0
```

### Issue 4: Schema Mismatch Between SQLite and Databricks

**Problem:** SQLite schema doesn't match Databricks

**Solution:**
```bash
# Regenerate SQLite schemas from Databricks (canonical)
cd FAQ_update
python -m granular_impact.database.generate_sqlite_schemas

# Validate they match
python -m granular_impact.database.generate_sqlite_schemas --validate
```

### Issue 5: "Catalog/Schema not found" in Databricks

**Problem:** Catalog or schema doesn't exist

**Solution:**
```sql
-- In Databricks SQL Editor
CREATE CATALOG IF NOT EXISTS onedata_us_east_1_shared_dit;
CREATE SCHEMA IF NOT EXISTS onedata_us_east_1_shared_dit.faq_granular_impact;

-- Verify
SHOW CATALOGS;
SHOW SCHEMAS IN onedata_us_east_1_shared_dit;
```

### Issue 6: Permission Denied in Databricks

**Problem:** Cannot create tables

**Solution:**
```sql
-- Check current user
SELECT current_user();

-- Check permissions
SHOW GRANTS ON CATALOG onedata_us_east_1_shared_dit;
SHOW GRANTS ON SCHEMA faq_granular_impact;

-- Request permissions from admin
-- Need: CREATE TABLE, SELECT, INSERT, UPDATE on schema
```

## Best Practices

### 1. Use Batch Queries

❌ Don't loop over checksums:
```python
for checksum in checksums:
    faqs = spark.sql(f"SELECT * FROM ... WHERE content_checksum = '{checksum}'")
```

✅ Use batch query:
```python
template = QueryTemplates.get_faqs_by_checksums_batch(catalog, schema)
sql = template.format(checksums=checksum_list)
all_faqs = spark.sql(sql)
```

### 2. Respect Temporal Validity

Always filter by `is_valid = TRUE`:
```sql
SELECT * FROM faq_question_sources
WHERE content_checksum = '...'
  AND is_valid = TRUE  -- Current valid sources only
```

### 3. Embed Diff Data as JSON

Store structured diff in `content_change_log.diff_data`:
```python
diff_data = json.dumps({
    "chunks": [...],
    "statistics": {...}
})
```

## Viewing the Database

### Python Script

```python
from granular_impact.database import create_adapter, DatabaseDialect

adapter = create_adapter(
    DatabaseDialect.SQLITE,
    database_path="databases/granular_impact.db"
)

# List all tables
tables = adapter.fetchall(
    "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
)
for table in tables:
    count = adapter.fetchall(f"SELECT COUNT(*) FROM {table[0]}")[0][0]
    print(f"{table[0]}: {count} rows")

adapter.close()
```

### SQLite CLI

```bash
# Open database
sqlite3 databases/granular_impact.db

# Inside SQLite prompt:
.tables                       # List tables
.schema content_checksums     # Show table structure
SELECT * FROM faq_questions;  # Query data
.quit
```

### GUI Tool (Recommended)

**DB Browser for SQLite** (free, cross-platform):
- Download: https://sqlitebrowser.org/
- Open: File → Open Database → Select `databases/granular_impact.db`
- Browse tables, run queries, view schema visually

## Recreating the Database

If you need a fresh start:

```bash
# Delete existing database
rm databases/granular_impact.db

# Recreate with script
python create_database.py
```

Or simply run `create_database.py` - it will prompt to overwrite existing database.

## Testing

Run comprehensive database tests:
```bash
cd FAQ_update
pytest tests/test_database/ -v
```

All tests use SQLite in-memory databases for speed and independence.

## File Reference

**Scripts (in `FAQ_update/` root)**:
- `create_database.py` - Create persistent SQLite database
- `use_database_example.py` - Working examples of insert/query operations

**Database Location**:
- `databases/granular_impact.db` - SQLite database file (created by script)

**Module Files**:
- [schema_manager.py](schema_manager.py) - Unified schema manager
- [adapters.py](adapters.py) - Database adapters (SQLite, Databricks)
- [models.py](models.py) - Data models and enums
- [queries.py](queries.py) - SQL query templates

**Tests**:
- `tests/test_database/` - Comprehensive test suite (85+ tests)

## Quick Reference Commands

### Local Development

```bash
# Create SQLite database
python create_database.py

# Generate SQLite from Databricks
python -m granular_impact.database.generate_sqlite_schemas

# Validate schemas match
python -m granular_impact.database.generate_sqlite_schemas --validate

# Run tests
pytest tests/test_database/ -v

# View database
sqlite3 databases/granular_impact.db ".tables"
```

### Databricks Deployment

```bash
# Dry-run (preview)
python create_database.py --databricks \
  --catalog onedata_us_east_1_shared_dit \
  --schema faq_granular_impact \
  --dry-run

# Actually create
python create_database.py --databricks \
  --catalog onedata_us_east_1_shared_dit \
  --schema faq_granular_impact
```

### Databricks SQL Commands

```sql
-- Verify deployment
USE CATALOG onedata_us_east_1_shared_dit;
USE SCHEMA faq_granular_impact;
SHOW TABLES;

-- Check table structure
DESCRIBE TABLE EXTENDED content_repo;
SHOW CREATE TABLE content_repo;

-- Check constraints
SELECT * FROM information_schema.table_constraints
WHERE table_schema = 'faq_granular_impact';

-- Grant permissions
GRANT ALL PRIVILEGES ON SCHEMA faq_granular_impact TO `user@example.com`;
```

## See Also

- [sql/README.md](sql/README.md) - SQL schema documentation, query templates
- [schema_converter.py](schema_converter.py) - Databricks to SQLite schema converter
- [generate_sqlite_schemas.py](generate_sqlite_schemas.py) - Schema generation script
- [models.py](models.py) - Python dataclass models for all tables
- [queries.py](queries.py) - SQL query templates
- [../README.md](../README.md) - Main granular_impact module
- [../similarity/README.md](../similarity/README.md) - Similarity algorithms
- [../diff/README.md](../diff/README.md) - Diff analysis
- [../impact/README.md](../impact/README.md) - Impact scoring
