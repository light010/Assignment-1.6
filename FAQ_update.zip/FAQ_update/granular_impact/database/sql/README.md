# SQL Scripts Directory

This directory contains SQL scripts for the granular FAQ impact analysis system.

## Structure

```
sql/
├── schema/                         # Database schema
│   └── tables/                     # Individual table definitions (8 files)
│       ├── 00_content_repo.sql
│       ├── 01_content_checksums.sql
│       ├── 02_faq_questions.sql
│       ├── 03_faq_answers.sql
│       ├── 04_faq_question_sources.sql
│       ├── 05_faq_answer_sources.sql
│       ├── 06_content_change_log.sql
│       └── 07_faq_audit_log.sql
├── queries/                        # Query templates (4 files)
│   ├── get_active_faqs_with_sources.sql
│   ├── get_content_diffs_summary.sql
│   ├── get_detection_run_summary.sql
│   └── get_faqs_requiring_regeneration.sql
└── README.md                       # This file
```

## Schema Overview

The database consists of **8 tables**:

### Foundation Table
0. **content_repo** - Repository of source content files and metadata

### Core Tables
1. **content_checksums** - Master content table (checksum is THE identity)
2. **faq_questions** - FAQ questions (content-agnostic)
3. **faq_answers** - FAQ answers (1:1 with questions)

### Provenance Tables
4. **faq_question_sources** - Question provenance with temporal validity
5. **faq_answer_sources** - Answer provenance with temporal validity

### Change Detection
6. **content_change_log** - Content changes with diff_data (JSON), similarity scores, and impact metrics

### Audit
7. **faq_audit_log** - Minimal FK-based audit trail

## Key Concepts

### Checksum-Centric Architecture
- `content_checksum` (SHA-256) is THE content identity
- Location metadata (file_name, etc.) is for human reference only
- Change detection is based on checksums, not locations

### Temporal Validity
- `faq_question_sources` and `faq_answer_sources` track validity over time
- Fields: `is_valid`, `valid_from`, `valid_until`
- Allows tracking which content was valid when
- Supports regeneration without unique constraint violations

### Granular Impact Analysis
- `content_change_log.diff_data` stores structured diff (JSON)
- Impact metrics: `total_faqs_at_risk`, `affected_question_count`, `affected_answer_count`
- Savings = `total_faqs_at_risk - (affected_question_count + affected_answer_count)`

## Query Files

### 1. get_active_faqs_with_sources.sql
Retrieve active FAQs with their source content relationships.

**Parameters:**
- `{catalog}` - Database catalog
- `{schema}` - Database schema
- `{faq_filter}` - Optional FAQ ID filter

**Returns:**
- Question and answer text
- Source checksums (COLLECT_LIST)
- Source counts

### 2. get_content_diffs_summary.sql
Summary of content changes with diff data and impact metrics.

**Parameters:**
- `{catalog}` - Database catalog
- `{schema}` - Database schema
- `{detection_run_filter}` - Optional WHERE clause for detection run

**Returns:**
- Change details (checksums, type, similarity)
- Diff data (JSON)
- Impact metrics (at risk vs affected)
- FAQs saved

### 3. get_detection_run_summary.sql
Summary statistics for detection runs showing savings.

**Parameters:**
- `{catalog}` - Database catalog
- `{schema}` - Database schema
- `{limit}` - Number of recent runs

**Returns:**
- Changes detected
- FAQs at risk vs affected
- **Savings percentage** (key metric)
- Similarity statistics

### 4. get_faqs_requiring_regeneration.sql
FAQs that need regeneration based on content changes.

**Parameters:**
- `{catalog}` - Database catalog
- `{schema}` - Database schema
- `{detection_run_filter}` - Optional AND clause for detection run

**Returns:**
- FAQ question and answer details
- Change information
- Affected component (question/answer/both)

## Usage

### From Python

```python
from granular_impact.database.queries import QueryTemplates

# Get FAQs requiring regeneration
sql = QueryTemplates.get_faqs_requiring_regeneration(
    catalog="prod",
    schema="faq",
    detection_run_id="RUN_2025_01_21"
)

df = spark.sql(sql)
display(df)
```

### Direct SQL File Loading

```python
from pathlib import Path

sql_path = Path(__file__).parent / "sql" / "queries" / "get_detection_run_summary.sql"

with open(sql_path, "r", encoding="utf-8") as f:
    sql = f.read()
    sql = sql.format(catalog="prod", schema="faq", limit="10")

spark.sql(sql)
```

## Parameter Substitution

All query files support parameter substitution using Python format strings:

```python
sql_template = """
SELECT * FROM {catalog}.{schema}.faq_questions
WHERE status = 'active'
  {faq_filter}
"""

sql = sql_template.format(
    catalog="prod",
    schema="faq",
    faq_filter='AND question_id = 12345'
)
```

**Common Parameters:**
- `{catalog}` - Database catalog (Unity Catalog)
- `{schema}` - Database schema
- `{detection_run_id}` - Detection run identifier
- `{faq_filter}` - FAQ-specific filter (e.g., `AND q.question_id = 12345`)
- `{detection_run_filter}` - Detection run filter (e.g., `AND ccl.detection_run_id = "RUN_123"`)
- `{limit}` - Result limit

## Best Practices

### 1. Use Query Templates

✅ **Do:**
```python
sql = QueryTemplates.get_faqs_requiring_regeneration(catalog, schema, ...)
```

❌ **Don't:**
```python
with open("sql/queries/get_faqs_requiring_regeneration.sql") as f:
    sql = f.read().format(catalog=catalog, ...)
```

### 2. Always Use Parameterization

✅ **Do:**
```sql
SELECT * FROM {catalog}.{schema}.faq_questions
WHERE question_id = {question_id}
```

❌ **Don't:**
```sql
SELECT * FROM prod.faq.faq_questions
WHERE question_id = 12345
```

### 3. Test with Edge Cases

Always test queries with:
- Empty result sets
- Large result sets
- NULL values
- Missing data

## See Also

- [../README.md](../README.md) - Database module overview
- [../models.py](../models.py) - Python dataclass models
- [../queries.py](../queries.py) - QueryTemplates class
