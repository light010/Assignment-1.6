-- ============================================================================
-- Query: Get FAQs Requiring Regeneration
-- ============================================================================
-- Purpose: Retrieve FAQs that need regeneration based on content changes
--
-- Parameters:
--   {catalog} - Database catalog name
--   {schema} - Database schema name
--   {detection_run_filter} - Optional: AND clause for specific detection run ID
-- ============================================================================

SELECT DISTINCT
    q.question_id,
    q.question_text,
    a.answer_id,
    SUBSTR(a.answer_text, 1, 200) AS answer_preview,
    ccl.change_id,
    ccl.file_name,
    ccl.previous_checksum AS old_checksum,
    ccl.content_checksum AS new_checksum,
    ccl.change_type,
    ccl.similarity_score,
    ccl.detection_run_id,
    ccl.detection_timestamp,
    CASE
        WHEN qsrc.content_checksum = ccl.previous_checksum THEN 'question'
        WHEN asrc.content_checksum = ccl.previous_checksum THEN 'answer'
        ELSE 'both'
    END AS faq_component_affected
FROM {catalog}.{schema}.content_change_log ccl
INNER JOIN {catalog}.{schema}.faq_question_sources qsrc
    ON qsrc.content_checksum = ccl.previous_checksum
    AND qsrc.is_valid = TRUE
INNER JOIN {catalog}.{schema}.faq_questions q
    ON q.question_id = qsrc.question_id
    AND q.status = 'active'
LEFT JOIN {catalog}.{schema}.faq_answers a
    ON a.question_id = q.question_id
    AND a.status = 'active'
LEFT JOIN {catalog}.{schema}.faq_answer_sources asrc
    ON asrc.answer_id = a.answer_id
    AND asrc.content_checksum = ccl.previous_checksum
    AND asrc.is_valid = TRUE
WHERE ccl.requires_faq_regeneration = TRUE
  {detection_run_filter}

UNION

SELECT DISTINCT
    q.question_id,
    q.question_text,
    a.answer_id,
    SUBSTR(a.answer_text, 1, 200) AS answer_preview,
    ccl.change_id,
    ccl.file_name,
    ccl.previous_checksum AS old_checksum,
    ccl.content_checksum AS new_checksum,
    ccl.change_type,
    ccl.similarity_score,
    ccl.detection_run_id,
    ccl.detection_timestamp,
    'answer' AS faq_component_affected
FROM {catalog}.{schema}.content_change_log ccl
INNER JOIN {catalog}.{schema}.faq_answer_sources asrc
    ON asrc.content_checksum = ccl.previous_checksum
    AND asrc.is_valid = TRUE
INNER JOIN {catalog}.{schema}.faq_answers a
    ON a.answer_id = asrc.answer_id
    AND a.status = 'active'
INNER JOIN {catalog}.{schema}.faq_questions q
    ON q.question_id = a.question_id
    AND q.status = 'active'
WHERE ccl.requires_faq_regeneration = TRUE
  {detection_run_filter}

ORDER BY detection_timestamp DESC, question_id;
