-- ============================================================================
-- Query: Get Content Changes Summary
-- ============================================================================
-- Purpose: Summary of content changes with diff data and impact metrics
--
-- Parameters:
--   {catalog} - Database catalog name
--   {schema} - Database schema name
--   {detection_run_filter} - Optional: WHERE clause for specific detection run
-- ============================================================================

SELECT
    ccl.change_id,
    ccl.file_name,
    ccl.previous_checksum AS old_checksum,
    ccl.content_checksum AS new_checksum,
    ccl.change_type,
    ccl.similarity_score,
    ccl.similarity_method,
    ccl.diff_data,
    ccl.total_faqs_at_risk,
    ccl.affected_question_count,
    ccl.affected_answer_count,
    (ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count)) AS faqs_saved,
    ccl.detection_run_id,
    ccl.detection_timestamp
FROM {catalog}.{schema}.content_change_log ccl
{detection_run_filter}
ORDER BY ccl.detection_timestamp DESC;
