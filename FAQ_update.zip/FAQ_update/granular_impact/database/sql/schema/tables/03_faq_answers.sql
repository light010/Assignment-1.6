-- ============================================================================
-- TABLE: faq_answers
-- ============================================================================
-- Description: FAQ answers - linked to questions (1:1)
-- Dependencies: faq_questions
-- Owner: Analytics Assist Team
--
-- Key Concept: 1:1 relationship with faq_questions
--              Answer cannot exist without a question (FK CASCADE DELETE)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answers (
    -- Primary Identity
    answer_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Link to Question (1:1)
    question_id BIGINT NOT NULL,

    -- Answer Content
    answer_text STRING NOT NULL,
    answer_format STRING DEFAULT 'html' COMMENT 'html, markdown, plain',

    -- Quality Metrics
    confidence_score DOUBLE,

    -- Status
    status STRING NOT NULL DEFAULT 'active',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'FAQ answers - linked to questions (1:1)'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.feature.allowColumnDefaults' = 'supported'
);

-- Primary Key
ALTER TABLE faq_answers ADD CONSTRAINT IF NOT EXISTS pk_faq_answers
    PRIMARY KEY (answer_id);

-- Check Constraints
ALTER TABLE faq_answers ADD CONSTRAINT IF NOT EXISTS chk_answer_status
    CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));

ALTER TABLE faq_answers ADD CONSTRAINT IF NOT EXISTS chk_answer_format
    CHECK (answer_format IN ('html', 'markdown', 'plain'));

ALTER TABLE faq_answers ADD CONSTRAINT IF NOT EXISTS chk_confidence_score
    CHECK (confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0));

-- Foreign Key
ALTER TABLE faq_answers ADD CONSTRAINT IF NOT EXISTS fk_answers_questions
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE;
