-- ============================================================================
-- TABLE: content_repo
-- ============================================================================
-- Description: Repository of source content files and their metadata
-- Dependencies: None (foundation table)
-- Owner: Analytics Assist Team
--
-- Key Concept: Tracks raw source files with their extracted content paths
--              This table serves as the source-of-truth for content ingestion
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_repo (
    -- Primary key
    ud_source_file_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY COMMENT 'Auto-incrementing primary key',

    -- File identification
    raw_file_nme STRING NOT NULL COMMENT 'Raw file name',
    raw_file_type STRING COMMENT 'File type (pdf, docx, html, etc.)',
    raw_file_version_nbr INT DEFAULT 1 COMMENT 'File version number',

    -- Source information
    raw_file_path STRING COMMENT 'Full path to raw file',

    -- Content paths
    extracted_markdown_file_path STRING COMMENT 'Path to extracted markdown file',

    -- Content metadata
    title_nme STRING COMMENT 'Document title',
    content_checksum STRING COMMENT 'SHA-256 hash (64 chars) - links to content_checksums',
    file_status STRING COMMENT 'Active, Inactive, or Archived',

    -- Timestamps
    created_dt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation timestamp',
    last_modified_dt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'Last modification timestamp'
)
COMMENT 'Repository of source content files - source-of-truth for content ingestion'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true',
    'delta.deletedFileRetentionDuration' = 'interval 30 days',
    'delta.logRetentionDuration' = 'interval 90 days',
    'delta.feature.allowColumnDefaults' = 'supported'
);

-- Primary Key
ALTER TABLE content_repo ADD CONSTRAINT IF NOT EXISTS pk_content_repo
    PRIMARY KEY (ud_source_file_id);

-- Check Constraints
ALTER TABLE content_repo ADD CONSTRAINT IF NOT EXISTS chk_content_checksum_length
    CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64);

ALTER TABLE content_repo ADD CONSTRAINT IF NOT EXISTS chk_file_status
    CHECK (file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived'));
