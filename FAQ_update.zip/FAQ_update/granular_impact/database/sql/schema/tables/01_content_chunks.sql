-- ============================================================================
-- TABLE: content_chunks (Databricks Delta)
-- ============================================================================
-- Description: Stores individual content chunks with checksums
-- Dependencies: content_repo (FK: ud_source_file_id)
-- Owner: Analytics Assist Team
--
-- Key Concept: Each row represents ONE chunk of content from a source file.
--              Multiple chunks belong to one file version.
--              Chunks are identified by their SHA-256 checksum.
--              Foreign key to content_repo enables version tracking.
--
-- Design Principles:
--   - Same content can appear in different files (shared boilerplate)
--   - Same content can appear at different positions in same file (repeated headers/footers)
--   - No duplicate checksums allowed within same file
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_chunks (
    -- Primary Key
    chunk_id BIGINT GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key to content_repo
    ud_source_file_id BIGINT NOT NULL,

    -- Chunk Identity
    chunk_index INT NOT NULL,                      -- Position in file (0, 1, 2, ...)
    content_checksum STRING NOT NULL,              -- SHA-256 hash (64 chars)

    -- Chunk Content
    chunk_text STRING NOT NULL,                    -- Actual chunk text

    -- Optional Metadata
    chunk_page_number INT,                         -- Page number (if applicable)
    chunk_start_char INT,                          -- Character position start
    chunk_end_char INT,                            -- Character position end

    -- Timestamps and Status
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    status STRING NOT NULL DEFAULT 'active',

    -- Constraints
    CONSTRAINT pk_content_chunks PRIMARY KEY (chunk_id),
    CONSTRAINT fk_chunks_source_file FOREIGN KEY (ud_source_file_id)
        REFERENCES content_repo(ud_source_file_id),
    CONSTRAINT uq_file_chunk_checksum UNIQUE (ud_source_file_id, content_checksum),
    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
    CONSTRAINT chk_chunk_status CHECK (status IN ('active', 'archived', 'deleted'))
)
USING DELTA
PARTITIONED BY (status)
LOCATION '/mnt/data/content_chunks';

-- Optimize for queries by file and checksum
OPTIMIZE content_chunks ZORDER BY (ud_source_file_id, content_checksum);

-- ============================================================================
-- USAGE EXAMPLES (Databricks SQL)
-- ============================================================================
--
-- Insert chunks for a file:
--   INSERT INTO content_chunks
--   (ud_source_file_id, chunk_index, content_checksum, chunk_text, status)
--   VALUES (1, 0, 'abc123...', 'Chapter 1 content...', 'active');
--
-- Get all chunks for file version:
--   SELECT cc.* FROM content_chunks cc
--   JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
--   WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 1
--   ORDER BY cc.chunk_index;
-- ============================================================================
