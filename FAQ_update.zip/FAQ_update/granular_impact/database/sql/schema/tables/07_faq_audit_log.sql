-- ============================================================================
-- TABLE: faq_audit_log
-- ============================================================================
-- Description: Minimal audit trail tracking FAQ-level operations and impact
-- Dependencies: content_change_log, faq_questions, faq_answers
-- Owner: Analytics Assist Team
--
-- Key Concept: Simplified audit log with only essential foreign key references
--              Tracks which FAQs were affected by which content changes
--              Enables traceability without data duplication
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_audit_log (
    -- Primary Identity
    audit_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Foreign Key References (Primary Keys from other tables)
    change_id BIGINT COMMENT 'FK to content_change_log',
    question_id BIGINT COMMENT 'FK to faq_questions',
    answer_id BIGINT COMMENT 'FK to faq_answers (NULL if question-only audit)',
    detection_run_id STRING COMMENT 'Detection run identifier',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Minimal audit trail - tracks FAQ operations via foreign key references'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.feature.allowColumnDefaults' = 'supported'
);

-- Primary Key
ALTER TABLE faq_audit_log ADD CONSTRAINT IF NOT EXISTS pk_faq_audit_log
    PRIMARY KEY (audit_id);

-- Foreign Key Constraints
ALTER TABLE faq_audit_log ADD CONSTRAINT IF NOT EXISTS fk_audit_change
    FOREIGN KEY (change_id) REFERENCES content_change_log(change_id) ON DELETE CASCADE;

ALTER TABLE faq_audit_log ADD CONSTRAINT IF NOT EXISTS fk_audit_question
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id) ON DELETE CASCADE;

ALTER TABLE faq_audit_log ADD CONSTRAINT IF NOT EXISTS fk_audit_answer
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id) ON DELETE CASCADE;
