# Database Schema Directory - Modular SQL Structure

Enterprise-grade modular SQL organization for granular FAQ impact analysis.

## Philosophy

Following best practices from Netflix, Airbnb, Uber, and Google:
- **One file per table** - Easy to find, review, and modify
- **Explicit dependencies** - Documented in YAML
- **Separation by function** - Each table has a clear, single purpose
- **Clean git diffs** - Small files = easy PR reviews
- **Self-documenting** - File names and order tell the story

## Directory Structure

```
schema/
├── tables/              # Table definitions (7 files, ~45-87 lines each)
│   ├── 01_content_checksums.sql
│   ├── 02_faq_questions.sql
│   ├── 03_faq_answers.sql
│   ├── 04_faq_question_sources.sql
│   ├── 05_faq_answer_sources.sql
│   ├── 06_content_change_log.sql
│   └── 07_faq_audit_log.sql
├── _meta/               # Schema orchestration metadata
│   └── dependency_graph.yaml
└── README.md            # This file
```

**Note**: Foreign keys are embedded directly in table files. No separate directories for constraints, views, or indexes - keeping it simple and focused on core tables only.

## Tables Directory ([tables/](tables/))

Individual SQL file per table, prefixed with creation order:

| File | Table | Lines | Dependencies | Description |
|------|-------|-------|--------------|-------------|
| `01_content_checksums.sql` | content_checksums | ~55 | None | Master content table (foundation) |
| `02_faq_questions.sql` | faq_questions | ~45 | None | FAQ questions (content-agnostic) |
| `03_faq_answers.sql` | faq_answers | ~58 | faq_questions | FAQ answers (1:1 with questions) |
| `04_faq_question_sources.sql` | faq_question_sources | ~58 | faq_questions, content_checksums | Question provenance (temporal validity) |
| `05_faq_answer_sources.sql` | faq_answer_sources | ~57 | faq_answers, content_checksums | Answer provenance (temporal validity) |
| `06_content_change_log.sql` | content_change_log | ~87 | content_checksums | Change detection with diff data + impact metrics |
| `07_faq_audit_log.sql` | faq_audit_log | ~47 | content_change_log, faq_questions, faq_answers | Minimal audit trail (FK references only) |

**Total**: 7 tables, ~407 lines (avg ~58 lines/table)

**Design Philosophy**: Simplified architecture with 7 core tables:
- Diff data merged into `content_change_log.diff_data` (JSON field)
- Impact analysis tracked via `faq_audit_log` foreign key references
- Minimal design eliminating redundant tables

**File Format**:
- Header comment block (description, dependencies, owner)
- CREATE TABLE statement with inline comments
- Primary key constraints
- Check constraints
- Foreign key constraints (embedded in table file)
- Table properties (Delta Lake)

## Foreign Keys

All foreign key constraints are **embedded directly in table files** for simplicity:

| Table | Foreign Keys | References |
|-------|--------------|------------|
| `faq_answers` | 1 FK | → faq_questions (CASCADE DELETE) |
| `faq_question_sources` | 3 FKs | → faq_questions, content_checksums, content_change_log |
| `faq_answer_sources` | 3 FKs | → faq_answers, content_checksums, content_change_log |
| `faq_audit_log` | 3 FKs | → content_change_log, faq_questions, faq_answers |

**Total**: 10 foreign key constraints embedded in 4 table files

**Design Philosophy**:
- Keep FKs with their tables (single source of truth)
- No separate constraints directory needed
- Simpler to maintain and review
- All constraints use `IF NOT EXISTS` for idempotency

## Metadata Directory ([_meta/](_meta/))

### [dependency_graph.yaml](_meta/dependency_graph.yaml)

Simple YAML file defining:
1. **Table dependencies** - Which tables must exist before creating others
2. **Creation order** - Sequential order (1-7) for table creation
3. **Table descriptions** - What each table does

**Used by**: `SchemaManager` class for orchestrated schema creation

**Example**:
```yaml
tables:
  content_checksums:
    file: "tables/01_content_checksums.sql"
    dependencies: []
    order: 1
    description: "Master content identity table (foundation)"
    notes: "Checksum is THE identity; location is metadata only"

  faq_audit_log:
    file: "tables/07_faq_audit_log.sql"
    dependencies:
      - "content_change_log"
      - "faq_questions"
      - "faq_answers"
    order: 7
    description: "Minimal audit trail (FK references only)"
    notes: "Tracks which FAQs affected by which changes"
```

**Simplified Design**: No constraints, views, or indexes sections - just tables.

## Usage

### With SchemaManager (Recommended)

```python
from granular_impact.database import SchemaManager

manager = SchemaManager(spark, catalog="prod", schema="faq")

# Create all 7 tables in dependency order
manager.create_tables()

# Create specific table with auto-dependency resolution
manager.create_tables(specific_tables=["faq_audit_log"])
# Auto-creates: content_change_log, faq_questions, faq_answers, content_checksums

# Dry-run to see execution plan
manager.create_tables(dry_run=True)
```

### Manual Creation (For Testing/Debugging)

```python
# Read individual table file
from pathlib import Path

schema_dir = Path("sql/schema")
sql_file = schema_dir / "tables" / "01_content_checksums.sql"

with open(sql_file) as f:
    sql = f.read()

# Execute
spark.sql("USE CATALOG prod")
spark.sql("USE SCHEMA faq")
spark.sql(sql)
```

### Direct SQL Execution

```sql
-- In Databricks notebook
USE CATALOG prod;
USE SCHEMA faq;

-- Run individual file content
-- (paste content from tables/01_content_checksums.sql)
```

## Benefits of Modular Structure

### Current (Clean Modular)
```
tables/
  01_content_checksums.sql      (~55 lines)
  02_faq_questions.sql          (~45 lines)
  03_faq_answers.sql            (~58 lines)
  04_faq_question_sources.sql   (~58 lines)
  05_faq_answer_sources.sql     (~57 lines)
  06_content_change_log.sql     (~87 lines)
  07_faq_audit_log.sql          (~47 lines)
_meta/
  dependency_graph.yaml         (~95 lines)
```

**Total**: 7 files, ~407 lines of SQL + 1 YAML dependency file

### Advantages
- ✅ **Simple**: Only 7 core tables, no extra directories
- ✅ **Easy to navigate**: Find any table in seconds
- ✅ **Clean diffs**: Only changed files show up in PRs
- ✅ **Independent history**: Each table has its own git history
- ✅ **Testable**: Can test individual tables in isolation
- ✅ **No conflicts**: Different developers work on different files
- ✅ **Self-documenting**: File names = table names, order = creation order
- ✅ **Explicit dependencies**: dependency_graph.yaml makes relationships clear

## File Naming Conventions

### Tables
- Prefix with order number: `01_`, `02_`, etc.
- Use snake_case matching table name
- Example: `04_faq_question_sources.sql`

## Adding New Tables

1. Create SQL file in `tables/` with next order number (e.g., `08_new_table.sql`)
2. Add header comment with description and dependencies
3. Write `CREATE TABLE IF NOT EXISTS` with inline comments
4. Add primary key, check constraints, and any foreign keys
5. Update `_meta/dependency_graph.yaml`:
   ```yaml
   tables:
     new_table_name:
       file: "tables/08_new_table.sql"
       dependencies: ["dependent_table1", "dependent_table2"]
       order: 8
       description: "What this table does"
       notes: "Additional context"
   ```
6. Test creation:
   ```python
   manager.create_tables(specific_tables=["new_table_name"], dry_run=True)
   manager.create_tables(specific_tables=["new_table_name"])
   ```

## See Also

- [../README.md](../README.md) - SQL directory overview
- [../../README.md](../../README.md) - Database module documentation
- [../../schema_manager.py](../../schema_manager.py) - Schema orchestration class
- [../migrations/README.md](../migrations/README.md) - Migration guide (if needed)
