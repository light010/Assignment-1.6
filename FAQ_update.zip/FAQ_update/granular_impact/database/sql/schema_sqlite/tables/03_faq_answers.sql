-- ============================================================================
-- TABLE: faq_answers
-- ============================================================================
-- Description: FAQ answers - linked to questions (1:1)
-- Dependencies: faq_questions
-- Owner: Analytics Assist Team
--
-- Key Concept: 1:1 relationship with faq_questions
--              Answer cannot exist without a question (FK CASCADE DELETE)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answers (
    -- Primary Identity
    answer_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Link to Question (1:1)
    question_id INTEGER NOT NULL,

    -- Answer Content
    answer_text TEXT NOT NULL,
    answer_format TEXT DEFAULT 'html',

    -- Quality Metrics
    confidence_score DOUBLE,

    -- Status
    status TEXT NOT NULL DEFAULT 'active',

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    CONSTRAINT chk_answer_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted')),
    CONSTRAINT chk_answer_format CHECK (answer_format IN ('html', 'markdown', 'plain')),
    CONSTRAINT chk_confidence_score CHECK (confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0))
);

-- Primary Key

-- Check Constraints

-- Foreign Key
