-- ============================================================================
-- TABLE: faq_question_sources
-- ============================================================================
-- Description: Question provenance - which content inspired each question
-- Dependencies: faq_questions, content_checksums
-- Owner: Analytics Assist Team
--
-- Key Concept: Temporal validity tracking
--              is_valid + valid_from + valid_until = time-based provenance
--              Allows tracking which content was valid when
--              Supports regeneration without unique constraint violations
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_question_sources (
    -- Primary Identity
    source_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Links
    question_id INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,

    -- Source Attribution
    is_primary_source BOOLEAN DEFAULT FALSE,
    contribution_weight DOUBLE,

    -- Temporal Validity
    is_valid BOOLEAN NOT NULL DEFAULT TRUE,
    valid_from TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until TEXT,

    -- Invalidation Tracking
    invalidation_reason TEXT,
    invalidated_by_change_id INTEGER,

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    CONSTRAINT chk_qsrc_contribution CHECK (contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0))
);

-- Primary Key

-- Check Constraints

-- Foreign Key Constraints

-- NOTE: NO UNIQUE constraint on (question_id, content_checksum)
-- Reason: Same question can use same source across different validity periods
-- Temporal uniqueness is enforced via (is_valid, valid_from, valid_until) logic instead
-- This allows regeneration to reuse sources without constraint violations
