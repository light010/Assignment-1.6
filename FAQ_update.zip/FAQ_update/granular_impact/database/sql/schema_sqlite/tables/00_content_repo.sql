-- ============================================================================
-- TABLE: content_repo
-- ============================================================================
-- Description: Repository of source content files and their metadata
-- Dependencies: None (foundation table)
-- Owner: Analytics Assist Team
--
-- Key Concept: Tracks raw source files with their extracted content paths
--              This table serves as the source-of-truth for content ingestion
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_repo (
    -- Primary key
    ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- File identification
    raw_file_nme TEXT NOT NULL,
    raw_file_type TEXT,
    raw_file_version_nbr INT DEFAULT 1,

    -- Source information
    raw_file_path TEXT,

    -- Content paths
    extracted_markdown_file_path TEXT,

    -- Content metadata
    title_nme TEXT,
    content_checksum TEXT,
    file_status TEXT,

    -- Timestamps
    created_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_dt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Constraints
    UNIQUE(raw_file_nme, raw_file_version_nbr),
    CONSTRAINT chk_content_checksum_length CHECK (content_checksum IS NULL OR LENGTH(content_checksum) = 64),
    CONSTRAINT chk_file_status CHECK (file_status IS NULL OR file_status IN ('Active', 'Inactive', 'Archived'))
);

-- Primary Key

-- Check Constraints
