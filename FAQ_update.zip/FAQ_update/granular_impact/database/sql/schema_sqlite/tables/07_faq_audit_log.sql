-- ============================================================================
-- TABLE: faq_audit_log
-- ============================================================================
-- Description: Minimal audit trail tracking FAQ-level operations and impact
-- Dependencies: content_change_log, faq_questions, faq_answers
-- Owner: Analytics Assist Team
--
-- Key Concept: Simplified audit log with only essential foreign key references
--              Tracks which FAQs were affected by which content changes
--              Enables traceability without data duplication
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_audit_log (
    -- Primary Identity
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Foreign Key References (Primary Keys from other tables)
    change_id INTEGER,
    question_id INTEGER,
    answer_id INTEGER,
    detection_run_id TEXT,

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Primary Key

-- Foreign Key Constraints
