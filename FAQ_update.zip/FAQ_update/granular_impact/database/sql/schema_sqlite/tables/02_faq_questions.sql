-- ============================================================================
-- TABLE: faq_questions
-- ============================================================================
-- Description: FAQ questions - content-agnostic
-- Dependencies: None (independent of content)
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Questions can exist without answers (draft state)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_questions (
    -- Primary Identity
    question_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Question Content
    question_text TEXT NOT NULL,

    -- Metadata
    source_type TEXT,
    generation_method TEXT,

    -- Status
    status TEXT NOT NULL DEFAULT 'active',

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
,
    CONSTRAINT chk_question_status CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'))
);

-- Primary Key

-- Check Constraints
