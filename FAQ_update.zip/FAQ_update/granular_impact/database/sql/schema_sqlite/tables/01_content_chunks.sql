-- ============================================================================
-- TABLE: content_chunks
-- ============================================================================
-- Description: Stores individual content chunks with checksums
-- Dependencies: content_repo (FK: ud_source_file_id)
-- Owner: Analytics Assist Team
--
-- Key Concept: Each row represents ONE chunk of content from a source file.
--              Multiple chunks belong to one file version.
--              Chunks are identified by their SHA-256 checksum.
--              Foreign key to content_repo enables version tracking.
--
-- Design Principles:
--   - chunk_id: Auto-increment surrogate PK for simple references
--   - content_checksum: Natural key (SHA-256), unique within file
--   - chunk_text: Stores actual content (no re-chunking needed)
--   - chunk_index: Preserves original order within file
--   - ud_source_file_id: Links to content_repo for version tracking
--   - Same content can appear in different files (shared boilerplate)
--   - Same content can appear at different positions in same file (repeated headers/footers)
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_chunks (
    -- Primary Key
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Foreign Key to content_repo
    ud_source_file_id INTEGER NOT NULL,

    -- Chunk Identity
    chunk_index INTEGER NOT NULL,              -- Position in file (0, 1, 2, ...)
    content_checksum TEXT NOT NULL,            -- SHA-256 hash (64 chars)

    -- Chunk Content
    chunk_text TEXT NOT NULL,                  -- Actual chunk text

    -- Optional Metadata
    chunk_page_number INTEGER,                 -- Page number (if applicable)
    chunk_start_char INTEGER,                  -- Character position start
    chunk_end_char INTEGER,                    -- Character position end

    -- Timestamps and Status
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active',

    -- Constraints
    FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE,                          -- Delete chunks when file deleted
    UNIQUE(ud_source_file_id, content_checksum),     -- No duplicate checksums per file
    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
    CONSTRAINT chk_chunk_status CHECK (status IN ('active', 'archived', 'deleted'))
);

-- Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_chunks_checksum
    ON content_chunks(content_checksum);

CREATE INDEX IF NOT EXISTS idx_chunks_source_file
    ON content_chunks(ud_source_file_id);

CREATE INDEX IF NOT EXISTS idx_chunks_status
    ON content_chunks(status);

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================
--
-- Insert chunks for a file:
--   INSERT INTO content_chunks
--   (ud_source_file_id, chunk_index, content_checksum, chunk_text)
--   VALUES (1, 0, 'abc123...', 'Chapter 1 content...');
--
-- Get all chunks for file version:
--   SELECT cc.* FROM content_chunks cc
--   JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
--   WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 1
--   ORDER BY cc.chunk_index;
--
-- Compare two versions:
--   -- Get v1 chunks
--   SELECT cc.content_checksum, cc.chunk_text
--   FROM content_chunks cc
--   JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
--   WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 1;
--
--   -- Get v2 chunks
--   SELECT cc.content_checksum, cc.chunk_text
--   FROM content_chunks cc
--   JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
--   WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 2;
-- ============================================================================
