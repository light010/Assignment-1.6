"""
Data models for granular impact analysis.

Defines dataclass models matching the 8-table database schema:

Core Tables (8):
0. ContentRepo - Repository of source content files and metadata
1. ContentChecksum - Master content table (checksum is THE identity)
2. FAQQuestion - FAQ questions (content-agnostic)
3. FAQAnswer - FAQ answers (1:1 with questions)
4. FAQQuestionSource - Question provenance with temporal validity
5. FAQAnswerSource - Answer provenance with temporal validity
6. ContentChangeLog - Change detection with diff_data (JSON), similarity scores, impact metrics
7. AuditLogEntry - Minimal audit trail (FK references only)

Helper Models:
- ContentChange - Transient model for change detection phase (not persisted)

Enums:
- ContentStatus, FAQStatus, SourceType, GenerationMethod
- ChangeType, InvalidationReason, AnswerFormat, FileStatus
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


# ============================================================================
# ENUMS
# ============================================================================


class ContentStatus(str, Enum):
    """Content status values."""

    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"


class FAQStatus(str, Enum):
    """FAQ status values."""

    ACTIVE = "active"
    INVALIDATED = "invalidated"
    ARCHIVED = "archived"
    DELETED = "deleted"


class SourceType(str, Enum):
    """FAQ source types."""

    FROM_DOCUMENTS = "from_documents"
    FROM_USER_QUERIES = "from_user_queries"
    FROM_MANUAL = "from_manual"
    FROM_VALIDATION = "from_validation"


class GenerationMethod(str, Enum):
    """FAQ generation methods."""

    LLM_GENERATED = "llm_generated"
    HUMAN_WRITTEN = "human_written"
    EXTRACTED = "extracted"


class ChangeType(str, Enum):
    """Content change types."""

    NEW_CONTENT = "new_content"
    MODIFIED_CONTENT = "modified_content"
    UNCHANGED_CONTENT = "unchanged_content"
    DELETED_CONTENT = "deleted_content"
    LOCATION_CHANGE = "location_change"


class InvalidationReason(str, Enum):
    """Provenance invalidation reasons."""

    CONTENT_CHANGED = "content_changed"
    CONTENT_DELETED = "content_deleted"
    QUALITY_ISSUE = "quality_issue"
    MANUAL = "manual"
    SELECTIVE_IMPACT = "selective_impact"


class AnswerFormat(str, Enum):
    """Answer text formats."""

    HTML = "html"
    MARKDOWN = "markdown"
    PLAIN = "plain"


class FileStatus(str, Enum):
    """File status values for content_repo."""

    ACTIVE = "Active"
    INACTIVE = "Inactive"
    ARCHIVED = "Archived"


# ============================================================================
# CORE TABLES (from V8)
# ============================================================================


@dataclass
class ContentRepo:
    """
    Repository of source content files and their metadata.

    Maps to: content_repo table

    Tracks raw source files with their extracted content paths.
    This table serves as the source-of-truth for content ingestion.
    """

    raw_file_nme: str
    created_dt: datetime = field(default_factory=datetime.now)
    last_modified_dt: datetime = field(default_factory=datetime.now)

    ud_source_file_id: Optional[int] = None  # AUTOINCREMENT primary key
    raw_file_type: Optional[str] = None
    raw_file_version_nbr: int = 1
    raw_file_path: Optional[str] = None
    extracted_markdown_file_path: Optional[str] = None
    title_nme: Optional[str] = None
    content_checksum: Optional[str] = None
    file_status: Optional[FileStatus] = None

    def __post_init__(self):
        """Validate content checksum length if provided."""
        if self.content_checksum is not None:
            if len(self.content_checksum) != 64:
                raise ValueError(
                    f"content_checksum must be 64 chars, got {len(self.content_checksum)}"
                )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "ud_source_file_id": self.ud_source_file_id,
            "raw_file_nme": self.raw_file_nme,
            "raw_file_type": self.raw_file_type,
            "raw_file_version_nbr": self.raw_file_version_nbr,
            "raw_file_path": self.raw_file_path,
            "extracted_markdown_file_path": self.extracted_markdown_file_path,
            "title_nme": self.title_nme,
            "content_checksum": self.content_checksum,
            "file_status": self.file_status.value if self.file_status else None,
            "created_dt": self.created_dt,
            "last_modified_dt": self.last_modified_dt,
        }


@dataclass
class ContentChecksum:
    """
    Represents a unique content identity (master content table).

    Maps to: content_checksums table

    The content_checksum is THE identity. Location metadata (file_name,
    page_number, etc.) is for human reference only, NOT for content analysis.
    """

    content_checksum: str  # SHA-256 hash (64 chars) - THE identity
    status: ContentStatus = ContentStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)

    # Content Properties
    file_type: Optional[str] = None  # pdf, html, docx, xml, confluence
    content_format: Optional[str] = None  # markdown, html, plain_text
    title: Optional[str] = None

    # METADATA: Location information (for human reference only)
    file_name: Optional[str] = None
    url: Optional[str] = None
    source_file_path: Optional[str] = None
    file_version: Optional[str] = None

    # Content Storage
    markdown_file_path: Optional[str] = None

    def __post_init__(self):
        """Validate checksum length."""
        if len(self.content_checksum) != 64:
            raise ValueError(f"content_checksum must be 64 chars, got {len(self.content_checksum)}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "content_checksum": self.content_checksum,
            "file_type": self.file_type,
            "content_format": self.content_format,
            "title": self.title,
            "status": self.status.value,
            "file_name": self.file_name,
            "url": self.url,
            "source_file_path": self.source_file_path,
            "file_version": self.file_version,
            "markdown_file_path": self.markdown_file_path,
            "created_at": self.created_at,
        }


@dataclass
class FAQQuestion:
    """
    Represents an FAQ question (content-agnostic).

    Maps to: faq_questions table
    """

    question_id: Optional[int] = None  # IDENTITY column, assigned by DB
    question_text: str = ""
    status: FAQStatus = FAQStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    modified_at: datetime = field(default_factory=datetime.now)

    # Metadata
    source_type: Optional[SourceType] = None
    generation_method: Optional[GenerationMethod] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "question_id": self.question_id,
            "question_text": self.question_text,
            "source_type": self.source_type.value if self.source_type else None,
            "generation_method": self.generation_method.value if self.generation_method else None,
            "status": self.status.value,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
        }


@dataclass
class FAQQuestionSource:
    """
    Question provenance - which content inspired each question.

    Maps to: faq_question_sources table

    Supports temporal validity:
    - is_valid: Current validity status
    - valid_from/valid_until: Validity time range
    - invalidation_reason: Why it was invalidated
    - invalidated_by_change_id: Which content change caused invalidation
    """

    question_id: int
    content_checksum: str
    is_valid: bool = True
    valid_from: datetime = field(default_factory=datetime.now)
    created_at: datetime = field(default_factory=datetime.now)

    source_id: Optional[int] = None  # IDENTITY column
    is_primary_source: bool = False
    contribution_weight: Optional[float] = None  # 0.0 to 1.0
    valid_until: Optional[datetime] = None
    invalidation_reason: Optional[InvalidationReason] = None
    invalidated_by_change_id: Optional[int] = None

    def __post_init__(self):
        """Validate contribution weight."""
        if self.contribution_weight is not None:
            if not (0.0 <= self.contribution_weight <= 1.0):
                raise ValueError(f"contribution_weight must be 0.0-1.0, got {self.contribution_weight}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "source_id": self.source_id,
            "question_id": self.question_id,
            "content_checksum": self.content_checksum,
            "is_primary_source": self.is_primary_source,
            "contribution_weight": self.contribution_weight,
            "is_valid": self.is_valid,
            "valid_from": self.valid_from,
            "valid_until": self.valid_until,
            "invalidation_reason": self.invalidation_reason.value if self.invalidation_reason else None,
            "invalidated_by_change_id": self.invalidated_by_change_id,
            "created_at": self.created_at,
        }


@dataclass
class FAQAnswer:
    """
    Represents an FAQ answer (linked to question 1:1).

    Maps to: faq_answers table
    """

    question_id: int
    answer_text: str
    status: FAQStatus = FAQStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    modified_at: datetime = field(default_factory=datetime.now)

    answer_id: Optional[int] = None  # IDENTITY column
    answer_format: AnswerFormat = AnswerFormat.HTML
    confidence_score: Optional[float] = None  # 0.0 to 1.0

    def __post_init__(self):
        """Validate confidence score."""
        if self.confidence_score is not None:
            if not (0.0 <= self.confidence_score <= 1.0):
                raise ValueError(f"confidence_score must be 0.0-1.0, got {self.confidence_score}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "answer_id": self.answer_id,
            "question_id": self.question_id,
            "answer_text": self.answer_text,
            "answer_format": self.answer_format.value,
            "confidence_score": self.confidence_score,
            "status": self.status.value,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
        }


@dataclass
class FAQAnswerSource:
    """
    Answer provenance - which content provided answer information.

    Maps to: faq_answer_sources table

    Supports temporal validity similar to FAQQuestionSource.
    """

    answer_id: int
    content_checksum: str
    is_valid: bool = True
    valid_from: datetime = field(default_factory=datetime.now)
    created_at: datetime = field(default_factory=datetime.now)

    source_id: Optional[int] = None  # IDENTITY column
    is_primary_source: bool = False
    contribution_weight: Optional[float] = None  # 0.0 to 1.0
    context_employed: Optional[str] = None  # JSON: which sections/paragraphs used
    valid_until: Optional[datetime] = None
    invalidation_reason: Optional[InvalidationReason] = None
    invalidated_by_change_id: Optional[int] = None

    def __post_init__(self):
        """Validate contribution weight."""
        if self.contribution_weight is not None:
            if not (0.0 <= self.contribution_weight <= 1.0):
                raise ValueError(f"contribution_weight must be 0.0-1.0, got {self.contribution_weight}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "source_id": self.source_id,
            "answer_id": self.answer_id,
            "content_checksum": self.content_checksum,
            "is_primary_source": self.is_primary_source,
            "contribution_weight": self.contribution_weight,
            "context_employed": self.context_employed,
            "is_valid": self.is_valid,
            "valid_from": self.valid_from,
            "valid_until": self.valid_until,
            "invalidation_reason": self.invalidation_reason.value if self.invalidation_reason else None,
            "invalidated_by_change_id": self.invalidated_by_change_id,
            "created_at": self.created_at,
        }


@dataclass
class ContentChangeLog:
    """
    Content change detection log with granular impact analysis.

    Maps to: content_change_log table

    Tracks similarity scores and granular impact counts
    (affected_question_count, affected_answer_count) instead of blanket invalidation.
    """

    content_checksum: str  # NEW checksum
    file_name: str
    requires_faq_regeneration: bool
    detection_run_id: str
    detection_timestamp: datetime = field(default_factory=datetime.now)
    total_faqs_at_risk: int = 0  # Total FAQs linked to old checksum
    affected_question_count: int = 0  # Questions actually affected
    affected_answer_count: int = 0  # Answers actually affected

    change_id: Optional[int] = None  # IDENTITY column
    previous_checksum: Optional[str] = None  # NULL for new content
    change_type: Optional[ChangeType] = None
    similarity_score: Optional[float] = None  # 0.0 to 1.0
    similarity_method: Optional[str] = None  # bm25, jaccard, cosine, levenshtein, hybrid
    diff_data: Optional[str] = None  # JSON: structured diff data

    def __post_init__(self):
        """Validate checksums and similarity score."""
        if len(self.content_checksum) != 64:
            raise ValueError(f"content_checksum must be 64 chars, got {len(self.content_checksum)}")
        if self.previous_checksum and len(self.previous_checksum) != 64:
            raise ValueError(f"previous_checksum must be 64 chars, got {len(self.previous_checksum)}")
        if self.similarity_score is not None:
            if not (0.0 <= self.similarity_score <= 1.0):
                raise ValueError(f"similarity_score must be 0.0-1.0, got {self.similarity_score}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "change_id": self.change_id,
            "content_checksum": self.content_checksum,
            "previous_checksum": self.previous_checksum,
            "file_name": self.file_name,
            "requires_faq_regeneration": self.requires_faq_regeneration,
            "change_type": self.change_type.value if self.change_type else None,
            "similarity_score": self.similarity_score,
            "similarity_method": self.similarity_method,
            "diff_data": self.diff_data,
            "total_faqs_at_risk": self.total_faqs_at_risk,
            "affected_question_count": self.affected_question_count,
            "affected_answer_count": self.affected_answer_count,
            "detection_run_id": self.detection_run_id,
            "detection_timestamp": self.detection_timestamp,
        }


@dataclass
class AuditLogEntry:
    """
    Minimal audit trail for FAQ operations.

    Maps to: faq_audit_log table

    Tracks which FAQs were affected by which content changes via foreign key references.
    """

    audit_id: Optional[int] = None  # IDENTITY column
    change_id: Optional[int] = None  # FK to content_change_log
    question_id: Optional[int] = None  # FK to faq_questions
    answer_id: Optional[int] = None  # FK to faq_answers
    detection_run_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "audit_id": self.audit_id,
            "change_id": self.change_id,
            "question_id": self.question_id,
            "answer_id": self.answer_id,
            "detection_run_id": self.detection_run_id,
            "created_at": self.created_at,
        }


# ============================================================================
# HELPER MODELS (not directly mapped to tables)
# ============================================================================


@dataclass
class ContentChange:
    """
    Represents a detected change in content (used during change detection phase).

    This is a transient model used before persisting to ContentChangeLog.
    """

    old_checksum: str  # Previous content checksum
    new_checksum: str  # New content checksum
    change_type: ChangeType
    detected_at: datetime = field(default_factory=datetime.now)

    file_name: Optional[str] = None
    page_number: Optional[int] = None
    old_content: Optional[str] = None
    new_content: Optional[str] = None
    similarity_score: Optional[float] = None
    llm_friendly_diff: Optional[str] = None  # LLM-friendly diff for MODIFIED content

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "old_checksum": self.old_checksum,
            "new_checksum": self.new_checksum,
            "change_type": self.change_type.value,
            "detected_at": self.detected_at,
            "file_name": self.file_name,
            "page_number": self.page_number,
            "old_content": self.old_content,
            "new_content": self.new_content,
            "similarity_score": self.similarity_score,
            "llm_friendly_diff": self.llm_friendly_diff,
        }
