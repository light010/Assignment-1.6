"""Database connection management for Databricks/Delta Lake."""

from typing import Optional

from pyspark.sql import SparkSession


class DatabaseConnection:
    """
    Manages Databricks connection and Unity Catalog access.

    Simple wrapper for Spark session with fully-qualified table name generation.
    """

    def __init__(self, catalog: str, schema: str, use_unity_catalog: bool = True):
        """
        Initialize database connection.

        Args:
            catalog: Unity Catalog name
            schema: Database schema name
            use_unity_catalog: Whether to use Unity Catalog (default: True)
        """
        self.catalog = catalog
        self.schema = schema
        self.use_unity_catalog = use_unity_catalog
        self._spark: Optional[SparkSession] = None

    @property
    def spark(self) -> SparkSession:
        """Get or create Spark session."""
        if self._spark is None:
            self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def get_fully_qualified_table(self, table_name: str) -> str:
        """
        Get fully qualified table name for Unity Catalog.

        Args:
            table_name: Base table name (e.g., 'faq_questions')

        Returns:
            Fully qualified name (e.g., 'catalog.schema.faq_questions')
        """
        if self.use_unity_catalog:
            return f"{self.catalog}.{self.schema}.{table_name}"
        return f"{self.schema}.{table_name}"
