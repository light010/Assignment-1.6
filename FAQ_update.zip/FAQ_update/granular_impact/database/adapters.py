"""
Database adapters for different backends.

Provides unified interface for:
- Databricks/Spark (via PySpark)
- SQLite (via sqlite3)
- PostgreSQL (via psycopg2, optional)
"""

import sqlite3
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, List, Optional, Tuple

from granular_impact.database.dialect import DatabaseDialect


class DatabaseAdapter(ABC):
    """Abstract base class for database adapters."""

    def __init__(self, dialect: DatabaseDialect):
        """
        Initialize adapter.

        Args:
            dialect: Database dialect
        """
        self.dialect = dialect

    @abstractmethod
    def connect(self) -> Any:
        """Establish database connection."""
        pass

    @abstractmethod
    def execute(self, sql: str, params: Optional[Tuple] = None) -> Any:
        """Execute SQL statement."""
        pass

    @abstractmethod
    def fetchall(self, sql: str, params: Optional[Tuple] = None) -> List[Tuple]:
        """Execute SQL and fetch all results."""
        pass

    @abstractmethod
    def commit(self):
        """Commit transaction."""
        pass

    @abstractmethod
    def close(self):
        """Close connection."""
        pass


class SQLiteAdapter(DatabaseAdapter):
    """
    SQLite adapter for local development and testing.

    Features:
    - In-memory database support (for tests)
    - File-based database support (for local dev)
    - Foreign key enforcement enabled by default
    - Thread-safe with check_same_thread=False option
    """

    def __init__(
        self,
        database_path: Optional[str] = None,
        in_memory: bool = False,
        enable_foreign_keys: bool = True,
    ):
        """
        Initialize SQLite adapter.

        Args:
            database_path: Path to SQLite database file (None for in-memory)
            in_memory: Use in-memory database (overrides database_path)
            enable_foreign_keys: Enable foreign key constraints (default: True)
        """
        super().__init__(DatabaseDialect.SQLITE)

        if in_memory:
            self.database_path = ":memory:"
        elif database_path:
            self.database_path = str(database_path)
        else:
            # Default: in-memory
            self.database_path = ":memory:"

        self.enable_foreign_keys = enable_foreign_keys
        self._connection: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        """
        Establish SQLite connection.

        Returns:
            SQLite connection object
        """
        if self._connection is None:
            # check_same_thread=False allows multi-threaded access
            self._connection = sqlite3.connect(
                self.database_path, check_same_thread=False
            )

            # Enable foreign keys (required for CASCADE DELETE)
            if self.enable_foreign_keys:
                self._connection.execute("PRAGMA foreign_keys = ON;")

            # Return rows as Row objects (dict-like)
            self._connection.row_factory = sqlite3.Row

        return self._connection

    def execute(self, sql: str, params: Optional[Tuple] = None) -> sqlite3.Cursor:
        """
        Execute SQL statement(s).

        Args:
            sql: SQL statement(s) - can be single or multiple statements
            params: Query parameters (optional, only works with single statements)

        Returns:
            Cursor object
        """
        conn = self.connect()
        if params:
            # Parameterized queries only work with single statements
            return conn.execute(sql, params)

        # Check if SQL contains multiple statements (simple heuristic: multiple semicolons)
        # Strip comments and whitespace to avoid false positives
        sql_clean = sql.strip()
        semicolon_count = sql_clean.count(';')

        # If multiple statements or ends with semicolon, use executescript
        # executescript handles multiple statements but doesn't return a cursor
        if semicolon_count > 1 or (semicolon_count == 1 and sql_clean.endswith(';')):
            conn.executescript(sql)
            # Return a dummy cursor since executescript doesn't return one
            return conn.execute("SELECT 1")
        else:
            return conn.execute(sql)

    def fetchall(self, sql: str, params: Optional[Tuple] = None) -> List[Tuple]:
        """
        Execute SQL and fetch all results.

        Args:
            sql: SQL query
            params: Query parameters (optional)

        Returns:
            List of result rows
        """
        cursor = self.execute(sql, params)
        return cursor.fetchall()

    def commit(self):
        """Commit current transaction."""
        if self._connection:
            self._connection.commit()

    def close(self):
        """Close database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        if exc_type is None:
            self.commit()
        self.close()


class DatabricksAdapter(DatabaseAdapter):
    """
    Databricks adapter using PySpark.

    This is a thin wrapper around the existing DatabaseConnection
    to maintain backward compatibility.
    """

    def __init__(self, catalog: str, schema: str, spark_session=None):
        """
        Initialize Databricks adapter.

        Args:
            catalog: Unity Catalog name
            schema: Database schema name
            spark_session: PySpark SparkSession (optional, created if None)
        """
        super().__init__(DatabaseDialect.DATABRICKS)
        self.catalog = catalog
        self.schema = schema
        self._spark = spark_session

    def connect(self) -> Any:
        """Get or create Spark session."""
        if self._spark is None:
            from pyspark.sql import SparkSession

            self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def execute(self, sql: str, params: Optional[Tuple] = None) -> Any:
        """
        Execute SQL via Spark.

        Args:
            sql: SQL statement
            params: Not supported for Spark (raises ValueError)

        Returns:
            DataFrame or None
        """
        if params:
            raise ValueError("Parameterized queries not supported for Spark adapter")

        spark = self.connect()
        return spark.sql(sql)

    def fetchall(self, sql: str, params: Optional[Tuple] = None) -> List[Tuple]:
        """
        Execute SQL and fetch all results.

        Args:
            sql: SQL query
            params: Not supported

        Returns:
            List of result rows
        """
        df = self.execute(sql, params)
        if df is not None:
            return [tuple(row) for row in df.collect()]
        return []

    def commit(self):
        """Commit not needed for Spark (auto-commit)."""
        pass

    def close(self):
        """Close Spark session (typically not done)."""
        # Typically, we don't close Spark sessions
        # They're managed at the application level
        pass

    def get_fully_qualified_table(self, table_name: str) -> str:
        """
        Get fully qualified table name.

        Args:
            table_name: Base table name

        Returns:
            Fully qualified name (catalog.schema.table)
        """
        return f"{self.catalog}.{self.schema}.{table_name}"


def create_adapter(
    dialect: DatabaseDialect,
    **kwargs,
) -> DatabaseAdapter:
    """
    Factory function to create database adapter.

    Args:
        dialect: Database dialect
        **kwargs: Dialect-specific arguments

    Returns:
        DatabaseAdapter instance

    Examples:
        >>> # SQLite in-memory
        >>> adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)

        >>> # SQLite file-based
        >>> adapter = create_adapter(
        ...     DatabaseDialect.SQLITE,
        ...     database_path="granular_impact.db"
        ... )

        >>> # Databricks
        >>> adapter = create_adapter(
        ...     DatabaseDialect.DATABRICKS,
        ...     catalog="prod",
        ...     schema="faq"
        ... )
    """
    if dialect == DatabaseDialect.SQLITE:
        return SQLiteAdapter(**kwargs)

    elif dialect == DatabaseDialect.DATABRICKS:
        return DatabricksAdapter(**kwargs)

    elif dialect == DatabaseDialect.POSTGRESQL:
        # Future: PostgreSQL adapter
        raise NotImplementedError("PostgreSQL adapter not yet implemented")

    else:
        raise ValueError(f"Unsupported dialect: {dialect}")
