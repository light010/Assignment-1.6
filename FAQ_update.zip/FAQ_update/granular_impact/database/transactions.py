"""Transaction management for database operations with retry logic."""

import time
from typing import Any, Callable


class TransactionManager:
    """
    Manages database transactions with exponential backoff retry logic.

    Simple retry wrapper for database operations that may fail due to
    transient issues (network, locks, etc.).
    """

    def __init__(self, max_retries: int = 3, retry_delay: float = 1.0):
        """
        Initialize transaction manager.

        Args:
            max_retries: Maximum number of retry attempts (default: 3)
            retry_delay: Base delay in seconds between retries (default: 1.0)
        """
        self.max_retries = max_retries
        self.retry_delay = retry_delay

    def execute_with_retry(self, operation: Callable[[], Any]) -> Any:
        """
        Execute operation with exponential backoff retry logic.

        Args:
            operation: Callable operation to execute

        Returns:
            Result from operation

        Raises:
            Last exception if all retries fail
        """
        last_error = None
        for attempt in range(self.max_retries):
            try:
                return operation()
            except Exception as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    # Exponential backoff: 1s, 2s, 4s, 8s, ...
                    delay = self.retry_delay * (2 ** attempt)
                    time.sleep(delay)

        raise last_error
