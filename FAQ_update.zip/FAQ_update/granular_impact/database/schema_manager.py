"""
Schema management for granular impact analysis.

Provides unified schema manager supporting multiple database backends:
- Databricks Unity Catalog (Spark SQL + Delta Lake)
- SQLite (local development/testing)
- PostgreSQL (future)

Features:
- Dependency-aware table creation (respects FK relationships)
- Fine-grained control (create specific components)
- Dry-run mode for validation
- Schema validation against expected structure
- Multi-dialect support via adapters
"""

import yaml
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

from loguru import logger

from granular_impact.database.dialect import DatabaseDialect
from granular_impact.database.adapters import DatabaseAdapter


class SchemaComponent(str, Enum):
    """Schema component types."""

    TABLES = "tables"
    CONSTRAINTS = "constraints"
    INDEXES = "indexes"
    VIEWS = "views"
    ALL = "all"


class DeploymentMode(str, Enum):
    """Schema deployment modes."""

    CREATE = "create"
    UPDATE = "update"
    MIGRATE = "migrate"
    VALIDATE = "validate"


@dataclass
class SchemaValidationResult:
    """Result of schema validation."""

    is_valid: bool
    missing_tables: List[str] = field(default_factory=list)
    missing_constraints: List[str] = field(default_factory=list)
    missing_indexes: List[str] = field(default_factory=list)
    missing_views: List[str] = field(default_factory=list)
    extra_tables: List[str] = field(default_factory=list)
    validation_timestamp: datetime = field(default_factory=datetime.now)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def __str__(self) -> str:
        """Human-readable validation report."""
        lines = [
            f"Schema Validation Report ({self.validation_timestamp})",
            f"Status: {'✅ VALID' if self.is_valid else '❌ INVALID'}",
            "",
        ]

        if self.missing_tables:
            lines.append(f"Missing Tables ({len(self.missing_tables)}):")
            for table in self.missing_tables:
                lines.append(f"  - {table}")
            lines.append("")

        if self.missing_views:
            lines.append(f"Missing Views ({len(self.missing_views)}):")
            for view in self.missing_views:
                lines.append(f"  - {view}")
            lines.append("")

        if self.errors:
            lines.append(f"Errors ({len(self.errors)}):")
            for error in self.errors:
                lines.append(f"  ❌ {error}")
            lines.append("")

        if self.warnings:
            lines.append(f"Warnings ({len(self.warnings)}):")
            for warning in self.warnings:
                lines.append(f"  ⚠️  {warning}")

        return "\n".join(lines)


class SchemaManager:
    """
    Unified schema manager supporting multiple database backends.

    Supports:
    - Databricks Unity Catalog (Spark SQL + Delta Lake)
    - SQLite (local development/testing)
    - PostgreSQL (future)

    Example:
        >>> from granular_impact.database.adapters import create_adapter
        >>> from granular_impact.database.dialect import DatabaseDialect
        >>>
        >>> # SQLite for local testing
        >>> adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
        >>> manager = SchemaManager(adapter=adapter)
        >>> manager.create_schema()
        >>>
        >>> # Databricks for production
        >>> adapter = create_adapter(
        ...     DatabaseDialect.DATABRICKS,
        ...     catalog="prod",
        ...     schema="faq"
        ... )
        >>> manager = SchemaManager(adapter=adapter)
        >>> manager.create_schema()
    """

    def __init__(
        self,
        adapter: DatabaseAdapter,
        schema_dir: Optional[Path] = None,
    ):
        """
        Initialize schema manager.

        Args:
            adapter: Database adapter (Databricks, SQLite, PostgreSQL)
            schema_dir: Path to schema directory (auto-detected based on dialect)
        """
        self.adapter = adapter
        self.dialect = adapter.dialect

        if schema_dir is None:
            schema_dir = self._get_default_schema_dir()

        self.schema_dir = Path(schema_dir)
        self.dependency_graph = self._load_dependency_graph()

        logger.info(
            f"SchemaManager initialized for dialect={self.dialect.value} "
            f"with {len(self.dependency_graph.get('tables', {}))} tables"
        )

    def _get_default_schema_dir(self) -> Path:
        """Get default schema directory based on dialect."""
        base_path = Path(__file__).parent / "sql"

        if self.dialect == DatabaseDialect.DATABRICKS:
            return base_path / "schema"
        elif self.dialect == DatabaseDialect.SQLITE:
            return base_path / "schema_sqlite"
        elif self.dialect == DatabaseDialect.POSTGRESQL:
            return base_path / "schema_postgresql"
        else:
            raise ValueError(f"Unsupported dialect: {self.dialect}")

    def _load_dependency_graph(self) -> Dict:
        """Load dependency graph from YAML."""
        graph_path = self.schema_dir / "_meta" / "dependency_graph.yaml"

        if not graph_path.exists():
            raise FileNotFoundError(f"Dependency graph not found: {graph_path}")

        with open(graph_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _load_sql_file(self, relative_path: str) -> str:
        """Load SQL file content."""
        file_path = self.schema_dir / relative_path

        if not file_path.exists():
            raise FileNotFoundError(f"SQL file not found: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()

    def _execute_sql(self, sql: str, description: str, dry_run: bool = False):
        """Execute SQL with logging and dry-run support."""
        if dry_run:
            logger.info(f"[DRY RUN] Would execute: {description}")
            logger.debug(f"SQL:\n{sql[:500]}...")
        else:
            logger.info(f"Executing: {description}")
            try:
                self.adapter.execute(sql)
                logger.success(f"✅ Completed: {description}")
            except Exception as e:
                logger.error(f"❌ Failed: {description}")
                logger.error(f"Error: {str(e)}")
                raise

    def create_schema(
        self,
        components: Optional[List[SchemaComponent]] = None,
        specific_tables: Optional[List[str]] = None,
        dry_run: bool = False,
    ) -> Dict[str, List[str]]:
        """
        Create schema with fine-grained control.

        Args:
            components: Which components to create (default: TABLES only)
            specific_tables: Create only these tables (with dependencies)
            dry_run: Print SQL without executing

        Returns:
            Dictionary of created objects by component type

        Example:
            >>> # Create all tables
            >>> manager.create_schema()
            >>>
            >>> # Create specific table with dependencies
            >>> manager.create_schema(specific_tables=["faq_audit_log"])
            >>>
            >>> # Dry run to see execution plan
            >>> manager.create_schema(dry_run=True)
        """
        if components is None:
            # Default: only tables (constraints are inline)
            components = [SchemaComponent.TABLES]

        # Expand ALL to specific components
        if SchemaComponent.ALL in components:
            components = [SchemaComponent.TABLES]

        created = {comp.value: [] for comp in components}

        logger.info(f"Creating schema for dialect={self.dialect.value}")
        logger.info(f"Components: {[c.value for c in components]}")

        # Phase 1: Tables
        if SchemaComponent.TABLES in components:
            tables_created = self._create_tables(specific_tables, dry_run)
            created[SchemaComponent.TABLES.value] = tables_created

        logger.success("✅ Schema creation completed")
        self._print_summary(created)

        return created

    def _create_tables(
        self,
        specific_tables: Optional[List[str]],
        dry_run: bool,
    ) -> List[str]:
        """Create tables in dependency order."""
        tables_config = self.dependency_graph.get("tables", {})

        if specific_tables:
            tables_to_create = self._resolve_dependencies(specific_tables, tables_config)
        else:
            tables_to_create = list(tables_config.keys())

        # Sort by dependency order
        tables_to_create.sort(key=lambda t: tables_config[t].get("order", 999))

        created = []
        for table_name in tables_to_create:
            table_info = tables_config[table_name]
            sql_file = table_info["file"]
            sql = self._load_sql_file(sql_file)

            self._execute_sql(sql, f"Creating table: {table_name}", dry_run)
            created.append(table_name)

        return created

    def _resolve_dependencies(
        self, table_names: List[str], tables_config: Dict
    ) -> List[str]:
        """Resolve table dependencies recursively."""
        resolved = set()
        to_process = set(table_names)

        while to_process:
            table = to_process.pop()
            if table in resolved:
                continue

            table_info = tables_config.get(table)
            if not table_info:
                logger.warning(f"Table not found in config: {table}")
                continue

            # Add dependencies to processing queue
            deps = table_info.get("dependencies", [])
            for dep in deps:
                if dep not in resolved:
                    to_process.add(dep)

            resolved.add(table)

        return list(resolved)

    def _print_summary(self, created: Dict[str, List[str]]):
        """Print creation summary."""
        logger.info("=" * 70)
        logger.info("SCHEMA CREATION SUMMARY")
        logger.info("=" * 70)

        for component, objects in created.items():
            if objects:
                logger.info(f"{component.upper()}: {len(objects)} created")
                for obj in objects:
                    logger.info(f"  ✅ {obj}")

        logger.info("=" * 70)

    def validate_schema(self) -> SchemaValidationResult:
        """
        Validate current schema against expected schema.

        Returns:
            SchemaValidationResult with validation details

        Example:
            >>> result = manager.validate_schema()
            >>> print(result)
            >>> if not result.is_valid:
            ...     print("Missing tables:", result.missing_tables)
        """
        result = SchemaValidationResult(is_valid=True)

        try:
            # Get current tables
            if self.dialect == DatabaseDialect.SQLITE:
                current_tables = set(
                    row[0]
                    for row in self.adapter.fetchall(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                    )
                )
            else:
                # For Databricks, validation requires Spark-specific logic
                logger.warning("Schema validation not yet implemented for Databricks")
                return result

            # Expected tables
            expected_tables = set(self.dependency_graph.get("tables", {}).keys())

            # Check tables
            result.missing_tables = list(expected_tables - current_tables)
            result.extra_tables = list(current_tables - expected_tables)

            # Determine validity
            if result.missing_tables:
                result.is_valid = False

            if result.extra_tables:
                result.warnings.append(
                    f"Found {len(result.extra_tables)} unexpected tables"
                )

        except Exception as e:
            result.is_valid = False
            result.errors.append(f"Validation error: {str(e)}")

        return result

    def drop_schema(self, cascade: bool = False, dry_run: bool = False):
        """
        Drop all schema objects in reverse dependency order.

        Args:
            cascade: Use CASCADE for drops
            dry_run: Print SQL without executing

        DANGER: This drops all tables and data!
        """
        logger.warning("⚠️  DROP SCHEMA REQUESTED - THIS WILL DELETE ALL DATA!")

        if not dry_run:
            confirmation = input("Type 'DELETE ALL DATA' to confirm: ")
            if confirmation != "DELETE ALL DATA":
                logger.info("Drop cancelled by user")
                return

        cascade_clause = "CASCADE" if cascade else ""

        # Drop tables in reverse order
        tables = list(self.dependency_graph.get("tables", {}).items())
        tables.sort(key=lambda t: t[1].get("order", 999), reverse=True)

        for table_name, _ in tables:
            sql = f"DROP TABLE IF EXISTS {table_name} {cascade_clause}"
            self._execute_sql(sql, f"Dropping table: {table_name}", dry_run)

        logger.success("Schema drop completed")
