# Diff Module

Text difference analysis for detecting and characterizing changes in FAQ content.

## Overview

The diff module provides tools for analyzing differences between text versions, extracting meaningful phrases, and detecting semantically important changes like numbers, dates, and policy modifications.

## Components

### 1. DiffEngine - Core Difference Computation

**File**: [diff_engine.py](diff_engine.py)

Computes detailed differences between two text versions.

**Example**:
```python
from granular_impact.diff import DiffEngine

engine = DiffEngine()

old_text = """
Employees must submit expense reports within 30 days.
Late submissions will not be reimbursed.
"""

new_text = """
Employees must submit expense reports within 45 days.
Late submissions require manager approval.
"""

result = engine.compute_diff(old_text, new_text)

print(f"Diff Ratio: {result.diff_ratio:.3f}")
print(f"Total Changes: {result.total_changes}")
print(f"\nAdditions: {len(result.additions)}")
for addition in result.additions:
    print(f"  + {addition}")

print(f"\nDeletions: {len(result.deletions)}")
for deletion in result.deletions:
    print(f"  - {deletion}")
```

**Output**:
```
Diff Ratio: 0.812
Total Changes: 4

Additions: 2
  + Employees must submit expense reports within 45 days.
  + Late submissions require manager approval.

Deletions: 2
  - Employees must submit expense reports within 30 days.
  - Late submissions will not be reimbursed.
```

**DiffResult Structure**:
```python
@dataclass
class DiffResult:
    additions: List[str]       # Added lines/phrases
    deletions: List[str]       # Deleted lines/phrases
    modifications: List[Tuple[str, str]]  # (old, new) pairs
    diff_ratio: float          # Overall similarity (0-1)
    total_changes: int         # Count of changes
```

---

### 2. PhraseExtractor - Meaningful Phrase Extraction

**File**: [phrase_extractor.py](phrase_extractor.py)

Extracts important phrases from text and identifies changed phrases between versions.

**Example**:
```python
from granular_impact.diff import PhraseExtractor

extractor = PhraseExtractor(
    min_length=3,   # Minimum words in phrase
    max_length=10   # Maximum words in phrase
)

text = """
The company's paid time off policy provides 15 days per year.
Employees must use PTO within the calendar year.
Unused PTO does not roll over.
"""

phrases = extractor.extract_phrases(text)

print("Extracted Phrases:")
for phrase in phrases:
    print(f"  - {phrase}")
```

**Output**:
```
Extracted Phrases:
  - The company's paid time off policy provides 15 days per year
  - Employees must use PTO within the calendar year
  - Unused PTO does not roll over
```

**Detecting Changed Phrases**:
```python
old_text = "Employees get 15 days of PTO annually."
new_text = "Employees get 20 days of PTO annually."

changed = extractor.extract_changed_phrases(old_text, new_text)

print("Changed Phrases:")
for phrase in changed:
    print(f"  ~ {phrase}")
```

**Output**:
```
Changed Phrases:
  ~ Employees get 15 days of PTO annually
  ~ Employees get 20 days of PTO annually
```

**Use Cases**:
- Identifying key policy statements that changed
- Extracting important sentences for review
- Finding contextual changes around specific topics
- Generating change summaries

---

### 3. SemanticDetector - Semantic Change Detection

**File**: [semantic_detector.py](semantic_detector.py)

Detects specific types of semantic changes: numbers, dates, URLs, emails, and policy keywords.

**Example - Numeric Changes**:
```python
from granular_impact.diff import SemanticDetector

detector = SemanticDetector()

old_text = "The reimbursement limit is $500 per month."
new_text = "The reimbursement limit is $750 per month."

numeric_changes = detector.detect_numeric_changes(old_text, new_text)

print("Numeric Changes:")
for change in numeric_changes:
    print(f"  {change.change_type}: {change.old_value} -> {change.new_value}")
    print(f"  Context: {change.context}")
```

**Output**:
```
Numeric Changes:
  numeric: 500 ->
  Context: removed
  numeric:  -> 750
  Context: added
```

**Example - Date Changes**:
```python
old_text = "The deadline is 12/31/2024."
new_text = "The deadline is 01/15/2025."

date_changes = detector.detect_date_changes(old_text, new_text)

print("Date Changes:")
for change in date_changes:
    print(f"  Date: {change.old_value} -> {change.new_value}")
```

**SemanticChange Structure**:
```python
@dataclass
class SemanticChange:
    change_type: str    # "numeric", "date", "url", "email", "policy"
    old_value: str      # Previous value
    new_value: str      # New value
    context: str        # Additional context ("removed", "added", "modified")
```

**Detection Patterns**:

| Type | Pattern | Example |
|------|---------|---------|
| Numbers | `\b\d+(?:\.\d+)?\b` | `30`, `45.5`, `1000` |
| Dates | `\d{1,2}[/-]\d{1,2}[/-]\d{2,4}` | `12/31/2024`, `1-15-25` |
| URLs | `https?://[^\s]+` | `https://example.com` |
| Emails | `[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}` | `user@example.com` |

**All Detection Methods**:
```python
detector = SemanticDetector()

# Detect numeric changes (amounts, percentages, counts)
numeric_changes = detector.detect_numeric_changes(old_text, new_text)

# Detect date changes (deadlines, effective dates)
date_changes = detector.detect_date_changes(old_text, new_text)

# More methods can be added for URLs, emails, policy keywords
```

---

## Complete Workflow Example

```python
from granular_impact.diff import DiffEngine, PhraseExtractor, SemanticDetector

# Initialize components
diff_engine = DiffEngine()
phrase_extractor = PhraseExtractor()
semantic_detector = SemanticDetector()

# Sample FAQ content change
old_answer = """
Employees can submit expense reports within 30 days of the expense date.
The maximum reimbursement is $500 per month.
Reports must be submitted by email to finance@company.com.
"""

new_answer = """
Employees can submit expense reports within 45 days of the expense date.
The maximum reimbursement is $750 per month.
Reports must be submitted through the online portal at https://expenses.company.com.
"""

# 1. Compute overall diff
diff_result = diff_engine.compute_diff(old_answer, new_answer)

print("=" * 80)
print("DIFF ANALYSIS")
print("=" * 80)
print(f"Similarity: {diff_result.diff_ratio:.1%}")
print(f"Total Changes: {diff_result.total_changes}")

# 2. Extract changed phrases
changed_phrases = phrase_extractor.extract_changed_phrases(old_answer, new_answer)

print("\nChanged Phrases:")
for phrase in changed_phrases:
    print(f"  ~ {phrase}")

# 3. Detect semantic changes
print("\nSemantic Changes:")

# Numbers (reimbursement amounts, days)
numeric_changes = semantic_detector.detect_numeric_changes(old_answer, new_answer)
if numeric_changes:
    print(f"  Numbers changed: {len(numeric_changes)}")
    for change in numeric_changes:
        if change.old_value and change.new_value:
            print(f"    {change.old_value} -> {change.new_value}")
        elif change.old_value:
            print(f"    Removed: {change.old_value}")
        else:
            print(f"    Added: {change.new_value}")

# Dates (if any)
date_changes = semantic_detector.detect_date_changes(old_answer, new_answer)
if date_changes:
    print(f"  Dates changed: {len(date_changes)}")

print("\n" + "=" * 80)
```

**Output**:
```
================================================================================
DIFF ANALYSIS
================================================================================
Similarity: 68.2%
Total Changes: 6

Changed Phrases:
  ~ Employees can submit expense reports within 30 days of the expense date
  ~ Employees can submit expense reports within 45 days of the expense date
  ~ The maximum reimbursement is $500 per month
  ~ The maximum reimbursement is $750 per month
  ~ Reports must be submitted by email to finance@company.com
  ~ Reports must be submitted through the online portal at https://expenses.company.com

Semantic Changes:
  Numbers changed: 4
    Removed: 30
    Added: 45
    Removed: 500
    Added: 750

================================================================================
```

---

## Integration with Impact Analysis

The diff module integrates with the impact scoring system:

```python
from granular_impact.diff import DiffEngine, SemanticDetector
from granular_impact.impact import ImpactScorer

# Compute diff
diff_engine = DiffEngine()
diff_result = diff_engine.compute_diff(old_text, new_text)

# Detect semantic changes
semantic_detector = SemanticDetector()
numeric_changes = semantic_detector.detect_numeric_changes(old_text, new_text)

# Score impact
scorer = ImpactScorer()

# Diff magnitude score (based on amount of change)
diff_score = scorer.compute_diff_magnitude_score(
    old_text,
    new_text,
    diff_result.diff_ratio
)

# Semantic importance score (based on type of changes)
semantic_changes = {"numeric": numeric_changes}
semantic_score = scorer.compute_semantic_importance_score(semantic_changes)

print(f"Diff Magnitude Score: {diff_score:.3f}")
print(f"Semantic Importance Score: {semantic_score:.3f}")
```

---

## Advanced Usage

### Custom Phrase Extraction

```python
class CustomPhraseExtractor(PhraseExtractor):
    def extract_phrases(self, text: str) -> List[str]:
        # Custom logic for domain-specific phrases
        phrases = super().extract_phrases(text)

        # Add policy-specific extraction
        policy_keywords = ["must", "required", "mandatory", "prohibited"]
        policy_phrases = [
            p for p in phrases
            if any(keyword in p.lower() for keyword in policy_keywords)
        ]

        return policy_phrases

extractor = CustomPhraseExtractor()
```

### Custom Semantic Detection

```python
class PolicySemanticDetector(SemanticDetector):
    def detect_policy_changes(self, old_text: str, new_text: str):
        """Detect policy-specific changes."""
        policy_keywords = [
            "must", "required", "mandatory", "shall",
            "prohibited", "not allowed", "forbidden"
        ]

        changes = []
        for keyword in policy_keywords:
            old_count = old_text.lower().count(keyword)
            new_count = new_text.lower().count(keyword)

            if old_count != new_count:
                changes.append(SemanticChange(
                    change_type="policy",
                    old_value=f"{keyword} ({old_count})",
                    new_value=f"{keyword} ({new_count})",
                    context="frequency_change"
                ))

        return changes

detector = PolicySemanticDetector()
policy_changes = detector.detect_policy_changes(old_text, new_text)
```

---

## Best Practices

### 1. Combine All Three Components

Always use DiffEngine, PhraseExtractor, and SemanticDetector together for comprehensive analysis:

```python
def analyze_content_change(old_text: str, new_text: str):
    """Complete diff analysis."""
    diff = DiffEngine().compute_diff(old_text, new_text)
    phrases = PhraseExtractor().extract_changed_phrases(old_text, new_text)
    semantic = SemanticDetector().detect_numeric_changes(old_text, new_text)

    return {
        "diff_ratio": diff.diff_ratio,
        "total_changes": diff.total_changes,
        "changed_phrases": list(phrases),
        "semantic_changes": semantic,
    }
```

### 2. Threshold-Based Filtering

Filter out minor changes:

```python
diff_result = diff_engine.compute_diff(old_text, new_text)

# Only process if significant change
if diff_result.diff_ratio < 0.95:  # Less than 95% similar
    # Significant change, analyze further
    phrases = phrase_extractor.extract_changed_phrases(old_text, new_text)
    semantic = semantic_detector.detect_numeric_changes(old_text, new_text)
```

### 3. Categorize Changes by Impact

```python
def categorize_impact(semantic_changes):
    """Categorize semantic changes by impact."""
    high_impact = []
    medium_impact = []
    low_impact = []

    for change in semantic_changes:
        if change.change_type == "numeric":
            # Check if percentage change is significant
            try:
                old_val = float(change.old_value)
                new_val = float(change.new_value)
                pct_change = abs((new_val - old_val) / old_val)

                if pct_change > 0.5:  # >50% change
                    high_impact.append(change)
                elif pct_change > 0.2:  # >20% change
                    medium_impact.append(change)
                else:
                    low_impact.append(change)
            except (ValueError, ZeroDivisionError):
                medium_impact.append(change)

    return high_impact, medium_impact, low_impact
```

---

## Testing

```python
def test_diff_module():
    """Test diff module components."""
    from granular_impact.diff import DiffEngine, PhraseExtractor, SemanticDetector

    # Test data
    old = "Submit reports within 30 days. Max $500."
    new = "Submit reports within 45 days. Max $750."

    # Test DiffEngine
    diff = DiffEngine().compute_diff(old, new)
    assert diff.diff_ratio < 1.0
    assert diff.total_changes > 0

    # Test PhraseExtractor
    phrases = PhraseExtractor().extract_changed_phrases(old, new)
    assert len(phrases) > 0

    # Test SemanticDetector
    changes = SemanticDetector().detect_numeric_changes(old, new)
    assert len(changes) == 4  # 30, 45, 500, 750

    print("✓ All diff module tests passed")

test_diff_module()
```

---

## Performance

- **DiffEngine**: ~1ms per comparison
- **PhraseExtractor**: ~2ms for typical FAQ content
- **SemanticDetector**: ~0.5ms per detection type

Total overhead: ~5ms for complete analysis

---

## API Reference

### DiffEngine

```python
def compute_diff(text1: str, text2: str) -> DiffResult
```

### PhraseExtractor

```python
def extract_phrases(text: str) -> List[str]
def extract_changed_phrases(old_text: str, new_text: str) -> Set[str]
```

### SemanticDetector

```python
def detect_numeric_changes(old_text: str, new_text: str) -> List[SemanticChange]
def detect_date_changes(old_text: str, new_text: str) -> List[SemanticChange]
```

---

## Future Enhancements

Potential additions to this module:

1. **URL/Email Detection**: Detect changes in links and contact information
2. **Policy Keyword Detection**: Identify changes in policy language
3. **Sentiment Analysis**: Detect tone changes
4. **Entity Recognition**: Detect changes in named entities (people, places, organizations)
5. **Diff Visualization**: Generate HTML/visual diffs
6. **Change Summarization**: Auto-generate change summaries

---

## Contributing

When extending this module:
1. Maintain consistency with existing interfaces
2. Add comprehensive type hints
3. Include docstrings with examples
4. Write unit tests
5. Document new detection patterns
