"""
Detect semantic changes (numbers, dates, policies).
"""

import re
from dataclasses import dataclass
from typing import List


@dataclass
class SemanticChange:
    """Represents a detected semantic change."""
    change_type: str
    old_value: str
    new_value: str
    context: str


class SemanticDetector:
    """Detects semantic changes in text."""

    def __init__(self):
        self.number_pattern = r'\b\d+(?:\.\d+)?\b'
        self.date_pattern = r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b'
        self.url_pattern = r'https?://[^\s]+'
        self.email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

    def detect_numeric_changes(self, old_text: str, new_text: str) -> List[SemanticChange]:
        """Detect numeric value changes."""
        old_numbers = set(re.findall(self.number_pattern, old_text))
        new_numbers = set(re.findall(self.number_pattern, new_text))

        changes = []
        removed = old_numbers - new_numbers
        added = new_numbers - old_numbers

        for old_val in removed:
            changes.append(SemanticChange(
                change_type="numeric",
                old_value=old_val,
                new_value="",
                context="removed"
            ))

        for new_val in added:
            changes.append(SemanticChange(
                change_type="numeric",
                old_value="",
                new_value=new_val,
                context="added"
            ))

        return changes

    def detect_date_changes(self, old_text: str, new_text: str) -> List[SemanticChange]:
        """Detect date changes."""
        old_dates = set(re.findall(self.date_pattern, old_text))
        new_dates = set(re.findall(self.date_pattern, new_text))

        changes = []
        for date in old_dates - new_dates:
            changes.append(SemanticChange(
                change_type="date",
                old_value=date,
                new_value="",
                context="removed"
            ))

        return changes
