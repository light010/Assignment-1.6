"""
Extract meaningful phrases from text differences.
"""

import re
from typing import List, Set


class PhraseExtractor:
    """Extracts important phrases from text."""

    def __init__(self, min_length: int = 3, max_length: int = 10):
        self.min_length = min_length
        self.max_length = max_length

    def extract_phrases(self, text: str) -> List[str]:
        """
        Extract phrases from text.

        Args:
            text: Input text

        Returns:
            List of extracted phrases
        """
        # Split into sentences
        sentences = re.split(r'[.!?]', text)

        phrases = []
        for sentence in sentences:
            words = sentence.split()
            if self.min_length <= len(words) <= self.max_length:
                phrases.append(sentence.strip())

        return phrases

    def extract_changed_phrases(self, old_text: str, new_text: str) -> Set[str]:
        """
        Extract phrases that changed between texts.

        Args:
            old_text: Original text
            new_text: Modified text

        Returns:
            Set of changed phrases
        """
        old_phrases = set(self.extract_phrases(old_text))
        new_phrases = set(self.extract_phrases(new_text))

        changed = old_phrases.symmetric_difference(new_phrases)
        return changed
