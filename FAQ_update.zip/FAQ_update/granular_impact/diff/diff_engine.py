"""
Core diff computation engine.
"""

import difflib
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class DiffResult:
    """Result of diff computation."""
    additions: List[str]
    deletions: List[str]
    modifications: List[Tuple[str, str]]
    diff_ratio: float
    total_changes: int


class DiffEngine:
    """Computes differences between texts."""

    def compute_diff(self, text1: str, text2: str) -> DiffResult:
        """
        Compute diff between two texts.

        Args:
            text1: Original text
            text2: Modified text

        Returns:
            DiffResult object
        """
        lines1 = text1.splitlines()
        lines2 = text2.splitlines()

        differ = difflib.Differ()
        diff = list(differ.compare(lines1, lines2))

        additions = [line[2:] for line in diff if line.startswith('+ ')]
        deletions = [line[2:] for line in diff if line.startswith('- ')]

        matcher = difflib.SequenceMatcher(None, text1, text2)
        diff_ratio = matcher.ratio()

        return DiffResult(
            additions=additions,
            deletions=deletions,
            modifications=[],
            diff_ratio=diff_ratio,
            total_changes=len(additions) + len(deletions)
        )
