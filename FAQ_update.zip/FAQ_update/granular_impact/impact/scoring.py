"""
Individual scoring methods for impact analysis.

Provides component scores that feed into overall impact assessment.
"""

from typing import Dict

from granular_impact.similarity.base import SimilarityResult


class ImpactScorer:
    """Computes individual impact scores."""

    def __init__(
        self,
        similarity_weight: float = 0.40,
        diff_magnitude_weight: float = 0.30,
        semantic_importance_weight: float = 0.30,
    ):
        """
        Initialize impact scorer.

        Args:
            similarity_weight: Weight for similarity score
            diff_magnitude_weight: Weight for diff magnitude
            semantic_importance_weight: Weight for semantic importance
        """
        self.similarity_weight = similarity_weight
        self.diff_magnitude_weight = diff_magnitude_weight
        self.semantic_importance_weight = semantic_importance_weight

        # Validate weights sum to 1.0
        total = similarity_weight + diff_magnitude_weight + semantic_importance_weight
        if not (0.99 <= total <= 1.01):
            raise ValueError(f"Weights must sum to 1.0, got {total}")

    def compute_similarity_score(self, similarity_result: SimilarityResult) -> float:
        """
        Compute similarity component score.

        Args:
            similarity_result: Result from similarity calculation

        Returns:
            Similarity score (0-1, inverted so higher = more impact)
        """
        # Invert similarity: low similarity = high impact
        return 1.0 - similarity_result.score

    def compute_diff_magnitude_score(
        self, old_text: str, new_text: str, diff_ratio: float
    ) -> float:
        """
        Compute diff magnitude score based on amount of change.

        Args:
            old_text: Original text
            new_text: Modified text
            diff_ratio: Diff ratio from diff engine

        Returns:
            Magnitude score (0-1)
        """
        # Length change ratio
        old_len = len(old_text)
        new_len = len(new_text)

        if old_len == 0:
            length_ratio = 1.0 if new_len > 0 else 0.0
        else:
            length_ratio = abs(new_len - old_len) / old_len

        # Combine diff ratio and length change
        # diff_ratio closer to 0 = more changes
        magnitude = (1.0 - diff_ratio) * 0.7 + min(length_ratio, 1.0) * 0.3

        return magnitude

    def compute_semantic_importance_score(self, semantic_changes: Dict) -> float:
        """
        Compute semantic importance based on type of changes.

        Args:
            semantic_changes: Dictionary of detected semantic changes

        Returns:
            Semantic importance score (0-1)
        """
        # Weight different types of changes
        weights = {
            "numeric": 0.8,
            "date": 0.9,
            "policy": 1.0,
            "url": 0.6,
            "email": 0.7,
        }

        if not semantic_changes:
            return 0.0

        total_importance = 0.0
        for change_type, changes in semantic_changes.items():
            weight = weights.get(change_type, 0.5)
            num_changes = len(changes) if isinstance(changes, list) else 1
            total_importance += weight * min(num_changes / 5.0, 1.0)

        # Normalize to [0, 1]
        return min(total_importance, 1.0)

    def compute_overall_score(
        self,
        similarity_score: float,
        diff_magnitude_score: float,
        semantic_importance_score: float,
    ) -> float:
        """
        Compute weighted overall impact score.

        Args:
            similarity_score: Similarity component
            diff_magnitude_score: Diff magnitude component
            semantic_importance_score: Semantic importance component

        Returns:
            Overall impact score (0-1)
        """
        overall = (
            similarity_score * self.similarity_weight
            + diff_magnitude_score * self.diff_magnitude_weight
            + semantic_importance_score * self.semantic_importance_weight
        )

        return overall
