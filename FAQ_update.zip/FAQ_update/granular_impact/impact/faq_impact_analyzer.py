"""
FAQ Impact Analyzer - Converts similarity results to FAQ impact assessments.

This module provides a clean separation between:
1. Core similarity computation (BaseSimilarityCalculator)
2. FAQ-specific impact analysis (FaqImpactAnalyzer)

The analyzer wraps any similarity calculator and provides:
- Configurable impact thresholds
- Database integration (FAQImpactAnalysis objects)
- Batch processing
- Impact level classification

Architecture:
    SimilarityCalculator -> SimilarityResult -> FaqImpactAnalyzer -> FAQImpactAnalysis
"""

from datetime import datetime
from typing import Dict, List, Optional

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    BatchSimilarityResult,
    SimilarityResult,
)


# Default impact level thresholds (dissimilarity scores)
DEFAULT_IMPACT_THRESHOLDS = {
    'critical': 0.8,  # 80%+ change
    'high': 0.6,      # 60-80% change
    'medium': 0.4,    # 40-60% change
    'low': 0.2,       # 20-40% change
    # Below 0.2 = NONE
}


class FaqImpactAnalyzer:
    """
    Analyzes FAQ impact using similarity calculators.

    This class separates FAQ-specific logic from core similarity computation,
    following Single Responsibility Principle and Dependency Inversion Principle.

    Example:
        >>> from granular_impact.similarity import JaccardSimilarityCalculator
        >>> from granular_impact.impact import FaqImpactAnalyzer
        >>>
        >>> # Create similarity calculator
        >>> calc = JaccardSimilarityCalculator.for_faq_content()
        >>>
        >>> # Wrap with FAQ analyzer
        >>> analyzer = FaqImpactAnalyzer(calc)
        >>>
        >>> # Compute similarity
        >>> result = calc.compute_similarity(old_text, new_text)
        >>>
        >>> # Convert to FAQ impact analysis
        >>> impact = analyzer.to_faq_impact_analysis(
        ...     similarity_result=result,
        ...     change_id=1,
        ...     question_id=100,
        ...     threshold=0.3
        ... )
        >>>
        >>> # Ready for database insertion
        >>> db.session.add(impact)
    """

    def __init__(
        self,
        similarity_calculator: BaseSimilarityCalculator,
        impact_thresholds: Optional[Dict[str, float]] = None
    ):
        """
        Initialize FAQ impact analyzer.

        Args:
            similarity_calculator: Any BaseSimilarityCalculator implementation
            impact_thresholds: Custom impact level thresholds (optional)
                              Format: {'critical': 0.8, 'high': 0.6, ...}

        Raises:
            ValueError: If thresholds are invalid
        """
        self.calculator = similarity_calculator
        self.thresholds = impact_thresholds or DEFAULT_IMPACT_THRESHOLDS.copy()

        # Validate thresholds
        self._validate_thresholds()

    def _validate_thresholds(self) -> None:
        """Validate that impact thresholds are valid."""
        for level, threshold in self.thresholds.items():
            if not (0.0 <= threshold <= 1.0):
                raise ValueError(
                    f"Threshold for '{level}' must be between 0.0 and 1.0, got {threshold}"
                )

    def compute_impact_level(self, dissimilarity: float) -> str:
        """
        Compute impact level from dissimilarity score.

        Args:
            dissimilarity: Dissimilarity score (0.0 to 1.0)

        Returns:
            Impact level string: 'HIGH', 'MEDIUM', 'LOW', or 'NONE'

        Note:
            Uses configurable thresholds. Higher dissimilarity = higher impact.
        """
        if dissimilarity >= self.thresholds.get('critical', 0.8):
            return 'HIGH'  # Using HIGH instead of CRITICAL to match ImpactLevel enum
        elif dissimilarity >= self.thresholds.get('high', 0.6):
            return 'HIGH'
        elif dissimilarity >= self.thresholds.get('medium', 0.4):
            return 'MEDIUM'
        elif dissimilarity >= self.thresholds.get('low', 0.2):
            return 'LOW'
        else:
            return 'NONE'

    def validate_similarity_result(self, similarity_result: SimilarityResult) -> bool:
        """
        Validate that similarity result is compatible with FAQ impact analysis.

        Args:
            similarity_result: SimilarityResult to validate

        Returns:
            True if valid for FAQ impact analysis
        """
        try:
            assert isinstance(similarity_result.score, float)
            assert 0.0 <= similarity_result.score <= 1.0
            assert isinstance(similarity_result.algorithm, str)
            assert isinstance(similarity_result.processing_time_ms, float)
            return True
        except (AssertionError, AttributeError):
            return False

    def to_faq_impact_analysis(
        self,
        similarity_result: SimilarityResult,
        change_id: int,
        question_id: int,
        threshold: float,
        answer_id: Optional[int] = None,
        diff_id: Optional[int] = None,
    ):
        """
        Convert similarity result to FAQImpactAnalysis database object.

        Args:
            similarity_result: SimilarityResult from compute_similarity()
            change_id: ID of content change being analyzed
            question_id: ID of FAQ question being checked
            threshold: Dissimilarity threshold for marking as affected
            answer_id: Optional answer ID
            diff_id: Optional diff ID

        Returns:
            FAQImpactAnalysis object ready for database insertion

        Raises:
            ValueError: If threshold is invalid
            ImportError: If database module not available
        """
        # Validate threshold
        if not (0.0 <= threshold <= 1.0):
            raise ValueError(f"threshold must be between 0.0 and 1.0, got {threshold}")

        # Import database models (optional dependency)
        try:
            from granular_impact.database.models import (
                FAQImpactAnalysis,
                ImpactLevel,
                AnalysisMethod,
            )
        except ImportError as e:
            raise ImportError(
                f"FAQ impact analysis requires database module: {e}. "
                "Install with: pip install pyspark"
            ) from e

        # Calculate dissimilarity for impact analysis
        dissimilarity = 1.0 - similarity_result.score

        # Determine if FAQ is affected based on threshold
        is_affected = dissimilarity >= threshold

        # Compute impact level using configured thresholds
        impact_level_str = self.compute_impact_level(dissimilarity)

        # Map string to ImpactLevel enum
        impact_level_map = {
            'HIGH': ImpactLevel.HIGH,
            'MEDIUM': ImpactLevel.MEDIUM,
            'LOW': ImpactLevel.LOW,
            'NONE': ImpactLevel.NONE,
        }
        impact_level = impact_level_map.get(impact_level_str, ImpactLevel.NONE)

        # Map algorithm to analysis method
        algo_name = similarity_result.algorithm.lower()
        if 'jaccard' in algo_name:
            analysis_method = AnalysisMethod.RULE_BASED  # Lexical overlap
        elif 'cosine' in algo_name or 'embedding' in algo_name:
            analysis_method = AnalysisMethod.ML_MODEL  # Semantic similarity
        elif 'hybrid' in algo_name:
            analysis_method = AnalysisMethod.HYBRID
        else:
            analysis_method = AnalysisMethod.RULE_BASED

        # Create FAQImpactAnalysis object
        return FAQImpactAnalysis(
            change_id=change_id,
            question_id=question_id,
            answer_id=answer_id,
            diff_id=diff_id,
            overall_impact_score=dissimilarity,
            lexical_overlap_score=similarity_result.score if 'jaccard' in algo_name else None,
            semantic_similarity_score=similarity_result.score if 'cosine' in algo_name else None,
            keyword_match_score=None,  # Not computed by base algorithms
            phrase_match_score=None,  # Not computed by base algorithms
            impact_level=impact_level,
            is_affected=is_affected,
            confidence=0.9,  # High confidence for direct computation
            analysis_method=analysis_method,
            analysis_version="v3.1",
            threshold_used=threshold,
            analyzed_at=datetime.utcnow(),
            metadata=similarity_result.metadata,
        )

    def batch_to_faq_impact_analysis(
        self,
        batch_result: BatchSimilarityResult,
        change_id: int,
        question_ids: List[int],
        threshold: float,
        answer_ids: Optional[List[Optional[int]]] = None,
        diff_ids: Optional[List[Optional[int]]] = None,
    ) -> List:
        """
        Convert batch similarity results to FAQImpactAnalysis objects.

        Args:
            batch_result: BatchSimilarityResult from compute_batch_similarity()
            change_id: ID of content change being analyzed
            question_ids: List of FAQ question IDs (must match results length)
            threshold: Dissimilarity threshold for marking as affected
            answer_ids: Optional list of answer IDs
            diff_ids: Optional list of diff IDs

        Returns:
            List of FAQImpactAnalysis objects

        Raises:
            ValueError: If list lengths don't match results
        """
        num_results = len(batch_result.results)

        if len(question_ids) != num_results:
            raise ValueError(
                f"question_ids length ({len(question_ids)}) must match "
                f"results length ({num_results})"
            )

        if answer_ids and len(answer_ids) != num_results:
            raise ValueError(
                f"answer_ids length ({len(answer_ids)}) must match "
                f"results length ({num_results})"
            )

        if diff_ids and len(diff_ids) != num_results:
            raise ValueError(
                f"diff_ids length ({len(diff_ids)}) must match "
                f"results length ({num_results})"
            )

        # Default to None for optional IDs
        if not answer_ids:
            answer_ids = [None] * num_results
        if not diff_ids:
            diff_ids = [None] * num_results

        impacts = []
        for sim_result, question_id, answer_id, diff_id in zip(
            batch_result.results, question_ids, answer_ids, diff_ids
        ):
            impact = self.to_faq_impact_analysis(
                similarity_result=sim_result,
                change_id=change_id,
                question_id=question_id,
                threshold=threshold,
                answer_id=answer_id,
                diff_id=diff_id,
            )
            impacts.append(impact)

        return impacts

    def get_affected_faqs(
        self,
        batch_result: BatchSimilarityResult,
        question_ids: List[int],
        threshold: float,
    ) -> List[int]:
        """
        Get list of affected FAQ question IDs from batch results.

        Args:
            batch_result: BatchSimilarityResult from compute_batch_similarity()
            question_ids: List of FAQ question IDs
            threshold: Dissimilarity threshold

        Returns:
            List of question_ids where dissimilarity >= threshold
        """
        if len(question_ids) != len(batch_result.results):
            raise ValueError("question_ids length must match results length")

        affected = []
        for question_id, result in zip(question_ids, batch_result.results):
            dissimilarity = 1.0 - result.score
            if dissimilarity >= threshold:
                affected.append(question_id)

        return affected

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"FaqImpactAnalyzer(calculator={self.calculator.get_algorithm_name()}, "
            f"thresholds={self.thresholds})"
        )