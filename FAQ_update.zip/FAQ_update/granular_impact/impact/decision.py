"""Impact decision logic."""
from granular_impact.config import ImpactLevel
from granular_impact.database.models import ImpactDecision


class ImpactDecisionMaker:
    def __init__(self, config):
        self.config = config

    def make_decision(self, impact_score: float) -> ImpactDecision:
        if impact_score >= self.config.critical_threshold:
            return ImpactDecision.INVALIDATE
        elif impact_score >= self.config.high_threshold:
            return ImpactDecision.HIGH_IMPACT
        elif impact_score >= self.config.medium_threshold:
            return ImpactDecision.MEDIUM_IMPACT
        elif impact_score >= self.config.low_threshold:
            return ImpactDecision.LOW_IMPACT
        else:
            return ImpactDecision.NO_IMPACT
