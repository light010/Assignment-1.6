"""Core impact analysis logic."""
from datetime import datetime
from uuid import uuid4

from granular_impact.database.models import ImpactResult, ChangeType
from granular_impact.impact.scoring import ImpactScorer
from granular_impact.impact.decision import ImpactDecisionMaker


class ImpactAnalyzer:
    def __init__(self, config, similarity_calculator, diff_engine, semantic_detector):
        self.config = config
        self.similarity_calculator = similarity_calculator
        self.diff_engine = diff_engine
        self.semantic_detector = semantic_detector
        self.scorer = ImpactScorer()
        self.decision_maker = ImpactDecisionMaker(config.impact)

    def analyze_impact(self, faq_id: str, content_id: str, old_content: str, new_content: str, old_checksum: str, new_checksum: str) -> ImpactResult:
        sim_result = self.similarity_calculator.compute_similarity(old_content, new_content)
        diff_result = self.diff_engine.compute_diff(old_content, new_content)
        semantic_changes = self.semantic_detector.detect_numeric_changes(old_content, new_content)

        sim_score = self.scorer.compute_similarity_score(sim_result)
        diff_score = self.scorer.compute_diff_magnitude_score(old_content, new_content, diff_result.diff_ratio)
        sem_score = self.scorer.compute_semantic_importance_score({"numeric": semantic_changes})

        overall_score = self.scorer.compute_overall_score(sim_score, diff_score, sem_score)
        decision = self.decision_maker.make_decision(overall_score)

        return ImpactResult(
            result_id=str(uuid4()),
            faq_id=faq_id,
            content_id=content_id,
            content_old_checksum=old_checksum,
            content_new_checksum=new_checksum,
            similarity_score=sim_score,
            diff_magnitude=diff_score,
            semantic_importance=sem_score,
            overall_impact_score=overall_score,
            impact_decision=decision,
            change_type=ChangeType.CONTENT_UPDATE,
            analysis_timestamp=datetime.now(),
            algorithm_used=sim_result.algorithm,
            algorithm_metadata=sim_result.metadata
        )
