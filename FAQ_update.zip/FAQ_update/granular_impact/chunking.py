"""
Simple Chunking Module

Minimal character-based chunking for computing content checksums.
No overengineering - just split text into fixed-size chunks and compute SHA-256 hashes.

Design Philosophy:
- Simple: Character-based splitting, no complex algorithms
- Deterministic: Same content always produces same chunks/checksums
- Minimal: No dependencies beyond stdlib
- Correct: Chunks concatenate back to original content

Author: Analytics Assist Team
Date: 2025-10-26
"""

import hashlib
from typing import List, Tuple


class SimpleChunker:
    """
    Simple character-based text chunker.

    Splits text into fixed-size character chunks for checksum computation.
    Designed to be minimal and deterministic.

    Example:
        >>> chunker = SimpleChunker(chunk_size=1000)
        >>> chunks = chunker.chunk("Long document...")
        >>> chunks_with_checksums = chunker.chunk_with_checksums("Long document...")
    """

    def __init__(self, chunk_size: int = 1000):
        """
        Initialize chunker with chunk size.

        Args:
            chunk_size: Number of characters per chunk (default: 1000)

        Raises:
            ValueError: If chunk_size <= 0
        """
        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")

        self.chunk_size = chunk_size

    def chunk(self, content: str) -> List[str]:
        """
        Split content into fixed-size character chunks.

        Args:
            content: Text content to chunk

        Returns:
            List of text chunks (empty list if content is empty)

        Example:
            >>> chunker = SimpleChunker(chunk_size=50)
            >>> chunks = chunker.chunk("A" * 125)
            >>> len(chunks)
            3
            >>> [len(c) for c in chunks]
            [50, 50, 25]
        """
        if not content:
            return []

        chunks = []
        start = 0

        while start < len(content):
            end = start + self.chunk_size
            chunks.append(content[start:end])
            start = end

        return chunks

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str]]:
        """
        Split content into chunks and compute SHA-256 checksum for each.

        Args:
            content: Text content to chunk and hash

        Returns:
            List of (chunk_text, checksum) tuples
            - chunk_text: The text chunk
            - checksum: 64-character hex string (SHA-256)

        Example:
            >>> chunker = SimpleChunker(chunk_size=100)
            >>> results = chunker.chunk_with_checksums("Sample text")
            >>> chunk, checksum = results[0]
            >>> len(checksum)
            64
        """
        chunks = self.chunk(content)

        results = []
        for chunk_text in chunks:
            checksum = self._compute_checksum(chunk_text)
            results.append((chunk_text, checksum))

        return results

    def _compute_checksum(self, text: str) -> str:
        """
        Compute SHA-256 checksum for text.

        Args:
            text: Text to hash

        Returns:
            64-character hex string (SHA-256)
        """
        return hashlib.sha256(text.encode('utf-8')).hexdigest()
