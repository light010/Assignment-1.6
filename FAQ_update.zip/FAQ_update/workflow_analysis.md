# Deep Analysis of Proposed Workflow

## Your Proposed Workflow

### Step 1 - Notebook 0 (Baseline Ingestion)
```
Load sample_content_repo.csv
Insert 14 records (all v1, all Active)
Result: 14 records in content_repo
```

### Step 2 - Notebook 1 (Baseline Checksums)
```
For each Active record in content_repo:
  - Chunk the markdown file
  - Compute checksums
  - Insert into content_checksums
Result: 14 files worth of checksums (baseline)
```

### Step 3 - Notebook 3 (Content Update)
```
Load sample_content_repo_v2_edited.csv

For each row in CSV:
  Keep old version (append-only)
  - If NOT EXISTS: INSERT

Result: 15 active records (either v1 or v2, NOT both)
```

### Step 4 - Notebook 4 (Change Detection)
```
# Get files modified since baseline
modified_files = content_repo WHERE last_modified_dt > SINCE_DATE

For each modified_file:
  # Compute NEW checksums (v2)
  new_checksums = chunk_and_compute(modified_file.markdown_path)

  # Load OLD checksums (v1) from baseline
  old_checksums = content_checksums WHERE file_name = modified_file.raw_file_nme
                                     AND created_at < EDIT_TIME

  # Detect changes
  changes = compare_checksums(new_checksums, old_checksums)
```

---

## CRITICAL ANALYSIS

### ✅ LOOPHOLE #1 RESOLVED: Step 3 Logic - APPEND-ONLY Strategy Confirmed

**Clarified Requirement:**
```
For each row in CSV:
  Keep old version (append-only) ✅ Correct approach
  - If NOT EXISTS: INSERT

Result: 24 active records (BOTH v1 AND v2 for updated files)
```

**Understanding:**
- **Append-only** means ALL versions (v1, v2, v3, ...) remain in content_repo
- This creates a **complete audit trail** of all content versions
- Query logic must use `MAX(raw_file_version_nbr)` to get latest version

**What Will Happen (Correct):**

Given your CSV files:
- Baseline CSV: 14 files (all v1)
- Edited CSV: 15 files (8 at v2, 7 at v1)

With append-only strategy:
```
After Notebook 0: 14 records (all v1)

After Notebook 3 with append-only + duplicate prevention:
  - Employee_Handbook v1 EXISTS → KEEP (no action)
  - Employee_Handbook v2 from CSV → INSERT (new version)
  - ... same for 7 other updated files
  - Benefits_Guide v1 EXISTS → KEEP
  - Benefits_Guide v1 from CSV → SKIP (duplicate prevention needed!)
  - Workplace_Safety v1 NEW → INSERT
  - Equipment_Return v1 NEW → INSERT

Result: 14 (original v1) + 8 (new v2) + 2 (new files) - 5 (skipped duplicates) = 19 records
```

---

### ✅ LOOPHOLE #2 RESOLVED: Duplicate Prevention - Fixed by Cleaning CSV

**The Problem (RESOLVED):**

The edited CSV previously contained unchanged files that also existed in the baseline:
- Benefits_Guide v1, Code_of_Conduct v1, etc. (5 files)
- This caused duplicate insertions in Notebook 3

**Solution Applied:**
Removed unchanged v1 files from `sample_content_repo_v2_edited.csv`. The CSV now contains ONLY:
- 8 files at v2 (updates from baseline)
- 2 files at v1 (new files: Workplace_Safety, Equipment_Return)

**Result:** CSV represents "delta/changes" from baseline, not complete state. No duplicates will be created! ✅

---

### ✅ LOOPHOLE #3 RESOLVED: Schema Migration from content_checksums to content_chunks

**Original Problem (content_checksums table):**
```
old_checksums = content_checksums WHERE file_name = modified_file.raw_file_nme
                                   AND created_at < EDIT_TIME  ❌ FRAGILE
```

**Critical Issues (NOW RESOLVED):**

1. **❌ OLD: EDIT_TIME fragility**
   - Relied on timestamp comparison
   - Broke if notebooks ran out of order
   - ✅ NEW: No timestamps needed - FK to content_repo provides version

2. **❌ OLD: Multiple entries for same file**
   - Running Notebook 1 twice created duplicates
   - No way to identify which checksums belonged to which version
   - ✅ NEW: `UNIQUE(ud_source_file_id, content_checksum)` prevents duplicates per file

3. **❌ OLD: Not version-aware**
   - Only had `file_name`, no `file_version`
   - Had to rely on `created_at` timestamp (FRAGILE)
   - ✅ NEW: Direct FK to content_repo with version tracking

**NEW SCHEMA DESIGN (content_chunks):**

```sql
-- content_repo: Version tracking with UNIQUE constraint
CREATE TABLE content_repo (
    ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_file_nme TEXT NOT NULL,
    raw_file_version_nbr INT DEFAULT 1,
    ...
    UNIQUE(raw_file_nme, raw_file_version_nbr),  -- ✅ Prevents duplicate versions
);

-- content_chunks: FK relationship enables version tracking
CREATE TABLE content_chunks (
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
    ud_source_file_id INTEGER NOT NULL,         -- ✅ FK to specific file version
    chunk_index INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,
    chunk_text TEXT NOT NULL,                    -- ✅ Stores content (no re-chunking)
    ...
    FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE,
    UNIQUE(ud_source_file_id, content_checksum), -- ✅ No duplicate checksums per file
);
```

**NEW VERSION-AWARE QUERY PATTERN:**

```sql
-- Get v1 chunks (EXPLICIT version - no timestamps!)
SELECT cc.content_checksum, cc.chunk_text, cc.chunk_index
FROM content_chunks cc
JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
WHERE cr.raw_file_nme = 'handbook.pdf'
  AND cr.raw_file_version_nbr = 1
ORDER BY cc.chunk_index;

-- Get v2 chunks (EXPLICIT version - no timestamps!)
SELECT cc.content_checksum, cc.chunk_text, cc.chunk_index
FROM content_chunks cc
JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
WHERE cr.raw_file_nme = 'handbook.pdf'
  AND cr.raw_file_version_nbr = 2
ORDER BY cc.chunk_index;

-- Compare versions (structural, not temporal)
SELECT
    v1.content_checksum as v1_checksum,
    v2.content_checksum as v2_checksum,
    CASE
        WHEN v1.content_checksum = v2.content_checksum THEN 'UNCHANGED'
        WHEN v1.content_checksum IS NULL THEN 'NEW_CONTENT'
        WHEN v2.content_checksum IS NULL THEN 'DELETED_CONTENT'
        ELSE 'MODIFIED_CONTENT'
    END as change_type
FROM (SELECT * FROM content_chunks WHERE ud_source_file_id = 1) v1
FULL OUTER JOIN (SELECT * FROM content_chunks WHERE ud_source_file_id = 5) v2
    ON v1.chunk_index = v2.chunk_index;
```

**KEY BENEFITS:**

1. ✅ **Version tracking is STRUCTURAL, not TEMPORAL**
   - `ud_source_file_id` uniquely identifies file version
   - No dependency on timestamps or execution order

2. ✅ **Prevents duplicate file versions**
   - `UNIQUE(raw_file_nme, raw_file_version_nbr)` in content_repo
   - Can't accidentally insert handbook.pdf v1 twice

3. ✅ **Prevents duplicate chunks per file**
   - `UNIQUE(ud_source_file_id, content_checksum)` in content_chunks
   - Same checksum can't appear twice in same file version

4. ✅ **Allows shared content across files**
   - Same boilerplate can appear in multiple documents
   - Checksum only unique within file, not globally

5. ✅ **Stores chunk text**
   - No need to re-chunk files for comparison
   - Faster change detection

**STATUS:** ✅ **COMPLETELY RESOLVED** - Schema redesign eliminates all timestamp fragility

---

### 🚨 LOOPHOLE #4: Notebook 4 Computes NEW Checksums but Doesn't Store Version Info

```
For each modified_file:
  # Compute NEW checksums (v2)
  new_checksums = chunk_and_compute(modified_file.markdown_path)
```

**The Problem:**
- You compute v2 checksums in-memory
- You compare them to v1 baseline checksums
- But WHERE do you store the v2 checksums?
- If you don't store them, how do you handle v2 → v3 updates later?

**The Missing Piece:**
Notebook 4 should:
1. Compute v2 checksums
2. **Store them in content_checksums with a flag** (e.g., `is_baseline=0`, `version_nbr=2`)
3. Compare against baseline (v1) checksums
4. Detect changes

Otherwise, v2 checksums are lost and you can't track v2 → v3 changes.

---

### 🚨 LOOPHOLE #5: What Happens to DELETED Files?

**Scenario:**
- Baseline has Parking_Policy.pdf (v1)
- Edited CSV does NOT have Parking_Policy.pdf
- This means the file was REMOVED from the content repository

**What does your workflow do?**
- Notebook 0: Inserts Parking_Policy v1
- Notebook 1: Computes checksums for Parking_Policy v1 (baseline)
- Notebook 3: Edited CSV doesn't have it → NO ACTION (append-only)
- Result: Parking_Policy v1 remains in content_repo as "Active"

**Is this correct?**
- If a file is removed from the source, should it stay "Active"?
- Should it be marked "Inactive" or "Deleted"?
- What about its FAQs? Should they be invalidated?

Your current workflow **DOES NOT handle deletions**.

---

### ✅ LOOPHOLE #6 RESOLVED: Duplicate v1 Records - Same as Loophole #2

**Status:** RESOLVED by cleaning CSV (same fix as Loophole #2)

The edited CSV no longer contains unchanged v1 files, so this issue is eliminated.

---

### 🚨 LOOPHOLE #7: Timestamp-Based Filtering is FRAGILE

In Step 4:
```
modified_files = content_repo WHERE last_modified_dt > SINCE_DATE
```

**Problems:**

1. **Manual timestamp management:**
   - You have to manually set SINCE_DATE
   - What if you run Notebook 4 multiple times?
   - What if you forget to update SINCE_DATE?

2. **No idempotency:**
   - Running Notebook 4 twice with same SINCE_DATE will re-detect same changes
   - Creates duplicate entries in content_change_log

3. **Timezone issues:**
   - SINCE_DATE format must match database format
   - Your DB uses 'YYYY-MM-DD HH:MM:SS'
   - What if someone uses ISO format or different timezone?

**Better Approach:**
Use version numbers instead:
```sql
SELECT * FROM content_repo
WHERE raw_file_version_nbr > 1  -- All updated files
  AND file_status = 'Active'
```

Or use a flag:
```sql
SELECT * FROM content_repo
WHERE change_detected_flag = 0  -- Not yet processed
  AND file_status = 'Active'
```

---

### 🚨 LOOPHOLE #8: No Handling for Version > 2 (Future Updates)

**Scenario:**
- Today: v1 (baseline)
- Next week: v2 (first update) ← Your workflow handles this
- Next month: v3 (second update) ← Does your workflow handle this?

**For v2 → v3 detection:**
- Baseline is v1 checksums
- Current is v3 checksums
- But v3 changes might be INCREMENTAL from v2, not v1
- You need to compare v3 against v2 (not v1!) to detect RECENT changes

**Your workflow assumes only 2 versions exist!**

**Solution:**
Store checksums for EACH version:
```sql
content_checksums:
  - content_checksum
  - file_name
  - file_version_nbr  ← ADD THIS!
  - created_at
  - is_current (boolean)
```

Then comparison logic:
```python
# Get previous version checksums
prev_version = current_version - 1
old_checksums = SELECT * FROM content_checksums
                WHERE file_name = ? AND file_version_nbr = prev_version

# Get current version checksums (computed on-the-fly or loaded)
new_checksums = chunk_and_compute(current_file)

# Compare
changes = detect_changes(new_checksums, old_checksums)

# Store new checksums for future comparisons
INSERT INTO content_checksums (file_version_nbr = current_version)
```

---

### 🚨 LOOPHOLE #9: NEW Files in Edited CSV Have No Baseline

**Scenario:**
- Workplace_Safety.pdf is NEW in edited CSV (v1)
- Equipment_Return.pdf is NEW in edited CSV (v1)

**What happens in Step 4?**
```
modified_files = content_repo WHERE last_modified_dt > SINCE_DATE

For Workplace_Safety:
  new_checksums = chunk_and_compute(Workplace_Safety_v1.md)

  old_checksums = content_checksums WHERE file_name = 'Workplace_Safety.pdf'
                                     AND created_at < EDIT_TIME
  → Returns EMPTY (no baseline!)

  changes = compare_checksums(new_checksums, EMPTY)
  → All chunks marked as "NEW_CONTENT"
```

**Is this correct behavior?**
- YES, technically they are "new content"
- But should NEW files go through change detection at all?
- Or should they be handled separately (e.g., auto-approved for FAQ generation)?

**Recommendation:**
Separate NEW files from UPDATED files:
```python
new_files = content_repo WHERE file_version_nbr = 1
                          AND raw_file_nme NOT IN (SELECT DISTINCT raw_file_nme
                                                   FROM baseline_content)

updated_files = content_repo WHERE file_version_nbr > 1

# NEW files: Auto-process (all content is new)
# UPDATED files: Run change detection
```

---

### 🚨 LOOPHOLE #10: content_repo Has No "Processed" Flag

**Problem:**
- After Notebook 4 detects changes, how do you mark files as "processed"?
- If you run Notebook 4 again, it will re-detect the same changes
- Creates duplicate entries in content_change_log

**Example:**
```
Run 1 of Notebook 4:
  - Detects Employee_Handbook v1 → v2 changes
  - Inserts 50 change records into content_change_log

Run 2 of Notebook 4 (by accident):
  - Detects same changes again (SINCE_DATE unchanged)
  - Inserts ANOTHER 50 change records
  → Now you have 100 records for same change!
```

**Solution:**
Add a `change_detection_status` column:
```sql
ALTER TABLE content_repo
ADD COLUMN change_detection_status VARCHAR(20) DEFAULT 'pending';

-- Values: 'pending', 'in_progress', 'completed', 'failed'
```

Then:
```python
# Notebook 4
modified_files = content_repo WHERE last_modified_dt > SINCE_DATE
                              AND change_detection_status = 'pending'

# After processing
UPDATE content_repo
SET change_detection_status = 'completed'
WHERE ud_source_file_id = ?
```

---

## REVISED WORKFLOW WITH FIXES

### Step 0: Database Schema Updates

```sql
-- Add version tracking to checksums
ALTER TABLE content_checksums
ADD COLUMN file_version_nbr INTEGER,
ADD COLUMN is_baseline BOOLEAN DEFAULT 0;

-- Add processing status to content_repo
ALTER TABLE content_repo
ADD COLUMN change_detection_status VARCHAR(20) DEFAULT 'pending';

-- Add unique constraint to prevent duplicates
CREATE UNIQUE INDEX idx_unique_file_version
ON content_repo(raw_file_nme, raw_file_version_nbr, file_status)
WHERE file_status = 'Active';
```

### Step 1 - Notebook 0 (Baseline Ingestion)

```python
# Load baseline CSV
baseline_df = pd.read_csv('sample_content_repo.csv')

# Insert with duplicate check
for _, row in baseline_df.iterrows():
    existing = pd.read_sql_query("""
        SELECT ud_source_file_id FROM content_repo
        WHERE raw_file_nme = ? AND raw_file_version_nbr = ?
          AND file_status = 'Active'
    """, conn, params=[row['raw_file_nme'], row['raw_file_version_nbr']])

    if len(existing) == 0:
        # Add status field
        row['change_detection_status'] = 'completed'  # Baseline = already processed
        pd.DataFrame([row]).to_sql('content_repo', conn, if_exists='append', index=False)

# Result: 14 records (all v1, all Active, all status='completed')
```

### Step 2 - Notebook 1 (Baseline Checksums)

```python
# Get all v1 files (baseline)
baseline_files = pd.read_sql_query("""
    SELECT * FROM content_repo
    WHERE raw_file_version_nbr = 1 AND file_status = 'Active'
""", conn)

for _, file_row in baseline_files.iterrows():
    # Chunk and compute checksums
    chunks = chunker.chunk_with_checksums(content)

    for chunk_text, checksum in chunks:
        # Insert with version and baseline flag
        conn.execute("""
            INSERT INTO content_checksums
            (content_checksum, file_name, file_version_nbr, is_baseline, status)
            VALUES (?, ?, ?, ?, ?)
        """, (checksum, file_row['raw_file_nme'], 1, True, 'active'))

# Result: 14 files worth of checksums (all v1, all is_baseline=True)
```

### Step 3 - Notebook 3 (Content Update)

```python
# Load edited CSV (complete state snapshot)
edited_df = pd.read_csv('sample_content_repo_v2_edited.csv')

# Strategy: UPSERT (insert if not exists, skip if exists)
for _, row in edited_df.iterrows():
    # Check if (file_name, version) already exists
    existing = pd.read_sql_query("""
        SELECT ud_source_file_id FROM content_repo
        WHERE raw_file_nme = ? AND raw_file_version_nbr = ?
          AND file_status = 'Active'
    """, conn, params=[row['raw_file_nme'], row['raw_file_version_nbr']])

    if len(existing) > 0:
        # Already exists - SKIP (no duplicate)
        print(f"SKIP: {row['raw_file_nme']} v{row['raw_file_version_nbr']} already exists")
        continue

    # Check if this is a new version of existing file
    prev_version = pd.read_sql_query("""
        SELECT MAX(raw_file_version_nbr) as max_version FROM content_repo
        WHERE raw_file_nme = ? AND file_status = 'Active'
    """, conn, params=[row['raw_file_nme']])

    if prev_version.iloc[0]['max_version'] is not None:
        # This is an UPDATE (new version)
        row['change_detection_status'] = 'pending'  # Needs change detection
        print(f"UPDATE: {row['raw_file_nme']} v{prev_version.iloc[0]['max_version']} → v{row['raw_file_version_nbr']}")
    else:
        # This is a NEW file
        row['change_detection_status'] = 'new_file'  # Mark as new (no baseline)
        print(f"NEW: {row['raw_file_nme']} v{row['raw_file_version_nbr']}")

    # INSERT (append-only)
    pd.DataFrame([row]).to_sql('content_repo', conn, if_exists='append', index=False)

# Result: 14 (original v1) + 8 (new v2) + 2 (new files) = 24 records total
#         But each (file, version) is UNIQUE
```

**Expected After Notebook 3:**
```
Employee_Handbook.pdf  v1  status='completed'   (from baseline)
Employee_Handbook.pdf  v2  status='pending'     (new version)
Benefits_Guide.pdf     v1  status='completed'   (unchanged)
Workplace_Safety.pdf   v1  status='new_file'    (new file)
... etc
```

### Step 4 - Notebook 4 (Change Detection)

```python
# Get files that need change detection
# Option 1: Use status flag (BETTER)
files_to_process = pd.read_sql_query("""
    SELECT * FROM content_repo
    WHERE change_detection_status = 'pending'
      AND file_status = 'Active'
""", conn)

# Option 2: Use timestamp (if status not available)
# files_to_process = pd.read_sql_query("""
#     SELECT * FROM content_repo
#     WHERE last_modified_dt > ?
#       AND file_status = 'Active'
#       AND raw_file_version_nbr > 1
# """, conn, params=[SINCE_DATE])

for _, file_row in files_to_process.iterrows():
    file_name = file_row['raw_file_nme']
    current_version = file_row['raw_file_version_nbr']
    prev_version = current_version - 1

    # Compute NEW checksums (current version)
    markdown_path = PROJECT_ROOT / file_row['extracted_markdown_file_path']
    content = markdown_path.read_text(encoding='utf-8')
    new_chunks = chunker.chunk_with_checksums(content)

    # Prepare current_data for detector
    current_data = {}
    for chunk_text, checksum in new_chunks:
        current_data[checksum] = {
            'text': chunk_text,
            'file_name': file_name,
            'page_num': None
        }

    # Load OLD checksums (previous version from database)
    old_checksums_df = pd.read_sql_query("""
        SELECT * FROM content_checksums
        WHERE file_name = ? AND file_version_nbr = ?
          AND status = 'active'
    """, conn, params=[file_name, prev_version])

    # Prepare previous_data for detector
    # Need to reconstruct chunk text from checksum
    # PROBLEM: We didn't store chunk text in content_checksums!

    # SOLUTION 1: Re-compute chunks from v1 file
    prev_file = pd.read_sql_query("""
        SELECT * FROM content_repo
        WHERE raw_file_nme = ? AND raw_file_version_nbr = ?
          AND file_status = 'Active'
    """, conn, params=[file_name, prev_version])

    if len(prev_file) > 0:
        prev_path = PROJECT_ROOT / prev_file.iloc[0]['extracted_markdown_file_path']
        prev_content = prev_path.read_text(encoding='utf-8')
        prev_chunks = chunker.chunk_with_checksums(prev_content)

        previous_data = {}
        for chunk_text, checksum in prev_chunks:
            previous_data[checksum] = {
                'content_text': chunk_text,
                'file_name': file_name
            }
    else:
        # No previous version (new file)
        previous_data = {}

    # Run change detection
    changes = detector.detect_changes(
        file_name=file_name,
        current_checksums_data=current_data,
        previous_checksums_data=previous_data,
        detection_run_id=DETECTION_RUN_ID
    )

    # Store changes
    ChangeDetectionQueries.store_change_detection_results(
        conn, changes, DETECTION_RUN_ID, use_spark=False
    )

    # Store current version checksums for future comparisons
    for checksum in current_data.keys():
        conn.execute("""
            INSERT INTO content_checksums
            (content_checksum, file_name, file_version_nbr, is_baseline, status)
            VALUES (?, ?, ?, ?, ?)
        """, (checksum, file_name, current_version, False, 'active'))

    # Mark file as processed
    conn.execute("""
        UPDATE content_repo
        SET change_detection_status = 'completed'
        WHERE ud_source_file_id = ?
    """, (file_row['ud_source_file_id'],))

print(f"✅ Processed {len(files_to_process)} files")
```

### Handling NEW Files (Separate Process)

```python
# Get new files (no baseline to compare against)
new_files = pd.read_sql_query("""
    SELECT * FROM content_repo
    WHERE change_detection_status = 'new_file'
      AND file_status = 'Active'
""", conn)

for _, file_row in new_files.iterrows():
    # All content is NEW
    # Mark all chunks as NEW_CONTENT
    # Or skip change detection and go directly to FAQ generation

    # Store checksums for future tracking
    markdown_path = PROJECT_ROOT / file_row['extracted_markdown_file_path']
    content = markdown_path.read_text(encoding='utf-8')
    chunks = chunker.chunk_with_checksums(content)

    for chunk_text, checksum in chunks:
        conn.execute("""
            INSERT INTO content_checksums
            (content_checksum, file_name, file_version_nbr, is_baseline, status)
            VALUES (?, ?, ?, ?, ?)
        """, (checksum, file_row['raw_file_nme'], file_row['raw_file_version_nbr'],
              False, 'active'))

    # Mark as processed
    conn.execute("""
        UPDATE content_repo
        SET change_detection_status = 'completed'
        WHERE ud_source_file_id = ?
    """, (file_row['ud_source_file_id'],))
```

---

## SUMMARY OF LOOPHOLES (UPDATED WITH APPEND-ONLY + CSV CLEANUP)

**Design Decision Confirmed:** ✅ **APPEND-ONLY STRATEGY** - Keep ALL versions (v1, v2, v3, ...) in content_repo

This creates a complete audit trail and is a VALID design choice.

| # | Loophole | Impact | Status | Solution |
|---|----------|--------|--------|----------|
| 1 | ~~Step 3 contradicts result~~ | ~~Confusion~~ | ✅ **RESOLVED** | Append-only confirmed - keep all versions |
| 2 | ~~Duplicate v1 in CSV~~ | ~~5 duplicate records~~ | ✅ **RESOLVED** | Removed unchanged files from CSV |
| 3 | ~~Timestamp-based filtering fragile~~ | ~~Wrong comparisons~~ | ✅ **RESOLVED** | Schema migration to content_chunks with FK to content_repo |
| 4 | ~~v2 checksums not stored~~ | ~~Re-computation overhead~~ | ✅ **RESOLVED** | content_chunks stores chunk_text |
| 5 | Deleted files not handled | Parking_Policy remains | ⚠️ Low | Design decision needed |
| 6 | ~~Duplicate v1 in DB~~ | ~~Data integrity~~ | ✅ **RESOLVED** | UNIQUE(raw_file_nme, raw_file_version_nbr) constraint |
| 7 | ~~Manual SINCE_DATE management~~ | ~~Human error~~ | ✅ **RESOLVED** | Version-aware queries with FK join |
| 8 | ~~Version comparison logic~~ | ~~Works if fixed~~ | ✅ **RESOLVED** | Compare via ud_source_file_id |
| 9 | NEW files mixed with UPDATED | Confusing | ⚠️ Low | Can separate in queries |
| 10 | No processed flag | Re-processing | ⚠️ Low | Use version-based filtering |

**SCHEMA MIGRATION IMPACT:**
- ✅ Loophole #3: **RESOLVED** - FK relationship provides structural version tracking (no timestamps)
- ✅ Loophole #4: **RESOLVED** - chunk_text stored in content_chunks (no re-chunking)
- ✅ Loophole #6: **RESOLVED** - UNIQUE constraint prevents duplicate file versions
- ✅ Loophole #7: **RESOLVED** - No SINCE_DATE needed, use version number queries
- ✅ Loophole #8: **RESOLVED** - Each version has unique ud_source_file_id for direct comparison

**REMAINING ISSUES:**
- ⚠️ Loophole #5: Deleted files handling (design decision needed)
- ⚠️ Loophole #9: NEW vs UPDATED file separation (optional improvement)
- ⚠️ Loophole #10: Processed flag (optional improvement)

---

## FINAL RECOMMENDATION (UPDATED FOR APPEND-ONLY + CSV CLEANUP)

Your proposed workflow uses **APPEND-ONLY STRATEGY** ✅ - This is a valid design choice!

### Expected Database State (After CSV Cleanup):

```
After Notebook 0: 14 records (all v1)
After Notebook 3: 24 records (NO DUPLICATES!)
  - 8 files with BOTH v1 and v2 (16 records)
  - 5 files with only v1 (5 records, unchanged from baseline)
  - 2 files with only v1 (2 records, new files)
  - 1 file Parking_Policy.pdf v1 (1 record, from baseline, not in edited CSV)
Total: 24 records
```

### CRITICAL FIXES NEEDED:

### 1. ✅ **CSV Cleanup - COMPLETED**

**Problem:** Edited CSV contained unchanged v1 files that already existed in baseline
**Solution:** Removed 5 unchanged files from `sample_content_repo_v2_edited.csv`
**Result:** CSV now represents "delta/changes" - no duplicates will be created!

### 2. **Fix Notebook 4 - Use Version-Aware Queries** ⚠️ **Important**

```python
# Instead of timestamp filtering:
# modified_files = WHERE last_modified_dt > SINCE_DATE

# Use version-based filtering:
updated_files = pd.read_sql_query("""
    SELECT DISTINCT raw_file_nme
    FROM content_repo
    WHERE file_status = 'Active'
    GROUP BY raw_file_nme
    HAVING MAX(raw_file_version_nbr) > 1
""", conn)
# This returns files with v2, v3, etc. (i.e., updated files)
```

### 3. **Fix Notebook 4 - Use Chunk-Level Data** ❌ **CRITICAL**

```python
# Current (WRONG - uses file-level):
current_data = {}
for _, row in modified_content_df.iterrows():
    if pd.notna(row["content_checksum"]):  # This is "None"!
        text = full_path.read_text(encoding="utf-8")  # FULL FILE
        current_data[row["content_checksum"]] = {'text': text}

# Fixed (uses chunk-level):
# After chunking in Step 3:
current_data = {}
for chunk_text, checksum in chunks:  # Use actual chunks!
    current_data[checksum] = {
        'text': chunk_text,  # CHUNK text, not full file
        'file_name': file_name
    }
```

### 4. **Query Patterns for Append-Only Design**

Since all versions remain active, queries must be version-aware:

```sql
-- Get latest version of each file
SELECT cr1.*
FROM content_repo cr1
INNER JOIN (
    SELECT raw_file_nme, MAX(raw_file_version_nbr) as max_ver
    FROM content_repo
    WHERE file_status = 'Active'
    GROUP BY raw_file_nme
) cr2 ON cr1.raw_file_nme = cr2.raw_file_nme
     AND cr1.raw_file_version_nbr = cr2.max_ver
WHERE cr1.file_status = 'Active'
```

### 5. **Optional: Add Version Tracking to Checksums**

```sql
ALTER TABLE content_checksums ADD COLUMN file_version_nbr INTEGER;
```

This allows storing checksums per version instead of re-computing.

---

## 🎯 PRIORITY ACTION ITEMS

1. ✅ **CSV Cleanup** - COMPLETED (removed 5 unchanged files from edited CSV)
2. **Clean current database** - Remove existing 5 duplicate v1 records from previous runs
3. **Fix Notebook 4 chunk-level data** ← **MOST CRITICAL NOW!**
4. **Fix Notebook 4 to use version-aware queries** (not timestamp filtering)
5. **(Optional) Add version column to checksums table** for better tracking

This will create a **robust append-only workflow** that handles v1→v2→v3→... correctly.

---

## 🎉 MAJOR SCHEMA IMPROVEMENTS

### Schema Migration: content_checksums → content_chunks

**Migration Date:** 2025-10-27

**Key Changes:**

1. **✅ Added UNIQUE constraint to content_repo**
   ```sql
   UNIQUE(raw_file_nme, raw_file_version_nbr)
   ```
   - Prevents duplicate file version entries
   - Eliminates Loophole #6 (duplicate v1 records)

2. **✅ Replaced content_checksums with content_chunks**
   ```sql
   CREATE TABLE content_chunks (
       chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
       ud_source_file_id INTEGER NOT NULL,  -- FK to content_repo
       content_checksum TEXT NOT NULL,
       chunk_text TEXT NOT NULL,            -- NEW: stores actual content
       chunk_index INTEGER NOT NULL,        -- NEW: preserves order
       FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
           ON DELETE CASCADE,
       UNIQUE(ud_source_file_id, content_checksum)
   );
   ```

3. **✅ Changed constraint from global to per-file uniqueness**
   - OLD: `UNIQUE(content_checksum)` - prevented shared boilerplate
   - NEW: `UNIQUE(ud_source_file_id, content_checksum)` - allows shared content across files

**Problems Solved:**

| Loophole | Old Approach | New Approach | Status |
|----------|--------------|--------------|--------|
| #3 | Timestamp-based `created_at < EDIT_TIME` | FK to content_repo with explicit version | ✅ RESOLVED |
| #4 | Checksums not stored, re-computation needed | `chunk_text` stored in table | ✅ RESOLVED |
| #6 | No duplicate prevention | `UNIQUE(raw_file_nme, raw_file_version_nbr)` | ✅ RESOLVED |
| #7 | Manual SINCE_DATE management | Version-aware JOIN queries | ✅ RESOLVED |
| #8 | Version comparison fragile | Direct `ud_source_file_id` comparison | ✅ RESOLVED |

**Test Coverage:**
- ✅ 12/12 tests passing
- ✅ FK constraint tests (cascade delete)
- ✅ UNIQUE constraint tests (per-file checksum uniqueness)
- ✅ Cross-file boilerplate sharing tests
- ✅ Version-aware query tests

---

## 📋 NEXT STEPS

Now that the CSV is cleaned and schema migrated, the main remaining issue is **Notebook 4's change detection logic**:

**Problem:** Notebook 4 currently uses file-level data instead of chunk-level data
**Impact:** Change detection receives empty `current_data` and reports everything as deleted

**Solution:** Modify Notebook 4 to use content_chunks table with proper version-aware queries:

```python
# NEW APPROACH: Query content_chunks with version awareness
def get_chunks_for_version(file_name: str, version: int):
    return pd.read_sql_query("""
        SELECT cc.content_checksum, cc.chunk_text, cc.chunk_index
        FROM content_chunks cc
        JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
        WHERE cr.raw_file_nme = ?
          AND cr.raw_file_version_nbr = ?
          AND cc.status = 'active'
        ORDER BY cc.chunk_index
    """, conn, params=[file_name, version])

# Get v1 chunks
v1_chunks = get_chunks_for_version('handbook.pdf', 1)

# Get v2 chunks
v2_chunks = get_chunks_for_version('handbook.pdf', 2)

# Compare
current_data = {row['content_checksum']: {'text': row['chunk_text']}
                for _, row in v2_chunks.iterrows()}
previous_data = {row['content_checksum']: {'content_text': row['chunk_text']}
                 for _, row in v1_chunks.iterrows()}

changes = detector.detect_changes(file_name, current_data, previous_data, run_id)
```
