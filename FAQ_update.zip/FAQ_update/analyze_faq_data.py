"""
Deep analysis of FAQ workflow data integrity.
"""
import sqlite3
import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
DB_PATH = PROJECT_ROOT / "databases" / "my_database.db"

# Load CSV files
baseline_csv = pd.read_csv(PROJECT_ROOT / "granular_impact/data_ingestion/data/sample_content_repo.csv")
edited_csv = pd.read_csv(PROJECT_ROOT / "granular_impact/data_ingestion/data/sample_content_repo_v2_edited.csv")

print("=" * 100)
print("COMPREHENSIVE WORKFLOW DATA ANALYSIS")
print("=" * 100)

print("\n" + "=" * 100)
print("PART 1: SOURCE CSV FILES ANALYSIS")
print("=" * 100)

print("\n📄 BASELINE CSV (sample_content_repo.csv) - Should be loaded by Notebook 0:")
print(f"   Total files: {len(baseline_csv)}")
print(f"   All v1 files: {(baseline_csv['raw_file_version_nbr'] == 1).all()}")
print("\nBaseline files:")
for _, row in baseline_csv.iterrows():
    print(f"   {row['raw_file_nme']:30s} v{row['raw_file_version_nbr']} → {row['extracted_markdown_file_path']}")

print("\n📄 EDITED CSV (sample_content_repo_v2_edited.csv) - Should be loaded by Notebook 3:")
print(f"   Total files: {len(edited_csv)}")

# Categorize the edited CSV
v1_only = edited_csv[edited_csv['raw_file_version_nbr'] == 1]['raw_file_nme'].tolist()
v2_files = edited_csv[edited_csv['raw_file_version_nbr'] == 2]['raw_file_nme'].tolist()

print(f"\n   Files at v1 (unchanged): {len(v1_only)}")
print(f"   Files at v2 (updated):   {len(v2_files)}")

print("\nEdited CSV breakdown:")
print("\n   ✏️  UPDATED FILES (v1 → v2):")
for fname in sorted(v2_files):
    v1_title = baseline_csv[baseline_csv['raw_file_nme'] == fname]['title_nme'].values[0]
    v2_title = edited_csv[edited_csv['raw_file_nme'] == fname]['title_nme'].values[0]
    print(f"      {fname:30s} v1: '{v1_title}'")
    print(f"      {'':<30s} v2: '{v2_title}'")

print("\n   🆕 NEW FILES (not in baseline):")
new_files = set(edited_csv['raw_file_nme']) - set(baseline_csv['raw_file_nme'])
for fname in sorted(new_files):
    row = edited_csv[edited_csv['raw_file_nme'] == fname].iloc[0]
    print(f"      {fname:30s} v{row['raw_file_version_nbr']} → {row['title_nme']}")

print("\n   🗑️  REMOVED FILES (in baseline but not in edited):")
removed_files = set(baseline_csv['raw_file_nme']) - set(edited_csv['raw_file_nme'])
for fname in sorted(removed_files):
    row = baseline_csv[baseline_csv['raw_file_nme'] == fname].iloc[0]
    print(f"      {fname:30s} v{row['raw_file_version_nbr']} → {row['title_nme']}")

print("\n   ⚪ UNCHANGED FILES (same in both):")
unchanged_files = [f for f in v1_only if f in baseline_csv['raw_file_nme'].tolist()]
for fname in sorted(unchanged_files):
    row = baseline_csv[baseline_csv['raw_file_nme'] == fname].iloc[0]
    print(f"      {fname:30s} v{row['raw_file_version_nbr']}")

print("\n" + "=" * 100)
print("PART 2: DATABASE ACTUAL STATE")
print("=" * 100)

conn = sqlite3.connect(DB_PATH)

# Check content_repo table
content_repo_df = pd.read_sql_query("""
    SELECT ud_source_file_id, raw_file_nme, raw_file_version_nbr,
           created_dt, last_modified_dt, file_status,
           extracted_markdown_file_path, title_nme
    FROM content_repo
    WHERE file_status = 'Active'
    ORDER BY raw_file_nme, raw_file_version_nbr
""", conn)

print(f"\n📊 CONTENT_REPO table:")
print(f"   Total active records: {len(content_repo_df)}")
print(f"\n   Records per file:")

for fname in sorted(content_repo_df['raw_file_nme'].unique()):
    file_records = content_repo_df[content_repo_df['raw_file_nme'] == fname]
    print(f"\n   {fname}:")
    for _, row in file_records.iterrows():
        print(f"      ID={row['ud_source_file_id']:3d} v{row['raw_file_version_nbr']} "
              f"created={row['created_dt']} modified={row['last_modified_dt']}")
        print(f"           Title: {row['title_nme']}")
        print(f"           Path:  {row['extracted_markdown_file_path']}")

print("\n" + "=" * 100)
print("PART 3: EXPECTED vs ACTUAL DATABASE STATE")
print("=" * 100)

print("\n🔍 CHECKING: What SHOULD be in content_repo after Notebook 0 + Notebook 3?")

print("\n   Expected after Notebook 0 (baseline load):")
print(f"      - 14 files from baseline CSV, all v1")

print("\n   Expected after Notebook 3 (edited load):")
print(f"      - Should KEEP v1 records (14 files)")
print(f"      - Should ADD v2 records for updated files (8 files)")
print(f"      - Should ADD new files (2 files: Workplace_Safety, Equipment_Return)")
print(f"      - Total expected: 14 (v1) + 8 (v2 updates) + 2 (new v1) = 24 records")

print(f"\n   ❗ ACTUAL in database: {len(content_repo_df)} records")

# Count by version
v1_count = len(content_repo_df[content_repo_df['raw_file_version_nbr'] == 1])
v2_count = len(content_repo_df[content_repo_df['raw_file_version_nbr'] == 2])
print(f"      v1 records: {v1_count}")
print(f"      v2 records: {v2_count}")

# Check for duplicates
duplicates = content_repo_df[content_repo_df.duplicated(subset=['raw_file_nme', 'raw_file_version_nbr'], keep=False)]
if len(duplicates) > 0:
    print(f"\n   ⚠️  DUPLICATE RECORDS FOUND:")
    for fname in duplicates['raw_file_nme'].unique():
        dups = duplicates[duplicates['raw_file_nme'] == fname]
        print(f"      {fname}: {len(dups)} records with same file+version")
        for _, row in dups.iterrows():
            print(f"         ID={row['ud_source_file_id']} v{row['raw_file_version_nbr']} "
                  f"created={row['created_dt']}")

print("\n" + "=" * 100)
print("PART 4: CHECKSUM TABLE ANALYSIS")
print("=" * 100)

checksums_df = pd.read_sql_query("""
    SELECT file_name, COUNT(*) as checksum_count,
           MIN(created_at) as first_created,
           MAX(created_at) as last_created
    FROM content_checksums
    WHERE status = 'active'
    GROUP BY file_name
    ORDER BY file_name
""", conn)

print(f"\n📊 CONTENT_CHECKSUMS table:")
print(f"   Files with checksums: {len(checksums_df)}")
print(f"\n   Checksums per file:")
print(checksums_df.to_string(index=False))

# Check timing
print("\n   ⏰ Checksum creation timeline:")
all_checksums = pd.read_sql_query("""
    SELECT created_at, COUNT(*) as count
    FROM content_checksums
    WHERE status = 'active'
    GROUP BY created_at
    ORDER BY created_at
""", conn)
print(all_checksums.to_string(index=False))

print("\n" + "=" * 100)
print("PART 5: CRITICAL ISSUES IDENTIFICATION")
print("=" * 100)

issues = []

# Issue 1: Check if v1 and v2 both exist for updated files
print("\n🔍 Checking for v1/v2 coexistence in content_repo...")
for fname in v2_files:
    file_records = content_repo_df[content_repo_df['raw_file_nme'] == fname]
    versions = sorted(file_records['raw_file_version_nbr'].unique())
    if 1 in versions and 2 in versions:
        issues.append(f"❌ {fname} has BOTH v1 and v2 in content_repo (should have only v2)")
        print(f"   ❌ {fname}: versions {versions} (BOTH present)")
    elif 2 in versions and 1 not in versions:
        print(f"   ✅ {fname}: only v2 present (correct)")
    elif 1 in versions and 2 not in versions:
        issues.append(f"❌ {fname} has only v1 (missing v2 update)")
        print(f"   ❌ {fname}: only v1 present (MISSING v2)")

# Issue 2: Check baseline checksums
print("\n🔍 Checking baseline checksums...")
baseline_time = "2025-10-27 09:44:56"  # First checksum creation time
baseline_checksums = pd.read_sql_query("""
    SELECT file_name, COUNT(*) as count
    FROM content_checksums
    WHERE status = 'active' AND created_at = ?
    GROUP BY file_name
""", conn, params=[baseline_time])

print(f"   Checksums created at baseline time ({baseline_time}):")
print(f"   Files: {len(baseline_checksums)}")
if len(baseline_checksums) != len(baseline_csv):
    issues.append(f"❌ Baseline checksums count mismatch: expected {len(baseline_csv)}, got {len(baseline_checksums)}")

# Issue 3: Check for contaminated baseline
print("\n🔍 Checking for baseline contamination...")
for fname in v2_files:
    file_checksums = pd.read_sql_query("""
        SELECT COUNT(*) as count, MIN(created_at) as first, MAX(created_at) as last
        FROM content_checksums
        WHERE file_name = ? AND status = 'active'
    """, conn, params=[fname])

    if file_checksums.iloc[0]['count'] > 1:
        # Has multiple checksum creation times
        issues.append(f"⚠️  {fname} has checksums from multiple ingestion runs (baseline contamination)")
        print(f"   ⚠️  {fname}: {file_checksums.iloc[0]['count']} checksums "
              f"from {file_checksums.iloc[0]['first']} to {file_checksums.iloc[0]['last']}")

conn.close()

print("\n" + "=" * 100)
print("SUMMARY OF ISSUES")
print("=" * 100)

if len(issues) == 0:
    print("\n✅ No critical issues found!")
else:
    print(f"\n❌ Found {len(issues)} critical issues:\n")
    for i, issue in enumerate(issues, 1):
        print(f"   {i}. {issue}")

print("\n" + "=" * 100)
