"""
Test script to demonstrate LLM-friendly diff integration in ContentChangeDetector.

This script shows how the llm_friendly_diff field is now automatically populated
for MODIFIED content during change detection.
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from granular_impact.detection.content_change_detector import ContentChangeDetector
from granular_impact.detection.checksum_extractor import ChecksumExtractor
from granular_impact.database.models import ChangeType
from datetime import datetime
import uuid


def main():
    print("=" * 80)
    print("LLM-Friendly Diff Integration Test")
    print("=" * 80)
    print()

    # Initialize detector WITH llm_diff computation enabled
    detector = ContentChangeDetector(
        checksum_algorithm="sha256",
        similarity_threshold=0.8,
        compute_llm_diffs=True,  # Enable LLM diffs
        diff_context_lines=1,     # Show 1 line of context
    )

    print("✅ ContentChangeDetector initialized with LLM diff computation")
    print(f"   Config: {detector.get_config()}")
    print()

    # Create test data
    checksum_extractor = ChecksumExtractor("sha256")

    # PREVIOUS VERSION (old content)
    previous_content = {
        "time_off": "# Time Off Policy\n\nEmployees are entitled to 10 sick days per year.",
        "remote_work": "# Remote Work\n\nEmployees may work remotely up to 2 days per week.",
        "benefits": "# Benefits\n\nFull-time employees receive health insurance coverage.",
    }

    # CURRENT VERSION (new content with modifications)
    current_content = {
        "time_off": "# Time Off Policy\n\nEmployees are entitled to 12 sick days per year.",
        "remote_work": "# Remote Work\n\nEmployees may work remotely up to 3 days per week.",
        "benefits": "# Benefits\n\nFull-time employees receive health insurance coverage.",  # Unchanged
    }

    # Build previous_checksums_data
    previous_checksums_data = {}
    for key, content in previous_content.items():
        checksum = checksum_extractor.compute_checksum(content)
        previous_checksums_data[checksum] = {
            "content_text": content,
            "file_name": "hr_handbook.pdf",
            "page_number": 1,
        }

    # Build current_checksums_data
    current_checksums_data = {}
    for key, content in current_content.items():
        checksum = checksum_extractor.compute_checksum(content)
        current_checksums_data[checksum] = {
            "text": content,
            "file_name": "hr_handbook.pdf",
            "page_num": 1,
            "markdown_path": f"./sample/{key}.md",
        }

    # Run detection
    detection_run_id = f"test_run_{uuid.uuid4().hex[:8]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    print("🔍 Running change detection...")
    print()

    changes = detector.detect_changes(
        file_name="hr_handbook.pdf",
        current_checksums_data=current_checksums_data,
        previous_checksums_data=previous_checksums_data,
        detection_run_id=detection_run_id,
    )

    print()
    print("=" * 80)
    print("RESULTS")
    print("=" * 80)
    print()

    # Categorize changes
    modified_changes = [c for c in changes if c.change_type == ChangeType.MODIFIED_CONTENT]
    unchanged_changes = [c for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT]

    print(f"📊 Summary:")
    print(f"   MODIFIED:  {len(modified_changes)}")
    print(f"   UNCHANGED: {len(unchanged_changes)}")
    print()

    # Show MODIFIED changes with LLM-friendly diffs
    if modified_changes:
        print("🔄 MODIFIED Content (with LLM-friendly diffs):")
        print()

        for i, change in enumerate(modified_changes, 1):
            print(f"Change #{i}:")
            print(f"  Old checksum: {change.old_checksum[:16]}...")
            print(f"  New checksum: {change.new_checksum[:16]}...")
            print(f"  Similarity:   {change.similarity_score:.3f}")
            print()

            if change.llm_friendly_diff:
                print("  LLM-Friendly Diff:")
                print("  " + "-" * 76)
                for line in change.llm_friendly_diff.split("\n"):
                    print(f"  {line}")
                print("  " + "-" * 76)
            else:
                print("  ⚠️  No diff computed (llm_friendly_diff is None)")

            print()

    # Show UNCHANGED content
    if unchanged_changes:
        print(f"✓ UNCHANGED Content: {len(unchanged_changes)} items (no diffs needed)")
        print()

    print("=" * 80)
    print("✅ Test Complete!")
    print()
    print("💡 Key Points:")
    print("   1. llm_friendly_diff is automatically computed for MODIFIED content")
    print("   2. The diff shows WHAT CHANGED in an LLM-readable format")
    print("   3. You can access it via: change.llm_friendly_diff")
    print("   4. Configure with: compute_llm_diffs=True/False, diff_context_lines=N")
    print("=" * 80)


if __name__ == "__main__":
    main()
