# FAQ Content Tracking System - Modular Architecture

## Overview

This directory contains a modular, well-organized implementation of the FAQ content tracking pipeline. The monolithic `production_pipeline.py` has been refactored into logical, maintainable modules.

## Directory Structure

```
src/
├── __init__.py                    # Main package initialization
├── content_diff.py                # Content diff processing (preserved from original)
│
├── core/                          # Core pipeline orchestration
│   ├── __init__.py
│   └── pipeline.py                # Main ContentTrackingPipeline class
│
├── detectors/                     # Change detection logic
│   ├── __init__.py
│   └── change_detector.py         # ChangeDetector class
│
├── processors/                    # Change processing
│   ├── __init__.py
│   ├── change_processor.py        # ChangeProcessor class
│   └── faq_mapper.py              # FAQMapper class
│
├── reporters/                     # Reporting and analytics
│   ├── __init__.py
│   └── impact_reporter.py         # ImpactReporter class
│
├── validators/                    # Validation logic
│   ├── __init__.py
│   └── content_validator.py       # ContentValidator class
│
└── utils/                         # Utility functions
    ├── __init__.py
    ├── checksum_utils.py          # Checksum calculation utilities
    ├── logging_config.py          # Logging configuration
    └── timestamp_utils.py         # Timestamp formatting utilities
```

## Module Responsibilities

### 1. Core Module (`core/`)

**`pipeline.py`** - Main orchestrator
- `ContentTrackingPipeline`: Main entry point for the system
- Coordinates all components
- Provides high-level API for daily processing
- Handles error management and logging

### 2. Detectors Module (`detectors/`)

**`change_detector.py`** - Change detection and classification
- `ChangeDetector`: Detects and classifies content changes
- Identifies: content edits, position changes, new content, deletions, structural changes
- Builds document state representations
- Performs checksum-based matching

### 3. Processors Module (`processors/`)

**`change_processor.py`** - Change recording
- `ChangeProcessor`: Records changes in tracking database
- Validates content IDs (cross-DB FK enforcement)
- Implements idempotent inserts (INSERT OR IGNORE)
- Handles proper time semantics (effective_date vs detected_at)

**`faq_mapper.py`** - FAQ mapping management
- `FAQMapper`: Updates FAQ content mappings
- Invalidates FAQs for content edits
- Relocates FAQs for position changes
- Provides FAQ query utilities

### 4. Reporters Module (`reporters/`)

**`impact_reporter.py`** - Impact analysis and reporting
- `ImpactReporter`: Generates impact reports
- Calculates severity levels
- Provides change timelines
- Generates human-readable reports

### 5. Validators Module (`validators/`)

**`content_validator.py`** - Data validation
- `ContentValidator`: Cross-database validation
- Validates content IDs (FK constraint enforcement)
- Retrieves content by checksum
- Validates file existence

### 6. Utils Module (`utils/`)

**`timestamp_utils.py`** - Timestamp handling
- `format_timestamp()`: ISO-8601 UTC formatting
- `parse_timestamp()`: Parse timestamp strings

**`checksum_utils.py`** - Checksum operations
- `calculate_file_checksum()`: SHA-256 file checksums
- `calculate_content_checksum()`: SHA-256 content checksums
- `verify_checksum()`: Checksum verification

**`logging_config.py`** - Logging setup
- `setup_logger()`: Configurable logger setup
- `setup_production_logger()`: Production defaults
- `setup_debug_logger()`: Debug configuration

## Usage Examples

### Basic Usage

```python
from src.core import ContentTrackingPipeline

# Initialize pipeline
pipeline = ContentTrackingPipeline(
    content_db='content_repo.db',
    tracking_db='version_tracking_new.db'
)

# Run daily processing
results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')

# Generate report
if results['status'] == 'success':
    report = pipeline.generate_report_text(results)
    print(report)
```

### Using Individual Components

```python
from src.detectors import ChangeDetector
from src.validators import ContentValidator
from src.utils import calculate_file_checksum

# Detect changes
detector = ChangeDetector('content.db', 'tracking.db')
changes = detector.detect_changes('2025-01-01T00:00:00Z')

# Validate content
validator = ContentValidator('content.db', 'tracking.db')
is_valid = validator.validate_content_id(123)

# Calculate checksum
checksum = calculate_file_checksum('/path/to/file.md')
```

### Command-Line Usage

```bash
# Run pipeline from command line
python -m src.core.pipeline "2025-01-01T00:00:00Z"

# With custom database paths
python -m src.core.pipeline "2025-01-01T00:00:00Z" content.db tracking.db
```

## Migration from production_pipeline.py

The original `production_pipeline.py` has been split as follows:

| Original Location | New Location |
|------------------|--------------|
| `ContentTrackingPipeline.__init__()` → | `core/pipeline.py` |
| `ContentTrackingPipeline._detect_changes()` → | `detectors/change_detector.py` |
| `ContentTrackingPipeline._process_changes()` → | `processors/change_processor.py` |
| `ContentTrackingPipeline._update_faq_mappings()` → | `processors/faq_mapper.py` |
| `ContentTrackingPipeline._generate_impact_report()` → | `reporters/impact_reporter.py` |
| `ContentTrackingPipeline.validate_content_id()` → | `validators/content_validator.py` |
| `ContentTrackingPipeline._calculate_file_checksum()` → | `utils/checksum_utils.py` |
| `ContentTrackingPipeline._setup_logging()` → | `utils/logging_config.py` |

### Backward Compatibility

The API remains the same. Code using the old `production_pipeline.py` can be updated with minimal changes:

```python
# Old code
from production_pipeline import ContentTrackingPipeline
pipeline = ContentTrackingPipeline('content.db', 'tracking.db')

# New code (same API)
from src.core import ContentTrackingPipeline
pipeline = ContentTrackingPipeline('content.db', 'tracking.db')
```

## Key Improvements

1. **Modularity**: Each component has a single, well-defined responsibility
2. **Testability**: Individual components can be tested in isolation
3. **Maintainability**: Changes to one component don't affect others
4. **Reusability**: Utilities and validators can be used independently
5. **Documentation**: Each module is self-documenting with clear APIs
6. **Type Safety**: Better type hints throughout
7. **Error Handling**: Consistent error handling patterns
8. **Logging**: Centralized, configurable logging

## Testing

Each module can be tested independently:

```python
# Test change detection
from src.detectors import ChangeDetector
detector = ChangeDetector('test_content.db', 'test_tracking.db')
changes = detector.detect_changes('2025-01-01T00:00:00Z')
assert 'content_edits' in changes

# Test validation
from src.validators import ContentValidator
validator = ContentValidator('test_content.db', 'test_tracking.db')
assert validator.validate_content_id(123) == True

# Test utilities
from src.utils import calculate_file_checksum
checksum = calculate_file_checksum('test_file.md')
assert len(checksum) == 64  # SHA-256 hex length
```

## Dependencies

- `sqlite3`: Database operations
- `pandas`: Data manipulation
- `hashlib`: Checksum calculation
- `logging`: Logging functionality
- `datetime`: Timestamp handling
- `difflib`: Content diff generation (in content_diff.py)
- `gzip`: Diff compression (in content_diff.py)

## Design Principles

1. **Single Responsibility**: Each class has one clear purpose
2. **Dependency Injection**: Components receive dependencies via constructor
3. **Cross-DB Validation**: Explicit FK validation for cross-database references
4. **Idempotency**: All change recording operations are idempotent
5. **Time Semantics**: Clear distinction between effective_date and detected_at
6. **Error Recovery**: Graceful handling of partial failures

## Future Enhancements

Potential areas for extension:

1. **Async Processing**: Add async/await support for concurrent operations
2. **Batch Processing**: Optimize for large-scale batch processing
3. **Caching**: Add caching layer for frequently accessed data
4. **Monitoring**: Enhanced metrics and monitoring hooks
5. **API Server**: REST API wrapper around the pipeline
6. **Testing Suite**: Comprehensive unit and integration tests

## Notes

- The original `content_diff.py` remains at the top level for compatibility
- All cross-database foreign key constraints are enforced in code
- Structural changes are derived from VIEWs, not explicitly stored
- The system maintains full backward compatibility with the original API
