# production_pipeline.py
import sqlite3
import pandas as pd
import hashlib
import json
import logging
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from content_diff import ContentDiffProcessor, EnhancedContentDiffProcessor

class ContentTrackingPipeline:
    """
    Production pipeline for content tracking with proper change classification.
    """
    
    def __init__(self, content_db: str, tracking_db: str):
        self.content_db = content_db
        self.tracking_db = tracking_db
        self.logger = self._setup_logging()
        
    def _setup_logging(self):
        """Configure logging for production use."""
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        
        # File handler with rotation
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler(
            'content_tracking.log',
            maxBytes=10485760,  # 10MB
            backupCount=5
        )
        file_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        )
        
        logger.addHandler(file_handler)
        return logger

    def validate_content_id(self, content_id: int) -> bool:
        """
        Validate content_id exists in content_repo.
        Required for cross-database foreign key enforcement.
        """
        with sqlite3.connect(self.content_db) as conn:
            result = conn.execute(
                "SELECT 1 FROM content_repo WHERE ud_source_file_id = ? LIMIT 1",
                (content_id,)
            ).fetchone()
            return result is not None

    def _record_change_idempotent(self, conn: sqlite3.Connection,
                                   change_type: str, change_data: dict):
        """
        Record change with idempotency guarantee (Fix 8).
        Uses INSERT OR IGNORE to handle duplicates gracefully.

        IMPORTANT: Proper time semantics:
        - effective_date = when change occurred in source (from last_modified_dt)
        - detected_at = when pipeline detected it (use format_timestamp(datetime.now()))
        """
        # Use INSERT OR IGNORE to handle duplicates gracefully
        query = """
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_content_id, previous_page_number,
                previous_checksum, change_trigger, effective_date, detected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        # Get current timestamp for detected_at (when we're detecting this NOW)
        detected_at_now = format_timestamp(datetime.now())

        cursor = conn.execute(query, (
            change_data['content_id'],
            change_data['file_name'],
            change_data['page_number'],
            change_data.get('checksum') or change_data.get('new_checksum'),
            change_type,
            change_data.get('previous_content_id'),
            change_data.get('previous_page_number') or change_data.get('from_page'),
            change_data.get('previous_checksum') or change_data.get('old_checksum'),
            change_data.get('change_trigger', 'automated'),
            change_data.get('effective_date', change_data.get('detected_at')),  # Prefer effective_date
            detected_at_now  # When pipeline is detecting it NOW
        ))

        # Check if insert was successful or ignored
        if cursor.rowcount == 0:
            self.logger.debug(
                f"Duplicate change ignored: {change_type} for "
                f"{change_data['file_name']} page {change_data['page_number']}"
            )
            return None

        change_id = cursor.lastrowid

        # If this is a deletion, invalidate affected FAQ mappings
        if change_type == 'page_deleted' and change_id:
            checksum = change_data.get('checksum') or change_data.get('previous_checksum')
            if checksum:
                conn.execute("""
                    UPDATE faq_content_map
                    SET is_valid = 0,
                        valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                        invalidation_reason = 'content_deleted',
                        invalidated_by_change_id = ?
                    WHERE content_checksum = ?
                      AND is_valid = 1
                """, (change_id, checksum))

        return change_id

    def _record_change_with_validation(self, conn: sqlite3.Connection, change_data: dict):
        """
        Record change with cross-DB validation.
        Validates content_id exists in content_repo before inserting.
        """
        # Validate FK constraint in code (since cross-DB FK not supported)
        if not self.validate_content_id(change_data['content_id']):
            raise ValueError(f"Invalid content_id: {change_data['content_id']}")

        # Proceed with insert
        conn.execute("""INSERT INTO content_change_log ...""", change_data)

    def process_daily_updates(self, since_date: str) -> Dict:
        """
        Main entry point for daily processing.
        
        Args:
            since_date: ISO format datetime to process changes since
            
        Returns:
            Dictionary with processing results and statistics
        """
        start_time = datetime.now()
        self.logger.info(f"Starting daily processing for changes since {since_date}")
        
        try:
            # 1. Load and analyze changes
            changes = self._detect_changes(since_date)
            
            # 2. Process changes
            processing_results = self._process_changes(changes)
            
            # 3. Update FAQ mappings
            faq_results = self._update_faq_mappings(changes)

            # 4. Process content diffs (NEW!)
            diff_processor = ContentDiffProcessor(self.content_db, self.tracking_db)
            diff_results = diff_processor.process_pending_diffs()
            self.logger.info(f"Generated {diff_results['diffs_generated']} diffs")
            
            # 4. Generate impact report
            impact_report = self._generate_impact_report(changes, faq_results, diff_results)
            
            # 5. Record run metadata
            self._record_run_metadata(
                since_date, 
                changes, 
                processing_results,
                start_time
            )
            
            self.logger.info("Daily processing completed successfully")
            
            return {
                'status': 'success',
                'changes': changes,
                'processing_results': processing_results,
                'faq_results': faq_results,
                'impact_report': impact_report,
                'execution_time': (datetime.now() - start_time).total_seconds()
            }
            
        except Exception as e:
            self.logger.error(f"Pipeline failed: {e}", exc_info=True)
            return {
                'status': 'failed',
                'error': str(e),
                'execution_time': (datetime.now() - start_time).total_seconds()
            }
    
    def _detect_changes(self, since_date: str) -> Dict:
        """
        Detect and classify all changes since given date.
        """
        # Load recent content
        with sqlite3.connect(self.content_db) as conn:
            recent_content = pd.read_sql("""
                SELECT * FROM content_repo
                WHERE last_modified_dt > ?
                ORDER BY raw_file_nme, last_modified_dt
            """, conn, params=[since_date])
        
        # Calculate checksums
        for idx, row in recent_content.iterrows():
            if pd.notna(row['extracted_markdown_file_path']):
                checksum = self._calculate_file_checksum(
                    row['extracted_markdown_file_path']
                )
                recent_content.at[idx, 'calculated_checksum'] = checksum
            else:
                recent_content.at[idx, 'calculated_checksum'] = None
        
        # Classify changes
        changes = {
            'content_edits': [],
            'position_changes': [],
            'new_content': [],
            'deletions': [],
            'structural_changes': []
        }
        
        # Group by file for analysis
        for file_name, file_group in recent_content.groupby('raw_file_nme'):
            file_changes = self._analyze_file_changes(file_name, file_group)
            
            # Merge results
            for change_type, items in file_changes.items():
                changes[change_type].extend(items)
        
        # Log summary
        total_changes = sum(len(v) for v in changes.values())
        self.logger.info(f"Detected {total_changes} total changes")
        for change_type, items in changes.items():
            if items:
                self.logger.info(f"  {change_type}: {len(items)}")
        
        return changes
    
    def _analyze_file_changes(self, file_name: str, content_df: pd.DataFrame) -> Dict:
        """
        Analyze changes for a single file.
        """
        changes = {
            'content_edits': [],
            'position_changes': [],
            'new_content': [],
            'deletions': [],
            'structural_changes': []
        }
        
        # Load current state from tracking database
        with sqlite3.connect(self.tracking_db) as conn:
            current_state = pd.read_sql("""
                WITH latest_changes AS (
                    SELECT
                        content_id,
                        page_number,
                        content_checksum,
                        change_type,
                        ROW_NUMBER() OVER (
                            PARTITION BY page_number
                            ORDER BY detected_at DESC, change_id DESC
                        ) as rn
                    FROM content_change_log
                    WHERE file_name = ?
                )
                SELECT content_id, page_number, content_checksum, change_type
                FROM latest_changes
                WHERE rn = 1 AND change_type != 'page_deleted'
            """, conn, params=[file_name])
        
        # Build lookup maps
        current_by_page = {
            row['page_number']: row 
            for _, row in current_state.iterrows()
        }
        current_by_checksum = {
            row['content_checksum']: row 
            for _, row in current_state.iterrows()
        }
        
        # Track seen checksums in this batch
        batch_seen = {}
        
        # Process each content item
        for _, row in content_df.iterrows():
            checksum = row['calculated_checksum']
            page_num = row['raw_file_page_nbr']
            content_id = row['ud_source_file_id']
            
            if not checksum:
                self.logger.warning(
                    f"Skipping {file_name} page {page_num}: "
                    f"no checksum available"
                )
                continue
            
            # Check if we've seen this checksum in batch
            if checksum in batch_seen:
                prev_page = batch_seen[checksum]['page_number']
                if prev_page != page_num:
                    # Same content, different page = position change
                    changes['position_changes'].append({
                        'content_id': content_id,
                        'checksum': checksum,
                        'from_page': prev_page,
                        'to_page': page_num,
                        'file_name': file_name,
                        'detected_at': row['last_modified_dt']
                    })
                continue
            
            # Check against current state
            if checksum in current_by_checksum:
                # Known content
                current = current_by_checksum[checksum]
                if current['page_number'] != page_num:
                    # Position change
                    changes['position_changes'].append({
                        'content_id': content_id,
                        'checksum': checksum,
                        'from_page': current['page_number'],
                        'to_page': page_num,
                        'file_name': file_name,
                        'detected_at': row['last_modified_dt']
                    })
            elif page_num in current_by_page:
                # Same page, different content = edit
                current = current_by_page[page_num]
                changes['content_edits'].append({
                    'content_id': content_id,
                    'page_number': page_num,
                    'old_checksum': current['content_checksum'],
                    'new_checksum': checksum,
                    'previous_content_id': current['content_id'],
                    'file_name': file_name,
                    'detected_at': row['last_modified_dt']
                })
            else:
                # New page
                changes['new_content'].append({
                    'content_id': content_id,
                    'page_number': page_num,
                    'checksum': checksum,
                    'file_name': file_name,
                    'detected_at': row['last_modified_dt']
                })
            
            # Update batch tracking
            batch_seen[checksum] = {
                'content_id': content_id,
                'page_number': page_num
            }
        
        # Detect structural changes
        if changes['new_content'] and changes['position_changes']:
            structural = self._detect_structural_changes(
                changes['new_content'],
                changes['position_changes']
            )
            changes['structural_changes'].extend(structural)

        # FIXED: Detect deletions - only if checksum is completely gone from new document
        # Build set of all checksums seen in new content
        new_checksums_set = {
            row['calculated_checksum']
            for _, row in content_df.iterrows()
            if row['calculated_checksum']
        }

        # Only pages whose checksums are completely gone are deletions
        for page_num, current in current_by_page.items():
            current_checksum = current['content_checksum']
            if current_checksum not in new_checksums_set:
                changes['deletions'].append({
                    'content_id': current['content_id'],
                    'page_number': page_num,
                    'checksum': current_checksum,
                    'file_name': file_name,
                    'detected_at': datetime.now().isoformat()
                })

        return changes
    
    def _detect_structural_changes(self, new_content: List, 
                                   position_changes: List) -> List:
        """
        Detect structural changes like page insertions.
        """
        structural = []
        
        for new_page in new_content:
            # Find all moves that could be caused by this insertion
            affected_moves = [
                m for m in position_changes
                if m['from_page'] >= new_page['page_number'] and
                   m['to_page'] > new_page['page_number']
            ]
            
            if affected_moves:
                structural.append({
                    'type': 'page_insertion',
                    'file_name': new_page['file_name'],
                    'inserted_at': new_page['page_number'],
                    'inserted_content_id': new_page['content_id'],
                    'cascading_moves': affected_moves,
                    'detected_at': new_page['detected_at']
                })
        
        return structural

    def _build_document_states(self, current_state: pd.DataFrame,
                               content_df: pd.DataFrame) -> Tuple[Dict, Dict]:
        """
        Build complete document state dictionaries for race-free analysis (Fix 9).
        Returns (old_data, new_data) with by_page and by_checksum indexes.
        """
        old_data = {'by_page': {}, 'by_checksum': {}}
        new_data = {'by_page': {}, 'by_checksum': {}}

        # Build old state indexes
        for _, row in current_state.iterrows():
            page = row['page_number']
            checksum = row['content_checksum']

            old_data['by_page'][page] = {
                'content_id': row['content_id'],
                'page_number': page,
                'checksum': checksum
            }

            if checksum not in old_data['by_checksum']:
                old_data['by_checksum'][checksum] = []
            old_data['by_checksum'][checksum].append(old_data['by_page'][page])

        # Build new state indexes
        for _, row in content_df.iterrows():
            page = row['raw_file_page_nbr']
            checksum = row.get('calculated_checksum')

            if not checksum:
                continue

            new_data['by_page'][page] = {
                'content_id': row['ud_source_file_id'],
                'page_number': page,
                'checksum': checksum,
                'effective_date': row.get('last_modified_dt', datetime.now().isoformat())
            }

            if checksum not in new_data['by_checksum']:
                new_data['by_checksum'][checksum] = []
            new_data['by_checksum'][checksum].append(new_data['by_page'][page])

        return old_data, new_data

    def _find_checksum_matches(self, old_data: Dict, new_data: Dict) -> List[Dict]:
        """
        Find all checksum matches between old and new states (Fix 9).
        Uses greedy nearest-neighbor matching for duplicates.
        """
        matches = []
        old_checksums = set(old_data['by_checksum'].keys())
        new_checksums = set(new_data['by_checksum'].keys())
        common_checksums = old_checksums & new_checksums

        for checksum in sorted(common_checksums):
            old_pages = sorted([p['page_number'] for p in old_data['by_checksum'][checksum]])
            new_pages = sorted([p['page_number'] for p in new_data['by_checksum'][checksum]])

            # Greedy nearest-neighbor matching
            i = j = 0
            while i < len(old_pages) and j < len(new_pages):
                old_page = old_pages[i]
                new_page = new_pages[j]

                # Look ahead for closer matches
                go_next_old = (i + 1 < len(old_pages) and
                              abs(old_pages[i + 1] - new_page) < abs(old_page - new_page))
                go_next_new = (j + 1 < len(new_pages) and
                              abs(old_page - new_pages[j + 1]) < abs(old_page - new_page))

                if go_next_old:
                    i += 1
                    continue
                if go_next_new:
                    j += 1
                    continue

                # Found a match
                old_info = old_data['by_page'][old_page]
                new_info = new_data['by_page'][new_page]

                matches.append({
                    'checksum': checksum,
                    'old_page': old_page,
                    'new_page': new_page,
                    'old_content_id': old_info['content_id'],
                    'new_content_id': new_info['content_id'],
                    'effective_date': new_info['effective_date']
                })

                i += 1
                j += 1

        return matches


    def _process_changes(self, changes: Dict) -> Dict:
        """
        Record all changes in tracking database.
        Note: Structural changes are no longer explicitly recorded - they are derived
        via v_document_structure_changes VIEW from position_change patterns.
        """
        results = {
            'content_edits_processed': 0,
            'position_changes_processed': 0,
            'new_content_processed': 0,
            'deletions_processed': 0,
            'errors': []
        }

        with sqlite3.connect(self.tracking_db) as conn:
            # Process content edits
            for edit in changes['content_edits']:
                try:
                    change_id = self._record_content_edit(conn, edit)
                    results['content_edits_processed'] += 1
                except Exception as e:
                    self.logger.error(f"Failed to process edit: {e}")
                    results['errors'].append({
                        'type': 'content_edit',
                        'data': edit,
                        'error': str(e)
                    })

            # Process position changes
            # These are automatically aggregated by v_document_structure_changes VIEW
            for move in changes['position_changes']:
                try:
                    self._record_position_change(conn, move)
                    results['position_changes_processed'] += 1
                except Exception as e:
                    self.logger.error(f"Failed to process move: {e}")
                    results['errors'].append({
                        'type': 'position_change',
                        'data': move,
                        'error': str(e)
                    })

            # Process new content
            for new in changes['new_content']:
                try:
                    self._record_new_content(conn, new)
                    results['new_content_processed'] += 1
                except Exception as e:
                    self.logger.error(f"Failed to process new content: {e}")
                    results['errors'].append({
                        'type': 'new_content',
                        'data': new,
                        'error': str(e)
                    })

            # Note: structural_changes are no longer explicitly processed
            # They are automatically derived from position_changes via the VIEW

            conn.commit()

        return results
    
    def _record_content_edit(self, conn: sqlite3.Connection, edit: Dict) -> int:
        """
        Record a content edit change with validation and idempotency (Fix 8).

        IMPORTANT: Proper time semantics:
        - effective_date = when edit occurred in source (from edit['effective_date'] or last_modified_dt)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB or explicitly here)
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validate_content_id(edit['content_id']):
            raise ValueError(f"Invalid content_id: {edit['content_id']}")

        # ENHANCED: Use INSERT OR IGNORE for idempotency
        # Note: detected_at will use DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')) from DDL
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_content_id, previous_checksum,
                change_trigger, effective_date
            ) VALUES (?, ?, ?, ?, 'content_edit', ?, ?, 'content_update', ?)
        """, (
            edit['content_id'], edit['file_name'], edit['page_number'],
            edit['new_checksum'], edit['previous_content_id'],
            edit['old_checksum'],
            edit.get('effective_date', edit.get('detected_at'))  # Use source timestamp
        ))

        if cursor.rowcount == 0:
            self.logger.debug(
                f"Duplicate edit ignored: {edit['file_name']} page {edit['page_number']}"
            )

        return cursor.lastrowid if cursor.rowcount > 0 else None
    
    def _record_position_change(self, conn: sqlite3.Connection, move: Dict):
        """
        Record a position change with validation and idempotency (Fix 8).

        IMPORTANT: Proper time semantics:
        - effective_date = when move occurred in source (from move['effective_date'] or last_modified_dt)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB)
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validate_content_id(move['content_id']):
            raise ValueError(f"Invalid content_id: {move['content_id']}")

        # ENHANCED: Use INSERT OR IGNORE for idempotency
        # Note: detected_at will use DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')) from DDL
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_page_number, change_trigger,
                effective_date
            ) VALUES (?, ?, ?, ?, 'position_change', ?, 'page_reorder', ?)
        """, (
            move['content_id'], move['file_name'], move['to_page'],
            move['checksum'], move['from_page'],
            move.get('effective_date', move.get('detected_at'))  # Use source timestamp
        ))

        if cursor.rowcount == 0:
            self.logger.debug(
                f"Duplicate move ignored: {move['file_name']} page {move['from_page']}->{move['to_page']}"
            )
    
    def _record_new_content(self, conn: sqlite3.Connection, new: Dict):
        """
        Record new content creation with validation and idempotency (Fix 8).

        IMPORTANT: Proper time semantics:
        - effective_date = when content was created in source (from new['effective_date'] or last_modified_dt)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB)
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validate_content_id(new['content_id']):
            raise ValueError(f"Invalid content_id: {new['content_id']}")

        # ENHANCED: Use INSERT OR IGNORE for idempotency
        # Note: detected_at will use DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')) from DDL
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, change_trigger, effective_date
            ) VALUES (?, ?, ?, ?, 'initial_creation', 'new_page', ?)
        """, (
            new['content_id'], new['file_name'], new['page_number'],
            new['checksum'],
            new.get('effective_date', new.get('detected_at'))  # Use source timestamp
        ))

        if cursor.rowcount == 0:
            self.logger.debug(
                f"Duplicate new content ignored: {new['file_name']} page {new['page_number']}"
            )
    
    # REMOVED: _record_structural_change method
    # Structural changes are now derived via v_document_structure_changes VIEW
    # No explicit recording needed - patterns are automatically detected from position_changes
    #
    # To query structural changes, use:
    #   SELECT * FROM v_document_structure_changes WHERE file_name = ?
    #
    # The VIEW automatically aggregates:
    # - Page insertions (3+ pages moving forward)
    # - Page deletions (3+ pages moving backward)
    # - Page reordering (complex movement patterns)
    
    def _update_faq_mappings(self, changes: Dict) -> Dict:
        """
        Update FAQ mappings based on detected changes.

        IMPORTANT: Cross-database FK validation for current_content_id
        Since faq_content_map.current_content_id references content_repo.ud_source_file_id
        across databases, SQLite cannot enforce this FK constraint. We validate in code:
        - During position changes: content_id comes from validated change records
        - During inserts (not shown here): call validate_content_id() before INSERT
        - See validate_content_id() method for FK validation implementation
        """
        results = {
            'faqs_invalidated': 0,
            'faqs_relocated': 0,
            'errors': []
        }

        with sqlite3.connect(self.tracking_db) as conn:
            # Invalidate FAQs for content edits
            for edit in changes['content_edits']:
                try:
                    # Use ISO-8601 format for valid_until timestamp
                    cursor = conn.execute("""
                        UPDATE faq_content_map
                        SET is_valid = 0,
                            valid_until = strftime('%Y-%m-%dT%H:%M:%SZ', 'now'),
                            invalidation_reason = 'content_edited',
                            invalidated_by_change_id = (
                                SELECT change_id FROM content_change_log
                                WHERE content_id = ?
                                ORDER BY change_id DESC LIMIT 1
                            )
                        WHERE content_checksum = ? AND is_valid = 1
                    """, (edit['content_id'], edit['old_checksum']))
                    
                    results['faqs_invalidated'] += cursor.rowcount
                    
                except Exception as e:
                    self.logger.error(f"Failed to invalidate FAQs: {e}")
                    results['errors'].append(str(e))
            
            # Update locations for position changes
            for move in changes['position_changes']:
                try:
                    cursor = conn.execute("""
                        UPDATE faq_content_map
                        SET current_page_number = ?,
                            current_content_id = ?
                        WHERE content_checksum = ? 
                          AND is_valid = 1
                          AND current_file_name = ?
                    """, (
                        move['to_page'], 
                        move['content_id'],
                        move['checksum'],
                        move['file_name']
                    ))
                    
                    results['faqs_relocated'] += cursor.rowcount
                    
                except Exception as e:
                    self.logger.error(f"Failed to relocate FAQs: {e}")
                    results['errors'].append(str(e))
            
            conn.commit()
        
        return results
    
    def _generate_impact_report(self, changes: Dict,
                               faq_results: Dict,
                               diff_results: Dict) -> Dict:
        """
        Generate impact report for the changes.
        Note: Structural changes are queried from v_document_structure_changes VIEW.
        """
        # Query structural changes from VIEW (derived, not stored)
        with sqlite3.connect(self.tracking_db) as conn:
            structural_count = pd.read_sql(
                "SELECT COUNT(*) as cnt FROM v_document_structure_changes",
                conn
            ).iloc[0]['cnt']

        report = {
            'summary': {
                'total_changes': (
                    len(changes['content_edits']) +
                    len(changes['position_changes']) +
                    len(changes['new_content']) +
                    len(changes['deletions'])
                ),
                'files_affected': len(set(
                    item.get('file_name')
                    for items in [changes['content_edits'], changes['position_changes'],
                                  changes['new_content'], changes['deletions']]
                    for item in items
                )),
                'faqs_impacted': (
                    faq_results['faqs_invalidated'] +
                    faq_results['faqs_relocated']
                )
            },
            'details': {
                'content_modifications': len(changes['content_edits']),
                'page_movements': len(changes['position_changes']),
                'new_pages': len(changes['new_content']),
                'deleted_pages': len(changes['deletions']),
                'structural_changes_detected': structural_count  # From VIEW
            },
            'faq_impact': {
                'invalidated': faq_results['faqs_invalidated'],
                'relocated': faq_results['faqs_relocated'],
                'errors': len(faq_results['errors'])
            },
            'diff_processing': {
                'diffs_generated': diff_results.get('diffs_generated', 0),
                'diffs_failed': diff_results.get('diffs_failed', 0),
                'errors': len(diff_results.get('errors', []))
            }
        }

        # Determine severity
        if report['summary']['faqs_impacted'] > 100:
            report['severity'] = 'high'
        elif report['summary']['faqs_impacted'] > 20:
            report['severity'] = 'medium'
        elif report['summary']['total_changes'] > 0:
            report['severity'] = 'low'
        else:
            report['severity'] = 'none'

        return report
    
    def _record_run_metadata(self, since_date: str, changes: Dict,
                            results: Dict, start_time: datetime):
        """Record metadata about this pipeline run."""
        with sqlite3.connect(self.tracking_db) as conn:
            # This would record to a pipeline_runs table
            # Implementation depends on specific monitoring needs
            pass
    
    def _calculate_file_checksum(self, file_path: str) -> Optional[str]:
        """Calculate SHA-256 checksum of file."""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        except Exception as e:
            self.logger.error(f"Failed to calculate checksum for {file_path}: {e}")
            return None
        
    def _get_content_by_checksum(self, checksum: str) -> Optional[str]:
        """Retrieve content text by checksum for diff generation."""
        with sqlite3.connect(self.content_db) as conn:
            result = conn.execute("""
                SELECT extracted_markdown_file_path
                FROM content_repo
                WHERE content_checksum = ?
                LIMIT 1
            """, (checksum,)).fetchone()

            if result and result[0]:
                try:
                    with open(result[0], 'r', encoding='utf-8') as f:
                        return f.read()
                except Exception as e:
                    self.logger.error(f"Failed to read content: {e}")
            return None
    
    def get_current_faqs_for_page(self, file_name: str, 
                                  page_number: int) -> pd.DataFrame:
        """
        Get all currently valid FAQs for a specific page.
        """
        with sqlite3.connect(self.tracking_db) as conn:
            query = """
                SELECT 
                    fcm.*,
                    fq.question_txt,
                    fa.faq_answer_txt
                FROM faq_content_map fcm
                JOIN faq_questions fq ON fcm.question_id = fq.question_id
                LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                WHERE fcm.current_file_name = ?
                  AND fcm.current_page_number = ?
                  AND fcm.is_valid = 1
                ORDER BY fcm.created_at
            """
            
            # Note: This assumes faq_questions and faq_answers are 
            # attached to the tracking database or accessible via views
            
            return pd.read_sql(query, conn, params=[file_name, page_number])


# Usage example
if __name__ == "__main__":
    pipeline = ContentTrackingPipeline(
        content_db='content_repo.db',
        tracking_db='version_tracking_new.db'
    )
    
    # Run daily processing
    results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')
    
    # Print impact report
    print("\nImpact Report:")
    print(json.dumps(results['impact_report'], indent=2))
    
    # Query FAQs for a specific page
    faqs = pipeline.get_current_faqs_for_page('Employee_Leave_Policy.pdf', 4)
    print(f"\nCurrent FAQs for page 4: {len(faqs)}")