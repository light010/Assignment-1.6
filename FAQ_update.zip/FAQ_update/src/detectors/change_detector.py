"""
Change Detector Module

Detects and classifies content changes including edits, position changes,
new content, deletions, and structural changes.
"""

import sqlite3
import pandas as pd
import logging
from datetime import datetime
from typing import Dict, List, Tuple, Optional

from utils.checksum_utils import calculate_file_checksum

logger = logging.getLogger(__name__)


class ChangeDetector:
    """Detects and classifies changes in content repository."""

    def __init__(self, content_db: str, tracking_db: str):
        """
        Initialize change detector.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database
        """
        self.content_db = content_db
        self.tracking_db = tracking_db

    def detect_changes(self, since_date: str) -> Dict[str, List]:
        """
        Detect and classify all changes since given date.

        Args:
            since_date: ISO format datetime to process changes since

        Returns:
            Dictionary containing categorized changes:
            - content_edits: Content modifications
            - position_changes: Page movements
            - new_content: New pages added
            - deletions: Pages removed
            - structural_changes: Page insertions and reorganizations

        Examples:
            >>> detector = ChangeDetector('content.db', 'tracking.db')
            >>> changes = detector.detect_changes('2025-01-01T00:00:00Z')
            >>> len(changes['content_edits'])
            5
        """
        # Load recent content (modified since date)
        with sqlite3.connect(self.content_db) as conn:
            recent_content = pd.read_sql("""
                SELECT * FROM content_repo
                WHERE last_modified_dt > ?
                ORDER BY raw_file_nme, last_modified_dt
            """, conn, params=[since_date])

        # Calculate checksums
        for idx, row in recent_content.iterrows():
            if pd.notna(row['extracted_markdown_file_path']):
                checksum = calculate_file_checksum(
                    row['extracted_markdown_file_path']
                )
                recent_content.at[idx, 'calculated_checksum'] = checksum
            else:
                recent_content.at[idx, 'calculated_checksum'] = None

        # Classify changes
        changes = {
            'content_edits': [],
            'position_changes': [],
            'new_content': [],
            'deletions': [],
            'structural_changes': []
        }

        # Group by file for analysis
        for file_name, file_group in recent_content.groupby('raw_file_nme'):
            file_changes = self._analyze_file_changes(file_name, file_group, since_date)

            # Merge results
            for change_type, items in file_changes.items():
                changes[change_type].extend(items)

        # Log summary
        total_changes = sum(len(v) for v in changes.values())
        logger.info(f"Detected {total_changes} total changes")
        for change_type, items in changes.items():
            if items:
                logger.info(f"  {change_type}: {len(items)}")

        return changes

    def _analyze_file_changes(self, file_name: str, content_df: pd.DataFrame,
                              since_date: str) -> Dict[str, List]:
        """
        Analyze changes for a single file using two-phase algorithm.

        Phase 1: Build complete document states (old and new)
        Phase 2: Compare states to classify changes correctly

        This avoids race conditions in sequential processing and correctly distinguishes
        between content edits (true modifications) and insertions (old content moved).

        Args:
            file_name: Name of the file being analyzed
            content_df: DataFrame containing file's content records (modified after since_date)
            since_date: ISO datetime to detect deletions properly

        Returns:
            Dictionary of categorized changes for this file
        """
        changes = {
            'content_edits': [],
            'position_changes': [],
            'new_content': [],
            'deletions': [],
            'structural_changes': []
        }

        # Load current state from tracking database
        current_state = self._load_current_state(file_name)

        # PHASE 1: Build complete document states
        old_state = self._build_document_state(current_state, 'old')
        new_state = self._build_document_state(content_df, 'new')

        # Track processed items to avoid duplicates
        processed_checksums = set()
        processed_pages = set()

        # PHASE 2A: Detect position changes (checksums that moved pages)
        for checksum, new_pages in new_state['by_checksum'].items():
            if checksum in old_state['by_checksum']:
                old_pages = old_state['by_checksum'][checksum]

                # For each occurrence in new state
                for new_page_info in new_pages:
                    new_page = new_page_info['page_number']

                    # Find matching old page (prefer exact match, then closest)
                    old_page_info = self._find_best_match(old_pages, new_page)

                    if old_page_info and old_page_info['page_number'] != new_page:
                        # Position change detected
                        changes['position_changes'].append({
                            'content_id': new_page_info['content_id'],
                            'checksum': checksum,
                            'from_page': old_page_info['page_number'],
                            'to_page': new_page,
                            'file_name': file_name,
                            'detected_at': new_page_info['detected_at']
                        })
                        processed_pages.add(new_page)
                        processed_checksums.add(checksum)

        # PHASE 2B: Detect content edits and new content
        for new_page, new_page_info in new_state['by_page'].items():
            if new_page in processed_pages:
                # Already processed as position change
                continue

            new_checksum = new_page_info['checksum']

            if new_checksum in processed_checksums:
                # Same checksum at same page (no change)
                continue

            if new_page in old_state['by_page']:
                # Page existed before
                old_page_info = old_state['by_page'][new_page]
                old_checksum = old_page_info['checksum']

                if old_checksum != new_checksum:
                    # Different content at same page
                    # Key question: Did old content move elsewhere?

                    if old_checksum in new_state['by_checksum']:
                        # Old content exists elsewhere in new state
                        # This is NEW CONTENT (insertion scenario)
                        changes['new_content'].append({
                            'content_id': new_page_info['content_id'],
                            'page_number': new_page,
                            'checksum': new_checksum,
                            'file_name': file_name,
                            'detected_at': new_page_info['detected_at']
                        })
                    else:
                        # Old content is gone completely
                        # This is CONTENT EDIT (true modification)
                        changes['content_edits'].append({
                            'content_id': new_page_info['content_id'],
                            'page_number': new_page,
                            'old_checksum': old_checksum,
                            'new_checksum': new_checksum,
                            'previous_content_id': old_page_info['content_id'],
                            'file_name': file_name,
                            'detected_at': new_page_info['detected_at']
                        })
            else:
                # Page didn't exist before - NEW CONTENT
                changes['new_content'].append({
                    'content_id': new_page_info['content_id'],
                    'page_number': new_page,
                    'checksum': new_checksum,
                    'file_name': file_name,
                    'detected_at': new_page_info['detected_at']
                })

        # PHASE 2C: Detect deletions
        # Load FULL current state of document (not just modified content)
        with sqlite3.connect(self.content_db) as conn:
            full_current_doc = pd.read_sql("""
                SELECT raw_file_page_nbr, content_checksum, ud_source_file_id
                FROM content_repo
                WHERE raw_file_nme = ? AND file_status = 'Active'
            """, conn, params=[file_name])

        # Build checksum set from full current document
        full_current_checksums = set(full_current_doc['content_checksum'])

        for old_page, old_page_info in old_state['by_page'].items():
            old_checksum = old_page_info['checksum']

            # Content is deleted if:
            # 1. Checksum not found in FULL current document
            # 2. Not just missing from modified records
            if old_checksum not in full_current_checksums:
                # Checksum gone completely from active content - TRUE DELETION
                changes['deletions'].append({
                    'content_id': old_page_info['content_id'],
                    'page_number': old_page,
                    'checksum': old_checksum,
                    'file_name': file_name,
                    'detected_at': datetime.now().isoformat()
                })
                logger.info(f"Deletion detected: {file_name} page {old_page}")

        # Detect structural changes
        if changes['new_content'] and changes['position_changes']:
            structural = self._detect_structural_changes(
                changes['new_content'],
                changes['position_changes']
            )
            changes['structural_changes'].extend(structural)

        return changes

    def _build_document_state(self, df: pd.DataFrame, state_type: str) -> Dict:
        """
        Build a complete document state from DataFrame.

        Creates indexed views for efficient lookup:
        - by_page: Maps page numbers to content info
        - by_checksum: Maps checksums to list of page info

        Args:
            df: DataFrame with content records
            state_type: 'old' or 'new' for appropriate field names

        Returns:
            Dictionary with by_page and by_checksum indexes
        """
        state = {
            'by_page': {},
            'by_checksum': {}
        }

        for _, row in df.iterrows():
            # Get appropriate field names based on state type
            if state_type == 'old':
                page = row['page_number']
                checksum = row['content_checksum']
                content_id = row['content_id']
                detected_at = None
            else:  # new
                page = row['raw_file_page_nbr']
                checksum = row.get('calculated_checksum')
                content_id = row['ud_source_file_id']
                detected_at = row.get('last_modified_dt', datetime.now().isoformat())

            if not checksum:
                continue

            page_info = {
                'content_id': content_id,
                'page_number': page,
                'checksum': checksum,
                'detected_at': detected_at
            }

            # Index by page (single entry per page)
            state['by_page'][page] = page_info

            # Index by checksum (multiple pages may have same checksum)
            if checksum not in state['by_checksum']:
                state['by_checksum'][checksum] = []
            state['by_checksum'][checksum].append(page_info)

        return state

    def _find_best_match(self, old_pages: List[Dict], new_page: int) -> Optional[Dict]:
        """
        Find the best matching old page for a new page number.

        Prefers exact page match, then closest page number.

        Args:
            old_pages: List of old page info dicts
            new_page: New page number to match

        Returns:
            Best matching old page info, or None
        """
        if not old_pages:
            return None

        # Try exact match first
        for old_page_info in old_pages:
            if old_page_info['page_number'] == new_page:
                return old_page_info

        # Find closest by page number
        closest = min(old_pages, key=lambda p: abs(p['page_number'] - new_page))
        return closest

    def _load_current_state(self, file_name: str) -> pd.DataFrame:
        """
        Load current state for a file from tracking database.

        Args:
            file_name: Name of the file

        Returns:
            DataFrame containing current state
        """
        with sqlite3.connect(self.tracking_db) as conn:
            current_state = pd.read_sql("""
                WITH latest_changes AS (
                    SELECT
                        content_id,
                        page_number,
                        content_checksum,
                        change_type,
                        ROW_NUMBER() OVER (
                            PARTITION BY page_number
                            ORDER BY detected_at DESC, change_id DESC
                        ) as rn
                    FROM content_change_log
                    WHERE file_name = ?
                )
                SELECT content_id, page_number, content_checksum, change_type
                FROM latest_changes
                WHERE rn = 1 AND change_type != 'page_deleted'
            """, conn, params=[file_name])

        return current_state

    def _detect_structural_changes(self, new_content: List[dict],
                                   position_changes: List[dict]) -> List[dict]:
        """
        Detect structural changes like page insertions.

        Args:
            new_content: List of new content items
            position_changes: List of position changes

        Returns:
            List of detected structural changes
        """
        structural = []

        for new_page in new_content:
            # Find all moves that could be caused by this insertion
            affected_moves = [
                m for m in position_changes
                if m['from_page'] >= new_page['page_number'] and
                   m['to_page'] > new_page['page_number']
            ]

            if affected_moves:
                structural.append({
                    'type': 'page_insertion',
                    'file_name': new_page['file_name'],
                    'inserted_at': new_page['page_number'],
                    'inserted_content_id': new_page['content_id'],
                    'cascading_moves': affected_moves,
                    'detected_at': new_page['detected_at']
                })

        return structural

    def build_document_states(self, current_state: pd.DataFrame,
                              content_df: pd.DataFrame) -> Tuple[Dict, Dict]:
        """
        Build complete document state dictionaries for race-free analysis.

        This method builds indexed views of old and new document states
        to enable accurate change detection without race conditions.

        Args:
            current_state: DataFrame with current tracked state
            content_df: DataFrame with new content

        Returns:
            Tuple of (old_data, new_data) dictionaries with:
            - by_page: Dict mapping page numbers to content info
            - by_checksum: Dict mapping checksums to list of content info

        Examples:
            >>> old_data, new_data = detector.build_document_states(current, new)
            >>> old_data['by_page'][5]
            {'content_id': 123, 'page_number': 5, 'checksum': 'abc...'}
        """
        old_data = {'by_page': {}, 'by_checksum': {}}
        new_data = {'by_page': {}, 'by_checksum': {}}

        # Build old state indexes
        for _, row in current_state.iterrows():
            page = row['page_number']
            checksum = row['content_checksum']

            old_data['by_page'][page] = {
                'content_id': row['content_id'],
                'page_number': page,
                'checksum': checksum
            }

            if checksum not in old_data['by_checksum']:
                old_data['by_checksum'][checksum] = []
            old_data['by_checksum'][checksum].append(old_data['by_page'][page])

        # Build new state indexes
        for _, row in content_df.iterrows():
            page = row['raw_file_page_nbr']
            checksum = row.get('calculated_checksum')

            if not checksum:
                continue

            new_data['by_page'][page] = {
                'content_id': row['ud_source_file_id'],
                'page_number': page,
                'checksum': checksum,
                'effective_date': row.get('last_modified_dt', datetime.now().isoformat())
            }

            if checksum not in new_data['by_checksum']:
                new_data['by_checksum'][checksum] = []
            new_data['by_checksum'][checksum].append(new_data['by_page'][page])

        return old_data, new_data

    def find_checksum_matches(self, old_data: Dict, new_data: Dict) -> List[Dict]:
        """
        Find all checksum matches between old and new states.

        Uses greedy nearest-neighbor matching for duplicate checksums.

        Args:
            old_data: Old document state from build_document_states()
            new_data: New document state from build_document_states()

        Returns:
            List of match dictionaries with old/new page mappings
        """
        matches = []
        old_checksums = set(old_data['by_checksum'].keys())
        new_checksums = set(new_data['by_checksum'].keys())
        common_checksums = old_checksums & new_checksums

        for checksum in sorted(common_checksums):
            old_pages = sorted([p['page_number'] for p in old_data['by_checksum'][checksum]])
            new_pages = sorted([p['page_number'] for p in new_data['by_checksum'][checksum]])

            # Greedy nearest-neighbor matching
            i = j = 0
            while i < len(old_pages) and j < len(new_pages):
                old_page = old_pages[i]
                new_page = new_pages[j]

                # Look ahead for closer matches
                go_next_old = (i + 1 < len(old_pages) and
                              abs(old_pages[i + 1] - new_page) < abs(old_page - new_page))
                go_next_new = (j + 1 < len(new_pages) and
                              abs(old_page - new_pages[j + 1]) < abs(old_page - new_page))

                if go_next_old:
                    i += 1
                    continue
                if go_next_new:
                    j += 1
                    continue

                # Found a match
                old_info = old_data['by_page'][old_page]
                new_info = new_data['by_page'][new_page]

                matches.append({
                    'checksum': checksum,
                    'old_page': old_page,
                    'new_page': new_page,
                    'old_content_id': old_info['content_id'],
                    'new_content_id': new_info['content_id'],
                    'effective_date': new_info['effective_date']
                })

                i += 1
                j += 1

        return matches
