"""
FAQ Regeneration Detector Module

Simplified change detection focused solely on determining whether FAQ regeneration
is needed for a content.

Key Question: "Is this checksum new?"
- If YES (checksum not in baseline) → REGENERATE FAQ
- If NO (checksum exists in baseline) → NO regeneration needed

This module handles the many-to-many relationship between checksums and questions and answers:
- One checksum can have multiple questions and answers.
- One question can be associated with multiple checksums
- One answer can also be associated with multiple checksums.

The detector only identifies WHICH checksums need regeneration. The FAQ generation
system separately decides HOW MANY FAQs to generate per checksum.

IMPORTANT DESIGN PRINCIPLES:
- Detection is checksum-centric within file scope (raw_file_nme)
- Baseline = Set of all checksums ever seen in a file's history
- Page number (raw_file_page_nbr) is metadata only - NOT used for detection
- content_id identifies the page entity but is NOT used for comparison
- Only checksum set membership determines regeneration need
"""

import sqlite3
import pandas as pd
import logging
from datetime import datetime
from typing import Dict, List, Optional, Set

from utils.checksum_utils import calculate_file_checksum

logger = logging.getLogger(__name__)


class FAQRegenerationDetector:
    """
    Detects which content changes require FAQ regeneration.

    This class provides a simplified detection mechanism focused on the
    business need: "Should we regenerate FAQ for this page?"

    Unlike the full ChangeDetector which categorizes changes into 5 types
    (edits, moves, new, deletions, structural), this detector has only
    2 categories: regenerate_faq and no_action_needed.
    """

    def __init__(self, content_db: str, tracking_db: str):
        """
        Initialize FAQ regeneration detector.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database (with content_change_log)

        Examples:
            >>> detector = FAQRegenerationDetector('content.db', 'tracking.db')
            >>> result = detector.detect('2025-01-01T00:00:00Z')
        """
        self.content_db = content_db
        self.tracking_db = tracking_db

    def detect(self, since_date: str, file_name: Optional[str] = None) -> Dict:
        """
        Detect which content changes require FAQ regeneration with comprehensive telemetry.

        Core Logic (Checksum-Centric):
        For each content_id with recent changes:
        1. Get its current checksum (from extracted_markdown_file_path)
        2. Compare to baseline = Set of all checksums ever seen in this file
        3. If checksum NOT in baseline → New content → REGENERATE FAQ
        4. If checksum IN baseline → Content reused → NO regeneration needed

        Args:
            since_date: ISO format datetime to process changes since
            file_name: Optional file name filter (process only this file)

        Returns:
            Dictionary with detection results and comprehensive telemetry:
            {
                'regenerate_faq': [
                    {
                        'content_id': int,
                        'file_name': str,
                        'checksum': str,
                        'last_modified_dt': str,
                        'metadata': {...},  # All content_repo fields
                        'existing_faq_count': int
                    },
                    ...
                ],
                'no_action_needed': [
                    # Same structure as regenerate_faq
                    ...
                ],
                'telemetry': {
                    # Detection metadata
                    'detection_timestamp': str,      # ISO-8601 when detection started
                    'since_date': str,               # Input parameter
                    'file_filter': Optional[str],    # Input parameter

                    # Timing metrics
                    'detection_started_at': str,     # ISO-8601
                    'detection_completed_at': str,   # ISO-8601
                    'detection_duration_seconds': float,

                    # Summary statistics
                    'total_pages_analyzed': int,
                    'pages_requiring_regeneration': int,
                    'pages_not_requiring_regeneration': int,
                    'faqs_to_invalidate': int,
                    'faqs_preserved': int,

                    # Operational metrics
                    'files_processed': int,
                    'pages_with_missing_checksums': int,
                    'pages_with_no_baseline': int,
                    'total_baseline_checksums_loaded': int,

                    # Per-file breakdown
                    'files_detail': [
                        {
                            'file_name': str,
                            'baseline_checksums_count': int,
                            'pages_analyzed': int,
                            'pages_requiring_regeneration': int,
                            'pages_not_requiring_regeneration': int,
                            'pages_with_missing_checksums': int,
                            'faqs_to_invalidate': int,
                            'faqs_preserved': int
                        },
                        ...
                    ],

                    # Warnings & issues
                    'warnings': [str, ...]
                }
            }

        Note:
            - Detection is purely based on checksum set membership
            - All telemetry is included in result - no need to call separate summary method
            - page is optional in metadata dict (may be None for single-page documents)
            - content_id identifies the page but is not used for comparison

        Examples:
            >>> detector = FAQRegenerationDetector('content.db', 'tracking.db')
            >>> result = detector.detect('2025-01-01T00:00:00Z')
            >>>
            >>> # Access detection results
            >>> print(f"Pages to regenerate: {len(result['regenerate_faq'])}")
            >>> print(f"Pages to skip: {len(result['no_action_needed'])}")
            >>>
            >>> # Access telemetry
            >>> telemetry = result['telemetry']
            >>> print(f"Detection took: {telemetry['detection_duration_seconds']:.2f}s")
            >>> print(f"FAQs preserved: {telemetry['faqs_preserved']}")
            >>> print(f"Files processed: {telemetry['files_processed']}")
            >>>
            >>> # Check for issues
            >>> if telemetry['warnings']:
            >>>     print(f"Warnings: {len(telemetry['warnings'])}")
            >>>     for warning in telemetry['warnings']:
            >>>         print(f"  - {warning}")
        """
        logger.info(f"Starting FAQ regeneration detection since {since_date}")

        # ============================================================
        # TELEMETRY INITIALIZATION
        # ============================================================
        start_time = datetime.now()
        telemetry = {
            # Detection metadata
            'detection_timestamp': start_time.isoformat(),
            'since_date': since_date,
            'file_filter': file_name,

            # Timing metrics (will be finalized at end)
            'detection_started_at': start_time.isoformat(),
            'detection_completed_at': None,
            'detection_duration_seconds': None,

            # Summary statistics (will be calculated at end)
            'total_pages_analyzed': 0,
            'pages_requiring_regeneration': 0,
            'pages_not_requiring_regeneration': 0,
            'faqs_to_invalidate': 0,
            'faqs_preserved': 0,

            # Operational metrics (will be aggregated during processing)
            'files_processed': 0,
            'pages_with_missing_checksums': 0,
            'pages_with_no_baseline': 0,
            'total_baseline_checksums_loaded': 0,

            # Per-file breakdown
            'files_detail': [],

            # Warnings & issues
            'warnings': []
        }

        # Load recent content (modified since date)
        with sqlite3.connect(self.content_db) as conn:
            if file_name:
                recent_content = pd.read_sql("""
                    SELECT * FROM content_repo
                    WHERE last_modified_dt > ? AND raw_file_nme = ?
                    ORDER BY raw_file_nme, raw_file_page_nbr
                """, conn, params=[since_date, file_name])
            else:
                recent_content = pd.read_sql("""
                    SELECT * FROM content_repo
                    WHERE last_modified_dt > ?
                    ORDER BY raw_file_nme, raw_file_page_nbr
                """, conn, params=[since_date])

        if recent_content.empty:
            logger.info("No content changes found since specified date")

            # Finalize telemetry for empty result
            end_time = datetime.now()
            telemetry['detection_completed_at'] = end_time.isoformat()
            telemetry['detection_duration_seconds'] = (end_time - start_time).total_seconds()

            return {
                'regenerate_faq': [],
                'no_action_needed': [],
                'telemetry': telemetry
            }

        # Calculate checksums for files that have markdown paths
        for idx, row in recent_content.iterrows():
            if pd.notna(row['extracted_markdown_file_path']):
                checksum = calculate_file_checksum(
                    row['extracted_markdown_file_path']
                )
                recent_content.at[idx, 'calculated_checksum'] = checksum
            else:
                recent_content.at[idx, 'calculated_checksum'] = None
                warning_msg = f"No markdown file for {row['raw_file_nme']} page {row['raw_file_page_nbr']}"
                logger.warning(warning_msg)
                telemetry['warnings'].append(warning_msg)

        # Initialize results
        results = {
            'regenerate_faq': [],
            'no_action_needed': []
        }

        # Process by file and aggregate metrics
        for file_name_group, file_group in recent_content.groupby('raw_file_nme'):
            file_results = self._analyze_file(file_name_group, file_group, since_date)

            # Aggregate detection results
            results['regenerate_faq'].extend(file_results['regenerate_faq'])
            results['no_action_needed'].extend(file_results['no_action_needed'])

            # Aggregate per-file metrics
            telemetry['files_detail'].append(file_results['metrics'])

            # Aggregate warnings
            telemetry['warnings'].extend(file_results['warnings'])

        # ============================================================
        # CALCULATE FINAL TELEMETRY METRICS
        # ============================================================

        # Summary statistics
        telemetry['total_pages_analyzed'] = len(results['regenerate_faq']) + len(results['no_action_needed'])
        telemetry['pages_requiring_regeneration'] = len(results['regenerate_faq'])
        telemetry['pages_not_requiring_regeneration'] = len(results['no_action_needed'])
        telemetry['faqs_to_invalidate'] = sum(
            item['existing_faq_count'] for item in results['regenerate_faq']
        )
        telemetry['faqs_preserved'] = sum(
            item['existing_faq_count'] for item in results['no_action_needed']
        )

        # Operational metrics (aggregate from per-file metrics)
        telemetry['files_processed'] = len(telemetry['files_detail'])
        telemetry['pages_with_missing_checksums'] = sum(
            f['pages_with_missing_checksums'] for f in telemetry['files_detail']
        )
        telemetry['pages_with_no_baseline'] = sum(
            f['pages_analyzed'] for f in telemetry['files_detail'] if f['baseline_checksums_count'] == 0
        )
        telemetry['total_baseline_checksums_loaded'] = sum(
            f['baseline_checksums_count'] for f in telemetry['files_detail']
        )

        # Finalize timing
        end_time = datetime.now()
        telemetry['detection_completed_at'] = end_time.isoformat()
        telemetry['detection_duration_seconds'] = (end_time - start_time).total_seconds()

        # Log summary
        logger.info("FAQ Regeneration Detection Summary:")
        logger.info(f"  Pages requiring FAQ regeneration: {telemetry['pages_requiring_regeneration']}")
        logger.info(f"  Pages not requiring regeneration: {telemetry['pages_not_requiring_regeneration']}")
        logger.info(f"  Total FAQs to regenerate: {telemetry['faqs_to_invalidate']}")
        logger.info(f"  Total FAQs preserved (no regeneration): {telemetry['faqs_preserved']}")
        logger.info(f"  Detection completed in {telemetry['detection_duration_seconds']:.2f}s")

        return {
            'regenerate_faq': results['regenerate_faq'],
            'no_action_needed': results['no_action_needed'],
            'telemetry': telemetry
        }

    def _build_metadata_dict(self, row: pd.Series) -> Dict:
        """
        Build metadata dictionary from content_repo row.

        Extracts all available fields from content_repo and places them in a
        flexible metadata structure. This allows downstream consumers to access
        any field they need without hardcoding specific fields in the detector.

        Args:
            row: Pandas Series containing content_repo fields

        Returns:
            Dictionary containing all non-core content_repo fields

        Note:
            - Uses .get() to handle missing fields gracefully
            - Returns None for missing values (allows downstream to check with .get())
            - Includes ALL content_repo fields for maximum flexibility
        """
        return {
            'page': row.get('raw_file_page_nbr'),  # May be None
            'domain': row.get('domain'),
            'service': row.get('service'),
            'orgoid': row.get('orgoid'),
            'associateoid': row.get('associateoid'),
            'raw_file_type': row.get('raw_file_type'),
            'raw_file_version_nbr': row.get('raw_file_version_nbr'),
            'source_url_txt': row.get('source_url_txt'),
            'parent_location_txt': row.get('parent_location_txt'),
            'raw_file_path': row.get('raw_file_path'),
            'extracted_markdown_file_path': row.get('extracted_markdown_file_path'),
            'extracted_layout_file_path': row.get('extracted_layout_file_path'),
            'title_nme': row.get('title_nme'),
            'breadcrumb_txt': row.get('breadcrumb_txt'),
            'content_tags_txt': row.get('content_tags_txt'),
            'version_nbr': row.get('version_nbr'),
            'file_status': row.get('file_status'),
            'created_dt': row.get('created_dt'),
        }

    def _analyze_file(self, file_name: str, content_df: pd.DataFrame, since_date: str) -> Dict:
        """
        Analyze FAQ regeneration needs for a single file.

        Core Logic:
        - Load baseline = Set of all checksums that existed BEFORE the since_date
        - For each content_id in recent changes:
            - If its checksum is IN baseline → No regeneration (content reused)
            - If its checksum is NOT IN baseline → Regenerate (new/modified content)

        Args:
            file_name: Name of the file being analyzed (raw_file_nme)
            content_df: DataFrame containing file's recent content records with calculated checksums
            since_date: ISO format datetime that defines the baseline cutoff

        Returns:
            Dictionary with:
                - regenerate_faq: List of pages requiring FAQ regeneration
                - no_action_needed: List of pages not requiring regeneration
                - metrics: Per-file telemetry metrics
                - warnings: List of warnings for this file

        Note:
            - page is optional in metadata (may be None for single-page documents)
            - content_id identifies the page entity but is not used for comparison
            - Only checksum set membership determines regeneration decision
            - All content_repo fields passed in metadata for downstream flexibility
        """
        results = {
            'regenerate_faq': [],
            'no_action_needed': []
        }

        # Initialize per-file metrics
        file_metrics = {
            'file_name': file_name,
            'baseline_checksums_count': 0,
            'pages_analyzed': 0,
            'pages_requiring_regeneration': 0,
            'pages_not_requiring_regeneration': 0,
            'pages_with_missing_checksums': 0,
            'faqs_to_invalidate': 0,
            'faqs_preserved': 0,
        }
        file_warnings = []

        # Load baseline checksums (all checksums that existed BEFORE the since_date)
        baseline_checksums = self._load_baseline_state(file_name, since_date)
        file_metrics['baseline_checksums_count'] = len(baseline_checksums)

        # If no baseline exists, everything is new (initial creation)
        if not baseline_checksums:
            warning_msg = f"No baseline found for {file_name} - treating as initial creation"
            logger.info(warning_msg)
            file_warnings.append(warning_msg)

            for _, row in content_df.iterrows():
                file_metrics['pages_analyzed'] += 1
                checksum = row.get('calculated_checksum')

                if checksum:
                    results['regenerate_faq'].append({
                        # CORE (mandatory)
                        'content_id': row['ud_source_file_id'],
                        'file_name': file_name,
                        'checksum': checksum,
                        'last_modified_dt': row['last_modified_dt'],
                        # METADATA (optional, flexible)
                        'metadata': self._build_metadata_dict(row),
                        # CALCULATED
                        'existing_faq_count': 0
                    })
                    file_metrics['pages_requiring_regeneration'] += 1
                else:
                    file_metrics['pages_with_missing_checksums'] += 1

            return {
                'regenerate_faq': results['regenerate_faq'],
                'no_action_needed': results['no_action_needed'],
                'metrics': file_metrics,
                'warnings': file_warnings
            }

        # Process each content_id with recent changes
        for _, row in content_df.iterrows():
            file_metrics['pages_analyzed'] += 1
            current_checksum = row.get('calculated_checksum')
            content_id = row['ud_source_file_id']

            if not current_checksum:
                warning_msg = f"Skipping {file_name} content_id {content_id}: no checksum"
                logger.warning(warning_msg)
                file_warnings.append(warning_msg)
                file_metrics['pages_with_missing_checksums'] += 1
                continue

            # THE KEY QUESTION: Is this checksum new to this file?
            if current_checksum in baseline_checksums:
                # Checksum already exists in this file's history → NO REGENERATION
                # (Content may have been reused, duplicated, or moved, but it's not new)

                # Count existing FAQs for this checksum
                faq_count = self._count_faqs_for_checksum(current_checksum)

                results['no_action_needed'].append({
                    # CORE (mandatory)
                    'content_id': content_id,
                    'file_name': file_name,
                    'checksum': current_checksum,
                    'last_modified_dt': row['last_modified_dt'],
                    # METADATA (optional, flexible)
                    'metadata': self._build_metadata_dict(row),
                    # CALCULATED
                    'existing_faq_count': faq_count
                })

                file_metrics['pages_not_requiring_regeneration'] += 1
                file_metrics['faqs_preserved'] += faq_count

                logger.debug(
                    f"No regeneration needed: {file_name} content_id {content_id} "
                    f"(checksum {current_checksum[:8]}... already exists in file, "
                    f"{faq_count} FAQs preserved)"
                )
            else:
                # Checksum is NEW to this file → REGENERATE FAQ
                # (Either truly new content or modified content)

                # Count FAQs that will be affected (though we don't track which specific
                # FAQ-to-checksum link is being replaced in this simplified model)
                faq_count = 0  # In simplified model, we don't know old checksum per content_id

                results['regenerate_faq'].append({
                    # CORE (mandatory)
                    'content_id': content_id,
                    'file_name': file_name,
                    'checksum': current_checksum,
                    'last_modified_dt': row['last_modified_dt'],
                    # METADATA (optional, flexible)
                    'metadata': self._build_metadata_dict(row),
                    # CALCULATED
                    'existing_faq_count': faq_count
                })

                file_metrics['pages_requiring_regeneration'] += 1
                file_metrics['faqs_to_invalidate'] += faq_count

                logger.info(
                    f"FAQ regeneration needed: {file_name} content_id {content_id} "
                    f"(checksum {current_checksum[:8]}... is new to this file)"
                )

        return {
            'regenerate_faq': results['regenerate_faq'],
            'no_action_needed': results['no_action_needed'],
            'metrics': file_metrics,
            'warnings': file_warnings
        }

    def _load_baseline_state(self, file_name: str, before_date: str) -> Set[str]:
        """
        Load baseline checksums for a file from content repository.

        Returns the set of all checksums that existed BEFORE the specified date.
        This is used to determine if a checksum is "new" (requires FAQ regeneration)
        or "already seen" (no regeneration needed).

        Args:
            file_name: Name of the file (raw_file_nme)
            before_date: ISO format datetime - only include checksums from content modified before this date

        Returns:
            Set of content checksums that existed before the cutoff date.
            Empty set if no history exists (indicates initial creation).

        Note:
            - Only checksums matter for detection, not page numbers or content_ids
            - A checksum in the baseline means "this content existed before the detection period"
            - Loads from content_repo (source of truth) not content_change_log
        """
        with sqlite3.connect(self.content_db) as conn:
            cursor = conn.execute("""
                SELECT DISTINCT content_checksum
                FROM content_repo
                WHERE raw_file_nme = ?
                  AND last_modified_dt <= ?
                  AND file_status = 'Active'
                  AND content_checksum IS NOT NULL
            """, (file_name, before_date))

            # Build set from query results
            baseline_checksums = {row[0] for row in cursor.fetchall()}

        return baseline_checksums

    def _count_faqs_for_checksum(self, checksum: str) -> int:
        """
        Count how many valid FAQs exist for a given checksum.

        This shows the many-to-many relationship: one checksum can have
        multiple FAQs (different questions about the same content).

        Args:
            checksum: Content checksum to look up

        Returns:
            Number of valid FAQ mappings for this checksum
        """
        with sqlite3.connect(self.tracking_db) as conn:
            count = conn.execute("""
                SELECT COUNT(*)
                FROM faq_content_map
                WHERE content_checksum = ? AND is_valid = 1
            """, (checksum,)).fetchone()[0]

        return count

    def get_faqs_to_invalidate(self, checksums: List[str]) -> pd.DataFrame:
        """
        Get all valid FAQs for given checksums.

        Useful when you need to know exactly which FAQs exist for specific checksums.

        Args:
            checksums: List of content checksums to look up

        Returns:
            DataFrame with FAQ details for the given checksums

        Examples:
            >>> result = detector.detect('2025-01-01T00:00:00Z')
            >>> # Get all checksums that need FAQ regeneration
            >>> checksums_to_regen = [item['checksum']
            ...                       for item in result['regenerate_faq']]
            >>> existing_faqs = detector.get_faqs_to_invalidate(checksums_to_regen)
            >>> print(f"Found {len(existing_faqs)} existing FAQs for these checksums")
        """
        if not checksums:
            return pd.DataFrame()

        with sqlite3.connect(self.tracking_db) as conn:
            placeholders = ','.join('?' * len(checksums))
            query = f"""
                SELECT
                    fcm.map_id,
                    fcm.question_id,
                    fcm.answer_id,
                    fcm.content_checksum,
                    fcm.current_file_name,
                    fcm.current_page_number,
                    fq.question_txt,
                    fa.faq_answer_txt
                FROM faq_content_map fcm
                JOIN faq_questions fq ON fcm.question_id = fq.question_id
                LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                WHERE fcm.content_checksum IN ({placeholders})
                  AND fcm.is_valid = 1
                ORDER BY fcm.content_checksum, fcm.map_id
            """
            return pd.read_sql(query, conn, params=checksums)

