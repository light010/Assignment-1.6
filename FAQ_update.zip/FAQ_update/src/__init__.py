"""
FAQ Content Tracking System

A modular pipeline for tracking content changes, managing FAQ mappings,
and generating impact reports.
"""

from .core import ContentTrackingPipeline
from .content_diff import ContentDiffProcessor, EnhancedContentDiffProcessor

__version__ = '1.0.0'

__all__ = [
    'ContentTrackingPipeline',
    'ContentDiffProcessor',
    'EnhancedContentDiffProcessor',
]
