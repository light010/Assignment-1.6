"""
Content Diff Processing Module

This module provides classes for generating and storing content diffs for FAQ content changes.
It includes basic diff generation with compression and advanced semantic markdown analysis.
"""

import difflib
import gzip
import json
import logging
import sqlite3
import pandas as pd
from datetime import datetime
from typing import Dict, Optional


class ContentDiffProcessor:
    """Generates and stores content diffs for content edits."""

    def __init__(self, content_db: str, tracking_db: str):
        self.content_db = content_db
        self.tracking_db = tracking_db
        self.logger = logging.getLogger(__name__)

    def process_pending_diffs(self, max_records: int = 100) -> Dict:
        """
        Find content edits without diffs and generate them.

        Works with both ChangeDetector (via content_change_log) and
        FAQRegenerationDetector (via direct checksum comparison).
        """
        results = {
            'diffs_generated': 0,
            'diffs_failed': 0,
            'errors': []
        }

        # Query for content_edits without diffs
        with sqlite3.connect(self.tracking_db) as conn:
            pending = pd.read_sql("""
                SELECT
                    ccl.change_id,
                    ccl.content_checksum as new_checksum,
                    ccl.previous_checksum as old_checksum
                FROM content_change_log ccl
                LEFT JOIN content_diffs cd ON ccl.change_id = cd.change_id
                WHERE ccl.change_type = 'content_edit'
                  AND cd.change_id IS NULL
                ORDER BY ccl.detected_at DESC
                LIMIT ?
            """, conn, params=[max_records])

            for _, row in pending.iterrows():
                try:
                    # Fetch content by checksum
                    old_content = self._get_content_by_checksum(row['old_checksum'])
                    new_content = self._get_content_by_checksum(row['new_checksum'])

                    if not old_content or not new_content:
                        self.logger.warning(f"Cannot generate diff for change {row['change_id']}: missing content")
                        continue

                    # Generate diff
                    start_time = datetime.now()
                    diff_data = self._generate_diff(
                        old_content, new_content,
                        row['old_checksum'], row['new_checksum']
                    )
                    processing_time = (datetime.now() - start_time).total_seconds() * 1000

                    # Store diff (with optional semantic_summary)
                    conn.execute("""
                        INSERT INTO content_diffs (
                            change_id, old_checksum, new_checksum,
                            unified_diff_gzip, similarity_score,
                            chars_added, chars_removed,
                            lines_added, lines_removed,
                            is_minor_change, semantic_summary, processing_time_ms
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        row['change_id'],
                        row['old_checksum'],
                        row['new_checksum'],
                        diff_data['unified_diff_gzip'],
                        diff_data['similarity_score'],
                        diff_data['chars_added'],
                        diff_data['chars_removed'],
                        diff_data['lines_added'],
                        diff_data['lines_removed'],
                        diff_data['is_minor_change'],
                        diff_data.get('semantic_summary'),  # Optional for EnhancedContentDiffProcessor
                        processing_time
                    ))

                    results['diffs_generated'] += 1

                except Exception as e:
                    self.logger.error(f"Failed to generate diff for change {row['change_id']}: {e}")
                    results['diffs_failed'] += 1
                    results['errors'].append(str(e))

            conn.commit()

        return results

    def _get_content_by_checksum(self, checksum: str) -> Optional[str]:
        """Retrieve content text by checksum."""
        with sqlite3.connect(self.content_db) as conn:
            result = conn.execute("""
                SELECT extracted_markdown_file_path
                FROM content_repo
                WHERE content_checksum = ?
                LIMIT 1
            """, (checksum,)).fetchone()

            if result and result[0]:
                try:
                    with open(result[0], 'r', encoding='utf-8') as f:
                        return f.read()
                except Exception as e:
                    self.logger.error(f"Failed to read content: {e}")
            return None

    def _generate_diff(self, old_content: str, new_content: str,
                      old_checksum: str, new_checksum: str) -> Dict:
        """Generate diff metrics and unified diff."""
        # Split into lines
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)

        # Generate unified diff
        diff_lines = list(difflib.unified_diff(
            old_lines, new_lines,
            fromfile='old_content',
            tofile='new_content',
            lineterm=''
        ))
        unified_diff = '\n'.join(diff_lines)

        # Compress diff
        unified_diff_gzip = gzip.compress(unified_diff.encode('utf-8'))

        # Calculate similarity
        matcher = difflib.SequenceMatcher(None, old_content, new_content)
        similarity_score = matcher.ratio()

        # Count changes
        chars_added = len(new_content) - len(old_content)
        chars_removed = abs(min(0, chars_added))
        chars_added = max(0, chars_added)

        lines_added = sum(1 for line in diff_lines if line.startswith('+') and not line.startswith('+++'))
        lines_removed = sum(1 for line in diff_lines if line.startswith('-') and not line.startswith('---'))

        # Determine if minor change (high similarity, few changes)
        is_minor_change = (
            similarity_score >= 0.9 and
            chars_added + chars_removed < 100 and
            lines_added + lines_removed < 5
        )

        return {
            'unified_diff_gzip': unified_diff_gzip,
            'similarity_score': similarity_score,
            'chars_added': chars_added,
            'chars_removed': chars_removed,
            'lines_added': lines_added,
            'lines_removed': lines_removed,
            'is_minor_change': 1 if is_minor_change else 0
        }


class EnhancedContentDiffProcessor(ContentDiffProcessor):
    """Adds semantic markdown analysis to diff processing."""

    def _generate_diff(self, old_content: str, new_content: str,
                      old_checksum: str, new_checksum: str) -> Dict:
        """Generate diff with semantic analysis."""
        # Get basic diff
        diff_data = super()._generate_diff(old_content, new_content, old_checksum, new_checksum)

        # Add semantic analysis
        try:
            semantic_summary = self._generate_semantic_diff(old_content, new_content)
            diff_data['semantic_summary'] = json.dumps(semantic_summary)
        except Exception as e:
            self.logger.error(f"Semantic diff failed: {e}")
            diff_data['semantic_summary'] = None

        return diff_data

    def _generate_semantic_diff(self, old_md: str, new_md: str) -> Dict:
        """Parse markdown structure and identify semantic changes."""
        import re

        def parse_markdown(text):
            """Simple markdown parser."""
            elements = {
                'headers': [],
                'paragraphs': [],
                'list_items': [],
                'links': []
            }

            lines = text.split('\n')
            for i, line in enumerate(lines):
                # Headers
                if line.startswith('#'):
                    level = len(line) - len(line.lstrip('#'))
                    title = line.lstrip('#').strip()
                    elements['headers'].append({'level': level, 'title': title, 'line': i})

                # List items
                elif line.strip().startswith(('-', '*', '+')):
                    item = line.strip()[1:].strip()
                    elements['list_items'].append({'text': item, 'line': i})

                # Paragraphs (simplified - non-empty, non-special lines)
                elif line.strip() and not line.startswith('>'):
                    elements['paragraphs'].append({'text': line.strip(), 'line': i})

                # Links (check all lines, not mutually exclusive with other elements)
                links = re.findall(r'\[([^\]]+)\]\(([^\)]+)\)', line)
                for text, url in links:
                    elements['links'].append({'text': text, 'url': url, 'line': i})

            return elements

        old_elements = parse_markdown(old_md)
        new_elements = parse_markdown(new_md)

        # Compare structures
        summary = []
        stats = {
            'headers_changed': 0,
            'paragraphs_changed': 0,
            'list_items_changed': 0,
            'links_changed': 0
        }

        # Compare headers
        old_headers = {h['title']: h for h in old_elements['headers']}
        new_headers = {h['title']: h for h in new_elements['headers']}

        for title in set(old_headers.keys()) - set(new_headers.keys()):
            summary.append(f"Removed Header: \"{title}\"")
            stats['headers_changed'] += 1

        for title in set(new_headers.keys()) - set(old_headers.keys()):
            summary.append(f"Added Header: \"{title}\"")
            stats['headers_changed'] += 1

        # Compare list items (simplified count comparison)
        if len(old_elements['list_items']) != len(new_elements['list_items']):
            diff_count = abs(len(new_elements['list_items']) - len(old_elements['list_items']))
            summary.append(f"List items changed: {diff_count} items added/removed")
            stats['list_items_changed'] = diff_count

        # Compare paragraphs (simplified count comparison)
        if len(old_elements['paragraphs']) != len(new_elements['paragraphs']):
            diff_count = abs(len(new_elements['paragraphs']) - len(old_elements['paragraphs']))
            summary.append(f"Paragraphs changed: {diff_count} paragraphs added/removed")
            stats['paragraphs_changed'] = diff_count

        # Compare links
        old_links = {(l['text'], l['url']) for l in old_elements['links']}
        new_links = {(l['text'], l['url']) for l in new_elements['links']}

        for text, url in (old_links - new_links):
            summary.append(f"Removed Link: \"{text}\" -> {url}")
            stats['links_changed'] += 1

        for text, url in (new_links - old_links):
            summary.append(f"Added Link: \"{text}\" -> {url}")
            stats['links_changed'] += 1

        return {
            'summary': summary[:20],  # Limit to top 20 changes
            'total_changes': len(summary),
            'stats': stats
        }