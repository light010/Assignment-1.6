"""
Content Validator Module

Provides content validation functions for cross-database foreign key enforcement
and data integrity checks.
"""

import sqlite3
import logging
from typing import Optional, List

logger = logging.getLogger(__name__)


class ContentValidator:
    """Validates content integrity across databases."""

    def __init__(self, content_db: str, tracking_db: str):
        """
        Initialize content validator.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database
        """
        self.content_db = content_db
        self.tracking_db = tracking_db

    def validate_content_id(self, content_id: int) -> bool:
        """
        Validate that content_id exists in content_repo.

        This is required for cross-database foreign key enforcement since
        SQLite does not support FK constraints across different database files.

        Args:
            content_id: Content ID to validate

        Returns:
            True if content_id exists, False otherwise

        Examples:
            >>> validator = ContentValidator('content.db', 'tracking.db')
            >>> validator.validate_content_id(123)
            True
        """
        try:
            with sqlite3.connect(self.content_db) as conn:
                result = conn.execute(
                    "SELECT 1 FROM content_repo WHERE ud_source_file_id = ? LIMIT 1",
                    (content_id,)
                ).fetchone()
                return result is not None
        except sqlite3.Error as e:
            logger.error(f"Database error validating content_id {content_id}: {e}")
            return False

    def validate_content_ids(self, content_ids: List[int]) -> dict:
        """
        Validate multiple content IDs in bulk.

        Args:
            content_ids: List of content IDs to validate

        Returns:
            Dictionary with 'valid' and 'invalid' lists

        Examples:
            >>> validator.validate_content_ids([123, 456, 789])
            {'valid': [123, 456], 'invalid': [789]}
        """
        valid = []
        invalid = []

        with sqlite3.connect(self.content_db) as conn:
            for content_id in content_ids:
                try:
                    result = conn.execute(
                        "SELECT 1 FROM content_repo WHERE ud_source_file_id = ? LIMIT 1",
                        (content_id,)
                    ).fetchone()

                    if result:
                        valid.append(content_id)
                    else:
                        invalid.append(content_id)
                except sqlite3.Error as e:
                    logger.error(f"Error validating content_id {content_id}: {e}")
                    invalid.append(content_id)

        return {'valid': valid, 'invalid': invalid}

    def validate_checksum_exists(self, checksum: str) -> bool:
        """
        Validate that a checksum exists in content_repo.

        Args:
            checksum: Content checksum to validate

        Returns:
            True if checksum exists, False otherwise
        """
        try:
            with sqlite3.connect(self.content_db) as conn:
                result = conn.execute(
                    "SELECT 1 FROM content_repo WHERE content_checksum = ? LIMIT 1",
                    (checksum,)
                ).fetchone()
                return result is not None
        except sqlite3.Error as e:
            logger.error(f"Database error validating checksum {checksum}: {e}")
            return False

    def get_content_by_checksum(self, checksum: str) -> Optional[str]:
        """
        Retrieve content text by checksum for diff generation.

        Args:
            checksum: Content checksum

        Returns:
            Content text as string, or None if not found

        Examples:
            >>> validator.get_content_by_checksum('abc123...')
            '# Document Content\nSome markdown text...'
        """
        try:
            with sqlite3.connect(self.content_db) as conn:
                result = conn.execute("""
                    SELECT extracted_markdown_file_path
                    FROM content_repo
                    WHERE content_checksum = ?
                    LIMIT 1
                """, (checksum,)).fetchone()

                if result and result[0]:
                    try:
                        with open(result[0], 'r', encoding='utf-8') as f:
                            return f.read()
                    except IOError as e:
                        logger.error(f"Failed to read content file {result[0]}: {e}")
                        return None
                return None
        except sqlite3.Error as e:
            logger.error(f"Database error retrieving content for checksum {checksum}: {e}")
            return None

    def validate_file_exists(self, file_name: str) -> bool:
        """
        Validate that a file exists in content_repo.

        Args:
            file_name: File name to validate

        Returns:
            True if file exists, False otherwise
        """
        try:
            with sqlite3.connect(self.content_db) as conn:
                result = conn.execute(
                    "SELECT 1 FROM content_repo WHERE raw_file_nme = ? LIMIT 1",
                    (file_name,)
                ).fetchone()
                return result is not None
        except sqlite3.Error as e:
            logger.error(f"Database error validating file {file_name}: {e}")
            return False
