"""
Human-Readable Diff Formatter

Generates LLM-ready, human-readable summaries of content changes
suitable for use in prompts and reports.
"""

import gzip
import sqlite3
from typing import Dict, List, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class DiffFormatter:
    """Formats content diffs into human-readable summaries for LLM consumption."""

    def __init__(self, content_db: str, tracking_db: str):
        self.content_db = content_db
        self.tracking_db = tracking_db

    def get_human_readable_summary(self, change_id: int) -> Optional[str]:
        """
        Generate a comprehensive human-readable summary for a single change.

        Args:
            change_id: ID of the change to summarize

        Returns:
            Human-readable markdown-formatted summary or None if not found
        """
        with sqlite3.connect(self.tracking_db) as conn:
            cursor = conn.cursor()

            # Get change details with diff
            cursor.execute("""
                SELECT
                    cd.change_id,
                    ccl.content_id,
                    ccl.file_name,
                    ccl.page_number,
                    cd.old_checksum,
                    cd.new_checksum,
                    cd.unified_diff_gzip,
                    cd.similarity_score,
                    cd.chars_added,
                    cd.chars_removed,
                    cd.lines_added,
                    cd.lines_removed,
                    cd.is_minor_change,
                    cd.semantic_summary,
                    ccl.change_type,
                    ccl.detected_at,
                    ccl.effective_date
                FROM content_diffs cd
                JOIN content_change_log ccl ON cd.change_id = ccl.change_id
                WHERE cd.change_id = ?
            """, (change_id,))

            row = cursor.fetchone()
            if not row:
                return None

            # Unpack data
            (change_id, content_id, file_name, page_number, old_checksum, new_checksum,
             unified_diff_gzip, similarity_score, chars_added, chars_removed,
             lines_added, lines_removed, is_minor_change, semantic_summary,
             change_type, detected_at, effective_date) = row

            # Decompress diff
            diff_text = gzip.decompress(unified_diff_gzip).decode('utf-8') if unified_diff_gzip else None

            # Build human-readable summary
            summary_parts = []

            # Header
            summary_parts.append("# Content Change Summary\n")
            summary_parts.append(f"**Change ID:** {change_id}\n")
            summary_parts.append(f"**Document:** {file_name}\n")
            summary_parts.append(f"**Page:** {page_number}\n")
            summary_parts.append(f"**Change Type:** {change_type.replace('_', ' ').title()}\n")
            summary_parts.append(f"**Detected:** {detected_at}\n")
            summary_parts.append("\n---\n\n")

            # Change Metrics
            summary_parts.append("## Change Metrics\n\n")
            summary_parts.append(f"- **Similarity to Original:** {similarity_score:.1%}\n")
            summary_parts.append(f"- **Content Added:** {chars_added} characters, {lines_added} lines\n")
            summary_parts.append(f"- **Content Removed:** {chars_removed} characters, {lines_removed} lines\n")
            summary_parts.append(f"- **Magnitude:** {'Minor' if is_minor_change else 'Significant'} change\n")

            if semantic_summary:
                summary_parts.append(f"- **Summary:** {semantic_summary}\n")

            summary_parts.append("\n")

            # Detailed Changes
            if diff_text:
                summary_parts.append("## Detailed Changes\n\n")
                summary_parts.append("```diff\n")
                summary_parts.append(diff_text)
                summary_parts.append("\n```\n\n")

            # Change Interpretation
            summary_parts.append("## Change Interpretation\n\n")
            summary_parts.append(self._interpret_changes(
                similarity_score, chars_added, chars_removed,
                lines_added, lines_removed, diff_text
            ))

            return ''.join(summary_parts)

    def get_batch_summary(self, since_date: Optional[str] = None,
                         file_name: Optional[str] = None,
                         max_changes: int = 50) -> str:
        """
        Generate a summary of all changes, suitable for LLM context.

        Args:
            since_date: Filter changes after this date (ISO format)
            file_name: Filter by specific file
            max_changes: Maximum number of changes to include

        Returns:
            Human-readable markdown summary of all changes
        """
        with sqlite3.connect(self.tracking_db) as conn:
            # Build query
            query = """
                SELECT
                    cd.change_id,
                    ccl.content_id,
                    ccl.file_name,
                    ccl.page_number,
                    cd.similarity_score,
                    cd.chars_added,
                    cd.chars_removed,
                    cd.lines_added,
                    cd.lines_removed,
                    cd.is_minor_change,
                    ccl.change_type,
                    ccl.detected_at
                FROM content_diffs cd
                JOIN content_change_log ccl ON cd.change_id = ccl.change_id
                WHERE 1=1
            """
            params = []

            if since_date:
                query += " AND ccl.detected_at > ?"
                params.append(since_date)

            if file_name:
                query += " AND ccl.file_name = ?"
                params.append(file_name)

            query += " ORDER BY ccl.detected_at DESC LIMIT ?"
            params.append(max_changes)

            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()

            if not rows:
                return "No content changes found matching the criteria."

            # Build summary
            parts = []
            parts.append("# Content Changes Summary\n\n")
            parts.append(f"**Total Changes:** {len(rows)}\n")

            if since_date:
                parts.append(f"**Since:** {since_date}\n")
            if file_name:
                parts.append(f"**File:** {file_name}\n")

            parts.append("\n---\n\n")

            # Group by file
            by_file: Dict[str, List] = {}
            for row in rows:
                file = row[2]
                if file not in by_file:
                    by_file[file] = []
                by_file[file].append(row)

            # Generate summary for each file
            for file, changes in by_file.items():
                parts.append(f"## {file}\n\n")
                parts.append(f"**{len(changes)} change(s) detected**\n\n")

                for row in changes:
                    (change_id, content_id, _, page_number, similarity_score,
                     chars_added, chars_removed, lines_added, lines_removed,
                     is_minor_change, change_type, detected_at) = row

                    magnitude = "minor" if is_minor_change else "significant"
                    change_desc = self._get_change_description(
                        similarity_score, chars_added, chars_removed,
                        lines_added, lines_removed
                    )

                    parts.append(f"### Page {page_number} - {change_type.replace('_', ' ').title()}\n\n")
                    parts.append(f"- **Change ID:** {change_id}\n")
                    parts.append(f"- **Magnitude:** {magnitude.title()}\n")
                    parts.append(f"- **Similarity:** {similarity_score:.1%}\n")
                    parts.append(f"- **Description:** {change_desc}\n")
                    parts.append(f"- **Detected:** {detected_at}\n")
                    parts.append("\n")

            return ''.join(parts)

    def get_llm_prompt_context(self, change_id: int) -> Optional[str]:
        """
        Generate LLM-optimized context for a specific change.
        Includes only the most relevant information for FAQ regeneration.

        Args:
            change_id: ID of the change

        Returns:
            Concise LLM-ready context string
        """
        with sqlite3.connect(self.tracking_db) as conn:
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    ccl.file_name,
                    ccl.page_number,
                    cd.unified_diff_gzip,
                    cd.similarity_score,
                    cd.chars_added,
                    cd.lines_added,
                    cd.is_minor_change
                FROM content_diffs cd
                JOIN content_change_log ccl ON cd.change_id = ccl.change_id
                WHERE cd.change_id = ?
            """, (change_id,))

            row = cursor.fetchone()
            if not row:
                return None

            file_name, page_number, unified_diff_gzip, similarity_score, chars_added, lines_added, is_minor_change = row

            # Decompress diff
            diff_text = gzip.decompress(unified_diff_gzip).decode('utf-8') if unified_diff_gzip else ""

            # Extract key changes from diff
            key_changes = self._extract_key_changes(diff_text)

            # Build concise context
            context_parts = [
                f"Document: {file_name}, Page {page_number}",
                f"Change magnitude: {'Minor' if is_minor_change else 'Significant'}",
                f"Content similarity: {similarity_score:.0%}",
                f"Changes: +{chars_added} chars, +{lines_added} lines",
                "",
                "Key modifications:",
            ]
            context_parts.extend(key_changes)

            return "\n".join(context_parts)

    def _interpret_changes(self, similarity_score: float, chars_added: int,
                          chars_removed: int, lines_added: int,
                          lines_removed: int, diff_text: Optional[str]) -> str:
        """Generate human interpretation of changes."""
        interpretation = []

        # Magnitude assessment
        if similarity_score > 0.9:
            interpretation.append("This is a **minor edit** with minimal changes to the original content.")
        elif similarity_score > 0.7:
            interpretation.append("This is a **moderate edit** with some substantive changes.")
        elif similarity_score > 0.4:
            interpretation.append("This is a **significant edit** with substantial modifications.")
        else:
            interpretation.append("This is a **major rewrite** with extensive changes to the original content.")

        # Net change assessment
        net_chars = chars_added - chars_removed
        net_lines = lines_added - lines_removed

        if net_chars > 0:
            interpretation.append(f"Content has **expanded** by approximately {net_chars} characters ({net_lines} lines).")
        elif net_chars < 0:
            interpretation.append(f"Content has **contracted** by approximately {abs(net_chars)} characters ({abs(net_lines)} lines).")
        else:
            interpretation.append("Content length remained approximately the same (replacements/edits).")

        # Extract key topics if possible
        if diff_text:
            added_topics = self._extract_topics(diff_text, added=True)
            removed_topics = self._extract_topics(diff_text, added=False)

            if added_topics:
                interpretation.append(f"\n**New topics/information added:** {', '.join(added_topics[:3])}")
            if removed_topics:
                interpretation.append(f"\n**Topics/information removed:** {', '.join(removed_topics[:3])}")

        return '\n\n'.join(interpretation) + "\n"

    def _get_change_description(self, similarity_score: float, chars_added: int,
                               chars_removed: int, lines_added: int,
                               lines_removed: int) -> str:
        """Generate brief change description."""
        if similarity_score > 0.9:
            return f"Minor edits (+{chars_added} chars, +{lines_added} lines)"
        elif similarity_score > 0.7:
            return f"Moderate changes (+{chars_added} chars, -{chars_removed} chars, net {lines_added - lines_removed:+d} lines)"
        elif similarity_score > 0.4:
            return f"Significant modifications (+{chars_added} chars, -{chars_removed} chars)"
        else:
            return f"Major rewrite ({similarity_score:.0%} similar, +{chars_added} chars)"

    def _extract_key_changes(self, diff_text: str) -> List[str]:
        """Extract key changes from diff for LLM context."""
        if not diff_text:
            return []

        changes = []
        lines = diff_text.split('\n')

        for line in lines:
            if line.startswith('+') and not line.startswith('+++'):
                # Added content
                content = line[1:].strip()
                if content and len(content) > 10:  # Ignore trivial additions
                    if content.startswith('#'):
                        changes.append(f"  • New section: {content}")
                    elif content.startswith('-'):
                        changes.append(f"  • New item: {content[:80]}")
                    elif '**' in content or 'NEW' in content.upper():
                        changes.append(f"  • Updated: {content[:80]}")
            elif line.startswith('-') and not line.startswith('---'):
                # Removed content (less important for FAQ generation)
                pass

        return changes[:10]  # Limit to top 10 changes

    def _extract_topics(self, diff_text: str, added: bool = True) -> List[str]:
        """Extract topic headings from diff."""
        if not diff_text:
            return []

        topics = []
        prefix = '+' if added else '-'
        lines = diff_text.split('\n')

        for line in lines:
            if line.startswith(prefix) and line.strip().startswith(prefix + '##'):
                # Extract markdown heading
                topic = line.lstrip(prefix).strip().lstrip('#').strip()
                if topic and topic not in topics:
                    topics.append(topic)

        return topics
