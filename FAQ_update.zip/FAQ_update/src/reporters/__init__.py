"""
Reporters Package

Provides impact reporting and analytics functionality.
"""

from .impact_reporter import ImpactReporter

__all__ = ['ImpactReporter']
