"""
Impact Reporter Module

Generates impact reports and analytics for content changes and FAQ updates.
"""

import sqlite3
import pandas as pd
import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class ImpactReporter:
    """Generates impact reports for content changes."""

    def __init__(self, tracking_db: str):
        """
        Initialize impact reporter.

        Args:
            tracking_db: Path to tracking database
        """
        self.tracking_db = tracking_db

    def generate_impact_report(self, changes: Dict[str, List],
                               faq_results: Dict,
                               diff_results: Dict = None) -> Dict:
        """
        Generate comprehensive impact report for changes.

        Note: Structural changes are queried from v_document_structure_changes VIEW.

        Args:
            changes: Dictionary of categorized changes from ChangeDetector
                    OR adapted from FAQRegenerationDetector
            faq_results: Results from FAQ mapping updates
            diff_results: Results from diff processing (optional, can be None)

        Returns:
            Comprehensive impact report dictionary

        Examples:
            >>> reporter = ImpactReporter('tracking.db')
            >>> # With ChangeDetector
            >>> report = reporter.generate_impact_report(changes, faq_results, diff_results)
            >>> # With FAQRegenerationDetector
            >>> from detectors.faq_to_changes_adapter import FAQToChangesAdapter
            >>> adapted = FAQToChangesAdapter.adapt(faq_regen_result)
            >>> report = reporter.generate_impact_report(adapted, faq_results, None)
            >>> report['severity']
            'medium'
        """
        # Handle None diff_results
        if diff_results is None:
            diff_results = {'diffs_generated': 0, 'diffs_failed': 0, 'errors': []}
        # Query structural changes from VIEW (derived, not stored)
        with sqlite3.connect(self.tracking_db) as conn:
            structural_count = pd.read_sql(
                "SELECT COUNT(*) as cnt FROM v_document_structure_changes",
                conn
            ).iloc[0]['cnt']

        # Get unique files affected
        files_affected = set()
        for items in [changes['content_edits'], changes['position_changes'],
                      changes['new_content'], changes['deletions']]:
            for item in items:
                file_name = item.get('file_name')
                if file_name:
                    files_affected.add(file_name)

        report = {
            'summary': {
                'total_changes': (
                    len(changes['content_edits']) +
                    len(changes['position_changes']) +
                    len(changes['new_content']) +
                    len(changes['deletions'])
                ),
                'files_affected': len(files_affected),
                'faqs_impacted': (
                    faq_results['faqs_invalidated'] +
                    faq_results['faqs_relocated']
                )
            },
            'details': {
                'content_modifications': len(changes['content_edits']),
                'page_movements': len(changes['position_changes']),
                'new_pages': len(changes['new_content']),
                'deleted_pages': len(changes['deletions']),
                'structural_changes_detected': structural_count
            },
            'faq_impact': {
                'invalidated': faq_results['faqs_invalidated'],
                'relocated': faq_results['faqs_relocated'],
                'errors': len(faq_results['errors'])
            },
            'diff_processing': {
                'diffs_generated': diff_results.get('diffs_generated', 0),
                'diffs_failed': diff_results.get('diffs_failed', 0),
                'errors': len(diff_results.get('errors', []))
            }
        }

        # Determine severity
        report['severity'] = self._calculate_severity(report)

        # Add file-level breakdown
        report['files'] = self._generate_file_breakdown(changes)

        return report

    def _calculate_severity(self, report: Dict) -> str:
        """
        Calculate severity level based on impact metrics.

        Args:
            report: Impact report dictionary

        Returns:
            Severity level: 'critical', 'high', 'medium', 'low', or 'none'
        """
        faqs_impacted = report['summary']['faqs_impacted']
        total_changes = report['summary']['total_changes']
        deleted_pages = report['details']['deleted_pages']

        if deleted_pages > 10 or faqs_impacted > 500:
            return 'critical'
        elif faqs_impacted > 100 or deleted_pages > 5:
            return 'high'
        elif faqs_impacted > 20 or total_changes > 50:
            return 'medium'
        elif total_changes > 0:
            return 'low'
        else:
            return 'none'

    def _generate_file_breakdown(self, changes: Dict[str, List]) -> List[Dict]:
        """
        Generate per-file breakdown of changes.

        Args:
            changes: Dictionary of categorized changes

        Returns:
            List of file-level change summaries
        """
        file_stats = {}

        # Aggregate changes by file
        for change_type, items in changes.items():
            for item in items:
                file_name = item.get('file_name')
                if not file_name:
                    continue

                if file_name not in file_stats:
                    file_stats[file_name] = {
                        'file_name': file_name,
                        'content_edits': 0,
                        'position_changes': 0,
                        'new_content': 0,
                        'deletions': 0,
                        'structural_changes': 0
                    }

                file_stats[file_name][change_type] += 1

        return list(file_stats.values())

    def get_change_timeline(self, file_name: Optional[str] = None,
                           since_date: Optional[str] = None,
                           limit: int = 100) -> pd.DataFrame:
        """
        Get chronological timeline of changes.

        Args:
            file_name: Optional file name filter
            since_date: Optional ISO format datetime filter
            limit: Maximum number of records to return

        Returns:
            DataFrame with change timeline

        Examples:
            >>> reporter = ImpactReporter('tracking.db')
            >>> timeline = reporter.get_change_timeline(file_name='policy.pdf')
            >>> len(timeline)
            25
        """
        with sqlite3.connect(self.tracking_db) as conn:
            query = """
                SELECT
                    change_id,
                    content_id,
                    file_name,
                    page_number,
                    change_type,
                    effective_date,
                    detected_at,
                    change_trigger
                FROM content_change_log
                WHERE 1=1
            """
            params = []

            if file_name:
                query += " AND file_name = ?"
                params.append(file_name)

            if since_date:
                query += " AND detected_at > ?"
                params.append(since_date)

            query += " ORDER BY detected_at DESC LIMIT ?"
            params.append(limit)

            return pd.read_sql(query, conn, params=params)

    def get_faq_impact_summary(self, since_date: Optional[str] = None) -> Dict:
        """
        Get summary of FAQ impact metrics.

        Args:
            since_date: Optional ISO format datetime filter

        Returns:
            Dictionary with FAQ impact statistics
        """
        with sqlite3.connect(self.tracking_db) as conn:
            if since_date:
                invalidated = pd.read_sql("""
                    SELECT COUNT(*) as cnt
                    FROM faq_content_map
                    WHERE is_valid = 0 AND valid_until > ?
                """, conn, params=[since_date]).iloc[0]['cnt']

                relocated = pd.read_sql("""
                    SELECT COUNT(DISTINCT fcm.question_id) as cnt
                    FROM faq_content_map fcm
                    JOIN content_change_log ccl ON fcm.current_content_id = ccl.content_id
                    WHERE ccl.change_type = 'position_change'
                      AND ccl.detected_at > ?
                      AND fcm.is_valid = 1
                """, conn, params=[since_date]).iloc[0]['cnt']
            else:
                invalidated = pd.read_sql("""
                    SELECT COUNT(*) as cnt
                    FROM faq_content_map
                    WHERE is_valid = 0
                """, conn).iloc[0]['cnt']

                relocated = pd.read_sql("""
                    SELECT COUNT(DISTINCT fcm.question_id) as cnt
                    FROM faq_content_map fcm
                    JOIN content_change_log ccl ON fcm.current_content_id = ccl.content_id
                    WHERE ccl.change_type = 'position_change'
                      AND fcm.is_valid = 1
                """, conn).iloc[0]['cnt']

            active = pd.read_sql("""
                SELECT COUNT(*) as cnt
                FROM faq_content_map
                WHERE is_valid = 1
            """, conn).iloc[0]['cnt']

        return {
            'active_faqs': active,
            'invalidated_faqs': invalidated,
            'relocated_faqs': relocated,
            'invalidation_rate': (invalidated / (active + invalidated) * 100) if (active + invalidated) > 0 else 0
        }

    def get_structural_changes_summary(self, file_name: Optional[str] = None) -> pd.DataFrame:
        """
        Get summary of structural changes from VIEW.

        Args:
            file_name: Optional file name filter

        Returns:
            DataFrame with structural change information
        """
        with sqlite3.connect(self.tracking_db) as conn:
            if file_name:
                query = """
                    SELECT * FROM v_document_structure_changes
                    WHERE file_name = ?
                    ORDER BY detected_at DESC
                """
                params = [file_name]
            else:
                query = """
                    SELECT * FROM v_document_structure_changes
                    ORDER BY detected_at DESC
                """
                params = []

            return pd.read_sql(query, conn, params=params)

    def generate_change_report_text(self, report: Dict) -> str:
        """
        Generate human-readable text report.

        Args:
            report: Impact report dictionary from generate_impact_report()

        Returns:
            Formatted text report
        """
        lines = [
            "=" * 60,
            "CONTENT CHANGE IMPACT REPORT",
            "=" * 60,
            "",
            f"Severity: {report['severity'].upper()}",
            "",
            "SUMMARY:",
            f"  Total Changes: {report['summary']['total_changes']}",
            f"  Files Affected: {report['summary']['files_affected']}",
            f"  FAQs Impacted: {report['summary']['faqs_impacted']}",
            "",
            "CHANGE DETAILS:",
            f"  Content Modifications: {report['details']['content_modifications']}",
            f"  Page Movements: {report['details']['page_movements']}",
            f"  New Pages: {report['details']['new_pages']}",
            f"  Deleted Pages: {report['details']['deleted_pages']}",
            f"  Structural Changes: {report['details']['structural_changes_detected']}",
            "",
            "FAQ IMPACT:",
            f"  Invalidated: {report['faq_impact']['invalidated']}",
            f"  Relocated: {report['faq_impact']['relocated']}",
            f"  Errors: {report['faq_impact']['errors']}",
            "",
            "DIFF PROCESSING:",
            f"  Diffs Generated: {report['diff_processing']['diffs_generated']}",
            f"  Failed: {report['diff_processing']['diffs_failed']}",
            ""
        ]

        if report.get('files'):
            lines.extend([
                "FILE BREAKDOWN:",
                ""
            ])
            for file_stat in report['files']:
                lines.append(f"  {file_stat['file_name']}:")
                lines.append(f"    Edits: {file_stat['content_edits']}, "
                           f"Moves: {file_stat['position_changes']}, "
                           f"New: {file_stat['new_content']}, "
                           f"Deleted: {file_stat['deletions']}")
                lines.append("")

        lines.append("=" * 60)

        return "\n".join(lines)
