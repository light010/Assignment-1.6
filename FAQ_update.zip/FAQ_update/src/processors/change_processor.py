"""
Change Processor Module

Contains two classes:
1. ChangeLogger - NEW simplified class for checksum-centric architecture (USE THIS)
2. ChangeProcessor - DEPRECATED legacy class (for backward compatibility only)

ChangeLogger logs FAQ regeneration detection results using the simplified
schema with binary decision model (requires_faq_regeneration) and JSON metadata.

ChangeProcessor is deprecated and will be removed in future versions.
It used complex change_type classification which has been replaced.

Migration Guide:
    OLD (ChangeProcessor):
        processor = ChangeProcessor(content_db, tracking_db)
        processor.process_changes(changes)

    NEW (ChangeLogger):
        logger = ChangeLogger(db_path='faq_update.db')
        logger.log_detection_results(detection_result)
"""

import sqlite3
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path

from utils.timestamp_utils import format_timestamp
from validators.content_validator import ContentValidator

logger = logging.getLogger(__name__)


# ============================================================================
# ChangeLogger - NEW SIMPLIFIED CLASS (USE THIS)
# ============================================================================

class ChangeLogger:
    """
    Logs FAQ regeneration detection results to content_change_log table.

    This class handles persistence of detection results from FAQRegenerationDetector,
    storing them in the simplified checksum-centric schema.

    Key Design Principles:
        1. Checksum-centric: Checksum is the primary identity for FAQ mapping
        2. Binary decision: requires_faq_regeneration (0=reuse, 1=regenerate)
        3. JSON metadata: All descriptive fields stored flexibly
        4. Idempotency: Safe to re-run detection for same period
        5. Batch tracking: Groups detections by run_id for analytics

    Attributes:
        db_path (str): Path to the unified faq_update.db database

    Example:
        >>> # Initialize logger
        >>> logger = ChangeLogger(db_path='databases/faq_update.db')
        >>>
        >>> # Get detection results from detector
        >>> detector = FAQRegenerationDetector(
        ...     content_db='content.db',
        ...     baseline_db='baseline.db'
        ... )
        >>> result = detector.detect(since_date='2024-01-01')
        >>>
        >>> # Log results to database
        >>> log_result = logger.log_detection_results(result)
        >>>
        >>> # Check results
        >>> print(f"Records inserted: {log_result['records_inserted']}")
        >>> print(f"Duplicates skipped: {log_result['duplicates_skipped']}")
    """

    def __init__(self, db_path: str):
        """
        Initialize ChangeLogger with database connection.

        Args:
            db_path: Path to the unified faq_update.db database

        Raises:
            FileNotFoundError: If database file doesn't exist
            sqlite3.Error: If database connection fails
        """
        self.db_path = str(Path(db_path).resolve())

        # Verify database exists
        if not Path(self.db_path).exists():
            raise FileNotFoundError(f"Database not found: {self.db_path}")

        # Test connection and verify schema
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("PRAGMA foreign_keys = ON")

                # Verify content_change_log table exists
                cursor = conn.execute("""
                    SELECT name FROM sqlite_master
                    WHERE type='table' AND name='content_change_log'
                """)
                if not cursor.fetchone():
                    raise ValueError(
                        f"content_change_log table not found in {self.db_path}. "
                        f"Please run create_schema_v4.sql first."
                    )

                logger.info(f"ChangeLogger initialized with database: {self.db_path}")
        except sqlite3.Error as e:
            raise sqlite3.Error(f"Failed to connect to database {self.db_path}: {e}")

    def log_detection_results(
        self,
        detection_result: Dict[str, Any],
        detection_run_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Log FAQ regeneration detection results to content_change_log table.

        Args:
            detection_result: Results from FAQRegenerationDetector.detect()
            detection_run_id: Optional run identifier (defaults to detection_timestamp)

        Returns:
            Dictionary with logging results

        Raises:
            ValueError: If detection_result missing required fields
        """
        # Validate structure
        if 'regenerate_faq' not in detection_result:
            raise ValueError("detection_result missing 'regenerate_faq' key")
        if 'no_action_needed' not in detection_result:
            raise ValueError("detection_result missing 'no_action_needed' key")
        if 'telemetry' not in detection_result:
            raise ValueError("detection_result missing 'telemetry' key")

        # Determine detection_run_id
        if detection_run_id is None:
            detection_run_id = detection_result['telemetry'].get('detection_timestamp')
            if not detection_run_id:
                detection_run_id = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

        since_date = detection_result['telemetry'].get('since_date')

        # Initialize results
        results = {
            'detection_run_id': detection_run_id,
            'records_inserted': 0,
            'duplicates_skipped': 0,
            'records_requiring_regen': 0,
            'records_preserving': 0,
            'errors': [],
            'logged_at': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        }

        # Process pages
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA foreign_keys = ON")

            # Pages requiring regeneration
            for page in detection_result['regenerate_faq']:
                try:
                    inserted = self._log_page_detection(
                        conn, page, 1, detection_run_id, since_date
                    )
                    if inserted:
                        results['records_inserted'] += 1
                        results['records_requiring_regen'] += 1
                    else:
                        results['duplicates_skipped'] += 1
                except Exception as e:
                    logger.error(f"Failed to log page requiring regeneration: {e}")
                    results['errors'].append({
                        'type': 'regenerate_faq',
                        'data': page,
                        'error': str(e)
                    })

            # Pages to preserve
            for page in detection_result['no_action_needed']:
                try:
                    inserted = self._log_page_detection(
                        conn, page, 0, detection_run_id, since_date
                    )
                    if inserted:
                        results['records_inserted'] += 1
                        results['records_preserving'] += 1
                    else:
                        results['duplicates_skipped'] += 1
                except Exception as e:
                    logger.error(f"Failed to log page to preserve: {e}")
                    results['errors'].append({
                        'type': 'no_action_needed',
                        'data': page,
                        'error': str(e)
                    })

            conn.commit()

        logger.info(
            f"Detection logged: run_id={detection_run_id}, "
            f"inserted={results['records_inserted']}, "
            f"requiring_regen={results['records_requiring_regen']}"
        )

        return results

    def _log_page_detection(
        self,
        conn: sqlite3.Connection,
        page_data: Dict[str, Any],
        requires_faq_regeneration: int,
        detection_run_id: str,
        since_date: Optional[str]
    ) -> bool:
        """Log a single page detection to content_change_log."""
        # Validate required fields
        required = ['content_id', 'file_name', 'checksum', 'last_modified_dt']
        for field in required:
            if field not in page_data:
                raise ValueError(f"page_data missing required field: {field}")

        # Extract core fields
        content_id = page_data['content_id']
        file_name = page_data['file_name']
        checksum = page_data['checksum']
        source_modified_at = page_data['last_modified_dt']
        existing_faq_count = page_data.get('existing_faq_count', 0)

        # Get metadata JSON (detector already provides this as a dict)
        metadata_dict = page_data.get('metadata', {})
        metadata = json.dumps(metadata_dict) if metadata_dict else None

        # Insert with idempotency
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id,
                content_checksum,
                file_name,
                requires_faq_regeneration,
                metadata,
                source_modified_at,
                existing_faq_count,
                detection_run_id,
                since_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            content_id, checksum, file_name, requires_faq_regeneration,
            metadata, source_modified_at, existing_faq_count,
            detection_run_id, since_date
        ))

        return cursor.rowcount > 0

    def _build_metadata_json(self, page_data: Dict[str, Any]) -> Optional[str]:
        """Build metadata JSON from page_data, excluding core fields."""
        core_fields = {
            'content_id', 'file_name', 'checksum', 'last_modified_dt',
            'existing_faq_count'
        }

        metadata = {}
        for key, value in page_data.items():
            if key not in core_fields and value is not None:
                metadata[key] = value

        return json.dumps(metadata) if metadata else None

    def get_detection_history(
        self,
        file_name: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Retrieve detection history from content_change_log."""
        query = """
            SELECT change_id, content_id, file_name, content_checksum,
                   requires_faq_regeneration, metadata, source_modified_at,
                   detected_at, existing_faq_count, detection_run_id, since_date
            FROM content_change_log
        """

        params = []
        if file_name:
            query += " WHERE file_name = ?"
            params.append(file_name)

        query += " ORDER BY detected_at DESC LIMIT ?"
        params.append(limit)

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)

            results = []
            for row in cursor.fetchall():
                record = dict(row)
                if record['metadata']:
                    try:
                        record['metadata'] = json.loads(record['metadata'])
                    except json.JSONDecodeError:
                        logger.warning(
                            f"Failed to parse metadata JSON for change_id={record['change_id']}"
                        )
                        record['metadata'] = {}
                else:
                    record['metadata'] = {}
                results.append(record)

            return results

    def get_latest_detection_run(self) -> Optional[Dict[str, Any]]:
        """Get statistics for the most recent detection run."""
        query = """
            SELECT detection_run_id, run_started_at, run_completed_at,
                   total_pages_analyzed, pages_requiring_regeneration,
                   pages_not_requiring_regeneration, total_existing_faqs,
                   faqs_to_invalidate, files_processed,
                   unique_checksums_detected, detection_period_start
            FROM v_detection_run_stats
            ORDER BY run_started_at DESC LIMIT 1
        """

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query)
            row = cursor.fetchone()
            return dict(row) if row else None


# ============================================================================
# ChangeProcessor - DEPRECATED LEGACY CLASS
# ============================================================================


class ChangeProcessor:
    """
    DEPRECATED: Use ChangeLogger instead.

    This class is deprecated and will be removed in future versions.
    It uses the old change_type classification system which has been replaced
    by the simplified binary decision model (requires_faq_regeneration).

    Migration:
        OLD: processor = ChangeProcessor(content_db, tracking_db)
        NEW: logger = ChangeLogger(db_path='faq_update.db')

    See ChangeLogger class above for the new simplified approach.
    """

    def __init__(self, content_db: str, tracking_db: str):
        """
        Initialize change processor.

        DEPRECATED: Use ChangeLogger instead.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database
        """
        import warnings
        warnings.warn(
            "ChangeProcessor is deprecated. Use ChangeLogger instead. "
            "ChangeProcessor will be removed in a future version.",
            DeprecationWarning,
            stacklevel=2
        )

        self.content_db = content_db
        self.tracking_db = tracking_db
        self.validator = ContentValidator(content_db, tracking_db)

    @staticmethod
    def _validate_page_number_requirement(change_type: str, page_number: Optional[int],
                                          change_data: Dict) -> None:
        """
        Validate page_number requirements based on change type.

        Validation Rules:
        - position_change: page_number REQUIRED (needs both to_page and from_page)
        - page_inserted: page_number REQUIRED (needs to know where inserted)
        - page_deleted: page_number REQUIRED (needs to know what was deleted)
        - content_edit: page_number OPTIONAL (may be single-page doc or web content)
        - initial_creation: page_number OPTIONAL (may be single-page doc or web content)

        Args:
            change_type: Type of change being recorded
            page_number: Page number value (may be None)
            change_data: Full change data dictionary for context in error messages

        Raises:
            ValueError: If page_number is None when required for the change type
        """
        # Changes that REQUIRE page_number
        requires_page = ['position_change', 'page_inserted', 'page_deleted']

        if change_type in requires_page and page_number is None:
            raise ValueError(
                f"page_number is required for change_type '{change_type}' but got None. "
                f"Change data: {change_data}"
            )

        # For position_change, also validate from_page
        if change_type == 'position_change':
            from_page = change_data.get('from_page') or change_data.get('previous_page_number')
            if from_page is None:
                raise ValueError(
                    f"from_page (previous_page_number) is required for position_change but got None. "
                    f"Change data: {change_data}"
                )

    def process_changes(self, changes: Dict[str, List]) -> Dict:
        """
        Record all changes in tracking database.

        Note: Structural changes are no longer explicitly recorded - they are derived
        via v_document_structure_changes VIEW from position_change patterns.

        Args:
            changes: Dictionary of categorized changes from ChangeDetector

        Returns:
            Dictionary with processing results and statistics

        Examples:
            >>> processor = ChangeProcessor('content.db', 'tracking.db')
            >>> results = processor.process_changes(changes)
            >>> results['content_edits_processed']
            10
        """
        results = {
            'content_edits_processed': 0,
            'position_changes_processed': 0,
            'new_content_processed': 0,
            'deletions_processed': 0,
            'errors': []
        }

        with sqlite3.connect(self.tracking_db) as conn:
            # Process content edits
            for edit in changes['content_edits']:
                try:
                    change_id = self._record_content_edit(conn, edit)
                    if change_id:
                        results['content_edits_processed'] += 1
                except Exception as e:
                    logger.error(f"Failed to process edit: {e}")
                    results['errors'].append({
                        'type': 'content_edit',
                        'data': edit,
                        'error': str(e)
                    })

            # Process position changes
            for move in changes['position_changes']:
                try:
                    self._record_position_change(conn, move)
                    results['position_changes_processed'] += 1
                except Exception as e:
                    logger.error(f"Failed to process move: {e}")
                    results['errors'].append({
                        'type': 'position_change',
                        'data': move,
                        'error': str(e)
                    })

            # Process new content
            for new in changes['new_content']:
                try:
                    self._record_new_content(conn, new)
                    results['new_content_processed'] += 1
                except Exception as e:
                    logger.error(f"Failed to process new content: {e}")
                    results['errors'].append({
                        'type': 'new_content',
                        'data': new,
                        'error': str(e)
                    })

            # Process deletions
            for deletion in changes['deletions']:
                try:
                    self._record_deletion(conn, deletion)
                    results['deletions_processed'] += 1
                except Exception as e:
                    logger.error(f"Failed to process deletion: {e}")
                    results['errors'].append({
                        'type': 'deletion',
                        'data': deletion,
                        'error': str(e)
                    })

            conn.commit()

        return results

    def _record_content_edit(self, conn: sqlite3.Connection, edit: Dict) -> Optional[int]:
        """
        Record a content edit change with validation and idempotency.

        IMPORTANT: Proper time semantics:
        - last_modified_dt = when edit occurred in source (from edit['last_modified_dt'], REQUIRED)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB)

        Args:
            conn: Database connection
            edit: Edit change dictionary (must include 'last_modified_dt')

        Returns:
            Change ID if inserted, None if duplicate

        Raises:
            ValueError: If content_id is invalid or last_modified_dt is missing
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validator.validate_content_id(edit['content_id']):
            raise ValueError(f"Invalid content_id: {edit['content_id']}")

        if 'last_modified_dt' not in edit:
            raise ValueError(f"Missing required field 'last_modified_dt' in edit: {edit}")

        # Use INSERT OR IGNORE for idempotency
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_content_id, previous_checksum,
                change_trigger, last_modified_dt
            ) VALUES (?, ?, ?, ?, 'content_edit', ?, ?, 'content_update', ?)
        """, (
            edit['content_id'], edit['file_name'], edit['page_number'],
            edit['new_checksum'], edit['previous_content_id'],
            edit['old_checksum'],
            edit['last_modified_dt']
        ))

        if cursor.rowcount == 0:
            logger.debug(
                f"Duplicate edit ignored: {edit['file_name']} page {edit['page_number']}"
            )
            return None

        return cursor.lastrowid

    def _record_position_change(self, conn: sqlite3.Connection, move: Dict) -> Optional[int]:
        """
        Record a position change with validation and idempotency.

        IMPORTANT: Proper time semantics:
        - last_modified_dt = when move occurred in source (from move['last_modified_dt'], REQUIRED)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB)

        Args:
            conn: Database connection
            move: Position change dictionary (must include 'last_modified_dt')

        Returns:
            Change ID if inserted, None if duplicate

        Raises:
            ValueError: If content_id is invalid, last_modified_dt is missing, or page_number is None
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validator.validate_content_id(move['content_id']):
            raise ValueError(f"Invalid content_id: {move['content_id']}")

        if 'last_modified_dt' not in move:
            raise ValueError(f"Missing required field 'last_modified_dt' in move: {move}")

        # Validate page_number requirement (position_change REQUIRES page)
        self._validate_page_number_requirement('position_change', move.get('to_page'), move)

        # Use INSERT OR IGNORE for idempotency
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_page_number, change_trigger,
                last_modified_dt
            ) VALUES (?, ?, ?, ?, 'position_change', ?, 'page_reorder', ?)
        """, (
            move['content_id'], move['file_name'], move['to_page'],
            move['checksum'], move['from_page'],
            move['last_modified_dt']
        ))

        if cursor.rowcount == 0:
            logger.debug(
                f"Duplicate move ignored: {move['file_name']} page {move['from_page']}->{move['to_page']}"
            )
            return None

        return cursor.lastrowid

    def _record_new_content(self, conn: sqlite3.Connection, new: Dict) -> Optional[int]:
        """
        Record new content creation with validation and idempotency.

        IMPORTANT: Proper time semantics:
        - last_modified_dt = when content was created in source (from new['last_modified_dt'], REQUIRED)
        - detected_at = when pipeline detected it (set to now() by DEFAULT in DB)

        Args:
            conn: Database connection
            new: New content dictionary (must include 'last_modified_dt')

        Returns:
            Change ID if inserted, None if duplicate

        Raises:
            ValueError: If content_id is invalid or last_modified_dt is missing
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validator.validate_content_id(new['content_id']):
            raise ValueError(f"Invalid content_id: {new['content_id']}")

        if 'last_modified_dt' not in new:
            raise ValueError(f"Missing required field 'last_modified_dt' in new content: {new}")

        # Use INSERT OR IGNORE for idempotency
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, change_trigger, last_modified_dt
            ) VALUES (?, ?, ?, ?, 'initial_creation', 'new_page', ?)
        """, (
            new['content_id'], new['file_name'], new['page_number'],
            new['checksum'],
            new['last_modified_dt']
        ))

        if cursor.rowcount == 0:
            logger.debug(
                f"Duplicate new content ignored: {new['file_name']} page {new['page_number']}"
            )
            return None

        return cursor.lastrowid

    def _record_deletion(self, conn: sqlite3.Connection, deletion: Dict) -> Optional[int]:
        """
        Record content deletion with validation and idempotency.

        Also invalidates affected FAQ mappings.

        Args:
            conn: Database connection
            deletion: Deletion change dictionary (must include 'last_modified_dt')

        Returns:
            Change ID if inserted, None if duplicate

        Raises:
            ValueError: If content_id is invalid, last_modified_dt is missing, or page_number is None
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validator.validate_content_id(deletion['content_id']):
            raise ValueError(f"Invalid content_id: {deletion['content_id']}")

        if 'last_modified_dt' not in deletion:
            raise ValueError(f"Missing required field 'last_modified_dt' in deletion: {deletion}")

        # Validate page_number requirement (page_deleted REQUIRES page)
        self._validate_page_number_requirement('page_deleted', deletion.get('page_number'), deletion)

        # Use INSERT OR IGNORE for idempotency
        cursor = conn.execute("""
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, change_trigger, last_modified_dt
            ) VALUES (?, ?, ?, ?, 'page_deleted', 'content_removed', ?)
        """, (
            deletion['content_id'], deletion['file_name'],
            deletion['page_number'], deletion['checksum'],
            deletion['last_modified_dt']
        ))

        if cursor.rowcount == 0:
            logger.debug(
                f"Duplicate deletion ignored: {deletion['file_name']} page {deletion['page_number']}"
            )
            return None

        change_id = cursor.lastrowid

        # Invalidate affected FAQ mappings
        if change_id:
            conn.execute("""
                UPDATE faq_content_map
                SET is_valid = 0,
                    valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                    invalidation_reason = 'content_deleted',
                    invalidated_by_change_id = ?
                WHERE content_checksum = ?
                  AND is_valid = 1
            """, (change_id, deletion['checksum']))

        return change_id

    def record_change_idempotent(self, conn: sqlite3.Connection,
                                 change_type: str, change_data: dict) -> Optional[int]:
        """
        Record change with idempotency guarantee.

        Uses INSERT OR IGNORE to handle duplicates gracefully.

        IMPORTANT: Proper time semantics:
        - last_modified_dt = when change occurred in source (REQUIRED in change_data)
        - detected_at = when pipeline detected it (auto-set to now() by database DEFAULT)

        Args:
            conn: Database connection
            change_type: Type of change (content_edit, position_change, etc.)
            change_data: Dictionary containing change information (must include 'last_modified_dt')

        Returns:
            Change ID if inserted, None if duplicate

        Raises:
            ValueError: If last_modified_dt is missing or page_number validation fails
        """
        if 'last_modified_dt' not in change_data:
            raise ValueError(f"Missing required field 'last_modified_dt' in change_data: {change_data}")

        # Validate page_number requirement based on change_type
        self._validate_page_number_requirement(change_type, change_data.get('page_number'), change_data)

        # Use INSERT OR IGNORE to handle duplicates gracefully
        query = """
            INSERT OR IGNORE INTO content_change_log (
                content_id, file_name, page_number, content_checksum,
                change_type, previous_content_id, previous_page_number,
                previous_checksum, change_trigger, last_modified_dt, detected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        # Get current timestamp for detected_at (when we're detecting this NOW)
        detected_at_now = format_timestamp(datetime.now())

        cursor = conn.execute(query, (
            change_data['content_id'],
            change_data['file_name'],
            change_data['page_number'],
            change_data.get('checksum') or change_data.get('new_checksum'),
            change_type,
            change_data.get('previous_content_id'),
            change_data.get('previous_page_number') or change_data.get('from_page'),
            change_data.get('previous_checksum') or change_data.get('old_checksum'),
            change_data.get('change_trigger', 'automated'),
            change_data['last_modified_dt'],
            detected_at_now
        ))

        # Check if insert was successful or ignored
        if cursor.rowcount == 0:
            logger.debug(
                f"Duplicate change ignored: {change_type} for "
                f"{change_data['file_name']} page {change_data['page_number']}"
            )
            return None

        change_id = cursor.lastrowid

        # If this is a deletion, invalidate affected FAQ mappings
        if change_type == 'page_deleted' and change_id:
            checksum = change_data.get('checksum') or change_data.get('previous_checksum')
            if checksum:
                conn.execute("""
                    UPDATE faq_content_map
                    SET is_valid = 0,
                        valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                        invalidation_reason = 'content_deleted',
                        invalidated_by_change_id = ?
                    WHERE content_checksum = ?
                      AND is_valid = 1
                """, (change_id, checksum))

        return change_id
