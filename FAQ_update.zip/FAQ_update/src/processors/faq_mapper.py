"""
FAQ Mapper Module

Contains two classes:
1. FAQUpdater - NEW simplified class for checksum-centric architecture (USE THIS)
2. FAQMapper - DEPRECATED legacy class (for backward compatibility only)

FAQUpdater processes FAQ regeneration detection results using the simplified
schema with checksum-based invalidation and JSON metadata.

FAQMapper is deprecated and will be removed in future versions.
It used complex change_type classification which has been replaced.

Migration Guide:
    OLD (FAQMapper):
        mapper = FAQMapper(content_db, tracking_db)
        mapper.update_faq_mappings(changes)

    NEW (FAQUpdater):
        updater = FAQUpdater(db_path='faq_update.db')
        updater.process_detection_results(detection_result)
"""

import sqlite3
import json
import pandas as pd
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path

from validators.content_validator import ContentValidator

logger = logging.getLogger(__name__)


# ============================================================================
# FAQUpdater - NEW SIMPLIFIED CLASS (USE THIS)
# ============================================================================

class FAQUpdater:
    """
    Processes FAQ regeneration detection results for FAQ invalidation and updates.

    This class handles FAQ content_map updates based on detection results from
    FAQRegenerationDetector, using the simplified checksum-centric schema.

    Key Design Principles:
        1. Checksum-based invalidation: If checksum requires regeneration, invalidate all FAQs
        2. Metadata updates: Update FAQ metadata JSON when content preserved
        3. Binary decision: Simple regenerate vs preserve logic
        4. Batch processing: Handles all detections in a single transaction
        5. Audit trail: Links invalidations to detection run

    Attributes:
        db_path (str): Path to the unified faq_update.db database

    Example:
        >>> updater = FAQUpdater(db_path='databases/faq_update.db')
        >>> result = detector.detect(since_date='2024-01-01')
        >>> update_result = updater.process_detection_results(result)
        >>> print(f"FAQs invalidated: {update_result['faqs_invalidated']}")
    """

    def __init__(self, db_path: str):
        """Initialize FAQUpdater with database connection."""
        self.db_path = str(Path(db_path).resolve())

        if not Path(self.db_path).exists():
            raise FileNotFoundError(f"Database not found: {self.db_path}")

        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("PRAGMA foreign_keys = ON")
                cursor = conn.execute("""
                    SELECT name FROM sqlite_master
                    WHERE type='table' AND name='faq_content_map'
                """)
                if not cursor.fetchone():
                    raise ValueError(
                        f"faq_content_map table not found in {self.db_path}. "
                        f"Please run create_schema_v4.sql first."
                    )
                logger.info(f"FAQUpdater initialized with database: {self.db_path}")
        except sqlite3.Error as e:
            raise sqlite3.Error(f"Failed to connect to database {self.db_path}: {e}")

    def process_detection_results(
        self,
        detection_result: Dict[str, Any],
        detection_run_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Process FAQ regeneration detection results."""
        if 'regenerate_faq' not in detection_result:
            raise ValueError("detection_result missing 'regenerate_faq' key")
        if 'no_action_needed' not in detection_result:
            raise ValueError("detection_result missing 'no_action_needed' key")
        if 'telemetry' not in detection_result:
            raise ValueError("detection_result missing 'telemetry' key")

        if detection_run_id is None:
            detection_run_id = detection_result['telemetry'].get('detection_timestamp')
            if not detection_run_id:
                detection_run_id = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

        results = {
            'detection_run_id': detection_run_id,
            'faqs_invalidated': 0,
            'faqs_preserved': 0,
            'faqs_metadata_updated': 0,
            'checksums_requiring_regen': 0,
            'checksums_preserved': 0,
            'errors': [],
            'processed_at': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        }

        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA foreign_keys = ON")

            for page in detection_result['regenerate_faq']:
                try:
                    invalidated = self._invalidate_faqs_by_checksum(
                        conn, page['checksum'], detection_run_id
                    )
                    results['faqs_invalidated'] += invalidated
                    if invalidated > 0:
                        results['checksums_requiring_regen'] += 1
                except Exception as e:
                    logger.error(f"Failed to invalidate FAQs: {e}")
                    results['errors'].append({
                        'type': 'invalidation',
                        'checksum': page.get('checksum'),
                        'error': str(e)
                    })

            for page in detection_result['no_action_needed']:
                try:
                    updated = self._update_faq_metadata(conn, page['checksum'], page)
                    results['faqs_preserved'] += self._count_valid_faqs_by_checksum(
                        conn, page['checksum']
                    )
                    results['faqs_metadata_updated'] += updated
                    if updated > 0 or self._count_valid_faqs_by_checksum(conn, page['checksum']) > 0:
                        results['checksums_preserved'] += 1
                except Exception as e:
                    logger.error(f"Failed to update FAQ metadata: {e}")
                    results['errors'].append({
                        'type': 'metadata_update',
                        'checksum': page.get('checksum'),
                        'error': str(e)
                    })

            conn.commit()

        logger.info(
            f"FAQ processing complete: run_id={detection_run_id}, "
            f"invalidated={results['faqs_invalidated']}, preserved={results['faqs_preserved']}"
        )

        return results

    def _invalidate_faqs_by_checksum(
        self, conn: sqlite3.Connection, checksum: str, detection_run_id: str
    ) -> int:
        """Invalidate all FAQs associated with a checksum."""
        cursor = conn.execute("""
            SELECT change_id FROM content_change_log
            WHERE content_checksum = ? AND detection_run_id = ?
              AND requires_faq_regeneration = 1
            ORDER BY detected_at DESC LIMIT 1
        """, (checksum, detection_run_id))

        row = cursor.fetchone()
        change_id = row[0] if row else None

        cursor = conn.execute("""
            UPDATE faq_content_map
            SET is_valid = 0,
                valid_until = COALESCE(valid_until, strftime('%Y-%m-%dT%H:%M:%SZ','now')),
                invalidation_reason = 'content_edited',
                invalidated_by_change_id = ?
            WHERE content_checksum = ? AND is_valid = 1
        """, (change_id, checksum))

        invalidated = cursor.rowcount
        if invalidated > 0:
            logger.debug(f"Invalidated {invalidated} FAQs for checksum {checksum[:8]}...")

        return invalidated

    def _update_faq_metadata(
        self, conn: sqlite3.Connection, checksum: str, page_data: Dict[str, Any]
    ) -> int:
        """Update FAQ metadata for preserved checksums."""
        metadata = {}
        core_fields = {'content_id', 'file_name', 'checksum', 'last_modified_dt', 'existing_faq_count'}
        for key, value in page_data.items():
            if key not in core_fields and value is not None:
                if not key.startswith('current_'):
                    metadata[f'current_{key}'] = value
                else:
                    metadata[key] = value

        metadata_json = json.dumps(metadata) if metadata else None

        cursor = conn.execute("""
            UPDATE faq_content_map
            SET current_metadata = ?, current_content_id = ?, current_file_name = ?
            WHERE content_checksum = ? AND is_valid = 1
        """, (metadata_json, page_data.get('content_id'), page_data.get('file_name'), checksum))

        updated = cursor.rowcount
        if updated > 0:
            logger.debug(f"Updated metadata for {updated} FAQs with checksum {checksum[:8]}...")

        return updated

    def _count_valid_faqs_by_checksum(self, conn: sqlite3.Connection, checksum: str) -> int:
        """Count number of valid FAQs for a checksum."""
        cursor = conn.execute("""
            SELECT COUNT(*) FROM faq_content_map
            WHERE content_checksum = ? AND is_valid = 1
        """, (checksum,))
        return cursor.fetchone()[0]

    def get_faqs_by_checksum(
        self, checksum: str, include_invalid: bool = False
    ) -> List[Dict[str, Any]]:
        """Get all FAQs associated with a checksum."""
        query = """
            SELECT fcm.map_id, fcm.question_id, fcm.answer_id, fcm.content_checksum,
                   fcm.current_content_id, fcm.current_file_name, fcm.current_metadata,
                   fcm.original_metadata, fcm.is_valid, fcm.valid_from, fcm.valid_until,
                   fcm.invalidation_reason, fcm.created_at,
                   fq.question_txt, fa.faq_answer_txt
            FROM faq_content_map fcm
            JOIN faq_questions fq ON fcm.question_id = fq.question_id
            LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
            WHERE fcm.content_checksum = ?
        """

        params = [checksum]
        if not include_invalid:
            query += " AND fcm.is_valid = 1"
        query += " ORDER BY fcm.created_at"

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)

            results = []
            for row in cursor.fetchall():
                record = dict(row)
                for metadata_field in ['current_metadata', 'original_metadata']:
                    if record[metadata_field]:
                        try:
                            record[metadata_field] = json.loads(record[metadata_field])
                        except json.JSONDecodeError:
                            logger.warning(f"Failed to parse {metadata_field} JSON")
                            record[metadata_field] = {}
                    else:
                        record[metadata_field] = {}
                results.append(record)

            return results

    def get_invalidated_faqs(
        self, since_date: Optional[str] = None, detection_run_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get invalidated FAQs with optional filtering."""
        query = """
            SELECT fcm.map_id, fcm.question_id, fcm.answer_id, fcm.content_checksum,
                   fcm.current_file_name, fcm.current_metadata, fcm.invalidation_reason,
                   fcm.valid_until as invalidated_at, fcm.invalidated_by_change_id,
                   ccl.requires_faq_regeneration, ccl.detected_at, ccl.detection_run_id,
                   fq.question_txt, fa.faq_answer_txt
            FROM faq_content_map fcm
            JOIN faq_questions fq ON fcm.question_id = fq.question_id
            LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
            LEFT JOIN content_change_log ccl ON fcm.invalidated_by_change_id = ccl.change_id
            WHERE fcm.is_valid = 0
        """

        params = []
        if since_date:
            query += " AND fcm.valid_until > ?"
            params.append(since_date)
        if detection_run_id:
            query += " AND ccl.detection_run_id = ?"
            params.append(detection_run_id)

        query += " ORDER BY fcm.valid_until DESC"

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)

            results = []
            for row in cursor.fetchall():
                record = dict(row)
                if record['current_metadata']:
                    try:
                        record['current_metadata'] = json.loads(record['current_metadata'])
                    except json.JSONDecodeError:
                        record['current_metadata'] = {}
                else:
                    record['current_metadata'] = {}
                results.append(record)

            return results


# ============================================================================
# FAQMapper - DEPRECATED LEGACY CLASS
# ============================================================================


class FAQMapper:
    """
    DEPRECATED: Use FAQUpdater instead.

    This class is deprecated and will be removed in future versions.
    It uses the old change_type classification system which has been replaced
    by the simplified checksum-based invalidation model.

    Migration:
        OLD: mapper = FAQMapper(content_db, tracking_db)
        NEW: updater = FAQUpdater(db_path='faq_update.db')

    See FAQUpdater class above for the new simplified approach.
    """

    def __init__(self, content_db: str, tracking_db: str):
        """
        Initialize FAQ mapper.

        DEPRECATED: Use FAQUpdater instead.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database
        """
        import warnings
        warnings.warn(
            "FAQMapper is deprecated. Use FAQUpdater instead. "
            "FAQMapper will be removed in a future version.",
            DeprecationWarning,
            stacklevel=2
        )

        self.content_db = content_db
        self.tracking_db = tracking_db
        self.validator = ContentValidator(content_db, tracking_db)

    def update_faq_mappings(self, changes: Dict[str, List]) -> Dict:
        """
        Update FAQ mappings based on detected changes.

        IMPORTANT: Cross-database FK validation for current_content_id
        Since faq_content_map.current_content_id references content_repo.ud_source_file_id
        across databases, SQLite cannot enforce this FK constraint. We validate in code.

        Args:
            changes: Dictionary of categorized changes from ChangeDetector
                    OR adapted from FAQRegenerationDetector using FAQToChangesAdapter

        Returns:
            Dictionary with FAQ update results and statistics

        Examples:
            >>> mapper = FAQMapper('content.db', 'tracking.db')
            >>> # From ChangeDetector
            >>> results = mapper.update_faq_mappings(changes)
            >>> # OR from FAQRegenerationDetector
            >>> from detectors.faq_to_changes_adapter import FAQToChangesAdapter
            >>> adapted = FAQToChangesAdapter.adapt(faq_regen_result)
            >>> results = mapper.update_faq_mappings(adapted)
            >>> results['faqs_invalidated']
            15
        """
        results = {
            'faqs_invalidated': 0,
            'faqs_relocated': 0,
            'errors': []
        }

        with sqlite3.connect(self.tracking_db) as conn:
            # Invalidate FAQs for content edits
            for edit in changes['content_edits']:
                try:
                    invalidated = self._invalidate_faqs_for_edit(conn, edit)
                    results['faqs_invalidated'] += invalidated
                except Exception as e:
                    logger.error(f"Failed to invalidate FAQs: {e}")
                    results['errors'].append(str(e))

            # Update locations for position changes
            for move in changes['position_changes']:
                try:
                    relocated = self._relocate_faqs_for_move(conn, move)
                    results['faqs_relocated'] += relocated
                except Exception as e:
                    logger.error(f"Failed to relocate FAQs: {e}")
                    results['errors'].append(str(e))

            # Invalidate FAQs for deletions (handled by ChangeProcessor, but double-check)
            for deletion in changes['deletions']:
                try:
                    invalidated = self._invalidate_faqs_for_deletion(conn, deletion)
                    results['faqs_invalidated'] += invalidated
                except Exception as e:
                    logger.error(f"Failed to invalidate FAQs for deletion: {e}")
                    results['errors'].append(str(e))

            conn.commit()

        return results

    def _invalidate_faqs_for_edit(self, conn: sqlite3.Connection, edit: Dict) -> int:
        """
        Invalidate FAQs affected by content edit.

        IMPORTANT: Simplified FAQ regeneration detector doesn't track old_checksum per content_id.
        When old_checksum is None, we cannot invalidate FAQs because we don't know which
        checksum to target. This is a known limitation of the simplified checksum-centric model.

        Args:
            conn: Database connection
            edit: Edit change dictionary with optional 'old_checksum' field

        Returns:
            Number of FAQs invalidated (0 if old_checksum is None)
        """
        old_checksum = edit.get('old_checksum')

        if old_checksum is None:
            # Simplified FAQ detector doesn't track old_checksum per content_id
            # We can't invalidate without knowing which checksum to target
            logger.warning(
                f"Cannot invalidate FAQs for content_id {edit['content_id']}: "
                f"old_checksum not provided (simplified detection model limitation). "
                f"This is expected when using FAQRegenerationDetector."
            )
            return 0

        # Original logic for full ChangeDetector (which provides old_checksum)
        cursor = conn.execute("""
            UPDATE faq_content_map
            SET is_valid = 0,
                valid_until = strftime('%Y-%m-%dT%H:%M:%SZ', 'now'),
                invalidation_reason = 'content_edited',
                invalidated_by_change_id = (
                    SELECT change_id FROM content_change_log
                    WHERE content_id = ?
                    ORDER BY change_id DESC LIMIT 1
                )
            WHERE content_checksum = ? AND is_valid = 1
        """, (edit['content_id'], old_checksum))

        return cursor.rowcount

    def _relocate_faqs_for_move(self, conn: sqlite3.Connection, move: Dict) -> int:
        """
        Update FAQ locations for position change.

        Validates content_id before updating (cross-DB FK constraint).

        Args:
            conn: Database connection
            move: Position change dictionary

        Returns:
            Number of FAQs relocated

        Raises:
            ValueError: If content_id is invalid
        """
        # Validate FK constraint in code (cross-DB FK not supported)
        if not self.validator.validate_content_id(move['content_id']):
            raise ValueError(f"Invalid content_id: {move['content_id']}")

        cursor = conn.execute("""
            UPDATE faq_content_map
            SET current_page_number = ?,
                current_content_id = ?
            WHERE content_checksum = ?
              AND is_valid = 1
              AND current_file_name = ?
        """, (
            move['to_page'],
            move['content_id'],
            move['checksum'],
            move['file_name']
        ))

        return cursor.rowcount

    def _invalidate_faqs_for_deletion(self, conn: sqlite3.Connection, deletion: Dict) -> int:
        """
        Invalidate FAQs for deleted content.

        Args:
            conn: Database connection
            deletion: Deletion change dictionary

        Returns:
            Number of FAQs invalidated
        """
        cursor = conn.execute("""
            UPDATE faq_content_map
            SET is_valid = 0,
                valid_until = strftime('%Y-%m-%dT%H:%M:%SZ', 'now'),
                invalidation_reason = 'content_deleted',
                invalidated_by_change_id = (
                    SELECT change_id FROM content_change_log
                    WHERE content_id = ? AND change_type = 'page_deleted'
                    ORDER BY change_id DESC LIMIT 1
                )
            WHERE content_checksum = ? AND is_valid = 1
        """, (deletion['content_id'], deletion['checksum']))

        return cursor.rowcount

    def get_current_faqs_for_page(self, file_name: str, page_number: int) -> pd.DataFrame:
        """
        Get all currently valid FAQs for a specific page.

        Args:
            file_name: Name of the file
            page_number: Page number

        Returns:
            DataFrame containing FAQ information

        Examples:
            >>> mapper = FAQMapper('content.db', 'tracking.db')
            >>> faqs = mapper.get_current_faqs_for_page('policy.pdf', 4)
            >>> len(faqs)
            3
        """
        with sqlite3.connect(self.tracking_db) as conn:
            query = """
                SELECT
                    fcm.*,
                    fq.question_txt,
                    fa.faq_answer_txt
                FROM faq_content_map fcm
                JOIN faq_questions fq ON fcm.question_id = fq.question_id
                LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                WHERE fcm.current_file_name = ?
                  AND fcm.current_page_number = ?
                  AND fcm.is_valid = 1
                ORDER BY fcm.created_at
            """

            return pd.read_sql(query, conn, params=[file_name, page_number])

    def get_faqs_by_checksum(self, checksum: str) -> pd.DataFrame:
        """
        Get all FAQs associated with a specific content checksum.

        Args:
            checksum: Content checksum

        Returns:
            DataFrame containing FAQ information
        """
        with sqlite3.connect(self.tracking_db) as conn:
            query = """
                SELECT
                    fcm.*,
                    fq.question_txt,
                    fa.faq_answer_txt
                FROM faq_content_map fcm
                JOIN faq_questions fq ON fcm.question_id = fq.question_id
                LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                WHERE fcm.content_checksum = ?
                ORDER BY fcm.created_at
            """

            return pd.read_sql(query, conn, params=[checksum])

    def get_invalidated_faqs(self, since_date: str = None) -> pd.DataFrame:
        """
        Get all invalidated FAQs, optionally filtered by date.

        Args:
            since_date: Optional ISO format datetime to filter invalidations

        Returns:
            DataFrame containing invalidated FAQ information
        """
        with sqlite3.connect(self.tracking_db) as conn:
            if since_date:
                query = """
                    SELECT
                        fcm.*,
                        fq.question_txt,
                        fa.faq_answer_txt,
                        ccl.change_type,
                        ccl.detected_at as change_detected_at
                    FROM faq_content_map fcm
                    JOIN faq_questions fq ON fcm.question_id = fq.question_id
                    LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                    LEFT JOIN content_change_log ccl ON fcm.invalidated_by_change_id = ccl.change_id
                    WHERE fcm.is_valid = 0
                      AND fcm.valid_until > ?
                    ORDER BY fcm.valid_until DESC
                """
                params = [since_date]
            else:
                query = """
                    SELECT
                        fcm.*,
                        fq.question_txt,
                        fa.faq_answer_txt,
                        ccl.change_type,
                        ccl.detected_at as change_detected_at
                    FROM faq_content_map fcm
                    JOIN faq_questions fq ON fcm.question_id = fq.question_id
                    LEFT JOIN faq_answers fa ON fcm.answer_id = fa.answer_id
                    LEFT JOIN content_change_log ccl ON fcm.invalidated_by_change_id = ccl.change_id
                    WHERE fcm.is_valid = 0
                    ORDER BY fcm.valid_until DESC
                """
                params = []

            return pd.read_sql(query, conn, params=params)
