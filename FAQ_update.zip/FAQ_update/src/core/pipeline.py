"""
Content Tracking Pipeline Core Module

Main orchestrator for the production content tracking pipeline with proper
change classification, validation, and reporting.
"""

import json
import logging
from datetime import datetime
from typing import Dict, Optional
from pathlib import Path

from utils.logging_config import setup_production_logger
from validators.content_validator import ContentValidator
from detectors.change_detector import ChangeDetector
from processors.change_processor import ChangeProcessor
from processors.faq_mapper import FAQMapper
from reporters.impact_reporter import ImpactReporter
import sys
from pathlib import Path

# Add parent directory to path for content_diff import
sys.path.insert(0, str(Path(__file__).parent.parent))
from content_diff import ContentDiffProcessor

logger = logging.getLogger(__name__)


class ContentTrackingPipeline:
    """
    Production pipeline for content tracking with proper change classification.

    This is the main entry point for the content tracking system. It orchestrates
    the entire process of detecting, processing, and reporting content changes.
    """

    def __init__(self, content_db: str, tracking_db: str, enable_debug: bool = False):
        """
        Initialize the content tracking pipeline.

        Args:
            content_db: Path to content repository database
            tracking_db: Path to tracking database
            enable_debug: If True, enables debug logging

        Examples:
            >>> pipeline = ContentTrackingPipeline('content.db', 'tracking.db')
            >>> results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')
        """
        self.content_db = content_db
        self.tracking_db = tracking_db

        # Initialize logger
        self.logger = setup_production_logger(__name__)
        if enable_debug:
            self.logger.setLevel(logging.DEBUG)

        # Initialize components
        self.validator = ContentValidator(content_db, tracking_db)
        self.detector = ChangeDetector(content_db, tracking_db)
        self.processor = ChangeProcessor(content_db, tracking_db)
        self.faq_mapper = FAQMapper(content_db, tracking_db)
        self.reporter = ImpactReporter(tracking_db)
        self.diff_processor = ContentDiffProcessor(content_db, tracking_db)

    def process_daily_updates(self, since_date: str) -> Dict:
        """
        Main entry point for daily processing.

        Args:
            since_date: ISO format datetime to process changes since

        Returns:
            Dictionary with processing results and statistics:
            - status: 'success' or 'failed'
            - changes: Detected changes
            - processing_results: Processing statistics
            - faq_results: FAQ update results
            - impact_report: Impact analysis
            - execution_time: Execution time in seconds

        Examples:
            >>> pipeline = ContentTrackingPipeline('content.db', 'tracking.db')
            >>> results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')
            >>> print(results['impact_report']['severity'])
            'medium'
        """
        start_time = datetime.now()
        self.logger.info(f"Starting daily processing for changes since {since_date}")

        try:
            # 1. Detect and analyze changes
            self.logger.info("Step 1: Detecting changes...")
            changes = self.detector.detect_changes(since_date)

            # 2. Process changes
            self.logger.info("Step 2: Processing changes...")
            processing_results = self.processor.process_changes(changes)

            # 3. Update FAQ mappings
            self.logger.info("Step 3: Updating FAQ mappings...")
            faq_results = self.faq_mapper.update_faq_mappings(changes)

            # 4. Process content diffs
            self.logger.info("Step 4: Generating content diffs...")
            diff_results = self.diff_processor.process_pending_diffs()
            self.logger.info(f"Generated {diff_results['diffs_generated']} diffs")

            # 5. Generate impact report
            self.logger.info("Step 5: Generating impact report...")
            impact_report = self.reporter.generate_impact_report(
                changes, faq_results, diff_results
            )

            # 6. Record run metadata
            self.logger.info("Step 6: Recording run metadata...")
            self._record_run_metadata(
                since_date,
                changes,
                processing_results,
                start_time
            )

            execution_time = (datetime.now() - start_time).total_seconds()
            self.logger.info(f"Daily processing completed successfully in {execution_time:.2f}s")

            return {
                'status': 'success',
                'changes': changes,
                'processing_results': processing_results,
                'faq_results': faq_results,
                'diff_results': diff_results,
                'impact_report': impact_report,
                'execution_time': execution_time
            }

        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self.logger.error(f"Pipeline failed after {execution_time:.2f}s: {e}", exc_info=True)
            return {
                'status': 'failed',
                'error': str(e),
                'execution_time': execution_time
            }

    def _record_run_metadata(self, since_date: str, changes: Dict,
                            results: Dict, start_time: datetime):
        """
        Record metadata about this pipeline run.

        Args:
            since_date: Start date for processing
            changes: Detected changes
            results: Processing results
            start_time: Pipeline start time
        """
        # This would record to a pipeline_runs table
        # Implementation depends on specific monitoring needs
        metadata = {
            'run_timestamp': start_time.isoformat(),
            'since_date': since_date,
            'total_changes': sum(len(v) for v in changes.values()),
            'processing_results': results
        }
        self.logger.debug(f"Run metadata: {json.dumps(metadata, indent=2)}")

    def get_current_faqs_for_page(self, file_name: str, page_number: int):
        """
        Get all currently valid FAQs for a specific page.

        Args:
            file_name: Name of the file
            page_number: Page number

        Returns:
            DataFrame containing FAQ information

        Examples:
            >>> pipeline = ContentTrackingPipeline('content.db', 'tracking.db')
            >>> faqs = pipeline.get_current_faqs_for_page('policy.pdf', 4)
            >>> len(faqs)
            3
        """
        return self.faq_mapper.get_current_faqs_for_page(file_name, page_number)

    def generate_report_text(self, results: Dict) -> str:
        """
        Generate human-readable text report from results.

        Args:
            results: Results dictionary from process_daily_updates()

        Returns:
            Formatted text report

        Examples:
            >>> results = pipeline.process_daily_updates('2025-01-01T00:00:00Z')
            >>> report_text = pipeline.generate_report_text(results)
            >>> print(report_text)
        """
        if results['status'] != 'success':
            return f"Pipeline failed: {results.get('error', 'Unknown error')}"

        return self.reporter.generate_change_report_text(results['impact_report'])

    def get_change_timeline(self, file_name: Optional[str] = None,
                           since_date: Optional[str] = None,
                           limit: int = 100):
        """
        Get chronological timeline of changes.

        Args:
            file_name: Optional file name filter
            since_date: Optional ISO format datetime filter
            limit: Maximum number of records to return

        Returns:
            DataFrame with change timeline
        """
        return self.reporter.get_change_timeline(file_name, since_date, limit)

    def get_faq_impact_summary(self, since_date: Optional[str] = None):
        """
        Get summary of FAQ impact metrics.

        Args:
            since_date: Optional ISO format datetime filter

        Returns:
            Dictionary with FAQ impact statistics
        """
        return self.reporter.get_faq_impact_summary(since_date)


def main():
    """
    Main entry point for command-line usage.

    Examples:
        python -m src.core.pipeline
    """
    import sys

    if len(sys.argv) < 2:
        print("Usage: python -m src.core.pipeline <since_date> [content_db] [tracking_db]")
        print("Example: python -m src.core.pipeline 2025-01-01T00:00:00Z")
        sys.exit(1)

    since_date = sys.argv[1]
    content_db = sys.argv[2] if len(sys.argv) > 2 else 'content_repo.db'
    tracking_db = sys.argv[3] if len(sys.argv) > 3 else 'version_tracking_new.db'

    # Initialize and run pipeline
    pipeline = ContentTrackingPipeline(content_db, tracking_db)
    results = pipeline.process_daily_updates(since_date)

    # Print results
    if results['status'] == 'success':
        print("\n" + pipeline.generate_report_text(results))
        print(f"\nExecution time: {results['execution_time']:.2f} seconds")

        # Query FAQs for example page
        if results['changes']['content_edits']:
            first_edit = results['changes']['content_edits'][0]
            faqs = pipeline.get_current_faqs_for_page(
                first_edit['file_name'],
                first_edit['page_number']
            )
            print(f"\nFAQs for {first_edit['file_name']} page {first_edit['page_number']}: {len(faqs)}")
    else:
        print(f"\nPipeline failed: {results['error']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
