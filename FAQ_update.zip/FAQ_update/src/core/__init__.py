"""
Core Package

Provides the main ContentTrackingPipeline orchestrator.
"""

from .pipeline import ContentTrackingPipeline

__all__ = ['ContentTrackingPipeline']
