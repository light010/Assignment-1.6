"""
Utilities Package

Provides utility functions for timestamps, checksums, and logging configuration.
"""

# Import production utilities (for pipeline modules)
from . import timestamp_utils
from . import checksum_utils as _checksum_utils
from .logging_config import (
    setup_logger,
    setup_production_logger,
    setup_debug_logger
)

# Import notebook utilities (for Jupyter notebooks)
# These override the production versions for consistent test data
from .notebook_utils import (
    BASE_TIME,
    format_timestamp,  # Override timestamp_utils.format_timestamp
    get_timestamp,
    calculate_checksum,  # Override _checksum_utils.calculate_content_checksum
    calculate_file_checksum,  # From notebook_utils (wraps checksum_utils)
    validate_checksum,
    create_markdown_file,
    compress_diff,
    decompress_diff,
    preview_dataframe,
    print_config_banner,
    log_success,
    log_info,
    log_warning,
    log_error
)

# Also export production utilities with explicit names
parse_timestamp = timestamp_utils.parse_timestamp
calculate_content_checksum = _checksum_utils.calculate_content_checksum
verify_checksum = _checksum_utils.verify_checksum

__all__ = [
    # Original utils
    'format_timestamp',
    'parse_timestamp',
    'calculate_file_checksum',
    'calculate_content_checksum',
    'verify_checksum',
    'setup_logger',
    'setup_production_logger',
    'setup_debug_logger',

    # Notebook utilities
    'BASE_TIME',
    'get_timestamp',
    'calculate_checksum',
    'validate_checksum',
    'create_markdown_file',
    'compress_diff',
    'decompress_diff',
    'preview_dataframe',
    'print_config_banner',
    'log_success',
    'log_info',
    'log_warning',
    'log_error',
]
