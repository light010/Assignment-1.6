"""
Timestamp Utilities Module

Provides standardized timestamp formatting functions for the FAQ tracking system.
"""

from datetime import datetime
from typing import Optional


def format_timestamp(dt: Optional[datetime] = None) -> str:
    """
    Format timestamp as ISO-8601 UTC with 'Z' suffix.

    Args:
        dt: datetime object to format. If None, uses current UTC time.

    Returns:
        Formatted timestamp string in format: YYYY-MM-DDTHH:MM:SSZ

    Examples:
        >>> format_timestamp(datetime(2025, 1, 15, 10, 30, 45))
        '2025-01-15T10:30:45Z'
        >>> format_timestamp()  # Returns current time
        '2025-10-07T...'
    """
    if dt is None:
        dt = datetime.now()

    if isinstance(dt, str):
        # Parse and reformat to ensure consistency
        dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))

    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


def parse_timestamp(timestamp_str: str) -> datetime:
    """
    Parse ISO-8601 timestamp string to datetime object.

    Args:
        timestamp_str: ISO-8601 formatted timestamp string

    Returns:
        datetime object

    Examples:
        >>> parse_timestamp('2025-01-15T10:30:45Z')
        datetime(2025, 1, 15, 10, 30, 45)
    """
    return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
