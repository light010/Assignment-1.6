"""
Logging Configuration Module

Provides standardized logging setup for the FAQ tracking system.
"""

import logging
from logging.handlers import RotatingFileHandler
from typing import Optional


def setup_logger(
    name: str,
    log_file: str = 'content_tracking.log',
    level: int = logging.INFO,
    max_bytes: int = 10485760,  # 10MB
    backup_count: int = 5,
    include_console: bool = False
) -> logging.Logger:
    """
    Configure a logger with file rotation and optional console output.

    Args:
        name: Logger name (typically __name__ from calling module)
        log_file: Path to log file
        level: Logging level (default: INFO)
        max_bytes: Maximum log file size before rotation (default: 10MB)
        backup_count: Number of backup files to keep (default: 5)
        include_console: Whether to also log to console (default: False)

    Returns:
        Configured logger instance

    Examples:
        >>> logger = setup_logger(__name__)
        >>> logger.info("Processing started")
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # File handler with rotation
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # Optional console handler
    if include_console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    return logger


def setup_production_logger(name: str, log_to_file: bool = True) -> logging.Logger:
    """
    Set up logger with production-ready defaults.

    Args:
        name: Logger name
        log_to_file: Whether to log to file (default: True). If False, only console output.

    Returns:
        Configured logger for production use
    """
    if not log_to_file:
        # Console-only logger
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        logger.handlers.clear()

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        return logger

    return setup_logger(
        name=name,
        log_file='content_tracking.log',
        level=logging.INFO,
        max_bytes=10485760,  # 10MB
        backup_count=5,
        include_console=False
    )


def setup_debug_logger(name: str) -> logging.Logger:
    """
    Set up logger with debug-level logging and console output.

    Args:
        name: Logger name

    Returns:
        Configured logger for debugging
    """
    return setup_logger(
        name=name,
        log_file='content_tracking_debug.log',
        level=logging.DEBUG,
        max_bytes=10485760,
        backup_count=3,
        include_console=True
    )
