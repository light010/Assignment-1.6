"""
Checksum Utilities Module

Provides file checksum calculation utilities for content tracking.
"""

import hashlib
import logging
from typing import Optional
from pathlib import Path

logger = logging.getLogger(__name__)


def calculate_file_checksum(file_path: str) -> Optional[str]:
    """
    Calculate SHA-256 checksum of a file.

    Args:
        file_path: Path to the file to checksum

    Returns:
        Hexadecimal SHA-256 checksum string, or None if file cannot be read

    Examples:
        >>> calculate_file_checksum('/path/to/file.txt')
        'a1b2c3d4e5f6...'
    """
    try:
        with open(file_path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()
    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
        return None
    except PermissionError:
        logger.error(f"Permission denied reading file: {file_path}")
        return None
    except Exception as e:
        logger.error(f"Failed to calculate checksum for {file_path}: {e}")
        return None


def calculate_content_checksum(content: str) -> str:
    """
    Calculate SHA-256 checksum of string content.

    Args:
        content: String content to checksum

    Returns:
        Hexadecimal SHA-256 checksum string

    Examples:
        >>> calculate_content_checksum("Hello, World!")
        'dffd6021bb2bd5b0af676290809ec3a5...'
    """
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


def verify_checksum(file_path: str, expected_checksum: str) -> bool:
    """
    Verify that a file's checksum matches the expected value.

    Args:
        file_path: Path to the file to verify
        expected_checksum: Expected SHA-256 checksum

    Returns:
        True if checksums match, False otherwise

    Examples:
        >>> verify_checksum('/path/to/file.txt', 'a1b2c3...')
        True
    """
    actual_checksum = calculate_file_checksum(file_path)
    if actual_checksum is None:
        return False
    return actual_checksum == expected_checksum
