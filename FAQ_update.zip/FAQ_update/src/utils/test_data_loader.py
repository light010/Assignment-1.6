"""
Test Data Loader

Loads test data from CSV files for database initialization.
Simplifies notebook by externalizing test data.
"""

import pandas as pd
from pathlib import Path
from typing import Dict

def load_test_data() -> Dict[str, pd.DataFrame]:
    """
    Load all test data from CSV files.

    Returns:
        Dictionary containing DataFrames for each table:
        - content_repo
        - faq_questions
        - faq_answers

    CSV Files Location:
        FAQ_update/data/*.csv
    """
    # Get data directory (relative to this file)
    current_file = Path(__file__)
    project_root = current_file.parent.parent.parent
    data_dir = project_root / 'data'

    if not data_dir.exists():
        raise FileNotFoundError(f"Data directory not found: {data_dir}")

    data = {}

    # Load content_repo
    csv_path = data_dir / 'test_content_repo.csv'
    if csv_path.exists():
        data['content_repo'] = pd.read_csv(csv_path)
    else:
        raise FileNotFoundError(f"Missing: {csv_path}")

    # Load faq_questions
    csv_path = data_dir / 'test_faq_questions.csv'
    if csv_path.exists():
        data['faq_questions'] = pd.read_csv(csv_path)
    else:
        raise FileNotFoundError(f"Missing: {csv_path}")

    # Load faq_answers
    csv_path = data_dir / 'test_faq_answers.csv'
    if csv_path.exists():
        data['faq_answers'] = pd.read_csv(csv_path)
    else:
        raise FileNotFoundError(f"Missing: {csv_path}")

    # Add source metadata
    data['source'] = 'csv'

    return data


def get_data_summary(data: Dict[str, pd.DataFrame]) -> str:
    """
    Generate a summary of loaded test data.

    Args:
        data: Dictionary of DataFrames from load_test_data()

    Returns:
        Formatted string summary
    """
    summary_lines = []
    summary_lines.append(f"📊 Test Data Summary (Source: {data.get('source', 'unknown').upper()}):")

    for table_name in ['content_repo', 'faq_questions', 'faq_answers']:
        if table_name in data:
            count = len(data[table_name])
            summary_lines.append(f"  - {table_name:30} {count:3} records")

    return '\n'.join(summary_lines)