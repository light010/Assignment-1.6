"""
Notebook Utility Functions

This module provides shared utilities for Jupyter notebooks, including:
- Timestamp functions with consistent base time for testing
- Checksum calculations
- File operations
- Diff compression
- Display helpers
- Logging helpers

All notebooks should import from this module to ensure consistency.
"""

import hashlib
import gzip
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


# ============================================================================
# CONFIGURATION
# ============================================================================

# Base time for all test data (ensures consistent, realistic timeline)
# This matches the timeline used in content_edit scenarios
BASE_TIME = datetime(2025, 1, 1, 10, 0, 0)


# ============================================================================
# TIMESTAMP FUNCTIONS
# ============================================================================

def format_timestamp(dt: Optional[datetime] = None, use_base_time: bool = True) -> str:
    """
    Format timestamp as ISO-8601 UTC with 'Z' suffix.

    Format: YYYY-MM-DDTHH:MM:SS.000Z (with milliseconds for consistency)

    Args:
        dt: Datetime to format. If None, uses BASE_TIME (for consistent test data)
        use_base_time: If True and dt is None, uses BASE_TIME. If False, uses now()

    Returns:
        ISO-8601 formatted timestamp string

    Examples:
        >>> format_timestamp()  # Uses BASE_TIME for consistent test data
        '2025-01-01T10:00:00.000Z'

        >>> format_timestamp(use_base_time=False)  # Uses current time
        '2025-10-07T12:34:56.000Z'

        >>> format_timestamp(datetime(2025, 5, 15, 14, 30, 0))
        '2025-05-15T14:30:00.000Z'
    """
    if dt is None:
        dt = BASE_TIME if use_base_time else datetime.utcnow()
    return dt.strftime('%Y-%m-%dT%H:%M:%S.000Z')


def get_timestamp(days_offset: int = 0, hours_offset: int = 0,
                  base_time: Optional[datetime] = None) -> str:
    """
    Generate ISO timestamp with offset from base time.

    This is useful for creating test data with specific dates relative to BASE_TIME.

    Format: YYYY-MM-DDTHH:MM:SS.000Z

    Args:
        days_offset: Number of days to add to base time
        hours_offset: Number of hours to add to base time
        base_time: Base datetime to offset from. If None, uses BASE_TIME

    Returns:
        ISO-8601 formatted timestamp string

    Examples:
        >>> get_timestamp(0)  # Day 0: 2025-01-01
        '2025-01-01T10:00:00.000Z'

        >>> get_timestamp(1)  # Day 1: 2025-01-02
        '2025-01-02T10:00:00.000Z'

        >>> get_timestamp(0, hours_offset=5)  # 5 hours later
        '2025-01-01T15:00:00.000Z'

        >>> get_timestamp(2, 3)  # 2 days and 3 hours later
        '2025-01-03T13:00:00.000Z'
    """
    if base_time is None:
        base_time = BASE_TIME
    dt = base_time + timedelta(days=days_offset, hours=hours_offset)
    return dt.strftime('%Y-%m-%dT%H:%M:%S.000Z')


# ============================================================================
# CHECKSUM FUNCTIONS
# ============================================================================

def calculate_checksum(content: str) -> str:
    """
    Calculate SHA-256 checksum for string content.

    Args:
        content: String content to hash

    Returns:
        64-character hex string (SHA-256 hash)

    Examples:
        >>> calculate_checksum("Hello World")
        'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e'
    """
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


def calculate_file_checksum(file_path: Path) -> str:
    """
    Calculate SHA-256 checksum for file contents.

    Args:
        file_path: Path to file (Path object or string)

    Returns:
        64-character hex string (SHA-256 hash)

    Raises:
        FileNotFoundError: If file doesn't exist

    Examples:
        >>> calculate_file_checksum(Path('test.md'))
        'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    """
    if isinstance(file_path, str):
        file_path = Path(file_path)

    with open(file_path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def validate_checksum(checksum: str) -> bool:
    """
    Validate checksum format (64 hex characters).

    Args:
        checksum: Checksum string to validate

    Returns:
        True if valid SHA-256 checksum format, False otherwise

    Examples:
        >>> validate_checksum('a' * 64)
        True

        >>> validate_checksum('invalid')
        False

        >>> validate_checksum('zzzz' + 'a' * 60)  # Invalid hex
        False
    """
    if not checksum:
        return False
    if len(checksum) != 64:
        return False
    try:
        int(checksum, 16)  # Check if valid hex
        return True
    except ValueError:
        return False


# ============================================================================
# FILE OPERATIONS
# ============================================================================

def create_markdown_file(file_path: Path, content: str) -> str:
    """
    Create markdown file and return its checksum.

    Creates parent directories if they don't exist.
    Uses newline='' to preserve exact line endings (prevents \n -> \r\n conversion on Windows).

    Args:
        file_path: Path where file should be created (Path object or string)
        content: Markdown content to write

    Returns:
        SHA-256 checksum of the content (matches what will be stored on disk)

    Examples:
        >>> from pathlib import Path
        >>> test_path = Path('test_output/sample.md')
        >>> checksum = create_markdown_file(test_path, '# Hello\\nWorld')
        >>> test_path.exists()
        True
    """
    if isinstance(file_path, str):
        file_path = Path(file_path)

    file_path.parent.mkdir(parents=True, exist_ok=True)
    # Use newline='' to prevent line ending conversion on Windows
    # This ensures the file checksum matches the content checksum
    with open(file_path, 'w', encoding='utf-8', newline='') as f:
        f.write(content)
    return calculate_checksum(content)


# ============================================================================
# COMPRESSION FUNCTIONS (for content_diffs)
# ============================================================================

def compress_diff(diff_text: str) -> bytes:
    """
    Compress diff text using gzip.

    Used for storing large diffs efficiently in the database.

    Args:
        diff_text: Text diff to compress

    Returns:
        Gzip-compressed bytes

    Examples:
        >>> compressed = compress_diff("- old line\\n+ new line")
        >>> len(compressed) < len("- old line\\n+ new line")
        True
    """
    return gzip.compress(diff_text.encode('utf-8'))


def decompress_diff(compressed: bytes) -> str:
    """
    Decompress gzipped diff text.

    Args:
        compressed: Gzip-compressed bytes

    Returns:
        Decompressed text string

    Examples:
        >>> original = "- old\\n+ new"
        >>> compressed = compress_diff(original)
        >>> decompress_diff(compressed) == original
        True
    """
    return gzip.decompress(compressed).decode('utf-8')


# ============================================================================
# DISPLAY FUNCTIONS
# ============================================================================

def preview_dataframe(df: pd.DataFrame, name: str, max_rows: int = 5):
    """
    Display preview of dataframe with consistent formatting.

    Shows emoji icon, row count, and formatted table output.

    Args:
        df: DataFrame to preview
        name: Display name for the dataframe
        max_rows: Maximum number of rows to display (default: 5)

    Examples:
        >>> df = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        >>> preview_dataframe(df, "Test Data", max_rows=2)

        📄 Test Data Preview (first 2 of 2 rows):
        --------------------------------------------------------------------------------
         a  b
         1  3
         2  4
        --------------------------------------------------------------------------------
    """
    print(f"\n📄 {name} Preview (first {min(max_rows, len(df))} of {len(df)} rows):")
    print("-" * 80)
    if len(df) > 0:
        print(df.head(max_rows).to_string(index=False))
    else:
        print("  (No records)")
    print("-" * 80)


# ============================================================================
# LOGGING FUNCTIONS
# ============================================================================

def log_success(message: str):
    """
    Log success message with ✅ icon.

    Args:
        message: Success message to display
    """
    print(f"✅ {message}")


def log_info(message: str):
    """
    Log info message with ℹ️ icon.

    Args:
        message: Info message to display
    """
    print(f"ℹ️  {message}")


def log_warning(message: str):
    """
    Log warning message with ⚠️ icon.

    Args:
        message: Warning message to display
    """
    print(f"⚠️  {message}")


def log_error(message: str):
    """
    Log error message with ❌ icon.

    Args:
        message: Error message to display
    """
    print(f"❌ {message}")


# ============================================================================
# CONFIGURATION DISPLAY
# ============================================================================

def print_config_banner(title: str, db_path: Path, **kwargs):
    """
    Print consistent configuration banner for notebooks.

    Args:
        title: Notebook title
        db_path: Path to database
        **kwargs: Additional key-value pairs to display

    Examples:
        >>> print_config_banner(
        ...     "Setup Tables",
        ...     Path("databases/faq.db"),
        ...     test_data_dir=Path("docs/test_data")
        ... )
        ================================================================================
        🚀 Setup Tables
        ================================================================================

        📁 Database: /path/to/databases/faq.db
        📁 test_data_dir: /path/to/docs/test_data
        ================================================================================
    """
    print("=" * 80)
    print(f"🚀 {title}")
    print("=" * 80)
    print(f"\n📁 Database: {db_path.absolute()}")

    for key, value in kwargs.items():
        formatted_key = key.replace('_', ' ').title()
        if isinstance(value, Path):
            print(f"📁 {formatted_key}: {value.absolute()}")
        else:
            print(f"📁 {formatted_key}: {value}")

    print("=" * 80)


# ============================================================================
# MODULE INFO
# ============================================================================

__all__ = [
    # Constants
    'BASE_TIME',

    # Timestamp functions
    'format_timestamp',
    'get_timestamp',

    # Checksum functions
    'calculate_checksum',
    'calculate_file_checksum',
    'validate_checksum',

    # File operations
    'create_markdown_file',

    # Compression
    'compress_diff',
    'decompress_diff',

    # Display
    'preview_dataframe',
    'print_config_banner',

    # Logging
    'log_success',
    'log_info',
    'log_warning',
    'log_error',
]


if __name__ == '__main__':
    # Test the utilities
    print("Testing notebook_utils module...")

    # Test timestamps
    print("\n1. Timestamp Tests:")
    print(f"   Base time: {format_timestamp()}")
    print(f"   Day 0: {get_timestamp(0)}")
    print(f"   Day 1: {get_timestamp(1)}")
    print(f"   Day 2, Hour 5: {get_timestamp(2, 5)}")

    # Test checksums
    print("\n2. Checksum Tests:")
    test_content = "Test content"
    checksum = calculate_checksum(test_content)
    print(f"   Checksum: {checksum[:32]}...")
    print(f"   Valid: {validate_checksum(checksum)}")
    print(f"   Invalid checksum: {validate_checksum('invalid')}")

    # Test compression
    print("\n3. Compression Tests:")
    test_diff = "- Old line 1\n- Old line 2\n+ New line 1\n+ New line 2\n+ New line 3"
    compressed = compress_diff(test_diff)
    decompressed = decompress_diff(compressed)
    print(f"   Original size: {len(test_diff)} bytes")
    print(f"   Compressed size: {len(compressed)} bytes")
    print(f"   Compression ratio: {len(compressed)/len(test_diff)*100:.1f}%")
    print(f"   Decompression works: {decompressed == test_diff}")

    # Test logging
    print("\n4. Logging Tests:")
    log_success("Success message")
    log_info("Info message")
    log_warning("Warning message")
    log_error("Error message")

    # Test dataframe preview
    print("\n5. Display Tests:")
    test_df = pd.DataFrame({
        'id': [1, 2, 3],
        'name': ['Alice', 'Bob', 'Charlie'],
        'value': [100, 200, 300]
    })
    preview_dataframe(test_df, "Test DataFrame", max_rows=2)

    print("\n✅ All tests passed!")
