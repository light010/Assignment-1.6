# Granular FAQ Impact Detection Algorithm - V8

## Overview
This algorithm performs **selective FAQ invalidation** by analyzing which specific FAQs are affected by content changes, rather than blindly invalidating all FAQs.

## Problem Solved
**Before (V7):**
- Page has 10 FAQs
- Tiny edit: "10 days" → "12 days"
- Result: Invalidate ALL 10 FAQs, regenerate ALL 10 ❌

**After (V8):**
- Page has 10 FAQs
- Tiny edit: "10 days" → "12 days"
- Impact analysis: Only Q1 mentions "10 days"
- Result: Invalidate ONLY Q1, regenerate ONLY Q1 ✅
- **Saved: 9 FAQs from unnecessary regeneration!**

---

## Algorithm Steps

### Phase 1: Content Change Detection (PURE CHECKSUM-CENTRIC)

```python
def detect_content_changes(file_name, detection_run_id, since_date):
    """
    Detect content changes using PURE CHECKSUM COMPARISON (no location dependency).

    Strategy:
    1. Get previous checksums for THIS FILE only (not global)
    2. Get current checksums for THIS FILE
    3. Find new checksums (not in previous set)
    4. Find deleted checksums (not in current set)
    5. Use SIMILARITY MATCHING to link new → deleted (modified content)

    Returns list of changes with old/new checksums and similarity scores.
    """

    # Step 1: Extract CURRENT checksums from file system
    current_checksums_data = extract_checksums_from_file(file_name)
    # Returns: {checksum: {'text': '...', 'markdown_path': '...', 'page_num': 42}, ...}

    current_checksums = set(current_checksums_data.keys())

    # Step 2: Query PREVIOUS checksums for THIS FILE (scoped, not global!)
    previous_checksums_data = db.execute("""
        SELECT DISTINCT
            cc.content_checksum,
            cc.content_text,
            cl.page_number
        FROM content_checksums cc
        INNER JOIN content_locations cl ON cc.content_checksum = cl.content_checksum
        WHERE cl.file_name = ?
          AND cc.created_at < ?
          AND cl.is_current_location = TRUE
          AND cl.valid_until IS NULL
    """, [file_name, since_date]).fetchall()

    previous_checksums = {row['content_checksum']: row for row in previous_checksums_data}
    previous_checksums_set = set(previous_checksums.keys())

    # Step 3: Set operations (checksums only, NO location comparison!)
    new_checksums = current_checksums - previous_checksums_set
    deleted_checksums = previous_checksums_set - current_checksums
    unchanged_checksums = current_checksums & previous_checksums_set

    print(f"Checksum analysis for {file_name}:")
    print(f"  Current: {len(current_checksums)} checksums")
    print(f"  Previous: {len(previous_checksums_set)} checksums")
    print(f"  New: {len(new_checksums)} checksums")
    print(f"  Deleted: {len(deleted_checksums)} checksums")
    print(f"  Unchanged: {len(unchanged_checksums)} checksums")

    # Step 4: SIMILARITY MATCHING (N × M where N and M are small)
    # For each NEW checksum, find best match in DELETED checksums
    changes = []

    # Track which deleted checksums have been matched (to detect splits/merges)
    deleted_matched = {}  # {deleted_checksum: [(new_checksum, score), ...]}
    new_matched = {}      # {new_checksum: (deleted_checksum, score)}

    if new_checksums and deleted_checksums:
        print(f"  Running similarity matching ({len(new_checksums)} × {len(deleted_checksums)} = {len(new_checksums) * len(deleted_checksums)} comparisons)...")

        for new_checksum in new_checksums:
            new_text = current_checksums_data[new_checksum]['text']

            best_match = None
            best_score = 0.0

            for deleted_checksum in deleted_checksums:
                deleted_text = previous_checksums[deleted_checksum]['content_text']

                # Compute similarity (hybrid method for robustness)
                similarity = compute_similarity_hybrid(new_text, deleted_text)

                if similarity > best_score:
                    best_score = similarity
                    best_match = deleted_checksum

            # Decision threshold: 0.8 (80% similarity)
            if best_score >= 0.8:
                # This is MODIFIED content
                new_matched[new_checksum] = (best_match, best_score)

                if best_match not in deleted_matched:
                    deleted_matched[best_match] = []
                deleted_matched[best_match].append((new_checksum, best_score))

                changes.append({
                    'old_checksum': best_match,
                    'new_checksum': new_checksum,
                    'old_text': previous_checksums[best_match]['content_text'],
                    'new_text': new_text,
                    'change_type': 'modified_content',
                    'similarity_score': best_score,
                    'similarity_method': 'hybrid',
                    'page_number': current_checksums_data[new_checksum].get('page_num')  # For logging only
                })
            else:
                # No good match - this is NEW content
                changes.append({
                    'old_checksum': None,
                    'new_checksum': new_checksum,
                    'old_text': None,
                    'new_text': new_text,
                    'change_type': 'new_content',
                    'similarity_score': 0.0,
                    'page_number': current_checksums_data[new_checksum].get('page_num')
                })
    else:
        # No similarity matching needed
        for new_checksum in new_checksums:
            changes.append({
                'old_checksum': None,
                'new_checksum': new_checksum,
                'old_text': None,
                'new_text': current_checksums_data[new_checksum]['text'],
                'change_type': 'new_content',
                'similarity_score': 0.0,
                'page_number': current_checksums_data[new_checksum].get('page_num')
            })

    # Step 5: Handle DELETED checksums (not matched to any new checksum)
    for deleted_checksum in deleted_checksums:
        if deleted_checksum not in deleted_matched:
            # Truly DELETED content (no similar new content found)
            changes.append({
                'old_checksum': deleted_checksum,
                'new_checksum': None,
                'old_text': previous_checksums[deleted_checksum]['content_text'],
                'new_text': None,
                'change_type': 'deleted_content',
                'similarity_score': 0.0,
                'page_number': previous_checksums[deleted_checksum].get('page_number')
            })

    # Step 6: EDGE CASE - Multiple new checksums match same deleted checksum
    # This indicates content SPLIT (one page became multiple pages)
    for deleted_checksum, matches in deleted_matched.items():
        if len(matches) > 1:
            print(f"  ⚠️  Content split detected: {deleted_checksum[:8]}... → {len(matches)} new checksums")
            # All new checksums flagged for FAQ regeneration (already in changes list)

    print(f"  Changes detected: {len(changes)}")

    return changes

---

### Phase 1.5: Similarity Computation Methods (NEW in V8)

#### Overview of Similarity Methods

For content with **dates, numbers, words, and structure**, we need robust similarity matching.

| Method | Speed | Accuracy | Best For | Issues with Dates/Numbers |
|--------|-------|----------|----------|---------------------------|
| **Jaccard** | ⚡ Fast | Medium | Quick filtering | ❌ Treats "10" and "12" as completely different tokens |
| **BM25** | ⚡ Fast | Medium-High | Keyword matching | ❌ Sensitive to stopwords, ignores semantic meaning |
| **Levenshtein** | 🐢 Slow | High | Typos, small edits | ✅ Good for "10"→"12" but slow for long text |
| **Difflib** | ⚡⚡ Very Fast | High | Word-level changes | ✅ Good balance, Python built-in |
| **TF-IDF Cosine** | ⚡ Fast | High | Semantic weight | ⚠️ Numbers treated as terms (OK for our use) |
| **Embedding Cosine** | 🐢 Slow | Very High | Semantic understanding | ✅ Best accuracy but requires model |

#### Recommended: Hybrid Multi-Level Approach

```python
def compute_similarity_hybrid(text1, text2):
    """
    Hybrid similarity for robustness across different content types.

    Strategy:
    - Level 1: Jaccard (fast filter to eliminate obvious non-matches)
    - Level 2: Difflib (word-level similarity, handles small edits well)
    - Level 3: TF-IDF Cosine (semantic weighting, emphasizes important terms)

    Returns: Combined similarity score (0.0 to 1.0)
    """
    import difflib
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import re

    # Preprocessing: Normalize whitespace
    text1_clean = ' '.join(text1.split())
    text2_clean = ' '.join(text2.split())

    # --- LEVEL 1: Jaccard Similarity (Fast Filter) ---
    # Token-based overlap (good for catching major differences)
    tokens1 = set(text1_clean.lower().split())
    tokens2 = set(text2_clean.lower().split())

    if not tokens1 or not tokens2:
        return 0.0

    jaccard = len(tokens1 & tokens2) / len(tokens1 | tokens2)

    # Early exit: If Jaccard < 0.3, texts are too different
    if jaccard < 0.3:
        return 0.0  # Save time, skip expensive methods

    # --- LEVEL 2: Difflib SequenceMatcher (Word-level Similarity) ---
    # Handles small edits well: "10 days" → "12 days" gets high score
    # Python built-in, very fast
    difflib_ratio = difflib.SequenceMatcher(None, text1_clean, text2_clean).ratio()

    # --- LEVEL 3: TF-IDF Cosine Similarity (Semantic Weighting) ---
    # Gives more weight to important terms (policy keywords) vs common words
    try:
        vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words='english',  # Remove common words
            max_features=1000,
            ngram_range=(1, 2)  # Unigrams and bigrams
        )

        tfidf_matrix = vectorizer.fit_transform([text1_clean, text2_clean])
        tfidf_cosine = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
    except:
        # Fallback if TF-IDF fails (e.g., text too short)
        tfidf_cosine = difflib_ratio

    # --- LEVEL 4 (Optional): Embedding-based Similarity ---
    # Most accurate but slowest - uncomment if accuracy is critical
    # embedding_cosine = compute_embedding_similarity(text1_clean, text2_clean)

    # --- Weighted Combination ---
    # Adjust weights based on your validation results
    similarity = (
        jaccard * 0.2 +         # Fast filter contribution
        difflib_ratio * 0.5 +   # Word-level changes (most important for "10"→"12")
        tfidf_cosine * 0.3      # Semantic weighting (policy keywords)
    )

    return similarity


def compute_jaccard(text1, text2):
    """Jaccard similarity between token sets."""
    tokens1 = set(text1.lower().split())
    tokens2 = set(text2.lower().split())

    if not tokens1 or not tokens2:
        return 0.0

    intersection = tokens1 & tokens2
    union = tokens1 | tokens2

    return len(intersection) / len(union)


def compute_embedding_similarity(text1, text2):
    """
    Semantic similarity using sentence embeddings.
    OPTIONAL - Only use if maximum accuracy is needed.

    Requires: pip install sentence-transformers
    """
    try:
        from sentence_transformers import SentenceTransformer, util

        # Load model (cache this globally in production!)
        model = SentenceTransformer('all-MiniLM-L6-v2')  # Fast, 384-dim embeddings

        # Encode texts
        emb1 = model.encode(text1, convert_to_tensor=True)
        emb2 = model.encode(text2, convert_to_tensor=True)

        # Cosine similarity
        similarity = util.cos_sim(emb1, emb2).item()

        return similarity
    except Exception as e:
        print(f"Warning: Embedding similarity failed: {e}")
        return 0.0  # Fallback


def compute_bm25_similarity(text1, text2):
    """
    BM25 similarity score.
    Good for keyword-based matching but less robust for our use case.

    Requires: pip install rank-bm25
    """
    try:
        from rank_bm25 import BM25Okapi

        # Tokenize
        tokens1 = text1.lower().split()
        tokens2 = text2.lower().split()

        # Build BM25 index for text1
        bm25 = BM25Okapi([tokens1])

        # Score text2 against text1
        score = bm25.get_scores(tokens2)[0]

        # Normalize (BM25 scores are unbounded, normalize to 0-1)
        max_possible = len(tokens2) * 2.0  # Rough upper bound
        normalized_score = min(score / max_possible, 1.0)

        return normalized_score
    except:
        return 0.0
```

#### Why This Hybrid Approach Works for Your Content

**Example 1: Numeric Change**
```
Before: "Employees receive 10 sick days per year"
After:  "Employees receive 12 sick days per year"

Jaccard: 0.875 (7/8 tokens match)
Difflib: 0.93 (only "10"→"12" different)
TF-IDF: 0.91 (high similarity, policy terms match)

Combined: 0.90 ✅ Strong match! (Modified content detected)
```

**Example 2: Date Change**
```
Before: "Policy effective January 1, 2025"
After:  "Policy effective February 1, 2025"

Jaccard: 0.80 (4/5 tokens match)
Difflib: 0.88 (only "January"→"February")
TF-IDF: 0.85

Combined: 0.85 ✅ Strong match!
```

**Example 3: Major Rewrite (NOT a modification)**
```
Before: "Sick leave policy for full-time employees"
After:  "Vacation policy for part-time contractors"

Jaccard: 0.33 (only "policy", "for" match)
Difflib: 0.45 (many words different)
TF-IDF: 0.25 (different key terms)

Combined: 0.34 ❌ Below 0.8 threshold → Treated as NEW content (correct!)
```

#### Performance Considerations

```python
# For a file with 100 pages, 5 new, 5 deleted:
# - Comparisons: 5 × 5 = 25
# - Time per comparison (hybrid): ~10ms
# - Total time: 25 × 10ms = 250ms ✅ Very fast!

# For a file with 1000 pages, 50 new, 50 deleted:
# - Comparisons: 50 × 50 = 2500
# - Total time: 2500 × 10ms = 25 seconds ✅ Acceptable
```

#### Tuning Recommendations

**Similarity Threshold:**
- **0.85+**: Very strict (only obvious modifications) - Use if you want minimal false positives
- **0.80-0.85**: Balanced (recommended starting point) ⭐
- **0.70-0.80**: Loose (more matches, but may have false positives)

**Adjust based on validation:**
```python
# Test on your historical data
# Count false positives: New content incorrectly marked as modified
# Count false negatives: Modified content incorrectly marked as new

# Adjust threshold to minimize false positives (higher priority)
```

---

### Phase 2: Compute Content Diffs (NEW in V8)

```python
def compute_content_diff(old_text, new_text):
    """
    Compute granular diff between old and new content.
    Uses multiple algorithms for robust change detection.
    """
    import difflib
    from diff_match_patch import diff_match_patch

    # Method 1: Line-based diff (difflib)
    differ = difflib.Differ()
    line_diff = list(differ.compare(
        old_text.splitlines(),
        new_text.splitlines()
    ))

    # Method 2: Word-level diff (diff-match-patch)
    dmp = diff_match_patch()
    word_diffs = dmp.diff_main(old_text, new_text)
    dmp.diff_cleanupSemantic(word_diffs)

    # Extract changes
    chunks = []
    changed_phrases = set()

    for i, (op, text) in enumerate(word_diffs):
        if op != 0:  # Not equal (either insert or delete)
            chunks.append({
                'type': 'added' if op == 1 else 'deleted' if op == -1 else 'modified',
                'text': text,
                'position': i
            })

            # Extract meaningful phrases (not single words)
            phrases = extract_meaningful_phrases(text)
            changed_phrases.update(phrases)

    # Compute statistics
    additions = sum(1 for op, _ in word_diffs if op == 1)
    deletions = sum(1 for op, _ in word_diffs if op == -1)
    total_words = len(new_text.split())
    change_percentage = ((additions + deletions) / total_words * 100) if total_words > 0 else 0

    # Detect semantic changes
    contains_numeric_changes = detect_numeric_changes(chunks)
    contains_date_changes = detect_date_changes(chunks)
    contains_policy_changes = detect_policy_keywords(chunks)
    contains_eligibility_changes = detect_eligibility_terms(chunks)

    return {
        'chunks': chunks,
        'changed_phrases': list(changed_phrases),
        'additions_count': additions,
        'deletions_count': deletions,
        'change_percentage': change_percentage,
        'contains_numeric_changes': contains_numeric_changes,
        'contains_date_changes': contains_date_changes,
        'contains_policy_changes': contains_policy_changes,
        'contains_eligibility_changes': contains_eligibility_changes,
        'diff_data': {
            'word_diffs': word_diffs,
            'line_diffs': line_diff
        }
    }

def extract_meaningful_phrases(text, min_words=2, max_words=5):
    """Extract n-grams (2-5 words) from text."""
    from nltk import ngrams
    words = text.split()
    phrases = []

    for n in range(min_words, min(max_words + 1, len(words) + 1)):
        phrases.extend([' '.join(gram) for gram in ngrams(words, n)])

    return phrases

def detect_numeric_changes(chunks):
    """Check if any chunks contain numeric changes."""
    import re
    for chunk in chunks:
        if re.search(r'\d+', chunk['text']):
            return True
    return False

def detect_date_changes(chunks):
    """Check if chunks contain date-related changes."""
    date_patterns = [
        r'\d{1,2}/\d{1,2}/\d{2,4}',  # MM/DD/YYYY
        r'\d{4}-\d{2}-\d{2}',         # YYYY-MM-DD
        r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2}',
        r'\d{1,2}\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)'
    ]
    import re
    for chunk in chunks:
        for pattern in date_patterns:
            if re.search(pattern, chunk['text'], re.IGNORECASE):
                return True
    return False

def detect_policy_keywords(chunks):
    """Check if policy-related keywords changed."""
    policy_keywords = ['must', 'shall', 'required', 'mandatory', 'prohibited', 'allowed', 'eligible']
    for chunk in chunks:
        if any(keyword in chunk['text'].lower() for keyword in policy_keywords):
            return True
    return False

def detect_eligibility_terms(chunks):
    """Check if eligibility terms changed."""
    eligibility_terms = ['all employees', 'full-time', 'part-time', 'eligible', 'qualified', 'enrolled']
    for chunk in chunks:
        if any(term in chunk['text'].lower() for term in eligibility_terms):
            return True
    return False
```

---

### Phase 3: Compute FAQ Impact Scores (CORE INNOVATION)

```python
def analyze_faq_impact(change, diff_data, detection_run_id):
    """
    Analyze which FAQs are affected by this specific content change.
    Uses multiple scoring methods for robustness.
    """

    old_checksum = change['old_checksum']
    new_checksum = change['new_checksum']

    # Step 1: Get all FAQs linked to the OLD checksum
    # ⚠️ NOTE: This Phase 3 example shows a SIMPLIFIED query for illustration.
    # The production-ready version is in get_faqs_for_checksum() (see line 530).
    #
    # BUGS IN THE ORIGINAL QUERY (NOW FIXED BELOW):
    # Bug 1: LEFT JOIN + WHERE filter violates LEFT JOIN semantics
    #        - WHERE qs.is_valid = TRUE filters OUT rows where qs is NULL
    #        - This silently drops FAQs without question sources
    # Bug 2: Missing asrc.is_valid = TRUE (asymmetric validation)
    #        - Question sources filtered by is_valid but answer sources aren't
    #        - Returns stale/invalidated answer sources!
    # Bug 3: OR logic doesn't track impact type
    #        - Cannot distinguish "Q uses checksum" vs "A uses checksum" vs "both"
    #        - Loses granular tracking for selective invalidation
    #
    # CORRECTED QUERY (use UNION to separate question vs answer impacts):
    faqs = db.execute("""
        -- Question-impacted FAQs
        SELECT DISTINCT
            q.question_id,
            q.question_text,
            a.answer_id,
            a.answer_text,
            'question' as impact_type,
            qs.source_id as impacted_source_id
        FROM faq_questions q
        INNER JOIN faq_question_sources qs
            ON q.question_id = qs.question_id
            AND qs.is_valid = TRUE  -- Only valid sources
        LEFT JOIN faq_answers a
            ON q.question_id = a.question_id
            AND a.status = 'active'
        WHERE qs.content_checksum = ?
          AND q.status = 'active'

        UNION ALL

        -- Answer-impacted FAQs
        SELECT DISTINCT
            q.question_id,
            q.question_text,
            a.answer_id,
            a.answer_text,
            'answer' as impact_type,
            asrc.source_id as impacted_source_id
        FROM faq_questions q
        INNER JOIN faq_answers a
            ON q.question_id = a.question_id
            AND a.status = 'active'
        INNER JOIN faq_answer_sources asrc
            ON a.answer_id = asrc.answer_id
            AND asrc.is_valid = TRUE  -- Symmetric validation!
        WHERE asrc.content_checksum = ?
          AND q.status = 'active'
    """, [old_checksum, old_checksum]).fetchall()

    if not faqs:
        return []  # No FAQs to analyze

    # Step 2: For each FAQ, compute impact scores
    impact_results = []

    for faq in faqs:
        question_text = faq['question_text']
        answer_text = faq['answer_text']

        # Combine question + answer for analysis
        faq_full_text = f"{question_text} {answer_text}"

        # Score 1: Lexical Overlap (Jaccard similarity with changed phrases)
        lexical_score = compute_lexical_overlap(
            faq_full_text,
            diff_data['changed_phrases']
        )

        # Score 2: Keyword Matching (how many changed phrases appear in FAQ)
        keyword_score = compute_keyword_match(
            faq_full_text,
            diff_data['changed_phrases']
        )

        # Score 3: Semantic Similarity (if embeddings available)
        semantic_score = compute_semantic_similarity(
            faq_full_text,
            diff_data['chunks']
        )

        # Score 4: Phrase Matching (exact phrase matches)
        phrase_score, matched_phrases = compute_phrase_match(
            faq_full_text,
            diff_data['changed_phrases']
        )

        # Combine scores (weighted average)
        overall_score = (
            lexical_score * 0.3 +
            keyword_score * 0.3 +
            semantic_score * 0.2 +
            phrase_score * 0.2
        )

        # Decision: Is FAQ affected?
        # Use multiple thresholds for different impact levels
        if overall_score >= 0.7:
            is_affected = True
            impact_level = 'high'
            impact_reason = f"FAQ text strongly overlaps with changes (score: {overall_score:.2f}). Matched phrases: {matched_phrases}"
        elif overall_score >= 0.4:
            is_affected = True
            impact_level = 'medium'
            impact_reason = f"FAQ text moderately overlaps with changes (score: {overall_score:.2f}). Review recommended."
        elif overall_score >= 0.2:
            is_affected = False  # Below threshold, but flag for review
            impact_level = 'low'
            impact_reason = f"Minimal overlap (score: {overall_score:.2f}). Likely unaffected but flagged for review."
        else:
            is_affected = False
            impact_level = 'none'
            impact_reason = f"No significant overlap with changes (score: {overall_score:.2f})"

        # Special case: If diff contains numeric/policy changes and FAQ mentions same terms
        if diff_data['contains_numeric_changes'] or diff_data['contains_policy_changes']:
            if has_critical_overlap(faq_full_text, diff_data):
                is_affected = True
                impact_level = 'high'
                impact_reason = f"Critical content change detected (numeric/policy). {impact_reason}"

        impact_results.append({
            'question_id': faq['question_id'],
            'answer_id': faq['answer_id'],
            'overall_impact_score': overall_score,
            'lexical_overlap_score': lexical_score,
            'keyword_match_score': keyword_score,
            'semantic_similarity_score': semantic_score,
            'phrase_match_score': phrase_score,
            'is_affected': is_affected,
            'impact_level': impact_level,
            'impact_reason': impact_reason,
            'matched_changes': {
                'matched_phrases': matched_phrases,
                'question_matches': find_matches(question_text, diff_data['changed_phrases']),
                'answer_matches': find_matches(answer_text, diff_data['changed_phrases'])
            }
        })

    return impact_results

def compute_lexical_overlap(faq_text, changed_phrases):
    """Jaccard similarity between FAQ tokens and changed phrases."""
    faq_tokens = set(faq_text.lower().split())
    changed_tokens = set(' '.join(changed_phrases).lower().split())

    if not faq_tokens or not changed_tokens:
        return 0.0

    intersection = faq_tokens & changed_tokens
    union = faq_tokens | changed_tokens

    return len(intersection) / len(union)

def compute_keyword_match(faq_text, changed_phrases):
    """Count how many changed phrases appear in FAQ."""
    faq_lower = faq_text.lower()
    matches = sum(1 for phrase in changed_phrases if phrase.lower() in faq_lower)

    if not changed_phrases:
        return 0.0

    return matches / len(changed_phrases)

def compute_semantic_similarity(faq_text, diff_chunks):
    """
    Compute semantic similarity using embeddings.
    Requires embedding model (e.g., sentence-transformers).
    """
    try:
        from sentence_transformers import SentenceTransformer, util
        model = SentenceTransformer('all-MiniLM-L6-v2')

        # Embed FAQ text
        faq_embedding = model.encode(faq_text, convert_to_tensor=True)

        # Embed changed text chunks
        changed_texts = [chunk['text'] for chunk in diff_chunks]
        if not changed_texts:
            return 0.0

        chunk_embeddings = model.encode(changed_texts, convert_to_tensor=True)

        # Compute max similarity (FAQ to any changed chunk)
        similarities = util.cos_sim(faq_embedding, chunk_embeddings)
        max_similarity = float(similarities.max())

        return max_similarity
    except:
        # Fallback if embeddings not available
        return 0.0

def compute_phrase_match(faq_text, changed_phrases):
    """Find exact phrase matches in FAQ."""
    faq_lower = faq_text.lower()
    matched = [phrase for phrase in changed_phrases if phrase.lower() in faq_lower]

    if not changed_phrases:
        return 0.0, []

    score = len(matched) / len(changed_phrases)
    return score, matched

def find_matches(text, phrases):
    """Find which phrases appear in text."""
    text_lower = text.lower()
    return [phrase for phrase in phrases if phrase.lower() in text_lower]

def has_critical_overlap(faq_text, diff_data):
    """Check if FAQ contains critical terms that changed."""
    import re

    # Extract numbers from diff
    diff_numbers = set()
    for chunk in diff_data['chunks']:
        numbers = re.findall(r'\d+', chunk['text'])
        diff_numbers.update(numbers)

    # Check if FAQ contains same numbers
    faq_numbers = set(re.findall(r'\d+', faq_text))

    return bool(diff_numbers & faq_numbers)
```

#### Edge Cases Handled by the Corrected Query

The UNION-based query (lines 546-584) correctly handles these edge cases:

1. **FAQ uses same source for both Q&A**
   - Returns as TWO rows: one with `impact_type='question'`, one with `impact_type='answer'`
   - Downstream aggregation combines them into single FAQ record with both impacts tracked

2. **Multiple sources per FAQ component**
   - UNION ALL preserves all source relationships
   - `impacted_source_id` column lists all affected sources
   - Enables precise source-level invalidation

3. **Question without answer**
   - `answer_id` and `answer_text` return as NULL
   - Still tracked for impact analysis (question-only FAQ)

4. **Inactive answers**
   - Excluded via `a.status = 'active'` filter in both CTEs
   - Prevents analysis of deprecated FAQ versions

5. **Invalid/stale sources**
   - Symmetric `is_valid = TRUE` filters in both CTEs
   - Prevents returning FAQs with already-invalidated sources

**Production Note:** The `get_faqs_for_checksum()` function (line 1097) implements this exact corrected query and is used by the FAQ-centric workflow to avoid the bugs shown here.

---

### Phase 4: Store Results in Database

```python
def store_impact_analysis(change_id, diff_id, impact_results, detection_run_id):
    """Store impact analysis results in database."""

    affected_count = sum(1 for r in impact_results if r['is_affected'])

    # Update change log with impact counts
    db.execute("""
        UPDATE content_change_log
        SET affected_question_count = ?,
            affected_answer_count = ?
        WHERE change_id = ?
    """, [affected_count, affected_count, change_id])

    # Insert impact analysis for each FAQ
    for result in impact_results:
        db.execute("""
            INSERT INTO faq_impact_analysis (
                change_id,
                diff_id,
                question_id,
                answer_id,
                overall_impact_score,
                lexical_overlap_score,
                keyword_match_score,
                semantic_similarity_score,
                phrase_match_score,
                is_affected,
                impact_level,
                confidence,
                impact_reason,
                matched_changes,
                analysis_method,
                analysis_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            change_id,
            diff_id,
            result['question_id'],
            result['answer_id'],
            result['overall_impact_score'],
            result['lexical_overlap_score'],
            result['keyword_match_score'],
            result['semantic_similarity_score'],
            result['phrase_match_score'],
            result['is_affected'],
            result['impact_level'],
            0.8,  # Confidence (could be computed)
            result['impact_reason'],
            json.dumps(result['matched_changes']),
            'hybrid',  # lexical + semantic + keyword
            'v1.0'
        ])
```

---

### Phase 5: Selective Invalidation

```python
def selective_invalidate_faqs(change_id):
    """
    Invalidate ONLY the FAQs that are affected by this change.
    Keep unaffected FAQs valid!
    """

    # Get affected FAQs from impact analysis
    affected_faqs = db.execute("""
        SELECT question_id, answer_id
        FROM faq_impact_analysis
        WHERE change_id = ?
          AND is_affected = TRUE
    """, [change_id]).fetchall()

    for faq in affected_faqs:
        # Invalidate question sources
        db.execute("""
            UPDATE faq_question_sources
            SET is_valid = FALSE,
                valid_until = CURRENT_TIMESTAMP(),
                invalidation_reason = 'selective_impact',
                invalidated_by_change_id = ?
            WHERE question_id = ?
              AND is_valid = TRUE
        """, [change_id, faq['question_id']])

        # Invalidate answer sources
        if faq['answer_id']:
            db.execute("""
                UPDATE faq_answer_sources
                SET is_valid = FALSE,
                    valid_until = CURRENT_TIMESTAMP(),
                    invalidation_reason = 'selective_impact',
                    invalidated_by_change_id = ?
                WHERE answer_id = ?
                  AND is_valid = TRUE
            """, [change_id, faq['answer_id']])

    # Audit log
    db.execute("""
        INSERT INTO faq_audit_log (
            table_name,
            action,
            change_reason,
            detection_run_id
        ) VALUES (?, ?, ?, ?)
    """, [
        'faq_answer_sources',
        'SELECTIVE_INVALIDATE',
        f'Selective invalidation: {len(affected_faqs)} FAQs affected by change_id {change_id}',
        detection_run_id
    ])

    return len(affected_faqs)
```

---

## Complete Workflow (WITH ISSUE 5.3 FIX)

### ⚠️ CRITICAL FIX: FAQ-Centric Deduplication

**Problem Solved:** If a single FAQ sources from multiple checksums that all change in one run, the original algorithm analyzed that FAQ multiple times, creating **duplicate and conflicting** impact analysis records.

**Solution:** Collect all changes first, then build FAQ→Changes mapping, analyze each FAQ exactly **once** with all its related changes aggregated.

```python
def run_granular_faq_update_detection(file_name, detection_run_id):
    """
    Complete workflow for granular FAQ impact detection.

    FIXED (Issue 5.3): FAQ-centric processing with deduplication.
    - Analyzes each FAQ exactly once per detection run
    - Aggregates impact across all changes affecting same FAQ
    - Prevents duplicate/conflicting analysis records
    """

    print(f"Starting granular detection for {file_name}...")

    # ============================================================
    # PHASE 1: Detect ALL content changes
    # ============================================================
    changes = detect_content_changes(file_name, detection_run_id, since_date)
    print(f"Found {len(changes)} changes")

    if not changes:
        print("No changes detected")
        return {'changes_detected': 0, 'faqs_analyzed': 0, 'faqs_affected': 0}

    # ============================================================
    # PHASE 2: Store changes and compute diffs
    # ============================================================
    change_records = []

    for change in changes:
        if change['change_type'] != 'modified_content':
            continue  # Only analyze modifications

        # Compute diff
        diff_data = compute_content_diff(change['old_text'], change['new_text'])

        # Store change + diff in database
        change_id = store_change_log(change, diff_data, detection_run_id)
        diff_id = store_content_diff(change_id, diff_data)

        print(f"  Change {change_id}: {diff_data['change_percentage']:.1f}% changed")
        print(f"    Phrases: {diff_data['changed_phrases'][:3]}...")

        # Collect change records for FAQ mapping
        change_records.append({
            'change_id': change_id,
            'diff_id': diff_id,
            'old_checksum': change['old_checksum'],
            'new_checksum': change['new_checksum'],
            'diff_data': diff_data,
            'change': change
        })

    print(f"\nStored {len(change_records)} change records")

    # ============================================================
    # PHASE 3: Build FAQ → Changes Mapping (DEDUPLICATION FIX)
    # ============================================================
    # This is the KEY FIX: Group changes by affected FAQ BEFORE analysis
    faq_to_changes = build_faq_change_mapping(change_records)

    total_faqs = len(faq_to_changes)
    multi_change_faqs = sum(1 for f in faq_to_changes.values() if len(f['changes']) > 1)

    print(f"\n📊 FAQ Analysis Scope:")
    print(f"  Unique FAQs affected: {total_faqs}")
    print(f"  FAQs with multiple changes: {multi_change_faqs}")
    if multi_change_faqs > 0:
        print(f"  ✅ Deduplication will save {multi_change_faqs} redundant analyses!")

    # ============================================================
    # PHASE 4: Analyze Each FAQ ONCE (Aggregated Impact)
    # ============================================================
    total_faqs_analyzed = 0
    total_faqs_affected = 0
    total_faqs_saved = 0

    for faq_key, faq_data in faq_to_changes.items():
        question_id, answer_id = faq_key
        related_changes = faq_data['changes']

        # Compute aggregated impact (considers ALL changes together)
        aggregated_impact = compute_aggregated_faq_impact(
            question_id=question_id,
            answer_id=answer_id,
            related_changes=related_changes,
            detection_run_id=detection_run_id
        )

        # Store SINGLE impact record per FAQ
        store_aggregated_impact_analysis(aggregated_impact, detection_run_id)

        total_faqs_analyzed += 1
        if aggregated_impact['is_affected']:
            total_faqs_affected += 1
        else:
            total_faqs_saved += 1

        # Logging
        if len(related_changes) > 1:
            change_ids = [c['change_id'] for c in related_changes]
            print(f"  FAQ Q{question_id}: {len(related_changes)} changes → "
                  f"{'AFFECTED' if aggregated_impact['is_affected'] else 'NOT AFFECTED'} "
                  f"(score: {aggregated_impact['overall_impact_score']:.2f}, "
                  f"changes: {change_ids})")

    # ============================================================
    # PHASE 5: Selective Invalidation (Run-Level, No Duplicates)
    # ============================================================
    invalidated_count = selective_invalidate_faqs_by_run(detection_run_id)

    print(f"\n✅ Detection Complete!")
    print(f"=" * 60)
    print(f"Changes detected: {len(change_records)}")
    print(f"FAQs analyzed: {total_faqs_analyzed}")
    print(f"FAQs affected (invalidated): {total_faqs_affected}")
    print(f"FAQs preserved (saved): {total_faqs_saved}")
    print(f"Redundant analyses prevented: {sum(len(f['changes'])-1 for f in faq_to_changes.values() if len(f['changes'])>1)}")

    return {
        'detection_run_id': detection_run_id,
        'changes_detected': len(change_records),
        'faqs_analyzed': total_faqs_analyzed,
        'faqs_affected': total_faqs_affected,
        'faqs_saved': total_faqs_saved,
        'deduplication_savings': multi_change_faqs
    }
```

---

### NEW FUNCTION: Build FAQ-Change Mapping

```python
def build_faq_change_mapping(change_records):
    """
    Build mapping of FAQs to ALL changes that affect them.

    This function implements the CORE FIX for Issue 5.3:
    - Prevents duplicate analysis when FAQ sources from multiple changing checksums
    - Groups all changes affecting same FAQ for aggregated analysis

    Args:
        change_records: List of dicts with change_id, old_checksum, diff_data, etc.

    Returns:
        dict: {
            (question_id, answer_id): {
                'question_id': int,
                'answer_id': int,
                'question_text': str,
                'answer_text': str,
                'changes': [change_record1, change_record2, ...],
                'source_types': ['question', 'answer', ...]  # Which parts use which checksums
            },
            ...
        }

    Example:
        FAQ Q1 sources from checksums A, B, C
        Detection run finds: A→A', B→B', C unchanged

        Result:
        {
            (1, 101): {
                'question_id': 1,
                'changes': [
                    {change_id: 1, old_checksum: A, ...},
                    {change_id: 2, old_checksum: B, ...}
                ]
            }
        }

        FAQ Q1 analyzed ONCE with both changes, not twice!
    """

    faq_mapping = {}  # {(question_id, answer_id): faq_data}

    for change_record in change_records:
        old_checksum = change_record['old_checksum']

        # Find all FAQs that use this checksum (in question OR answer sources)
        affected_faqs = get_faqs_for_checksum(old_checksum)

        for faq in affected_faqs:
            question_id = faq['question_id']
            answer_id = faq['answer_id']
            faq_key = (question_id, answer_id)

            # Initialize FAQ entry if first time seeing it
            if faq_key not in faq_mapping:
                faq_mapping[faq_key] = {
                    'question_id': question_id,
                    'answer_id': answer_id,
                    'question_text': faq['question_text'],
                    'answer_text': faq['answer_text'],
                    'changes': [],
                    'source_types': []
                }

            # Add this change to FAQ's change list (deduplicated by change_id)
            if change_record not in faq_mapping[faq_key]['changes']:
                faq_mapping[faq_key]['changes'].append(change_record)
                faq_mapping[faq_key]['source_types'].append(faq['source_type'])

    return faq_mapping


def get_faqs_for_checksum(checksum):
    """
    Get all FAQs that use a given checksum in their sources.

    Returns list with FAQ details and source type (question/answer).
    """
    with sqlite3.connect(tracking_db) as conn:
        # Query both question sources and answer sources
        faqs = conn.execute("""
            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                a.answer_text,
                'question' as source_type,
                qs.source_id
            FROM faq_questions q
            INNER JOIN faq_question_sources qs ON q.question_id = qs.question_id
            LEFT JOIN faq_answers a ON q.question_id = a.question_id
            WHERE qs.content_checksum = ?
              AND q.status = 'active'
              AND qs.is_valid = TRUE

            UNION

            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                a.answer_text,
                'answer' as source_type,
                asrc.source_id
            FROM faq_answers a
            INNER JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
            INNER JOIN faq_questions q ON a.question_id = q.question_id
            WHERE asrc.content_checksum = ?
              AND q.status = 'active'
              AND a.status = 'active'
              AND asrc.is_valid = TRUE
        """, (checksum, checksum)).fetchall()

        return [dict(row) for row in faqs]
```

---

### NEW FUNCTION: Aggregated Impact Analysis

```python
def compute_aggregated_faq_impact(question_id, answer_id, related_changes, detection_run_id):
    """
    Compute aggregated impact considering ALL changes affecting this FAQ.

    Aggregation Strategy: MAX_IMPACT
    - Use highest impact score from any change (conservative approach)
    - Rationale: If ANY change significantly affects FAQ, invalidate it
    - Alternative strategies: weighted_avg, majority_vote (less conservative)

    Args:
        question_id: FAQ question ID
        answer_id: FAQ answer ID
        related_changes: List of change_records affecting this FAQ
        detection_run_id: Current detection run ID

    Returns:
        dict with aggregated impact decision and per-change breakdown
    """

    # Get FAQ text
    question_text, answer_text = get_faq_text(question_id, answer_id)
    faq_full_text = f"{question_text} {answer_text}"

    # Analyze impact for EACH change individually
    individual_impacts = []

    for change_rec in related_changes:
        # Use existing single-change analysis (from Phase 3 of algorithm)
        impact = analyze_single_change_impact(
            faq_full_text=faq_full_text,
            question_text=question_text,
            answer_text=answer_text,
            change=change_rec['change'],
            diff_data=change_rec['diff_data']
        )

        individual_impacts.append({
            'change_id': change_rec['change_id'],
            'diff_id': change_rec['diff_id'],
            'old_checksum': change_rec['old_checksum'],
            'new_checksum': change_rec['new_checksum'],
            **impact  # overall_score, lexical_score, etc.
        })

    # Aggregate using MAX_IMPACT strategy
    max_impact = max(individual_impacts, key=lambda x: x['overall_score'])

    # Compute statistics
    avg_score = sum(i['overall_score'] for i in individual_impacts) / len(individual_impacts)
    vote_affected = sum(1 for i in individual_impacts if i['is_affected'])
    vote_not_affected = len(individual_impacts) - vote_affected

    # Final decision: Use max impact (conservative)
    is_affected = max_impact['is_affected']
    overall_score = max_impact['overall_score']

    # Build aggregated reason
    if is_affected:
        impact_reason = (
            f"FAQ affected by {vote_affected}/{len(individual_impacts)} changes. "
            f"Max impact: {overall_score:.2f} from change {max_impact['change_id']} "
            f"(checksum {max_impact['old_checksum'][:8]}→{max_impact['new_checksum'][:8]}). "
            f"{max_impact['impact_reason']}"
        )
    else:
        impact_reason = (
            f"FAQ not significantly affected by {len(individual_impacts)} changes. "
            f"Max impact: {overall_score:.2f} (below threshold). "
            f"Avg: {avg_score:.2f}. All changes have minimal overlap with FAQ text."
        )

    return {
        'detection_run_id': detection_run_id,
        'question_id': question_id,
        'answer_id': answer_id,

        # Aggregated decision
        'is_affected': is_affected,
        'overall_impact_score': overall_score,
        'impact_level': max_impact['impact_level'],
        'impact_reason': impact_reason,

        # Aggregation metadata
        'aggregation_method': 'max_impact',
        'change_count': len(individual_impacts),
        'related_change_ids': [c['change_id'] for c in related_changes],

        # Per-change breakdown (for audit trail)
        'impact_breakdown': individual_impacts,

        # Statistics
        'max_score': max_impact['overall_score'],
        'avg_score': avg_score,
        'min_score': min(i['overall_score'] for i in individual_impacts),
        'vote_affected': vote_affected,
        'vote_not_affected': vote_not_affected,

        # Scoring components (from max impact change)
        'lexical_score': max_impact['lexical_score'],
        'keyword_score': max_impact['keyword_score'],
        'semantic_score': max_impact['semantic_score'],
        'phrase_score': max_impact['phrase_score'],
        'matched_phrases': max_impact['matched_phrases']
    }


def analyze_single_change_impact(faq_full_text, question_text, answer_text, change, diff_data):
    """
    Analyze impact of a SINGLE change on a FAQ.

    This is the existing V8 logic from Phase 3, extracted into a function
    for reuse in aggregated analysis.
    """

    # Scoring (existing V8 logic)
    lexical_score = compute_lexical_overlap(faq_full_text, diff_data['changed_phrases'])
    keyword_score = compute_keyword_match(faq_full_text, diff_data['changed_phrases'])
    semantic_score = compute_semantic_similarity(faq_full_text, diff_data['chunks'])
    phrase_score, matched_phrases = compute_phrase_match(faq_full_text, diff_data['changed_phrases'])

    # Weighted combination
    overall_score = (
        lexical_score * 0.3 +
        keyword_score * 0.3 +
        semantic_score * 0.2 +
        phrase_score * 0.2
    )

    # Decision thresholds
    if overall_score >= 0.7:
        is_affected = True
        impact_level = 'high'
        impact_reason = f"Strong overlap (score: {overall_score:.2f}). Matched: {matched_phrases}"
    elif overall_score >= 0.4:
        is_affected = True
        impact_level = 'medium'
        impact_reason = f"Moderate overlap (score: {overall_score:.2f})"
    elif overall_score >= 0.2:
        is_affected = False
        impact_level = 'low'
        impact_reason = f"Minimal overlap (score: {overall_score:.2f})"
    else:
        is_affected = False
        impact_level = 'none'
        impact_reason = f"No significant overlap (score: {overall_score:.2f})"

    # Critical change override
    if diff_data.get('contains_numeric_changes') or diff_data.get('contains_policy_changes'):
        if has_critical_overlap(faq_full_text, diff_data):
            is_affected = True
            impact_level = 'high'
            impact_reason = f"Critical content change. {impact_reason}"

    return {
        'overall_score': overall_score,
        'lexical_score': lexical_score,
        'keyword_score': keyword_score,
        'semantic_score': semantic_score,
        'phrase_score': phrase_score,
        'is_affected': is_affected,
        'impact_level': impact_level,
        'impact_reason': impact_reason,
        'matched_phrases': matched_phrases
    }
```

---

### UPDATED FUNCTION: Store Aggregated Impact

```python
def store_aggregated_impact_analysis(aggregated_impact, detection_run_id):
    """
    Store SINGLE aggregated impact analysis per FAQ.

    Schema Change: faq_impact_analysis now has detection_run_id instead of per-change records.
    Constraint: UNIQUE (detection_run_id, question_id, answer_id)
    """

    with sqlite3.connect(tracking_db) as conn:
        conn.execute("""
            INSERT INTO faq_impact_analysis (
                detection_run_id,
                question_id,
                answer_id,

                -- Aggregated scores
                overall_impact_score,
                lexical_overlap_score,
                keyword_match_score,
                semantic_similarity_score,
                phrase_match_score,

                -- Decision
                is_affected,
                impact_level,
                confidence,
                impact_reason,

                -- Aggregation metadata
                aggregation_method,
                related_change_ids,
                change_count,
                impact_breakdown,

                -- Statistics
                max_score,
                avg_score,
                min_score,
                vote_affected,
                vote_not_affected,

                -- Matched changes
                matched_changes,

                -- Metadata
                analysis_method,
                analysis_version,
                analyzed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            detection_run_id,
            aggregated_impact['question_id'],
            aggregated_impact['answer_id'],

            # Scores
            aggregated_impact['overall_impact_score'],
            aggregated_impact['lexical_score'],
            aggregated_impact['keyword_score'],
            aggregated_impact['semantic_score'],
            aggregated_impact['phrase_score'],

            # Decision
            aggregated_impact['is_affected'],
            aggregated_impact['impact_level'],
            0.9,  # Higher confidence (multiple changes analyzed)
            aggregated_impact['impact_reason'],

            # Aggregation
            aggregated_impact['aggregation_method'],
            json.dumps(aggregated_impact['related_change_ids']),
            aggregated_impact['change_count'],
            json.dumps(aggregated_impact['impact_breakdown']),

            # Stats
            aggregated_impact['max_score'],
            aggregated_impact['avg_score'],
            aggregated_impact['min_score'],
            aggregated_impact['vote_affected'],
            aggregated_impact['vote_not_affected'],

            # Matched
            json.dumps(aggregated_impact.get('matched_phrases', [])),

            # Metadata
            'hybrid_aggregated',
            'v8.1',  # Version updated to reflect deduplication fix
            datetime.now().isoformat()
        ))

        conn.commit()
```

---

### UPDATED FUNCTION: Run-Level Invalidation

```python
def selective_invalidate_faqs_by_run(detection_run_id):
    """
    Invalidate FAQs based on aggregated impact analysis for entire detection run.

    CHANGED: No longer per-change invalidation (prevents duplicate invalidations)
    """

    with sqlite3.connect(tracking_db) as conn:
        # Get all affected FAQs for this run (SINGLE query, no duplicates!)
        affected_faqs = conn.execute("""
            SELECT
                question_id,
                answer_id,
                related_change_ids,
                impact_reason
            FROM faq_impact_analysis
            WHERE detection_run_id = ?
              AND is_affected = TRUE
        """, (detection_run_id,)).fetchall()

        invalidated_count = 0

        for faq in affected_faqs:
            question_id = faq['question_id']
            answer_id = faq['answer_id']
            related_change_ids = json.loads(faq['related_change_ids'])

            # Invalidate question sources
            conn.execute("""
                UPDATE faq_question_sources
                SET is_valid = FALSE,
                    valid_until = CURRENT_TIMESTAMP(),
                    invalidation_reason = 'selective_impact_aggregated',
                    invalidated_by_change_id = ?
                WHERE question_id = ?
                  AND is_valid = TRUE
            """, (related_change_ids[0], question_id))  # Link to first change for FK

            # Invalidate answer sources
            if answer_id:
                conn.execute("""
                    UPDATE faq_answer_sources
                    SET is_valid = FALSE,
                        valid_until = CURRENT_TIMESTAMP(),
                        invalidation_reason = 'selective_impact_aggregated',
                        invalidated_by_change_id = ?
                    WHERE answer_id = ?
                      AND is_valid = TRUE
                """, (related_change_ids[0], answer_id))

            invalidated_count += 1

        # Audit log (SINGLE entry for entire run)
        conn.execute("""
            INSERT INTO faq_audit_log (
                table_name,
                action,
                change_reason,
                detection_run_id,
                performed_at
            ) VALUES (?, ?, ?, ?, ?)
        """, (
            'faq_answer_sources',
            'SELECTIVE_INVALIDATE_AGGREGATED',
            f'Aggregated invalidation: {invalidated_count} FAQs affected by run {detection_run_id}',
            detection_run_id,
            datetime.now().isoformat()
        ))

        conn.commit()

    return invalidated_count
```

---

## Benefits of V8

### Example: Real-World Scenario

**Page 2 Content:**
```
Sick Leave Policy
- Employees receive 10 sick days per year
- Accrual rate: 1 day per month after 30 days
- Can be used for personal illness or family care
- Unused days carry over to next year (max 5 days)
```

**10 FAQs:**
1. How many sick days do employees get?
2. What is the sick leave accrual rate?
3. Can I use sick days for family care?
4. Do sick days carry over?
5. What is the maximum carryover?
6. When does sick leave accrual start?
7. Are part-time employees eligible?
8. Can sick leave be used for medical appointments?
9. How do I request sick leave?
10. Is sick leave paid or unpaid?

**Edit:** "10 sick days" → "12 sick days"

**V7 Behavior:**
- Invalidate all 10 FAQs
- Regenerate all 10
- Send all 10 for SME verification
- Cost: 10 LLM calls + 10 SME reviews

**V8 Behavior:**
- Diff: Changed "10" to "12" in one phrase
- Impact analysis:
  - Q1: "How many sick days..." → **AFFECTED** (mentions "sick days")
  - Q2: "What is the accrual rate..." → **NOT AFFECTED** (doesn't mention total count)
  - Q3-Q10: **NOT AFFECTED**
- Invalidate only Q1
- Regenerate only Q1
- Send only Q1 for SME verification
- Cost: 1 LLM call + 1 SME review
- **Savings: 90%!** ✅

---

## Configuration & Tuning

### Impact Score Thresholds

```python
IMPACT_THRESHOLDS = {
    'high': 0.7,      # Definite impact, auto-invalidate
    'medium': 0.4,    # Probable impact, flag for review
    'low': 0.2,       # Possible impact, keep valid but monitor
    'none': 0.0       # No impact, keep valid
}
```

### Score Weights

```python
SCORE_WEIGHTS = {
    'lexical': 0.3,    # Jaccard similarity
    'keyword': 0.3,    # Keyword matching
    'semantic': 0.2,   # Embedding similarity
    'phrase': 0.2      # Exact phrase matching
}
```

Adjust based on your data and validation results!

---

## ISSUE 5.3: FAQ Impact Analysis Deduplication (CRITICAL FIX)

### Problem Statement

**Discovered:** 2025-01-22
**Severity:** HIGH - Data integrity and performance issue

The original V8 algorithm had a critical architectural flaw: it processed impact analysis **per content change** instead of **per FAQ**. This created duplicate and conflicting analysis when a single FAQ sourced from multiple content checksums that all changed in the same detection run.

###  Root Cause

**Original Algorithm Flow (BROKEN):**
```python
for change in changes:  # Per-change iteration
    faqs = get_faqs_for_checksum(change['old_checksum'])
    for faq in faqs:
        analyze_faq_impact(faq, change)  # ❌ FAQ analyzed multiple times!
        store_impact_analysis(...)
```

**Problem:** If FAQ Q1 sources from checksums A, B, and C, and all three change in one run:
- Change A → Q1 analyzed (result 1)
- Change B → Q1 analyzed AGAIN (result 2)
- Change C → Q1 analyzed AGAIN (result 3)

**Result:** 3 separate impact analysis records for Q1, potentially with **conflicting `is_affected` decisions**!

### Real-World Scenario

```
FAQ Q1: "How many sick days do full-time employees receive?"
  - Question sourced from: checksum_A (handbook page 5)
  - Answer sourced from: checksum_B (benefits guide page 12)
  - Answer also sourced from: checksum_C (policy doc page 3)

Detection Run Detects:
  Change 1: checksum_A → checksum_A_v2 (eligibility change: "Full-time" → "All")
  Change 2: checksum_B → checksum_B_v2 (benefit change: "10 days" → "12 days")
  Change 3: checksum_C → checksum_C_v2 (process change: "Manager approval" → "Self-service")

Original V8 Impact Analysis (BROKEN):
  Change 1 analysis: is_affected=TRUE, score=0.82 (eligibility term in question)
  Change 2 analysis: is_affected=TRUE, score=0.95 (numeric match in answer)
  Change 3 analysis: is_affected=FALSE, score=0.15 (no overlap)

Database State:
  faq_impact_analysis:
    (change_id=1, question_id=Q1, is_affected=TRUE)
    (change_id=2, question_id=Q1, is_affected=TRUE)
    (change_id=3, question_id=Q1, is_affected=FALSE)

  ❌ CONFLICT! Q1 both affected AND not affected
  ❌ Three redundant LLM calls for same FAQ
  ❌ Unclear which decision drives invalidation
```

### Impact

1. **Data Integrity**
   - Conflicting `is_affected` decisions in database
   - Violates semantic constraint: "One FAQ, one decision per run"
   - Audit trail ambiguity

2. **Performance**
   - Duplicate LLM calls for embedding similarity
   - Duplicate impact score computations
   - Database bloat (3× rows for same FAQ)

3. **Business Logic**
   - Unpredictable invalidation behavior
   - SME confusion (FAQ appears in multiple change reports)
   - Lost V8 optimization benefits

### Solution: FAQ-Centric Aggregation

**Fixed Algorithm Flow:**
```python
# Step 1: Collect ALL changes first
changes = detect_content_changes(...)

# Step 2: Build FAQ → Changes mapping
faq_to_changes = {}
for change in changes:
    faqs = get_faqs_for_checksum(change['old_checksum'])
    for faq in faqs:
        if faq not in faq_to_changes:
            faq_to_changes[faq] = []
        faq_to_changes[faq].append(change)

# Step 3: Analyze each FAQ ONCE with ALL its changes
for faq, related_changes in faq_to_changes.items():
    aggregated_impact = compute_aggregated_faq_impact(faq, related_changes)
    # Aggregation strategy: MAX_IMPACT (conservative)
    # If ANY change has high impact → FAQ is affected
    store_aggregated_impact_analysis(aggregated_impact)
```

**Result (FIXED):**
```
FAQ Q1 analyzed ONCE with all 3 changes:
  Individual scores: [0.82, 0.95, 0.15]
  Aggregation: MAX_IMPACT = 0.95
  Decision: is_affected=TRUE
  Reason: "FAQ affected by 2/3 changes. Max impact: 0.95 from change 2"

Database State:
  faq_impact_analysis:
    (detection_run_id=RUN_5, question_id=Q1, is_affected=TRUE,
     overall_score=0.95, related_change_ids=[1,2,3],
     impact_breakdown={...})

  ✅ Single, definitive decision
  ✅ Clear audit trail
  ✅ No redundant analysis
```

### Schema Changes Required

```sql
-- Add detection_run_id to faq_impact_analysis
ALTER TABLE faq_impact_analysis ADD COLUMN detection_run_id STRING NOT NULL;
ALTER TABLE faq_impact_analysis ADD COLUMN aggregation_method STRING;
ALTER TABLE faq_impact_analysis ADD COLUMN related_change_ids STRING;  -- JSON array
ALTER TABLE faq_impact_analysis ADD COLUMN change_count INT;
ALTER TABLE faq_impact_analysis ADD COLUMN impact_breakdown STRING;  -- JSON
ALTER TABLE faq_impact_analysis ADD COLUMN max_score DOUBLE;
ALTER TABLE faq_impact_analysis ADD COLUMN avg_score DOUBLE;
ALTER TABLE faq_impact_analysis ADD COLUMN vote_affected INT;
ALTER TABLE faq_impact_analysis ADD COLUMN vote_not_affected INT;

-- Change unique constraint
ALTER TABLE faq_impact_analysis DROP CONSTRAINT unique_faq_change_analysis;
ALTER TABLE faq_impact_analysis ADD CONSTRAINT unique_faq_run_analysis
    UNIQUE (detection_run_id, question_id, answer_id);

-- Update invalidation_reason enum
ALTER TABLE faq_question_sources ADD CONSTRAINT chk_invalidation_reason CHECK (
    invalidation_reason IN (..., 'selective_impact_aggregated')
);
```

### Benefits of Fix

1. **Eliminates Duplicates**
   - FAQ analyzed exactly once per detection run
   - No conflicting decisions

2. **Reduces Costs**
   - Fewer LLM calls (no redundant embeddings)
   - Smaller database (1 row per FAQ vs N rows)

3. **Better Explainability**
   - Single impact_reason aggregates all changes
   - `impact_breakdown` JSON shows per-change details
   - Clear decision: "Max impact from change X"

4. **Preserves V8 Innovation**
   - Still does granular FAQ-level analysis
   - Still saves FAQs from unnecessary regeneration
   - Just fixes the many-to-many relationship handling

### Metrics to Monitor

```sql
-- How many FAQs had multiple changes in same run?
SELECT
    detection_run_id,
    AVG(change_count) as avg_changes_per_faq,
    MAX(change_count) as max_changes_per_faq,
    SUM(CASE WHEN change_count > 1 THEN 1 ELSE 0 END) as faqs_with_multiple_changes
FROM faq_impact_analysis
GROUP BY detection_run_id;

-- How many redundant analyses prevented?
SELECT
    detection_run_id,
    SUM(change_count - 1) as analyses_saved
FROM faq_impact_analysis
WHERE change_count > 1
GROUP BY detection_run_id;
```

### Version History

- **V8.0** (2025-01-20): Initial granular impact analysis
- **V8.1** (2025-01-22): **Fixed Issue 5.3** - Added FAQ-centric deduplication

---

## END OF ALGORITHM
