## 5B. Remote Work During Parental Leave (NEW SECTION)
- Employees may request flexible remote work arrangements
- Available during final 4 weeks of parental leave
- Must be approved by manager and HR
- Subject to business needs and role requirements

## 5C. Parental Leave Return-to-Work Support
- Gradual return schedule available (min 20 hours/week)
- Lactation room access and break times provided
- Career development catch-up sessions offered
