## 4. Sick Leave (UPDATED)
Employees are entitled to sick leave as follows:
- **15 days** of paid sick leave per year (INCREASED FROM 10)
- Medical certificate required for absences over **2 consecutive days** (CHANGED FROM 3)
- Unused sick leave **can carry over up to 3 days** (NEW POLICY)

## 5. Parental Leave
- 12 weeks of paid parental leave for primary caregiver
- 4 weeks of paid parental leave for secondary caregiver
- **NEW: Additional 2 weeks unpaid leave available upon request**
