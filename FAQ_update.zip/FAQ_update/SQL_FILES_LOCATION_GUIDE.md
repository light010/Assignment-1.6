# SQL Files Location Guide

## Answer: Where to Put SQL Files

**Location**: `granular_impact/database/sql/`

All SQL files for the granular impact analysis system should be placed in the **database module's SQL directory**.

## Directory Structure

```
FAQ_update/granular_impact/database/sql/
├── README.md                         # SQL directory documentation
├── schema/                           # Database schema definitions
│   └── create_tables.sql            # ✅ Main schema creation script
├── queries/                          # Reusable query templates
│   ├── get_high_impact_faqs.sql     # ✅ Query high-impact FAQs
│   ├── content_changes_report.sql   # ✅ Content change reports
│   └── invalidation_summary.sql     # ✅ Invalidation statistics
└── migrations/                       # Schema version migrations
    └── (future migration files)
```

## Accessing SQL Files

### Method 1: Using QueryTemplates Class (Recommended)

```python
from granular_impact.database import QueryTemplates

# Load and execute schema creation
sql = QueryTemplates.create_schema(
    catalog="onedata_us_east_1_shared_dit",
    schema="faq_service"
)

spark.sql(sql)

# Load high-impact FAQs query
sql = QueryTemplates.get_high_impact_faqs(
    catalog="onedata_us_east_1_shared_dit",
    schema="faq_service",
    days_back=7,
    min_score=0.75
)

df = spark.sql(sql)
display(df)
```

### Method 2: Direct File Loading

```python
from pathlib import Path
from granular_impact.database import QueryTemplates

# Load any SQL file
sql = QueryTemplates.load_sql_file(
    "queries/content_changes_report.sql",
    params={
        "catalog": "onedata_us_east_1_shared_dit",
        "schema": "faq_service",
        "start_date": "2025-01-01",
        "end_date": "2025-01-31"
    }
)

df = spark.sql(sql)
```

### Method 3: Manual File Reading

```python
from pathlib import Path

sql_dir = Path("/path/to/granular_impact/database/sql")
sql_file = sql_dir / "schema" / "create_tables.sql"

with open(sql_file) as f:
    sql = f.read()

# Substitute parameters
sql = sql.format(
    catalog="onedata_us_east_1_shared_dit",
    schema="faq_service"
)

spark.sql(sql)
```

## Available SQL Files

### 1. Schema Files (`sql/schema/`)

#### create_tables.sql
Creates all required tables for the impact analysis system:
- `content_repo` - Source content with checksums
- `faq_qa_bank` - FAQ Q&A pairs
- `faq_impact_results` - Impact analysis results
- `faq_impact_audit_log` - Audit trail

**Usage**:
```python
sql = QueryTemplates.create_schema("my_catalog", "my_schema")
spark.sql(sql)
```

### 2. Query Files (`sql/queries/`)

#### get_high_impact_faqs.sql
Retrieves FAQs with high or critical impact.

**Parameters**:
- `catalog` - Database catalog
- `schema` - Database schema
- `days_back` - Number of days to look back (default: 7)
- `min_score` - Minimum impact score (default: 0.75)

**Usage**:
```python
sql = QueryTemplates.get_high_impact_faqs(
    catalog="my_catalog",
    schema="my_schema",
    days_back=14,
    min_score=0.80
)
df = spark.sql(sql)
```

#### content_changes_report.sql
Generates summary report of content changes and their impact.

**Parameters**:
- `catalog` - Database catalog
- `schema` - Database schema
- `start_date` - Start date (YYYY-MM-DD)
- `end_date` - End date (YYYY-MM-DD)

**Usage**:
```python
sql = QueryTemplates.get_content_changes_report(
    catalog="my_catalog",
    schema="my_schema",
    start_date="2025-01-01",
    end_date="2025-01-31"
)
df = spark.sql(sql)
```

#### invalidation_summary.sql
Provides summary statistics on invalidations and impact decisions.

**Parameters**:
- `catalog` - Database catalog
- `schema` - Database schema
- `days_back` - Number of days to look back (default: 30)

**Usage**:
```python
sql = QueryTemplates.get_invalidation_summary(
    catalog="my_catalog",
    schema="my_schema",
    days_back=30
)
df = spark.sql(sql)
```

## Adding New SQL Files

### File Naming Convention

- **Schema files**: `create_<entity>.sql`, `alter_<entity>.sql`
- **Query files**: `<operation>_<entity>.sql`
- **Migration files**: `v<version>_<description>.sql`

### Steps to Add a New SQL File

1. **Create the SQL file** in the appropriate directory:
   ```bash
   # For a new query
   touch granular_impact/database/sql/queries/my_new_query.sql
   ```

2. **Add parameter placeholders** using `{parameter_name}`:
   ```sql
   -- my_new_query.sql
   SELECT *
   FROM {catalog}.{schema}.my_table
   WHERE date >= '{start_date}'
   ```

3. **Add a helper method** to `QueryTemplates`:
   ```python
   @staticmethod
   def get_my_new_query(catalog: str, schema: str, start_date: str) -> str:
       """Load my new query."""
       return QueryTemplates.load_sql_file(
           "queries/my_new_query.sql",
           {
               "catalog": catalog,
               "schema": schema,
               "start_date": start_date
           }
       )
   ```

4. **Use it in your code**:
   ```python
   sql = QueryTemplates.get_my_new_query("cat", "schema", "2025-01-01")
   df = spark.sql(sql)
   ```

## Best Practices

### 1. Use Parameter Substitution

✅ **Good**:
```sql
SELECT * FROM {catalog}.{schema}.table_name
WHERE score >= {min_score}
```

❌ **Bad**:
```sql
SELECT * FROM hardcoded_catalog.hardcoded_schema.table_name
WHERE score >= 0.75
```

### 2. Make Queries Idempotent

✅ **Good**:
```sql
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.my_table ...
```

❌ **Bad**:
```sql
CREATE TABLE {catalog}.{schema}.my_table ...
```

### 3. Add Comments

```sql
-- ============================================================================
-- Query: Description of what this query does
-- ============================================================================
-- Detailed explanation
--
-- Parameters:
--   {catalog} - Database catalog
--   {schema} - Database schema
-- ============================================================================

SELECT ...
```

### 4. Use Descriptive Names

✅ **Good**: `get_high_impact_faqs_requiring_review.sql`
❌ **Bad**: `query1.sql`

## Integration with Databricks Notebooks

In Databricks notebooks (see `notebooks/01_schema_setup.py`):

```python
# Method 1: Using QueryTemplates
from granular_impact.database import QueryTemplates

sql = QueryTemplates.create_schema(
    catalog=dbutils.widgets.get("catalog"),
    schema=dbutils.widgets.get("schema")
)

spark.sql(sql)

# Method 2: Direct file path in Databricks workspace
sql_path = "/Workspace/Users/your.email@company.com/granular_impact/database/sql/schema/create_tables.sql"

with open(sql_path) as f:
    sql = f.read()

sql = sql.format(catalog="my_catalog", schema="my_schema")
spark.sql(sql)
```

## Summary

| Aspect | Answer |
|--------|--------|
| **Main Location** | `granular_impact/database/sql/` |
| **Schema Files** | `sql/schema/` |
| **Query Files** | `sql/queries/` |
| **Migrations** | `sql/migrations/` |
| **Access Method** | `QueryTemplates.load_sql_file()` or helper methods |
| **Parameter Format** | `{parameter_name}` in SQL files |

## Quick Reference

```bash
# SQL file locations
FAQ_update/granular_impact/database/sql/
├── schema/create_tables.sql      # ✅ CREATE TABLE statements
├── queries/*.sql                 # ✅ Reusable SELECT queries
└── migrations/*.sql              # ✅ Schema version changes

# Python access
from granular_impact.database import QueryTemplates

sql = QueryTemplates.load_sql_file("queries/my_query.sql", {...})
sql = QueryTemplates.create_schema(catalog, schema)
sql = QueryTemplates.get_high_impact_faqs(catalog, schema, ...)
```

---

**All your SQL files should go in: `FAQ_update/granular_impact/database/sql/`** ✅
