# FAQ Content Mapping Schema - Senior Data Architect Analysis

**Date**: 2025-10-20
**Analyst**: Senior Data Architecture Review
**Scope**: faq_content_map table redesign for many-to-many content relationships
**Priority**: 🔴 **CRITICAL** - Current schema cannot support stated requirements

---

## 📋 Executive Summary

### Current State: **BROKEN**
The current `faq_content_map` schema implements a **1:1 relationship** between FAQ pairs and content, but your business requirements clearly state a **M:N (many-to-many) relationship**.

### Business Requirement (Stated)
> "A question can be generated from 1 or multiple contents and answer can also be generated from one or more contents. question's and answer's contents can be different-2."

### Current Implementation
- **1 FAQ pair** → **1 content_checksum** (single mapping row)
- Cannot store multiple source contents
- Cannot differentiate question sources from answer sources
- **Fundamentally incompatible with requirements**

### Impact: 🔴 **BLOCKER**
- FAQ generation will fail for multi-source scenarios
- Invalidation logic will be incorrect
- Cannot track true content-FAQ relationships
- Data model does not match business process

---

## 🔍 Deep Analysis: Current Schema vs Requirements

### Part 1: Current Schema Structure

```
faq_content_map (current v4)
├── map_id (PK)
├── question_id (FK → faq_questions)
├── answer_id (FK → faq_answers)
├── content_checksum ← SINGLE content reference
├── current_content_id (FK → content_repo)
├── current_file_name
├── current_metadata (JSON)
├── original_content_id
├── original_metadata (JSON)
├── is_valid
├── validity timestamps
└── invalidation tracking
```

**Cardinality**: `(question_id, answer_id) → 1 content_checksum`

**Limitation**: Each FAQ pair can only reference **ONE** content piece.

---

### Part 2: Business Requirements Analysis

#### Requirement 1: Multi-Source Question Generation
```
Question: "What is the parental leave policy?"

Sources Used:
  ✓ Page 2 (content_checksum: abc123...) - "Sick Leave section mentions parental"
  ✓ Page 5 (content_checksum: def456...) - "Parental Leave main section"
  ✓ Page 8 (content_checksum: ghi789...) - "Benefits overview"

Current Schema: ❌ Can only store ONE checksum
Required: Store ALL 3 checksums with role="question_source"
```

#### Requirement 2: Multi-Source Answer Generation
```
Answer: "Primary caregiver gets 12 weeks paid leave..."

Sources Used:
  ✓ Page 5 (content_checksum: def456...) - "12 weeks primary caregiver"
  ✓ Page 8 (content_checksum: ghi789...) - "Benefits and compensation"
  ✓ Page 10 (content_checksum: jkl012...) - "Return to work policies"

Current Schema: ❌ Can only store ONE checksum
Required: Store ALL 3 checksums with role="answer_source"
```

#### Requirement 3: Different Sources for Q vs A
```
Question Sources:  [Page 2, Page 5, Page 8]
Answer Sources:    [Page 5, Page 8, Page 10]  ← Different set!

Overlap: Page 5, Page 8 (used for both)
Question-only: Page 2
Answer-only: Page 10

Current Schema: ❌ Cannot distinguish Q vs A sources
Required: Tag each source with role (question_source | answer_source | both)
```

---

### Part 3: Consequence Analysis

#### Scenario: Multi-Source FAQ Generation

**Generation Process** (actual business flow):
1. Retriever fetches 5 relevant content chunks for question
2. LLM generates question using all 5 chunks as context
3. Retriever fetches 7 relevant chunks for answer
4. LLM generates answer using all 7 chunks as context
5. System needs to **persist all 12 source relationships**

**Current Schema Behavior**:
```python
# What can we store?
faq_content_map.insert({
    'question_id': 1001,
    'answer_id': 2001,
    'content_checksum': '???'  # Which ONE checksum do we pick from 12???
})

# Options (all bad):
# A) Pick first chunk → Lose 11/12 source tracking
# B) Pick most relevant → Still lose 11/12 tracking
# C) Store JSON array → Violates normalization, breaks FK, can't query
# D) Create 12 rows → Duplicate question_id/answer_id (confusing)
```

**Result**: **Data loss** - 92% of source relationships lost.

---

#### Scenario: Content Change Invalidation

**Business Logic** (stated requirement):
> "If content changes, invalidate FAQs that used that content"

**Problem with current schema**:

```
FAQ #1001 generated from:
  Question: [Checksum A, Checksum B, Checksum C]
  Answer:   [Checksum C, Checksum D, Checksum E]

Day 2: Checksum D changes (answer source modified)

Current Schema Query:
  SELECT * FROM faq_content_map
  WHERE content_checksum = 'D'

Result: ❌ NO ROWS FOUND

Why? Because faq_content_map.content_checksum = 'A'
(only first question source was stored, answer sources lost)

FAQ #1001 remains VALID despite answer source changing
→ INCORRECT BEHAVIOR
→ STALE FAQ SERVED TO USERS
```

**Severity**: 🔴 **CRITICAL** - Invalidation logic fundamentally broken

---

#### Scenario: Partial Content Change

**Advanced Requirement** (implied by multi-source model):

```
FAQ #1001 generated from:
  Question: [Checksum A, Checksum B, Checksum C]
  Answer:   [Checksum A, Checksum D, Checksum E]

Day 2: Checksum E changes (minor answer source updated)

Smart Invalidation Logic:
  - Question still valid (sources A, B, C unchanged)
  - Answer needs regeneration (source E changed)
  - Option: Regenerate only answer, reuse question

Current Schema: ❌ Cannot support this
  - Cannot tell which sources contributed to Q vs A
  - Must invalidate entire FAQ pair
  - Wasteful regeneration
```

**Impact**: Unnecessary API costs, slower processing

---

## 🏗️ Required Architecture: Many-to-Many Design

### Correct Relationship Model

```
┌─────────────────┐         ┌──────────────────────┐         ┌──────────────┐
│  faq_questions  │         │   faq_content_map    │         │ content_repo │
│                 │         │   (junction table)   │         │              │
│ question_id PK  │────────>│ question_id FK       │         │ checksum     │
└─────────────────┘    1    │ answer_id FK         │    N    │ content_id   │
                             │ content_checksum FK  │<────────│              │
┌─────────────────┐         │ source_role ENUM     │         └──────────────┘
│   faq_answers   │         │ contribution_score   │
│                 │         │ sequence_order       │
│ answer_id PK    │────────>│                      │
└─────────────────┘    1    └──────────────────────┘
                                       N
```

**Cardinality**: `M:N` (Many-to-Many)
- 1 Question → N content sources
- 1 Answer → N content sources
- 1 Content → N FAQ questions (reused across FAQs)
- 1 Content → N FAQ answers (reused across FAQs)

---

### Proposed Schema: `faq_content_sources` (Junction Table)

```sql
CREATE TABLE faq_content_sources (
    -- Primary Key (composite)
    source_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- FAQ IDENTIFICATION
    -- ========================================================================
    question_id INTEGER NOT NULL,
    answer_id INTEGER,  -- NULL if source only used for question

    -- ========================================================================
    -- CONTENT IDENTIFICATION (What content was used)
    -- ========================================================================
    content_checksum TEXT NOT NULL CHECK(length(content_checksum) = 64),
    content_id INTEGER NOT NULL,  -- FK to content_repo (for retrieval)

    -- ========================================================================
    -- SOURCE ROLE (How content was used)
    -- ========================================================================
    source_role TEXT NOT NULL CHECK(source_role IN (
        'question_source',   -- Used to generate question only
        'answer_source',     -- Used to generate answer only
        'both'               -- Used for both question and answer
    )),

    -- ========================================================================
    -- CONTRIBUTION METADATA
    -- ========================================================================
    contribution_score REAL CHECK(contribution_score BETWEEN 0 AND 1),
        -- LLM relevance score (0.0 = low, 1.0 = high)
        -- Allows weighting during invalidation decisions

    sequence_order INTEGER,
        -- Order in which sources were presented to LLM (1, 2, 3...)
        -- Important for RAG context ordering

    chunk_metadata JSON,
        -- {
        --   "page": 5,
        --   "section": "Parental Leave",
        --   "chunk_start": 0,
        --   "chunk_end": 500,
        --   "retrieval_score": 0.92
        -- }

    -- ========================================================================
    -- TIMESTAMPS
    -- ========================================================================
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),

    -- ========================================================================
    -- FOREIGN KEYS
    -- ========================================================================
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        ON DELETE CASCADE,
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        ON DELETE CASCADE,
    FOREIGN KEY (content_id) REFERENCES content_repo(ud_source_file_id)
        ON DELETE CASCADE,

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    -- Prevent duplicate source assignments
    UNIQUE(question_id, answer_id, content_checksum, source_role),

    -- Ensure answer_id is provided for answer sources
    CHECK(
        (source_role = 'question_source' AND answer_id IS NULL) OR
        (source_role IN ('answer_source', 'both') AND answer_id IS NOT NULL)
    )
);
```

---

### Indexes for `faq_content_sources`

```sql
-- ========================================================================
-- PRIMARY LOOKUP INDEXES
-- ========================================================================

-- Find all sources for a question
CREATE INDEX idx_fcs_question ON faq_content_sources(question_id, source_role);

-- Find all sources for an answer
CREATE INDEX idx_fcs_answer ON faq_content_sources(answer_id, source_role);

-- Find all FAQs using a specific content (for invalidation)
CREATE INDEX idx_fcs_checksum ON faq_content_sources(
    content_checksum,
    source_role
);

-- Content ID lookup (for markdown retrieval)
CREATE INDEX idx_fcs_content ON faq_content_sources(content_id);

-- ========================================================================
-- QUERY OPTIMIZATION INDEXES
-- ========================================================================

-- Find question sources ordered by contribution
CREATE INDEX idx_fcs_question_contrib ON faq_content_sources(
    question_id,
    contribution_score DESC
) WHERE source_role IN ('question_source', 'both');

-- Find answer sources ordered by contribution
CREATE INDEX idx_fcs_answer_contrib ON faq_content_sources(
    answer_id,
    contribution_score DESC
) WHERE source_role IN ('answer_source', 'both');

-- Sequence order lookup (for context reconstruction)
CREATE INDEX idx_fcs_sequence ON faq_content_sources(
    question_id,
    answer_id,
    sequence_order
);
```

---

### Modified `faq_content_map` Schema (Metadata Table)

**New Role**: FAQ-level metadata and validity tracking (NOT content mapping)

```sql
CREATE TABLE faq_content_map (
    map_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- FAQ IDENTIFICATION
    -- ========================================================================
    question_id INTEGER NOT NULL,
    answer_id INTEGER NOT NULL,

    -- ========================================================================
    -- VALIDITY MANAGEMENT (FAQ-level, not content-level)
    -- ========================================================================
    is_valid BOOLEAN NOT NULL DEFAULT 1 CHECK(is_valid IN (0,1)),
    valid_from TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    valid_until TEXT,

    -- ========================================================================
    -- INVALIDATION TRACKING
    -- ========================================================================
    invalidation_reason TEXT CHECK(
        invalidation_reason IS NULL OR
        invalidation_reason IN (
            'source_content_changed',   -- One or more sources changed
            'source_content_deleted',   -- One or more sources removed
            'manual_invalidation',      -- Human decision
            'accuracy_issue',           -- Found incorrect
            'question_deprecated'       -- No longer relevant
        )
    ),
    invalidated_by_change_ids JSON,  -- Array of change_ids that triggered invalidation
        -- Example: ["123", "456"] (multiple sources can change simultaneously)

    replaced_by_map_id INTEGER,

    -- ========================================================================
    -- GENERATION METADATA (FAQ-level)
    -- ========================================================================
    generation_method TEXT,
        -- Example: "RAG_GPT4_v1", "manual", "hybrid"

    generation_config JSON,
        -- {
        --   "model": "gpt-4",
        --   "temperature": 0.7,
        --   "max_tokens": 500,
        --   "retrieval_k": 5
        -- }

    confidence_score REAL CHECK(confidence_score IS NULL OR confidence_score BETWEEN 0 AND 1),
        -- Overall FAQ confidence (aggregate of source contributions)

    created_for_version INTEGER NOT NULL DEFAULT 1,

    -- ========================================================================
    -- TIMESTAMPS
    -- ========================================================================
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    last_validated_at TEXT,
    last_regenerated_at TEXT,

    -- ========================================================================
    -- FOREIGN KEYS
    -- ========================================================================
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        ON DELETE CASCADE,
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        ON DELETE CASCADE,
    FOREIGN KEY (replaced_by_map_id) REFERENCES faq_content_map(map_id)
        ON DELETE SET NULL,

    -- ========================================================================
    -- CONSTRAINTS
    -- ========================================================================
    -- One active mapping per FAQ pair
    UNIQUE(question_id, answer_id, is_valid)
        WHERE is_valid = 1,

    -- Validity constraint
    CHECK((is_valid = 1 AND valid_until IS NULL) OR
          (is_valid = 0 AND valid_until IS NOT NULL))
);
```

**Key Changes**:
- ❌ **REMOVED**: `content_checksum`, `current_content_id`, `current_file_name`, `current_metadata`, `original_metadata`, `original_content_id`
  - **Reason**: Content mapping moved to `faq_content_sources` junction table

- ✅ **ADDED**: `invalidated_by_change_ids` (JSON array)
  - **Reason**: Multiple sources can change, need to track all

- ✅ **ADDED**: `generation_config` (JSON)
  - **Reason**: Track LLM parameters for reproducibility

- ✅ **ADDED**: `last_regenerated_at`
  - **Reason**: Track when FAQ was regenerated (vs validated)

- ✅ **FOCUS**: FAQ-level metadata, not content-level mapping

---

## 🎯 Invalidation Logic with New Schema

### Query 1: Find FAQs Affected by Content Change

```sql
-- When content checksum XYZ changes, find all affected FAQs

SELECT DISTINCT
    fcs.question_id,
    fcs.answer_id,
    fcs.source_role,
    fcm.map_id,
    fcm.is_valid
FROM faq_content_sources fcs
JOIN faq_content_map fcm
    ON fcs.question_id = fcm.question_id
    AND fcs.answer_id = fcm.answer_id
WHERE fcs.content_checksum = 'XYZ'  -- Changed content
  AND fcm.is_valid = 1               -- Currently valid FAQs
ORDER BY fcs.question_id, fcs.answer_id;
```

**Result**: Returns ALL FAQs that used content XYZ, regardless of whether it was 1 of many sources.

---

### Query 2: Smart Invalidation (Question vs Answer)

```sql
-- Find FAQs where ONLY answer sources changed (question still valid)

WITH changed_checksums AS (
    SELECT content_checksum
    FROM content_change_log
    WHERE requires_faq_regeneration = 1
      AND detected_at > ?  -- Since last check
),
faq_question_changes AS (
    SELECT DISTINCT question_id, answer_id
    FROM faq_content_sources fcs
    JOIN changed_checksums cc ON fcs.content_checksum = cc.content_checksum
    WHERE fcs.source_role IN ('question_source', 'both')
),
faq_answer_changes AS (
    SELECT DISTINCT question_id, answer_id
    FROM faq_content_sources fcs
    JOIN changed_checksums cc ON fcs.content_checksum = cc.content_checksum
    WHERE fcs.source_role IN ('answer_source', 'both')
)
SELECT
    fac.question_id,
    fac.answer_id,
    CASE
        WHEN fqc.question_id IS NOT NULL THEN 'regenerate_both'
        ELSE 'regenerate_answer_only'
    END as action
FROM faq_answer_changes fac
LEFT JOIN faq_question_changes fqc
    ON fac.question_id = fqc.question_id
    AND fac.answer_id = fqc.answer_id;
```

**Result**: Identifies FAQs where only answer needs regeneration (cost optimization).

---

### Query 3: Partial Invalidation (Weighted Decision)

```sql
-- Invalidate FAQ only if high-contribution sources changed

WITH changed_checksums AS (
    SELECT content_checksum
    FROM content_change_log
    WHERE requires_faq_regeneration = 1
),
faq_change_impact AS (
    SELECT
        fcs.question_id,
        fcs.answer_id,
        SUM(fcs.contribution_score) as total_changed_contribution,
        COUNT(*) as changed_source_count,
        (SELECT COUNT(*)
         FROM faq_content_sources
         WHERE question_id = fcs.question_id
           AND answer_id = fcs.answer_id) as total_source_count
    FROM faq_content_sources fcs
    JOIN changed_checksums cc ON fcs.content_checksum = cc.content_checksum
    GROUP BY fcs.question_id, fcs.answer_id
)
SELECT
    question_id,
    answer_id,
    total_changed_contribution,
    changed_source_count,
    total_source_count,
    CASE
        -- Invalidate if >50% contribution changed OR >50% sources changed
        WHEN total_changed_contribution > 0.5 THEN 'invalidate'
        WHEN changed_source_count * 1.0 / total_source_count > 0.5 THEN 'invalidate'
        ELSE 'review_manually'
    END as recommendation
FROM faq_change_impact;
```

**Result**: Smart invalidation based on impact threshold (prevents over-invalidation).

---

## 📊 Data Examples

### Example 1: Simple FAQ (Single Source)

**FAQ**:
- Question: "How many annual leave days do I get?"
- Answer: "15 days per year"

**Sources**:
```sql
INSERT INTO faq_content_sources VALUES
  (1, 1001, 2001, 'abc123...', 1001, 'both', 1.0, 1, '{"page": 1, "section": "Annual Leave"}', now());
```

**Explanation**: Same content used for both question and answer (simple case).

---

### Example 2: Multi-Source FAQ (Complex)

**FAQ**:
- Question: "What is the parental leave policy?"
- Answer: "Primary caregiver gets 12 weeks paid, secondary gets 4 weeks..."

**Sources**:
```sql
-- Question sources (3 sources)
INSERT INTO faq_content_sources VALUES
  (2, 1002, NULL,  'abc123...', 1002, 'question_source', 0.6, 1, '{"page": 2, "section": "Sick Leave"}', now()),
  (3, 1002, NULL,  'def456...', 1005, 'question_source', 0.9, 2, '{"page": 5, "section": "Parental Leave"}', now()),
  (4, 1002, NULL,  'ghi789...', 1008, 'question_source', 0.7, 3, '{"page": 8, "section": "Benefits"}', now());

-- Answer sources (4 sources, 2 overlap with question)
INSERT INTO faq_content_sources VALUES
  (5, 1002, 2002, 'def456...', 1005, 'answer_source', 0.95, 1, '{"page": 5, "section": "Parental Leave"}', now()),
  (6, 1002, 2002, 'ghi789...', 1008, 'answer_source', 0.8, 2, '{"page": 8, "section": "Benefits"}', now()),
  (7, 1002, 2002, 'jkl012...', 1010, 'answer_source', 0.7, 3, '{"page": 10, "section": "Return to Work"}', now()),
  (8, 1002, 2002, 'mno345...', 1012, 'answer_source', 0.5, 4, '{"page": 12, "section": "Exceptions"}', now());
```

**Analysis**:
- **7 total unique sources** (3 Q-only, 2 shared, 2 A-only)
- If `def456` changes → Affects both question AND answer
- If `jkl012` changes → Affects only answer (can preserve question)
- If `abc123` changes → Affects only question (can preserve answer)

---

## 🚨 Critical Issues with Current Schema (Detailed)

### Issue #1: Data Loss During FAQ Generation

**Current Code Path** (hypothetical):
```python
# FAQ generation process
question_context = retriever.get_contexts(query, k=5)
question = llm.generate_question(question_context)

answer_context = retriever.get_contexts(question, k=7)
answer = llm.generate_answer(answer_context)

# Save to database - PROBLEM STARTS HERE
# Current schema: Can only store ONE checksum
# Which one do we pick from 12 total (5 Q + 7 A)?

faq_content_map.insert({
    'question_id': question.id,
    'answer_id': answer.id,
    'content_checksum': question_context[0].checksum  # ❌ Arbitrary choice!
    # Lost: question_context[1-4] and answer_context[0-6]
})
```

**Data Loss**: 91.7% of source relationships (11 out of 12 sources)

---

### Issue #2: Incorrect Invalidation Logic

**Scenario**:
```
FAQ #1001 sources:
  Question: [Checksum A, B, C]
  Answer: [Checksum D, E, F]

Current faq_content_map row:
  question_id: 1001
  answer_id: 2001
  content_checksum: A  ← Only first question source stored

Day 2: Checksum D changes (answer source)

Invalidation Query:
  UPDATE faq_content_map
  SET is_valid = 0
  WHERE content_checksum IN (
      SELECT content_checksum
      FROM content_change_log
      WHERE requires_faq_regeneration = 1
  )

Result: 0 rows updated (FAQ #1001 not invalidated)
Reason: content_checksum = 'A', but 'D' changed (A ≠ D)

FAQ #1001 remains valid with STALE ANSWER
→ Users get incorrect information
→ BUSINESS LOGIC FAILURE
```

---

### Issue #3: Cannot Implement Smart Regeneration

**Business Optimization** (reduce API costs):

```
Ideal Logic:
  IF only_question_sources_changed:
      regenerate_question_only()
      reuse_existing_answer()  # Save API costs
  ELIF only_answer_sources_changed:
      reuse_existing_question()
      regenerate_answer_only()  # Save API costs
  ELSE:
      regenerate_both()

Current Schema:
  ❌ Cannot determine which sources → Q vs A
  ❌ Must always regenerate both
  ❌ Wasteful API usage
```

**Cost Impact**: Potentially 2x API costs

---

### Issue #4: Cannot Track Content Reuse

**Analytics Question**: "Which content pages are most valuable for FAQ generation?"

```sql
-- Desired Query (IMPOSSIBLE with current schema):
SELECT
    content_checksum,
    COUNT(DISTINCT question_id) as faqs_using_this_content,
    AVG(contribution_score) as avg_contribution
FROM faq_content_sources
GROUP BY content_checksum
ORDER BY faqs_using_this_content DESC;

-- Current Schema (WRONG RESULTS):
SELECT
    content_checksum,
    COUNT(*) as faq_count  -- ❌ Undercounts by ~90%
FROM faq_content_map
GROUP BY content_checksum;
```

**Analytics Impact**: Cannot measure content value, cannot prioritize content quality improvements

---

### Issue #5: Cannot Implement Versioning

**Future Requirement**: Track how FAQ sources change over time

```
FAQ #1001 Version History:
  v1 (2025-01-01):
    Sources: [A, B, C]  ← Initial generation

  v2 (2025-02-01):
    Sources: [A, B, D]  ← Content C changed to D

  v3 (2025-03-01):
    Sources: [A, D, E]  ← Content B changed to E

Current Schema:
  ❌ Cannot store v1, v2, v3 source lists
  ❌ Only has current_content_id and original_content_id
  ❌ Loses all intermediate versions
```

**Audit Impact**: Cannot explain why FAQ changed, cannot reproduce historical FAQs

---

## 📋 COMPREHENSIVE TODO LIST

### 🔴 **PHASE 1: IMMEDIATE BLOCKERS** (Week 1)

#### Task 1.1: Validate Business Requirements with Stakeholders
**Priority**: 🔴 CRITICAL
**Owner**: Product/Business
**Duration**: 1-2 days

**Actions**:
1. **Confirm multi-source requirement is real**
   - Interview FAQ generation team
   - Review RAG implementation (how many contexts used?)
   - Check if current system already generates from multiple sources
   - Document: "Is this theoretical or actual current behavior?"

2. **Define cardinality boundaries**
   - Typical number of sources per question (avg/max)?
   - Typical number of sources per answer (avg/max)?
   - Are there hard limits? (e.g., max 10 sources per FAQ)

3. **Prioritize use cases**
   - Is single-source FAQ generation still valid? (probably yes)
   - What % of FAQs are multi-source? (5%? 50%? 90%?)
   - Can we defer multi-source to Phase 2?

**Output**:
- ✅ Confirmed requirements document
- ✅ Cardinality specifications (min/avg/max sources)
- ✅ Use case prioritization (single vs multi-source)

---

#### Task 1.2: Design Review Meeting
**Priority**: 🔴 CRITICAL
**Owner**: Data Architect + Dev Lead + Product
**Duration**: 2-4 hours

**Agenda**:
1. Present current schema limitations (this document)
2. Review proposed `faq_content_sources` junction table design
3. Discuss alternatives (if any):
   - Option A: Junction table (recommended)
   - Option B: JSON array in faq_content_map (NOT recommended)
   - Option C: Hybrid approach (single-source as default, junction for multi)
4. Decide on approach
5. Define success criteria
6. Assign tasks

**Output**:
- ✅ Approved design decision
- ✅ Signed-off architecture diagram
- ✅ Task assignments with deadlines

---

#### Task 1.3: Impact Analysis
**Priority**: 🔴 CRITICAL
**Owner**: Tech Lead
**Duration**: 1 day

**Actions**:
1. **Code audit**: Identify all code that reads/writes `faq_content_map`
   - FAQ generation pipeline
   - Invalidation logic
   - Retrieval APIs
   - Analytics queries

2. **Estimate migration effort**
   - Schema changes: ~2 days
   - Code changes: ? (depends on audit)
   - Testing: ~3-5 days
   - Total: ? days

3. **Identify breaking changes**
   - Which APIs will break?
   - Which queries will need rewriting?
   - Which notebooks need updating?

4. **Data migration planning**
   - Is there existing prod data in faq_content_map?
   - Can we migrate, or must we regenerate FAQs?
   - Downtime requirements?

**Output**:
- ✅ Code audit report (files affected, LOC to change)
- ✅ Effort estimate (person-days)
- ✅ Risk assessment
- ✅ Migration strategy document

---

### 🟡 **PHASE 2: SCHEMA DESIGN** (Week 2)

#### Task 2.1: Finalize `faq_content_sources` Table Schema
**Priority**: 🟡 HIGH
**Owner**: Data Architect
**Duration**: 1 day

**Actions**:
1. Refine junction table definition based on Task 1.1 feedback
2. Add any additional metadata fields discovered in impact analysis
3. Design indexes for common query patterns
4. Write migration SQL script (v4 → v5)
5. Document design decisions

**Deliverables**:
- ✅ `create_schema_v5.sql` (full schema with junction table)
- ✅ Migration script: `migrate_v4_to_v5.sql`
- ✅ Rollback script: `rollback_v5_to_v4.sql`
- ✅ Index design document

---

#### Task 2.2: Update `faq_content_map` Table (Remove Content Fields)
**Priority**: 🟡 HIGH
**Owner**: Data Architect
**Duration**: 0.5 days

**Actions**:
1. Remove content-related columns (see schema above):
   - `content_checksum`
   - `current_content_id`
   - `current_file_name`
   - `current_metadata`
   - `original_content_id`
   - `original_metadata`

2. Add new columns:
   - `invalidated_by_change_ids` (JSON array)
   - `generation_config` (JSON)
   - `last_regenerated_at` (TEXT)

3. Update foreign keys
4. Update indexes
5. Update views that reference old columns

**Deliverables**:
- ✅ Updated `faq_content_map` schema in v5 SQL
- ✅ Migration steps documented

---

#### Task 2.3: Create Database Views for Common Queries
**Priority**: 🟡 MEDIUM
**Owner**: Data Architect
**Duration**: 1 day

**Actions**:
1. **View**: `v_faq_with_sources` (FAQ with all source details)
   ```sql
   SELECT
       fcm.question_id, fcm.answer_id,
       fcs.content_checksum, fcs.source_role,
       fcs.contribution_score, fcs.sequence_order,
       cr.extracted_markdown_file_path
   FROM faq_content_map fcm
   JOIN faq_content_sources fcs ON ...
   JOIN content_repo cr ON ...
   ```

2. **View**: `v_content_faq_usage` (which FAQs use each content)
   ```sql
   SELECT
       content_checksum,
       COUNT(DISTINCT question_id) as question_count,
       COUNT(DISTINCT answer_id) as answer_count,
       AVG(contribution_score) as avg_contribution
   FROM faq_content_sources
   GROUP BY content_checksum
   ```

3. **View**: `v_faqs_affected_by_change` (for invalidation queries)
   ```sql
   -- Given changed checksums, find affected FAQs
   ```

4. **View**: `v_faq_source_summary` (FAQ-level source aggregation)
   ```sql
   SELECT
       question_id, answer_id,
       COUNT(CASE WHEN source_role IN ('question_source','both') THEN 1 END) as question_source_count,
       COUNT(CASE WHEN source_role IN ('answer_source','both') THEN 1 END) as answer_source_count,
       SUM(contribution_score) as total_contribution
   FROM faq_content_sources
   GROUP BY question_id, answer_id
   ```

**Deliverables**:
- ✅ 4+ views defined in v5 schema
- ✅ View documentation with use cases
- ✅ Example queries for common operations

---

### 🟢 **PHASE 3: CODE MIGRATION** (Week 3-4)

#### Task 3.1: Update FAQ Generation Pipeline
**Priority**: 🟡 HIGH
**Owner**: ML/RAG Engineer
**Duration**: 3-5 days

**Changes Required**:
1. **After question generation**:
   ```python
   # OLD CODE (v4):
   first_context_checksum = question_contexts[0].checksum

   # NEW CODE (v5):
   for idx, context in enumerate(question_contexts, 1):
       faq_content_sources.insert({
           'question_id': question_id,
           'answer_id': None,  # Not created yet
           'content_checksum': context.checksum,
           'content_id': context.content_id,
           'source_role': 'question_source',
           'contribution_score': context.score,
           'sequence_order': idx,
           'chunk_metadata': json.dumps(context.metadata)
       })
   ```

2. **After answer generation**:
   ```python
   # NEW CODE (v5):
   for idx, context in enumerate(answer_contexts, 1):
       # Check if already inserted as question source
       existing = faq_content_sources.get(
           question_id=question_id,
           content_checksum=context.checksum,
           source_role='question_source'
       )

       if existing:
           # Update to 'both'
           faq_content_sources.update(
               existing.source_id,
               source_role='both',
               answer_id=answer_id  # Add answer reference
           )
       else:
           # Insert as answer-only source
           faq_content_sources.insert({
               'question_id': question_id,
               'answer_id': answer_id,
               'content_checksum': context.checksum,
               'content_id': context.content_id,
               'source_role': 'answer_source',
               'contribution_score': context.score,
               'sequence_order': idx,
               'chunk_metadata': json.dumps(context.metadata)
           })
   ```

3. **Update faq_content_map insert**:
   ```python
   # OLD CODE (v4):
   faq_content_map.insert({
       'question_id': question_id,
       'answer_id': answer_id,
       'content_checksum': first_checksum,  # ❌ REMOVED
       'current_content_id': first_content_id,  # ❌ REMOVED
       # ... other content fields removed
   })

   # NEW CODE (v5):
   faq_content_map.insert({
       'question_id': question_id,
       'answer_id': answer_id,
       'generation_method': 'RAG_GPT4_v1',
       'generation_config': json.dumps({
           'model': 'gpt-4',
           'temperature': 0.7,
           'question_contexts_count': len(question_contexts),
           'answer_contexts_count': len(answer_contexts)
       }),
       'confidence_score': calculate_aggregate_confidence(
           question_contexts, answer_contexts
       )
   })
   ```

**Deliverables**:
- ✅ Updated FAQ generation code
- ✅ Unit tests for source insertion logic
- ✅ Integration tests for end-to-end flow

---

#### Task 3.2: Rewrite Invalidation Logic
**Priority**: 🔴 CRITICAL
**Owner**: Backend Engineer
**Duration**: 3-5 days

**Changes Required**:
1. **Replace old invalidation query**:
   ```python
   # OLD CODE (v4) - BROKEN:
   def invalidate_faqs(changed_checksums):
       conn.execute("""
           UPDATE faq_content_map
           SET is_valid = 0,
               valid_until = ?,
               invalidation_reason = 'content_edited'
           WHERE content_checksum IN (?)
       """, (now(), changed_checksums))

   # NEW CODE (v5) - CORRECT:
   def invalidate_faqs(changed_checksums):
       # Find affected FAQs
       affected_faqs = conn.execute("""
           SELECT DISTINCT
               fcs.question_id,
               fcs.answer_id,
               fcm.map_id,
               GROUP_CONCAT(fcs.content_checksum) as changed_sources
           FROM faq_content_sources fcs
           JOIN faq_content_map fcm
               ON fcs.question_id = fcm.question_id
               AND fcs.answer_id = fcm.answer_id
           WHERE fcs.content_checksum IN (?)
             AND fcm.is_valid = 1
           GROUP BY fcs.question_id, fcs.answer_id, fcm.map_id
       """, (changed_checksums,)).fetchall()

       # Invalidate each FAQ
       for faq in affected_faqs:
           conn.execute("""
               UPDATE faq_content_map
               SET is_valid = 0,
                   valid_until = ?,
                   invalidation_reason = 'source_content_changed',
                   invalidated_by_change_ids = ?
               WHERE map_id = ?
           """, (now(), json.dumps(faq.changed_sources), faq.map_id))
   ```

2. **Add smart invalidation (optional optimization)**:
   ```python
   def smart_invalidate(changed_checksums):
       # Implement Task 3.3 logic (weighted invalidation)
       pass
   ```

**Deliverables**:
- ✅ Updated `change_processor.py` or equivalent
- ✅ Updated `faq_mapper.py` or equivalent
- ✅ Unit tests covering:
   - Single-source FAQ invalidation
   - Multi-source FAQ invalidation
   - Partial source changes
   - No-source FAQs (if any)

---

#### Task 3.3: Implement Smart Invalidation (Optional - Phase 2)
**Priority**: 🟢 LOW
**Owner**: ML Engineer
**Duration**: 2-3 days

**Features**:
1. **Contribution-weighted invalidation**:
   - Only invalidate if high-contribution sources changed
   - Threshold: >50% contribution score changed

2. **Question-only vs Answer-only regeneration**:
   - If only question sources changed → regenerate question, reuse answer
   - If only answer sources changed → reuse question, regenerate answer

3. **Configurable thresholds**:
   - Make invalidation thresholds configurable
   - Different thresholds for different domains/services

**Deliverables**:
- ✅ `smart_invalidation.py` module
- ✅ Configuration schema for thresholds
- ✅ A/B testing framework (compare smart vs simple invalidation)

---

#### Task 3.4: Update Retrieval/Query APIs
**Priority**: 🟡 MEDIUM
**Owner**: Backend Engineer
**Duration**: 2-3 days

**Changes Required**:
1. **FAQ retrieval endpoint**:
   ```python
   # GET /api/faqs/{question_id}

   # OLD CODE (v4):
   def get_faq(question_id):
       faq = db.query("""
           SELECT fcm.*,
                  cr.extracted_markdown_file_path
           FROM faq_content_map fcm
           JOIN content_repo cr ON fcm.current_content_id = cr.ud_source_file_id
           WHERE fcm.question_id = ? AND fcm.is_valid = 1
       """, question_id)
       return faq  # Single content reference

   # NEW CODE (v5):
   def get_faq_with_sources(question_id):
       faq = db.query("""
           SELECT * FROM faq_content_map
           WHERE question_id = ? AND is_valid = 1
       """, question_id).fetchone()

       sources = db.query("""
           SELECT fcs.*, cr.extracted_markdown_file_path
           FROM faq_content_sources fcs
           JOIN content_repo cr ON fcs.content_id = cr.ud_source_file_id
           WHERE fcs.question_id = ?
           ORDER BY fcs.sequence_order
       """, question_id).fetchall()

       return {
           'faq': faq,
           'question_sources': [s for s in sources if s.source_role in ('question_source', 'both')],
           'answer_sources': [s for s in sources if s.source_role in ('answer_source', 'both')]
       }
   ```

2. **Content-to-FAQ lookup**:
   ```python
   # GET /api/content/{content_id}/faqs

   def get_faqs_using_content(content_id):
       return db.query("""
           SELECT DISTINCT
               fcs.question_id,
               fcs.answer_id,
               fcs.source_role,
               fcm.is_valid,
               q.question_txt,
               a.faq_answer_txt
           FROM faq_content_sources fcs
           JOIN faq_content_map fcm ON ...
           JOIN faq_questions q ON ...
           JOIN faq_answers a ON ...
           WHERE fcs.content_id = ?
       """, content_id)
   ```

**Deliverables**:
- ✅ Updated API endpoints
- ✅ API documentation (OpenAPI/Swagger)
- ✅ Integration tests

---

#### Task 3.5: Update Analytics Queries
**Priority**: 🟢 LOW
**Owner**: Data Analyst
**Duration**: 1-2 days

**Changes Required**:
1. **Dashboard queries** (if any exist):
   - Update to use `faq_content_sources` instead of `faq_content_map.content_checksum`
   - Fix any broken visualizations

2. **Reports**:
   - Content usage reports
   - FAQ quality reports
   - Invalidation statistics

**Deliverables**:
- ✅ Updated SQL queries in notebooks/dashboards
- ✅ Verified reports run without errors

---

### 🔵 **PHASE 4: TESTING & VALIDATION** (Week 5)

#### Task 4.1: Create Test Data
**Priority**: 🟡 HIGH
**Owner**: QA/Test Engineer
**Duration**: 1 day

**Test Scenarios**:
1. **Single-source FAQ**:
   - 1 question source = 1 answer source (same content)
   - Expected: 1 row in `faq_content_sources`, role='both'

2. **Multi-source FAQ (separate Q&A)**:
   - 3 question sources
   - 4 answer sources
   - No overlap
   - Expected: 7 rows in `faq_content_sources`

3. **Multi-source FAQ (overlapping Q&A)**:
   - 5 question sources
   - 5 answer sources
   - 2 sources used for both
   - Expected: 8 rows (3 Q-only + 3 A-only + 2 both)

4. **Edge cases**:
   - FAQ with 0 sources (should this be allowed?)
   - FAQ with NULL answer_id (question-only FAQ)
   - Very high source count (10+ sources)

**Deliverables**:
- ✅ Test data generation script
- ✅ Test database with all scenarios
- ✅ Expected results documentation

---

#### Task 4.2: Integration Testing
**Priority**: 🔴 CRITICAL
**Owner**: QA Engineer
**Duration**: 3-5 days

**Test Cases**:
1. **FAQ Generation Flow**:
   - Input: Query → Retriever returns 5 contexts
   - Expected: 5 rows inserted into `faq_content_sources`
   - Validate: All sources correctly linked to question_id

2. **Invalidation Flow**:
   - Setup: Create FAQ with 3 sources [A, B, C]
   - Action: Mark checksum B as changed
   - Expected: FAQ invalidated
   - Validate: `invalidated_by_change_ids` contains change_id for B

3. **Smart Invalidation Flow**:
   - Setup: FAQ with 4 sources, contributions [0.9, 0.1, 0.1, 0.1]
   - Action: Mark low-contribution source (0.1) as changed
   - Expected: FAQ NOT invalidated (below threshold)
   - Validate: is_valid = 1

4. **Retrieval Flow**:
   - Setup: FAQ with sources in specific order [A, B, C]
   - Action: Retrieve FAQ sources ordered by sequence_order
   - Expected: Sources returned in correct order
   - Validate: sequence_order preserved

**Deliverables**:
- ✅ Integration test suite
- ✅ Test execution report (pass/fail)
- ✅ Bug tickets for any failures

---

#### Task 4.3: Performance Testing
**Priority**: 🟡 MEDIUM
**Owner**: Performance Engineer
**Duration**: 2-3 days

**Benchmarks**:
1. **FAQ generation with N sources** (N = 1, 5, 10, 20):
   - Measure insertion time
   - Acceptable: <100ms for 20 sources

2. **Invalidation query with M changed checksums** (M = 1, 10, 100):
   - Measure query time to find affected FAQs
   - Acceptable: <500ms for 100 checksums

3. **FAQ retrieval with sources**:
   - Measure JOIN performance (faq_content_map + faq_content_sources)
   - Acceptable: <50ms per FAQ

4. **Index effectiveness**:
   - Run EXPLAIN QUERY PLAN on all critical queries
   - Ensure indexes are being used

**Deliverables**:
- ✅ Performance test results
- ✅ Index optimization recommendations (if needed)
- ✅ Go/No-go decision for production

---

### 🟣 **PHASE 5: MIGRATION & DEPLOYMENT** (Week 6)

#### Task 5.1: Data Migration Strategy
**Priority**: 🔴 CRITICAL
**Owner**: Database Admin
**Duration**: 1 day

**Decision Point**: Can we migrate existing data?

**Option A: Migrate Existing FAQs** (if existing data in prod):
```sql
-- For each FAQ in old schema:
-- 1. Keep faq_content_map row (remove content fields)
-- 2. Create 1 row in faq_content_sources with best guess
-- 3. Mark FAQ as "needs_regeneration" flag

-- Migration script (rough):
INSERT INTO faq_content_sources (
    question_id, answer_id, content_checksum, content_id,
    source_role, contribution_score, sequence_order
)
SELECT
    question_id,
    answer_id,
    content_checksum,  -- Old single-source reference
    current_content_id,
    'both',  -- Assume used for both Q&A
    1.0,  -- Unknown contribution
    1  -- First source
FROM faq_content_map_v4
WHERE is_valid = 1;

-- Flag for regeneration
UPDATE faq_content_map
SET generation_method = 'migrated_v4_single_source',
    confidence_score = 0.5  -- Lower confidence for migrated data
WHERE generation_method IS NULL;
```

**Option B: Regenerate All FAQs** (recommended if feasible):
- Drop old FAQ data
- Run FAQ generation pipeline from scratch with new schema
- Ensures all FAQs have complete multi-source tracking

**Deliverables**:
- ✅ Migration decision documented
- ✅ Migration script (if Option A)
- ✅ Rollback plan
- ✅ Downtime estimate

---

#### Task 5.2: Schema Migration Execution
**Priority**: 🔴 CRITICAL
**Owner**: Database Admin + Dev Lead
**Duration**: 1 day (includes testing)

**Steps**:
1. **Backup production database** (if applicable)
2. **Run migration in staging environment**
3. **Validate migration** (run test queries)
4. **Schedule production migration** (with downtime if needed)
5. **Execute production migration**
6. **Validate production** (smoke tests)
7. **Monitor for 24 hours**

**Deliverables**:
- ✅ Successful schema migration
- ✅ Data validation report
- ✅ Rollback plan (ready to execute if needed)

---

#### Task 5.3: Code Deployment
**Priority**: 🔴 CRITICAL
**Owner**: DevOps + Dev Lead
**Duration**: 1 day

**Steps**:
1. Deploy updated code (Tasks 3.1-3.4)
2. Feature flag: Enable new schema gradually
3. Monitor error logs
4. Validate FAQ generation still works
5. Full rollout if no issues

**Deliverables**:
- ✅ Deployed code to production
- ✅ Monitoring dashboard showing health metrics
- ✅ Post-deployment validation report

---

### 🎯 **PHASE 6: POST-DEPLOYMENT** (Ongoing)

#### Task 6.1: Monitor FAQ Quality
**Priority**: 🟡 MEDIUM
**Owner**: ML Engineer + Product
**Duration**: Ongoing (2 weeks intensive)

**Metrics**:
1. **FAQ accuracy**: Has accuracy improved/degraded?
2. **Source diversity**: Average sources per FAQ (should be >1 for multi-source)
3. **Invalidation rate**: Are FAQs being invalidated correctly?
4. **Regeneration rate**: How often are FAQs regenerated?

**Deliverables**:
- ✅ Quality dashboard
- ✅ Weekly quality reports (2 weeks)
- ✅ Issue log (track any quality degradations)

---

#### Task 6.2: Optimize Smart Invalidation
**Priority**: 🟢 LOW
**Owner**: ML Engineer
**Duration**: 1-2 weeks

**Experiment**:
1. Run A/B test: Simple invalidation vs Smart invalidation
2. Measure:
   - API cost reduction (from reusing questions/answers)
   - Quality impact (does smart invalidation reduce accuracy?)
3. Tune thresholds based on results
4. Rollout winning strategy

**Deliverables**:
- ✅ A/B test results
- ✅ Optimized thresholds configuration
- ✅ Production rollout (if beneficial)

---

#### Task 6.3: Documentation Updates
**Priority**: 🟡 MEDIUM
**Owner**: Tech Writer + Data Architect
**Duration**: 2-3 days

**Documents to Update**:
1. **Schema documentation**: Add junction table design
2. **API documentation**: Update endpoint specs
3. **Developer guide**: How to use faq_content_sources
4. **Runbooks**: Updated invalidation procedures
5. **Architecture diagrams**: New ERD with junction table

**Deliverables**:
- ✅ Updated documentation (Confluence/Wiki)
- ✅ Code comments in SQL schema
- ✅ README updates in repo

---

## 📊 Summary Metrics

### Effort Estimation

| Phase | Duration | Team Size | Effort (person-days) |
|-------|----------|-----------|---------------------|
| Phase 1: Requirements | 1 week | 3 | 15 |
| Phase 2: Schema Design | 1 week | 2 | 10 |
| Phase 3: Code Migration | 2 weeks | 4 | 40 |
| Phase 4: Testing | 1 week | 3 | 15 |
| Phase 5: Deployment | 1 week | 3 | 15 |
| Phase 6: Post-Deploy | 2 weeks | 2 | 20 |
| **TOTAL** | **8 weeks** | **Varies** | **115 person-days** |

**Team Composition**:
- Data Architect (full-time, 8 weeks)
- ML/RAG Engineer (full-time, 4 weeks)
- Backend Engineers (2x, 3 weeks each)
- QA Engineer (full-time, 2 weeks)
- DevOps (part-time, 1 week)
- Product Manager (part-time, 1 week)

---

### Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Requirements change mid-project | MEDIUM | HIGH | Lock requirements in Phase 1, get sign-off |
| Data migration fails | LOW | CRITICAL | Thorough testing in staging, rollback plan |
| Performance degradation | MEDIUM | MEDIUM | Benchmark in Phase 4, optimize indexes |
| FAQ quality degrades | LOW | HIGH | Monitor closely in Phase 6, quick rollback if needed |
| Team capacity issues | MEDIUM | MEDIUM | Adjust timeline, prioritize critical tasks |

---

## 🎯 Decision Points

### Decision #1: Proceed with Full Redesign?
**Options**:
- ✅ **Option A**: Full junction table redesign (recommended)
  - **Pros**: Correct data model, supports all requirements, scalable
  - **Cons**: 8 weeks effort, moderate risk

- ❌ **Option B**: Keep current schema, limit to single-source FAQs
  - **Pros**: No changes needed, zero risk
  - **Cons**: Cannot support multi-source FAQs, business requirement NOT met

- ❌ **Option C**: Store sources as JSON array in current schema
  - **Pros**: Minimal schema change
  - **Cons**: Violates normalization, poor query performance, cannot enforce FK, difficult to maintain

**Recommendation**: **Option A** (Full redesign)

---

### Decision #2: Migration Strategy?
**Options**:
- ✅ **Option A**: Regenerate all FAQs from scratch (recommended)
  - **Pros**: Clean data, full source tracking from day 1
  - **Cons**: API costs to regenerate, temporary FAQ unavailability

- ⚠️ **Option B**: Migrate existing data with partial info
  - **Pros**: Preserve existing FAQs, no regeneration needed
  - **Cons**: Migrated FAQs have incomplete source data (single-source only)

**Recommendation**: **Option A** if FAQ count is small (<10k) or regeneration is fast. **Option B** if FAQ count is large (>100k) and regeneration is expensive.

---

### Decision #3: Deployment Approach?
**Options**:
- ✅ **Option A**: Schema + code deployed together (recommended for dev)
  - **Pros**: Simpler, atomic deployment
  - **Cons**: Requires downtime or careful feature flagging

- ⚠️ **Option B**: Phased deployment (schema first, code later)
  - **Pros**: Can deploy schema in advance, test separately
  - **Cons**: More complex, requires backward compatibility

**Recommendation**: **Option A** for dev environment, **Option B** for production (if zero-downtime required)

---

## 📌 IMMEDIATE ACTION ITEMS (THIS WEEK)

### 🔥 **DO THESE NOW** (Before any coding):

1. **[ ] Validate Requirements** (Task 1.1)
   - Confirm multi-source FAQ generation is REAL (not theoretical)
   - Check current RAG implementation: How many contexts used?
   - Define cardinality limits (max sources per FAQ)

2. **[ ] Call Design Review Meeting** (Task 1.2)
   - Present this analysis document
   - Get stakeholder buy-in
   - Decide: Go/No-go on redesign

3. **[ ] Impact Analysis** (Task 1.3)
   - Audit codebase for `faq_content_map` usage
   - Estimate effort
   - Assess risks

4. **[ ] Create Decision Log**
   - Document all decisions made
   - Get sign-offs from stakeholders
   - Publish to team

---

## 📞 Next Steps

**After reading this document**:

1. **Schedule design review meeting** (include all stakeholders)
2. **Assign owner for each Phase 1 task**
3. **Set deadlines for Phase 1 completion** (1 week target)
4. **Review and approve this TODO list** (add/remove tasks as needed)
5. **Communicate to team** (share this document, gather feedback)

**Questions to Answer**:
- [ ] Is multi-source FAQ generation a real requirement? (Validate with Product)
- [ ] What % of FAQs are currently multi-source? (Analyze existing data)
- [ ] Can we afford 8 weeks for this redesign? (Discuss with management)
- [ ] Should we defer to future release? (Prioritization decision)
- [ ] Do we have the team capacity? (Resource planning)

---

**END OF ANALYSIS**

**Document Version**: 1.0
**Last Updated**: 2025-10-20
**Status**: DRAFT - Awaiting stakeholder review
**Next Review**: After Phase 1 completion
