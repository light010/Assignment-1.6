#!/usr/bin/env python3
"""
Fix paths and ID mismatches in setup_tables.ipynb

This script:
1. Converts relative paths to environment-aware absolute paths
2. Fixes ID mismatches in test data generators (1-8 → 1001-1010)
3. Updates commented out code to use correct IDs
"""

import json
import os
from pathlib import Path

# File paths
NOTEBOOK_PATH = Path(__file__).parent.parent / 'notebooks' / 'setup_tables.ipynb'
BACKUP_PATH = NOTEBOOK_PATH.with_suffix('.ipynb.backup')

def fix_paths(cell_source):
    """Replace relative paths with environment-aware paths"""
    replacements = [
        (
            "DATABASE_DIR = Path('../databases')\n"
            "SQL_DIR = Path('../sql')\n"
            "DOCS_DIR = Path('../docs')\n"
            "TEST_DATA_DIR = Path('../docs/test_sample_data')",

            "# Environment-aware path configuration\n"
            "import os\n"
            "ENV = os.getenv('ENVIRONMENT', 'local')  # Default to local for development\n"
            "REGION = os.getenv('REGION', 'us-east-1')\n\n"
            "if ENV == 'local':\n"
            "    # Local development - use relative paths\n"
            "    BASE_DIR = Path(__file__).parent.parent if '__file__' in globals() else Path('../')\n"
            "    DATABASE_DIR = BASE_DIR / 'databases'\n"
            "    SQL_DIR = BASE_DIR / 'sql'\n"
            "    DOCS_DIR = BASE_DIR / 'docs'\n"
            "    TEST_DATA_DIR = DOCS_DIR / 'test_sample_data'\n"
            "elif ENV in ['DIT', 'FIT']:\n"
            "    # Databricks non-prod environments\n"
            "    VOLUME_BASE = f'/Volumes/onedata_{REGION.replace(\"-\", \"_\")}_shared_{ENV.lower()}/faq_services'\n"
            "    DATABASE_DIR = Path(VOLUME_BASE) / 'databases'\n"
            "    SQL_DIR = Path(VOLUME_BASE) / 'sql'\n"
            "    DOCS_DIR = Path(VOLUME_BASE) / 'docs'\n"
            "    TEST_DATA_DIR = DOCS_DIR / 'test_sample_data'\n"
            "else:\n"
            "    # Databricks production environment\n"
            "    VOLUME_BASE = f'/Volumes/onedata_{REGION.replace(\"-\", \"_\")}_shared_prod/faq_services'\n"
            "    DATABASE_DIR = Path(VOLUME_BASE) / 'databases'\n"
            "    SQL_DIR = Path(VOLUME_BASE) / 'sql'\n"
            "    DOCS_DIR = Path(VOLUME_BASE) / 'docs'\n"
            "    TEST_DATA_DIR = DOCS_DIR / 'test_sample_data'"
        ),
    ]

    for old, new in replacements:
        cell_source = cell_source.replace(old, new)

    return cell_source

def fix_id_mismatches(cell_source):
    """Fix ID mismatches in faq_content_map test data generator"""
    # Map of old IDs to new IDs
    id_mapping = {
        "'question_id': 1,": "'question_id': 1001,",
        "'question_id': 2,": "'question_id': 1002,",
        "'question_id': 3,": "'question_id': 1003,",
        "'question_id': 4,": "'question_id': 1004,",
        "'question_id': 5,": "'question_id': 1005,",
        "'question_id': 8,": "'question_id': 1008,",

        # Also fix answer IDs if they exist
        "'answer_id': 1,": "'answer_id': 1001,",
        "'answer_id': 2,": "'answer_id': 1002,",
        "'answer_id': 3,": "'answer_id': 1003,",
        "'answer_id': 4,": "'answer_id': 1004,",
        "'answer_id': 5,": "'answer_id': 1005,",
        "'answer_id': 8,": "'answer_id': 1008,",
    }

    for old, new in id_mapping.items():
        cell_source = cell_source.replace(old, new)

    return cell_source

def add_warning_comment(cell_source):
    """Add warning comment about ID consistency"""
    if "'question_id':" in cell_source and "generate_test_faq_content_map" in cell_source:
        warning = (
            "# WARNING: Ensure question_id and answer_id values match those in\n"
            "# generate_test_faq_questions() and generate_test_faq_answers()\n"
            "# Current test data uses IDs: 1001-1010\n\n"
        )
        if warning not in cell_source:
            # Add warning at start of function
            cell_source = cell_source.replace(
                "def generate_test_faq_content_map(",
                f"{warning}def generate_test_faq_content_map("
            )

    return cell_source

def process_notebook():
    """Process the notebook file"""
    print(f"Reading notebook: {NOTEBOOK_PATH}")

    # Backup original
    if not BACKUP_PATH.exists():
        print(f"Creating backup: {BACKUP_PATH}")
        with open(NOTEBOOK_PATH, 'r', encoding='utf-8') as f:
            backup_content = f.read()
        with open(BACKUP_PATH, 'w', encoding='utf-8') as f:
            f.write(backup_content)

    # Load notebook
    with open(NOTEBOOK_PATH, 'r', encoding='utf-8') as f:
        notebook = json.load(f)

    changes_made = 0

    # Process each cell
    for cell in notebook.get('cells', []):
        if cell.get('cell_type') == 'code':
            source = ''.join(cell.get('source', []))
            original_source = source

            # Apply fixes
            source = fix_paths(source)
            source = fix_id_mismatches(source)
            source = add_warning_comment(source)

            # Update cell if changed
            if source != original_source:
                cell['source'] = source.splitlines(keepends=True)
                changes_made += 1

    # Save updated notebook
    if changes_made > 0:
        print(f"Made changes to {changes_made} cells")
        with open(NOTEBOOK_PATH, 'w', encoding='utf-8') as f:
            json.dump(notebook, f, indent=1, ensure_ascii=False)
        print(f"✅ Notebook updated: {NOTEBOOK_PATH}")
    else:
        print("ℹ️  No changes needed")

    return changes_made

if __name__ == '__main__':
    try:
        changes = process_notebook()
        print(f"\n{'='*60}")
        print(f"Summary: {changes} cells modified")
        print(f"Backup saved to: {BACKUP_PATH}")
        print(f"{'='*60}")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()