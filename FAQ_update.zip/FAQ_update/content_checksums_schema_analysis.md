# Deep Analysis: content_checksums Schema Design

## 🔍 CURRENT SCHEMA EVALUATION

### Current Schema:
```sql
CREATE TABLE IF NOT EXISTS content_checksums (
    -- Primary Identity
    content_checksum TEXT NOT NULL,

    -- Content Properties
    file_type TEXT,
    content_format TEXT,
    title TEXT,
    status TEXT NOT NULL DEFAULT 'active',

    -- METADATA: Location information (for human reference only, NOT for analysis)
    file_name TEXT,
    url TEXT,
    source_file_path TEXT,
    file_version TEXT,  ← EXISTS but is TEXT type!

    -- Content Storage
    markdown_file_path TEXT,

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
    CONSTRAINT chk_content_status CHECK (status IN ('active', 'archived', 'deleted'))
);
```

---

## ✅ GOOD NEWS: Schema Already Has `file_version`!

**I MISSED THIS!** The schema already has a `file_version` column (line 26).

However, there are **critical issues** with how it's defined and used.

---

## 🚨 CRITICAL ISSUES WITH CURRENT SCHEMA

### Issue #1: `file_version` is TEXT, Not INTEGER

```sql
file_version TEXT,  ← Should be INTEGER or stored as "v1", "v2"?
```

**Questions:**
1. What format are you using? `"1"`, `"v1"`, `"2"`, `"v2"`?
2. Should this be INTEGER for proper sorting/comparison?
3. Is it nullable? (What about content from URLs with no version?)

**Problem:**
- TEXT comparison: `"10" < "2"` (alphabetical, wrong!)
- INTEGER comparison: `10 > 2` (numeric, correct!)

**Recommendation:**
- Use INTEGER if versions are always numeric
- Or use TEXT with format "v{number}" and proper constraints

---

### Issue #2: No PRIMARY KEY Constraint

```sql
content_checksum TEXT NOT NULL,  ← NOT NULL but not PRIMARY KEY!
```

**Current behavior:**
- Same checksum can be inserted multiple times
- No uniqueness enforcement
- Can create duplicates!

**Example of the problem:**
```sql
-- First insertion (Notebook 1, v1 of Employee_Handbook, chunk 1)
INSERT INTO content_checksums VALUES ('abc123...', 'Employee_Handbook.pdf', '1', ...);

-- Second insertion (accidentally re-run Notebook 1)
INSERT INTO content_checksums VALUES ('abc123...', 'Employee_Handbook.pdf', '1', ...);
-- ✅ SUCCEEDS! Creates duplicate row with same checksum
```

**Impact:**
- `SELECT * FROM content_checksums WHERE file_name = 'X'` returns duplicates
- Change detection gets confused
- Database bloat

---

### Issue #3: No CHUNK CONTENT Storage

```sql
-- Content Storage
markdown_file_path TEXT,  ← Only stores FILE path, not chunk content!
```

**Current workflow (as I understand it):**

**Notebook 1 (Baseline):**
```python
# 1. Read file
content = read_file('Employee_Handbook_v1.md')

# 2. Chunk it
chunks = chunker.chunk_with_checksums(content)
# Result: [('chunk1 text...', 'abc123'), ('chunk2 text...', 'def456'), ...]

# 3. Store checksums
for chunk_text, checksum in chunks:
    INSERT INTO content_checksums (
        content_checksum='abc123',
        file_name='Employee_Handbook.pdf',
        markdown_file_path='path/to/Employee_Handbook_v1.md',  ← FILE path
        file_version='1'
    )
```

**Problem:** You're NOT storing `chunk_text`!

**Notebook 4 (Change Detection):**
```python
# Load previous checksums
old_checksums = SELECT * FROM content_checksums WHERE file_name = 'X'
# Returns: [{'content_checksum': 'abc123', 'markdown_file_path': 'path/to/file.md'}, ...]

# To get chunk content, you have to:
# 1. Read the ENTIRE file again
# 2. Re-chunk it
# 3. Find matching checksum

file_content = read_file(old_checksums[0]['markdown_file_path'])
chunks = chunker.chunk_with_checksums(file_content)
for chunk_text, checksum in chunks:
    if checksum == 'abc123':
        # Found the chunk!
        previous_data[checksum] = {'content_text': chunk_text}
```

**This is INEFFICIENT and FRAGILE:**
- Re-chunking is computational overhead
- If chunking algorithm changes, checksums won't match!
- If file is deleted, can't retrieve chunk content

---

### Issue #4: No Chunk Position/Order Tracking

**Scenario:**
```
Employee_Handbook_v1.md (5000 chars) → 5 chunks:
- Chunk 0: checksum='aaa111', text='Introduction...'
- Chunk 1: checksum='bbb222', text='Section 1...'
- Chunk 2: checksum='ccc333', text='Section 2...'
- Chunk 3: checksum='ddd444', text='Section 3...'
- Chunk 4: checksum='eee555', text='Conclusion...'
```

**Current schema stores:**
```sql
content_checksum | file_name             | file_version
'aaa111'         | Employee_Handbook.pdf | 1
'bbb222'         | Employee_Handbook.pdf | 1
'ccc333'         | Employee_Handbook.pdf | 1
'ddd444'         | Employee_Handbook.pdf | 1
'eee555'         | Employee_Handbook.pdf | 1
```

**Problems:**
1. **No chunk order** - Can't reconstruct original sequence
2. **No chunk position** - Don't know where chunk came from in file
3. **No page numbers** - Can't tell which page the chunk is from

**Use cases that break:**
- "Show me chunks from page 5"
- "Reconstruct the original file from chunks"
- "What changed on page 3?"

---

### Issue #5: Mixing Version Tracking Approaches

Your workflow uses **TWO** places for version info:

1. **content_repo table:**
   - Has `raw_file_version_nbr INTEGER`
   - Properly typed as INTEGER
   - Represents file version

2. **content_checksums table:**
   - Has `file_version TEXT`
   - Poorly typed as TEXT
   - Represents... what? File version? Chunk version?

**Confusion:**
- Should `content_checksums.file_version` match `content_repo.raw_file_version_nbr`?
- What if they get out of sync?
- Why duplicate this information?

---

## 💡 PROPOSED SCHEMA IMPROVEMENTS

### Option 1: Minimal Changes (Quick Fix)

**Goal:** Fix immediate issues without major refactoring

```sql
CREATE TABLE IF NOT EXISTS content_checksums (
    -- Primary Identity (MADE PRIMARY KEY)
    content_checksum TEXT PRIMARY KEY,  ← ADD PRIMARY KEY CONSTRAINT

    -- Content Properties
    file_type TEXT,
    content_format TEXT,
    title TEXT,
    status TEXT NOT NULL DEFAULT 'active',

    -- METADATA: Location information
    file_name TEXT NOT NULL,  ← ADD NOT NULL
    url TEXT,
    source_file_path TEXT,
    file_version INTEGER,  ← CHANGE to INTEGER (or keep TEXT with format 'v1', 'v2')

    -- Content Storage (ADD CHUNK DATA)
    chunk_text TEXT,  ← ADD THIS! Store actual chunk content
    chunk_index INTEGER,  ← ADD THIS! Store chunk position (0, 1, 2, ...)
    chunk_page_number INTEGER,  ← ADD THIS! Optional page number
    markdown_file_path TEXT,  ← Keep for reference

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
    CONSTRAINT chk_content_status CHECK (status IN ('active', 'archived', 'deleted'))
);

-- Add composite unique index for file+version+chunk tracking
CREATE UNIQUE INDEX IF NOT EXISTS idx_file_version_chunk
ON content_checksums(file_name, file_version, chunk_index);
```

**Pros:**
✅ Prevents duplicate checksums (PRIMARY KEY)
✅ Stores chunk content (no re-chunking needed)
✅ Tracks chunk order (chunk_index)
✅ Version-aware (file_version INTEGER)

**Cons:**
⚠️ Breaks existing code that assumes checksum can repeat
⚠️ Requires data migration
⚠️ Increases storage (chunk_text duplication)

---

### Option 2: Full Redesign (Proper Normalization)

**Goal:** Proper database design with separate tables

```sql
-- Table 1: Files (one row per file version)
CREATE TABLE IF NOT EXISTS content_files (
    file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_name TEXT NOT NULL,
    file_version INTEGER NOT NULL,
    file_path TEXT,
    markdown_path TEXT,
    file_type TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active',

    UNIQUE(file_name, file_version)
);

-- Table 2: Chunks (many rows per file, each with checksum)
CREATE TABLE IF NOT EXISTS content_chunks (
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER NOT NULL,  -- Foreign key to content_files
    chunk_index INTEGER NOT NULL,  -- Position in file (0, 1, 2, ...)
    content_checksum TEXT NOT NULL UNIQUE,  -- Checksum of chunk
    chunk_text TEXT NOT NULL,  -- Actual chunk content
    chunk_page_number INTEGER,  -- Optional page number
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (file_id) REFERENCES content_files(file_id),
    UNIQUE(file_id, chunk_index),
    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_chunks_checksum ON content_chunks(content_checksum);
CREATE INDEX IF NOT EXISTS idx_chunks_file ON content_chunks(file_id);
```

**Pros:**
✅ Proper normalization (no data duplication)
✅ Clear relationships (file → chunks)
✅ Supports all use cases
✅ Scalable and maintainable

**Cons:**
⚠️ Requires major refactoring of all code
⚠️ More complex queries (JOINs needed)
⚠️ Migration complexity

---

### Option 3: Hybrid Approach (Composite Primary Key)

**Goal:** Keep current table, but make checksum+version+chunk unique

```sql
CREATE TABLE IF NOT EXISTS content_checksums (
    -- Primary Identity (COMPOSITE KEY)
    content_checksum TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_version INTEGER NOT NULL,
    chunk_index INTEGER NOT NULL,

    -- Content Properties
    file_type TEXT,
    content_format TEXT,
    title TEXT,
    status TEXT NOT NULL DEFAULT 'active',

    -- Location
    url TEXT,
    source_file_path TEXT,

    -- Content Storage
    chunk_text TEXT NOT NULL,  ← Store chunk content
    chunk_page_number INTEGER,
    markdown_file_path TEXT,

    -- Timestamps
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (file_name, file_version, chunk_index),  ← COMPOSITE PRIMARY KEY

    CONSTRAINT chk_checksum_length CHECK (LENGTH(content_checksum) = 64),
    CONSTRAINT chk_content_status CHECK (status IN ('active', 'archived', 'deleted'))
);

-- Unique index on checksum (each checksum should be unique too)
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_checksum
ON content_checksums(content_checksum);
```

**Pros:**
✅ Prevents duplicates
✅ Stores chunk content
✅ Tracks versions and order
✅ Can query by file+version or by checksum

**Cons:**
⚠️ More complex primary key
⚠️ Harder to reference from other tables

---

## 🎯 RECOMMENDATION: Option 1 (Minimal Changes)

For your current workflow, I recommend **Option 1** with these changes:

### Step 1: Update Schema

```sql
-- Add new columns (ALTER TABLE)
ALTER TABLE content_checksums ADD COLUMN chunk_text TEXT;
ALTER TABLE content_checksums ADD COLUMN chunk_index INTEGER;
ALTER TABLE content_checksums ADD COLUMN chunk_page_number INTEGER;

-- Change file_version to INTEGER (requires migration)
-- Option A: If using numeric versions (1, 2, 3)
ALTER TABLE content_checksums ADD COLUMN file_version_nbr INTEGER;
UPDATE content_checksums SET file_version_nbr = CAST(file_version AS INTEGER);
ALTER TABLE content_checksums DROP COLUMN file_version;
ALTER TABLE content_checksums RENAME COLUMN file_version_nbr TO file_version;

-- Option B: If using text versions ('v1', 'v2')
-- Keep as TEXT but add constraint
ALTER TABLE content_checksums ADD CONSTRAINT chk_file_version
CHECK (file_version GLOB 'v[0-9]*');
```

### Step 2: Add Unique Constraint (Prevent Duplicates)

```sql
-- Prevent same checksum from being inserted twice
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_checksum_per_version
ON content_checksums(content_checksum, file_version);

-- Or even stricter: each checksum should be globally unique
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_checksum
ON content_checksums(content_checksum);
```

### Step 3: Update Notebook 1 Code

```python
# Current (WRONG - doesn't store chunk text):
for chunk_text, checksum in chunks:
    conn.execute("""
        INSERT INTO content_checksums
        (content_checksum, file_name, file_version, markdown_file_path)
        VALUES (?, ?, ?, ?)
    """, (checksum, file_name, version, markdown_path))

# Fixed (stores chunk text and index):
for chunk_index, (chunk_text, checksum) in enumerate(chunks):
    conn.execute("""
        INSERT INTO content_checksums
        (content_checksum, file_name, file_version, chunk_index, chunk_text, markdown_file_path, status)
        VALUES (?, ?, ?, ?, ?, ?, 'active')
    """, (checksum, file_name, version, chunk_index, chunk_text, markdown_path))
```

### Step 4: Update Notebook 4 Code

```python
# Current (INEFFICIENT - re-reads and re-chunks file):
old_checksums_df = pd.read_sql_query("""
    SELECT * FROM content_checksums WHERE file_name = ?
""", conn, params=[file_name])

# Read file and re-chunk
prev_path = PROJECT_ROOT / prev_file['markdown_path']
prev_content = prev_path.read_text(encoding='utf-8')
prev_chunks = chunker.chunk_with_checksums(prev_content)

# Match checksums to get text
for chunk_text, checksum in prev_chunks:
    previous_data[checksum] = {'content_text': chunk_text}

# Fixed (EFFICIENT - loads chunk text from database):
old_checksums_df = pd.read_sql_query("""
    SELECT content_checksum, chunk_text, file_name, chunk_index
    FROM content_checksums
    WHERE file_name = ? AND file_version = ?
    ORDER BY chunk_index
""", conn, params=[file_name, prev_version])

# Directly use stored chunk text
for _, row in old_checksums_df.iterrows():
    previous_data[row['content_checksum']] = {
        'content_text': row['chunk_text'],
        'file_name': row['file_name']
    }
```

---

## 🔍 ANSWERING YOUR SPECIFIC QUESTIONS

### Q1: "Multiple entries for same file?"

**A:** YES, this is CORRECT and EXPECTED!

```
Employee_Handbook.pdf v1 → 5 chunks → 5 rows in content_checksums
Employee_Handbook.pdf v2 → 5 chunks → 5 rows in content_checksums
Total: 10 rows for same file (different versions and chunks)
```

**But:** Each row should be UNIQUE by `(file_name, file_version, chunk_index)`

**Problem:** Current schema allows DUPLICATE rows with same checksum!

**Solution:** Add `PRIMARY KEY (content_checksum)` or `UNIQUE INDEX`

---

### Q2: "Should I store chunk text?"

**A:** YES, ABSOLUTELY!

**Reasons:**
1. **Performance:** No need to re-read and re-chunk files
2. **Reliability:** If file is deleted, chunk content is preserved
3. **Consistency:** If chunking algorithm changes, old chunks remain intact
4. **Use case:** Can directly retrieve chunk content for FAQ generation

**Storage concern:** Yes, it increases database size, but:
- Text compression is good in SQLite
- Performance gain > storage cost
- Chunks are typically small (1000-2000 chars)

---

### Q3: "How to make it version-aware without timestamp?"

**A:** Use `file_version` column properly!

**Current problem:** `file_version` exists but is TEXT and not used properly

**Solution:**

```sql
-- Query for v1 checksums (baseline)
SELECT * FROM content_checksums
WHERE file_name = 'Employee_Handbook.pdf' AND file_version = 1;

-- Query for v2 checksums (current)
SELECT * FROM content_checksums
WHERE file_name = 'Employee_Handbook.pdf' AND file_version = 2;

-- Query for latest version
SELECT cc.* FROM content_checksums cc
INNER JOIN (
    SELECT file_name, MAX(file_version) as max_ver
    FROM content_checksums
    GROUP BY file_name
) latest ON cc.file_name = latest.file_name
         AND cc.file_version = latest.max_ver;
```

**No timestamp needed!** Version number is explicit and reliable.

---

## ✅ FINAL RECOMMENDATION

### Immediate Actions:

1. **Add columns:**
   ```sql
   ALTER TABLE content_checksums ADD COLUMN chunk_text TEXT;
   ALTER TABLE content_checksums ADD COLUMN chunk_index INTEGER;
   ```

2. **Convert file_version to INTEGER:**
   ```sql
   -- Migrate data: '1' → 1, '2' → 2
   UPDATE content_checksums SET file_version = CAST(file_version AS INTEGER);
   ```

3. **Add unique constraint:**
   ```sql
   CREATE UNIQUE INDEX idx_unique_checksum ON content_checksums(content_checksum);
   ```

4. **Update Notebook 1:** Store `chunk_text` and `chunk_index`

5. **Update Notebook 4:** Load `chunk_text` from database (don't re-chunk)

### This solves ALL your concerns:
✅ Multiple chunks per file supported
✅ Chunk content stored (no re-chunking)
✅ Version-aware (use file_version, not timestamp)
✅ Prevents duplicates (unique constraint)
✅ Maintains chunk order (chunk_index)
