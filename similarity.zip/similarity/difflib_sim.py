"""
Simplified difflib-based similarity implementation.

Uses Python's difflib.SequenceMatcher for computing similarity ratios.
Clean, minimal implementation - no batch processing, no caching, no performance tracking.

Design Principles:
- Simplicity over complexity
- Core difflib algorithm preserved
- Useful helper methods kept (diff blocks, unified diff)
- Factory functions for common use cases
"""

import difflib
from typing import Dict, List, NamedTuple, Tuple

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)


class DiffBlock(NamedTuple):
    """Represents a diff operation block."""

    tag: str  # 'replace', 'delete', 'insert', 'equal'
    i1: int  # Start index in first sequence
    i2: int  # End index in first sequence
    j1: int  # Start index in second sequence
    j2: int  # End index in second sequence
    text1: str  # Text from first sequence
    text2: str  # Text from second sequence


class DifflibSimilarityCalculator(BaseSimilarityCalculator):
    """
    Simplified similarity calculator using Python's difflib.SequenceMatcher.

    Provides a ratio between 0.0 and 1.0 based on the Ratcliff/Obershelp
    gestalt pattern matching algorithm.
    """

    def __init__(
        self,
        autojunk: bool = True,
        use_quick_ratio: bool = False,
        lowercase: bool = True,
        remove_punctuation: bool = False,
        min_token_length: int = 1,
    ):
        """
        Initialize difflib similarity calculator.

        Args:
            autojunk: Automatically treat certain sequences as junk
            use_quick_ratio: Use quick_ratio() for faster but less accurate results
            lowercase: Convert text to lowercase
            remove_punctuation: Remove punctuation
            min_token_length: Minimum token length
        """
        super().__init__(
            lowercase=lowercase,
            remove_punctuation=remove_punctuation,
            min_token_length=min_token_length,
        )
        self.autojunk = autojunk
        self.use_quick_ratio = use_quick_ratio

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "difflib"
        """
        return "difflib"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute difflib similarity between two texts.

        Args:
            text1: First text to compare
            text2: Second text to compare

        Returns:
            SimilarityResult with difflib ratio

        Raises:
            ValueError: If texts are invalid
        """
        # Validate inputs
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Preprocess
        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Create sequence matcher
        matcher = difflib.SequenceMatcher(
            isjunk=None, a=proc_text1, b=proc_text2, autojunk=self.autojunk
        )

        # Compute similarity ratio
        if self.use_quick_ratio:
            score = matcher.quick_ratio()
        else:
            score = matcher.ratio()

        # Get matching blocks and opcodes for metadata
        matching_blocks = matcher.get_matching_blocks()
        opcodes = list(matcher.get_opcodes())

        # Calculate character-level statistics
        num_matches = sum(block.size for block in matching_blocks)
        len1 = len(proc_text1)
        len2 = len(proc_text2)

        # Build metadata
        metadata = {
            "ratio": score,
            "matching_blocks": len(matching_blocks),
            "matching_characters": num_matches,
            "text1_length": len1,
            "text2_length": len2,
            "operations": self._summarize_opcodes(opcodes),
        }

        return SimilarityResult(
            score=score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def get_diff_blocks(self, text1: str, text2: str) -> List[DiffBlock]:
        """
        Get detailed diff blocks between two texts.

        Args:
            text1: First text
            text2: Second text

        Returns:
            List of DiffBlock objects describing differences

        Raises:
            ValueError: If texts are invalid
        """
        # Validate and preprocess
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Create matcher and get opcodes
        matcher = difflib.SequenceMatcher(
            isjunk=None, a=proc_text1, b=proc_text2, autojunk=self.autojunk
        )
        opcodes = matcher.get_opcodes()

        # Convert to DiffBlock objects
        diff_blocks = []
        for tag, i1, i2, j1, j2 in opcodes:
            block = DiffBlock(
                tag=tag,
                i1=i1,
                i2=i2,
                j1=j1,
                j2=j2,
                text1=proc_text1[i1:i2],
                text2=proc_text2[j1:j2],
            )
            diff_blocks.append(block)

        return diff_blocks

    def get_unified_diff(
        self, text1: str, text2: str, context_lines: int = 3
    ) -> List[str]:
        """
        Generate unified diff format between two texts.

        Args:
            text1: First text
            text2: Second text
            context_lines: Number of context lines to show

        Returns:
            List of diff lines in unified diff format

        Raises:
            ValueError: If texts are invalid
        """
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        lines1 = text1.splitlines(keepends=True)
        lines2 = text2.splitlines(keepends=True)

        diff = difflib.unified_diff(
            lines1,
            lines2,
            fromfile="text1",
            tofile="text2",
            lineterm="",
            n=context_lines,
        )

        return list(diff)

    def get_llm_friendly_diff(
        self, text1: str, text2: str, context_lines: int = 2, max_context_chars: int = 100
    ) -> str:
        """
        Generate an LLM-friendly diff format that clearly shows what changed.

        This format is optimized for language model prompts, showing:
        - Only the lines/sections where changes occurred
        - Clear "BEFORE" and "AFTER" labels
        - Relevant context around each change
        - Concise, readable format

        Args:
            text1: Original text
            text2: Modified text
            context_lines: Number of context lines to show around changes (default: 2)
            max_context_chars: Maximum characters to show in context lines (default: 100)

        Returns:
            Formatted string describing the changes in LLM-friendly format

        Raises:
            ValueError: If texts are invalid

        Example:
            >>> calc = DifflibSimilarityCalculator()
            >>> diff = calc.get_llm_friendly_diff(
            ...     "Employees receive 15 vacation days",
            ...     "Employees receive 20 vacation days"
            ... )
            >>> print(diff)
            CHANGE #1:
            Context: "Employees receive "
            BEFORE: "15 vacation days"
            AFTER:  "20 vacation days"
        """
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Get diff blocks
        diff_blocks = self.get_diff_blocks(text1, text2)

        if not diff_blocks:
            return "No differences found."

        # Build LLM-friendly output
        changes = []
        change_num = 0

        for i, block in enumerate(diff_blocks):
            # Skip 'equal' blocks unless they're context
            if block.tag == 'equal':
                continue

            change_num += 1
            change_parts = []

            # Add change header
            change_parts.append(f"CHANGE #{change_num}:")

            # Find context before this change
            context_before = ""
            if i > 0 and diff_blocks[i - 1].tag == 'equal':
                ctx_text = diff_blocks[i - 1].text1
                if len(ctx_text) > max_context_chars:
                    # Show last part of context
                    ctx_text = "..." + ctx_text[-max_context_chars:]
                context_before = ctx_text

            # Find context after this change
            context_after = ""
            if i < len(diff_blocks) - 1 and diff_blocks[i + 1].tag == 'equal':
                ctx_text = diff_blocks[i + 1].text1
                if len(ctx_text) > max_context_chars:
                    # Show first part of context
                    ctx_text = ctx_text[:max_context_chars] + "..."
                context_after = ctx_text

            # Add context
            if context_before:
                change_parts.append(f'Context before: "{context_before.strip()}"')

            # Add the actual change
            if block.tag == 'replace':
                change_parts.append(f'BEFORE: "{block.text1}"')
                change_parts.append(f'AFTER:  "{block.text2}"')
            elif block.tag == 'delete':
                change_parts.append(f'DELETED: "{block.text1}"')
            elif block.tag == 'insert':
                change_parts.append(f'INSERTED: "{block.text2}"')

            # Add context after
            if context_after:
                change_parts.append(f'Context after: "{context_after.strip()}"')

            changes.append("\n".join(change_parts))

        if not changes:
            return "No differences found."

        # Combine all changes
        header = f"Found {change_num} change(s):\n\n"
        return header + "\n\n".join(changes)

    def _get_token_level_changes(self, text1: str, text2: str) -> List[Tuple[str, str]]:
        """
        Get token-level (word/number-aware) changes between two texts.

        This method splits text into tokens (words, numbers, punctuation) and finds
        which tokens changed, providing more meaningful diffs than character-level.

        Args:
            text1: Original text
            text2: Modified text

        Returns:
            List of (old_token, new_token) tuples representing changes

        Example:
            "after 90 days" vs "after 60 days" → [("90", "60")]
            not character-level "9" → "6"
        """
        import re

        # Tokenize: split on word boundaries, but keep numbers together
        # This regex splits on spaces/punctuation but keeps numbers as single tokens
        token_pattern = r'\b\w+\b|\S'

        tokens1 = re.findall(token_pattern, text1)
        tokens2 = re.findall(token_pattern, text2)

        # Use SequenceMatcher on tokens instead of characters
        matcher = difflib.SequenceMatcher(None, tokens1, tokens2, autojunk=self.autojunk)
        opcodes = matcher.get_opcodes()

        changes = []
        for tag, i1, i2, j1, j2 in opcodes:
            if tag in ('replace', 'delete', 'insert'):
                old_part = ' '.join(tokens1[i1:i2]) if i1 < i2 else ''
                new_part = ' '.join(tokens2[j1:j2]) if j1 < j2 else ''

                if tag == 'replace' and old_part and new_part:
                    changes.append((old_part, new_part))
                elif tag == 'delete' and old_part:
                    changes.append((old_part, ''))
                elif tag == 'insert' and new_part:
                    changes.append(('', new_part))

        return changes

    def _extract_sentence(self, text: str, change_pos: int) -> str:
        """
        Extract the sentence containing the change position.

        Args:
            text: Full text
            change_pos: Position of the change

        Returns:
            The sentence containing the change
        """
        # Find sentence boundaries (., !, ?, or line breaks)
        import re

        # Split into sentences
        sentences = re.split(r'([.!?]+(?:\s|$))', text)

        # Reconstruct sentences with their terminators
        full_sentences = []
        for i in range(0, len(sentences) - 1, 2):
            if i + 1 < len(sentences):
                full_sentences.append(sentences[i] + sentences[i + 1])
            else:
                full_sentences.append(sentences[i])

        # If last item doesn't have terminator
        if len(sentences) % 2 == 1 and sentences[-1].strip():
            full_sentences.append(sentences[-1])

        # Find which sentence contains the change
        pos = 0
        for sentence in full_sentences:
            if pos <= change_pos < pos + len(sentence):
                return sentence.strip()
            pos += len(sentence)

        # Fallback: return the text
        return text.strip()

    def get_llm_friendly_diff_line_based(
        self, text1: str, text2: str, context_lines: int = 2, show_inline_changes: bool = True
    ) -> str:
        """
        Generate an LLM-friendly diff at line level (for multi-line texts).

        This is better for comparing documents, markdown, or multi-line content
        where you want to see which lines changed.

        Args:
            text1: Original text
            text2: Modified text
            context_lines: Number of context lines around changes
            show_inline_changes: If True, highlights exact character changes within changed lines

        Returns:
            Formatted string showing line-level changes

        Example:
            >>> calc = DifflibSimilarityCalculator()
            >>> diff = calc.get_llm_friendly_diff_line_based(
            ...     "Line 1\\nOld line 2\\nLine 3",
            ...     "Line 1\\nNew line 2\\nLine 3"
            ... )
        """
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        lines1 = text1.splitlines()
        lines2 = text2.splitlines()

        # Use difflib on lines
        matcher = difflib.SequenceMatcher(None, lines1, lines2, autojunk=self.autojunk)
        opcodes = matcher.get_opcodes()

        changes = []
        change_num = 0

        for tag, i1, i2, j1, j2 in opcodes:
            if tag == 'equal':
                continue

            # Show the change
            if tag == 'replace':
                # Process each pair of changed lines separately when show_inline_changes is True
                if show_inline_changes:
                    # Handle multiple line replacements by creating individual changes
                    num_old_lines = i2 - i1
                    num_new_lines = j2 - j1
                    max_lines = max(num_old_lines, num_new_lines)

                    for idx in range(max_lines):
                        change_num += 1
                        change_parts = [f"CHANGE #{change_num}:"]

                        # Get the old and new line for this index (if they exist)
                        line_old = lines1[i1 + idx] if idx < num_old_lines else ""
                        line_new = lines2[j1 + idx] if idx < num_new_lines else ""

                        if line_old and line_new:
                            # Both lines exist - compare them to detect changes
                            line_matcher = difflib.SequenceMatcher(None, line_old, line_new)
                            line_opcodes = line_matcher.get_opcodes()

                            # Find if there are actual changes in this line
                            first_change_pos = None
                            for ltag, li1, li2, lj1, lj2 in line_opcodes:
                                if ltag in ('replace', 'delete', 'insert'):
                                    if first_change_pos is None:
                                        first_change_pos = li1
                                    break

                            if first_change_pos is not None:
                                # Calculate position in full text for sentence extraction
                                # Sum up lengths of all previous lines + newline characters
                                char_pos_in_text1 = sum(len(lines1[k]) + 1 for k in range(i1 + idx)) + first_change_pos
                                char_pos_in_text2 = sum(len(lines2[k]) + 1 for k in range(j1 + idx)) + first_change_pos

                                # Extract sentences from the FULL text (not just the line)
                                sentence_old = self._extract_sentence(text1, char_pos_in_text1)
                                sentence_new = self._extract_sentence(text2, char_pos_in_text2)

                                # Use token-level changes for better number/word detection
                                changes_found = self._get_token_level_changes(sentence_old, sentence_new)

                                # Show full sentences
                                change_parts.append(f'BEFORE: "{sentence_old}"')
                                change_parts.append(f'AFTER:  "{sentence_new}"')

                                # Show specific changes
                                if changes_found:
                                    change_parts.append("WHAT CHANGED:")
                                    for old_part, new_part in changes_found:
                                        if old_part and new_part:
                                            change_parts.append(f'  "{old_part}" → "{new_part}"')
                                        elif old_part:
                                            change_parts.append(f'  Deleted: "{old_part}"')
                                        elif new_part:
                                            change_parts.append(f'  Inserted: "{new_part}"')
                            else:
                                # No inline changes found (lines are identical after preprocessing)
                                change_parts.append(f'BEFORE: "{line_old}"')
                                change_parts.append(f'AFTER:  "{line_new}"')
                        elif line_old:
                            # Only old line exists (deletion)
                            char_pos_in_text1 = sum(len(lines1[k]) + 1 for k in range(i1 + idx))
                            sentence_old = self._extract_sentence(text1, char_pos_in_text1)
                            change_parts.append(f'DELETED: "{sentence_old}"')
                        elif line_new:
                            # Only new line exists (insertion)
                            char_pos_in_text2 = sum(len(lines2[k]) + 1 for k in range(j1 + idx))
                            sentence_new = self._extract_sentence(text2, char_pos_in_text2)
                            change_parts.append(f'INSERTED: "{sentence_new}"')

                        changes.append("\n".join(change_parts))
                else:
                    # show_inline_changes=False: show full lines together
                    change_num += 1
                    change_parts = [f"CHANGE #{change_num}:"]
                    change_parts.append("BEFORE:")
                    for line in lines1[i1:i2]:
                        change_parts.append(f'  "{line}"')
                    change_parts.append("AFTER:")
                    for line in lines2[j1:j2]:
                        change_parts.append(f'  "{line}"')
                    changes.append("\n".join(change_parts))

            elif tag == 'delete':
                # Handle deletions - create separate change for each deleted line if show_inline_changes
                if show_inline_changes:
                    for idx in range(i1, i2):
                        change_num += 1
                        line_old = lines1[idx]
                        char_pos_in_text1 = sum(len(lines1[k]) + 1 for k in range(idx))
                        sentence_old = self._extract_sentence(text1, char_pos_in_text1)
                        change_parts = [
                            f"CHANGE #{change_num}:",
                            f'DELETED: "{sentence_old}"'
                        ]
                        changes.append("\n".join(change_parts))
                else:
                    change_num += 1
                    change_parts = [f"CHANGE #{change_num}:", "DELETED:"]
                    for line in lines1[i1:i2]:
                        change_parts.append(f'  "{line}"')
                    changes.append("\n".join(change_parts))

            elif tag == 'insert':
                # Handle insertions - create separate change for each inserted line if show_inline_changes
                if show_inline_changes:
                    for idx in range(j1, j2):
                        change_num += 1
                        line_new = lines2[idx]
                        char_pos_in_text2 = sum(len(lines2[k]) + 1 for k in range(idx))
                        sentence_new = self._extract_sentence(text2, char_pos_in_text2)
                        change_parts = [
                            f"CHANGE #{change_num}:",
                            f'INSERTED: "{sentence_new}"'
                        ]
                        changes.append("\n".join(change_parts))
                else:
                    change_num += 1
                    change_parts = [f"CHANGE #{change_num}:", "INSERTED:"]
                    for line in lines2[j1:j2]:
                        change_parts.append(f'  "{line}"')
                    changes.append("\n".join(change_parts))

        if not changes:
            return "No differences found."

        header = f"Found {change_num} change(s):\n\n"
        return header + "\n\n".join(changes)

    def _summarize_opcodes(self, opcodes: List[Tuple]) -> dict:
        """
        Summarize opcodes into operation counts.

        Args:
            opcodes: List of (tag, i1, i2, j1, j2) tuples

        Returns:
            Dictionary with operation counts
        """
        summary = {"replace": 0, "delete": 0, "insert": 0, "equal": 0}

        for tag, _, _, _, _ in opcodes:
            summary[tag] += 1

        summary["total_operations"] = len(opcodes)

        return summary


class TokenBasedDifflibCalculator(DifflibSimilarityCalculator):
    """
    Token-based difflib similarity that compares word sequences.

    Instead of comparing character sequences, this compares token (word) sequences.
    More effective for understanding semantic changes.
    """

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "difflib_token"
        """
        return "difflib_token"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute token-based difflib similarity.

        Args:
            text1: First text
            text2: Second text

        Returns:
            SimilarityResult with token-based ratio

        Raises:
            ValueError: If texts are invalid
        """
        # Validate and preprocess
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Tokenize
        tokens1 = self.tokenize(proc_text1)
        tokens2 = self.tokenize(proc_text2)

        # Handle empty tokens
        if not tokens1 or not tokens2:
            return SimilarityResult(
                score=0.0,
                text1=text1,
                text2=text2,
                algorithm=self.get_algorithm_name(),
                metadata={"tokens1_count": 0, "tokens2_count": 0},
            )

        # Create sequence matcher on tokens
        matcher = difflib.SequenceMatcher(
            isjunk=None, a=tokens1, b=tokens2, autojunk=self.autojunk
        )

        # Compute similarity
        if self.use_quick_ratio:
            score = matcher.quick_ratio()
        else:
            score = matcher.ratio()

        # Get matching blocks and opcodes
        matching_blocks = matcher.get_matching_blocks()
        opcodes = list(matcher.get_opcodes())

        # Calculate token-level statistics
        num_matching_tokens = sum(block.size for block in matching_blocks)

        # Build metadata
        metadata = {
            "ratio": score,
            "matching_blocks": len(matching_blocks),
            "matching_tokens": num_matching_tokens,
            "tokens1_count": len(tokens1),
            "tokens2_count": len(tokens2),
            "operations": self._summarize_opcodes(opcodes),
        }

        return SimilarityResult(
            score=score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def get_token_diff_blocks(self, text1: str, text2: str) -> List[DiffBlock]:
        """
        Get diff blocks at token level.

        Args:
            text1: First text
            text2: Second text

        Returns:
            List of DiffBlock objects for tokens

        Raises:
            ValueError: If texts are invalid
        """
        # Validate and preprocess
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        proc_text1 = self.preprocess_text(text1)
        proc_text2 = self.preprocess_text(text2)

        # Tokenize
        tokens1 = self.tokenize(proc_text1)
        tokens2 = self.tokenize(proc_text2)

        # Create matcher
        matcher = difflib.SequenceMatcher(
            isjunk=None, a=tokens1, b=tokens2, autojunk=self.autojunk
        )
        opcodes = matcher.get_opcodes()

        # Convert to DiffBlock objects
        diff_blocks = []
        for tag, i1, i2, j1, j2 in opcodes:
            block = DiffBlock(
                tag=tag,
                i1=i1,
                i2=i2,
                j1=j1,
                j2=j2,
                text1=" ".join(tokens1[i1:i2]) if tokens1 else "",
                text2=" ".join(tokens2[j1:j2]) if tokens2 else "",
            )
            diff_blocks.append(block)

        return diff_blocks


# Factory functions for common use cases


def create_faq_modification_detector() -> DifflibSimilarityCalculator:
    """
    Create difflib calculator optimized for FAQ modification detection.

    Preserves numbers, dates, and special characters to detect changes like "10" -> "12".
    Case-insensitive for general text comparison.

    Returns:
        DifflibSimilarityCalculator configured for modification detection

    Example:
        >>> calc = create_faq_modification_detector()
        >>> result = calc.compute_similarity(
        ...     "Employees receive 10 sick days per year",
        ...     "Employees receive 12 sick days per year"
        ... )
        >>> print(f"Score: {result.score:.3f}")  # ~0.96 (high similarity, small change)
    """
    return DifflibSimilarityCalculator(
        autojunk=True,
        use_quick_ratio=False,
        lowercase=True,
        remove_punctuation=False,  # Keep numbers, dates intact
        min_token_length=1,
    )


def create_character_level_analyzer() -> DifflibSimilarityCalculator:
    """
    Create difflib calculator for pure character-level analysis.

    Preserves ALL characters including case and punctuation.
    Best for detecting exact character changes.

    Returns:
        DifflibSimilarityCalculator configured for character-level analysis

    Example:
        >>> calc = create_character_level_analyzer()
        >>> result = calc.compute_similarity("ABC123", "ABC456")
        >>> print(f"Score: {result.score:.3f}")  # Detects "123" vs "456"
    """
    return DifflibSimilarityCalculator(
        autojunk=False,  # Don't skip any characters
        use_quick_ratio=False,
        lowercase=False,  # Case-sensitive
        remove_punctuation=False,
        min_token_length=1,
    )


def create_fast_diff_calculator() -> DifflibSimilarityCalculator:
    """
    Create difflib calculator optimized for speed.

    Uses quick_ratio for faster (but slightly less accurate) results.

    Returns:
        DifflibSimilarityCalculator configured for fast processing

    Example:
        >>> calc = create_fast_diff_calculator()
        >>> result = calc.compute_similarity(text1, text2)
    """
    return DifflibSimilarityCalculator(
        autojunk=True,
        use_quick_ratio=True,  # Fast mode
        lowercase=True,
        remove_punctuation=True,
        min_token_length=2,
    )


# Convenience exports
__all__ = [
    "DifflibSimilarityCalculator",
    "TokenBasedDifflibCalculator",
    "DiffBlock",
    "create_faq_modification_detector",
    "create_character_level_analyzer",
    "create_fast_diff_calculator",
]
