"""
Simplified hybrid multi-algorithm similarity approach.

Combines multiple similarity algorithms with configurable weights.
Clean, minimal implementation - no batch processing, no caching.

Design Principles:
- Simplicity over complexity
- Weighted combination of Jaccard, Difflib, and BM25
- Early exit optimization for performance
- Factory methods for common use cases
"""

from typing import Dict, Optional

from granular_impact.similarity.base import (
    BaseSimilarityCalculator,
    SimilarityResult,
)
from granular_impact.similarity.bm25_sim import BM25SimilarityCalculator
from granular_impact.similarity.difflib_sim import DifflibSimilarityCalculator
from granular_impact.similarity.jaccard_sim import JaccardSimilarityCalculator


class HybridSimilarityCalculator(BaseSimilarityCalculator):
    """
    Simplified hybrid similarity calculator combining multiple algorithms.

    Computes similarity using multiple methods and returns a weighted average.
    """

    def __init__(
        self,
        weights: Optional[Dict[str, float]] = None,
        early_exit_threshold: float = 0.0,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        min_token_length: int = 1,
    ):
        """
        Initialize hybrid similarity calculator.

        Args:
            weights: Dictionary of algorithm weights (must sum to 1.0)
                    Default: {'jaccard': 0.25, 'difflib': 0.25, 'bm25': 0.50}
            early_exit_threshold: Jaccard threshold for early exit optimization
                                 Set to 0.0 to disable (default)
            lowercase: Convert to lowercase
            remove_punctuation: Remove punctuation
            min_token_length: Minimum token length
        """
        super().__init__(
            lowercase=lowercase,
            remove_punctuation=remove_punctuation,
            min_token_length=min_token_length,
        )

        # Set default weights
        if weights is None:
            weights = {
                "jaccard": 0.50,
                "difflib": 0.50,
                # "bm25": 0.50,
            }

        # Validate weights
        total_weight = sum(weights.values())
        if not (0.99 <= total_weight <= 1.01):
            raise ValueError(
                f"Weights must sum to 1.0, got {total_weight}. Weights: {weights}"
            )

        self.weights = weights
        self.early_exit_threshold = early_exit_threshold

        # Initialize calculators
        self._init_calculators()

    def _init_calculators(self) -> None:
        """Initialize all similarity calculators."""
        base_params = {
            "lowercase": self.lowercase,
            "remove_punctuation": self.remove_punctuation,
            "min_token_length": self.min_token_length,
        }

        self.calculators = {}

        if "jaccard" in self.weights:
            self.calculators["jaccard"] = JaccardSimilarityCalculator(**base_params)

        if "difflib" in self.weights:
            # Difflib works better without punctuation removal for character-level accuracy
            self.calculators["difflib"] = DifflibSimilarityCalculator(
                lowercase=self.lowercase,
                remove_punctuation=False,  # Keep punctuation for better "10"→"12" detection
                min_token_length=1,
                autojunk=True,
            )

        if "bm25" in self.weights:
            self.calculators["bm25"] = BM25SimilarityCalculator(**base_params)

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "hybrid"
        """
        return "hybrid"

    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """
        Compute hybrid similarity using all configured algorithms.

        Supports early exit optimization based on Jaccard score.
        If early_exit_threshold > 0 and Jaccard < threshold, returns 0.0 immediately.

        Args:
            text1: First text
            text2: Second text

        Returns:
            SimilarityResult with weighted average score

        Raises:
            ValueError: If texts are invalid
        """
        # Validate
        if text1 is None or text2 is None:
            raise ValueError("Texts cannot be None")
        if not text1.strip() or not text2.strip():
            raise ValueError("Texts cannot be empty")

        # Clean whitespace
        text1_clean = " ".join(text1.split())
        text2_clean = " ".join(text2.split())

        # Compute similarity with each algorithm
        individual_results = {}
        individual_scores = {}
        early_exit = False
        algorithms_skipped = []

        # Early Exit: Compute Jaccard first if enabled
        if self.early_exit_threshold > 0.0 and "jaccard" in self.calculators:
            jaccard_result = self.calculators["jaccard"].compute_similarity(
                text1_clean, text2_clean
            )
            individual_results["jaccard"] = jaccard_result
            individual_scores["jaccard"] = jaccard_result.score

            # Early exit if Jaccard score is too low
            if jaccard_result.score < self.early_exit_threshold:
                early_exit = True
                algorithms_skipped = [
                    name for name in self.calculators.keys() if name != "jaccard"
                ]

                metadata = {
                    "early_exit": True,
                    "early_exit_threshold": self.early_exit_threshold,
                    "weighted_score": 0.0,
                    "individual_scores": individual_scores,
                    "weights": self.weights,
                    "algorithms_used": ["jaccard"],
                    "algorithms_skipped": algorithms_skipped,
                }

                return SimilarityResult(
                    score=0.0,
                    text1=text1,
                    text2=text2,
                    algorithm=self.get_algorithm_name(),
                    metadata=metadata,
                )

        # Compute remaining algorithms
        for name, calculator in self.calculators.items():
            if name in individual_results:
                continue  # Already computed (Jaccard in early exit path)

            result = calculator.compute_similarity(text1_clean, text2_clean)
            individual_results[name] = result
            individual_scores[name] = result.score

        # Compute weighted average
        weighted_score = 0.0
        for name, score in individual_scores.items():
            weighted_score += score * self.weights.get(name, 0.0)

        # Build metadata
        metadata = {
            "early_exit": early_exit,
            "early_exit_threshold": self.early_exit_threshold,
            "weighted_score": weighted_score,
            "individual_scores": individual_scores,
            "weights": self.weights,
            "algorithms_used": list(individual_results.keys()),
            "algorithms_skipped": algorithms_skipped,
        }

        # Include detailed metadata from each algorithm
        for name, result in individual_results.items():
            metadata[f"{name}_metadata"] = result.metadata

        return SimilarityResult(
            score=weighted_score,
            text1=text1,
            text2=text2,
            algorithm=self.get_algorithm_name(),
            metadata=metadata,
        )

    def get_algorithm_breakdown(self, text1: str, text2: str) -> Dict[str, float]:
        """
        Get detailed breakdown of scores from each algorithm.

        Args:
            text1: First text
            text2: Second text

        Returns:
            Dictionary mapping algorithm names to scores
        """
        result = self.compute_similarity(text1, text2)
        return result.metadata["individual_scores"]

    @classmethod
    def for_modification_detection(cls) -> "HybridSimilarityCalculator":
        """
        Factory method for FAQ modification detection.

        Optimized for detecting content modifications where small changes
        like "10"→"12" need high similarity scores.

        Configuration:
        - Early exit at Jaccard < 0.3
        - Weights: Jaccard=0.2, Difflib=0.5, BM25=0.3

        Returns:
            HybridSimilarityCalculator configured for modification detection
        """
        return cls(
            weights={
                "jaccard": 0.40,
                "difflib": 0.60,
                # "bm25": 0.30,
            },
            early_exit_threshold=0.3,
        )

    @classmethod
    def for_general_similarity(cls) -> "HybridSimilarityCalculator":
        """
        Factory method for general similarity comparison.

        Uses balanced weights without early exit optimization.

        Returns:
            HybridSimilarityCalculator configured for general similarity
        """
        return cls(
            weights={
                "jaccard": 0.33,
                "difflib": 0.33,
                "bm25": 0.34,
            },
            early_exit_threshold=0.0,  # Disabled
        )


class PolicyContentSimilarity(HybridSimilarityCalculator):
    """
    Specialized similarity calculator for policy content analysis.

    Pre-configured for optimal detection of policy document changes:
    - Dates: "January 1, 2025" → "February 1, 2025"
    - Numbers: "10 sick days" → "12 sick days"
    - Small wording changes
    """

    def __init__(self):
        """Initialize policy content similarity calculator."""
        super().__init__(
            weights={
                "jaccard": 0.20,
                "difflib": 0.50,
                "bm25": 0.30,
            },
            early_exit_threshold=0.3,
        )

    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        Returns:
            Algorithm name "policy_similarity"
        """
        return "policy_similarity"

    def is_modification(self, text1: str, text2: str, threshold: float = 0.80) -> bool:
        """
        Check if text2 is a modification of text1.

        Args:
            text1: Original text
            text2: New text
            threshold: Similarity threshold (recommended 0.80-0.85)

        Returns:
            True if similarity >= threshold (likely a modification)
            False if similarity < threshold (likely new content)
        """
        result = self.compute_similarity(text1, text2)
        return result.score >= threshold

    def classify_change(self, text1: str, text2: str) -> tuple[str, float, Dict]:
        """
        Classify the type of change between two policy texts.

        Args:
            text1: Original text
            text2: New text

        Returns:
            Tuple of (change_type, similarity_score, details)

            change_types:
            - "identical": score >= 0.95
            - "minor_modification": score >= 0.85
            - "major_modification": score >= 0.70
            - "significant_change": score >= 0.40
            - "new_content": score < 0.40
        """
        result = self.compute_similarity(text1, text2)
        score = result.score

        # Classification thresholds
        if score >= 0.95:
            change_type = "identical"
        elif score >= 0.85:
            change_type = "minor_modification"
        elif score >= 0.70:
            change_type = "major_modification"
        elif score >= 0.40:
            change_type = "significant_change"
        else:
            change_type = "new_content"

        details = {
            "similarity_score": score,
            "breakdown": self.get_algorithm_breakdown(text1, text2),
            "early_exit": result.metadata.get("early_exit", False),
        }

        return change_type, score, details


# Convenience exports
__all__ = [
    "HybridSimilarityCalculator",
    "PolicyContentSimilarity",
]