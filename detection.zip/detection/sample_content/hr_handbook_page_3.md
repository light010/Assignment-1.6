# Remote Work

Employees may work remotely up to 2 days per week.