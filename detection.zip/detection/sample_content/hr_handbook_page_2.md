# Benefits

Full-time employees receive health insurance coverage.