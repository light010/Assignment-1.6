"""
Change detection module - V8.2 implementation.

Pure checksum-centric change detection with similarity matching:
- ContentChangeDetector: V8.2 algorithm with similarity matching
- ChecksumExtractor: Core checksum computation
- ChecksumFileExtractor: Extract checksums from files/databases
- ChangeDetectionQueries: Database utilities for change detection

Main entry point: ContentChangeDetector (implements V8.2 algorithm)
"""

from granular_impact.detection.checksum_extractor import ChecksumExtractor
from granular_impact.detection.checksum_file_extractor import ChecksumFileExtractor
from granular_impact.detection.content_change_detector import ContentChangeDetector
from granular_impact.detection.database_queries import ChangeDetectionQueries

__all__ = [
    "ContentChangeDetector",  # V8.2 detector with similarity matching
    "ChecksumExtractor",  # Core checksum computation
    "ChecksumFileExtractor",  # File/database extraction
    "ChangeDetectionQueries",  # Database utilities
]
