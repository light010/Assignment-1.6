"""
Database query utilities for change detection.

Provides SQL queries and helper functions for:
- Retrieving previous checksums for a file
- Storing change detection results
- FAQ lookup by checksum

Compatible with V8.2 schema only.
Supports both SQLite (local development) and Databricks Delta tables (production).
"""

from datetime import datetime
from typing import Dict, List, Optional

from granular_impact.database.models import ContentChange
from granular_impact.utils.logging_utils import get_logger

logger = get_logger(__name__)


class ChangeDetectionQueries:
    """
    SQL query templates and helper functions for change detection.

    Uses V8.2 schema: content_checksums, content_change_log, faq_questions, faq_answers.
    Supports both SQLite and Databricks SQL dialects.
    """

    @staticmethod
    def get_previous_checksums_for_file(
        conn,
        file_name: str,
        since_date: Optional[datetime] = None,
        use_spark: bool = False,
    ) -> Dict[str, Dict]:
        """
        Get previous checksums for a specific file (scoped, not global).

        This query implements the V8.2 checksum-centric approach:
        - Scoped to THIS FILE only (not global checksums)
        - Filters by created_at < since_date (if provided)
        - Returns checksums with their content and metadata

        Args:
            conn: Database connection (sqlite3.Connection or Spark session)
            file_name: Name of file to query
            since_date: Only get checksums created before this date (optional)
            use_spark: Whether to use Spark SQL syntax (Databricks)

        Returns:
            Dictionary: {checksum: {'content_text': '...', 'page_number': 42, ...}, ...}
        """
        if use_spark:
            return ChangeDetectionQueries._get_previous_checksums_spark(
                conn, file_name, since_date
            )
        else:
            return ChangeDetectionQueries._get_previous_checksums_sqlite(
                conn, file_name, since_date
            )

    @staticmethod
    def _get_previous_checksums_sqlite(
        conn, file_name: str, since_date: Optional[datetime]
    ) -> Dict[str, Dict]:
        """
        Get previous checksums using SQLite.

        Uses V8.2 schema: content_checksums table.
        """
        import sqlite3

        if since_date:
            query = """
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at,
                    cc.markdown_file_path
                FROM content_checksums cc
                WHERE cc.file_name = ?
                  AND cc.created_at < ?
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """
            params = (file_name, since_date.isoformat())
        else:
            query = """
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at,
                    cc.markdown_file_path
                FROM content_checksums cc
                WHERE cc.file_name = ?
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """
            params = (file_name,)

        cursor = conn.execute(query, params)

        # Convert rows to dict
        columns = [desc[0] for desc in cursor.description]
        checksums_data = {}

        for row in cursor.fetchall():
            row_dict = dict(zip(columns, row))
            checksum = row_dict["content_checksum"]
            checksums_data[checksum] = row_dict

        logger.info(
            f"📊 Retrieved {len(checksums_data)} previous checksums for {file_name}"
        )

        return checksums_data

    @staticmethod
    def _get_previous_checksums_spark(
        spark, file_name: str, since_date: Optional[datetime]
    ) -> Dict[str, Dict]:
        """Get previous checksums using Spark SQL (Databricks) - V8.2 schema."""

        if since_date:
            query = f"""
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at
                FROM content_checksums cc
                WHERE cc.file_name = '{file_name}'
                  AND cc.created_at < '{since_date.isoformat()}'
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """
        else:
            query = f"""
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at
                FROM content_checksums cc
                WHERE cc.file_name = '{file_name}'
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """

        df = spark.sql(query)
        rows = df.collect()

        checksums_data = {}
        for row in rows:
            row_dict = row.asDict()
            checksum = row_dict["content_checksum"]
            checksums_data[checksum] = row_dict

        logger.info(
            f"📊 Retrieved {len(checksums_data)} previous checksums for {file_name}"
        )

        return checksums_data

    @staticmethod
    def store_change_detection_results(
        conn,
        changes: List[ContentChange],
        detection_run_id: str,
        use_spark: bool = False,
    ) -> int:
        """
        Store change detection results in content_change_log table.

        Args:
            conn: Database connection (sqlite3.Connection or Spark session)
            changes: List of ContentChange objects
            detection_run_id: Unique ID for this detection run
            use_spark: Whether to use Spark SQL (Databricks)

        Returns:
            Number of records inserted
        """
        if use_spark:
            return ChangeDetectionQueries._store_changes_spark(
                conn, changes, detection_run_id
            )
        else:
            return ChangeDetectionQueries._store_changes_sqlite(
                conn, changes, detection_run_id
            )

    @staticmethod
    def _store_changes_sqlite(
        conn, changes: List[ContentChange], detection_run_id: str
    ) -> int:
        """Store changes using SQLite - V8.2 schema."""
        import sqlite3

        insert_query = """
            INSERT INTO content_change_log (
                content_checksum,
                previous_checksum,
                file_name,
                page_number,
                section_name,
                requires_faq_regeneration,
                change_type,
                similarity_score,
                similarity_method,
                total_faqs_at_risk,
                affected_question_count,
                affected_answer_count,
                detection_run_id,
                detection_timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        cursor = conn.cursor()
        inserted = 0

        for change in changes:
            # Determine if FAQ regeneration required
            requires_regen = change.change_type in (
                "new_content",
                "modified_content",
                "deleted_content",
            )

            try:
                cursor.execute(
                    insert_query,
                    (
                        change.content_checksum,
                        change.old_checksum if change.old_checksum else None,
                        change.file_name,
                        change.page_number,
                        None,  # section_name
                        requires_regen,
                        change.change_type.value,
                        change.similarity_score,
                        "hybrid",  # similarity_method
                        0,  # total_faqs_at_risk (updated later by impact analysis)
                        0,  # affected_question_count (updated later)
                        0,  # affected_answer_count (updated later)
                        detection_run_id,
                        datetime.now().isoformat(),
                    ),
                )
                inserted += 1

            except sqlite3.IntegrityError as e:
                logger.warning(f"   ⚠️  Failed to insert change: {e}")

        conn.commit()
        logger.info(f"💾 Stored {inserted}/{len(changes)} changes to database")

        return inserted

    @staticmethod
    def _store_changes_spark(
        spark, changes: List[ContentChange], detection_run_id: str
    ) -> int:
        """Store changes using Spark SQL (Databricks) - V8.2 schema."""
        from pyspark.sql import Row

        # Convert changes to rows
        rows = []

        for change in changes:
            requires_regen = change.change_type in (
                "new_content",
                "modified_content",
                "deleted_content",
            )

            rows.append(
                Row(
                    content_checksum=change.content_checksum,
                    previous_checksum=change.old_checksum if change.old_checksum else None,
                    file_name=change.file_name,
                    page_number=change.page_number,
                    section_name=None,
                    requires_faq_regeneration=requires_regen,
                    change_type=change.change_type.value,
                    similarity_score=change.similarity_score,
                    similarity_method="hybrid",
                    total_faqs_at_risk=0,
                    affected_question_count=0,
                    affected_answer_count=0,
                    detection_run_id=detection_run_id,
                    detection_timestamp=datetime.now(),
                )
            )

        if not rows:
            logger.warning("No changes to store")
            return 0

        # Create DataFrame and write
        df = spark.createDataFrame(rows)
        df.write.format("delta").mode("append").saveAsTable("content_change_log")

        logger.info(f"💾 Stored {len(rows)} changes to Delta table")

        return len(rows)

    @staticmethod
    def get_faqs_for_checksum(
        conn, checksum: str, use_spark: bool = False
    ) -> List[Dict]:
        """
        Get all FAQs that use a given checksum in their sources.

        Uses UNION query to correctly handle both question and answer sources.
        V8.2 schema uses question_text and answer_text (not txt variants).

        Args:
            conn: Database connection (sqlite3.Connection or Spark session)
            checksum: Content checksum to search for
            use_spark: Whether to use Spark SQL syntax

        Returns:
            List of FAQ dictionaries with source_type ('question' or 'answer')
        """
        query = """
            -- Question-impacted FAQs
            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                a.answer_text,
                'question' as source_type,
                qs.source_id
            FROM faq_questions q
            INNER JOIN faq_question_sources qs
                ON q.question_id = qs.question_id
                AND qs.is_valid = TRUE
            LEFT JOIN faq_answers a
                ON q.question_id = a.question_id
                AND a.status = 'active'
            WHERE qs.content_checksum = ?
              AND q.status = 'active'

            UNION

            -- Answer-impacted FAQs
            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                a.answer_text,
                'answer' as source_type,
                asrc.source_id
            FROM faq_questions q
            INNER JOIN faq_answers a
                ON q.question_id = a.question_id
                AND a.status = 'active'
            INNER JOIN faq_answer_sources asrc
                ON a.answer_id = asrc.answer_id
                AND asrc.is_valid = TRUE
            WHERE asrc.content_checksum = ?
              AND q.status = 'active'
        """

        if use_spark:
            # Spark SQL uses same syntax but with string substitution
            query_spark = query.replace("?", f"'{checksum}'")
            df = conn.sql(query_spark)
            rows = df.collect()
            return [row.asDict() for row in rows]
        else:
            # SQLite
            cursor = conn.execute(query, (checksum, checksum))
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
