# Core Module - Domain Layer

## Overview

The `core` module represents the **domain layer** of the application - it defines **WHAT** the system does, not **HOW** it does it. This module contains pure business concepts and has **ZERO dependencies** on other application modules.

## Architecture Principles

### Clean Architecture
```
┌─────────────┐         ┌─────────────┐
│  chunking   │────────>│    core     │<────────┤  utility   │
│ (implement) │         │  (domain)   │         │  (infra)   │
└─────────────┘         └─────────────┘         └─────────────┘
```

**Dependency Direction**: `chunking → core ← utility`

- **Core has NO dependencies** - it's pure domain logic
- **Chunking depends on core** - uses domain models and interfaces
- **Utility depends on core** - may use domain exceptions

### The "WHAT vs HOW" Test

| Concept | What/How? | Module |
|---------|-----------|--------|
| "A chunk has metadata with index and method" | WHAT | core |
| "We compute SHA-256 hashes for checksums" | HOW | utility |
| "We split on paragraph boundaries recursively" | HOW | chunking |
| "Chunk size must be positive" | WHAT | core |

## Module Structure

```
core/
├── __init__.py           # Public API exports
├── README.md             # This file
├── models/               # Domain value objects
│   ├── __init__.py
│   └── chunk.py          # ChunkMetadata dataclass
├── interfaces/           # Abstract contracts
│   ├── __init__.py
│   └── chunker.py        # IChunker ABC
└── exceptions/           # Domain errors
    ├── __init__.py
    └── chunking.py       # ChunkingError hierarchy
```

## Components

### Models (Value Objects)

**ChunkMetadata** - Immutable value object representing chunk metadata

```python
from core import ChunkMetadata

# Create metadata
metadata = ChunkMetadata(
    chunk_index=0,
    chunk_method="recursive",
    headers={"h1": "Introduction"},
    start_pos=0,
    end_pos=3000
)

# Serialize for database
data = metadata.to_dict()

# Deserialize from database
loaded = ChunkMetadata.from_dict(data)
```

**Business Rules:**
- `chunk_index` must be non-negative
- `chunk_method` must be one of: "recursive", "header", "no_split"
- If `start_pos` is provided, `end_pos` must also be provided and be greater
- `headers` is always a dict (empty if no headers)

### Interfaces (Contracts)

**IChunker** - Abstract base class for all chunking strategies

```python
from core import IChunker, ChunkMetadata

class MyCustomChunker(IChunker):
    def chunk(self, content: str) -> List[str]:
        # Your chunking logic
        return [content]

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        # Your chunking with metadata
        checksum = compute_checksum(content)
        metadata = ChunkMetadata(chunk_index=0, chunk_method="custom")
        return [(content, checksum, metadata)]
```

**Contract Requirements:**
- `chunk()` - Basic splitting without metadata
- `chunk_with_checksums()` - Full-featured with checksums and metadata

### Exceptions (Domain Errors)

**ChunkingError hierarchy** - Domain-specific exceptions

```python
from core import ChunkingError, ChunkSizeError, ChunkOverlapError

try:
    chunker = RecursiveCharacterChunker(chunk_size=-100)
except ChunkSizeError as e:
    print(f"Invalid configuration: {e}")
```

**Exception Hierarchy:**
- `ChunkingError` - Base for all chunking errors
  - `ChunkSizeError` - Invalid chunk_size value
  - `ChunkOverlapError` - Invalid chunk_overlap value
  - `ChunkValidationError` - Content validation failures

## Usage Examples

### Basic Import

```python
from core import ChunkMetadata, IChunker, ChunkingError
```

### Creating Metadata

```python
# Minimal metadata (for header-based splits)
metadata = ChunkMetadata(
    chunk_index=0,
    chunk_method="header"
)

# Full metadata (for recursive splits)
metadata = ChunkMetadata(
    chunk_index=0,
    chunk_method="recursive",
    headers={"h1": "Title", "h2": "Section"},
    start_pos=0,
    end_pos=3000
)
```

### Implementing IChunker

```python
from core import IChunker, ChunkMetadata
from typing import List, Tuple

class FixedSizeChunker(IChunker):
    def __init__(self, size: int = 1000):
        self.size = size

    def chunk(self, content: str) -> List[str]:
        return [content[i:i+self.size] for i in range(0, len(content), self.size)]

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        chunks = self.chunk(content)
        results = []
        for idx, chunk_text in enumerate(chunks):
            checksum = compute_checksum(chunk_text)
            metadata = ChunkMetadata(
                chunk_index=idx,
                chunk_method="fixed",
                start_pos=idx * self.size,
                end_pos=min((idx + 1) * self.size, len(content))
            )
            results.append((chunk_text, checksum, metadata))
        return results
```

## Design Decisions

### Why Frozen Dataclass?

ChunkMetadata is immutable (`frozen=True`) because:
1. **Value Object Pattern** - metadata should not change after creation
2. **Thread Safety** - can be safely shared across threads
3. **Hashable** - can be used as dict keys
4. **Predictability** - easier to reason about

### Why Abstract Interface?

IChunker uses ABC because:
1. **Strategy Pattern** - allows swapping implementations
2. **Type Safety** - mypy/pylint can verify implementations
3. **Contract Enforcement** - ensures all chunkers have same API
4. **Documentation** - interface is self-documenting

### Why Exception Hierarchy?

Custom exceptions because:
1. **Precise Error Handling** - catch specific errors
2. **Domain Language** - errors use business terminology
3. **Debugging** - clear error messages for domain violations
4. **API Stability** - don't rely on ValueError/TypeError

## Testing

Core module components should be tested with:

```python
# Test ChunkMetadata validation
def test_chunk_metadata_negative_index():
    with pytest.raises(ValueError):
        ChunkMetadata(chunk_index=-1, chunk_method="recursive")

# Test ChunkMetadata serialization
def test_chunk_metadata_roundtrip():
    original = ChunkMetadata(chunk_index=0, chunk_method="recursive")
    data = original.to_dict()
    loaded = ChunkMetadata.from_dict(data)
    assert original == loaded

# Test IChunker implementation
def test_ichunker_contract():
    chunker = RecursiveCharacterChunker()
    assert isinstance(chunker, IChunker)
    chunks = chunker.chunk("test content")
    assert isinstance(chunks, list)
```

## Migration from Dict-Based Metadata

**Before (dict-based):**
```python
metadata = {
    "chunk_index": 0,
    "chunk_method": "recursive",
    "headers": {},
}
chunk_index = metadata["chunk_index"]  # Dict access
```

**After (dataclass-based):**
```python
metadata = ChunkMetadata(
    chunk_index=0,
    chunk_method="recursive",
    headers={},
)
chunk_index = metadata.chunk_index  # Attribute access
```

**Benefits:**
- Type hints and IDE autocomplete
- Validation on creation
- Immutability guarantees
- Serialization methods built-in

## FAQs

**Q: Can I add fields to ChunkMetadata?**
A: Yes, but follow the process:
1. Add field to dataclass with default value
2. Update `to_dict`/`from_dict` if needed
3. Update all chunker implementations
4. Update tests

**Q: Do I need to implement IChunker for my custom chunker?**
A: Yes, if you want type safety and to ensure API compatibility. It's optional but strongly recommended.

**Q: Should I catch ChunkingError or specific subclasses?**
A: Catch specific subclasses when you can handle them differently. Catch ChunkingError when you want to handle all chunking errors the same way.

**Q: Can core module import from utility or chunking?**
A: NO. Core has zero dependencies. If you need something from utility, it belongs in utility, not core.

## Version History

- **1.0.0** - Initial release with ChunkMetadata, IChunker, ChunkingError hierarchy
