"""
CORE Module - Domain Layer (Business Concepts - the "WHAT")

This module contains domain-level abstractions that define WHAT the system does,
not HOW it does it. It has ZERO dependencies on other modules.

Architecture:
- models/: Value objects and domain entities (ChunkMetadata, DetectionResult, etc.)
- interfaces/: Abstract contracts (IChunker, IChangeDetector, ISimilarityCalculator)
- exceptions/: Domain-specific errors (ChunkingError, etc.)

Dependency Direction: chunking → core ← utility
                      detection → core ← utility
                      similarity → core ← utility

Example:
    >>> from core import ChunkMetadata, IChunker, ChunkingError
    >>> metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")
    >>> metadata.to_dict()
    {'chunk_index': 0, 'chunk_method': 'recursive', 'headers': {}, ...}
    >>>
    >>> from core import DetectionResult, IChangeDetector, ChangeType
    >>> result = DetectionResult(
    ...     old_checksum="abc",
    ...     new_checksum="def",
    ...     change_type=ChangeType.MODIFIED_CONTENT,
    ...     similarity_score=0.85
    ... )
"""

# Public API exports - Models
from core.models import ChunkMetadata, DetectionConfig, DetectionResult, ChangeType

# Public API exports - Interfaces
from core.interfaces import IChunker, IChangeDetector, IFileLoader, ISimilarityCalculator

# Public API exports - Exceptions
from core.exceptions import (
    ChunkingError,
    ChunkSizeError,
    ChunkOverlapError,
    ChunkValidationError,
)

__version__ = "1.1.0"

__all__ = [
    # Models
    "ChunkMetadata",
    "DetectionResult",
    "DetectionConfig",
    "ChangeType",
    # Interfaces
    "IChunker",
    "IChangeDetector",
    "IFileLoader",
    "ISimilarityCalculator",
    # Exceptions
    "ChunkingError",
    "ChunkSizeError",
    "ChunkOverlapError",
    "ChunkValidationError",
]
