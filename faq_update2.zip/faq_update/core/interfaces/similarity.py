"""
ISimilarityCalculator - Abstract Interface for Similarity Computation

This defines the pure contract that all similarity calculator implementations must follow.
It is framework-agnostic and represents the core business capability of measuring text similarity.

Design Principles:
    - Strategy Pattern: Different implementations for different similarity algorithms
    - Liskov Substitution: All implementations must be interchangeable
    - Single Responsibility: Focus on similarity calculation only
    - Framework Agnostic: No dependencies on specific libraries or utilities

This interface is analogous to IChunker in the chunking module - it defines WHAT
similarity calculation means, not HOW to implement it.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.models.similarity import SimilarityResult


class ISimilarityCalculator(ABC):
    """
    Abstract base class defining the contract for all similarity calculators.

    All similarity calculators must implement these methods to provide consistent
    behavior across different algorithms (Jaccard, Difflib, BM25, Hybrid, etc.).

    This interface represents the core domain capability: measuring how similar
    two pieces of text are and returning a normalized score with metadata.

    Design Principles:
        - Strategy Pattern: Different implementations for different algorithms
        - Liskov Substitution: All implementations must be interchangeable
        - Single Responsibility: Focus on similarity calculation logic only
        - Framework Agnostic: No dependencies on preprocessing or utilities

    Example:
        >>> class MyCustomCalculator(ISimilarityCalculator):
        ...     def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        ...         # Custom similarity logic
        ...         score = 0.75
        ...         return SimilarityResult(score, text1, text2, "custom", {})
        ...
        ...     def get_algorithm_name(self) -> str:
        ...         return "custom"
        >>>
        >>> calc = MyCustomCalculator()
        >>> result = calc.compute_similarity("hello world", "hello there")
        >>> result.score
        0.75
    """

    @abstractmethod
    def compute_similarity(self, text1: str, text2: str) -> "SimilarityResult":
        """
        Compute similarity between two texts.

        This is the core operation - calculate how similar text1 is to text2
        and return a normalized score between 0.0 (completely different) and
        1.0 (identical), along with algorithm-specific metadata.

        Args:
            text1: First text to compare
            text2: Second text to compare

        Returns:
            SimilarityResult containing:
                - score (float): Normalized similarity score [0.0, 1.0]
                - text1 (str): Original first text
                - text2 (str): Original second text
                - algorithm (str): Name of the algorithm used
                - metadata (dict): Algorithm-specific information

        Raises:
            ValueError: If texts are None or empty
            SimilarityCalculationError: If computation fails

        Example:
            >>> from similarity.jaccard_sim import JaccardSimilarityCalculator
            >>> calc = JaccardSimilarityCalculator()
            >>> result = calc.compute_similarity("hello world", "hello there")
            >>> print(f"Score: {result.score:.3f}")
            Score: 0.667
            >>> result.algorithm
            'jaccard'
        """
        pass

    @abstractmethod
    def get_algorithm_name(self) -> str:
        """
        Get the name of this similarity algorithm.

        This identifier is used for logging, debugging, and metadata tracking.
        Should be a lowercase, hyphenated string that uniquely identifies the
        algorithm (e.g., "jaccard", "difflib", "bm25", "hybrid").

        Returns:
            Algorithm name string

        Example:
            >>> from similarity.jaccard_sim import JaccardSimilarityCalculator
            >>> calc = JaccardSimilarityCalculator()
            >>> calc.get_algorithm_name()
            'jaccard'
        """
        pass
