"""
Core Interfaces - Abstract Contracts for Domain Operations

This module contains abstract base classes that define contracts
for domain operations. Implementations are provided in other modules.

Available Interfaces:
    - IChunker: Content chunking strategies
    - ISimilarityCalculator: Similarity calculation algorithms
    - IChangeDetector: Change detection workflows
    - IFileLoader: File loading operations
"""

from core.interfaces.chunker import IChunker
from core.interfaces.detection import IChangeDetector, IFileLoader
from core.interfaces.similarity import ISimilarityCalculator

__all__ = [
    "IChunker",
    "ISimilarityCalculator",
    "IChangeDetector",
    "IFileLoader",
]
