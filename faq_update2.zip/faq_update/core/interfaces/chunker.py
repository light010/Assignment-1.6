"""
IChunker - Abstract Interface for Text Chunking Strategies

This defines the contract that all chunking implementations must follow.
It is framework-agnostic and represents the core business capability of chunking.
"""

from abc import ABC, abstractmethod
from typing import List, Tuple
from core.models.chunk import ChunkMetadata


class IChunker(ABC):
    """
    Abstract base class defining the contract for all text chunking strategies.

    All chunkers must implement these methods to provide consistent behavior
    across different chunking strategies (recursive, header-based, hybrid, etc.).

    This interface represents the core domain capability: splitting text into
    manageable chunks with metadata and checksums for tracking.

    Design Principles:
        - Strategy Pattern: Different implementations for different chunking strategies
        - Liskov Substitution: All implementations must be interchangeable
        - Single Responsibility: Focus on chunking logic only
        - Framework Agnostic: No dependencies on specific libraries

    Example:
        >>> class MyCustomChunker(IChunker):
        ...     def chunk(self, content: str) -> List[str]:
        ...         # Custom chunking logic
        ...         return [content]
        ...
        ...     def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        ...         # Custom chunking with metadata
        ...         return [(content, "checksum123", ChunkMetadata(0, "custom"))]
    """

    @abstractmethod
    def chunk(self, content: str) -> List[str]:
        """
        Split content into chunks without metadata.

        This is the minimal chunking operation - just split text into
        appropriately-sized chunks following the strategy's rules.

        Args:
            content: Text content to chunk

        Returns:
            List of text chunks

        Raises:
            ChunkingError: If chunking fails due to invalid input or configuration

        Example:
            >>> chunker = RecursiveCharacterChunker(chunk_size=1000)
            >>> chunks = chunker.chunk("Long text content...")
            >>> len(chunks)
            5
        """
        pass

    @abstractmethod
    def chunk_with_checksums(
        self, content: str
    ) -> List[Tuple[str, str, ChunkMetadata]]:
        """
        Split content into chunks with checksums and metadata.

        This is the full-featured chunking operation that provides everything
        needed for change detection, tracking, and database storage.

        Args:
            content: Text content to chunk

        Returns:
            List of tuples, each containing:
                - chunk_text (str): The actual chunk text
                - checksum (str): SHA-256 hash of the chunk for change detection
                - metadata (ChunkMetadata): Domain object with chunk information

        Raises:
            ChunkingError: If chunking fails due to invalid input or configuration

        Example:
            >>> chunker = RecursiveCharacterChunker(chunk_size=1000)
            >>> results = chunker.chunk_with_checksums("Long text content...")
            >>> for chunk_text, checksum, metadata in results:
            ...     print(f"Chunk {metadata.chunk_index}: {len(chunk_text)} chars")
            ...     print(f"Method: {metadata.chunk_method}, Checksum: {checksum[:8]}...")
            Chunk 0: 982 chars
            Method: recursive, Checksum: a1b2c3d4...
        """
        pass
