"""
IChangeDetector and IFileLoader - Abstract Interfaces for Change Detection

This defines the pure contracts that all change detection implementations must follow.
It is framework-agnostic and represents the core business capability of detecting
changes in content.

Design Principles:
    - Strategy Pattern: Different implementations for different detection algorithms
    - Liskov Substitution: All implementations must be interchangeable
    - Single Responsibility: Focus on change detection only
    - Framework Agnostic: No dependencies on specific libraries or utilities
    - Dependency Injection: Similarity calculators and other dependencies are injected

This interface is analogous to IChunker and ISimilarityCalculator - it defines WHAT
change detection means, not HOW to implement it.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List

if TYPE_CHECKING:
    from core.models.detection import DetectionResult, DetectionConfig


class IChangeDetector(ABC):
    """
    Abstract base class defining the contract for all change detectors.

    All change detectors must implement these methods to provide consistent
    behavior across different algorithms (checksum-based, semantic, rule-based, etc.).

    This interface represents the core domain capability: detecting what has changed
    between two versions of content and returning structured results with metadata.

    Design Principles:
        - Strategy Pattern: Different implementations for different algorithms
        - Liskov Substitution: All implementations must be interchangeable
        - Single Responsibility: Focus on change detection logic only
        - Framework Agnostic: No dependencies on preprocessing or utilities
        - Returns domain models (DetectionResult), not database models

    Example:
        >>> from core.interfaces.detection import IChangeDetector
        >>> from core.models.detection import DetectionResult, DetectionConfig
        >>> from similarity.hybrid import HybridSimilarityCalculator
        >>>
        >>> class MyCustomDetector(IChangeDetector):
        ...     def __init__(self, similarity_calculator):
        ...         self.similarity_calculator = similarity_calculator
        ...         self.config = DetectionConfig()
        ...
        ...     def detect_changes(self, file_name, current_data, previous_data, run_id):
        ...         # Custom detection logic
        ...         results = []
        ...         # ... detection logic ...
        ...         return results
        ...
        ...     def get_config(self):
        ...         return self.config
        >>>
        >>> calc = HybridSimilarityCalculator.for_modification_detection()
        >>> detector = MyCustomDetector(calc)
        >>> results = detector.detect_changes("file.md", {}, {}, "run_123")
    """

    @abstractmethod
    def detect_changes(
        self,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
        run_id: str,
    ) -> List["DetectionResult"]:
        """
        Detect changes between current and previous content versions.

        This is the core operation - analyze two versions of content and return
        a list of detected changes with their classifications, similarity scores,
        and metadata.

        Args:
            file_name: Name of the file being analyzed
            current_data: Current version checksums and content
                Format: {checksum: {'text': '...', 'page_num': 42, ...}, ...}
            previous_data: Previous version checksums and content
                Format: {checksum: {'content_text': '...', 'page_number': 42, ...}, ...}
            run_id: Unique identifier for this detection run

        Returns:
            List of DetectionResult containing:
                - old_checksum (str): Checksum from previous version
                - new_checksum (str): Checksum from current version
                - change_type (ChangeType): NEW, MODIFIED, DELETED, or UNCHANGED
                - similarity_score (float): Similarity score [0.0, 1.0]
                - metadata (dict): Algorithm-specific information
                - file_name, page_number, content, etc.

        Raises:
            ValueError: If data is invalid or missing required fields
            DetectionError: If detection computation fails

        Design Notes:
            - Returns DetectionResult (domain model), not ContentChange (database model)
            - Results can be converted to database models using result.to_content_change()
            - Implementations should use injected similarity calculators (ISimilarityCalculator)
            - Per-file scoping: each file's changes are detected independently

        Example:
            >>> from detection.checksum_detector import ChecksumChangeDetector
            >>> from similarity.hybrid import HybridSimilarityCalculator
            >>>
            >>> calc = HybridSimilarityCalculator.for_modification_detection()
            >>> detector = ChecksumChangeDetector(calc)
            >>>
            >>> current = {
            ...     "abc123": {"text": "Hello World", "page_num": 1},
            ...     "def456": {"text": "New Content", "page_num": 2}
            ... }
            >>> previous = {
            ...     "abc123": {"content_text": "Hello World", "page_number": 1},
            ...     "xyz789": {"content_text": "Old Content", "page_number": 3}
            ... }
            >>>
            >>> results = detector.detect_changes("test.md", current, previous, "run_1")
            >>> len(results)
            3
            >>> results[0].change_type
            <ChangeType.UNCHANGED_CONTENT: 'unchanged_content'>
            >>> results[1].change_type
            <ChangeType.NEW_CONTENT: 'new_content'>
            >>> results[2].change_type
            <ChangeType.DELETED_CONTENT: 'deleted_content'>
        """
        pass

    @abstractmethod
    def get_config(self) -> "DetectionConfig":
        """
        Get the configuration of this change detector.

        This provides transparency into the detector's settings including
        similarity thresholds, algorithms used, weights, and other parameters.
        Useful for debugging, logging, and metadata tracking.

        Returns:
            DetectionConfig object containing:
                - checksum_algorithm (str): Algorithm used (e.g., "sha256")
                - similarity_threshold (float): Threshold for MODIFIED classification
                - compute_llm_diffs (bool): Whether to generate LLM-friendly diffs
                - diff_context_lines (int): Context lines for diffs
                - similarity_weights (dict): Weights for hybrid similarity

        Example:
            >>> from detection.checksum_detector import ChecksumChangeDetector
            >>> from similarity.hybrid import HybridSimilarityCalculator
            >>>
            >>> calc = HybridSimilarityCalculator.for_modification_detection()
            >>> detector = ChecksumChangeDetector(calc)
            >>> config = detector.get_config()
            >>> config.similarity_threshold
            0.8
            >>> config.checksum_algorithm
            'sha256'
            >>> config.to_dict()
            {'checksum_algorithm': 'sha256', 'similarity_threshold': 0.8, ...}
        """
        pass


class IFileLoader(ABC):
    """
    Abstract base class defining the contract for loading content from various sources.

    File loaders are responsible for extracting checksums and content from different
    file formats (markdown, CSV, JSON, database queries, etc.) and returning them
    in a standardized format for change detection.

    Design Principles:
        - Strategy Pattern: Different implementations for different file formats
        - Liskov Substitution: All implementations must be interchangeable
        - Single Responsibility: Focus on file loading and parsing only
        - Consistent Output: All loaders return the same data structure

    Example:
        >>> from core.interfaces.detection import IFileLoader
        >>>
        >>> class MyCustomLoader(IFileLoader):
        ...     def load_from_markdown(self, path):
        ...         # Custom markdown loading logic
        ...         return {"checksum1": {"text": "...", "page_num": 1}}
        ...
        ...     def load_from_csv(self, path):
        ...         # Custom CSV loading logic
        ...         return {"checksum1": {"content_text": "...", "page_number": 1}}
        >>>
        >>> loader = MyCustomLoader()
        >>> data = loader.load_from_markdown("path/to/file.md")
    """

    @abstractmethod
    def load_from_markdown(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from markdown files.

        Scans a directory of markdown files, computes checksums for each content
        section, and returns a dictionary mapping checksums to their content and metadata.

        Args:
            path: Path to markdown directory or file

        Returns:
            Dictionary mapping checksums to content metadata:
                {
                    "checksum1": {
                        "text": "Content text...",
                        "page_num": 42,
                        "markdown_path": "path/to/file.md",
                        # ... other metadata ...
                    },
                    "checksum2": {...},
                }

        Raises:
            FileNotFoundError: If path does not exist
            ValueError: If content cannot be parsed
            IOError: If file cannot be read

        Example:
            >>> from data_ingestion.loaders import MarkdownFileLoader
            >>> loader = MarkdownFileLoader()
            >>> data = loader.load_from_markdown("./data/markdown/")
            >>> len(data)
            42
            >>> list(data.keys())[0]
            'a1b2c3d4e5f6...'
            >>> data['a1b2c3d4e5f6...']['text']
            'How do I reset my password?'
        """
        pass

    @abstractmethod
    def load_from_csv(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from CSV file.

        Reads a CSV file containing content and checksums, and returns a dictionary
        mapping checksums to their content and metadata.

        Args:
            path: Path to CSV file

        Returns:
            Dictionary mapping checksums to content metadata:
                {
                    "checksum1": {
                        "content_text": "Content text...",
                        "page_number": 42,
                        # ... other metadata ...
                    },
                    "checksum2": {...},
                }

        Raises:
            FileNotFoundError: If CSV file does not exist
            ValueError: If CSV format is invalid
            IOError: If file cannot be read

        Example:
            >>> from data_ingestion.loaders import CSVFileLoader
            >>> loader = CSVFileLoader()
            >>> data = loader.load_from_csv("./data/previous_checksums.csv")
            >>> len(data)
            38
            >>> list(data.keys())[0]
            'x1y2z3...'
            >>> data['x1y2z3...']['content_text']
            'Previous FAQ content...'
        """
        pass
