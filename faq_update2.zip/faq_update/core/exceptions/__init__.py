"""
Core Exceptions - Domain-Specific Error Types

This module contains exception classes that represent domain-level errors.
These exceptions communicate business rule violations and validation failures.
"""

from core.exceptions.chunking import (
    ChunkingError,
    ChunkSizeError,
    ChunkOverlapError,
    ChunkValidationError,
)
from core.exceptions.similarity import (
    SimilarityError,
    InvalidSimilarityThresholdError,
    SimilarityCalculationError,
    InvalidWeightConfigurationError,
)

__all__ = [
    "ChunkingError",
    "ChunkSizeError",
    "ChunkOverlapError",
    "ChunkValidationError",
    "SimilarityError",
    "InvalidSimilarityThresholdError",
    "SimilarityCalculationError",
    "InvalidWeightConfigurationError",
]
