"""
Similarity Exceptions - Domain-Specific Error Types

This module defines exception classes for similarity-related errors.
These exceptions represent business rule violations and calculation failures.

Exception Hierarchy:
    SimilarityError
    ├── InvalidSimilarityThresholdError
    ├── SimilarityCalculationError
    └── InvalidWeightConfigurationError

These exceptions are analogous to ChunkingError in the chunking module.
"""


class SimilarityError(Exception):
    """
    Base exception for all similarity-related errors.

    This is the root of the similarity exception hierarchy. All similarity
    errors should inherit from this class to allow for easy catching of
    all similarity-related issues.

    Example:
        >>> try:
        ...     result = calc.compute_similarity(None, "text")
        ... except SimilarityError as e:
        ...     print(f"Similarity error: {e}")
        Similarity error: Texts cannot be None
    """

    pass


class InvalidSimilarityThresholdError(SimilarityError):
    """
    Exception raised when a similarity threshold violates business rules.

    Business Rule: Thresholds must be between 0.0 and 1.0 (inclusive)

    This is raised when:
    - Threshold is negative
    - Threshold is greater than 1.0
    - Thresholds in SimilarityMatchPolicy are not in descending order

    Example:
        >>> raise InvalidSimilarityThresholdError(
        ...     "Threshold must be between 0.0 and 1.0, got 1.5"
        ... )
        InvalidSimilarityThresholdError: Threshold must be between 0.0 and 1.0, got 1.5
    """

    pass


class SimilarityCalculationError(SimilarityError):
    """
    Exception raised when similarity calculation fails.

    This can occur when:
    - Texts cannot be processed by the algorithm
    - Algorithm encounters unexpected input (malformed text, incompatible encoding)
    - Calculation produces invalid results (NaN, infinity)
    - Required dependencies are unavailable

    Example:
        >>> raise SimilarityCalculationError(
        ...     "Failed to compute similarity: division by zero in BM25 calculation"
        ... )
        SimilarityCalculationError: Failed to compute similarity: division by zero...
    """

    pass


class InvalidWeightConfigurationError(SimilarityError):
    """
    Exception raised when algorithm weights violate business rules.

    Business Rule: In hybrid algorithms, weights must sum to 1.0 (within tolerance)

    This is raised when:
    - Weights don't sum to 1.0 (within 0.01 tolerance)
    - Individual weights are negative
    - FAQSimilarityConfig has invalid weight configuration

    Example:
        >>> raise InvalidWeightConfigurationError(
        ...     "Algorithm weights must sum to 1.0, got 0.75. "
        ...     "Weights: jaccard=0.3, difflib=0.45"
        ... )
        InvalidWeightConfigurationError: Algorithm weights must sum to 1.0, got 0.75...
    """

    pass


# Convenience exports
__all__ = [
    "SimilarityError",
    "InvalidSimilarityThresholdError",
    "SimilarityCalculationError",
    "InvalidWeightConfigurationError",
]
