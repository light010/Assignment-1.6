"""
Chunking Exceptions - Domain-Specific Error Types

This module defines exception classes for chunking-related errors.
These exceptions represent business rule violations and validation failures.
"""


class ChunkingError(Exception):
    """
    Base exception for all chunking-related errors.

    This is the root of the chunking exception hierarchy. All chunking
    errors should inherit from this class to allow for easy catching
    of all chunking-related issues.

    Example:
        >>> try:
        ...     chunker = RecursiveCharacterChunker(chunk_size=-100)
        ... except ChunkingError as e:
        ...     print(f"Chunking error: {e}")
        Chunking error: Chunk size must be positive...
    """

    pass


class ChunkSizeError(ChunkingError):
    """
    Exception raised when chunk_size violates business rules.

    Business Rule: chunk_size must be positive (> 0)

    Example:
        >>> raise ChunkSizeError("chunk_size must be positive, got -100")
        ChunkSizeError: chunk_size must be positive, got -100
    """

    pass


class ChunkOverlapError(ChunkingError):
    """
    Exception raised when chunk_overlap violates business rules.

    Business Rule: chunk_overlap must be less than chunk_size

    Example:
        >>> raise ChunkOverlapError("chunk_overlap (800) must be less than chunk_size (500)")
        ChunkOverlapError: chunk_overlap (800) must be less than chunk_size (500)
    """

    pass


class ChunkValidationError(ChunkingError):
    """
    Exception raised when chunk content fails validation.

    This can occur when:
    - Content cannot be chunked using the specified strategy
    - Content structure is invalid for the chunking method
    - Metadata cannot be generated for chunks

    Example:
        >>> raise ChunkValidationError("Cannot split content: no valid separators found")
        ChunkValidationError: Cannot split content: no valid separators found
    """

    pass
