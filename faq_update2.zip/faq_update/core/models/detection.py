"""
Detection Domain Models - Value Objects and Business Rules

This module contains pure domain models representing change detection concepts.
These are framework-agnostic value objects used across all detection algorithms.

Models included:
    - ChangeType: Enum defining types of content changes
    - DetectionResult: The result of a change detection analysis
    - DetectionConfig: Configuration for change detection algorithms

These models are analogous to SimilarityResult and ChunkMetadata in other modules -
they represent domain concepts, not implementation details.

Design Principles:
    - Immutable value objects (dataclasses with frozen=True where appropriate)
    - Domain-driven design (represents business concepts)
    - Framework agnostic (no dependencies on database, utilities, etc.)
    - Separation from database models (DetectionResult != ContentChange)
    - Rich behavior (methods for conversion, validation, serialization)
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


class ChangeType(str, Enum):
    """
    Types of content changes detected during analysis.

    This enum represents the business classification of how content has changed
    between two versions. It is used by change detectors to classify their findings.

    Values:
        - NEW_CONTENT: Content appears in current version but not in previous
        - MODIFIED_CONTENT: Content exists in both versions but differs (similarity >= threshold)
        - DELETED_CONTENT: Content appears in previous version but not in current
        - UNCHANGED_CONTENT: Content is identical in both versions

    Business Rules:
        - NEW_CONTENT: similarity_score = 0.0, old_checksum = "", new_checksum != ""
        - MODIFIED_CONTENT: similarity_score >= threshold, old_checksum != "", new_checksum != ""
        - DELETED_CONTENT: similarity_score = 0.0, old_checksum != "", new_checksum = ""
        - UNCHANGED_CONTENT: similarity_score = 1.0, old_checksum == new_checksum

    Example:
        >>> ChangeType.NEW_CONTENT
        <ChangeType.NEW_CONTENT: 'new_content'>
        >>> ChangeType.NEW_CONTENT.value
        'new_content'
        >>> str(ChangeType.MODIFIED_CONTENT)
        'ChangeType.MODIFIED_CONTENT'
        >>> ChangeType('modified_content')
        <ChangeType.MODIFIED_CONTENT: 'modified_content'>
    """

    NEW_CONTENT = "new_content"
    MODIFIED_CONTENT = "modified_content"
    DELETED_CONTENT = "deleted_content"
    UNCHANGED_CONTENT = "unchanged_content"


@dataclass
class DetectionResult:
    """
    Immutable result of a change detection analysis.

    This domain model captures the essential information about a detected change:
    what changed, how it changed, similarity scores, and contextual metadata.

    This is a DOMAIN MODEL, not a database model. It represents the business concept
    of a "detected change" and can be converted to database models (ContentChange)
    when persistence is needed.

    Attributes:
        old_checksum: Checksum from previous version ("" if NEW_CONTENT)
        new_checksum: Checksum from current version ("" if DELETED_CONTENT)
        change_type: Classification of the change
        similarity_score: Similarity between old and new content [0.0, 1.0]
        detected_at: Timestamp when change was detected
        file_name: Name of file containing the change (optional)
        page_number: Page number where change appears (optional)
        old_content: Text content from previous version (optional)
        new_content: Text content from current version (optional)
        metadata: Additional algorithm-specific information
        similarity_method: Method used for similarity calculation (default: "hybrid")
        requires_faq_regeneration: Whether this change requires FAQ regeneration (auto-calculated)

    Business Rules:
        - similarity_score must be between 0.0 and 1.0
        - NEW_CONTENT: old_checksum must be empty, new_checksum must not be empty
        - DELETED_CONTENT: new_checksum must be empty, old_checksum must not be empty
        - MODIFIED_CONTENT: both checksums must not be empty, must be different
        - UNCHANGED_CONTENT: both checksums must be identical
        - requires_faq_regeneration: True for NEW/MODIFIED/DELETED, False for UNCHANGED

    Example:
        >>> from datetime import datetime
        >>> result = DetectionResult(
        ...     old_checksum="abc123",
        ...     new_checksum="def456",
        ...     change_type=ChangeType.MODIFIED_CONTENT,
        ...     similarity_score=0.87,
        ...     detected_at=datetime.now(),
        ...     file_name="faq.md",
        ...     page_number=5,
        ...     old_content="Old text",
        ...     new_content="New text",
        ...     metadata={"llm_diff": {...}}
        ... )
        >>> result.change_type
        <ChangeType.MODIFIED_CONTENT: 'modified_content'>
        >>> result.similarity_score
        0.87
        >>> result.requires_faq_regeneration
        True
        >>> result.similarity_method
        'hybrid'
    """

    old_checksum: str
    new_checksum: str
    change_type: ChangeType
    similarity_score: float
    detected_at: datetime = field(default_factory=datetime.now)

    # Context metadata (optional)
    file_name: Optional[str] = None
    page_number: Optional[int] = None

    # Content (optional, for analysis and reporting)
    old_content: Optional[str] = None
    new_content: Optional[str] = None

    # Algorithm-specific metadata (diffs, algorithm breakdown, etc.)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # ✅ NEW: Similarity method (default: "hybrid")
    similarity_method: str = "hybrid"

    # ✅ NEW: Auto-calculated field for FAQ regeneration requirement
    requires_faq_regeneration: bool = field(init=False)

    def __post_init__(self):
        """Validate detection result business rules and calculate derived fields."""
        # ✅ Calculate requires_faq_regeneration based on change type
        # Only UNCHANGED_CONTENT does NOT require regeneration
        self.requires_faq_regeneration = self.change_type in [
            ChangeType.NEW_CONTENT,
            ChangeType.MODIFIED_CONTENT,
            ChangeType.DELETED_CONTENT,
        ]

        # Validate similarity score range
        if not (0.0 <= self.similarity_score <= 1.0):
            raise ValueError(
                f"similarity_score must be between 0.0 and 1.0, got {self.similarity_score}"
            )

        # Validate checksum consistency with change type
        if self.change_type == ChangeType.NEW_CONTENT:
            if self.old_checksum != "":
                raise ValueError(
                    f"NEW_CONTENT must have empty old_checksum, got '{self.old_checksum}'"
                )
            if self.new_checksum == "":
                raise ValueError("NEW_CONTENT must have non-empty new_checksum")

        elif self.change_type == ChangeType.DELETED_CONTENT:
            if self.new_checksum != "":
                raise ValueError(
                    f"DELETED_CONTENT must have empty new_checksum, got '{self.new_checksum}'"
                )
            if self.old_checksum == "":
                raise ValueError("DELETED_CONTENT must have non-empty old_checksum")

        elif self.change_type == ChangeType.MODIFIED_CONTENT:
            if self.old_checksum == "" or self.new_checksum == "":
                raise ValueError(
                    "MODIFIED_CONTENT must have both old_checksum and new_checksum"
                )
            if self.old_checksum == self.new_checksum:
                raise ValueError(
                    "MODIFIED_CONTENT must have different checksums "
                    f"(got identical: '{self.old_checksum}')"
                )

        elif self.change_type == ChangeType.UNCHANGED_CONTENT:
            if self.old_checksum != self.new_checksum:
                raise ValueError(
                    f"UNCHANGED_CONTENT must have identical checksums, "
                    f"got old='{self.old_checksum}' != new='{self.new_checksum}'"
                )
            if self.old_checksum == "":
                raise ValueError("UNCHANGED_CONTENT must have non-empty checksums")

    @property
    def llm_diff(self) -> Optional[str]:
        """
        Get LLM-friendly diff from metadata.

        This property provides convenient access to the llm_diff stored in metadata,
        matching the interface expected by the repository layer.

        Returns:
            LLM-friendly diff JSON string, or None if not available

        Example:
            >>> result = DetectionResult(
            ...     old_checksum="abc",
            ...     new_checksum="def",
            ...     change_type=ChangeType.MODIFIED_CONTENT,
            ...     similarity_score=0.85,
            ...     metadata={"llm_diff": '{"total_changes": 2}'}
            ... )
            >>> result.llm_diff
            '{"total_changes": 2}'
        """
        return self.metadata.get("llm_diff")

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert result to dictionary for serialization.

        Returns:
            Dictionary representation with all fields

        Example:
            >>> result = DetectionResult(
            ...     old_checksum="abc",
            ...     new_checksum="def",
            ...     change_type=ChangeType.MODIFIED_CONTENT,
            ...     similarity_score=0.85,
            ...     detected_at=datetime(2025, 11, 1, 12, 0, 0)
            ... )
            >>> d = result.to_dict()
            >>> d['change_type']
            'modified_content'
            >>> d['similarity_score']
            0.85
            >>> d['requires_faq_regeneration']
            True
            >>> d['similarity_method']
            'hybrid'
        """
        return {
            "old_checksum": self.old_checksum,
            "new_checksum": self.new_checksum,
            "change_type": self.change_type.value,
            "similarity_score": self.similarity_score,
            "similarity_method": self.similarity_method,
            "requires_faq_regeneration": self.requires_faq_regeneration,
            "detected_at": self.detected_at.isoformat(),
            "file_name": self.file_name,
            "page_number": self.page_number,
            "old_content": self.old_content,
            "new_content": self.new_content,
            "metadata": self.metadata,
        }

    def to_content_change(self):
        """
        Convert to database ContentChange model for persistence.

        This method bridges the domain model (DetectionResult) and the database
        model (ContentChange). It handles the conversion of domain types to
        database types.

        Returns:
            ContentChange database model instance

        Raises:
            ImportError: If database.models cannot be imported

        Example:
            >>> result = DetectionResult(
            ...     old_checksum="abc",
            ...     new_checksum="def",
            ...     change_type=ChangeType.MODIFIED_CONTENT,
            ...     similarity_score=0.85,
            ...     detected_at=datetime.now(),
            ...     file_name="test.md",
            ...     metadata={"llm_diff": "..."}
            ... )
            >>> content_change = result.to_content_change()
            >>> content_change.change_type.value
            'modified_content'
            >>> content_change.similarity_score
            0.85
        """
        from database.models import ChangeType as DBChangeType
        from database.models import ContentChange

        return ContentChange(
            old_checksum=self.old_checksum,
            new_checksum=self.new_checksum,
            change_type=DBChangeType(self.change_type.value),
            detected_at=self.detected_at,
            file_name=self.file_name,
            page_number=self.page_number,
            old_content=self.old_content,
            new_content=self.new_content,
            similarity_score=self.similarity_score,
            llm_friendly_diff=self.metadata.get("llm_diff"),
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DetectionResult":
        """
        Create DetectionResult from dictionary (e.g., from JSON or database).

        Args:
            data: Dictionary with required fields

        Returns:
            DetectionResult instance

        Raises:
            ValueError: If data is invalid
            KeyError: If required fields are missing

        Example:
            >>> data = {
            ...     'old_checksum': 'abc',
            ...     'new_checksum': 'def',
            ...     'change_type': 'modified_content',
            ...     'similarity_score': 0.85,
            ...     'detected_at': '2025-11-01T12:00:00',
            ...     'file_name': 'test.md',
            ...     'metadata': {}
            ... }
            >>> result = DetectionResult.from_dict(data)
            >>> result.similarity_score
            0.85
        """
        # Handle datetime parsing
        detected_at = data.get("detected_at")
        if isinstance(detected_at, str):
            detected_at = datetime.fromisoformat(detected_at)
        elif detected_at is None:
            detected_at = datetime.now()

        # Handle ChangeType parsing
        change_type = data["change_type"]
        if isinstance(change_type, str):
            change_type = ChangeType(change_type)

        return cls(
            old_checksum=data["old_checksum"],
            new_checksum=data["new_checksum"],
            change_type=change_type,
            similarity_score=data["similarity_score"],
            detected_at=detected_at,
            file_name=data.get("file_name"),
            page_number=data.get("page_number"),
            old_content=data.get("old_content"),
            new_content=data.get("new_content"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class DetectionConfig:
    """
    Configuration for change detection algorithms.

    This domain object encapsulates the business configuration for how change
    detection should be performed. It centralizes configuration that determines
    detection behavior.

    Attributes:
        checksum_algorithm: Hash algorithm to use (default: "sha256")
        similarity_threshold: Minimum similarity for MODIFIED classification (default: 0.8)
        compute_llm_diffs: Whether to generate LLM-friendly diffs (default: False)
        diff_context_lines: Number of context lines for diffs (default: 3)
        similarity_weights: Weights for hybrid similarity algorithms

    Business Rules:
        - similarity_threshold must be between 0.0 and 1.0
        - diff_context_lines must be non-negative
        - similarity_weights must sum to 1.0 if provided
        - For FAQ modifications, difflib weight should be higher (better for small changes)

    Example:
        >>> config = DetectionConfig()
        >>> config.similarity_threshold
        0.8
        >>> config.checksum_algorithm
        'sha256'
        >>> config.to_dict()
        {'checksum_algorithm': 'sha256', 'similarity_threshold': 0.8, ...}
        >>>
        >>> # Custom config
        >>> custom = DetectionConfig(
        ...     similarity_threshold=0.85,
        ...     compute_llm_diffs=True,
        ...     diff_context_lines=5,
        ...     similarity_weights={"jaccard": 0.40, "difflib": 0.60}
        ... )
        >>> custom.similarity_threshold
        0.85
    """

    checksum_algorithm: str = "sha256"
    similarity_threshold: float = 0.8
    compute_llm_diffs: bool = False
    diff_context_lines: int = 3
    similarity_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "jaccard": 0.40,
            "difflib": 0.60,
        }
    )

    def __post_init__(self):
        """Validate configuration business rules."""
        # Validate similarity threshold
        if not (0.0 <= self.similarity_threshold <= 1.0):
            raise ValueError(
                f"similarity_threshold must be between 0.0 and 1.0, "
                f"got {self.similarity_threshold}"
            )

        # Validate diff context lines
        if self.diff_context_lines < 0:
            raise ValueError(
                f"diff_context_lines must be non-negative, got {self.diff_context_lines}"
            )

        # Validate similarity weights sum to 1.0 (within tolerance)
        if self.similarity_weights:
            total_weight = sum(self.similarity_weights.values())
            if not (0.99 <= total_weight <= 1.01):
                raise ValueError(
                    f"similarity_weights must sum to 1.0 (within 0.01 tolerance), "
                    f"got {total_weight}. Weights: {self.similarity_weights}"
                )

            # Validate all weights are non-negative
            for name, weight in self.similarity_weights.items():
                if weight < 0:
                    raise ValueError(
                        f"All weights must be non-negative, got {name}={weight}"
                    )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert config to dictionary for serialization.

        Returns:
            Dictionary representation with all fields

        Example:
            >>> config = DetectionConfig(similarity_threshold=0.85)
            >>> d = config.to_dict()
            >>> d['similarity_threshold']
            0.85
            >>> d['checksum_algorithm']
            'sha256'
        """
        return {
            "checksum_algorithm": self.checksum_algorithm,
            "similarity_threshold": self.similarity_threshold,
            "compute_llm_diffs": self.compute_llm_diffs,
            "diff_context_lines": self.diff_context_lines,
            "similarity_weights": self.similarity_weights.copy(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DetectionConfig":
        """
        Create DetectionConfig from dictionary.

        Args:
            data: Dictionary with config fields

        Returns:
            DetectionConfig instance

        Example:
            >>> data = {
            ...     'checksum_algorithm': 'sha256',
            ...     'similarity_threshold': 0.85,
            ...     'compute_llm_diffs': True,
            ...     'diff_context_lines': 5,
            ...     'similarity_weights': {'jaccard': 0.4, 'difflib': 0.6}
            ... }
            >>> config = DetectionConfig.from_dict(data)
            >>> config.similarity_threshold
            0.85
        """
        return cls(
            checksum_algorithm=data.get("checksum_algorithm", "sha256"),
            similarity_threshold=data.get("similarity_threshold", 0.8),
            compute_llm_diffs=data.get("compute_llm_diffs", False),
            diff_context_lines=data.get("diff_context_lines", 3),
            similarity_weights=data.get(
                "similarity_weights", {"jaccard": 0.40, "difflib": 0.60}
            ),
        )


# Convenience exports
__all__ = [
    "ChangeType",
    "DetectionResult",
    "DetectionConfig",
]
