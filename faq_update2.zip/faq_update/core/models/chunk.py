"""
ChunkMetadata - Domain Value Object for Chunk Metadata

This is a pure domain model representing metadata about a text chunk.
It is used across all chunking strategies and must remain framework-agnostic.
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional


@dataclass(frozen=True)
class ChunkMetadata:
    """
    Immutable value object representing metadata about a text chunk.

    This domain model captures the essential information about how a chunk
    was created and where it came from in the original content.

    Attributes:
        chunk_index: Zero-based index of this chunk in the sequence
        chunk_method: Strategy used to create this chunk ("recursive", "header", "no_split")
        headers: Hierarchical markdown headers context (e.g., {"h1": "Title", "h2": "Section"})
        start_pos: Starting character position in original content (None for header-only splits)
        end_pos: Ending character position in original content (None for header-only splits)

    Business Rules:
        - chunk_index must be non-negative
        - chunk_method must be one of the supported strategies
        - If start_pos is provided, end_pos must also be provided and > start_pos
        - headers is always a dict (empty if no headers present)

    Example:
        >>> metadata = ChunkMetadata(
        ...     chunk_index=0,
        ...     chunk_method="recursive",
        ...     headers={"h1": "Introduction"},
        ...     start_pos=0,
        ...     end_pos=3000
        ... )
        >>> metadata.chunk_index
        0
        >>> metadata.to_dict()
        {'chunk_index': 0, 'chunk_method': 'recursive', ...}
    """

    chunk_index: int
    chunk_method: str
    headers: Dict[str, str] = field(default_factory=dict)
    start_pos: Optional[int] = None
    end_pos: Optional[int] = None

    def __post_init__(self):
        """Validate business invariants."""
        if self.chunk_index < 0:
            raise ValueError(f"chunk_index must be non-negative, got {self.chunk_index}")

        valid_methods = {"recursive", "header", "no_split"}
        if self.chunk_method not in valid_methods:
            raise ValueError(
                f"chunk_method must be one of {valid_methods}, got '{self.chunk_method}'"
            )

        # Validate position consistency
        if self.start_pos is not None and self.end_pos is not None:
            if self.end_pos <= self.start_pos:
                raise ValueError(
                    f"end_pos ({self.end_pos}) must be greater than start_pos ({self.start_pos})"
                )
        elif self.start_pos is not None or self.end_pos is not None:
            raise ValueError("start_pos and end_pos must both be provided or both be None")

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary for database storage or serialization.

        Returns:
            Dictionary representation with all fields

        Example:
            >>> metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")
            >>> metadata.to_dict()
            {'chunk_index': 0, 'chunk_method': 'recursive', 'headers': {}, 'start_pos': None, 'end_pos': None}
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChunkMetadata":
        """
        Create ChunkMetadata from dictionary (e.g., from database).

        Args:
            data: Dictionary with metadata fields

        Returns:
            ChunkMetadata instance

        Raises:
            ValueError: If data is invalid or missing required fields

        Example:
            >>> data = {'chunk_index': 0, 'chunk_method': 'recursive', 'headers': {}}
            >>> metadata = ChunkMetadata.from_dict(data)
            >>> metadata.chunk_index
            0
        """
        # Extract only fields that ChunkMetadata accepts
        valid_fields = {'chunk_index', 'chunk_method', 'headers', 'start_pos', 'end_pos'}
        filtered_data = {k: v for k, v in data.items() if k in valid_fields}

        return cls(**filtered_data)
