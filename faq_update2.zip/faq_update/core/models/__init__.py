"""
Core Models - Domain Value Objects and Entities

This module contains immutable value objects and domain entities
that represent core business concepts.
"""

from core.models.chunk import ChunkMetadata
from core.models.detection import ChangeType, DetectionConfig, DetectionResult
from core.models.similarity import (
    ChangeClassification,
    DEFAULT_FAQ_CONFIG,
    FAQSimilarityConfig,
    SimilarityMatchPolicy,
    SimilarityResult,
    SimilarityThreshold,
)

__all__ = [
    "ChunkMetadata",
    "SimilarityResult",
    "SimilarityThreshold",
    "ChangeClassification",
    "SimilarityMatchPolicy",
    "FAQSimilarityConfig",
    "DEFAULT_FAQ_CONFIG",
    "DetectionResult",
    "DetectionConfig",
    "ChangeType",
]
