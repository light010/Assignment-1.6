"""
Similarity Domain Models - Value Objects and Business Rules

This module contains pure domain models representing similarity concepts.
These are framework-agnostic value objects used across all similarity algorithms.

Models included:
    - SimilarityResult: The result of a similarity comparison
    - SimilarityThreshold: Business-defined thresholds for similarity levels
    - ChangeClassification: Classification of content changes
    - SimilarityMatchPolicy: Business rules for classifying similarity scores
    - FAQSimilarityConfig: Configuration for FAQ similarity calculations

These models are analogous to ChunkMetadata in the chunking module - they represent
domain concepts, not implementation details.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, NamedTuple


@dataclass
class SimilarityResult:
    """
    Immutable result of a similarity comparison between two texts.

    This domain model captures the essential information about a similarity
    calculation: the score, the texts compared, the algorithm used, and
    algorithm-specific metadata.

    Attributes:
        score: Similarity score between 0.0 (different) and 1.0 (identical)
        text1: First text compared
        text2: Second text compared
        algorithm: Name of the algorithm used (e.g., "jaccard", "difflib")
        metadata: Additional algorithm-specific information

    Business Rules:
        - score must be between 0.0 and 1.0 (inclusive)
        - texts and algorithm must be non-empty strings
        - metadata is always a dict (empty if no additional info)

    Example:
        >>> result = SimilarityResult(
        ...     score=0.85,
        ...     text1="hello world",
        ...     text2="hello there",
        ...     algorithm="jaccard",
        ...     metadata={"intersection_size": 1, "union_size": 3}
        ... )
        >>> result.score
        0.85
        >>> result.is_similar(0.80)
        True
        >>> result.to_dict()
        {'score': 0.85, 'text1': 'hello world', ...}
    """

    score: float
    text1: str
    text2: str
    algorithm: str
    metadata: Dict[str, Any]

    def __post_init__(self):
        """Validate similarity result."""
        if not (0.0 <= self.score <= 1.0):
            raise ValueError(
                f"Similarity score must be between 0.0 and 1.0, got {self.score}"
            )

    def is_similar(self, threshold: float) -> bool:
        """
        Check if similarity exceeds threshold.

        Args:
            threshold: Minimum similarity score to be considered similar

        Returns:
            True if score >= threshold

        Example:
            >>> result = SimilarityResult(0.85, "a", "b", "jaccard", {})
            >>> result.is_similar(0.80)
            True
            >>> result.is_similar(0.90)
            False
        """
        return self.score >= threshold

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert result to dictionary for serialization.

        Returns:
            Dictionary representation with all fields

        Example:
            >>> result = SimilarityResult(0.85, "hello", "hi", "jaccard", {})
            >>> d = result.to_dict()
            >>> d['score']
            0.85
            >>> d['algorithm']
            'jaccard'
        """
        return {
            "score": self.score,
            "text1": self.text1,
            "text2": self.text2,
            "algorithm": self.algorithm,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SimilarityResult":
        """
        Create SimilarityResult from dictionary (e.g., from database or JSON).

        Args:
            data: Dictionary with required fields

        Returns:
            SimilarityResult instance

        Raises:
            ValueError: If data is invalid or missing required fields
            KeyError: If required fields are missing

        Example:
            >>> data = {
            ...     'score': 0.75,
            ...     'text1': 'hello',
            ...     'text2': 'hi',
            ...     'algorithm': 'difflib',
            ...     'metadata': {}
            ... }
            >>> result = SimilarityResult.from_dict(data)
            >>> result.score
            0.75
        """
        return cls(
            score=data["score"],
            text1=data["text1"],
            text2=data["text2"],
            algorithm=data["algorithm"],
            metadata=data.get("metadata", {}),
        )


class SimilarityThreshold(Enum):
    """
    Business-defined threshold values for FAQ similarity classification.

    These thresholds represent domain knowledge about what constitutes
    different levels of similarity in FAQ content. They are used by
    SimilarityMatchPolicy to classify changes.

    Threshold Values:
        - IDENTICAL (0.95): Texts are essentially the same (minor formatting differences)
        - MINOR_MODIFICATION (0.85): Small changes like "10" → "12" or date updates
        - MAJOR_MODIFICATION (0.70): Significant content changes but same topic
        - SIGNIFICANT_CHANGE (0.40): Large changes, possibly different topic
        - NEW_CONTENT (0.0): Completely different content

    Example:
        >>> SimilarityThreshold.MINOR_MODIFICATION.value
        0.85
        >>> threshold = SimilarityThreshold.MAJOR_MODIFICATION
        >>> threshold.value
        0.70
    """

    IDENTICAL = 0.95
    MINOR_MODIFICATION = 0.85
    MAJOR_MODIFICATION = 0.70
    SIGNIFICANT_CHANGE = 0.40
    NEW_CONTENT = 0.0


class ChangeClassification(NamedTuple):
    """
    Classification of content changes based on similarity analysis.

    This value object represents the business classification of how much
    content has changed between two versions.

    Attributes:
        change_type: Category of change ("identical", "minor_modification", etc.)
        score: The similarity score that led to this classification
        details: Additional context (algorithm breakdown, metadata, etc.)

    Valid change_type values:
        - "identical": No meaningful changes
        - "minor_modification": Small updates (numbers, dates)
        - "major_modification": Significant content changes
        - "significant_change": Large structural changes
        - "new_content": Completely different

    Example:
        >>> classification = ChangeClassification(
        ...     change_type="minor_modification",
        ...     score=0.87,
        ...     details={"breakdown": {"jaccard": 0.85, "difflib": 0.89}}
        ... )
        >>> classification.change_type
        'minor_modification'
        >>> classification.score
        0.87
    """

    change_type: str
    score: float
    details: Dict[str, Any]


def validate_change_type(change_type: str) -> None:
    """
    Validate that a change_type is one of the valid values.

    Args:
        change_type: The change type string to validate

    Raises:
        ValueError: If change_type is not valid

    Example:
        >>> validate_change_type("minor_modification")  # OK
        >>> validate_change_type("invalid")  # Raises ValueError
    """
    valid_types = {
        "identical",
        "minor_modification",
        "major_modification",
        "significant_change",
        "new_content",
    }
    if change_type not in valid_types:
        raise ValueError(
            f"change_type must be one of {valid_types}, got '{change_type}'"
        )


@dataclass(frozen=True)
class SimilarityMatchPolicy:
    """
    Business policy for classifying similarity scores.

    This domain object encapsulates the business rules for determining
    what level of similarity corresponds to what type of change. It
    centralizes threshold logic that was previously scattered across
    calculator implementations.

    Attributes:
        identical_threshold: Minimum score for "identical" classification (default: 0.95)
        minor_modification_threshold: Minimum score for "minor_modification" (default: 0.85)
        major_modification_threshold: Minimum score for "major_modification" (default: 0.70)
        significant_change_threshold: Minimum score for "significant_change" (default: 0.40)

    Anything below significant_change_threshold is classified as "new_content".

    Example:
        >>> policy = SimilarityMatchPolicy()
        >>> policy.classify(0.87)
        'minor_modification'
        >>> policy.classify(0.65)
        'major_modification'
        >>>
        >>> classification = policy.classify_detailed(0.87)
        >>> classification.change_type
        'minor_modification'
        >>> classification.score
        0.87
    """

    identical_threshold: float = SimilarityThreshold.IDENTICAL.value
    minor_modification_threshold: float = SimilarityThreshold.MINOR_MODIFICATION.value
    major_modification_threshold: float = SimilarityThreshold.MAJOR_MODIFICATION.value
    significant_change_threshold: float = SimilarityThreshold.SIGNIFICANT_CHANGE.value

    def __post_init__(self):
        """Validate thresholds are in descending order."""
        thresholds = [
            self.identical_threshold,
            self.minor_modification_threshold,
            self.major_modification_threshold,
            self.significant_change_threshold,
        ]
        if thresholds != sorted(thresholds, reverse=True):
            raise ValueError(
                "Thresholds must be in descending order: "
                f"identical >= minor >= major >= significant. Got: {thresholds}"
            )

    def classify(self, score: float) -> str:
        """
        Classify a similarity score into a change category.

        Args:
            score: Similarity score between 0.0 and 1.0

        Returns:
            Change type string

        Example:
            >>> policy = SimilarityMatchPolicy()
            >>> policy.classify(0.96)
            'identical'
            >>> policy.classify(0.87)
            'minor_modification'
            >>> policy.classify(0.75)
            'major_modification'
            >>> policy.classify(0.50)
            'significant_change'
            >>> policy.classify(0.30)
            'new_content'
        """
        if score >= self.identical_threshold:
            return "identical"
        elif score >= self.minor_modification_threshold:
            return "minor_modification"
        elif score >= self.major_modification_threshold:
            return "major_modification"
        elif score >= self.significant_change_threshold:
            return "significant_change"
        else:
            return "new_content"

    def classify_detailed(
        self, score: float, extra_details: Dict[str, Any] = None
    ) -> ChangeClassification:
        """
        Classify a score and return detailed classification object.

        Args:
            score: Similarity score between 0.0 and 1.0
            extra_details: Optional additional context to include in details

        Returns:
            ChangeClassification with type, score, and details

        Example:
            >>> policy = SimilarityMatchPolicy()
            >>> result = policy.classify_detailed(
            ...     0.87,
            ...     extra_details={"algorithm": "hybrid", "breakdown": {...}}
            ... )
            >>> result.change_type
            'minor_modification'
            >>> result.score
            0.87
            >>> 'algorithm' in result.details
            True
        """
        change_type = self.classify(score)
        validate_change_type(change_type)  # Validate before creating
        details = {
            "threshold_used": self._get_threshold_for_type(change_type),
            **(extra_details or {}),
        }
        return ChangeClassification(change_type, score, details)

    def _get_threshold_for_type(self, change_type: str) -> float:
        """Get the threshold value that corresponds to a change type."""
        mapping = {
            "identical": self.identical_threshold,
            "minor_modification": self.minor_modification_threshold,
            "major_modification": self.major_modification_threshold,
            "significant_change": self.significant_change_threshold,
            "new_content": 0.0,
        }
        return mapping.get(change_type, 0.0)


@dataclass
class FAQSimilarityConfig:
    """
    Configuration for FAQ-specific similarity calculations.

    This domain object encapsulates the FAQ business domain knowledge
    about how similarity should be calculated. It centralizes configuration
    that was previously scattered across factory methods.

    Attributes:
        preserve_punctuation: Keep punctuation for number/date detection (True for FAQs)
        preserve_case: Keep case sensitivity (False for FAQs - case-insensitive)
        min_token_length: Minimum token length to consider (1 for FAQs - keep all)
        jaccard_weight: Weight for Jaccard algorithm in hybrid (0.40 typical)
        difflib_weight: Weight for Difflib algorithm in hybrid (0.60 typical)
        bm25_weight: Weight for BM25 algorithm in hybrid (0.0 to disable)
        early_exit_threshold: Jaccard threshold for early exit optimization (0.3 typical)

    Business Rules:
        - Weights must sum to 1.0 (within 0.01 tolerance)
        - Weights must be non-negative
        - For FAQ modifications, preserve_punctuation=True to detect "10" → "12"
        - For FAQ modifications, difflib_weight should be higher (better for small changes)

    Example:
        >>> config = FAQSimilarityConfig()
        >>> config.preserve_punctuation
        True
        >>> config.jaccard_weight + config.difflib_weight
        1.0
        >>>
        >>> # Custom config
        >>> custom = FAQSimilarityConfig(
        ...     jaccard_weight=0.5,
        ...     difflib_weight=0.5,
        ...     early_exit_threshold=0.0  # Disable early exit
        ... )
    """

    preserve_punctuation: bool = True
    preserve_case: bool = False
    min_token_length: int = 1
    jaccard_weight: float = 0.40
    difflib_weight: float = 0.60
    bm25_weight: float = 0.0
    early_exit_threshold: float = 0.3

    def __post_init__(self):
        """Validate configuration business rules."""
        # Validate weights sum to 1.0 (within tolerance)
        total_weight = self.jaccard_weight + self.difflib_weight + self.bm25_weight
        if not (0.99 <= total_weight <= 1.01):
            raise ValueError(
                f"Algorithm weights must sum to 1.0 (within 0.01 tolerance), "
                f"got {total_weight}. Weights: jaccard={self.jaccard_weight}, "
                f"difflib={self.difflib_weight}, bm25={self.bm25_weight}"
            )

        # Validate weights are non-negative
        if self.jaccard_weight < 0 or self.difflib_weight < 0 or self.bm25_weight < 0:
            raise ValueError("All weights must be non-negative")

        # Validate early exit threshold
        if not (0.0 <= self.early_exit_threshold <= 1.0):
            raise ValueError(
                f"early_exit_threshold must be between 0.0 and 1.0, "
                f"got {self.early_exit_threshold}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary for serialization."""
        return {
            "preserve_punctuation": self.preserve_punctuation,
            "preserve_case": self.preserve_case,
            "min_token_length": self.min_token_length,
            "jaccard_weight": self.jaccard_weight,
            "difflib_weight": self.difflib_weight,
            "bm25_weight": self.bm25_weight,
            "early_exit_threshold": self.early_exit_threshold,
        }


# Default FAQ configuration constant
DEFAULT_FAQ_CONFIG = FAQSimilarityConfig(
    preserve_punctuation=True,  # Keep numbers and dates intact
    preserve_case=False,  # Case-insensitive comparison
    min_token_length=1,  # Keep all tokens
    jaccard_weight=0.40,  # Set-based similarity
    difflib_weight=0.60,  # Sequence-based similarity (better for small changes)
    bm25_weight=0.0,  # Disabled for simplicity
    early_exit_threshold=0.3,  # Skip expensive calculations if Jaccard < 0.3
)


# Convenience exports
__all__ = [
    "SimilarityResult",
    "SimilarityThreshold",
    "ChangeClassification",
    "SimilarityMatchPolicy",
    "FAQSimilarityConfig",
    "DEFAULT_FAQ_CONFIG",
]
