"""Tests for detection module."""
