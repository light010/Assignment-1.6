"""
Unit tests for DiffGenerator service.

Tests the diff generation logic extracted from ChecksumChangeDetector,
ensuring exception safety and proper integration with DifflibSimilarityCalculator.
"""

import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, r"c:\Users\praka\projects\FAQ_combined\faq_update")

from detection.services.diff_generator import DiffGenerator
from similarity.difflib_sim import DifflibSimilarityCalculator


class TestDiffGeneratorInit(unittest.TestCase):
    """Test DiffGenerator initialization."""

    def test_init_valid_context_lines(self):
        """Test initialization with valid context lines."""
        calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(calc, context_lines=3)
        self.assertEqual(generator.context_lines, 3)
        self.assertIs(generator.diff_calculator, calc)

    def test_init_zero_context_lines(self):
        """Test initialization with 0 context lines (valid)."""
        calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(calc, context_lines=0)
        self.assertEqual(generator.context_lines, 0)

    def test_init_large_context_lines(self):
        """Test initialization with large context lines."""
        calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(calc, context_lines=100)
        self.assertEqual(generator.context_lines, 100)

    def test_init_invalid_negative_context_lines(self):
        """Test initialization fails with negative context lines."""
        calc = Mock(spec=DifflibSimilarityCalculator)
        with self.assertRaises(ValueError) as cm:
            DiffGenerator(calc, context_lines=-1)
        self.assertIn("context_lines must be non-negative", str(cm.exception))

    def test_init_default_context_lines(self):
        """Test default context_lines is 3."""
        calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(calc)
        self.assertEqual(generator.context_lines, 3)


class TestDiffGeneratorGenerateLLMDiff(unittest.TestCase):
    """Test generate_llm_diff() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.calc = Mock(spec=DifflibSimilarityCalculator)
        self.generator = DiffGenerator(self.calc, context_lines=3)

    def test_generate_llm_diff_success(self):
        """Test successful diff generation."""
        # Setup
        old_text = "How do I reset my password?"
        new_text = "How do I reset my password and username?"
        expected_diff = '{"changes": ["added username"], "context": []}'

        self.calc.get_llm_friendly_diff_json.return_value = expected_diff

        # Execute
        result = self.generator.generate_llm_diff(old_text, new_text)

        # Verify
        self.assertEqual(result, expected_diff)
        self.calc.get_llm_friendly_diff_json.assert_called_once_with(
            text1=old_text,
            text2=new_text,
            context_lines=3,
            show_inline_changes=True,
        )

    def test_generate_llm_diff_with_show_inline_changes_false(self):
        """Test diff generation with show_inline_changes=False."""
        old_text = "Old text"
        new_text = "New text"
        expected_diff = '{"changes": []}'

        self.calc.get_llm_friendly_diff_json.return_value = expected_diff

        result = self.generator.generate_llm_diff(
            old_text, new_text, show_inline_changes=False
        )

        self.assertEqual(result, expected_diff)
        self.calc.get_llm_friendly_diff_json.assert_called_once_with(
            text1=old_text,
            text2=new_text,
            context_lines=3,
            show_inline_changes=False,
        )

    def test_generate_llm_diff_empty_strings(self):
        """Test diff generation with empty strings (valid input)."""
        self.calc.get_llm_friendly_diff_json.return_value = '{"changes": []}'

        result = self.generator.generate_llm_diff("", "")

        self.assertIsNotNone(result)
        self.calc.get_llm_friendly_diff_json.assert_called_once()

    def test_generate_llm_diff_identical_texts(self):
        """Test diff generation with identical texts."""
        text = "Same text"
        self.calc.get_llm_friendly_diff_json.return_value = '{"changes": []}'

        result = self.generator.generate_llm_diff(text, text)

        self.assertIsNotNone(result)

    def test_generate_llm_diff_exception_returns_none(self):
        """Test that exceptions are caught and None is returned."""
        # Setup
        self.calc.get_llm_friendly_diff_json.side_effect = Exception(
            "Diff calculation failed"
        )

        # Execute with logging captured
        with patch("detection.services.diff_generator.logger") as mock_logger:
            result = self.generator.generate_llm_diff("old", "new")

        # Verify
        self.assertIsNone(result)
        mock_logger.warning.assert_called_once()
        warning_msg = mock_logger.warning.call_args[0][0]
        self.assertIn("Failed to generate LLM diff", warning_msg)
        self.assertIn("Diff calculation failed", warning_msg)

    def test_generate_llm_diff_value_error_returns_none(self):
        """Test that ValueError is caught and None is returned."""
        self.calc.get_llm_friendly_diff_json.side_effect = ValueError("Invalid input")

        with patch("detection.services.diff_generator.logger") as mock_logger:
            result = self.generator.generate_llm_diff("old", "new")

        self.assertIsNone(result)
        mock_logger.warning.assert_called_once()

    def test_generate_llm_diff_runtime_error_returns_none(self):
        """Test that RuntimeError is caught and None is returned."""
        self.calc.get_llm_friendly_diff_json.side_effect = RuntimeError(
            "Runtime error"
        )

        with patch("detection.services.diff_generator.logger") as mock_logger:
            result = self.generator.generate_llm_diff("old", "new")

        self.assertIsNone(result)
        mock_logger.warning.assert_called_once()

    def test_generate_llm_diff_uses_correct_context_lines(self):
        """Test that configured context_lines is used."""
        # Generator with 5 context lines
        generator = DiffGenerator(self.calc, context_lines=5)
        self.calc.get_llm_friendly_diff_json.return_value = "{}"

        generator.generate_llm_diff("old", "new")

        # Verify context_lines=5 was passed
        call_args = self.calc.get_llm_friendly_diff_json.call_args
        self.assertEqual(call_args[1]["context_lines"], 5)


class TestDiffGeneratorGenerateLLMDiffWithChecksum(unittest.TestCase):
    """Test generate_llm_diff_with_checksum() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.calc = Mock(spec=DifflibSimilarityCalculator)
        self.generator = DiffGenerator(self.calc, context_lines=3)

    def test_generate_llm_diff_with_checksum_success(self):
        """Test successful diff generation with checksum context."""
        old_text = "Old content"
        new_text = "New content"
        old_checksum = "abc123def456"
        new_checksum = "xyz789uvw012"
        expected_diff = '{"changes": []}'

        self.calc.get_llm_friendly_diff_json.return_value = expected_diff

        result = self.generator.generate_llm_diff_with_checksum(
            old_text, new_text, old_checksum, new_checksum
        )

        self.assertEqual(result, expected_diff)
        self.calc.get_llm_friendly_diff_json.assert_called_once_with(
            text1=old_text,
            text2=new_text,
            context_lines=3,
            show_inline_changes=True,
        )

    def test_generate_llm_diff_with_checksum_exception_logs_checksums(self):
        """Test that exception logs include truncated checksums."""
        old_checksum = "abc123def456ghi789"
        new_checksum = "xyz789uvw012rst345"

        self.calc.get_llm_friendly_diff_json.side_effect = Exception("Failed")

        with patch("detection.services.diff_generator.logger") as mock_logger:
            result = self.generator.generate_llm_diff_with_checksum(
                "old", "new", old_checksum, new_checksum
            )

        self.assertIsNone(result)
        mock_logger.warning.assert_called_once()
        warning_msg = mock_logger.warning.call_args[0][0]

        # Should include truncated checksums (8 chars from CHECKSUM_DISPLAY_LENGTH)
        self.assertIn("abc123de", warning_msg)  # First 8 chars of old
        self.assertIn("xyz789uv", warning_msg)  # First 8 chars of new
        self.assertIn("Failed", warning_msg)

    def test_generate_llm_diff_with_checksum_show_inline_changes_false(self):
        """Test with show_inline_changes=False."""
        self.calc.get_llm_friendly_diff_json.return_value = "{}"

        result = self.generator.generate_llm_diff_with_checksum(
            "old", "new", "abc123", "xyz789", show_inline_changes=False
        )

        self.assertIsNotNone(result)
        call_args = self.calc.get_llm_friendly_diff_json.call_args
        self.assertEqual(call_args[1]["show_inline_changes"], False)

    def test_generate_llm_diff_with_checksum_short_checksums(self):
        """Test with checksums shorter than CHECKSUM_DISPLAY_LENGTH."""
        old_checksum = "abc"
        new_checksum = "xyz"

        self.calc.get_llm_friendly_diff_json.side_effect = Exception("Failed")

        with patch("detection.services.diff_generator.logger") as mock_logger:
            self.generator.generate_llm_diff_with_checksum(
                "old", "new", old_checksum, new_checksum
            )

        warning_msg = mock_logger.warning.call_args[0][0]
        # Should not crash with short checksums
        self.assertIn("abc", warning_msg)
        self.assertIn("xyz", warning_msg)


class TestDiffGeneratorIntegration(unittest.TestCase):
    """Integration tests with real DifflibSimilarityCalculator (if feasible)."""

    def test_integration_with_real_calculator(self):
        """Test with actual DifflibSimilarityCalculator."""
        # Create real calculator
        calc = DifflibSimilarityCalculator(
            autojunk=True,
            use_quick_ratio=False,
            lowercase=True,
            remove_punctuation=False,
        )

        generator = DiffGenerator(calc, context_lines=1)

        old_text = "How do I reset my password?"
        new_text = "How do I reset my password and username?"

        # Execute
        result = generator.generate_llm_diff(old_text, new_text)

        # Verify
        self.assertIsNotNone(result)
        self.assertIsInstance(result, str)
        # Should be valid JSON-like string
        self.assertTrue(len(result) > 0)

    def test_integration_exception_handling(self):
        """Test exception handling with real calculator."""
        calc = DifflibSimilarityCalculator()
        generator = DiffGenerator(calc, context_lines=1)

        # This should work fine (no exception)
        result = generator.generate_llm_diff("test", "test2")
        self.assertIsNotNone(result)


if __name__ == "__main__":
    unittest.main()
