"""
Unit tests for EdgeCaseAnalyzer service.

Tests the edge case detection logic extracted from ChecksumChangeDetector,
ensuring content splits are detected and logged correctly.
"""

import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, r"c:\Users\praka\projects\FAQ_combined\faq_update")

from detection.services.edge_case_analyzer import EdgeCaseAnalyzer, EdgeCaseReport


class TestEdgeCaseAnalyzerInit(unittest.TestCase):
    """Test EdgeCaseAnalyzer initialization."""

    def test_init_default_display_length(self):
        """Test initialization with default display length."""
        analyzer = EdgeCaseAnalyzer()
        self.assertEqual(analyzer.display_len, 8)

    def test_init_custom_display_length(self):
        """Test initialization with custom display length."""
        analyzer = EdgeCaseAnalyzer(checksum_display_length=12)
        self.assertEqual(analyzer.display_len, 12)

    def test_init_zero_display_length(self):
        """Test initialization with 0 display length (edge case)."""
        analyzer = EdgeCaseAnalyzer(checksum_display_length=0)
        self.assertEqual(analyzer.display_len, 0)


class TestEdgeCaseReportDataclass(unittest.TestCase):
    """Test EdgeCaseReport dataclass."""

    def test_edge_case_report_empty(self):
        """Test creating empty EdgeCaseReport."""
        report = EdgeCaseReport()
        self.assertEqual(report.content_splits, [])

    def test_edge_case_report_with_splits(self):
        """Test creating EdgeCaseReport with content splits."""
        splits = [
            ("old_abc123", [("new_def456", 0.85), ("new_ghi789", 0.82)]),
            ("old_xyz999", [("new_uvw000", 0.90), ("new_rst111", 0.88)]),
        ]
        report = EdgeCaseReport(content_splits=splits)
        self.assertEqual(len(report.content_splits), 2)
        self.assertEqual(report.content_splits[0][0], "old_abc123")
        self.assertEqual(len(report.content_splits[0][1]), 2)


class TestDetectContentSplits(unittest.TestCase):
    """Test detect_content_splits() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.analyzer = EdgeCaseAnalyzer(checksum_display_length=8)

    def test_detect_content_splits_no_splits(self):
        """Test when there are no splits (each old matches at most 1 new)."""
        deleted_matched = {
            "old_abc123": [("new_def456", 0.85)],
            "old_xyz789": [("new_uvw012", 0.90)],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            splits = self.analyzer.detect_content_splits(deleted_matched)

        # No splits should be detected
        self.assertEqual(splits, [])
        # No warnings should be logged
        mock_logger.warning.assert_not_called()

    def test_detect_content_splits_empty_input(self):
        """Test with empty deleted_matched."""
        deleted_matched = {}

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            splits = self.analyzer.detect_content_splits(deleted_matched)

        self.assertEqual(splits, [])
        mock_logger.warning.assert_not_called()

    def test_detect_content_splits_single_split(self):
        """Test detecting a single content split (1 old → 2 new)."""
        deleted_matched = {
            "old_abc123def456": [
                ("new_ghi789jkl012", 0.85),
                ("new_mno345pqr678", 0.82),
            ],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            splits = self.analyzer.detect_content_splits(deleted_matched)

        # One split should be detected
        self.assertEqual(len(splits), 1)
        self.assertEqual(splits[0][0], "old_abc123def456")
        self.assertEqual(len(splits[0][1]), 2)

        # Should log warning 3 times (1 for detection, 2 for details)
        self.assertEqual(mock_logger.warning.call_count, 3)

        # Verify warning messages
        warnings = [call[0][0] for call in mock_logger.warning.call_args_list]

        # First warning: detection message
        self.assertIn("Content SPLIT detected", warnings[0])
        self.assertIn("old_abc1", warnings[0])  # Truncated to 8 chars
        self.assertIn("2 new checksums", warnings[0])

        # Second warning: new checksums
        self.assertIn("New checksums", warnings[1])
        self.assertIn("new_ghi7", warnings[1])  # Truncated
        self.assertIn("new_mno3", warnings[1])  # Truncated

        # Third warning: similarity scores
        self.assertIn("Similarity scores", warnings[2])
        self.assertIn("0.850", warnings[2])
        self.assertIn("0.820", warnings[2])

    def test_detect_content_splits_multiple_splits(self):
        """Test detecting multiple content splits."""
        deleted_matched = {
            "old_abc123": [("new_def456", 0.85), ("new_ghi789", 0.82)],
            "old_xyz999": [
                ("new_uvw000", 0.90),
                ("new_rst111", 0.88),
                ("new_opq222", 0.81),
            ],
            "old_normal": [("new_normal", 0.95)],  # Not a split
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            splits = self.analyzer.detect_content_splits(deleted_matched)

        # Two splits should be detected
        self.assertEqual(len(splits), 2)

        # First split: old_abc123 → 2 new
        split1 = next(s for s in splits if s[0] == "old_abc123")
        self.assertEqual(len(split1[1]), 2)

        # Second split: old_xyz999 → 3 new
        split2 = next(s for s in splits if s[0] == "old_xyz999")
        self.assertEqual(len(split2[1]), 3)

        # Should log warnings for both splits (3 lines each = 6 total)
        self.assertEqual(mock_logger.warning.call_count, 6)

    def test_detect_content_splits_large_split(self):
        """Test detecting a large split (1 old → many new)."""
        deleted_matched = {
            "old_large": [
                ("new_1", 0.90),
                ("new_2", 0.89),
                ("new_3", 0.88),
                ("new_4", 0.87),
                ("new_5", 0.86),
            ],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            splits = self.analyzer.detect_content_splits(deleted_matched)

        self.assertEqual(len(splits), 1)
        self.assertEqual(len(splits[0][1]), 5)

        # Verify detection message mentions 5 new checksums
        first_warning = mock_logger.warning.call_args_list[0][0][0]
        self.assertIn("5 new checksums", first_warning)

    def test_detect_content_splits_checksum_truncation(self):
        """Test that checksums are truncated correctly."""
        analyzer = EdgeCaseAnalyzer(checksum_display_length=5)  # Custom length

        deleted_matched = {
            "old_verylongchecksum12345": [
                ("new_verylongchecksum67890", 0.85),
                ("new_verylongchecksum11111", 0.82),
            ],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            analyzer.detect_content_splits(deleted_matched)

        # Check first warning for truncation to 5 chars
        first_warning = mock_logger.warning.call_args_list[0][0][0]
        self.assertIn("old_v", first_warning)  # First 5 chars

        # Check second warning (new checksums)
        second_warning = mock_logger.warning.call_args_list[1][0][0]
        self.assertIn("new_v", second_warning)

    def test_detect_content_splits_score_formatting(self):
        """Test that similarity scores are formatted to 3 decimal places."""
        deleted_matched = {
            "old_abc": [
                ("new_def", 0.8547),  # Should be formatted as 0.855
                ("new_ghi", 0.8213),  # Should be formatted as 0.821
            ],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            self.analyzer.detect_content_splits(deleted_matched)

        # Check third warning (similarity scores)
        third_warning = mock_logger.warning.call_args_list[2][0][0]
        self.assertIn("0.855", third_warning)
        self.assertIn("0.821", third_warning)

    def test_detect_content_splits_preserves_order(self):
        """Test that splits preserve the order of matches."""
        deleted_matched = {
            "old_abc": [
                ("new_first", 0.90),
                ("new_second", 0.85),
                ("new_third", 0.80),
            ],
        }

        splits = self.analyzer.detect_content_splits(deleted_matched)

        # Check order is preserved
        self.assertEqual(splits[0][1][0][0], "new_first")
        self.assertEqual(splits[0][1][1][0], "new_second")
        self.assertEqual(splits[0][1][2][0], "new_third")


class TestDetectContentMerges(unittest.TestCase):
    """Test detect_content_merges() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.analyzer = EdgeCaseAnalyzer()

    def test_detect_content_merges_placeholder(self):
        """Test detect_content_merges (currently returns empty list)."""
        new_matched = {
            "new_abc123": ("old_def456", 0.85),
            "new_xyz789": ("old_uvw012", 0.90),
        }

        merges = self.analyzer.detect_content_merges(new_matched)

        # Currently returns empty list (future enhancement)
        self.assertEqual(merges, [])

    def test_detect_content_merges_empty_input(self):
        """Test with empty new_matched."""
        merges = self.analyzer.detect_content_merges({})
        self.assertEqual(merges, [])


class TestAnalyzeMatches(unittest.TestCase):
    """Test analyze_matches() comprehensive method."""

    def setUp(self):
        """Set up test fixtures."""
        self.analyzer = EdgeCaseAnalyzer()

    def test_analyze_matches_no_edge_cases(self):
        """Test when there are no edge cases."""
        deleted_matched = {
            "old_abc": [("new_def", 0.85)],
            "old_xyz": [("new_uvw", 0.90)],
        }
        new_matched = {
            "new_def": ("old_abc", 0.85),
            "new_uvw": ("old_xyz", 0.90),
        }

        with patch("detection.services.edge_case_analyzer.logger"):
            report = self.analyzer.analyze_matches(deleted_matched, new_matched)

        self.assertIsInstance(report, EdgeCaseReport)
        self.assertEqual(report.content_splits, [])

    def test_analyze_matches_with_splits(self):
        """Test when there are content splits."""
        deleted_matched = {
            "old_abc": [("new_def", 0.85), ("new_ghi", 0.82)],
        }
        new_matched = {
            "new_def": ("old_abc", 0.85),
            "new_ghi": ("old_abc", 0.82),
        }

        with patch("detection.services.edge_case_analyzer.logger"):
            report = self.analyzer.analyze_matches(deleted_matched, new_matched)

        self.assertEqual(len(report.content_splits), 1)

    def test_analyze_matches_empty_inputs(self):
        """Test with empty inputs."""
        report = self.analyzer.analyze_matches({}, {})

        self.assertIsInstance(report, EdgeCaseReport)
        self.assertEqual(report.content_splits, [])

    def test_analyze_matches_returns_edge_case_report(self):
        """Test that analyze_matches returns EdgeCaseReport instance."""
        report = self.analyzer.analyze_matches({}, {})
        self.assertIsInstance(report, EdgeCaseReport)
        self.assertTrue(hasattr(report, "content_splits"))


class TestEdgeCaseAnalyzerLogging(unittest.TestCase):
    """Test logging behavior in detail."""

    def test_logging_format_matches_original(self):
        """Test that logging format matches the original implementation."""
        analyzer = EdgeCaseAnalyzer(checksum_display_length=8)

        deleted_matched = {
            "old_abc123def456": [
                ("new_ghi789jkl012", 0.850),
                ("new_mno345pqr678", 0.820),
            ],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            analyzer.detect_content_splits(deleted_matched)

        # Verify exact warning emoji and format
        warnings = [call[0][0] for call in mock_logger.warning.call_args_list]

        # First warning should start with emoji
        self.assertTrue(warnings[0].startswith("⚠️"))
        self.assertIn("Content SPLIT detected:", warnings[0])

        # Second warning should have spacing
        self.assertTrue(warnings[1].startswith("   "))
        self.assertIn("New checksums:", warnings[1])

        # Third warning should have spacing
        self.assertTrue(warnings[2].startswith("   "))
        self.assertIn("Similarity scores:", warnings[2])

    def test_logging_uses_warning_level(self):
        """Test that warning level is used (not info or error)."""
        analyzer = EdgeCaseAnalyzer()

        deleted_matched = {
            "old_abc": [("new_def", 0.85), ("new_ghi", 0.82)],
        }

        with patch("detection.services.edge_case_analyzer.logger") as mock_logger:
            analyzer.detect_content_splits(deleted_matched)

        # Verify warning() was called, not info() or error()
        self.assertTrue(mock_logger.warning.called)
        self.assertFalse(mock_logger.info.called)
        self.assertFalse(mock_logger.error.called)


if __name__ == "__main__":
    unittest.main()
