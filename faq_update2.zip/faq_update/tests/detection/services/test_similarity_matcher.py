"""
Unit tests for SimilarityMatcher service.

Tests the similarity matching logic extracted from ChecksumChangeDetector,
ensuring greedy matching, threshold logic, and exception handling work correctly.
"""

import sys
import unittest
from unittest.mock import Mock, MagicMock

sys.path.insert(0, r"c:\Users\praka\projects\FAQ_combined\faq_update")

from detection.services.similarity_matcher import SimilarityMatcher, MatchResult
from core.models.similarity import SimilarityResult


class TestSimilarityMatcherInit(unittest.TestCase):
    """Test SimilarityMatcher initialization."""

    def test_init_valid_threshold(self):
        """Test initialization with valid threshold."""
        calc = Mock()
        matcher = SimilarityMatcher(calc, threshold=0.8)
        self.assertEqual(matcher.threshold, 0.8)
        self.assertIs(matcher.calculator, calc)

    def test_init_threshold_at_boundaries(self):
        """Test initialization with boundary thresholds (0.0 and 1.0)."""
        calc = Mock()

        # Lower boundary
        matcher1 = SimilarityMatcher(calc, threshold=0.0)
        self.assertEqual(matcher1.threshold, 0.0)

        # Upper boundary
        matcher2 = SimilarityMatcher(calc, threshold=1.0)
        self.assertEqual(matcher2.threshold, 1.0)

    def test_init_invalid_threshold_too_low(self):
        """Test initialization fails with threshold < 0."""
        calc = Mock()
        with self.assertRaises(ValueError) as cm:
            SimilarityMatcher(calc, threshold=-0.1)
        self.assertIn("threshold must be between 0.0 and 1.0", str(cm.exception))

    def test_init_invalid_threshold_too_high(self):
        """Test initialization fails with threshold > 1.0."""
        calc = Mock()
        with self.assertRaises(ValueError) as cm:
            SimilarityMatcher(calc, threshold=1.1)
        self.assertIn("threshold must be between 0.0 and 1.0", str(cm.exception))


class TestSimilarityMatcherFindMatches(unittest.TestCase):
    """Test find_matches() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.calc = Mock()
        self.matcher = SimilarityMatcher(self.calc, threshold=0.8)

    def test_find_matches_perfect_match(self):
        """Test finding a perfect match (score = 1.0)."""
        # Setup
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Hello World", "page_num": 1}}
        previous_data = {"old1": {"content_text": "Hello World", "page_number": 1}}

        # Mock similarity calculator - create object with .score attribute
        mock_result = Mock()
        mock_result.score = 1.0
        self.calc.compute_similarity.return_value = mock_result

        # Execute
        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Verify
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].new_checksum, "new1")
        self.assertEqual(results[0].best_match_checksum, "old1")
        self.assertEqual(results[0].best_score, 1.0)
        self.assertTrue(results[0].is_match)

    def test_find_matches_above_threshold(self):
        """Test match above threshold (score = 0.85 >= 0.8)."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Hello", "page_num": 1}}
        previous_data = {"old1": {"content_text": "Hello!", "page_number": 1}}

        mock_result = Mock()
        mock_result.score = 0.85
        self.calc.compute_similarity.return_value = mock_result

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.85)

    def test_find_matches_at_threshold(self):
        """Test match exactly at threshold (score = 0.8 >= 0.8) - inclusive."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Test", "page_num": 1}}
        previous_data = {"old1": {"content_text": "Test!", "page_number": 1}}

        mock_result = Mock()
        mock_result.score = 0.8
        self.calc.compute_similarity.return_value = mock_result

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # CRITICAL: threshold check is inclusive (>=, not >)
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.8)

    def test_find_matches_below_threshold(self):
        """Test no match below threshold (score = 0.79 < 0.8)."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Different", "page_num": 1}}
        previous_data = {"old1": {"content_text": "Content", "page_number": 1}}

        mock_result = Mock()
        mock_result.score = 0.79
        self.calc.compute_similarity.return_value = mock_result

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.79)
        # Note: best_match_checksum is set (best match found), but is_match=False (below threshold)
        self.assertEqual(results[0].best_match_checksum, "old1")

    def test_find_matches_greedy_best_match(self):
        """Test greedy algorithm selects highest score."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1", "old2", "old3"}
        current_data = {"new1": {"text": "Content", "page_num": 1}}
        previous_data = {
            "old1": {"content_text": "Content A", "page_number": 1},
            "old2": {"content_text": "Content B", "page_number": 2},
            "old3": {"content_text": "Content C", "page_number": 3},
        }

        # Mock: return different score based on which checksum is compared
        def mock_similarity(text1, text2):
            mock = Mock()
            if "Content A" in text2:
                mock.score = 0.7
            elif "Content B" in text2:
                mock.score = 0.9  # Highest!
            else:  # Content C
                mock.score = 0.75
            return mock

        self.calc.compute_similarity.side_effect = mock_similarity

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Should select the one with highest score (0.9), regardless of iteration order
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.9)
        self.assertEqual(results[0].best_match_checksum, "old2")

    def test_find_matches_multiple_new_checksums(self):
        """Test matching multiple new checksums."""
        new_checksums = {"new1", "new2", "new3"}
        deleted_checksums = {"old1", "old2"}
        current_data = {
            "new1": {"text": "A", "page_num": 1},
            "new2": {"text": "B", "page_num": 2},
            "new3": {"text": "C", "page_num": 3},
        }
        previous_data = {
            "old1": {"content_text": "A", "page_number": 1},
            "old2": {"content_text": "B", "page_number": 2},
        }

        # Mock: return score based on content similarity
        def mock_similarity(text1, text2):
            mock = Mock()
            # High similarity for exact matches
            if text1 == text2:
                mock.score = 0.9
            # Low similarity for different content
            else:
                mock.score = 0.5
            return mock

        self.calc.compute_similarity.side_effect = mock_similarity

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Should return 3 results (one per new checksum)
        self.assertEqual(len(results), 3)

        # Build map
        matches = {r.new_checksum: r for r in results}

        # new1 matches old1 (A == A, score 0.9 >= 0.8)
        self.assertTrue(matches["new1"].is_match)
        self.assertEqual(matches["new1"].best_score, 0.9)

        # new2 matches old2 (B == B, score 0.9 >= 0.8)
        self.assertTrue(matches["new2"].is_match)
        self.assertEqual(matches["new2"].best_score, 0.9)

        # new3 has no good match (C != A/B, score 0.5 < 0.8)
        self.assertFalse(matches["new3"].is_match)
        self.assertEqual(matches["new3"].best_score, 0.5)

    def test_find_matches_missing_new_text(self):
        """Test handling of missing text in current data."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"page_num": 1}}  # No 'text' field!
        previous_data = {"old1": {"content_text": "Content", "page_number": 1}}

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Should return no-match result
        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].is_match)
        self.assertIsNone(results[0].best_match_checksum)
        self.assertEqual(results[0].best_score, 0.0)

    def test_find_matches_missing_deleted_text(self):
        """Test handling of missing text in previous data."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Content", "page_num": 1}}
        previous_data = {"old1": {"page_number": 1}}  # No 'content_text' field!

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Should return no-match result (no comparison possible)
        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.0)

    def test_find_matches_empty_sets(self):
        """Test with empty checksum sets."""
        current_data = {}
        previous_data = {}

        # Empty new checksums
        results = self.matcher.find_matches(set(), {"old1"}, current_data, previous_data)
        self.assertEqual(len(results), 0)

        # Empty deleted checksums
        results = self.matcher.find_matches({"new1"}, set(), {"new1": {"text": "A", "page_num": 1}}, previous_data)
        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].is_match)  # No deleted to match against

    def test_find_matches_calculator_exception(self):
        """Test handling of calculator exceptions."""
        new_checksums = {"new1"}
        deleted_checksums = {"old1"}
        current_data = {"new1": {"text": "Content", "page_num": 1}}
        previous_data = {"old1": {"content_text": "Content", "page_number": 1}}

        # Mock calculator raises exception
        self.calc.compute_similarity.side_effect = RuntimeError("Calculation failed")

        results = self.matcher.find_matches(
            new_checksums, deleted_checksums, current_data, previous_data
        )

        # Should handle gracefully and return no-match
        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].is_match)
        self.assertEqual(results[0].best_score, 0.0)


class TestMatchResultDataclass(unittest.TestCase):
    """Test MatchResult dataclass."""

    def test_match_result_creation(self):
        """Test creating MatchResult."""
        result = MatchResult(
            new_checksum="new1",
            best_match_checksum="old1",
            best_score=0.85,
            is_match=True,
        )

        self.assertEqual(result.new_checksum, "new1")
        self.assertEqual(result.best_match_checksum, "old1")
        self.assertEqual(result.best_score, 0.85)
        self.assertTrue(result.is_match)

    def test_match_result_no_match(self):
        """Test MatchResult for no match."""
        result = MatchResult(
            new_checksum="new1",
            best_match_checksum=None,
            best_score=0.0,
            is_match=False,
        )

        self.assertEqual(result.new_checksum, "new1")
        self.assertIsNone(result.best_match_checksum)
        self.assertEqual(result.best_score, 0.0)
        self.assertFalse(result.is_match)


if __name__ == "__main__":
    unittest.main()
