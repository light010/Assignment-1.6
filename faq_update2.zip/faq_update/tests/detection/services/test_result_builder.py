"""
Unit tests for DetectionResultBuilder service.

Tests the result construction logic extracted from ChecksumChangeDetector,
ensuring correct field mapping and validation for all change types.
"""

import sys
import unittest
from datetime import datetime

sys.path.insert(0, r"c:\Users\praka\projects\FAQ_combined\faq_update")

from detection.services.result_builder import DetectionResultBuilder
from detection.services.similarity_matcher import MatchResult
from core.models.detection import ChangeType, DetectionResult


class TestBuildModified(unittest.TestCase):
    """Test build_modified() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "handbook.pdf"

    def test_build_modified_basic(self):
        """Test building MODIFIED result with basic data."""
        match_result = MatchResult(
            new_checksum="new_abc123",
            best_match_checksum="old_xyz789",
            best_score=0.87,
            is_match=True,
        )

        current_data = {
            "new_abc123": {"text": "How do I reset my password?", "page_num": 42}
        }

        previous_data = {
            "old_xyz789": {
                "content_text": "How to reset password?",
                "page_number": 41,
            }
        }

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # Verify all fields
        self.assertIsInstance(result, DetectionResult)
        self.assertEqual(result.old_checksum, "old_xyz789")
        self.assertEqual(result.new_checksum, "new_abc123")
        self.assertEqual(result.change_type, ChangeType.MODIFIED_CONTENT)
        self.assertEqual(result.similarity_score, 0.87)
        self.assertEqual(result.file_name, "handbook.pdf")
        self.assertEqual(result.page_number, 42)  # From CURRENT data
        self.assertEqual(result.old_content, "How to reset password?")
        self.assertEqual(result.new_content, "How do I reset my password?")
        self.assertEqual(result.metadata, {})

    def test_build_modified_with_llm_diff(self):
        """Test building MODIFIED result with LLM diff."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        current_data = {"new_abc": {"text": "New text", "page_num": 1}}
        previous_data = {"old_xyz": {"content_text": "Old text", "page_number": 1}}

        llm_diff = '{"changes": ["text"], "additions": 1, "deletions": 1}'

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data, llm_diff=llm_diff
        )

        # Verify metadata contains llm_diff
        self.assertIn("llm_diff", result.metadata)
        self.assertEqual(result.metadata["llm_diff"], llm_diff)

    def test_build_modified_without_llm_diff(self):
        """Test building MODIFIED result without LLM diff (None)."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        current_data = {"new_abc": {"text": "New", "page_num": 1}}
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data, llm_diff=None
        )

        # metadata should be empty dict (no llm_diff key)
        self.assertEqual(result.metadata, {})

    def test_build_modified_empty_llm_diff_string(self):
        """Test with empty string llm_diff (should NOT be included)."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        current_data = {"new_abc": {"text": "New", "page_num": 1}}
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data, llm_diff=""
        )

        # Empty string is falsy, so metadata should be empty
        self.assertEqual(result.metadata, {})

    def test_build_modified_missing_text_fields(self):
        """Test with missing text fields (should return None)."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        # Missing 'text' and 'content_text' fields
        current_data = {"new_abc": {"page_num": 1}}
        previous_data = {"old_xyz": {"page_number": 1}}

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # Should return None for missing fields
        self.assertIsNone(result.new_content)
        self.assertIsNone(result.old_content)

    def test_build_modified_missing_page_fields(self):
        """Test with missing page fields (should return None)."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        # Missing page_num
        current_data = {"new_abc": {"text": "New"}}
        previous_data = {"old_xyz": {"content_text": "Old"}}

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # page_number should be None
        self.assertIsNone(result.page_number)

    def test_build_modified_uses_current_page_number(self):
        """Test that page_number comes from CURRENT data, not previous."""
        match_result = MatchResult(
            new_checksum="new_abc",
            best_match_checksum="old_xyz",
            best_score=0.85,
            is_match=True,
        )

        # Different page numbers
        current_data = {"new_abc": {"text": "New", "page_num": 99}}
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # Should use page_num from current (99), not previous (1)
        self.assertEqual(result.page_number, 99)


class TestBuildNew(unittest.TestCase):
    """Test build_new() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "handbook.pdf"

    def test_build_new_basic(self):
        """Test building NEW result with basic data."""
        new_checksum = "new_abc123"
        current_data = {
            "new_abc123": {"text": "Brand new FAQ", "page_num": 5}
        }

        result = self.builder.build_new(new_checksum, self.file_name, current_data)

        # Verify all fields
        self.assertIsInstance(result, DetectionResult)
        self.assertEqual(result.old_checksum, "")  # Empty for NEW
        self.assertEqual(result.new_checksum, "new_abc123")
        self.assertEqual(result.change_type, ChangeType.NEW_CONTENT)
        self.assertEqual(result.similarity_score, 0.0)  # No match
        self.assertEqual(result.file_name, "handbook.pdf")
        self.assertEqual(result.page_number, 5)
        self.assertIsNone(result.old_content)  # No old content
        self.assertEqual(result.new_content, "Brand new FAQ")
        self.assertEqual(result.metadata, {})

    def test_build_new_empty_old_checksum(self):
        """Test that old_checksum is empty string (required by DetectionResult)."""
        current_data = {"new_abc": {"text": "New", "page_num": 1}}

        result = self.builder.build_new("new_abc", self.file_name, current_data)

        # old_checksum MUST be empty string, not None
        self.assertEqual(result.old_checksum, "")
        self.assertIsInstance(result.old_checksum, str)

    def test_build_new_zero_similarity_score(self):
        """Test that similarity_score is 0.0 (semantic: no match)."""
        current_data = {"new_abc": {"text": "New", "page_num": 1}}

        result = self.builder.build_new("new_abc", self.file_name, current_data)

        self.assertEqual(result.similarity_score, 0.0)

    def test_build_new_missing_text_field(self):
        """Test with missing text field."""
        current_data = {"new_abc": {"page_num": 1}}

        result = self.builder.build_new("new_abc", self.file_name, current_data)

        self.assertIsNone(result.new_content)

    def test_build_new_missing_page_field(self):
        """Test with missing page_num field."""
        current_data = {"new_abc": {"text": "New"}}

        result = self.builder.build_new("new_abc", self.file_name, current_data)

        self.assertIsNone(result.page_number)


class TestBuildDeleted(unittest.TestCase):
    """Test build_deleted() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "handbook.pdf"

    def test_build_deleted_basic(self):
        """Test building DELETED result with basic data."""
        deleted_checksum = "old_xyz789"
        previous_data = {
            "old_xyz789": {"content_text": "Deleted FAQ", "page_number": 10}
        }

        result = self.builder.build_deleted(
            deleted_checksum, self.file_name, previous_data
        )

        # Verify all fields
        self.assertIsInstance(result, DetectionResult)
        self.assertEqual(result.old_checksum, "old_xyz789")
        self.assertEqual(result.new_checksum, "")  # Empty for DELETED
        self.assertEqual(result.change_type, ChangeType.DELETED_CONTENT)
        self.assertEqual(result.similarity_score, 0.0)  # No match
        self.assertEqual(result.file_name, "handbook.pdf")
        self.assertEqual(result.page_number, 10)  # From PREVIOUS data
        self.assertEqual(result.old_content, "Deleted FAQ")
        self.assertIsNone(result.new_content)  # No new content
        self.assertEqual(result.metadata, {})

    def test_build_deleted_empty_new_checksum(self):
        """Test that new_checksum is empty string (required by DetectionResult)."""
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        # new_checksum MUST be empty string, not None
        self.assertEqual(result.new_checksum, "")
        self.assertIsInstance(result.new_checksum, str)

    def test_build_deleted_zero_similarity_score(self):
        """Test that similarity_score is 0.0 (semantic: no match)."""
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        self.assertEqual(result.similarity_score, 0.0)

    def test_build_deleted_uses_previous_page_number(self):
        """Test that page_number comes from PREVIOUS data (old location)."""
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 42}}

        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        # Should use page_number from previous (42)
        self.assertEqual(result.page_number, 42)

    def test_build_deleted_missing_content_text_field(self):
        """Test with missing content_text field."""
        previous_data = {"old_xyz": {"page_number": 1}}

        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        self.assertIsNone(result.old_content)

    def test_build_deleted_missing_page_number_field(self):
        """Test with missing page_number field."""
        previous_data = {"old_xyz": {"content_text": "Old"}}

        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        self.assertIsNone(result.page_number)


class TestBuildUnchanged(unittest.TestCase):
    """Test build_unchanged() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "handbook.pdf"

    def test_build_unchanged_basic(self):
        """Test building UNCHANGED result with basic data."""
        unchanged_checksum = "same_abc123"
        current_data = {
            "same_abc123": {"text": "Unchanged FAQ", "page_num": 7}
        }

        result = self.builder.build_unchanged(
            unchanged_checksum, self.file_name, current_data
        )

        # Verify all fields
        self.assertIsInstance(result, DetectionResult)
        self.assertEqual(result.old_checksum, "same_abc123")
        self.assertEqual(result.new_checksum, "same_abc123")  # Same as old!
        self.assertEqual(result.change_type, ChangeType.UNCHANGED_CONTENT)
        self.assertEqual(result.similarity_score, 1.0)  # Perfect match
        self.assertEqual(result.file_name, "handbook.pdf")
        self.assertEqual(result.page_number, 7)
        self.assertIsNone(result.old_content)  # Optimization: don't load
        self.assertIsNone(result.new_content)  # Optimization: don't load
        self.assertEqual(result.metadata, {})

    def test_build_unchanged_checksums_equal(self):
        """Test that old_checksum equals new_checksum (required)."""
        current_data = {"same_abc": {"text": "Text", "page_num": 1}}

        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        # Both checksums must be equal
        self.assertEqual(result.old_checksum, result.new_checksum)
        self.assertEqual(result.old_checksum, "same_abc")

    def test_build_unchanged_perfect_similarity_score(self):
        """Test that similarity_score is 1.0 (perfect match)."""
        current_data = {"same_abc": {"text": "Text", "page_num": 1}}

        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        # Must be exactly 1.0
        self.assertEqual(result.similarity_score, 1.0)

    def test_build_unchanged_content_fields_none(self):
        """Test that content fields are None (optimization)."""
        current_data = {"same_abc": {"text": "Text", "page_num": 1}}

        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        # Both content fields should be None (not loaded)
        self.assertIsNone(result.old_content)
        self.assertIsNone(result.new_content)

    def test_build_unchanged_uses_current_page_number(self):
        """Test that page_number comes from CURRENT data."""
        current_data = {"same_abc": {"text": "Text", "page_num": 99}}

        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        # Should use page_num from current
        self.assertEqual(result.page_number, 99)

    def test_build_unchanged_missing_page_field(self):
        """Test with missing page_num field."""
        current_data = {"same_abc": {"text": "Text"}}

        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        self.assertIsNone(result.page_number)


class TestFieldMapping(unittest.TestCase):
    """Test field name mapping (text vs content_text, page_num vs page_number)."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "test.pdf"

    def test_current_data_uses_text_and_page_num(self):
        """Test that current_data uses 'text' and 'page_num' keys."""
        match_result = MatchResult("new_abc", "old_xyz", 0.85, True)

        current_data = {
            "new_abc": {
                "text": "Current text",  # NOT content_text
                "page_num": 1,  # NOT page_number
            }
        }

        previous_data = {
            "old_xyz": {
                "content_text": "Old text",
                "page_number": 1,
            }
        }

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # Verify text came from 'text' key
        self.assertEqual(result.new_content, "Current text")
        # Verify page came from 'page_num' key
        self.assertEqual(result.page_number, 1)

    def test_previous_data_uses_content_text_and_page_number(self):
        """Test that previous_data uses 'content_text' and 'page_number' keys."""
        match_result = MatchResult("new_abc", "old_xyz", 0.85, True)

        current_data = {
            "new_abc": {
                "text": "Current text",
                "page_num": 2,
            }
        }

        previous_data = {
            "old_xyz": {
                "content_text": "Previous text",  # NOT text
                "page_number": 1,  # NOT page_num
            }
        }

        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        # Verify text came from 'content_text' key
        self.assertEqual(result.old_content, "Previous text")
        # Note: page_number comes from current_data in MODIFIED


class TestDetectionResultValidation(unittest.TestCase):
    """Test that built results satisfy DetectionResult validation."""

    def setUp(self):
        """Set up test fixtures."""
        self.builder = DetectionResultBuilder()
        self.file_name = "test.pdf"

    def test_modified_result_validates(self):
        """Test that MODIFIED result passes DetectionResult validation."""
        match_result = MatchResult("new_abc", "old_xyz", 0.85, True)
        current_data = {"new_abc": {"text": "New", "page_num": 1}}
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        # Should not raise validation error
        result = self.builder.build_modified(
            match_result, self.file_name, current_data, previous_data
        )

        self.assertIsInstance(result, DetectionResult)

    def test_new_result_validates(self):
        """Test that NEW result passes DetectionResult validation."""
        current_data = {"new_abc": {"text": "New", "page_num": 1}}

        # Should not raise validation error
        result = self.builder.build_new("new_abc", self.file_name, current_data)

        self.assertIsInstance(result, DetectionResult)

    def test_deleted_result_validates(self):
        """Test that DELETED result passes DetectionResult validation."""
        previous_data = {"old_xyz": {"content_text": "Old", "page_number": 1}}

        # Should not raise validation error
        result = self.builder.build_deleted("old_xyz", self.file_name, previous_data)

        self.assertIsInstance(result, DetectionResult)

    def test_unchanged_result_validates(self):
        """Test that UNCHANGED result passes DetectionResult validation."""
        current_data = {"same_abc": {"text": "Same", "page_num": 1}}

        # Should not raise validation error
        result = self.builder.build_unchanged("same_abc", self.file_name, current_data)

        self.assertIsInstance(result, DetectionResult)


if __name__ == "__main__":
    unittest.main()
