"""Tests for detection services."""
