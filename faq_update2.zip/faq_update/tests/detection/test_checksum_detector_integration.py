"""
Integration tests for refactored ChecksumChangeDetector.

Tests the complete workflow including service composition, all change types,
factory methods, and backward compatibility.
"""

import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, r"c:\Users\praka\projects\FAQ_combined\faq_update")

from detection.checksum_detector import ChecksumChangeDetector
from detection.services.similarity_matcher import SimilarityMatcher
from detection.services.diff_generator import DiffGenerator
from detection.services.edge_case_analyzer import EdgeCaseAnalyzer
from detection.services.result_builder import DetectionResultBuilder
from core.models.detection import ChangeType, DetectionConfig, DetectionResult
from similarity.hybrid import HybridSimilarityCalculator
from similarity.difflib_sim import DifflibSimilarityCalculator


class TestChecksumDetectorBackwardCompatibility(unittest.TestCase):
    """Test backward compatibility with existing API."""

    def test_default_constructor_works(self):
        """Test that detector can be created with no arguments (backward compatible)."""
        detector = ChecksumChangeDetector()

        self.assertIsNotNone(detector)
        self.assertIsNotNone(detector.config)
        self.assertIsNotNone(detector.similarity_calculator)

    def test_constructor_with_calculator_only(self):
        """Test constructor with only similarity_calculator."""
        calc = HybridSimilarityCalculator.for_modification_detection()
        detector = ChecksumChangeDetector(similarity_calculator=calc)

        self.assertIs(detector.similarity_calculator, calc)
        self.assertIsNotNone(detector.config)

    def test_constructor_with_config_only(self):
        """Test constructor with only config."""
        config = DetectionConfig(
            checksum_algorithm="sha256",
            similarity_threshold=0.85,
            compute_llm_diffs=True,
            diff_context_lines=5,
        )
        detector = ChecksumChangeDetector(config=config)

        self.assertIs(detector.config, config)
        self.assertIsNotNone(detector.similarity_calculator)

    def test_constructor_with_calculator_and_config(self):
        """Test constructor with both calculator and config."""
        calc = HybridSimilarityCalculator.for_modification_detection()
        config = DetectionConfig(
            checksum_algorithm="sha256",
            similarity_threshold=0.85,
        )
        detector = ChecksumChangeDetector(similarity_calculator=calc, config=config)

        self.assertIs(detector.similarity_calculator, calc)
        self.assertIs(detector.config, config)


class TestChecksumDetectorServiceInjection(unittest.TestCase):
    """Test new service injection feature."""

    def test_inject_custom_similarity_matcher(self):
        """Test injecting custom SimilarityMatcher."""
        calc = Mock()
        matcher = SimilarityMatcher(calc, threshold=0.9)
        detector = ChecksumChangeDetector(similarity_matcher=matcher)

        self.assertIs(detector.matcher, matcher)

    def test_inject_custom_diff_generator(self):
        """Test injecting custom DiffGenerator."""
        diff_calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(diff_calc, context_lines=10)
        detector = ChecksumChangeDetector(diff_generator=generator)

        self.assertIs(detector.diff_generator, generator)

    def test_inject_custom_edge_case_analyzer(self):
        """Test injecting custom EdgeCaseAnalyzer."""
        analyzer = EdgeCaseAnalyzer(checksum_display_length=12)
        detector = ChecksumChangeDetector(edge_case_analyzer=analyzer)

        self.assertIs(detector.edge_analyzer, analyzer)

    def test_inject_custom_result_builder(self):
        """Test injecting custom DetectionResultBuilder."""
        builder = DetectionResultBuilder()
        detector = ChecksumChangeDetector(result_builder=builder)

        self.assertIs(detector.result_builder, builder)

    def test_inject_all_services(self):
        """Test injecting all services at once."""
        calc = Mock()
        matcher = SimilarityMatcher(calc, threshold=0.9)
        diff_calc = Mock(spec=DifflibSimilarityCalculator)
        generator = DiffGenerator(diff_calc)
        analyzer = EdgeCaseAnalyzer()
        builder = DetectionResultBuilder()

        detector = ChecksumChangeDetector(
            similarity_matcher=matcher,
            diff_generator=generator,
            edge_case_analyzer=analyzer,
            result_builder=builder,
        )

        self.assertIs(detector.matcher, matcher)
        self.assertIs(detector.diff_generator, generator)
        self.assertIs(detector.edge_analyzer, analyzer)
        self.assertIs(detector.result_builder, builder)


class TestChecksumDetectorFactoryMethods(unittest.TestCase):
    """Test factory methods."""

    def test_for_faq_updates_factory(self):
        """Test for_faq_updates() factory method."""
        detector = ChecksumChangeDetector.for_faq_updates()

        self.assertIsNotNone(detector)
        self.assertIsNotNone(detector.similarity_calculator)
        self.assertIsNotNone(detector.config)

        # Verify configuration
        self.assertEqual(detector.config.similarity_threshold, 0.8)
        self.assertTrue(detector.config.compute_llm_diffs)

    def test_for_policy_tracking_factory(self):
        """Test for_policy_tracking() factory method."""
        detector = ChecksumChangeDetector.for_policy_tracking()

        self.assertIsNotNone(detector)
        self.assertIsNotNone(detector.similarity_calculator)
        self.assertIsNotNone(detector.config)

        # Verify configuration (stricter threshold)
        self.assertEqual(detector.config.similarity_threshold, 0.9)
        self.assertTrue(detector.config.compute_llm_diffs)
        self.assertEqual(detector.config.diff_context_lines, 5)


class TestDetectChangesUnchangedContent(unittest.TestCase):
    """Test detecting UNCHANGED content."""

    def setUp(self):
        """Set up test fixtures."""
        self.detector = ChecksumChangeDetector()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_detect_unchanged_single_item(self):
        """Test detecting single unchanged item."""
        data = {
            "checksum_abc123": {"text": "Content", "page_num": 1}
        }

        results = self.detector.detect_changes(
            self.file_name, data, data, self.run_id
        )

        # Should have 1 UNCHANGED result
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].change_type, ChangeType.UNCHANGED_CONTENT)
        self.assertEqual(results[0].old_checksum, "checksum_abc123")
        self.assertEqual(results[0].new_checksum, "checksum_abc123")
        self.assertEqual(results[0].similarity_score, 1.0)

    def test_detect_unchanged_multiple_items(self):
        """Test detecting multiple unchanged items."""
        data = {
            "checksum_1": {"text": "Content 1", "page_num": 1},
            "checksum_2": {"text": "Content 2", "page_num": 2},
            "checksum_3": {"text": "Content 3", "page_num": 3},
        }

        results = self.detector.detect_changes(
            self.file_name, data, data, self.run_id
        )

        # Should have 3 UNCHANGED results
        self.assertEqual(len(results), 3)
        unchanged_results = [r for r in results if r.change_type == ChangeType.UNCHANGED_CONTENT]
        self.assertEqual(len(unchanged_results), 3)


class TestDetectChangesNewContent(unittest.TestCase):
    """Test detecting NEW content."""

    def setUp(self):
        """Set up test fixtures."""
        self.detector = ChecksumChangeDetector()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_detect_new_single_item(self):
        """Test detecting single new item."""
        current_data = {
            "new_checksum": {"text": "New content", "page_num": 1}
        }
        previous_data = {}

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Should have 1 NEW result
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].change_type, ChangeType.NEW_CONTENT)
        self.assertEqual(results[0].old_checksum, "")
        self.assertEqual(results[0].new_checksum, "new_checksum")
        self.assertEqual(results[0].similarity_score, 0.0)
        self.assertEqual(results[0].new_content, "New content")

    def test_detect_new_multiple_items(self):
        """Test detecting multiple new items."""
        current_data = {
            "new_1": {"text": "New 1", "page_num": 1},
            "new_2": {"text": "New 2", "page_num": 2},
            "new_3": {"text": "New 3", "page_num": 3},
        }
        previous_data = {}

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Should have 3 NEW results
        self.assertEqual(len(results), 3)
        new_results = [r for r in results if r.change_type == ChangeType.NEW_CONTENT]
        self.assertEqual(len(new_results), 3)


class TestDetectChangesDeletedContent(unittest.TestCase):
    """Test detecting DELETED content."""

    def setUp(self):
        """Set up test fixtures."""
        self.detector = ChecksumChangeDetector()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_detect_deleted_single_item(self):
        """Test detecting single deleted item."""
        current_data = {}
        previous_data = {
            "deleted_checksum": {"content_text": "Deleted content", "page_number": 1}
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Should have 1 DELETED result
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].change_type, ChangeType.DELETED_CONTENT)
        self.assertEqual(results[0].old_checksum, "deleted_checksum")
        self.assertEqual(results[0].new_checksum, "")
        self.assertEqual(results[0].similarity_score, 0.0)
        self.assertEqual(results[0].old_content, "Deleted content")

    def test_detect_deleted_multiple_items(self):
        """Test detecting multiple deleted items."""
        current_data = {}
        previous_data = {
            "deleted_1": {"content_text": "Deleted 1", "page_number": 1},
            "deleted_2": {"content_text": "Deleted 2", "page_number": 2},
            "deleted_3": {"content_text": "Deleted 3", "page_number": 3},
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Should have 3 DELETED results
        self.assertEqual(len(results), 3)
        deleted_results = [r for r in results if r.change_type == ChangeType.DELETED_CONTENT]
        self.assertEqual(len(deleted_results), 3)


class TestDetectChangesModifiedContent(unittest.TestCase):
    """Test detecting MODIFIED content."""

    def setUp(self):
        """Set up test fixtures."""
        # Use real calculator for integration testing
        self.detector = ChecksumChangeDetector.for_faq_updates()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_detect_modified_high_similarity(self):
        """Test detecting modified content with high similarity."""
        # Use nearly identical text to ensure high similarity
        current_data = {
            "new_abc": {"text": "How do I reset my password and update my profile?", "page_num": 1}
        }
        previous_data = {
            "old_xyz": {"content_text": "How do I reset my password and update my profile information?", "page_number": 1}
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Check if it was detected as MODIFIED (should be with very similar text)
        modified_results = [r for r in results if r.change_type == ChangeType.MODIFIED_CONTENT]

        if len(modified_results) == 1:
            # High similarity detected
            self.assertEqual(modified_results[0].old_checksum, "old_xyz")
            self.assertEqual(modified_results[0].new_checksum, "new_abc")
            self.assertGreaterEqual(modified_results[0].similarity_score, 0.8)
        else:
            # Low similarity - should be NEW + DELETED
            self.assertEqual(len(results), 2)
            change_types = {r.change_type for r in results}
            self.assertEqual(change_types, {ChangeType.NEW_CONTENT, ChangeType.DELETED_CONTENT})

    def test_detect_modified_low_similarity_treated_as_new_deleted(self):
        """Test that low similarity is treated as separate NEW and DELETED."""
        current_data = {
            "new_abc": {"text": "Completely different new text", "page_num": 1}
        }
        previous_data = {
            "old_xyz": {"content_text": "Original content xyz", "page_number": 1}
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Should have 2 results: 1 NEW, 1 DELETED (low similarity)
        self.assertEqual(len(results), 2)
        change_types = {r.change_type for r in results}
        self.assertEqual(change_types, {ChangeType.NEW_CONTENT, ChangeType.DELETED_CONTENT})


class TestDetectChangesMixedScenarios(unittest.TestCase):
    """Test mixed scenarios with multiple change types."""

    def setUp(self):
        """Set up test fixtures."""
        self.detector = ChecksumChangeDetector.for_faq_updates()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_mixed_all_change_types(self):
        """Test scenario with NEW, MODIFIED, DELETED, UNCHANGED."""
        current_data = {
            "unchanged_1": {"text": "Unchanged content", "page_num": 1},
            "new_1": {"text": "Brand new content", "page_num": 2},
            "modified_new": {"text": "How do I reset my password and update my profile information here?", "page_num": 3},
        }

        previous_data = {
            "unchanged_1": {"content_text": "Unchanged content", "page_number": 1},
            "deleted_1": {"content_text": "Deleted content", "page_number": 2},
            "modified_old": {"content_text": "How do I reset my password and update my profile information?", "page_number": 3},
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Count change types
        change_type_counts = {}
        for result in results:
            change_type_counts[result.change_type] = change_type_counts.get(result.change_type, 0) + 1

        # Should have UNCHANGED and either:
        # - MODIFIED (if similarity >= 0.8) OR
        # - NEW + DELETED (if similarity < 0.8)
        self.assertEqual(change_type_counts[ChangeType.UNCHANGED_CONTENT], 1)

        # Check for MODIFIED or (NEW + DELETED)
        if ChangeType.MODIFIED_CONTENT in change_type_counts:
            # High similarity detected
            self.assertEqual(change_type_counts[ChangeType.MODIFIED_CONTENT], 1)
            self.assertEqual(change_type_counts.get(ChangeType.NEW_CONTENT, 0), 1)
            self.assertEqual(change_type_counts.get(ChangeType.DELETED_CONTENT, 0), 1)
        else:
            # Low similarity - should be 2 NEW, 2 DELETED
            self.assertEqual(change_type_counts.get(ChangeType.NEW_CONTENT, 0), 2)
            self.assertEqual(change_type_counts.get(ChangeType.DELETED_CONTENT, 0), 2)

    def test_empty_current_and_previous(self):
        """Test with both current and previous empty."""
        results = self.detector.detect_changes(
            self.file_name, {}, {}, self.run_id
        )

        # Should return empty list
        self.assertEqual(len(results), 0)

    def test_only_unchanged_content(self):
        """Test with only unchanged content."""
        data = {
            "checksum_1": {"text": "Content 1", "page_num": 1},
            "checksum_2": {"text": "Content 2", "page_num": 2},
        }

        results = self.detector.detect_changes(
            self.file_name, data, data, self.run_id
        )

        # All should be UNCHANGED
        self.assertEqual(len(results), 2)
        self.assertTrue(all(r.change_type == ChangeType.UNCHANGED_CONTENT for r in results))


class TestDetectChangesResultMetadata(unittest.TestCase):
    """Test that results contain correct metadata."""

    def setUp(self):
        """Set up test fixtures."""
        # Enable LLM diffs
        config = DetectionConfig(
            similarity_threshold=0.8,
            compute_llm_diffs=True,
            diff_context_lines=3,
        )
        self.detector = ChecksumChangeDetector(config=config)
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_modified_result_has_llm_diff(self):
        """Test that MODIFIED results have llm_diff in metadata."""
        current_data = {
            "new_abc": {"text": "How do I reset my password?", "page_num": 1}
        }
        previous_data = {
            "old_xyz": {"content_text": "How to reset password?", "page_number": 1}
        }

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        # Find MODIFIED result
        modified = [r for r in results if r.change_type == ChangeType.MODIFIED_CONTENT]

        if modified:  # If similarity is high enough
            result = modified[0]
            # Should have llm_diff in metadata
            self.assertIn("llm_diff", result.metadata)
            self.assertIsNotNone(result.metadata["llm_diff"])

    def test_result_has_correct_file_name(self):
        """Test that results have correct file_name."""
        current_data = {"new_abc": {"text": "New", "page_num": 1}}
        previous_data = {}

        results = self.detector.detect_changes(
            "custom_file.pdf", current_data, previous_data, self.run_id
        )

        self.assertEqual(results[0].file_name, "custom_file.pdf")

    def test_result_has_detected_at_timestamp(self):
        """Test that results have detected_at timestamp."""
        current_data = {"new_abc": {"text": "New", "page_num": 1}}
        previous_data = {}

        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        self.assertIsNotNone(results[0].detected_at)


class TestDetectChangesEdgeCases(unittest.TestCase):
    """Test edge cases and error handling."""

    def setUp(self):
        """Set up test fixtures."""
        self.detector = ChecksumChangeDetector()
        self.file_name = "test.pdf"
        self.run_id = "test_run_1"

    def test_missing_text_fields(self):
        """Test with missing text fields (should not crash)."""
        current_data = {
            "new_abc": {"page_num": 1}  # Missing 'text'
        }
        previous_data = {}

        # Should not crash
        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        self.assertEqual(len(results), 1)
        self.assertIsNone(results[0].new_content)

    def test_missing_page_fields(self):
        """Test with missing page fields (should not crash)."""
        current_data = {
            "new_abc": {"text": "New"}  # Missing 'page_num'
        }
        previous_data = {}

        # Should not crash
        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        self.assertEqual(len(results), 1)
        self.assertIsNone(results[0].page_number)

    def test_content_split_is_logged(self):
        """Test that content splits are detected and logged."""
        # This would require high similarity between one old and multiple new
        # For now, just verify it doesn't crash
        current_data = {
            "new_1": {"text": "Part 1 of split content", "page_num": 1},
            "new_2": {"text": "Part 2 of split content", "page_num": 2},
        }
        previous_data = {
            "old_1": {"content_text": "Original combined content", "page_number": 1},
        }

        # Should not crash (even if no split detected due to low similarity)
        results = self.detector.detect_changes(
            self.file_name, current_data, previous_data, self.run_id
        )

        self.assertIsNotNone(results)


if __name__ == "__main__":
    unittest.main()
