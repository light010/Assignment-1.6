"""
Comprehensive Test Cases for detect_changes Method
===================================================

This test suite verifies that the refactored detect_changes method produces
the exact same output as the original implementation (code1).

Test Categories:
1. MODIFIED_CONTENT: Content with high similarity (>= threshold)
2. NEW_CONTENT: Content that appears in current but not in previous
3. DELETED_CONTENT: Content that appears in previous but not in current
4. UNCHANGED_CONTENT: Identical content in both versions
5. Edge Cases: Splits, merges, multiple changes

Expected Output Format (from your example):
- change_type: new_content | modified_content | deleted_content | unchanged_content
- similarity_score: 0.0-1.0 (0.0 for new/deleted, 0.8-1.0 for modified, 1.0 for unchanged)
- old_checksum: Previous checksum (None for new_content)
- new_checksum: Current checksum (None for deleted_content)
- llm_friendly_diff: JSON string with diff data (None for new/deleted/unchanged)
- file_name: Name of file being analyzed
- page_number: Page number where content appears
"""

import json
import unittest
from datetime import datetime
from typing import Dict, List

from core.models.detection import ChangeType
from database.models import ContentChange
from detection.checksum_detector import ChecksumChangeDetector


class TestDetectChangesRefactored(unittest.TestCase):
    """Test suite for refactored detect_changes method."""

    def setUp(self):
        """Initialize detector for each test."""
        # Create detector with default configuration
        self.detector = ChecksumChangeDetector.for_faq_updates()
        self.file_name = "Employee_Handbook.pdf"
        self.run_id = "test_run_001"

    # ========================================================================
    # TEST CASE 1: MODIFIED_CONTENT (High Similarity)
    # ========================================================================

    def test_modified_content_high_similarity(self):
        """
        Test Case 1: MODIFIED_CONTENT with similarity >= 0.8

        Scenario:
        - Previous: "The company provides health insurance to all employees."
        - Current:  "The company provides health insurance to all full-time employees."

        Expected:
        - change_type: modified_content
        - similarity_score: ~0.95 (high similarity)
        - old_checksum: <previous_checksum>
        - new_checksum: <current_checksum>
        - llm_friendly_diff: JSON with change details
        """
        previous_data = {
            "abc123old": {
                "content_text": "The company provides health insurance to all employees.",
                "page_number": 1,
                "file_name": self.file_name,
            }
        }

        current_data = {
            "def456new": {
                "text": "The company provides health insurance to all full-time employees.",
                "page_num": 1,
                "file_name": self.file_name,
            }
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 1, "Should detect exactly 1 change")

        change = results[0]
        self.assertIsInstance(change, ContentChange, "Should return ContentChange object")
        self.assertEqual(change.change_type, ChangeType.MODIFIED_CONTENT)
        self.assertEqual(change.old_checksum, "abc123old")
        self.assertEqual(change.new_checksum, "def456new")
        self.assertGreaterEqual(change.similarity_score, 0.8, "Similarity should be >= 0.8")
        self.assertLess(change.similarity_score, 1.0, "Similarity should be < 1.0")
        self.assertEqual(change.file_name, self.file_name)
        self.assertEqual(change.page_number, 1)

        # Verify LLM diff is generated
        if self.detector.config.compute_llm_diffs:
            self.assertIsNotNone(change.llm_friendly_diff, "LLM diff should be generated")
            # Verify it's valid JSON
            try:
                diff_data = json.loads(change.llm_friendly_diff)
                self.assertIn("total_changes", diff_data, "Diff should have total_changes")
            except json.JSONDecodeError:
                self.fail("llm_friendly_diff should be valid JSON")

    # ========================================================================
    # TEST CASE 2: NEW_CONTENT
    # ========================================================================

    def test_new_content(self):
        """
        Test Case 2: NEW_CONTENT appears in current but not in previous

        Scenario:
        - Previous: (empty)
        - Current:  "Remote work policy updated for 2025."

        Expected:
        - change_type: new_content
        - similarity_score: 0.0
        - old_checksum: "" (empty)
        - new_checksum: <current_checksum>
        - llm_friendly_diff: None
        """
        previous_data = {}  # No previous content

        current_data = {
            "xyz789new": {
                "text": "Remote work policy updated for 2025.",
                "page_num": 2,
                "file_name": self.file_name,
            }
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 1, "Should detect exactly 1 new content")

        change = results[0]
        self.assertEqual(change.change_type, ChangeType.NEW_CONTENT)
        self.assertEqual(change.old_checksum, "", "old_checksum should be empty for new content")
        self.assertEqual(change.new_checksum, "xyz789new")
        self.assertEqual(change.similarity_score, 0.0, "Similarity should be 0.0 for new content")
        self.assertEqual(change.file_name, self.file_name)
        self.assertEqual(change.page_number, 2)
        self.assertIsNone(change.llm_friendly_diff, "LLM diff should be None for new content")
        self.assertIsNone(change.old_content, "old_content should be None for new content")
        self.assertIsNotNone(change.new_content, "new_content should be populated")

    # ========================================================================
    # TEST CASE 3: DELETED_CONTENT
    # ========================================================================

    def test_deleted_content(self):
        """
        Test Case 3: DELETED_CONTENT appears in previous but not in current

        Scenario:
        - Previous: "Travel reimbursement policy."
        - Current:  (empty)

        Expected:
        - change_type: deleted_content
        - similarity_score: 0.0
        - old_checksum: <previous_checksum>
        - new_checksum: "" (empty)
        - llm_friendly_diff: None
        """
        previous_data = {
            "old999del": {
                "content_text": "Travel reimbursement policy.",
                "page_number": 3,
                "file_name": self.file_name,
            }
        }

        current_data = {}  # Content deleted

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 1, "Should detect exactly 1 deleted content")

        change = results[0]
        self.assertEqual(change.change_type, ChangeType.DELETED_CONTENT)
        self.assertEqual(change.old_checksum, "old999del")
        self.assertEqual(change.new_checksum, "", "new_checksum should be empty for deleted content")
        self.assertEqual(change.similarity_score, 0.0, "Similarity should be 0.0 for deleted content")
        self.assertEqual(change.file_name, self.file_name)
        self.assertEqual(change.page_number, 3)
        self.assertIsNone(change.llm_friendly_diff, "LLM diff should be None for deleted content")
        self.assertIsNotNone(change.old_content, "old_content should be populated")
        self.assertIsNone(change.new_content, "new_content should be None for deleted content")

    # ========================================================================
    # TEST CASE 4: UNCHANGED_CONTENT
    # ========================================================================

    def test_unchanged_content(self):
        """
        Test Case 4: UNCHANGED_CONTENT - identical in both versions

        Scenario:
        - Previous: "Workplace safety guidelines."
        - Current:  "Workplace safety guidelines." (identical checksum)

        Expected:
        - change_type: unchanged_content
        - similarity_score: 1.0
        - old_checksum: <checksum>
        - new_checksum: <checksum> (same)
        - llm_friendly_diff: None
        """
        checksum = "same888unchanged"

        previous_data = {
            checksum: {
                "content_text": "Workplace safety guidelines.",
                "page_number": 4,
                "file_name": self.file_name,
            }
        }

        current_data = {
            checksum: {
                "text": "Workplace safety guidelines.",
                "page_num": 4,
                "file_name": self.file_name,
            }
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 1, "Should detect exactly 1 unchanged content")

        change = results[0]
        self.assertEqual(change.change_type, ChangeType.UNCHANGED_CONTENT)
        self.assertEqual(change.old_checksum, checksum)
        self.assertEqual(change.new_checksum, checksum, "Checksums should be identical")
        self.assertEqual(change.similarity_score, 1.0, "Similarity should be 1.0 for unchanged content")
        self.assertEqual(change.file_name, self.file_name)
        self.assertEqual(change.page_number, 4)
        self.assertIsNone(change.llm_friendly_diff, "LLM diff should be None for unchanged content")

    # ========================================================================
    # TEST CASE 5: MIXED CHANGES (Integration Test)
    # ========================================================================

    def test_mixed_changes_all_types(self):
        """
        Test Case 5: Mixed changes - all types in one file

        Scenario:
        - MODIFIED: "Vacation policy" -> "Vacation policy updated"
        - NEW: "Email policy" (new)
        - DELETED: "Parking policy" (removed)
        - UNCHANGED: "Equipment return" (same)

        Expected:
        - 4 total changes detected
        - 1 modified, 1 new, 1 deleted, 1 unchanged
        - Correct similarity scores for each type
        """
        previous_data = {
            "vac001": {
                "content_text": "Vacation policy allows 15 days per year.",
                "page_number": 1,
                "file_name": self.file_name,
            },
            "park002": {
                "content_text": "Parking policy for employees.",
                "page_number": 2,
                "file_name": self.file_name,
            },
            "equip003": {
                "content_text": "Equipment return policy.",
                "page_number": 3,
                "file_name": self.file_name,
            },
        }

        current_data = {
            "vac001new": {
                "text": "Vacation policy allows 20 days per year for full-time employees.",
                "page_num": 1,
                "file_name": self.file_name,
            },
            "email004": {
                "text": "Email policy for professional communication.",
                "page_num": 4,
                "file_name": self.file_name,
            },
            "equip003": {  # Same checksum as previous
                "text": "Equipment return policy.",
                "page_num": 3,
                "file_name": self.file_name,
            },
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 4, "Should detect 4 changes total")

        # Count by type
        modified_count = sum(1 for r in results if r.change_type == ChangeType.MODIFIED_CONTENT)
        new_count = sum(1 for r in results if r.change_type == ChangeType.NEW_CONTENT)
        deleted_count = sum(1 for r in results if r.change_type == ChangeType.DELETED_CONTENT)
        unchanged_count = sum(1 for r in results if r.change_type == ChangeType.UNCHANGED_CONTENT)

        self.assertEqual(modified_count, 1, "Should have 1 modified content")
        self.assertEqual(new_count, 1, "Should have 1 new content")
        self.assertEqual(deleted_count, 1, "Should have 1 deleted content")
        self.assertEqual(unchanged_count, 1, "Should have 1 unchanged content")

        # Verify specific changes
        modified = [r for r in results if r.change_type == ChangeType.MODIFIED_CONTENT][0]
        self.assertEqual(modified.old_checksum, "vac001")
        self.assertEqual(modified.new_checksum, "vac001new")
        self.assertGreaterEqual(modified.similarity_score, 0.8)

        new = [r for r in results if r.change_type == ChangeType.NEW_CONTENT][0]
        self.assertEqual(new.old_checksum, "")
        self.assertEqual(new.new_checksum, "email004")
        self.assertEqual(new.similarity_score, 0.0)

        deleted = [r for r in results if r.change_type == ChangeType.DELETED_CONTENT][0]
        self.assertEqual(deleted.old_checksum, "park002")
        self.assertEqual(deleted.new_checksum, "")
        self.assertEqual(deleted.similarity_score, 0.0)

        unchanged = [r for r in results if r.change_type == ChangeType.UNCHANGED_CONTENT][0]
        self.assertEqual(unchanged.old_checksum, "equip003")
        self.assertEqual(unchanged.new_checksum, "equip003")
        self.assertEqual(unchanged.similarity_score, 1.0)

    # ========================================================================
    # TEST CASE 6: LOW SIMILARITY (Should be NEW, not MODIFIED)
    # ========================================================================

    def test_low_similarity_treated_as_new(self):
        """
        Test Case 6: Low similarity (< threshold) should be treated as NEW

        Scenario:
        - Previous: "Health insurance benefits."
        - Current:  "Remote work equipment allowance."
        - Similarity: < 0.8 (below threshold)

        Expected:
        - 1 NEW content (not MODIFIED)
        - 1 DELETED content
        - Total: 2 changes
        """
        previous_data = {
            "health555": {
                "content_text": "Health insurance benefits for all employees.",
                "page_number": 1,
                "file_name": self.file_name,
            }
        }

        current_data = {
            "remote666": {
                "text": "Remote work equipment allowance of $500 per year.",
                "page_num": 1,
                "file_name": self.file_name,
            }
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Assertions
        self.assertEqual(len(results), 2, "Should detect 2 changes (1 new + 1 deleted)")

        new_count = sum(1 for r in results if r.change_type == ChangeType.NEW_CONTENT)
        deleted_count = sum(1 for r in results if r.change_type == ChangeType.DELETED_CONTENT)

        self.assertEqual(new_count, 1, "Low similarity should be treated as NEW")
        self.assertEqual(deleted_count, 1, "Old content should be DELETED")

    # ========================================================================
    # TEST CASE 7: VERIFY OUTPUT FORMAT MATCHES EXPECTED SCHEMA
    # ========================================================================

    def test_output_format_matches_expected_schema(self):
        """
        Test Case 7: Verify ContentChange objects have all required fields

        This test ensures that the output format matches your expected schema:
        - change_id (optional - set by database)
        - content_checksum (new_checksum)
        - previous_checksum (old_checksum)
        - file_name
        - change_type
        - similarity_score
        - diff_data (llm_friendly_diff)
        - detection_timestamp
        """
        previous_data = {
            "test001": {
                "content_text": "Original text for schema validation.",
                "page_number": 1,
                "file_name": self.file_name,
            }
        }

        current_data = {
            "test002": {
                "text": "Updated text for schema validation testing.",
                "page_num": 1,
                "file_name": self.file_name,
            }
        }

        # Run detection
        results = self.detector.detect_changes(
            file_name=self.file_name,
            current_checksums_data=current_data,
            previous_checksums_data=previous_data,
            detection_run_id=self.run_id,
        )

        # Verify all required fields are present
        self.assertGreater(len(results), 0, "Should have at least 1 result")

        change = results[0]

        # Required fields
        self.assertIsNotNone(change.new_checksum, "new_checksum is required")
        self.assertIsNotNone(change.old_checksum, "old_checksum is required (can be empty)")
        self.assertIsNotNone(change.file_name, "file_name is required")
        self.assertIsNotNone(change.change_type, "change_type is required")
        self.assertIsNotNone(change.similarity_score, "similarity_score is required")
        self.assertIsNotNone(change.detected_at, "detected_at is required")

        # Type validation
        self.assertIsInstance(change.new_checksum, str)
        self.assertIsInstance(change.old_checksum, str)
        self.assertIsInstance(change.file_name, str)
        self.assertIsInstance(change.change_type, ChangeType)
        self.assertIsInstance(change.similarity_score, float)
        self.assertIsInstance(change.detected_at, datetime)

        # llm_friendly_diff can be None or str
        if change.llm_friendly_diff is not None:
            self.assertIsInstance(change.llm_friendly_diff, str)


if __name__ == "__main__":
    unittest.main()
