"""
Unit tests for core module - Domain Layer Components

Tests for ChunkMetadata, IChunker interface, and domain exceptions.
These tests focus on business rule validation and domain logic.
"""

import pytest
from core import (
    ChunkMetadata,
    IChunker,
    ChunkingError,
    ChunkSizeError,
    ChunkOverlapError,
    ChunkValidationError,
)
from typing import List, Tuple


class TestChunkMetadata:
    """Test ChunkMetadata dataclass - domain value object."""

    def test_minimal_creation(self):
        """Test creating ChunkMetadata with only required fields."""
        metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")

        assert metadata.chunk_index == 0
        assert metadata.chunk_method == "recursive"
        assert metadata.headers == {}
        assert metadata.start_pos is None
        assert metadata.end_pos is None

    def test_full_creation(self):
        """Test creating ChunkMetadata with all fields."""
        metadata = ChunkMetadata(
            chunk_index=5,
            chunk_method="header",
            headers={"h1": "Title", "h2": "Section"},
            start_pos=1000,
            end_pos=2000,
        )

        assert metadata.chunk_index == 5
        assert metadata.chunk_method == "header"
        assert metadata.headers == {"h1": "Title", "h2": "Section"}
        assert metadata.start_pos == 1000
        assert metadata.end_pos == 2000

    def test_immutability(self):
        """Test that ChunkMetadata is immutable (frozen dataclass)."""
        metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")

        with pytest.raises(Exception):  # FrozenInstanceError
            metadata.chunk_index = 10

    def test_negative_chunk_index_rejected(self):
        """Test business rule: chunk_index must be non-negative."""
        with pytest.raises(ValueError, match="chunk_index must be non-negative"):
            ChunkMetadata(chunk_index=-1, chunk_method="recursive")

    def test_invalid_chunk_method_rejected(self):
        """Test business rule: chunk_method must be valid."""
        with pytest.raises(ValueError, match="chunk_method must be one of"):
            ChunkMetadata(chunk_index=0, chunk_method="invalid_method")

    def test_valid_chunk_methods(self):
        """Test all valid chunk methods are accepted."""
        valid_methods = ["recursive", "header", "no_split"]

        for method in valid_methods:
            metadata = ChunkMetadata(chunk_index=0, chunk_method=method)
            assert metadata.chunk_method == method

    def test_position_validation_both_or_none(self):
        """Test business rule: start_pos and end_pos must both be provided or both None."""
        # Only start_pos provided - should fail
        with pytest.raises(ValueError, match="start_pos and end_pos must both be"):
            ChunkMetadata(
                chunk_index=0, chunk_method="recursive", start_pos=100, end_pos=None
            )

        # Only end_pos provided - should fail
        with pytest.raises(ValueError, match="start_pos and end_pos must both be"):
            ChunkMetadata(
                chunk_index=0, chunk_method="recursive", start_pos=None, end_pos=100
            )

        # Both provided - should succeed
        metadata = ChunkMetadata(
            chunk_index=0, chunk_method="recursive", start_pos=0, end_pos=100
        )
        assert metadata.start_pos == 0
        assert metadata.end_pos == 100

        # Neither provided - should succeed
        metadata = ChunkMetadata(chunk_index=0, chunk_method="header")
        assert metadata.start_pos is None
        assert metadata.end_pos is None

    def test_position_validation_end_greater_than_start(self):
        """Test business rule: end_pos must be greater than start_pos."""
        # end_pos == start_pos - should fail
        with pytest.raises(ValueError, match="end_pos.*must be greater than start_pos"):
            ChunkMetadata(
                chunk_index=0, chunk_method="recursive", start_pos=100, end_pos=100
            )

        # end_pos < start_pos - should fail
        with pytest.raises(ValueError, match="end_pos.*must be greater than start_pos"):
            ChunkMetadata(
                chunk_index=0, chunk_method="recursive", start_pos=100, end_pos=50
            )

        # end_pos > start_pos - should succeed
        metadata = ChunkMetadata(
            chunk_index=0, chunk_method="recursive", start_pos=0, end_pos=100
        )
        assert metadata.end_pos > metadata.start_pos

    def test_to_dict_minimal(self):
        """Test serialization to dict with minimal fields."""
        metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")
        data = metadata.to_dict()

        assert data == {
            "chunk_index": 0,
            "chunk_method": "recursive",
            "headers": {},
            "start_pos": None,
            "end_pos": None,
        }

    def test_to_dict_full(self):
        """Test serialization to dict with all fields."""
        metadata = ChunkMetadata(
            chunk_index=5,
            chunk_method="header",
            headers={"h1": "Title"},
            start_pos=1000,
            end_pos=2000,
        )
        data = metadata.to_dict()

        assert data == {
            "chunk_index": 5,
            "chunk_method": "header",
            "headers": {"h1": "Title"},
            "start_pos": 1000,
            "end_pos": 2000,
        }

    def test_from_dict_minimal(self):
        """Test deserialization from dict with minimal fields."""
        data = {"chunk_index": 0, "chunk_method": "recursive"}
        metadata = ChunkMetadata.from_dict(data)

        assert metadata.chunk_index == 0
        assert metadata.chunk_method == "recursive"
        assert metadata.headers == {}
        assert metadata.start_pos is None
        assert metadata.end_pos is None

    def test_from_dict_full(self):
        """Test deserialization from dict with all fields."""
        data = {
            "chunk_index": 5,
            "chunk_method": "header",
            "headers": {"h1": "Title", "h2": "Section"},
            "start_pos": 1000,
            "end_pos": 2000,
        }
        metadata = ChunkMetadata.from_dict(data)

        assert metadata.chunk_index == 5
        assert metadata.chunk_method == "header"
        assert metadata.headers == {"h1": "Title", "h2": "Section"}
        assert metadata.start_pos == 1000
        assert metadata.end_pos == 2000

    def test_from_dict_filters_unknown_fields(self):
        """Test that from_dict ignores unknown fields."""
        data = {
            "chunk_index": 0,
            "chunk_method": "recursive",
            "unknown_field": "should_be_ignored",
            "another_unknown": 123,
        }
        metadata = ChunkMetadata.from_dict(data)

        # Should create successfully, ignoring unknown fields
        assert metadata.chunk_index == 0
        assert metadata.chunk_method == "recursive"
        assert not hasattr(metadata, "unknown_field")

    def test_roundtrip_serialization_minimal(self):
        """Test that to_dict -> from_dict preserves data (minimal)."""
        original = ChunkMetadata(chunk_index=0, chunk_method="recursive")
        data = original.to_dict()
        loaded = ChunkMetadata.from_dict(data)

        assert original == loaded

    def test_roundtrip_serialization_full(self):
        """Test that to_dict -> from_dict preserves data (full)."""
        original = ChunkMetadata(
            chunk_index=5,
            chunk_method="header",
            headers={"h1": "Title", "h2": "Section"},
            start_pos=1000,
            end_pos=2000,
        )
        data = original.to_dict()
        loaded = ChunkMetadata.from_dict(data)

        assert original == loaded

    def test_equality(self):
        """Test that two ChunkMetadata with same values are equal."""
        metadata1 = ChunkMetadata(
            chunk_index=0, chunk_method="recursive", headers={"h1": "Title"}
        )
        metadata2 = ChunkMetadata(
            chunk_index=0, chunk_method="recursive", headers={"h1": "Title"}
        )

        assert metadata1 == metadata2

    def test_inequality(self):
        """Test that ChunkMetadata with different values are not equal."""
        metadata1 = ChunkMetadata(chunk_index=0, chunk_method="recursive")
        metadata2 = ChunkMetadata(chunk_index=1, chunk_method="recursive")

        assert metadata1 != metadata2


class TestExceptionHierarchy:
    """Test exception hierarchy and relationships."""

    def test_chunking_error_is_exception(self):
        """Test ChunkingError inherits from Exception."""
        assert issubclass(ChunkingError, Exception)

    def test_chunk_size_error_is_chunking_error(self):
        """Test ChunkSizeError inherits from ChunkingError."""
        assert issubclass(ChunkSizeError, ChunkingError)

    def test_chunk_overlap_error_is_chunking_error(self):
        """Test ChunkOverlapError inherits from ChunkingError."""
        assert issubclass(ChunkOverlapError, ChunkingError)

    def test_chunk_validation_error_is_chunking_error(self):
        """Test ChunkValidationError inherits from ChunkingError."""
        assert issubclass(ChunkValidationError, ChunkingError)

    def test_catch_specific_exception(self):
        """Test catching specific exception type."""
        with pytest.raises(ChunkSizeError):
            raise ChunkSizeError("Invalid size")

    def test_catch_base_exception(self):
        """Test catching base ChunkingError catches subclasses."""
        with pytest.raises(ChunkingError):
            raise ChunkSizeError("Invalid size")


class MockChunker(IChunker):
    """Mock implementation of IChunker for testing."""

    def chunk(self, content: str) -> List[str]:
        return [content] if content else []

    def chunk_with_checksums(
        self, content: str
    ) -> List[Tuple[str, str, ChunkMetadata]]:
        if not content:
            return []
        metadata = ChunkMetadata(chunk_index=0, chunk_method="recursive")
        return [(content, "mock_checksum", metadata)]


class TestIChunkerInterface:
    """Test IChunker abstract interface."""

    def test_cannot_instantiate_interface(self):
        """Test that IChunker cannot be instantiated directly."""
        with pytest.raises(TypeError):
            IChunker()  # type: ignore

    def test_mock_implementation_works(self):
        """Test that concrete implementation of IChunker works."""
        chunker = MockChunker()
        assert isinstance(chunker, IChunker)

        # Test chunk()
        chunks = chunker.chunk("test content")
        assert chunks == ["test content"]

        # Test chunk_with_checksums()
        results = chunker.chunk_with_checksums("test content")
        assert len(results) == 1
        chunk_text, checksum, metadata = results[0]
        assert chunk_text == "test content"
        assert checksum == "mock_checksum"
        assert isinstance(metadata, ChunkMetadata)

    def test_incomplete_implementation_fails(self):
        """Test that incomplete IChunker implementation cannot be instantiated."""

        with pytest.raises(TypeError):

            class IncompleteChunker(IChunker):
                def chunk(self, content: str) -> List[str]:
                    return [content]

                # Missing chunk_with_checksums()

            IncompleteChunker()  # Should fail - missing abstract method
