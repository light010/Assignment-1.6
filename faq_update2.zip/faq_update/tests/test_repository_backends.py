"""
Comprehensive repository integration tests with both SQLite and Databricks backends.

Tests that repositories work correctly with both backend implementations:
- SQLite backend (for local development and testing)
- Databricks backend (mocked for CI/CD, real in Databricks environment)

This ensures the repository pattern truly abstracts away database differences.
"""

import pytest
import tempfile
from pathlib import Path
import pandas as pd
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime


class TestRepositoryWithSQLiteBackend:
    """Test all repositories with SQLite backend."""

    @pytest.fixture
    def sqlite_backend(self):
        """Create SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass

    def test_content_repository_sqlite(self, sqlite_backend):
        """Test ContentRepository with SQLite backend."""
        from database.repository import ContentRepository

        repo = ContentRepository(sqlite_backend)

        # Test ingest
        df = pd.DataFrame({
            'raw_file_nme': ['test1.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [1, 1],
            'raw_file_path': ['/path/test1.pdf', '/path/test2.pdf'],
            'extracted_markdown_file_path': ['/md/test1.md', '/md/test2.md'],
            'title_nme': ['Test 1', 'Test 2'],
            'file_status': ['Active', 'Active']
        })

        result = repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')
        assert result['success'] == True
        assert result['rows_inserted'] == 2

        # Test list
        files = repo.list_files()
        assert len(files) == 2

        # Test stats
        stats = repo.get_file_stats()
        assert stats['total_files'] == 2
        assert stats['by_type']['pdf'] == 2

    def test_faq_repository_sqlite(self, sqlite_backend):
        """Test FAQRepository with SQLite backend."""
        from database.repository import FAQRepository

        repo = FAQRepository(sqlite_backend)

        # Test ingest questions
        questions_df = pd.DataFrame({
            'question_text': ['Q1?', 'Q2?', 'Q3?'],
            'source_type': ['from_documents', 'from_documents', 'from_documents'],
            'generation_method': ['llm_generated', 'llm_generated', 'llm_generated'],
            'status': ['active', 'active', 'active']
        })

        result = repo.ingest_questions(questions_df)
        assert result['success'] == True
        assert result['rows_inserted'] == 3

        # Test list questions
        questions = repo.list_questions()
        assert len(questions) == 3

        # Test ingest answers
        answers_df = pd.DataFrame({
            'question_id': [questions[0]['question_id'], questions[1]['question_id']],
            'answer_text': ['Answer 1', 'Answer 2'],
            'status': ['active', 'active']
        })

        result = repo.ingest_answers(answers_df)
        assert result['success'] == True
        assert result['rows_inserted'] == 2

        # Test list answers
        answers = repo.list_answers()
        assert len(answers) == 2

    def test_audit_repository_sqlite(self, sqlite_backend):
        """Test AuditRepository with SQLite backend."""
        from database.repository import AuditRepository
        from database.models import ChangeType
        from core.models.detection import DetectionResult

        repo = AuditRepository(sqlite_backend)

        # Create detection results
        changes = [
            DetectionResult(
                old_checksum="",
                new_checksum="hash1",
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                similarity_score=0.0,
                new_content="New content",
                old_content=None,
                metadata={}
            ),
            DetectionResult(
                old_checksum="hash1",
                new_checksum="hash2",
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                similarity_score=0.85,
                new_content="Modified content",
                old_content="Old content",
                metadata={}
            )
        ]

        # Store results
        run_id = "test_run_001"
        inserted = repo.store_detection_results(changes, run_id=run_id)
        assert inserted == 2

        # Query results
        run_changes = repo.get_changes_by_run(run_id)
        assert len(run_changes) == 2

        # Test get_run_summary
        summary = repo.get_run_summary(run_id)
        assert summary is not None
        assert summary['total_changes'] == 2


class TestRepositoryWithMockedDatabricksBackend:
    """Test repositories with mocked Databricks backend."""

    @pytest.fixture
    def mocked_databricks_backend(self):
        """Create mocked Databricks backend for testing."""
        mock_backend = Mock()

        # Mock execute_query to return empty results by default
        mock_backend.execute_query.return_value = []

        # Mock execute_command to return success
        mock_backend.execute_command.return_value = 1

        # Mock ingest_dataframe to return success
        mock_backend.ingest_dataframe.return_value = {
            'success': True,
            'rows_inserted': 0,
            'message': 'Mock ingestion successful'
        }

        # Mock transaction methods
        mock_backend.begin_transaction.return_value = None
        mock_backend.commit.return_value = None
        mock_backend.rollback.return_value = None
        mock_backend.close.return_value = None

        # Mock get_table_name to return Unity Catalog format
        mock_backend.get_table_name = lambda table: f"test_catalog.test_schema.{table}"

        yield mock_backend

    def test_content_repository_databricks_mock(self, mocked_databricks_backend):
        """Test ContentRepository with mocked Databricks backend."""
        from database.repository import ContentRepository

        # Mock successful ingestion
        mocked_databricks_backend.ingest_dataframe.return_value = {
            'success': True,
            'rows_inserted': 2,
            'message': 'Ingested 2 rows'
        }

        repo = ContentRepository(mocked_databricks_backend)

        df = pd.DataFrame({
            'raw_file_nme': ['test1.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [1, 1],
            'raw_file_path': ['/path/test1.pdf', '/path/test2.pdf'],
            'extracted_markdown_file_path': ['/md/test1.md', '/md/test2.md'],
            'title_nme': ['Test 1', 'Test 2'],
            'file_status': ['Active', 'Active']
        })

        result = repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        assert result['success'] == True
        assert result['rows_inserted'] == 2
        mocked_databricks_backend.ingest_dataframe.assert_called_once()

    def test_faq_repository_databricks_mock(self, mocked_databricks_backend):
        """Test FAQRepository with mocked Databricks backend."""
        from database.repository import FAQRepository

        # Mock successful ingestion
        mocked_databricks_backend.ingest_dataframe.return_value = {
            'success': True,
            'rows_inserted': 3,
            'message': 'Ingested 3 rows'
        }

        repo = FAQRepository(mocked_databricks_backend)

        questions_df = pd.DataFrame({
            'question_text': ['Q1?', 'Q2?', 'Q3?'],
            'source_type': ['from_documents', 'from_documents', 'from_documents'],
            'generation_method': ['llm_generated', 'llm_generated', 'llm_generated'],
            'status': ['active', 'active', 'active']
        })

        result = repo.ingest_questions(questions_df)

        assert result['success'] == True
        assert result['rows_inserted'] == 3
        mocked_databricks_backend.ingest_dataframe.assert_called_once()

    def test_audit_repository_databricks_mock(self, mocked_databricks_backend):
        """Test AuditRepository with mocked Databricks backend."""
        from database.repository import AuditRepository
        from database.models import ChangeType
        from core.models.detection import DetectionResult

        # Mock successful command execution
        mocked_databricks_backend.execute_command.return_value = 2

        repo = AuditRepository(mocked_databricks_backend)

        changes = [
            DetectionResult(
                old_checksum="",
                new_checksum="hash1",
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                similarity_score=0.0,
                new_content="New content",
                old_content=None,
                metadata={}
            )
        ]

        run_id = "test_run_001"
        inserted = repo.store_detection_results(changes, run_id=run_id)

        # Verify backend methods were called
        assert mocked_databricks_backend.execute_command.called or mocked_databricks_backend.ingest_dataframe.called


class TestBackendAgnosticOperations:
    """Test that repositories work identically with both backends."""

    def test_same_operations_both_backends(self):
        """Test that the same repository operations work with both backends."""
        from database.backends.factory import BackendFactory
        from database.repository import ContentRepository
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        # Test with SQLite
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            sqlite_config = DatabaseConfig(backend='sqlite', db_path=db_path)
            sqlite_backend = BackendFactory.create_backend(sqlite_config, force_new=True)

            schema_manager = SchemaManager(sqlite_backend)
            schema_manager.create_all_tables()

            sqlite_repo = ContentRepository(sqlite_backend)

            # Same dataframe for both
            df = pd.DataFrame({
                'raw_file_nme': ['test.pdf'],
                'raw_file_type': ['pdf'],
                'raw_file_version_nbr': [1],
                'raw_file_path': ['/path/test.pdf'],
                'extracted_markdown_file_path': ['/md/test.md'],
                'title_nme': ['Test'],
                'file_status': ['Active']
            })

            # Ingest with SQLite
            sqlite_result = sqlite_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')
            assert sqlite_result['success'] == True

            # Get stats with SQLite
            sqlite_stats = sqlite_repo.get_file_stats()
            assert sqlite_stats['total_files'] == 1

            sqlite_backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

        # Test with mocked Databricks
        mock_databricks = Mock()
        mock_databricks.ingest_dataframe.return_value = {
            'success': True,
            'rows_inserted': 1,
            'message': 'Success'
        }
        mock_databricks.execute_query.return_value = [
            {'total_files': 1, 'unique_files': 1}
        ]

        databricks_repo = ContentRepository(mock_databricks)

        # Ingest with Databricks (mocked)
        databricks_result = databricks_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')
        assert databricks_result['success'] == True

        # Both backends should support the same operations
        assert hasattr(sqlite_repo, 'ingest_files_bulk')
        assert hasattr(databricks_repo, 'ingest_files_bulk')
        assert hasattr(sqlite_repo, 'list_files')
        assert hasattr(databricks_repo, 'list_files')


class TestRepositoryErrorHandling:
    """Test error handling in repositories across backends."""

    @pytest.fixture
    def sqlite_backend(self):
        """Create SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass

    def test_invalid_dataframe_handling(self, sqlite_backend):
        """Test handling of invalid dataframes."""
        from database.repository import ContentRepository

        repo = ContentRepository(sqlite_backend)

        # Empty dataframe
        empty_df = pd.DataFrame()

        with pytest.raises((ValueError, Exception)):
            repo.ingest_files_bulk(files_df=empty_df, validate=True, if_exists='append')

    def test_transaction_rollback_on_error(self, sqlite_backend):
        """Test that transactions rollback on error."""
        from database.repository import ContentRepository

        repo = ContentRepository(sqlite_backend)

        initial_stats = repo.get_file_stats()
        initial_count = initial_stats['total_files']

        try:
            with repo.transaction():
                # Valid data
                df = pd.DataFrame({
                    'raw_file_nme': ['test.pdf'],
                    'raw_file_type': ['pdf'],
                    'raw_file_version_nbr': [1],
                    'raw_file_path': ['/path/test.pdf'],
                    'extracted_markdown_file_path': ['/md/test.md'],
                    'title_nme': ['Test'],
                    'file_status': ['Active']
                })

                repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

                # Force error
                raise Exception("Test error")
        except Exception:
            pass

        # Verify rollback
        final_stats = repo.get_file_stats()
        final_count = final_stats['total_files']

        assert final_count == initial_count


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
