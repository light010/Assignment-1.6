"""
Database Output Format Tests
=============================

This test suite verifies that ContentChange objects can be converted to the
expected database format matching your example output.

Expected Database Schema:
-------------------------
- change_id: int (auto-generated)
- content_checksum: str (new_checksum)
- previous_checksum: str | None (old_checksum)
- file_name: str
- requires_faq_regeneration: int (0 or 1)
- change_type: str
- similarity_score: float
- similarity_method: str ("hybrid")
- diff_data: str | None (JSON)
- total_faqs_at_risk: int
- affected_question_count: int
- affected_answer_count: int
- detection_run_id: str
- detection_timestamp: datetime

Example Output (from your spec):
---------------------------------
change_id=43, content_checksum=f3bbae..., previous_checksum=b54c22...,
file_name=Employee_Handbook.pdf, requires_faq_regeneration=1,
change_type=modified_content, similarity_score=0.950515, similarity_method=hybrid,
diff_data={"total_changes": 2, "change_types": {"replace": 2}}, ...
"""

import json
import unittest
from datetime import datetime

from core.models.detection import ChangeType
from database.models import ContentChange


class TestDatabaseOutputFormat(unittest.TestCase):
    """Test conversion of ContentChange to database format."""

    def test_to_change_log_dict_modified_content(self):
        """
        Test MODIFIED_CONTENT conversion to database format.

        Expected:
        - requires_faq_regeneration: 1
        - similarity_method: "hybrid"
        - diff_data: Valid JSON string
        """
        change = ContentChange(
            old_checksum="b54c22ec37e28c72f242c5c96ba13a0d",
            new_checksum="f3bbae03d26ce982636aaa5552ad07e8",
            change_type=ChangeType.MODIFIED_CONTENT,
            detected_at=datetime.now(),
            file_name="Employee_Handbook.pdf",
            page_number=1,
            old_content="Old text",
            new_content="New text",
            similarity_score=0.950515,
            llm_friendly_diff='{"total_changes": 2, "change_types": {"replace": 2}}',
        )

        # Convert to database format
        db_dict = change.to_change_log_dict()

        # Assertions
        self.assertEqual(db_dict["content_checksum"], "f3bbae03d26ce982636aaa5552ad07e8")
        self.assertEqual(db_dict["previous_checksum"], "b54c22ec37e28c72f242c5c96ba13a0d")
        self.assertEqual(db_dict["file_name"], "Employee_Handbook.pdf")
        self.assertEqual(db_dict["requires_faq_regeneration"], 1, "Modified content requires regeneration")
        self.assertEqual(db_dict["change_type"], "modified_content")
        self.assertAlmostEqual(db_dict["similarity_score"], 0.950515, places=6)
        self.assertEqual(db_dict["similarity_method"], "hybrid")
        self.assertIsNotNone(db_dict["diff_data"])

        # Verify diff_data is valid JSON
        try:
            diff_obj = json.loads(db_dict["diff_data"])
            self.assertIn("total_changes", diff_obj)
            self.assertEqual(diff_obj["total_changes"], 2)
        except json.JSONDecodeError:
            self.fail("diff_data should be valid JSON")

        # Verify impact metrics are initialized to 0
        self.assertEqual(db_dict["total_faqs_at_risk"], 0)
        self.assertEqual(db_dict["affected_question_count"], 0)
        self.assertEqual(db_dict["affected_answer_count"], 0)

    def test_to_change_log_dict_new_content(self):
        """
        Test NEW_CONTENT conversion to database format.

        Expected:
        - requires_faq_regeneration: 1
        - previous_checksum: None
        - similarity_score: 0.0
        - diff_data: None
        """
        change = ContentChange(
            old_checksum="",
            new_checksum="7317c6901c9282b3c1adbab4f0b5937f",
            change_type=ChangeType.NEW_CONTENT,
            detected_at=datetime.now(),
            file_name="Travel_Policy.pdf",
            page_number=2,
            old_content=None,
            new_content="New travel policy content",
            similarity_score=0.0,
            llm_friendly_diff=None,
        )

        # Convert to database format
        db_dict = change.to_change_log_dict()

        # Assertions
        self.assertEqual(db_dict["content_checksum"], "7317c6901c9282b3c1adbab4f0b5937f")
        self.assertIsNone(db_dict["previous_checksum"], "New content has no previous checksum")
        self.assertEqual(db_dict["file_name"], "Travel_Policy.pdf")
        self.assertEqual(db_dict["requires_faq_regeneration"], 1, "New content requires regeneration")
        self.assertEqual(db_dict["change_type"], "new_content")
        self.assertEqual(db_dict["similarity_score"], 0.0)
        self.assertEqual(db_dict["similarity_method"], "hybrid")
        self.assertIsNone(db_dict["diff_data"], "New content has no diff")

    def test_to_change_log_dict_deleted_content(self):
        """
        Test DELETED_CONTENT conversion to database format.

        Expected:
        - requires_faq_regeneration: 1
        - content_checksum: "" (empty for deleted)
        - similarity_score: 0.0
        - diff_data: None
        """
        change = ContentChange(
            old_checksum="c0a9947d707ea77c52566453c69cc6ae",
            new_checksum="",
            change_type=ChangeType.DELETED_CONTENT,
            detected_at=datetime.now(),
            file_name="Travel_Policy.pdf",
            page_number=3,
            old_content="Old content that was deleted",
            new_content=None,
            similarity_score=0.0,
            llm_friendly_diff=None,
        )

        # Convert to database format
        db_dict = change.to_change_log_dict()

        # Assertions
        self.assertEqual(db_dict["content_checksum"], "", "Deleted content has empty new checksum")
        self.assertEqual(db_dict["previous_checksum"], "c0a9947d707ea77c52566453c69cc6ae")
        self.assertEqual(db_dict["file_name"], "Travel_Policy.pdf")
        self.assertEqual(db_dict["requires_faq_regeneration"], 1, "Deleted content requires regeneration")
        self.assertEqual(db_dict["change_type"], "deleted_content")
        self.assertEqual(db_dict["similarity_score"], 0.0)
        self.assertEqual(db_dict["similarity_method"], "hybrid")
        self.assertIsNone(db_dict["diff_data"], "Deleted content has no diff")

    def test_to_change_log_dict_unchanged_content(self):
        """
        Test UNCHANGED_CONTENT conversion to database format.

        Expected:
        - requires_faq_regeneration: 0 (NO regeneration needed)
        - similarity_score: 1.0
        - content_checksum and previous_checksum are identical
        - diff_data: None
        """
        checksum = "30635deca8c6424f51a689016694ba5e"

        change = ContentChange(
            old_checksum=checksum,
            new_checksum=checksum,
            change_type=ChangeType.UNCHANGED_CONTENT,
            detected_at=datetime.now(),
            file_name="Workplace_Safety.pdf",
            page_number=4,
            old_content=None,
            new_content=None,
            similarity_score=1.0,
            llm_friendly_diff=None,
        )

        # Convert to database format
        db_dict = change.to_change_log_dict()

        # Assertions
        self.assertEqual(db_dict["content_checksum"], checksum)
        self.assertEqual(db_dict["previous_checksum"], checksum, "Unchanged has identical checksums")
        self.assertEqual(db_dict["file_name"], "Workplace_Safety.pdf")
        self.assertEqual(db_dict["requires_faq_regeneration"], 0, "Unchanged content does NOT require regeneration")
        self.assertEqual(db_dict["change_type"], "unchanged_content")
        self.assertEqual(db_dict["similarity_score"], 1.0)
        self.assertEqual(db_dict["similarity_method"], "hybrid")
        self.assertIsNone(db_dict["diff_data"], "Unchanged content has no diff")

    def test_bulk_conversion_matches_expected_output(self):
        """
        Test bulk conversion of mixed changes to match your expected output format.

        This test creates multiple changes and verifies they all convert correctly.
        """
        changes = [
            ContentChange(
                old_checksum="b54c22ec37e28c72",
                new_checksum="f3bbae03d26ce982",
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime(2025, 10, 27, 13, 2, 8),
                file_name="Employee_Handbook.pdf",
                page_number=1,
                similarity_score=0.950515,
                llm_friendly_diff='{"total_changes": 2}',
            ),
            ContentChange(
                old_checksum="",
                new_checksum="7317c6901c9282b3",
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime(2025, 10, 27, 13, 2, 8),
                file_name="Travel_Policy.pdf",
                page_number=2,
                similarity_score=0.0,
                llm_friendly_diff=None,
            ),
            ContentChange(
                old_checksum="30635deca8c6424f",
                new_checksum="30635deca8c6424f",
                change_type=ChangeType.UNCHANGED_CONTENT,
                detected_at=datetime(2025, 10, 27, 13, 2, 8),
                file_name="Workplace_Safety.pdf",
                page_number=4,
                similarity_score=1.0,
                llm_friendly_diff=None,
            ),
        ]

        # Convert all to database format
        db_records = [change.to_change_log_dict() for change in changes]

        # Verify count
        self.assertEqual(len(db_records), 3)

        # Verify requires_faq_regeneration values
        regen_values = [r["requires_faq_regeneration"] for r in db_records]
        self.assertEqual(regen_values, [1, 1, 0], "Modified and New require regen, Unchanged does not")

        # Verify all have similarity_method
        for record in db_records:
            self.assertEqual(record["similarity_method"], "hybrid")

        # Verify similarity scores
        scores = [r["similarity_score"] for r in db_records]
        self.assertAlmostEqual(scores[0], 0.950515, places=6, msg="Modified has high similarity")
        self.assertEqual(scores[1], 0.0, "New has 0.0 similarity")
        self.assertEqual(scores[2], 1.0, "Unchanged has 1.0 similarity")


if __name__ == "__main__":
    unittest.main()
