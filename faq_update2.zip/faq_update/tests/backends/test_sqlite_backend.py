"""
Tests for SQLite Backend

Comprehensive test suite for SQLiteBackend implementation.

Tests cover:
- Connection management
- CRUD operations
- Bulk DataFrame operations
- Transaction management
- Schema operations
- Error handling
- Thread safety

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import pytest
import sqlite3
import pandas as pd
from pathlib import Path
import tempfile
import os

from database.backends.sqlite import SQLiteBackend
from database.config import DatabaseConfig
from database.backends.base import (
    BackendType,
    ConnectionError as BackendConnectionError,
    QueryError,
    CommandError,
    TransactionError,
    TableNotFoundError,
    MultipleResultsError,
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def temp_db():
    """Create a temporary database file path (file created on first use)."""
    # Get a unique filename in temp directory without creating the file
    temp_dir = tempfile.gettempdir()
    db_path = os.path.join(temp_dir, f"test_sqlite_{os.getpid()}_{id(temp_dir)}.db")

    yield db_path

    # Cleanup
    try:
        if os.path.exists(db_path):
            os.unlink(db_path)
    except Exception:
        pass


@pytest.fixture
def in_memory_config():
    """Create in-memory database configuration."""
    return DatabaseConfig(backend="sqlite", db_path=":memory:")


@pytest.fixture
def temp_db_config(temp_db):
    """Create temporary database configuration."""
    return DatabaseConfig(backend="sqlite", db_path=temp_db)


@pytest.fixture
def backend_in_memory(in_memory_config):
    """Create in-memory SQLite backend."""
    backend = SQLiteBackend(in_memory_config)
    backend.connect()

    # Create a test table
    backend.execute_command("""
        CREATE TABLE test_table (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            value INTEGER,
            active INTEGER DEFAULT 1
        )
    """)

    yield backend

    backend.close()


@pytest.fixture
def backend_with_fk(in_memory_config):
    """Create backend with foreign key test tables."""
    backend = SQLiteBackend(in_memory_config)
    backend.connect()

    # Parent table
    backend.execute_command("""
        CREATE TABLE parent (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL
        )
    """)

    # Child table with foreign key
    backend.execute_command("""
        CREATE TABLE child (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER NOT NULL,
            value TEXT,
            FOREIGN KEY (parent_id) REFERENCES parent(id)
        )
    """)

    yield backend

    backend.close()


# =============================================================================
# Test Backend Initialization
# =============================================================================

class TestBackendInitialization:
    """Test backend initialization and configuration."""

    def test_create_backend_with_config(self, in_memory_config):
        """Test creating backend with configuration."""
        backend = SQLiteBackend(in_memory_config)

        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == ":memory:"
        assert not backend.is_connected

    def test_create_backend_with_invalid_config(self):
        """Test that invalid config raises error."""
        invalid_config = DatabaseConfig(backend="databricks", catalog="test", schema="test")

        with pytest.raises(Exception):  # ConfigurationError
            SQLiteBackend(invalid_config)

    def test_create_backend_without_db_path(self):
        """Test that missing db_path raises error."""
        # This should fail in DatabaseConfig validation
        with pytest.raises(ValueError):
            DatabaseConfig(backend="sqlite", db_path=None)


# =============================================================================
# Test Connection Management
# =============================================================================

class TestConnectionManagement:
    """Test connection lifecycle."""

    def test_connect_and_disconnect(self, in_memory_config):
        """Test connecting and disconnecting."""
        backend = SQLiteBackend(in_memory_config)

        assert not backend.is_connected

        backend.connect()
        assert backend.is_connected

        backend.close()
        assert not backend.is_connected

    def test_connect_creates_file(self, temp_db_config):
        """Test that connect creates database file."""
        db_path = temp_db_config.db_path

        # File shouldn't exist yet
        assert not Path(db_path).exists()

        backend = SQLiteBackend(temp_db_config)

        # File still shouldn't exist until connect is called
        assert not Path(db_path).exists()

        backend.connect()

        # Now it should exist
        assert Path(db_path).exists()

        backend.close()

        # File should still exist after close
        assert Path(db_path).exists()

    def test_context_manager(self, in_memory_config):
        """Test using backend as context manager."""
        with SQLiteBackend(in_memory_config) as backend:
            assert backend.is_connected

            backend.execute_command("""
                CREATE TABLE test (id INTEGER PRIMARY KEY)
            """)

        # Connection should be closed
        assert not backend.is_connected

    def test_connect_idempotent(self, in_memory_config):
        """Test that calling connect multiple times is safe."""
        backend = SQLiteBackend(in_memory_config)

        backend.connect()
        backend.connect()  # Second connect should be safe
        backend.connect()  # Third connect should be safe

        assert backend.is_connected

        backend.close()


# =============================================================================
# Test Query Operations
# =============================================================================

class TestQueryOperations:
    """Test SELECT queries."""

    def test_execute_query(self, backend_in_memory):
        """Test basic query execution."""
        # Insert test data
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # Query
        results = backend_in_memory.execute_query(
            "SELECT * FROM test_table WHERE name = ?",
            ("test1",)
        )

        assert len(results) == 1
        assert results[0]['name'] == "test1"
        assert results[0]['value'] == 100

    def test_execute_query_empty_result(self, backend_in_memory):
        """Test query that returns no results."""
        results = backend_in_memory.execute_query(
            "SELECT * FROM test_table WHERE name = ?",
            ("nonexistent",)
        )

        assert len(results) == 0
        assert results == []

    def test_execute_query_single(self, backend_in_memory):
        """Test query_single returns one result."""
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        result = backend_in_memory.execute_query_single(
            "SELECT * FROM test_table WHERE name = ?",
            ("test1",)
        )

        assert result is not None
        assert result['name'] == "test1"

    def test_execute_query_single_no_results(self, backend_in_memory):
        """Test query_single returns None when no results."""
        result = backend_in_memory.execute_query_single(
            "SELECT * FROM test_table WHERE name = ?",
            ("nonexistent",)
        )

        assert result is None

    def test_execute_query_single_multiple_results(self, backend_in_memory):
        """Test query_single raises error for multiple results."""
        # Insert multiple rows
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test", 100)
        )
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test", 200)
        )

        with pytest.raises(MultipleResultsError):
            backend_in_memory.execute_query_single(
                "SELECT * FROM test_table WHERE name = ?",
                ("test",)
            )

    def test_query_without_connection(self, in_memory_config):
        """Test that query without connection raises error."""
        backend = SQLiteBackend(in_memory_config)

        with pytest.raises(QueryError):
            backend.execute_query("SELECT 1")


# =============================================================================
# Test Command Operations
# =============================================================================

class TestCommandOperations:
    """Test INSERT, UPDATE, DELETE commands."""

    def test_execute_command_insert(self, backend_in_memory):
        """Test INSERT command."""
        rows_affected = backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        assert rows_affected == 1

        # Verify insert
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 1

    def test_execute_command_update(self, backend_in_memory):
        """Test UPDATE command."""
        # Insert
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # Update
        rows_affected = backend_in_memory.execute_command(
            "UPDATE test_table SET value = ? WHERE name = ?",
            (200, "test1")
        )

        assert rows_affected == 1

        # Verify
        result = backend_in_memory.execute_query_single(
            "SELECT value FROM test_table WHERE name = ?",
            ("test1",)
        )
        assert result['value'] == 200

    def test_execute_command_delete(self, backend_in_memory):
        """Test DELETE command."""
        # Insert
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # Delete
        rows_affected = backend_in_memory.execute_command(
            "DELETE FROM test_table WHERE name = ?",
            ("test1",)
        )

        assert rows_affected == 1

        # Verify
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 0

    def test_execute_many(self, backend_in_memory):
        """Test batch insert with execute_many."""
        rows = [
            ("test1", 100),
            ("test2", 200),
            ("test3", 300),
        ]

        rows_affected = backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            rows
        )

        assert rows_affected == 3

        # Verify
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 3


# =============================================================================
# Test Bulk DataFrame Operations
# =============================================================================

class TestDataFrameOperations:
    """Test DataFrame ingestion and reading."""

    def test_ingest_dataframe(self, backend_in_memory):
        """Test bulk DataFrame insert."""
        df = pd.DataFrame({
            'name': ['test1', 'test2', 'test3'],
            'value': [100, 200, 300]
        })

        result = backend_in_memory.ingest_dataframe(df, "test_table")

        assert result['success'] is True
        assert result['rows_inserted'] == 3

        # Verify
        rows = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(rows) == 3

    def test_ingest_empty_dataframe(self, backend_in_memory):
        """Test ingesting empty DataFrame."""
        df = pd.DataFrame({'name': [], 'value': []})

        result = backend_in_memory.ingest_dataframe(df, "test_table")

        assert result['success'] is True
        assert result['rows_inserted'] == 0

    def test_read_table(self, backend_in_memory):
        """Test reading table into DataFrame."""
        # Insert data
        backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            [("test1", 100), ("test2", 200), ("test3", 300)]
        )

        # Read
        df = backend_in_memory.read_table("test_table")

        assert len(df) == 3
        assert 'name' in df.columns
        assert 'value' in df.columns

    def test_read_table_with_filter(self, backend_in_memory):
        """Test reading table with WHERE clause."""
        # Insert data
        backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            [("test1", 100), ("test2", 200), ("test3", 300)]
        )

        # Read with filter
        df = backend_in_memory.read_table(
            "test_table",
            where="value > ?",
            params=(150,)
        )

        assert len(df) == 2

    def test_read_table_with_columns(self, backend_in_memory):
        """Test reading specific columns."""
        # Insert data
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # Read specific columns
        df = backend_in_memory.read_table(
            "test_table",
            columns=['name']
        )

        assert 'name' in df.columns
        assert 'value' not in df.columns


# =============================================================================
# Test Transaction Management
# =============================================================================

class TestTransactions:
    """Test transaction management."""

    def test_transaction_commit(self, backend_in_memory):
        """Test successful transaction commit."""
        backend_in_memory.begin_transaction()

        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )
        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test2", 200)
        )

        backend_in_memory.commit()

        # Verify both inserts succeeded
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 2

    def test_transaction_rollback(self, backend_in_memory):
        """Test transaction rollback."""
        backend_in_memory.begin_transaction()

        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        backend_in_memory.rollback()

        # Verify insert was rolled back
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 0

    def test_transaction_rollback_on_error(self, backend_in_memory):
        """Test that rollback works after error."""
        backend_in_memory.begin_transaction()

        backend_in_memory.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # This will fail (duplicate primary key)
        try:
            backend_in_memory.execute_command(
                "INSERT INTO test_table (id, name, value) VALUES (?, ?, ?)",
                (1, "test2", 200)
            )
            backend_in_memory.execute_command(
                "INSERT INTO test_table (id, name, value) VALUES (?, ?, ?)",
                (1, "test3", 300)  # Same ID - will fail
            )
        except CommandError:
            backend_in_memory.rollback()

        # Verify both inserts were rolled back
        results = backend_in_memory.execute_query("SELECT * FROM test_table")
        assert len(results) == 0

    def test_foreign_key_enforcement(self, backend_with_fk):
        """Test that foreign keys are enforced."""
        # Insert parent
        backend_with_fk.execute_command(
            "INSERT INTO parent (id, name) VALUES (?, ?)",
            (1, "parent1")
        )

        # Insert child with valid FK
        backend_with_fk.execute_command(
            "INSERT INTO child (id, parent_id, value) VALUES (?, ?, ?)",
            (1, 1, "child1")
        )

        # Try to insert child with invalid FK (should fail)
        with pytest.raises(CommandError):
            backend_with_fk.execute_command(
                "INSERT INTO child (id, parent_id, value) VALUES (?, ?, ?)",
                (2, 999, "child2")  # parent_id 999 doesn't exist
            )


# =============================================================================
# Test Schema Operations
# =============================================================================

class TestSchemaOperations:
    """Test schema introspection."""

    def test_table_exists(self, backend_in_memory):
        """Test table_exists check."""
        assert backend_in_memory.table_exists("test_table") is True
        assert backend_in_memory.table_exists("nonexistent_table") is False

    def test_list_tables(self, backend_in_memory):
        """Test listing all tables."""
        tables = backend_in_memory.list_tables()

        assert "test_table" in tables
        assert len(tables) >= 1

    def test_get_table_schema(self, backend_in_memory):
        """Test getting table schema."""
        schema = backend_in_memory.get_table_schema("test_table")

        assert len(schema) == 4  # 4 columns

        # Check column names
        column_names = [col['name'] for col in schema]
        assert 'id' in column_names
        assert 'name' in column_names
        assert 'value' in column_names
        assert 'active' in column_names

        # Check primary key
        id_col = next(col for col in schema if col['name'] == 'id')
        assert id_col['primary_key'] is True

    def test_get_schema_nonexistent_table(self, backend_in_memory):
        """Test getting schema for nonexistent table."""
        with pytest.raises(TableNotFoundError):
            backend_in_memory.get_table_schema("nonexistent_table")


# =============================================================================
# Test Utility Methods
# =============================================================================

class TestUtilityMethods:
    """Test utility methods."""

    def test_get_row_count(self, backend_in_memory):
        """Test getting row count."""
        # Insert data
        backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            [("test1", 100), ("test2", 200), ("test3", 300)]
        )

        count = backend_in_memory.get_row_count("test_table")
        assert count == 3

    def test_get_row_count_with_filter(self, backend_in_memory):
        """Test getting row count with WHERE clause."""
        # Insert data
        backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            [("test1", 100), ("test2", 200), ("test3", 300)]
        )

        count = backend_in_memory.get_row_count(
            "test_table",
            where="value > ?",
            params=(150,)
        )
        assert count == 2

    def test_get_distinct_values(self, backend_in_memory):
        """Test getting distinct values from column."""
        # Insert data with duplicates
        backend_in_memory.execute_many(
            "INSERT INTO test_table (name, value, active) VALUES (?, ?, ?)",
            [
                ("test1", 100, 1),
                ("test2", 200, 1),
                ("test3", 300, 0),
                ("test4", 400, 1),
            ]
        )

        distinct_active = backend_in_memory.get_distinct_values(
            "test_table",
            "active"
        )

        assert len(distinct_active) == 2
        assert 0 in distinct_active
        assert 1 in distinct_active


# =============================================================================
# Test Error Handling
# =============================================================================

class TestErrorHandling:
    """Test error handling."""

    def test_sql_syntax_error(self, backend_in_memory):
        """Test that SQL syntax errors are caught."""
        with pytest.raises(QueryError):
            backend_in_memory.execute_query("INVALID SQL SYNTAX")

    def test_command_on_disconnected_backend(self, in_memory_config):
        """Test command on disconnected backend raises error."""
        backend = SQLiteBackend(in_memory_config)

        with pytest.raises(CommandError):
            backend.execute_command("INSERT INTO test VALUES (1)")

    def test_table_not_found(self, backend_in_memory):
        """Test querying nonexistent table."""
        with pytest.raises(QueryError):
            backend_in_memory.execute_query("SELECT * FROM nonexistent_table")


# =============================================================================
# Test Cleanup
# =============================================================================

class TestCleanup:
    """Test proper cleanup."""

    def test_close_in_transaction(self, temp_db_config):
        """Test that closing with active transaction rolls back."""
        # Use file-based database so we can reconnect and check
        backend = SQLiteBackend(temp_db_config)
        backend.connect()

        # Create test table
        backend.execute_command("""
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                value INTEGER
            )
        """)

        # Start transaction and insert data
        backend.begin_transaction()

        backend.execute_command(
            "INSERT INTO test_table (name, value) VALUES (?, ?)",
            ("test1", 100)
        )

        # Close without commit (should rollback)
        backend.close()

        # Reconnect and verify rollback
        backend.connect()
        results = backend.execute_query("SELECT * FROM test_table")
        assert len(results) == 0

        backend.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
