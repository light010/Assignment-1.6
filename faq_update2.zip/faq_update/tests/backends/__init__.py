"""
Backend Tests

Test suite for database backends.

Tests:
- test_sqlite_backend.py: SQLite backend implementation tests
- test_databricks_backend.py: Databricks backend tests (future)
- test_backend_interface.py: IBackend interface compliance tests (future)
"""
