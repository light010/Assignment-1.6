"""
Tests for Backend Factory System

Comprehensive test suite for BackendFactory class and backend creation.

Tests cover:
- Backend creation with auto-detection
- Explicit SQLite backend creation
- Explicit Databricks backend creation
- Singleton pattern and caching
- Backend lifecycle management
- Thread safety
- Error handling
- Convenience methods
- Factory reset functionality

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import pytest
import os
import tempfile
import threading
from pathlib import Path
from typing import Optional
from unittest.mock import patch, MagicMock

from database.backends.factory import BackendFactory, get_backend, reset_backend
from database.config import DatabaseConfig
from database.backends.base import IBackend, BackendType, ConfigurationError


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture(autouse=True)
def reset_factory():
    """Reset factory singleton before and after each test."""
    BackendFactory.reset()
    yield
    BackendFactory.reset()


@pytest.fixture
def clean_env(monkeypatch):
    """Clean environment variables before each test."""
    for key in list(os.environ.keys()):
        if key.startswith("DATABASE_"):
            monkeypatch.delenv(key, raising=False)
    monkeypatch.delenv("DATABRICKS_RUNTIME_VERSION", raising=False)
    return monkeypatch


@pytest.fixture
def temp_db():
    """Create a temporary database file path."""
    temp_dir = tempfile.gettempdir()
    db_path = os.path.join(temp_dir, f"test_factory_{os.getpid()}.db")

    yield db_path

    # Cleanup
    try:
        if os.path.exists(db_path):
            os.unlink(db_path)
    except Exception:
        pass


@pytest.fixture
def sqlite_config(temp_db):
    """Create SQLite configuration."""
    return DatabaseConfig(backend="sqlite", db_path=temp_db)


@pytest.fixture
def in_memory_config():
    """Create in-memory SQLite configuration."""
    return DatabaseConfig(backend="sqlite", db_path=":memory:")


# =============================================================================
# Test Backend Creation - Auto-Detection
# =============================================================================

class TestCreateBackend:
    """Test BackendFactory.create_backend() with auto-detection."""

    def test_create_backend_with_sqlite_config(self, sqlite_config):
        """Test creating backend with explicit SQLite config."""
        backend = BackendFactory.create_backend(sqlite_config)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == sqlite_config.db_path

    def test_create_backend_with_in_memory_config(self, in_memory_config):
        """Test creating backend with in-memory SQLite config."""
        backend = BackendFactory.create_backend(in_memory_config)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == ":memory:"

    def test_create_backend_from_env_sqlite(self, clean_env, temp_db):
        """Test creating backend from environment (SQLite)."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", temp_db)

        backend = BackendFactory.create_backend()

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == temp_db

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_create_backend_with_databricks_config(self, mock_databricks_backend):
        """Test creating backend with Databricks config."""
        # Mock DatabricksBackend since it requires Spark
        mock_instance = MagicMock(spec=IBackend)
        mock_instance.backend_type = BackendType.DATABRICKS
        mock_databricks_backend.return_value = mock_instance

        config = DatabaseConfig(
            backend="databricks",
            catalog="test_catalog",
            schema="test_schema"
        )

        backend = BackendFactory.create_backend(config)

        assert backend is not None
        assert backend.backend_type == BackendType.DATABRICKS
        mock_databricks_backend.assert_called_once()

    def test_create_backend_invalid_config_type(self):
        """Test that invalid config type raises error."""
        with pytest.raises(Exception):
            BackendFactory.create_backend("not_a_config")

    def test_create_backend_none_config_uses_env(self, clean_env, temp_db):
        """Test that None config loads from environment."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", temp_db)

        backend = BackendFactory.create_backend(config=None)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE


# =============================================================================
# Test Explicit SQLite Backend Creation
# =============================================================================

class TestCreateSQLiteBackend:
    """Test BackendFactory.create_sqlite_backend() convenience method."""

    def test_create_sqlite_backend_default_path(self):
        """Test creating SQLite backend with default path."""
        backend = BackendFactory.create_sqlite_backend()

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == "databases/granular_impact.db"

    def test_create_sqlite_backend_custom_path(self, temp_db):
        """Test creating SQLite backend with custom path."""
        backend = BackendFactory.create_sqlite_backend(db_path=temp_db)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == temp_db

    def test_create_sqlite_backend_in_memory(self):
        """Test creating in-memory SQLite backend."""
        backend = BackendFactory.create_sqlite_backend(db_path=":memory:")

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == ":memory:"

    def test_create_sqlite_backend_with_options(self, temp_db):
        """Test creating SQLite backend with additional options."""
        backend = BackendFactory.create_sqlite_backend(
            db_path=temp_db,
            timeout=60.0,
            pool_size=10,
            echo_sql=True
        )

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.config.timeout == 60.0
        assert backend.config.pool_size == 10
        assert backend.config.echo_sql is True


# =============================================================================
# Test Explicit Databricks Backend Creation
# =============================================================================

class TestCreateDatabricksBackend:
    """Test BackendFactory.create_databricks_backend() convenience method."""

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_create_databricks_backend_minimal(self, mock_databricks_backend):
        """Test creating Databricks backend with minimal parameters."""
        mock_instance = MagicMock(spec=IBackend)
        mock_instance.backend_type = BackendType.DATABRICKS
        mock_databricks_backend.return_value = mock_instance

        backend = BackendFactory.create_databricks_backend(
            catalog="test_catalog",
            schema="test_schema"
        )

        assert backend is not None
        assert backend.backend_type == BackendType.DATABRICKS
        mock_databricks_backend.assert_called_once()

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_create_databricks_backend_with_cluster(self, mock_databricks_backend):
        """Test creating Databricks backend with cluster ID."""
        mock_instance = MagicMock(spec=IBackend)
        mock_instance.backend_type = BackendType.DATABRICKS
        mock_databricks_backend.return_value = mock_instance

        backend = BackendFactory.create_databricks_backend(
            catalog="test_catalog",
            schema="test_schema",
            cluster_id="cluster-123"
        )

        assert backend is not None
        mock_databricks_backend.assert_called_once()

        # Verify config passed to backend
        call_args = mock_databricks_backend.call_args
        config = call_args[0][0]
        assert config.catalog == "test_catalog"
        assert config.schema == "test_schema"
        assert config.cluster_id == "cluster-123"

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_create_databricks_backend_with_options(self, mock_databricks_backend):
        """Test creating Databricks backend with additional options."""
        mock_instance = MagicMock(spec=IBackend)
        mock_instance.backend_type = BackendType.DATABRICKS
        mock_databricks_backend.return_value = mock_instance

        backend = BackendFactory.create_databricks_backend(
            catalog="test_catalog",
            schema="test_schema",
            pool_size=20,
            echo_sql=True
        )

        assert backend is not None

        # Verify config
        call_args = mock_databricks_backend.call_args
        config = call_args[0][0]
        assert config.pool_size == 20
        assert config.echo_sql is True


# =============================================================================
# Test In-Memory Backend Creation
# =============================================================================

class TestCreateInMemoryBackend:
    """Test BackendFactory.create_in_memory_backend() convenience method."""

    def test_create_in_memory_backend(self):
        """Test creating in-memory backend."""
        backend = BackendFactory.create_in_memory_backend()

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE
        assert backend.db_path == ":memory:"

    def test_in_memory_backend_is_functional(self):
        """Test that in-memory backend is functional."""
        backend = BackendFactory.create_in_memory_backend()
        backend.connect()

        # Create a test table
        backend.execute_command("""
            CREATE TABLE test (
                id INTEGER PRIMARY KEY,
                name TEXT
            )
        """)

        # Insert data
        backend.execute_command(
            "INSERT INTO test (id, name) VALUES (?, ?)",
            (1, "test")
        )

        # Query data
        results = backend.execute_query("SELECT * FROM test")
        assert len(results) == 1
        assert results[0]['name'] == "test"

        backend.close()


# =============================================================================
# Test Singleton Pattern
# =============================================================================

class TestSingletonPattern:
    """Test backend caching and singleton behavior."""

    def test_singleton_returns_same_instance(self, sqlite_config):
        """Test that multiple calls return the same instance."""
        backend1 = BackendFactory.create_backend(sqlite_config)
        backend2 = BackendFactory.create_backend(sqlite_config)

        assert backend1 is backend2

    def test_singleton_with_none_config(self, clean_env, temp_db):
        """Test singleton with None config (from env)."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", temp_db)

        backend1 = BackendFactory.create_backend()
        backend2 = BackendFactory.create_backend()

        assert backend1 is backend2

    def test_force_new_bypasses_singleton(self, sqlite_config):
        """Test that force_new=True creates new instance."""
        backend1 = BackendFactory.create_backend(sqlite_config)
        backend2 = BackendFactory.create_backend(sqlite_config, force_new=True)

        assert backend1 is not backend2
        # But singleton should still be backend1
        backend3 = BackendFactory.create_backend(sqlite_config)
        assert backend1 is backend3

    def test_get_instance_returns_existing(self, sqlite_config):
        """Test get_instance() returns existing instance."""
        # Create instance
        backend1 = BackendFactory.create_backend(sqlite_config)

        # Get instance without creating
        backend2 = BackendFactory.get_instance()

        assert backend1 is backend2

    def test_get_instance_returns_none_if_not_initialized(self):
        """Test get_instance() returns None if no instance exists."""
        instance = BackendFactory.get_instance()
        assert instance is None

    def test_is_initialized_true_after_creation(self, sqlite_config):
        """Test is_initialized() returns True after creation."""
        assert BackendFactory.is_initialized() is False

        BackendFactory.create_backend(sqlite_config)

        assert BackendFactory.is_initialized() is True

    def test_is_initialized_false_after_reset(self, sqlite_config):
        """Test is_initialized() returns False after reset."""
        BackendFactory.create_backend(sqlite_config)
        assert BackendFactory.is_initialized() is True

        BackendFactory.reset()

        assert BackendFactory.is_initialized() is False


# =============================================================================
# Test Backend Lifecycle Management
# =============================================================================

class TestLifecycleManagement:
    """Test backend lifecycle and cleanup."""

    def test_reset_closes_backend(self, sqlite_config):
        """Test that reset() closes the backend."""
        backend = BackendFactory.create_backend(sqlite_config)
        backend.connect()

        assert backend.is_connected

        BackendFactory.reset()

        # Backend should be closed
        assert not backend.is_connected

    def test_reset_clears_singleton(self, sqlite_config):
        """Test that reset() clears singleton instance."""
        backend1 = BackendFactory.create_backend(sqlite_config)

        BackendFactory.reset()

        backend2 = BackendFactory.create_backend(sqlite_config)

        # Should be different instances
        assert backend1 is not backend2

    def test_reset_when_no_instance(self):
        """Test that reset() works when no instance exists."""
        # Should not raise error
        BackendFactory.reset()
        BackendFactory.reset()  # Call twice

    def test_multiple_reset_calls(self, sqlite_config):
        """Test multiple reset calls are safe."""
        backend = BackendFactory.create_backend(sqlite_config)

        BackendFactory.reset()
        BackendFactory.reset()
        BackendFactory.reset()

        # Should still be able to create new backend
        new_backend = BackendFactory.create_backend(sqlite_config)
        assert new_backend is not None


# =============================================================================
# Test Thread Safety
# =============================================================================

class TestThreadSafety:
    """Test thread-safe singleton creation."""

    def test_concurrent_creation_same_instance(self, sqlite_config):
        """Test that concurrent creates return same instance."""
        backends = []
        errors = []

        def create_backend():
            try:
                backend = BackendFactory.create_backend(sqlite_config)
                backends.append(backend)
            except Exception as e:
                errors.append(e)

        # Create 10 threads that all try to create backend
        threads = [threading.Thread(target=create_backend) for _ in range(10)]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        # No errors should occur
        assert len(errors) == 0

        # All backends should be the same instance
        assert len(backends) == 10
        first_backend = backends[0]
        assert all(b is first_backend for b in backends)

    def test_concurrent_reset_and_create(self, sqlite_config):
        """Test concurrent reset and create operations."""
        results = []
        errors = []

        def create_and_reset():
            try:
                backend = BackendFactory.create_backend(sqlite_config)
                results.append(('create', backend))
                BackendFactory.reset()
                results.append(('reset', None))
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=create_and_reset) for _ in range(5)]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        # Should complete without errors (may have some expected race conditions)
        # The important thing is no crashes or deadlocks
        assert len(results) > 0


# =============================================================================
# Test Convenience Functions
# =============================================================================

class TestConvenienceFunctions:
    """Test module-level convenience functions."""

    def test_get_backend_function(self, sqlite_config):
        """Test get_backend() convenience function."""
        backend = get_backend(sqlite_config)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE

    def test_get_backend_singleton(self, sqlite_config):
        """Test get_backend() returns singleton."""
        backend1 = get_backend(sqlite_config)
        backend2 = get_backend(sqlite_config)

        assert backend1 is backend2

    def test_reset_backend_function(self, sqlite_config):
        """Test reset_backend() convenience function."""
        backend1 = get_backend(sqlite_config)

        reset_backend()

        backend2 = get_backend(sqlite_config)

        assert backend1 is not backend2

    def test_get_backend_from_env(self, clean_env, temp_db):
        """Test get_backend() with None config."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", temp_db)

        backend = get_backend()

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE


# =============================================================================
# Test Error Handling
# =============================================================================

class TestErrorHandling:
    """Test error handling in factory."""

    def test_invalid_backend_type_in_config(self):
        """Test that invalid backend type raises error."""
        with pytest.raises(ValueError, match="Invalid backend"):
            config = DatabaseConfig(backend="invalid", db_path="test.db")
            BackendFactory.create_backend(config)

    def test_missing_sqlite_db_path(self):
        """Test that missing db_path raises error."""
        with pytest.raises(ValueError, match="requires 'db_path'"):
            config = DatabaseConfig(backend="sqlite", db_path=None)
            BackendFactory.create_backend(config)

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_missing_databricks_catalog(self, mock_databricks_backend):
        """Test that missing catalog raises error."""
        with pytest.raises(ValueError, match="requires 'catalog'"):
            config = DatabaseConfig(backend="databricks", catalog=None, schema="test")
            BackendFactory.create_backend(config)

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_missing_databricks_schema(self, mock_databricks_backend):
        """Test that missing schema raises error."""
        with pytest.raises(ValueError, match="requires 'schema'"):
            config = DatabaseConfig(backend="databricks", catalog="test", schema=None)
            BackendFactory.create_backend(config)

    @patch('database.backends.sqlite.backend.SQLiteBackend')
    def test_backend_import_error(self, mock_sqlite_backend):
        """Test handling of import errors."""
        # Make backend raise ImportError
        mock_sqlite_backend.side_effect = ImportError("Module not found")

        config = DatabaseConfig(backend="sqlite", db_path="test.db")

        with pytest.raises(ImportError):
            BackendFactory.create_backend(config)


# =============================================================================
# Test Backend Selection Logic
# =============================================================================

class TestBackendSelection:
    """Test backend auto-detection and selection logic."""

    def test_auto_detect_sqlite_from_env(self, clean_env, temp_db):
        """Test auto-detection selects SQLite from env."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", temp_db)

        backend = BackendFactory.create_backend()

        assert backend.backend_type == BackendType.SQLITE

    @patch('database.backends.databricks.backend.DatabricksBackend')
    def test_auto_detect_databricks_from_runtime(self, mock_databricks_backend, clean_env):
        """Test auto-detection detects Databricks runtime."""
        mock_instance = MagicMock(spec=IBackend)
        mock_instance.backend_type = BackendType.DATABRICKS
        mock_databricks_backend.return_value = mock_instance

        # Set Databricks runtime env var (no DATABASE_BACKEND)
        clean_env.setenv("DATABRICKS_RUNTIME_VERSION", "13.3")
        clean_env.setenv("DATABASE_CATALOG", "test_catalog")
        clean_env.setenv("DATABASE_SCHEMA", "test_schema")

        backend = BackendFactory.create_backend()

        assert backend.backend_type == BackendType.DATABRICKS

    def test_explicit_config_overrides_env(self, clean_env, temp_db):
        """Test that explicit config overrides environment."""
        # Set env to one thing
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", "env_path.db")

        # But pass different config
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)
        backend = BackendFactory.create_backend(config)

        assert backend.db_path == temp_db
        assert backend.db_path != "env_path.db"


# =============================================================================
# Test Integration with Actual Backends
# =============================================================================

class TestBackendIntegration:
    """Test factory integration with actual backend implementations."""

    def test_created_backend_is_functional(self, temp_db):
        """Test that factory-created backend is fully functional."""
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)
        backend = BackendFactory.create_backend(config)

        # Connect
        backend.connect()
        assert backend.is_connected

        # Create table
        backend.execute_command("""
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                value INTEGER
            )
        """)

        # Insert data
        backend.execute_command(
            "INSERT INTO test_table (id, name, value) VALUES (?, ?, ?)",
            (1, "test", 100)
        )

        # Query data
        results = backend.execute_query("SELECT * FROM test_table")
        assert len(results) == 1
        assert results[0]['name'] == "test"
        assert results[0]['value'] == 100

        # Close
        backend.close()
        assert not backend.is_connected

    def test_singleton_backend_shares_state(self, temp_db):
        """Test that singleton instances share database state."""
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)

        # Create first backend and insert data
        backend1 = BackendFactory.create_backend(config)
        backend1.connect()
        backend1.execute_command("""
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY,
                name TEXT
            )
        """)
        backend1.execute_command(
            "INSERT INTO test_table (id, name) VALUES (?, ?)",
            (1, "shared_data")
        )

        # Get second backend (same instance)
        backend2 = BackendFactory.create_backend(config)

        # Should see the same data
        results = backend2.execute_query("SELECT * FROM test_table")
        assert len(results) == 1
        assert results[0]['name'] == "shared_data"

        backend1.close()


# =============================================================================
# Test Documentation Examples
# =============================================================================

class TestDocumentationExamples:
    """Test that examples from documentation work correctly."""

    def test_basic_usage_example(self, temp_db):
        """Test basic usage example from docstring."""
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)
        backend = BackendFactory.create_backend(config)

        assert backend is not None
        assert backend.backend_type == BackendType.SQLITE

    def test_singleton_example(self, temp_db):
        """Test singleton example from docstring."""
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)

        # First call creates backend
        backend1 = BackendFactory.create_backend(config)

        # Second call returns same instance
        backend2 = BackendFactory.create_backend(config)

        assert backend1 is backend2

    def test_reset_example(self, temp_db):
        """Test reset example from docstring."""
        config = DatabaseConfig(backend="sqlite", db_path=temp_db)

        backend1 = BackendFactory.create_backend(config)

        # Reset singleton
        BackendFactory.reset()

        backend2 = BackendFactory.create_backend(config)

        assert backend1 is not backend2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
