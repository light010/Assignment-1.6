"""
Tests for Database Configuration System

Comprehensive test suite for DatabaseConfig class and configuration loading.

Tests cover:
- Configuration dataclass initialization
- Environment variable loading (from_env)
- YAML file loading (from_yaml)
- Dictionary loading (from_dict)
- Configuration validation
- Default values
- Helper methods
- Export methods
- Auto-detection logic
- Edge cases and error handling

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import pytest
import os
import yaml
import tempfile
from pathlib import Path
from typing import Dict, Any

from database.config import DatabaseConfig, BackendType


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def clean_env(monkeypatch):
    """Clean environment variables before each test."""
    # Remove all DATABASE_* environment variables
    for key in list(os.environ.keys()):
        if key.startswith("DATABASE_"):
            monkeypatch.delenv(key, raising=False)
    # Remove DATABRICKS_RUNTIME_VERSION for clean tests
    monkeypatch.delenv("DATABRICKS_RUNTIME_VERSION", raising=False)
    return monkeypatch


@pytest.fixture
def temp_yaml_file():
    """Create a temporary YAML file for testing."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml_path = Path(f.name)

    yield yaml_path

    # Cleanup
    if yaml_path.exists():
        yaml_path.unlink()


@pytest.fixture
def sqlite_config_dict() -> Dict[str, Any]:
    """Sample SQLite configuration dictionary."""
    return {
        "backend": "sqlite",
        "db_path": "databases/test.db",
        "timeout": 30.0,
        "enable_foreign_keys": True,
        "journal_mode": "WAL",
        "pool_size": 5,
        "max_overflow": 10,
        "echo_sql": False,
        "autocommit": False
    }


@pytest.fixture
def databricks_config_dict() -> Dict[str, Any]:
    """Sample Databricks configuration dictionary."""
    return {
        "backend": "databricks",
        "catalog": "test_catalog",
        "schema": "test_schema",
        "cluster_id": "test-cluster-123",
        "pool_size": 5,
        "max_overflow": 10,
        "echo_sql": False
    }


# =============================================================================
# Test Configuration Initialization
# =============================================================================

class TestConfigInitialization:
    """Test DatabaseConfig dataclass initialization."""

    def test_create_sqlite_config_minimal(self):
        """Test creating minimal SQLite configuration."""
        config = DatabaseConfig(backend="sqlite", db_path="test.db")

        assert config.backend == "sqlite"
        assert config.db_path == "test.db"
        assert config.timeout == 30.0  # Default
        assert config.enable_foreign_keys is True  # Default
        assert config.journal_mode == "WAL"  # Default
        assert config.pool_size == 5  # Default

    def test_create_sqlite_config_full(self):
        """Test creating full SQLite configuration."""
        config = DatabaseConfig(
            backend="sqlite",
            db_path="databases/faq.db",
            timeout=60.0,
            enable_foreign_keys=False,
            journal_mode="DELETE",
            pool_size=10,
            max_overflow=20,
            echo_sql=True,
            autocommit=True
        )

        assert config.backend == "sqlite"
        assert config.db_path == "databases/faq.db"
        assert config.timeout == 60.0
        assert config.enable_foreign_keys is False
        assert config.journal_mode == "DELETE"
        assert config.pool_size == 10
        assert config.max_overflow == 20
        assert config.echo_sql is True
        assert config.autocommit is True

    def test_create_databricks_config_minimal(self):
        """Test creating minimal Databricks configuration."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="prod_catalog",
            schema="faq_schema"
        )

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"
        assert config.cluster_id is None  # Optional
        assert config.pool_size == 5  # Default

    def test_create_databricks_config_full(self):
        """Test creating full Databricks configuration."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="prod_catalog",
            schema="faq_schema",
            cluster_id="cluster-123-abc",
            pool_size=20,
            max_overflow=40,
            echo_sql=True
        )

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"
        assert config.cluster_id == "cluster-123-abc"
        assert config.pool_size == 20
        assert config.max_overflow == 40
        assert config.echo_sql is True

    def test_config_is_frozen(self):
        """Test that config is immutable (frozen dataclass)."""
        config = DatabaseConfig(backend="sqlite", db_path="test.db")

        with pytest.raises(Exception):  # FrozenInstanceError
            config.db_path = "new_path.db"

    def test_config_with_extra_fields(self):
        """Test config with extra backend-specific fields."""
        config = DatabaseConfig(
            backend="sqlite",
            db_path="test.db",
            extra={"custom_pragma": "value", "special_mode": True}
        )

        assert config.extra == {"custom_pragma": "value", "special_mode": True}


# =============================================================================
# Test Configuration Validation
# =============================================================================

class TestConfigValidation:
    """Test configuration validation in __post_init__."""

    def test_invalid_backend_type(self):
        """Test that invalid backend type raises error."""
        with pytest.raises(ValueError, match="Invalid backend"):
            DatabaseConfig(backend="invalid_backend", db_path="test.db")

    def test_sqlite_missing_db_path(self):
        """Test that SQLite without db_path raises error."""
        with pytest.raises(ValueError, match="requires 'db_path'"):
            DatabaseConfig(backend="sqlite", db_path=None)

    def test_sqlite_empty_db_path(self):
        """Test that SQLite with empty db_path raises error."""
        with pytest.raises(ValueError, match="requires 'db_path'"):
            DatabaseConfig(backend="sqlite", db_path="")

    def test_databricks_missing_catalog(self):
        """Test that Databricks without catalog raises error."""
        with pytest.raises(ValueError, match="requires 'catalog'"):
            DatabaseConfig(backend="databricks", catalog=None, schema="test")

    def test_databricks_missing_schema(self):
        """Test that Databricks without schema raises error."""
        with pytest.raises(ValueError, match="requires 'schema'"):
            DatabaseConfig(backend="databricks", catalog="test", schema=None)

    def test_databricks_empty_catalog(self):
        """Test that Databricks with empty catalog raises error."""
        with pytest.raises(ValueError, match="requires 'catalog'"):
            DatabaseConfig(backend="databricks", catalog="", schema="test")

    def test_databricks_empty_schema(self):
        """Test that Databricks with empty schema raises error."""
        with pytest.raises(ValueError, match="requires 'schema'"):
            DatabaseConfig(backend="databricks", catalog="test", schema="")

    def test_negative_timeout(self):
        """Test that negative timeout raises error."""
        with pytest.raises(ValueError, match="timeout must be positive"):
            DatabaseConfig(backend="sqlite", db_path="test.db", timeout=-1)

    def test_zero_timeout(self):
        """Test that zero timeout raises error."""
        with pytest.raises(ValueError, match="timeout must be positive"):
            DatabaseConfig(backend="sqlite", db_path="test.db", timeout=0)

    def test_negative_pool_size(self):
        """Test that negative pool_size raises error."""
        with pytest.raises(ValueError, match="pool_size must be positive"):
            DatabaseConfig(backend="sqlite", db_path="test.db", pool_size=-1)

    def test_zero_pool_size(self):
        """Test that zero pool_size raises error."""
        with pytest.raises(ValueError, match="pool_size must be positive"):
            DatabaseConfig(backend="sqlite", db_path="test.db", pool_size=0)

    def test_negative_max_overflow(self):
        """Test that negative max_overflow raises error."""
        with pytest.raises(ValueError, match="max_overflow must be non-negative"):
            DatabaseConfig(backend="sqlite", db_path="test.db", max_overflow=-1)

    def test_zero_max_overflow_allowed(self):
        """Test that zero max_overflow is allowed."""
        config = DatabaseConfig(backend="sqlite", db_path="test.db", max_overflow=0)
        assert config.max_overflow == 0


# =============================================================================
# Test Environment Variable Loading
# =============================================================================

class TestFromEnv:
    """Test loading configuration from environment variables."""

    def test_from_env_sqlite_minimal(self, clean_env):
        """Test loading minimal SQLite config from env."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", "databases/test.db")

        config = DatabaseConfig.from_env()

        assert config.backend == "sqlite"
        assert config.db_path == "databases/test.db"
        assert config.timeout == 30.0  # Default

    def test_from_env_sqlite_full(self, clean_env):
        """Test loading full SQLite config from env."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", "databases/test.db")
        clean_env.setenv("DATABASE_TIMEOUT", "60")
        clean_env.setenv("DATABASE_FOREIGN_KEYS", "false")
        clean_env.setenv("DATABASE_JOURNAL_MODE", "DELETE")
        clean_env.setenv("DATABASE_POOL_SIZE", "10")
        clean_env.setenv("DATABASE_MAX_OVERFLOW", "20")
        clean_env.setenv("DATABASE_ECHO_SQL", "true")

        config = DatabaseConfig.from_env()

        assert config.backend == "sqlite"
        assert config.db_path == "databases/test.db"
        assert config.timeout == 60.0
        assert config.enable_foreign_keys is False
        assert config.journal_mode == "DELETE"
        assert config.pool_size == 10
        assert config.max_overflow == 20
        assert config.echo_sql is True

    def test_from_env_databricks_minimal(self, clean_env):
        """Test loading minimal Databricks config from env."""
        clean_env.setenv("DATABASE_BACKEND", "databricks")
        clean_env.setenv("DATABASE_CATALOG", "prod_catalog")
        clean_env.setenv("DATABASE_SCHEMA", "faq_schema")

        config = DatabaseConfig.from_env()

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"
        assert config.cluster_id is None

    def test_from_env_databricks_full(self, clean_env):
        """Test loading full Databricks config from env."""
        clean_env.setenv("DATABASE_BACKEND", "databricks")
        clean_env.setenv("DATABASE_CATALOG", "prod_catalog")
        clean_env.setenv("DATABASE_SCHEMA", "faq_schema")
        clean_env.setenv("DATABASE_CLUSTER_ID", "cluster-123")
        clean_env.setenv("DATABASE_POOL_SIZE", "20")
        clean_env.setenv("DATABASE_MAX_OVERFLOW", "40")
        clean_env.setenv("DATABASE_ECHO_SQL", "yes")

        config = DatabaseConfig.from_env()

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"
        assert config.cluster_id == "cluster-123"
        assert config.pool_size == 20
        assert config.max_overflow == 40
        assert config.echo_sql is True

    def test_from_env_auto_detect_databricks(self, clean_env):
        """Test auto-detection of Databricks environment."""
        # Don't set DATABASE_BACKEND, but set DATABRICKS_RUNTIME_VERSION
        clean_env.setenv("DATABRICKS_RUNTIME_VERSION", "13.3")
        clean_env.setenv("DATABASE_CATALOG", "prod_catalog")
        clean_env.setenv("DATABASE_SCHEMA", "faq_schema")

        config = DatabaseConfig.from_env()

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"

    def test_from_env_auto_detect_sqlite_default(self, clean_env):
        """Test auto-detection defaults to SQLite."""
        # No DATABASE_BACKEND and no DATABRICKS_RUNTIME_VERSION
        # Should default to SQLite

        config = DatabaseConfig.from_env()

        assert config.backend == "sqlite"
        assert config.db_path == "databases/granular_impact.db"  # Default

    def test_from_env_boolean_variants(self, clean_env):
        """Test different boolean string formats."""
        test_cases = [
            ("true", True),
            ("True", True),
            ("TRUE", True),
            ("1", True),
            ("yes", True),
            ("on", True),
            ("false", False),
            ("False", False),
            ("FALSE", False),
            ("0", False),
            ("no", False),
            ("off", False),
        ]

        for value, expected in test_cases:
            clean_env.setenv("DATABASE_BACKEND", "sqlite")
            clean_env.setenv("DATABASE_PATH", "test.db")
            clean_env.setenv("DATABASE_ECHO_SQL", value)

            config = DatabaseConfig.from_env()
            assert config.echo_sql == expected, f"Failed for value: {value}"

    def test_from_env_numeric_parsing(self, clean_env):
        """Test numeric string parsing."""
        clean_env.setenv("DATABASE_BACKEND", "sqlite")
        clean_env.setenv("DATABASE_PATH", "test.db")
        clean_env.setenv("DATABASE_TIMEOUT", "45.5")
        clean_env.setenv("DATABASE_POOL_SIZE", "15")

        config = DatabaseConfig.from_env()

        assert config.timeout == 45.5  # Parsed as float
        assert config.pool_size == 15  # Parsed as int

    def test_from_env_custom_prefix(self, clean_env):
        """Test using custom environment variable prefix."""
        clean_env.setenv("MYAPP_BACKEND", "sqlite")
        clean_env.setenv("MYAPP_PATH", "databases/custom.db")

        config = DatabaseConfig.from_env(prefix="MYAPP_")

        assert config.backend == "sqlite"
        assert config.db_path == "databases/custom.db"


# =============================================================================
# Test YAML Loading
# =============================================================================

class TestFromYaml:
    """Test loading configuration from YAML files."""

    def test_from_yaml_sqlite(self, temp_yaml_file):
        """Test loading SQLite config from YAML."""
        yaml_content = {
            "database": {
                "backend": "sqlite",
                "db_path": "databases/test.db",
                "timeout": 60,
                "enable_foreign_keys": True,
                "journal_mode": "WAL"
            }
        }

        with open(temp_yaml_file, 'w') as f:
            yaml.dump(yaml_content, f)

        config = DatabaseConfig.from_yaml(temp_yaml_file)

        assert config.backend == "sqlite"
        assert config.db_path == "databases/test.db"
        assert config.timeout == 60
        assert config.enable_foreign_keys is True
        assert config.journal_mode == "WAL"

    def test_from_yaml_databricks(self, temp_yaml_file):
        """Test loading Databricks config from YAML."""
        yaml_content = {
            "database": {
                "backend": "databricks",
                "catalog": "prod_catalog",
                "schema": "faq_schema",
                "cluster_id": "cluster-123",
                "pool_size": 20
            }
        }

        with open(temp_yaml_file, 'w') as f:
            yaml.dump(yaml_content, f)

        config = DatabaseConfig.from_yaml(temp_yaml_file)

        assert config.backend == "databricks"
        assert config.catalog == "prod_catalog"
        assert config.schema == "faq_schema"
        assert config.cluster_id == "cluster-123"
        assert config.pool_size == 20

    def test_from_yaml_nonexistent_file(self):
        """Test loading from nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            DatabaseConfig.from_yaml(Path("nonexistent_file.yaml"))

    def test_from_yaml_invalid_yaml(self, temp_yaml_file):
        """Test loading invalid YAML raises error."""
        with open(temp_yaml_file, 'w') as f:
            f.write("invalid: yaml: content: [unclosed")

        with pytest.raises(Exception):  # yaml.YAMLError
            DatabaseConfig.from_yaml(temp_yaml_file)

    def test_from_yaml_missing_database_key(self, temp_yaml_file):
        """Test YAML without 'database' key raises error."""
        yaml_content = {
            "other_key": {
                "backend": "sqlite",
                "db_path": "test.db"
            }
        }

        with open(temp_yaml_file, 'w') as f:
            yaml.dump(yaml_content, f)

        with pytest.raises(ValueError, match="YAML must contain 'database' key"):
            DatabaseConfig.from_yaml(temp_yaml_file)


# =============================================================================
# Test Dictionary Loading
# =============================================================================

class TestFromDict:
    """Test loading configuration from dictionaries."""

    def test_from_dict_sqlite(self, sqlite_config_dict):
        """Test loading SQLite config from dict."""
        config = DatabaseConfig.from_dict(sqlite_config_dict)

        assert config.backend == "sqlite"
        assert config.db_path == "databases/test.db"
        assert config.timeout == 30.0
        assert config.enable_foreign_keys is True

    def test_from_dict_databricks(self, databricks_config_dict):
        """Test loading Databricks config from dict."""
        config = DatabaseConfig.from_dict(databricks_config_dict)

        assert config.backend == "databricks"
        assert config.catalog == "test_catalog"
        assert config.schema == "test_schema"
        assert config.cluster_id == "test-cluster-123"

    def test_from_dict_minimal(self):
        """Test loading minimal config from dict."""
        config_dict = {
            "backend": "sqlite",
            "db_path": "test.db"
        }

        config = DatabaseConfig.from_dict(config_dict)

        assert config.backend == "sqlite"
        assert config.db_path == "test.db"
        # Should have defaults
        assert config.pool_size == 5
        assert config.timeout == 30.0

    def test_from_dict_with_extra_keys(self):
        """Test from_dict raises error on unknown keys."""
        config_dict = {
            "backend": "sqlite",
            "db_path": "test.db",
            "unknown_key": "should_cause_error",
            "another_unknown": 123
        }

        # from_dict passes kwargs directly, so unknown keys raise TypeError
        with pytest.raises(TypeError, match="unexpected keyword argument"):
            DatabaseConfig.from_dict(config_dict)


# =============================================================================
# Test Helper Methods
# =============================================================================

class TestHelperMethods:
    """Test configuration helper methods."""

    def test_is_sqlite(self):
        """Test is_sqlite() helper."""
        sqlite_config = DatabaseConfig(backend="sqlite", db_path="test.db")
        databricks_config = DatabaseConfig(
            backend="databricks",
            catalog="test",
            schema="test"
        )

        assert sqlite_config.is_sqlite() is True
        assert databricks_config.is_sqlite() is False

    def test_is_databricks(self):
        """Test is_databricks() helper."""
        sqlite_config = DatabaseConfig(backend="sqlite", db_path="test.db")
        databricks_config = DatabaseConfig(
            backend="databricks",
            catalog="test",
            schema="test"
        )

        assert sqlite_config.is_databricks() is False
        assert databricks_config.is_databricks() is True

    def test_get_connection_string_sqlite(self):
        """Test get_connection_string() for SQLite."""
        config = DatabaseConfig(backend="sqlite", db_path="databases/test.db")

        conn_str = config.get_connection_string()

        assert "sqlite" in conn_str.lower()
        assert "databases/test.db" in conn_str

    def test_get_connection_string_databricks(self):
        """Test get_connection_string() for Databricks."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="prod_catalog",
            schema="faq_schema"
        )

        conn_str = config.get_connection_string()

        assert "databricks" in conn_str.lower() or "spark" in conn_str.lower()
        assert "prod_catalog" in conn_str
        assert "faq_schema" in conn_str


# =============================================================================
# Test Export Methods
# =============================================================================

class TestExportMethods:
    """Test configuration export methods."""

    def test_to_dict_sqlite(self):
        """Test exporting SQLite config to dict."""
        config = DatabaseConfig(
            backend="sqlite",
            db_path="databases/test.db",
            timeout=60.0,
            pool_size=10
        )

        config_dict = config.to_dict()

        assert isinstance(config_dict, dict)
        assert config_dict["backend"] == "sqlite"
        assert config_dict["db_path"] == "databases/test.db"
        assert config_dict["timeout"] == 60.0
        assert config_dict["pool_size"] == 10

    def test_to_dict_databricks(self):
        """Test exporting Databricks config to dict."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="prod_catalog",
            schema="faq_schema",
            cluster_id="cluster-123"
        )

        config_dict = config.to_dict()

        assert config_dict["backend"] == "databricks"
        assert config_dict["catalog"] == "prod_catalog"
        assert config_dict["schema"] == "faq_schema"
        assert config_dict["cluster_id"] == "cluster-123"

    def test_to_yaml_sqlite(self, temp_yaml_file):
        """Test exporting SQLite config to YAML."""
        config = DatabaseConfig(
            backend="sqlite",
            db_path="databases/test.db",
            timeout=60.0
        )

        config.to_yaml(temp_yaml_file)

        # Read back and verify
        with open(temp_yaml_file, 'r') as f:
            loaded = yaml.safe_load(f)

        assert "database" in loaded
        assert loaded["database"]["backend"] == "sqlite"
        assert loaded["database"]["db_path"] == "databases/test.db"
        assert loaded["database"]["timeout"] == 60.0

    def test_to_yaml_databricks(self, temp_yaml_file):
        """Test exporting Databricks config to YAML."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="prod_catalog",
            schema="faq_schema"
        )

        config.to_yaml(temp_yaml_file)

        # Read back and verify
        with open(temp_yaml_file, 'r') as f:
            loaded = yaml.safe_load(f)

        assert loaded["database"]["backend"] == "databricks"
        assert loaded["database"]["catalog"] == "prod_catalog"
        assert loaded["database"]["schema"] == "faq_schema"

    def test_roundtrip_yaml(self, temp_yaml_file):
        """Test config can be saved and loaded from YAML."""
        original_config = DatabaseConfig(
            backend="sqlite",
            db_path="databases/test.db",
            timeout=60.0,
            pool_size=10,
            echo_sql=True
        )

        # Save to YAML
        original_config.to_yaml(temp_yaml_file)

        # Load back
        loaded_config = DatabaseConfig.from_yaml(temp_yaml_file)

        # Verify all fields match
        assert loaded_config.backend == original_config.backend
        assert loaded_config.db_path == original_config.db_path
        assert loaded_config.timeout == original_config.timeout
        assert loaded_config.pool_size == original_config.pool_size
        assert loaded_config.echo_sql == original_config.echo_sql


# =============================================================================
# Test Edge Cases
# =============================================================================

class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_in_memory_sqlite(self):
        """Test in-memory SQLite database."""
        config = DatabaseConfig(backend="sqlite", db_path=":memory:")

        assert config.backend == "sqlite"
        assert config.db_path == ":memory:"

    def test_very_long_db_path(self):
        """Test config with very long path."""
        long_path = "databases/" + "a" * 500 + "/test.db"
        config = DatabaseConfig(backend="sqlite", db_path=long_path)

        assert config.db_path == long_path

    def test_special_characters_in_strings(self):
        """Test config with special characters."""
        config = DatabaseConfig(
            backend="databricks",
            catalog="catalog_with-dashes",
            schema="schema.with.dots",
            cluster_id="cluster/with/slashes"
        )

        assert config.catalog == "catalog_with-dashes"
        assert config.schema == "schema.with.dots"
        assert config.cluster_id == "cluster/with/slashes"

    def test_very_large_pool_sizes(self):
        """Test config with very large pool sizes."""
        config = DatabaseConfig(
            backend="sqlite",
            db_path="test.db",
            pool_size=10000,
            max_overflow=50000
        )

        assert config.pool_size == 10000
        assert config.max_overflow == 50000

    def test_config_equality(self):
        """Test that two identical configs are equal."""
        config1 = DatabaseConfig(backend="sqlite", db_path="test.db")
        config2 = DatabaseConfig(backend="sqlite", db_path="test.db")

        # Dataclasses with same values should be equal
        assert config1 == config2

    def test_config_hashing(self):
        """Test that configs with mutable fields are not hashable."""
        config = DatabaseConfig(backend="sqlite", db_path="test.db")

        # Config contains mutable 'extra' dict, so it's not hashable
        # This is expected behavior
        with pytest.raises(TypeError, match="unhashable type"):
            config_set = {config}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
