"""
Unit Tests for FAQ Generation Module

This module tests the faq_generation module including:
- QuestionGenerator class
- Prompt templates
- Function calling schemas
- Error handling and validation

Test Coverage:
- Initialization and configuration
- Document-based question generation (batch processing)
- Text-based question generation (single chunk processing)
- Error handling and edge cases
- Integration with oneailib components

Run tests:
    pytest tests/test_faq_generation.py -v
    pytest tests/test_faq_generation.py::TestQuestionGenerator -v

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
from oneailib.core.documents.base import Document

from faq_generation import (
    QuestionGenerator,
    QuestionGeneratorError,
    LLMGenerationError,
    create_question_generator,
)
from faq_generation.prompts import FAQ_QUESTION_GENERATION_PROMPT
from faq_generation.schemas import FAQ_QUESTION_GENERATION_SCHEMA


# =============================================================================
# Test Fixtures
# =============================================================================


@pytest.fixture
def sample_documents():
    """Create sample documents for testing."""
    return [
        Document(
            page_content="Health insurance enrollment period starts on January 1st.",
            metadata={"content_checksum": "abc123def456"}
        ),
        Document(
            page_content="Employees can add dependents to health insurance plans.",
            metadata={"content_checksum": "xyz789ghi012"}
        ),
    ]


@pytest.fixture
def sample_generated_questions():
    """Create sample generated question documents."""
    return [
        Document(
            page_content="",
            metadata={
                "question": "When does the health insurance enrollment period start?",
                "id": "q001",
                "version": "1.0",
                "content_checksum": "abc123def456",
                "status": "active"
            }
        ),
        Document(
            page_content="",
            metadata={
                "question": "Can dependents be added to health insurance plans?",
                "id": "q002",
                "version": "1.0",
                "content_checksum": "xyz789ghi012",
                "status": "active"
            }
        ),
    ]


@pytest.fixture
def question_generator():
    """Create a QuestionGenerator instance for testing."""
    return QuestionGenerator(
        chat_model_name="test-model",
        temperature=0.0,
        max_tokens=1000,
        max_retries=3,
        seconds_between_retries=1,
        max_questions=5,
    )


# =============================================================================
# Test QuestionGenerator Initialization
# =============================================================================


class TestQuestionGeneratorInit:
    """Test QuestionGenerator initialization and configuration."""

    def test_init_with_defaults(self):
        """Test initialization with default parameters."""
        gen = QuestionGenerator()
        assert gen.chat_model_name == "gpt-4o_2024-11-20-pgo-amrs"
        assert gen.temperature == 0.0
        assert gen.max_tokens == 4000
        assert gen.max_retries == 10
        assert gen.max_questions == 5

    def test_init_with_custom_params(self):
        """Test initialization with custom parameters."""
        gen = QuestionGenerator(
            chat_model_name="custom-model",
            temperature=0.7,
            max_tokens=2000,
            max_retries=5,
            max_questions=3,
        )
        assert gen.chat_model_name == "custom-model"
        assert gen.temperature == 0.7
        assert gen.max_tokens == 2000
        assert gen.max_retries == 5
        assert gen.max_questions == 3

    def test_init_invalid_temperature(self):
        """Test initialization with invalid temperature."""
        with pytest.raises(ValueError, match="temperature must be between"):
            QuestionGenerator(temperature=1.5)

        with pytest.raises(ValueError, match="temperature must be between"):
            QuestionGenerator(temperature=-0.1)

    def test_init_invalid_max_tokens(self):
        """Test initialization with invalid max_tokens."""
        with pytest.raises(ValueError, match="max_tokens must be positive"):
            QuestionGenerator(max_tokens=0)

        with pytest.raises(ValueError, match="max_tokens must be positive"):
            QuestionGenerator(max_tokens=-100)

    def test_init_invalid_max_retries(self):
        """Test initialization with invalid max_retries."""
        with pytest.raises(ValueError, match="max_retries must be non-negative"):
            QuestionGenerator(max_retries=-1)

    def test_init_invalid_max_questions(self):
        """Test initialization with invalid max_questions."""
        with pytest.raises(ValueError, match="max_questions must be positive"):
            QuestionGenerator(max_questions=0)


# =============================================================================
# Test QuestionGenerator - generate_from_documents
# =============================================================================


class TestGenerateFromDocuments:
    """Test the generate_from_documents method (batch processing)."""

    @patch('faq_generation.question_generator.AzureOpenAIChatModel')
    @patch('faq_generation.question_generator.DecomposeKeysTransformer')
    @patch('faq_generation.question_generator.AddDocumentIDTransformer')
    @patch('faq_generation.question_generator.AddDocumentVersionTransformer')
    def test_generate_from_documents_success(
        self,
        mock_version_transformer,
        mock_id_transformer,
        mock_decomposer,
        mock_llm,
        question_generator,
        sample_documents,
        sample_generated_questions,
    ):
        """Test successful question generation from documents."""
        # Setup mocks
        mock_llm_instance = Mock()
        mock_llm_instance.return_value = sample_generated_questions
        mock_llm.return_value = mock_llm_instance

        mock_decomposer_instance = Mock()
        mock_decomposer_instance.transform_documents.return_value = sample_generated_questions
        mock_decomposer.return_value = mock_decomposer_instance

        mock_id_instance = Mock()
        mock_id_instance.transform_documents.return_value = sample_generated_questions
        mock_id_transformer.return_value = mock_id_instance

        mock_version_instance = Mock()
        mock_version_instance.transform_documents.return_value = sample_generated_questions
        mock_version_transformer.return_value = mock_version_instance

        # Execute
        result = question_generator.generate_from_documents(sample_documents)

        # Verify
        assert len(result) == 2
        assert all(isinstance(doc, Document) for doc in result)
        mock_llm_instance.assert_called_once_with(sample_documents)
        mock_decomposer_instance.transform_documents.assert_called_once()
        mock_id_instance.transform_documents.assert_called_once()
        mock_version_instance.transform_documents.assert_called_once()

    @patch('faq_generation.question_generator.AzureOpenAIChatModel')
    def test_generate_from_documents_llm_failure(
        self,
        mock_llm,
        question_generator,
        sample_documents,
    ):
        """Test handling of LLM generation failure."""
        # Setup mock to raise exception
        mock_llm_instance = Mock()
        mock_llm_instance.side_effect = Exception("LLM API Error")
        mock_llm.return_value = mock_llm_instance

        # Execute and verify exception
        with pytest.raises(LLMGenerationError, match="Question generation failed"):
            question_generator.generate_from_documents(sample_documents)

    @patch('faq_generation.question_generator.AzureOpenAIChatModel')
    @patch('faq_generation.question_generator.DecomposeKeysTransformer')
    def test_generate_from_documents_without_ids(
        self,
        mock_decomposer,
        mock_llm,
        question_generator,
        sample_documents,
        sample_generated_questions,
    ):
        """Test question generation without adding IDs."""
        # Setup mocks
        mock_llm_instance = Mock()
        mock_llm_instance.return_value = sample_generated_questions
        mock_llm.return_value = mock_llm_instance

        mock_decomposer_instance = Mock()
        mock_decomposer_instance.transform_documents.return_value = sample_generated_questions
        mock_decomposer.return_value = mock_decomposer_instance

        # Execute with add_ids=False
        result = question_generator.generate_from_documents(
            sample_documents,
            add_ids=False,
            add_versions=False
        )

        # Verify - should not call ID or version transformers
        assert len(result) == 2


# =============================================================================
# Test QuestionGenerator - generate_from_text
# =============================================================================


class TestGenerateFromText:
    """Test the generate_from_text method (single chunk processing)."""

    @patch.object(QuestionGenerator, 'generate_from_documents')
    def test_generate_from_text_success(self, mock_generate_docs, question_generator):
        """Test successful question generation from text."""
        # Setup mock
        mock_question_docs = [
            Document(
                page_content="",
                metadata={
                    "question": "What is health insurance?",
                    "id": "q123",
                    "version": "1.0",
                    "content_checksum": "abc123",
                }
            )
        ]
        mock_generate_docs.return_value = mock_question_docs

        # Execute
        result = question_generator.generate_from_text(
            chunk_text="Health insurance information...",
            content_checksum="abc123"
        )

        # Verify
        assert len(result) == 1
        assert isinstance(result[0], dict)
        assert result[0]['question_text'] == "What is health insurance?"
        assert result[0]['question_id'] == "q123"
        assert result[0]['content_checksum'] == "abc123"
        assert result[0]['source_type'] == "document"
        assert result[0]['generation_method'] == "LLM"
        assert result[0]['status'] == "active"

    def test_generate_from_text_empty_chunk(self, question_generator):
        """Test error handling for empty chunk text."""
        with pytest.raises(ValueError, match="chunk_text cannot be empty"):
            question_generator.generate_from_text(
                chunk_text="",
                content_checksum="abc123"
            )

        with pytest.raises(ValueError, match="chunk_text cannot be empty"):
            question_generator.generate_from_text(
                chunk_text="   ",
                content_checksum="abc123"
            )

    def test_generate_from_text_empty_checksum(self, question_generator):
        """Test error handling for empty checksum."""
        with pytest.raises(ValueError, match="content_checksum cannot be empty"):
            question_generator.generate_from_text(
                chunk_text="Health insurance...",
                content_checksum=""
            )

    @patch.object(QuestionGenerator, 'generate_from_documents')
    def test_generate_from_text_with_custom_metadata(
        self,
        mock_generate_docs,
        question_generator
    ):
        """Test question generation with custom metadata."""
        # Setup mock
        mock_question_docs = [
            Document(
                page_content="",
                metadata={
                    "question": "Test question?",
                    "id": "q456",
                    "version": "1.0",
                }
            )
        ]
        mock_generate_docs.return_value = mock_question_docs

        # Execute with custom parameters
        result = question_generator.generate_from_text(
            chunk_text="Test content",
            content_checksum="xyz789",
            source_type="manual",
            generation_method="human",
            status="inactive"
        )

        # Verify custom metadata
        assert result[0]['source_type'] == "manual"
        assert result[0]['generation_method'] == "human"
        assert result[0]['status'] == "inactive"


# =============================================================================
# Test Utility Methods
# =============================================================================


class TestUtilityMethods:
    """Test utility methods of QuestionGenerator."""

    @patch.object(QuestionGenerator, 'generate_from_documents')
    def test_get_question_documents_as_dataframe(
        self,
        mock_generate,
        question_generator,
        sample_generated_questions
    ):
        """Test conversion of documents to DataFrame."""
        import pandas as pd

        df = question_generator.get_question_documents_as_dataframe(
            sample_generated_questions
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert 'question_text' in df.columns
        assert 'question_id' in df.columns
        assert 'source_type' in df.columns
        assert 'generation_method' in df.columns
        assert 'status' in df.columns

    @patch.object(QuestionGenerator, 'generate_from_documents')
    def test_get_question_sources_as_dataframe(
        self,
        mock_generate,
        question_generator,
        sample_generated_questions
    ):
        """Test conversion of question sources to DataFrame."""
        import pandas as pd

        df = question_generator.get_question_sources_as_dataframe(
            sample_generated_questions
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert 'question_id' in df.columns
        assert 'content_checksum' in df.columns
        assert 'is_primary_source' in df.columns
        assert 'contribution_weight' in df.columns
        assert 'is_valid' in df.columns


# =============================================================================
# Test Factory Functions
# =============================================================================


class TestFactoryFunctions:
    """Test factory functions."""

    def test_create_question_generator_default(self):
        """Test factory function with default parameters."""
        gen = create_question_generator()
        assert isinstance(gen, QuestionGenerator)
        assert gen.chat_model_name == "gpt-4o_2024-11-20-pgo-amrs"

    def test_create_question_generator_custom(self):
        """Test factory function with custom parameters."""
        gen = create_question_generator(
            model_name="custom-model",
            temperature=0.5,
            max_questions=3
        )
        assert isinstance(gen, QuestionGenerator)
        assert gen.chat_model_name == "custom-model"
        assert gen.temperature == 0.5
        assert gen.max_questions == 3


# =============================================================================
# Test Prompts and Schemas
# =============================================================================


class TestPromptsAndSchemas:
    """Test prompt templates and function calling schemas."""

    def test_question_generation_prompt_exists(self):
        """Test that question generation prompt is defined."""
        assert FAQ_QUESTION_GENERATION_PROMPT is not None
        assert hasattr(FAQ_QUESTION_GENERATION_PROMPT, 'input_variables')
        assert hasattr(FAQ_QUESTION_GENERATION_PROMPT, 'dialog_transcript')

    def test_question_generation_schema_exists(self):
        """Test that question generation schema is defined."""
        assert FAQ_QUESTION_GENERATION_SCHEMA is not None
        assert hasattr(FAQ_QUESTION_GENERATION_SCHEMA, 'name')
        assert hasattr(FAQ_QUESTION_GENERATION_SCHEMA, 'description')
        assert hasattr(FAQ_QUESTION_GENERATION_SCHEMA, 'parameters')

    def test_question_generation_prompt_variables(self):
        """Test that prompt has required input variables."""
        assert 'page_content' in FAQ_QUESTION_GENERATION_PROMPT.input_variables

    def test_question_generation_schema_structure(self):
        """Test that schema has correct structure."""
        assert FAQ_QUESTION_GENERATION_SCHEMA.name == "get_list_format"
        assert FAQ_QUESTION_GENERATION_SCHEMA.parameters.type == "object"
        assert "questions_for_single_cluster" in FAQ_QUESTION_GENERATION_SCHEMA.parameters.properties


# =============================================================================
# Integration Tests (Optional - require actual LLM access)
# =============================================================================


@pytest.mark.integration
@pytest.mark.skip(reason="Requires actual Azure OpenAI credentials")
class TestIntegration:
    """Integration tests with actual LLM (skipped by default)."""

    def test_real_question_generation(self):
        """Test actual question generation with real LLM."""
        # This test requires actual Azure OpenAI credentials
        # Only run with: pytest tests/test_faq_generation.py -m integration
        gen = QuestionGenerator()
        questions = gen.generate_from_text(
            chunk_text="Health insurance enrollment period starts January 1st.",
            content_checksum="test123"
        )
        assert len(questions) > 0
        assert all('question_text' in q for q in questions)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
