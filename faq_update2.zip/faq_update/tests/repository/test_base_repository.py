"""
Unit Tests for BaseRepository

Comprehensive tests for BaseRepository functionality including:
- Connection management
- Transaction support
- Error handling
- Retry logic
- Query result mapping
- Context managers

Author: Analytics Assist Team
Date: 2025-11-02
"""

import pytest
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import Mock, MagicMock, patch, call

from database.repository.base import (
    BaseRepository,
    RepositoryError,
    ConnectionError,
    TransactionError,
    QueryError,
    DataValidationError,
    RetryExhaustedError,
    RetryConfig,
)
from database.backends.base import (
    IBackend,
    BackendType,
    BackendError,
    ConnectionError as BackendConnectionError,
    QueryError as BackendQueryError,
    CommandError as BackendCommandError,
    TransactionError as BackendTransactionError,
)


# =============================================================================
# Test Fixtures
# =============================================================================


@dataclass
class User:
    """Sample domain model for testing."""
    id: int
    name: str
    email: str


class MockBackend(IBackend):
    """Mock backend for testing."""

    def __init__(self, should_fail: bool = False):
        super().__init__()
        self._backend_type = BackendType.SQLITE
        self._is_connected = False
        self.should_fail = should_fail

        # Track method calls
        self.connect_called = 0
        self.close_called = 0
        self.begin_transaction_called = 0
        self.commit_called = 0
        self.rollback_called = 0
        self.query_called = 0
        self.command_called = 0

    @property
    def backend_type(self) -> BackendType:
        return self._backend_type

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    def connect(self) -> None:
        self.connect_called += 1
        if self.should_fail:
            raise BackendConnectionError("Mock connection failed")
        self._is_connected = True

    def close(self) -> None:
        self.close_called += 1
        self._is_connected = False

    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        self.query_called += 1
        if self.should_fail:
            raise BackendQueryError("Mock query failed")

        # Mock some data
        if "users" in query.lower():
            return [
                {"id": 1, "name": "Alice", "email": "alice@example.com"},
                {"id": 2, "name": "Bob", "email": "bob@example.com"},
            ]
        return []

    def execute_query_single(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        results = self.execute_query(query, params, timeout)
        return results[0] if results else None

    def execute_command(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> int:
        self.command_called += 1
        if self.should_fail:
            raise BackendCommandError("Mock command failed")
        return 1  # Mock affected rows

    def execute_many(
        self,
        command: str,
        params_list: List[Tuple],
        timeout: Optional[int] = None
    ) -> int:
        return len(params_list)

    def ingest_dataframe(self, df, table_name: str, **kwargs) -> Dict[str, Any]:
        return {"success": True, "rows_inserted": len(df)}

    def read_table(self, table_name: str, **kwargs):
        import pandas as pd
        return pd.DataFrame()

    def begin_transaction(self) -> None:
        self.begin_transaction_called += 1

    def commit(self) -> None:
        self.commit_called += 1

    def rollback(self) -> None:
        self.rollback_called += 1

    def table_exists(self, table_name: str) -> bool:
        return True

    def get_table_schema(self, table_name: str) -> List[Dict[str, str]]:
        return []

    def list_tables(self) -> List[str]:
        return ["users", "posts"]

    def get_row_count(self, table_name: str, **kwargs) -> int:
        return 10

    def get_distinct_values(self, table_name: str, column: str, **kwargs) -> List[Any]:
        return ["value1", "value2"]


class TestRepository(BaseRepository[User]):
    """Concrete repository for testing."""

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID."""
        result = self.execute_query_single(
            "SELECT * FROM users WHERE id = ?",
            (user_id,)
        )
        return self.map_to_model(result, User) if result else None

    def get_all_users(self) -> List[User]:
        """Get all users."""
        results = self.execute_query("SELECT * FROM users")
        return self.map_to_models(results, User)

    def create_user(self, name: str, email: str) -> int:
        """Create user and return ID."""
        return self.execute_insert(
            "INSERT INTO users (name, email) VALUES (?, ?)",
            (name, email)
        )


# =============================================================================
# Test Cases
# =============================================================================


class TestBaseRepositoryInitialization:
    """Test repository initialization."""

    def test_init_with_valid_backend(self):
        """Test initialization with valid backend."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        assert repo.backend is backend
        assert not repo.is_connected
        assert isinstance(repo.retry_config, RetryConfig)

    def test_init_with_invalid_backend(self):
        """Test initialization with invalid backend type."""
        with pytest.raises(TypeError, match="must be an IBackend instance"):
            TestRepository("not a backend")

    def test_init_with_auto_connect(self):
        """Test auto-connect on initialization."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        assert repo.is_connected
        assert backend.connect_called == 1

    def test_init_with_auto_connect_failure(self):
        """Test auto-connect failure."""
        backend = MockBackend(should_fail=True)

        with pytest.raises(ConnectionError, match="Could not connect"):
            TestRepository(backend, auto_connect=True)

    def test_init_with_custom_retry_config(self):
        """Test initialization with custom retry config."""
        backend = MockBackend()
        retry_config = RetryConfig(max_attempts=5, initial_delay=0.5)
        repo = TestRepository(backend, retry_config=retry_config, auto_connect=False)

        assert repo.retry_config.max_attempts == 5
        assert repo.retry_config.initial_delay == 0.5


class TestConnectionManagement:
    """Test connection management (Point 79)."""

    def test_explicit_connect(self):
        """Test explicit connection."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        assert not repo.is_connected
        repo.connect()
        assert repo.is_connected
        assert backend.connect_called == 1

    def test_explicit_close(self):
        """Test explicit close."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        assert repo.is_connected
        repo.close()
        assert not repo.is_connected
        assert backend.close_called == 1

    def test_connection_context_manager(self):
        """Test connection context manager."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        assert not repo.is_connected

        with repo.connection():
            assert repo.is_connected
            # Connection active during context

        # Connection closed after context
        assert not repo.is_connected
        assert backend.connect_called == 1
        assert backend.close_called == 1

    def test_connection_context_manager_already_connected(self):
        """Test context manager when already connected."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        assert repo.is_connected
        initial_connect_count = backend.connect_called

        with repo.connection():
            assert repo.is_connected
            # Should not connect again

        # Should not close (was already connected)
        assert repo.is_connected
        assert backend.connect_called == initial_connect_count
        assert backend.close_called == 0


class TestTransactionManagement:
    """Test transaction management (Point 80)."""

    def test_transaction_success(self):
        """Test successful transaction."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        with repo.transaction():
            repo.execute_command("INSERT INTO users ...")

        assert backend.begin_transaction_called == 1
        assert backend.commit_called == 1
        assert backend.rollback_called == 0

    def test_transaction_rollback_on_error(self):
        """Test transaction rollback on error."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        with pytest.raises(TransactionError):
            with repo.transaction():
                # Simulate error
                raise ValueError("Something went wrong")

        assert backend.begin_transaction_called == 1
        assert backend.commit_called == 0
        assert backend.rollback_called == 1

    def test_transaction_with_query_error(self):
        """Test transaction rollback on query error."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        with pytest.raises(TransactionError):
            with repo.transaction():
                backend.should_fail = True
                repo.execute_command("INSERT INTO users ...")

        assert backend.rollback_called == 1


class TestErrorHandling:
    """Test error handling (Point 81)."""

    def test_backend_connection_error_wrapped(self):
        """Test BackendConnectionError wrapped as ConnectionError."""
        backend = MockBackend(should_fail=True)

        with pytest.raises(ConnectionError, match="Could not connect"):
            TestRepository(backend, auto_connect=True)

    def test_backend_query_error_wrapped(self):
        """Test BackendQueryError wrapped as QueryError."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        backend.should_fail = True

        with pytest.raises(QueryError, match="Query execution"):
            repo.execute_query("SELECT * FROM users")

    def test_backend_command_error_wrapped(self):
        """Test BackendCommandError wrapped as QueryError."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        backend.should_fail = True

        with pytest.raises(QueryError, match="Command execution"):
            repo.execute_command("INSERT INTO users ...")


class TestRetryLogic:
    """Test retry logic (Point 83)."""

    def test_retry_on_connection_error(self):
        """Test retry on connection errors."""
        backend = MockBackend()
        repo = TestRepository(
            backend,
            retry_config=RetryConfig(max_attempts=3, initial_delay=0.01),
            auto_connect=True
        )

        # Mock backend to fail first 2 times, then succeed
        call_count = [0]
        original_query = backend.execute_query

        def flaky_query(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                raise BackendQueryError("Database locked")
            return original_query(*args, **kwargs)

        backend.execute_query = flaky_query

        # Should succeed after retries
        results = repo.execute_query("SELECT * FROM users")
        assert len(results) == 2
        assert call_count[0] == 3  # Failed twice, succeeded third time

    def test_retry_exhausted(self):
        """Test retry exhaustion."""
        backend = MockBackend()
        repo = TestRepository(
            backend,
            retry_config=RetryConfig(max_attempts=3, initial_delay=0.01),
            auto_connect=True
        )

        # Mock backend to always fail
        backend.execute_query = Mock(side_effect=BackendQueryError("Database locked"))

        with pytest.raises(RetryExhaustedError, match="failed after 3 attempts"):
            repo.execute_query("SELECT * FROM users")

        # Should have tried 3 times
        assert backend.execute_query.call_count == 3

    def test_no_retry_for_non_retryable_errors(self):
        """Test no retry for non-retryable errors."""
        backend = MockBackend()
        repo = TestRepository(
            backend,
            retry_config=RetryConfig(max_attempts=3, initial_delay=0.01),
            auto_connect=True
        )

        # Mock backend to fail with non-retryable error
        backend.execute_query = Mock(side_effect=BackendQueryError("Syntax error"))

        with pytest.raises(QueryError, match="Query execution"):
            repo.execute_query("SELECT * FROM users")

        # Should have tried only once (no retry)
        assert backend.execute_query.call_count == 1

    def test_retry_disabled(self):
        """Test query with retry disabled."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        backend.execute_query = Mock(side_effect=BackendQueryError("Database locked"))

        with pytest.raises(QueryError):
            repo.execute_query("SELECT * FROM users", with_retry=False)

        # Should have tried only once
        assert backend.execute_query.call_count == 1


class TestQueryExecution:
    """Test query execution methods."""

    def test_execute_query_success(self):
        """Test successful query execution."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        results = repo.execute_query("SELECT * FROM users")

        assert len(results) == 2
        assert results[0]["name"] == "Alice"
        assert backend.query_called == 1

    def test_execute_query_single_one_result(self):
        """Test execute_query_single with one result."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        # Mock to return single result
        backend.execute_query = Mock(return_value=[
            {"id": 1, "name": "Alice", "email": "alice@example.com"}
        ])

        result = repo.execute_query_single("SELECT * FROM users WHERE id = 1")

        assert result is not None
        assert result["name"] == "Alice"

    def test_execute_query_single_no_result(self):
        """Test execute_query_single with no results."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        backend.execute_query = Mock(return_value=[])

        result = repo.execute_query_single("SELECT * FROM users WHERE id = 999")

        assert result is None

    def test_execute_query_single_multiple_results_error(self):
        """Test execute_query_single with multiple results."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        with pytest.raises(QueryError, match="expected to return 0 or 1 row"):
            repo.execute_query_single("SELECT * FROM users")

    def test_execute_command_success(self):
        """Test successful command execution."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        rows = repo.execute_command("UPDATE users SET name = 'Charlie' WHERE id = 1")

        assert rows == 1
        assert backend.command_called == 1

    def test_execute_insert_success(self):
        """Test successful insert with ID return."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        # Mock last_insert_rowid
        backend.execute_query = Mock(return_value=[{"id": 42}])

        user_id = repo.execute_insert(
            "INSERT INTO users (name, email) VALUES (?, ?)",
            ("Charlie", "charlie@example.com")
        )

        assert user_id == 42
        assert backend.command_called == 1

    def test_query_not_connected_error(self):
        """Test query when not connected."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        with pytest.raises(ConnectionError, match="not connected"):
            repo.execute_query("SELECT * FROM users")


class TestQueryResultMapping:
    """Test query result mapping (Point 84)."""

    def test_map_to_model_dataclass(self):
        """Test mapping dictionary to dataclass."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        data = {"id": 1, "name": "Alice", "email": "alice@example.com"}
        user = repo.map_to_model(data, User)

        assert isinstance(user, User)
        assert user.id == 1
        assert user.name == "Alice"
        assert user.email == "alice@example.com"

    def test_map_to_model_with_extra_fields(self):
        """Test mapping with extra fields (non-strict)."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        data = {
            "id": 1,
            "name": "Alice",
            "email": "alice@example.com",
            "extra_field": "ignored"
        }
        user = repo.map_to_model(data, User, strict=False)

        assert user.id == 1
        assert user.name == "Alice"

    def test_map_to_model_strict_with_extra_fields(self):
        """Test mapping with extra fields (strict mode)."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        data = {
            "id": 1,
            "name": "Alice",
            "email": "alice@example.com",
            "extra_field": "should_fail"
        }

        with pytest.raises(DataValidationError, match="Extra keys"):
            repo.map_to_model(data, User, strict=True)

    def test_map_to_models_list(self):
        """Test mapping list of dictionaries to models."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        data_list = [
            {"id": 1, "name": "Alice", "email": "alice@example.com"},
            {"id": 2, "name": "Bob", "email": "bob@example.com"},
        ]
        users = repo.map_to_models(data_list, User)

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"

    def test_model_to_dict_dataclass(self):
        """Test converting dataclass to dictionary."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        user = User(id=1, name="Alice", email="alice@example.com")
        data = repo.model_to_dict(user)

        assert isinstance(data, dict)
        assert data["id"] == 1
        assert data["name"] == "Alice"
        assert data["email"] == "alice@example.com"

    def test_model_to_dict_with_to_dict_method(self):
        """Test converting model with to_dict() method."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        class CustomModel:
            def __init__(self, value: str):
                self.value = value

            def to_dict(self):
                return {"value": self.value}

        model = CustomModel("test")
        data = repo.model_to_dict(model)

        assert data == {"value": "test"}


class TestContextManagers:
    """Test context manager support."""

    def test_repository_context_manager(self):
        """Test repository as context manager."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        assert not repo.is_connected

        with repo:
            assert repo.is_connected
            users = repo.get_all_users()
            assert len(users) == 2

        assert not repo.is_connected

    def test_nested_transaction_contexts(self):
        """Test nested transaction and connection contexts."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=False)

        with repo.connection():
            with repo.transaction():
                repo.execute_command("INSERT INTO users ...")
                assert repo.is_connected

        assert backend.begin_transaction_called == 1
        assert backend.commit_called == 1


class TestConcreteRepository:
    """Test concrete repository implementation."""

    def test_get_user_by_id(self):
        """Test get_user_by_id method."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        # Mock single result
        backend.execute_query = Mock(return_value=[
            {"id": 1, "name": "Alice", "email": "alice@example.com"}
        ])

        user = repo.get_user_by_id(1)

        assert user is not None
        assert isinstance(user, User)
        assert user.name == "Alice"

    def test_get_user_by_id_not_found(self):
        """Test get_user_by_id with non-existent ID."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        backend.execute_query = Mock(return_value=[])

        user = repo.get_user_by_id(999)

        assert user is None

    def test_get_all_users(self):
        """Test get_all_users method."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        users = repo.get_all_users()

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)

    def test_create_user(self):
        """Test create_user method."""
        backend = MockBackend()
        repo = TestRepository(backend, auto_connect=True)

        # Mock last_insert_rowid
        backend.execute_query = Mock(return_value=[{"id": 3}])

        user_id = repo.create_user("Charlie", "charlie@example.com")

        assert user_id == 3


class TestRetryConfigCalculation:
    """Test RetryConfig delay calculations."""

    def test_exponential_backoff(self):
        """Test exponential backoff calculation."""
        config = RetryConfig(
            max_attempts=5,
            initial_delay=0.1,
            exponential_base=2.0,
            jitter=False
        )

        delays = [config.get_delay(i) for i in range(5)]

        assert delays[0] == 0.1  # 0.1 * 2^0
        assert delays[1] == 0.2  # 0.1 * 2^1
        assert delays[2] == 0.4  # 0.1 * 2^2
        assert delays[3] == 0.8  # 0.1 * 2^3
        assert delays[4] == 1.6  # 0.1 * 2^4

    def test_max_delay_cap(self):
        """Test max_delay cap."""
        config = RetryConfig(
            max_attempts=10,
            initial_delay=1.0,
            max_delay=5.0,
            exponential_base=2.0,
            jitter=False
        )

        # Large attempt should be capped
        delay = config.get_delay(10)
        assert delay == 5.0

    def test_jitter_adds_randomness(self):
        """Test that jitter adds randomness."""
        config = RetryConfig(
            max_attempts=3,
            initial_delay=1.0,
            jitter=True
        )

        # Get multiple delays for same attempt
        delays = [config.get_delay(1) for _ in range(10)]

        # Should have different values due to jitter
        assert len(set(delays)) > 1

        # All should be within range [0.5 * base_delay, 1.5 * base_delay]
        base_delay = 2.0  # initial_delay * 2^1
        assert all(0.5 * base_delay <= d <= 1.5 * base_delay for d in delays)


# =============================================================================
# Run Tests
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
