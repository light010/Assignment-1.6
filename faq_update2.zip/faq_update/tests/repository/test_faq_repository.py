"""
Integration Tests for FAQRepository

Comprehensive tests for FAQRepository functionality including:
- Question retrieval operations (Point 107)
- Answer retrieval operations (Point 108)
- Checksum-based FAQ lookup (Point 109)
- Question ingestion (Point 110)
- Answer ingestion (Point 111)
- FAQ status updates (Point 112)
- FAQ statistics (Point 113)
- FAQ validation (Point 114)
- Question source linking (Point 117)
- Answer source linking (Point 118)
- Question source retrieval (Point 119)
- Answer source retrieval (Point 120)
- Question source ingestion (Point 121)
- Answer source ingestion (Point 122)
- Provenance validation (Point 123)
- Source tracking and lineage (Point 124)

Tests use an in-memory SQLite database for fast, isolated testing.

Points covered: 107-125 from migration plan (sections D & E)

Author: Analytics Assist Team
Date: 2025-11-02
"""

import pytest
import pandas as pd
from datetime import datetime
from typing import Dict, Any
import hashlib

from database.repository.faq_repository import (
    FAQRepository,
    FAQRepositoryError,
    QuestionNotFoundError,
    AnswerNotFoundError,
    SourceNotFoundError,
    DuplicateQuestionError,
    DuplicateAnswerError,
    ForeignKeyViolationError,
    ProvenanceValidationError,
)
from database.repository.base import (
    DataValidationError,
    QueryError,
)
from database.backends.sqlite.backend import SQLiteBackend
from database.config import DatabaseConfig
from database.models import (
    FAQStatus,
    SourceType,
    GenerationMethod,
    InvalidationReason,
    AnswerFormat,
)


# =============================================================================
# Test Fixtures
# =============================================================================


@pytest.fixture
def in_memory_backend():
    """Create an in-memory SQLite backend for testing."""
    config = DatabaseConfig(
        backend="sqlite",
        db_path=":memory:"  # In-memory database
    )
    backend = SQLiteBackend(config)
    backend.connect()

    # Create FAQ questions table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_questions (
            question_id TEXT PRIMARY KEY,
            question_text TEXT NOT NULL,
            source_type TEXT,
            generation_method TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create FAQ answers table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_answers (
            answer_id TEXT PRIMARY KEY,
            question_id TEXT NOT NULL,
            answer_text TEXT NOT NULL,
            answer_format TEXT DEFAULT 'html',
            confidence_score REAL,
            status TEXT NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        )
    """)

    # Create FAQ question sources table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_question_sources (
            question_id TEXT NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source INTEGER DEFAULT 0,
            contribution_weight REAL,
            is_valid INTEGER DEFAULT 1,
            valid_from DATETIME NOT NULL,
            valid_until DATETIME,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (question_id, content_checksum),
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        )
    """)

    # Create FAQ answer sources table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_answer_sources (
            answer_id TEXT NOT NULL,
            content_checksum TEXT NOT NULL,
            is_primary_source INTEGER DEFAULT 0,
            contribution_weight REAL,
            context_employed TEXT,
            is_valid INTEGER DEFAULT 1,
            valid_from DATETIME NOT NULL,
            valid_until DATETIME,
            invalidation_reason TEXT,
            invalidated_by_change_id INTEGER,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (answer_id, content_checksum),
            FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        )
    """)

    # Create content_chunks table for FK validation
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            content_checksum TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    yield backend

    backend.close()


@pytest.fixture
def faq_repo(in_memory_backend):
    """Create FAQRepository with in-memory backend."""
    return FAQRepository(in_memory_backend, auto_connect=False)


@pytest.fixture
def sample_questions_df():
    """Create sample questions DataFrame for testing."""
    return pd.DataFrame({
        'question_id': ['Q001', 'Q002', 'Q003'],
        'question_text': [
            'What is the refund policy?',
            'How do I reset my password?',
            'Where can I find documentation?'
        ],
        'source_type': ['from_documents', 'from_user_queries', 'from_manual'],
        'generation_method': ['llm_generated', 'llm_generated', 'human_written'],
        'status': ['active', 'active', 'active']
    })


@pytest.fixture
def sample_answers_df():
    """Create sample answers DataFrame for testing."""
    return pd.DataFrame({
        'answer_id': ['A001', 'A002', 'A003'],
        'question_id': ['Q001', 'Q002', 'Q003'],
        'answer_text': [
            'Our refund policy allows returns within 30 days...',
            'You can reset your password by clicking...',
            'Documentation is available at docs.example.com'
        ],
        'answer_format': ['html', 'markdown', 'plain'],
        'confidence_score': [0.95, 0.88, 1.0],
        'status': ['active', 'active', 'active']
    })


@pytest.fixture
def sample_checksums():
    """Create sample content checksums for testing."""
    return [
        hashlib.sha256(f'content {i}'.encode('utf-8')).hexdigest()
        for i in range(5)
    ]


# =============================================================================
# Question Retrieval Tests (Point 107)
# =============================================================================


class TestQuestionRetrieval:
    """Test question retrieval operations (Point 107)."""

    def test_get_question_by_id_not_found(self, faq_repo):
        """Test getting non-existent question returns None."""
        result = faq_repo.get_question_by_id("Q999")
        assert result is None

    def test_get_question_by_id_success(self, faq_repo, sample_questions_df):
        """Test getting question by ID returns correct question."""
        # Insert test question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Retrieve question
        result = faq_repo.get_question_by_id("Q001")

        assert result is not None
        assert result['question_id'] == "Q001"
        assert result['question_text'] == "What is the refund policy?"
        assert result['status'] == "active"

    def test_get_question_by_id_empty_raises(self, faq_repo):
        """Test that empty question ID raises ValueError."""
        with pytest.raises(ValueError, match="question_id cannot be empty"):
            faq_repo.get_question_by_id("")

        with pytest.raises(ValueError, match="question_id cannot be empty"):
            faq_repo.get_question_by_id("   ")


# =============================================================================
# Answer Retrieval Tests (Point 108)
# =============================================================================


class TestAnswerRetrieval:
    """Test answer retrieval operations (Point 108)."""

    def test_get_answer_by_id_not_found(self, faq_repo):
        """Test getting non-existent answer returns None."""
        result = faq_repo.get_answer_by_id("A999")
        assert result is None

    def test_get_answer_by_id_success(self, faq_repo, sample_questions_df, sample_answers_df):
        """Test getting answer by ID returns correct answer."""
        # Insert test data
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        # Retrieve answer
        result = faq_repo.get_answer_by_id("A001")

        assert result is not None
        assert result['answer_id'] == "A001"
        assert result['question_id'] == "Q001"
        assert 'refund policy' in result['answer_text']

    def test_get_answer_by_id_empty_raises(self, faq_repo):
        """Test that empty answer ID raises ValueError."""
        with pytest.raises(ValueError, match="answer_id cannot be empty"):
            faq_repo.get_answer_by_id("")

    def test_get_answer_by_question_id_success(self, faq_repo, sample_questions_df, sample_answers_df):
        """Test getting answer by question ID."""
        # Insert test data
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        # Retrieve answer by question ID
        result = faq_repo.get_answer_by_question_id("Q001")

        assert result is not None
        assert result['answer_id'] == "A001"
        assert result['question_id'] == "Q001"

    def test_get_answer_by_question_id_not_found(self, faq_repo):
        """Test getting answer for non-existent question."""
        result = faq_repo.get_answer_by_question_id("Q999")
        assert result is None


# =============================================================================
# Checksum-based FAQ Lookup Tests (Point 109)
# =============================================================================


class TestChecksumFAQLookup:
    """Test checksum-based FAQ lookup (Point 109)."""

    def test_get_faqs_by_checksum_empty(self, faq_repo, sample_checksums):
        """Test getting FAQs for checksum with no results."""
        result = faq_repo.get_faqs_by_checksum(sample_checksums[0])

        assert result['total_questions'] == 0
        assert result['total_answers'] == 0
        assert result['questions'] == []
        assert result['answers'] == []

    def test_get_faqs_by_checksum_invalid_checksum_raises(self, faq_repo):
        """Test that invalid checksum raises ValueError."""
        # Too short
        with pytest.raises(ValueError, match="must be 64 characters"):
            faq_repo.get_faqs_by_checksum("abc123")

        # Empty
        with pytest.raises(ValueError, match="must be a non-empty string"):
            faq_repo.get_faqs_by_checksum("")

    def test_get_faqs_by_checksum_with_sources(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test getting FAQs linked to a checksum."""
        # Insert questions and answers
        faq_repo.ingest_questions(sample_questions_df.head(2))
        faq_repo.ingest_answers(sample_answers_df.head(2))

        # Link question to checksum
        checksum = sample_checksums[0]
        faq_repo.link_question_sources("Q001", [checksum])

        # Link answer to checksum
        faq_repo.link_answer_sources("A001", [checksum])

        # Get FAQs by checksum
        result = faq_repo.get_faqs_by_checksum(checksum)

        assert result['total_questions'] == 1
        assert result['total_answers'] == 1
        assert result['questions'][0]['question_id'] == "Q001"
        assert result['answers'][0]['answer_id'] == "A001"

    def test_get_faqs_by_checksum_exclude_invalid(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test excluding invalidated sources."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Link question sources
        checksum = sample_checksums[0]
        sources_df = pd.DataFrame({
            'question_id': ['Q001'],
            'content_checksum': [checksum],
            'is_valid': [0],  # Invalid
            'valid_from': [datetime.now()]
        })
        faq_repo.ingest_question_sources(sources_df, validate=False, validate_fk=False)

        # Get FAQs (should exclude invalid by default)
        result = faq_repo.get_faqs_by_checksum(checksum)

        assert result['total_questions'] == 0

        # Get FAQs including invalid
        result_with_invalid = faq_repo.get_faqs_by_checksum(checksum, include_invalid=True)

        assert result_with_invalid['total_questions'] == 1


# =============================================================================
# Question Ingestion Tests (Point 110)
# =============================================================================


class TestQuestionIngestion:
    """Test question ingestion operations (Point 110)."""

    def test_ingest_questions_success(self, faq_repo, sample_questions_df):
        """Test successful bulk question ingestion."""
        result = faq_repo.ingest_questions(sample_questions_df)

        assert result['success'] is True
        assert result['rows_inserted'] == 3

        # Verify questions were inserted
        question = faq_repo.get_question_by_id("Q001")
        assert question is not None
        assert question['question_text'] == "What is the refund policy?"

    def test_ingest_questions_empty_raises(self, faq_repo):
        """Test that empty DataFrame raises error."""
        empty_df = pd.DataFrame()

        with pytest.raises(DataValidationError, match="Cannot ingest empty DataFrame"):
            faq_repo.ingest_questions(empty_df)

    def test_ingest_questions_missing_column_raises(self, faq_repo):
        """Test that missing required column raises error."""
        df = pd.DataFrame({
            'question_id': ['Q001']
            # Missing question_text
        })

        with pytest.raises(DataValidationError, match="Missing required columns"):
            faq_repo.ingest_questions(df)

    def test_ingest_questions_invalid_status_raises(self, faq_repo):
        """Test that invalid status raises error."""
        df = pd.DataFrame({
            'question_id': ['Q001'],
            'question_text': ['Test question?'],
            'status': ['invalid_status']
        })

        with pytest.raises(DataValidationError, match="Invalid status values"):
            faq_repo.ingest_questions(df)

    def test_ingest_questions_null_id_raises(self, faq_repo):
        """Test that null question_id raises error."""
        df = pd.DataFrame({
            'question_id': [None],
            'question_text': ['Test question?']
        })

        with pytest.raises(DataValidationError, match="null question_id"):
            faq_repo.ingest_questions(df)

    def test_ingest_questions_empty_text_raises(self, faq_repo):
        """Test that empty question_text raises error."""
        df = pd.DataFrame({
            'question_id': ['Q001'],
            'question_text': ['   ']  # Empty after strip
        })

        with pytest.raises(DataValidationError, match="empty question_text"):
            faq_repo.ingest_questions(df)

    def test_ingest_questions_adds_defaults(self, faq_repo):
        """Test that ingestion adds default values."""
        df = pd.DataFrame({
            'question_id': ['Q001'],
            'question_text': ['Test question?']
            # No status, created_at, modified_at
        })

        result = faq_repo.ingest_questions(df)
        assert result['success'] is True

        # Verify defaults were added
        question = faq_repo.get_question_by_id("Q001")
        assert question['status'] == 'active'
        assert question['created_at'] is not None
        assert question['modified_at'] is not None


# =============================================================================
# Answer Ingestion Tests (Point 111)
# =============================================================================


class TestAnswerIngestion:
    """Test answer ingestion operations (Point 111)."""

    def test_ingest_answers_success(self, faq_repo, sample_questions_df, sample_answers_df):
        """Test successful bulk answer ingestion."""
        # Insert questions first
        faq_repo.ingest_questions(sample_questions_df)

        # Insert answers
        result = faq_repo.ingest_answers(sample_answers_df)

        assert result['success'] is True
        assert result['rows_inserted'] == 3

        # Verify answers were inserted
        answer = faq_repo.get_answer_by_id("A001")
        assert answer is not None
        assert answer['question_id'] == "Q001"

    def test_ingest_answers_empty_raises(self, faq_repo):
        """Test that empty DataFrame raises error."""
        empty_df = pd.DataFrame()

        with pytest.raises(DataValidationError, match="Cannot ingest empty DataFrame"):
            faq_repo.ingest_answers(empty_df)

    def test_ingest_answers_missing_column_raises(self, faq_repo):
        """Test that missing required column raises error."""
        df = pd.DataFrame({
            'answer_id': ['A001'],
            'question_id': ['Q001']
            # Missing answer_text
        })

        with pytest.raises(DataValidationError, match="Missing required columns"):
            faq_repo.ingest_answers(df)

    def test_ingest_answers_fk_violation_raises(self, faq_repo, sample_answers_df):
        """Test that FK violation raises error."""
        # Try to insert answers without questions
        with pytest.raises(ForeignKeyViolationError, match="Foreign key violation"):
            faq_repo.ingest_answers(sample_answers_df, validate_fk=True)

    def test_ingest_answers_invalid_confidence_score_raises(self, faq_repo, sample_questions_df):
        """Test that invalid confidence_score raises error."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Try to insert answer with invalid score
        df = pd.DataFrame({
            'answer_id': ['A001'],
            'question_id': ['Q001'],
            'answer_text': ['Test answer'],
            'confidence_score': [1.5]  # Invalid (> 1.0)
        })

        with pytest.raises(DataValidationError, match="invalid confidence_score"):
            faq_repo.ingest_answers(df)

    def test_ingest_answers_adds_defaults(self, faq_repo, sample_questions_df):
        """Test that ingestion adds default values."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        df = pd.DataFrame({
            'answer_id': ['A001'],
            'question_id': ['Q001'],
            'answer_text': ['Test answer']
            # No status, answer_format, created_at, modified_at
        })

        result = faq_repo.ingest_answers(df)
        assert result['success'] is True

        # Verify defaults were added
        answer = faq_repo.get_answer_by_id("A001")
        assert answer['status'] == 'active'
        assert answer['answer_format'] == 'html'
        assert answer['created_at'] is not None


# =============================================================================
# FAQ Status Update Tests (Point 112)
# =============================================================================


class TestFAQStatusUpdate:
    """Test FAQ status update operations (Point 112)."""

    def test_update_question_status_success(self, faq_repo, sample_questions_df):
        """Test updating question status."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Update status
        rows = faq_repo.update_faq_status("Q001", "invalidated", faq_type="question")

        assert rows == 1

        # Verify update
        question = faq_repo.get_question_by_id("Q001")
        assert question['status'] == "invalidated"

    def test_update_answer_status_success(self, faq_repo, sample_questions_df, sample_answers_df):
        """Test updating answer status."""
        # Insert data
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        # Update status
        rows = faq_repo.update_faq_status("A001", "archived", faq_type="answer")

        assert rows == 1

        # Verify update
        answer = faq_repo.get_answer_by_id("A001")
        assert answer['status'] == "archived"

    def test_update_status_not_found_raises(self, faq_repo):
        """Test updating non-existent FAQ raises error."""
        with pytest.raises(QuestionNotFoundError, match="not found"):
            faq_repo.update_faq_status("Q999", "archived", faq_type="question")

        with pytest.raises(AnswerNotFoundError, match="not found"):
            faq_repo.update_faq_status("A999", "archived", faq_type="answer")

    def test_update_status_invalid_status_raises(self, faq_repo, sample_questions_df):
        """Test that invalid status raises error."""
        faq_repo.ingest_questions(sample_questions_df.head(1))

        with pytest.raises(DataValidationError, match="Invalid status"):
            faq_repo.update_faq_status("Q001", "invalid_status", faq_type="question")

    def test_update_status_invalid_faq_type_raises(self, faq_repo):
        """Test that invalid faq_type raises error."""
        with pytest.raises(ValueError, match="must be 'question' or 'answer'"):
            faq_repo.update_faq_status("Q001", "active", faq_type="invalid")


# =============================================================================
# FAQ Statistics Tests (Point 113)
# =============================================================================


class TestFAQStatistics:
    """Test FAQ statistics operations (Point 113)."""

    def test_get_faq_stats_empty(self, faq_repo):
        """Test statistics for empty tables."""
        stats = faq_repo.get_faq_stats()

        assert stats['total_questions'] == 0
        assert stats['total_answers'] == 0
        assert stats['questions_by_status'] == {}
        assert stats['answers_by_status'] == {}
        assert stats['questions_without_answers'] == 0
        assert stats['avg_confidence_score'] is None

    def test_get_faq_stats_with_data(self, faq_repo, sample_questions_df, sample_answers_df):
        """Test statistics with data."""
        # Insert all questions
        faq_repo.ingest_questions(sample_questions_df)

        # Insert only 2 answers (leaving 1 question without answer)
        faq_repo.ingest_answers(sample_answers_df.head(2))

        stats = faq_repo.get_faq_stats()

        assert stats['total_questions'] == 3
        assert stats['total_answers'] == 2
        assert stats['questions_by_status']['active'] == 3
        assert stats['answers_by_status']['active'] == 2
        assert stats['questions_without_answers'] == 1

        # Check average confidence score
        expected_avg = (0.95 + 0.88) / 2
        assert abs(stats['avg_confidence_score'] - expected_avg) < 0.01

    def test_get_faq_stats_by_source_type(self, faq_repo, sample_questions_df):
        """Test statistics grouped by source type."""
        faq_repo.ingest_questions(sample_questions_df)

        stats = faq_repo.get_faq_stats()

        assert stats['questions_by_source_type']['from_documents'] == 1
        assert stats['questions_by_source_type']['from_user_queries'] == 1
        assert stats['questions_by_source_type']['from_manual'] == 1

    def test_get_faq_stats_by_generation_method(self, faq_repo, sample_questions_df):
        """Test statistics grouped by generation method."""
        faq_repo.ingest_questions(sample_questions_df)

        stats = faq_repo.get_faq_stats()

        assert stats['questions_by_generation_method']['llm_generated'] == 2
        assert stats['questions_by_generation_method']['human_written'] == 1


# =============================================================================
# Question Source Operations Tests (Points 117, 119, 121)
# =============================================================================


class TestQuestionSourceOperations:
    """Test question source operations (Points 117, 119, 121)."""

    def test_link_question_sources_success(self, faq_repo, sample_questions_df, sample_checksums):
        """Test linking sources to question (Point 117)."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Link sources
        checksums = sample_checksums[:3]
        result = faq_repo.link_question_sources(
            "Q001",
            checksums,
            is_primary_source=[True, False, False],
            contribution_weights=[0.6, 0.3, 0.1]
        )

        assert result['success'] is True
        assert result['sources_linked'] == 3
        assert result['question_id'] == "Q001"

    def test_link_question_sources_not_found_raises(self, faq_repo, sample_checksums):
        """Test linking sources to non-existent question raises error."""
        with pytest.raises(QuestionNotFoundError, match="not found"):
            faq_repo.link_question_sources("Q999", sample_checksums[:2])

    def test_link_question_sources_invalid_checksum_raises(self, faq_repo, sample_questions_df):
        """Test linking invalid checksum raises error."""
        faq_repo.ingest_questions(sample_questions_df.head(1))

        with pytest.raises(DataValidationError, match="Invalid checksum format"):
            faq_repo.link_question_sources("Q001", ["invalid_checksum"])

    def test_link_question_sources_weight_mismatch_raises(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test mismatched weights length raises error."""
        faq_repo.ingest_questions(sample_questions_df.head(1))

        with pytest.raises(DataValidationError, match="length must match"):
            faq_repo.link_question_sources(
                "Q001",
                sample_checksums[:3],
                contribution_weights=[0.5, 0.5]  # Only 2 weights for 3 checksums
            )

    def test_get_sources_for_question_success(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test getting sources for question (Point 119)."""
        # Insert question and link sources
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.link_question_sources("Q001", sample_checksums[:2])

        # Get sources
        sources = faq_repo.get_sources_for_question("Q001")

        assert len(sources) == 2
        assert all(s['question_id'] == "Q001" for s in sources)

    def test_get_sources_for_question_empty(self, faq_repo, sample_questions_df):
        """Test getting sources for question with no sources."""
        faq_repo.ingest_questions(sample_questions_df.head(1))

        sources = faq_repo.get_sources_for_question("Q001")

        assert sources == []

    def test_get_sources_for_question_valid_only(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test filtering only valid sources."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Insert sources (1 valid, 1 invalid)
        sources_df = pd.DataFrame({
            'question_id': ['Q001', 'Q001'],
            'content_checksum': sample_checksums[:2],
            'is_valid': [1, 0],
            'valid_from': [datetime.now(), datetime.now()]
        })
        faq_repo.ingest_question_sources(sources_df, validate=False, validate_fk=False)

        # Get only valid sources
        valid_sources = faq_repo.get_sources_for_question("Q001", valid_only=True)
        assert len(valid_sources) == 1

        # Get all sources
        all_sources = faq_repo.get_sources_for_question("Q001", valid_only=False)
        assert len(all_sources) == 2

    def test_ingest_question_sources_success(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test bulk question sources ingestion (Point 121)."""
        # Insert questions
        faq_repo.ingest_questions(sample_questions_df.head(2))

        # Create sources DataFrame
        sources_df = pd.DataFrame({
            'question_id': ['Q001', 'Q001', 'Q002'],
            'content_checksum': sample_checksums[:3],
            'contribution_weight': [0.7, 0.3, 1.0]
        })

        result = faq_repo.ingest_question_sources(sources_df, validate_fk=False)

        assert result['success'] is True
        assert result['rows_inserted'] == 3

    def test_ingest_question_sources_fk_violation_raises(
        self, faq_repo, sample_checksums
    ):
        """Test FK violation raises error."""
        sources_df = pd.DataFrame({
            'question_id': ['Q999'],  # Non-existent
            'content_checksum': [sample_checksums[0]]
        })

        with pytest.raises(ForeignKeyViolationError, match="Foreign key violation"):
            faq_repo.ingest_question_sources(sources_df, validate_fk=True)

    def test_ingest_question_sources_invalid_checksum_raises(self, faq_repo):
        """Test invalid checksum format raises error."""
        sources_df = pd.DataFrame({
            'question_id': ['Q001'],
            'content_checksum': ['invalid']  # Not 64 chars
        })

        with pytest.raises(DataValidationError, match="invalid content_checksum"):
            faq_repo.ingest_question_sources(sources_df)


# =============================================================================
# Answer Source Operations Tests (Points 118, 120, 122)
# =============================================================================


class TestAnswerSourceOperations:
    """Test answer source operations (Points 118, 120, 122)."""

    def test_link_answer_sources_success(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test linking sources to answer (Point 118)."""
        # Insert question and answer
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        # Link sources
        checksums = sample_checksums[:3]
        contexts = ['{"section": "policy"}', '{"section": "terms"}', None]
        result = faq_repo.link_answer_sources(
            "A001",
            checksums,
            is_primary_source=[True, False, False],
            contribution_weights=[0.5, 0.3, 0.2],
            context_employed=contexts
        )

        assert result['success'] is True
        assert result['sources_linked'] == 3
        assert result['answer_id'] == "A001"

    def test_link_answer_sources_not_found_raises(self, faq_repo, sample_checksums):
        """Test linking sources to non-existent answer raises error."""
        with pytest.raises(AnswerNotFoundError, match="not found"):
            faq_repo.link_answer_sources("A999", sample_checksums[:2])

    def test_link_answer_sources_context_mismatch_raises(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test mismatched context length raises error."""
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        with pytest.raises(DataValidationError, match="length must match"):
            faq_repo.link_answer_sources(
                "A001",
                sample_checksums[:3],
                context_employed=['{}', '{}']  # Only 2 contexts for 3 checksums
            )

    def test_get_sources_for_answer_success(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test getting sources for answer (Point 120)."""
        # Insert data and link sources
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))
        faq_repo.link_answer_sources("A001", sample_checksums[:2])

        # Get sources
        sources = faq_repo.get_sources_for_answer("A001")

        assert len(sources) == 2
        assert all(s['answer_id'] == "A001" for s in sources)

    def test_get_sources_for_answer_empty(
        self, faq_repo, sample_questions_df, sample_answers_df
    ):
        """Test getting sources for answer with no sources."""
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))

        sources = faq_repo.get_sources_for_answer("A001")

        assert sources == []

    def test_ingest_answer_sources_success(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test bulk answer sources ingestion (Point 122)."""
        # Insert questions and answers
        faq_repo.ingest_questions(sample_questions_df.head(2))
        faq_repo.ingest_answers(sample_answers_df.head(2))

        # Create sources DataFrame
        sources_df = pd.DataFrame({
            'answer_id': ['A001', 'A001', 'A002'],
            'content_checksum': sample_checksums[:3],
            'contribution_weight': [0.6, 0.4, 1.0],
            'context_employed': ['{}', '{}', '{}']
        })

        result = faq_repo.ingest_answer_sources(sources_df, validate_fk=False)

        assert result['success'] is True
        assert result['rows_inserted'] == 3

    def test_ingest_answer_sources_fk_violation_raises(self, faq_repo, sample_checksums):
        """Test FK violation raises error."""
        sources_df = pd.DataFrame({
            'answer_id': ['A999'],  # Non-existent
            'content_checksum': [sample_checksums[0]]
        })

        with pytest.raises(ForeignKeyViolationError, match="Foreign key violation"):
            faq_repo.ingest_answer_sources(sources_df, validate_fk=True)


# =============================================================================
# Provenance Validation Tests (Point 123)
# =============================================================================


class TestProvenanceValidation:
    """Test provenance validation (Point 123)."""

    def test_validate_content_checksum_exists_true(self, faq_repo, sample_checksums):
        """Test validating existing content checksum."""
        # Insert content chunk
        checksum = sample_checksums[0]
        faq_repo.backend.execute_command(
            "INSERT INTO content_chunks (content_checksum, chunk_text) VALUES (?, ?)",
            (checksum, "test content")
        )

        assert faq_repo.validate_content_checksum_exists(checksum) is True

    def test_validate_content_checksum_exists_false(self, faq_repo, sample_checksums):
        """Test validating non-existent content checksum."""
        assert faq_repo.validate_content_checksum_exists(sample_checksums[0]) is False

    def test_validate_content_checksums_all_valid(self, faq_repo, sample_checksums):
        """Test validating multiple valid checksums."""
        # Insert content chunks
        for checksum in sample_checksums[:3]:
            faq_repo.backend.execute_command(
                "INSERT INTO content_chunks (content_checksum, chunk_text) VALUES (?, ?)",
                (checksum, "test content")
            )

        valid, invalid = faq_repo.validate_content_checksums(sample_checksums[:3])

        assert len(valid) == 3
        assert len(invalid) == 0

    def test_validate_content_checksums_some_invalid(self, faq_repo, sample_checksums):
        """Test validating mix of valid and invalid checksums."""
        # Insert only first 2 checksums
        for checksum in sample_checksums[:2]:
            faq_repo.backend.execute_command(
                "INSERT INTO content_chunks (content_checksum, chunk_text) VALUES (?, ?)",
                (checksum, "test content")
            )

        valid, invalid = faq_repo.validate_content_checksums(sample_checksums[:4])

        assert len(valid) == 2
        assert len(invalid) == 2
        assert sample_checksums[0] in valid
        assert sample_checksums[1] in valid
        assert sample_checksums[2] in invalid
        assert sample_checksums[3] in invalid


# =============================================================================
# Source Tracking Tests (Point 124)
# =============================================================================


class TestSourceTracking:
    """Test source tracking and lineage (Point 124)."""

    def test_track_source_lineage_question(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test tracking lineage for question."""
        # Insert question and link sources
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.link_question_sources("Q001", sample_checksums[:3])

        # Track lineage
        lineage = faq_repo.track_source_lineage("Q001", faq_type="question")

        assert lineage['faq_id'] == "Q001"
        assert lineage['faq_type'] == "question"
        assert lineage['total_sources'] == 3
        assert lineage['valid_sources'] == 3
        assert lineage['invalid_sources'] == 0
        assert lineage['faq_data'] is not None
        assert len(lineage['sources']) == 3

    def test_track_source_lineage_answer(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test tracking lineage for answer."""
        # Insert question, answer and link sources
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.ingest_answers(sample_answers_df.head(1))
        faq_repo.link_answer_sources("A001", sample_checksums[:2])

        # Track lineage
        lineage = faq_repo.track_source_lineage("A001", faq_type="answer")

        assert lineage['faq_id'] == "A001"
        assert lineage['faq_type'] == "answer"
        assert lineage['total_sources'] == 2
        assert lineage['valid_sources'] == 2
        assert lineage['invalid_sources'] == 0

    def test_track_source_lineage_with_invalid_sources(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test tracking lineage with mix of valid/invalid sources."""
        # Insert question
        faq_repo.ingest_questions(sample_questions_df.head(1))

        # Insert sources (2 valid, 1 invalid)
        sources_df = pd.DataFrame({
            'question_id': ['Q001', 'Q001', 'Q001'],
            'content_checksum': sample_checksums[:3],
            'is_valid': [1, 1, 0],
            'valid_from': [datetime.now()] * 3
        })
        faq_repo.ingest_question_sources(sources_df, validate=False, validate_fk=False)

        # Track lineage
        lineage = faq_repo.track_source_lineage("Q001", faq_type="question")

        assert lineage['total_sources'] == 3
        assert lineage['valid_sources'] == 2
        assert lineage['invalid_sources'] == 1

    def test_track_source_lineage_invalid_faq_type_raises(self, faq_repo):
        """Test invalid faq_type raises error."""
        with pytest.raises(ValueError, match="must be 'question' or 'answer'"):
            faq_repo.track_source_lineage("Q001", faq_type="invalid")


# =============================================================================
# Integration Tests (End-to-End)
# =============================================================================


class TestFAQRepositoryIntegration:
    """End-to-end integration tests."""

    def test_complete_faq_workflow(
        self, faq_repo, sample_questions_df, sample_answers_df, sample_checksums
    ):
        """Test complete FAQ workflow with all operations."""
        # Step 1: Ingest questions
        q_result = faq_repo.ingest_questions(sample_questions_df)
        assert q_result['success'] is True

        # Step 2: Ingest answers
        a_result = faq_repo.ingest_answers(sample_answers_df)
        assert a_result['success'] is True

        # Step 3: Link question sources
        faq_repo.link_question_sources("Q001", sample_checksums[:2])
        q_sources = faq_repo.get_sources_for_question("Q001")
        assert len(q_sources) == 2

        # Step 4: Link answer sources
        faq_repo.link_answer_sources("A001", sample_checksums[2:4])
        a_sources = faq_repo.get_sources_for_answer("A001")
        assert len(a_sources) == 2

        # Step 5: Get FAQ by checksum
        faqs = faq_repo.get_faqs_by_checksum(sample_checksums[0])
        assert faqs['total_questions'] >= 1

        # Step 6: Get statistics
        stats = faq_repo.get_faq_stats()
        assert stats['total_questions'] == 3
        assert stats['total_answers'] == 3

        # Step 7: Track lineage
        lineage = faq_repo.track_source_lineage("Q001", "question")
        assert lineage['total_sources'] == 2

        # Step 8: Update status
        faq_repo.update_faq_status("Q001", "archived", faq_type="question")
        question = faq_repo.get_question_by_id("Q001")
        assert question['status'] == "archived"

    def test_provenance_invalidation_workflow(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test provenance invalidation workflow."""
        # Insert question and link sources
        faq_repo.ingest_questions(sample_questions_df.head(1))
        faq_repo.link_question_sources("Q001", sample_checksums[:3])

        # Verify all sources are valid
        lineage = faq_repo.track_source_lineage("Q001", "question")
        assert lineage['valid_sources'] == 3

        # Invalidate one source
        faq_repo.backend.execute_command(
            """
            UPDATE faq_question_sources
            SET is_valid = 0,
                valid_until = ?,
                invalidation_reason = ?
            WHERE question_id = ? AND content_checksum = ?
            """,
            (datetime.now(), "content_changed", "Q001", sample_checksums[0])
        )

        # Track lineage again
        lineage = faq_repo.track_source_lineage("Q001", "question")
        assert lineage['valid_sources'] == 2
        assert lineage['invalid_sources'] == 1

    def test_multi_question_source_sharing(
        self, faq_repo, sample_questions_df, sample_checksums
    ):
        """Test multiple questions sharing same source."""
        # Insert 2 questions
        faq_repo.ingest_questions(sample_questions_df.head(2))

        # Link both to same checksum
        shared_checksum = sample_checksums[0]
        faq_repo.link_question_sources("Q001", [shared_checksum])
        faq_repo.link_question_sources("Q002", [shared_checksum])

        # Get FAQs by checksum
        faqs = faq_repo.get_faqs_by_checksum(shared_checksum)

        assert faqs['total_questions'] == 2
        assert any(q['question_id'] == "Q001" for q in faqs['questions'])
        assert any(q['question_id'] == "Q002" for q in faqs['questions'])


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
