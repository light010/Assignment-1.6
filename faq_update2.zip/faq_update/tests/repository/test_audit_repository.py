"""
Integration Tests for AuditRepository

Comprehensive tests for AuditRepository functionality including:
- Change logging (single and bulk)
- Change history retrieval
- Detection run management
- Detection results storage
- FAQ invalidation tracking
- Baseline data retrieval
- Performance-optimized queries

Tests use an in-memory SQLite database for fast, isolated testing.

Author: Analytics Assist Team
Date: 2025-11-02
"""

import pytest
import pandas as pd
from datetime import datetime
from typing import Dict, Any
import hashlib
import json

from database.repository.audit_repository import (
    AuditRepository,
    AuditRepositoryError,
    ChangeLogNotFoundError,
    DetectionRunNotFoundError,
    InvalidDetectionResultError,
    DuplicateChangeLogError,
)
from database.repository.base import (
    DataValidationError,
    QueryError,
)
from database.backends.sqlite.backend import SQLiteBackend
from database.config import DatabaseConfig
from database.models import ChangeType, ContentChangeLog, AuditLogEntry


# =============================================================================
# Test Fixtures
# =============================================================================


@pytest.fixture
def in_memory_backend():
    """Create an in-memory SQLite backend for testing with all required tables."""
    config = DatabaseConfig(
        backend="sqlite",
        db_path=":memory:"  # In-memory database
    )
    backend = SQLiteBackend(config)
    backend.connect()

    # Create content_repo table (for FK relationships)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            created_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create content_chunks table (for baseline data)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ud_source_file_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            content_text TEXT NOT NULL,
            chunk_sequence INTEGER,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
        )
    """)

    # Create content_change_log table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_change_log (
            change_id INTEGER PRIMARY KEY AUTOINCREMENT,
            content_checksum TEXT NOT NULL,
            previous_checksum TEXT,
            file_name TEXT NOT NULL,
            requires_faq_regeneration INTEGER NOT NULL,
            change_type TEXT,
            similarity_score REAL,
            similarity_method TEXT,
            diff_data TEXT,
            total_faqs_at_risk INTEGER NOT NULL DEFAULT 0,
            affected_question_count INTEGER NOT NULL DEFAULT 0,
            affected_answer_count INTEGER NOT NULL DEFAULT 0,
            detection_run_id TEXT NOT NULL,
            detection_timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create indexes
    backend.execute_command("""
        CREATE INDEX IF NOT EXISTS idx_ccl_content_checksum
        ON content_change_log(content_checksum)
    """)
    backend.execute_command("""
        CREATE INDEX IF NOT EXISTS idx_ccl_previous_checksum
        ON content_change_log(previous_checksum)
    """)
    backend.execute_command("""
        CREATE INDEX IF NOT EXISTS idx_ccl_detection_run
        ON content_change_log(detection_run_id)
    """)

    # Create faq_questions table (for FK relationships)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_questions (
            question_id TEXT PRIMARY KEY,
            question_text TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create faq_answers table (for FK relationships)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_answers (
            answer_id TEXT PRIMARY KEY,
            question_id TEXT NOT NULL,
            answer_text TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        )
    """)

    # Create faq_question_sources table (for provenance)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_question_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id TEXT NOT NULL,
            content_checksum TEXT NOT NULL,
            is_valid INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
        )
    """)

    # Create faq_answer_sources table (for provenance)
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_answer_sources (
            source_id INTEGER PRIMARY KEY AUTOINCREMENT,
            answer_id TEXT NOT NULL,
            content_checksum TEXT NOT NULL,
            is_valid INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        )
    """)

    # Create faq_audit_log table
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS faq_audit_log (
            audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
            change_id INTEGER,
            question_id TEXT,
            answer_id TEXT,
            detection_run_id TEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (change_id) REFERENCES content_change_log(change_id),
            FOREIGN KEY (question_id) REFERENCES faq_questions(question_id),
            FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
        )
    """)

    # Create indexes
    backend.execute_command("""
        CREATE INDEX IF NOT EXISTS idx_audit_change_id
        ON faq_audit_log(change_id)
    """)
    backend.execute_command("""
        CREATE INDEX IF NOT EXISTS idx_audit_question_id
        ON faq_audit_log(question_id)
    """)

    yield backend

    backend.close()


@pytest.fixture
def audit_repo(in_memory_backend):
    """Create AuditRepository with in-memory backend."""
    return AuditRepository(in_memory_backend, auto_connect=False)


@pytest.fixture
def sample_checksum():
    """Generate a valid SHA-256 checksum for testing."""
    return hashlib.sha256(b"test content").hexdigest()


@pytest.fixture
def sample_change_log_data(sample_checksum):
    """Create sample change log data for testing."""
    return {
        'content_checksum': sample_checksum,
        'file_name': 'test_file.pdf',
        'requires_faq_regeneration': True,
        'detection_run_id': 'test_run_001',
        'previous_checksum': hashlib.sha256(b"old content").hexdigest(),
        'change_type': ChangeType.MODIFIED_CONTENT,
        'similarity_score': 0.85,
        'similarity_method': 'hybrid',
        'diff_data': {'changes': ['line 1 changed']},
        'total_faqs_at_risk': 10,
        'affected_question_count': 3,
        'affected_answer_count': 2,
    }


@pytest.fixture
def populated_backend(in_memory_backend, sample_checksum):
    """Create backend with sample data populated."""
    backend = in_memory_backend

    # Insert sample file
    backend.execute_command(
        "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
        ("test_file.pdf",)
    )

    # Insert sample chunks
    backend.execute_command(
        """INSERT INTO content_chunks
           (ud_source_file_id, chunk_index, content_checksum, content_text, chunk_sequence)
           VALUES (?, ?, ?, ?, ?)""",
        (1, 0, sample_checksum, "test content", 0)
    )

    # Insert sample FAQ data
    backend.execute_command(
        "INSERT INTO faq_questions (question_id, question_text, status) VALUES (?, ?, ?)",
        ("q_001", "What is the policy?", "active")
    )

    backend.execute_command(
        "INSERT INTO faq_answers (answer_id, question_id, answer_text, status) VALUES (?, ?, ?, ?)",
        ("a_001", "q_001", "The policy is...", "active")
    )

    # Insert provenance links
    old_checksum = hashlib.sha256(b"old content").hexdigest()
    backend.execute_command(
        "INSERT INTO faq_question_sources (question_id, content_checksum, is_valid) VALUES (?, ?, ?)",
        ("q_001", old_checksum, 1)
    )

    backend.execute_command(
        "INSERT INTO faq_answer_sources (answer_id, content_checksum, is_valid) VALUES (?, ?, ?)",
        ("a_001", old_checksum, 1)
    )

    return backend


# =============================================================================
# Change Logging Tests (Points 127-128)
# =============================================================================


class TestChangeLogging:
    """Test change logging operations."""

    def test_log_change_success(self, audit_repo, sample_change_log_data):
        """Test logging a single change successfully."""
        change_log = audit_repo.log_change(**sample_change_log_data)

        assert change_log.change_id is not None
        assert change_log.change_id > 0
        assert change_log.content_checksum == sample_change_log_data['content_checksum']
        assert change_log.file_name == sample_change_log_data['file_name']
        assert change_log.requires_faq_regeneration == True
        assert change_log.similarity_score == 0.85

    def test_log_change_minimal_data(self, audit_repo, sample_checksum):
        """Test logging with only required fields."""
        change_log = audit_repo.log_change(
            content_checksum=sample_checksum,
            file_name="minimal.pdf",
            requires_faq_regeneration=False,
            detection_run_id="run_002"
        )

        assert change_log.change_id is not None
        assert change_log.previous_checksum is None
        assert change_log.change_type is None
        assert change_log.similarity_score is None

    def test_log_change_invalid_checksum(self, audit_repo):
        """Test logging with invalid checksum fails validation."""
        with pytest.raises(DataValidationError):
            audit_repo.log_change(
                content_checksum="invalid_checksum",  # Too short
                file_name="test.pdf",
                requires_faq_regeneration=True,
                detection_run_id="run_003"
            )

    def test_log_change_invalid_similarity_score(self, audit_repo, sample_checksum):
        """Test logging with invalid similarity score fails validation."""
        with pytest.raises(DataValidationError):
            audit_repo.log_change(
                content_checksum=sample_checksum,
                file_name="test.pdf",
                requires_faq_regeneration=True,
                detection_run_id="run_004",
                similarity_score=1.5  # Out of range
            )

    def test_log_changes_bulk_success(self, audit_repo, sample_checksum):
        """Test bulk logging of changes."""
        changes_df = pd.DataFrame([
            {
                'content_checksum': sample_checksum,
                'file_name': 'file1.pdf',
                'requires_faq_regeneration': True,
                'detection_run_id': 'bulk_run_001',
                'change_type': 'modified_content',
                'similarity_score': 0.85
            },
            {
                'content_checksum': hashlib.sha256(b"content2").hexdigest(),
                'file_name': 'file2.pdf',
                'requires_faq_regeneration': False,
                'detection_run_id': 'bulk_run_001',
                'change_type': 'new_content'
            }
        ])

        result = audit_repo.log_changes_bulk(changes_df)

        assert result['success'] == True
        assert result['rows_inserted'] == 2

    def test_log_changes_bulk_empty_df(self, audit_repo):
        """Test bulk logging with empty DataFrame fails."""
        empty_df = pd.DataFrame()

        with pytest.raises(DataValidationError):
            audit_repo.log_changes_bulk(empty_df)

    def test_log_changes_bulk_missing_columns(self, audit_repo):
        """Test bulk logging with missing required columns fails."""
        incomplete_df = pd.DataFrame([
            {'content_checksum': hashlib.sha256(b"test").hexdigest()}
        ])

        with pytest.raises(DataValidationError):
            audit_repo.log_changes_bulk(incomplete_df)


# =============================================================================
# Change Retrieval Tests (Points 129-131)
# =============================================================================


class TestChangeRetrieval:
    """Test change retrieval operations."""

    def test_get_changes_for_file(self, audit_repo, sample_change_log_data):
        """Test retrieving changes for a specific file."""
        # Insert a change
        audit_repo.log_change(**sample_change_log_data)

        # Retrieve changes
        changes = audit_repo.get_changes_for_file("test_file.pdf")

        assert len(changes) == 1
        assert changes[0].file_name == "test_file.pdf"
        assert changes[0].change_type == ChangeType.MODIFIED_CONTENT

    def test_get_changes_for_file_with_limit(self, audit_repo, sample_checksum):
        """Test retrieving changes with limit."""
        # Insert multiple changes
        for i in range(5):
            audit_repo.log_change(
                content_checksum=hashlib.sha256(f"content_{i}".encode()).hexdigest(),
                file_name="multi_change.pdf",
                requires_faq_regeneration=True,
                detection_run_id=f"run_{i}"
            )

        # Retrieve with limit
        changes = audit_repo.get_changes_for_file("multi_change.pdf", limit=3)

        assert len(changes) == 3

    def test_get_changes_by_run(self, audit_repo, sample_checksum):
        """Test retrieving changes for a specific detection run."""
        run_id = "specific_run_001"

        # Insert changes for this run
        for i in range(3):
            audit_repo.log_change(
                content_checksum=hashlib.sha256(f"content_{i}".encode()).hexdigest(),
                file_name=f"file_{i}.pdf",
                requires_faq_regeneration=True,
                detection_run_id=run_id
            )

        # Retrieve changes
        changes = audit_repo.get_changes_by_run(run_id)

        assert len(changes) == 3
        for change in changes:
            assert change.detection_run_id == run_id

    def test_get_changes_by_run_not_found(self, audit_repo):
        """Test retrieving changes for non-existent run fails."""
        with pytest.raises(DetectionRunNotFoundError):
            audit_repo.get_changes_by_run("nonexistent_run")

    def test_get_latest_run_id(self, audit_repo, sample_checksum):
        """Test getting the latest run ID."""
        # Insert changes with different timestamps
        run_ids = ["run_001", "run_002", "run_003"]

        for run_id in run_ids:
            audit_repo.log_change(
                content_checksum=sample_checksum,
                file_name="test.pdf",
                requires_faq_regeneration=True,
                detection_run_id=run_id
            )

        latest_run = audit_repo.get_latest_run_id()

        # Should return the last inserted run
        assert latest_run == "run_003"

    def test_get_latest_run_id_empty(self, audit_repo):
        """Test getting latest run ID when no runs exist."""
        result = audit_repo.get_latest_run_id()
        assert result is None


# =============================================================================
# Detection Run Summary Tests (Point 132)
# =============================================================================


class TestDetectionRunSummary:
    """Test detection run summary operations."""

    def test_get_run_summary(self, audit_repo, sample_checksum):
        """Test getting summary for a detection run."""
        run_id = "summary_run_001"

        # Insert changes with various metrics
        for i in range(3):
            audit_repo.log_change(
                content_checksum=hashlib.sha256(f"content_{i}".encode()).hexdigest(),
                file_name=f"file_{i}.pdf",
                requires_faq_regeneration=True,
                detection_run_id=run_id,
                change_type=ChangeType.MODIFIED_CONTENT,
                similarity_score=0.8 + (i * 0.05),
                total_faqs_at_risk=10,
                affected_question_count=2 + i,
                affected_answer_count=1
            )

        summaries = audit_repo.get_run_summary(detection_run_id=run_id)

        assert len(summaries) == 1
        summary = summaries[0]

        assert summary['detection_run_id'] == run_id
        assert summary['total_changes_detected'] == 3
        assert summary['unique_files_changed'] == 3
        assert summary['total_faqs_at_risk'] == 30
        assert summary['questions_actually_affected'] == 9  # 2+3+4
        assert summary['answers_actually_affected'] == 3

    def test_get_run_summary_multiple_runs(self, audit_repo, sample_checksum):
        """Test getting summaries for multiple runs."""
        # Insert changes for different runs
        for run_num in range(3):
            run_id = f"multi_run_{run_num:03d}"
            audit_repo.log_change(
                content_checksum=hashlib.sha256(f"content_{run_num}".encode()).hexdigest(),
                file_name="test.pdf",
                requires_faq_regeneration=True,
                detection_run_id=run_id,
                similarity_score=0.85
            )

        summaries = audit_repo.get_run_summary(limit=10)

        assert len(summaries) >= 3


# =============================================================================
# Detection Operations Tests (Points 137-145)
# =============================================================================


class TestDetectionOperations:
    """Test detection-specific operations."""

    def test_get_previous_checksums(self, audit_repo, populated_backend, sample_checksum):
        """Test retrieving baseline checksums for change detection."""
        repo = AuditRepository(populated_backend, auto_connect=False)

        baseline = repo.get_previous_checksums()

        assert len(baseline) > 0
        assert sample_checksum in baseline
        assert 'content_text' in baseline[sample_checksum]
        assert baseline[sample_checksum]['content_text'] == "test content"

    def test_get_previous_checksums_filtered(self, audit_repo, populated_backend, sample_checksum):
        """Test retrieving checksums filtered by file name."""
        repo = AuditRepository(populated_backend, auto_connect=False)

        baseline = repo.get_previous_checksums(file_name="test_file.pdf")

        assert len(baseline) > 0

    def test_store_detection_results(self, audit_repo, sample_checksum):
        """Test storing detection results from change detector."""
        # Create mock DetectionResult objects
        class MockDetectionResult:
            def __init__(self, new_checksum, old_checksum, file_name, requires_regen, change_type, score):
                self.new_checksum = new_checksum
                self.old_checksum = old_checksum
                self.file_name = file_name
                self.requires_faq_regeneration = requires_regen
                self.change_type = change_type
                self.similarity_score = score
                self.similarity_method = "hybrid"
                self.llm_diff = "Test diff"

        results = [
            MockDetectionResult(
                sample_checksum,
                hashlib.sha256(b"old1").hexdigest(),
                "file1.pdf",
                True,
                ChangeType.MODIFIED_CONTENT,
                0.85
            ),
            MockDetectionResult(
                hashlib.sha256(b"new2").hexdigest(),
                None,
                "file2.pdf",
                False,
                ChangeType.NEW_CONTENT,
                None
            )
        ]

        result = audit_repo.store_detection_results(results, "store_run_001")

        assert result['success'] == True
        assert result['rows_inserted'] == 2

    def test_store_detection_results_empty(self, audit_repo):
        """Test storing empty detection results."""
        result = audit_repo.store_detection_results([], "empty_run")

        assert result['success'] == True
        assert result['rows_inserted'] == 0

    def test_get_faqs_requiring_regeneration(self, audit_repo, populated_backend):
        """Test retrieving FAQs that need regeneration."""
        repo = AuditRepository(populated_backend, auto_connect=False)

        # Log a change that affects FAQs
        old_checksum = hashlib.sha256(b"old content").hexdigest()
        new_checksum = hashlib.sha256(b"new content").hexdigest()

        repo.log_change(
            content_checksum=new_checksum,
            previous_checksum=old_checksum,
            file_name="test_file.pdf",
            requires_faq_regeneration=True,
            detection_run_id="regen_run_001",
            change_type=ChangeType.MODIFIED_CONTENT
        )

        # Get FAQs requiring regeneration
        faqs = repo.get_faqs_requiring_regeneration("regen_run_001")

        assert len(faqs) > 0
        # Should find q_001 which is linked to old_checksum
        question_ids = [faq['question_id'] for faq in faqs]
        assert "q_001" in question_ids

    def test_mark_faq_invalidated(self, audit_repo, sample_change_log_data):
        """Test marking FAQ as invalidated."""
        # First log a change
        change_log = audit_repo.log_change(**sample_change_log_data)

        # Mark FAQ as invalidated
        audit_entry = audit_repo.mark_faq_invalidated(
            question_id="q_001",
            change_id=change_log.change_id,
            detection_run_id="test_run_001",
            answer_id="a_001"
        )

        assert audit_entry.audit_id is not None
        assert audit_entry.audit_id > 0
        assert audit_entry.question_id == "q_001"
        assert audit_entry.answer_id == "a_001"
        assert audit_entry.change_id == change_log.change_id

    def test_get_content_changes_summary(self, audit_repo, sample_checksum):
        """Test retrieving content changes summary."""
        run_id = "summary_changes_001"

        # Log changes with impact metrics
        audit_repo.log_change(
            content_checksum=sample_checksum,
            file_name="test.pdf",
            requires_faq_regeneration=True,
            detection_run_id=run_id,
            total_faqs_at_risk=10,
            affected_question_count=3,
            affected_answer_count=2,
            similarity_score=0.85,
            similarity_method="hybrid"
        )

        summary = audit_repo.get_content_changes_summary(detection_run_id=run_id)

        assert len(summary) == 1
        assert summary[0]['detection_run_id'] == run_id
        assert summary[0]['faqs_saved'] == 5  # 10 - (3 + 2)


# =============================================================================
# Validation Tests (Point 133)
# =============================================================================


class TestValidation:
    """Test validation operations."""

    def test_validate_change_log_success(self, audit_repo, sample_checksum):
        """Test successful validation."""
        is_valid, error = audit_repo.validate_change_log(
            content_checksum=sample_checksum,
            file_name="test.pdf",
            detection_run_id="run_001",
            similarity_score=0.85
        )

        assert is_valid == True
        assert error is None

    def test_validate_change_log_invalid_checksum(self, audit_repo):
        """Test validation with invalid checksum."""
        is_valid, error = audit_repo.validate_change_log(
            content_checksum="invalid",
            file_name="test.pdf",
            detection_run_id="run_001"
        )

        assert is_valid == False
        assert "64 characters" in error

    def test_validate_change_log_invalid_score(self, audit_repo, sample_checksum):
        """Test validation with invalid similarity score."""
        is_valid, error = audit_repo.validate_change_log(
            content_checksum=sample_checksum,
            file_name="test.pdf",
            detection_run_id="run_001",
            similarity_score=2.0  # Out of range
        )

        assert is_valid == False
        assert "between 0.0 and 1.0" in error


# =============================================================================
# Integration Tests
# =============================================================================


class TestIntegration:
    """End-to-end integration tests."""

    def test_full_detection_workflow(self, audit_repo, populated_backend, sample_checksum):
        """Test complete detection workflow from baseline to FAQ invalidation."""
        repo = AuditRepository(populated_backend, auto_connect=False)

        # Step 1: Get baseline checksums
        baseline = repo.get_previous_checksums()
        assert len(baseline) > 0

        # Step 2: Log detected changes
        old_checksum = hashlib.sha256(b"old content").hexdigest()
        new_checksum = hashlib.sha256(b"new content").hexdigest()

        change_log = repo.log_change(
            content_checksum=new_checksum,
            previous_checksum=old_checksum,
            file_name="test_file.pdf",
            requires_faq_regeneration=True,
            detection_run_id="workflow_run_001",
            change_type=ChangeType.MODIFIED_CONTENT,
            similarity_score=0.82
        )

        # Step 3: Get run summary
        summaries = repo.get_run_summary(detection_run_id="workflow_run_001")
        assert len(summaries) == 1

        # Step 4: Get FAQs requiring regeneration
        faqs = repo.get_faqs_requiring_regeneration("workflow_run_001")
        # May or may not have FAQs depending on provenance links

        # Step 5: Mark FAQ as invalidated (if exists)
        if len(faqs) > 0:
            audit_entry = repo.mark_faq_invalidated(
                question_id=faqs[0]['question_id'],
                change_id=change_log.change_id,
                detection_run_id="workflow_run_001"
            )
            assert audit_entry.audit_id is not None

        # Step 6: Get content changes summary
        summary = repo.get_content_changes_summary(detection_run_id="workflow_run_001")
        assert len(summary) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
