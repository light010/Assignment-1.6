"""
Integration Tests for ContentRepository

Comprehensive tests for ContentRepository functionality including:
- File retrieval operations
- File ingestion (single and bulk)
- File status updates
- File statistics
- Chunk operations
- Foreign key validation
- Full-text search
- Checksum validation

Tests use an in-memory SQLite database for fast, isolated testing.

Author: Analytics Assist Team
Date: 2025-11-02
"""

import pytest
import pandas as pd
from datetime import datetime
from typing import Dict, Any
import hashlib

from database.repository.content_repository import (
    ContentRepository,
    ContentRepositoryError,
    FileNotFoundError,
    ChunkNotFoundError,
    DuplicateFileError,
    ForeignKeyViolationError,
)
from database.repository.base import (
    DataValidationError,
    QueryError,
)
from database.backends.sqlite.backend import SQLiteBackend
from database.config import DatabaseConfig


# =============================================================================
# Test Fixtures
# =============================================================================


@pytest.fixture
def in_memory_backend():
    """Create an in-memory SQLite backend for testing."""
    config = DatabaseConfig(
        backend="sqlite",
        db_path=":memory:"  # In-memory database
    )
    backend = SQLiteBackend(config)
    backend.connect()

    # Create tables
    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_repo (
            ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_file_nme TEXT NOT NULL,
            raw_file_type TEXT,
            raw_file_version_nbr INTEGER DEFAULT 1,
            raw_file_path TEXT,
            extracted_markdown_file_path TEXT,
            title_nme TEXT,
            file_status TEXT,
            created_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_modified_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    backend.execute_command("""
        CREATE TABLE IF NOT EXISTS content_chunks (
            chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ud_source_file_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content_checksum TEXT NOT NULL,
            chunk_text TEXT NOT NULL,
            chunk_page_number INTEGER,
            chunk_start_char INTEGER,
            chunk_end_char INTEGER,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
        )
    """)

    yield backend

    backend.close()


@pytest.fixture
def content_repo(in_memory_backend):
    """Create ContentRepository with in-memory backend."""
    return ContentRepository(in_memory_backend, auto_connect=False)


@pytest.fixture
def sample_files_df():
    """Create sample files DataFrame for testing."""
    return pd.DataFrame({
        'raw_file_nme': ['file1.pdf', 'file2.html', 'file3.docx'],
        'raw_file_type': ['pdf', 'html', 'docx'],
        'file_status': ['Active', 'Active', 'Inactive'],
        'title_nme': ['File 1 Title', 'File 2 Title', 'File 3 Title']
    })


@pytest.fixture
def sample_chunks_df():
    """Create sample chunks DataFrame for testing."""
    # Generate simple checksums for testing
    def generate_checksum(text: str) -> str:
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    return pd.DataFrame({
        'ud_source_file_id': [1, 1, 1, 2, 2],
        'chunk_index': [0, 1, 2, 0, 1],
        'content_checksum': [
            generate_checksum('chunk 0 content'),
            generate_checksum('chunk 1 content'),
            generate_checksum('chunk 2 content'),
            generate_checksum('chunk 0 file 2'),
            generate_checksum('chunk 1 file 2'),
        ],
        'chunk_text': [
            'chunk 0 content',
            'chunk 1 content',
            'chunk 2 content',
            'chunk 0 file 2',
            'chunk 1 file 2',
        ]
    })


# =============================================================================
# File Retrieval Tests (Points 87-89)
# =============================================================================


class TestFileRetrieval:
    """Test file retrieval operations."""

    def test_get_file_by_name_not_found(self, content_repo):
        """Test getting non-existent file returns None."""
        result = content_repo.get_file_by_name("nonexistent.pdf")
        assert result is None

    def test_get_file_by_name_success(self, content_repo, sample_files_df):
        """Test getting file by name returns correct file."""
        # Insert test file
        content_repo.ingest_files_bulk(sample_files_df.head(1))

        # Retrieve file
        result = content_repo.get_file_by_name("file1.pdf")

        assert result is not None
        assert result['raw_file_nme'] == "file1.pdf"
        assert result['raw_file_type'] == "pdf"
        assert result['file_status'] == "Active"

    def test_get_file_by_name_with_version(self, content_repo):
        """Test getting specific file version."""
        # Insert file version 1
        file_id_v1 = content_repo.ingest_file(
            file_name="versioned.pdf",
            version=1,
            status="Active"
        )

        # Insert file version 2
        file_id_v2 = content_repo.ingest_file(
            file_name="versioned.pdf",
            version=2,
            status="Active"
        )

        # Get version 1
        result_v1 = content_repo.get_file_by_name("versioned.pdf", version=1)
        assert result_v1['ud_source_file_id'] == file_id_v1
        assert result_v1['raw_file_version_nbr'] == 1

        # Get version 2
        result_v2 = content_repo.get_file_by_name("versioned.pdf", version=2)
        assert result_v2['ud_source_file_id'] == file_id_v2
        assert result_v2['raw_file_version_nbr'] == 2

    def test_get_file_by_name_empty_raises(self, content_repo):
        """Test that empty file name raises ValueError."""
        with pytest.raises(ValueError, match="file_name cannot be empty"):
            content_repo.get_file_by_name("")

    def test_get_file_by_id_success(self, content_repo, sample_files_df):
        """Test getting file by ID."""
        # Insert test file
        content_repo.ingest_files_bulk(sample_files_df.head(1))

        # Get file by ID (should be 1)
        result = content_repo.get_file_by_id(1)

        assert result is not None
        assert result['ud_source_file_id'] == 1
        assert result['raw_file_nme'] == "file1.pdf"

    def test_get_file_by_id_not_found(self, content_repo):
        """Test getting non-existent file ID returns None."""
        result = content_repo.get_file_by_id(999)
        assert result is None

    def test_get_file_by_id_invalid_raises(self, content_repo):
        """Test that invalid file ID raises ValueError."""
        with pytest.raises(ValueError, match="file_id must be a positive integer"):
            content_repo.get_file_by_id(0)

        with pytest.raises(ValueError, match="file_id must be a positive integer"):
            content_repo.get_file_by_id(-1)

    def test_list_files_empty(self, content_repo):
        """Test listing files when table is empty."""
        result = content_repo.list_files()
        assert result == []

    def test_list_files_all(self, content_repo, sample_files_df):
        """Test listing all files."""
        # Insert test files
        content_repo.ingest_files_bulk(sample_files_df)

        # List all files
        result = content_repo.list_files()

        assert len(result) == 3
        assert [f['raw_file_nme'] for f in result] == ['file3.docx', 'file2.html', 'file1.pdf']  # DESC order

    def test_list_files_with_status_filter(self, content_repo, sample_files_df):
        """Test listing files filtered by status."""
        # Insert test files
        content_repo.ingest_files_bulk(sample_files_df)

        # List only active files
        result = content_repo.list_files(status="Active")

        assert len(result) == 2
        assert all(f['file_status'] == "Active" for f in result)

    def test_list_files_with_type_filter(self, content_repo, sample_files_df):
        """Test listing files filtered by type."""
        # Insert test files
        content_repo.ingest_files_bulk(sample_files_df)

        # List only PDF files
        result = content_repo.list_files(file_type="pdf")

        assert len(result) == 1
        assert result[0]['raw_file_type'] == "pdf"

    def test_list_files_with_limit(self, content_repo, sample_files_df):
        """Test listing files with limit."""
        # Insert test files
        content_repo.ingest_files_bulk(sample_files_df)

        # List with limit
        result = content_repo.list_files(limit=2)

        assert len(result) == 2

    def test_list_files_with_pagination(self, content_repo, sample_files_df):
        """Test listing files with pagination."""
        # Insert test files
        content_repo.ingest_files_bulk(sample_files_df)

        # Get page 1
        page_1 = content_repo.list_files(limit=2, offset=0)
        assert len(page_1) == 2

        # Get page 2
        page_2 = content_repo.list_files(limit=2, offset=2)
        assert len(page_2) == 1

    def test_get_files_modified_after(self, content_repo, in_memory_backend):
        """Test getting files modified after a specific date."""
        # Insert files with different modification dates
        now = datetime.now()

        # Insert older file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("old_file.pdf", "Active", "2025-10-01 10:00:00", "2025-10-01 10:00:00"))

        # Insert newer file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("new_file.pdf", "Active", "2025-10-28 15:00:00", "2025-10-28 15:00:00"))

        # Insert another newer file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("newest_file.pdf", "Active", "2025-10-29 12:00:00", "2025-10-29 12:00:00"))

        # Get files modified after specific date
        result = content_repo.get_files_modified_after("2025-10-27 00:00:00")

        assert len(result) == 2
        assert result[0]['raw_file_nme'] == 'newest_file.pdf'  # DESC order
        assert result[1]['raw_file_nme'] == 'new_file.pdf'

    def test_get_files_modified_after_no_results(self, content_repo, in_memory_backend):
        """Test getting files when none match the date filter."""
        # Insert older file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("old_file.pdf", "Active", "2025-10-01 10:00:00", "2025-10-01 10:00:00"))

        # Query for files after a future date
        result = content_repo.get_files_modified_after("2025-11-01 00:00:00")

        assert len(result) == 0

    def test_get_files_modified_after_with_status_filter(self, content_repo, in_memory_backend):
        """Test getting files with status filter."""
        # Insert active file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("active_file.pdf", "Active", "2025-10-28 10:00:00", "2025-10-28 10:00:00"))

        # Insert inactive file
        in_memory_backend.execute_command("""
            INSERT INTO content_repo (raw_file_nme, file_status, created_dt, last_modified_dt)
            VALUES (?, ?, ?, ?)
        """, ("inactive_file.pdf", "Inactive", "2025-10-28 11:00:00", "2025-10-28 11:00:00"))

        # Get only active files
        result = content_repo.get_files_modified_after("2025-10-27 00:00:00", status="Active")

        assert len(result) == 1
        assert result[0]['raw_file_nme'] == 'active_file.pdf'

        # Get all files regardless of status
        result_all = content_repo.get_files_modified_after("2025-10-27 00:00:00", status=None)

        assert len(result_all) == 2

    def test_get_files_modified_after_empty_date_error(self, content_repo):
        """Test that empty date raises ValueError."""
        with pytest.raises(ValueError, match="since_date cannot be empty"):
            content_repo.get_files_modified_after("")


# =============================================================================
# File Ingestion Tests (Points 90-91)
# =============================================================================


class TestFileIngestion:
    """Test file ingestion operations."""

    def test_ingest_file_minimal(self, content_repo):
        """Test ingesting file with minimal data."""
        file_id = content_repo.ingest_file(file_name="test.pdf")

        assert isinstance(file_id, int)
        assert file_id > 0

        # Verify file was inserted
        file = content_repo.get_file_by_id(file_id)
        assert file['raw_file_nme'] == "test.pdf"
        assert file['file_status'] == "Active"  # Default
        assert file['raw_file_version_nbr'] == 1  # Default

    def test_ingest_file_complete(self, content_repo):
        """Test ingesting file with all fields."""
        file_id = content_repo.ingest_file(
            file_name="complete.pdf",
            file_type="pdf",
            file_path="/data/complete.pdf",
            extracted_markdown_path="/data/complete.md",
            title="Complete File",
            status="Active",
            version=2
        )

        # Verify all fields
        file = content_repo.get_file_by_id(file_id)
        assert file['raw_file_nme'] == "complete.pdf"
        assert file['raw_file_type'] == "pdf"
        assert file['raw_file_path'] == "/data/complete.pdf"
        assert file['extracted_markdown_file_path'] == "/data/complete.md"
        assert file['title_nme'] == "Complete File"
        assert file['file_status'] == "Active"
        assert file['raw_file_version_nbr'] == 2

    def test_ingest_file_empty_name_raises(self, content_repo):
        """Test that empty file name raises error."""
        with pytest.raises(DataValidationError, match="file_name is required"):
            content_repo.ingest_file(file_name="")

    def test_ingest_file_invalid_status_raises(self, content_repo):
        """Test that invalid status raises error."""
        with pytest.raises(DataValidationError, match="Invalid status"):
            content_repo.ingest_file(
                file_name="test.pdf",
                status="InvalidStatus"
            )

    def test_ingest_file_invalid_version_raises(self, content_repo):
        """Test that invalid version raises error."""
        with pytest.raises(DataValidationError, match="version must be >= 1"):
            content_repo.ingest_file(
                file_name="test.pdf",
                version=0
            )

    def test_ingest_file_duplicate_raises(self, content_repo):
        """Test that duplicate file raises error."""
        # Insert first file
        content_repo.ingest_file(file_name="test.pdf", version=1)

        # Try to insert duplicate
        with pytest.raises(DuplicateFileError, match="already exists"):
            content_repo.ingest_file(file_name="test.pdf", version=1)

    def test_ingest_files_bulk_success(self, content_repo, sample_files_df):
        """Test bulk ingestion of files."""
        result = content_repo.ingest_files_bulk(sample_files_df)

        assert result['success'] is True
        assert result['rows_inserted'] == 3

        # Verify files were inserted
        files = content_repo.list_files()
        assert len(files) == 3

    def test_ingest_files_bulk_empty_raises(self, content_repo):
        """Test that empty DataFrame raises error."""
        empty_df = pd.DataFrame()

        with pytest.raises(DataValidationError, match="Cannot ingest empty DataFrame"):
            content_repo.ingest_files_bulk(empty_df)

    def test_ingest_files_bulk_missing_column_raises(self, content_repo):
        """Test that missing required column raises error."""
        df = pd.DataFrame({
            'file_status': ['Active']
            # Missing raw_file_nme
        })

        with pytest.raises(DataValidationError, match="Missing required column: raw_file_nme"):
            content_repo.ingest_files_bulk(df)

    def test_ingest_files_bulk_invalid_status_raises(self, content_repo):
        """Test that invalid status in bulk raises error."""
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf'],
            'file_status': ['InvalidStatus']
        })

        with pytest.raises(DataValidationError, match="Invalid file_status values"):
            content_repo.ingest_files_bulk(df)

    def test_ingest_files_bulk_adds_defaults(self, content_repo):
        """Test that bulk ingestion adds default values."""
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf']
            # No status or version
        })

        result = content_repo.ingest_files_bulk(df)
        assert result['success'] is True

        # Verify defaults were added
        file = content_repo.get_file_by_name("test.pdf")
        assert file['file_status'] == 'Active'
        assert file['raw_file_version_nbr'] == 1


# =============================================================================
# File Update Tests (Point 92)
# =============================================================================


class TestFileUpdates:
    """Test file update operations."""

    def test_update_file_status_success(self, content_repo):
        """Test updating file status."""
        # Insert file
        file_id = content_repo.ingest_file(file_name="test.pdf", status="Active")

        # Update status
        rows = content_repo.update_file_status(file_id, "Archived")

        assert rows == 1

        # Verify update
        file = content_repo.get_file_by_id(file_id)
        assert file['file_status'] == "Archived"

    def test_update_file_status_not_found_raises(self, content_repo):
        """Test updating non-existent file raises error."""
        with pytest.raises(FileNotFoundError, match="not found"):
            content_repo.update_file_status(999, "Archived")

    def test_update_file_status_invalid_status_raises(self, content_repo):
        """Test that invalid status raises error."""
        file_id = content_repo.ingest_file(file_name="test.pdf")

        with pytest.raises(DataValidationError, match="Invalid status"):
            content_repo.update_file_status(file_id, "InvalidStatus")


# =============================================================================
# File Statistics Tests (Point 93)
# =============================================================================


class TestFileStatistics:
    """Test file statistics operations."""

    def test_get_file_stats_empty(self, content_repo):
        """Test statistics for empty table."""
        stats = content_repo.get_file_stats()

        assert stats['total_files'] == 0
        assert stats['by_status'] == {}
        assert stats['by_type'] == {}
        assert stats['unique_files'] == 0

    def test_get_file_stats_with_data(self, content_repo, sample_files_df):
        """Test statistics with data."""
        content_repo.ingest_files_bulk(sample_files_df)

        stats = content_repo.get_file_stats()

        assert stats['total_files'] == 3
        assert stats['by_status']['Active'] == 2
        assert stats['by_status']['Inactive'] == 1
        assert stats['by_type']['pdf'] == 1
        assert stats['by_type']['html'] == 1
        assert stats['by_type']['docx'] == 1
        assert stats['unique_files'] == 3


# =============================================================================
# Foreign Key Validation Tests (Point 94)
# =============================================================================


class TestForeignKeyValidation:
    """Test foreign key validation."""

    def test_validate_file_exists_true(self, content_repo):
        """Test validating existing file."""
        file_id = content_repo.ingest_file(file_name="test.pdf")

        assert content_repo.validate_file_exists(file_id) is True

    def test_validate_file_exists_false(self, content_repo):
        """Test validating non-existent file."""
        assert content_repo.validate_file_exists(999) is False

    def test_validate_file_ids_all_valid(self, content_repo):
        """Test validating multiple valid file IDs."""
        id1 = content_repo.ingest_file(file_name="file1.pdf")
        id2 = content_repo.ingest_file(file_name="file2.pdf")

        valid, invalid = content_repo.validate_file_ids([id1, id2])

        assert len(valid) == 2
        assert len(invalid) == 0
        assert id1 in valid
        assert id2 in valid

    def test_validate_file_ids_some_invalid(self, content_repo):
        """Test validating mix of valid and invalid IDs."""
        id1 = content_repo.ingest_file(file_name="file1.pdf")

        valid, invalid = content_repo.validate_file_ids([id1, 999, 888])

        assert len(valid) == 1
        assert len(invalid) == 2
        assert id1 in valid
        assert 999 in invalid
        assert 888 in invalid


# =============================================================================
# Chunk Operations Tests (Phase 3C: Points 96-105)
# =============================================================================


class TestChunkOperations:
    """Test chunk operations."""

    def test_get_chunks_by_file_empty(self, content_repo):
        """Test getting chunks for file with no chunks."""
        file_id = content_repo.ingest_file(file_name="test.pdf")

        chunks = content_repo.get_chunks_by_file(file_id)

        assert chunks == []

    def test_get_chunks_by_file_success(self, content_repo, sample_files_df, sample_chunks_df):
        """Test getting chunks for file."""
        # Insert files and chunks
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        # Get chunks for file 1
        chunks = content_repo.get_chunks_by_file(1)

        assert len(chunks) == 3
        assert chunks[0]['chunk_index'] == 0
        assert chunks[1]['chunk_index'] == 1
        assert chunks[2]['chunk_index'] == 2

    def test_get_chunk_by_checksum_found(self, content_repo, sample_files_df, sample_chunks_df):
        """Test getting chunk by checksum."""
        # Insert data
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        # Get chunk by checksum
        checksum = sample_chunks_df.iloc[0]['content_checksum']
        chunk = content_repo.get_chunk_by_checksum(checksum)

        assert chunk is not None
        assert chunk['content_checksum'] == checksum

    def test_get_chunk_by_checksum_not_found(self, content_repo):
        """Test getting non-existent chunk returns None."""
        fake_checksum = "a" * 64
        chunk = content_repo.get_chunk_by_checksum(fake_checksum)

        assert chunk is None

    def test_ingest_chunks_success(self, content_repo, sample_files_df, sample_chunks_df):
        """Test bulk chunk ingestion."""
        # Insert files first
        content_repo.ingest_files_bulk(sample_files_df)

        # Insert chunks
        result = content_repo.ingest_chunks(sample_chunks_df)

        assert result['success'] is True
        assert result['rows_inserted'] == 5

    def test_ingest_chunks_fk_violation_raises(self, content_repo, sample_chunks_df):
        """Test that FK violation raises error."""
        # Try to insert chunks without files
        with pytest.raises(ForeignKeyViolationError, match="Foreign key violation"):
            content_repo.ingest_chunks(sample_chunks_df, validate_fk=True)

    def test_ingest_chunks_missing_columns_raises(self, content_repo):
        """Test that missing columns raises error."""
        df = pd.DataFrame({
            'ud_source_file_id': [1]
            # Missing required columns
        })

        with pytest.raises(DataValidationError, match="Missing required columns"):
            content_repo.ingest_chunks(df)

    def test_clear_chunks_for_file(self, content_repo, sample_files_df, sample_chunks_df):
        """Test clearing chunks for file."""
        # Insert data
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        # Verify chunks exist
        chunks_before = content_repo.get_chunks_by_file(1)
        assert len(chunks_before) == 3

        # Clear chunks
        deleted = content_repo.clear_chunks_for_file(1)

        assert deleted == 3

        # Verify chunks cleared
        chunks_after = content_repo.get_chunks_by_file(1)
        assert len(chunks_after) == 0

    def test_get_chunk_stats_overall(self, content_repo, sample_files_df, sample_chunks_df):
        """Test overall chunk statistics."""
        # Insert data
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        stats = content_repo.get_chunk_stats()

        assert stats['total_chunks'] == 5
        assert stats['unique_checksums'] == 5

    def test_get_chunk_stats_for_file(self, content_repo, sample_files_df, sample_chunks_df):
        """Test chunk statistics for specific file."""
        # Insert data
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        stats = content_repo.get_chunk_stats(file_id=1)

        assert stats['file_chunk_count'] == 3
        assert stats['unique_checksums_in_file'] == 3

    def test_find_chunks_by_text(self, content_repo, sample_files_df, sample_chunks_df):
        """Test full-text search in chunks."""
        # Insert data
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        # Search for "chunk 0"
        results = content_repo.find_chunks_by_text("chunk 0")

        assert len(results) == 2  # Two chunks contain "chunk 0"
        assert all("chunk 0" in r['chunk_text'] for r in results)

    def test_validate_chunk_checksum_valid(self, content_repo):
        """Test checksum validation for valid checksum."""
        text = "test content"
        checksum = hashlib.sha256(text.encode('utf-8')).hexdigest()

        is_valid = content_repo.validate_chunk_checksum(checksum, text)

        assert is_valid is True

    def test_validate_chunk_checksum_invalid(self, content_repo):
        """Test checksum validation for invalid checksum."""
        text = "test content"
        wrong_checksum = "a" * 64

        is_valid = content_repo.validate_chunk_checksum(wrong_checksum, text)

        assert is_valid is False

    def test_detect_duplicate_chunks_none(self, content_repo, sample_files_df, sample_chunks_df):
        """Test detecting duplicates when there are none."""
        # Insert data (no duplicates in sample data)
        content_repo.ingest_files_bulk(sample_files_df)
        content_repo.ingest_chunks(sample_chunks_df)

        duplicates = content_repo.detect_duplicate_chunks(1)

        assert len(duplicates) == 0

    def test_detect_duplicate_chunks_found(self, content_repo, sample_files_df):
        """Test detecting duplicate chunks."""
        # Insert file
        content_repo.ingest_files_bulk(sample_files_df.head(1))

        # Insert chunks with duplicate checksum
        duplicate_checksum = "a" * 64
        df = pd.DataFrame({
            'ud_source_file_id': [1, 1, 1],
            'chunk_index': [0, 1, 2],
            'content_checksum': [duplicate_checksum, duplicate_checksum, "b" * 64],
            'chunk_text': ['text1', 'text2', 'text3']
        })

        content_repo.ingest_chunks(df, validate_fk=False)

        duplicates = content_repo.detect_duplicate_chunks(1)

        assert len(duplicates) == 1
        assert duplicates[0]['content_checksum'] == duplicate_checksum
        assert duplicates[0]['occurrence_count'] == 2


# =============================================================================
# Integration Tests
# =============================================================================


class TestContentRepositoryIntegration:
    """End-to-end integration tests."""

    def test_complete_workflow(self, content_repo):
        """Test complete workflow: ingest files, ingest chunks, query."""
        # Step 1: Ingest files
        files_df = pd.DataFrame({
            'raw_file_nme': ['handbook.pdf', 'policy.html'],
            'raw_file_type': ['pdf', 'html'],
            'file_status': ['Active', 'Active']
        })

        result = content_repo.ingest_files_bulk(files_df)
        assert result['success'] is True

        # Step 2: Get file IDs
        file1 = content_repo.get_file_by_name('handbook.pdf')
        file2 = content_repo.get_file_by_name('policy.html')

        # Step 3: Ingest chunks
        chunks_df = pd.DataFrame({
            'ud_source_file_id': [file1['ud_source_file_id']] * 3,
            'chunk_index': [0, 1, 2],
            'content_checksum': [
                hashlib.sha256(f'content {i}'.encode()).hexdigest()
                for i in range(3)
            ],
            'chunk_text': [f'content {i}' for i in range(3)]
        })

        result = content_repo.ingest_chunks(chunks_df)
        assert result['success'] is True

        # Step 4: Query chunks
        chunks = content_repo.get_chunks_by_file(file1['ud_source_file_id'])
        assert len(chunks) == 3

        # Step 5: Get statistics
        stats = content_repo.get_file_stats()
        assert stats['total_files'] == 2

        chunk_stats = content_repo.get_chunk_stats()
        assert chunk_stats['total_chunks'] == 3

        # Step 6: Update status
        content_repo.update_file_status(file1['ud_source_file_id'], 'Archived')

        # Step 7: Clear chunks
        deleted = content_repo.clear_chunks_for_file(file1['ud_source_file_id'])
        assert deleted == 3


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
