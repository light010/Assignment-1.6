"""
Tests for notebook ingestion workflows using repository pattern.

Tests the refactored notebook patterns for:
- 1_content_repo_ingestion.ipynb (v1 ingestion) - Uses ContentRepository
- 5_content_repo_edit.ipynb (v2 ingestion) - Uses ContentRepository

Following TDD approach: Write tests first, then implement.
Uses repository pattern (no direct SQL, no old adapter classes).
"""

import pytest
import sys
import os
import pandas as pd
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock


class TestContentRepoIngestionV1:
    """Test version 1 content repository ingestion using ContentRepository."""

    @pytest.fixture
    def test_backend(self):
        """Create temporary SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        # Create backend with temporary database
        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        # Create schema
        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        # Cleanup
        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass  # File is locked on Windows, OS will clean it up

    def test_repository_exists(self):
        """Test that ContentRepository can be imported."""
        from database.repository import ContentRepository

        assert ContentRepository is not None

    def test_ingestion_from_csv_local(self, test_backend):
        """Test ingesting from CSV using ContentRepository."""
        from database.repository import ContentRepository

        # Create temporary CSV data
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("raw_file_nme,raw_file_type,raw_file_version_nbr,raw_file_path,extracted_markdown_file_path,title_nme,file_status\n")
            f.write("test.pdf,pdf,1,/path/to/test.pdf,/path/to/test.md,Test Document,Active\n")
            csv_path = f.name

        try:
            # Load CSV into DataFrame
            df = pd.read_csv(csv_path)

            # Initialize repository
            content_repo = ContentRepository(test_backend)

            # Ingest from dataframe
            result = content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

            # Verify success
            assert result['success'] == True
            assert result['rows_inserted'] == 1

        finally:
            os.unlink(csv_path)

    def test_ingestion_from_dataframe(self, test_backend):
        """Test ingesting from pandas DataFrame using ContentRepository."""
        from database.repository import ContentRepository

        # Create sample data
        df = pd.DataFrame({
            'raw_file_nme': ['test1.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [1, 1],
            'raw_file_path': ['/path/to/test1.pdf', '/path/to/test2.pdf'],
            'extracted_markdown_file_path': ['/path/to/test1.md', '/path/to/test2.md'],
            'title_nme': ['Test 1', 'Test 2'],
            'file_status': ['Active', 'Active']
        })

        # Initialize repository
        content_repo = ContentRepository(test_backend)

        # Ingest from dataframe
        result = content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        # Verify success
        assert result['success'] == True
        assert result['rows_inserted'] == 2

    def test_get_stats_after_ingestion(self, test_backend):
        """Test getting statistics after ingestion using ContentRepository."""
        from database.repository import ContentRepository

        # Create and ingest sample data
        df = pd.DataFrame({
            'raw_file_nme': ['test1.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [1, 1],
            'raw_file_path': ['/path/to/test1.pdf', '/path/to/test2.pdf'],
            'extracted_markdown_file_path': ['/path/to/test1.md', '/path/to/test2.md'],
            'title_nme': ['Test 1', 'Test 2'],
            'file_status': ['Active', 'Active']
        })

        content_repo = ContentRepository(test_backend)
        content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        # Get stats using repository
        stats = content_repo.get_file_stats()

        # Verify stats
        assert stats['total_files'] == 2
        assert stats['unique_files'] == 2
        assert 'pdf' in stats['by_type']
        assert stats['by_type']['pdf'] == 2


class TestContentRepoIngestionV2:
    """Test version 2 content repository ingestion using ContentRepository."""

    @pytest.fixture
    def test_backend(self):
        """Create temporary SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        # Create backend with temporary database
        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        # Create schema
        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        # Cleanup
        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass  # File is locked on Windows, OS will clean it up

    def test_version_2_ingestion(self, test_backend):
        """Test ingesting version 2 content after version 1 using ContentRepository."""
        from database.repository import ContentRepository

        content_repo = ContentRepository(test_backend)

        # First ingest v1 data
        df_v1 = pd.DataFrame({
            'raw_file_nme': ['test.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [1, 1],
            'raw_file_path': ['/path/to/test.pdf', '/path/to/test2.pdf'],
            'extracted_markdown_file_path': ['/path/to/test_v1.md', '/path/to/test2_v1.md'],
            'title_nme': ['Test v1', 'Test2 v1'],
            'file_status': ['Active', 'Active']
        })

        result_v1 = content_repo.ingest_files_bulk(files_df=df_v1, validate=True, if_exists='append')

        assert result_v1['success'] == True
        assert result_v1['rows_inserted'] == 2

        # Now ingest v2 data (same files, different version)
        df_v2 = pd.DataFrame({
            'raw_file_nme': ['test.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf'],
            'raw_file_version_nbr': [2, 2],
            'raw_file_path': ['/path/to/test.pdf', '/path/to/test2.pdf'],
            'extracted_markdown_file_path': ['/path/to/test_v2.md', '/path/to/test2_v2.md'],
            'title_nme': ['Test v2 UPDATED', 'Test2 v2 UPDATED'],
            'file_status': ['Active', 'Active']
        })

        result_v2 = content_repo.ingest_files_bulk(files_df=df_v2, validate=True, if_exists='append')

        # Verify v2 ingestion
        assert result_v2['success'] == True
        assert result_v2['rows_inserted'] == 2

        # Verify both versions exist in database using repository
        stats = content_repo.get_file_stats()
        assert stats['total_files'] == 4  # 2 v1 + 2 v2

    def test_prerequisite_check_fails_without_v1(self, test_backend):
        """Test that prerequisite check detects no v1 data using ContentRepository."""
        from database.repository import ContentRepository

        content_repo = ContentRepository(test_backend)

        # Try to list v1 files (should be empty)
        v1_files = content_repo.list_files(version=1)

        # Should be empty since we haven't ingested anything
        assert len(v1_files) == 0

    def test_version_distribution_query(self, test_backend):
        """Test querying version distribution using ContentRepository."""
        from database.repository import ContentRepository

        content_repo = ContentRepository(test_backend)

        # Ingest mixed version data
        df = pd.DataFrame({
            'raw_file_nme': ['test1.pdf', 'test1.pdf', 'test2.pdf'],
            'raw_file_type': ['pdf', 'pdf', 'pdf'],
            'raw_file_version_nbr': [1, 2, 1],
            'raw_file_path': ['/path/to/test1.pdf', '/path/to/test1.pdf', '/path/to/test2.pdf'],
            'extracted_markdown_file_path': ['/path/to/test1_v1.md', '/path/to/test1_v2.md', '/path/to/test2_v1.md'],
            'title_nme': ['Test1 v1', 'Test1 v2', 'Test2 v1'],
            'file_status': ['Active', 'Active', 'Active']
        })

        content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        # Query version distribution using repository
        stats = content_repo.get_file_stats()
        by_version = stats.get('by_version', {})

        # Verify distribution
        assert by_version.get(1, 0) == 2  # 2 v1 files
        assert by_version.get(2, 0) == 1  # 1 v2 file


class TestEnvironmentCompatibility:
    """Test that notebooks work in both environments."""

    def test_is_databricks_returns_false_locally(self):
        """Test environment detection in local mode."""
        from utils.env_utils import is_databricks

        # Should return False in local test environment
        assert is_databricks() == False

    def test_configuration_pattern_local(self):
        """Test configuration pattern for local environment."""
        from utils.env_utils import is_databricks

        # Simulate notebook configuration cell
        if is_databricks():
            # This branch should not execute in tests
            CATALOG = "test_catalog"
            SCHEMA = "test_schema"
            DATA_PATH = "/Volumes/test/path"
            DB_PATH = None
        else:
            # This branch should execute in tests
            CATALOG = None
            SCHEMA = None
            DATA_PATH = "data_ingestion/data/5_sample_content_repo_v2_edited.csv"
            DB_PATH = "databases/faq_update.db"

        # Verify local configuration
        assert CATALOG is None
        assert SCHEMA is None
        assert DATA_PATH == "data_ingestion/data/5_sample_content_repo_v2_edited.csv"
        assert DB_PATH == "databases/faq_update.db"

    @patch.dict('os.environ', {'DATABRICKS_RUNTIME_VERSION': '13.3'})
    @patch.dict('sys.modules', {'pyspark.dbutils': MagicMock()})
    def test_configuration_pattern_databricks(self):
        """Test configuration pattern for Databricks environment."""
        # This test simulates Databricks environment
        # In real Databricks, is_databricks() would return True
        pass


class TestDataValidation:
    """Test data validation in notebooks."""

    def test_version_number_validation(self):
        """Test that version number is validated during ingestion."""
        from data_ingestion import ContentRepoIngestion
        from database.setup import setup_database
        import tempfile

        # Create temporary database file
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        # Setup database with tables
        result = setup_database(db_path=db_path, create_tables=True)
        result['adapter'].close()

        # Create sample data with version 2
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [2],
            'raw_file_path': ['/path/to/test.pdf'],
            'extracted_markdown_file_path': ['/path/to/test_v2.md'],
            'title_nme': ['Test v2'],
            'file_status': ['Active']
        })

        # Verify version number in dataframe
        versions = df['raw_file_version_nbr'].unique()
        assert 2 in versions

        ingestion = ContentRepoIngestion(db_path=db_path)
        result = ingestion.ingest_from_dataframe(df)

        assert result['success'] == True

        # Note: Not deleting temp db file to avoid Windows file locking issues

    def test_required_columns_present(self):
        """Test that required columns are present in data."""
        # Define required columns as per notebook
        required_columns = [
            'raw_file_nme',
            'raw_file_type',
            'raw_file_version_nbr',
            'raw_file_path',
            'extracted_markdown_file_path',
            'title_nme',
            'file_status'
        ]

        # Create sample dataframe
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [1],
            'raw_file_path': ['/path/to/test.pdf'],
            'extracted_markdown_file_path': ['/path/to/test.md'],
            'title_nme': ['Test'],
            'file_status': ['Active']
        })

        # Verify all required columns present
        for col in required_columns:
            assert col in df.columns, f"Missing required column: {col}"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
