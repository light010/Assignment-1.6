"""
Integration tests - End-to-end testing using repository pattern.

Tests complete workflows with real database backends:
- SQLite backend for local testing
- Repository pattern for all database operations
- Full workflow from setup to query
"""

import pytest
import tempfile
from pathlib import Path
import pandas as pd


class TestIntegrationRepositoryPattern:
    """End-to-end integration tests using repository pattern."""

    @pytest.fixture
    def test_backend(self):
        """Create temporary SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        # Create backend with temporary database
        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        # Create schema
        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        # Cleanup
        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass  # File is locked on Windows, OS will clean it up

    def test_full_workflow_content_ingestion(self, test_backend):
        """Test complete workflow: setup -> ingest -> query using ContentRepository."""
        from database.repository import ContentRepository

        # Create repository
        content_repo = ContentRepository(test_backend)

        # Insert test data
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [1],
            'raw_file_path': ['/data/test.pdf'],
            'extracted_markdown_file_path': ['/md/test.md'],
            'title_nme': ['Test Doc'],
            'file_status': ['Active']
        })

        result = content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        assert result['success'] == True
        assert result['rows_inserted'] == 1

        # Query it back using repository
        files = content_repo.list_files()
        assert len(files) == 1
        assert files[0]['raw_file_nme'] == 'test.pdf'

        # Get stats
        stats = content_repo.get_file_stats()
        assert stats['total_files'] == 1

    def test_full_workflow_faq_operations(self, test_backend):
        """Test complete FAQ workflow using FAQRepository."""
        from database.repository import FAQRepository

        # Create repository
        faq_repo = FAQRepository(test_backend)

        # Insert test questions
        questions_df = pd.DataFrame({
            'question_text': ['How to test?', 'What is FAQ?'],
            'source_type': ['from_documents', 'from_documents'],
            'generation_method': ['llm_generated', 'llm_generated'],
            'status': ['active', 'active']
        })

        result = faq_repo.ingest_questions(questions_df)
        assert result['success'] == True
        assert result['rows_inserted'] == 2

        # Query FAQs
        questions = faq_repo.list_questions()
        assert len(questions) == 2

        # Insert answers
        answers_df = pd.DataFrame({
            'question_id': [questions[0]['question_id']],
            'answer_text': ['This is how to test.'],
            'status': ['active']
        })

        result = faq_repo.ingest_answers(answers_df)
        assert result['success'] == True
        assert result['rows_inserted'] == 1

        # Verify answer exists
        answers = faq_repo.list_answers()
        assert len(answers) == 1
        assert answers[0]['answer_text'] == 'This is how to test.'

    def test_full_workflow_change_detection(self, test_backend):
        """Test complete change detection workflow using AuditRepository."""
        from database.repository import AuditRepository, ContentRepository
        from detection import ChecksumChangeDetector
        from database.models import ChangeType
        from core.models.detection import DetectionResult
        from datetime import datetime

        # Create repositories
        audit_repo = AuditRepository(test_backend)
        content_repo = ContentRepository(test_backend)

        # First ingest some content
        df = pd.DataFrame({
            'raw_file_nme': ['test.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [1],
            'raw_file_path': ['/data/test.pdf'],
            'extracted_markdown_file_path': ['/md/test.md'],
            'title_nme': ['Test Doc'],
            'file_status': ['Active']
        })

        content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

        # Create test detection results
        changes = [
            DetectionResult(
                old_checksum="",
                new_checksum="abc123",
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.pdf",
                similarity_score=0.0,
                new_content="New content",
                old_content=None,
                metadata={}
            )
        ]

        # Store detection results
        run_id = "test_run_001"
        inserted = audit_repo.store_detection_results(changes, run_id=run_id)
        assert inserted == 1

        # Query results back
        run_changes = audit_repo.get_changes_by_run(run_id)
        assert len(run_changes) == 1
        assert run_changes[0]['change_type'] == 'new_content'

    def test_full_workflow_multi_version_content(self, test_backend):
        """Test workflow with multiple versions of same file."""
        from database.repository import ContentRepository

        content_repo = ContentRepository(test_backend)

        # Ingest v1
        df_v1 = pd.DataFrame({
            'raw_file_nme': ['doc.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [1],
            'raw_file_path': ['/data/doc.pdf'],
            'extracted_markdown_file_path': ['/md/doc_v1.md'],
            'title_nme': ['Doc v1'],
            'file_status': ['Active']
        })

        content_repo.ingest_files_bulk(files_df=df_v1, validate=True, if_exists='append')

        # Ingest v2
        df_v2 = pd.DataFrame({
            'raw_file_nme': ['doc.pdf'],
            'raw_file_type': ['pdf'],
            'raw_file_version_nbr': [2],
            'raw_file_path': ['/data/doc.pdf'],
            'extracted_markdown_file_path': ['/md/doc_v2.md'],
            'title_nme': ['Doc v2 UPDATED'],
            'file_status': ['Active']
        })

        content_repo.ingest_files_bulk(files_df=df_v2, validate=True, if_exists='append')

        # Query all files
        all_files = content_repo.list_files()
        assert len(all_files) == 2

        # Query only v2
        v2_files = content_repo.list_files(version=2)
        assert len(v2_files) == 1
        assert v2_files[0]['title_nme'] == 'Doc v2 UPDATED'

    def test_repository_transaction_rollback(self, test_backend):
        """Test transaction rollback in repository."""
        from database.repository import ContentRepository

        content_repo = ContentRepository(test_backend)

        # Start with clean state
        stats_before = content_repo.get_file_stats()
        count_before = stats_before['total_files']

        try:
            with content_repo.transaction():
                # Insert data
                df = pd.DataFrame({
                    'raw_file_nme': ['rollback_test.pdf'],
                    'raw_file_type': ['pdf'],
                    'raw_file_version_nbr': [1],
                    'raw_file_path': ['/data/rollback_test.pdf'],
                    'extracted_markdown_file_path': ['/md/rollback_test.md'],
                    'title_nme': ['Rollback Test'],
                    'file_status': ['Active']
                })

                content_repo.ingest_files_bulk(files_df=df, validate=True, if_exists='append')

                # Force an error to trigger rollback
                raise Exception("Simulated error for rollback test")

        except Exception:
            # Exception expected
            pass

        # Verify data was rolled back
        stats_after = content_repo.get_file_stats()
        count_after = stats_after['total_files']

        assert count_after == count_before  # Should be same (rolled back)


class TestBackwardCompatibility:
    """Test that new system works with existing patterns."""

    def test_backend_factory_singleton_pattern(self):
        """Test singleton pattern still works correctly."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)

            # Create first backend
            backend1 = BackendFactory.create_backend(config)

            # Create second backend (should be same instance)
            backend2 = BackendFactory.create_backend(config)

            assert backend1 is backend2

            backend1.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_repository_with_different_backends(self):
        """Test that repositories work with any backend implementation."""
        from database.backends.factory import BackendFactory
        from database.repository import ContentRepository
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            # Create SQLite backend
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            # Create schema
            schema_manager = SchemaManager(backend)
            schema_manager.create_all_tables()

            # Create repository
            content_repo = ContentRepository(backend)

            # Repository should work with any backend
            assert content_repo is not None
            assert hasattr(content_repo, 'ingest_files_bulk')
            assert hasattr(content_repo, 'list_files')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
