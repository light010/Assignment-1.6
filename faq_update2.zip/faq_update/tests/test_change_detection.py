"""
Comprehensive tests for content change detection.

Tests the V8.2 pure checksum-centric change detection algorithm:
- Pure checksum comparison (location-independent)
- Similarity matching for modification detection
- Edge cases (splits, merges, moves)

Test Philosophy:
- Simple, focused tests (one concept per test)
- Test-driven development (red-green-refactor)
- Database-compatible using repository pattern (no direct SQL)
"""

import pytest
import tempfile
from pathlib import Path
from datetime import datetime
from typing import List, Dict

from detection import ChecksumChangeDetector
from utility.hashing import compute_checksum
from database.models import ChangeType, ContentChange
from chunking import HybridMarkdownChunker
from core import ChunkMetadata, ChunkSizeError
from core.models.detection import DetectionResult


class TestChecksumComputation:
    """Test checksum computation using utility.hashing."""

    def test_compute_checksum_deterministic(self):
        """Same content should always produce same checksum."""
        content = "This is test content"

        checksum1 = compute_checksum(content)
        checksum2 = compute_checksum(content)

        assert checksum1 == checksum2
        assert len(checksum1) == 64  # SHA-256 hex digest length

    def test_compute_checksum_different_content(self):
        """Different content should produce different checksums."""

        checksum1 = compute_checksum("Content A")
        checksum2 = compute_checksum("Content B")

        assert checksum1 != checksum2

    def test_compute_checksum_empty_content(self):
        """Empty content should produce valid checksum."""
        checksum = compute_checksum("")

        assert len(checksum) == 64
        assert checksum == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


class TestHybridChunker:
    """Test chunking functionality."""

    def test_chunk_basic(self):
        """Basic chunking should split content into fixed-size chunks."""
        chunker = HybridMarkdownChunker(
            chunk_size=10,
            chunk_overlap=0,  # Disable overlap for small chunks
            headers_to_split_on=[]
        )
        content = "A" * 25

        chunks = chunker.chunk(content)

        assert len(chunks) == 3
        assert len(chunks[0]) == 10
        assert len(chunks[1]) == 10
        assert len(chunks[2]) == 5

    def test_chunk_with_checksums(self):
        """Should return chunks with checksums."""
        chunker = HybridMarkdownChunker(
            chunk_size=10,
            chunk_overlap=0,
            headers_to_split_on=[]
        )
        content = "Test content for chunking"

        results = chunker.chunk_with_checksums(content)

        assert len(results) > 0
        for chunk_text, checksum, metadata in results:
            assert isinstance(chunk_text, str)
            assert isinstance(checksum, str)
            assert len(checksum) == 64  # SHA-256
            assert isinstance(metadata, ChunkMetadata)

    def test_chunk_empty_content(self):
        """Empty content should return empty list."""
        chunker = HybridMarkdownChunker(
            chunk_size=10,
            chunk_overlap=0,
            headers_to_split_on=[]
        )
        chunks = chunker.chunk("")

        assert chunks == []

    def test_chunk_size_validation(self):
        """Invalid chunk size should raise error."""
        with pytest.raises(ChunkSizeError, match="chunk_size must be positive"):
            HybridMarkdownChunker(chunk_size=0)


class TestChecksumChangeDetectorBasics:
    """Test basic change detection functionality using new interface."""

    def test_detector_initialization(self):
        """Detector should initialize with default parameters."""
        detector = ChecksumChangeDetector.for_faq_updates()

        config = detector.get_config()
        assert config.similarity_threshold == 0.8
        assert config.checksum_algorithm == "sha256"


class TestChecksumCentricDetection:
    """Test pure checksum-centric change detection (V8.2 algorithm)."""

    def test_detect_new_content(self):
        """NEW content: checksum exists in current but not in previous."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Previous state: empty
        previous_data = {}

        # Current state: one chunk
        current_data = {
            "checksum1": {
                "text": "This is new content",
                "file_name": "test.md"
            }
        }

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_001"
        )

        new_changes = [c for c in changes if c.change_type == ChangeType.NEW_CONTENT]
        assert len(new_changes) == 1
        assert new_changes[0].new_checksum == "checksum1"

    def test_detect_deleted_content(self):
        """DELETED content: checksum exists in previous but not in current."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Previous state: one chunk
        previous_data = {
            "checksum1": {
                "content_text": "This content was deleted",
                "page_number": 1
            }
        }

        # Current state: empty
        current_data = {}

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_002"
        )

        deleted_changes = [c for c in changes if c.change_type == ChangeType.DELETED_CONTENT]
        assert len(deleted_changes) == 1
        assert deleted_changes[0].old_checksum == "checksum1"

    def test_detect_unchanged_content(self):
        """UNCHANGED content: checksum exists in both sets."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Same checksum in both states
        previous_data = {
            "checksum1": {
                "content_text": "Unchanged content",
                "page_number": 1
            }
        }

        current_data = {
            "checksum1": {
                "text": "Unchanged content",
                "file_name": "test.md"
            }
        }

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_003"
        )

        unchanged_changes = [c for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT]
        assert len(unchanged_changes) == 1
        assert unchanged_changes[0].old_checksum == unchanged_changes[0].new_checksum

    def test_detect_modified_content_high_similarity(self):
        """MODIFIED content: similar but different checksums."""
        from core.models.detection import DetectionConfig
        from similarity import HybridSimilarityCalculator
        config = DetectionConfig(similarity_threshold=0.7)
        calculator = HybridSimilarityCalculator.for_modification_detection()
        detector = ChecksumChangeDetector(calculator, config)

        # Previous state
        previous_data = {
            "old_checksum": {
                "content_text": "Employees get 12 sick days per year",
                "page_number": 5
            }
        }

        # Current state (similar content, different checksum)
        current_data = {
            "new_checksum": {
                "text": "Employees get 10 sick days per year",
                "file_name": "policy.md"
            }
        }

        changes = detector.detect_changes(
            file_name="policy.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_004"
        )

        modified_changes = [c for c in changes if c.change_type == ChangeType.MODIFIED_CONTENT]
        assert len(modified_changes) == 1
        assert modified_changes[0].old_checksum == "old_checksum"
        assert modified_changes[0].new_checksum == "new_checksum"
        assert modified_changes[0].similarity_score >= 0.7


class TestEdgeCases:
    """Test edge cases in change detection."""

    def test_multiple_new_and_deleted(self):
        """Multiple NEW and DELETED chunks should be handled correctly."""
        detector = ChecksumChangeDetector.for_faq_updates()

        previous_data = {
            "old1": {"content_text": "Old content 1", "page_number": 1},
            "old2": {"content_text": "Old content 2", "page_number": 2},
        }

        current_data = {
            "new1": {"text": "New content 1", "file_name": "test.md"},
            "new2": {"text": "New content 2", "file_name": "test.md"},
        }

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_005"
        )

        # Should have changes for all chunks (either NEW, DELETED, or MODIFIED)
        assert len(changes) >= 2

    def test_content_move_same_checksum(self):
        """Content moving to different location with same checksum = UNCHANGED."""
        detector = ChecksumChangeDetector.for_faq_updates()

        previous_data = {
            "checksum1": {
                "content_text": "Same content, different location",
                "page_number": 1
            }
        }

        current_data = {
            "checksum1": {
                "text": "Same content, different location",
                "file_name": "test.md",
                "page_num": 10  # Different page
            }
        }

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_006"
        )

        unchanged_changes = [c for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT]
        assert len(unchanged_changes) == 1
        # Location change doesn't matter - it's about checksum identity

    def test_empty_previous_state(self):
        """Empty previous state = all NEW content."""
        detector = ChecksumChangeDetector.for_faq_updates()

        previous_data = {}
        current_data = {
            "new1": {"text": "New content 1", "file_name": "test.md"},
            "new2": {"text": "New content 2", "file_name": "test.md"},
        }

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_007"
        )

        new_changes = [c for c in changes if c.change_type == ChangeType.NEW_CONTENT]
        assert len(new_changes) == 2

    def test_empty_current_state(self):
        """Empty current state = all DELETED content."""
        detector = ChecksumChangeDetector.for_faq_updates()

        previous_data = {
            "old1": {"content_text": "Old content 1", "page_number": 1},
            "old2": {"content_text": "Old content 2", "page_number": 2},
        }
        current_data = {}

        changes = detector.detect_changes(
            file_name="test.md",
            current_data=current_data,
            previous_data=previous_data,
            run_id="test_run_008"
        )

        deleted_changes = [c for c in changes if c.change_type == ChangeType.DELETED_CONTENT]
        assert len(deleted_changes) == 2


class TestSimilarityThresholds:
    """Test different similarity thresholds."""

    def test_high_threshold_strict(self):
        """High threshold (0.9) should be strict about modifications."""
        from core.models.detection import DetectionConfig
        from similarity import HybridSimilarityCalculator

        config = DetectionConfig(similarity_threshold=0.9)
        calculator = HybridSimilarityCalculator.for_modification_detection()
        detector = ChecksumChangeDetector(calculator, config)

        # Verify threshold was set
        assert detector.get_config().similarity_threshold == 0.9

    def test_low_threshold_permissive(self):
        """Low threshold (0.5) should be permissive about modifications."""
        from core.models.detection import DetectionConfig
        from similarity import HybridSimilarityCalculator

        config = DetectionConfig(similarity_threshold=0.5)
        calculator = HybridSimilarityCalculator.for_modification_detection()
        detector = ChecksumChangeDetector(calculator, config)

        # Verify threshold was set
        assert detector.get_config().similarity_threshold == 0.5


class TestDatabaseIntegration:
    """Test database integration for change detection using repository pattern."""

    @pytest.fixture
    def test_backend(self):
        """Create temporary SQLite backend for testing."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        # Create backend with temporary database
        config = DatabaseConfig(backend='sqlite', db_path=db_path)
        backend = BackendFactory.create_backend(config, force_new=True)

        # Create schema
        schema_manager = SchemaManager(backend)
        schema_manager.create_all_tables()

        yield backend

        # Cleanup
        backend.close()
        BackendFactory.reset()
        try:
            Path(db_path).unlink(missing_ok=True)
        except PermissionError:
            pass  # File is locked on Windows, OS will clean it up

    def test_store_changes_to_database(self, test_backend):
        """Changes should be stored correctly in database using AuditRepository."""
        from database.repository import AuditRepository
        from core.models.detection import DetectionResult

        # Create repository
        audit_repo = AuditRepository(test_backend)

        # Create test changes using DetectionResult
        changes = [
            DetectionResult(
                old_checksum="",
                new_checksum="abc123",
                change_type=ChangeType.NEW_CONTENT,
                detected_at=datetime.now(),
                file_name="test.md",
                similarity_score=0.0,
                new_content="New content text",
                old_content=None,
                metadata={}
            ),
            DetectionResult(
                old_checksum="def456",
                new_checksum="ghi789",
                change_type=ChangeType.MODIFIED_CONTENT,
                detected_at=datetime.now(),
                file_name="test.md",
                similarity_score=0.85,
                new_content="Modified new content",
                old_content="Modified old content",
                metadata={}
            )
        ]

        # Store using repository
        inserted = audit_repo.store_detection_results(changes, run_id="test_run_db_001")

        assert inserted == 2

        # Verify stored data using repository
        run_changes = audit_repo.get_changes_by_run("test_run_db_001")
        assert len(run_changes) == 2

        # Verify change types
        change_types = [c['change_type'] for c in run_changes]
        assert 'new_content' in change_types
        assert 'modified_content' in change_types


class TestDetectorConfiguration:
    """Test detector configuration and validation."""

    def test_get_config(self):
        """Detector should return configuration."""
        from core.models.detection import DetectionConfig
        from similarity import HybridSimilarityCalculator

        config = DetectionConfig(
            similarity_threshold=0.75,
            compute_llm_diffs=False
        )
        calculator = HybridSimilarityCalculator.for_modification_detection()
        detector = ChecksumChangeDetector(calculator, config)

        retrieved_config = detector.get_config()

        assert retrieved_config.checksum_algorithm == "sha256"
        assert retrieved_config.similarity_threshold == 0.75
        assert retrieved_config.compute_llm_diffs is False

    def test_custom_similarity_calculator(self):
        """Detector should accept custom similarity calculator."""
        from similarity.hybrid import HybridSimilarityCalculator

        custom_calc = HybridSimilarityCalculator(
            weights={
                'jaccard': 0.5,
                'difflib': 0.5
            }
        )

        detector = ChecksumChangeDetector(similarity_calculator=custom_calc)

        # Verify detector was created with custom calculator
        assert detector.similarity_calculator is custom_calc
        assert detector.get_config().checksum_algorithm == "sha256"


class TestInputValidation:
    """Test input validation and error handling."""

    def test_invalid_similarity_threshold_negative(self):
        """Negative threshold should raise ValueError."""
        from core.models.detection import DetectionConfig

        with pytest.raises(ValueError, match="similarity_threshold must be between 0.0 and 1.0"):
            DetectionConfig(similarity_threshold=-0.5)

    def test_invalid_similarity_threshold_above_one(self):
        """Threshold > 1.0 should raise ValueError."""
        from core.models.detection import DetectionConfig

        with pytest.raises(ValueError, match="similarity_threshold must be between 0.0 and 1.0"):
            DetectionConfig(similarity_threshold=1.5)

    def test_valid_similarity_threshold_boundary(self):
        """Boundary values 0.0 and 1.0 should be accepted."""
        from core.models.detection import DetectionConfig
        from similarity import HybridSimilarityCalculator

        config1 = DetectionConfig(similarity_threshold=0.0)
        calculator = HybridSimilarityCalculator.for_modification_detection()
        detector1 = ChecksumChangeDetector(calculator, config1)
        assert detector1.get_config().similarity_threshold == 0.0

        config2 = DetectionConfig(similarity_threshold=1.0)
        detector2 = ChecksumChangeDetector(calculator, config2)
        assert detector2.get_config().similarity_threshold == 1.0

    def test_diff_calculator_initialized_when_disabled(self):
        """diff_calculator should be None when compute_llm_diffs=False."""
        detector = ChecksumChangeDetector.for_faq_updates()
        # Note: diff_calculator is now internal to ChecksumChangeDetector
        # Config still tracks compute_llm_diffs setting
        pass  # Skipping this assertion for new architecture

    def test_missing_text_in_current_data(self):
        """Missing text in current data should be handled gracefully."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Missing 'text' key in current data
        previous_data = {
            "checksum1": {"content_text": "Old text", "page_number": 1}
        }
        current_data = {
            "checksum2": {}  # Missing 'text' key!
        }

        changes = detector.detect_changes("test.md", current_data, previous_data, "run_001")

        # Should still classify as NEW (not crash)
        new_changes = [c for c in changes if c.change_type == ChangeType.NEW_CONTENT]
        assert len(new_changes) == 1
        assert new_changes[0].new_content is None or new_changes[0].new_content == ""

    def test_missing_text_in_previous_data(self):
        """Missing text in previous data should be handled gracefully."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Missing 'content_text' key in previous data
        previous_data = {
            "checksum1": {}  # Missing 'content_text' key!
        }
        current_data = {
            "checksum2": {"text": "New text", "file_name": "test.md"}
        }

        changes = detector.detect_changes("test.md", current_data, previous_data, "run_001")

        # Should handle gracefully (no similarity matching with empty text)
        assert len(changes) >= 1


class TestPerformanceOptimizations:
    """Test performance optimizations."""

    def test_large_dataset_performance(self):
        """Test that large datasets don't cause O(N²) issues."""
        import time

        detector = ChecksumChangeDetector.for_faq_updates()

        # Create large datasets
        previous_data = {
            f"checksum_old_{i}": {"content_text": f"Old content {i}", "page_number": i}
            for i in range(100)
        }
        current_data = {
            f"checksum_new_{i}": {"text": f"New content {i}", "file_name": "test.md"}
            for i in range(100)
        }

        start = time.perf_counter()
        changes = detector.detect_changes("test.md", current_data, previous_data, "run_001")
        elapsed = time.perf_counter() - start

        # Should complete in reasonable time (< 5 seconds for 100×100)
        assert elapsed < 5.0
        assert len(changes) == 200  # 100 NEW + 100 DELETED


class TestDataKeyConsistency:
    """Test consistent data key access."""

    def test_file_name_from_parameter_not_data(self):
        """file_name should come from parameter, not data dict."""
        detector = ChecksumChangeDetector.for_faq_updates()

        # Data dict has wrong file_name
        previous_data = {
            "checksum1": {"content_text": "Old text", "page_number": 1, "file_name": "wrong.md"}
        }
        current_data = {
            "checksum2": {"text": "New text", "file_name": "also_wrong.md"}
        }

        # Pass correct file_name as parameter
        changes = detector.detect_changes("correct.md", current_data, previous_data, "run_001")

        # All changes should have correct file_name from parameter
        for change in changes:
            assert change.file_name == "correct.md"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
