"""
Unit Tests for Answer Generator Validation

This module specifically tests the validation logic that ensures
answers cannot be generated without questions.

Key Principle: AN ANSWER MUST HAVE A QUESTION

Run tests:
    pytest tests/test_answer_validation.py -v

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import pytest
from unittest.mock import Mock, patch
from oneailib.core.documents.base import Document

from faq_generation import AnswerGenerator, LLMAnswerGenerationError


class TestAnswerQuestionValidation:
    """Test that answers cannot be generated without questions."""

    def test_generate_from_question_missing_question_text(self):
        """Test that empty question_text raises ValueError."""
        gen = AnswerGenerator()

        # Test with None
        with pytest.raises(ValueError, match="Cannot generate answer without a question"):
            gen.generate_from_question(
                question_text=None,
                context_text="Some context",
                question_id="q123",
                content_checksum="abc123"
            )

        # Test with empty string
        with pytest.raises(ValueError, match="Cannot generate answer without a question"):
            gen.generate_from_question(
                question_text="",
                context_text="Some context",
                question_id="q123",
                content_checksum="abc123"
            )

        # Test with whitespace only
        with pytest.raises(ValueError, match="Cannot generate answer without a question"):
            gen.generate_from_question(
                question_text="   ",
                context_text="Some context",
                question_id="q123",
                content_checksum="abc123"
            )

    def test_generate_from_question_missing_question_id(self):
        """Test that empty question_id raises ValueError."""
        gen = AnswerGenerator()

        # Test with None
        with pytest.raises(ValueError, match="Cannot generate answer without a question_id"):
            gen.generate_from_question(
                question_text="What is this?",
                context_text="Some context",
                question_id=None,
                content_checksum="abc123"
            )

        # Test with empty string
        with pytest.raises(ValueError, match="Cannot generate answer without a question_id"):
            gen.generate_from_question(
                question_text="What is this?",
                context_text="Some context",
                question_id="",
                content_checksum="abc123"
            )

    def test_generate_from_documents_missing_question_in_metadata(self):
        """Test that documents without questions in metadata raise ValueError."""
        gen = AnswerGenerator()

        # Document without question in metadata
        bad_docs = [
            Document(
                page_content="Some content",
                metadata={
                    "context": "Some context",
                    "content_checksum": "abc123"
                    # Missing 'question' field!
                }
            )
        ]

        with pytest.raises(ValueError, match="Cannot generate answers without questions"):
            gen.generate_from_documents(bad_docs)

    def test_generate_from_documents_empty_question_in_metadata(self):
        """Test that documents with empty questions raise ValueError."""
        gen = AnswerGenerator()

        # Document with empty question
        bad_docs = [
            Document(
                page_content="Some content",
                metadata={
                    "question": "",  # Empty question!
                    "context": "Some context",
                    "content_checksum": "abc123"
                }
            )
        ]

        with pytest.raises(ValueError, match="Cannot generate answers without questions"):
            gen.generate_from_documents(bad_docs)

    def test_generate_from_documents_whitespace_question(self):
        """Test that documents with whitespace-only questions raise ValueError."""
        gen = AnswerGenerator()

        bad_docs = [
            Document(
                page_content="Some content",
                metadata={
                    "question": "   ",  # Whitespace only!
                    "context": "Some context",
                    "content_checksum": "abc123"
                }
            )
        ]

        with pytest.raises(ValueError, match="Cannot generate answers without questions"):
            gen.generate_from_documents(bad_docs)

    def test_generate_from_documents_mixed_valid_invalid(self):
        """Test that validation fails if ANY document is missing a question."""
        gen = AnswerGenerator()

        # Mix of valid and invalid documents
        mixed_docs = [
            Document(
                page_content="Content 1",
                metadata={
                    "question": "What is this?",
                    "context": "Context 1",
                    "content_checksum": "abc123"
                }
            ),
            Document(
                page_content="Content 2",
                metadata={
                    "context": "Context 2",  # Missing question!
                    "content_checksum": "def456"
                }
            ),
            Document(
                page_content="Content 3",
                metadata={
                    "question": "Another question?",
                    "context": "Context 3",
                    "content_checksum": "ghi789"
                }
            )
        ]

        with pytest.raises(ValueError, match="Cannot generate answers without questions"):
            gen.generate_from_documents(mixed_docs)

    @patch('faq_generation.answer_generator.AzureOpenAIChatModel')
    @patch('faq_generation.answer_generator.DecomposeKeysTransformer')
    @patch('faq_generation.answer_generator.AddDocumentIDTransformer')
    @patch('faq_generation.answer_generator.AddDocumentVersionTransformer')
    def test_generate_from_documents_valid_questions_passes(
        self,
        mock_version,
        mock_id,
        mock_decomposer,
        mock_llm
    ):
        """Test that validation passes when all documents have valid questions."""
        gen = AnswerGenerator()

        # Valid documents with questions
        valid_docs = [
            Document(
                page_content="Content 1",
                metadata={
                    "question": "What is health insurance?",
                    "context": "Context 1",
                    "content_checksum": "abc123"
                }
            ),
            Document(
                page_content="Content 2",
                metadata={
                    "question": "How do I enroll?",
                    "context": "Context 2",
                    "content_checksum": "def456"
                }
            )
        ]

        # Setup mocks
        mock_answer_docs = [
            Document(page_content="", metadata={"answer": "Answer 1", "id": "a1"}),
            Document(page_content="", metadata={"answer": "Answer 2", "id": "a2"})
        ]

        mock_llm_instance = Mock()
        mock_llm_instance.return_value = mock_answer_docs
        mock_llm.return_value = mock_llm_instance

        mock_decomposer_instance = Mock()
        mock_decomposer_instance.transform_documents.return_value = mock_answer_docs
        mock_decomposer.return_value = mock_decomposer_instance

        mock_id_instance = Mock()
        mock_id_instance.transform_documents.return_value = mock_answer_docs
        mock_id.return_value = mock_id_instance

        mock_version_instance = Mock()
        mock_version_instance.transform_documents.return_value = mock_answer_docs
        mock_version.return_value = mock_version_instance

        # Should NOT raise an error
        result = gen.generate_from_documents(valid_docs, generate_embeddings=False)

        assert len(result) == 2
        # Validation passed, so LLM was called
        mock_llm_instance.assert_called_once()

    def test_validation_error_message_helpful(self):
        """Test that validation error messages are helpful and informative."""
        gen = AnswerGenerator()

        bad_docs = [
            Document(
                page_content="Content",
                metadata={
                    "context": "Some context",
                    "content_checksum": "abc123",
                    "some_other_field": "value"
                }
            )
        ]

        try:
            gen.generate_from_documents(bad_docs)
            pytest.fail("Should have raised ValueError")
        except ValueError as e:
            error_message = str(e)

            # Check that error message contains helpful information
            assert "Cannot generate answers without questions" in error_message
            assert "An answer MUST have a question" in error_message
            assert "Document #0" in error_message  # Shows which document
            assert "has_question_key=False" in error_message  # Shows diagnosis
            assert "metadata_keys=" in error_message  # Shows what keys exist


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
