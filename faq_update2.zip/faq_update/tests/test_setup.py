"""
Tests for backend factory and repository setup system.

Tests the new repository pattern architecture:
- BackendFactory for creating backends
- Repository creation and initialization
- Environment detection and configuration

Following TDD approach: Write tests first, then implement.
"""

import pytest
import sys
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock


class TestBackendFactory:
    """Test BackendFactory for creating database backends."""

    def test_create_sqlite_backend(self):
        """Test creating SQLite backend."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            # Verify backend type
            assert backend is not None
            assert hasattr(backend, 'execute_query')
            assert hasattr(backend, 'execute_command')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_create_sqlite_backend_convenience(self):
        """Test convenience method for SQLite backend."""
        from database.backends.factory import BackendFactory

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            backend = BackendFactory.create_sqlite_backend(db_path=db_path)

            assert backend is not None
            assert hasattr(backend, 'execute_query')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_backend_factory_singleton(self):
        """Test that factory returns singleton by default."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)

            # Create first backend
            backend1 = BackendFactory.create_backend(config)

            # Create second backend (should be same instance)
            backend2 = BackendFactory.create_backend(config)

            assert backend1 is backend2

            backend1.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_backend_factory_force_new(self):
        """Test that force_new creates new instance."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)

            # Create first backend
            backend1 = BackendFactory.create_backend(config, force_new=True)

            # Create second backend with force_new
            backend2 = BackendFactory.create_backend(config, force_new=True)

            # Should NOT be same instance
            assert backend1 is not backend2

            backend1.close()
            backend2.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_backend_factory_reset(self):
        """Test resetting factory singleton."""
        from database.backends.factory import BackendFactory
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)

            # Create backend
            backend1 = BackendFactory.create_backend(config)

            # Reset
            BackendFactory.reset()

            # Create new backend after reset
            backend2 = BackendFactory.create_backend(config)

            # Should NOT be same instance (reset cleared it)
            assert backend1 is not backend2

            backend2.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass


class TestDatabaseConfig:
    """Test DatabaseConfig system."""

    def test_create_sqlite_config(self):
        """Test creating SQLite configuration."""
        from database.config import DatabaseConfig

        config = DatabaseConfig(backend='sqlite', db_path='test.db')

        assert config.backend == 'sqlite'
        assert config.db_path == 'test.db'
        assert config.is_sqlite() == True
        assert config.is_databricks() == False

    def test_create_databricks_config(self):
        """Test creating Databricks configuration."""
        from database.config import DatabaseConfig

        config = DatabaseConfig(
            backend='databricks',
            catalog='test_catalog',
            schema='test_schema'
        )

        assert config.backend == 'databricks'
        assert config.catalog == 'test_catalog'
        assert config.schema == 'test_schema'
        assert config.is_sqlite() == False
        assert config.is_databricks() == True

    def test_config_validation_sqlite_requires_path(self):
        """Test that SQLite config requires db_path."""
        from database.config import DatabaseConfig

        with pytest.raises(ValueError, match="SQLite backend requires 'db_path'"):
            DatabaseConfig(backend='sqlite')

    def test_config_validation_databricks_requires_catalog(self):
        """Test that Databricks config requires catalog and schema."""
        from database.config import DatabaseConfig

        with pytest.raises(ValueError, match="Databricks backend requires 'catalog'"):
            DatabaseConfig(backend='databricks')

        with pytest.raises(ValueError, match="Databricks backend requires 'schema'"):
            DatabaseConfig(backend='databricks', catalog='test')

    def test_config_from_env(self):
        """Test loading config from environment variables."""
        from database.config import DatabaseConfig

        # Mock SQLite environment
        with patch.dict(os.environ, {'DATABASE_BACKEND': 'sqlite', 'DATABASE_PATH': 'env_test.db'}):
            config = DatabaseConfig.from_env()

            assert config.backend == 'sqlite'
            assert config.db_path == 'env_test.db'

    def test_config_connection_string(self):
        """Test connection string generation."""
        from database.config import DatabaseConfig

        # SQLite
        config_sqlite = DatabaseConfig(backend='sqlite', db_path='test.db')
        assert config_sqlite.get_connection_string() == 'sqlite://test.db'

        # Databricks
        config_databricks = DatabaseConfig(backend='databricks', catalog='cat', schema='sch')
        assert config_databricks.get_connection_string() == 'databricks://cat.sch'


class TestRepositoryCreation:
    """Test creating repositories from backends."""

    def test_create_content_repository(self):
        """Test creating ContentRepository with backend."""
        from database.backends.factory import BackendFactory
        from database.repository import ContentRepository
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            # Create schema
            schema_manager = SchemaManager(backend)
            schema_manager.create_all_tables()

            # Create repository
            content_repo = ContentRepository(backend)

            assert content_repo is not None
            assert hasattr(content_repo, 'ingest_files_bulk')
            assert hasattr(content_repo, 'get_file_stats')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_create_faq_repository(self):
        """Test creating FAQRepository with backend."""
        from database.backends.factory import BackendFactory
        from database.repository import FAQRepository
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            # Create schema
            schema_manager = SchemaManager(backend)
            schema_manager.create_all_tables()

            # Create repository
            faq_repo = FAQRepository(backend)

            assert faq_repo is not None
            assert hasattr(faq_repo, 'ingest_questions')
            assert hasattr(faq_repo, 'ingest_answers')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass

    def test_create_audit_repository(self):
        """Test creating AuditRepository with backend."""
        from database.backends.factory import BackendFactory
        from database.repository import AuditRepository
        from database.config import DatabaseConfig
        from database.schema_manager import SchemaManager

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            # Create schema
            schema_manager = SchemaManager(backend)
            schema_manager.create_all_tables()

            # Create repository
            audit_repo = AuditRepository(backend)

            assert audit_repo is not None
            assert hasattr(audit_repo, 'store_detection_results')
            assert hasattr(audit_repo, 'get_changes_by_run')

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass


class TestSchemaManager:
    """Test SchemaManager with backends."""

    def test_create_all_tables(self):
        """Test creating all tables using SchemaManager."""
        from database.backends.factory import BackendFactory
        from database.schema_manager import SchemaManager
        from database.config import DatabaseConfig

        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name

        try:
            config = DatabaseConfig(backend='sqlite', db_path=db_path)
            backend = BackendFactory.create_backend(config, force_new=True)

            schema_manager = SchemaManager(backend)
            schema_manager.create_all_tables()

            # Verify tables exist
            tables = backend.execute_query(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            table_names = [t['name'] for t in tables]

            expected_tables = [
                'content_repo',
                'content_chunks',
                'faq_questions',
                'faq_answers',
                'faq_question_sources',
                'faq_answer_sources',
                'content_change_log',
                'faq_audit_log'
            ]

            for table in expected_tables:
                assert table in table_names, f"Missing table: {table}"

            backend.close()
        finally:
            BackendFactory.reset()
            try:
                Path(db_path).unlink(missing_ok=True)
            except PermissionError:
                pass


class TestEnvironmentDetection:
    """Test environment detection for configuration."""

    def test_is_databricks_returns_false_locally(self):
        """Test environment detection in local mode."""
        from utility.environment import is_databricks

        # Should return False in local test environment
        assert is_databricks() == False

    @patch.dict('os.environ', {'DATABRICKS_RUNTIME_VERSION': '13.3'})
    def test_is_databricks_returns_true_in_databricks(self):
        """Test environment detection with Databricks env var."""
        from utility.environment import is_databricks

        # Should detect Databricks
        assert is_databricks() == True

    def test_config_auto_detection_local(self):
        """Test config auto-detection in local environment."""
        from database.config import DatabaseConfig

        # In local environment, from_env() should default to SQLite
        with patch.dict(os.environ, {}, clear=True):
            config = DatabaseConfig.from_env()

            assert config.backend == 'sqlite'
            assert config.db_path is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
