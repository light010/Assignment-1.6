"""
Utility Module - Impact-Specific Helpers and Tools

This module provides utility functions, validators, metrics collectors,
and other helper tools specific to FAQ impact analysis.

Utility Categories:

1. Metrics and Observability
   - ImpactMetricsCollector: Collect metrics during analysis/execution
   - PerformanceTracker: Track timing and performance data
   - HealthChecker: Verify system health before operations

2. Validators
   - QuestionValidator: Validate generated questions
   - AnswerValidator: Validate generated answers
   - ProvenanceValidator: Validate source links
   - ConfigValidator: Validate configuration objects

3. Formatters
   - ReportFormatter: Format ImpactAnalysisReport for display
   - DiffFormatter: Format diffs for human/LLM consumption
   - LogFormatter: Format logs for debugging

4. Helpers
   - ChecksumHelper: Compute and compare checksums
   - BatchHelper: Batch operations for efficiency
   - RetryHelper: Retry logic with exponential backoff

5. Constants
   - DEFAULT_BATCH_SIZE: 10
   - MAX_RETRY_ATTEMPTS: 3
   - CACHE_TTL_SECONDS: 3600

Example - Metrics Collection:
    >>> from faq_impact.utility import ImpactMetricsCollector
    >>>
    >>> metrics = ImpactMetricsCollector()
    >>> with metrics.track("analysis_phase"):
    ...     report = analyzer.analyze_changes()
    >>>
    >>> print(f"Analysis took {metrics.get_duration('analysis_phase')}s")
    >>> print(f"Analyzed {metrics.get_counter('chunks_processed')} chunks")

Example - Validation:
    >>> from faq_impact.utility import QuestionValidator
    >>>
    >>> validator = QuestionValidator(config)
    >>> is_valid = validator.validate(
    ...     question_text="What is the capital of France?",
    ...     min_length=10,
    ...     max_length=200
    ... )
    >>> if not is_valid:
    ...     print(f"Validation errors: {validator.errors}")

Example - Report Formatting:
    >>> from faq_impact.utility import ReportFormatter
    >>>
    >>> formatter = ReportFormatter(format="markdown")
    >>> markdown = formatter.format(report)
    >>> print(markdown)
    # Impact Analysis Report
    - New chunks: 5
    - Modified chunks: 3
    - Questions to regenerate: 12

Example - Retry Logic:
    >>> from faq_impact.utility import RetryHelper
    >>>
    >>> retry = RetryHelper(max_attempts=3, backoff_factor=2)
    >>> result = retry.execute(
    ...     func=llm_client.generate,
    ...     args=(prompt,),
    ...     retryable_exceptions=(TimeoutError, ConnectionError)
    ... )

Design Principles:
    - Focused Utilities: Each utility has a single, clear purpose
    - Reusability: Utilities can be used across modules
    - Testability: Each utility can be tested independently
    - No Business Logic: Utilities are pure helpers, no domain logic

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Imports will be added as utilities are implemented
__all__ = []
