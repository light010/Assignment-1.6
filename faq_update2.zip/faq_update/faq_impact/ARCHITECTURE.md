# FAQ Impact Analysis - Architecture

Detailed architectural documentation for the FAQ Impact Analysis module.

## Table of Contents

1. [System Overview](#system-overview)
2. [Architectural Principles](#architectural-principles)
3. [Module Architecture](#module-architecture)
4. [Data Flow](#data-flow)
5. [Design Patterns](#design-patterns)
6. [Component Details](#component-details)
7. [Database Design](#database-design)
8. [Integration Points](#integration-points)
9. [Decision Trees](#decision-trees)
10. [Sequence Diagrams](#sequence-diagrams)

## System Overview

### Purpose

The FAQ Impact Analysis module automates the process of maintaining FAQ content when source documents change. It identifies which questions and answers need updating and executes those updates intelligently.

### Core Problem

When source content changes, we need to:
1. Identify all affected Q/A pairs
2. Determine appropriate action (regenerate, deactivate, keep)
3. Execute changes while maintaining provenance
4. Ensure consistency and recoverability

### Solution Approach

**Two-Phase Design**: Separate analysis (planning) from application (execution)

```
┌─────────────────────────────────────────────────────────────┐
│                     PHASE 1: ANALYSIS                       │
│                      (Read-Only)                            │
├─────────────────────────────────────────────────────────────┤
│  Input: DetectionResult (new/modified/deleted chunks)       │
│  Output: ImpactAnalysisReport (what needs to change)        │
│  Duration: Seconds to minutes                               │
│  Reversible: Yes (no data modified)                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
                    Review / Approval
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                    PHASE 2: APPLICATION                     │
│                     (Writes Data)                           │
├─────────────────────────────────────────────────────────────┤
│  Input: ImpactAnalysisReport (approved plan)                │
│  Output: ExecutionReport (what changed)                     │
│  Duration: Minutes to hours (LLM generation)                │
│  Reversible: Partial (transaction rollback + audit log)     │
└─────────────────────────────────────────────────────────────┘
```

## Architectural Principles

### 1. Separation of Concerns

**Analysis vs. Application**
- Analysis determines WHAT needs to change (read-only)
- Application determines HOW to execute changes (writes)
- Clear boundary enables review workflows

**Strategy vs. Execution**
- Strategies analyze impact
- Executors apply changes
- Services provide reusable operations

### 2. Dependency Inversion

```
┌──────────────────────────────────────────────────────┐
│          High-Level Policy (Business Logic)          │
│  ImpactAnalyzer, Strategies, Executors, Services     │
└──────────────────────────────────────────────────────┘
                       ↓ Depends On ↓
┌──────────────────────────────────────────────────────┐
│              Abstractions (Interfaces)               │
│   ImpactStrategy, ChangeExecutor, IRepository        │
└──────────────────────────────────────────────────────┘
                       ↑ Implements ↑
┌──────────────────────────────────────────────────────┐
│         Low-Level Details (Implementations)          │
│  NewContentStrategy, SQLRepository, LLMClient        │
└──────────────────────────────────────────────────────┘
```

### 3. Single Responsibility

Each component has ONE reason to change:
- `ProvenanceAnalyzer`: Maps chunks to questions
- `DiffEvaluator`: Evaluates if changes are meaningful
- `QuestionGenerator`: Generates questions from content
- `ProvenanceManager`: Manages Q/A source links

### 4. Open/Closed

Open for extension, closed for modification:
- Add new strategies without changing ImpactAnalyzer
- Add new executors without changing ChangeExecutor
- Add new services without changing strategies

### 5. Dependency Injection

All dependencies injected, not created:

```python
# ❌ Bad: Creates dependencies internally
class ImpactAnalyzer:
    def __init__(self, backend):
        self.strategy = NewContentStrategy()  # Hard-coded

# ✅ Good: Dependencies injected
class ImpactAnalyzer:
    def __init__(
        self,
        backend: DatabaseBackend,
        strategies: Dict[ChangeType, ImpactStrategy]  # Injected
    ):
        self.backend = backend
        self.strategies = strategies
```

## Module Architecture

### Layer Architecture

```
┌────────────────────────────────────────────────────────────┐
│                    Presentation Layer                      │
│                  (Notebooks, CLI, API)                     │
└────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────┐
│                   Application Layer                        │
│      ImpactAnalyzer, ChangeExecutor (Coordinators)         │
└────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────┐
│                     Domain Layer                           │
│  Strategies, Executors, Services (Business Logic)          │
└────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────┐
│                  Infrastructure Layer                      │
│    Repositories, LLM Client, Database (Technical)          │
└────────────────────────────────────────────────────────────┘
```

### Component Diagram

```
┌─────────────────── faq_impact ───────────────────────┐
│                                                       │
│  ┌─────────────┐         ┌──────────────┐          │
│  │   Analysis  │         │ Application  │          │
│  │    Phase    │         │    Phase     │          │
│  └─────────────┘         └──────────────┘          │
│         ↓                        ↓                   │
│  ┌─────────────┐         ┌──────────────┐          │
│  │ Strategies  │         │  Executors   │          │
│  │  (What to   │         │  (How to     │          │
│  │   change)   │         │   change)    │          │
│  └─────────────┘         └──────────────┘          │
│         ↓                        ↓                   │
│  ┌──────────────────────────────────────┐          │
│  │          Shared Services              │          │
│  │  (Provenance, Generation, Validation) │          │
│  └──────────────────────────────────────┘          │
│         ↓                        ↓                   │
│  ┌──────────────────────────────────────┐          │
│  │          Core Models & Enums          │          │
│  │    (Domain Value Objects)             │          │
│  └──────────────────────────────────────┘          │
│                     ↓                                │
│  ┌──────────────────────────────────────┐          │
│  │       Database Repository Layer       │          │
│  │     (Database Operations)             │          │
│  └──────────────────────────────────────┘          │
└───────────────────────────────────────────────────┘
                      ↓
┌───────────────────────────────────────────────────┐
│            External Dependencies                  │
│  - detection (ChecksumChangeDetector)             │
│  - database.backends (SQLite, Databricks)         │
│  - LLM Client (OpenAI, Azure, etc.)               │
└───────────────────────────────────────────────────┘
```

## Data Flow

### Complete Workflow

```
1. Content Changes Detected
   ↓
   [detection.ChecksumChangeDetector]
   - Compares old vs new checksums
   - Generates DetectionResult
   ↓
2. Impact Analysis (Read-Only)
   ↓
   [faq_impact.analysis.ImpactAnalyzer]
   - For each change, select strategy
   - Strategy analyzes impact
   ↓
   [Impact Strategies]
   - NewContentStrategy    → identifies Q/A to generate
   - ModifiedContentStrategy → identifies Q/A to regenerate
   - DeletedContentStrategy  → identifies Q/A to deactivate
   ↓
   [Analysis Services]
   - ProvenanceAnalyzer    → maps chunks to questions
   - DiffEvaluator         → evaluates change severity
   - RegenerationPlanner   → creates regeneration plans
   ↓
   [ImpactAnalysisReport Generated]
   - Summary statistics
   - Detailed impact per change
   - Recommended actions
   ↓
3. Review & Approval (Human/Automated)
   ↓
4. Change Execution (Writes Data)
   ↓
   [faq_impact.application.ChangeExecutor]
   - For each planned change, select executor
   - Executor applies changes
   ↓
   [Change Executors]
   - NewContentExecutor      → creates Q/A pairs
   - ModifiedContentExecutor → regenerates Q/A pairs
   - DeletedContentExecutor  → deactivates/regenerates Q/A pairs
   ↓
   [Application Services]
   - QuestionGenerator     → generates questions
   - AnswerGenerator       → generates answers
   - ProvenanceManager     → updates source links
   - StatusManager         → updates status
   ↓
   [Repository Layer]
   - Persists to database
   - Maintains transactions
   ↓
   [ExecutionReport Generated]
   - Summary of changes made
   - Success/failure counts
   - Error details
```

### Data Flow Diagram

```
┌──────────────┐
│   Content    │
│  Repository  │
└──────────────┘
       ↓
┌──────────────┐
│   Chunks     │  Checksum    ┌─────────────┐
│   Table      │────────────→│  Detection  │
└──────────────┘              │   Module    │
                              └─────────────┘
                                     ↓
                              ┌─────────────┐
                              │ Detection   │
                              │   Result    │
                              └─────────────┘
                                     ↓
                              ┌─────────────┐
                              │   Impact    │
                              │  Analyzer   │
                              └─────────────┘
                                     ↓
                   ┌─────────────────┼─────────────────┐
                   ↓                 ↓                 ↓
           ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
           │     New      │  │   Modified   │  │   Deleted    │
           │   Content    │  │   Content    │  │   Content    │
           │  Strategy    │  │  Strategy    │  │  Strategy    │
           └──────────────┘  └──────────────┘  └──────────────┘
                   ↓                 ↓                 ↓
                   └─────────────────┼─────────────────┘
                                     ↓
                   ┌──────────────────────────────────┐
                   │      Provenance Analysis         │
                   │  (chunk → questions mapping)     │
                   └──────────────────────────────────┘
                                     ↓
                   ┌──────────────────────────────────┐
                   │     ImpactAnalysisReport         │
                   │  (plan of what needs to change)  │
                   └──────────────────────────────────┘
                                     ↓
                            Review / Approval
                                     ↓
                   ┌──────────────────────────────────┐
                   │       ChangeExecutor             │
                   └──────────────────────────────────┘
                                     ↓
                   ┌─────────────────┼─────────────────┐
                   ↓                 ↓                 ↓
           ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
           │     New      │  │   Modified   │  │   Deleted    │
           │   Content    │  │   Content    │  │   Content    │
           │  Executor    │  │  Executor    │  │  Executor    │
           └──────────────┘  └──────────────┘  └──────────────┘
                   ↓                 ↓                 ↓
           ┌──────────────────────────────────────────────────┐
           │          Application Services                    │
           │  - QuestionGenerator                             │
           │  - AnswerGenerator                               │
           │  - ProvenanceManager                             │
           │  - StatusManager                                 │
           └──────────────────────────────────────────────────┘
                                     ↓
           ┌──────────────────────────────────────────────────┐
           │            Database Updates                      │
           │  - questions table                               │
           │  - answers table                                 │
           │  - question_source table (provenance)            │
           └──────────────────────────────────────────────────┘
                                     ↓
                   ┌──────────────────────────────────┐
                   │      ExecutionReport             │
                   │  (summary of changes made)       │
                   └──────────────────────────────────┘
```

## Design Patterns

### 1. Strategy Pattern

**Problem**: Different change types require different handling logic.

**Solution**: Encapsulate algorithms in separate strategy classes.

```python
# Strategy Interface
class ImpactStrategy(ABC):
    @abstractmethod
    def analyze(
        self,
        change: DetectedChange,
        repository: ImpactRepository
    ) -> ChangeImpact:
        pass

# Concrete Strategies
class NewContentStrategy(ImpactStrategy):
    def analyze(self, change, repository):
        # Generate new Q/A pairs
        return ChangeImpact(action=ChangeAction.GENERATE, ...)

class ModifiedContentStrategy(ImpactStrategy):
    def analyze(self, change, repository):
        # Regenerate affected Q/A pairs
        return ChangeImpact(action=ChangeAction.REGENERATE, ...)

class DeletedContentStrategy(ImpactStrategy):
    def analyze(self, change, repository):
        # Deactivate or regenerate Q/A pairs
        return ChangeImpact(action=ChangeAction.DEACTIVATE, ...)

# Context
class ImpactAnalyzer:
    def __init__(self, strategies: Dict[ChangeType, ImpactStrategy]):
        self.strategies = strategies

    def analyze_change(self, change):
        strategy = self.strategies[change.change_type]
        return strategy.analyze(change, self.repository)
```

### 2. Repository Pattern

**Problem**: Business logic shouldn't depend on database implementation details.

**Solution**: Abstract database operations behind repository interfaces.

```python
# Repository Interface
class ImpactRepository(ABC):
    @abstractmethod
    def get_affected_questions(self, chunk_id: int) -> List[int]:
        pass

    @abstractmethod
    def get_question_sources(self, question_id: int) -> List[int]:
        pass

# Concrete Repository
class SQLImpactRepository(ImpactRepository):
    def __init__(self, backend: DatabaseBackend):
        self.backend = backend

    def get_affected_questions(self, chunk_id: int) -> List[int]:
        query = "SELECT question_id FROM question_source WHERE chunk_id = ?"
        return self.backend.execute_query(query, (chunk_id,))
```

### 3. Service Layer

**Problem**: Strategies and executors need reusable operations.

**Solution**: Extract reusable operations into focused services.

```python
# Services are single-responsibility, stateless
class ProvenanceAnalyzer:
    def __init__(self, repository: ImpactRepository):
        self.repository = repository

    def get_questions_by_chunk(self, chunk_id: int) -> List[int]:
        return self.repository.get_affected_questions(chunk_id)

    def is_single_source_question(self, question_id: int) -> bool:
        sources = self.repository.get_question_sources(question_id)
        return len(sources) == 1

# Strategies compose services
class DeletedContentStrategy(ImpactStrategy):
    def __init__(self, provenance_analyzer: ProvenanceAnalyzer):
        self.provenance = provenance_analyzer

    def analyze(self, change, repository):
        questions = self.provenance.get_questions_by_chunk(change.chunk_id)
        for q_id in questions:
            if self.provenance.is_single_source_question(q_id):
                # Deactivate
                pass
            else:
                # Regenerate
                pass
```

### 4. Value Objects

**Problem**: Ensure data integrity and immutability.

**Solution**: Use frozen dataclasses with validation.

```python
from dataclasses import dataclass
from typing import List

@dataclass(frozen=True)
class ChangeImpact:
    chunk_id: int
    change_type: ChangeType
    action: ChangeAction
    affected_question_ids: List[int]
    regeneration_plan: Optional[RegenerationPlan] = None

    def __post_init__(self):
        if self.chunk_id <= 0:
            raise ValueError("chunk_id must be positive")
        if not self.affected_question_ids and self.action != ChangeAction.KEEP:
            raise ValueError("Must specify affected questions")
```

### 5. Dependency Injection

**Problem**: Hard-coded dependencies make testing difficult.

**Solution**: Inject all dependencies through constructors.

```python
# Dependencies injected
class ImpactAnalyzer:
    def __init__(
        self,
        backend: DatabaseBackend,
        repository: ImpactRepository,
        strategies: Dict[ChangeType, ImpactStrategy],
        config: ImpactAnalysisConfig
    ):
        self.backend = backend
        self.repository = repository
        self.strategies = strategies
        self.config = config

# Easy to test with mocks
def test_analyzer():
    mock_backend = Mock(spec=DatabaseBackend)
    mock_repository = Mock(spec=ImpactRepository)
    mock_strategies = {ChangeType.NEW: Mock(spec=ImpactStrategy)}
    config = ImpactAnalysisConfig()

    analyzer = ImpactAnalyzer(
        mock_backend,
        mock_repository,
        mock_strategies,
        config
    )
    # Test analyzer...
```

## Component Details

### Core Models

**ImpactAnalysisReport**
```python
@dataclass(frozen=True)
class ImpactAnalysisReport:
    """Complete report of detected changes and their impacts"""
    analysis_run_id: int
    detection_run_id: int
    timestamp: datetime
    new_content_count: int
    modified_content_count: int
    deleted_content_count: int
    changes: List[ChangeImpact]
    questions_to_generate: List[int]  # chunk_ids
    questions_to_regenerate: List[int]  # question_ids
    questions_to_deactivate: List[int]  # question_ids
    summary_metrics: ImpactMetrics
```

**ChangeImpact**
```python
@dataclass(frozen=True)
class ChangeImpact:
    """Impact of a single content change"""
    chunk_id: int
    old_checksum: Optional[str]
    new_checksum: Optional[str]
    change_type: ChangeType  # NEW, MODIFIED, DELETED
    action: ChangeAction  # GENERATE, REGENERATE, DEACTIVATE, KEEP
    affected_question_ids: List[int]
    regeneration_plan: Optional[RegenerationPlan]
    provenance_updates: List[ProvenanceUpdate]
    reason: str  # Human-readable explanation
```

### Analysis Components

**ImpactAnalyzer** (Main Entry Point)
```python
class ImpactAnalyzer:
    """Coordinates impact analysis workflow"""

    def analyze_changes(self) -> ImpactAnalysisReport:
        """Main entry point for analysis"""
        # 1. Get detection results
        detection_result = self.get_latest_detection()

        # 2. Analyze each change
        impacts = []
        for change in detection_result.changes:
            strategy = self.strategies[change.change_type]
            impact = strategy.analyze(change, self.repository)
            impacts.append(impact)

        # 3. Build report
        return self._build_report(impacts)
```

**Impact Strategies**

*NewContentStrategy*
```python
class NewContentStrategy(ImpactStrategy):
    """Handle newly added content chunks"""

    def analyze(self, change, repository):
        # New content → generate Q/A
        return ChangeImpact(
            chunk_id=change.chunk_id,
            new_checksum=change.new_checksum,
            change_type=ChangeType.NEW,
            action=ChangeAction.GENERATE,
            affected_question_ids=[],
            reason="New content requires Q/A generation"
        )
```

*ModifiedContentStrategy*
```python
class ModifiedContentStrategy(ImpactStrategy):
    """Handle modified content chunks"""

    def __init__(
        self,
        provenance_analyzer: ProvenanceAnalyzer,
        diff_evaluator: DiffEvaluator,
        regeneration_planner: RegenerationPlanner
    ):
        self.provenance = provenance_analyzer
        self.diff_eval = diff_evaluator
        self.planner = regeneration_planner

    def analyze(self, change, repository):
        # 1. Find affected questions
        questions = self.provenance.get_questions_by_chunk(change.chunk_id)

        # 2. Evaluate diff
        old_content = repository.get_content(change.old_checksum)
        new_content = repository.get_content(change.new_checksum)
        diff = repository.get_llm_friendly_diff(change.chunk_id)
        evaluation = self.diff_eval.evaluate_diff(old_content, new_content, diff)

        # 3. Determine which questions need regeneration
        questions_to_regen = []
        for q_id in questions:
            if self.diff_eval.affects_question(evaluation, q_id):
                questions_to_regen.append(q_id)

        # 4. Create regeneration plan
        plan = self.planner.plan_for_modified_content(
            change.chunk_id,
            questions_to_regen,
            evaluation
        )

        return ChangeImpact(
            chunk_id=change.chunk_id,
            old_checksum=change.old_checksum,
            new_checksum=change.new_checksum,
            change_type=ChangeType.MODIFIED,
            action=ChangeAction.REGENERATE,
            affected_question_ids=questions_to_regen,
            regeneration_plan=plan,
            provenance_updates=[
                ProvenanceUpdate(
                    question_id=q_id,
                    remove_checksum=change.old_checksum,
                    add_checksum=change.new_checksum
                )
                for q_id in questions_to_regen
            ],
            reason=f"Content changed: {evaluation.summary}"
        )
```

*DeletedContentStrategy*
```python
class DeletedContentStrategy(ImpactStrategy):
    """Handle deleted content chunks"""

    def __init__(
        self,
        provenance_analyzer: ProvenanceAnalyzer,
        regeneration_planner: RegenerationPlanner
    ):
        self.provenance = provenance_analyzer
        self.planner = regeneration_planner

    def analyze(self, change, repository):
        # 1. Find affected questions
        questions = self.provenance.get_questions_by_chunk(change.chunk_id)

        # 2. Classify questions
        to_deactivate = []
        to_regenerate = []

        for q_id in questions:
            if self.provenance.is_single_source_question(q_id):
                to_deactivate.append(q_id)
            else:
                to_regenerate.append(q_id)

        # 3. Create regeneration plan for multi-source questions
        plan = self.planner.plan_for_deleted_content(
            change.chunk_id,
            to_regenerate
        )

        return ChangeImpact(
            chunk_id=change.chunk_id,
            old_checksum=change.old_checksum,
            new_checksum=None,
            change_type=ChangeType.DELETED,
            action=ChangeAction.DEACTIVATE if to_regenerate else ChangeAction.DEACTIVATE,
            affected_question_ids=to_deactivate + to_regenerate,
            regeneration_plan=plan if to_regenerate else None,
            provenance_updates=[
                ProvenanceUpdate(
                    question_id=q_id,
                    remove_checksum=change.old_checksum
                )
                for q_id in questions
            ],
            reason=f"Content deleted: deactivate {len(to_deactivate)}, regenerate {len(to_regenerate)}"
        )
```

### Application Components

**ChangeExecutor** (Main Entry Point)
```python
class ChangeExecutor:
    """Executes planned changes from ImpactAnalysisReport"""

    def apply_changes(self, report: ImpactAnalysisReport) -> ExecutionReport:
        """Main entry point for execution"""
        results = []

        with self.repository.transaction():
            for impact in report.changes:
                executor = self.executors[impact.action]
                result = executor.execute(impact, self.repository, self.services)
                results.append(result)

        return self._build_report(results)
```

**Change Executors**

*NewContentExecutor*
```python
class NewContentExecutor(ChangeExecutor):
    """Creates Q/A pairs for new content"""

    def execute(self, impact, repository, services):
        # 1. Get content
        content = repository.get_content(impact.new_checksum)

        # 2. Generate questions
        questions = services.question_generator.generate_from_chunk(
            impact.chunk_id,
            content
        )

        # 3. Generate answers
        answers = []
        for question in questions:
            answer = services.answer_generator.generate_for_question(
                question.id,
                question.text,
                content
            )
            answers.append(answer)

        # 4. Update provenance
        for question in questions:
            services.provenance_manager.add_source(
                question.id,
                impact.chunk_id,
                impact.new_checksum
            )

        # 5. Activate
        for question in questions:
            services.status_manager.activate_question(question.id)

        return NewContentExecutionResult(
            questions_created=len(questions),
            answers_created=len(answers)
        )
```

## Database Design

### Schema Extensions

```sql
-- Track impact analysis runs
CREATE TABLE impact_analysis_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    detection_run_id INTEGER NOT NULL,
    timestamp DATETIME NOT NULL,
    new_content_count INTEGER NOT NULL,
    modified_content_count INTEGER NOT NULL,
    deleted_content_count INTEGER NOT NULL,
    status TEXT NOT NULL,  -- 'completed', 'failed', 'in_progress'
    FOREIGN KEY (detection_run_id) REFERENCES detection_runs(id)
);

-- Cache chunk-to-question mappings for performance
CREATE TABLE chunk_impact_cache (
    chunk_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    cached_at DATETIME NOT NULL,
    PRIMARY KEY (chunk_id, question_id),
    FOREIGN KEY (chunk_id) REFERENCES chunks(id),
    FOREIGN KEY (question_id) REFERENCES questions(id)
);
CREATE INDEX idx_chunk_impact_chunk ON chunk_impact_cache(chunk_id);
CREATE INDEX idx_chunk_impact_question ON chunk_impact_cache(question_id);

-- Track regeneration queue
CREATE TABLE regeneration_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_run_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    reason TEXT NOT NULL,  -- 'content_changed', 'source_deleted', etc.
    priority INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending',  -- 'pending', 'in_progress', 'completed', 'failed'
    created_at DATETIME NOT NULL,
    completed_at DATETIME,
    FOREIGN KEY (analysis_run_id) REFERENCES impact_analysis_runs(id),
    FOREIGN KEY (question_id) REFERENCES questions(id)
);
CREATE INDEX idx_regen_queue_status ON regeneration_queue(status);
CREATE INDEX idx_regen_queue_priority ON regeneration_queue(priority DESC);

-- Store detailed metrics
CREATE TABLE impact_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_run_id INTEGER NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL NOT NULL,
    recorded_at DATETIME NOT NULL,
    FOREIGN KEY (analysis_run_id) REFERENCES impact_analysis_runs(id)
);
CREATE INDEX idx_impact_metrics_run ON impact_metrics(analysis_run_id);
```

### Key Queries

**Get Questions Affected by Chunk**
```sql
SELECT DISTINCT qs.question_id
FROM question_source qs
WHERE qs.chunk_id = ?
  AND qs.status = 'Active'
```

**Get Sources for Question**
```sql
SELECT chunk_id, checksum
FROM question_source
WHERE question_id = ?
  AND status = 'Active'
```

**Check if Single-Source Question**
```sql
SELECT COUNT(DISTINCT chunk_id)
FROM question_source
WHERE question_id = ?
  AND status = 'Active'
```

## Integration Points

### 1. Change Detection Module

```python
from detection import ChecksumChangeDetector
from faq_impact.analysis import ImpactAnalyzer

# Use existing change detector
detector = ChecksumChangeDetector(backend)
detection_result = detector.detect_changes()

# Analyze impact
analyzer = ImpactAnalyzer(backend)
impact_report = analyzer.analyze_from_detection(detection_result)
```

### 2. Database Module

```python
from database.backends.factory import BackendFactory
from faq_impact.database.repository import ImpactRepository

# Use shared backend
backend = BackendFactory.create_backend(config)

# Create impact repository
repository = ImpactRepository(backend)
```

### 3. LLM Client

```python
# Use existing LLM client
from faq_impact.application import ChangeExecutor

executor = ChangeExecutor(
    backend=backend,
    llm_client=llm_client,  # Shared LLM client
    config=config
)
```

## Decision Trees

### Change Type Decision Tree

```
Change Detected
    │
    ├─ old_checksum = NULL, new_checksum = X
    │     └─> ChangeType.NEW
    │
    ├─ old_checksum = X, new_checksum = Y
    │     └─> ChangeType.MODIFIED
    │
    └─ old_checksum = X, new_checksum = NULL
          └─> ChangeType.DELETED
```

### Action Decision Tree

```
ChangeType.NEW
    └─> ChangeAction.GENERATE
        - Generate questions from new content
        - Generate answers for questions
        - Link to new checksum

ChangeType.MODIFIED
    │
    ├─ Has affected questions?
    │    ├─ YES
    │    │   ├─ Diff is meaningful?
    │    │   │   ├─ YES → ChangeAction.REGENERATE
    │    │   │   │          - Regenerate affected questions
    │    │   │   │          - Regenerate answers
    │    │   │   │          - Update provenance (old→new checksum)
    │    │   │   └─ NO → ChangeAction.EVALUATE
    │    │   │              - Evaluate if answers still valid
    │    │   │              - Update provenance
    │    │   └─ (No affected questions) → ChangeAction.KEEP
    │    └─ NO → ChangeAction.KEEP
    │             - Update provenance only
    └─

ChangeType.DELETED
    │
    ├─ For each affected question:
    │    │
    │    ├─ Single-source question?
    │    │    ├─ YES → ChangeAction.DEACTIVATE
    │    │    │          - Set question to Inactive
    │    │    │          - Set answers to Inactive
    │    │    │          - Remove provenance link
    │    │    └─ NO → ChangeAction.REGENERATE
    │    │               - Regenerate using remaining sources
    │    │               - Remove deleted checksum from provenance
    └─
```

### Regeneration Decision Tree

```
Question affected by change
    │
    ├─ Content deleted?
    │    ├─ Single source → DEACTIVATE
    │    └─ Multiple sources → REGENERATE with remaining
    │
    ├─ Content modified?
    │    │
    │    ├─ Diff evaluation
    │    │    │
    │    │    ├─ Facts changed (numbers, names, etc.) → REGENERATE
    │    │    │
    │    │    ├─ Structure changed significantly → REGENERATE
    │    │    │
    │    │    ├─ Tone/style changed only → EVALUATE
    │    │    │   └─> Ask LLM: "Is answer still valid?"
    │    │    │        ├─ YES → KEEP
    │    │    │        └─ NO → REGENERATE
    │    │    │
    │    │    └─ Minimal changes → KEEP
    │    │         - Update provenance only
    │    └─
    │
    └─ Content new? → GENERATE
```

## Sequence Diagrams

### Analysis Phase Sequence

```
User/Notebook → ImpactAnalyzer → Strategy → ProvenanceAnalyzer → Repository → Database
    │               │              │               │                │            │
    │ analyze()     │              │               │                │            │
    ├──────────────>│              │               │                │            │
    │               │ get_latest_detection()       │                │            │
    │               ├──────────────────────────────────────────────>│            │
    │               │<─────────────────────────────────────────────┤            │
    │               │              │               │                │            │
    │               │ analyze()    │               │                │            │
    │               ├─────────────>│               │                │            │
    │               │              │ get_questions_by_chunk()       │            │
    │               │              ├──────────────>│                │            │
    │               │              │               │ query()        │            │
    │               │              │               ├───────────────>│            │
    │               │              │               │                │ SELECT...  │
    │               │              │               │                ├───────────>│
    │               │              │               │                │<───────────┤
    │               │              │               │<───────────────┤            │
    │               │              │<──────────────┤                │            │
    │               │              │               │                │            │
    │               │<─────────────┤               │                │            │
    │               │ ChangeImpact │               │                │            │
    │               │              │               │                │            │
    │<──────────────┤              │               │                │            │
    │ ImpactAnalysisReport         │               │                │            │
```

### Execution Phase Sequence

```
User/Notebook → ChangeExecutor → Executor → QuestionGenerator → AnswerGenerator → ProvenanceManager → Repository
    │               │              │             │                    │                 │                │
    │ apply()       │              │             │                    │                 │                │
    ├──────────────>│              │             │                    │                 │                │
    │               │ begin_transaction()        │                    │                 │                │
    │               ├─────────────────────────────────────────────────────────────────────────────────>│
    │               │              │             │                    │                 │                │
    │               │ execute()    │             │                    │                 │                │
    │               ├─────────────>│             │                    │                 │                │
    │               │              │ generate_from_chunk()            │                 │                │
    │               │              ├────────────>│                    │                 │                │
    │               │              │             │ [LLM call]         │                 │                │
    │               │              │<────────────┤                    │                 │                │
    │               │              │             │                    │                 │                │
    │               │              │ generate_for_question()          │                 │                │
    │               │              ├────────────────────────────────>│                 │                │
    │               │              │             │                    │ [LLM call]      │                │
    │               │              │<────────────────────────────────┤                 │                │
    │               │              │             │                    │                 │                │
    │               │              │ add_source()                     │                 │                │
    │               │              ├────────────────────────────────────────────────────>│                │
    │               │              │             │                    │                 │ INSERT...      │
    │               │              │             │                    │                 ├───────────────>│
    │               │              │             │                    │                 │<───────────────┤
    │               │              │<────────────────────────────────────────────────────┤                │
    │               │<─────────────┤             │                    │                 │                │
    │               │              │             │                    │                 │                │
    │               │ commit()     │             │                    │                 │                │
    │               ├─────────────────────────────────────────────────────────────────────────────────>│
    │<──────────────┤              │             │                    │                 │                │
    │ ExecutionReport              │             │                    │                 │                │
```

## Transaction Management

### Transaction Boundaries

```python
# Each execution is atomic
class ChangeExecutor:
    def apply_changes(self, report: ImpactAnalysisReport) -> ExecutionReport:
        results = []

        try:
            with self.repository.transaction():  # BEGIN TRANSACTION
                for impact in report.changes:
                    executor = self.executors[impact.action]
                    result = executor.execute(impact, self.repository, self.services)
                    results.append(result)

                # All operations succeeded
                # COMMIT happens automatically on context exit

        except Exception as e:
            # Any failure triggers rollback
            # ROLLBACK happens automatically
            raise ExecutionError(f"Execution failed: {e}") from e

        return self._build_report(results)
```

### Savepoints for Partial Rollback

```python
# Advanced: Use savepoints for partial rollback
with self.repository.transaction():
    for impact in report.changes:
        savepoint = self.repository.savepoint(f"change_{impact.chunk_id}")

        try:
            result = executor.execute(impact, ...)
            results.append(result)
        except Exception as e:
            # Rollback this change only, continue with others
            self.repository.rollback_to_savepoint(savepoint)
            errors.append((impact, e))
            continue
```

## Error Handling Strategy

### Error Categories

1. **Recoverable Errors** (Retry)
   - LLM timeout
   - Network connectivity issues
   - Database connection lost
   - Rate limiting

2. **Non-Recoverable Errors** (Fail)
   - Invalid data
   - Schema violations
   - Permission denied
   - Configuration error

3. **Partial Failures** (Continue with errors)
   - One question generation failed (continue with others)
   - One answer generation failed (continue with others)

### Retry Strategy

```python
class RetryHelper:
    def execute(
        self,
        func,
        max_attempts=3,
        backoff_factor=2,
        retryable_exceptions=(TimeoutError, ConnectionError)
    ):
        for attempt in range(max_attempts):
            try:
                return func()
            except retryable_exceptions as e:
                if attempt == max_attempts - 1:
                    raise
                wait_time = backoff_factor ** attempt
                time.sleep(wait_time)
                continue
```

## Performance Considerations

### 1. Caching

**Chunk-to-Question Cache**
```python
# Pre-compute and cache chunk→question mappings
def rebuild_cache(repository):
    """Rebuild chunk_impact_cache table"""
    repository.execute("""
        INSERT INTO chunk_impact_cache (chunk_id, question_id, cached_at)
        SELECT DISTINCT
            qs.chunk_id,
            qs.question_id,
            CURRENT_TIMESTAMP
        FROM question_source qs
        WHERE qs.status = 'Active'
    """)

# Use cache for fast lookups
def get_affected_questions_cached(chunk_id):
    return repository.execute_query(
        "SELECT question_id FROM chunk_impact_cache WHERE chunk_id = ?",
        (chunk_id,)
    )
```

### 2. Batch Processing

```python
# Process multiple items in parallel
class BatchProcessor:
    def batch_generate_questions(self, chunk_ids, batch_size=10):
        results = []
        for batch in chunks(chunk_ids, batch_size):
            # Generate for batch in parallel
            batch_results = asyncio.gather(*[
                self.generate_async(chunk_id)
                for chunk_id in batch
            ])
            results.extend(batch_results)
        return results
```

### 3. Lazy Loading

```python
# Don't load content until needed
@dataclass
class ChangeImpact:
    chunk_id: int
    _content: Optional[str] = field(default=None, repr=False)

    def get_content(self, repository):
        if self._content is None:
            self._content = repository.get_content(self.chunk_id)
        return self._content
```

## Testing Strategy

### Test Pyramid

```
       ┌───────────────┐
       │  Integration  │  ← Few, slow, end-to-end
       │     Tests     │     (full workflow)
       └───────────────┘
      ┌─────────────────┐
      │  Service Tests  │  ← Some, medium speed
      │ (with test DB)  │     (strategies + services + repository)
      └─────────────────┘
    ┌───────────────────────┐
    │     Unit Tests        │  ← Many, fast, isolated
    │  (mocked dependencies)│     (individual classes)
    └───────────────────────┘
```

### Test Coverage Goals

- **Overall**: > 90%
- **Core Models**: 100% (simple dataclasses)
- **Strategies**: > 95% (critical business logic)
- **Executors**: > 95% (critical business logic)
- **Services**: > 90%
- **Repositories**: > 85%

---

**Document Version**: 1.0.0
**Last Updated**: 2025-11-02
**Author**: Analytics Assist Team
