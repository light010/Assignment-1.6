# Deleted Content Analysis Logic

**Author**: Analytics Assist Team
**Date**: 2025-11-02
**Related Files**:
- Implementation: [`analysis/strategies/deleted_content_strategy.py`](../analysis/strategies/deleted_content_strategy.py)
- Tests: [`tests/analysis/strategies/test_deleted_content_strategy.py`](../tests/analysis/strategies/test_deleted_content_strategy.py)
- Interface: [`core/interfaces/analyzer.py`](../core/interfaces/analyzer.py)

---

## Overview

The **DeletedContentStrategy** handles scenarios where source content has been deleted from the knowledge base. This strategy determines which questions and answers should be inactivated (if they lose their sole/all sources) or regenerated (if they have multiple sources remaining).

### Key Concepts

- **Sole Source**: Question/answer has exactly **1 valid source**
  - If that source is deleted → **INACTIVATE** the entity
- **Multi-Source**: Question/answer has **2+ valid sources**
  - If one source deleted → **REGEN** (keep entity active, regenerate with remaining sources)
- **Orphaned**: Question/answer has **0 valid sources**
  - **INACTIVATE** (no sources remain)
- **Cascading**: Question inactivated → automatically **INACTIVATE** all its answers

---

## Decision Flow

### High-Level Flow

```
┌────────────────────────────────────────────────────────────────┐
│                   DELETED_CONTENT Detected                      │
│              (previous_checksum = deleted content)              │
└─────────────────────────┬──────────────────────────────────────┘
                          │
                          ▼
         ┌────────────────────────────────────┐
         │  Find Affected Questions/Answers   │
         │  (query source tables)             │
         └──────────┬─────────────────────────┘
                    │
         ┌──────────┴──────────┐
         │                     │
         ▼                     ▼
  ┌──────────────┐      ┌──────────────┐
  │  Questions   │      │   Answers    │
  │  Affected    │      │   Affected   │
  └──────┬───────┘      └──────┬───────┘
         │                     │
         │                     │
         ▼                     ▼
  ┌──────────────┐      ┌──────────────┐
  │ Count Valid  │      │ Count Valid  │
  │   Sources    │      │   Sources    │
  └──────┬───────┘      └──────┬───────┘
         │                     │
         │                     │
         ▼                     ▼
  ┌──────────────┐      ┌──────────────┐
  │   Classify   │      │   Classify   │
  │   Question   │      │    Answer    │
  └──────┬───────┘      └──────┬───────┘
         │                     │
         │                     │
         ▼                     ▼
  ┌──────────────────┐  ┌──────────────────┐
  │ Generate         │  │ Generate         │
  │ Decision(s)      │  │ Decision(s)      │
  └──────────────────┘  └──────────────────┘
```

---

## Question Deletion Logic

### Classification and Decisions

```
                    ┌─────────────────────┐
                    │ Question Source     │
                    │ Deleted             │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
        ┌──────────┐     ┌──────────┐    ┌──────────┐
        │ Orphaned │     │  Sole    │    │  Multi   │
        │ count=0  │     │ Source   │    │ Source   │
        │          │     │ count=1  │    │ count>1  │
        └────┬─────┘     └────┬─────┘    └────┬─────┘
             │                │               │
             │                │               │
             ▼                ▼               ▼
    ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
    │ INACTIVATE  │  │ INACTIVATE  │  │  REGEN_Q    │
    │ Question    │  │ Question    │  │ Question    │
    └──────┬──────┘  └──────┬──────┘  └─────────────┘
           │                │
           │                │
           ▼                ▼
    ┌─────────────────────────────┐
    │  CASCADE INACTIVATE         │
    │  All Associated Answers     │
    └─────────────────────────────┘
```

### Decision Rules

| Source Count | Classification | Decision      | Reason Code              | Cascade? |
|-------------|----------------|---------------|--------------------------|----------|
| **0**       | Orphaned       | **INACTIVATE** | `ORPHANED_QUESTION`      | ✅ Yes   |
| **1**       | Sole Source    | **INACTIVATE** | `CONTENT_DELETED`        | ✅ Yes   |
| **2+**      | Multi-Source   | **REGEN_Q**    | `MULTI_SOURCE_ONE_MODIFIED` | ❌ No |

---

## Answer Deletion Logic

### Classification and Decisions

```
                    ┌─────────────────────┐
                    │ Answer Source       │
                    │ Deleted             │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
     ┌─────────────┐   ┌─────────────┐  ┌─────────────┐
     │ Parent Q    │   │  Orphaned   │  │  Has Valid  │
     │ Inactivated?│   │  count=0    │  │  Sources    │
     │             │   │             │  │  count>=1   │
     └──────┬──────┘   └──────┬──────┘  └──────┬──────┘
            │                 │                │
            ▼                 ▼                ▼
     ┌─────────────┐   ┌─────────────┐  ┌─────────────┐
     │   SKIP      │   │ INACTIVATE  │  │  REGEN_A    │
     │ (Already    │   │  Answer     │  │  Answer     │
     │  Cascaded)  │   │             │  │             │
     └─────────────┘   └─────────────┘  └─────────────┘
```

### Decision Rules

| Condition                          | Decision       | Reason Code              |
|------------------------------------|----------------|--------------------------|
| Parent question being inactivated  | **SKIP**       | (Already cascaded)       |
| Orphaned (count=0)                 | **INACTIVATE** | `ORPHANED_ANSWER`        |
| Has remaining sources (count>=1)   | **REGEN_A**    | `ANSWER_FACTS_CHANGED`   |

---

## Detailed Examples

### Example 1: Sole Source Question Deletion

**Scenario**: Question 42 has only one source (checksum `abc123`). That source is deleted.

**Database State**:
```sql
-- Before deletion
faq_questions:         question_id=42, status='active'
faq_question_sources:  question_id=42, content_checksum='abc123', is_valid=1
faq_answers:           answer_id=100, question_id=42, status='active'
                       answer_id=101, question_id=42, status='active'
```

**Detection Context**:
```python
DetectionContext(
    change_type="DELETED_CONTENT",
    previous_checksum="abc123",  # Deleted content
    change_id=500
)
```

**Analysis Process**:
1. Find affected questions: `[42]`
2. Count sources for Q42: `valid_source_count=1, is_sole_source=True`
3. Classify: **Sole Source**
4. Generate decisions:
   - **INACTIVATE** Question 42 (reason: `CONTENT_DELETED`)
   - **INACTIVATE** Answer 100 (reason: `ORPHANED_ANSWER`, cascade)
   - **INACTIVATE** Answer 101 (reason: `ORPHANED_ANSWER`, cascade)

**Generated Decisions**:
```python
[
    ImpactDecision(
        entity_type=EntityType.QUESTION,
        entity_id=42,
        decision=DecisionType.INACTIVATE,
        reason=ReasonCode.CONTENT_DELETED,
        details={"valid_source_count": 1, "previous_checksum": "abc123"}
    ),
    ImpactDecision(
        entity_type=EntityType.ANSWER,
        entity_id=100,
        decision=DecisionType.INACTIVATE,
        reason=ReasonCode.ORPHANED_ANSWER,
        details={"question_id": 42, "reason_detail": "Cascaded from question"}
    ),
    ImpactDecision(
        entity_type=EntityType.ANSWER,
        entity_id=101,
        decision=DecisionType.INACTIVATE,
        reason=ReasonCode.ORPHANED_ANSWER,
        details={"question_id": 42, "reason_detail": "Cascaded from question"}
    )
]
```

---

### Example 2: Multi-Source Question Deletion

**Scenario**: Question 58 has three sources (`abc123`, `def456`, `ghi789`). Source `abc123` is deleted.

**Database State**:
```sql
-- Before deletion
faq_questions:         question_id=58, status='active'
faq_question_sources:  question_id=58, content_checksum='abc123', is_valid=1
                       question_id=58, content_checksum='def456', is_valid=1
                       question_id=58, content_checksum='ghi789', is_valid=1
```

**Detection Context**:
```python
DetectionContext(
    change_type="DELETED_CONTENT",
    previous_checksum="abc123",  # Deleted content
    change_id=501
)
```

**Analysis Process**:
1. Find affected questions: `[58]`
2. Count sources for Q58: `valid_source_count=3, is_sole_source=False`
3. Classify: **Multi-Source**
4. Generate decisions:
   - **REGEN_Q** Question 58 (reason: `MULTI_SOURCE_ONE_MODIFIED`)
   - (No cascading - question remains active)

**Generated Decisions**:
```python
[
    ImpactDecision(
        entity_type=EntityType.QUESTION,
        entity_id=58,
        decision=DecisionType.REGEN_Q,
        reason=ReasonCode.MULTI_SOURCE_ONE_MODIFIED,
        details={
            "valid_source_count": 3,
            "remaining_checksums": ["def456", "ghi789", "abc123"],
            "previous_checksum": "abc123"
        }
    )
]
```

---

### Example 3: Orphaned Question Edge Case

**Scenario**: Question 91 had two sources, but both became invalid over time. Now the last reference is deleted.

**Database State**:
```sql
-- Before deletion (both sources already invalid)
faq_questions:         question_id=91, status='active'
faq_question_sources:  question_id=91, content_checksum='aaa111', is_valid=0  # Invalid
                       question_id=91, content_checksum='bbb222', is_valid=0  # Invalid
```

**Detection Context**:
```python
DetectionContext(
    change_type="DELETED_CONTENT",
    previous_checksum="bbb222",  # Last reference deleted
    change_id=502
)
```

**Analysis Process**:
1. Find affected questions: `[91]`
2. Count sources for Q91: `valid_source_count=0, is_sole_source=False`
3. Classify: **Orphaned**
4. Generate decisions:
   - **INACTIVATE** Question 91 (reason: `ORPHANED_QUESTION`)
   - Cascade to all answers

**Generated Decisions**:
```python
[
    ImpactDecision(
        entity_type=EntityType.QUESTION,
        entity_id=91,
        decision=DecisionType.INACTIVATE,
        reason=ReasonCode.ORPHANED_QUESTION,
        details={
            "valid_source_count": 0,
            "previous_checksum": "bbb222",
            "reason_detail": "All sources for this question are invalid or deleted"
        }
    ),
    # ... cascaded answer decisions ...
]
```

---

### Example 4: Answer-Only Deletion

**Scenario**: Answer 200 uses source `xyz999`. That source is deleted, but the question remains valid.

**Database State**:
```sql
-- Before deletion
faq_answers:          answer_id=200, question_id=99, status='active'
faq_answer_sources:   answer_id=200, content_checksum='xyz999', is_valid=1
                      answer_id=200, content_checksum='lmn555', is_valid=1
faq_questions:        question_id=99, status='active'  # Question still valid
```

**Detection Context**:
```python
DetectionContext(
    change_type="DELETED_CONTENT",
    previous_checksum="xyz999",  # Deleted content
    change_id=503
)
```

**Analysis Process**:
1. Find affected questions: `[]` (none)
2. Find affected answers: `[200]`
3. Count sources for A200: `valid_source_count=2, is_sole_source=False`
4. Check parent question: Q99 is NOT being inactivated
5. Generate decisions:
   - **REGEN_A** Answer 200 (reason: `ANSWER_FACTS_CHANGED`)

**Generated Decisions**:
```python
[
    ImpactDecision(
        entity_type=EntityType.ANSWER,
        entity_id=200,
        decision=DecisionType.REGEN_A,
        reason=ReasonCode.ANSWER_FACTS_CHANGED,
        details={
            "question_id": 99,
            "valid_source_count": 2,
            "remaining_checksums": ["lmn555", "xyz999"],
            "previous_checksum": "xyz999"
        }
    )
]
```

---

## Implementation Details

### Database Queries

#### Find Affected Questions
```sql
SELECT DISTINCT question_id
FROM faq_question_sources
WHERE content_checksum = ? -- previous_checksum
  AND is_valid = 1
ORDER BY question_id
```

#### Find Affected Answers
```sql
SELECT DISTINCT answer_id
FROM faq_answer_sources
WHERE content_checksum = ? -- previous_checksum
  AND is_valid = 1
ORDER BY answer_id
```

#### Find Answers for Cascading
```sql
SELECT answer_id
FROM faq_answers
WHERE question_id = ?
  AND status = 'active'
ORDER BY answer_id
```

#### Get Parent Question for Answer
```sql
SELECT question_id
FROM faq_answers
WHERE answer_id = ?
```

### Source Counting

The strategy uses the **SourceCounter** service to dynamically count valid sources:

```python
# Count sources for a question
source_count_result = source_counter.count_sources_for_question(question_id)

# Returns: SourceCountResult
# - valid_source_count: int (number of valid sources)
# - is_sole_source: bool (True if count == 1)
# - is_orphaned(): bool (True if count == 0)
# - source_checksums: List[str] (list of valid checksums)
```

**SourceCounter Query** (example for questions):
```sql
SELECT content_checksum
FROM faq_question_sources
WHERE question_id = ?
  AND is_valid = 1
ORDER BY created_at DESC
```

---

## Edge Cases and Error Handling

### Edge Case 1: No FAQs Affected

**Scenario**: Deleted content checksum has no corresponding entries in source tables.

**Behavior**: Return empty decision list `[]` (valid NOOP).

```python
# No questions or answers affected
decisions = strategy.analyze(context)
assert decisions == []  # NOOP
```

---

### Edge Case 2: Answer Without Parent Question

**Scenario**: Answer exists in `faq_answer_sources` but has no corresponding entry in `faq_answers` table.

**Behavior**: Skip the answer (log warning).

```python
# Answer 999 has no parent question
logger.warning(f"Answer {answer_id} has no parent question - skipping")
return []  # Skip decision for this answer
```

---

### Edge Case 3: Question Being Inactivated + Answer Also Affected

**Scenario**: Both a question and its answer have the deleted content as a source.

**Behavior**:
1. Inactivate question (sole source)
2. Cascade inactivation to answer
3. Skip separate answer decision (already cascaded)

```python
# Avoid duplicate inactivation decisions
if question_id in inactivated_question_ids:
    logger.debug("Answer's parent question is being inactivated - skipping")
    return []  # Already handled by cascade
```

---

### Error Handling

#### Missing `previous_checksum`
```python
if context.previous_checksum is None:
    raise ValueError("DeletedContentStrategy requires previous_checksum")
```

#### Wrong `change_type`
```python
if context.change_type != "DELETED_CONTENT":
    raise ValueError("DeletedContentStrategy requires change_type='DELETED_CONTENT'")
```

#### Database Query Errors
```python
try:
    rows = backend.execute_query(query, params)
except Exception as e:
    logger.error(f"Database query failed: {e}")
    raise RuntimeError(f"Failed to query affected questions: {e}")
```

---

## Testing Strategy

### Test Coverage

The test suite covers:

1. **can_handle() Validation**
   - Accepts `DELETED_CONTENT`
   - Rejects `NEW_CONTENT`, `MODIFIED_CONTENT`

2. **Context Validation**
   - Valid context passes
   - Missing `previous_checksum` raises error
   - Wrong `change_type` raises error

3. **Sole Source Question**
   - Inactivates question
   - Cascades to all answers
   - Correct reason codes

4. **Multi-Source Question**
   - Regenerates question (REGEN_Q)
   - No cascading

5. **Orphaned Question**
   - Inactivates question with `ORPHANED_QUESTION`
   - Cascades to answers

6. **Answer-Only Deletion**
   - Regenerates answer (REGEN_A)
   - Inactivates if orphaned
   - Skips if parent question inactivated

7. **Edge Cases**
   - No affected FAQs
   - Answer without parent question
   - Mixed scenarios

### Running Tests

```bash
# Run all tests
pytest tests/analysis/strategies/test_deleted_content_strategy.py -v

# Run specific test class
pytest tests/analysis/strategies/test_deleted_content_strategy.py::TestSoleSourceQuestionDeletion -v

# Run with coverage
pytest tests/analysis/strategies/test_deleted_content_strategy.py --cov=analysis.strategies.deleted_content_strategy
```

---

## Performance Considerations

### Query Optimization

1. **Affected Entity Discovery**: Uses indexed `content_checksum` column
2. **Source Counting**: Cached by SourceCounter (TTL=300s by default)
3. **Cascade Queries**: Single query per question for all answers

### Scalability

- **Question Count**: O(n) where n = number of affected questions
- **Answer Count**: O(m) where m = number of affected answers
- **Source Counting**: Cached, O(1) for repeated queries within TTL

**Estimated Performance**:
- 10 affected questions + 30 answers: ~50-100ms
- 100 affected questions + 300 answers: ~500ms-1s

---

## Decision Audit Trail

All decisions include comprehensive details for audit trails:

### INACTIVATE Decision Details
```json
{
    "previous_checksum": "abc123",
    "valid_source_count": 1,
    "remaining_checksums": ["def456"],
    "reason_detail": "Question's sole source content was deleted"
}
```

### REGEN_Q Decision Details
```json
{
    "previous_checksum": "abc123",
    "valid_source_count": 3,
    "remaining_checksums": ["def456", "ghi789", "jkl012"],
    "reason_detail": "One of multiple sources deleted, regenerate question"
}
```

### REGEN_A Decision Details
```json
{
    "question_id": 99,
    "previous_checksum": "xyz999",
    "valid_source_count": 2,
    "remaining_checksums": ["lmn555", "opq333"],
    "reason_detail": "Answer source deleted, regenerate with remaining sources"
}
```

---

## Integration with Impact System

### Strategy Registration

```python
# In ImpactAnalyzer initialization
from analysis.strategies.deleted_content_strategy import DeletedContentStrategy

analyzer = ImpactAnalyzer(
    backend=backend,
    strategies=[
        NewContentStrategy(backend),
        ModifiedContentStrategy(backend, token_matcher, source_counter),
        DeletedContentStrategy(backend, source_counter),  # Register here
    ]
)
```

### Strategy Selection

```python
# In ImpactAnalyzer.analyze_change()
for strategy in self.strategies:
    if strategy.can_handle(context.change_type):
        decisions = strategy.analyze(context)
        break
```

---

## Future Enhancements

### Potential Improvements

1. **Batch Source Counting**: Count sources for all affected entities in one query
2. **Smart Cascading**: Detect if answers are also directly affected (avoid duplicate decisions)
3. **Partial Regeneration**: For multi-source entities, regenerate only affected sections
4. **Undo Support**: Generate "restore" decisions if deleted content is re-added
5. **Threshold Tuning**: Configurable thresholds for sole source vs multi-source classification

---

## References

- **Implementation**: [`analysis/strategies/deleted_content_strategy.py`](../analysis/strategies/deleted_content_strategy.py)
- **Tests**: [`tests/analysis/strategies/test_deleted_content_strategy.py`](../tests/analysis/strategies/test_deleted_content_strategy.py)
- **Interface**: [`core/interfaces/analyzer.py`](../core/interfaces/analyzer.py)
- **SourceCounter**: [`analysis/services/source_counter.py`](../analysis/services/source_counter.py)
- **Decision Types**: [`core/enums/decision_type.py`](../core/enums/decision_type.py)
- **Reason Codes**: [`core/enums/reason_code.py`](../core/enums/reason_code.py)

---

**Document Version**: 1.0
**Last Updated**: 2025-11-02
