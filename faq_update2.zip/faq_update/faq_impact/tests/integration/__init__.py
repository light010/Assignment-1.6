"""
Integration Tests - End-to-End Workflow Tests

This module contains end-to-end integration tests that verify complete
workflows from change detection through execution. These tests use real
database backends and (optionally) real LLM clients.

Test Files:
    test_full_workflow.py             - Complete workflow tests
    test_new_content_flow.py          - New content detection -> execution
    test_modified_content_flow.py     - Modified content detection -> execution
    test_deleted_content_flow.py      - Deleted content detection -> execution
    test_mixed_changes_flow.py        - Multiple change types together
    test_error_handling_flow.py       - Error scenarios and recovery
    test_transaction_rollback_flow.py - Transaction rollback scenarios

Integration Test Characteristics:
    - Use real database backend (SQLite for tests)
    - May use real or mocked LLM client (configurable)
    - Test complete workflows end-to-end
    - Verify database state after operations
    - Test transaction semantics
    - Slower than unit tests (< 30s per test)

Example Integration Test:
    def test_new_content_complete_flow(test_backend, llm_client):
        '''Test complete flow for new content'''
        # Setup: Create new chunk
        chunk_id = create_test_chunk(test_backend, "New content")

        # Phase 1: Analyze
        analyzer = ImpactAnalyzer(test_backend)
        report = analyzer.analyze_changes()

        # Verify analysis
        assert report.new_content_count == 1
        assert len(report.questions_to_generate) > 0

        # Phase 2: Execute
        executor = ChangeExecutor(test_backend, llm_client)
        result = executor.apply_changes(report)

        # Verify execution
        assert result.questions_created > 0
        assert result.answers_created > 0

        # Verify database state
        questions = get_questions_for_chunk(test_backend, chunk_id)
        assert len(questions) > 0
        assert all(q.status == "Active" for q in questions)

        # Verify provenance
        sources = get_question_sources(test_backend, questions[0].id)
        assert chunk_id in sources

Author: Analytics Assist Team
Date: 2025-11-02
"""

__all__ = []
