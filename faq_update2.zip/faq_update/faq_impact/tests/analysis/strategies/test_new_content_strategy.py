"""
Unit Tests for NewContentStrategy

This module contains comprehensive unit tests for the NewContentStrategy class,
covering normal operation, edge cases, validation, and error handling.

Test Coverage:
    - can_handle() method tests
    - analyze() method tests (normal cases)
    - Duplicate checksum detection
    - Invalid context handling
    - Edge case: NEW_CONTENT with previous_checksum
    - Cost estimation validation
    - Decision details schema validation

Author: Analytics Assist Team
Date: 2025-11-02
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
from typing import List, Dict, Any

# Import code under test
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../..')))

from faq_impact.analysis.strategies.new_content_strategy import NewContentStrategy
from faq_impact.core.models.detection_context import DetectionContext
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.analysis.services.checksum_validator import ValidationResult
from faq_update.database.backends.base import IBackend


class TestNewContentStrategyCanHandle(unittest.TestCase):
    """Test suite for NewContentStrategy.can_handle() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.strategy = NewContentStrategy(self.mock_backend)

    def test_can_handle_new_content(self):
        """Test that can_handle returns True for NEW_CONTENT."""
        result = self.strategy.can_handle("NEW_CONTENT")
        self.assertTrue(result)

    def test_can_handle_modified_content(self):
        """Test that can_handle returns False for MODIFIED_CONTENT."""
        result = self.strategy.can_handle("MODIFIED_CONTENT")
        self.assertFalse(result)

    def test_can_handle_deleted_content(self):
        """Test that can_handle returns False for DELETED_CONTENT."""
        result = self.strategy.can_handle("DELETED_CONTENT")
        self.assertFalse(result)

    def test_can_handle_invalid_type(self):
        """Test that can_handle returns False for invalid change types."""
        result = self.strategy.can_handle("INVALID_TYPE")
        self.assertFalse(result)

    def test_can_handle_case_sensitive(self):
        """Test that can_handle is case-sensitive."""
        result = self.strategy.can_handle("new_content")
        self.assertFalse(result)

        result = self.strategy.can_handle("New_Content")
        self.assertFalse(result)


class TestNewContentStrategyAnalyzeNormalCases(unittest.TestCase):
    """Test suite for NewContentStrategy.analyze() - normal operation."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_validator = Mock()
        self.mock_estimator = Mock()

        # Configure cost estimator defaults
        self.mock_estimator.cost_per_question_gen = 0.05
        self.mock_estimator.cost_per_answer_gen = 0.03

        self.strategy = NewContentStrategy(
            self.mock_backend,
            validator=self.mock_validator,
            estimator=self.mock_estimator
        )

    def test_analyze_new_unique_content(self):
        """Test analyze() with new, unique content generates PLAN_CREATE."""
        # Create test context
        context = DetectionContext(
            detection_run_id="run_001",
            change_id=123,
            change_type="NEW_CONTENT",
            content_checksum="a" * 64,  # Valid 64-char hex
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="test_doc.pdf",
            metadata={"chunk_id": 456, "page_number": 10}
        )

        # Mock validator to return valid, non-existent checksum
        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="a" * 64,
            is_valid=True,
            exists=False,
            explanation="Checksum format is valid but not found in active chunks"
        )

        # Analyze
        decisions = self.strategy.analyze(context)

        # Assertions
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.PLAN_CREATE)
        self.assertEqual(decision.reason, ReasonCode.NEW_CONTENT_ADDED)
        self.assertEqual(decision.entity_type, EntityType.QUESTION)
        self.assertIsNone(decision.entity_id)  # New question, no ID yet
        self.assertEqual(decision.change_id, 123)
        self.assertEqual(decision.detection_run_id, "run_001")
        self.assertFalse(decision.applied)

        # Check details
        self.assertIn("chunk_id", decision.details)
        self.assertEqual(decision.details["chunk_id"], 456)
        self.assertIn("content_checksum", decision.details)
        self.assertEqual(decision.details["content_checksum"], "a" * 64)
        self.assertIn("file_name", decision.details)
        self.assertEqual(decision.details["file_name"], "test_doc.pdf")
        self.assertIn("estimated_cost_usd", decision.details)
        self.assertEqual(decision.details["estimated_cost_usd"], 0.08)  # 0.05 + 0.03

    def test_analyze_new_content_with_minimal_metadata(self):
        """Test analyze() with minimal metadata (no chunk_id, no file_name)."""
        context = DetectionContext(
            detection_run_id="run_002",
            change_id=124,
            change_type="NEW_CONTENT",
            content_checksum="b" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name=None,  # Missing file_name
            metadata={}  # Empty metadata (no chunk_id)
        )

        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="b" * 64,
            is_valid=True,
            exists=False,
            explanation="Valid checksum, not found"
        )

        decisions = self.strategy.analyze(context)

        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.PLAN_CREATE)
        self.assertIsNone(decision.details["chunk_id"])  # No chunk_id in metadata
        self.assertEqual(decision.details["file_name"], "unknown")  # Default

    def test_analyze_decision_details_schema(self):
        """Test that decision details contain all expected fields."""
        context = DetectionContext(
            detection_run_id="run_003",
            change_id=125,
            change_type="NEW_CONTENT",
            content_checksum="c" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="doc.pdf",
            metadata={"chunk_id": 789, "chunk_index": 5, "page_number": 12}
        )

        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="c" * 64,
            is_valid=True,
            exists=False,
            explanation="Valid"
        )

        decisions = self.strategy.analyze(context)
        details = decisions[0].details

        # Check required fields
        required_fields = [
            "chunk_id",
            "content_checksum",
            "file_name",
            "estimated_cost_usd",
            "estimated_question_count",
            "estimated_answer_count"
        ]

        for field in required_fields:
            self.assertIn(field, details, f"Missing required field: {field}")

        # Check optional fields
        self.assertIn("chunk_sequence", details)
        self.assertEqual(details["chunk_sequence"], 5)
        self.assertIn("page_number", details)
        self.assertEqual(details["page_number"], 12)


class TestNewContentStrategyDuplicateDetection(unittest.TestCase):
    """Test suite for duplicate checksum detection."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_validator = Mock()
        self.mock_estimator = Mock()

        self.strategy = NewContentStrategy(
            self.mock_backend,
            validator=self.mock_validator,
            estimator=self.mock_estimator
        )

    def test_analyze_duplicate_checksum_returns_noop(self):
        """Test that duplicate checksum generates NOOP decision."""
        context = DetectionContext(
            detection_run_id="run_004",
            change_id=126,
            change_type="NEW_CONTENT",
            content_checksum="d" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="dup_doc.pdf",
            metadata={"chunk_id": 999}
        )

        # Mock validator to return existing checksum
        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="d" * 64,
            is_valid=True,
            exists=True,  # Duplicate detected
            explanation="Checksum is valid and exists in active chunks"
        )

        decisions = self.strategy.analyze(context)

        # Should return NOOP decision
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.NOOP)
        self.assertEqual(decision.reason, ReasonCode.ALREADY_HANDLED)
        self.assertEqual(decision.entity_type, EntityType.CHANGE)
        self.assertEqual(decision.entity_id, 126)  # NOOP targets change itself

        # Check details
        self.assertIn("noop_reason", decision.details)
        self.assertEqual(decision.details["noop_reason"], "content_already_indexed")
        self.assertIn("content_checksum", decision.details)


class TestNewContentStrategyValidation(unittest.TestCase):
    """Test suite for context validation and error handling."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_validator = Mock()
        self.mock_estimator = Mock()

        self.strategy = NewContentStrategy(
            self.mock_backend,
            validator=self.mock_validator,
            estimator=self.mock_estimator
        )

    def test_analyze_invalid_change_type_raises_error(self):
        """Test that wrong change_type raises ValueError."""
        context = DetectionContext(
            detection_run_id="run_005",
            change_id=127,
            change_type="MODIFIED_CONTENT",  # Wrong type!
            content_checksum="e" * 64,
            previous_checksum="f" * 64,
            diff_data=None,
            similarity_score=0.5,
            file_name="test.pdf",
            metadata={}
        )

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("non-NEW_CONTENT", str(cm.exception))

    def test_analyze_missing_content_checksum_raises_error(self):
        """Test that missing content_checksum raises ValueError."""
        # DetectionContext validation will catch this in __post_init__
        with self.assertRaises(ValueError):
            context = DetectionContext(
                detection_run_id="run_006",
                change_id=128,
                change_type="NEW_CONTENT",
                content_checksum=None,  # Missing!
                previous_checksum=None,
                diff_data=None,
                similarity_score=None,
                file_name="test.pdf",
                metadata={}
            )

    def test_analyze_invalid_checksum_length_raises_error(self):
        """Test that invalid checksum length raises ValueError."""
        context = DetectionContext(
            detection_run_id="run_007",
            change_id=129,
            change_type="NEW_CONTENT",
            content_checksum="short",  # Invalid length!
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="test.pdf",
            metadata={}
        )

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("Invalid content_checksum length", str(cm.exception))

    def test_analyze_invalid_checksum_format_raises_error(self):
        """Test that invalid checksum format raises ValueError."""
        context = DetectionContext(
            detection_run_id="run_008",
            change_id=130,
            change_type="NEW_CONTENT",
            content_checksum="z" * 64,  # Valid length but invalid hex
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="test.pdf",
            metadata={"chunk_id": 100}
        )

        # Mock validator to return invalid format
        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="z" * 64,
            is_valid=False,
            exists=False,
            explanation="Invalid format: must be hexadecimal (0-9, a-f)"
        )

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("Invalid content_checksum", str(cm.exception))

    def test_analyze_invalid_change_id_raises_error(self):
        """Test that invalid change_id raises ValueError."""
        context = DetectionContext(
            detection_run_id="run_009",
            change_id=0,  # Invalid! Must be > 0
            change_type="NEW_CONTENT",
            content_checksum="a" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="test.pdf",
            metadata={}
        )

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("Invalid change_id", str(cm.exception))


class TestNewContentStrategyEdgeCases(unittest.TestCase):
    """Test suite for edge cases and unusual scenarios."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_validator = Mock()
        self.mock_estimator = Mock()
        self.mock_estimator.cost_per_question_gen = 0.05
        self.mock_estimator.cost_per_answer_gen = 0.03

        self.strategy = NewContentStrategy(
            self.mock_backend,
            validator=self.mock_validator,
            estimator=self.mock_estimator
        )

    def test_analyze_new_content_validates_at_context_level(self):
        """Test that DetectionContext validates NEW_CONTENT cannot have previous_checksum."""
        # DetectionContext validation should prevent this scenario
        # NEW_CONTENT with previous_checksum is invalid and caught at dataclass level
        with self.assertRaises(ValueError) as cm:
            context = DetectionContext(
                detection_run_id="run_010",
                change_id=131,
                change_type="NEW_CONTENT",
                content_checksum="a" * 64,
                previous_checksum="b" * 64,  # Invalid for NEW_CONTENT
                diff_data=None,
                similarity_score=None,
                file_name="edge_case.pdf",
                metadata={"chunk_id": 200}
            )

        self.assertIn("NEW_CONTENT should not have previous_checksum", str(cm.exception))


class TestNewContentStrategyCostEstimation(unittest.TestCase):
    """Test suite for cost estimation."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_validator = Mock()
        self.mock_estimator = Mock()

        self.strategy = NewContentStrategy(
            self.mock_backend,
            validator=self.mock_validator,
            estimator=self.mock_estimator
        )

    def test_cost_estimation_includes_question_and_answer(self):
        """Test that cost estimation includes both Q and A generation."""
        self.mock_estimator.cost_per_question_gen = 0.10
        self.mock_estimator.cost_per_answer_gen = 0.05

        context = DetectionContext(
            detection_run_id="run_011",
            change_id=132,
            change_type="NEW_CONTENT",
            content_checksum="a" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="cost_test.pdf",
            metadata={"chunk_id": 300}
        )

        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="a" * 64,
            is_valid=True,
            exists=False,
            explanation="Valid"
        )

        decisions = self.strategy.analyze(context)
        estimated_cost = decisions[0].details["estimated_cost_usd"]

        # Should be 0.10 + 0.05 = 0.15
        self.assertEqual(estimated_cost, 0.15)

    def test_cost_estimation_with_default_estimator(self):
        """Test cost estimation with default CostEstimator values."""
        # Create strategy with default estimator
        strategy = NewContentStrategy(self.mock_backend)
        strategy.validator = self.mock_validator

        context = DetectionContext(
            detection_run_id="run_012",
            change_id=133,
            change_type="NEW_CONTENT",
            content_checksum="a" * 64,
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="default_cost.pdf",
            metadata={"chunk_id": 400}
        )

        self.mock_validator.validate_checksum.return_value = ValidationResult(
            checksum="a" * 64,
            is_valid=True,
            exists=False,
            explanation="Valid"
        )

        decisions = strategy.analyze(context)
        estimated_cost = decisions[0].details["estimated_cost_usd"]

        # Default: 0.05 + 0.03 = 0.08
        self.assertEqual(estimated_cost, 0.08)


class TestNewContentStrategyIntegration(unittest.TestCase):
    """Integration tests for NewContentStrategy (minimal mocking)."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)

    def test_strategy_initialization_with_defaults(self):
        """Test that strategy initializes correctly with default dependencies."""
        strategy = NewContentStrategy(self.mock_backend)

        self.assertIsNotNone(strategy.backend)
        self.assertIsNotNone(strategy.validator)
        self.assertIsNotNone(strategy.estimator)

    def test_strategy_initialization_with_custom_dependencies(self):
        """Test that strategy accepts custom validator and estimator."""
        mock_validator = Mock()
        mock_estimator = Mock()

        strategy = NewContentStrategy(
            self.mock_backend,
            validator=mock_validator,
            estimator=mock_estimator
        )

        self.assertIs(strategy.validator, mock_validator)
        self.assertIs(strategy.estimator, mock_estimator)


# =============================================================================
# Test Suite Runner
# =============================================================================

def suite():
    """Create test suite for NewContentStrategy."""
    test_suite = unittest.TestSuite()

    # Add test cases
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyCanHandle))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyAnalyzeNormalCases))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyDuplicateDetection))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyValidation))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyEdgeCases))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyCostEstimation))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestNewContentStrategyIntegration))

    return test_suite


if __name__ == '__main__':
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite())
