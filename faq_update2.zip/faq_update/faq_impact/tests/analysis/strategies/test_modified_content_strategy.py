"""
Unit Tests for ModifiedContentStrategy

This module contains comprehensive unit tests for the ModifiedContentStrategy class,
covering normal operation, edge cases, validation, and error handling.

Test Coverage:
    - can_handle() method tests
    - analyze() method tests (normal cases)
    - Direct-linked FAQ discovery
    - Token overlap detection (indirect impact)
    - REGEN_Q decisions for directly affected questions
    - REGEN_Q decisions for token-overlap questions
    - REGEN_A vs EVALUATE decision logic based on similarity
    - EVALUATE decision metadata validation
    - Edge case: no affected FAQs (returns empty list)
    - Context validation tests

Author: Analytics Assist Team
Date: 2025-11-02
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
from typing import List, Dict, Any

# Import code under test
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../..')))

from faq_impact.analysis.strategies.modified_content_strategy import ModifiedContentStrategy
from faq_impact.core.models.detection_context import DetectionContext, TokenOverlapResult
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.analysis.services.token_matcher import ITokenMatcher
from faq_impact.analysis.services.source_counter import ISourceCounter, SourceCountResult
from faq_update.database.backends.base import IBackend


class TestModifiedContentStrategyCanHandle(unittest.TestCase):
    """Test suite for ModifiedContentStrategy.can_handle() method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_can_handle_modified_content(self):
        """Test that can_handle returns True for MODIFIED_CONTENT."""
        result = self.strategy.can_handle("MODIFIED_CONTENT")
        self.assertTrue(result)

    def test_can_handle_new_content(self):
        """Test that can_handle returns False for NEW_CONTENT."""
        result = self.strategy.can_handle("NEW_CONTENT")
        self.assertFalse(result)

    def test_can_handle_deleted_content(self):
        """Test that can_handle returns False for DELETED_CONTENT."""
        result = self.strategy.can_handle("DELETED_CONTENT")
        self.assertFalse(result)

    def test_can_handle_invalid_type(self):
        """Test that can_handle returns False for invalid change types."""
        result = self.strategy.can_handle("INVALID_TYPE")
        self.assertFalse(result)

    def test_can_handle_case_sensitive(self):
        """Test that can_handle is case-sensitive."""
        result = self.strategy.can_handle("modified_content")
        self.assertFalse(result)

        result = self.strategy.can_handle("Modified_Content")
        self.assertFalse(result)


class TestModifiedContentStrategyValidation(unittest.TestCase):
    """Test suite for context validation and error handling."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_analyze_invalid_change_type_raises_error(self):
        """Test that wrong change_type raises ValueError in validation.

        Note: DetectionContext validation prevents creating invalid contexts,
        so this tests the strategy's own validation as a safety check."""
        # Create a mock context that bypasses DetectionContext validation
        context = Mock()
        context.change_type = "NEW_CONTENT"  # Wrong type!
        context.content_checksum = "a" * 64
        context.previous_checksum = "b" * 64
        context.similarity_score = 0.75
        context.change_id = 123
        context.detection_run_id = "run_001"
        context.file_name = "test.pdf"
        context.metadata = {}
        context.diff_data = None

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("ModifiedContentStrategy requires change_type='MODIFIED_CONTENT'", str(cm.exception))

    def test_analyze_missing_content_checksum_raises_error(self):
        """Test that missing content_checksum raises ValueError."""
        # Use mock to bypass DetectionContext validation
        context = Mock()
        context.change_type = "MODIFIED_CONTENT"
        context.content_checksum = None  # Missing!
        context.previous_checksum = "b" * 64
        context.similarity_score = 0.75
        context.change_id = 124
        context.detection_run_id = "run_002"
        context.file_name = "test.pdf"
        context.metadata = {}
        context.diff_data = None

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("content_checksum", str(cm.exception))

    def test_analyze_missing_previous_checksum_raises_error(self):
        """Test that missing previous_checksum raises ValueError."""
        # Use mock to bypass DetectionContext validation
        context = Mock()
        context.change_type = "MODIFIED_CONTENT"
        context.content_checksum = "a" * 64
        context.previous_checksum = None  # Missing!
        context.similarity_score = 0.75
        context.change_id = 125
        context.detection_run_id = "run_003"
        context.file_name = "test.pdf"
        context.metadata = {}
        context.diff_data = None

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("previous_checksum", str(cm.exception))

    def test_analyze_missing_similarity_score_raises_error(self):
        """Test that missing similarity_score raises ValueError."""
        # Use mock to bypass DetectionContext validation
        context = Mock()
        context.change_type = "MODIFIED_CONTENT"
        context.content_checksum = "a" * 64
        context.previous_checksum = "b" * 64
        context.similarity_score = None  # Missing!
        context.change_id = 126
        context.detection_run_id = "run_004"
        context.file_name = "test.pdf"
        context.metadata = {}
        context.diff_data = None

        with self.assertRaises(ValueError) as cm:
            self.strategy.analyze(context)

        self.assertIn("similarity_score", str(cm.exception))


class TestModifiedContentStrategyNoImpact(unittest.TestCase):
    """Test suite for edge case: no affected FAQs."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_analyze_no_affected_faqs_returns_empty_list(self):
        """Test that no affected FAQs returns empty list (NOOP)."""
        context = DetectionContext(
            detection_run_id="run_005",
            change_id=127,
            change_type="MODIFIED_CONTENT",
            content_checksum="a" * 64,
            previous_checksum="b" * 64,
            diff_data={"changes": []},
            similarity_score=0.95,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: no direct questions
        self.mock_backend.execute_query.side_effect = [
            [],  # No questions
            []   # No answers
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        decisions = self.strategy.analyze(context)

        # Should return empty list
        self.assertEqual(len(decisions), 0)


class TestModifiedContentStrategyDirectImpact(unittest.TestCase):
    """Test suite for directly affected FAQs."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_analyze_sole_source_question_generates_regen_q(self):
        """Test that sole-source question generates REGEN_Q."""
        context = DetectionContext(
            detection_run_id="run_006",
            change_id=128,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_abc" + ("0" * 57),
            previous_checksum="old_abc" + ("0" * 57),
            diff_data=None,
            similarity_score=0.75,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 1 directly affected question, 0 answers
        self.mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # 1 question
            []                       # No answers
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        # Mock: sole source
        self.mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=None,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["new_abc" + ("0" * 57)]
        )

        decisions = self.strategy.analyze(context)

        # Should generate REGEN_Q for sole-source question
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.REGEN_Q)
        self.assertEqual(decision.reason, ReasonCode.SOLE_SOURCE_CONTENT_CHANGED)
        self.assertEqual(decision.entity_type, EntityType.QUESTION)
        self.assertEqual(decision.entity_id, 42)
        self.assertEqual(decision.change_id, 128)
        self.assertFalse(decision.applied)

        # Check details
        self.assertIn("previous_checksum", decision.details)
        self.assertIn("new_checksum", decision.details)
        self.assertIn("similarity_score", decision.details)
        self.assertEqual(decision.details["similarity_score"], 0.75)
        self.assertEqual(decision.details["impact_type"], "direct")

    def test_analyze_multi_source_question_no_decision(self):
        """Test that multi-source question doesn't generate question decision."""
        context = DetectionContext(
            detection_run_id="run_007",
            change_id=129,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_def" + ("0" * 57),
            previous_checksum="old_def" + ("0" * 57),
            diff_data=None,
            similarity_score=0.75,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 1 directly affected question, 0 answers
        self.mock_backend.execute_query.side_effect = [
            [{"question_id": 43}],  # 1 question
            []                       # No answers
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        # Mock: multi-source (3 sources)
        self.mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=43,
            answer_id=None,
            valid_source_count=3,
            is_sole_source=False,
            source_checksums=["checksum1", "checksum2", "checksum3"]
        )

        decisions = self.strategy.analyze(context)

        # Should NOT generate decision for multi-source question
        self.assertEqual(len(decisions), 0)

    def test_analyze_major_change_answer_generates_regen_a(self):
        """Test that major change (similarity < 0.6) generates REGEN_A."""
        context = DetectionContext(
            detection_run_id="run_008",
            change_id=130,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_ghi" + ("0" * 57),
            previous_checksum="old_ghi" + ("0" * 57),
            diff_data=None,
            similarity_score=0.45,  # Major change (< 0.6)
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 0 questions, 1 answer
        self.mock_backend.execute_query.side_effect = [
            [],                      # No questions
            [{"answer_id": 100}],   # 1 answer
            [{"question_id": 50}]    # Answer's parent question
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        decisions = self.strategy.analyze(context)

        # Should generate REGEN_A for major change
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.REGEN_A)
        self.assertEqual(decision.reason, ReasonCode.ANSWER_FACTS_CHANGED)
        self.assertEqual(decision.entity_type, EntityType.ANSWER)
        self.assertEqual(decision.entity_id, 100)

        # Check details
        self.assertIn("similarity_score", decision.details)
        self.assertEqual(decision.details["similarity_score"], 0.45)
        self.assertEqual(decision.details["change_magnitude"], "major")
        self.assertIn("question_id", decision.details)
        self.assertEqual(decision.details["question_id"], 50)

    def test_analyze_minor_change_answer_generates_regen_a(self):
        """Test that minor change (similarity ≥ 0.6) generates REGEN_A with standard priority."""
        context = DetectionContext(
            detection_run_id="run_009",
            change_id=131,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_jkl" + ("0" * 57),
            previous_checksum="old_jkl" + ("0" * 57),
            diff_data=None,
            similarity_score=0.85,  # Minor change (≥ 0.6)
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 0 questions, 1 answer
        self.mock_backend.execute_query.side_effect = [
            [],                      # No questions
            [{"answer_id": 101}],   # 1 answer
            [{"question_id": 51}]    # Answer's parent question
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        decisions = self.strategy.analyze(context)

        # Should generate REGEN_A for minor change (standard priority)
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.REGEN_A)
        self.assertEqual(decision.reason, ReasonCode.MULTI_SOURCE_ONE_MODIFIED)
        self.assertEqual(decision.entity_type, EntityType.ANSWER)
        self.assertEqual(decision.entity_id, 101)

        # Check details
        self.assertIn("similarity_score", decision.details)
        self.assertEqual(decision.details["similarity_score"], 0.85)
        self.assertEqual(decision.details["change_magnitude"], "minor")
        self.assertEqual(decision.details["priority"], "standard")
        self.assertIn("question_id", decision.details)
        self.assertEqual(decision.details["question_id"], 51)


class TestModifiedContentStrategyTokenOverlap(unittest.TestCase):
    """Test suite for token overlap (indirect impact) detection."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_analyze_token_overlap_generates_regen_q(self):
        """Test that token overlap generates REGEN_Q for indirectly affected questions."""
        context = DetectionContext(
            detection_run_id="run_010",
            change_id=132,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_mno" + ("0" * 57),
            previous_checksum="old_mno" + ("0" * 57),
            diff_data={"changes": [{"tokens": ["refund", "policy", "30", "days"]}]},
            similarity_score=0.70,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: no direct impact
        self.mock_backend.execute_query.side_effect = [
            [],  # No directly affected questions
            []   # No directly affected answers
        ]

        # Mock: token overlap detected
        overlap_result = TokenOverlapResult(
            question_id=60,
            overlap_score=0.75,
            matched_tokens={"refund", "policy", "30"},
            total_question_tokens=10,
            overlap_percentage=75.0  # 0-100 range
        )
        self.mock_token_matcher.find_overlapping_questions.return_value = [overlap_result]

        decisions = self.strategy.analyze(context)

        # Should generate REGEN_Q for token overlap
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.REGEN_Q)
        self.assertEqual(decision.reason, ReasonCode.SOLE_SOURCE_CONTENT_CHANGED)
        self.assertEqual(decision.entity_type, EntityType.QUESTION)
        self.assertEqual(decision.entity_id, 60)

        # Check details
        self.assertIn("overlap_score", decision.details)
        self.assertEqual(decision.details["overlap_score"], 0.75)
        self.assertIn("overlap_percentage", decision.details)
        self.assertEqual(decision.details["overlap_percentage"], 75.0)  # 0-100 range
        self.assertIn("matched_tokens", decision.details)
        self.assertEqual(decision.details["impact_type"], "indirect")
        self.assertEqual(decision.details["detection_method"], "token_overlap")

    def test_analyze_token_overlap_excludes_direct_questions(self):
        """Test that token overlap excludes questions already in direct impact."""
        context = DetectionContext(
            detection_run_id="run_011",
            change_id=133,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_pqr" + ("0" * 57),
            previous_checksum="old_pqr" + ("0" * 57),
            diff_data={"changes": [{"tokens": ["test"]}]},
            similarity_score=0.70,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 1 directly affected question (ID 70)
        self.mock_backend.execute_query.side_effect = [
            [{"question_id": 70}],  # Directly affected
            []                       # No answers
        ]

        # Mock: token overlap includes question 70 and 71
        overlap_result_70 = TokenOverlapResult(
            question_id=70,  # Already in direct impact
            overlap_score=0.8,
            matched_tokens={"test"},
            total_question_tokens=5,
            overlap_percentage=80.0  # 0-100 range
        )
        overlap_result_71 = TokenOverlapResult(
            question_id=71,  # New, indirect only
            overlap_score=0.6,
            matched_tokens={"test"},
            total_question_tokens=5,
            overlap_percentage=60.0  # 0-100 range
        )
        self.mock_token_matcher.find_overlapping_questions.return_value = [
            overlap_result_70,
            overlap_result_71
        ]

        # Mock: sole source for question 70
        self.mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=70,
            answer_id=None,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["old_pqr" + ("0" * 57)]
        )

        decisions = self.strategy.analyze(context)

        # Should generate:
        # 1. REGEN_Q for question 70 (direct, sole source)
        # 2. REGEN_Q for question 71 (indirect, token overlap)
        self.assertEqual(len(decisions), 2)

        # Check question 70 (direct)
        direct_decision = [d for d in decisions if d.entity_id == 70][0]
        self.assertEqual(direct_decision.reason, ReasonCode.SOLE_SOURCE_CONTENT_CHANGED)
        self.assertEqual(direct_decision.details["impact_type"], "direct")

        # Check question 71 (indirect)
        indirect_decision = [d for d in decisions if d.entity_id == 71][0]
        self.assertEqual(indirect_decision.reason, ReasonCode.SOLE_SOURCE_CONTENT_CHANGED)
        self.assertEqual(indirect_decision.details["impact_type"], "indirect")
        self.assertEqual(indirect_decision.details["detection_method"], "token_overlap")


class TestModifiedContentStrategyComplexScenarios(unittest.TestCase):
    """Test suite for complex multi-entity scenarios."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_analyze_mixed_impact_multiple_decisions(self):
        """Test complex scenario with direct + indirect + answer impacts."""
        context = DetectionContext(
            detection_run_id="run_012",
            change_id=134,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_stu" + ("0" * 57),
            previous_checksum="old_stu" + ("0" * 57),
            diff_data={"changes": [{"tokens": ["update"]}]},
            similarity_score=0.50,  # Major change
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 1 direct question, 1 direct answer
        self.mock_backend.execute_query.side_effect = [
            [{"question_id": 80}],   # Direct question
            [{"answer_id": 110}],    # Direct answer
            [{"question_id": 81}],    # Answer's parent question
        ]

        # Mock: token overlap for question 82 (indirect)
        overlap_result = TokenOverlapResult(
            question_id=82,
            overlap_score=0.7,
            matched_tokens={"update"},
            total_question_tokens=5,
            overlap_percentage=70.0  # 0-100 range
        )
        self.mock_token_matcher.find_overlapping_questions.return_value = [overlap_result]

        # Mock: sole source for question 80
        self.mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=80,
            answer_id=None,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["old_stu" + ("0" * 57)]
        )

        decisions = self.strategy.analyze(context)

        # Should generate 3 decisions:
        # 1. REGEN_Q for question 80 (direct, sole source)
        # 2. REGEN_A for answer 110 (major change, similarity < 0.6)
        # 3. REGEN_Q for question 82 (indirect, token overlap)
        self.assertEqual(len(decisions), 3)

        # Verify each decision type
        regen_q_decisions = [d for d in decisions if d.decision == DecisionType.REGEN_Q]
        regen_a_decisions = [d for d in decisions if d.decision == DecisionType.REGEN_A]

        self.assertEqual(len(regen_q_decisions), 2)  # Questions 80 and 82
        self.assertEqual(len(regen_a_decisions), 1)  # Answer 110

    def test_analyze_similarity_threshold_boundary(self):
        """Test similarity score at exact threshold boundary (0.6)."""
        context = DetectionContext(
            detection_run_id="run_013",
            change_id=135,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_vwx" + ("0" * 57),
            previous_checksum="old_vwx" + ("0" * 57),
            diff_data=None,
            similarity_score=0.6,  # Exact threshold
            file_name="test.pdf",
            metadata={}
        )

        # Mock: 1 answer only
        self.mock_backend.execute_query.side_effect = [
            [],                      # No questions
            [{"answer_id": 120}],   # 1 answer
            [{"question_id": 90}]    # Answer's parent
        ]

        # Mock: no token overlap
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        decisions = self.strategy.analyze(context)

        # At threshold 0.6, should be REGEN_A with minor/standard priority (≥ 0.6 = minor)
        self.assertEqual(len(decisions), 1)
        decision = decisions[0]

        self.assertEqual(decision.decision, DecisionType.REGEN_A)
        self.assertEqual(decision.reason, ReasonCode.MULTI_SOURCE_ONE_MODIFIED)
        self.assertEqual(decision.details["change_magnitude"], "minor")
        self.assertEqual(decision.details["priority"], "standard")


class TestModifiedContentStrategyDecisionDetails(unittest.TestCase):
    """Test suite for decision details schema and metadata."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_backend = Mock(spec=IBackend)
        self.mock_token_matcher = Mock(spec=ITokenMatcher)
        self.mock_source_counter = Mock(spec=ISourceCounter)

        self.strategy = ModifiedContentStrategy(
            self.mock_backend,
            self.mock_token_matcher,
            self.mock_source_counter
        )

    def test_regen_q_decision_details_schema(self):
        """Test REGEN_Q decision contains all expected details fields."""
        context = DetectionContext(
            detection_run_id="run_014",
            change_id=136,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_xyz" + ("0" * 57),
            previous_checksum="old_xyz" + ("0" * 57),
            diff_data=None,
            similarity_score=0.75,
            file_name="test.pdf",
            metadata={}
        )

        # Mock: sole source question
        self.mock_backend.execute_query.side_effect = [
            [{"question_id": 95}],
            []
        ]
        self.mock_token_matcher.find_overlapping_questions.return_value = []
        self.mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=95,
            answer_id=None,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["old_xyz" + ("0" * 57)]
        )

        decisions = self.strategy.analyze(context)
        details = decisions[0].details

        # Check required fields
        required_fields = [
            "previous_checksum",
            "new_checksum",
            "similarity_score",
            "impact_type",
            "reason_detail"
        ]

        for field in required_fields:
            self.assertIn(field, details, f"Missing required field: {field}")

    def test_minor_change_decision_has_priority_field(self):
        """Test that minor change decisions include priority field."""
        context = DetectionContext(
            detection_run_id="run_015",
            change_id=137,
            change_type="MODIFIED_CONTENT",
            content_checksum="new_123" + ("0" * 57),
            previous_checksum="old_123" + ("0" * 57),
            diff_data=None,
            similarity_score=0.8,  # Minor change
            file_name="test.pdf",
            metadata={}
        )

        # Mock: answer with minor change
        self.mock_backend.execute_query.side_effect = [
            [],
            [{"answer_id": 130}],
            [{"question_id": 96}]
        ]
        self.mock_token_matcher.find_overlapping_questions.return_value = []

        decisions = self.strategy.analyze(context)
        details = decisions[0].details

        # Check priority field exists
        self.assertIn("priority", details)
        self.assertEqual(details["priority"], "standard")

        # Check change_magnitude
        self.assertIn("change_magnitude", details)
        self.assertEqual(details["change_magnitude"], "minor")


if __name__ == "__main__":
    unittest.main()
