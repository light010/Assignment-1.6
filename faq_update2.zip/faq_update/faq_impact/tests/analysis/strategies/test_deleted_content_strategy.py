"""
Unit Tests for DeletedContentStrategy

This module contains comprehensive unit tests for the DeletedContentStrategy class,
covering all decision paths, edge cases, and error conditions.

Test Coverage:
    - can_handle() method validation
    - Sole source question deletion (INACTIVATE + cascade)
    - Multi-source question deletion (REGEN_Q)
    - Orphaned question detection (all sources invalid)
    - Answer-only deletion (REGEN_A)
    - Cascading inactivation (question → answers)
    - Edge cases: no affected FAQs, invalid context, etc.

Author: Analytics Assist Team
Date: 2025-11-02
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
from typing import List, Dict, Any

# Import classes under test
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../..')))

from faq_impact.analysis.strategies.deleted_content_strategy import DeletedContentStrategy
from faq_impact.core.models.detection_context import DetectionContext, SourceCountResult
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_backend():
    """Create a mock database backend."""
    backend = Mock()
    backend.execute_query = Mock(return_value=[])
    return backend


@pytest.fixture
def mock_source_counter():
    """Create a mock source counter service."""
    counter = Mock()
    counter.count_sources_for_question = Mock()
    counter.count_sources_for_answer = Mock()
    return counter


@pytest.fixture
def strategy(mock_backend, mock_source_counter):
    """Create a DeletedContentStrategy instance with mocked dependencies."""
    return DeletedContentStrategy(
        backend=mock_backend,
        source_counter=mock_source_counter
    )


@pytest.fixture
def deleted_content_context():
    """Create a valid DetectionContext for deleted content."""
    return DetectionContext(
        detection_run_id="test_run_001",
        change_id=123,
        change_type="DELETED_CONTENT",
        content_checksum=None,
        previous_checksum="deleted_checksum_abc123",
        diff_data=None,
        similarity_score=None,
        file_name="test_file.pdf",
        metadata={"chunk_id": 456}
    )


# =============================================================================
# Test: can_handle() Method
# =============================================================================


class TestCanHandle:
    """Test cases for the can_handle() method."""

    def test_can_handle_deleted_content(self, strategy):
        """Test that strategy handles DELETED_CONTENT change type."""
        assert strategy.can_handle("DELETED_CONTENT") is True

    def test_cannot_handle_new_content(self, strategy):
        """Test that strategy does not handle NEW_CONTENT."""
        assert strategy.can_handle("NEW_CONTENT") is False

    def test_cannot_handle_modified_content(self, strategy):
        """Test that strategy does not handle MODIFIED_CONTENT."""
        assert strategy.can_handle("MODIFIED_CONTENT") is False

    def test_cannot_handle_invalid_type(self, strategy):
        """Test that strategy does not handle invalid change types."""
        assert strategy.can_handle("INVALID_TYPE") is False
        assert strategy.can_handle("") is False


# =============================================================================
# Test: Context Validation
# =============================================================================


class TestContextValidation:
    """Test cases for context validation."""

    def test_valid_context(self, strategy, deleted_content_context, mock_backend):
        """Test that valid context passes validation."""
        # Setup: no affected FAQs
        mock_backend.execute_query.return_value = []

        # Should not raise exception
        decisions = strategy.analyze(deleted_content_context)
        assert decisions == []

    def test_missing_previous_checksum(self, strategy):
        """Test that context without previous_checksum raises ValueError."""
        context = DetectionContext(
            detection_run_id="test_run",
            change_id=1,
            change_type="DELETED_CONTENT",
            content_checksum=None,
            previous_checksum=None,  # Missing!
            diff_data=None,
            similarity_score=None,
            file_name="test.pdf",
            metadata={}
        )

        with pytest.raises(ValueError, match="requires previous_checksum"):
            strategy.analyze(context)

    def test_wrong_change_type(self, strategy):
        """Test that wrong change_type raises ValueError."""
        context = DetectionContext(
            detection_run_id="test_run",
            change_id=1,
            change_type="NEW_CONTENT",  # Wrong type!
            content_checksum="abc123",
            previous_checksum=None,
            diff_data=None,
            similarity_score=None,
            file_name="test.pdf",
            metadata={}
        )

        with pytest.raises(ValueError, match="requires change_type='DELETED_CONTENT'"):
            strategy.analyze(context)


# =============================================================================
# Test: Sole Source Question Deletion
# =============================================================================


class TestSoleSourceQuestionDeletion:
    """Test cases for sole source question deletion scenarios."""

    def test_sole_source_question_inactivate(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that sole source question is inactivated and answers are cascaded."""
        # Setup: Question 42 is affected, has sole source
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected questions
            [],  # No affected answers directly
            [{"answer_id": 100}, {"answer_id": 101}]  # Answers for cascading
        ]

        # Mock source counter: question has sole source
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["remaining_checksum"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 3 decisions (1 question INACTIVATE + 2 answer INACTIVATE cascades)
        assert len(decisions) == 3

        # Check question decision
        question_decision = decisions[0]
        assert question_decision.entity_type == EntityType.QUESTION
        assert question_decision.entity_id == 42
        assert question_decision.decision == DecisionType.INACTIVATE
        assert question_decision.reason == ReasonCode.CONTENT_DELETED
        assert question_decision.details["valid_source_count"] == 1

        # Check cascaded answer decisions
        answer_decisions = decisions[1:]
        assert all(d.entity_type == EntityType.ANSWER for d in answer_decisions)
        assert all(d.decision == DecisionType.INACTIVATE for d in answer_decisions)
        assert all(d.reason == ReasonCode.ORPHANED_ANSWER for d in answer_decisions)
        assert {d.entity_id for d in answer_decisions} == {100, 101}

    def test_multiple_sole_source_questions(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that multiple sole source questions are all inactivated."""
        # Setup: Questions 42 and 58 are affected, both sole source
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}, {"question_id": 58}],  # Affected questions
            [],  # No affected answers directly
            [{"answer_id": 100}],  # Answers for Q42
            [{"answer_id": 200}, {"answer_id": 201}]  # Answers for Q58
        ]

        # Mock source counter: both questions have sole source
        mock_source_counter.count_sources_for_question.side_effect = [
            SourceCountResult(
                question_id=42, answer_id=100, valid_source_count=1,
                is_sole_source=True, source_checksums=["checksum1"]
            ),
            SourceCountResult(
                question_id=58, answer_id=200, valid_source_count=1,
                is_sole_source=True, source_checksums=["checksum2"]
            )
        ]

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 2 questions + 3 answers = 5 decisions
        assert len(decisions) == 5

        # Check both questions are inactivated
        question_decisions = [d for d in decisions if d.entity_type == EntityType.QUESTION]
        assert len(question_decisions) == 2
        assert {d.entity_id for d in question_decisions} == {42, 58}
        assert all(d.decision == DecisionType.INACTIVATE for d in question_decisions)


# =============================================================================
# Test: Multi-Source Question Deletion
# =============================================================================


class TestMultiSourceQuestionDeletion:
    """Test cases for multi-source question deletion scenarios."""

    def test_multi_source_question_regen(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that multi-source question is regenerated (REGEN_Q), not inactivated."""
        # Setup: Question 42 is affected, has multiple sources
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected questions
            []  # No affected answers directly
        ]

        # Mock source counter: question has 3 sources
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=3,
            is_sole_source=False,
            source_checksums=["checksum1", "checksum2", "checksum3"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 1 decision (REGEN_Q)
        assert len(decisions) == 1

        decision = decisions[0]
        assert decision.entity_type == EntityType.QUESTION
        assert decision.entity_id == 42
        assert decision.decision == DecisionType.REGEN_Q
        assert decision.reason == ReasonCode.MULTI_SOURCE_ONE_MODIFIED
        assert decision.details["valid_source_count"] == 3
        assert len(decision.details["remaining_checksums"]) == 3

    def test_multi_source_no_cascade(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that REGEN_Q does not cascade to answers."""
        # Setup: Question 42 is affected, has multiple sources
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected questions
            []  # No affected answers directly
        ]

        # Mock source counter: question has 2 sources
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=2,
            is_sole_source=False,
            source_checksums=["checksum1", "checksum2"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: Only 1 decision (REGEN_Q), no cascaded answer decisions
        assert len(decisions) == 1
        assert decisions[0].entity_type == EntityType.QUESTION
        assert decisions[0].decision == DecisionType.REGEN_Q


# =============================================================================
# Test: Orphaned Question Detection
# =============================================================================


class TestOrphanedQuestionDetection:
    """Test cases for orphaned question detection (all sources invalid)."""

    def test_orphaned_question_inactivate(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that orphaned question (count=0) is inactivated with ORPHANED_QUESTION reason."""
        # Setup: Question 42 is affected, has no valid sources
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected questions
            [],  # No affected answers directly
            [{"answer_id": 100}]  # Answers for cascading
        ]

        # Mock source counter: question is orphaned
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=0,
            is_sole_source=False,
            source_checksums=[]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 2 decisions (1 question + 1 answer cascade)
        assert len(decisions) == 2

        # Check question decision
        question_decision = decisions[0]
        assert question_decision.entity_type == EntityType.QUESTION
        assert question_decision.entity_id == 42
        assert question_decision.decision == DecisionType.INACTIVATE
        assert question_decision.reason == ReasonCode.ORPHANED_QUESTION
        assert question_decision.details["valid_source_count"] == 0

    def test_orphaned_question_cascade_to_answers(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that orphaned question cascades inactivation to all answers."""
        # Setup: Orphaned question with multiple answers
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected questions
            [],  # No affected answers directly
            [{"answer_id": 100}, {"answer_id": 101}, {"answer_id": 102}]  # 3 answers
        ]

        # Mock source counter: question is orphaned
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=0,
            is_sole_source=False,
            source_checksums=[]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 4 decisions (1 question + 3 answer cascades)
        assert len(decisions) == 4

        answer_decisions = [d for d in decisions if d.entity_type == EntityType.ANSWER]
        assert len(answer_decisions) == 3
        assert all(d.decision == DecisionType.INACTIVATE for d in answer_decisions)
        assert all(d.reason == ReasonCode.ORPHANED_ANSWER for d in answer_decisions)


# =============================================================================
# Test: Answer-Only Deletion
# =============================================================================


class TestAnswerOnlyDeletion:
    """Test cases for answer-only source deletion (question remains valid)."""

    def test_answer_only_deletion_regen(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that answer with deleted source is regenerated (REGEN_A)."""
        # Setup: Answer 100 is affected, question is NOT being inactivated
        mock_backend.execute_query.side_effect = [
            [],  # No affected questions
            [{"answer_id": 100}],  # Affected answer
            [{"question_id": 42}]  # Parent question lookup
        ]

        # Mock source counter: answer has 2 sources remaining
        mock_source_counter.count_sources_for_answer.return_value = SourceCountResult(
            question_id=None,
            answer_id=100,
            valid_source_count=2,
            is_sole_source=False,
            source_checksums=["checksum1", "checksum2"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 1 decision (REGEN_A)
        assert len(decisions) == 1

        decision = decisions[0]
        assert decision.entity_type == EntityType.ANSWER
        assert decision.entity_id == 100
        assert decision.decision == DecisionType.REGEN_A
        assert decision.reason == ReasonCode.ANSWER_FACTS_CHANGED
        assert decision.details["valid_source_count"] == 2

    def test_orphaned_answer_inactivate(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that orphaned answer (count=0) is inactivated."""
        # Setup: Answer 100 is affected, no sources remain
        mock_backend.execute_query.side_effect = [
            [],  # No affected questions
            [{"answer_id": 100}],  # Affected answer
            [{"question_id": 42}]  # Parent question lookup
        ]

        # Mock source counter: answer is orphaned
        mock_source_counter.count_sources_for_answer.return_value = SourceCountResult(
            question_id=None,
            answer_id=100,
            valid_source_count=0,
            is_sole_source=False,
            source_checksums=[]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 1 decision (INACTIVATE)
        assert len(decisions) == 1

        decision = decisions[0]
        assert decision.entity_type == EntityType.ANSWER
        assert decision.entity_id == 100
        assert decision.decision == DecisionType.INACTIVATE
        assert decision.reason == ReasonCode.ORPHANED_ANSWER
        assert decision.details["valid_source_count"] == 0

    def test_answer_skip_if_question_inactivated(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that answer deletion is skipped if parent question is being inactivated."""
        # Setup: Both question and answer affected, question has sole source
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],  # Affected question
            [{"answer_id": 100}],  # Affected answer (same answer as question's cascade)
            [{"answer_id": 100}],  # Answers for question cascade
            [{"question_id": 42}]  # Parent question lookup for answer
        ]

        # Mock source counter
        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42,
            answer_id=100,
            valid_source_count=1,
            is_sole_source=True,
            source_checksums=["checksum"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: 2 decisions (1 question INACTIVATE + 1 cascaded answer INACTIVATE)
        # The answer should NOT have a separate REGEN_A decision because it's already
        # being cascaded from the question inactivation
        assert len(decisions) == 2

        # Verify both decisions are INACTIVATE
        assert all(d.decision == DecisionType.INACTIVATE for d in decisions)
        assert decisions[0].entity_type == EntityType.QUESTION
        assert decisions[1].entity_type == EntityType.ANSWER


# =============================================================================
# Test: Edge Cases
# =============================================================================


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_no_affected_faqs(
        self,
        strategy,
        deleted_content_context,
        mock_backend
    ):
        """Test that empty decision list is returned when no FAQs are affected."""
        # Setup: no affected questions or answers
        mock_backend.execute_query.side_effect = [
            [],  # No affected questions
            []  # No affected answers
        ]

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: empty list returned
        assert decisions == []

    def test_answer_without_parent_question(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that answer without parent question is skipped."""
        # Setup: Answer 100 is affected, but has no parent question
        mock_backend.execute_query.side_effect = [
            [],  # No affected questions
            [{"answer_id": 100}],  # Affected answer
            []  # Parent question lookup returns empty
        ]

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: no decisions generated (orphan answer skipped)
        assert decisions == []

    def test_multiple_mixed_scenarios(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test complex scenario with mix of sole source, multi-source, and orphaned entities."""
        # Setup: Multiple questions with different source counts
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}, {"question_id": 58}, {"question_id": 91}],  # 3 questions
            [{"answer_id": 200}],  # 1 affected answer
            [{"answer_id": 100}],  # Cascade for Q42
            [],  # No cascade for Q58 (multi-source, no cascade)
            [{"answer_id": 150}, {"answer_id": 151}],  # Cascade for Q91
            [{"question_id": 99}]  # Parent for answer 200
        ]

        # Mock source counter
        mock_source_counter.count_sources_for_question.side_effect = [
            # Q42: sole source → INACTIVATE + cascade
            SourceCountResult(question_id=42, answer_id=100, valid_source_count=1,
                            is_sole_source=True, source_checksums=["c1"]),
            # Q58: multi-source → REGEN_Q
            SourceCountResult(question_id=58, answer_id=120, valid_source_count=3,
                            is_sole_source=False, source_checksums=["c2", "c3", "c4"]),
            # Q91: orphaned → INACTIVATE + cascade
            SourceCountResult(question_id=91, answer_id=150, valid_source_count=0,
                            is_sole_source=False, source_checksums=[])
        ]

        mock_source_counter.count_sources_for_answer.return_value = SourceCountResult(
            question_id=None, answer_id=200, valid_source_count=2,
            is_sole_source=False, source_checksums=["c5", "c6"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify: Q42 INACTIVATE + 1 cascade, Q58 REGEN_Q, Q91 INACTIVATE + 2 cascades, A200 REGEN_A
        # Total: 2 + 1 + 3 + 1 = 7 decisions
        assert len(decisions) == 7

        # Count decision types
        inactivate_count = sum(1 for d in decisions if d.decision == DecisionType.INACTIVATE)
        regen_q_count = sum(1 for d in decisions if d.decision == DecisionType.REGEN_Q)
        regen_a_count = sum(1 for d in decisions if d.decision == DecisionType.REGEN_A)

        assert inactivate_count == 5  # Q42, A100, Q91, A150, A151
        assert regen_q_count == 1  # Q58
        assert regen_a_count == 1  # A200


# =============================================================================
# Test: Decision Validation
# =============================================================================


class TestDecisionValidation:
    """Test that generated decisions are valid ImpactDecision objects."""

    def test_decision_fields_populated(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that all decision fields are properly populated."""
        # Setup: Simple sole source question
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}],
            [],
            []  # No answers to cascade
        ]

        mock_source_counter.count_sources_for_question.return_value = SourceCountResult(
            question_id=42, answer_id=100, valid_source_count=1,
            is_sole_source=True, source_checksums=["checksum"]
        )

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify decision fields
        decision = decisions[0]
        assert decision.entity_type == EntityType.QUESTION
        assert decision.entity_id == 42
        assert decision.change_id == deleted_content_context.change_id
        assert decision.detection_run_id == deleted_content_context.detection_run_id
        assert decision.decision == DecisionType.INACTIVATE
        assert decision.reason == ReasonCode.CONTENT_DELETED
        assert isinstance(decision.details, dict)
        assert decision.applied is False
        assert decision.applied_at is None
        assert decision.applied_by is None
        assert decision.application_error is None

    def test_decision_reason_compatibility(
        self,
        strategy,
        deleted_content_context,
        mock_backend,
        mock_source_counter
    ):
        """Test that decision-reason combinations are valid."""
        # Setup: Mix of decision types
        mock_backend.execute_query.side_effect = [
            [{"question_id": 42}, {"question_id": 58}],
            [],
            [],  # No cascade for Q42
        ]

        mock_source_counter.count_sources_for_question.side_effect = [
            # Q42: sole source → INACTIVATE + CONTENT_DELETED
            SourceCountResult(question_id=42, answer_id=100, valid_source_count=1,
                            is_sole_source=True, source_checksums=["c1"]),
            # Q58: multi-source → REGEN_Q + MULTI_SOURCE_ONE_MODIFIED
            SourceCountResult(question_id=58, answer_id=120, valid_source_count=2,
                            is_sole_source=False, source_checksums=["c2", "c3"])
        ]

        # Execute
        decisions = strategy.analyze(deleted_content_context)

        # Verify compatibility
        for decision in decisions:
            # Should not raise ValueError
            assert ReasonCode.is_compatible(decision.decision, decision.reason)


# =============================================================================
# Run Tests
# =============================================================================


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
