"""
Integration Tests for Analysis Services

This module tests all analysis services together to verify they work correctly
when composed. Tests use mock database backend to avoid external dependencies.

Test Coverage:
    - SourceCounter with caching
    - TokenMatcher with diff_data extraction
    - ChecksumValidator with batch operations
    - DecisionPrioritizer with custom rules
    - CostEstimator with decision batches
    - Cross-service integration scenarios

Author: Analytics Assist Team
Date: 2025-11-02
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
from typing import List, Dict, Any

# Import services
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_impact.analysis.services.source_counter import SourceCounter
from faq_impact.analysis.services.token_matcher import TokenMatcher
from faq_impact.analysis.services.checksum_validator import ChecksumValidator
from faq_impact.analysis.services.decision_prioritizer import DecisionPrioritizer, PriorityRule
from faq_impact.analysis.services.cost_estimator import CostEstimator

from faq_impact.core.models.impact_decision import ImpactDecision, ImpactSummary
from faq_impact.core.models.detection_context import SourceCountResult, TokenOverlapResult
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode


# =============================================================================
# Test Fixtures
# =============================================================================


def create_mock_backend() -> Mock:
    """Create mock database backend with common query responses."""
    backend = Mock()
    backend.execute_query = Mock()
    return backend


def create_sample_decision(
    impact_id: int = 1,
    decision_type: DecisionType = DecisionType.REGEN_Q,
    reason: ReasonCode = ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR,
    details: Dict[str, Any] = None
) -> ImpactDecision:
    """Create sample ImpactDecision for testing."""
    return ImpactDecision(
        impact_id=impact_id,
        entity_type=EntityType.QUESTION,
        entity_id=123,
        change_id=456,
        detection_run_id="test_run_001",
        decision=decision_type,
        reason=reason,
        details=details or {},
        created_at=datetime.now(),
        applied=False,
        applied_at=None,
        applied_by=None,
        application_error=None
    )


def create_sample_diff_data() -> Dict[str, Any]:
    """Create sample diff_data JSON for testing."""
    return {
        "total_changes": 2,
        "changes": [
            {
                "change_type": "replace",
                "token_changes": [
                    {"type": "replace", "old_value": "12 days", "new_value": "10 days"},
                    {"type": "replace", "old_value": "$1,000", "new_value": "$1,500"}
                ]
            }
        ]
    }


# =============================================================================
# SourceCounter Integration Tests
# =============================================================================


class TestSourceCounterIntegration(unittest.TestCase):
    """Integration tests for SourceCounter service."""

    def setUp(self):
        """Set up test fixtures."""
        self.backend = create_mock_backend()
        self.counter = SourceCounter(self.backend, enable_cache=True, cache_ttl_seconds=300)

    def test_count_sources_for_question_with_cache(self):
        """Test counting question sources with caching enabled."""
        # Mock database responses
        self.backend.execute_query.side_effect = [
            # First call: get answer_id
            [{'answer_id': 789}],
            # Second call: get sources
            [
                {'content_checksum': 'abc123'},
                {'content_checksum': 'def456'},
                {'content_checksum': 'ghi789'}
            ]
        ]

        # First call - should hit database
        result1 = self.counter.count_sources_for_question(123)
        self.assertEqual(result1.valid_source_count, 3)
        self.assertFalse(result1.is_sole_source)
        self.assertEqual(result1.answer_id, 789)
        self.assertEqual(len(result1.source_checksums), 3)

        # Second call - should use cache
        result2 = self.counter.count_sources_for_question(123)
        self.assertEqual(result2.valid_source_count, 3)

        # Verify cache hit
        stats = self.counter.get_cache_stats()
        self.assertEqual(stats['hits'], 1)
        self.assertEqual(stats['misses'], 1)

    def test_count_sources_orphaned_question(self):
        """Test counting sources for orphaned question (zero sources)."""
        # Mock database responses
        self.backend.execute_query.side_effect = [
            # First call: get answer_id
            [{'answer_id': 789}],
            # Second call: get sources (empty)
            []
        ]

        result = self.counter.count_sources_for_question(123)
        self.assertEqual(result.valid_source_count, 0)
        self.assertTrue(result.is_orphaned())
        self.assertFalse(result.is_sole_source)
        self.assertEqual(len(result.source_checksums), 0)

    def test_count_sources_sole_source_question(self):
        """Test counting sources for sole-source question."""
        # Mock database responses
        self.backend.execute_query.side_effect = [
            # First call: get answer_id
            [{'answer_id': 789}],
            # Second call: get sources (one source)
            [{'content_checksum': 'abc123'}]
        ]

        result = self.counter.count_sources_for_question(123)
        self.assertEqual(result.valid_source_count, 1)
        self.assertTrue(result.is_sole_source)
        self.assertFalse(result.is_orphaned())
        self.assertTrue(result.has_checksum('abc123'))

    def test_cache_clear(self):
        """Test cache clearing functionality."""
        # Setup cached result
        self.backend.execute_query.side_effect = [
            [{'answer_id': 789}],
            [{'content_checksum': 'abc123'}]
        ]

        result1 = self.counter.count_sources_for_question(123)

        # Clear cache
        self.counter.clear_cache()

        # Verify cache is empty
        stats = self.counter.get_cache_stats()
        self.assertEqual(stats['entries'], 0)
        self.assertEqual(stats['hits'], 0)
        self.assertEqual(stats['misses'], 0)


# =============================================================================
# TokenMatcher Integration Tests
# =============================================================================


class TestTokenMatcherIntegration(unittest.TestCase):
    """Integration tests for TokenMatcher service."""

    def setUp(self):
        """Set up test fixtures."""
        self.backend = create_mock_backend()
        self.matcher = TokenMatcher(self.backend, overlap_threshold=0.3)

    def test_extract_tokens_from_diff_data(self):
        """Test token extraction from diff_data JSON."""
        diff_data = create_sample_diff_data()
        tokens = self.matcher.extract_tokens_from_diff_data(diff_data)

        # Should extract: 12, 10, days, 1000, 1500
        self.assertGreater(len(tokens), 0)
        self.assertIn('12', tokens)
        self.assertIn('10', tokens)
        self.assertIn('days', tokens)

    def test_calculate_token_overlap(self):
        """Test Jaccard similarity calculation."""
        changed_tokens = {'annual', 'limit', '12', '10'}
        question_text = "What is the annual contribution limit?"

        score = self.matcher.calculate_token_overlap(changed_tokens, question_text)

        # Should have overlap (annual, limit present in question)
        self.assertGreater(score, 0.0)
        self.assertLessEqual(score, 1.0)

    def test_find_overlapping_questions(self):
        """Test finding questions with significant token overlap."""
        diff_data = create_sample_diff_data()

        # Mock database response
        self.backend.execute_query.return_value = [
            {'question_id': 1, 'question_text': 'How many days do we get?'},
            {'question_id': 2, 'question_text': 'What is the daily allowance?'}
        ]

        results = self.matcher.find_overlapping_questions(diff_data, 'checksum123')

        # Should return list of TokenOverlapResult
        self.assertIsInstance(results, list)
        for result in results:
            self.assertIsInstance(result, TokenOverlapResult)
            self.assertGreaterEqual(result.overlap_score, self.matcher.overlap_threshold)

    def test_empty_diff_data_handling(self):
        """Test handling of empty diff_data."""
        diff_data = {"changes": []}
        tokens = self.matcher.extract_tokens_from_diff_data(diff_data)
        self.assertEqual(len(tokens), 0)


# =============================================================================
# ChecksumValidator Integration Tests
# =============================================================================


class TestChecksumValidatorIntegration(unittest.TestCase):
    """Integration tests for ChecksumValidator service."""

    def setUp(self):
        """Set up test fixtures."""
        self.backend = create_mock_backend()
        self.validator = ChecksumValidator(self.backend)

    def test_validate_valid_checksum(self):
        """Test validation of valid checksum that exists."""
        valid_checksum = 'a' * 64  # 64-char hex string

        # Mock database response
        self.backend.execute_query.return_value = [{'count': 1}]

        result = self.validator.validate_checksum(valid_checksum)

        self.assertTrue(result.is_valid)
        self.assertTrue(result.exists)
        self.assertTrue(result.is_ok())

    def test_validate_invalid_format(self):
        """Test validation of invalid checksum format."""
        invalid_checksum = 'invalid'

        result = self.validator.validate_checksum(invalid_checksum)

        self.assertFalse(result.is_valid)
        self.assertFalse(result.exists)
        self.assertTrue(result.has_error())

    def test_validate_checksums_batch(self):
        """Test batch validation of multiple checksums."""
        checksums = [
            'a' * 64,  # Valid
            'b' * 64,  # Valid
            'invalid'  # Invalid
        ]

        # Mock database response (only for format-valid checksums)
        self.backend.execute_query.return_value = [
            {'content_checksum': 'a' * 64, 'count': 1},
            {'content_checksum': 'b' * 64, 'count': 2}  # Duplicate
        ]

        results = self.validator.validate_checksums_batch(checksums)

        self.assertEqual(len(results), 3)
        self.assertTrue(results['a' * 64].is_ok())
        self.assertTrue(results['b' * 64].is_ok())
        self.assertFalse(results['invalid'].is_valid)

    def test_is_duplicate_checksum(self):
        """Test duplicate checksum detection."""
        checksum = 'a' * 64

        # Mock database response showing duplicate
        self.backend.execute_query.return_value = [{'count': 2}]

        is_duplicate = self.validator.is_duplicate_checksum(checksum)

        self.assertTrue(is_duplicate)


# =============================================================================
# DecisionPrioritizer Integration Tests
# =============================================================================


class TestDecisionPrioritizerIntegration(unittest.TestCase):
    """Integration tests for DecisionPrioritizer service."""

    def setUp(self):
        """Set up test fixtures."""
        self.prioritizer = DecisionPrioritizer()

    def test_get_priority_score_inactivate(self):
        """Test priority scoring for INACTIVATE decision."""
        decision = create_sample_decision(
            decision_type=DecisionType.INACTIVATE,
            reason=ReasonCode.SOLE_SOURCE_DELETED
        )

        score = self.prioritizer.get_priority_score(decision)

        # INACTIVATE base (100) + SOLE_SOURCE_DELETED adjustment (20) = 120
        self.assertEqual(score, 120)

    def test_sort_by_priority(self):
        """Test sorting decisions by priority."""
        decisions = [
            create_sample_decision(1, DecisionType.NOOP, ReasonCode.NO_ACTION_NEEDED),
            create_sample_decision(2, DecisionType.INACTIVATE, ReasonCode.SOLE_SOURCE_DELETED),
            create_sample_decision(3, DecisionType.REGEN_Q, ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR)
        ]

        sorted_decisions = self.prioritizer.sort_by_priority(decisions)

        # Should be: INACTIVATE, REGEN_Q, NOOP
        self.assertEqual(sorted_decisions[0].decision, DecisionType.INACTIVATE)
        self.assertEqual(sorted_decisions[1].decision, DecisionType.REGEN_Q)
        self.assertEqual(sorted_decisions[2].decision, DecisionType.NOOP)

    def test_add_custom_rule(self):
        """Test adding custom priority rule."""
        # Create rule: boost priority for high similarity
        high_similarity_rule = PriorityRule(
            name="high_similarity",
            condition=lambda d: d.details.get('similarity_score', 0) > 0.9,
            priority_adjustment=10
        )

        self.prioritizer.add_custom_rule(high_similarity_rule)

        # Decision with high similarity
        decision = create_sample_decision(
            decision_type=DecisionType.REGEN_Q,
            details={'similarity_score': 0.95}
        )

        score = self.prioritizer.get_priority_score(decision)

        # REGEN_Q base (80) + SOLE_SOURCE_MODIFIED_MAJOR (15) + custom (10) = 105
        self.assertEqual(score, 105)

    def test_get_priority_breakdown(self):
        """Test detailed priority breakdown."""
        decision = create_sample_decision(
            decision_type=DecisionType.REGEN_Q,
            reason=ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR
        )

        breakdown = self.prioritizer.get_priority_breakdown(decision)

        self.assertEqual(breakdown['base_priority'], 80)  # REGEN_Q
        self.assertEqual(breakdown['reason_adjustment'], 15)  # SOLE_SOURCE_MODIFIED_MAJOR
        self.assertEqual(breakdown['custom_adjustments'], 0)
        self.assertEqual(breakdown['final_score'], 95)


# =============================================================================
# CostEstimator Integration Tests
# =============================================================================


class TestCostEstimatorIntegration(unittest.TestCase):
    """Integration tests for CostEstimator service."""

    def setUp(self):
        """Set up test fixtures."""
        self.estimator = CostEstimator()

    def test_estimate_decision_cost_regen_q(self):
        """Test cost estimation for REGEN_Q decision."""
        decision = create_sample_decision(decision_type=DecisionType.REGEN_Q)

        cost = self.estimator.estimate_decision_cost(decision)

        # Should equal cost_per_question_gen (default $0.05)
        self.assertEqual(cost, 0.05)

    def test_estimate_decisions_batch(self):
        """Test batch cost estimation with breakdown."""
        decisions = [
            create_sample_decision(1, DecisionType.REGEN_Q),
            create_sample_decision(2, DecisionType.REGEN_A),
            create_sample_decision(3, DecisionType.PLAN_CREATE),
            create_sample_decision(4, DecisionType.EVALUATE),
            create_sample_decision(5, DecisionType.INACTIVATE)
        ]

        estimate = self.estimator.estimate_decisions_batch(decisions)

        # REGEN_Q: $0.05
        # REGEN_A: $0.03
        # PLAN_CREATE: $0.05 + $0.03 = $0.08
        # EVALUATE: $0.02
        # INACTIVATE: $0.00
        # Total: $0.18
        self.assertAlmostEqual(estimate.total_cost_usd, 0.18, places=2)
        self.assertEqual(estimate.generation_count, 4)  # Q+A from CREATE, Q from REGEN_Q, A from REGEN_A
        self.assertEqual(estimate.evaluation_count, 1)

    def test_estimate_summary_cost(self):
        """Test cost estimation from ImpactSummary."""
        decisions = [
            create_sample_decision(1, DecisionType.REGEN_Q),
            create_sample_decision(2, DecisionType.REGEN_Q),
            create_sample_decision(3, DecisionType.REGEN_A)
        ]

        summary = ImpactSummary.from_decisions(decisions, cost_per_generation=0.0)
        estimate = self.estimator.estimate_summary_cost(summary)

        # 2 * REGEN_Q ($0.05) + 1 * REGEN_A ($0.03) = $0.13
        self.assertAlmostEqual(estimate.total_cost_usd, 0.13, places=2)

    def test_cost_estimate_format_summary(self):
        """Test formatted cost summary output."""
        decisions = [create_sample_decision(i, DecisionType.REGEN_Q) for i in range(5)]

        estimate = self.estimator.estimate_decisions_batch(decisions)
        summary = estimate.format_summary()

        self.assertIn("Cost Estimate:", summary)
        self.assertIn("Total:", summary)
        self.assertIn("Question Generation:", summary)


# =============================================================================
# Cross-Service Integration Tests
# =============================================================================


class TestCrossServiceIntegration(unittest.TestCase):
    """Integration tests for services working together."""

    def setUp(self):
        """Set up test fixtures."""
        self.backend = create_mock_backend()
        self.source_counter = SourceCounter(self.backend)
        self.token_matcher = TokenMatcher(self.backend)
        self.checksum_validator = ChecksumValidator(self.backend)
        self.prioritizer = DecisionPrioritizer()
        self.estimator = CostEstimator()

    def test_analyze_modified_content_workflow(self):
        """
        Test complete workflow for modified content analysis.

        Workflow:
        1. Validate checksum
        2. Extract tokens from diff
        3. Find overlapping questions
        4. Count sources for each question
        5. Create impact decisions
        6. Prioritize decisions
        7. Estimate costs
        """
        # 1. Validate checksum
        checksum = 'a' * 64
        self.backend.execute_query.return_value = [{'count': 1}]
        validation_result = self.checksum_validator.validate_checksum(checksum)
        self.assertTrue(validation_result.is_ok())

        # 2. Extract tokens from diff
        diff_data = create_sample_diff_data()
        tokens = self.token_matcher.extract_tokens_from_diff_data(diff_data)
        self.assertGreater(len(tokens), 0)

        # 3. Find overlapping questions
        self.backend.execute_query.return_value = [
            {'question_id': 1, 'question_text': 'How many days allowed?'}
        ]
        overlap_results = self.token_matcher.find_overlapping_questions(diff_data, checksum)

        # 4. Count sources for questions (if needed)
        # (Skipped for brevity - would check sole vs multi-source)

        # 5. Create impact decisions
        decisions = [
            create_sample_decision(1, DecisionType.REGEN_Q, ReasonCode.TOKEN_OVERLAP_HIGH),
            create_sample_decision(2, DecisionType.REGEN_A, ReasonCode.MULTI_SOURCE_MODIFIED)
        ]

        # 6. Prioritize decisions
        sorted_decisions = self.prioritizer.sort_by_priority(decisions)
        self.assertEqual(len(sorted_decisions), 2)

        # 7. Estimate costs
        cost_estimate = self.estimator.estimate_decisions_batch(sorted_decisions)
        self.assertGreater(cost_estimate.total_cost_usd, 0)

        # Workflow complete!
        self.assertTrue(True)

    def test_deleted_content_orphan_detection_workflow(self):
        """
        Test workflow for deleted content with orphan detection.

        Workflow:
        1. Find questions using deleted content
        2. Count remaining sources for each question
        3. Identify orphaned vs multi-source questions
        4. Create INACTIVATE decisions for orphans
        5. Create REGEN decisions for multi-source
        6. Prioritize (INACTIVATE should be highest)
        7. Estimate costs (INACTIVATE has no cost)
        """
        # 1. Find questions using deleted content
        deleted_checksum = 'deleted' + 'a' * 57

        # 2-3. Check sources for each question
        self.backend.execute_query.side_effect = [
            # Question 1: orphaned (0 sources after deletion)
            [{'answer_id': 101}],
            [],
            # Question 2: multi-source (2 sources remaining)
            [{'answer_id': 102}],
            [{'content_checksum': 'abc123'}, {'content_checksum': 'def456'}]
        ]

        result1 = self.source_counter.count_sources_for_question(1)
        result2 = self.source_counter.count_sources_for_question(2)

        self.assertTrue(result1.is_orphaned())
        self.assertTrue(result2.is_multi_source())

        # 4-5. Create decisions
        decisions = []
        if result1.is_orphaned():
            decisions.append(create_sample_decision(
                1, DecisionType.INACTIVATE, ReasonCode.SOLE_SOURCE_DELETED
            ))
        if result2.is_multi_source():
            decisions.append(create_sample_decision(
                2, DecisionType.REGEN_A, ReasonCode.MULTI_SOURCE_DELETED
            ))

        # 6. Prioritize
        sorted_decisions = self.prioritizer.sort_by_priority(decisions)
        self.assertEqual(sorted_decisions[0].decision, DecisionType.INACTIVATE)

        # 7. Estimate costs
        cost_estimate = self.estimator.estimate_decisions_batch(sorted_decisions)
        # INACTIVATE: $0, REGEN_A: $0.03
        self.assertAlmostEqual(cost_estimate.total_cost_usd, 0.03, places=2)


# =============================================================================
# Test Suite
# =============================================================================


def suite():
    """Create test suite."""
    test_suite = unittest.TestSuite()

    # Add test classes
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestSourceCounterIntegration))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestTokenMatcherIntegration))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestChecksumValidatorIntegration))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestDecisionPrioritizerIntegration))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestCostEstimatorIntegration))
    test_suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestCrossServiceIntegration))

    return test_suite


if __name__ == '__main__':
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite())
