"""
FAQ Impact Analysis Module

This module provides comprehensive impact analysis and automated change propagation
for FAQ content management. It separates analysis (what changed) from application
(how to respond) to enable both planning and execution workflows.

Architecture Overview:
    1. Analysis Phase - Identifies changes and their impacts
       - Detects new, modified, and deleted content chunks
       - Analyzes impact on existing Q/A pairs
       - Generates LLM-friendly diffs for modified content
       - Produces ImpactAnalysisReport for review

    2. Application Phase - Executes changes based on analysis
       - Generates new Q/A pairs for new content
       - Regenerates affected Q/A pairs for modified content
       - Deactivates or regenerates Q/A pairs for deleted content
       - Maintains provenance through checksum tracking

Core Concepts:
    - Change Detection: Identify new/modified/deleted chunks via checksums
    - Impact Analysis: Map chunks to affected questions and answers
    - Selective Regeneration: Only regenerate when truly necessary
    - Provenance Tracking: Link Q/A pairs to source content checksums

Design Principles:
    - Separation of Concerns: Analysis doesn't modify data
    - Strategy Pattern: Pluggable strategies for different change types
    - Repository Pattern: Clean database abstraction
    - Immutability: Value objects for data integrity

Module Structure:
    core/           - Domain models, interfaces, enums
    database/       - SQL schema, queries, repository layer
    analysis/       - Impact analysis strategies and services
    application/    - Change execution and application logic
    config/         - Configuration classes
    utility/        - Metrics, validators, helpers
    tests/          - Comprehensive test coverage

Usage Example:
    >>> from faq_impact.analysis import ImpactAnalyzer
    >>> from faq_impact.application import ChangeExecutor
    >>> from database.backends.factory import BackendFactory
    >>>
    >>> # Analysis Phase
    >>> backend = BackendFactory.create_backend(config)
    >>> analyzer = ImpactAnalyzer(backend)
    >>> report = analyzer.analyze_changes()
    >>>
    >>> # Review report, then execute changes
    >>> executor = ChangeExecutor(backend)
    >>> results = executor.apply_changes(report)

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Analytics Assist Team"

# Core exports will be added as components are implemented
__all__ = [
    "__version__",
    "__author__",
]
