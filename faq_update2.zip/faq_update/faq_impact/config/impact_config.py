"""
ImpactAnalysisConfig - Configuration for FAQ Impact Analysis

This module defines the configuration dataclass for impact analysis behavior,
controlling similarity detection, LLM evaluation, and regeneration decisions.

Classes:
    - ImpactAnalysisConfig: Main configuration dataclass with validation

Author: Analytics Assist Team
Date: 2025-11-02
"""

import os
from dataclasses import dataclass, field
from typing import Optional

from ..core.enums.similarity_method import SimilarityMethod


@dataclass
class ImpactAnalysisConfig:
    """
    Configuration for FAQ Impact Analysis behavior.

    This configuration controls how the impact analysis system detects changes
    and makes regeneration decisions. It provides sensible defaults optimized
    for typical FAQ content while supporting customization for specific needs.

    Attributes:
        token_overlap_threshold: Minimum token overlap ratio (Jaccard similarity)
            to consider content as requiring regeneration. Range: 0.0-1.0.
            - 0.3 (default): Regenerate if >70% tokens changed (aggressive)
            - 0.5: Regenerate if >50% tokens changed (balanced)
            - 0.7: Regenerate if >30% tokens changed (conservative)

        similarity_method: Method for calculating content similarity.
            Default: 'jaccard' (TOKEN_OVERLAP) - fast, good for factual changes.
            Options: 'jaccard', 'sequence', 'hybrid', 'semantic'

        min_token_overlap_count: Minimum number of overlapping tokens required
            to consider content related (prevents false positives from tiny chunks).
            Default: 2 tokens

        enable_llm_evaluation: Whether to use LLM for semantic evaluation of
            changes (more accurate but slower/costly).
            Default: True - enables intelligent decision-making

        llm_timeout_seconds: Maximum time to wait for LLM evaluation API calls.
            Default: 30 seconds - prevents hanging on slow API responses

        max_concurrent_evaluations: Maximum number of concurrent LLM evaluations
            to run in parallel (controls cost and rate limits).
            Default: 5 - balances throughput with API rate limits

    Example:
        >>> # Use defaults
        >>> config = ImpactAnalysisConfig()
        >>> config.token_overlap_threshold
        0.3

        >>> # Customize for aggressive regeneration
        >>> config = ImpactAnalysisConfig(
        ...     token_overlap_threshold=0.2,
        ...     enable_llm_evaluation=False  # Skip LLM for speed
        ... )

        >>> # Load from environment variables
        >>> config = ImpactAnalysisConfig.from_env()

    Environment Variables:
        IMPACT_TOKEN_OVERLAP_THRESHOLD: Override token_overlap_threshold
        IMPACT_SIMILARITY_METHOD: Override similarity_method
        IMPACT_MIN_TOKEN_OVERLAP: Override min_token_overlap_count
        IMPACT_ENABLE_LLM_EVAL: Override enable_llm_evaluation (true/false)
        IMPACT_LLM_TIMEOUT: Override llm_timeout_seconds
        IMPACT_MAX_CONCURRENT_EVAL: Override max_concurrent_evaluations

    Validation:
        Configuration validates itself on creation:
        - Thresholds must be in range 0.0-1.0
        - Similarity method must be valid SimilarityMethod
        - Counts and timeouts must be positive integers
        - Raises clear ValueError on invalid configuration

    Design Notes:
        - Defaults optimized for typical FAQ content (factual, structured)
        - Conservative defaults favor accuracy over speed
        - All values can be overridden via environment variables
        - Validation happens at creation time (fail-fast principle)
    """

    token_overlap_threshold: float = 0.3
    similarity_method: str = "jaccard"  # Maps to SimilarityMethod.TOKEN_OVERLAP
    min_token_overlap_count: int = 2
    enable_llm_evaluation: bool = True
    llm_timeout_seconds: int = 30
    max_concurrent_evaluations: int = 5

    def __post_init__(self):
        """
        Validate configuration after initialization.

        Raises:
            ValueError: If any configuration value is invalid
        """
        self._validate()

    def _validate(self):
        """
        Validate all configuration values.

        Raises:
            ValueError: If any value is invalid, with descriptive error message
        """
        # Validate token_overlap_threshold
        if not isinstance(self.token_overlap_threshold, (int, float)):
            raise ValueError(
                f"token_overlap_threshold must be a number, "
                f"got {type(self.token_overlap_threshold).__name__}"
            )
        if not (0.0 <= self.token_overlap_threshold <= 1.0):
            raise ValueError(
                f"token_overlap_threshold must be between 0.0 and 1.0, "
                f"got {self.token_overlap_threshold}"
            )

        # Validate similarity_method
        valid_methods = ["jaccard", "sequence", "hybrid", "semantic", "bm25"]
        if self.similarity_method.lower() not in valid_methods:
            raise ValueError(
                f"similarity_method must be one of {valid_methods}, "
                f"got '{self.similarity_method}'"
            )

        # Validate min_token_overlap_count
        if not isinstance(self.min_token_overlap_count, int):
            raise ValueError(
                f"min_token_overlap_count must be an integer, "
                f"got {type(self.min_token_overlap_count).__name__}"
            )
        if self.min_token_overlap_count < 0:
            raise ValueError(
                f"min_token_overlap_count must be non-negative, "
                f"got {self.min_token_overlap_count}"
            )

        # Validate enable_llm_evaluation
        if not isinstance(self.enable_llm_evaluation, bool):
            raise ValueError(
                f"enable_llm_evaluation must be a boolean, "
                f"got {type(self.enable_llm_evaluation).__name__}"
            )

        # Validate llm_timeout_seconds
        if not isinstance(self.llm_timeout_seconds, int):
            raise ValueError(
                f"llm_timeout_seconds must be an integer, "
                f"got {type(self.llm_timeout_seconds).__name__}"
            )
        if self.llm_timeout_seconds <= 0:
            raise ValueError(
                f"llm_timeout_seconds must be positive, "
                f"got {self.llm_timeout_seconds}"
            )

        # Validate max_concurrent_evaluations
        if not isinstance(self.max_concurrent_evaluations, int):
            raise ValueError(
                f"max_concurrent_evaluations must be an integer, "
                f"got {type(self.max_concurrent_evaluations).__name__}"
            )
        if self.max_concurrent_evaluations <= 0:
            raise ValueError(
                f"max_concurrent_evaluations must be positive, "
                f"got {self.max_concurrent_evaluations}"
            )

    def get_similarity_method_enum(self) -> SimilarityMethod:
        """
        Convert similarity_method string to SimilarityMethod enum.

        Returns:
            SimilarityMethod enum corresponding to configured method

        Raises:
            ValueError: If similarity_method is not valid

        Example:
            >>> config = ImpactAnalysisConfig(similarity_method="jaccard")
            >>> config.get_similarity_method_enum()
            <SimilarityMethod.TOKEN_OVERLAP: 'TOKEN_OVERLAP'>
        """
        method_mapping = {
            "jaccard": SimilarityMethod.TOKEN_OVERLAP,
            "sequence": SimilarityMethod.SEQUENCE_SIMILARITY,
            "hybrid": SimilarityMethod.HYBRID,
            "semantic": SimilarityMethod.SEMANTIC_EMBEDDING,
            "bm25": SimilarityMethod.BM25,
        }
        return method_mapping[self.similarity_method.lower()]

    @classmethod
    def from_env(cls) -> "ImpactAnalysisConfig":
        """
        Create ImpactAnalysisConfig from environment variables.

        Environment variables override default values. If an environment variable
        is not set, the default value is used.

        Returns:
            ImpactAnalysisConfig instance with values from environment

        Environment Variables:
            IMPACT_TOKEN_OVERLAP_THRESHOLD: float (0.0-1.0)
            IMPACT_SIMILARITY_METHOD: str (jaccard, sequence, hybrid, semantic)
            IMPACT_MIN_TOKEN_OVERLAP: int (>= 0)
            IMPACT_ENABLE_LLM_EVAL: bool (true/false, 1/0, yes/no)
            IMPACT_LLM_TIMEOUT: int (> 0)
            IMPACT_MAX_CONCURRENT_EVAL: int (> 0)

        Example:
            >>> # With environment variables set:
            >>> # export IMPACT_TOKEN_OVERLAP_THRESHOLD=0.5
            >>> # export IMPACT_ENABLE_LLM_EVAL=false
            >>> config = ImpactAnalysisConfig.from_env()
            >>> config.token_overlap_threshold
            0.5
            >>> config.enable_llm_evaluation
            False

        Raises:
            ValueError: If environment variable values are invalid
        """
        def parse_bool(value: str) -> bool:
            """Parse boolean from environment variable string."""
            return value.lower() in ("true", "1", "yes", "on")

        return cls(
            token_overlap_threshold=float(
                os.getenv("IMPACT_TOKEN_OVERLAP_THRESHOLD", "0.3")
            ),
            similarity_method=os.getenv("IMPACT_SIMILARITY_METHOD", "jaccard"),
            min_token_overlap_count=int(
                os.getenv("IMPACT_MIN_TOKEN_OVERLAP", "2")
            ),
            enable_llm_evaluation=parse_bool(
                os.getenv("IMPACT_ENABLE_LLM_EVAL", "true")
            ),
            llm_timeout_seconds=int(os.getenv("IMPACT_LLM_TIMEOUT", "30")),
            max_concurrent_evaluations=int(
                os.getenv("IMPACT_MAX_CONCURRENT_EVAL", "5")
            ),
        )

    @classmethod
    def for_aggressive_regeneration(cls) -> "ImpactAnalysisConfig":
        """
        Factory method for aggressive regeneration configuration.

        This configuration maximizes regeneration - regenerates FAQs even for
        small changes. Use when accuracy is critical and cost is secondary.

        Configuration:
            - token_overlap_threshold: 0.5 (regenerate if >50% tokens changed)
            - similarity_method: hybrid (most comprehensive detection)
            - min_token_overlap_count: 1 (detect even tiny overlaps)
            - enable_llm_evaluation: True (use LLM for all decisions)
            - llm_timeout_seconds: 45 (allow more time for LLM)
            - max_concurrent_evaluations: 10 (faster processing)

        Use Cases:
            - Critical content (legal, medical, financial)
            - First-time migration to impact analysis
            - Content with frequent factual updates
            - When over-regeneration is acceptable

        Returns:
            ImpactAnalysisConfig configured for aggressive regeneration

        Example:
            >>> config = ImpactAnalysisConfig.for_aggressive_regeneration()
            >>> config.token_overlap_threshold
            0.5
            >>> config.similarity_method
            'hybrid'
        """
        return cls(
            token_overlap_threshold=0.5,
            similarity_method="hybrid",
            min_token_overlap_count=1,
            enable_llm_evaluation=True,
            llm_timeout_seconds=45,
            max_concurrent_evaluations=10,
        )

    @classmethod
    def for_conservative_regeneration(cls) -> "ImpactAnalysisConfig":
        """
        Factory method for conservative regeneration configuration.

        This configuration minimizes regeneration - only regenerates for
        significant changes. Use when minimizing cost/churn is important.

        Configuration:
            - token_overlap_threshold: 0.15 (only regenerate if >85% tokens changed)
            - similarity_method: jaccard (fast, focuses on token changes)
            - min_token_overlap_count: 3 (require meaningful overlap)
            - enable_llm_evaluation: False (skip LLM, use rules only)
            - llm_timeout_seconds: 20 (shorter timeout)
            - max_concurrent_evaluations: 3 (lower concurrency)

        Use Cases:
            - Stable content with rare updates
            - Cost-sensitive environments
            - Content with minor wording changes
            - When under-regeneration is acceptable

        Returns:
            ImpactAnalysisConfig configured for conservative regeneration

        Example:
            >>> config = ImpactAnalysisConfig.for_conservative_regeneration()
            >>> config.token_overlap_threshold
            0.15
            >>> config.enable_llm_evaluation
            False
        """
        return cls(
            token_overlap_threshold=0.15,
            similarity_method="jaccard",
            min_token_overlap_count=3,
            enable_llm_evaluation=False,
            llm_timeout_seconds=20,
            max_concurrent_evaluations=3,
        )

    @classmethod
    def for_cost_optimized(cls) -> "ImpactAnalysisConfig":
        """
        Factory method for cost-optimized configuration.

        This configuration balances accuracy and cost - uses fast methods
        first, LLM only when necessary. Use for production workloads.

        Configuration:
            - token_overlap_threshold: 0.3 (balanced threshold)
            - similarity_method: jaccard (fast, good enough)
            - min_token_overlap_count: 2 (standard minimum)
            - enable_llm_evaluation: True (but used selectively)
            - llm_timeout_seconds: 30 (standard timeout)
            - max_concurrent_evaluations: 5 (moderate concurrency)

        Use Cases:
            - Production FAQ systems
            - Regular content updates
            - Budget-conscious deployments
            - Most common scenario

        Returns:
            ImpactAnalysisConfig configured for cost optimization

        Example:
            >>> config = ImpactAnalysisConfig.for_cost_optimized()
            >>> config.similarity_method
            'jaccard'
            >>> config.enable_llm_evaluation
            True
        """
        return cls(
            token_overlap_threshold=0.3,
            similarity_method="jaccard",
            min_token_overlap_count=2,
            enable_llm_evaluation=True,
            llm_timeout_seconds=30,
            max_concurrent_evaluations=5,
        )

    def to_dict(self) -> dict:
        """
        Convert configuration to dictionary.

        Returns:
            Dictionary representation of configuration

        Example:
            >>> config = ImpactAnalysisConfig()
            >>> config.to_dict()
            {
                'token_overlap_threshold': 0.3,
                'similarity_method': 'jaccard',
                'min_token_overlap_count': 2,
                'enable_llm_evaluation': True,
                'llm_timeout_seconds': 30,
                'max_concurrent_evaluations': 5
            }
        """
        return {
            "token_overlap_threshold": self.token_overlap_threshold,
            "similarity_method": self.similarity_method,
            "min_token_overlap_count": self.min_token_overlap_count,
            "enable_llm_evaluation": self.enable_llm_evaluation,
            "llm_timeout_seconds": self.llm_timeout_seconds,
            "max_concurrent_evaluations": self.max_concurrent_evaluations,
        }

    def __repr__(self) -> str:
        """
        Return detailed string representation of configuration.

        Returns:
            String representation suitable for debugging

        Example:
            >>> config = ImpactAnalysisConfig()
            >>> repr(config)
            'ImpactAnalysisConfig(token_overlap_threshold=0.3, ...)'
        """
        return (
            f"ImpactAnalysisConfig("
            f"token_overlap_threshold={self.token_overlap_threshold}, "
            f"similarity_method='{self.similarity_method}', "
            f"min_token_overlap_count={self.min_token_overlap_count}, "
            f"enable_llm_evaluation={self.enable_llm_evaluation}, "
            f"llm_timeout_seconds={self.llm_timeout_seconds}, "
            f"max_concurrent_evaluations={self.max_concurrent_evaluations})"
        )


__all__ = ["ImpactAnalysisConfig"]
