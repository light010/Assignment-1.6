"""
Configuration Module - Impact Analysis Settings

This module provides configuration classes for FAQ impact analysis.
Configurations control behavior of analysis and execution phases.

Configuration Classes:

1. ImpactAnalysisConfig
   Purpose: Configure analysis behavior
   Settings:
   - token_overlap_threshold: Minimum token overlap for change detection
   - similarity_method: Method for calculating similarity (jaccard, hybrid, etc.)
   - min_token_overlap_count: Minimum overlapping tokens required
   - enable_llm_evaluation: Whether to use LLM for semantic evaluation
   - llm_timeout_seconds: Timeout for LLM API calls
   - max_concurrent_evaluations: Max concurrent LLM evaluations

   Factory Methods:
   - from_env(): Load from environment variables
   - for_cost_optimized(): Production-ready balanced configuration
   - for_aggressive_regeneration(): Maximum accuracy configuration
   - for_conservative_regeneration(): Minimize regeneration configuration

Configuration Sources:
    1. Environment Variables (highest priority)
       - IMPACT_TOKEN_OVERLAP_THRESHOLD=0.3
       - IMPACT_SIMILARITY_METHOD=jaccard
       - IMPACT_MIN_TOKEN_OVERLAP=2
       - IMPACT_ENABLE_LLM_EVAL=true
       - IMPACT_LLM_TIMEOUT=30
       - IMPACT_MAX_CONCURRENT_EVAL=5

    2. Factory Methods (medium priority)
       - ImpactAnalysisConfig.for_cost_optimized()
       - ImpactAnalysisConfig.for_aggressive_regeneration()
       - ImpactAnalysisConfig.for_conservative_regeneration()

    3. Default Values (lowest priority)
       - Defined in ImpactAnalysisConfig dataclass

Loading Configurations:
    >>> from faq_impact.config import ImpactAnalysisConfig
    >>>
    >>> # Load from environment and defaults
    >>> config = ImpactAnalysisConfig.from_env()
    >>>
    >>> # Use factory preset
    >>> config = ImpactAnalysisConfig.for_cost_optimized()
    >>>
    >>> # Manual construction
    >>> config = ImpactAnalysisConfig(
    ...     token_overlap_threshold=0.4,
    ...     enable_llm_evaluation=True
    ... )

Validation:
    Configurations validate themselves:
    - Type checking (int, bool, float, str)
    - Range validation (thresholds 0.0-1.0, positive integers)
    - Dependency validation (LLM config if evaluation enabled)

Constants:
    Impact-specific constants for analysis behavior:
    - DEFAULT_TOKEN_OVERLAP_THRESHOLD = 0.3
    - DEFAULT_JACCARD_SIMILARITY = 0.3
    - MIN_VALID_SOURCES_THRESHOLD = 1
    - MAX_DETAILS_JSON_SIZE = 10000
    - BATCH_SIZE_IMPACT_APPLICATION = 100

Cost Estimates:
    Utilities for estimating LLM costs:
    - COST_PER_QUESTION_GENERATION = $0.0168
    - COST_PER_ANSWER_GENERATION = $0.0364
    - COST_PER_LLM_EVALUATION = $0.0252
    - estimate_analysis_cost(): Calculate total cost

Validation Utilities:
    - validate_llm_config_if_enabled(): Check LLM availability
    - validate_config_combinations(): Check logical consistency
    - validate_full_configuration(): Comprehensive validation
    - suggest_config_improvements(): Get optimization suggestions

Example:
    >>> from faq_impact.config import ImpactAnalysisConfig
    >>> from faq_impact.config import estimate_analysis_cost
    >>> from faq_impact.config import validate_full_configuration
    >>>
    >>> # Load configuration
    >>> config = ImpactAnalysisConfig.for_cost_optimized()
    >>>
    >>> # Validate configuration
    >>> report = validate_full_configuration(config)
    >>> if report['errors']:
    ...     print("Errors:", report['errors'])
    >>>
    >>> # Estimate costs
    >>> estimate = estimate_analysis_cost(num_new_chunks=100)
    >>> print(f"Estimated cost: ${estimate.total_cost:.2f}")

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Configuration Classes
from .impact_config import ImpactAnalysisConfig

# Constants
from .constants import (
    # Similarity and Token Overlap
    DEFAULT_TOKEN_OVERLAP_THRESHOLD,
    DEFAULT_JACCARD_SIMILARITY,
    MIN_TOKEN_OVERLAP_COUNT,

    # Validation Thresholds
    MIN_VALID_SOURCES_THRESHOLD,

    # Resource Limits
    MAX_DETAILS_JSON_SIZE,
    MAX_CONCURRENT_LLM_EVALUATIONS,
    LLM_EVALUATION_TIMEOUT_SECONDS,

    # Batch Processing
    BATCH_SIZE_IMPACT_APPLICATION,
    BATCH_SIZE_TOKEN_OVERLAP,
    BATCH_SIZE_LLM_EVALUATION,

    # Decision Metadata
    DECISION_REASON_MAX_LENGTH,
    MAX_REASON_CODES_PER_DECISION,

    # Performance Tuning
    ENABLE_CHUNK_QUESTION_CACHE,
    CACHE_TTL_SECONDS,

    # Logging and Debugging
    LOG_DETAILED_DECISIONS,
    INCLUDE_FULL_DIFF_IN_DETAILS,

    # Validation
    validate_constants,
)

# Cost Estimates
from .cost_estimates import (
    # Token Usage Estimates
    COST_PER_QUESTION_GENERATION_TOKENS,
    COST_PER_ANSWER_GENERATION_TOKENS,
    COST_PER_LLM_EVALUATION_TOKENS,

    # Model Pricing
    GPT4_TURBO_COST_PER_1K_TOKENS,
    GPT4O_COST_PER_1K_TOKENS,
    GPT35_TURBO_COST_PER_1K_TOKENS,
    DEFAULT_MODEL_COST_PER_1K_TOKENS,

    # Operation Costs
    COST_PER_QUESTION_GENERATION,
    COST_PER_ANSWER_GENERATION,
    COST_PER_LLM_EVALUATION,

    # Batch Costs
    COST_PER_100_NEW_CHUNKS,
    COST_PER_100_MODIFIED_CHUNKS,

    # Utilities
    CostEstimate,
    estimate_analysis_cost,
    estimate_cost_for_model,
)

# Validation Utilities
from .validators import (
    ConfigurationWarning,
    ConfigurationError,
    validate_llm_config_if_enabled,
    validate_config_combinations,
    suggest_config_improvements,
    validate_resource_limits,
    validate_full_configuration,
    print_validation_report,
)

__all__ = [
    # Configuration Classes
    "ImpactAnalysisConfig",

    # Constants - Similarity and Token Overlap
    "DEFAULT_TOKEN_OVERLAP_THRESHOLD",
    "DEFAULT_JACCARD_SIMILARITY",
    "MIN_TOKEN_OVERLAP_COUNT",

    # Constants - Validation Thresholds
    "MIN_VALID_SOURCES_THRESHOLD",

    # Constants - Resource Limits
    "MAX_DETAILS_JSON_SIZE",
    "MAX_CONCURRENT_LLM_EVALUATIONS",
    "LLM_EVALUATION_TIMEOUT_SECONDS",

    # Constants - Batch Processing
    "BATCH_SIZE_IMPACT_APPLICATION",
    "BATCH_SIZE_TOKEN_OVERLAP",
    "BATCH_SIZE_LLM_EVALUATION",

    # Constants - Decision Metadata
    "DECISION_REASON_MAX_LENGTH",
    "MAX_REASON_CODES_PER_DECISION",

    # Constants - Performance Tuning
    "ENABLE_CHUNK_QUESTION_CACHE",
    "CACHE_TTL_SECONDS",

    # Constants - Logging and Debugging
    "LOG_DETAILED_DECISIONS",
    "INCLUDE_FULL_DIFF_IN_DETAILS",

    # Constants - Validation
    "validate_constants",

    # Cost Estimates - Token Usage
    "COST_PER_QUESTION_GENERATION_TOKENS",
    "COST_PER_ANSWER_GENERATION_TOKENS",
    "COST_PER_LLM_EVALUATION_TOKENS",

    # Cost Estimates - Model Pricing
    "GPT4_TURBO_COST_PER_1K_TOKENS",
    "GPT4O_COST_PER_1K_TOKENS",
    "GPT35_TURBO_COST_PER_1K_TOKENS",
    "DEFAULT_MODEL_COST_PER_1K_TOKENS",

    # Cost Estimates - Operation Costs
    "COST_PER_QUESTION_GENERATION",
    "COST_PER_ANSWER_GENERATION",
    "COST_PER_LLM_EVALUATION",

    # Cost Estimates - Batch Costs
    "COST_PER_100_NEW_CHUNKS",
    "COST_PER_100_MODIFIED_CHUNKS",

    # Cost Estimates - Utilities
    "CostEstimate",
    "estimate_analysis_cost",
    "estimate_cost_for_model",

    # Validation Utilities
    "ConfigurationWarning",
    "ConfigurationError",
    "validate_llm_config_if_enabled",
    "validate_config_combinations",
    "suggest_config_improvements",
    "validate_resource_limits",
    "validate_full_configuration",
    "print_validation_report",
]
