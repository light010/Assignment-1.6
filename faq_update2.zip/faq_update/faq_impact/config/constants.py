"""
Impact Analysis Constants

This module defines constants specific to FAQ impact analysis and regeneration.
These constants control analysis behavior, performance tuning, and resource limits.

Constants are organized into categories:
1. Similarity and Token Overlap - Thresholds for change detection
2. Validation Thresholds - Minimum requirements for valid data
3. Resource Limits - Performance and safety constraints
4. Batch Processing - Concurrency and batch size settings

DO NOT modify these values unless you understand the full impact on analysis behavior.

Author: Analytics Assist Team
Date: 2025-11-02
"""

# =============================================================================
# SIMILARITY AND TOKEN OVERLAP THRESHOLDS
# =============================================================================

# Default threshold for token overlap (Jaccard similarity)
# Used when token overlap ratio falls below this value → triggers regeneration
# Range: 0.0 (no overlap) to 1.0 (identical tokens)
#
# Rationale: 0.3 means if >70% of tokens changed, regenerate
# - Conservative: Catches most meaningful content changes
# - Avoids: False positives from minor wording tweaks
# - Based on: Empirical testing with FAQ content
DEFAULT_TOKEN_OVERLAP_THRESHOLD = 0.3

# Default threshold for Jaccard similarity (same as token overlap)
# Separate constant for clarity when explicitly using Jaccard method
# Used in: Modified content analysis, early filtering
#
# Rationale: Same as DEFAULT_TOKEN_OVERLAP_THRESHOLD for consistency
# - Jaccard = |A ∩ B| / |A ∪ B| where A, B are token sets
# - 0.3 means 30% of combined tokens are shared
DEFAULT_JACCARD_SIMILARITY = 0.3


# =============================================================================
# VALIDATION THRESHOLDS
# =============================================================================

# Minimum number of valid source chunks required for question to be considered valid
# Used in: Sole source detection, multi-source validation
#
# Rationale: 1 means at least one source must be valid
# - Questions with 0 valid sources → marked for deletion
# - Questions with >= 1 valid sources → kept (possibly regenerated)
# - Critical for: Orphan detection, cleanup decisions
MIN_VALID_SOURCES_THRESHOLD = 1

# Minimum number of overlapping tokens required to consider content related
# Used in: Token overlap analysis, false positive prevention
#
# Rationale: 2 tokens minimum prevents spurious matches
# - Example: "the" overlaps everywhere but meaningless
# - Example: "credit limit" = 2 tokens → meaningful match
# - Prevents: Tiny chunks from triggering false positives
MIN_TOKEN_OVERLAP_COUNT = 2


# =============================================================================
# RESOURCE LIMITS
# =============================================================================

# Maximum size (in characters) for faq_impact.details JSON column
# Used in: Decision detail storage, JSON validation
#
# Rationale: 10,000 characters sufficient for most decision metadata
# - Typical details: ~500-2000 chars (tokens, reasons, metadata)
# - Max details: ~10,000 chars (large diffs, multiple reasons)
# - Database: TEXT column typically supports 64KB
# - Safety: Prevents accidental storage of huge diffs
MAX_DETAILS_JSON_SIZE = 10000

# Maximum number of LLM evaluations to run concurrently
# Used in: LLM evaluation service, rate limiting
#
# Rationale: 5 concurrent requests balances throughput vs rate limits
# - Azure OpenAI: Typically allows 10-100 requests/min
# - Cost control: Limits concurrent API spend
# - Latency: 5 concurrent = good parallelism without overwhelming
# - Adjustable: Can increase for higher-tier API plans
MAX_CONCURRENT_LLM_EVALUATIONS = 5

# Timeout for individual LLM evaluation API calls (seconds)
# Used in: LLM client, timeout handling
#
# Rationale: 30 seconds prevents hanging on slow API responses
# - Typical response: 2-10 seconds for evaluation
# - Slow response: 10-20 seconds during high load
# - Timeout: 30 seconds allows slow but reasonable responses
# - Prevents: Indefinite hangs on API failures
LLM_EVALUATION_TIMEOUT_SECONDS = 30


# =============================================================================
# BATCH PROCESSING
# =============================================================================

# Batch size for processing impact decisions during application phase
# Used in: Impact applicator, batch updates
#
# Rationale: 100 decisions per batch optimal for database performance
# - Too small (e.g., 10): Many round trips, slow
# - Too large (e.g., 1000): Memory pressure, long transactions
# - Sweet spot: 100 balances throughput, memory, transaction time
# - Database: Most databases handle 100-row inserts efficiently
BATCH_SIZE_IMPACT_APPLICATION = 100

# Batch size for token overlap analysis
# Used in: Token matcher, bulk similarity calculations
#
# Rationale: 50 comparisons per batch optimal for in-memory analysis
# - Token overlap: Fast operation (set intersection)
# - Memory: 50 pairs = manageable memory footprint
# - CPU: Good utilization without cache thrashing
BATCH_SIZE_TOKEN_OVERLAP = 50

# Batch size for LLM evaluations (smaller due to cost/latency)
# Used in: LLM evaluator, API call batching
#
# Rationale: 10 evaluations per batch for cost control
# - LLM calls: Expensive ($0.01-$0.10 per evaluation)
# - Latency: Each call takes 2-10 seconds
# - Batch of 10: ~20-100 seconds total (with concurrency)
# - Cost visibility: Smaller batches easier to monitor
BATCH_SIZE_LLM_EVALUATION = 10


# =============================================================================
# DECISION METADATA
# =============================================================================

# Maximum length for decision reason text
# Used in: ImpactDecision.reason validation
#
# Rationale: 500 characters sufficient for human-readable reason
# - Typical reason: "Token overlap 0.25 below threshold 0.3"
# - Max reason: Multi-line explanation with context
# - Database: VARCHAR(500) or TEXT
DECISION_REASON_MAX_LENGTH = 500

# Maximum number of reason codes per decision
# Used in: ReasonCode validation, details JSON
#
# Rationale: 5 reason codes cover most complex scenarios
# - Typical: 1-2 reason codes (e.g., SOLE_SOURCE, ALL_SOURCES_DELETED)
# - Complex: 3-4 reason codes (e.g., multiple regeneration triggers)
# - Limit: Prevents excessive complexity in decision logic
MAX_REASON_CODES_PER_DECISION = 5


# =============================================================================
# PERFORMANCE TUNING
# =============================================================================

# Enable caching of chunk-to-question mappings
# Used in: Impact analyzer, performance optimization
#
# Rationale: Caching dramatically improves performance for large analyses
# - Without cache: Query database for every chunk's questions
# - With cache: Load all mappings once, lookup in memory
# - Trade-off: Memory usage vs query count
# - Recommended: True for batch analysis, False for real-time
ENABLE_CHUNK_QUESTION_CACHE = True

# Cache TTL (time-to-live) in seconds
# Used in: Cache invalidation, stale data prevention
#
# Rationale: 300 seconds (5 minutes) balances freshness vs performance
# - Analysis typically completes in < 5 minutes
# - Prevents: Stale cache if database updated during analysis
# - Production: May increase to 15-30 minutes for stable content
CACHE_TTL_SECONDS = 300


# =============================================================================
# LOGGING AND DEBUGGING
# =============================================================================

# Log detailed analysis decisions (verbose mode)
# Used in: Impact analyzer, debugging
#
# Rationale: False by default to reduce log noise
# - Production: False (logs only summaries)
# - Development: True (logs every decision with reasoning)
# - Performance: Minimal impact (just logging)
LOG_DETAILED_DECISIONS = False

# Include full diff in decision details JSON
# Used in: Modified content strategy, details generation
#
# Rationale: False by default to save space
# - Full diff: Can be 1000+ characters for large changes
# - Summary: Sufficient for most use cases (changed tokens count)
# - Enable: When debugging regeneration decisions
INCLUDE_FULL_DIFF_IN_DETAILS = False


# =============================================================================
# VALIDATION
# =============================================================================

def validate_constants():
    """
    Validate that all constants are correctly configured.

    This function checks that all constant values are within valid ranges
    and logically consistent. It runs automatically on module import.

    Raises:
        ValueError: If any constant is invalid or inconsistent

    Example:
        >>> from faq_impact.config.constants import validate_constants
        >>> validate_constants()  # Raises ValueError if invalid
    """
    # Validate thresholds (must be in range 0.0-1.0)
    thresholds = {
        "DEFAULT_TOKEN_OVERLAP_THRESHOLD": DEFAULT_TOKEN_OVERLAP_THRESHOLD,
        "DEFAULT_JACCARD_SIMILARITY": DEFAULT_JACCARD_SIMILARITY,
    }
    for name, value in thresholds.items():
        if not isinstance(value, (int, float)):
            raise ValueError(f"{name} must be a number, got {type(value).__name__}")
        if not (0.0 <= value <= 1.0):
            raise ValueError(f"{name} must be between 0.0 and 1.0, got {value}")

    # Validate positive integers
    positive_ints = {
        "MIN_VALID_SOURCES_THRESHOLD": MIN_VALID_SOURCES_THRESHOLD,
        "MIN_TOKEN_OVERLAP_COUNT": MIN_TOKEN_OVERLAP_COUNT,
        "MAX_DETAILS_JSON_SIZE": MAX_DETAILS_JSON_SIZE,
        "MAX_CONCURRENT_LLM_EVALUATIONS": MAX_CONCURRENT_LLM_EVALUATIONS,
        "LLM_EVALUATION_TIMEOUT_SECONDS": LLM_EVALUATION_TIMEOUT_SECONDS,
        "BATCH_SIZE_IMPACT_APPLICATION": BATCH_SIZE_IMPACT_APPLICATION,
        "BATCH_SIZE_TOKEN_OVERLAP": BATCH_SIZE_TOKEN_OVERLAP,
        "BATCH_SIZE_LLM_EVALUATION": BATCH_SIZE_LLM_EVALUATION,
        "DECISION_REASON_MAX_LENGTH": DECISION_REASON_MAX_LENGTH,
        "MAX_REASON_CODES_PER_DECISION": MAX_REASON_CODES_PER_DECISION,
        "CACHE_TTL_SECONDS": CACHE_TTL_SECONDS,
    }
    for name, value in positive_ints.items():
        if not isinstance(value, int):
            raise ValueError(f"{name} must be an integer, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"{name} must be positive, got {value}")

    # Validate booleans
    booleans = {
        "ENABLE_CHUNK_QUESTION_CACHE": ENABLE_CHUNK_QUESTION_CACHE,
        "LOG_DETAILED_DECISIONS": LOG_DETAILED_DECISIONS,
        "INCLUDE_FULL_DIFF_IN_DETAILS": INCLUDE_FULL_DIFF_IN_DETAILS,
    }
    for name, value in booleans.items():
        if not isinstance(value, bool):
            raise ValueError(f"{name} must be a boolean, got {type(value).__name__}")

    # Validate logical consistency
    if MIN_TOKEN_OVERLAP_COUNT < 0:
        raise ValueError(
            f"MIN_TOKEN_OVERLAP_COUNT cannot be negative, got {MIN_TOKEN_OVERLAP_COUNT}"
        )

    if BATCH_SIZE_LLM_EVALUATION > MAX_CONCURRENT_LLM_EVALUATIONS * 10:
        raise ValueError(
            f"BATCH_SIZE_LLM_EVALUATION ({BATCH_SIZE_LLM_EVALUATION}) should not be "
            f"much larger than MAX_CONCURRENT_LLM_EVALUATIONS "
            f"({MAX_CONCURRENT_LLM_EVALUATIONS}) to avoid excessive batching"
        )


# Run validation on import
validate_constants()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Similarity and Token Overlap
    "DEFAULT_TOKEN_OVERLAP_THRESHOLD",
    "DEFAULT_JACCARD_SIMILARITY",

    # Validation Thresholds
    "MIN_VALID_SOURCES_THRESHOLD",
    "MIN_TOKEN_OVERLAP_COUNT",

    # Resource Limits
    "MAX_DETAILS_JSON_SIZE",
    "MAX_CONCURRENT_LLM_EVALUATIONS",
    "LLM_EVALUATION_TIMEOUT_SECONDS",

    # Batch Processing
    "BATCH_SIZE_IMPACT_APPLICATION",
    "BATCH_SIZE_TOKEN_OVERLAP",
    "BATCH_SIZE_LLM_EVALUATION",

    # Decision Metadata
    "DECISION_REASON_MAX_LENGTH",
    "MAX_REASON_CODES_PER_DECISION",

    # Performance Tuning
    "ENABLE_CHUNK_QUESTION_CACHE",
    "CACHE_TTL_SECONDS",

    # Logging and Debugging
    "LOG_DETAILED_DECISIONS",
    "INCLUDE_FULL_DIFF_IN_DETAILS",

    # Validation
    "validate_constants",
]
