# FAQ Impact Analysis Configuration Guide

**Version**: 1.0.0
**Date**: 2025-11-02
**Module**: `faq_impact.config`

---

## Table of Contents

1. [Overview](#overview)
2. [Configuration Classes](#configuration-classes)
3. [Configuration Options](#configuration-options)
4. [Factory Methods](#factory-methods)
5. [Environment Variables](#environment-variables)
6. [Constants Reference](#constants-reference)
7. [Cost Estimates](#cost-estimates)
8. [Validation](#validation)
9. [Performance Implications](#performance-implications)
10. [Examples](#examples)

---

## Overview

The FAQ Impact Analysis system uses configuration to control:

- **Similarity Detection**: How changes are detected (token overlap, thresholds)
- **LLM Evaluation**: When and how LLMs are used for decision-making
- **Resource Limits**: Concurrency, timeouts, batch sizes
- **Cost Optimization**: Balancing accuracy vs API costs

### Configuration Philosophy

- **Sensible Defaults**: Works out-of-the-box for most FAQ content
- **Environment Overrides**: All settings configurable via environment variables
- **Factory Presets**: Common configurations available as factory methods
- **Validation**: Automatic validation with helpful error messages

---

## Configuration Classes

### ImpactAnalysisConfig

Main configuration class for impact analysis behavior.

**Location**: `faq_impact.config.impact_config`

**Purpose**: Controls how impact analysis detects changes and makes regeneration decisions.

**Usage**:
```python
from faq_impact.config import ImpactAnalysisConfig

# Use defaults
config = ImpactAnalysisConfig()

# Customize
config = ImpactAnalysisConfig(
    token_overlap_threshold=0.4,
    enable_llm_evaluation=False
)

# Load from environment
config = ImpactAnalysisConfig.from_env()

# Use factory preset
config = ImpactAnalysisConfig.for_cost_optimized()
```

---

## Configuration Options

### token_overlap_threshold

**Type**: `float`
**Range**: 0.0 - 1.0
**Default**: 0.3

**Description**: Minimum token overlap ratio (Jaccard similarity) required to skip regeneration.

**Interpretation**:
- **0.3 (default)**: Regenerate if >70% of tokens changed (aggressive)
- **0.5**: Regenerate if >50% of tokens changed (balanced)
- **0.7**: Regenerate if >30% of tokens changed (conservative)

**When to Change**:
- **Lower (0.1-0.2)**: For very stable content where only major changes matter
- **Higher (0.4-0.5)**: For content with frequent factual updates

**Performance Impact**: None (computation is fast)

**Example**:
```python
# Regenerate only for major changes (85%+ tokens changed)
config = ImpactAnalysisConfig(token_overlap_threshold=0.15)
```

---

### similarity_method

**Type**: `str`
**Options**: `"jaccard"`, `"sequence"`, `"hybrid"`, `"semantic"`, `"bm25"`
**Default**: `"jaccard"`

**Description**: Method for calculating similarity between old and new content.

**Methods**:

| Method | Speed | Accuracy | Use Case |
|--------|-------|----------|----------|
| `jaccard` | Fast | Good | Factual changes (numbers, dates) |
| `sequence` | Medium | Better | Rephrasing, reordering |
| `hybrid` | Slow | Best | Comprehensive detection |
| `semantic` | Slowest | Best | Meaning-based similarity (requires LLM) |
| `bm25` | Medium | Good | Document-level similarity |

**Performance Impact**:
- `jaccard`: O(n), very fast
- `sequence`: O(n*m), 2-5x slower than jaccard
- `hybrid`: Combines both, 3-7x slower than jaccard
- `semantic`: Requires API calls, 100x+ slower

**Example**:
```python
# Use hybrid for comprehensive change detection
config = ImpactAnalysisConfig(similarity_method="hybrid")

# Use jaccard for speed on large datasets
config = ImpactAnalysisConfig(similarity_method="jaccard")
```

---

### min_token_overlap_count

**Type**: `int`
**Range**: >= 0
**Default**: 2

**Description**: Minimum number of overlapping tokens required to consider content related.

**Purpose**: Prevents false positives from common words (e.g., "the", "a", "is")

**When to Change**:
- **Lower (1)**: For very short content chunks
- **Higher (3-5)**: To reduce noise from minor overlaps

**Example**:
```python
# Require at least 3 meaningful overlapping tokens
config = ImpactAnalysisConfig(min_token_overlap_count=3)
```

---

### enable_llm_evaluation

**Type**: `bool`
**Default**: `True`

**Description**: Whether to use LLM for semantic evaluation of changes.

**Impact**:
- **True**: More accurate decisions, higher cost (~$0.025 per evaluation)
- **False**: Rule-based only, free, may miss semantic changes

**When to Disable**:
- Cost-sensitive environments
- Very large datasets (1000+ chunks)
- Content with clear factual changes (no ambiguity)

**When to Enable**:
- Critical content (legal, medical, financial)
- Content with subtle semantic changes
- First-time migration (validate behavior)

**Example**:
```python
# Disable LLM for cost savings
config = ImpactAnalysisConfig(enable_llm_evaluation=False)
```

---

### llm_timeout_seconds

**Type**: `int`
**Range**: > 0
**Default**: 30

**Description**: Maximum time to wait for LLM API responses.

**Typical Response Times**:
- Normal: 2-10 seconds
- High load: 10-20 seconds
- Timeout: 30+ seconds

**When to Change**:
- **Lower (20)**: Fast-fail for performance testing
- **Higher (45-60)**: During API high-load periods

**Example**:
```python
# Use shorter timeout for faster failure detection
config = ImpactAnalysisConfig(llm_timeout_seconds=20)
```

---

### max_concurrent_evaluations

**Type**: `int`
**Range**: > 0
**Default**: 5

**Description**: Maximum number of concurrent LLM API calls.

**Considerations**:
- **API Rate Limits**: Azure OpenAI typically allows 10-100 requests/min
- **Cost Control**: More concurrency = faster processing but higher cost
- **Latency**: Optimal at 5-10 for most deployments

**When to Change**:
- **Lower (2-3)**: Strict cost control, low rate limits
- **Higher (10-20)**: High-throughput processing, premium API tier

**Example**:
```python
# Higher concurrency for faster processing
config = ImpactAnalysisConfig(max_concurrent_evaluations=10)
```

---

## Factory Methods

### for_cost_optimized()

**Purpose**: Production-ready configuration balancing accuracy and cost.

**Configuration**:
```python
token_overlap_threshold = 0.3
similarity_method = "jaccard"
min_token_overlap_count = 2
enable_llm_evaluation = True
llm_timeout_seconds = 30
max_concurrent_evaluations = 5
```

**Use Cases**:
- Production FAQ systems
- Regular content updates
- Budget-conscious deployments

**Example**:
```python
config = ImpactAnalysisConfig.for_cost_optimized()
```

---

### for_aggressive_regeneration()

**Purpose**: Maximum accuracy, regenerates even for small changes.

**Configuration**:
```python
token_overlap_threshold = 0.5
similarity_method = "hybrid"
min_token_overlap_count = 1
enable_llm_evaluation = True
llm_timeout_seconds = 45
max_concurrent_evaluations = 10
```

**Use Cases**:
- Critical content (legal, medical, financial)
- First-time migration validation
- Content with frequent factual updates

**Example**:
```python
config = ImpactAnalysisConfig.for_aggressive_regeneration()
```

---

### for_conservative_regeneration()

**Purpose**: Minimize regeneration, only for major changes.

**Configuration**:
```python
token_overlap_threshold = 0.15
similarity_method = "jaccard"
min_token_overlap_count = 3
enable_llm_evaluation = False
llm_timeout_seconds = 20
max_concurrent_evaluations = 3
```

**Use Cases**:
- Stable content with rare updates
- Cost-sensitive environments
- Content with minor wording changes

**Example**:
```python
config = ImpactAnalysisConfig.for_conservative_regeneration()
```

---

## Environment Variables

All configuration options support environment variable overrides:

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `IMPACT_TOKEN_OVERLAP_THRESHOLD` | float | 0.3 | Token overlap threshold |
| `IMPACT_SIMILARITY_METHOD` | str | jaccard | Similarity calculation method |
| `IMPACT_MIN_TOKEN_OVERLAP` | int | 2 | Minimum token overlap count |
| `IMPACT_ENABLE_LLM_EVAL` | bool | true | Enable LLM evaluation |
| `IMPACT_LLM_TIMEOUT` | int | 30 | LLM timeout in seconds |
| `IMPACT_MAX_CONCURRENT_EVAL` | int | 5 | Max concurrent LLM calls |

**Example**:
```bash
# Set environment variables
export IMPACT_TOKEN_OVERLAP_THRESHOLD=0.4
export IMPACT_ENABLE_LLM_EVAL=false

# Load from environment
config = ImpactAnalysisConfig.from_env()
```

---

## Constants Reference

### Similarity Thresholds

```python
from faq_impact.config.constants import (
    DEFAULT_TOKEN_OVERLAP_THRESHOLD,  # 0.3
    DEFAULT_JACCARD_SIMILARITY,       # 0.3
    MIN_TOKEN_OVERLAP_COUNT,          # 2
)
```

### Validation Thresholds

```python
from faq_impact.config.constants import (
    MIN_VALID_SOURCES_THRESHOLD,      # 1
)
```

### Resource Limits

```python
from faq_impact.config.constants import (
    MAX_DETAILS_JSON_SIZE,            # 10,000 chars
    MAX_CONCURRENT_LLM_EVALUATIONS,   # 5
    LLM_EVALUATION_TIMEOUT_SECONDS,   # 30
)
```

### Batch Processing

```python
from faq_impact.config.constants import (
    BATCH_SIZE_IMPACT_APPLICATION,    # 100
    BATCH_SIZE_TOKEN_OVERLAP,         # 50
    BATCH_SIZE_LLM_EVALUATION,        # 10
)
```

---

## Cost Estimates

### Token Usage

```python
from faq_impact.config.cost_estimates import (
    COST_PER_QUESTION_GENERATION_TOKENS,  # 1,200 tokens
    COST_PER_ANSWER_GENERATION_TOKENS,    # 2,600 tokens
    COST_PER_LLM_EVALUATION_TOKENS,       # 1,800 tokens
)
```

### USD Costs (GPT-4 Turbo)

```python
from faq_impact.config.cost_estimates import (
    COST_PER_QUESTION_GENERATION,     # $0.0168
    COST_PER_ANSWER_GENERATION,       # $0.0364
    COST_PER_LLM_EVALUATION,          # $0.0252
)
```

### Cost Estimation

```python
from faq_impact.config.cost_estimates import estimate_analysis_cost

# Estimate cost for 100 new chunks, 50 modified
estimate = estimate_analysis_cost(
    num_new_chunks=100,
    num_modified_chunks=50
)

print(estimate.format_summary())
# Output:
# Cost Estimate Summary:
# ----------------------
# Question Generation:   $5.04
# Answer Generation:     $16.38
# LLM Evaluation:        $3.78
# ----------------------
# Total Cost:            $25.20
```

---

## Validation

### Automatic Validation

All configurations validate themselves on creation:

```python
config = ImpactAnalysisConfig(token_overlap_threshold=1.5)
# Raises: ValueError: token_overlap_threshold must be between 0.0 and 1.0
```

### Manual Validation

```python
from faq_impact.config.validators import validate_full_configuration

config = ImpactAnalysisConfig()
report = validate_full_configuration(
    config,
    llm_client=my_llm_client,
    expected_questions=500
)

# Check results
if report['errors']:
    print("Configuration errors:", report['errors'])
if report['warnings']:
    print("Warnings:", report['warnings'])
if report['suggestions']:
    print("Suggestions:", report['suggestions'])
```

---

## Performance Implications

### Configuration Impact on Processing Time

| Setting | Impact | 100 Chunks | 1000 Chunks |
|---------|--------|------------|-------------|
| `similarity_method="jaccard"` | Fast | ~5 sec | ~50 sec |
| `similarity_method="hybrid"` | Medium | ~15 sec | ~150 sec |
| `enable_llm_evaluation=True` | Slow | ~2 min | ~20 min |
| `max_concurrent_evaluations=5` | Baseline | - | - |
| `max_concurrent_evaluations=10` | 2x faster | ~1 min | ~10 min |

**Notes**:
- Times assume 3 questions per chunk
- LLM evaluation dominates processing time
- Concurrency only affects LLM evaluation speed

### Memory Usage

| Configuration | Memory/Chunk | 1000 Chunks | 10000 Chunks |
|--------------|--------------|-------------|--------------|
| Minimal (jaccard, no LLM) | ~10 KB | ~10 MB | ~100 MB |
| Standard (jaccard, LLM) | ~15 KB | ~15 MB | ~150 MB |
| Comprehensive (hybrid, LLM) | ~20 KB | ~20 MB | ~200 MB |

---

## Examples

### Example 1: Production Configuration

```python
from faq_impact.config import ImpactAnalysisConfig

# Use cost-optimized preset
config = ImpactAnalysisConfig.for_cost_optimized()

# Override specific settings
config.max_concurrent_evaluations = 8  # Higher throughput
```

### Example 2: Development/Testing

```python
# Fast processing for development
config = ImpactAnalysisConfig(
    similarity_method="jaccard",
    enable_llm_evaluation=False,  # Skip LLM for speed
    token_overlap_threshold=0.3
)
```

### Example 3: Critical Content

```python
# Maximum accuracy for critical content
config = ImpactAnalysisConfig.for_aggressive_regeneration()

# Validate configuration
from faq_impact.config.validators import validate_full_configuration
report = validate_full_configuration(config, llm_client=my_client)
```

### Example 4: Cost-Sensitive Deployment

```python
# Minimize API costs
config = ImpactAnalysisConfig(
    enable_llm_evaluation=False,      # No LLM calls
    similarity_method="jaccard",      # Fast method
    token_overlap_threshold=0.15,     # Only major changes
    max_concurrent_evaluations=3      # Lower concurrency
)
```

### Example 5: Environment-Based Configuration

```python
import os

# Set environment variables in deployment
os.environ['IMPACT_TOKEN_OVERLAP_THRESHOLD'] = '0.4'
os.environ['IMPACT_SIMILARITY_METHOD'] = 'hybrid'
os.environ['IMPACT_ENABLE_LLM_EVAL'] = 'true'

# Load from environment
config = ImpactAnalysisConfig.from_env()
```

---

## Best Practices

1. **Start with Presets**: Use factory methods (`for_cost_optimized()`, etc.) as starting points
2. **Validate Early**: Run `validate_full_configuration()` before production deployment
3. **Monitor Costs**: Use `estimate_analysis_cost()` to predict costs before running analysis
4. **Environment Variables**: Use environment variables for deployment-specific settings
5. **Profile Performance**: Measure actual performance with your content before tuning
6. **Document Overrides**: Document any deviations from preset configurations

---

## Troubleshooting

### Issue: Too Many Regenerations

**Symptoms**: FAQs regenerating even for minor changes

**Solutions**:
- Lower `token_overlap_threshold` (e.g., 0.15)
- Use `for_conservative_regeneration()` preset
- Disable LLM evaluation if using rule-based decisions

### Issue: Missing Changes

**Symptoms**: FAQs not updating when content changes

**Solutions**:
- Raise `token_overlap_threshold` (e.g., 0.5)
- Use `similarity_method="hybrid"`
- Enable LLM evaluation

### Issue: High Costs

**Symptoms**: API costs higher than expected

**Solutions**:
- Disable `enable_llm_evaluation`
- Use `similarity_method="jaccard"` (no API calls)
- Lower `max_concurrent_evaluations`
- Process in smaller batches

### Issue: Slow Processing

**Symptoms**: Analysis taking too long

**Solutions**:
- Increase `max_concurrent_evaluations` (if API allows)
- Use `similarity_method="jaccard"` instead of `hybrid`
- Disable LLM evaluation for faster processing
- Process in parallel batches

---

## See Also

- [MIGRATION.md](MIGRATION.md) - Migration guide from existing config
- [validators.py](validators.py) - Configuration validation utilities
- [cost_estimates.py](cost_estimates.py) - Cost estimation utilities
- [IMPLEMENTATION_PLAN.md](../IMPLEMENTATION_PLAN.md) - Overall system design

---

**Last Updated**: 2025-11-02
**Maintainer**: Analytics Assist Team
