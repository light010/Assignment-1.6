# FAQ Impact Config Integration with Base Config

**Version**: 1.0.0
**Date**: 2025-11-02
**Purpose**: Document integration between `faq_impact.config` and `faq_update.config`

---

## Overview

The FAQ Impact Analysis configuration system extends the base `faq_update` configuration without conflicts. The two configuration systems are designed to coexist and complement each other.

### Configuration Hierarchy

```
faq_update/config/                    # Base configuration
├── constants.py                      # System-wide constants
│   ├── CHECKSUM_ALGORITHM
│   ├── DEFAULT_CHUNK_SIZE
│   ├── DEFAULT_SIMILARITY_THRESHOLD  # For change detection
│   └── ...
└── __init__.py

faq_update/faq_impact/config/         # Impact-specific configuration
├── impact_config.py                  # ImpactAnalysisConfig
│   ├── token_overlap_threshold       # For impact analysis
│   ├── similarity_method
│   └── ...
├── constants.py                      # Impact-specific constants
│   ├── DEFAULT_TOKEN_OVERLAP_THRESHOLD
│   ├── BATCH_SIZE_IMPACT_APPLICATION
│   └── ...
├── cost_estimates.py                 # Cost estimation utilities
├── validators.py                     # Configuration validation
└── __init__.py
```

---

## Key Differences

### Base Config (`faq_update.config`)

**Purpose**: System-wide constants for content processing pipeline

**Scope**:
- Chunking parameters (chunk size, overlap)
- Checksum algorithms
- Change detection thresholds
- Diff generation settings

**Usage**: Used by upstream systems (chunking, change detection, notebooks)

**Stability**: Very stable - changes affect entire pipeline

### Impact Config (`faq_impact.config`)

**Purpose**: Impact analysis and FAQ regeneration behavior

**Scope**:
- Impact detection thresholds
- LLM evaluation settings
- Batch processing sizes
- Cost estimates

**Usage**: Used by impact analysis module only

**Stability**: More flexible - changes isolated to impact analysis

---

## Shared Concepts

### Similarity Thresholds

The two config systems use similarity thresholds for different purposes:

| Constant | Module | Purpose | Default | Range |
|----------|--------|---------|---------|-------|
| `DEFAULT_SIMILARITY_THRESHOLD` | base | Change detection (MODIFIED vs NEW) | 0.8 | 0.0-1.0 |
| `DEFAULT_TOKEN_OVERLAP_THRESHOLD` | impact | Regeneration decision (keep vs regenerate) | 0.3 | 0.0-1.0 |

**Key Difference**: These thresholds measure different things!

- **Base Config (0.8)**: "Is new content similar enough to old content to be considered MODIFIED (not NEW)?"
  - High threshold (0.8) = stricter, more content classified as NEW
  - Used in: 7_change_detection_unified.ipynb

- **Impact Config (0.3)**: "Is token overlap high enough to skip regeneration?"
  - Low threshold (0.3) = more aggressive regeneration
  - Used in: Impact analysis strategies

**Example**:
```python
# Change detection (base config)
# Classifies change type: NEW vs MODIFIED vs DELETED
if difflib_similarity >= 0.8:  # DEFAULT_SIMILARITY_THRESHOLD
    change_type = "MODIFIED"
else:
    change_type = "NEW"

# Impact analysis (impact config)
# Decides regeneration for MODIFIED content
if token_overlap >= 0.3:  # DEFAULT_TOKEN_OVERLAP_THRESHOLD
    decision = "KEEP"  # Sufficient overlap
else:
    decision = "REGENERATE"  # Changed too much
```

---

## No Conflicts

### Name Conflicts: None

The two configuration systems use different constant names:

| Base Config | Impact Config | Notes |
|-------------|---------------|-------|
| `DEFAULT_SIMILARITY_THRESHOLD` | `DEFAULT_TOKEN_OVERLAP_THRESHOLD` | Different purposes |
| `CHECKSUM_ALGORITHM` | (not used) | Impact config uses base config checksums |
| `DEFAULT_CHUNK_SIZE` | (not used) | Impact config analyzes existing chunks |
| `validate_constants()` | `validate_constants()` | Same name, different modules (OK) |

### Import Conflicts: None

Imports are module-scoped:

```python
# Base config
from config.constants import DEFAULT_SIMILARITY_THRESHOLD

# Impact config
from faq_impact.config.constants import DEFAULT_TOKEN_OVERLAP_THRESHOLD

# No ambiguity - different modules, different names
```

---

## Integration Patterns

### Pattern 1: Impact Config Uses Base Config

Impact analysis depends on base config for fundamental constants:

```python
from config.constants import CHECKSUM_ALGORITHM, DEFAULT_CHUNK_SIZE
from faq_impact.config import ImpactAnalysisConfig

# Impact analysis uses base config for chunk identification
# but has its own thresholds for regeneration decisions
config = ImpactAnalysisConfig()
```

**Dependencies**:
- Impact analysis queries use checksums (from base config)
- Impact analysis operates on chunks (sized per base config)
- Impact analysis builds on change detection results (from base config)

### Pattern 2: Independent Configuration

Most impact config settings are independent:

```python
from faq_impact.config import ImpactAnalysisConfig

# These settings are impact-specific, don't affect base config
config = ImpactAnalysisConfig(
    token_overlap_threshold=0.4,      # Impact only
    enable_llm_evaluation=True,       # Impact only
    max_concurrent_evaluations=10     # Impact only
)
```

### Pattern 3: Complementary Use

Both configs work together in the full pipeline:

```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
from faq_impact.config import ImpactAnalysisConfig

# Step 1: Change detection (uses base config)
if similarity >= DEFAULT_SIMILARITY_THRESHOLD:
    change_type = "MODIFIED"

    # Step 2: Impact analysis (uses impact config)
    config = ImpactAnalysisConfig()
    decision = analyzer.analyze_modified_content(
        old_content=old,
        new_content=new,
        config=config
    )
```

---

## Configuration Precedence

### When Both Configs Apply

In rare cases where both configurations could apply, use this precedence:

1. **Base Config**: For pipeline-wide behavior
   - Chunk sizing
   - Checksum algorithms
   - Change type classification

2. **Impact Config**: For impact-specific behavior
   - Regeneration decisions
   - LLM evaluation
   - Batch processing

**Example**:
```python
# Use base config for change detection
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
change_detector = ContentChangeDetector(
    similarity_threshold=DEFAULT_SIMILARITY_THRESHOLD
)

# Use impact config for regeneration decisions
from faq_impact.config import ImpactAnalysisConfig
analyzer = ImpactAnalyzer(
    config=ImpactAnalysisConfig.for_cost_optimized()
)
```

---

## Environment Variables

### Base Config Environment Variables

```bash
# Not currently supported by base config
# Base config uses hardcoded constants
```

### Impact Config Environment Variables

```bash
# Impact config supports environment overrides
export IMPACT_TOKEN_OVERLAP_THRESHOLD=0.4
export IMPACT_SIMILARITY_METHOD=hybrid
export IMPACT_ENABLE_LLM_EVAL=true
export IMPACT_LLM_TIMEOUT=30
export IMPACT_MAX_CONCURRENT_EVAL=5
```

**No Conflicts**: Different prefixes (`IMPACT_*` vs none)

---

## Migration from Base Config

If you were previously using base config constants for impact decisions:

### Before (Incorrect)

```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD

# This was never correct - base config similarity is for change detection
if token_overlap >= DEFAULT_SIMILARITY_THRESHOLD:  # 0.8 - too high!
    decision = "KEEP"
```

### After (Correct)

```python
from faq_impact.config import DEFAULT_TOKEN_OVERLAP_THRESHOLD

# Use impact-specific threshold
if token_overlap >= DEFAULT_TOKEN_OVERLAP_THRESHOLD:  # 0.3 - appropriate
    decision = "KEEP"
```

---

## Compatibility Matrix

| Base Config Version | Impact Config Version | Compatible? | Notes |
|---------------------|----------------------|-------------|-------|
| 1.0.0 | 1.0.0 | ✅ Yes | Initial release |
| Future | Future | ✅ Yes | No breaking changes planned |

**Guarantee**: Impact config will always remain compatible with base config.

---

## Testing Configuration Integration

### Test Base Config

```python
from config.constants import validate_constants

# Validate base config
validate_constants()  # Should not raise
```

### Test Impact Config

```python
from faq_impact.config.constants import validate_constants

# Validate impact config
validate_constants()  # Should not raise
```

### Test Integration

```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
from faq_impact.config import DEFAULT_TOKEN_OVERLAP_THRESHOLD

# These should be different values for different purposes
assert DEFAULT_SIMILARITY_THRESHOLD != DEFAULT_TOKEN_OVERLAP_THRESHOLD
assert DEFAULT_SIMILARITY_THRESHOLD == 0.8
assert DEFAULT_TOKEN_OVERLAP_THRESHOLD == 0.3
```

---

## Common Pitfalls

### Pitfall 1: Using Wrong Threshold

❌ **Wrong**:
```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
# Using base config threshold for impact analysis
if token_overlap >= DEFAULT_SIMILARITY_THRESHOLD:  # 0.8 is too high!
    ...
```

✅ **Correct**:
```python
from faq_impact.config import DEFAULT_TOKEN_OVERLAP_THRESHOLD
if token_overlap >= DEFAULT_TOKEN_OVERLAP_THRESHOLD:  # 0.3 is appropriate
    ...
```

### Pitfall 2: Modifying Base Config for Impact

❌ **Wrong**:
```python
# Changing base config affects entire pipeline!
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
DEFAULT_SIMILARITY_THRESHOLD = 0.3  # Don't do this!
```

✅ **Correct**:
```python
# Use impact config instead
from faq_impact.config import ImpactAnalysisConfig
config = ImpactAnalysisConfig(token_overlap_threshold=0.3)
```

### Pitfall 3: Assuming Same Constants

❌ **Wrong**:
```python
# These are NOT the same!
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
from faq_impact.config import DEFAULT_TOKEN_OVERLAP_THRESHOLD
assert DEFAULT_SIMILARITY_THRESHOLD == DEFAULT_TOKEN_OVERLAP_THRESHOLD  # False!
```

✅ **Correct**:
```python
# Understand they serve different purposes
similarity_for_change_detection = 0.8
token_overlap_for_regeneration = 0.3
```

---

## Future Plans

### Base Config

- Remain stable
- No planned changes to existing constants
- New constants may be added for new features

### Impact Config

- Add more factory methods (e.g., `for_high_accuracy()`)
- Add more cost estimation utilities
- Add configuration profiles (dev, prod, test)
- Maintain backward compatibility

---

## Summary

### Key Takeaways

1. **No Conflicts**: Base and impact configs coexist cleanly
2. **Different Purposes**: Base = pipeline-wide, Impact = analysis-specific
3. **Complementary**: Work together in full FAQ generation pipeline
4. **Independent**: Can be configured separately
5. **Stable**: Both maintain backward compatibility

### When to Use Each

| Use Base Config For | Use Impact Config For |
|---------------------|----------------------|
| Chunk sizing | Regeneration decisions |
| Checksum algorithms | LLM evaluation settings |
| Change type classification | Token overlap thresholds |
| Diff generation | Batch processing sizes |
| Pipeline-wide settings | Impact analysis behavior |

---

**Last Updated**: 2025-11-02
**Maintainer**: Analytics Assist Team
