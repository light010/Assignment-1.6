# Configuration Migration Guide

**Version**: 1.0.0
**Date**: 2025-11-02
**Audience**: Developers migrating from change detection to impact analysis

---

## Overview

This guide helps you migrate from the existing change detection configuration to the new FAQ Impact Analysis configuration system.

### What's Changing?

- **Before**: Change detection used base config (`faq_update.config`) for all decisions
- **After**: Impact analysis uses dedicated config (`faq_impact.config`) for regeneration decisions
- **Result**: More flexible, purpose-built configuration for impact analysis

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Configuration Mapping](#configuration-mapping)
3. [Step-by-Step Migration](#step-by-step-migration)
4. [Before/After Examples](#beforeafter-examples)
5. [Common Migration Scenarios](#common-migration-scenarios)
6. [Troubleshooting](#troubleshooting)
7. [Validation](#validation)

---

## Quick Start

### Minimal Migration

If you were using default change detection settings:

```python
# Before: Implicit default behavior
# (no explicit configuration)

# After: Explicit configuration
from faq_impact.config import ImpactAnalysisConfig

config = ImpactAnalysisConfig()  # Uses sensible defaults
```

### Recommended Migration

For production systems:

```python
# After: Use cost-optimized preset
from faq_impact.config import ImpactAnalysisConfig

config = ImpactAnalysisConfig.for_cost_optimized()
```

---

## Configuration Mapping

### Change Detection → Impact Analysis

| Old Concept (Change Detection) | New Concept (Impact Analysis) | Notes |
|-------------------------------|------------------------------|-------|
| `DEFAULT_SIMILARITY_THRESHOLD=0.8` | `token_overlap_threshold=0.3` | Different purpose, different range |
| No explicit config | `ImpactAnalysisConfig` | Explicit configuration |
| Rule-based only | `enable_llm_evaluation=True` | Optional LLM enhancement |
| No cost tracking | `estimate_analysis_cost()` | Built-in cost estimation |
| No validation | `validate_full_configuration()` | Comprehensive validation |

### Constant Migration

| Old Constant (Base Config) | New Constant (Impact Config) | Changed? |
|---------------------------|------------------------------|----------|
| `DEFAULT_SIMILARITY_THRESHOLD` | `DEFAULT_TOKEN_OVERLAP_THRESHOLD` | ✅ Yes (0.8 → 0.3) |
| `CHECKSUM_ALGORITHM` | (reuse base config) | ❌ No |
| `DEFAULT_CHUNK_SIZE` | (reuse base config) | ❌ No |
| N/A | `MAX_CONCURRENT_LLM_EVALUATIONS` | ✅ New |
| N/A | `BATCH_SIZE_IMPACT_APPLICATION` | ✅ New |

---

## Step-by-Step Migration

### Step 1: Review Current Usage

Identify where you're using change detection constants:

```bash
# Search for base config imports
grep -r "from config.constants import" .
grep -r "DEFAULT_SIMILARITY_THRESHOLD" .
```

### Step 2: Install Impact Config

Impact config is already available:

```python
# Test import
from faq_impact.config import ImpactAnalysisConfig
print("Impact config available!")
```

### Step 3: Choose Configuration Strategy

Pick one of these approaches:

**Option A: Use Defaults** (recommended for most users)
```python
from faq_impact.config import ImpactAnalysisConfig
config = ImpactAnalysisConfig()
```

**Option B: Use Factory Preset** (recommended for production)
```python
from faq_impact.config import ImpactAnalysisConfig
config = ImpactAnalysisConfig.for_cost_optimized()
```

**Option C: Customize** (for specific requirements)
```python
from faq_impact.config import ImpactAnalysisConfig
config = ImpactAnalysisConfig(
    token_overlap_threshold=0.4,
    enable_llm_evaluation=True
)
```

**Option D: Environment Variables** (for deployment flexibility)
```bash
export IMPACT_TOKEN_OVERLAP_THRESHOLD=0.4
export IMPACT_ENABLE_LLM_EVAL=true
```
```python
from faq_impact.config import ImpactAnalysisConfig
config = ImpactAnalysisConfig.from_env()
```

### Step 4: Update Code

Replace change detection logic with impact analysis:

**Before**:
```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD

# Rule-based decision
if token_overlap >= DEFAULT_SIMILARITY_THRESHOLD:  # 0.8
    decision = "KEEP"
else:
    decision = "REGENERATE"
```

**After**:
```python
from faq_impact.config import ImpactAnalysisConfig

config = ImpactAnalysisConfig()
analyzer = ImpactAnalyzer(config=config)

# Configurable, optionally LLM-enhanced decision
decision = analyzer.analyze_modified_content(
    old_content=old,
    new_content=new
)
```

### Step 5: Validate Configuration

```python
from faq_impact.config import validate_full_configuration

config = ImpactAnalysisConfig()
report = validate_full_configuration(config)

if report['errors']:
    print("Configuration errors:", report['errors'])
    exit(1)

if report['warnings']:
    print("Warnings:", report['warnings'])

print("Configuration validated successfully!")
```

### Step 6: Test Migration

Run a small-scale test before full migration:

```python
# Test with small dataset
test_chunks = load_test_chunks(limit=10)
analyzer = ImpactAnalyzer(config=config)

for chunk in test_chunks:
    decision = analyzer.analyze_chunk(chunk)
    print(f"Chunk {chunk.id}: {decision.decision_type}")
```

### Step 7: Monitor and Tune

After migration, monitor and adjust:

```python
# Estimate costs
from faq_impact.config import estimate_analysis_cost

estimate = estimate_analysis_cost(num_new_chunks=1000)
print(f"Estimated cost: ${estimate.total_cost:.2f}")

# Get configuration suggestions
from faq_impact.config import suggest_config_improvements

suggestions = suggest_config_improvements(config)
for suggestion in suggestions:
    print(f"Suggestion: {suggestion}")
```

---

## Before/After Examples

### Example 1: Basic Change Detection → Impact Analysis

**Before** (Change Detection):
```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
import difflib

def should_regenerate(old_content, new_content):
    """Rule-based regeneration decision."""
    similarity = difflib.SequenceMatcher(
        None, old_content, new_content
    ).ratio()

    # Use change detection threshold
    return similarity < DEFAULT_SIMILARITY_THRESHOLD  # 0.8
```

**After** (Impact Analysis):
```python
from faq_impact.config import ImpactAnalysisConfig
from faq_impact.analysis import ImpactAnalyzer

def should_regenerate(old_content, new_content, backend):
    """Configurable, optionally LLM-enhanced decision."""
    config = ImpactAnalysisConfig.for_cost_optimized()
    analyzer = ImpactAnalyzer(backend=backend, config=config)

    decision = analyzer.analyze_modified_content(
        old_content=old_content,
        new_content=new_content
    )

    return decision.decision_type == DecisionType.REGENERATE
```

### Example 2: Batch Processing

**Before** (Manual Batching):
```python
from config.constants import DEFAULT_SIMILARITY_THRESHOLD

def process_changes(changes):
    """Process all changes with hardcoded settings."""
    decisions = []

    for change in changes:
        # Hardcoded threshold
        if change.similarity < DEFAULT_SIMILARITY_THRESHOLD:
            decisions.append("REGENERATE")
        else:
            decisions.append("KEEP")

    return decisions
```

**After** (Configured Batching):
```python
from faq_impact.config import ImpactAnalysisConfig, BATCH_SIZE_IMPACT_APPLICATION
from faq_impact.analysis import ImpactAnalyzer

def process_changes(changes, backend, config=None):
    """Process changes with configuration."""
    if config is None:
        config = ImpactAnalysisConfig.for_cost_optimized()

    analyzer = ImpactAnalyzer(backend=backend, config=config)

    # Batch processing with configured size
    batch_size = BATCH_SIZE_IMPACT_APPLICATION
    decisions = []

    for i in range(0, len(changes), batch_size):
        batch = changes[i:i+batch_size]
        batch_decisions = analyzer.analyze_changes(batch)
        decisions.extend(batch_decisions)

    return decisions
```

### Example 3: Cost Estimation

**Before** (No Cost Tracking):
```python
def regenerate_faqs(changes):
    """Regenerate FAQs without cost awareness."""
    # No way to estimate costs beforehand
    for change in changes:
        if should_regenerate(change):
            regenerate(change)
```

**After** (With Cost Estimation):
```python
from faq_impact.config import estimate_analysis_cost

def regenerate_faqs(changes, config):
    """Regenerate FAQs with cost estimation."""
    # Estimate costs before processing
    estimate = estimate_analysis_cost(
        num_modified_chunks=len(changes)
    )

    print(f"Estimated cost: ${estimate.total_cost:.2f}")
    print(estimate.format_summary())

    # User confirmation
    if estimate.total_cost > 10.0:
        confirm = input("Proceed with regeneration? (y/n): ")
        if confirm.lower() != 'y':
            return

    # Process with configuration
    analyzer = ImpactAnalyzer(backend=backend, config=config)
    decisions = analyzer.analyze_changes(changes)

    for decision in decisions:
        if decision.decision_type == DecisionType.REGENERATE:
            regenerate(decision)
```

---

## Common Migration Scenarios

### Scenario 1: Conservative User (Minimize Regeneration)

**Goal**: Only regenerate for major changes, minimize costs

**Before**:
```python
# Manually tune threshold higher
CUSTOM_THRESHOLD = 0.9  # Very high
```

**After**:
```python
from faq_impact.config import ImpactAnalysisConfig

# Use conservative preset
config = ImpactAnalysisConfig.for_conservative_regeneration()
# token_overlap_threshold=0.15 (regenerate only if >85% changed)
# enable_llm_evaluation=False (no LLM costs)
```

### Scenario 2: Aggressive User (Maximize Accuracy)

**Goal**: Regenerate even for small changes, use LLM for decisions

**Before**:
```python
# Manually tune threshold lower
CUSTOM_THRESHOLD = 0.5  # Lower
```

**After**:
```python
from faq_impact.config import ImpactAnalysisConfig

# Use aggressive preset
config = ImpactAnalysisConfig.for_aggressive_regeneration()
# token_overlap_threshold=0.5 (regenerate if >50% changed)
# enable_llm_evaluation=True (use LLM)
# similarity_method="hybrid" (comprehensive)
```

### Scenario 3: Production User (Balance Cost and Accuracy)

**Goal**: Good accuracy with reasonable costs

**Before**:
```python
# Use defaults
from config.constants import DEFAULT_SIMILARITY_THRESHOLD
```

**After**:
```python
from faq_impact.config import ImpactAnalysisConfig

# Use cost-optimized preset
config = ImpactAnalysisConfig.for_cost_optimized()
# token_overlap_threshold=0.3 (balanced)
# enable_llm_evaluation=True (smart decisions)
# similarity_method="jaccard" (fast)
```

### Scenario 4: Development User (Fast Iteration)

**Goal**: Fast processing for development/testing

**Before**:
```python
# Skip some processing for speed
```

**After**:
```python
from faq_impact.config import ImpactAnalysisConfig

# Fast configuration
config = ImpactAnalysisConfig(
    similarity_method="jaccard",      # Fastest
    enable_llm_evaluation=False,      # Skip LLM
    max_concurrent_evaluations=10     # More concurrency
)
```

---

## Troubleshooting

### Issue 1: Too Many Regenerations

**Symptoms**: FAQs regenerating more than before

**Cause**: Impact config default threshold (0.3) is lower than change detection (0.8)

**Solution**:
```python
# Use conservative preset or lower threshold
config = ImpactAnalysisConfig.for_conservative_regeneration()
# OR
config = ImpactAnalysisConfig(token_overlap_threshold=0.15)
```

### Issue 2: Missing Regenerations

**Symptoms**: FAQs not regenerating when they should

**Cause**: Threshold too high or LLM evaluation disabled

**Solution**:
```python
# Use aggressive preset or enable LLM
config = ImpactAnalysisConfig.for_aggressive_regeneration()
# OR
config = ImpactAnalysisConfig(
    token_overlap_threshold=0.5,
    enable_llm_evaluation=True
)
```

### Issue 3: High Costs

**Symptoms**: API costs higher than expected

**Cause**: LLM evaluation enabled for all decisions

**Solution**:
```python
# Disable LLM or use cheaper model
config = ImpactAnalysisConfig(enable_llm_evaluation=False)
# OR estimate costs first
from faq_impact.config import estimate_analysis_cost
estimate = estimate_analysis_cost(num_modified_chunks=len(changes))
print(f"Estimated cost: ${estimate.total_cost:.2f}")
```

### Issue 4: Slow Processing

**Symptoms**: Analysis taking longer than before

**Cause**: LLM evaluation adds latency

**Solution**:
```python
# Increase concurrency or disable LLM
config = ImpactAnalysisConfig(
    max_concurrent_evaluations=10,  # More parallelism
    enable_llm_evaluation=False     # OR disable LLM
)
```

---

## Validation

### Validate Migration Success

Run these checks after migration:

**1. Configuration Loads Successfully**
```python
from faq_impact.config import ImpactAnalysisConfig

config = ImpactAnalysisConfig()
print("✅ Configuration loaded")
```

**2. Validation Passes**
```python
from faq_impact.config import validate_full_configuration

report = validate_full_configuration(config)
assert len(report['errors']) == 0, "Configuration has errors"
print("✅ Configuration validated")
```

**3. Analyzer Initializes**
```python
from faq_impact.analysis import ImpactAnalyzer

analyzer = ImpactAnalyzer(backend=backend, config=config)
print("✅ Analyzer initialized")
```

**4. Sample Analysis Works**
```python
decision = analyzer.analyze_modified_content(
    old_content="Old FAQ answer",
    new_content="New FAQ answer"
)
print(f"✅ Sample analysis: {decision.decision_type}")
```

**5. Cost Estimation Works**
```python
from faq_impact.config import estimate_analysis_cost

estimate = estimate_analysis_cost(num_modified_chunks=10)
print(f"✅ Cost estimation: ${estimate.total_cost:.2f}")
```

---

## Migration Checklist

- [ ] Review current change detection usage
- [ ] Choose configuration strategy (default, preset, custom, env)
- [ ] Update imports (`config.constants` → `faq_impact.config`)
- [ ] Update threshold constants (0.8 → 0.3 or appropriate value)
- [ ] Add configuration initialization
- [ ] Replace rule-based logic with analyzer
- [ ] Add validation checks
- [ ] Test with small dataset
- [ ] Estimate costs for full dataset
- [ ] Monitor initial runs
- [ ] Tune configuration based on results
- [ ] Document configuration choices
- [ ] Update deployment scripts (if using env vars)

---

## Best Practices

1. **Start with Presets**: Use factory methods as starting points
2. **Validate Early**: Run validation before production deployment
3. **Estimate Costs**: Use cost estimation before large runs
4. **Monitor Results**: Track regeneration rates and adjust
5. **Document Choices**: Record why you chose specific settings
6. **Test Incrementally**: Migrate in stages, not all at once

---

## Getting Help

### Configuration Issues

```python
from faq_impact.config import suggest_config_improvements

config = ImpactAnalysisConfig()
suggestions = suggest_config_improvements(config)
for suggestion in suggestions:
    print(suggestion)
```

### Validation Issues

```python
from faq_impact.config import validate_full_configuration, print_validation_report

config = ImpactAnalysisConfig()
report = validate_full_configuration(config)
print_validation_report(report)
```

### Documentation

- [CONFIG.md](CONFIG.md) - Comprehensive configuration documentation
- [INTEGRATION.md](INTEGRATION.md) - Integration with base config
- [IMPLEMENTATION_PLAN.md](../IMPLEMENTATION_PLAN.md) - Overall system design

---

## Summary

### Key Migration Points

1. **New Configuration System**: Dedicated config for impact analysis
2. **Different Thresholds**: 0.3 vs 0.8 for different purposes
3. **Factory Presets**: Easy configuration for common scenarios
4. **Cost Awareness**: Built-in cost estimation
5. **Validation**: Comprehensive configuration validation

### Migration Difficulty

| Scenario | Difficulty | Time Estimate |
|----------|-----------|---------------|
| Using defaults | ✅ Easy | 5 minutes |
| Using presets | ✅ Easy | 10 minutes |
| Custom configuration | 🔶 Medium | 30 minutes |
| Complex tuning | 🔶 Medium | 1-2 hours |

---

**Last Updated**: 2025-11-02
**Maintainer**: Analytics Assist Team
