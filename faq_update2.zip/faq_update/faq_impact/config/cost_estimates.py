"""
Cost Estimation Constants for Impact Analysis Decisions

This module defines cost estimation constants for LLM-based operations in
FAQ impact analysis. These estimates help predict and control costs for
question generation, answer generation, and LLM-based evaluations.

Cost estimates are based on:
- Azure OpenAI GPT-4 Turbo pricing (as of 2025)
- Typical token usage patterns for FAQ content
- Measured averages from production workloads

Constants:
    - Token usage estimates per operation
    - USD cost multipliers per model
    - Cost calculation utilities

Usage:
    >>> from faq_impact.config.cost_estimates import estimate_analysis_cost
    >>> cost = estimate_analysis_cost(
    ...     num_questions=100,
    ...     num_answers=100,
    ...     num_evaluations=50
    ... )
    >>> print(f"Estimated cost: ${cost:.2f}")

Author: Analytics Assist Team
Date: 2025-11-02
"""

from dataclasses import dataclass
from typing import Optional


# =============================================================================
# TOKEN USAGE ESTIMATES
# =============================================================================

# Question Generation - Tokens per operation
# Based on: 3_question_source_gen.ipynb analysis
#
# Breakdown:
# - Input: System prompt (200) + chunk content (750) + function schema (100) = 1050
# - Output: 3-5 questions with metadata = 150-250 tokens
# - Average: ~1200 tokens per chunk
COST_PER_QUESTION_GENERATION_TOKENS = 1200

# Answer Generation - Tokens per operation
# Based on: 4_answer_source_gen.ipynb analysis
#
# Breakdown:
# - Input: System prompt (250) + question (20) + context chunks (2-3 x 750) + schema (100) = ~2400
# - Output: Answer with sources (100-300) = 200 tokens average
# - Average: ~2600 tokens per question
COST_PER_ANSWER_GENERATION_TOKENS = 2600

# LLM Evaluation - Tokens per operation
# Used for: Semantic change evaluation, regeneration decision validation
#
# Breakdown:
# - Input: System prompt (150) + old content (750) + new content (750) + question (50) = 1700
# - Output: Evaluation result with reasoning (50-100) = 75 tokens average
# - Average: ~1800 tokens per evaluation
COST_PER_LLM_EVALUATION_TOKENS = 1800

# Question Regeneration - Tokens per operation
# Same as question generation (reuses same prompt/process)
COST_PER_QUESTION_REGENERATION_TOKENS = COST_PER_QUESTION_GENERATION_TOKENS

# Answer Regeneration - Tokens per operation
# Same as answer generation (reuses same prompt/process)
COST_PER_ANSWER_REGENERATION_TOKENS = COST_PER_ANSWER_GENERATION_TOKENS


# =============================================================================
# MODEL PRICING (USD per 1K tokens)
# =============================================================================
# Based on Azure OpenAI pricing as of 2025-01-01
# Source: https://azure.microsoft.com/en-us/pricing/details/cognitive-services/openai-service/

# GPT-4 Turbo (0125 / 1106 versions)
# Most common model for FAQ generation (good quality/cost balance)
#
# Input: $10.00 per 1M tokens = $0.010 per 1K tokens
# Output: $30.00 per 1M tokens = $0.030 per 1K tokens
# Weighted average (assuming 80% input, 20% output): $0.014 per 1K tokens
GPT4_TURBO_COST_PER_1K_TOKENS = 0.014

# GPT-4o (Omni model)
# Faster, cheaper alternative for simpler tasks
#
# Input: $5.00 per 1M tokens = $0.005 per 1K tokens
# Output: $15.00 per 1M tokens = $0.015 per 1K tokens
# Weighted average: $0.007 per 1K tokens
GPT4O_COST_PER_1K_TOKENS = 0.007

# GPT-3.5 Turbo (0125 version)
# Budget option for evaluations and simple generation
#
# Input: $0.50 per 1M tokens = $0.0005 per 1K tokens
# Output: $1.50 per 1M tokens = $0.0015 per 1K tokens
# Weighted average: $0.0008 per 1K tokens
GPT35_TURBO_COST_PER_1K_TOKENS = 0.0008

# Default model (GPT-4 Turbo - most commonly used)
DEFAULT_MODEL_COST_PER_1K_TOKENS = GPT4_TURBO_COST_PER_1K_TOKENS


# =============================================================================
# OPERATION COST ESTIMATES (USD)
# =============================================================================
# Pre-calculated costs for common operations using default model

# Cost to generate questions from one chunk
COST_PER_QUESTION_GENERATION = (
    COST_PER_QUESTION_GENERATION_TOKENS / 1000 * DEFAULT_MODEL_COST_PER_1K_TOKENS
)

# Cost to generate answer for one question
COST_PER_ANSWER_GENERATION = (
    COST_PER_ANSWER_GENERATION_TOKENS / 1000 * DEFAULT_MODEL_COST_PER_1K_TOKENS
)

# Cost to evaluate one content change with LLM
COST_PER_LLM_EVALUATION = (
    COST_PER_LLM_EVALUATION_TOKENS / 1000 * DEFAULT_MODEL_COST_PER_1K_TOKENS
)

# Cost to regenerate questions for one chunk
COST_PER_QUESTION_REGENERATION = COST_PER_QUESTION_GENERATION

# Cost to regenerate answer for one question
COST_PER_ANSWER_REGENERATION = COST_PER_ANSWER_GENERATION


# =============================================================================
# BATCH COST ESTIMATES
# =============================================================================
# Useful for planning and budgeting

# Cost per 100 new chunks (question + answer generation)
# Assumes: 3 questions per chunk, 3 answers per chunk
COST_PER_100_NEW_CHUNKS = (
    COST_PER_QUESTION_GENERATION * 100  # Question gen
    + COST_PER_ANSWER_GENERATION * 300  # Answer gen (3 per chunk)
)

# Cost per 100 modified chunks (with LLM evaluation)
# Assumes: 3 questions per chunk, 50% require regeneration
COST_PER_100_MODIFIED_CHUNKS = (
    COST_PER_LLM_EVALUATION * 300  # Evaluate all questions
    + COST_PER_QUESTION_REGENERATION * 150  # Regenerate 50%
    + COST_PER_ANSWER_REGENERATION * 150  # Regenerate 50% answers
)

# Cost per 100 deleted chunks (minimal - just inactivation queries)
# No LLM calls, just database operations
COST_PER_100_DELETED_CHUNKS = 0.0


# =============================================================================
# COST CALCULATION UTILITIES
# =============================================================================

@dataclass
class CostEstimate:
    """
    Cost estimate breakdown for impact analysis operations.

    Attributes:
        question_generation_cost: Cost for generating new questions
        answer_generation_cost: Cost for generating new answers
        llm_evaluation_cost: Cost for LLM-based change evaluations
        question_regeneration_cost: Cost for regenerating existing questions
        answer_regeneration_cost: Cost for regenerating existing answers
        total_cost: Total estimated cost (sum of all components)
        operation_count: Number of operations in estimate
        model_name: Model used for cost calculation

    Example:
        >>> estimate = CostEstimate(
        ...     question_generation_cost=1.20,
        ...     answer_generation_cost=3.60,
        ...     llm_evaluation_cost=0.90,
        ...     question_regeneration_cost=0.60,
        ...     answer_regeneration_cost=1.80,
        ...     total_cost=8.10,
        ...     operation_count=100,
        ...     model_name="gpt-4-turbo"
        ... )
        >>> print(estimate.format_summary())
    """
    question_generation_cost: float = 0.0
    answer_generation_cost: float = 0.0
    llm_evaluation_cost: float = 0.0
    question_regeneration_cost: float = 0.0
    answer_regeneration_cost: float = 0.0
    total_cost: float = 0.0
    operation_count: int = 0
    model_name: str = "gpt-4-turbo"

    def __post_init__(self):
        """Calculate total cost if not provided."""
        if self.total_cost == 0.0:
            self.total_cost = (
                self.question_generation_cost
                + self.answer_generation_cost
                + self.llm_evaluation_cost
                + self.question_regeneration_cost
                + self.answer_regeneration_cost
            )

    def format_summary(self) -> str:
        """
        Format cost estimate as human-readable summary.

        Returns:
            Multi-line string with cost breakdown

        Example:
            >>> estimate = CostEstimate(total_cost=8.10, operation_count=100)
            >>> print(estimate.format_summary())
            Cost Estimate Summary:
            ----------------------
            Question Generation:   $1.20
            Answer Generation:     $3.60
            LLM Evaluation:        $0.90
            Question Regeneration: $0.60
            Answer Regeneration:   $1.80
            ----------------------
            Total Cost:            $8.10
            Operations:            100
            Model:                 gpt-4-turbo
        """
        return f"""Cost Estimate Summary:
----------------------
Question Generation:   ${self.question_generation_cost:.2f}
Answer Generation:     ${self.answer_generation_cost:.2f}
LLM Evaluation:        ${self.llm_evaluation_cost:.2f}
Question Regeneration: ${self.question_regeneration_cost:.2f}
Answer Regeneration:   ${self.answer_regeneration_cost:.2f}
----------------------
Total Cost:            ${self.total_cost:.2f}
Operations:            {self.operation_count}
Model:                 {self.model_name}"""


def estimate_analysis_cost(
    num_new_chunks: int = 0,
    num_modified_chunks: int = 0,
    num_deleted_chunks: int = 0,
    num_questions: int = 0,
    num_answers: int = 0,
    num_evaluations: int = 0,
    model_cost_per_1k: Optional[float] = None,
) -> CostEstimate:
    """
    Estimate cost for an impact analysis run.

    Args:
        num_new_chunks: Number of new content chunks
        num_modified_chunks: Number of modified content chunks
        num_deleted_chunks: Number of deleted chunks (minimal cost)
        num_questions: Number of questions to generate/regenerate
        num_answers: Number of answers to generate/regenerate
        num_evaluations: Number of LLM evaluations to perform
        model_cost_per_1k: Cost per 1K tokens (defaults to GPT-4 Turbo)

    Returns:
        CostEstimate with detailed breakdown

    Example:
        >>> # Estimate cost for 100 new chunks
        >>> estimate = estimate_analysis_cost(num_new_chunks=100)
        >>> print(f"Cost: ${estimate.total_cost:.2f}")

        >>> # Estimate cost for mixed workload
        >>> estimate = estimate_analysis_cost(
        ...     num_new_chunks=50,
        ...     num_modified_chunks=30,
        ...     num_evaluations=90
        ... )
        >>> print(estimate.format_summary())
    """
    if model_cost_per_1k is None:
        model_cost_per_1k = DEFAULT_MODEL_COST_PER_1K_TOKENS

    # Calculate per-token costs
    cost_per_q_gen = COST_PER_QUESTION_GENERATION_TOKENS / 1000 * model_cost_per_1k
    cost_per_a_gen = COST_PER_ANSWER_GENERATION_TOKENS / 1000 * model_cost_per_1k
    cost_per_eval = COST_PER_LLM_EVALUATION_TOKENS / 1000 * model_cost_per_1k

    # Calculate component costs
    question_gen_cost = num_questions * cost_per_q_gen
    answer_gen_cost = num_answers * cost_per_a_gen
    evaluation_cost = num_evaluations * cost_per_eval

    # Add costs from chunk-based estimates (if provided instead of operation counts)
    if num_new_chunks > 0:
        # Assume 3 questions per chunk
        question_gen_cost += num_new_chunks * cost_per_q_gen * 3
        answer_gen_cost += num_new_chunks * cost_per_a_gen * 3

    if num_modified_chunks > 0:
        # Assume 3 questions per chunk, 50% regeneration rate
        evaluation_cost += num_modified_chunks * cost_per_eval * 3
        question_gen_cost += num_modified_chunks * cost_per_q_gen * 1.5
        answer_gen_cost += num_modified_chunks * cost_per_a_gen * 1.5

    total_operations = (
        num_new_chunks + num_modified_chunks + num_deleted_chunks +
        num_questions + num_answers + num_evaluations
    )

    return CostEstimate(
        question_generation_cost=question_gen_cost,
        answer_generation_cost=answer_gen_cost,
        llm_evaluation_cost=evaluation_cost,
        question_regeneration_cost=0.0,  # Included in question_generation_cost
        answer_regeneration_cost=0.0,  # Included in answer_generation_cost
        total_cost=question_gen_cost + answer_gen_cost + evaluation_cost,
        operation_count=total_operations,
        model_name="custom" if model_cost_per_1k != DEFAULT_MODEL_COST_PER_1K_TOKENS else "gpt-4-turbo",
    )


def estimate_cost_for_model(
    num_operations: int,
    operation_type: str,
    model_name: str = "gpt-4-turbo",
) -> float:
    """
    Estimate cost for a specific number of operations with a specific model.

    Args:
        num_operations: Number of operations to perform
        operation_type: Type of operation ('question', 'answer', 'evaluation')
        model_name: Model to use ('gpt-4-turbo', 'gpt-4o', 'gpt-3.5-turbo')

    Returns:
        Estimated cost in USD

    Raises:
        ValueError: If operation_type or model_name is invalid

    Example:
        >>> # Cost for 100 question generations with GPT-4 Turbo
        >>> cost = estimate_cost_for_model(100, "question", "gpt-4-turbo")
        >>> print(f"${cost:.2f}")

        >>> # Cost for 50 evaluations with cheaper GPT-3.5
        >>> cost = estimate_cost_for_model(50, "evaluation", "gpt-3.5-turbo")
        >>> print(f"${cost:.2f}")
    """
    # Get model cost
    model_costs = {
        "gpt-4-turbo": GPT4_TURBO_COST_PER_1K_TOKENS,
        "gpt-4o": GPT4O_COST_PER_1K_TOKENS,
        "gpt-3.5-turbo": GPT35_TURBO_COST_PER_1K_TOKENS,
    }
    if model_name not in model_costs:
        raise ValueError(
            f"Invalid model_name '{model_name}'. "
            f"Valid options: {list(model_costs.keys())}"
        )
    model_cost = model_costs[model_name]

    # Get operation token count
    operation_tokens = {
        "question": COST_PER_QUESTION_GENERATION_TOKENS,
        "answer": COST_PER_ANSWER_GENERATION_TOKENS,
        "evaluation": COST_PER_LLM_EVALUATION_TOKENS,
    }
    if operation_type not in operation_tokens:
        raise ValueError(
            f"Invalid operation_type '{operation_type}'. "
            f"Valid options: {list(operation_tokens.keys())}"
        )
    tokens = operation_tokens[operation_type]

    return num_operations * (tokens / 1000) * model_cost


# =============================================================================
# VALIDATION
# =============================================================================

def validate_cost_constants():
    """
    Validate that all cost constants are correctly configured.

    Raises:
        ValueError: If any constant is invalid
    """
    # Validate token counts (must be positive)
    token_counts = {
        "COST_PER_QUESTION_GENERATION_TOKENS": COST_PER_QUESTION_GENERATION_TOKENS,
        "COST_PER_ANSWER_GENERATION_TOKENS": COST_PER_ANSWER_GENERATION_TOKENS,
        "COST_PER_LLM_EVALUATION_TOKENS": COST_PER_LLM_EVALUATION_TOKENS,
    }
    for name, value in token_counts.items():
        if not isinstance(value, int):
            raise ValueError(f"{name} must be an integer, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"{name} must be positive, got {value}")

    # Validate cost multipliers (must be positive floats)
    cost_multipliers = {
        "GPT4_TURBO_COST_PER_1K_TOKENS": GPT4_TURBO_COST_PER_1K_TOKENS,
        "GPT4O_COST_PER_1K_TOKENS": GPT4O_COST_PER_1K_TOKENS,
        "GPT35_TURBO_COST_PER_1K_TOKENS": GPT35_TURBO_COST_PER_1K_TOKENS,
    }
    for name, value in cost_multipliers.items():
        if not isinstance(value, (int, float)):
            raise ValueError(f"{name} must be a number, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"{name} must be positive, got {value}")

    # Validate logical consistency
    if GPT4_TURBO_COST_PER_1K_TOKENS < GPT35_TURBO_COST_PER_1K_TOKENS:
        raise ValueError(
            "GPT-4 Turbo should be more expensive than GPT-3.5 Turbo "
            "(check pricing constants)"
        )


# Run validation on import
validate_cost_constants()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Token Usage Estimates
    "COST_PER_QUESTION_GENERATION_TOKENS",
    "COST_PER_ANSWER_GENERATION_TOKENS",
    "COST_PER_LLM_EVALUATION_TOKENS",
    "COST_PER_QUESTION_REGENERATION_TOKENS",
    "COST_PER_ANSWER_REGENERATION_TOKENS",

    # Model Pricing
    "GPT4_TURBO_COST_PER_1K_TOKENS",
    "GPT4O_COST_PER_1K_TOKENS",
    "GPT35_TURBO_COST_PER_1K_TOKENS",
    "DEFAULT_MODEL_COST_PER_1K_TOKENS",

    # Operation Costs
    "COST_PER_QUESTION_GENERATION",
    "COST_PER_ANSWER_GENERATION",
    "COST_PER_LLM_EVALUATION",
    "COST_PER_QUESTION_REGENERATION",
    "COST_PER_ANSWER_REGENERATION",

    # Batch Costs
    "COST_PER_100_NEW_CHUNKS",
    "COST_PER_100_MODIFIED_CHUNKS",
    "COST_PER_100_DELETED_CHUNKS",

    # Utilities
    "CostEstimate",
    "estimate_analysis_cost",
    "estimate_cost_for_model",
    "validate_cost_constants",
]
