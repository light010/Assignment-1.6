"""
Configuration Validation Utilities

This module provides validation functions for configuration combinations and
dependencies. It ensures that configuration values are not only individually
valid but also logically consistent with each other.

Functions:
    - validate_llm_config_if_enabled: Ensure LLM config exists if evaluation enabled
    - validate_config_combinations: Check for incompatible config combinations
    - suggest_config_improvements: Provide suggestions for better configurations
    - validate_resource_limits: Ensure resource limits are reasonable

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import Optional, List, Dict, Any
import warnings

from .impact_config import ImpactAnalysisConfig


class ConfigurationWarning(UserWarning):
    """Warning raised for suboptimal but valid configurations."""
    pass


class ConfigurationError(ValueError):
    """Error raised for invalid configuration combinations."""
    pass


def validate_llm_config_if_enabled(
    config: ImpactAnalysisConfig,
    llm_client: Optional[Any] = None,
) -> None:
    """
    Validate that LLM configuration is available if LLM evaluation is enabled.

    If enable_llm_evaluation is True, this function checks that:
    1. An LLM client is provided or can be created
    2. LLM timeout is reasonable
    3. Max concurrent evaluations is within API limits

    Args:
        config: ImpactAnalysisConfig to validate
        llm_client: Optional LLM client instance (e.g., AzureOpenAIChatModel)

    Raises:
        ConfigurationError: If LLM evaluation enabled but LLM not available

    Example:
        >>> config = ImpactAnalysisConfig(enable_llm_evaluation=True)
        >>> validate_llm_config_if_enabled(config, llm_client=None)
        Traceback (most recent call last):
            ...
        ConfigurationError: LLM evaluation is enabled but no LLM client provided
    """
    if not config.enable_llm_evaluation:
        # LLM not enabled, no validation needed
        return

    # Check if LLM client is provided
    if llm_client is None:
        raise ConfigurationError(
            "LLM evaluation is enabled (enable_llm_evaluation=True) but no "
            "LLM client provided. Either provide an LLM client or set "
            "enable_llm_evaluation=False."
        )

    # Validate timeout is reasonable
    if config.llm_timeout_seconds < 10:
        warnings.warn(
            f"LLM timeout ({config.llm_timeout_seconds}s) is very short. "
            "LLM API calls typically take 5-15 seconds. Consider increasing "
            "to at least 20 seconds to avoid frequent timeouts.",
            ConfigurationWarning
        )
    elif config.llm_timeout_seconds > 120:
        warnings.warn(
            f"LLM timeout ({config.llm_timeout_seconds}s) is very long. "
            "This may cause the system to hang on slow API responses. "
            "Consider reducing to 30-60 seconds.",
            ConfigurationWarning
        )

    # Validate concurrent evaluations are reasonable
    if config.max_concurrent_evaluations > 20:
        warnings.warn(
            f"Max concurrent evaluations ({config.max_concurrent_evaluations}) "
            "is very high. This may exceed API rate limits and increase costs. "
            "Consider reducing to 5-10 for most Azure OpenAI deployments.",
            ConfigurationWarning
        )


def validate_config_combinations(config: ImpactAnalysisConfig) -> None:
    """
    Validate that configuration values are logically consistent.

    Checks for incompatible configuration combinations and raises errors
    or warnings as appropriate.

    Args:
        config: ImpactAnalysisConfig to validate

    Raises:
        ConfigurationError: If configuration contains logical inconsistencies

    Example:
        >>> config = ImpactAnalysisConfig(
        ...     token_overlap_threshold=0.1,
        ...     enable_llm_evaluation=False
        ... )
        >>> validate_config_combinations(config)  # May raise warnings
    """
    # Check token overlap threshold vs LLM evaluation
    if config.token_overlap_threshold < 0.2 and not config.enable_llm_evaluation:
        warnings.warn(
            f"Token overlap threshold ({config.token_overlap_threshold}) is "
            "very low but LLM evaluation is disabled. This may cause many "
            "unnecessary regenerations. Consider either:\n"
            "1. Increasing token_overlap_threshold to 0.3 or higher\n"
            "2. Enabling LLM evaluation for better decision-making",
            ConfigurationWarning
        )

    # Check token overlap threshold vs similarity method
    if config.token_overlap_threshold > 0.6 and config.similarity_method == "jaccard":
        warnings.warn(
            f"Token overlap threshold ({config.token_overlap_threshold}) is "
            "high with jaccard similarity method. This may miss meaningful "
            "changes. Consider:\n"
            "1. Lowering token_overlap_threshold to 0.3-0.5\n"
            "2. Using 'hybrid' similarity method for better accuracy",
            ConfigurationWarning
        )

    # Check min_token_overlap_count vs threshold
    if config.min_token_overlap_count > 5:
        warnings.warn(
            f"min_token_overlap_count ({config.min_token_overlap_count}) is "
            "high. This may cause false negatives (missed changes) for small "
            "content chunks. Consider reducing to 2-3 tokens.",
            ConfigurationWarning
        )

    # Check similarity method vs LLM evaluation
    if config.similarity_method == "hybrid" and not config.enable_llm_evaluation:
        # This is actually fine, just informational
        pass

    if config.similarity_method == "semantic" and not config.enable_llm_evaluation:
        raise ConfigurationError(
            "Semantic similarity method requires LLM evaluation to be enabled. "
            "Either set enable_llm_evaluation=True or use a different similarity "
            "method (jaccard, sequence, hybrid)."
        )


def suggest_config_improvements(config: ImpactAnalysisConfig) -> List[str]:
    """
    Suggest improvements for the given configuration.

    Analyzes configuration and returns list of suggestions for better
    performance, accuracy, or cost optimization.

    Args:
        config: ImpactAnalysisConfig to analyze

    Returns:
        List of suggestion strings

    Example:
        >>> config = ImpactAnalysisConfig(
        ...     similarity_method="hybrid",
        ...     enable_llm_evaluation=False
        ... )
        >>> suggestions = suggest_config_improvements(config)
        >>> for suggestion in suggestions:
        ...     print(suggestion)
    """
    suggestions = []

    # Suggest factory methods for common patterns
    if (
        config.token_overlap_threshold == 0.3
        and config.similarity_method == "jaccard"
        and config.enable_llm_evaluation is True
    ):
        suggestions.append(
            "Your configuration matches ImpactAnalysisConfig.for_cost_optimized(). "
            "Consider using this factory method for clarity."
        )

    # Suggest enabling LLM for better accuracy
    if not config.enable_llm_evaluation and config.token_overlap_threshold < 0.4:
        suggestions.append(
            "Consider enabling LLM evaluation (enable_llm_evaluation=True) for "
            "better accuracy with low token overlap threshold. This will improve "
            "decision quality but increase costs."
        )

    # Suggest hybrid method for comprehensive analysis
    if config.similarity_method == "jaccard" and config.enable_llm_evaluation:
        suggestions.append(
            "Consider using 'hybrid' similarity method for more comprehensive "
            "change detection. This combines token overlap with sequence similarity "
            "for better accuracy with minimal performance impact."
        )

    # Suggest increasing concurrency for performance
    if config.max_concurrent_evaluations < 5 and config.enable_llm_evaluation:
        suggestions.append(
            f"Max concurrent evaluations ({config.max_concurrent_evaluations}) is low. "
            "Consider increasing to 5-10 for better performance if your API rate "
            "limits allow."
        )

    # Suggest reducing concurrency for cost control
    if config.max_concurrent_evaluations > 10:
        suggestions.append(
            f"Max concurrent evaluations ({config.max_concurrent_evaluations}) is high. "
            "This increases API costs and may hit rate limits. Consider reducing to "
            "5-8 unless you need maximum throughput."
        )

    return suggestions


def validate_resource_limits(
    config: ImpactAnalysisConfig,
    expected_chunks: Optional[int] = None,
    expected_questions: Optional[int] = None,
) -> None:
    """
    Validate that resource limits are appropriate for expected workload.

    Args:
        config: ImpactAnalysisConfig to validate
        expected_chunks: Number of chunks expected to process (optional)
        expected_questions: Number of questions expected to analyze (optional)

    Raises:
        ConfigurationError: If resource limits are inadequate for workload

    Example:
        >>> config = ImpactAnalysisConfig(max_concurrent_evaluations=2)
        >>> validate_resource_limits(config, expected_questions=1000)
        # May raise warning about low concurrency for large workload
    """
    if expected_questions is None:
        return

    # Estimate processing time with current config
    if config.enable_llm_evaluation:
        # Assume 5 seconds per evaluation, with concurrency
        estimated_time_seconds = (
            expected_questions * 5 / config.max_concurrent_evaluations
        )
        estimated_minutes = estimated_time_seconds / 60

        if estimated_minutes > 30:
            warnings.warn(
                f"Estimated processing time: {estimated_minutes:.1f} minutes for "
                f"{expected_questions} questions with max_concurrent_evaluations="
                f"{config.max_concurrent_evaluations}. Consider:\n"
                f"1. Increasing max_concurrent_evaluations (current: {config.max_concurrent_evaluations})\n"
                f"2. Disabling LLM evaluation if speed is more important than accuracy\n"
                f"3. Processing in smaller batches",
                ConfigurationWarning
            )

    # Check if workload is very large
    if expected_chunks and expected_chunks > 10000:
        warnings.warn(
            f"Processing {expected_chunks} chunks is a large workload. Consider:\n"
            "1. Enabling chunk-question cache for better performance\n"
            "2. Using 'jaccard' similarity method (faster than 'hybrid')\n"
            "3. Processing in batches to avoid memory issues",
            ConfigurationWarning
        )


def validate_full_configuration(
    config: ImpactAnalysisConfig,
    llm_client: Optional[Any] = None,
    expected_chunks: Optional[int] = None,
    expected_questions: Optional[int] = None,
) -> Dict[str, List[str]]:
    """
    Perform comprehensive validation of configuration.

    This is the main validation entry point that runs all validation checks
    and returns a structured report of errors, warnings, and suggestions.

    Args:
        config: ImpactAnalysisConfig to validate
        llm_client: Optional LLM client instance
        expected_chunks: Expected number of chunks (optional)
        expected_questions: Expected number of questions (optional)

    Returns:
        Dictionary with keys 'errors', 'warnings', 'suggestions' containing
        lists of validation messages

    Example:
        >>> config = ImpactAnalysisConfig()
        >>> report = validate_full_configuration(config)
        >>> if report['errors']:
        ...     print("Configuration errors:", report['errors'])
        >>> if report['suggestions']:
        ...     print("Suggestions:", report['suggestions'])
    """
    errors = []
    warnings_list = []
    suggestions = []

    # Validate LLM config
    try:
        validate_llm_config_if_enabled(config, llm_client)
    except ConfigurationError as e:
        errors.append(str(e))

    # Validate config combinations
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        try:
            validate_config_combinations(config)
        except ConfigurationError as e:
            errors.append(str(e))

        # Capture warnings
        for warning in w:
            if issubclass(warning.category, ConfigurationWarning):
                warnings_list.append(str(warning.message))

    # Validate resource limits
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        try:
            validate_resource_limits(config, expected_chunks, expected_questions)
        except ConfigurationError as e:
            errors.append(str(e))

        # Capture warnings
        for warning in w:
            if issubclass(warning.category, ConfigurationWarning):
                warnings_list.append(str(warning.message))

    # Get suggestions
    suggestions = suggest_config_improvements(config)

    return {
        "errors": errors,
        "warnings": warnings_list,
        "suggestions": suggestions,
    }


def print_validation_report(report: Dict[str, List[str]]) -> None:
    """
    Pretty-print validation report.

    Args:
        report: Validation report from validate_full_configuration()

    Example:
        >>> config = ImpactAnalysisConfig()
        >>> report = validate_full_configuration(config)
        >>> print_validation_report(report)
        Configuration Validation Report
        ================================

        Errors: 0
        Warnings: 0
        Suggestions: 1

        Suggestions:
        - Your configuration matches ImpactAnalysisConfig.for_cost_optimized()...
    """
    print("Configuration Validation Report")
    print("=" * 50)
    print()
    print(f"Errors: {len(report['errors'])}")
    print(f"Warnings: {len(report['warnings'])}")
    print(f"Suggestions: {len(report['suggestions'])}")
    print()

    if report["errors"]:
        print("ERRORS:")
        print("-" * 50)
        for error in report["errors"]:
            print(f"❌ {error}")
        print()

    if report["warnings"]:
        print("WARNINGS:")
        print("-" * 50)
        for warning in report["warnings"]:
            print(f"⚠️  {warning}")
        print()

    if report["suggestions"]:
        print("SUGGESTIONS:")
        print("-" * 50)
        for suggestion in report["suggestions"]:
            print(f"💡 {suggestion}")
        print()

    if not report["errors"] and not report["warnings"] and not report["suggestions"]:
        print("✅ Configuration looks good!")


__all__ = [
    "ConfigurationWarning",
    "ConfigurationError",
    "validate_llm_config_if_enabled",
    "validate_config_combinations",
    "suggest_config_improvements",
    "validate_resource_limits",
    "validate_full_configuration",
    "print_validation_report",
]
