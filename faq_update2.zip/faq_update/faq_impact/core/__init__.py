"""
Core Domain Layer - Models, Interfaces, and Enums

This module contains the core domain logic for FAQ impact analysis:
- Immutable value objects representing business concepts
- Domain interfaces defining contracts
- Enumerations for type-safe classifications

Design Principles:
    - Domain-Driven Design: Rich domain models with behavior
    - Immutability: Value objects are frozen dataclasses
    - Type Safety: Enums for all classifications
    - Self-Validating: Models validate their own invariants

Submodules:
    models/     - Domain value objects (ImpactResult, ChangeImpact, etc.)
    interfaces/ - Abstract base classes and protocols
    enums/      - Type-safe enumerations (ImpactType, ChangeAction, etc.)

Example:
    >>> from faq_impact.core.models import ImpactAnalysisReport
    >>> from faq_impact.core.enums import ImpactType
    >>>
    >>> report = ImpactAnalysisReport(
    ...     new_content_count=5,
    ...     modified_content_count=3,
    ...     deleted_content_count=2
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Imports will be added as components are implemented
__all__ = []
