"""
ApplicationResult Data Class

This module defines the immutable value object for impact decision application
results in the FAQ impact analysis system.

Classes:
    - ApplicationResult: Result of executing an impact decision

Author: Analytics Assist Team
Date: 2025-11-02
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional
import json

from ..enums.decision_type import ApplicationStatus


@dataclass(frozen=True)
class ApplicationResult:
    """
    Immutable value object capturing the result of executing an impact decision.

    ApplicationResult records what happened when an impact decision was applied
    during the APPLY PLAN phase. It provides a complete audit trail of:
    - What was executed (impact_id)
    - Execution status (SUCCESS, FAILED, etc.)
    - Performance metrics (execution time)
    - Impact metrics (affected rows)
    - Error details (if failed)
    - Rollback information

    This dataclass is created by impact decision executors (CreateExecutor,
    RegenerateExecutor, etc.) and stored for audit purposes.

    Fields:
        impact_id: ID of the impact decision that was executed
        status: Execution status (from ApplicationStatus enum)
        executed_at: Timestamp when execution started
        execution_time_ms: Execution duration in milliseconds
        affected_rows: Number of database rows affected (inserts, updates)
        error_message: Error message if execution failed (None if success)
        rollback_performed: Whether rollback was executed on failure
        metadata: Additional execution context (dict)

    Example:
        >>> from faq_impact.core.models import ApplicationResult
        >>> from faq_impact.core.enums import ApplicationStatus
        >>> from datetime import datetime
        >>>
        >>> # Create successful application result
        >>> result = ApplicationResult(
        ...     impact_id=123,
        ...     status=ApplicationStatus.COMPLETED,
        ...     executed_at=datetime.now(),
        ...     execution_time_ms=1250,
        ...     affected_rows=2,
        ...     error_message=None,
        ...     rollback_performed=False,
        ...     metadata={
        ...         "question_id": 456,
        ...         "answer_id": 789,
        ...         "generation_tokens": 500
        ...     }
        ... )
        >>>
        >>> # Check status
        >>> result.is_successful()
        True
        >>> result.is_failed()
        False
        >>>
        >>> # Create failed application result
        >>> failed_result = ApplicationResult(
        ...     impact_id=124,
        ...     status=ApplicationStatus.FAILED,
        ...     executed_at=datetime.now(),
        ...     execution_time_ms=500,
        ...     affected_rows=0,
        ...     error_message="LLM API timeout after 30 seconds",
        ...     rollback_performed=True,
        ...     metadata={"retry_count": 3, "last_error_code": "TIMEOUT"}
        ... )
        >>>
        >>> failed_result.is_successful()
        False
        >>> failed_result.should_retry()
        True

    Design Notes:
        - Frozen dataclass for immutability (audit trail)
        - Used by executors to report execution outcomes
        - Stored in database or logs for audit trail
        - Enables retry logic for failed decisions
    """

    impact_id: int
    status: ApplicationStatus
    executed_at: datetime
    execution_time_ms: int
    affected_rows: int
    error_message: Optional[str]
    rollback_performed: bool
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Validate the ApplicationResult after initialization.

        Raises:
            ValueError: If validation fails
        """
        # Validate execution_time_ms
        if self.execution_time_ms < 0:
            raise ValueError(
                f"execution_time_ms cannot be negative, got {self.execution_time_ms}"
            )

        # Validate affected_rows
        if self.affected_rows < 0:
            raise ValueError(
                f"affected_rows cannot be negative, got {self.affected_rows}"
            )

        # Validate status-specific constraints
        if self.status == ApplicationStatus.COMPLETED:
            # Successful execution should not have error message
            if self.error_message is not None:
                raise ValueError(
                    "COMPLETED status should not have error_message, "
                    f"got: '{self.error_message}'"
                )
            # Successful execution should not have rollback
            if self.rollback_performed:
                raise ValueError("COMPLETED status should not have rollback_performed=True")

        elif self.status == ApplicationStatus.FAILED:
            # Failed execution should have error message
            if self.error_message is None or self.error_message.strip() == "":
                raise ValueError("FAILED status must have non-empty error_message")

        elif self.status == ApplicationStatus.SKIPPED:
            # Skipped execution should not have affected rows
            if self.affected_rows > 0:
                raise ValueError("SKIPPED status should not have affected_rows > 0")

        # Validate metadata is a dict
        if not isinstance(self.metadata, dict):
            raise ValueError(f"metadata must be a dictionary, got {type(self.metadata)}")

    def is_successful(self) -> bool:
        """
        Check if execution was successful.

        Returns:
            True if status is COMPLETED
        """
        return self.status == ApplicationStatus.COMPLETED

    def is_failed(self) -> bool:
        """
        Check if execution failed.

        Returns:
            True if status is FAILED
        """
        return self.status == ApplicationStatus.FAILED

    def is_skipped(self) -> bool:
        """
        Check if execution was skipped.

        Returns:
            True if status is SKIPPED
        """
        return self.status == ApplicationStatus.SKIPPED

    def should_retry(self) -> bool:
        """
        Check if this execution should be retried.

        Retry is allowed for FAILED status (errors may be transient).

        Returns:
            True if status is FAILED and retry is appropriate
        """
        return self.status.can_retry()

    def get_execution_time_seconds(self) -> float:
        """
        Get execution time in seconds (for display).

        Returns:
            Execution time in seconds as float
        """
        return self.execution_time_ms / 1000.0

    def has_error(self) -> bool:
        """
        Check if result has an error message.

        Returns:
            True if error_message is not None
        """
        return self.error_message is not None

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert ApplicationResult to dictionary for serialization.

        Returns:
            Dictionary representation with enum values as strings

        Example:
            >>> result = ApplicationResult(...)
            >>> d = result.to_dict()
            >>> d['status']
            'COMPLETED'
            >>> d['execution_time_ms']
            1250
        """
        return {
            "impact_id": self.impact_id,
            "status": self.status.value,
            "executed_at": self.executed_at.isoformat() if self.executed_at else None,
            "execution_time_ms": self.execution_time_ms,
            "affected_rows": self.affected_rows,
            "error_message": self.error_message,
            "rollback_performed": self.rollback_performed,
            "metadata": json.dumps(self.metadata) if self.metadata else "{}",
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApplicationResult":
        """
        Create ApplicationResult from dictionary.

        Args:
            data: Dictionary with application result fields

        Returns:
            ApplicationResult instance

        Raises:
            ValueError: If data is invalid or enums cannot be parsed

        Example:
            >>> data = {
            ...     "impact_id": 123,
            ...     "status": "COMPLETED",
            ...     "executed_at": "2025-11-02T10:00:00",
            ...     "execution_time_ms": 1250,
            ...     "affected_rows": 2,
            ...     "error_message": None,
            ...     "rollback_performed": False,
            ...     "metadata": '{"question_id": 456}'
            ... }
            >>> result = ApplicationResult.from_dict(data)
            >>> result.impact_id
            123
        """
        # Parse status enum
        status = ApplicationStatus.from_string(data["status"])

        # Parse timestamp
        executed_at = None
        if data.get("executed_at"):
            if isinstance(data["executed_at"], str):
                executed_at = datetime.fromisoformat(data["executed_at"])
            elif isinstance(data["executed_at"], datetime):
                executed_at = data["executed_at"]

        # Parse metadata JSON
        metadata = {}
        if data.get("metadata"):
            if isinstance(data["metadata"], str):
                metadata = json.loads(data["metadata"]) if data["metadata"] else {}
            else:
                metadata = data["metadata"]

        return cls(
            impact_id=data["impact_id"],
            status=status,
            executed_at=executed_at,
            execution_time_ms=data["execution_time_ms"],
            affected_rows=data["affected_rows"],
            error_message=data.get("error_message"),
            rollback_performed=data.get("rollback_performed", False),
            metadata=metadata,
        )

    @classmethod
    def create_success(
        cls,
        impact_id: int,
        executed_at: datetime,
        execution_time_ms: int,
        affected_rows: int,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ApplicationResult":
        """
        Factory method to create a successful application result.

        Args:
            impact_id: ID of the impact decision
            executed_at: Execution timestamp
            execution_time_ms: Execution duration in milliseconds
            affected_rows: Number of rows affected
            metadata: Optional execution metadata

        Returns:
            ApplicationResult with COMPLETED status

        Example:
            >>> result = ApplicationResult.create_success(
            ...     impact_id=123,
            ...     executed_at=datetime.now(),
            ...     execution_time_ms=1000,
            ...     affected_rows=1,
            ...     metadata={"question_id": 456}
            ... )
            >>> result.is_successful()
            True
        """
        return cls(
            impact_id=impact_id,
            status=ApplicationStatus.COMPLETED,
            executed_at=executed_at,
            execution_time_ms=execution_time_ms,
            affected_rows=affected_rows,
            error_message=None,
            rollback_performed=False,
            metadata=metadata or {},
        )

    @classmethod
    def create_failure(
        cls,
        impact_id: int,
        executed_at: datetime,
        execution_time_ms: int,
        error_message: str,
        rollback_performed: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ApplicationResult":
        """
        Factory method to create a failed application result.

        Args:
            impact_id: ID of the impact decision
            executed_at: Execution timestamp
            execution_time_ms: Execution duration in milliseconds
            error_message: Error message describing failure
            rollback_performed: Whether rollback was executed
            metadata: Optional execution metadata

        Returns:
            ApplicationResult with FAILED status

        Example:
            >>> result = ApplicationResult.create_failure(
            ...     impact_id=123,
            ...     executed_at=datetime.now(),
            ...     execution_time_ms=500,
            ...     error_message="Database connection timeout",
            ...     rollback_performed=True,
            ...     metadata={"retry_count": 3}
            ... )
            >>> result.is_failed()
            True
            >>> result.should_retry()
            True
        """
        return cls(
            impact_id=impact_id,
            status=ApplicationStatus.FAILED,
            executed_at=executed_at,
            execution_time_ms=execution_time_ms,
            affected_rows=0,
            error_message=error_message,
            rollback_performed=rollback_performed,
            metadata=metadata or {},
        )

    @classmethod
    def create_skipped(
        cls,
        impact_id: int,
        executed_at: datetime,
        reason: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ApplicationResult":
        """
        Factory method to create a skipped application result.

        Args:
            impact_id: ID of the impact decision
            executed_at: Execution timestamp
            reason: Reason for skipping
            metadata: Optional execution metadata

        Returns:
            ApplicationResult with SKIPPED status

        Example:
            >>> result = ApplicationResult.create_skipped(
            ...     impact_id=123,
            ...     executed_at=datetime.now(),
            ...     reason="User manually skipped decision",
            ...     metadata={"skipped_by": "user_123"}
            ... )
            >>> result.is_skipped()
            True
        """
        return cls(
            impact_id=impact_id,
            status=ApplicationStatus.SKIPPED,
            executed_at=executed_at,
            execution_time_ms=0,
            affected_rows=0,
            error_message=reason,  # Store skip reason in error_message field
            rollback_performed=False,
            metadata=metadata or {},
        )


# Convenience exports
__all__ = [
    "ApplicationResult",
]
