"""
Dataclass Conversion Utilities

This module provides generic utilities for converting between domain models
(dataclasses) and database rows (dictionaries) in the FAQ impact analysis system.

Functions:
    - model_to_dict: Convert any dataclass to dictionary
    - dict_to_model: Convert dictionary to specified dataclass
    - models_to_dicts: Batch convert list of dataclasses to dictionaries
    - dicts_to_models: Batch convert list of dictionaries to dataclasses

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import Dict, Any, List, Type, TypeVar, Optional
from dataclasses import is_dataclass, asdict, fields
import json

# Type variable for generic dataclass conversion
T = TypeVar('T')


def model_to_dict(model: Any, include_none: bool = True) -> Dict[str, Any]:
    """
    Convert a dataclass instance to a dictionary.

    This is a generic converter that works with any dataclass. It handles:
    - Nested dataclasses (recursively converts)
    - Enum values (converts to strings)
    - None values (optionally excludes)
    - JSON serialization compatibility

    Args:
        model: Dataclass instance to convert
        include_none: Whether to include fields with None values (default True)

    Returns:
        Dictionary representation of the dataclass

    Raises:
        TypeError: If model is not a dataclass
        ValueError: If model contains non-serializable values

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>> from faq_impact.core.enums import DecisionType, ReasonCode, EntityType
        >>> from datetime import datetime
        >>>
        >>> decision = ImpactDecision(
        ...     impact_id=123,
        ...     entity_type=EntityType.QUESTION,
        ...     entity_id=None,
        ...     change_id=456,
        ...     detection_run_id="run_001",
        ...     decision=DecisionType.PLAN_CREATE,
        ...     reason=ReasonCode.NEW_CONTENT_ADDED,
        ...     details={"chunk_id": 789},
        ...     created_at=datetime(2025, 11, 2, 10, 0, 0),
        ...     applied=False,
        ...     applied_at=None,
        ...     applied_by=None,
        ...     application_error=None
        ... )
        >>>
        >>> d = model_to_dict(decision)
        >>> d['decision']
        'PLAN_CREATE'
        >>> d['entity_type']
        'QUESTION'
        >>>
        >>> # Exclude None values
        >>> d_no_none = model_to_dict(decision, include_none=False)
        >>> 'entity_id' in d_no_none
        False
    """
    if not is_dataclass(model):
        raise TypeError(f"model must be a dataclass, got {type(model)}")

    # Use the model's to_dict() method if available
    if hasattr(model, 'to_dict'):
        result = model.to_dict()
    else:
        # Fallback to asdict() for basic conversion
        result = asdict(model)

    # Optionally exclude None values
    if not include_none:
        result = {k: v for k, v in result.items() if v is not None}

    return result


def dict_to_model(data: Dict[str, Any], model_class: Type[T]) -> T:
    """
    Convert a dictionary to a dataclass instance.

    This is a generic converter that works with any dataclass that has a
    from_dict() class method. It provides type safety and validation.

    Args:
        data: Dictionary with model fields
        model_class: Dataclass type to create

    Returns:
        Instance of model_class

    Raises:
        TypeError: If model_class is not a dataclass or lacks from_dict()
        ValueError: If data is invalid for the model

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> data = {
        ...     "impact_id": 123,
        ...     "entity_type": "QUESTION",
        ...     "entity_id": None,
        ...     "change_id": 456,
        ...     "detection_run_id": "run_001",
        ...     "decision": "PLAN_CREATE",
        ...     "reason": "NEW_CONTENT_ADDED",
        ...     "details": '{"chunk_id": 789}',
        ...     "created_at": "2025-11-02T10:00:00",
        ...     "applied": False,
        ...     "applied_at": None,
        ...     "applied_by": None,
        ...     "application_error": None
        ... }
        >>>
        >>> decision = dict_to_model(data, ImpactDecision)
        >>> decision.impact_id
        123
        >>> decision.decision.value
        'PLAN_CREATE'
    """
    if not is_dataclass(model_class):
        raise TypeError(f"model_class must be a dataclass, got {model_class}")

    # Use the model's from_dict() class method if available
    if hasattr(model_class, 'from_dict'):
        return model_class.from_dict(data)

    # Fallback: try direct instantiation (less safe)
    try:
        return model_class(**data)
    except Exception as e:
        raise ValueError(
            f"Failed to convert dict to {model_class.__name__}: {e}"
        )


def models_to_dicts(
    models: List[Any],
    include_none: bool = True
) -> List[Dict[str, Any]]:
    """
    Batch convert a list of dataclass instances to dictionaries.

    Args:
        models: List of dataclass instances
        include_none: Whether to include None values (default True)

    Returns:
        List of dictionary representations

    Raises:
        TypeError: If any model is not a dataclass

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> decisions = [decision1, decision2, decision3]
        >>> dicts = models_to_dicts(decisions)
        >>> len(dicts)
        3
        >>> all(isinstance(d, dict) for d in dicts)
        True
    """
    return [model_to_dict(model, include_none=include_none) for model in models]


def dicts_to_models(
    data_list: List[Dict[str, Any]],
    model_class: Type[T]
) -> List[T]:
    """
    Batch convert a list of dictionaries to dataclass instances.

    Args:
        data_list: List of dictionaries with model fields
        model_class: Dataclass type to create

    Returns:
        List of model_class instances

    Raises:
        TypeError: If model_class is not a dataclass
        ValueError: If any dict is invalid for the model

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> data_list = [dict1, dict2, dict3]
        >>> decisions = dicts_to_models(data_list, ImpactDecision)
        >>> len(decisions)
        3
        >>> all(isinstance(d, ImpactDecision) for d in decisions)
        True
    """
    return [dict_to_model(data, model_class) for data in data_list]


def validate_model_dict(
    data: Dict[str, Any],
    model_class: Type[T],
    raise_on_error: bool = True
) -> bool:
    """
    Validate that a dictionary can be converted to a dataclass.

    Checks if all required fields are present and types are compatible
    without actually creating the model instance.

    Args:
        data: Dictionary to validate
        model_class: Dataclass type to validate against
        raise_on_error: Whether to raise exception on validation failure

    Returns:
        True if valid, False if invalid (and raise_on_error=False)

    Raises:
        TypeError: If model_class is not a dataclass
        ValueError: If data is invalid (and raise_on_error=True)

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> data = {"impact_id": 123, "decision": "PLAN_CREATE", ...}
        >>> is_valid = validate_model_dict(data, ImpactDecision)
        >>> is_valid
        True
        >>>
        >>> invalid_data = {"impact_id": "not_an_int"}
        >>> is_valid = validate_model_dict(
        ...     invalid_data,
        ...     ImpactDecision,
        ...     raise_on_error=False
        ... )
        >>> is_valid
        False
    """
    if not is_dataclass(model_class):
        raise TypeError(f"model_class must be a dataclass, got {model_class}")

    try:
        # Attempt conversion (will validate in __post_init__)
        dict_to_model(data, model_class)
        return True
    except Exception as e:
        if raise_on_error:
            raise ValueError(
                f"Dictionary validation failed for {model_class.__name__}: {e}"
            )
        return False


def get_model_field_names(model_class: Type[T]) -> List[str]:
    """
    Get all field names for a dataclass.

    Args:
        model_class: Dataclass type

    Returns:
        List of field names as strings

    Raises:
        TypeError: If model_class is not a dataclass

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> field_names = get_model_field_names(ImpactDecision)
        >>> 'impact_id' in field_names
        True
        >>> 'decision' in field_names
        True
        >>> len(field_names) >= 10
        True
    """
    if not is_dataclass(model_class):
        raise TypeError(f"model_class must be a dataclass, got {model_class}")

    return [field.name for field in fields(model_class)]


def get_model_required_fields(model_class: Type[T]) -> List[str]:
    """
    Get required field names for a dataclass (fields without defaults).

    Args:
        model_class: Dataclass type

    Returns:
        List of required field names

    Raises:
        TypeError: If model_class is not a dataclass

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> required = get_model_required_fields(ImpactDecision)
        >>> 'impact_id' in required
        True
        >>> 'decision' in required
        True
    """
    if not is_dataclass(model_class):
        raise TypeError(f"model_class must be a dataclass, got {model_class}")

    required_fields = []
    for field_info in fields(model_class):
        # Field is required if it has no default and no default_factory
        if field_info.default == field_info.default_factory == type(field_info):
            # This is a hack to check if default was not set
            # A better way is to check field_info.default is dataclasses.MISSING
            from dataclasses import MISSING
            if field_info.default is MISSING and field_info.default_factory is MISSING:
                required_fields.append(field_info.name)

    return required_fields


def extract_field_subset(
    data: Dict[str, Any],
    model_class: Type[T],
    include_extra: bool = False
) -> Dict[str, Any]:
    """
    Extract only the fields relevant to a dataclass from a dictionary.

    Useful for cleaning database query results that may include extra columns.

    Args:
        data: Dictionary with possibly extra fields
        model_class: Dataclass type to extract fields for
        include_extra: Whether to include fields not in model (default False)

    Returns:
        Dictionary with only fields relevant to model_class

    Raises:
        TypeError: If model_class is not a dataclass

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>>
        >>> db_row = {
        ...     "impact_id": 123,
        ...     "decision": "PLAN_CREATE",
        ...     "extra_column": "ignored",
        ...     "another_extra": 999
        ... }
        >>>
        >>> clean_data = extract_field_subset(db_row, ImpactDecision)
        >>> 'impact_id' in clean_data
        True
        >>> 'extra_column' in clean_data
        False
    """
    if not is_dataclass(model_class):
        raise TypeError(f"model_class must be a dataclass, got {model_class}")

    field_names = get_model_field_names(model_class)

    if include_extra:
        return data.copy()
    else:
        return {k: v for k, v in data.items() if k in field_names}


def merge_model_updates(
    original: T,
    updates: Dict[str, Any],
    model_class: Type[T]
) -> T:
    """
    Create a new dataclass instance with updated fields (immutable update).

    Since dataclasses are frozen (immutable), this creates a new instance
    with specified fields updated while keeping others the same.

    Args:
        original: Original dataclass instance
        updates: Dictionary of fields to update
        model_class: Dataclass type

    Returns:
        New instance of model_class with updates applied

    Raises:
        TypeError: If original is not an instance of model_class
        ValueError: If updates contain invalid fields

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>> from datetime import datetime
        >>>
        >>> original = ImpactDecision(...)
        >>> original.applied
        False
        >>>
        >>> # "Update" applied status (creates new instance)
        >>> updated = merge_model_updates(
        ...     original,
        ...     {"applied": True, "applied_at": datetime.now()},
        ...     ImpactDecision
        ... )
        >>>
        >>> updated.applied
        True
        >>> original.applied  # Original unchanged
        False
    """
    if not isinstance(original, model_class):
        raise TypeError(
            f"original must be instance of {model_class.__name__}, "
            f"got {type(original).__name__}"
        )

    # Convert original to dict
    original_dict = model_to_dict(original)

    # Apply updates
    original_dict.update(updates)

    # Create new instance
    return dict_to_model(original_dict, model_class)


# Convenience exports
__all__ = [
    "model_to_dict",
    "dict_to_model",
    "models_to_dicts",
    "dicts_to_models",
    "validate_model_dict",
    "get_model_field_names",
    "get_model_required_fields",
    "extract_field_subset",
    "merge_model_updates",
]
