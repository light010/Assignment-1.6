"""
Core Domain Models - Immutable Value Objects

This module contains immutable value objects that represent core business
concepts in the FAQ impact analysis domain. All models are frozen dataclasses
with validation logic.

Key Models:

Decision Models:
    - ImpactDecision: A planned action in response to a content change
    - ImpactSummary: Aggregated metrics across multiple decisions
    - ApplicationResult: Result of executing an impact decision

Context Models:
    - DetectionContext: Complete context from content change detection

Analysis Result Models:
    - SourceCountResult: Results of source counting for orphan detection
    - TokenOverlapResult: Token matching results for modified content

Conversion Utilities:
    - model_to_dict: Convert dataclass to dictionary
    - dict_to_model: Convert dictionary to dataclass
    - models_to_dicts: Batch convert dataclasses to dictionaries
    - dicts_to_models: Batch convert dictionaries to dataclasses
    - validate_model_dict: Validate dictionary before conversion
    - get_model_field_names: Get field names for a dataclass
    - extract_field_subset: Extract only relevant fields from dict
    - merge_model_updates: Create new instance with updated fields (immutable)

Design Pattern:
    Immutable Value Objects - All models are @dataclass(frozen=True)

Validation:
    Models validate themselves in __post_init__ and raise descriptive errors

Example:
    >>> from faq_impact.core.models import ImpactDecision
    >>> from faq_impact.core.enums import EntityType, DecisionType, ReasonCode
    >>> from datetime import datetime
    >>>
    >>> decision = ImpactDecision(
    ...     impact_id=123,
    ...     entity_type=EntityType.QUESTION,
    ...     entity_id=None,
    ...     change_id=456,
    ...     detection_run_id="run_001",
    ...     decision=DecisionType.PLAN_CREATE,
    ...     reason=ReasonCode.NEW_CONTENT_ADDED,
    ...     details={"chunk_id": 789},
    ...     created_at=datetime.now(),
    ...     applied=False,
    ...     applied_at=None,
    ...     applied_by=None,
    ...     application_error=None
    ... )
    >>>
    >>> # Serialize to dict
    >>> decision_dict = decision.to_dict()
    >>> decision_dict['decision']
    'PLAN_CREATE'

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Import decision models
from .impact_decision import (
    ImpactDecision,
    ImpactSummary,
)

# Import context models
from .detection_context import (
    DetectionContext,
    SourceCountResult,
    TokenOverlapResult,
)

# Import application models
from .application_result import (
    ApplicationResult,
)

# Import conversion utilities
from .converters import (
    model_to_dict,
    dict_to_model,
    models_to_dicts,
    dicts_to_models,
    validate_model_dict,
    get_model_field_names,
    get_model_required_fields,
    extract_field_subset,
    merge_model_updates,
)

# Export all public interfaces
__all__ = [
    # Decision Models
    "ImpactDecision",
    "ImpactSummary",
    "ApplicationResult",
    # Context Models
    "DetectionContext",
    "SourceCountResult",
    "TokenOverlapResult",
    # Conversion Utilities
    "model_to_dict",
    "dict_to_model",
    "models_to_dicts",
    "dicts_to_models",
    "validate_model_dict",
    "get_model_field_names",
    "get_model_required_fields",
    "extract_field_subset",
    "merge_model_updates",
]
