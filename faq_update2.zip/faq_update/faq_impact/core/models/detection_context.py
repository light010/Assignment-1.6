"""
DetectionContext and Related Data Classes

This module defines immutable value objects for detection context, source counting,
and token overlap analysis in the FAQ impact analysis system.

Classes:
    - DetectionContext: Complete context from content change detection
    - SourceCountResult: Results of dynamic source counting for orphan detection
    - TokenOverlapResult: Token matching results for modified content analysis

Author: Analytics Assist Team
Date: 2025-11-02
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List
import json


@dataclass(frozen=True)
class DetectionContext:
    """
    Immutable value object encapsulating all context from content change detection.

    DetectionContext bundles all information needed for impact analysis from the
    content_change_log table. It provides a complete snapshot of:
    - What changed (change_id, change_type)
    - Content details (checksums, diff data)
    - Similarity metrics (if applicable)
    - File information
    - Additional metadata

    This dataclass is created by reading from content_change_log and passed to
    impact analysis strategies to determine appropriate actions.

    Fields:
        detection_run_id: Unique identifier for the detection run
        change_id: ID of the content change from content_change_log
        change_type: Type of change (NEW_CONTENT, MODIFIED_CONTENT, DELETED_CONTENT)
        content_checksum: Current content checksum (None for deleted content)
        previous_checksum: Previous content checksum (None for new content)
        diff_data: Detailed diff information (optional, dict)
        similarity_score: Similarity score between old and new content (0.0-1.0)
        file_name: Name of source file containing content
        metadata: Additional metadata from detection (dict)

    Example:
        >>> from faq_impact.core.models import DetectionContext
        >>>
        >>> # Create detection context for modified content
        >>> context = DetectionContext(
        ...     detection_run_id="run_20251102_001",
        ...     change_id=123,
        ...     change_type="MODIFIED_CONTENT",
        ...     content_checksum="abc123new",
        ...     previous_checksum="abc123old",
        ...     diff_data={"added_lines": 5, "removed_lines": 3},
        ...     similarity_score=0.75,
        ...     file_name="policies.pdf",
        ...     metadata={"chunk_id": 456, "page_number": 10}
        ... )
        >>>
        >>> # Access fields
        >>> context.change_type
        'MODIFIED_CONTENT'
        >>> context.similarity_score
        0.75
        >>>
        >>> # Serialize to dict
        >>> context_dict = context.to_dict()
        >>> context_dict['change_type']
        'MODIFIED_CONTENT'

    Design Notes:
        - Frozen dataclass ensures immutability
        - Created from content_change_log table rows
        - Passed to analysis strategies (NewContentStrategy, etc.)
        - Bundles all context needed for impact decisions
    """

    detection_run_id: str
    change_id: int
    change_type: str
    content_checksum: Optional[str]
    previous_checksum: Optional[str]
    diff_data: Optional[Dict[str, Any]]
    similarity_score: Optional[float]
    file_name: Optional[str]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Validate the DetectionContext after initialization.

        Raises:
            ValueError: If validation fails
        """
        # Validate change_type
        valid_change_types = {"NEW_CONTENT", "MODIFIED_CONTENT", "DELETED_CONTENT"}
        if self.change_type not in valid_change_types:
            raise ValueError(
                f"Invalid change_type '{self.change_type}'. "
                f"Valid types: {valid_change_types}"
            )

        # Validate checksums based on change type
        if self.change_type == "NEW_CONTENT":
            if self.content_checksum is None:
                raise ValueError("NEW_CONTENT must have content_checksum")
            if self.previous_checksum is not None:
                raise ValueError("NEW_CONTENT should not have previous_checksum")

        elif self.change_type == "DELETED_CONTENT":
            if self.previous_checksum is None:
                raise ValueError("DELETED_CONTENT must have previous_checksum")
            # content_checksum can be None for deleted content

        elif self.change_type == "MODIFIED_CONTENT":
            if self.content_checksum is None:
                raise ValueError("MODIFIED_CONTENT must have content_checksum")
            if self.previous_checksum is None:
                raise ValueError("MODIFIED_CONTENT must have previous_checksum")

        # Validate similarity_score range
        if self.similarity_score is not None:
            if not (0.0 <= self.similarity_score <= 1.0):
                raise ValueError(
                    f"similarity_score must be between 0.0 and 1.0, "
                    f"got {self.similarity_score}"
                )

        # Validate metadata is a dict
        if not isinstance(self.metadata, dict):
            raise ValueError(f"metadata must be a dictionary, got {type(self.metadata)}")

    def is_new_content(self) -> bool:
        """Check if this is a new content change."""
        return self.change_type == "NEW_CONTENT"

    def is_modified_content(self) -> bool:
        """Check if this is a modified content change."""
        return self.change_type == "MODIFIED_CONTENT"

    def is_deleted_content(self) -> bool:
        """Check if this is a deleted content change."""
        return self.change_type == "DELETED_CONTENT"

    def has_high_similarity(self, threshold: float = 0.9) -> bool:
        """
        Check if content has high similarity to previous version.

        Args:
            threshold: Similarity threshold (default 0.9)

        Returns:
            True if similarity_score >= threshold
        """
        if self.similarity_score is None:
            return False
        return self.similarity_score >= threshold

    def has_low_similarity(self, threshold: float = 0.5) -> bool:
        """
        Check if content has low similarity to previous version.

        Args:
            threshold: Similarity threshold (default 0.5)

        Returns:
            True if similarity_score < threshold
        """
        if self.similarity_score is None:
            return False
        return self.similarity_score < threshold

    def get_chunk_id(self) -> Optional[int]:
        """
        Extract chunk_id from metadata if available.

        Returns:
            chunk_id if present in metadata, None otherwise
        """
        return self.metadata.get("chunk_id")

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert DetectionContext to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "detection_run_id": self.detection_run_id,
            "change_id": self.change_id,
            "change_type": self.change_type,
            "content_checksum": self.content_checksum,
            "previous_checksum": self.previous_checksum,
            "diff_data": json.dumps(self.diff_data) if self.diff_data else None,
            "similarity_score": self.similarity_score,
            "file_name": self.file_name,
            "metadata": json.dumps(self.metadata) if self.metadata else "{}",
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DetectionContext":
        """
        Create DetectionContext from dictionary.

        Args:
            data: Dictionary with detection context fields

        Returns:
            DetectionContext instance
        """
        # Parse JSON fields
        diff_data = None
        if data.get("diff_data"):
            if isinstance(data["diff_data"], str):
                diff_data = json.loads(data["diff_data"])
            else:
                diff_data = data["diff_data"]

        metadata = {}
        if data.get("metadata"):
            if isinstance(data["metadata"], str):
                metadata = json.loads(data["metadata"])
            else:
                metadata = data["metadata"]

        return cls(
            detection_run_id=data["detection_run_id"],
            change_id=data["change_id"],
            change_type=data["change_type"],
            content_checksum=data.get("content_checksum"),
            previous_checksum=data.get("previous_checksum"),
            diff_data=diff_data,
            similarity_score=data.get("similarity_score"),
            file_name=data.get("file_name"),
            metadata=metadata,
        )


@dataclass(frozen=True)
class SourceCountResult:
    """
    Result of dynamic source counting for orphan detection.

    SourceCountResult encapsulates the outcome of counting how many valid sources
    a question or answer has. This is used in the DeletedContentStrategy to
    determine if entities should be inactivated (sole source) or left active
    (multi-source).

    Fields:
        question_id: ID of the question being analyzed (None for answer-only checks)
        answer_id: ID of the answer being analyzed
        valid_source_count: Number of valid sources remaining
        is_sole_source: True if only one source exists (count == 1)
        source_checksums: List of checksums for valid sources

    Example:
        >>> from faq_impact.core.models import SourceCountResult
        >>>
        >>> # Create source count result for orphan detection
        >>> result = SourceCountResult(
        ...     question_id=123,
        ...     answer_id=456,
        ...     valid_source_count=3,
        ...     is_sole_source=False,
        ...     source_checksums=["abc123", "def456", "ghi789"]
        ... )
        >>>
        >>> # Check if orphaned
        >>> result.is_orphaned()
        False
        >>> result.is_multi_source()
        True
        >>>
        >>> # Sole source example
        >>> sole_source = SourceCountResult(
        ...     question_id=124,
        ...     answer_id=457,
        ...     valid_source_count=1,
        ...     is_sole_source=True,
        ...     source_checksums=["abc123"]
        ... )
        >>> sole_source.is_orphaned()
        False
        >>> sole_source.is_sole_source
        True

    Design Notes:
        - Used by DeletedContentStrategy
        - valid_source_count == 0 → orphaned (inactivate)
        - valid_source_count == 1 → sole source (inactivate if deleted)
        - valid_source_count > 1 → multi-source (keep active, regen)
    """

    question_id: Optional[int]
    answer_id: int
    valid_source_count: int
    is_sole_source: bool
    source_checksums: List[str] = field(default_factory=list)

    def __post_init__(self):
        """
        Validate the SourceCountResult after initialization.

        Raises:
            ValueError: If validation fails
        """
        if self.valid_source_count < 0:
            raise ValueError(
                f"valid_source_count cannot be negative, got {self.valid_source_count}"
            )

        # Validate is_sole_source consistency
        if self.is_sole_source and self.valid_source_count != 1:
            raise ValueError(
                f"is_sole_source=True requires valid_source_count=1, "
                f"got {self.valid_source_count}"
            )

        if not self.is_sole_source and self.valid_source_count == 1:
            raise ValueError(
                f"valid_source_count=1 requires is_sole_source=True, "
                f"got is_sole_source={self.is_sole_source}"
            )

        # Validate source_checksums count matches valid_source_count
        if len(self.source_checksums) != self.valid_source_count:
            raise ValueError(
                f"source_checksums length ({len(self.source_checksums)}) "
                f"must match valid_source_count ({self.valid_source_count})"
            )

    def is_orphaned(self) -> bool:
        """
        Check if the entity is orphaned (no valid sources).

        Returns:
            True if valid_source_count == 0
        """
        return self.valid_source_count == 0

    def is_multi_source(self) -> bool:
        """
        Check if the entity has multiple sources.

        Returns:
            True if valid_source_count > 1
        """
        return self.valid_source_count > 1

    def has_checksum(self, checksum: str) -> bool:
        """
        Check if a specific checksum is in the valid sources.

        Args:
            checksum: Content checksum to check

        Returns:
            True if checksum is in source_checksums
        """
        return checksum in self.source_checksums

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert SourceCountResult to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "question_id": self.question_id,
            "answer_id": self.answer_id,
            "valid_source_count": self.valid_source_count,
            "is_sole_source": self.is_sole_source,
            "source_checksums": self.source_checksums,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SourceCountResult":
        """
        Create SourceCountResult from dictionary.

        Args:
            data: Dictionary with source count fields

        Returns:
            SourceCountResult instance
        """
        return cls(
            question_id=data.get("question_id"),
            answer_id=data["answer_id"],
            valid_source_count=data["valid_source_count"],
            is_sole_source=data["is_sole_source"],
            source_checksums=data.get("source_checksums", []),
        )


@dataclass(frozen=True)
class TokenOverlapResult:
    """
    Token matching results for modified content analysis.

    TokenOverlapResult captures the outcome of token overlap analysis between
    modified content and existing questions/answers. This is used in the
    ModifiedContentStrategy to determine if regeneration is needed.

    Fields:
        question_id: ID of the question being analyzed
        overlap_score: Overlap score (0.0-1.0) representing match percentage
        matched_tokens: List of tokens that matched between content and question
        total_question_tokens: Total number of tokens in the question
        overlap_percentage: Percentage of question tokens that matched (0-100)

    Example:
        >>> from faq_impact.core.models import TokenOverlapResult
        >>>
        >>> # Create token overlap result
        >>> result = TokenOverlapResult(
        ...     question_id=123,
        ...     overlap_score=0.75,
        ...     matched_tokens=["limit", "annual", "contribution"],
        ...     total_question_tokens=10,
        ...     overlap_percentage=75.0
        ... )
        >>>
        >>> # Check overlap thresholds
        >>> result.has_significant_overlap(threshold=0.7)
        True
        >>> result.has_high_overlap(threshold=0.9)
        False
        >>> result.get_matched_token_count()
        3

    Design Notes:
        - Used by ModifiedContentStrategy
        - High overlap (>70%) � likely needs regeneration
        - Low overlap (<30%) � likely no action needed
        - Medium overlap (30-70%) � needs LLM evaluation
    """

    question_id: int
    overlap_score: float
    matched_tokens: List[str]
    total_question_tokens: int
    overlap_percentage: float

    def __post_init__(self):
        """
        Validate the TokenOverlapResult after initialization.

        Raises:
            ValueError: If validation fails
        """
        # Validate overlap_score range
        if not (0.0 <= self.overlap_score <= 1.0):
            raise ValueError(
                f"overlap_score must be between 0.0 and 1.0, got {self.overlap_score}"
            )

        # Validate overlap_percentage range
        if not (0.0 <= self.overlap_percentage <= 100.0):
            raise ValueError(
                f"overlap_percentage must be between 0 and 100, "
                f"got {self.overlap_percentage}"
            )

        # Validate total_question_tokens
        if self.total_question_tokens <= 0:
            raise ValueError(
                f"total_question_tokens must be positive, got {self.total_question_tokens}"
            )

        # Validate matched_tokens count
        if len(self.matched_tokens) > self.total_question_tokens:
            raise ValueError(
                f"matched_tokens count ({len(self.matched_tokens)}) cannot exceed "
                f"total_question_tokens ({self.total_question_tokens})"
            )

        # Validate consistency between overlap_score and overlap_percentage
        expected_percentage = self.overlap_score * 100
        tolerance = 1.0  # Allow 1% tolerance for floating point
        if abs(expected_percentage - self.overlap_percentage) > tolerance:
            raise ValueError(
                f"overlap_percentage ({self.overlap_percentage}) is inconsistent "
                f"with overlap_score ({self.overlap_score}). "
                f"Expected approximately {expected_percentage}%"
            )

    def has_significant_overlap(self, threshold: float = 0.7) -> bool:
        """
        Check if overlap is significant (likely needs action).

        Args:
            threshold: Overlap threshold (default 0.7 = 70%)

        Returns:
            True if overlap_score >= threshold
        """
        return self.overlap_score >= threshold

    def has_high_overlap(self, threshold: float = 0.9) -> bool:
        """
        Check if overlap is very high (definitely needs regeneration).

        Args:
            threshold: Overlap threshold (default 0.9 = 90%)

        Returns:
            True if overlap_score >= threshold
        """
        return self.overlap_score >= threshold

    def has_low_overlap(self, threshold: float = 0.3) -> bool:
        """
        Check if overlap is low (likely no action needed).

        Args:
            threshold: Overlap threshold (default 0.3 = 30%)

        Returns:
            True if overlap_score < threshold
        """
        return self.overlap_score < threshold

    def is_ambiguous(self, low_threshold: float = 0.3, high_threshold: float = 0.7) -> bool:
        """
        Check if overlap is in ambiguous range (needs LLM evaluation).

        Args:
            low_threshold: Low threshold (default 0.3)
            high_threshold: High threshold (default 0.7)

        Returns:
            True if overlap is between low and high thresholds
        """
        return low_threshold <= self.overlap_score < high_threshold

    def get_matched_token_count(self) -> int:
        """
        Get the count of matched tokens.

        Returns:
            Number of tokens that matched
        """
        return len(self.matched_tokens)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert TokenOverlapResult to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "question_id": self.question_id,
            "overlap_score": self.overlap_score,
            "matched_tokens": self.matched_tokens,
            "total_question_tokens": self.total_question_tokens,
            "overlap_percentage": self.overlap_percentage,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TokenOverlapResult":
        """
        Create TokenOverlapResult from dictionary.

        Args:
            data: Dictionary with token overlap fields

        Returns:
            TokenOverlapResult instance
        """
        return cls(
            question_id=data["question_id"],
            overlap_score=data["overlap_score"],
            matched_tokens=data.get("matched_tokens", []),
            total_question_tokens=data["total_question_tokens"],
            overlap_percentage=data["overlap_percentage"],
        )


# Convenience exports
__all__ = [
    "DetectionContext",
    "SourceCountResult",
    "TokenOverlapResult",
]
