"""
ImpactDecision and ImpactSummary Data Classes

This module defines immutable value objects for impact decisions and their
aggregated summaries in the FAQ impact analysis system.

Classes:
    - ImpactDecision: Represents a single impact decision (planned action)
    - ImpactSummary: Aggregated metrics across multiple impact decisions

Author: Analytics Assist Team
Date: 2025-11-02
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List
import json

from ..enums.entity_type import EntityType
from ..enums.decision_type import DecisionType
from ..enums.reason_code import ReasonCode


@dataclass(frozen=True)
class ImpactDecision:
    """
    Immutable value object representing a single impact decision.

    An ImpactDecision represents a planned action (decision) to be taken in
    response to a content change. It is created during the ANALYSIS phase
    (read-only) and executed during the APPLY PLAN phase (mutations).

    Fields:
        impact_id: Unique identifier for this impact decision (UUID or auto-increment)
        entity_type: Type of entity this decision applies to (QUESTION, ANSWER, CHANGE)
        entity_id: ID of the specific entity (question_id, answer_id, or change_id)
                   May be None for PLAN_CREATE (entity doesn't exist yet)
        change_id: ID of the content change that triggered this decision
        detection_run_id: ID of the detection run that identified the change
        decision: The decision type (WHAT to do: PLAN_CREATE, REGEN_Q, etc.)
        reason: The reason code (WHY doing it: NEW_CONTENT_ADDED, etc.)
        details: Additional context as dictionary (scores, tokens, metadata)
        created_at: Timestamp when decision was created
        applied: Whether decision has been executed (False = pending)
        applied_at: Timestamp when decision was applied (None if not applied)
        applied_by: Who/what applied the decision (user ID, system name, etc.)
        application_error: Error message if application failed (None if success)

    Example:
        >>> from faq_impact.core.models import ImpactDecision
        >>> from faq_impact.core.enums import EntityType, DecisionType, ReasonCode
        >>> from datetime import datetime
        >>>
        >>> # Create a PLAN_CREATE decision for new content
        >>> decision = ImpactDecision(
        ...     impact_id=123,
        ...     entity_type=EntityType.QUESTION,
        ...     entity_id=None,  # Question doesn't exist yet
        ...     change_id=456,
        ...     detection_run_id="run_001",
        ...     decision=DecisionType.PLAN_CREATE,
        ...     reason=ReasonCode.NEW_CONTENT_ADDED,
        ...     details={"chunk_id": 789, "content_checksum": "abc123"},
        ...     created_at=datetime.now(),
        ...     applied=False,
        ...     applied_at=None,
        ...     applied_by=None,
        ...     application_error=None,
        ... )
        >>>
        >>> # Convert to dictionary for storage
        >>> decision_dict = decision.to_dict()
        >>> decision_dict['decision']
        'PLAN_CREATE'
        >>>
        >>> # Recreate from dictionary
        >>> restored = ImpactDecision.from_dict(decision_dict)
        >>> restored.impact_id
        123

    Design Notes:
        - Frozen dataclass ensures immutability (values cannot change after creation)
        - Validation happens in __post_init__ to catch errors early
        - to_dict/from_dict enable serialization for database storage
        - details field is flexible JSON for decision-specific context
    """

    impact_id: int
    entity_type: EntityType
    entity_id: Optional[int]
    change_id: int
    detection_run_id: str
    decision: DecisionType
    reason: ReasonCode
    details: Dict[str, Any]
    created_at: datetime
    applied: bool
    applied_at: Optional[datetime]
    applied_by: Optional[str]
    application_error: Optional[str]

    def __post_init__(self):
        """
        Validate the ImpactDecision after initialization.

        Raises:
            ValueError: If validation fails (invalid enum combinations, etc.)
        """
        # Validate decision-reason compatibility
        if not ReasonCode.is_compatible(self.decision, self.reason):
            raise ValueError(
                f"Reason '{self.reason.value}' is not compatible with "
                f"decision '{self.decision.value}'. "
                f"Valid reasons: {[r.value for r in ReasonCode.get_reasons_for_decision(self.decision)]}"
            )

        # Validate entity_id based on decision type
        if self.decision == DecisionType.PLAN_CREATE:
            # PLAN_CREATE should have entity_id=None (entity doesn't exist yet)
            if self.entity_id is not None:
                raise ValueError(
                    f"PLAN_CREATE decision should have entity_id=None, got {self.entity_id}"
                )
        else:
            # Other decisions should have entity_id (operating on existing entities)
            # Exception: CHANGE entity type can have entity_id = change_id
            if self.entity_type != EntityType.CHANGE and self.entity_id is None:
                raise ValueError(
                    f"{self.decision.value} decision for {self.entity_type.value} "
                    f"must have entity_id, got None"
                )

        # Validate entity_type based on decision type
        if self.decision == DecisionType.PLAN_CREATE:
            if self.entity_type != EntityType.QUESTION:
                raise ValueError(
                    f"PLAN_CREATE decision must have entity_type=QUESTION, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision == DecisionType.REGEN_A:
            if self.entity_type != EntityType.ANSWER:
                raise ValueError(
                    f"REGEN_A decision must have entity_type=ANSWER, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision in {DecisionType.REGEN_Q, DecisionType.REGEN_BOTH, DecisionType.INACTIVATE}:
            # These can be QUESTION or ANSWER
            if self.entity_type == EntityType.CHANGE:
                raise ValueError(
                    f"{self.decision.value} decision cannot have entity_type=CHANGE, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision in {DecisionType.EVALUATE, DecisionType.NOOP}:
            # These typically use CHANGE entity type
            if self.entity_type != EntityType.CHANGE:
                raise ValueError(
                    f"{self.decision.value} decision should have entity_type=CHANGE, "
                    f"got {self.entity_type.value}"
                )

        # Validate details is a dict
        if not isinstance(self.details, dict):
            raise ValueError(f"details must be a dictionary, got {type(self.details)}")

        # Validate applied/applied_at consistency
        if self.applied and self.applied_at is None:
            raise ValueError("If applied=True, applied_at must be set")
        if not self.applied and self.applied_at is not None:
            raise ValueError("If applied=False, applied_at must be None")

    def validate_decision_reason_compatibility(self) -> bool:
        """
        Validate that the decision type and reason code are compatible.

        This is a standalone validation method that can be called independently
        to verify decision-reason compatibility. It's also called in __post_init__.

        Returns:
            True if decision and reason are compatible

        Raises:
            ValueError: If decision and reason are incompatible

        Example:
            >>> decision = ImpactDecision(...)
            >>> decision.validate_decision_reason_compatibility()
            True
        """
        if not ReasonCode.is_compatible(self.decision, self.reason):
            raise ValueError(
                f"Decision-Reason mismatch: {self.decision.value} is not compatible "
                f"with reason {self.reason.value}. "
                f"Valid reasons for {self.decision.value}: "
                f"{[r.value for r in ReasonCode.get_reasons_for_decision(self.decision)]}"
            )
        return True

    def validate_entity_reference(self) -> bool:
        """
        Validate that entity_type and entity_id references are correct.

        Validates:
        - PLAN_CREATE must have entity_id=None (entity doesn't exist yet)
        - Non-PLAN_CREATE decisions must have entity_id (except CHANGE entity type)
        - Entity types match decision types (e.g., REGEN_A → ANSWER entity)

        Returns:
            True if entity references are valid

        Raises:
            ValueError: If entity references are invalid

        Example:
            >>> decision = ImpactDecision(...)
            >>> decision.validate_entity_reference()
            True
        """
        # Validate entity_id for PLAN_CREATE
        if self.decision == DecisionType.PLAN_CREATE:
            if self.entity_id is not None:
                raise ValueError(
                    f"PLAN_CREATE decision must have entity_id=None (entity doesn't exist yet), "
                    f"got entity_id={self.entity_id}"
                )
            if self.entity_type != EntityType.QUESTION:
                raise ValueError(
                    f"PLAN_CREATE decision must target QUESTION entity, "
                    f"got {self.entity_type.value}"
                )

        # Validate entity_id for non-PLAN_CREATE
        else:
            if self.entity_type != EntityType.CHANGE and self.entity_id is None:
                raise ValueError(
                    f"{self.decision.value} decision for {self.entity_type.value} "
                    f"must have entity_id (entity must exist), got None"
                )

        # Validate entity_type matches decision type
        if self.decision == DecisionType.REGEN_A:
            if self.entity_type != EntityType.ANSWER:
                raise ValueError(
                    f"REGEN_A decision must target ANSWER entity, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision in {DecisionType.REGEN_Q, DecisionType.REGEN_BOTH}:
            if self.entity_type not in {EntityType.QUESTION, EntityType.ANSWER}:
                raise ValueError(
                    f"{self.decision.value} decision must target QUESTION or ANSWER entity, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision == DecisionType.INACTIVATE:
            if self.entity_type == EntityType.CHANGE:
                raise ValueError(
                    f"INACTIVATE decision cannot target CHANGE entity, "
                    f"got {self.entity_type.value}"
                )
        elif self.decision in {DecisionType.EVALUATE, DecisionType.NOOP}:
            if self.entity_type != EntityType.CHANGE:
                raise ValueError(
                    f"{self.decision.value} decision should target CHANGE entity, "
                    f"got {self.entity_type.value}"
                )

        return True

    def validate_details_schema(self) -> bool:
        """
        Validate that the details dictionary contains expected fields.

        Different decision types expect different fields in the details dict:
        - PLAN_CREATE: chunk_id, content_checksum
        - REGEN_Q/A/BOTH: similarity_score, token_overlap, etc.
        - INACTIVATE: inactivation_reason, affected_entities
        - EVALUATE: evaluation_criteria, confidence_score

        Returns:
            True if details schema is valid

        Raises:
            ValueError: If required fields are missing or invalid

        Example:
            >>> decision = ImpactDecision(
            ...     decision=DecisionType.PLAN_CREATE,
            ...     details={"chunk_id": 123, "content_checksum": "abc"}
            ... )
            >>> decision.validate_details_schema()
            True
        """
        if not isinstance(self.details, dict):
            raise ValueError(f"details must be a dictionary, got {type(self.details)}")

        # Validate required fields based on decision type
        if self.decision == DecisionType.PLAN_CREATE:
            required_fields = ["chunk_id", "content_checksum"]
            missing_fields = [f for f in required_fields if f not in self.details]
            if missing_fields:
                raise ValueError(
                    f"PLAN_CREATE decision missing required details fields: {missing_fields}. "
                    f"Required: {required_fields}"
                )

        elif self.decision in {DecisionType.REGEN_Q, DecisionType.REGEN_A, DecisionType.REGEN_BOTH}:
            # Regeneration decisions should have similarity or token overlap info
            has_similarity = "similarity_score" in self.details
            has_token_overlap = "token_overlap" in self.details or "token_overlap_score" in self.details
            if not (has_similarity or has_token_overlap):
                raise ValueError(
                    f"{self.decision.value} decision should include similarity_score "
                    f"or token_overlap in details for auditability"
                )

        elif self.decision == DecisionType.INACTIVATE:
            # Inactivation should explain what's being inactivated
            if "affected_entity_count" not in self.details and "entity_ids" not in self.details:
                raise ValueError(
                    f"INACTIVATE decision should include affected_entity_count or "
                    f"entity_ids in details for audit trail"
                )

        elif self.decision == DecisionType.EVALUATE:
            # Evaluation decisions should have evaluation criteria
            if "evaluation_criteria" not in self.details and "confidence_score" not in self.details:
                raise ValueError(
                    f"EVALUATE decision should include evaluation_criteria or "
                    f"confidence_score in details"
                )

        # Validate JSON-serializable (no complex objects)
        try:
            json.dumps(self.details)
        except (TypeError, ValueError) as e:
            raise ValueError(f"details must be JSON-serializable: {e}")

        return True

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert ImpactDecision to dictionary for database storage.

        Returns:
            Dictionary representation with enum values as strings

        Example:
            >>> decision = ImpactDecision(...)
            >>> d = decision.to_dict()
            >>> d['decision']
            'PLAN_CREATE'
            >>> d['entity_type']
            'QUESTION'
        """
        return {
            "impact_id": self.impact_id,
            "entity_type": self.entity_type.value,
            "entity_id": self.entity_id,
            "change_id": self.change_id,
            "detection_run_id": self.detection_run_id,
            "decision": self.decision.value,
            "reason": self.reason.value,
            "details": json.dumps(self.details) if self.details else "{}",
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "applied": self.applied,
            "applied_at": self.applied_at.isoformat() if self.applied_at else None,
            "applied_by": self.applied_by,
            "application_error": self.application_error,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImpactDecision":
        """
        Create ImpactDecision from dictionary (e.g., database row).

        Args:
            data: Dictionary with impact decision fields

        Returns:
            ImpactDecision instance

        Raises:
            ValueError: If data is invalid or enums cannot be parsed

        Example:
            >>> data = {
            ...     "impact_id": 123,
            ...     "entity_type": "QUESTION",
            ...     "entity_id": None,
            ...     "change_id": 456,
            ...     "detection_run_id": "run_001",
            ...     "decision": "PLAN_CREATE",
            ...     "reason": "NEW_CONTENT_ADDED",
            ...     "details": '{"chunk_id": 789}',
            ...     "created_at": "2025-11-02T10:00:00",
            ...     "applied": False,
            ...     "applied_at": None,
            ...     "applied_by": None,
            ...     "application_error": None,
            ... }
            >>> decision = ImpactDecision.from_dict(data)
            >>> decision.impact_id
            123
        """
        # Parse enums
        entity_type = EntityType.from_string(data["entity_type"])
        decision = DecisionType.from_string(data["decision"])
        reason = ReasonCode.from_string(data["reason"])

        # Parse details JSON
        details_str = data.get("details", "{}")
        if isinstance(details_str, str):
            details = json.loads(details_str) if details_str else {}
        else:
            details = details_str  # Already a dict

        # Parse timestamps
        created_at = None
        if data.get("created_at"):
            if isinstance(data["created_at"], str):
                created_at = datetime.fromisoformat(data["created_at"])
            elif isinstance(data["created_at"], datetime):
                created_at = data["created_at"]

        applied_at = None
        if data.get("applied_at"):
            if isinstance(data["applied_at"], str):
                applied_at = datetime.fromisoformat(data["applied_at"])
            elif isinstance(data["applied_at"], datetime):
                applied_at = data["applied_at"]

        return cls(
            impact_id=data["impact_id"],
            entity_type=entity_type,
            entity_id=data.get("entity_id"),
            change_id=data["change_id"],
            detection_run_id=data["detection_run_id"],
            decision=decision,
            reason=reason,
            details=details,
            created_at=created_at,
            applied=data.get("applied", False),
            applied_at=applied_at,
            applied_by=data.get("applied_by"),
            application_error=data.get("application_error"),
        )

    def is_pending(self) -> bool:
        """
        Check if this decision is pending (not yet applied).

        Returns:
            True if decision has not been applied yet
        """
        return not self.applied

    def is_mutation(self) -> bool:
        """
        Check if this decision causes database mutations.

        Returns:
            True if decision modifies questions/answers tables
        """
        return self.decision.is_mutation()

    def requires_generation(self) -> bool:
        """
        Check if this decision requires LLM generation.

        Returns:
            True if decision needs to call generation services
        """
        return self.decision.requires_generation()

    def get_summary_line(self) -> str:
        """
        Get a one-line summary of this decision for logging/display.

        Returns:
            Human-readable summary string

        Example:
            >>> decision.get_summary_line()
            '[PLAN_CREATE] NEW_CONTENT_ADDED for QUESTION (change_id=456)'
        """
        entity_id_str = f"entity_id={self.entity_id}" if self.entity_id else "new entity"
        return (
            f"[{self.decision.value}] {self.reason.value} for "
            f"{self.entity_type.value} ({entity_id_str}, change_id={self.change_id})"
        )


@dataclass(frozen=True)
class ImpactSummary:
    """
    Aggregated metrics across multiple impact decisions.

    ImpactSummary provides a high-level view of impact analysis results,
    used for dashboards, reports, and cost estimation.

    Fields:
        total_impacts: Total number of impact decisions
        decisions_by_type: Count of decisions grouped by DecisionType
                          e.g., {"PLAN_CREATE": 5, "REGEN_A": 3, ...}
        decisions_by_reason: Count of decisions grouped by ReasonCode
                            e.g., {"NEW_CONTENT_ADDED": 5, "TOKEN_OVERLAP_DETECTED": 2}
        entities_affected: Count of affected entities by type
                          e.g., {"QUESTION": 8, "ANSWER": 12}
        estimated_cost: Estimated cost for applying all decisions (API calls, etc.)

    Example:
        >>> from faq_impact.core.models import ImpactSummary
        >>>
        >>> summary = ImpactSummary(
        ...     total_impacts=10,
        ...     decisions_by_type={"PLAN_CREATE": 5, "REGEN_A": 3, "INACTIVATE": 2},
        ...     decisions_by_reason={"NEW_CONTENT_ADDED": 5, "TOKEN_OVERLAP_DETECTED": 3},
        ...     entities_affected={"QUESTION": 5, "ANSWER": 5},
        ...     estimated_cost=0.25  # $0.25 in API costs
        ... )
        >>>
        >>> summary.get_mutation_count()
        10
        >>> summary.get_generation_count()
        8

    Design Notes:
        - Frozen dataclass for immutability
        - Used for high-level reporting and cost estimation
        - Can be created from a list of ImpactDecision objects
    """

    total_impacts: int
    decisions_by_type: Dict[str, int]
    decisions_by_reason: Dict[str, int]
    entities_affected: Dict[str, int]
    estimated_cost: float

    def get_mutation_count(self) -> int:
        """
        Get count of decisions that cause database mutations.

        Returns:
            Number of mutation decisions (PLAN_CREATE, REGEN_*, INACTIVATE)
        """
        mutation_types = [
            DecisionType.PLAN_CREATE.value,
            DecisionType.REGEN_Q.value,
            DecisionType.REGEN_A.value,
            DecisionType.REGEN_BOTH.value,
            DecisionType.INACTIVATE.value,
        ]
        return sum(
            count
            for decision_type, count in self.decisions_by_type.items()
            if decision_type in mutation_types
        )

    def get_generation_count(self) -> int:
        """
        Get count of decisions that require LLM generation.

        Returns:
            Number of generation decisions (PLAN_CREATE, REGEN_*)
        """
        generation_types = [
            DecisionType.PLAN_CREATE.value,
            DecisionType.REGEN_Q.value,
            DecisionType.REGEN_A.value,
            DecisionType.REGEN_BOTH.value,
        ]
        return sum(
            count
            for decision_type, count in self.decisions_by_type.items()
            if decision_type in generation_types
        )

    def get_inactivation_count(self) -> int:
        """
        Get count of inactivation decisions.

        Returns:
            Number of INACTIVATE decisions
        """
        return self.decisions_by_type.get(DecisionType.INACTIVATE.value, 0)

    @classmethod
    def from_decisions(cls, decisions: List[ImpactDecision], cost_per_generation: float = 0.03) -> "ImpactSummary":
        """
        Create ImpactSummary from a list of ImpactDecision objects.

        Args:
            decisions: List of ImpactDecision objects
            cost_per_generation: Estimated cost per LLM generation call (default $0.03)

        Returns:
            ImpactSummary with aggregated metrics

        Example:
            >>> decisions = [decision1, decision2, decision3]
            >>> summary = ImpactSummary.from_decisions(decisions)
            >>> summary.total_impacts
            3
        """
        # Count by type
        decisions_by_type: Dict[str, int] = {}
        for decision in decisions:
            decision_type = decision.decision.value
            decisions_by_type[decision_type] = decisions_by_type.get(decision_type, 0) + 1

        # Count by reason
        decisions_by_reason: Dict[str, int] = {}
        for decision in decisions:
            reason = decision.reason.value
            decisions_by_reason[reason] = decisions_by_reason.get(reason, 0) + 1

        # Count entities affected
        entities_affected: Dict[str, int] = {}
        for decision in decisions:
            entity_type = decision.entity_type.value
            entities_affected[entity_type] = entities_affected.get(entity_type, 0) + 1

        # Estimate cost (only generation decisions incur API costs)
        generation_count = sum(
            1 for d in decisions if d.requires_generation()
        )
        estimated_cost = generation_count * cost_per_generation

        return cls(
            total_impacts=len(decisions),
            decisions_by_type=decisions_by_type,
            decisions_by_reason=decisions_by_reason,
            entities_affected=entities_affected,
            estimated_cost=estimated_cost,
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert ImpactSummary to dictionary for serialization.

        Returns:
            Dictionary representation
        """
        return {
            "total_impacts": self.total_impacts,
            "decisions_by_type": self.decisions_by_type,
            "decisions_by_reason": self.decisions_by_reason,
            "entities_affected": self.entities_affected,
            "estimated_cost": self.estimated_cost,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImpactSummary":
        """
        Create ImpactSummary from dictionary.

        Args:
            data: Dictionary with summary fields

        Returns:
            ImpactSummary instance
        """
        return cls(
            total_impacts=data["total_impacts"],
            decisions_by_type=data["decisions_by_type"],
            decisions_by_reason=data["decisions_by_reason"],
            entities_affected=data["entities_affected"],
            estimated_cost=data["estimated_cost"],
        )


# Convenience exports
__all__ = [
    "ImpactDecision",
    "ImpactSummary",
]
