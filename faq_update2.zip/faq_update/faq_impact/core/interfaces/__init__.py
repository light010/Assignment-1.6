"""
Core Interfaces - Abstract Base Classes and Protocols

This module defines the contracts and interfaces for FAQ impact analysis.
Interfaces enable dependency inversion and make components testable and
pluggable.

Key Interfaces:

    Analysis Phase:
        - IImpactAnalyzer: Main analyzer orchestrator for content change analysis
        - IAnalysisStrategy: Strategy pattern for different change types (NEW/MODIFIED/DELETED)
        - ITokenMatcher: Token-based similarity matching for questions
        - ISourceCounter: Dynamic source counting for orphan detection

    Application Phase:
        - IImpactApplicator: Main applicator orchestrator for executing decisions
        - IExecutor: Strategy pattern for different decision types (CREATE/REGEN/INACTIVATE)
        - IProvenanceRoller: Temporal provenance management (roll forward validity)

    Evaluation:
        - ILLMEvaluator: LLM-based answer validity evaluation

Design Patterns:
    - Strategy Pattern: Pluggable analysis and execution strategies
    - Dependency Inversion: Depend on abstractions, not concretions
    - Interface Segregation: Focused, single-purpose interfaces
    - Command Pattern: Impact decisions as executable commands

Usage:
    >>> from faq_impact.core.interfaces import IImpactAnalyzer, IAnalysisStrategy
    >>> from faq_impact.core.models import DetectionContext, ImpactDecision
    >>>
    >>> # Implement a custom analysis strategy
    >>> class CustomStrategy(IAnalysisStrategy):
    ...     def can_handle(self, change_type: str) -> bool:
    ...         return change_type == "CUSTOM"
    ...
    ...     def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
    ...         # Custom implementation
    ...         return [ImpactDecision(...)]
    >>>
    >>> # Use the analyzer with dependency injection
    >>> analyzer: IImpactAnalyzer = ImpactAnalyzer([CustomStrategy()])
    >>> decisions = analyzer.analyze_change(context)

See Also:
    - PATTERNS.md: Detailed documentation of design patterns and best practices
    - analyzer.py: Analysis phase interfaces
    - applicator.py: Application phase interfaces
    - evaluator.py: Evaluation interfaces

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Analysis Phase Interfaces
from faq_impact.core.interfaces.analyzer import (
    IImpactAnalyzer,
    IAnalysisStrategy,
    ITokenMatcher,
    ISourceCounter,
)

# Application Phase Interfaces
from faq_impact.core.interfaces.applicator import (
    IImpactApplicator,
    IExecutor,
    IProvenanceRoller,
)

# Evaluation Interfaces
from faq_impact.core.interfaces.evaluator import (
    ILLMEvaluator,
)

# Export all interfaces for easy importing
__all__ = [
    # Analysis Phase
    "IImpactAnalyzer",
    "IAnalysisStrategy",
    "ITokenMatcher",
    "ISourceCounter",
    # Application Phase
    "IImpactApplicator",
    "IExecutor",
    "IProvenanceRoller",
    # Evaluation
    "ILLMEvaluator",
]
