"""
Analyzer Interfaces - Abstract Base Classes for Impact Analysis

This module defines the core interfaces for the impact analysis phase of the
FAQ impact system. These interfaces enable dependency injection, testability,
and pluggable analysis strategies.

Key Interfaces:
    - IImpactAnalyzer: Main analyzer orchestrator interface
    - IAnalysisStrategy: Strategy pattern for handling different change types
    - ITokenMatcher: Token-based similarity matching interface
    - ISourceCounter: Dynamic source counting interface

Design Patterns:
    - Strategy Pattern: IAnalysisStrategy for different change types
    - Dependency Inversion: Depend on abstractions, not concretions
    - Interface Segregation: Focused, single-purpose interfaces

Usage:
    >>> from faq_impact.core.interfaces import IImpactAnalyzer
    >>> from faq_impact.core.models import DetectionContext
    >>>
    >>> class MyAnalyzer(IImpactAnalyzer):
    ...     def analyze_change(self, context: DetectionContext) -> List[ImpactDecision]:
    ...         # Implementation here
    ...         pass

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from typing import List, TYPE_CHECKING

# Use TYPE_CHECKING to avoid circular imports at runtime
if TYPE_CHECKING:
    from faq_impact.core.models.detection_context import (
        DetectionContext,
        TokenOverlapResult,
        SourceCountResult,
    )
    from faq_impact.core.models.impact_decision import ImpactDecision
    from faq_impact.core.enums.decision_type import DecisionType


class IImpactAnalyzer(ABC):
    """
    Main interface for impact analysis orchestration.

    The IImpactAnalyzer is the primary entry point for analyzing content changes
    and generating impact decisions. It receives a DetectionContext (containing
    change information) and returns a list of ImpactDecision objects representing
    planned actions.

    **Responsibilities**:
        - Orchestrate the impact analysis process
        - Delegate to appropriate analysis strategies based on change type
        - Aggregate results from multiple strategies
        - Validate and deduplicate impact decisions
        - Return complete set of decisions for a given change

    **Phase**: Analysis Phase (read-only, no mutations)

    **When to Use**:
        - You need to analyze a detected content change
        - You want to generate impact decisions without applying them
        - You're implementing the planning phase of impact analysis

    **When NOT to Use**:
        - You need to execute/apply decisions (use IImpactApplicator instead)
        - You're implementing a specific change type strategy (use IAnalysisStrategy)

    Example:
        >>> from faq_impact.core.interfaces import IImpactAnalyzer
        >>> from faq_impact.core.models import DetectionContext
        >>>
        >>> analyzer: IImpactAnalyzer = get_analyzer()  # Dependency injection
        >>> context = DetectionContext(
        ...     detection_run_id=1,
        ...     change_id=123,
        ...     change_type="MODIFIED_CONTENT",
        ...     content_checksum="new_hash",
        ...     previous_checksum="old_hash"
        ... )
        >>> decisions = analyzer.analyze_change(context)
        >>> for decision in decisions:
        ...     print(f"{decision.decision_type}: {decision.reason_code}")

    Implementation Notes:
        - Implementations should be stateless or thread-safe
        - Should use IAnalysisStrategy instances for change-type-specific logic
        - Must not perform any database mutations (read-only phase)
        - Should handle errors gracefully and return EVALUATE decisions for edge cases
        - Should deduplicate decisions to avoid redundant actions

    See Also:
        - IAnalysisStrategy: For implementing change-type-specific analysis
        - IImpactApplicator: For executing the generated decisions
        - DetectionContext: Input data structure
        - ImpactDecision: Output data structure
    """

    @abstractmethod
    def analyze_change(
        self, context: "DetectionContext"
    ) -> List["ImpactDecision"]:
        """
        Analyze a content change and generate impact decisions.

        This is the main entry point for impact analysis. Given a DetectionContext
        containing information about a detected content change, this method analyzes
        the impact and returns a list of decisions representing planned actions.

        Args:
            context: DetectionContext containing change information including:
                - detection_run_id: ID of the current detection run
                - change_id: ID of the content change being analyzed
                - change_type: Type of change (NEW_CONTENT, MODIFIED_CONTENT, DELETED_CONTENT)
                - content_checksum: New content checksum
                - previous_checksum: Previous content checksum (if applicable)
                - diff_data: Optional diff information
                - similarity_score: Optional similarity score
                - file_name: Source file name
                - metadata: Additional context data

        Returns:
            List[ImpactDecision]: List of impact decisions to be recorded.
                Each decision contains:
                - entity_type: QUESTION, ANSWER, or CHANGE
                - entity_id: ID of affected entity (or None for new creations)
                - decision_type: PLAN_CREATE, REGEN_Q, REGEN_A, INACTIVATE, etc.
                - reason_code: Detailed reason for the decision
                - details: Additional context and metadata

        Raises:
            ValueError: If context is invalid or missing required fields
            RuntimeError: If analysis fails due to system errors

        Example:
            >>> context = DetectionContext(
            ...     detection_run_id=1,
            ...     change_id=100,
            ...     change_type="NEW_CONTENT",
            ...     content_checksum="abc123"
            ... )
            >>> decisions = analyzer.analyze_change(context)
            >>> assert len(decisions) > 0
            >>> assert decisions[0].decision_type == DecisionType.PLAN_CREATE

        Implementation Guidelines:
            1. Validate the input context
            2. Determine which strategy to use based on change_type
            3. Invoke the appropriate strategy's analyze() method
            4. Aggregate and deduplicate results
            5. Validate decision-reason compatibility
            6. Return complete list of decisions

        Notes:
            - This method is read-only and should not modify database state
            - Multiple decisions can be returned for a single change
            - Decisions are recorded but not yet applied/executed
            - Edge cases should return EVALUATE decisions for manual review
        """
        pass


class IAnalysisStrategy(ABC):
    """
    Strategy interface for analyzing specific types of content changes.

    The IAnalysisStrategy interface implements the Strategy Pattern, allowing
    different analysis logic for different change types (NEW_CONTENT,
    MODIFIED_CONTENT, DELETED_CONTENT). Each strategy encapsulates the specific
    decision-making logic for its change type.

    **Responsibilities**:
        - Determine if the strategy can handle a given change type
        - Analyze changes of a specific type
        - Generate appropriate impact decisions
        - Use supporting services (token matcher, source counter, etc.)

    **Strategy Types**:
        - NewContentStrategy: Handles NEW_CONTENT changes (generates PLAN_CREATE)
        - ModifiedContentStrategy: Handles MODIFIED_CONTENT (token overlap, similarity)
        - DeletedContentStrategy: Handles DELETED_CONTENT (sole source vs multi-source)

    **When to Use**:
        - You're implementing analysis logic for a specific change type
        - You want to extend the system with new change type handling
        - You need to customize decision-making logic

    **When NOT to Use**:
        - You need orchestration across multiple strategies (use IImpactAnalyzer)
        - You're executing decisions (use IExecutor instead)

    Example:
        >>> from faq_impact.core.interfaces import IAnalysisStrategy
        >>>
        >>> class NewContentStrategy(IAnalysisStrategy):
        ...     def can_handle(self, change_type: str) -> bool:
        ...         return change_type == "NEW_CONTENT"
        ...
        ...     def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        ...         # Generate PLAN_CREATE decisions for new content
        ...         return [ImpactDecision(...)]
        >>>
        >>> strategy = NewContentStrategy()
        >>> if strategy.can_handle("NEW_CONTENT"):
        ...     decisions = strategy.analyze(context)

    Implementation Notes:
        - Each strategy should handle exactly one change type
        - Use can_handle() to determine strategy applicability
        - Leverage supporting services (ITokenMatcher, ISourceCounter)
        - Return empty list if no decisions needed (NOOP case)
        - Return EVALUATE decisions for ambiguous cases

    See Also:
        - IImpactAnalyzer: Orchestrator that uses strategies
        - ITokenMatcher: For token-based similarity analysis
        - ISourceCounter: For dynamic source counting
    """

    @abstractmethod
    def can_handle(self, change_type: str) -> bool:
        """
        Determine if this strategy can handle the given change type.

        This method is used by the analyzer to select the appropriate strategy
        for a given change type. Each strategy should return True for exactly
        one change type.

        Args:
            change_type: String representing the type of change
                Typical values: "NEW_CONTENT", "MODIFIED_CONTENT", "DELETED_CONTENT"

        Returns:
            bool: True if this strategy can handle the change type, False otherwise

        Example:
            >>> strategy = NewContentStrategy()
            >>> strategy.can_handle("NEW_CONTENT")
            True
            >>> strategy.can_handle("MODIFIED_CONTENT")
            False

        Notes:
            - Should be a simple, fast check (no I/O operations)
            - Typically just compares change_type to a constant
            - Used for strategy selection in the analyzer
        """
        pass

    @abstractmethod
    def analyze(
        self, context: "DetectionContext"
    ) -> List["ImpactDecision"]:
        """
        Analyze a content change and generate impact decisions.

        This method contains the core analysis logic for this strategy's
        change type. It examines the change context and generates appropriate
        impact decisions based on business rules.

        Args:
            context: DetectionContext containing change information
                See IImpactAnalyzer.analyze_change() for context details

        Returns:
            List[ImpactDecision]: List of impact decisions generated by this strategy
                Can be empty list if no actions needed (NOOP case)

        Raises:
            ValueError: If context is invalid for this strategy
            RuntimeError: If analysis fails due to system errors

        Example:
            >>> context = DetectionContext(
            ...     change_type="NEW_CONTENT",
            ...     content_checksum="abc123"
            ... )
            >>> strategy = NewContentStrategy()
            >>> decisions = strategy.analyze(context)
            >>> assert all(d.decision_type == DecisionType.PLAN_CREATE for d in decisions)

        Implementation Guidelines:
            1. Validate context is appropriate for this strategy
            2. Query necessary data (questions, answers, sources)
            3. Apply business rules to determine decisions
            4. Use supporting services as needed
            5. Create ImpactDecision objects with proper reason codes
            6. Return list of decisions (or empty list for NOOP)

        Notes:
            - Should be idempotent (same input → same output)
            - Should not modify database state (read-only)
            - Can use ITokenMatcher, ISourceCounter, etc.
            - Should return EVALUATE for ambiguous cases
        """
        pass


class ITokenMatcher(ABC):
    """
    Interface for token-based similarity matching.

    The ITokenMatcher interface provides token-level analysis to detect
    questions that may be affected by content changes. It uses token overlap
    analysis to identify questions with significant lexical similarity to
    changed content.

    **Responsibilities**:
        - Tokenize changed content
        - Find questions with overlapping tokens
        - Calculate overlap scores and percentages
        - Return ranked results

    **Use Cases**:
        - Modified content strategy: Find questions affected by content edits
        - Token overlap detection: Identify high-overlap questions for regeneration
        - Similarity analysis: Complement semantic similarity with lexical analysis

    **When to Use**:
        - You need to find questions similar to changed content
        - You want token-level (lexical) similarity analysis
        - You're implementing modified content strategy

    **When NOT to Use**:
        - You need semantic similarity (use existing SimilarityService instead)
        - You're counting sources (use ISourceCounter instead)
        - You're analyzing new content (no existing questions to match)

    Example:
        >>> from faq_impact.core.interfaces import ITokenMatcher
        >>>
        >>> matcher: ITokenMatcher = get_token_matcher()
        >>> changed_tokens = ["refund", "policy", "30", "days"]
        >>> results = matcher.find_overlapping_questions(changed_tokens)
        >>> for result in results:
        ...     if result.overlap_percentage > 0.7:
        ...         print(f"Question {result.question_id}: {result.overlap_percentage:.2%} overlap")

    Implementation Notes:
        - Should use efficient token matching algorithms
        - May leverage database full-text search capabilities
        - Should normalize tokens (lowercase, stemming, etc.)
        - Should filter out stop words if appropriate
        - Should rank results by overlap percentage

    See Also:
        - IAnalysisStrategy: Uses token matcher for modified content analysis
        - TokenOverlapResult: Return type for token matching
    """

    @abstractmethod
    def find_overlapping_questions(
        self, changed_tokens: List[str]
    ) -> List["TokenOverlapResult"]:
        """
        Find questions with significant token overlap with changed content.

        Given a list of tokens from changed content, this method searches for
        questions that share a significant number of tokens and returns ranked
        results with overlap metrics.

        Args:
            changed_tokens: List of tokens from the changed content.
                Tokens should be preprocessed (normalized, filtered) by caller.
                Example: ["refund", "policy", "30", "days", "purchase"]

        Returns:
            List[TokenOverlapResult]: List of questions with token overlap, sorted
                by overlap percentage (highest first). Each result contains:
                - question_id: ID of the overlapping question
                - overlap_score: Absolute number of overlapping tokens
                - matched_tokens: List of tokens that matched
                - total_question_tokens: Total tokens in the question
                - overlap_percentage: Overlap score / total question tokens

        Example:
            >>> tokens = ["refund", "policy", "return", "item"]
            >>> results = matcher.find_overlapping_questions(tokens)
            >>> for r in results:
            ...     print(f"Q{r.question_id}: {r.overlap_percentage:.1%} "
            ...           f"({r.overlap_score}/{r.total_question_tokens} tokens)")
            Q42: 75.0% (3/4 tokens)
            Q58: 50.0% (2/4 tokens)

        Implementation Guidelines:
            1. Query active questions from database
            2. Tokenize each question's text
            3. Calculate token overlap with changed_tokens
            4. Filter results by minimum threshold (e.g., >40% overlap)
            5. Sort by overlap_percentage descending
            6. Return TokenOverlapResult objects

        Notes:
            - Only considers active questions (is_active=True)
            - Should be case-insensitive
            - May use stemming or lemmatization for better matching
            - Results should be sorted by overlap percentage
            - Empty list returned if no overlapping questions found
        """
        pass


class ISourceCounter(ABC):
    """
    Interface for dynamic source counting and validation.

    The ISourceCounter interface provides methods to count valid sources for
    questions and answers, enabling sole-source detection and orphan identification.
    This is critical for determining whether entities should be inactivated or
    regenerated when sources change.

    **Responsibilities**:
        - Count valid sources for questions and answers
        - Determine if an entity is sole-source
        - Identify orphaned entities (no valid sources)
        - Track source checksums for validation

    **Use Cases**:
        - Deleted content strategy: Determine sole-source vs multi-source
        - Modified content strategy: Check if modified content is sole source
        - Orphan detection: Find questions/answers with no valid sources

    **Key Concepts**:
        - **Valid Source**: Content chunk with valid checksum and is_active=True
        - **Sole Source**: Question/answer has exactly 1 valid source
        - **Multi-Source**: Question/answer has 2+ valid sources
        - **Orphan**: Question/answer has 0 valid sources

    **When to Use**:
        - You need to count how many valid sources a question/answer has
        - You're determining whether to inactivate vs regenerate
        - You're implementing deleted or modified content strategies

    **When NOT to Use**:
        - You need token matching (use ITokenMatcher instead)
        - You're analyzing new content (no existing sources yet)
        - You're executing decisions (use IExecutor instead)

    Example:
        >>> from faq_impact.core.interfaces import ISourceCounter
        >>> from faq_impact.core.enums import EntityType
        >>>
        >>> counter: ISourceCounter = get_source_counter()
        >>> result = counter.count_valid_sources(EntityType.QUESTION, question_id=42)
        >>> if result.is_sole_source:
        ...     print(f"Question {result.question_id} has sole source: {result.source_checksums[0]}")
        ... elif result.valid_source_count == 0:
        ...     print(f"Question {result.question_id} is orphaned!")
        ... else:
        ...     print(f"Question {result.question_id} has {result.valid_source_count} sources")

    Implementation Notes:
        - Should query faq_question_source or faq_answer_source tables
        - Should join with content_chunks to validate is_active and checksums
        - Should handle both question and answer entities
        - Should be efficient for batch operations
        - Should cache results if called multiple times in same analysis run

    See Also:
        - IAnalysisStrategy: Uses source counter for decision-making
        - SourceCountResult: Return type for source counting
        - EntityType: Enum for specifying entity type
    """

    @abstractmethod
    def count_valid_sources(
        self, entity_type: "EntityType", entity_id: int
    ) -> "SourceCountResult":
        """
        Count valid sources for a question or answer.

        This method counts how many valid (active, current) sources exist for
        a given question or answer, and returns detailed information about
        those sources.

        Args:
            entity_type: EntityType enum specifying QUESTION or ANSWER
            entity_id: ID of the question or answer to count sources for

        Returns:
            SourceCountResult: Object containing:
                - question_id: Question ID (if entity_type=QUESTION) or None
                - answer_id: Answer ID (if entity_type=ANSWER) or None
                - valid_source_count: Number of valid sources found
                - is_sole_source: True if valid_source_count == 1
                - source_checksums: List of checksums for valid sources

        Raises:
            ValueError: If entity_type is not QUESTION or ANSWER
            ValueError: If entity_id is invalid (< 1)

        Example:
            >>> from faq_impact.core.enums import EntityType
            >>>
            >>> # Count sources for a question
            >>> result = counter.count_valid_sources(EntityType.QUESTION, 42)
            >>> assert result.question_id == 42
            >>> assert result.answer_id is None
            >>> if result.is_sole_source:
            ...     print("This question has a sole source")
            >>>
            >>> # Count sources for an answer
            >>> result = counter.count_valid_sources(EntityType.ANSWER, 100)
            >>> assert result.answer_id == 100
            >>> print(f"Answer has {result.valid_source_count} valid sources")

        Implementation Guidelines:
            1. Validate input parameters
            2. Query appropriate source table (question_source or answer_source)
            3. Join with content_chunks to check is_active=True
            4. Filter for current/valid checksums
            5. Count results and collect checksums
            6. Return SourceCountResult with all fields populated

        Notes:
            - Only counts sources where content chunk is_active=True
            - Only counts sources with valid, current checksums
            - is_sole_source is True iff valid_source_count == 1
            - source_checksums list may be empty if no valid sources
            - For QUESTION: queries faq_question_source table
            - For ANSWER: queries faq_answer_source table
        """
        pass


# Convenience exports
__all__ = [
    "IImpactAnalyzer",
    "IAnalysisStrategy",
    "ITokenMatcher",
    "ISourceCounter",
]
