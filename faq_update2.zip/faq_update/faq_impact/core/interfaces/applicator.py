"""
Applicator Interfaces - Abstract Base Classes for Decision Execution

This module defines the core interfaces for the application phase of the
FAQ impact system. These interfaces enable dependency injection, testability,
and pluggable execution strategies for applying impact decisions.

Key Interfaces:
    - IImpactApplicator: Main applicator orchestrator interface
    - IExecutor: Strategy pattern for executing different decision types
    - IProvenanceRoller: Temporal provenance management interface

Design Patterns:
    - Strategy Pattern: IExecutor for different decision types
    - Dependency Inversion: Depend on abstractions, not concretions
    - Command Pattern: Impact decisions as executable commands
    - Transaction Management: Atomic execution with rollback support

Usage:
    >>> from faq_impact.core.interfaces import IImpactApplicator
    >>> from faq_impact.core.models import ImpactDecision
    >>>
    >>> class MyApplicator(IImpactApplicator):
    ...     def apply_decisions(self, decisions: List[ImpactDecision]) -> List[ApplicationResult]:
    ...         # Implementation here
    ...         pass

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from typing import List, Optional, TYPE_CHECKING

# Use TYPE_CHECKING to avoid circular imports at runtime
if TYPE_CHECKING:
    from faq_impact.core.models.impact_decision import ImpactDecision
    from faq_impact.core.models.application_result import ApplicationResult
    from faq_impact.core.enums.decision_type import DecisionType
    from faq_impact.core.enums.entity_type import EntityType


class IImpactApplicator(ABC):
    """
    Main interface for applying impact decisions (execution phase).

    The IImpactApplicator is the primary entry point for executing impact
    decisions. It receives a list of ImpactDecision objects (from the analysis
    phase) and applies them to the database, performing actual mutations like
    creating questions, regenerating answers, or inactivating entities.

    **Responsibilities**:
        - Orchestrate the decision execution process
        - Delegate to appropriate executors based on decision type
        - Manage transactions and ensure atomicity
        - Handle errors and rollbacks
        - Track execution status and results
        - Update faq_impact table with application status

    **Phase**: Application Phase (mutations allowed)

    **Key Differences from IImpactAnalyzer**:
        - IImpactAnalyzer: Planning phase (read-only, generates decisions)
        - IImpactApplicator: Execution phase (mutations, applies decisions)

    **When to Use**:
        - You need to execute/apply impact decisions
        - You want to make actual database changes based on decisions
        - You're implementing the execution phase of impact analysis

    **When NOT to Use**:
        - You need to analyze changes (use IImpactAnalyzer instead)
        - You're implementing a specific executor (use IExecutor)
        - You're just creating decisions without applying them

    Example:
        >>> from faq_impact.core.interfaces import IImpactApplicator
        >>> from faq_impact.core.models import ImpactDecision
        >>> from faq_impact.core.enums import DecisionType
        >>>
        >>> applicator: IImpactApplicator = get_applicator()  # Dependency injection
        >>> decisions = [
        ...     ImpactDecision(
        ...         decision_type=DecisionType.PLAN_CREATE,
        ...         entity_type=EntityType.QUESTION,
        ...         change_id=123,
        ...         reason_code=ReasonCode.NEW_CONTENT_ADDED
        ...     )
        ... ]
        >>> results = applicator.apply_decisions(decisions)
        >>> for result in results:
        ...     if result.status == ApplicationStatus.COMPLETED:
        ...         print(f"Success: {result.impact_id}")
        ...     else:
        ...         print(f"Failed: {result.error_message}")

    Implementation Notes:
        - Must be transactional: all-or-nothing or partial with tracking
        - Should update faq_impact.application_status for each decision
        - Should use IExecutor instances for decision-type-specific logic
        - Must handle errors gracefully and record failures
        - Should support selective application (apply subset of decisions)
        - Should prevent duplicate execution (check IN_PROGRESS status)

    See Also:
        - IExecutor: For implementing decision-type-specific execution
        - IImpactAnalyzer: For generating the decisions to apply
        - ImpactDecision: Input data structure
        - ApplicationResult: Output data structure
    """

    @abstractmethod
    def apply_decisions(
        self, decisions: List["ImpactDecision"]
    ) -> List["ApplicationResult"]:
        """
        Apply a list of impact decisions to the database.

        This is the main entry point for executing impact decisions. It takes
        a list of decisions (from the analysis phase) and executes them,
        performing actual database mutations and tracking results.

        Args:
            decisions: List[ImpactDecision] to execute. Each decision contains:
                - impact_id: Unique ID of the decision
                - decision_type: PLAN_CREATE, REGEN_Q, REGEN_A, INACTIVATE, etc.
                - entity_type: QUESTION, ANSWER, or CHANGE
                - entity_id: ID of entity to affect (or None for new creations)
                - change_id: ID of the content change that triggered this
                - reason_code: Reason for this decision
                - details: Additional execution context

        Returns:
            List[ApplicationResult]: Results for each decision, containing:
                - impact_id: ID of the decision that was executed
                - status: COMPLETED, FAILED, or SKIPPED
                - executed_at: Timestamp of execution
                - execution_time_ms: Time taken to execute
                - affected_rows: Number of database rows affected
                - error_message: Error details if status=FAILED
                - rollback_performed: Whether transaction was rolled back
                - metadata: Additional result information

        Raises:
            ValueError: If decisions list is empty or contains invalid decisions
            RuntimeError: If critical system error prevents execution

        Example:
            >>> decisions = [
            ...     ImpactDecision(decision_type=DecisionType.PLAN_CREATE, ...),
            ...     ImpactDecision(decision_type=DecisionType.REGEN_A, ...),
            ... ]
            >>> results = applicator.apply_decisions(decisions)
            >>> assert len(results) == len(decisions)
            >>> completed = [r for r in results if r.status == ApplicationStatus.COMPLETED]
            >>> failed = [r for r in results if r.status == ApplicationStatus.FAILED]
            >>> print(f"Completed: {len(completed)}, Failed: {len(failed)}")

        Implementation Guidelines:
            1. Validate input decisions
            2. Filter out already-executed decisions (status != PENDING)
            3. For each decision:
                a. Set status to IN_PROGRESS
                b. Find appropriate executor using can_handle()
                c. Execute decision via executor.execute()
                d. Update status to COMPLETED or FAILED
                e. Record result in ApplicationResult
            4. Handle transactions appropriately
            5. Return complete list of ApplicationResult objects

        Transaction Strategies:
            - **All-or-nothing**: Single transaction, rollback all on any failure
            - **Individual**: Each decision in own transaction (recommended)
            - **Batch**: Group related decisions in transactions

        Notes:
            - Updates faq_impact.application_status for each decision
            - Records execution timestamps and error messages
            - Should be idempotent: re-applying completed decisions is safe
            - Should prevent concurrent execution (check IN_PROGRESS status)
            - EVALUATE decisions may spawn new decisions after LLM review
        """
        pass


class IExecutor(ABC):
    """
    Strategy interface for executing specific types of impact decisions.

    The IExecutor interface implements the Strategy Pattern, allowing different
    execution logic for different decision types (PLAN_CREATE, REGEN_Q, REGEN_A,
    INACTIVATE, etc.). Each executor encapsulates the specific mutation logic
    for its decision type.

    **Responsibilities**:
        - Determine if the executor can handle a given decision type
        - Execute decisions of a specific type
        - Perform database mutations (inserts, updates)
        - Integrate with question/answer generation services
        - Track provenance and roll forward temporal validity
        - Return execution results

    **Executor Types**:
        - CreateExecutor: Handles PLAN_CREATE (generate new Q/A pairs)
        - RegenerateExecutor: Handles REGEN_Q, REGEN_A, REGEN_BOTH
        - InactivateExecutor: Handles INACTIVATE (mark entities inactive)
        - EvaluateExecutor: Handles EVALUATE (LLM-based decision-making)

    **When to Use**:
        - You're implementing execution logic for a specific decision type
        - You want to extend the system with new execution strategies
        - You need to customize mutation logic

    **When NOT to Use**:
        - You need orchestration across multiple executors (use IImpactApplicator)
        - You're analyzing changes (use IAnalysisStrategy instead)

    Example:
        >>> from faq_impact.core.interfaces import IExecutor
        >>> from faq_impact.core.enums import DecisionType
        >>>
        >>> class CreateExecutor(IExecutor):
        ...     def can_handle(self, decision_type: DecisionType) -> bool:
        ...         return decision_type == DecisionType.PLAN_CREATE
        ...
        ...     def execute(self, decision: ImpactDecision) -> ApplicationResult:
        ...         # Call question generation service
        ...         # Insert new question into database
        ...         # Roll forward provenance
        ...         # Return success result
        ...         return ApplicationResult(status=ApplicationStatus.COMPLETED, ...)
        >>>
        >>> executor = CreateExecutor()
        >>> if executor.can_handle(DecisionType.PLAN_CREATE):
        ...     result = executor.execute(decision)

    Implementation Notes:
        - Each executor should handle one or more related decision types
        - Use can_handle() to determine executor applicability
        - Should be transactional within execute()
        - Should integrate with generation services from faq_update/generation/
        - Should use IProvenanceRoller to update provenance
        - Should return FAILED status on errors, not raise exceptions

    See Also:
        - IImpactApplicator: Orchestrator that uses executors
        - IProvenanceRoller: For updating temporal provenance
        - Question/Answer Generation Services: For LLM-based generation
    """

    @abstractmethod
    def can_handle(self, decision_type: "DecisionType") -> bool:
        """
        Determine if this executor can handle the given decision type.

        This method is used by the applicator to select the appropriate executor
        for a given decision. Each executor should return True for one or more
        decision types it's designed to handle.

        Args:
            decision_type: DecisionType enum value
                Possible values: PLAN_CREATE, REGEN_Q, REGEN_A, REGEN_BOTH,
                                INACTIVATE, EVALUATE, NOOP

        Returns:
            bool: True if this executor can handle the decision type, False otherwise

        Example:
            >>> executor = CreateExecutor()
            >>> executor.can_handle(DecisionType.PLAN_CREATE)
            True
            >>> executor.can_handle(DecisionType.REGEN_Q)
            False
            >>>
            >>> executor = RegenerateExecutor()
            >>> executor.can_handle(DecisionType.REGEN_Q)
            True
            >>> executor.can_handle(DecisionType.REGEN_A)
            True
            >>> executor.can_handle(DecisionType.REGEN_BOTH)
            True

        Notes:
            - Should be a simple, fast check (no I/O operations)
            - Typically just compares decision_type to a constant or set
            - Used for executor selection in the applicator
            - An executor can handle multiple decision types if logic is similar
        """
        pass

    @abstractmethod
    def execute(
        self, decision: "ImpactDecision"
    ) -> "ApplicationResult":
        """
        Execute a single impact decision.

        This method contains the core execution logic for this executor's
        decision type(s). It performs the actual database mutations, calls
        generation services if needed, and returns the execution result.

        Args:
            decision: ImpactDecision to execute
                Contains all information needed for execution:
                - decision_type: Type of decision to execute
                - entity_type: QUESTION, ANSWER, or CHANGE
                - entity_id: ID of entity to affect (or None for new)
                - change_id: ID of triggering content change
                - reason_code: Reason for this decision
                - details: Additional execution context (checksums, metadata, etc.)

        Returns:
            ApplicationResult: Execution result containing:
                - impact_id: ID of the decision executed
                - status: COMPLETED or FAILED (never PENDING or IN_PROGRESS)
                - executed_at: Timestamp of execution
                - execution_time_ms: Time taken
                - affected_rows: Number of rows modified
                - error_message: Error details if FAILED
                - rollback_performed: Whether rollback occurred
                - metadata: Additional result info (e.g., new question_id)

        Example:
            >>> decision = ImpactDecision(
            ...     decision_type=DecisionType.PLAN_CREATE,
            ...     entity_type=EntityType.QUESTION,
            ...     change_id=123,
            ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
            ...     details={"content_checksum": "abc123"}
            ... )
            >>> executor = CreateExecutor()
            >>> result = executor.execute(decision)
            >>> if result.status == ApplicationStatus.COMPLETED:
            ...     new_question_id = result.metadata.get("question_id")
            ...     print(f"Created question {new_question_id}")

        Implementation Guidelines:
            1. Start timing execution
            2. Validate decision is appropriate for this executor
            3. Begin database transaction
            4. Perform decision-specific logic:
                - PLAN_CREATE: Call question generation, insert Q/A
                - REGEN_Q/A/BOTH: Regenerate content, update rows
                - INACTIVATE: Set is_active=False, set inactivation_reason
                - EVALUATE: Call LLM evaluator, spawn new decisions
            5. Roll forward provenance using IProvenanceRoller
            6. Commit transaction
            7. Record execution time and affected rows
            8. Return ApplicationResult with COMPLETED status
            9. On error: rollback, return ApplicationResult with FAILED status

        Error Handling:
            - Should NOT raise exceptions
            - Should catch errors and return FAILED status
            - Should record error_message in result
            - Should set rollback_performed=True if transaction rolled back

        Notes:
            - Must be transactional (commit on success, rollback on failure)
            - Should call generation services for PLAN_CREATE and REGEN_* decisions
            - Should use IProvenanceRoller to update provenance
            - Should update faq_impact.application_status (handled by applicator)
            - EVALUATE decisions may create new decisions via recursive analysis
        """
        pass


class IProvenanceRoller(ABC):
    """
    Interface for managing temporal provenance (rolling forward validity).

    The IProvenanceRoller interface handles the complex logic of updating
    provenance records when content changes. It "rolls forward" temporal
    validity by:
    1. Ending validity of old provenance (set valid_to = now)
    2. Creating new provenance with updated checksum (valid_from = now)

    **Responsibilities**:
        - Update question/answer provenance when content changes
        - Maintain temporal validity (valid_from, valid_to)
        - Handle both question and answer provenance
        - Support transaction rollback
        - Track change_id for audit trail

    **Key Concepts**:
        - **Temporal Validity**: Provenance records have valid_from and valid_to
        - **Roll Forward**: End old record, create new record with new checksum
        - **Bi-temporal**: Track both transaction time and valid time

    **When to Use**:
        - You're regenerating a question or answer (content changed)
        - You need to update provenance after content modification
        - You're implementing executor logic that changes Q/A content

    **When NOT to Use**:
        - You're creating a new question/answer (initial provenance, not roll)
        - You're inactivating without regeneration (no content change)
        - You're just analyzing changes (no mutations yet)

    Example:
        >>> from faq_impact.core.interfaces import IProvenanceRoller
        >>> from faq_impact.core.enums import EntityType
        >>>
        >>> roller: IProvenanceRoller = get_provenance_roller()
        >>> roller.roll_forward(
        ...     entity_type=EntityType.QUESTION,
        ...     entity_id=42,
        ...     old_checksum="old_hash",
        ...     new_checksum="new_hash",
        ...     change_id=123
        ... )
        # This will:
        # 1. Find provenance record for question 42 with checksum "old_hash"
        # 2. Set valid_to = now() on that record
        # 3. Insert new provenance record with checksum "new_hash", valid_from = now()

    Implementation Notes:
        - Should be called within a transaction (executor's transaction)
        - Should update faq_question_provenance or faq_answer_provenance
        - Should handle missing old provenance gracefully
        - Should maintain referential integrity
        - Should record change_id for audit trail

    See Also:
        - IExecutor: Executors use provenance roller during execution
        - Temporal Provenance Schema: Database schema for provenance tables
    """

    @abstractmethod
    def roll_forward(
        self,
        entity_type: "EntityType",
        entity_id: int,
        old_checksum: str,
        new_checksum: str,
        change_id: int,
    ) -> None:
        """
        Roll forward provenance by ending old record and creating new one.

        This method implements the temporal validity pattern for provenance.
        When content is regenerated, it:
        1. Finds the current (valid) provenance record with old_checksum
        2. Sets valid_to = now() on that record (ends validity)
        3. Creates new provenance record with new_checksum, valid_from = now()

        Args:
            entity_type: EntityType.QUESTION or EntityType.ANSWER
            entity_id: ID of the question or answer being updated
            old_checksum: Checksum before regeneration (to find old provenance)
            new_checksum: Checksum after regeneration (for new provenance)
            change_id: ID of the content change that triggered this update

        Returns:
            None: Method performs side effects (database updates)

        Raises:
            ValueError: If entity_type is not QUESTION or ANSWER
            ValueError: If entity_id, old_checksum, or new_checksum is invalid
            RuntimeError: If database update fails

        Example:
            >>> from faq_impact.core.enums import EntityType
            >>>
            >>> # After regenerating a question
            >>> roller.roll_forward(
            ...     entity_type=EntityType.QUESTION,
            ...     entity_id=42,
            ...     old_checksum="abc123",  # old content hash
            ...     new_checksum="def456",  # new content hash after regen
            ...     change_id=789           # the content change that triggered regen
            ... )
            >>>
            >>> # After regenerating an answer
            >>> roller.roll_forward(
            ...     entity_type=EntityType.ANSWER,
            ...     entity_id=100,
            ...     old_checksum="old_hash",
            ...     new_checksum="new_hash",
            ...     change_id=456
            ... )

        Implementation Guidelines:
            1. Validate input parameters
            2. Determine which provenance table to update:
                - EntityType.QUESTION → faq_question_provenance
                - EntityType.ANSWER → faq_answer_provenance
            3. Find current provenance record:
                - WHERE entity_id = ? AND content_checksum = ? AND valid_to IS NULL
            4. Update old record:
                - SET valid_to = NOW() WHERE provenance_id = ?
            5. Insert new record:
                - INSERT INTO provenance (entity_id, content_checksum, valid_from, change_id)
                - VALUES (entity_id, new_checksum, NOW(), change_id)
            6. Ensure transaction consistency

        Database Impact:
            - Updates 1 row (old provenance record)
            - Inserts 1 row (new provenance record)
            - Should be called within executor's transaction

        Notes:
            - Should be called AFTER regeneration completes successfully
            - Should be transactional with the regeneration itself
            - If old_checksum not found, may insert new record anyway (defensive)
            - Should maintain temporal consistency (no gaps or overlaps)
            - change_id links provenance update to the triggering change
        """
        pass


# Convenience exports
__all__ = [
    "IImpactApplicator",
    "IExecutor",
    "IProvenanceRoller",
]
