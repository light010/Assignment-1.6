"""
Evaluator Interfaces - Abstract Base Classes for LLM-Based Evaluation

This module defines the core interfaces for LLM-based evaluation in the
FAQ impact system. These interfaces enable AI-assisted decision-making
for ambiguous cases and answer validity checking.

Key Interfaces:
    - ILLMEvaluator: LLM-based answer evaluation interface

Design Patterns:
    - Strategy Pattern: Different LLM providers (OpenAI, Anthropic, etc.)
    - Dependency Inversion: Depend on abstractions, not specific LLM APIs
    - Provider Abstraction: Enable multiple LLM backends

Usage:
    >>> from faq_impact.core.interfaces import ILLMEvaluator
    >>>
    >>> class OpenAIEvaluator(ILLMEvaluator):
    ...     def evaluate_answer_validity(self, answer_id: int, new_content_checksum: str) -> bool:
    ...         # Call OpenAI API to evaluate answer
    ...         pass

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, TYPE_CHECKING


class ILLMEvaluator(ABC):
    """
    Interface for LLM-based answer validity evaluation.

    The ILLMEvaluator interface provides AI-assisted evaluation of answers
    to determine if they remain valid after content changes. This is used
    when impact analysis encounters ambiguous cases where rule-based logic
    is insufficient to make a confident decision.

    **Responsibilities**:
        - Evaluate if an answer is still valid given new content
        - Provide confidence scores for evaluation results
        - Support different LLM providers (OpenAI, Anthropic, etc.)
        - Return structured evaluation results
        - Handle LLM API errors gracefully

    **Use Cases**:
        - EVALUATE decisions: Resolve ambiguous cases via LLM
        - Answer quality checks: Verify regenerated answers are coherent
        - Edge case handling: Get AI opinion on complex scenarios
        - Similarity ambiguity: Decide if 0.75 similarity requires regen

    **When to Use**:
        - You have an EVALUATE decision that needs LLM review
        - You need to check if an answer is still valid after content change
        - You're implementing the EvaluateExecutor
        - You're handling edge cases that automated rules can't handle

    **When NOT to Use**:
        - You're doing standard rule-based analysis (use IAnalysisStrategy)
        - You're generating new questions/answers (use generation services)
        - You want fast, deterministic decisions (LLM calls are slow/costly)

    **Key Concepts**:
        - **Answer Validity**: Does the answer still correctly address the question?
        - **Content Checksum**: Identifies which version of content to evaluate against
        - **Confidence Score**: How confident is the LLM in its evaluation?
        - **Provider Abstraction**: Different implementations for different LLMs

    Example:
        >>> from faq_impact.core.interfaces import ILLMEvaluator
        >>>
        >>> evaluator: ILLMEvaluator = get_llm_evaluator()  # Dependency injection
        >>> is_valid = evaluator.evaluate_answer_validity(
        ...     answer_id=42,
        ...     new_content_checksum="new_hash"
        ... )
        >>> if is_valid:
        ...     print("Answer is still valid, no regeneration needed")
        ... else:
        ...     print("Answer is invalid, needs regeneration")

    Implementation Notes:
        - Should support multiple LLM providers via configuration
        - Should cache evaluation results to avoid duplicate LLM calls
        - Should handle rate limits and API errors gracefully
        - Should log LLM prompts and responses for debugging
        - Should include timeout handling (LLM calls can be slow)
        - Should track cost/token usage for monitoring

    Provider Implementations:
        - OpenAIEvaluator: Uses Azure OpenAI or OpenAI API
        - AnthropicEvaluator: Uses Anthropic Claude API
        - LocalEvaluator: Uses local/open-source models

    See Also:
        - IExecutor: EvaluateExecutor uses ILLMEvaluator
        - Question/Answer Generation Services: For generating content
    """

    @abstractmethod
    def evaluate_answer_validity(
        self, answer_id: int, new_content_checksum: str
    ) -> bool:
        """
        Evaluate if an answer is still valid given new content.

        This method uses an LLM to determine whether an existing answer
        remains valid and accurate when paired with new/modified content.
        It's used to resolve EVALUATE decisions and quality-check answers.

        Args:
            answer_id: ID of the answer to evaluate
            new_content_checksum: Checksum of the new/modified content to evaluate against

        Returns:
            bool: True if answer is still valid, False if it needs regeneration

        Raises:
            ValueError: If answer_id is invalid or answer not found
            ValueError: If new_content_checksum is invalid or content not found
            RuntimeError: If LLM API call fails after retries

        Example:
            >>> # After detecting content change with similarity = 0.75 (ambiguous)
            >>> evaluator = OpenAIEvaluator()
            >>> answer_id = 42
            >>> new_checksum = "abc123"  # new content version
            >>>
            >>> is_valid = evaluator.evaluate_answer_validity(answer_id, new_checksum)
            >>> if is_valid:
            ...     decision_type = DecisionType.NOOP  # Keep existing answer
            ... else:
            ...     decision_type = DecisionType.REGEN_A  # Regenerate answer

        Implementation Guidelines:
            1. Retrieve answer from database:
                - Get answer_text, question_text, question_id
            2. Retrieve new content from database:
                - Get content text using new_content_checksum
            3. Construct LLM prompt:
                - Include question, current answer, and new content
                - Ask: "Is this answer still valid given the new content?"
            4. Call LLM API:
                - Use structured output if possible (JSON with reasoning)
                - Request confidence score
            5. Parse LLM response:
                - Extract validity decision (true/false)
                - Extract reasoning (for logging/debugging)
            6. Cache result:
                - Store (answer_id, new_content_checksum) → result
            7. Return validity decision

        Prompt Engineering Tips:
            - Be specific: "Does the answer accurately address the question using the new content?"
            - Request reasoning: "Explain why the answer is/isn't valid"
            - Provide context: Include question, old answer, and new content
            - Use structured output: JSON schema for consistency
            - Request confidence: "How confident are you? (0-100%)"

        Example Prompt Structure:
            ```
            You are evaluating whether an FAQ answer is still valid after content changes.

            Question: {question_text}
            Current Answer: {answer_text}
            New Content: {new_content_text}

            Task: Determine if the Current Answer still accurately and completely
            addresses the Question using the New Content.

            Respond in JSON:
            {
                "is_valid": true/false,
                "confidence": 0-100,
                "reasoning": "explanation..."
            }
            ```

        Performance Considerations:
            - LLM calls are slow (100ms - 2s per call)
            - LLM calls are expensive (tokens cost money)
            - Should cache results to avoid duplicate evaluations
            - Should batch evaluations if possible (multiple answers in one call)
            - Should implement timeout handling (default: 30s)

        Error Handling:
            - If answer_id not found: raise ValueError
            - If content not found: raise ValueError
            - If LLM API fails: retry up to 3 times, then raise RuntimeError
            - If LLM response invalid: log warning, default to False (regenerate)

        Logging:
            - Log LLM prompts (for debugging/auditing)
            - Log LLM responses (for debugging/auditing)
            - Log evaluation results (answer_id, checksum, result, confidence)
            - Log token usage and cost (for monitoring)

        Notes:
            - Result should be deterministic given same inputs (cache helps)
            - Should use function calling or structured output for reliability
            - Should include question context, not just answer
            - Should compare against new content, not old content
            - Confidence score can inform follow-up actions (e.g., manual review if low)
        """
        pass

    def evaluate_with_confidence(
        self, answer_id: int, new_content_checksum: str
    ) -> Dict[str, Any]:
        """
        Evaluate answer validity with detailed confidence metrics.

        This optional method provides extended evaluation results including
        confidence scores, reasoning, and metadata. Implementations may
        override this to provide richer evaluation data.

        Args:
            answer_id: ID of the answer to evaluate
            new_content_checksum: Checksum of new content

        Returns:
            Dict containing:
                - is_valid (bool): Whether answer is valid
                - confidence (float): Confidence score 0.0-1.0
                - reasoning (str): LLM's explanation
                - model_used (str): LLM model identifier
                - tokens_used (int): Total tokens consumed
                - evaluation_time_ms (int): Time taken

        Example:
            >>> result = evaluator.evaluate_with_confidence(42, "abc123")
            >>> print(f"Valid: {result['is_valid']}")
            >>> print(f"Confidence: {result['confidence']:.2%}")
            >>> print(f"Reasoning: {result['reasoning']}")
            >>> if result['confidence'] < 0.7:
            ...     print("Low confidence, consider manual review")

        Notes:
            - Default implementation just calls evaluate_answer_validity()
            - Implementations can override to provide richer data
            - Useful for debugging and manual review workflows
        """
        is_valid = self.evaluate_answer_validity(answer_id, new_content_checksum)
        return {
            "is_valid": is_valid,
            "confidence": 1.0 if is_valid else 1.0,
            "reasoning": "Default implementation, no reasoning available",
            "model_used": "unknown",
            "tokens_used": 0,
            "evaluation_time_ms": 0,
        }


# Convenience exports
__all__ = [
    "ILLMEvaluator",
]
