# Interface Design Patterns

**Version**: 1.0.0
**Date**: 2025-11-02
**Author**: Analytics Assist Team

---

## Overview

This document explains the design patterns, architectural principles, and best practices used in the FAQ Impact Analysis interface design. Understanding these patterns is essential for implementing, extending, and testing the system.

---

## Table of Contents

1. [Core Design Principles](#core-design-principles)
2. [Strategy Pattern](#strategy-pattern)
3. [Dependency Injection](#dependency-injection)
4. [Interface Segregation](#interface-segregation)
5. [Command Pattern](#command-pattern)
6. [Testing Strategies](#testing-strategies)
7. [UML Diagrams](#uml-diagrams)
8. [Code Examples](#code-examples)
9. [Best Practices](#best-practices)

---

## Core Design Principles

### 1. Dependency Inversion Principle (DIP)

> **"Depend on abstractions, not concretions"**

All components depend on interfaces (abstractions), not concrete implementations. This enables:
- **Testability**: Mock implementations for unit testing
- **Flexibility**: Swap implementations without changing clients
- **Maintainability**: Changes to implementations don't affect interfaces

**Example**:
```python
# ❌ BAD: Depends on concrete class
class ImpactAnalyzer:
    def __init__(self):
        self.strategy = ModifiedContentStrategy()  # Hard-coded dependency

# ✅ GOOD: Depends on interface
class ImpactAnalyzer:
    def __init__(self, strategy: IAnalysisStrategy):
        self.strategy = strategy  # Injected dependency
```

### 2. Single Responsibility Principle (SRP)

> **"Each interface should have one reason to change"**

Interfaces are focused and cohesive:
- `IImpactAnalyzer`: Orchestrates analysis (doesn't implement strategies)
- `IAnalysisStrategy`: Implements specific change type logic (doesn't orchestrate)
- `ITokenMatcher`: Token matching only (doesn't count sources)
- `ISourceCounter`: Source counting only (doesn't match tokens)

### 3. Open/Closed Principle (OCP)

> **"Open for extension, closed for modification"**

System can be extended with new strategies without modifying existing code:
- Add new `IAnalysisStrategy` implementations without changing `IImpactAnalyzer`
- Add new `IExecutor` implementations without changing `IImpactApplicator`
- Add new `ILLMEvaluator` providers without changing executors

---

## Strategy Pattern

### Purpose

The Strategy Pattern enables different algorithms (strategies) to be selected at runtime. In our system, we use it for:
- **Analysis Strategies**: Different logic for NEW/MODIFIED/DELETED content
- **Execution Strategies**: Different logic for CREATE/REGEN/INACTIVATE decisions

### Structure

```
┌─────────────────────┐
│  ImpactAnalyzer     │
│  (Context)          │
├─────────────────────┤
│ - strategy          │◆───────┐
│ + analyze_change()  │        │
└─────────────────────┘        │
                               │
                               ▼
                    ┌─────────────────────┐
                    │ IAnalysisStrategy   │
                    │ (Strategy Interface)│
                    ├─────────────────────┤
                    │ + can_handle()      │
                    │ + analyze()         │
                    └─────────────────────┘
                               △
                ┌──────────────┼──────────────┐
                │              │              │
┌───────────────────┐ ┌────────────────┐ ┌──────────────────┐
│NewContentStrategy│ │ModifiedContent │ │DeletedContent    │
│                  │ │Strategy        │ │Strategy          │
├──────────────────┤ ├────────────────┤ ├──────────────────┤
│+ can_handle()    │ │+ can_handle()  │ │+ can_handle()    │
│+ analyze()       │ │+ analyze()     │ │+ analyze()       │
└──────────────────┘ └────────────────┘ └──────────────────┘
```

### Benefits

1. **Pluggable Algorithms**: Swap strategies at runtime
2. **Testability**: Test each strategy in isolation
3. **Maintainability**: Changes to one strategy don't affect others
4. **Extensibility**: Add new strategies without modifying existing code

### Implementation Example

```python
from typing import List
from faq_impact.core.interfaces import IImpactAnalyzer, IAnalysisStrategy
from faq_impact.core.models import DetectionContext, ImpactDecision

class ImpactAnalyzer(IImpactAnalyzer):
    """Analyzer that uses strategies for different change types."""

    def __init__(self, strategies: List[IAnalysisStrategy]):
        """
        Initialize analyzer with list of strategies.

        Args:
            strategies: List of IAnalysisStrategy implementations
        """
        self.strategies = strategies

    def analyze_change(self, context: DetectionContext) -> List[ImpactDecision]:
        """
        Analyze change by delegating to appropriate strategy.

        Uses Strategy Pattern: finds strategy that can handle change type,
        then delegates analysis to that strategy.
        """
        # Find strategy that can handle this change type
        strategy = self._select_strategy(context.change_type)

        if strategy is None:
            raise ValueError(f"No strategy found for change type: {context.change_type}")

        # Delegate to strategy
        return strategy.analyze(context)

    def _select_strategy(self, change_type: str) -> IAnalysisStrategy:
        """Select strategy based on change type."""
        for strategy in self.strategies:
            if strategy.can_handle(change_type):
                return strategy
        return None


# Example usage
analyzer = ImpactAnalyzer([
    NewContentStrategy(),
    ModifiedContentStrategy(),
    DeletedContentStrategy()
])

context = DetectionContext(change_type="NEW_CONTENT", ...)
decisions = analyzer.analyze_change(context)  # Uses NewContentStrategy
```

---

## Dependency Injection

### Purpose

Dependency Injection (DI) is a technique where dependencies are provided (injected) to a class rather than created internally. This enables:
- **Testability**: Inject mock dependencies for testing
- **Flexibility**: Configure different implementations
- **Decoupling**: Classes don't depend on concrete implementations

### Types of Dependency Injection

#### 1. Constructor Injection (Recommended)

Dependencies injected via constructor:

```python
class ImpactAnalyzer(IImpactAnalyzer):
    def __init__(
        self,
        strategies: List[IAnalysisStrategy],
        repository: ImpactRepository,
        logger: Logger
    ):
        """All dependencies injected via constructor."""
        self.strategies = strategies
        self.repository = repository
        self.logger = logger
```

**Benefits**:
- Dependencies are explicit and required
- Immutable after construction
- Easy to test

#### 2. Property Injection

Dependencies set via properties (less common):

```python
class ImpactAnalyzer(IImpactAnalyzer):
    @property
    def repository(self) -> ImpactRepository:
        return self._repository

    @repository.setter
    def repository(self, value: ImpactRepository):
        self._repository = value
```

**Use when**: Dependencies are optional or may change

#### 3. Method Injection

Dependencies passed to individual methods:

```python
def analyze_change(
    self,
    context: DetectionContext,
    strategy: IAnalysisStrategy  # Injected per call
) -> List[ImpactDecision]:
    return strategy.analyze(context)
```

**Use when**: Dependency varies per method call

### Dependency Injection Container Example

```python
from typing import Dict, Type, Any

class DIContainer:
    """Simple dependency injection container."""

    def __init__(self):
        self._singletons: Dict[Type, Any] = {}
        self._factories: Dict[Type, callable] = {}

    def register_singleton(self, interface: Type, instance: Any):
        """Register a singleton instance."""
        self._singletons[interface] = instance

    def register_factory(self, interface: Type, factory: callable):
        """Register a factory function."""
        self._factories[interface] = factory

    def resolve(self, interface: Type) -> Any:
        """Resolve an instance for the given interface."""
        if interface in self._singletons:
            return self._singletons[interface]
        if interface in self._factories:
            return self._factories[interface]()
        raise ValueError(f"No registration found for {interface}")


# Usage
container = DIContainer()

# Register strategies
container.register_singleton(
    IAnalysisStrategy,
    NewContentStrategy(
        repository=container.resolve(ImpactRepository)
    )
)

# Register analyzer
container.register_factory(
    IImpactAnalyzer,
    lambda: ImpactAnalyzer(
        strategies=[
            NewContentStrategy(),
            ModifiedContentStrategy(),
            DeletedContentStrategy()
        ],
        repository=container.resolve(ImpactRepository)
    )
)

# Resolve dependencies
analyzer = container.resolve(IImpactAnalyzer)
```

---

## Interface Segregation

### Purpose

> **"Clients should not be forced to depend on interfaces they don't use"**

We split large interfaces into smaller, focused ones:

### Example: Segregated Interfaces

```python
# ✅ GOOD: Focused interfaces
class ITokenMatcher(ABC):
    """Only token matching."""
    @abstractmethod
    def find_overlapping_questions(self, tokens: List[str]) -> List[TokenOverlapResult]:
        pass

class ISourceCounter(ABC):
    """Only source counting."""
    @abstractmethod
    def count_valid_sources(self, entity_type: EntityType, entity_id: int) -> SourceCountResult:
        pass


# ❌ BAD: Bloated interface
class IAnalysisHelper(ABC):
    """Everything in one interface (violates ISP)."""
    @abstractmethod
    def find_overlapping_questions(self, tokens: List[str]) -> List[TokenOverlapResult]:
        pass

    @abstractmethod
    def count_valid_sources(self, entity_type: EntityType, entity_id: int) -> SourceCountResult:
        pass

    @abstractmethod
    def evaluate_answer(self, answer_id: int) -> bool:
        pass
    # ... more unrelated methods
```

### Benefits

1. **Flexibility**: Implement only what you need
2. **Testability**: Mock only relevant interfaces
3. **Maintainability**: Changes to one interface don't affect others
4. **Clarity**: Each interface has clear purpose

---

## Command Pattern

### Purpose

Impact decisions act as **Command objects** - they encapsulate a request as an object, enabling:
- **Queueing**: Store decisions for later execution
- **Logging**: Audit trail of all decisions
- **Undo/Rollback**: Reverse decisions if needed
- **Selective Execution**: Apply only certain decisions

### Structure

```
┌─────────────────────┐
│  ImpactDecision     │  ◀──── Command
│  (Command)          │
├─────────────────────┤
│ - decision_type     │
│ - entity_type       │
│ - entity_id         │
│ + execute()         │  (implicit - executed by IExecutor)
└─────────────────────┘
         │
         │ executed by
         ▼
┌─────────────────────┐
│  IExecutor          │  ◀──── Command Handler
│  (Receiver)         │
├─────────────────────┤
│ + can_handle()      │
│ + execute()         │
└─────────────────────┘
         △
         │
┌─────────────────────┐
│  IImpactApplicator  │  ◀──── Invoker
│  (Invoker)          │
├─────────────────────┤
│ + apply_decisions() │
└─────────────────────┘
```

### Benefits

1. **Separation of Planning and Execution**: Analysis phase creates commands, application phase executes them
2. **Auditability**: All commands logged in `faq_impact` table
3. **Flexibility**: Execute commands in different orders or selectively
4. **Rollback Support**: Can reverse commands if needed

### Example

```python
# Analysis phase: Create commands (decisions)
analyzer = ImpactAnalyzer(...)
context = DetectionContext(change_type="NEW_CONTENT", ...)
decisions = analyzer.analyze_change(context)  # Returns list of ImpactDecision objects

# Store commands (decisions) in database
for decision in decisions:
    impact_repository.save_decision(decision)

# Application phase: Execute commands (later, possibly different process)
applicator = ImpactApplicator(...)
pending_decisions = impact_repository.get_pending_decisions()
results = applicator.apply_decisions(pending_decisions)  # Executes commands
```

---

## Testing Strategies

### 1. Unit Testing with Mocks

Mock dependencies to test classes in isolation:

```python
import pytest
from unittest.mock import Mock, MagicMock
from faq_impact.core.interfaces import IAnalysisStrategy, IImpactAnalyzer
from faq_impact.core.models import DetectionContext, ImpactDecision

def test_analyzer_delegates_to_strategy():
    """Test that analyzer delegates to correct strategy."""
    # Arrange: Create mock strategy
    mock_strategy = Mock(spec=IAnalysisStrategy)
    mock_strategy.can_handle.return_value = True
    mock_strategy.analyze.return_value = [
        ImpactDecision(decision_type=DecisionType.PLAN_CREATE, ...)
    ]

    analyzer = ImpactAnalyzer([mock_strategy])
    context = DetectionContext(change_type="NEW_CONTENT", ...)

    # Act
    decisions = analyzer.analyze_change(context)

    # Assert
    mock_strategy.can_handle.assert_called_once_with("NEW_CONTENT")
    mock_strategy.analyze.assert_called_once_with(context)
    assert len(decisions) == 1
    assert decisions[0].decision_type == DecisionType.PLAN_CREATE
```

### 2. Integration Testing

Test multiple components together:

```python
def test_end_to_end_new_content_flow():
    """Test complete flow from analysis to execution."""
    # Use real implementations (not mocks)
    repository = InMemoryImpactRepository()  # Test double
    token_matcher = TokenMatcher(repository)
    source_counter = SourceCounter(repository)

    strategy = NewContentStrategy(
        repository=repository,
        token_matcher=token_matcher,
        source_counter=source_counter
    )

    analyzer = ImpactAnalyzer([strategy], repository)

    # Test analysis
    context = DetectionContext(change_type="NEW_CONTENT", ...)
    decisions = analyzer.analyze_change(context)

    assert len(decisions) > 0
    assert all(d.decision_type == DecisionType.PLAN_CREATE for d in decisions)
```

### 3. Test Doubles

Use different types of test doubles:

#### Mock
Verifies behavior (method calls):
```python
mock_strategy = Mock(spec=IAnalysisStrategy)
mock_strategy.analyze.return_value = [...]
# Later: verify analyze() was called
mock_strategy.analyze.assert_called_once()
```

#### Stub
Provides canned responses:
```python
class StubStrategy(IAnalysisStrategy):
    def can_handle(self, change_type: str) -> bool:
        return True

    def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        return [ImpactDecision(...)]  # Canned response
```

#### Fake
Working implementation for testing:
```python
class InMemoryImpactRepository:
    """Fake repository using in-memory storage."""
    def __init__(self):
        self.decisions = []

    def save_decision(self, decision: ImpactDecision):
        self.decisions.append(decision)

    def get_pending_decisions(self) -> List[ImpactDecision]:
        return [d for d in self.decisions if d.application_status == "PENDING"]
```

### 4. Testing Interface Implementations

Test that implementations satisfy interface contracts:

```python
def test_strategy_satisfies_interface():
    """Test that NewContentStrategy implements IAnalysisStrategy correctly."""
    strategy = NewContentStrategy(...)

    # Test can_handle()
    assert strategy.can_handle("NEW_CONTENT") is True
    assert strategy.can_handle("MODIFIED_CONTENT") is False

    # Test analyze() returns correct type
    context = DetectionContext(change_type="NEW_CONTENT", ...)
    decisions = strategy.analyze(context)
    assert isinstance(decisions, list)
    assert all(isinstance(d, ImpactDecision) for d in decisions)
```

---

## UML Diagrams

### Class Diagram: Analysis Phase

```
┌─────────────────────────────────┐
│      IImpactAnalyzer            │
│      <<interface>>              │
├─────────────────────────────────┤
│ + analyze_change(context)       │
│   → List[ImpactDecision]        │
└─────────────────────────────────┘
              △
              │ implements
              │
┌─────────────────────────────────┐
│      ImpactAnalyzer             │
├─────────────────────────────────┤
│ - strategies: List[Strategy]    │
│ - repository: Repository        │
├─────────────────────────────────┤
│ + analyze_change(context)       │
│ - _select_strategy(type)        │
└─────────────────────────────────┘
              │
              │ uses
              ▼
┌─────────────────────────────────┐
│     IAnalysisStrategy           │
│     <<interface>>               │
├─────────────────────────────────┤
│ + can_handle(type) → bool       │
│ + analyze(context)              │
│   → List[ImpactDecision]        │
└─────────────────────────────────┘
              △
              │
    ┌─────────┼──────────┐
    │         │          │
    │         │          │
┌───────┐ ┌───────┐ ┌────────┐
│ New   │ │Modified│ │Deleted │
│Content│ │Content │ │Content │
│Strategy│ │Strategy│ │Strategy│
└───────┘ └────────┘ └────────┘
```

### Sequence Diagram: Analysis Flow

```
User          Analyzer        Strategy       Repository
 │                │              │               │
 │ analyze_change │              │               │
 ├───────────────►│              │               │
 │                │ can_handle?  │               │
 │                ├─────────────►│               │
 │                │     true     │               │
 │                │◄─────────────┤               │
 │                │              │               │
 │                │   analyze    │               │
 │                ├─────────────►│               │
 │                │              │ get_questions │
 │                │              ├──────────────►│
 │                │              │   questions   │
 │                │              │◄──────────────┤
 │                │              │               │
 │                │   decisions  │               │
 │                │◄─────────────┤               │
 │                │              │               │
 │   decisions    │              │               │
 │◄───────────────┤              │               │
 │                │              │               │
```

### Class Diagram: Execution Phase

```
┌─────────────────────────────────┐
│     IImpactApplicator           │
│     <<interface>>               │
├─────────────────────────────────┤
│ + apply_decisions(decisions)    │
│   → List[ApplicationResult]     │
└─────────────────────────────────┘
              △
              │
┌─────────────────────────────────┐
│     ImpactApplicator            │
├─────────────────────────────────┤
│ - executors: List[IExecutor]    │
│ - repository: Repository        │
├─────────────────────────────────┤
│ + apply_decisions(decisions)    │
│ - _select_executor(type)        │
└─────────────────────────────────┘
              │
              │ uses
              ▼
┌─────────────────────────────────┐
│        IExecutor                │
│        <<interface>>            │
├─────────────────────────────────┤
│ + can_handle(type) → bool       │
│ + execute(decision)             │
│   → ApplicationResult           │
└─────────────────────────────────┘
              △
              │
    ┌─────────┼──────────┐
    │         │          │
┌───────┐ ┌──────────┐ ┌─────────┐
│Create │ │Regenerate│ │Inactivate│
│Executor│ │Executor  │ │Executor │
└───────┘ └──────────┘ └─────────┘
```

---

## Code Examples

### Complete Implementation Example

```python
# analyzer.py - Main analyzer implementation
from typing import List
from faq_impact.core.interfaces import (
    IImpactAnalyzer,
    IAnalysisStrategy,
    ITokenMatcher,
    ISourceCounter
)
from faq_impact.core.models import DetectionContext, ImpactDecision

class ImpactAnalyzer(IImpactAnalyzer):
    """Main analyzer orchestrator with dependency injection."""

    def __init__(
        self,
        strategies: List[IAnalysisStrategy],
        repository: ImpactRepository,
        logger: Logger
    ):
        """
        Initialize analyzer with dependencies.

        Args:
            strategies: List of analysis strategies to use
            repository: Repository for data access
            logger: Logger for diagnostics
        """
        self.strategies = strategies
        self.repository = repository
        self.logger = logger

    def analyze_change(self, context: DetectionContext) -> List[ImpactDecision]:
        """Analyze change using appropriate strategy."""
        self.logger.info(f"Analyzing change {context.change_id}, type: {context.change_type}")

        # Select strategy
        strategy = self._select_strategy(context.change_type)
        if strategy is None:
            self.logger.error(f"No strategy for change type: {context.change_type}")
            raise ValueError(f"No strategy found for {context.change_type}")

        # Delegate to strategy
        self.logger.debug(f"Using strategy: {strategy.__class__.__name__}")
        decisions = strategy.analyze(context)

        # Deduplicate and validate
        decisions = self._deduplicate_decisions(decisions)
        self._validate_decisions(decisions)

        self.logger.info(f"Generated {len(decisions)} impact decisions")
        return decisions

    def _select_strategy(self, change_type: str) -> IAnalysisStrategy:
        """Select strategy based on change type."""
        for strategy in self.strategies:
            if strategy.can_handle(change_type):
                return strategy
        return None

    def _deduplicate_decisions(self, decisions: List[ImpactDecision]) -> List[ImpactDecision]:
        """Remove duplicate decisions."""
        seen = set()
        unique = []
        for decision in decisions:
            key = (decision.entity_type, decision.entity_id, decision.decision_type)
            if key not in seen:
                seen.add(key)
                unique.append(decision)
        return unique

    def _validate_decisions(self, decisions: List[ImpactDecision]):
        """Validate decisions."""
        from faq_impact.core.enums import ReasonCode
        for decision in decisions:
            if not ReasonCode.is_compatible(decision.decision_type, decision.reason_code):
                raise ValueError(
                    f"Invalid decision-reason combination: "
                    f"{decision.decision_type} with {decision.reason_code}"
                )


# new_content_strategy.py - Strategy implementation
from faq_impact.core.interfaces import IAnalysisStrategy
from faq_impact.core.enums import DecisionType, EntityType, ReasonCode

class NewContentStrategy(IAnalysisStrategy):
    """Strategy for analyzing NEW_CONTENT changes."""

    def __init__(self, repository: ImpactRepository):
        """Initialize with repository dependency."""
        self.repository = repository

    def can_handle(self, change_type: str) -> bool:
        """Can handle NEW_CONTENT changes."""
        return change_type == "NEW_CONTENT"

    def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        """
        Analyze new content and generate PLAN_CREATE decisions.

        Strategy: New content always generates new questions.
        """
        decisions = []

        # Create decision to generate new questions
        decision = ImpactDecision(
            entity_type=EntityType.QUESTION,
            entity_id=None,  # No entity_id yet (will be created)
            change_id=context.change_id,
            detection_run_id=context.detection_run_id,
            decision_type=DecisionType.PLAN_CREATE,
            reason_code=ReasonCode.NEW_CONTENT_ADDED,
            details={
                "content_checksum": context.content_checksum,
                "file_name": context.file_name
            }
        )
        decisions.append(decision)

        return decisions


# main.py - Dependency injection setup
from faq_impact.core.interfaces import IImpactAnalyzer
from faq_impact.analysis.impact_analyzer import ImpactAnalyzer
from faq_impact.analysis.strategies import (
    NewContentStrategy,
    ModifiedContentStrategy,
    DeletedContentStrategy
)

def create_analyzer() -> IImpactAnalyzer:
    """Factory function to create analyzer with dependencies."""
    # Create dependencies
    repository = ImpactRepository(connection_string="...")
    logger = get_logger("impact_analysis")

    # Create strategies
    strategies = [
        NewContentStrategy(repository=repository),
        ModifiedContentStrategy(
            repository=repository,
            token_matcher=TokenMatcher(repository),
            source_counter=SourceCounter(repository)
        ),
        DeletedContentStrategy(
            repository=repository,
            source_counter=SourceCounter(repository)
        )
    ]

    # Create and return analyzer
    return ImpactAnalyzer(
        strategies=strategies,
        repository=repository,
        logger=logger
    )


# Usage
analyzer = create_analyzer()
context = DetectionContext(...)
decisions = analyzer.analyze_change(context)
```

---

## Best Practices

### 1. Interface Design

✅ **DO**:
- Keep interfaces focused and cohesive (Single Responsibility)
- Use type hints for all parameters and return values
- Document all methods with docstrings
- Include usage examples in docstrings
- Raise specific exceptions with clear messages

❌ **DON'T**:
- Create "god interfaces" with too many methods
- Use generic types (use specific types)
- Omit documentation
- Leak implementation details in interfaces

### 2. Dependency Injection

✅ **DO**:
- Inject all dependencies via constructor
- Depend on interfaces, not implementations
- Make dependencies explicit and required
- Use factory functions to wire dependencies

❌ **DON'T**:
- Create dependencies inside classes (use DI)
- Use global state or singletons
- Hide dependencies (make them explicit)

### 3. Strategy Pattern

✅ **DO**:
- Use `can_handle()` for strategy selection
- Make strategies stateless when possible
- Return empty list for NOOP cases (not None)
- Log which strategy is being used

❌ **DON'T**:
- Use if/else chains (use strategies instead)
- Hard-code strategy selection
- Make strategies depend on each other

### 4. Testing

✅ **DO**:
- Test interfaces with multiple implementations
- Use mocks for external dependencies
- Test error handling paths
- Test edge cases and boundary conditions
- Use integration tests for complete flows

❌ **DON'T**:
- Skip testing error paths
- Test only happy path
- Use real database in unit tests
- Test implementation details

### 5. Error Handling

✅ **DO**:
- Raise specific exceptions (ValueError, RuntimeError)
- Include descriptive error messages
- Log errors with context
- Document which exceptions methods raise

❌ **DON'T**:
- Raise generic Exception
- Swallow exceptions silently
- Use exceptions for control flow
- Return None to indicate errors (use exceptions)

---

## Summary

The FAQ Impact Analysis system uses proven design patterns to achieve:

1. **Testability**: Interfaces enable mocking and isolation
2. **Flexibility**: Strategy pattern enables pluggable algorithms
3. **Maintainability**: Dependency inversion reduces coupling
4. **Extensibility**: Open/closed principle enables extensions

**Key Takeaways**:
- Depend on interfaces, not implementations (DIP)
- Inject dependencies, don't create them (DI)
- Use strategies for different algorithms (Strategy Pattern)
- Keep interfaces focused (Interface Segregation)
- Test with mocks and fakes (Testability)

---

## Further Reading

- **Design Patterns**: Gang of Four (GoF) book
- **Clean Architecture**: Robert C. Martin
- **Dependency Injection**: Martin Fowler's article
- **Python ABC Module**: Python documentation
- **Testing with Mocks**: unittest.mock documentation

---

**Document Status**: ✅ Complete
**Last Updated**: 2025-11-02
