"""
Decision Reason Codes - Why a decision was made

This module defines all possible reason codes for impact decisions.
Each reason code explains WHY a particular action was chosen.

Author: Analytics Assist Team
Date: 2025-11-02
"""

from enum import Enum


class DecisionReasonCode(Enum):
    """
    Reason codes for impact decisions.

    These codes explain WHY a decision was made, providing auditability
    and traceability for all FAQ update operations.
    """

    # =========================================================================
    # NEW CONTENT reasons
    # =========================================================================
    NEW_CONTENT = "NEW_CONTENT"
    """Brand new content added to the repository"""

    # =========================================================================
    # DELETED CONTENT reasons
    # =========================================================================
    SOLE_SOURCE_DELETED = "SOLE_SOURCE_DELETED"
    """The only source for this Q/A was deleted"""

    ORPHANED = "ORPHANED"
    """All sources for this Q/A were deleted (0 remaining)"""

    MULTI_SOURCE_PARTIAL_DELETE = "MULTI_SOURCE_PARTIAL_DELETE"
    """One of multiple sources was deleted (2+ sources remain)"""

    CASCADE_FROM_QUESTION = "CASCADE_FROM_QUESTION"
    """Answer inactivated because parent question was inactivated"""

    # =========================================================================
    # MODIFIED CONTENT reasons
    # =========================================================================
    SOLE_SOURCE_MODIFIED = "SOLE_SOURCE_MODIFIED"
    """The only source for this question was modified"""

    MULTI_SOURCE_MODIFIED = "MULTI_SOURCE_MODIFIED"
    """One of multiple sources was modified"""

    SOURCE_MODIFIED_MAJOR = "SOURCE_MODIFIED_MAJOR"
    """Source changed significantly (similarity < 0.6)"""

    SOURCE_MODIFIED_MINOR = "SOURCE_MODIFIED_MINOR"
    """Source changed slightly (similarity >= 0.6)"""

    INDIRECT_TOKEN_OVERLAP = "INDIRECT_TOKEN_OVERLAP"
    """Detected via token overlap (not directly linked to source)"""

    PROVENANCE_ROLL = "PROVENANCE_ROLL"
    """Source link update (old → new checksum)"""

    # =========================================================================
    # GENERAL
    # =========================================================================
    MANUAL_DECISION = "MANUAL_DECISION"
    """User manually decided to take this action"""

    QUALITY_ISSUE = "QUALITY_ISSUE"
    """Quality threshold not met"""

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_string(cls, value: str) -> 'DecisionReasonCode':
        """
        Create enum from string value.

        Args:
            value: String value of reason code

        Returns:
            DecisionReasonCode enum

        Raises:
            ValueError: If value is not a valid reason code
        """
        try:
            return cls(value)
        except ValueError:
            raise ValueError(
                f"Invalid reason code: {value}. "
                f"Valid codes are: {', '.join([c.value for c in cls])}"
            )


# Export for convenience
__all__ = ['DecisionReasonCode']
