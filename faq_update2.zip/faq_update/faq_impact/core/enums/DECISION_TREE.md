# Impact Decision Tree

**Version**: 1.0.0
**Date**: 2025-11-02
**Module**: faq_impact.core.enums

---

## Overview

This document describes the decision tree logic for the FAQ Impact Analysis system. It shows how content changes flow through the analysis process to produce impact decisions with specific decision types and reason codes.

**Key Concept**: The decision tree maps:
- **Input**: Change type (NEW_CONTENT, MODIFIED_CONTENT, DELETED_CONTENT) + Context
- **Output**: Impact decision (DecisionType + ReasonCode + EntityType)

---

## High-Level Flow

```
Content Change Detected
         |
         v
+------------------+
| Classify Change  |  (NEW, MODIFIED, DELETED)
+------------------+
         |
         v
+------------------+
| Analyze Context  |  (Sole source? Multi-source? Similarity? Token overlap?)
+------------------+
         |
         v
+------------------+
| Select Decision  |  (DecisionType + ReasonCode)
+------------------+
         |
         v
+------------------+
| Determine Entity |  (QUESTION, ANSWER, or CHANGE)
+------------------+
         |
         v
   Impact Decision
```

---

## Decision Trees by Change Type

### 1. NEW_CONTENT Decision Tree

When new content chunks are added to the knowledge base:

```
NEW_CONTENT Detected
         |
         v
  Generate Questions
         |
         v
+------------------+
| DecisionType:    |
| PLAN_CREATE      |
+------------------+
| ReasonCode:      |
| NEW_CONTENT_ADDED|
+------------------+
| EntityType:      |
| QUESTION         |
+------------------+
| entity_id: NULL  |
| (doesn't exist)  |
+------------------+
```

**Business Logic**:
- Every new content chunk triggers question generation
- Questions don't exist yet, so `entity_id` is NULL
- After generation, answers will be created separately

**Example**:
- New PDF page added → Generate questions from page content

---

### 2. DELETED_CONTENT Decision Tree

When content chunks are removed from the knowledge base:

```
DELETED_CONTENT Detected
         |
         v
Find Affected Questions
         |
         +------------------------+
         |                        |
         v                        v
   Sole Source              Multi-Source
   (1 source)               (2+ sources)
         |                        |
         v                        v
+------------------+     +------------------+
| Similar Content  |     | Remaining Valid? |
| Exists?          |     +------------------+
+------------------+              |
         |                        +-------------+
    +----+----+                   |             |
    |         |                   v             v
   Yes       No               All Invalid    Some Valid
    |         |                   |             |
    v         v                   v             v
 REGEN_BOTH  INACTIVATE        INACTIVATE   REGEN_A
    |         |                   |             |
    v         v                   v             v
+----------+ +----------+     +----------+  +----------+
| Reason:  | | Reason:  |     | Reason:  |  | Reason:  |
| SOLE_    | | CONTENT_ |     | ALL_     |  | MULTI_   |
| SOURCE_  | | DELETED  |     | SOURCES_ |  | SOURCE_  |
| DELETED_ | |          |     | INVALID  |  | ONE_     |
| REGEN    | |          |     |          |  | MODIFIED |
+----------+ +----------+     +----------+  +----------+
```

**Business Logic**:

**Sole Source Deleted**:
- Check if similar content exists elsewhere
- If yes → Regenerate Q&A with new content (REGEN_BOTH)
- If no → Inactivate question (CONTENT_DELETED)

**Multi-Source, One Deleted**:
- Check if remaining sources are valid
- If all invalid → Inactivate (ALL_SOURCES_INVALID)
- If some valid → Regenerate answer with remaining sources (MULTI_SOURCE_ONE_MODIFIED)

**Examples**:
1. Question based on 1 chunk, chunk deleted, no replacement → INACTIVATE
2. Question based on 1 chunk, chunk deleted, similar chunk exists → REGEN_BOTH
3. Answer uses 3 chunks, 1 deleted, 2 remain valid → REGEN_A
4. Answer uses 2 chunks, both deleted → INACTIVATE

---

### 3. MODIFIED_CONTENT Decision Tree

When content chunks are modified (most complex scenario):

```
MODIFIED_CONTENT Detected
         |
         v
Calculate Similarity
(old version vs new version)
         |
         +----------------------------------+
         |                                  |
         v                                  v
   High Similarity                   Low Similarity
   (score >= 0.85)                   (score < 0.70)
         |                                  |
         v                                  v
+------------------+              +------------------+
| Minor Change     |              | Major Change     |
+------------------+              +------------------+
         |                                  |
         v                                  v
    Check Token                         Analyze
    Overlap                             Impact
         |                                  |
    +----+----+                        +----+----+
    |         |                        |         |
   Yes       No                    Sole Source Multi-Source
    |         |                        |         |
    v         v                        v         v
 REGEN_A    NOOP               +----------+  +----------+
    |         |                | REGEN_Q  |  | REGEN_A  |
    v         v                | or       |  | or       |
+----------+ +----------+      | REGEN_   |  | REGEN_   |
| Reason:  | | Reason:  |      | BOTH     |  | BOTH     |
| TOKEN_   | | BELOW_   |      +----------+  +----------+
| OVERLAP_ | | SIMILAR- |           |             |
| DETECTED | | ITY_     |           v             v
|          | | THRESH-  |      +----------+  +----------+
|          | | OLD      |      | Reason:  |  | Reason:  |
+----------+ +----------+      | SOLE_    |  | MULTI-   |
                               | SOURCE_  |  | PLE_     |
                               | MODIFIED |  | SOURCES_ |
                               | _MAJOR   |  | MODIFIED |
                               +----------+  +----------+

         |
         v
   Ambiguous Similarity
   (0.70 <= score < 0.85)
         |
         v
+------------------+
| DecisionType:    |
| EVALUATE         |
+------------------+
| ReasonCode:      |
| SIMILARITY_      |
| AMBIGUOUS        |
+------------------+
| EntityType:      |
| CHANGE           |
+------------------+
```

**Business Logic**:

**High Similarity (>= 0.85) - Minor Change**:
1. Check for token overlap between modified content and existing answers
2. If significant overlap (>= 70%) → Regenerate answer (TOKEN_OVERLAP_DETECTED)
3. If minimal overlap → No action needed (BELOW_SIMILARITY_THRESHOLD)

**Low Similarity (< 0.70) - Major Change**:
1. Determine if modified content is sole source or multi-source
2. **Sole Source**:
   - Question text likely needs updating → REGEN_Q or REGEN_BOTH
   - ReasonCode: SOLE_SOURCE_MODIFIED_MAJOR
3. **Multi-Source**:
   - Multiple sources changed → Regenerate both Q&A
   - ReasonCode: MULTIPLE_SOURCES_MODIFIED

**Ambiguous Similarity (0.70 - 0.85)**:
1. Cannot automatically decide best action
2. Create EVALUATE decision for LLM review
3. ReasonCode: SIMILARITY_AMBIGUOUS
4. EntityType: CHANGE (not targeting specific Q/A yet)
5. LLM will analyze and create follow-up decision

**Examples**:
1. "$100 limit" → "$150 limit" (similarity 0.92, token overlap) → REGEN_A
2. Complete rewrite of sole source (similarity 0.45) → REGEN_BOTH
3. Moderate change (similarity 0.78) → EVALUATE
4. Whitespace-only change (similarity 0.98) → NOOP

---

## Decision Type Reference

### PLAN_CREATE
- **When**: New content added
- **Entity**: QUESTION (to be created)
- **Reasons**: NEW_CONTENT_ADDED

### REGEN_Q
- **When**: Question text needs updating, answer still valid
- **Entity**: QUESTION (existing)
- **Reasons**: SOLE_SOURCE_MODIFIED_MAJOR, SOLE_SOURCE_CONTENT_CHANGED

### REGEN_A
- **When**: Answer needs updating, question still valid
- **Entity**: ANSWER (existing)
- **Reasons**: MULTI_SOURCE_ONE_MODIFIED, ANSWER_FACTS_CHANGED, TOKEN_OVERLAP_DETECTED

### REGEN_BOTH
- **When**: Both question and answer need updating
- **Entity**: QUESTION (regenerates both Q+A together)
- **Reasons**: SOLE_SOURCE_DELETED_REGEN, MAJOR_CONTENT_RESTRUCTURE, MULTIPLE_SOURCES_MODIFIED

### INACTIVATE
- **When**: Content deleted, sources invalid, quality issues
- **Entity**: QUESTION or ANSWER
- **Reasons**: CONTENT_DELETED, SOLE_SOURCE_INVALID, ALL_SOURCES_INVALID, QUALITY_BELOW_THRESHOLD, ORPHANED_QUESTION, ORPHANED_ANSWER

### EVALUATE
- **When**: Cannot automatically decide, needs LLM review
- **Entity**: CHANGE (not specific Q/A yet)
- **Reasons**: SIMILARITY_AMBIGUOUS, PARTIAL_TOKEN_OVERLAP, MULTIPLE_CANDIDATES, EDGE_CASE_DETECTED, MANUAL_REVIEW_REQUESTED

### NOOP
- **When**: No action needed
- **Entity**: CHANGE
- **Reasons**: CONTENT_UNCHANGED, MINOR_FORMATTING_CHANGE, BELOW_SIMILARITY_THRESHOLD, ALREADY_HANDLED, NOT_APPLICABLE

---

## Entity Type Selection Rules

| Decision Type | Valid Entity Types | Notes |
|--------------|-------------------|-------|
| PLAN_CREATE | QUESTION | Question doesn't exist yet (entity_id = NULL) |
| REGEN_Q | QUESTION | Targets existing question |
| REGEN_A | ANSWER | Targets existing answer |
| REGEN_BOTH | QUESTION | Regenerates both, but decision targets question entity |
| INACTIVATE | QUESTION, ANSWER | Can inactivate either questions or answers |
| EVALUATE | CHANGE | Decision about the change itself, not specific Q/A |
| NOOP | CHANGE | No entity targeted, just recording decision |

---

## Similarity Thresholds

Reference thresholds used in decision tree:

| Threshold | Value | Meaning | Action |
|-----------|-------|---------|--------|
| IDENTICAL | >= 0.95 | Essentially same content | NOOP |
| MINOR_MODIFICATION | >= 0.85 | Small changes (numbers, dates) | Check token overlap → REGEN_A or NOOP |
| MAJOR_MODIFICATION | >= 0.70 | Significant changes | Likely REGEN_Q or REGEN_BOTH |
| SIGNIFICANT_CHANGE | >= 0.40 | Large structural changes | REGEN_BOTH or EVALUATE |
| NEW_CONTENT | < 0.40 | Completely different | REGEN_BOTH or INACTIVATE + PLAN_CREATE |

**Ambiguous Range**: 0.70 - 0.85
- Too similar to ignore, too different to treat as minor
- Triggers EVALUATE decision for LLM review

---

## Token Overlap Detection

Used for detecting factual changes in minor modifications:

```
Modified Content Detected
         |
         v
Calculate Token Sets
(old_tokens, new_tokens, answer_tokens)
         |
         v
Calculate Overlaps
- overlap_with_old = |answer ∩ old| / |answer|
- overlap_with_new = |answer ∩ new| / |answer|
         |
         v
Changed Tokens = (old - new) ∪ (new - old)
         |
         v
Answer Uses Changed Tokens?
         |
    +----+----+
    |         |
   Yes       No
    |         |
    v         v
 REGEN_A    NOOP
    |
    v
+------------------+
| ReasonCode:      |
| TOKEN_OVERLAP_   |
| DETECTED         |
+------------------+
```

**Example**:
- Old: "The limit is $100 per transaction"
- New: "The limit is $150 per transaction"
- Answer: "You can spend up to $100 per transaction"
- Changed tokens: {$100, $150}
- Answer contains "$100" → Token overlap detected → REGEN_A

---

## Inactivation Cascading

When questions are inactivated, answers must cascade:

```
Question Inactivated
(reason: CONTENT_DELETED, SOLE_SOURCE_INVALID, etc.)
         |
         v
Find All Answers for Question
         |
         v
For Each Answer:
         |
         v
+------------------+
| DecisionType:    |
| INACTIVATE       |
+------------------+
| ReasonCode:      |
| (from question)  |  ← Inherits question's reason
+------------------+
| EntityType:      |
| ANSWER           |
+------------------+
| Set is_active=   |
| False            |
+------------------+
| inactivation_    |
| reason:          |
| QUESTION_        |  ← Special cascade reason
| INACTIVATED      |
+------------------+
```

**Note**: Answers get TWO pieces of information:
1. **Impact decision reason**: Why the question was inactivated (e.g., CONTENT_DELETED)
2. **Database inactivation_reason**: QUESTION_INACTIVATED (indicates cascade)

---

## LLM Evaluation Path

When EVALUATE decisions are created:

```
EVALUATE Decision Created
         |
         v
Store in faq_impact table
(application_status = PENDING)
         |
         v
Apply Plan Phase:
LLM Evaluator Service
         |
         v
LLM Analyzes Change
(prompt with old content, new content, question, answer)
         |
         v
LLM Returns Recommendation
         |
    +----+----+
    |         |
    v         v
 Specific   Keep
 Action     Existing
    |         |
    v         v
Create     Mark EVALUATE
Follow-up  as COMPLETED
Decision   (no action)
    |
    v
(REGEN_Q, REGEN_A, REGEN_BOTH, INACTIVATE, or NOOP)
         |
         v
New Decision Created
(with LLM's recommended DecisionType + ReasonCode)
```

**Key Points**:
- EVALUATE decisions don't directly mutate Q/A tables
- LLM creates follow-up executable decisions
- Follow-up decisions have their own reason codes
- Original EVALUATE decision marked COMPLETED after LLM review

---

## Edge Cases

### Orphaned Questions

Questions with no valid sources remaining:

```
Question Exists
         |
         v
Check Source Validity
         |
         v
All Sources Deleted/Invalid
         |
         v
+------------------+
| DecisionType:    |
| INACTIVATE       |
+------------------+
| ReasonCode:      |
| ORPHANED_        |
| QUESTION         |
+------------------+
```

### Orphaned Answers

Answers whose parent question was deleted:

```
Answer Exists
         |
         v
Check Parent Question
         |
         v
Question Missing/Inactive
         |
         v
+------------------+
| DecisionType:    |
| INACTIVATE       |
+------------------+
| ReasonCode:      |
| ORPHANED_ANSWER  |
+------------------+
```

### Multiple Simultaneous Changes

```
Multiple Changes Detected
(same content chunk, same run)
         |
         v
Process First Change
         |
         v
Create Decision
         |
         v
Process Subsequent Changes
         |
         v
Check for Existing Decision
         |
    +----+----+
    |         |
   Found     Not Found
    |         |
    v         v
  NOOP      Normal
    |       Processing
    v
+------------------+
| ReasonCode:      |
| ALREADY_HANDLED  |
+------------------+
```

---

## Implementation Notes

### Strategy Pattern

The decision tree is implemented using the Strategy Pattern:

- `NewContentStrategy`: Handles NEW_CONTENT path
- `DeletedContentStrategy`: Handles DELETED_CONTENT path
- `ModifiedContentStrategy`: Handles MODIFIED_CONTENT path

Each strategy encapsulates the decision logic for its change type.

### Validation

All decisions are validated using `validators.py`:

```python
from faq_impact.core.enums import validate_impact_decision

validate_impact_decision(
    entity_type=EntityType.QUESTION,
    entity_id=None,
    decision_type=DecisionType.PLAN_CREATE,
    reason_code=ReasonCode.NEW_CONTENT_ADDED,
    application_status=ApplicationStatus.PENDING
)
```

### Serialization

Decisions are stored in the `faq_impact` table with:
- `decision_type`, `reason_code`, `entity_type`: VARCHAR enum values
- `details`: JSONB column with additional context (similarity scores, token overlap, etc.)

Use `serialization.py` helpers to serialize/deserialize enums in the `details` JSON.

---

## Summary

The decision tree maps content changes to impact decisions through:

1. **Change Classification**: NEW, MODIFIED, DELETED
2. **Context Analysis**: Sole source? Multi-source? Similarity? Token overlap?
3. **Decision Selection**: Choose DecisionType + ReasonCode based on rules
4. **Entity Determination**: QUESTION, ANSWER, or CHANGE
5. **Validation**: Ensure decision is valid and internally consistent

This systematic approach ensures:
- **Consistency**: Same changes produce same decisions
- **Auditability**: Every decision has a clear reason
- **Safety**: Read-only analysis phase, mutations only in apply phase
- **Flexibility**: LLM evaluation for ambiguous cases

---

**Version History**:
- 1.0.0 (2025-11-02): Initial decision tree documentation
