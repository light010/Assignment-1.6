"""
Enum Serialization Helpers

This module provides utilities for serializing and deserializing enums to/from
JSON format. This is essential for storing enum values in the faq_impact.details
JSONB column and for API responses.

Functions:
    - serialize_enum: Convert enum to JSON-serializable value
    - deserialize_enum: Convert JSON value back to enum
    - serialize_enum_dict: Serialize dictionary containing enums
    - deserialize_enum_dict: Deserialize dictionary with enum values

Author: Analytics Assist Team
Date: 2025-11-02
"""

import json
from enum import Enum
from typing import Any, Dict, List, Type, TypeVar, Union, Optional

from .decision_type import DecisionType, ApplicationStatus
from .entity_type import EntityType, InactivationReason
from .reason_code import ReasonCode
from .similarity_method import SimilarityMethod


# Type variable for enum types
E = TypeVar("E", bound=Enum)


class EnumSerializationError(Exception):
    """
    Exception raised when enum serialization/deserialization fails.

    This exception provides detailed error messages about what went wrong
    during the conversion process.
    """

    pass


# Registry of known enum types for deserialization
ENUM_TYPE_REGISTRY: Dict[str, Type[Enum]] = {
    "DecisionType": DecisionType,
    "ApplicationStatus": ApplicationStatus,
    "EntityType": EntityType,
    "InactivationReason": InactivationReason,
    "ReasonCode": ReasonCode,
    "SimilarityMethod": SimilarityMethod,
}


def serialize_enum(value: Enum) -> Dict[str, str]:
    """
    Serialize an enum to a JSON-serializable dictionary.

    The serialized format includes both the enum type and value, enabling
    type-safe deserialization.

    Args:
        value: Enum instance to serialize

    Returns:
        Dictionary with '__enum_type__' and 'value' keys

    Example:
        >>> from faq_impact.core.enums import DecisionType
        >>> serialize_enum(DecisionType.PLAN_CREATE)
        {'__enum_type__': 'DecisionType', 'value': 'PLAN_CREATE'}
        >>>
        >>> # Serialized format is JSON-compatible
        >>> import json
        >>> json.dumps(serialize_enum(DecisionType.REGEN_Q))
        '{"__enum_type__": "DecisionType", "value": "REGEN_Q"}'

    Design Notes:
        - '__enum_type__' prefix indicates this is a serialized enum
        - Enables type-safe deserialization without additional metadata
        - Works with all enum types in the system
    """
    if not isinstance(value, Enum):
        raise EnumSerializationError(
            f"Expected Enum instance, got {type(value).__name__}"
        )

    enum_type_name = type(value).__name__

    return {
        "__enum_type__": enum_type_name,
        "value": value.value,
    }


def deserialize_enum(
    data: Union[Dict[str, str], str],
    enum_type: Optional[Type[E]] = None,
) -> E:
    """
    Deserialize a JSON value back to an enum instance.

    Supports two formats:
    1. Dictionary with '__enum_type__' and 'value' (from serialize_enum)
    2. Plain string value (requires enum_type parameter)

    Args:
        data: Serialized enum data (dict or string)
        enum_type: Optional enum type to deserialize to (required for string data)

    Returns:
        Enum instance

    Raises:
        EnumSerializationError: If deserialization fails

    Example:
        >>> from faq_impact.core.enums import DecisionType
        >>>
        >>> # Deserialize from dictionary (type-safe)
        >>> data = {'__enum_type__': 'DecisionType', 'value': 'PLAN_CREATE'}
        >>> deserialize_enum(data)
        <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
        >>>
        >>> # Deserialize from string (requires enum_type)
        >>> deserialize_enum('REGEN_Q', enum_type=DecisionType)
        <DecisionType.REGEN_Q: 'REGEN_Q'>
        >>>
        >>> # Invalid value
        >>> deserialize_enum('INVALID', enum_type=DecisionType)
        Traceback (most recent call last):
            ...
        EnumSerializationError: ...

    Design Notes:
        - Dictionary format is preferred (type-safe, no ambiguity)
        - String format is convenient for manual construction
        - Uses ENUM_TYPE_REGISTRY for type lookup
    """
    # Handle dictionary format (type-safe)
    if isinstance(data, dict):
        if "__enum_type__" not in data or "value" not in data:
            raise EnumSerializationError(
                f"Invalid enum serialization format. Expected keys: "
                f"'__enum_type__' and 'value', got: {list(data.keys())}"
            )

        enum_type_name = data["__enum_type__"]
        enum_value = data["value"]

        if enum_type_name not in ENUM_TYPE_REGISTRY:
            raise EnumSerializationError(
                f"Unknown enum type '{enum_type_name}'. "
                f"Known types: {list(ENUM_TYPE_REGISTRY.keys())}"
            )

        target_enum_type = ENUM_TYPE_REGISTRY[enum_type_name]

    # Handle string format (requires enum_type parameter)
    elif isinstance(data, str):
        if enum_type is None:
            raise EnumSerializationError(
                "enum_type parameter is required when deserializing from string"
            )
        target_enum_type = enum_type
        enum_value = data

    else:
        raise EnumSerializationError(
            f"Expected dict or str, got {type(data).__name__}"
        )

    # Deserialize to enum
    try:
        return target_enum_type(enum_value)  # type: ignore
    except ValueError as e:
        valid_values = [e.value for e in target_enum_type]  # type: ignore
        raise EnumSerializationError(
            f"'{enum_value}' is not a valid {target_enum_type.__name__}. "
            f"Valid values: {valid_values}"
        ) from e


def serialize_enum_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Serialize a dictionary that may contain enum values.

    Recursively processes the dictionary, serializing any enum values found.
    Non-enum values are preserved as-is.

    Args:
        data: Dictionary that may contain enum values

    Returns:
        Dictionary with enums serialized to JSON-compatible format

    Example:
        >>> from faq_impact.core.enums import DecisionType, ReasonCode
        >>> data = {
        ...     'decision': DecisionType.PLAN_CREATE,
        ...     'reason': ReasonCode.NEW_CONTENT_ADDED,
        ...     'count': 5,
        ...     'nested': {
        ...         'status': ApplicationStatus.PENDING
        ...     }
        ... }
        >>> result = serialize_enum_dict(data)
        >>> result['decision']['__enum_type__']
        'DecisionType'
        >>> result['count']
        5

    Design Notes:
        - Handles nested dictionaries and lists
        - Preserves non-enum values unchanged
        - Suitable for storing in JSONB columns
    """
    result = {}

    for key, value in data.items():
        if isinstance(value, Enum):
            # Serialize enum
            result[key] = serialize_enum(value)
        elif isinstance(value, dict):
            # Recursively serialize nested dict
            result[key] = serialize_enum_dict(value)
        elif isinstance(value, list):
            # Serialize list items
            result[key] = [
                serialize_enum(item) if isinstance(item, Enum) else item
                for item in value
            ]
        else:
            # Preserve non-enum values
            result[key] = value

    return result


def deserialize_enum_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deserialize a dictionary that may contain serialized enum values.

    Recursively processes the dictionary, deserializing any enum values found.
    Non-enum values are preserved as-is.

    Args:
        data: Dictionary that may contain serialized enum values

    Returns:
        Dictionary with enums deserialized to enum instances

    Example:
        >>> data = {
        ...     'decision': {'__enum_type__': 'DecisionType', 'value': 'PLAN_CREATE'},
        ...     'reason': {'__enum_type__': 'ReasonCode', 'value': 'NEW_CONTENT_ADDED'},
        ...     'count': 5,
        ...     'nested': {
        ...         'status': {'__enum_type__': 'ApplicationStatus', 'value': 'PENDING'}
        ...     }
        ... }
        >>> result = deserialize_enum_dict(data)
        >>> result['decision']
        <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
        >>> result['count']
        5

    Design Notes:
        - Handles nested dictionaries and lists
        - Preserves non-enum values unchanged
        - Suitable for reading from JSONB columns
    """
    result = {}

    for key, value in data.items():
        if isinstance(value, dict) and "__enum_type__" in value:
            # Deserialize enum
            result[key] = deserialize_enum(value)
        elif isinstance(value, dict):
            # Recursively deserialize nested dict
            result[key] = deserialize_enum_dict(value)
        elif isinstance(value, list):
            # Deserialize list items
            result[key] = [
                (
                    deserialize_enum(item)
                    if isinstance(item, dict) and "__enum_type__" in item
                    else item
                )
                for item in value
            ]
        else:
            # Preserve non-enum values
            result[key] = value

    return result


def to_json_string(data: Dict[str, Any], indent: Optional[int] = None) -> str:
    """
    Convert dictionary with enums to JSON string.

    Convenience function that serializes enums and converts to JSON in one step.

    Args:
        data: Dictionary that may contain enum values
        indent: Optional indentation for pretty printing

    Returns:
        JSON string with serialized enums

    Example:
        >>> from faq_impact.core.enums import DecisionType
        >>> data = {'decision': DecisionType.PLAN_CREATE, 'count': 5}
        >>> json_str = to_json_string(data, indent=2)
        >>> 'PLAN_CREATE' in json_str
        True
        >>> '"count": 5' in json_str
        True
    """
    serialized = serialize_enum_dict(data)
    return json.dumps(serialized, indent=indent)


def from_json_string(json_str: str) -> Dict[str, Any]:
    """
    Parse JSON string and deserialize enums.

    Convenience function that parses JSON and deserializes enums in one step.

    Args:
        json_str: JSON string that may contain serialized enums

    Returns:
        Dictionary with deserialized enum instances

    Raises:
        json.JSONDecodeError: If JSON is invalid
        EnumSerializationError: If enum deserialization fails

    Example:
        >>> json_str = '''
        ... {
        ...   "decision": {
        ...     "__enum_type__": "DecisionType",
        ...     "value": "PLAN_CREATE"
        ...   },
        ...   "count": 5
        ... }
        ... '''
        >>> data = from_json_string(json_str)
        >>> data['decision']
        <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
    """
    parsed = json.loads(json_str)
    if not isinstance(parsed, dict):
        raise EnumSerializationError(
            f"Expected JSON object, got {type(parsed).__name__}"
        )
    return deserialize_enum_dict(parsed)


def register_enum_type(enum_type: Type[Enum]) -> None:
    """
    Register a new enum type for serialization/deserialization.

    This allows custom enum types to be used with the serialization system.
    All built-in impact analysis enums are pre-registered.

    Args:
        enum_type: Enum class to register

    Example:
        >>> from enum import Enum
        >>> class CustomEnum(Enum):
        ...     OPTION_A = "OPTION_A"
        ...     OPTION_B = "OPTION_B"
        >>> register_enum_type(CustomEnum)
        >>> # Now CustomEnum can be serialized/deserialized
    """
    if not issubclass(enum_type, Enum):
        raise EnumSerializationError(
            f"Expected Enum subclass, got {enum_type.__name__}"
        )

    enum_type_name = enum_type.__name__
    ENUM_TYPE_REGISTRY[enum_type_name] = enum_type


def get_registered_enum_types() -> List[str]:
    """
    Get list of all registered enum type names.

    Returns:
        List of enum type names available for deserialization

    Example:
        >>> types = get_registered_enum_types()
        >>> 'DecisionType' in types
        True
        >>> 'ReasonCode' in types
        True
    """
    return list(ENUM_TYPE_REGISTRY.keys())


# Convenience exports
__all__ = [
    "EnumSerializationError",
    "serialize_enum",
    "deserialize_enum",
    "serialize_enum_dict",
    "deserialize_enum_dict",
    "to_json_string",
    "from_json_string",
    "register_enum_type",
    "get_registered_enum_types",
    "ENUM_TYPE_REGISTRY",
]
