"""
Core Enumerations - Type-Safe Classifications

This module defines enumerations for all classifications in the FAQ impact
analysis domain. Using enums provides type safety, IDE autocomplete, and
clear documentation of valid values.

Key Enums:
    - DecisionType: PLAN_CREATE, REGEN_Q, REGEN_A, REGEN_BOTH, INACTIVATE, EVALUATE, NOOP
    - ApplicationStatus: PENDING, IN_PROGRESS, COMPLETED, FAILED, SKIPPED
    - EntityType: QUESTION, ANSWER, CHANGE
    - InactivationReason: CONTENT_DELETED, ALL_SOURCES_INVALID, MANUAL, QUALITY_ISSUE, QUESTION_INACTIVATED
    - ReasonCode: Comprehensive reason codes for each decision type
    - SimilarityMethod: TOKEN_OVERLAP, JACCARD_THRESHOLD, SEQUENCE_SIMILARITY, HYBRID, etc.

Utilities:
    - Validators: validate_impact_decision, validate_decision_reason_compatibility, etc.
    - Serialization: serialize_enum, deserialize_enum, serialize_enum_dict, etc.

Design Benefits:
    - Type Safety: Invalid values rejected at runtime
    - Discoverability: IDE shows all valid options
    - Maintainability: Centralized definition of valid values
    - Documentation: Self-documenting code
    - Validation: Business rules enforced via validators
    - Serialization: Easy storage in JSON/database

Example:
    >>> from faq_impact.core.enums import (
    ...     DecisionType,
    ...     ReasonCode,
    ...     EntityType,
    ...     ApplicationStatus,
    ...     validate_impact_decision
    ... )
    >>>
    >>> # Create and validate an impact decision
    >>> validate_impact_decision(
    ...     entity_type=EntityType.QUESTION,
    ...     entity_id=None,
    ...     decision_type=DecisionType.PLAN_CREATE,
    ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
    ...     application_status=ApplicationStatus.PENDING
    ... )  # No exception - valid decision
    >>>
    >>> # Serialize enum for JSON storage
    >>> from faq_impact.core.enums import serialize_enum
    >>> serialized = serialize_enum(DecisionType.PLAN_CREATE)
    >>> serialized
    {'__enum_type__': 'DecisionType', 'value': 'PLAN_CREATE'}

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Import enums
from .decision_type import DecisionType, ApplicationStatus
from .entity_type import EntityType, InactivationReason
from .reason_code import ReasonCode
from .similarity_method import SimilarityMethod
from .decision_reason_code import DecisionReasonCode  # NEW - Analyze-Execute Architecture

# Import validators
from .validators import (
    EnumValidationError,
    validate_decision_reason_compatibility,
    validate_entity_decision_compatibility,
    validate_entity_id_requirement,
    validate_impact_decision,
    validate_status_transition,
    validate_inactivation_reason_for_entity,
    get_validation_errors,
)

# Import serialization utilities
from .serialization import (
    EnumSerializationError,
    serialize_enum,
    deserialize_enum,
    serialize_enum_dict,
    deserialize_enum_dict,
    to_json_string,
    from_json_string,
    register_enum_type,
    get_registered_enum_types,
    ENUM_TYPE_REGISTRY,
)

# Export all
__all__ = [
    # Enums - Decision Types
    "DecisionType",
    "ApplicationStatus",
    # Enums - Entity Types
    "EntityType",
    "InactivationReason",
    # Enums - Reason Codes
    "ReasonCode",
    "DecisionReasonCode",  # NEW - Analyze-Execute Architecture
    # Enums - Similarity Methods
    "SimilarityMethod",
    # Validators
    "EnumValidationError",
    "validate_decision_reason_compatibility",
    "validate_entity_decision_compatibility",
    "validate_entity_id_requirement",
    "validate_impact_decision",
    "validate_status_transition",
    "validate_inactivation_reason_for_entity",
    "get_validation_errors",
    # Serialization
    "EnumSerializationError",
    "serialize_enum",
    "deserialize_enum",
    "serialize_enum_dict",
    "deserialize_enum_dict",
    "to_json_string",
    "from_json_string",
    "register_enum_type",
    "get_registered_enum_types",
    "ENUM_TYPE_REGISTRY",
]
