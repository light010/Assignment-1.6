"""
ReasonCode Enumeration

This module defines comprehensive reason codes for impact decisions in the
FAQ impact analysis system. Each reason code explains WHY a particular
decision type was chosen.

Enums:
    - ReasonCode: Detailed reasons for each decision type

Author: Analytics Assist Team
Date: 2025-11-02
"""

from enum import Enum
from typing import Dict, List, Set


class ReasonCode(Enum):
    """
    Comprehensive reason codes for impact decisions.

    Each impact decision has a decision_type (WHAT to do) and a reason_code
    (WHY we're doing it). This enum provides detailed, auditable reasons for
    every decision, grouped by the decision type they apply to.

    Reason codes enable:
    - Audit trails: Understanding historical decisions
    - Debugging: Diagnosing why certain decisions were made
    - Filtering: Querying decisions by reason (e.g., all token overlap cases)
    - Documentation: Self-documenting decision logic

    Reason Codes by Decision Type:

    PLAN_CREATE Reasons (new question generation):
        NEW_CONTENT_ADDED: New content chunk detected, generate questions
            Example: New PDF page added to knowledge base

    REGEN_Q Reasons (regenerate question only):
        SOLE_SOURCE_MODIFIED_MAJOR: Question's only source changed significantly
            Example: Question based on 1 chunk, chunk heavily edited
        SOLE_SOURCE_CONTENT_CHANGED: Sole source content changed moderately
            Example: Single source updated, question may need rephrasing

    REGEN_A Reasons (regenerate answer only):
        MULTI_SOURCE_ONE_MODIFIED: One of multiple sources changed
            Example: Answer uses 3 chunks, 1 chunk updated → regen answer
        ANSWER_FACTS_CHANGED: Answer content facts changed
            Example: "Limit is $100" → "$150", regenerate answer
        TOKEN_OVERLAP_DETECTED: Significant token overlap in modified content
            Example: Modified chunk shares 70% tokens with answer → regen

    REGEN_BOTH Reasons (regenerate both Q and A):
        SOLE_SOURCE_DELETED_REGEN: Sole source deleted, but similar content exists
            Example: Original chunk deleted, new similar chunk available
        MAJOR_CONTENT_RESTRUCTURE: Content significantly restructured
            Example: Entire section rewritten, regen full FAQ pair
        MULTIPLE_SOURCES_MODIFIED: Multiple sources changed simultaneously
            Example: 2+ sources for answer modified → regen everything

    INACTIVATE Reasons:
        CONTENT_DELETED: Source content was deleted
            Example: PDF page removed → inactivate dependent questions
        SOLE_SOURCE_INVALID: Question's only source is now invalid
            Example: Sole source marked as low quality → inactivate
        ALL_SOURCES_INVALID: All sources for Q/A are invalid
            Example: Multi-source answer lost all valid sources
        QUALITY_BELOW_THRESHOLD: Quality check failed
            Example: LLM evaluation score < 0.5 → inactivate
        ORPHANED_QUESTION: Question has no valid sources
            Example: All sources deleted over time → orphaned
        ORPHANED_ANSWER: Answer has no parent question
            Example: Question deleted but answer remains

    EVALUATE Reasons (needs LLM evaluation):
        SIMILARITY_AMBIGUOUS: Similarity score in ambiguous range
            Example: 0.75 similarity - unclear if regen needed
        PARTIAL_TOKEN_OVERLAP: Some token overlap, but not decisive
            Example: 40% overlap - needs LLM to decide
        MULTIPLE_CANDIDATES: Multiple conflicting decisions possible
            Example: Could be REGEN_Q or REGEN_A - need LLM input
        EDGE_CASE_DETECTED: Unusual edge case scenario
            Example: Complex multi-source scenario
        MANUAL_REVIEW_REQUESTED: User explicitly requested review
            Example: User flagged for manual inspection

    NOOP Reasons (no action needed):
        CONTENT_UNCHANGED: Content identical after normalization
            Example: Formatting-only change, no semantic difference
        MINOR_FORMATTING_CHANGE: Only formatting changed
            Example: Whitespace or punctuation changes
        BELOW_SIMILARITY_THRESHOLD: Change too small to matter
            Example: 0.98 similarity → essentially identical
        ALREADY_HANDLED: Decision already exists for this change
            Example: Duplicate detection prevented re-processing
        NOT_APPLICABLE: Decision not applicable to this entity
            Example: Answer-only change, question decision NOOP

    Example:
        >>> from faq_impact.core.enums import ReasonCode, DecisionType
        >>>
        >>> # Get reason code
        >>> reason = ReasonCode.NEW_CONTENT_ADDED
        >>> reason.value
        'NEW_CONTENT_ADDED'
        >>>
        >>> # Check which decision type it applies to
        >>> reason.get_decision_type()
        <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
        >>>
        >>> # Get all reasons for a decision type
        >>> ReasonCode.get_reasons_for_decision(DecisionType.REGEN_A)
        [<ReasonCode.MULTI_SOURCE_ONE_MODIFIED: ...>, ...]
        >>>
        >>> # Validate decision-reason compatibility
        >>> ReasonCode.is_compatible(DecisionType.PLAN_CREATE, ReasonCode.NEW_CONTENT_ADDED)
        True
        >>> ReasonCode.is_compatible(DecisionType.REGEN_Q, ReasonCode.NEW_CONTENT_ADDED)
        False

    Design Notes:
        - Each reason code maps to exactly one decision type
        - Reason codes are grouped logically by decision type
        - Stored in: faq_impact.reason_code column (VARCHAR)
        - Used in audit queries and debugging
    """

    # PLAN_CREATE Reasons
    NEW_CONTENT_ADDED = "NEW_CONTENT_ADDED"

    # REGEN_Q Reasons
    SOLE_SOURCE_MODIFIED_MAJOR = "SOLE_SOURCE_MODIFIED_MAJOR"
    SOLE_SOURCE_CONTENT_CHANGED = "SOLE_SOURCE_CONTENT_CHANGED"

    # REGEN_A Reasons
    MULTI_SOURCE_ONE_MODIFIED = "MULTI_SOURCE_ONE_MODIFIED"
    ANSWER_FACTS_CHANGED = "ANSWER_FACTS_CHANGED"
    TOKEN_OVERLAP_DETECTED = "TOKEN_OVERLAP_DETECTED"

    # REGEN_BOTH Reasons
    SOLE_SOURCE_DELETED_REGEN = "SOLE_SOURCE_DELETED_REGEN"
    MAJOR_CONTENT_RESTRUCTURE = "MAJOR_CONTENT_RESTRUCTURE"
    MULTIPLE_SOURCES_MODIFIED = "MULTIPLE_SOURCES_MODIFIED"

    # INACTIVATE Reasons
    CONTENT_DELETED = "CONTENT_DELETED"
    SOLE_SOURCE_INVALID = "SOLE_SOURCE_INVALID"
    ALL_SOURCES_INVALID = "ALL_SOURCES_INVALID"
    QUALITY_BELOW_THRESHOLD = "QUALITY_BELOW_THRESHOLD"
    ORPHANED_QUESTION = "ORPHANED_QUESTION"
    ORPHANED_ANSWER = "ORPHANED_ANSWER"

    # EVALUATE Reasons
    SIMILARITY_AMBIGUOUS = "SIMILARITY_AMBIGUOUS"
    PARTIAL_TOKEN_OVERLAP = "PARTIAL_TOKEN_OVERLAP"
    MULTIPLE_CANDIDATES = "MULTIPLE_CANDIDATES"
    EDGE_CASE_DETECTED = "EDGE_CASE_DETECTED"
    MANUAL_REVIEW_REQUESTED = "MANUAL_REVIEW_REQUESTED"

    # NOOP Reasons
    CONTENT_UNCHANGED = "CONTENT_UNCHANGED"
    MINOR_FORMATTING_CHANGE = "MINOR_FORMATTING_CHANGE"
    BELOW_SIMILARITY_THRESHOLD = "BELOW_SIMILARITY_THRESHOLD"
    ALREADY_HANDLED = "ALREADY_HANDLED"
    NOT_APPLICABLE = "NOT_APPLICABLE"

    def __str__(self) -> str:
        """
        Return string representation of the reason code.

        Returns:
            String value of the enum

        Example:
            >>> str(ReasonCode.NEW_CONTENT_ADDED)
            'NEW_CONTENT_ADDED'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for database storage.

        Returns:
            String value suitable for VARCHAR column

        Example:
            >>> ReasonCode.TOKEN_OVERLAP_DETECTED.to_string()
            'TOKEN_OVERLAP_DETECTED'
        """
        return self.value

    def get_decision_type(self) -> "DecisionType":
        """
        Get the decision type this reason code applies to.

        Returns:
            DecisionType enum that this reason is valid for

        Example:
            >>> ReasonCode.NEW_CONTENT_ADDED.get_decision_type()
            <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
            >>> ReasonCode.TOKEN_OVERLAP_DETECTED.get_decision_type()
            <DecisionType.REGEN_A: 'REGEN_A'>

        Note:
            Import DecisionType inline to avoid circular imports
        """
        from .decision_type import DecisionType

        return _REASON_TO_DECISION_MAP[self]

    def get_description(self) -> str:
        """
        Get human-readable description of this reason code.

        Returns:
            Description string explaining the reason

        Example:
            >>> desc = ReasonCode.NEW_CONTENT_ADDED.get_description()
            >>> "new content" in desc.lower()
            True
        """
        return _REASON_DESCRIPTIONS.get(
            self, "No description available for this reason code"
        )

    @classmethod
    def from_string(cls, value: str) -> "ReasonCode":
        """
        Create ReasonCode from string value.

        Args:
            value: String representation of reason code

        Returns:
            ReasonCode enum instance

        Raises:
            ValueError: If value is not a valid ReasonCode

        Example:
            >>> ReasonCode.from_string("NEW_CONTENT_ADDED")
            <ReasonCode.NEW_CONTENT_ADDED: 'NEW_CONTENT_ADDED'>
            >>> ReasonCode.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid ReasonCode
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid ReasonCode. "
                f"Valid values: {valid_values}"
            )

    @classmethod
    def get_reasons_for_decision(cls, decision_type: "DecisionType") -> List["ReasonCode"]:
        """
        Get all reason codes valid for a given decision type.

        Args:
            decision_type: DecisionType to get reasons for

        Returns:
            List of ReasonCode enums valid for this decision type

        Example:
            >>> from faq_update.faq_impact.core.enums import DecisionType
            >>> reasons = ReasonCode.get_reasons_for_decision(DecisionType.PLAN_CREATE)
            >>> ReasonCode.NEW_CONTENT_ADDED in reasons
            True
            >>> ReasonCode.TOKEN_OVERLAP_DETECTED in reasons
            False
        """
        return [
            reason
            for reason in cls
            if reason.get_decision_type() == decision_type
        ]

    @classmethod
    def is_compatible(cls, decision_type: "DecisionType", reason_code: "ReasonCode") -> bool:
        """
        Check if a reason code is compatible with a decision type.

        Args:
            decision_type: DecisionType to validate against
            reason_code: ReasonCode to check

        Returns:
            True if reason_code is valid for decision_type

        Example:
            >>> from faq_update.faq_impact.core.enums import DecisionType
            >>> ReasonCode.is_compatible(
            ...     DecisionType.PLAN_CREATE,
            ...     ReasonCode.NEW_CONTENT_ADDED
            ... )
            True
            >>> ReasonCode.is_compatible(
            ...     DecisionType.REGEN_Q,
            ...     ReasonCode.NEW_CONTENT_ADDED
            ... )
            False
        """
        return reason_code.get_decision_type() == decision_type

    @classmethod
    def get_reasons_by_category(cls) -> Dict[str, List["ReasonCode"]]:
        """
        Get reason codes grouped by decision type category.

        Returns:
            Dictionary mapping decision type names to reason code lists

        Example:
            >>> reasons_by_category = ReasonCode.get_reasons_by_category()
            >>> 'PLAN_CREATE' in reasons_by_category
            True
            >>> len(reasons_by_category['REGEN_A']) >= 1
            True
        """
        from .decision_type import DecisionType

        result: Dict[str, List[ReasonCode]] = {}
        for decision_type in DecisionType:
            result[decision_type.value] = cls.get_reasons_for_decision(decision_type)
        return result


# Mapping: ReasonCode → DecisionType
# This defines which reason codes are valid for which decision types
# Import DecisionType inline in methods to avoid circular import
def _build_reason_to_decision_map() -> Dict["ReasonCode", "DecisionType"]:
    """Build mapping from reason codes to decision types."""
    from .decision_type import DecisionType

    return {
        # PLAN_CREATE
        ReasonCode.NEW_CONTENT_ADDED: DecisionType.PLAN_CREATE,
        # REGEN_Q
        ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR: DecisionType.REGEN_Q,
        ReasonCode.SOLE_SOURCE_CONTENT_CHANGED: DecisionType.REGEN_Q,
        # REGEN_A
        ReasonCode.MULTI_SOURCE_ONE_MODIFIED: DecisionType.REGEN_A,
        ReasonCode.ANSWER_FACTS_CHANGED: DecisionType.REGEN_A,
        ReasonCode.TOKEN_OVERLAP_DETECTED: DecisionType.REGEN_A,
        # REGEN_BOTH
        ReasonCode.SOLE_SOURCE_DELETED_REGEN: DecisionType.REGEN_BOTH,
        ReasonCode.MAJOR_CONTENT_RESTRUCTURE: DecisionType.REGEN_BOTH,
        ReasonCode.MULTIPLE_SOURCES_MODIFIED: DecisionType.REGEN_BOTH,
        # INACTIVATE
        ReasonCode.CONTENT_DELETED: DecisionType.INACTIVATE,
        ReasonCode.SOLE_SOURCE_INVALID: DecisionType.INACTIVATE,
        ReasonCode.ALL_SOURCES_INVALID: DecisionType.INACTIVATE,
        ReasonCode.QUALITY_BELOW_THRESHOLD: DecisionType.INACTIVATE,
        ReasonCode.ORPHANED_QUESTION: DecisionType.INACTIVATE,
        ReasonCode.ORPHANED_ANSWER: DecisionType.INACTIVATE,
        # EVALUATE
        ReasonCode.SIMILARITY_AMBIGUOUS: DecisionType.EVALUATE,
        ReasonCode.PARTIAL_TOKEN_OVERLAP: DecisionType.EVALUATE,
        ReasonCode.MULTIPLE_CANDIDATES: DecisionType.EVALUATE,
        ReasonCode.EDGE_CASE_DETECTED: DecisionType.EVALUATE,
        ReasonCode.MANUAL_REVIEW_REQUESTED: DecisionType.EVALUATE,
        # NOOP
        ReasonCode.CONTENT_UNCHANGED: DecisionType.NOOP,
        ReasonCode.MINOR_FORMATTING_CHANGE: DecisionType.NOOP,
        ReasonCode.BELOW_SIMILARITY_THRESHOLD: DecisionType.NOOP,
        ReasonCode.ALREADY_HANDLED: DecisionType.NOOP,
        ReasonCode.NOT_APPLICABLE: DecisionType.NOOP,
    }


# Lazy-load the mapping to avoid circular import issues
_REASON_TO_DECISION_MAP: Dict["ReasonCode", "DecisionType"] = {}


def _ensure_mapping_loaded():
    """Ensure the reason-to-decision mapping is loaded."""
    global _REASON_TO_DECISION_MAP
    if not _REASON_TO_DECISION_MAP:
        _REASON_TO_DECISION_MAP = _build_reason_to_decision_map()


# Human-readable descriptions for each reason code
_REASON_DESCRIPTIONS: Dict["ReasonCode", str] = {
    # PLAN_CREATE
    ReasonCode.NEW_CONTENT_ADDED: "New content chunk detected in knowledge base, generate new questions from this content",
    # REGEN_Q
    ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR: "Question's sole source content changed significantly, regenerate question text",
    ReasonCode.SOLE_SOURCE_CONTENT_CHANGED: "Question's only source content was modified, may need question rephrasing",
    # REGEN_A
    ReasonCode.MULTI_SOURCE_ONE_MODIFIED: "One of multiple answer sources was modified, regenerate answer",
    ReasonCode.ANSWER_FACTS_CHANGED: "Answer content facts changed (e.g., numbers, dates), regenerate answer",
    ReasonCode.TOKEN_OVERLAP_DETECTED: "Significant token overlap detected between modified content and answer, regenerate",
    # REGEN_BOTH
    ReasonCode.SOLE_SOURCE_DELETED_REGEN: "Sole source deleted but similar content exists, regenerate Q&A pair",
    ReasonCode.MAJOR_CONTENT_RESTRUCTURE: "Content significantly restructured, regenerate entire FAQ pair",
    ReasonCode.MULTIPLE_SOURCES_MODIFIED: "Multiple answer sources modified simultaneously, regenerate both Q&A",
    # INACTIVATE
    ReasonCode.CONTENT_DELETED: "Source content chunk was deleted from knowledge base, inactivate dependent Q/A",
    ReasonCode.SOLE_SOURCE_INVALID: "Question's only source is now invalid, inactivate question",
    ReasonCode.ALL_SOURCES_INVALID: "All source content for this Q/A is invalid, inactivate",
    ReasonCode.QUALITY_BELOW_THRESHOLD: "Quality evaluation score below threshold, inactivate low-quality Q/A",
    ReasonCode.ORPHANED_QUESTION: "Question has no valid sources remaining, inactivate orphaned question",
    ReasonCode.ORPHANED_ANSWER: "Answer has no parent question, inactivate orphaned answer",
    # EVALUATE
    ReasonCode.SIMILARITY_AMBIGUOUS: "Similarity score in ambiguous range, needs LLM evaluation to decide",
    ReasonCode.PARTIAL_TOKEN_OVERLAP: "Partial token overlap detected, LLM evaluation needed to determine impact",
    ReasonCode.MULTIPLE_CANDIDATES: "Multiple conflicting decisions possible, needs LLM to choose best action",
    ReasonCode.EDGE_CASE_DETECTED: "Unusual edge case scenario detected, requires manual LLM review",
    ReasonCode.MANUAL_REVIEW_REQUESTED: "User explicitly requested LLM evaluation for this decision",
    # NOOP
    ReasonCode.CONTENT_UNCHANGED: "Content identical after normalization, no action needed",
    ReasonCode.MINOR_FORMATTING_CHANGE: "Only formatting changed (whitespace, punctuation), no semantic change",
    ReasonCode.BELOW_SIMILARITY_THRESHOLD: "Change magnitude below threshold, essentially identical content",
    ReasonCode.ALREADY_HANDLED: "Decision already exists for this change, duplicate prevented",
    ReasonCode.NOT_APPLICABLE: "Decision not applicable to this entity type, no action needed",
}


# Initialize the mapping on module load
_ensure_mapping_loaded()


# Convenience exports
__all__ = [
    "ReasonCode",
]
