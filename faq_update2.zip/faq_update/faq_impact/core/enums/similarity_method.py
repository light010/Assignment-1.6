"""
SimilarityMethod Enumeration

This module defines similarity methods used in FAQ impact analysis for
detecting content changes and determining regeneration decisions.

Enums:
    - SimilarityMethod: Methods for calculating content similarity

Author: Analytics Assist Team
Date: 2025-11-02
"""

from enum import Enum
from typing import List


class SimilarityMethod(Enum):
    """
    Methods for calculating similarity between content versions.

    Impact analysis uses similarity calculations to determine if modified
    content requires FAQ regeneration. Different methods are appropriate
    for different scenarios:
    - Token-based methods: Fast, good for detecting factual changes
    - Sequence-based methods: Better for semantic similarity
    - Hybrid methods: Combine multiple approaches for robustness

    Similarity Methods:

        TOKEN_OVERLAP: Token set overlap (Jaccard similarity)
            - Compares word sets between old and new content
            - Good for: Detecting factual changes (numbers, dates, names)
            - Range: 0.0 (no overlap) to 1.0 (identical tokens)
            - Fast: O(n+m) with sets
            - Example: "limit $100" vs "limit $150" → high overlap despite change

        JACCARD_THRESHOLD: Jaccard with configurable threshold
            - Same as TOKEN_OVERLAP but with explicit threshold check
            - Good for: Binary decisions (similar vs different)
            - Used in: Early exit optimizations
            - Example: Jaccard > 0.8 → skip expensive difflib calculation

        SEQUENCE_SIMILARITY: Sequence-based similarity (difflib)
            - Compares character sequences, considers order
            - Good for: Detecting rephrasing, structural changes
            - Range: 0.0 (completely different) to 1.0 (identical)
            - Slower: O(n*m) with dynamic programming
            - Example: Detects "A then B" vs "B then A" as different

        HYBRID: Weighted combination of multiple methods
            - Combines token overlap + sequence similarity
            - Good for: Comprehensive change detection
            - Configurable weights: Default 40% Jaccard, 60% difflib
            - Most accurate but slowest
            - Example: Catches both factual and structural changes

        SEMANTIC_EMBEDDING: Embedding-based similarity (future)
            - Uses LLM embeddings for semantic similarity
            - Good for: Detecting meaning changes despite rewording
            - Expensive: Requires API calls, embedding storage
            - Not yet implemented (reserved for future)

        BM25: BM25 ranking similarity (optional)
            - Information retrieval similarity metric
            - Good for: Document-level similarity, keyword matching
            - Configurable: Can be included in hybrid with weight
            - Example: Finding similar content chunks for replacement

    Example:
        >>> from faq_impact.core.enums import SimilarityMethod
        >>>
        >>> # Get method
        >>> method = SimilarityMethod.TOKEN_OVERLAP
        >>> method.value
        'TOKEN_OVERLAP'
        >>>
        >>> # Check if method is fast
        >>> method.is_fast()
        True
        >>> SimilarityMethod.HYBRID.is_fast()
        False
        >>>
        >>> # Get recommended method for scenario
        >>> SimilarityMethod.get_recommended_for_scenario("factual_change")
        <SimilarityMethod.TOKEN_OVERLAP: 'TOKEN_OVERLAP'>
        >>>
        >>> # Check if method requires external API
        >>> SimilarityMethod.TOKEN_OVERLAP.requires_api()
        False
        >>> SimilarityMethod.SEMANTIC_EMBEDDING.requires_api()
        True

    Design Notes:
        - Used in: analysis/services/token_matcher.py, similarity calculators
        - Stored in: faq_impact.details JSON (metadata about how similarity was calculated)
        - Default: HYBRID for accuracy, TOKEN_OVERLAP for speed
        - Extensible: Can add new methods without breaking existing code
    """

    TOKEN_OVERLAP = "TOKEN_OVERLAP"
    JACCARD_THRESHOLD = "JACCARD_THRESHOLD"
    SEQUENCE_SIMILARITY = "SEQUENCE_SIMILARITY"
    HYBRID = "HYBRID"
    SEMANTIC_EMBEDDING = "SEMANTIC_EMBEDDING"
    BM25 = "BM25"

    def __str__(self) -> str:
        """
        Return string representation of the similarity method.

        Returns:
            String value of the enum

        Example:
            >>> str(SimilarityMethod.TOKEN_OVERLAP)
            'TOKEN_OVERLAP'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for storage.

        Returns:
            String value suitable for JSON/database storage

        Example:
            >>> SimilarityMethod.HYBRID.to_string()
            'HYBRID'
        """
        return self.value

    def is_fast(self) -> bool:
        """
        Check if this method is computationally fast.

        Fast methods are suitable for bulk processing and early filtering.
        Slow methods are more accurate but should be used selectively.

        Returns:
            True if method is fast (O(n) or O(n log n))

        Example:
            >>> SimilarityMethod.TOKEN_OVERLAP.is_fast()
            True
            >>> SimilarityMethod.JACCARD_THRESHOLD.is_fast()
            True
            >>> SimilarityMethod.SEQUENCE_SIMILARITY.is_fast()
            False
            >>> SimilarityMethod.HYBRID.is_fast()
            False
        """
        return self in {
            SimilarityMethod.TOKEN_OVERLAP,
            SimilarityMethod.JACCARD_THRESHOLD,
        }

    def requires_api(self) -> bool:
        """
        Check if this method requires external API calls.

        API-based methods are expensive and may have latency/cost implications.

        Returns:
            True if method requires external API (LLM, embedding service)

        Example:
            >>> SimilarityMethod.TOKEN_OVERLAP.requires_api()
            False
            >>> SimilarityMethod.SEMANTIC_EMBEDDING.requires_api()
            True
        """
        return self == SimilarityMethod.SEMANTIC_EMBEDDING

    def is_hybrid(self) -> bool:
        """
        Check if this method combines multiple approaches.

        Hybrid methods use weighted combinations of simpler methods.

        Returns:
            True if method is hybrid

        Example:
            >>> SimilarityMethod.HYBRID.is_hybrid()
            True
            >>> SimilarityMethod.TOKEN_OVERLAP.is_hybrid()
            False
        """
        return self == SimilarityMethod.HYBRID

    def supports_threshold(self) -> bool:
        """
        Check if this method is designed for threshold-based decisions.

        Some methods are optimized for binary decisions (above/below threshold)
        rather than precise similarity scores.

        Returns:
            True if method supports threshold checks

        Example:
            >>> SimilarityMethod.JACCARD_THRESHOLD.supports_threshold()
            True
            >>> SimilarityMethod.TOKEN_OVERLAP.supports_threshold()
            True
        """
        return self in {
            SimilarityMethod.TOKEN_OVERLAP,
            SimilarityMethod.JACCARD_THRESHOLD,
            SimilarityMethod.SEQUENCE_SIMILARITY,
            SimilarityMethod.HYBRID,
        }

    @classmethod
    def from_string(cls, value: str) -> "SimilarityMethod":
        """
        Create SimilarityMethod from string value.

        Args:
            value: String representation of similarity method

        Returns:
            SimilarityMethod enum instance

        Raises:
            ValueError: If value is not a valid SimilarityMethod

        Example:
            >>> SimilarityMethod.from_string("TOKEN_OVERLAP")
            <SimilarityMethod.TOKEN_OVERLAP: 'TOKEN_OVERLAP'>
            >>> SimilarityMethod.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid SimilarityMethod
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid SimilarityMethod. "
                f"Valid values: {valid_values}"
            )

    @classmethod
    def get_fast_methods(cls) -> List["SimilarityMethod"]:
        """
        Get all fast similarity methods.

        Returns:
            List of SimilarityMethod enums that are fast

        Example:
            >>> methods = SimilarityMethod.get_fast_methods()
            >>> SimilarityMethod.TOKEN_OVERLAP in methods
            True
            >>> SimilarityMethod.HYBRID in methods
            False
        """
        return [method for method in cls if method.is_fast()]

    @classmethod
    def get_api_free_methods(cls) -> List["SimilarityMethod"]:
        """
        Get all methods that don't require external API calls.

        Returns:
            List of SimilarityMethod enums that are API-free

        Example:
            >>> methods = SimilarityMethod.get_api_free_methods()
            >>> SimilarityMethod.TOKEN_OVERLAP in methods
            True
            >>> SimilarityMethod.SEMANTIC_EMBEDDING in methods
            False
        """
        return [method for method in cls if not method.requires_api()]

    @classmethod
    def get_recommended_for_scenario(cls, scenario: str) -> "SimilarityMethod":
        """
        Get recommended similarity method for a given scenario.

        Args:
            scenario: Use case scenario name

        Returns:
            Recommended SimilarityMethod for this scenario

        Scenarios:
            - "factual_change": Detecting number/date changes
            - "structural_change": Detecting rephrasing/reordering
            - "comprehensive": Most accurate, slowest
            - "early_filter": Fast filtering before detailed analysis
            - "semantic": Meaning-based similarity (future)

        Example:
            >>> SimilarityMethod.get_recommended_for_scenario("factual_change")
            <SimilarityMethod.TOKEN_OVERLAP: 'TOKEN_OVERLAP'>
            >>> SimilarityMethod.get_recommended_for_scenario("comprehensive")
            <SimilarityMethod.HYBRID: 'HYBRID'>

        Raises:
            ValueError: If scenario is not recognized
        """
        recommendations = {
            "factual_change": SimilarityMethod.TOKEN_OVERLAP,
            "structural_change": SimilarityMethod.SEQUENCE_SIMILARITY,
            "comprehensive": SimilarityMethod.HYBRID,
            "early_filter": SimilarityMethod.JACCARD_THRESHOLD,
            "semantic": SimilarityMethod.SEMANTIC_EMBEDDING,
            "ranking": SimilarityMethod.BM25,
        }

        if scenario not in recommendations:
            valid_scenarios = list(recommendations.keys())
            raise ValueError(
                f"Unknown scenario '{scenario}'. "
                f"Valid scenarios: {valid_scenarios}"
            )

        return recommendations[scenario]

    def get_typical_threshold(self) -> float:
        """
        Get typical threshold value for this method.

        Different methods have different typical threshold values for
        determining "similar" vs "different" content.

        Returns:
            Typical threshold value (0.0 to 1.0)

        Example:
            >>> SimilarityMethod.TOKEN_OVERLAP.get_typical_threshold()
            0.7
            >>> SimilarityMethod.SEQUENCE_SIMILARITY.get_typical_threshold()
            0.85

        Note:
            These are guidelines, not hard rules. Actual thresholds may vary
            based on use case.
        """
        thresholds = {
            SimilarityMethod.TOKEN_OVERLAP: 0.7,
            SimilarityMethod.JACCARD_THRESHOLD: 0.7,
            SimilarityMethod.SEQUENCE_SIMILARITY: 0.85,
            SimilarityMethod.HYBRID: 0.8,
            SimilarityMethod.SEMANTIC_EMBEDDING: 0.85,
            SimilarityMethod.BM25: 0.5,
        }
        return thresholds.get(self, 0.8)


# Convenience exports
__all__ = [
    "SimilarityMethod",
]
