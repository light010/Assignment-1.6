"""
Enum Validation Utilities

This module provides validation functions for enum combinations and business
rules in the FAQ impact analysis system. These validators ensure data integrity
and catch configuration errors early.

Functions:
    - validate_decision_reason_compatibility: Ensure reason codes match decision types
    - validate_entity_decision_compatibility: Ensure entity types match decision types
    - validate_impact_decision: Comprehensive validation of impact decision data
    - validate_status_transition: Validate application status transitions

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import Optional, List, Tuple

from .decision_type import DecisionType, ApplicationStatus
from .entity_type import EntityType, InactivationReason
from .reason_code import ReasonCode


class EnumValidationError(ValueError):
    """
    Exception raised when enum validation fails.

    This exception provides detailed error messages about why validation failed,
    including the invalid values and expected constraints.
    """

    pass


def validate_decision_reason_compatibility(
    decision_type: DecisionType,
    reason_code: ReasonCode,
) -> None:
    """
    Validate that a reason code is compatible with a decision type.

    Each decision type has specific valid reason codes. This function ensures
    the combination is valid according to business rules.

    Args:
        decision_type: The type of impact decision
        reason_code: The reason code for the decision

    Raises:
        EnumValidationError: If reason_code is not valid for decision_type

    Example:
        >>> validate_decision_reason_compatibility(
        ...     DecisionType.PLAN_CREATE,
        ...     ReasonCode.NEW_CONTENT_ADDED
        ... )  # OK, no exception
        >>>
        >>> validate_decision_reason_compatibility(
        ...     DecisionType.REGEN_Q,
        ...     ReasonCode.NEW_CONTENT_ADDED
        ... )  # Raises EnumValidationError

    Design Notes:
        - Uses ReasonCode.is_compatible() internally
        - Provides detailed error messages with valid alternatives
        - Called during impact decision creation
    """
    if not ReasonCode.is_compatible(decision_type, reason_code):
        valid_reasons = ReasonCode.get_reasons_for_decision(decision_type)
        valid_reason_values = [r.value for r in valid_reasons]

        raise EnumValidationError(
            f"Reason code '{reason_code.value}' is not valid for decision type "
            f"'{decision_type.value}'. Valid reason codes for {decision_type.value}: "
            f"{valid_reason_values}"
        )


def validate_entity_decision_compatibility(
    entity_type: EntityType,
    decision_type: DecisionType,
) -> None:
    """
    Validate that an entity type is compatible with a decision type.

    Different decision types apply to different entity types:
    - QUESTION entities: PLAN_CREATE, REGEN_Q, REGEN_BOTH, INACTIVATE
    - ANSWER entities: REGEN_A, INACTIVATE
    - CHANGE entities: EVALUATE, NOOP

    Args:
        entity_type: The type of entity the decision applies to
        decision_type: The type of impact decision

    Raises:
        EnumValidationError: If entity_type is not valid for decision_type

    Example:
        >>> validate_entity_decision_compatibility(
        ...     EntityType.QUESTION,
        ...     DecisionType.PLAN_CREATE
        ... )  # OK
        >>>
        >>> validate_entity_decision_compatibility(
        ...     EntityType.ANSWER,
        ...     DecisionType.PLAN_CREATE
        ... )  # Raises EnumValidationError

    Design Notes:
        - Encodes business rules about which entities can have which decisions
        - CHANGE entity type is for decisions not targeting specific Q/A
        - REGEN_BOTH targets QUESTION entity (regenerates both Q and A together)
    """
    # Define valid combinations
    valid_combinations = {
        EntityType.QUESTION: {
            DecisionType.PLAN_CREATE,
            DecisionType.REGEN_Q,
            DecisionType.REGEN_BOTH,
            DecisionType.INACTIVATE,
        },
        EntityType.ANSWER: {
            DecisionType.REGEN_A,
            DecisionType.INACTIVATE,
        },
        EntityType.CHANGE: {
            DecisionType.EVALUATE,
            DecisionType.NOOP,
        },
    }

    if decision_type not in valid_combinations[entity_type]:
        valid_decisions = [d.value for d in valid_combinations[entity_type]]
        raise EnumValidationError(
            f"Decision type '{decision_type.value}' is not valid for entity type "
            f"'{entity_type.value}'. Valid decision types for {entity_type.value}: "
            f"{valid_decisions}"
        )


def validate_entity_id_requirement(
    entity_type: EntityType,
    decision_type: DecisionType,
    entity_id: Optional[int],
) -> None:
    """
    Validate that entity_id is provided when required.

    Some decisions require an entity_id (targeting existing Q/A), while others
    don't (creating new questions, or decisions about changes themselves).

    Args:
        entity_type: The type of entity
        decision_type: The type of impact decision
        entity_id: The entity ID (may be None)

    Raises:
        EnumValidationError: If entity_id is required but missing, or provided but not needed

    Example:
        >>> validate_entity_id_requirement(
        ...     EntityType.QUESTION,
        ...     DecisionType.REGEN_Q,
        ...     entity_id=123
        ... )  # OK, REGEN_Q requires entity_id
        >>>
        >>> validate_entity_id_requirement(
        ...     EntityType.QUESTION,
        ...     DecisionType.PLAN_CREATE,
        ...     entity_id=None
        ... )  # OK, PLAN_CREATE doesn't need entity_id yet

    Design Notes:
        - PLAN_CREATE: entity_id is None (question doesn't exist yet)
        - REGEN_*: entity_id is required (regenerating existing entity)
        - INACTIVATE: entity_id is required (inactivating existing entity)
        - EVALUATE, NOOP: entity_id depends on context (often None)
    """
    # Decisions that require entity_id (targeting existing entities)
    requires_entity_id = {
        DecisionType.REGEN_Q,
        DecisionType.REGEN_A,
        DecisionType.REGEN_BOTH,
        DecisionType.INACTIVATE,
    }

    # Decisions that should NOT have entity_id
    forbids_entity_id = {
        DecisionType.PLAN_CREATE,  # Question doesn't exist yet
    }

    if decision_type in requires_entity_id and entity_id is None:
        raise EnumValidationError(
            f"Decision type '{decision_type.value}' requires entity_id to be provided, "
            f"but got None. This decision targets an existing {entity_type.value}."
        )

    if decision_type in forbids_entity_id and entity_id is not None:
        raise EnumValidationError(
            f"Decision type '{decision_type.value}' should not have entity_id "
            f"(got {entity_id}). This decision creates a new entity."
        )


def validate_impact_decision(
    entity_type: EntityType,
    entity_id: Optional[int],
    decision_type: DecisionType,
    reason_code: ReasonCode,
    application_status: ApplicationStatus,
) -> None:
    """
    Comprehensive validation of an impact decision.

    Validates all constraints on an impact decision:
    - Decision type matches reason code
    - Entity type is compatible with decision type
    - Entity ID is provided when required
    - Application status is valid

    Args:
        entity_type: The type of entity the decision applies to
        entity_id: The entity ID (may be None for PLAN_CREATE)
        decision_type: The type of impact decision
        reason_code: The reason for the decision
        application_status: The execution status of the decision

    Raises:
        EnumValidationError: If any validation fails

    Example:
        >>> validate_impact_decision(
        ...     entity_type=EntityType.QUESTION,
        ...     entity_id=None,
        ...     decision_type=DecisionType.PLAN_CREATE,
        ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
        ...     application_status=ApplicationStatus.PENDING
        ... )  # OK, all valid
        >>>
        >>> validate_impact_decision(
        ...     entity_type=EntityType.ANSWER,
        ...     entity_id=None,
        ...     decision_type=DecisionType.PLAN_CREATE,
        ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
        ...     application_status=ApplicationStatus.PENDING
        ... )  # Raises EnumValidationError (ANSWER can't have PLAN_CREATE)

    Design Notes:
        - Should be called before creating ImpactDecision instances
        - Catches configuration errors early with clear messages
        - Centralizes all validation logic for consistency
    """
    # Validate decision-reason compatibility
    validate_decision_reason_compatibility(decision_type, reason_code)

    # Validate entity-decision compatibility
    validate_entity_decision_compatibility(entity_type, decision_type)

    # Validate entity_id requirement
    validate_entity_id_requirement(entity_type, decision_type, entity_id)

    # Validate application status is a valid enum value
    if not isinstance(application_status, ApplicationStatus):
        raise EnumValidationError(
            f"application_status must be an ApplicationStatus enum, "
            f"got {type(application_status).__name__}"
        )


def validate_status_transition(
    current_status: ApplicationStatus,
    new_status: ApplicationStatus,
) -> None:
    """
    Validate that a status transition is allowed.

    Not all status transitions are valid. This function enforces business rules
    about valid state transitions during decision application.

    Valid transitions:
        - PENDING → IN_PROGRESS (execution starts)
        - PENDING → SKIPPED (user skips decision)
        - IN_PROGRESS → COMPLETED (execution succeeds)
        - IN_PROGRESS → FAILED (execution fails)
        - IN_PROGRESS → SKIPPED (execution aborted)
        - FAILED → PENDING (retry)
        - Any terminal status → PENDING (manual reset/retry)

    Invalid transitions:
        - COMPLETED → anything (completed is final)
        - PENDING → COMPLETED (must go through IN_PROGRESS)
        - IN_PROGRESS → PENDING (can't go backwards except from FAILED)

    Args:
        current_status: Current application status
        new_status: Desired new status

    Raises:
        EnumValidationError: If transition is not allowed

    Example:
        >>> validate_status_transition(
        ...     ApplicationStatus.PENDING,
        ...     ApplicationStatus.IN_PROGRESS
        ... )  # OK
        >>>
        >>> validate_status_transition(
        ...     ApplicationStatus.COMPLETED,
        ...     ApplicationStatus.IN_PROGRESS
        ... )  # Raises EnumValidationError

    Design Notes:
        - Prevents invalid state transitions in apply plan executor
        - FAILED can be retried (reset to PENDING)
        - Terminal statuses can be manually reset if needed
        - IN_PROGRESS acts as a lock to prevent concurrent execution
    """
    # Define valid transitions
    valid_transitions = {
        ApplicationStatus.PENDING: {
            ApplicationStatus.IN_PROGRESS,
            ApplicationStatus.SKIPPED,
        },
        ApplicationStatus.IN_PROGRESS: {
            ApplicationStatus.COMPLETED,
            ApplicationStatus.FAILED,
            ApplicationStatus.SKIPPED,
        },
        ApplicationStatus.FAILED: {
            ApplicationStatus.PENDING,  # Retry
            ApplicationStatus.IN_PROGRESS,  # Direct retry
        },
        ApplicationStatus.SKIPPED: {
            ApplicationStatus.PENDING,  # Manual reset
        },
        ApplicationStatus.COMPLETED: {
            # Completed is typically final, but allow manual reset
            ApplicationStatus.PENDING,  # Manual reset (rare)
        },
    }

    if new_status not in valid_transitions[current_status]:
        valid_next = [s.value for s in valid_transitions[current_status]]
        raise EnumValidationError(
            f"Invalid status transition from '{current_status.value}' to "
            f"'{new_status.value}'. Valid transitions from {current_status.value}: "
            f"{valid_next}"
        )


def validate_inactivation_reason_for_entity(
    entity_type: EntityType,
    inactivation_reason: InactivationReason,
) -> None:
    """
    Validate that an inactivation reason is valid for an entity type.

    Some inactivation reasons only apply to specific entity types:
    - QUESTION_INACTIVATED: Only valid for answers (cascaded from question)
    - Other reasons: Valid for both questions and answers

    Args:
        entity_type: The type of entity being inactivated
        inactivation_reason: The reason for inactivation

    Raises:
        EnumValidationError: If reason is not valid for entity type

    Example:
        >>> validate_inactivation_reason_for_entity(
        ...     EntityType.ANSWER,
        ...     InactivationReason.QUESTION_INACTIVATED
        ... )  # OK, answers can be inactivated due to question inactivation
        >>>
        >>> validate_inactivation_reason_for_entity(
        ...     EntityType.QUESTION,
        ...     InactivationReason.QUESTION_INACTIVATED
        ... )  # Raises EnumValidationError (questions can't cascade from themselves)

    Design Notes:
        - QUESTION_INACTIVATED is special: only for answer cascade
        - Other reasons apply to both questions and answers
        - Used when creating INACTIVATE decisions
    """
    if (
        inactivation_reason == InactivationReason.QUESTION_INACTIVATED
        and entity_type != EntityType.ANSWER
    ):
        raise EnumValidationError(
            f"Inactivation reason '{inactivation_reason.value}' is only valid for "
            f"entity type ANSWER (cascaded inactivation), but got entity type "
            f"'{entity_type.value}'"
        )


def get_validation_errors(
    entity_type: EntityType,
    entity_id: Optional[int],
    decision_type: DecisionType,
    reason_code: ReasonCode,
    application_status: ApplicationStatus,
) -> List[str]:
    """
    Get all validation errors without raising exceptions.

    This function is useful for batch validation or UI feedback where you want
    to collect all errors rather than failing on the first one.

    Args:
        entity_type: The type of entity the decision applies to
        entity_id: The entity ID (may be None)
        decision_type: The type of impact decision
        reason_code: The reason for the decision
        application_status: The execution status

    Returns:
        List of error messages (empty if all valid)

    Example:
        >>> errors = get_validation_errors(
        ...     entity_type=EntityType.QUESTION,
        ...     entity_id=None,
        ...     decision_type=DecisionType.PLAN_CREATE,
        ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
        ...     application_status=ApplicationStatus.PENDING
        ... )
        >>> errors
        []  # No errors
        >>>
        >>> errors = get_validation_errors(
        ...     entity_type=EntityType.ANSWER,
        ...     entity_id=None,
        ...     decision_type=DecisionType.PLAN_CREATE,
        ...     reason_code=ReasonCode.NEW_CONTENT_ADDED,
        ...     application_status=ApplicationStatus.PENDING
        ... )
        >>> len(errors) > 0
        True

    Design Notes:
        - Useful for batch validation in ETL pipelines
        - Collects all errors rather than failing fast
        - Returns user-friendly error messages
    """
    errors: List[str] = []

    # Check decision-reason compatibility
    try:
        validate_decision_reason_compatibility(decision_type, reason_code)
    except EnumValidationError as e:
        errors.append(str(e))

    # Check entity-decision compatibility
    try:
        validate_entity_decision_compatibility(entity_type, decision_type)
    except EnumValidationError as e:
        errors.append(str(e))

    # Check entity_id requirement
    try:
        validate_entity_id_requirement(entity_type, decision_type, entity_id)
    except EnumValidationError as e:
        errors.append(str(e))

    # Check application status
    if not isinstance(application_status, ApplicationStatus):
        errors.append(
            f"application_status must be an ApplicationStatus enum, "
            f"got {type(application_status).__name__}"
        )

    return errors


# Convenience exports
__all__ = [
    "EnumValidationError",
    "validate_decision_reason_compatibility",
    "validate_entity_decision_compatibility",
    "validate_entity_id_requirement",
    "validate_impact_decision",
    "validate_status_transition",
    "validate_inactivation_reason_for_entity",
    "get_validation_errors",
]
