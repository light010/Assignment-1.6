"""
DecisionType and ApplicationStatus Enumerations

This module defines enumerations for impact decision types and their execution status
in the FAQ impact analysis system.

Enums:
    - DecisionType: Types of impact decisions that can be made
    - ApplicationStatus: Execution state of impact decisions

Author: Analytics Assist Team
Date: 2025-11-02
"""

from enum import Enum
from typing import List


class DecisionType(Enum):
    """
    Types of impact decisions in the FAQ impact analysis system.

    Impact decisions represent planned actions in response to content changes.
    These are created during the ANALYSIS phase (read-only) and executed
    during the APPLY PLAN phase (mutations).

    Decision Types:

        PLAN_CREATE: Create a new question from new content
            - Trigger: NEW_CONTENT detected (content chunk added)
            - Entity: QUESTION (entity_id = NULL until created)
            - Action: Generate new question(s) from content chunk
            - Example: New PDF page → generate questions from content

        REGEN_Q: Regenerate question text only
            - Trigger: MODIFIED_CONTENT with sole source changed significantly
            - Entity: QUESTION (entity_id = existing question_id)
            - Action: Regenerate question text, keep answer unchanged
            - Example: "What is limit?" → content changed → regen question

        REGEN_A: Regenerate answer only
            - Trigger: MODIFIED_CONTENT affecting answer, question still valid
            - Entity: ANSWER (entity_id = existing answer_id)
            - Action: Regenerate answer, keep question unchanged
            - Example: Answer facts changed, question phrasing still good

        REGEN_BOTH: Regenerate both question and answer
            - Trigger: MODIFIED_CONTENT with major changes to sole source
            - Entity: QUESTION (regenerates Q+A together)
            - Action: Regenerate both question text and answer
            - Example: Major content rewrite → regen entire FAQ pair

        INACTIVATE: Mark question or answer as inactive
            - Trigger: DELETED_CONTENT, source invalid, quality issue
            - Entity: QUESTION or ANSWER (depending on what to inactivate)
            - Action: Set is_active=False, record inactivation_reason
            - Example: Content deleted → inactivate dependent questions

        EVALUATE: LLM evaluation needed to decide
            - Trigger: Ambiguous change, edge case, uncertainty
            - Entity: CHANGE (entity_id = change_id, no specific Q/A yet)
            - Action: Send to LLM for evaluation, create follow-up decision
            - Example: Moderate similarity change → LLM decides regen vs keep

        NOOP: No operation needed
            - Trigger: Minor change, identical content, already handled
            - Entity: CHANGE (entity_id = change_id)
            - Action: No action, record decision for audit
            - Example: Formatting-only change → NOOP

    Example:
        >>> from faq_impact.core.enums import DecisionType
        >>>
        >>> # Create a decision type
        >>> decision = DecisionType.PLAN_CREATE
        >>> decision.value
        'PLAN_CREATE'
        >>>
        >>> # Check if decision requires generation
        >>> decision.requires_generation()
        True
        >>> DecisionType.NOOP.requires_generation()
        False
        >>>
        >>> # Get all regeneration decisions
        >>> DecisionType.get_regeneration_decisions()
        [<DecisionType.REGEN_Q: 'REGEN_Q'>, ...]
        >>>
        >>> # Group decisions by characteristic
        >>> DecisionType.REGEN_A.is_mutation()
        True
        >>> DecisionType.EVALUATE.is_mutation()
        False

    Design Notes:
        - Separates planning (decision creation) from execution (application)
        - Stored in: faq_impact.decision_type column
        - Each decision type has specific validation rules (see validators.py)
        - EVALUATE decisions spawn follow-up decisions after LLM review
    """

    PLAN_CREATE = "PLAN_CREATE"
    REGEN_Q = "REGEN_Q"
    REGEN_A = "REGEN_A"
    REGEN_BOTH = "REGEN_BOTH"
    INACTIVATE = "INACTIVATE"
    EVALUATE = "EVALUATE"
    NOOP = "NOOP"

    def __str__(self) -> str:
        """
        Return string representation of the decision type.

        Returns:
            String value of the enum

        Example:
            >>> str(DecisionType.PLAN_CREATE)
            'PLAN_CREATE'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for database storage.

        Returns:
            String value suitable for VARCHAR column

        Example:
            >>> DecisionType.REGEN_Q.to_string()
            'REGEN_Q'
        """
        return self.value

    def requires_generation(self) -> bool:
        """
        Check if this decision type requires LLM generation.

        Generation decisions need to call question/answer generation services
        during the apply plan phase.

        Returns:
            True if decision requires LLM generation

        Example:
            >>> DecisionType.PLAN_CREATE.requires_generation()
            True
            >>> DecisionType.REGEN_A.requires_generation()
            True
            >>> DecisionType.INACTIVATE.requires_generation()
            False
        """
        return self in {
            DecisionType.PLAN_CREATE,
            DecisionType.REGEN_Q,
            DecisionType.REGEN_A,
            DecisionType.REGEN_BOTH,
        }

    def is_regeneration(self) -> bool:
        """
        Check if this is a regeneration decision (not new creation).

        Regeneration decisions modify existing questions/answers rather than
        creating new ones.

        Returns:
            True if decision is regeneration type

        Example:
            >>> DecisionType.REGEN_Q.is_regeneration()
            True
            >>> DecisionType.PLAN_CREATE.is_regeneration()
            False
        """
        return self in {
            DecisionType.REGEN_Q,
            DecisionType.REGEN_A,
            DecisionType.REGEN_BOTH,
        }

    def is_mutation(self) -> bool:
        """
        Check if this decision type causes database mutations.

        Mutation decisions modify the faq_questions or faq_answers tables
        during execution (apply plan phase).

        Returns:
            True if decision causes database changes

        Example:
            >>> DecisionType.PLAN_CREATE.is_mutation()
            True
            >>> DecisionType.EVALUATE.is_mutation()
            False
            >>> DecisionType.NOOP.is_mutation()
            False
        """
        return self in {
            DecisionType.PLAN_CREATE,
            DecisionType.REGEN_Q,
            DecisionType.REGEN_A,
            DecisionType.REGEN_BOTH,
            DecisionType.INACTIVATE,
        }

    def is_deferred(self) -> bool:
        """
        Check if this decision type requires later evaluation.

        Deferred decisions (EVALUATE) don't execute immediately - they need
        LLM review first, which then creates follow-up executable decisions.

        Returns:
            True if decision is deferred for later evaluation

        Example:
            >>> DecisionType.EVALUATE.is_deferred()
            True
            >>> DecisionType.REGEN_A.is_deferred()
            False
        """
        return self == DecisionType.EVALUATE

    @classmethod
    def from_string(cls, value: str) -> "DecisionType":
        """
        Create DecisionType from string value.

        Args:
            value: String representation of decision type

        Returns:
            DecisionType enum instance

        Raises:
            ValueError: If value is not a valid DecisionType

        Example:
            >>> DecisionType.from_string("PLAN_CREATE")
            <DecisionType.PLAN_CREATE: 'PLAN_CREATE'>
            >>> DecisionType.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid DecisionType
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid DecisionType. "
                f"Valid values: {valid_values}"
            )

    @classmethod
    def get_generation_decisions(cls) -> List["DecisionType"]:
        """
        Get all decision types that require LLM generation.

        Returns:
            List of DecisionType enums that require generation

        Example:
            >>> decisions = DecisionType.get_generation_decisions()
            >>> DecisionType.PLAN_CREATE in decisions
            True
            >>> DecisionType.NOOP in decisions
            False
        """
        return [d for d in cls if d.requires_generation()]

    @classmethod
    def get_regeneration_decisions(cls) -> List["DecisionType"]:
        """
        Get all regeneration decision types.

        Returns:
            List of DecisionType enums that are regenerations

        Example:
            >>> decisions = DecisionType.get_regeneration_decisions()
            >>> DecisionType.REGEN_Q in decisions
            True
            >>> DecisionType.PLAN_CREATE in decisions
            False
        """
        return [d for d in cls if d.is_regeneration()]

    @classmethod
    def get_mutation_decisions(cls) -> List["DecisionType"]:
        """
        Get all decision types that cause database mutations.

        Returns:
            List of DecisionType enums that modify database

        Example:
            >>> decisions = DecisionType.get_mutation_decisions()
            >>> DecisionType.INACTIVATE in decisions
            True
            >>> DecisionType.EVALUATE in decisions
            False
        """
        return [d for d in cls if d.is_mutation()]


class ApplicationStatus(Enum):
    """
    Execution state of impact decisions during apply plan phase.

    After impact decisions are created (analysis phase), they need to be
    executed (apply plan phase). This enum tracks the execution state of
    each decision, enabling:
    - Progress tracking: Monitor which decisions have been applied
    - Retry logic: Retry failed decisions
    - Selective application: Apply only certain decisions
    - Audit trails: Record what happened to each decision

    Status Values:

        PENDING: Decision created, not yet executed
            - Initial state for all decisions after analysis
            - Waiting for apply plan phase to begin
            - Example: Impact analysis complete → all decisions PENDING

        IN_PROGRESS: Decision currently being executed
            - Apply plan executor has started processing this decision
            - Used to prevent duplicate execution (concurrency control)
            - Example: Generating new question → status IN_PROGRESS

        COMPLETED: Decision successfully executed
            - Action completed successfully, changes committed
            - Terminal state (success)
            - Example: Question regenerated → status COMPLETED

        FAILED: Decision execution failed
            - Error occurred during execution (LLM error, DB error, etc.)
            - Can be retried or manually investigated
            - Terminal state (failure, but retryable)
            - Example: LLM API timeout → status FAILED

        SKIPPED: Decision intentionally skipped
            - User chose not to apply this decision (selective application)
            - Or decision became obsolete (e.g., question already deleted)
            - Terminal state (intentional skip)
            - Example: User unchecks decision in UI → status SKIPPED

    Example:
        >>> from faq_impact.core.enums import ApplicationStatus
        >>>
        >>> # Create a status
        >>> status = ApplicationStatus.PENDING
        >>> status.value
        'PENDING'
        >>>
        >>> # Check if status is terminal
        >>> status.is_terminal()
        False
        >>> ApplicationStatus.COMPLETED.is_terminal()
        True
        >>>
        >>> # Check if status can be retried
        >>> ApplicationStatus.FAILED.can_retry()
        True
        >>> ApplicationStatus.COMPLETED.can_retry()
        False

    Database Usage:
        - Stored in: faq_impact.application_status column
        - Nullable: No (defaults to PENDING on creation)
        - Updated: During apply plan execution
        - Indexed: For filtering pending/failed decisions

    Design Notes:
        - Status transitions: PENDING → IN_PROGRESS → (COMPLETED|FAILED|SKIPPED)
        - IN_PROGRESS prevents concurrent execution of same decision
        - FAILED decisions can be retried (reset to PENDING)
        - SKIPPED is different from NOOP (NOOP is decision type, SKIPPED is execution state)
    """

    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"

    def __str__(self) -> str:
        """
        Return string representation of the application status.

        Returns:
            String value of the enum

        Example:
            >>> str(ApplicationStatus.PENDING)
            'PENDING'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for database storage.

        Returns:
            String value suitable for VARCHAR column

        Example:
            >>> ApplicationStatus.COMPLETED.to_string()
            'COMPLETED'
        """
        return self.value

    def is_terminal(self) -> bool:
        """
        Check if this is a terminal status (execution finished).

        Terminal statuses indicate the decision has been fully processed
        and won't be automatically picked up for execution again.

        Returns:
            True if status is terminal (COMPLETED, FAILED, SKIPPED)

        Example:
            >>> ApplicationStatus.PENDING.is_terminal()
            False
            >>> ApplicationStatus.IN_PROGRESS.is_terminal()
            False
            >>> ApplicationStatus.COMPLETED.is_terminal()
            True
            >>> ApplicationStatus.FAILED.is_terminal()
            True
        """
        return self in {
            ApplicationStatus.COMPLETED,
            ApplicationStatus.FAILED,
            ApplicationStatus.SKIPPED,
        }

    def is_active(self) -> bool:
        """
        Check if this status indicates active processing.

        Active statuses mean the decision is currently being worked on
        or waiting to be processed.

        Returns:
            True if status is PENDING or IN_PROGRESS

        Example:
            >>> ApplicationStatus.PENDING.is_active()
            True
            >>> ApplicationStatus.IN_PROGRESS.is_active()
            True
            >>> ApplicationStatus.COMPLETED.is_active()
            False
        """
        return self in {ApplicationStatus.PENDING, ApplicationStatus.IN_PROGRESS}

    def can_retry(self) -> bool:
        """
        Check if a decision with this status can be retried.

        Retry is allowed for FAILED decisions (errors may be transient).
        Other terminal statuses should not be retried.

        Returns:
            True if status is FAILED (retryable)

        Example:
            >>> ApplicationStatus.FAILED.can_retry()
            True
            >>> ApplicationStatus.COMPLETED.can_retry()
            False
            >>> ApplicationStatus.SKIPPED.can_retry()
            False
        """
        return self == ApplicationStatus.FAILED

    def is_successful(self) -> bool:
        """
        Check if this status indicates successful execution.

        Returns:
            True if status is COMPLETED

        Example:
            >>> ApplicationStatus.COMPLETED.is_successful()
            True
            >>> ApplicationStatus.FAILED.is_successful()
            False
        """
        return self == ApplicationStatus.COMPLETED

    @classmethod
    def from_string(cls, value: str) -> "ApplicationStatus":
        """
        Create ApplicationStatus from string value.

        Args:
            value: String representation of application status

        Returns:
            ApplicationStatus enum instance

        Raises:
            ValueError: If value is not a valid ApplicationStatus

        Example:
            >>> ApplicationStatus.from_string("PENDING")
            <ApplicationStatus.PENDING: 'PENDING'>
            >>> ApplicationStatus.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid ApplicationStatus
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid ApplicationStatus. "
                f"Valid values: {valid_values}"
            )

    @classmethod
    def get_terminal_statuses(cls) -> List["ApplicationStatus"]:
        """
        Get all terminal status values.

        Returns:
            List of ApplicationStatus enums that are terminal

        Example:
            >>> statuses = ApplicationStatus.get_terminal_statuses()
            >>> ApplicationStatus.COMPLETED in statuses
            True
            >>> ApplicationStatus.PENDING in statuses
            False
        """
        return [s for s in cls if s.is_terminal()]

    @classmethod
    def get_active_statuses(cls) -> List["ApplicationStatus"]:
        """
        Get all active status values.

        Returns:
            List of ApplicationStatus enums that are active

        Example:
            >>> statuses = ApplicationStatus.get_active_statuses()
            >>> ApplicationStatus.PENDING in statuses
            True
            >>> ApplicationStatus.COMPLETED in statuses
            False
        """
        return [s for s in cls if s.is_active()]


# Convenience exports
__all__ = [
    "DecisionType",
    "ApplicationStatus",
]
