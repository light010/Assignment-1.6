"""
EntityType and InactivationReason Enumerations

This module defines enumerations for entity classification and inactivation reasons
in the FAQ impact analysis system.

Enums:
    - EntityType: Represents what entity type an impact decision applies to
    - InactivationReason: Reasons for question/answer inactivation

Author: Analytics Assist Team
Date: 2025-11-02
"""

from enum import Enum


class EntityType(Enum):
    """
    Classification of entity types that impact decisions apply to.

    Impact decisions are made at different granularities:
    - QUESTION level: Decisions about generating/regenerating/inactivating questions
    - ANSWER level: Decisions about generating/regenerating answers for questions
    - CHANGE level: Decisions about how to handle a specific content change

    This enum identifies which entity type a particular ImpactDecision record
    pertains to, enabling proper tracking and application of impacts.

    Values:
        QUESTION: Impact decision applies to a question entity
            - Used for: PLAN_CREATE (new question), INACTIVATE (question), REGEN_Q
            - Stored in: faq_impact table with entity_type='QUESTION', entity_id=question_id

        ANSWER: Impact decision applies to an answer entity
            - Used for: REGEN_A (regenerate answer only)
            - Stored in: faq_impact table with entity_type='ANSWER', entity_id=answer_id

        CHANGE: Impact decision applies to a content change itself
            - Used for: EVALUATE (needs LLM review), NOOP (no action needed)
            - Stored in: faq_impact table with entity_type='CHANGE', entity_id=change_id

    Example:
        >>> from faq_impact.core.enums import EntityType
        >>>
        >>> # Creating an impact decision for a new question
        >>> entity_type = EntityType.QUESTION
        >>> entity_type.value
        'QUESTION'
        >>>
        >>> # Check entity type from string
        >>> EntityType('ANSWER')
        <EntityType.ANSWER: 'ANSWER'>
        >>>
        >>> # Iterate all entity types
        >>> for entity_type in EntityType:
        ...     print(entity_type.value)
        QUESTION
        ANSWER
        CHANGE

    Design Notes:
        - String values match enum names for simplicity
        - Used in faq_impact.entity_type column (VARCHAR)
        - Helps determine which table to look up entity details
        - CHANGE type is used for decisions that don't target specific Q/A
    """

    QUESTION = "QUESTION"
    ANSWER = "ANSWER"
    CHANGE = "CHANGE"

    def __str__(self) -> str:
        """
        Return string representation of the entity type.

        Returns:
            String value of the enum (e.g., "QUESTION")

        Example:
            >>> str(EntityType.QUESTION)
            'QUESTION'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for database storage.

        Returns:
            String value suitable for VARCHAR column

        Example:
            >>> EntityType.ANSWER.to_string()
            'ANSWER'
        """
        return self.value

    @classmethod
    def from_string(cls, value: str) -> "EntityType":
        """
        Create EntityType from string value.

        Args:
            value: String representation ("QUESTION", "ANSWER", "CHANGE")

        Returns:
            EntityType enum instance

        Raises:
            ValueError: If value is not a valid EntityType

        Example:
            >>> EntityType.from_string("QUESTION")
            <EntityType.QUESTION: 'QUESTION'>
            >>> EntityType.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid EntityType
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid EntityType. "
                f"Valid values: {valid_values}"
            )


class InactivationReason(Enum):
    """
    Reasons for inactivating questions or answers.

    When content changes result in questions or answers being marked inactive,
    this enum captures WHY the inactivation occurred. This supports:
    - Audit trails: Understanding historical inactivations
    - Cascading logic: Questions inactivated → answers auto-inactivated
    - Manual overrides: Allowing manual quality-based inactivation

    Values:
        CONTENT_DELETED: Source content chunk was deleted
            - Direct cause: Content removed from knowledge base
            - Action: Inactivate question/answer tied to deleted content
            - Example: PDF page removed, question based on that page → inactive

        ALL_SOURCES_INVALID: All source content for this Q/A is now invalid
            - Direct cause: Multi-source Q/A lost all valid sources
            - Action: Inactivate question/answer with no remaining valid sources
            - Example: Question based on 3 chunks, all 3 marked invalid → inactive

        MANUAL: Manual inactivation by user/admin
            - Direct cause: User judgment or quality control
            - Action: User explicitly marks question/answer as inactive
            - Example: Outdated question no longer relevant → manual inactive

        QUALITY_ISSUE: Automated quality check failed
            - Direct cause: LLM evaluation or quality metric below threshold
            - Action: System detected quality issue, marked inactive
            - Example: Answer coherence score < 0.5 → quality issue inactive

        QUESTION_INACTIVATED: Cascaded inactivation from parent question
            - Direct cause: Parent question was inactivated (any reason above)
            - Action: Automatically inactivate all answers for that question
            - Example: Question inactive (CONTENT_DELETED) → answers cascade

    Example:
        >>> from faq_impact.core.enums import InactivationReason
        >>>
        >>> # Creating an inactivation reason
        >>> reason = InactivationReason.CONTENT_DELETED
        >>> reason.value
        'CONTENT_DELETED'
        >>>
        >>> # Check if reason is cascaded
        >>> reason.is_cascaded()
        False
        >>> InactivationReason.QUESTION_INACTIVATED.is_cascaded()
        True
        >>>
        >>> # Get direct reasons (not cascaded)
        >>> InactivationReason.get_direct_reasons()
        [<InactivationReason.CONTENT_DELETED: 'CONTENT_DELETED'>, ...]

    Database Usage:
        - Stored in: faq_questions.inactivation_reason, faq_answers.inactivation_reason
        - Nullable: Yes (NULL = active, non-NULL = inactive with reason)
        - Immutable: Once set, should not change (audit trail)

    Design Notes:
        - Supports both direct and cascaded inactivation
        - QUESTION_INACTIVATED only applies to answers (cascade from question)
        - Enum values are descriptive strings for clarity
        - Can extend with new reasons without breaking existing logic
    """

    CONTENT_DELETED = "CONTENT_DELETED"
    ALL_SOURCES_INVALID = "ALL_SOURCES_INVALID"
    MANUAL = "MANUAL"
    QUALITY_ISSUE = "QUALITY_ISSUE"
    QUESTION_INACTIVATED = "QUESTION_INACTIVATED"

    def __str__(self) -> str:
        """
        Return string representation of the inactivation reason.

        Returns:
            String value of the enum

        Example:
            >>> str(InactivationReason.CONTENT_DELETED)
            'CONTENT_DELETED'
        """
        return self.value

    def to_string(self) -> str:
        """
        Convert enum to string for database storage.

        Returns:
            String value suitable for VARCHAR column

        Example:
            >>> InactivationReason.MANUAL.to_string()
            'MANUAL'
        """
        return self.value

    def is_cascaded(self) -> bool:
        """
        Check if this is a cascaded inactivation reason.

        Cascaded reasons are indirect - the entity was inactivated because
        a parent entity was inactivated, not due to direct content changes.

        Returns:
            True if this is a cascaded reason (QUESTION_INACTIVATED)

        Example:
            >>> InactivationReason.CONTENT_DELETED.is_cascaded()
            False
            >>> InactivationReason.QUESTION_INACTIVATED.is_cascaded()
            True
        """
        return self == InactivationReason.QUESTION_INACTIVATED

    def is_direct(self) -> bool:
        """
        Check if this is a direct inactivation reason.

        Direct reasons mean the entity itself had a problem, not inherited
        from a parent entity.

        Returns:
            True if this is NOT a cascaded reason

        Example:
            >>> InactivationReason.ALL_SOURCES_INVALID.is_direct()
            True
            >>> InactivationReason.QUESTION_INACTIVATED.is_direct()
            False
        """
        return not self.is_cascaded()

    @classmethod
    def from_string(cls, value: str) -> "InactivationReason":
        """
        Create InactivationReason from string value.

        Args:
            value: String representation of inactivation reason

        Returns:
            InactivationReason enum instance

        Raises:
            ValueError: If value is not a valid InactivationReason

        Example:
            >>> InactivationReason.from_string("CONTENT_DELETED")
            <InactivationReason.CONTENT_DELETED: 'CONTENT_DELETED'>
            >>> InactivationReason.from_string("INVALID")
            Traceback (most recent call last):
                ...
            ValueError: 'INVALID' is not a valid InactivationReason
        """
        try:
            return cls(value)
        except ValueError:
            valid_values = [e.value for e in cls]
            raise ValueError(
                f"'{value}' is not a valid InactivationReason. "
                f"Valid values: {valid_values}"
            )

    @classmethod
    def get_direct_reasons(cls) -> list["InactivationReason"]:
        """
        Get all direct (non-cascaded) inactivation reasons.

        Returns:
            List of InactivationReason enums that are direct causes

        Example:
            >>> reasons = InactivationReason.get_direct_reasons()
            >>> InactivationReason.QUESTION_INACTIVATED in reasons
            False
            >>> InactivationReason.CONTENT_DELETED in reasons
            True
        """
        return [reason for reason in cls if reason.is_direct()]

    @classmethod
    def get_cascaded_reasons(cls) -> list["InactivationReason"]:
        """
        Get all cascaded inactivation reasons.

        Returns:
            List of InactivationReason enums that are cascaded causes

        Example:
            >>> reasons = InactivationReason.get_cascaded_reasons()
            >>> reasons
            [<InactivationReason.QUESTION_INACTIVATED: 'QUESTION_INACTIVATED'>]
        """
        return [reason for reason in cls if reason.is_cascaded()]


# Convenience exports
__all__ = [
    "EntityType",
    "InactivationReason",
]
