"""
SimpleDeletedContentHandler - Simplified Deleted Content Handler with Best Practices

This module provides a simplified, production-ready handler for DELETED_CONTENT changes
that combines the best practices from DeletedContentStrategy with the direct execution
approach from handle_deleted_content.

Key Features:
    - Direct execution (no decision layer complexity)
    - Source counting (sole-source vs multi-source detection)
    - Cascading inactivations (question → answers)
    - Answer regeneration for multi-source scenarios
    - Comprehensive validation and error handling
    - Transaction support
    - Detailed logging and auditability

Decision Logic:
    - Sole source question → INACTIVATE question + cascade to all answers
    - Multi-source question → REGEN question with remaining sources
    - Orphaned question (0 sources) → INACTIVATE question + cascade to answers
    - Answer regeneration → For affected answers when parent question stays active

Classes:
    - SimpleDeletedContentHandler: Simplified handler for deleted content changes
    - HandlerResult: Result object with detailed metrics

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import Dict, Any, Optional, List, Set
from datetime import datetime
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger
from faq_impact.analysis.services.source_counter import SourceCounter

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Result Models
# =============================================================================


class HandlerResult:
    """
    Result from deleted content handler execution.

    Attributes:
        success: Whether operation succeeded
        questions_inactivated: Number of questions inactivated
        questions_regenerated: Number of questions regenerated
        answers_inactivated: Number of answers inactivated
        answers_regenerated: Number of answers regenerated
        error: Error message if failed
        no_impact: Whether no FAQs were affected (valid NOOP)
    """

    def __init__(
        self,
        success: bool,
        questions_inactivated: int = 0,
        questions_regenerated: int = 0,
        answers_inactivated: int = 0,
        answers_regenerated: int = 0,
        error: Optional[str] = None,
        no_impact: bool = False
    ):
        self.success = success
        self.questions_inactivated = questions_inactivated
        self.questions_regenerated = questions_regenerated
        self.answers_inactivated = answers_inactivated
        self.answers_regenerated = answers_regenerated
        self.error = error
        self.no_impact = no_impact

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for easy serialization."""
        return {
            'success': self.success,
            'questions_inactivated': self.questions_inactivated,
            'questions_regenerated': self.questions_regenerated,
            'answers_inactivated': self.answers_inactivated,
            'answers_regenerated': self.answers_regenerated,
            'error': self.error,
            'no_impact': self.no_impact
        }

    def __repr__(self) -> str:
        if self.no_impact:
            return f"<HandlerResult: SUCCESS - No FAQs affected>"
        if not self.success:
            return f"<HandlerResult: FAILED - {self.error}>"
        return (
            f"<HandlerResult: SUCCESS - "
            f"{self.questions_inactivated}Q_inactivated, "
            f"{self.questions_regenerated}Q_regenerated, "
            f"{self.answers_inactivated}A_inactivated, "
            f"{self.answers_regenerated}A_regenerated>"
        )


# =============================================================================
# Simple Handler Implementation
# =============================================================================


class SimpleDeletedContentHandler:
    """
    Simplified handler for DELETED_CONTENT changes with best practices.

    This handler combines:
    - Direct execution (like handle_deleted_content)
    - Source counting logic (like DeletedContentStrategy)
    - Cascading inactivations (question → answers)
    - Answer regeneration
    - Comprehensive validation

    Best Practices Included:
        1. Source Counting: Uses SourceCounter for accurate sole/multi-source detection
        2. Cascading: Automatically inactivates answers when question is inactivated
        3. Orphan Detection: Handles questions/answers with zero valid sources
        4. Answer Regeneration: Regenerates answers for multi-source questions
        5. Error Handling: Comprehensive try/catch with detailed errors
        6. Logging: Structured logging at all decision points
        7. Transactions: Optional transaction support
        8. Auditability: Returns detailed result object

    Decision Rules:
        - Question with 0 sources (orphaned) → INACTIVATE + cascade to answers
        - Question with 1 source (sole source) → INACTIVATE + cascade to answers
        - Question with 2+ sources (multi-source) → REGEN question + REGEN affected answers
        - Answer orphaned (0 sources) → INACTIVATE
        - Answer with sources (parent question active) → REGEN

    Usage:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> # Initialize
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> handler = SimpleDeletedContentHandler(backend, question_generator, answer_generator)
        >>>
        >>> # Process deleted content
        >>> change = {
        ...     'change_id': 123,
        ...     'previous_checksum': 'abc123...',  # Deleted content checksum
        ...     'file_name': 'deleted_doc.pdf'
        ... }
        >>> result = handler.handle(change)
        >>>
        >>> if result.success:
        ...     print(f"Inactivated: {result.questions_inactivated}Q, {result.answers_inactivated}A")
        ...     print(f"Regenerated: {result.questions_regenerated}Q, {result.answers_regenerated}A")
        >>> else:
        ...     print(f"Error: {result.error}")
    """

    def __init__(
        self,
        backend: IBackend,
        question_generator: Any,  # QuestionGenerator instance
        answer_generator: Any,    # AnswerGenerator instance
        source_counter: Optional[SourceCounter] = None,
        decision_repo: Optional[Any] = None,  # NEW: Optional DecisionRepository
        use_transactions: bool = True
    ):
        """
        Initialize handler with required dependencies.

        Args:
            backend: Database backend for queries and updates
            question_generator: QuestionGenerator instance for regenerating questions
            answer_generator: AnswerGenerator instance for regenerating answers
            source_counter: Optional SourceCounter (creates default if None)
            decision_repo: Optional DecisionRepository for persisting decisions
            use_transactions: Whether to use database transactions (default True)
        """
        self.backend = backend
        self.question_generator = question_generator
        self.answer_generator = answer_generator
        self.source_counter = source_counter or SourceCounter(backend)
        self.decision_repo = decision_repo  # NEW
        self.use_transactions = use_transactions

        logger.info(
            f"Initialized SimpleDeletedContentHandler "
            f"(transactions={'ON' if use_transactions else 'OFF'}, "
            f"decision_repo={'ON' if decision_repo else 'OFF'})"
        )

    # =========================================================================
    # NEW: ANALYZE METHOD - Determine impact without execution
    # =========================================================================

    def analyze(self, change: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze deleted content change and determine what actions to take.

        This method does NOT modify the database - it only analyzes and
        returns decisions about what SHOULD be done.

        Args:
            change: Dictionary with change information
                Required keys:
                - change_id: int
                - previous_checksum: str (deleted content checksum)

        Returns:
            List of decision dictionaries, each with:
                - change_id: int
                - change_type: 'deleted_content'
                - entity_type: 'question' or 'answer'
                - entity_id: str
                - action: 'INACTIVATE' or 'REGENERATE'
                - reason_code: str
                - priority: 'high' or 'standard'
                - source_count: int
                - estimated_cost_usd: float
        """
        decisions = []
        change_id = change.get('change_id')
        previous_checksum = change.get('previous_checksum')

        logger.info(
            f"[DELETED_CONTENT:ANALYZE] Processing change_id={change_id}, "
            f"previous_checksum={previous_checksum[:8] if previous_checksum else 'None'}..."
        )

        try:
            # Validate input
            self._validate_change_input(change)

            # Find affected questions
            affected_questions = self._find_affected_questions(previous_checksum)

            if not affected_questions:
                logger.info(f"[change_id={change_id}] No FAQs affected")
                return decisions  # Empty list

            logger.info(f"[change_id={change_id}] Found {len(affected_questions)} affected questions")

            # Analyze each question
            for question_id in affected_questions:
                # Count sources
                source_count_result = self.source_counter.count_sources_for_question(question_id)

                # Decision: INACTIVATE or REGENERATE
                if source_count_result.is_orphaned() or source_count_result.is_sole_source:
                    reason = "ORPHANED" if source_count_result.is_orphaned() else "SOLE_SOURCE_DELETED"

                    # Decision 1: Inactivate question
                    decisions.append({
                        'change_id': change_id,
                        'change_type': 'deleted_content',
                        'entity_type': 'question',
                        'entity_id': str(question_id),
                        'action': 'INACTIVATE',
                        'reason_code': reason,
                        'priority': 'high',
                        'source_count': source_count_result.valid_source_count,
                        'content_checksum': previous_checksum,
                        'estimated_cost_usd': 0.0
                    })

                    # Decision 2: Cascade to answers
                    answer_ids = self._get_answer_ids_for_analysis(question_id)
                    for answer_id in answer_ids:
                        decisions.append({
                            'change_id': change_id,
                            'change_type': 'deleted_content',
                            'entity_type': 'answer',
                            'entity_id': str(answer_id),
                            'action': 'INACTIVATE',
                            'reason_code': 'CASCADE_FROM_QUESTION',
                            'priority': 'high',
                            'content_checksum': previous_checksum,
                            'estimated_cost_usd': 0.0
                        })

                else:  # Multi-source
                    # Decision: Regenerate question
                    decisions.append({
                        'change_id': change_id,
                        'change_type': 'deleted_content',
                        'entity_type': 'question',
                        'entity_id': str(question_id),
                        'action': 'REGENERATE',
                        'reason_code': 'MULTI_SOURCE_PARTIAL_DELETE',
                        'priority': 'standard',
                        'source_count': source_count_result.valid_source_count,
                        'content_checksum': previous_checksum,
                        'estimated_cost_usd': 0.05
                    })

                    # Decisions: Regenerate answers
                    answer_ids = self._get_answer_ids_for_analysis(question_id)
                    for answer_id in answer_ids:
                        decisions.append({
                            'change_id': change_id,
                            'change_type': 'deleted_content',
                            'entity_type': 'answer',
                            'entity_id': str(answer_id),
                            'action': 'REGENERATE',
                            'reason_code': 'MULTI_SOURCE_PARTIAL_DELETE',
                            'priority': 'standard',
                            'content_checksum': previous_checksum,
                            'estimated_cost_usd': 0.03
                        })

            logger.info(f"[change_id={change_id}] Analysis complete: {len(decisions)} decisions created")

            return decisions

        except Exception as e:
            error_msg = f"Error during analysis: {str(e)}"
            logger.exception(f"[change_id={change_id}] {error_msg}")
            raise

    def _get_answer_ids_for_analysis(self, question_id: int) -> List[int]:
        """Get answer IDs for analysis (helper for analyze method)"""
        query = """
            SELECT answer_id
            FROM faq_answers
            WHERE question_id = ?
              AND status = 'active'
        """
        rows = self.backend.execute_query(query, (question_id,))
        return [row['answer_id'] for row in rows]

    # =========================================================================
    # NEW: EXECUTE METHOD - Execute decisions
    # =========================================================================

    def execute(self, decisions: List[Dict[str, Any]]) -> HandlerResult:
        """
        Execute decisions created by analyze().

        Args:
            decisions: List of decision dicts from analyze()

        Returns:
            HandlerResult with execution summary
        """
        logger.info(f"[DELETED_CONTENT:EXECUTE] Executing {len(decisions)} decisions...")

        questions_inactivated = 0
        questions_regenerated = 0
        answers_inactivated = 0
        answers_regenerated = 0
        post_exec_decisions = []

        try:
            for decision in decisions:
                action = decision['action']
                entity_type = decision['entity_type']
                entity_id = decision['entity_id']

                if action == 'INACTIVATE':
                    if entity_type == 'question':
                        # Set status AND inactivation audit trail
                        from datetime import datetime
                        now = datetime.now().isoformat()

                        self.backend.execute_update(
                            """UPDATE faq_questions
                               SET status='inactive',
                                   inactivation_reason=?,
                                   inactivated_by_change_id=?,
                                   inactivated_at=?,
                                   modified_at=?
                               WHERE question_id=?""",
                            (
                                decision.get('reason_code'),  # e.g., 'SOLE_SOURCE_DELETED'
                                decision.get('change_id'),
                                now,
                                now,
                                entity_id
                            )
                        )
                        questions_inactivated += 1

                        # Invalidate source
                        self.backend.execute_update(
                            "UPDATE faq_question_sources SET is_valid=0 WHERE question_id=? AND content_checksum=?",
                            (entity_id, decision.get('content_checksum'))
                        )

                        # NEW: Log POST-EXECUTION decision with REAL ID
                        post_exec_decisions.append({
                            'change_id': decision['change_id'],
                            'change_type': 'deleted_content',
                            'entity_type': 'question',
                            'entity_id': str(entity_id),  # REAL ID
                            'action': 'INACTIVATE',
                            'reason_code': decision.get('reason_code'),
                            'content_checksum': decision.get('content_checksum'),
                            'source_count': decision.get('source_count'),
                            'impact_type': decision.get('impact_type', 'direct')
                        })

                    elif entity_type == 'answer':
                        # Set status AND inactivation audit trail
                        from datetime import datetime
                        now = datetime.now().isoformat()

                        self.backend.execute_update(
                            """UPDATE faq_answers
                               SET status='inactive',
                                   inactivation_reason=?,
                                   inactivated_by_change_id=?,
                                   inactivated_at=?,
                                   modified_at=?
                               WHERE answer_id=?""",
                            (
                                decision.get('reason_code'),  # e.g., 'CASCADE_FROM_QUESTION'
                                decision.get('change_id'),
                                now,
                                now,
                                entity_id
                            )
                        )
                        answers_inactivated += 1

                        # NEW: Log POST-EXECUTION decision with REAL ID
                        post_exec_decisions.append({
                            'change_id': decision['change_id'],
                            'change_type': 'deleted_content',
                            'entity_type': 'answer',
                            'entity_id': str(entity_id),  # REAL ID
                            'action': 'INACTIVATE',
                            'reason_code': decision.get('reason_code'),
                            'content_checksum': decision.get('content_checksum'),
                            'impact_type': decision.get('impact_type', 'direct')
                        })

                elif action == 'REGENERATE':
                    if entity_type == 'question':
                        # Get remaining source texts
                        remaining_texts = self._get_remaining_source_texts(
                            question_id=int(entity_id),
                            excluded_checksum=decision.get('content_checksum')
                        )

                        if remaining_texts:
                            regenerated = self._regenerate_question(
                                question_id=int(entity_id),
                                source_texts=remaining_texts
                            )
                            if regenerated:
                                questions_regenerated += 1

                                # NEW: Log POST-EXECUTION decision with REAL ID
                                post_exec_decisions.append({
                                    'change_id': decision['change_id'],
                                    'change_type': 'deleted_content',
                                    'entity_type': 'question',
                                    'entity_id': str(entity_id),  # REAL ID
                                    'action': 'REGENERATE',
                                    'reason_code': decision.get('reason_code'),
                                    'content_checksum': decision.get('content_checksum'),
                                    'source_count': decision.get('source_count'),
                                    'impact_type': decision.get('impact_type', 'direct')
                                })

                            # Invalidate deleted source
                            self.backend.execute_update(
                                "UPDATE faq_question_sources SET is_valid=0 WHERE question_id=? AND content_checksum=?",
                                (entity_id, decision.get('content_checksum'))
                            )

                    elif entity_type == 'answer':
                        # Get question and remaining texts
                        q_query = "SELECT question_id, question_text FROM faq_answers a JOIN faq_questions q ON a.question_id=q.question_id WHERE a.answer_id=?"
                        q_rows = self.backend.execute_query(q_query, (entity_id,))

                        if q_rows:
                            question_id = q_rows[0]['question_id']
                            remaining_texts = self._get_remaining_source_texts(
                                question_id=question_id,
                                excluded_checksum=decision.get('content_checksum')
                            )

                            if remaining_texts:
                                combined_text = "\n\n".join(remaining_texts)
                                answers = self.answer_generator.generate_from_question(
                                    question_text=q_rows[0]['question_text'],
                                    context_text=combined_text,
                                    question_id=str(question_id),
                                    content_checksum="regenerated",
                                    status='active',
                                    confidence_score=0.95
                                )

                                if not isinstance(answers, list):
                                    answers = [answers]

                                if answers and len(answers) > 0:
                                    self.backend.execute_update(
                                        "UPDATE faq_answers SET answer_text=? WHERE answer_id=?",
                                        (answers[0]['answer_text'], entity_id)
                                    )
                                    answers_regenerated += 1

                                    # NEW: Log POST-EXECUTION decision with REAL ID
                                    post_exec_decisions.append({
                                        'change_id': decision['change_id'],
                                        'change_type': 'deleted_content',
                                        'entity_type': 'answer',
                                        'entity_id': str(entity_id),  # REAL ID
                                        'action': 'REGENERATE',
                                        'reason_code': decision.get('reason_code'),
                                        'content_checksum': decision.get('content_checksum'),
                                        'impact_type': decision.get('impact_type', 'direct')
                                    })

            # NEW: Persist POST-EXECUTION decisions
            if post_exec_decisions and self.decision_repo:
                try:
                    self.decision_repo.insert_batch(post_exec_decisions)
                    logger.info(f"Logged {len(post_exec_decisions)} POST-EXEC decisions")
                except Exception as e:
                    logger.warning(f"Failed to log decisions: {e}")

            logger.info(
                f"[DELETED_CONTENT:EXECUTE] Complete: "
                f"{questions_inactivated}Q_inactivated, {questions_regenerated}Q_regenerated, "
                f"{answers_inactivated}A_inactivated, {answers_regenerated}A_regenerated"
            )

            return HandlerResult(
                success=True,
                questions_inactivated=questions_inactivated,
                questions_regenerated=questions_regenerated,
                answers_inactivated=answers_inactivated,
                answers_regenerated=answers_regenerated
            )

        except Exception as e:
            error_msg = f"Execution error: {str(e)}"
            logger.exception(error_msg)
            return HandlerResult(success=False, error=error_msg)

    # =========================================================================
    # BACKWARD COMPATIBLE: handle() method (now calls analyze + execute)
    # =========================================================================

    def handle(self, change: Dict[str, Any]) -> HandlerResult:
        """
        Handle a DELETED_CONTENT change (POST-EXECUTION LOGGING).

        This method now:
        1. Analyzes impact (determines what needs to be done)
        2. Executes actions (includes POST-EXEC decision logging)
        3. Marks change as processed

        Args:
            change: Dictionary with change information
                Required keys:
                - change_id: int
                - previous_checksum: str (64-char SHA-256 hex of deleted content)
                Optional keys:
                - file_name: str

        Returns:
            HandlerResult with detailed outcome

        Example:
            >>> result = handler.handle({
            ...     'change_id': 123,
            ...     'previous_checksum': 'abc123...'
            ... })
            >>> print(result.to_dict())
        """
        change_id = change.get('change_id')

        logger.info(f"[DELETED_CONTENT:HANDLE] Processing change_id={change_id}")

        try:
            # Analyze first
            decisions = self.analyze(change)

            # Check if no impact
            if len(decisions) == 0:
                # Mark as processed (no impact is successful)
                self.backend.execute_update(
                    "UPDATE content_change_log SET processed=1, processed_at=? WHERE change_id=?",
                    (datetime.now().isoformat(), change_id)
                )
                return HandlerResult(success=True, no_impact=True)

            # Execute decisions (now includes POST-EXEC logging internally)
            result = self.execute(decisions)

            # Mark as processed if successful
            if result.success:
                self.backend.execute_update(
                    "UPDATE content_change_log SET processed=1, processed_at=? WHERE change_id=?",
                    (datetime.now().isoformat(), change_id)
                )
            else:
                # Mark as failed
                self.backend.execute_update(
                    "UPDATE content_change_log SET processing_error=? WHERE change_id=?",
                    (result.error, change_id)
                )

            return result

        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.exception(f"[change_id={change_id}] {error_msg}")
            # Mark as failed
            self.backend.execute_update(
                "UPDATE content_change_log SET processing_error=? WHERE change_id=?",
                (str(e), change_id)
            )
            return HandlerResult(success=False, error=error_msg)

    # -------------------------------------------------------------------------
    # Private Helper Methods
    # -------------------------------------------------------------------------

    def _validate_change_input(self, change: Dict[str, Any]) -> None:
        """
        Validate change input dictionary has required fields.

        Args:
            change: Change dictionary to validate

        Raises:
            ValueError: If validation fails
        """
        if not isinstance(change, dict):
            raise ValueError(f"Change must be a dict, got {type(change)}")

        if 'change_id' not in change:
            raise ValueError("Change missing required field: change_id")

        if 'previous_checksum' not in change:
            raise ValueError("Change missing required field: previous_checksum")

        change_id = change['change_id']
        if not isinstance(change_id, int) or change_id <= 0:
            raise ValueError(f"Invalid change_id: {change_id} (must be int > 0)")

        previous_checksum = change['previous_checksum']
        if not previous_checksum or not isinstance(previous_checksum, str):
            raise ValueError(f"Invalid previous_checksum: must be non-empty string")

        if len(previous_checksum) != 64:
            raise ValueError(
                f"Invalid previous_checksum length: expected 64 chars (SHA-256), "
                f"got {len(previous_checksum)}"
            )

    def _find_affected_questions(self, previous_checksum: str) -> List[int]:
        """
        Find all questions linked to the deleted content checksum.

        Args:
            previous_checksum: Checksum of the deleted content

        Returns:
            List of question_id values
        """
        query = """
            SELECT DISTINCT question_id
            FROM faq_question_sources
            WHERE content_checksum = ?
              AND is_valid = 1
            ORDER BY question_id
        """

        rows = self.backend.execute_query(query, (previous_checksum,))
        question_ids = [row['question_id'] for row in rows]

        logger.debug(
            f"Found {len(question_ids)} questions linked to deleted checksum "
            f"{previous_checksum[:8]}..."
        )

        return question_ids

    def _process_question_deletion(
        self,
        question_id: int,
        previous_checksum: str
    ) -> Dict[str, Any]:
        """
        Process deletion impact for a single question.

        Args:
            question_id: ID of the question to process
            previous_checksum: Checksum of deleted content

        Returns:
            Dict with metrics:
                - questions_inactivated: int
                - questions_regenerated: int
                - answers_inactivated: int
                - answers_regenerated: int
                - question_inactivated: bool (for tracking cascades)
        """
        metrics = {
            'questions_inactivated': 0,
            'questions_regenerated': 0,
            'answers_inactivated': 0,
            'answers_regenerated': 0,
            'question_inactivated': False
        }

        # Count remaining valid sources AFTER deletion
        source_count_result = self.source_counter.count_sources_for_question(question_id)

        logger.debug(
            f"Question {question_id}: {source_count_result.valid_source_count} sources remaining"
        )

        # Case 1: Orphaned (0 sources) or Sole source (1 source) → INACTIVATE
        if source_count_result.is_orphaned() or source_count_result.is_sole_source:
            reason = "orphaned" if source_count_result.is_orphaned() else "sole source"
            logger.info(f"Question {question_id} is {reason} - inactivating")

            # Inactivate question
            self.backend.execute_update(
                "UPDATE faq_questions SET status='inactive' WHERE question_id=?",
                (question_id,)
            )
            metrics['questions_inactivated'] = 1
            metrics['question_inactivated'] = True

            # Cascade inactivate all answers
            answer_count = self._cascade_inactivate_answers(question_id)
            metrics['answers_inactivated'] = answer_count

            # Invalidate deleted source
            self.backend.execute_update(
                "UPDATE faq_question_sources SET is_valid=0 WHERE question_id=? AND content_checksum=?",
                (question_id, previous_checksum)
            )

        # Case 2: Multi-source (2+ sources) → REGEN question + answers
        else:
            logger.info(
                f"Question {question_id} has {source_count_result.valid_source_count} sources - "
                f"regenerating"
            )

            # Get remaining source content
            remaining_texts = self._get_remaining_source_texts(
                question_id=question_id,
                excluded_checksum=previous_checksum
            )

            if remaining_texts:
                # Regenerate question
                regenerated = self._regenerate_question(
                    question_id=question_id,
                    source_texts=remaining_texts
                )

                if regenerated:
                    metrics['questions_regenerated'] = 1

                    # Regenerate answers for this question
                    answer_count = self._regenerate_answers_for_question(
                        question_id=question_id,
                        source_texts=remaining_texts
                    )
                    metrics['answers_regenerated'] = answer_count

                # Invalidate deleted source
                self.backend.execute_update(
                    "UPDATE faq_question_sources SET is_valid=0 WHERE question_id=? AND content_checksum=?",
                    (question_id, previous_checksum)
                )

        return metrics

    def _cascade_inactivate_answers(self, question_id: int) -> int:
        """
        Cascade inactivation from question to all its answers.

        Args:
            question_id: ID of the inactivated question

        Returns:
            Number of answers inactivated
        """
        query = """
            SELECT answer_id
            FROM faq_answers
            WHERE question_id = ?
              AND status = 'active'
        """

        rows = self.backend.execute_query(query, (question_id,))
        answer_ids = [row['answer_id'] for row in rows]

        if answer_ids:
            logger.info(
                f"Cascading inactivation from question {question_id} to {len(answer_ids)} answers"
            )

            # Inactivate all answers
            self.backend.execute_update(
                "UPDATE faq_answers SET status='inactive' WHERE question_id=?",
                (question_id,)
            )

        return len(answer_ids)

    def _get_remaining_source_texts(
        self,
        question_id: int,
        excluded_checksum: str
    ) -> List[str]:
        """
        Get source texts for remaining valid sources (excluding deleted one).

        Args:
            question_id: ID of the question
            excluded_checksum: Checksum to exclude (deleted content)

        Returns:
            List of chunk texts
        """
        query = """
            SELECT cc.chunk_text
            FROM faq_question_sources qs
            JOIN content_chunks cc ON qs.content_checksum = cc.content_checksum
            WHERE qs.question_id = ?
              AND qs.is_valid = 1
              AND qs.content_checksum != ?
              AND cc.is_active = 1
            ORDER BY qs.created_at DESC
        """

        rows = self.backend.execute_query(query, (question_id, excluded_checksum))
        texts = [row['chunk_text'] for row in rows]

        logger.debug(
            f"Found {len(texts)} remaining source texts for question {question_id}"
        )

        return texts

    def _regenerate_question(
        self,
        question_id: int,
        source_texts: List[str]
    ) -> bool:
        """
        Regenerate question text using remaining source content.

        Args:
            question_id: ID of the question to regenerate
            source_texts: List of source content texts

        Returns:
            True if regeneration succeeded, False otherwise
        """
        if not source_texts:
            logger.warning(f"No source texts for question {question_id} - skipping regeneration")
            return False

        try:
            # Combine source texts
            combined_text = "\n\n".join(source_texts)

            # Generate questions using generator
            logger.debug(f"Regenerating question {question_id} with {len(source_texts)} sources")

            questions = self.question_generator.generate_from_text(
                chunk_text=combined_text,
                content_checksum="regenerated",  # Placeholder
                source_type='document',
                generation_method='LLM_REGEN',
                status='active'
            )

            if questions and len(questions) > 0:
                # Update question text with first generated question
                new_question_text = questions[0]['question_text']

                self.backend.execute_update(
                    "UPDATE faq_questions SET question_text=? WHERE question_id=?",
                    (new_question_text, question_id)
                )

                logger.info(f"✓ Regenerated question {question_id}")
                return True
            else:
                logger.warning(f"No questions generated for question_id={question_id}")
                return False

        except Exception as e:
            logger.error(f"Error regenerating question {question_id}: {e}")
            return False

    def _regenerate_answers_for_question(
        self,
        question_id: int,
        source_texts: List[str]
    ) -> int:
        """
        Regenerate all answers for a question using remaining source content.

        Args:
            question_id: ID of the question
            source_texts: List of source content texts

        Returns:
            Number of answers regenerated
        """
        if not source_texts:
            logger.warning(f"No source texts for question {question_id} - skipping answer regeneration")
            return 0

        # Get current answers for this question
        query = """
            SELECT answer_id
            FROM faq_answers
            WHERE question_id = ?
              AND status = 'active'
        """

        rows = self.backend.execute_query(query, (question_id,))
        answer_ids = [row['answer_id'] for row in rows]

        if not answer_ids:
            logger.debug(f"No active answers to regenerate for question {question_id}")
            return 0

        # Get question text
        question_query = "SELECT question_text FROM faq_questions WHERE question_id=?"
        q_rows = self.backend.execute_query(question_query, (question_id,))

        if not q_rows:
            logger.warning(f"Question {question_id} not found - cannot regenerate answers")
            return 0

        question_text = q_rows[0]['question_text']
        combined_text = "\n\n".join(source_texts)

        regenerated_count = 0

        for answer_id in answer_ids:
            try:
                # Generate answer
                logger.debug(f"Regenerating answer {answer_id} for question {question_id}")

                answers = self.answer_generator.generate_from_question(
                    question_text=question_text,
                    context_text=combined_text,
                    question_id=str(question_id),
                    content_checksum="regenerated",  # Placeholder
                    status='active',
                    confidence_score=0.95
                )

                # Handle both single answer and list
                if not isinstance(answers, list):
                    answers = [answers]

                if answers and len(answers) > 0:
                    # Update answer text
                    new_answer_text = answers[0]['answer_text']

                    self.backend.execute_update(
                        "UPDATE faq_answers SET answer_text=? WHERE answer_id=?",
                        (new_answer_text, answer_id)
                    )

                    regenerated_count += 1
                    logger.debug(f"✓ Regenerated answer {answer_id}")

            except Exception as e:
                logger.error(f"Error regenerating answer {answer_id}: {e}")
                continue

        if regenerated_count > 0:
            logger.info(f"✓ Regenerated {regenerated_count} answers for question {question_id}")

        return regenerated_count


# =============================================================================
# Backward Compatibility Function
# =============================================================================


def handle_deleted_content_simple(
    change: Dict[str, Any],
    backend: IBackend,
    question_generator: Any,
    answer_generator: Any
) -> Dict[str, Any]:
    """
    Simplified wrapper function for backward compatibility with handle_deleted_content.

    This provides a drop-in replacement for the original handle_deleted_content()
    function with enhanced source counting, cascading, and error handling.

    Args:
        change: Change dictionary (same format as original)
        backend: Database backend
        question_generator: QuestionGenerator instance
        answer_generator: AnswerGenerator instance

    Returns:
        Dict with results (compatible with original format):
            - success: bool
            - questions_inactivated: int
            - questions_regenerated: int
            - answers_inactivated: int
            - answers_regenerated: int
            - error: str (if failed)

    Example:
        >>> # Original code:
        >>> # result = handle_deleted_content(change)
        >>>
        >>> # New code (drop-in replacement):
        >>> result = handle_deleted_content_simple(
        ...     change=change,
        ...     backend=backend,
        ...     question_generator=question_gen,
        ...     answer_generator=answer_gen
        ... )
        >>>
        >>> # Same result format
        >>> if result['success']:
        ...     print(f"Inactivated {result['questions_inactivated']} questions")
    """
    # Create handler instance
    handler = SimpleDeletedContentHandler(
        backend=backend,
        question_generator=question_generator,
        answer_generator=answer_generator
    )

    # Execute handler
    result = handler.handle(change)

    # Convert to dict for backward compatibility
    return result.to_dict()


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "SimpleDeletedContentHandler",
    "HandlerResult",
    "handle_deleted_content_simple",
]
