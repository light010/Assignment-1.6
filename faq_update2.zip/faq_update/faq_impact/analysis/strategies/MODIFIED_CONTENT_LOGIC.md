# Modified Content Strategy - Logic Documentation

**Author:** Analytics Assist Team
**Date:** 2025-11-02
**Module:** `faq_impact.analysis.strategies.modified_content_strategy`
**Status:** Production-Ready

---

## Table of Contents

1. [Overview](#overview)
2. [Key Concepts](#key-concepts)
3. [Decision Logic Flow](#decision-logic-flow)
4. [Impact Detection Methods](#impact-detection-methods)
5. [Decision Rules](#decision-rules)
6. [Examples](#examples)
7. [Testing Strategy](#testing-strategy)
8. [Performance Considerations](#performance-considerations)
9. [Future Enhancements](#future-enhancements)

---

## Overview

The **ModifiedContentStrategy** is the most complex analysis strategy in the FAQ impact system. It handles scenarios where existing source content has been modified (updated, edited, or restructured) in the knowledge base. The strategy determines which questions and answers need to be regenerated or evaluated based on:

- **Direct impact**: FAQs explicitly linked to the modified content
- **Indirect impact**: FAQs with significant token overlap but no direct link
- **Change magnitude**: Similarity scores determine major vs minor changes
- **Source dependency**: Sole-source vs multi-source FAQs have different decision rules

### Core Responsibilities

1. Find all FAQs **directly linked** to the modified content (previous_checksum)
2. Find all FAQs **indirectly affected** via token overlap analysis
3. Determine appropriate regeneration decisions based on:
   - Source counts (sole vs multi)
   - Similarity scores (major vs minor changes)
   - Token overlap metrics (indirect impact)
4. Generate detailed decision metadata for execution phase

### Dependencies

- **IBackend**: Database queries for finding affected FAQs
- **ITokenMatcher**: Token-based overlap detection for indirect impact
- **ISourceCounter**: Dynamic source counting for sole/multi-source classification

---

## Key Concepts

### Change Types and Severity

| Similarity Score | Change Type | Decision Logic |
|------------------|-------------|----------------|
| < 0.6            | **Major Change** | REGEN_A (regenerate answer immediately) |
| ≥ 0.6            | **Minor Change** | EVALUATE (LLM decides if regeneration needed) |
| ≥ 0.9            | **Trivial Change** | Usually EVALUATE or NOOP |

### Impact Categories

#### 1. Direct Impact
- FAQ has explicit source link to `previous_checksum` in `faq_*_sources` tables
- Most critical: content was actually used to generate the FAQ
- **Examples:**
  - Question generated from modified chunk
  - Answer citing modified chunk as source

#### 2. Indirect Impact (Token Overlap)
- No direct source link, but significant lexical similarity
- Detected via **TokenMatcher** using Jaccard similarity
- **Threshold:** Default 0.3+ overlap (configurable)
- **Examples:**
  - Question about "refund policy" when "refund_policy.pdf" is modified
  - Answer mentioning "30-day return" when return policy chunk is updated

### Source Dependencies

#### Sole Source
- FAQ has **exactly 1 valid source**
- **Implication:** Modification directly impacts FAQ semantics
- **Decision:** REGEN_Q (question text may need updating)
- **Example:** Question "What is the contribution limit?" generated from single chunk about limits

#### Multi-Source
- FAQ has **2+ valid sources**
- **Implication:** FAQ aggregates multiple sources, one changed
- **Decision:** Answer may need regen, question usually stable
- **Example:** Answer citing 3 different policy chunks, one updated

---

## Decision Logic Flow

### Phase 1: Validation

```python
# Required context fields
- change_type == "MODIFIED_CONTENT"
- content_checksum (new checksum) != None
- previous_checksum (old checksum) != None
- similarity_score (0.0-1.0) != None
```

**Validation Failures:**
- Missing any required field → `ValueError`
- Wrong change_type → `ValueError`
- Invalid similarity_score range → `ValueError`

### Phase 2: Direct Impact Detection

**Step 2.1: Find Directly Affected Questions**

```sql
SELECT DISTINCT question_id
FROM faq_question_sources
WHERE content_checksum = ?  -- previous_checksum
  AND is_valid = 1
ORDER BY question_id
```

**Step 2.2: Find Directly Affected Answers**

```sql
SELECT DISTINCT answer_id
FROM faq_answer_sources
WHERE content_checksum = ?  -- previous_checksum
  AND is_valid = 1
ORDER BY answer_id
```

### Phase 3: Indirect Impact Detection (Token Overlap)

**Step 3.1: Extract Tokens from Diff Data**

```python
# TokenMatcher.extract_tokens_from_diff_data()
diff_data = {
    "changes": [
        {
            "token_changes": [
                {"type": "replace", "old_value": "12", "new_value": "10"},
                {"type": "add", "new_value": "business"}
            ]
        }
    ]
}

# Extracted tokens: {"12", "10", "business"}
```

**Step 3.2: Find Overlapping Questions**

```python
# TokenMatcher.find_overlapping_questions()
# Returns: List[TokenOverlapResult]
#   - question_id
#   - overlap_score (Jaccard similarity)
#   - overlap_percentage
#   - matched_tokens
#   - total_question_tokens

# Filter: Exclude questions already in direct impact
```

### Phase 4: Decision Generation

#### For Each Directly Affected Question:

```
1. Count sources (SourceCounter.count_sources_for_question())
2. If sole_source:
     → REGEN_Q (reason: SOLE_SOURCE_CONTENT_CHANGED)
3. If multi_source:
     → No question decision (question stable, only answers may change)
```

#### For Each Directly Affected Answer:

```
1. Get parent question_id
2. Check similarity score:
   - If similarity < 0.6 (MAJOR CHANGE):
       → REGEN_A (reason: ANSWER_FACTS_CHANGED)
   - If similarity ≥ 0.6 (MINOR CHANGE):
       → EVALUATE (reason: SIMILARITY_AMBIGUOUS)
```

#### For Each Token-Overlap Question (Indirect):

```
→ REGEN_Q (reason: TOKEN_OVERLAP_DETECTED)
  Include overlap metrics in details JSON
```

### Phase 5: Edge Case Handling

**No Affected FAQs:**
```python
if (no direct questions AND
    no direct answers AND
    no token overlap):
    return []  # Empty list = NOOP
```

---

## Impact Detection Methods

### Direct Impact: Source Table Queries

**Advantages:**
- ✅ Highly accurate (explicit links)
- ✅ Fast (indexed queries)
- ✅ Deterministic (no false positives)

**Limitations:**
- ❌ Misses indirect relationships
- ❌ Requires well-maintained source links

### Indirect Impact: Token Overlap Analysis

**How It Works:**

1. **Token Extraction:**
   ```python
   # From diff_data JSON
   changed_tokens = {"refund", "policy", "30", "days"}
   ```

2. **Jaccard Similarity:**
   ```python
   # J(A, B) = |A ∩ B| / |A ∪ B|
   question_tokens = {"what", "is", "the", "refund", "policy"}
   overlap = |{"refund", "policy"}| / |{"what", "is", "the", "refund", "policy", "30", "days"}|
   overlap = 2 / 7 = 0.286
   ```

3. **Threshold Filtering:**
   ```python
   # Default threshold: 0.3 (30% overlap)
   if overlap >= 0.3:
       # Include in results
   ```

**Advantages:**
- ✅ Catches indirect relationships
- ✅ Lexical similarity is often semantic
- ✅ Configurable sensitivity

**Limitations:**
- ❌ Potential false positives (homonyms)
- ❌ Misses semantic similarity without lexical overlap
- ❌ Performance cost for large datasets

---

## Decision Rules

### Rule Matrix

| Scenario | Source Count | Similarity | Decision | Reason Code |
|----------|--------------|------------|----------|-------------|
| **Question (Direct)** | Sole (1) | Any | REGEN_Q | SOLE_SOURCE_CONTENT_CHANGED |
| **Question (Direct)** | Multi (2+) | Any | (none) | (question stable) |
| **Answer (Direct)** | Any | < 0.6 | REGEN_A | ANSWER_FACTS_CHANGED |
| **Answer (Direct)** | Any | ≥ 0.6 | EVALUATE | SIMILARITY_AMBIGUOUS |
| **Question (Indirect)** | N/A | Any | REGEN_Q | TOKEN_OVERLAP_DETECTED |
| **No Impact** | N/A | N/A | (empty list) | (NOOP) |

### Threshold Constants

```python
# Similarity threshold for major vs minor changes
SIMILARITY_THRESHOLD_MAJOR = 0.6

# < 0.6 = major change → REGEN_A
# ≥ 0.6 = minor change → EVALUATE
```

### Decision Details Schema

#### REGEN_Q (Direct Impact)

```json
{
  "previous_checksum": "old_abc123...",
  "new_checksum": "new_abc123...",
  "similarity_score": 0.75,
  "valid_source_count": 1,
  "impact_type": "direct",
  "reason_detail": "Question's sole source content was modified"
}
```

#### REGEN_Q (Indirect Impact - Token Overlap)

```json
{
  "previous_checksum": "old_def456...",
  "new_checksum": "new_def456...",
  "similarity_score": 0.70,
  "impact_type": "indirect",
  "overlap_score": 0.75,
  "overlap_percentage": 0.75,
  "matched_tokens": ["refund", "policy", "30"],
  "total_question_tokens": 10,
  "reason_detail": "Significant token overlap (75.0%) detected"
}
```

#### REGEN_A (Major Change)

```json
{
  "question_id": 50,
  "previous_checksum": "old_ghi789...",
  "new_checksum": "new_ghi789...",
  "similarity_score": 0.45,
  "similarity_threshold": 0.6,
  "change_magnitude": "major",
  "impact_type": "direct",
  "reason_detail": "Major content change detected (similarity=0.450)"
}
```

#### EVALUATE (Minor Change)

```json
{
  "question_id": 51,
  "previous_checksum": "old_jkl012...",
  "new_checksum": "new_jkl012...",
  "similarity_score": 0.85,
  "similarity_threshold": 0.6,
  "change_magnitude": "minor",
  "impact_type": "direct",
  "evaluation_criteria": [
    "Does the answer still accurately reflect the content?",
    "Are there any factual changes that affect the answer?",
    "Does the answer need to be regenerated or is it still valid?"
  ],
  "reason_detail": "Minor content change detected (similarity=0.850), LLM evaluation needed"
}
```

---

## Examples

### Example 1: Sole Source Question with Major Change

**Scenario:**
- Question "What is the annual contribution limit?" generated from single chunk
- Chunk modified: "12,000" → "15,000" (similarity = 0.55)

**Detection:**
- Direct impact: question_id=42 linked to previous_checksum
- Source count: 1 (sole source)
- Similarity: 0.55 (major change)

**Decisions Generated:**
1. **REGEN_Q** for question 42
   - Reason: SOLE_SOURCE_CONTENT_CHANGED
   - Details: similarity=0.55, sole source

### Example 2: Multi-Source Answer with Minor Change

**Scenario:**
- Answer "The policy covers X, Y, and Z" uses 3 source chunks
- One chunk modified slightly (similarity = 0.88)

**Detection:**
- Direct impact: answer_id=100 linked to previous_checksum
- Similarity: 0.88 (minor change)

**Decisions Generated:**
1. **EVALUATE** for answer 100
   - Reason: SIMILARITY_AMBIGUOUS
   - Details: similarity=0.88, evaluation_criteria=[...]

### Example 3: Token Overlap (Indirect Impact)

**Scenario:**
- Modified chunk contains tokens: ["refund", "policy", "30", "days"]
- Question "What is the refund policy timeframe?" has 70% token overlap
- No direct source link between question and chunk

**Detection:**
- Indirect impact: question_id=60 via token overlap
- Overlap: 0.70 (above 0.3 threshold)

**Decisions Generated:**
1. **REGEN_Q** for question 60
   - Reason: TOKEN_OVERLAP_DETECTED
   - Details: overlap=0.70, matched_tokens=["refund", "policy", "30"]

### Example 4: Complex Multi-Entity Scenario

**Scenario:**
- Modified chunk (similarity = 0.50, major change)
- Directly affects:
  - Question 80 (sole source)
  - Answer 110 (multi-source)
- Indirectly affects:
  - Question 82 (token overlap 0.65)

**Decisions Generated:**
1. **REGEN_Q** for question 80 (direct, sole source)
2. **REGEN_A** for answer 110 (direct, major change)
3. **REGEN_Q** for question 82 (indirect, token overlap)

### Example 5: No Impact (NOOP)

**Scenario:**
- Modified chunk has no direct links in faq_*_sources
- No token overlap with any existing questions
- Content change is isolated

**Decisions Generated:**
- Empty list `[]` (NOOP - no action needed)

---

## Testing Strategy

### Test Coverage Areas

1. **can_handle() Tests**
   - ✅ Returns True for "MODIFIED_CONTENT"
   - ✅ Returns False for other change types
   - ✅ Case-sensitive comparison

2. **Context Validation Tests**
   - ✅ Missing content_checksum raises ValueError
   - ✅ Missing previous_checksum raises ValueError
   - ✅ Missing similarity_score raises ValueError
   - ✅ Wrong change_type raises ValueError

3. **Direct Impact Tests**
   - ✅ Sole-source question → REGEN_Q
   - ✅ Multi-source question → no decision
   - ✅ Major change answer (< 0.6) → REGEN_A
   - ✅ Minor change answer (≥ 0.6) → EVALUATE

4. **Indirect Impact Tests**
   - ✅ Token overlap → REGEN_Q with TOKEN_OVERLAP_DETECTED
   - ✅ Excludes questions already in direct impact
   - ✅ Includes overlap metrics in details

5. **Edge Case Tests**
   - ✅ No affected FAQs → empty list
   - ✅ Similarity exactly at threshold (0.6) → EVALUATE
   - ✅ Complex mixed scenarios (direct + indirect + answers)

6. **Decision Details Schema Tests**
   - ✅ REGEN_Q details have required fields
   - ✅ EVALUATE details include evaluation_criteria
   - ✅ Token overlap details include overlap metrics

### Test File Location

```
faq_impact/tests/analysis/strategies/test_modified_content_strategy.py
```

### Running Tests

```bash
# Run all ModifiedContentStrategy tests
python -m unittest faq_impact.tests.analysis.strategies.test_modified_content_strategy

# Run specific test class
python -m unittest faq_impact.tests.analysis.strategies.test_modified_content_strategy.TestModifiedContentStrategyDirectImpact

# Run with verbose output
python -m unittest -v faq_impact.tests.analysis.strategies.test_modified_content_strategy
```

---

## Performance Considerations

### Query Optimization

**Direct Impact Queries:**
```sql
-- Indexed on (content_checksum, is_valid)
-- Fast lookup, O(log N) on indexed columns

SELECT DISTINCT question_id
FROM faq_question_sources
WHERE content_checksum = ?
  AND is_valid = 1
```

**Recommendations:**
- ✅ Ensure indexes on `content_checksum` and `is_valid` columns
- ✅ Use `DISTINCT` to avoid duplicate question/answer IDs
- ✅ Batch queries where possible

### Token Matcher Performance

**Considerations:**
- Token extraction from diff_data: O(M) where M = number of changes
- Jaccard similarity calculation: O(N) where N = number of questions
- Threshold filtering reduces result set size

**Optimizations:**
- Use database full-text search for initial filtering
- Cache token sets for questions (invalidate on question updates)
- Adjust overlap threshold based on dataset size

### Source Counter Caching

**Strategy:**
- SourceCounter may cache results within single analysis run
- Clear cache between detection runs to avoid stale data
- Trade-off: cache hits vs memory usage

---

## Future Enhancements

### Planned Improvements

1. **Semantic Similarity for Indirect Impact**
   - Current: Lexical token overlap (Jaccard)
   - Enhancement: Use embeddings + cosine similarity
   - Benefit: Catch semantic relationships without lexical overlap

2. **Configurable Thresholds**
   - Current: Hardcoded similarity threshold (0.6)
   - Enhancement: Load from configuration file
   - Benefit: Tune thresholds per domain/content type

3. **Batch Processing Optimization**
   - Current: Process one change at a time
   - Enhancement: Batch-process multiple changes
   - Benefit: Reduce redundant queries, improve throughput

4. **Historical Decision Analysis**
   - Current: No feedback loop
   - Enhancement: Analyze past decisions (EVALUATE outcomes)
   - Benefit: Improve threshold tuning, reduce false positives

5. **Differential Source Tracking**
   - Current: Binary (linked or not)
   - Enhancement: Track contribution weights per source
   - Benefit: More nuanced regeneration decisions

### Research Questions

- **Optimal Similarity Threshold:** Is 0.6 the best boundary for major/minor?
- **Token Overlap Threshold:** Should 0.3 be domain-specific?
- **Multi-Source Aggregation:** How to handle multiple modified sources?
- **Cascading Updates:** If question regenerated, auto-regen answers?

---

## Appendix: Code Organization

### File Structure

```
faq_impact/
├── analysis/
│   ├── strategies/
│   │   ├── modified_content_strategy.py      # Main implementation
│   │   ├── MODIFIED_CONTENT_LOGIC.md         # This documentation
│   │   └── ...
│   └── services/
│       ├── token_matcher.py                   # Token overlap detection
│       └── source_counter.py                  # Source counting
├── core/
│   ├── interfaces/
│   │   └── analyzer.py                        # IAnalysisStrategy interface
│   ├── models/
│   │   ├── detection_context.py               # Input data model
│   │   └── impact_decision.py                 # Output data model
│   └── enums/
│       ├── decision_type.py                   # DecisionType enum
│       └── reason_code.py                     # ReasonCode enum
└── tests/
    └── analysis/
        └── strategies/
            └── test_modified_content_strategy.py  # Unit tests
```

### Key Classes and Interfaces

- **ModifiedContentStrategy**: Main strategy implementation
- **ITokenMatcher**: Token overlap detection interface
- **ISourceCounter**: Source counting interface
- **DetectionContext**: Input data model (change information)
- **ImpactDecision**: Output data model (decision + metadata)
- **DecisionType**: Enum for decision types (REGEN_Q, REGEN_A, EVALUATE, etc.)
- **ReasonCode**: Enum for reason codes (why decision was made)

---

## References

- Implementation Plan: `IMPLEMENTATION_PLAN.md` (Items 131-140)
- Token Matcher Documentation: `analysis/services/TOKEN_MATCHER.md`
- Source Counter Documentation: `analysis/services/SOURCE_COUNTER.md`
- FAQ Impact System Overview: `docs/FAQ_IMPACT_SYSTEM.md`

---

**End of Documentation**

For questions or clarifications, contact the Analytics Assist Team.
