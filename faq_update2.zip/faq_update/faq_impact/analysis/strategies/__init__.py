"""
Impact Analysis Strategies - Pluggable Change Type Handlers

This module implements the Strategy Pattern for handling different types
of content changes. Each strategy encapsulates the logic for analyzing
one type of change (new, modified, deleted).

Strategy Pattern Benefits:
    - Single Responsibility: Each strategy handles one change type
    - Open/Closed: Add new strategies without modifying existing code
    - Testability: Each strategy can be tested independently
    - Flexibility: Strategies can be swapped or customized

Available Strategies:

1. NewContentStrategy
   Purpose: Handle newly added content chunks
   Logic:
   - Generate questions from the new chunk
   - Generate answers for those questions
   - Link Q/A pairs to the new chunk's checksum
   Output: List of questions/answers to create

2. ModifiedContentStrategy
   Purpose: Handle modified content chunks
   Logic:
   - Find all questions linked to old/new checksum
   - Use llm_friendly_diff to evaluate changes
   - Flag affected questions for regeneration
   - For unaffected questions, evaluate if answers still valid
   - Update provenance (invalidate old, add new checksum)
   Output: List of questions to regenerate, answers to update

3. DeletedContentStrategy
   Purpose: Handle deleted content chunks
   Logic:
   - Find all questions citing the deleted checksum
   - If question depends ONLY on deleted chunk → deactivate
   - If question depends on multiple chunks → regenerate using remaining sources
   - Invalidate deleted checksum in provenance
   Output: List of questions to deactivate, questions to regenerate

Strategy Interface:
    All strategies implement the ImpactStrategy interface:

    class ImpactStrategy(ABC):
        @abstractmethod
        def analyze(
            self,
            change: DetectedChange,
            repository: ImpactRepository
        ) -> ChangeImpact:
            '''Analyze the impact of a change'''
            pass

Example:
    >>> from faq_impact.analysis.strategies import ModifiedContentStrategy
    >>> from faq_impact.core.models import DetectedChange
    >>>
    >>> strategy = ModifiedContentStrategy(diff_evaluator, llm_client)
    >>> change = DetectedChange(
    ...     chunk_id=123,
    ...     old_checksum="abc",
    ...     new_checksum="def",
    ...     change_type=ChangeType.MODIFIED
    ... )
    >>> impact = strategy.analyze(change, repository)
    >>> print(f"Questions to regenerate: {impact.questions_to_regenerate}")

Design Notes:
    - Strategies are stateless and can be reused
    - Strategies depend on injected services (DiffEvaluator, LLM client)
    - Strategies return immutable ChangeImpact objects
    - Repository handles all database operations

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Import implemented strategies
from .new_content_strategy import NewContentStrategy

__all__ = [
    "NewContentStrategy",
]
