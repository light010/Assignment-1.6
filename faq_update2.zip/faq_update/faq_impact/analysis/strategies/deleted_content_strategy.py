"""
DeletedContentStrategy - Analysis Strategy for Deleted Content Changes

This module implements the analysis strategy for handling DELETED_CONTENT change
types in the FAQ impact system. When source content is deleted, this strategy
determines which questions and answers should be inactivated or regenerated based
on source counting logic.

Key Concepts:
    - Sole Source: Question/answer has exactly 1 valid source
        → If deleted, INACTIVATE the entity
    - Multi-Source: Question/answer has 2+ valid sources
        → If one deleted, REGEN (keep entity active, regenerate with remaining sources)
    - Orphaned: Question/answer has 0 valid sources
        → INACTIVATE (no sources remain)
    - Cascading: Question inactivated → cascade INACTIVATE to all its answers

Decision Logic Flow:
    1. Find all questions/answers linked to deleted content (previous_checksum)
    2. For each affected entity, count remaining valid sources
    3. Classify as sole source (count=1), multi-source (count>1), or orphaned (count=0)
    4. Generate appropriate decisions:
        - Sole source questions → INACTIVATE question + cascade to answers
        - Multi-source questions → REGEN_Q (preserve question, regenerate)
        - Sole source answers (question still valid) → REGEN_A
        - Multi-source answers → REGEN_A
        - Orphaned entities → INACTIVATE (all sources gone)

Classes:
    - DeletedContentStrategy: Concrete implementation of IAnalysisStrategy

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import List, Set, Tuple, Optional
from datetime import datetime

# Import core interfaces and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_impact.core.interfaces.analyzer import IAnalysisStrategy
from faq_impact.core.models.detection_context import DetectionContext
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.analysis.services.source_counter import ISourceCounter
from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# DeletedContentStrategy Implementation
# =============================================================================


class DeletedContentStrategy(IAnalysisStrategy):
    """
    Analysis strategy for DELETED_CONTENT change type.

    This strategy handles scenarios where source content has been deleted from
    the knowledge base. It determines which questions and answers should be
    inactivated (if they lose their sole/all sources) or regenerated (if they
    have multiple sources remaining).

    Core Logic:
        1. Query faq_question_sources and faq_answer_sources for entities
           linked to the deleted content (previous_checksum)
        2. For each affected entity, use SourceCounter to count remaining
           valid sources (excluding the deleted one)
        3. Apply decision rules:
            - Sole source question → INACTIVATE question + cascade to answers
            - Multi-source question → REGEN_Q (keep active, regenerate)
            - Sole source answer (question valid) → REGEN_A
            - Multi-source answer → REGEN_A
            - Orphaned entity (count=0) → INACTIVATE with ALL_SOURCES_INVALID
        4. Return list of ImpactDecision objects

    Dependencies:
        - backend: Database backend for querying source tables
        - source_counter: SourceCounter service for dynamic source counting

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from analysis.services.source_counter import SourceCounter
        >>>
        >>> backend = BackendFactory.create_backend(config)
        >>> source_counter = SourceCounter(backend)
        >>> strategy = DeletedContentStrategy(backend, source_counter)
        >>>
        >>> context = DetectionContext(
        ...     detection_run_id="run_001",
        ...     change_id=123,
        ...     change_type="DELETED_CONTENT",
        ...     previous_checksum="abc123",
        ...     content_checksum=None
        ... )
        >>>
        >>> if strategy.can_handle(context.change_type):
        ...     decisions = strategy.analyze(context)
        ...     for decision in decisions:
        ...         print(f"{decision.decision.value}: {decision.entity_type.value} {decision.entity_id}")

    Design Notes:
        - Read-only strategy: queries database but makes no mutations
        - Uses SourceCounter for accurate, cache-friendly source counting
        - Handles race conditions: dynamically recounts sources on each analysis
        - Cascades inactivations: question → answers
        - Generates one decision per affected entity
        - Returns empty list if no FAQs are affected (valid NOOP)
    """

    def __init__(self, backend: IBackend, source_counter: ISourceCounter):
        """
        Initialize DeletedContentStrategy.

        Args:
            backend: Database backend for executing queries
            source_counter: SourceCounter service for counting valid sources

        Example:
            >>> strategy = DeletedContentStrategy(backend, source_counter)
        """
        self.backend = backend
        self.source_counter = source_counter

        logger.info("Initialized DeletedContentStrategy")

    def can_handle(self, change_type: str) -> bool:
        """
        Determine if this strategy can handle the given change type.

        This strategy handles DELETED_CONTENT change types only.

        Args:
            change_type: String representing the type of change
                Expected value: "DELETED_CONTENT"

        Returns:
            bool: True if change_type is "DELETED_CONTENT", False otherwise

        Example:
            >>> strategy.can_handle("DELETED_CONTENT")
            True
            >>> strategy.can_handle("NEW_CONTENT")
            False
            >>> strategy.can_handle("MODIFIED_CONTENT")
            False

        Notes:
            - This is a fast check (no I/O operations)
            - Used by IImpactAnalyzer to select the appropriate strategy
        """
        return change_type == "DELETED_CONTENT"

    def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        """
        Analyze a DELETED_CONTENT change and generate impact decisions.

        This method implements the core deleted content analysis logic:
        1. Validate context (must have previous_checksum)
        2. Find all affected questions and answers
        3. Count remaining valid sources for each entity
        4. Generate appropriate decisions based on source counts
        5. Handle cascading inactivations (question → answers)

        Args:
            context: DetectionContext containing:
                - change_type: Must be "DELETED_CONTENT"
                - previous_checksum: Required (checksum of deleted content)
                - change_id: ID of the content change
                - detection_run_id: ID of the detection run

        Returns:
            List[ImpactDecision]: List of impact decisions, may include:
                - INACTIVATE decisions for sole source questions
                - INACTIVATE decisions for cascaded answers
                - REGEN_Q decisions for multi-source questions
                - REGEN_A decisions for answer-only source deletion
                - Empty list if no FAQs affected (valid NOOP)

        Raises:
            ValueError: If context is invalid (missing previous_checksum, wrong change_type)
            RuntimeError: If database queries fail

        Example:
            >>> context = DetectionContext(
            ...     detection_run_id="run_001",
            ...     change_id=123,
            ...     change_type="DELETED_CONTENT",
            ...     previous_checksum="abc123",
            ...     content_checksum=None
            ... )
            >>> decisions = strategy.analyze(context)
            >>> for decision in decisions:
            ...     print(f"{decision.decision.value}: {decision.reason.value}")

        Implementation Notes:
            - Dynamically recounts sources (handles race conditions)
            - Generates one decision per affected entity
            - Cascades question inactivations to answers
            - Returns empty list if no entities affected (NOOP)
            - All decisions reference the same change_id and detection_run_id
        """
        logger.info(
            f"Analyzing DELETED_CONTENT change (change_id={context.change_id}, "
            f"previous_checksum={context.previous_checksum})"
        )

        # Validate context
        self._validate_context(context)

        # Step 1: Find all affected questions and answers
        affected_questions = self._find_affected_questions(context.previous_checksum)
        affected_answers = self._find_affected_answers(context.previous_checksum)

        logger.info(
            f"Found {len(affected_questions)} affected questions, "
            f"{len(affected_answers)} affected answers"
        )

        if not affected_questions and not affected_answers:
            logger.info("No FAQs affected by deleted content - returning empty decision list")
            return []

        # Step 2: Generate decisions for affected entities
        decisions: List[ImpactDecision] = []
        inactivated_question_ids: Set[int] = set()

        # Process questions first (may cascade to answers)
        for question_id in affected_questions:
            question_decisions = self._process_question_deletion(
                question_id=question_id,
                context=context
            )
            decisions.extend(question_decisions)

            # Track which questions are being inactivated (for cascading)
            for decision in question_decisions:
                if (decision.decision == DecisionType.INACTIVATE and
                    decision.entity_type == EntityType.QUESTION):
                    inactivated_question_ids.add(question_id)

        # Process answers
        for answer_id in affected_answers:
            answer_decisions = self._process_answer_deletion(
                answer_id=answer_id,
                context=context,
                inactivated_question_ids=inactivated_question_ids
            )
            decisions.extend(answer_decisions)

        logger.info(
            f"Generated {len(decisions)} impact decisions for deleted content "
            f"(change_id={context.change_id})"
        )

        return decisions

    # -------------------------------------------------------------------------
    # Private Helper Methods
    # -------------------------------------------------------------------------

    def _validate_context(self, context: DetectionContext) -> None:
        """
        Validate that the DetectionContext is appropriate for this strategy.

        Args:
            context: DetectionContext to validate

        Raises:
            ValueError: If context is invalid
        """
        if context.change_type != "DELETED_CONTENT":
            raise ValueError(
                f"DeletedContentStrategy requires change_type='DELETED_CONTENT', "
                f"got '{context.change_type}'"
            )

        if context.previous_checksum is None:
            raise ValueError(
                "DeletedContentStrategy requires previous_checksum "
                "(checksum of deleted content)"
            )

        logger.debug(f"Context validated for deleted content analysis")

    def _find_affected_questions(self, previous_checksum: str) -> List[int]:
        """
        Find all questions linked to the deleted content checksum.

        Queries faq_question_sources table to find questions that have
        the deleted content as a source (is_valid=1).

        Args:
            previous_checksum: Checksum of the deleted content

        Returns:
            List of question_id values (integers)

        Example:
            >>> question_ids = strategy._find_affected_questions("abc123")
            >>> question_ids
            [42, 58, 91]
        """
        query = """
            SELECT DISTINCT question_id
            FROM faq_question_sources
            WHERE content_checksum = ?
              AND is_valid = 1
            ORDER BY question_id
        """

        rows = self.backend.execute_query(query, (previous_checksum,))
        question_ids = [row['question_id'] for row in rows]

        logger.debug(
            f"Found {len(question_ids)} questions linked to deleted checksum "
            f"{previous_checksum}"
        )

        return question_ids

    def _find_affected_answers(self, previous_checksum: str) -> List[int]:
        """
        Find all answers linked to the deleted content checksum.

        Queries faq_answer_sources table to find answers that have
        the deleted content as a source (is_valid=1).

        Args:
            previous_checksum: Checksum of the deleted content

        Returns:
            List of answer_id values (integers)

        Example:
            >>> answer_ids = strategy._find_affected_answers("abc123")
            >>> answer_ids
            [100, 101, 105]
        """
        query = """
            SELECT DISTINCT answer_id
            FROM faq_answer_sources
            WHERE content_checksum = ?
              AND is_valid = 1
            ORDER BY answer_id
        """

        rows = self.backend.execute_query(query, (previous_checksum,))
        answer_ids = [row['answer_id'] for row in rows]

        logger.debug(
            f"Found {len(answer_ids)} answers linked to deleted checksum "
            f"{previous_checksum}"
        )

        return answer_ids

    def _process_question_deletion(
        self,
        question_id: int,
        context: DetectionContext
    ) -> List[ImpactDecision]:
        """
        Process deletion impact for a single question.

        This method:
        1. Counts remaining valid sources for the question
        2. Determines if question should be inactivated or regenerated
        3. If inactivated, cascades to all associated answers
        4. Generates appropriate ImpactDecision objects

        Args:
            question_id: ID of the question to process
            context: DetectionContext with change information

        Returns:
            List of ImpactDecision objects (question + cascaded answers if inactivated)

        Decision Rules:
            - If orphaned (count=0): INACTIVATE with reason ORPHANED_QUESTION
            - If sole source (count=1, now being deleted): INACTIVATE with reason CONTENT_DELETED
            - If multi-source (count>1): REGEN_Q with reason MULTI_SOURCE_ONE_MODIFIED
        """
        decisions: List[ImpactDecision] = []

        # Count remaining valid sources AFTER deletion
        source_count_result = self.source_counter.count_sources_for_question(question_id)

        logger.debug(
            f"Question {question_id}: {source_count_result.valid_source_count} sources "
            f"(sole_source={source_count_result.is_sole_source}, "
            f"orphaned={source_count_result.is_orphaned()})"
        )

        # Case 1: Orphaned (no sources remain)
        if source_count_result.is_orphaned():
            logger.info(f"Question {question_id} is orphaned - inactivating")

            # Generate INACTIVATE decision for question
            question_decision = self._create_decision(
                context=context,
                entity_type=EntityType.QUESTION,
                entity_id=question_id,
                decision_type=DecisionType.INACTIVATE,
                reason=ReasonCode.ORPHANED_QUESTION,
                details={
                    "previous_checksum": context.previous_checksum,
                    "valid_source_count": 0,
                    "reason_detail": "All sources for this question are invalid or deleted"
                }
            )
            decisions.append(question_decision)

            # Cascade inactivation to all answers
            answer_decisions = self._cascade_inactivate_answers(
                question_id=question_id,
                context=context
            )
            decisions.extend(answer_decisions)

        # Case 2: Sole source (count=1, being deleted now)
        elif source_count_result.is_sole_source:
            logger.info(f"Question {question_id} has sole source - inactivating")

            # Generate INACTIVATE decision for question
            question_decision = self._create_decision(
                context=context,
                entity_type=EntityType.QUESTION,
                entity_id=question_id,
                decision_type=DecisionType.INACTIVATE,
                reason=ReasonCode.CONTENT_DELETED,
                details={
                    "previous_checksum": context.previous_checksum,
                    "valid_source_count": source_count_result.valid_source_count,
                    "remaining_checksums": source_count_result.source_checksums,
                    "reason_detail": "Question's sole source content was deleted"
                }
            )
            decisions.append(question_decision)

            # Cascade inactivation to all answers
            answer_decisions = self._cascade_inactivate_answers(
                question_id=question_id,
                context=context
            )
            decisions.extend(answer_decisions)

        # Case 3: Multi-source (count>1, keep question active, regenerate)
        else:
            logger.info(
                f"Question {question_id} has {source_count_result.valid_source_count} sources - "
                f"regenerating question"
            )

            # Generate REGEN_Q decision
            question_decision = self._create_decision(
                context=context,
                entity_type=EntityType.QUESTION,
                entity_id=question_id,
                decision_type=DecisionType.REGEN_Q,
                reason=ReasonCode.MULTI_SOURCE_ONE_MODIFIED,
                details={
                    "previous_checksum": context.previous_checksum,
                    "valid_source_count": source_count_result.valid_source_count,
                    "remaining_checksums": source_count_result.source_checksums,
                    "reason_detail": "One of multiple sources deleted, regenerate question"
                }
            )
            decisions.append(question_decision)

        return decisions

    def _process_answer_deletion(
        self,
        answer_id: int,
        context: DetectionContext,
        inactivated_question_ids: Set[int]
    ) -> List[ImpactDecision]:
        """
        Process deletion impact for a single answer.

        This method:
        1. Checks if answer's parent question is being inactivated (skip if so)
        2. Counts remaining valid sources for the answer
        3. Generates INACTIVATE or REGEN_A decision based on source count

        Args:
            answer_id: ID of the answer to process
            context: DetectionContext with change information
            inactivated_question_ids: Set of question IDs being inactivated
                (to avoid duplicate cascaded inactivations)

        Returns:
            List of ImpactDecision objects (single decision for answer)

        Decision Rules:
            - If parent question inactivated: Skip (already cascaded)
            - If orphaned (count=0): INACTIVATE with reason ORPHANED_ANSWER
            - If sole source or multi-source: REGEN_A with reason ANSWER_FACTS_CHANGED
        """
        decisions: List[ImpactDecision] = []

        # Get answer's parent question_id
        question_id = self._get_question_id_for_answer(answer_id)

        if question_id is None:
            logger.warning(f"Answer {answer_id} has no parent question - skipping")
            return decisions

        # Check if parent question is being inactivated
        if question_id in inactivated_question_ids:
            logger.debug(
                f"Answer {answer_id}'s parent question {question_id} is being "
                f"inactivated - skipping (will be cascaded)"
            )
            return decisions

        # Count remaining valid sources AFTER deletion
        source_count_result = self.source_counter.count_sources_for_answer(answer_id)

        logger.debug(
            f"Answer {answer_id}: {source_count_result.valid_source_count} sources "
            f"(sole_source={source_count_result.is_sole_source}, "
            f"orphaned={source_count_result.is_orphaned()})"
        )

        # Case 1: Orphaned (no sources remain)
        if source_count_result.is_orphaned():
            logger.info(f"Answer {answer_id} is orphaned - inactivating")

            answer_decision = self._create_decision(
                context=context,
                entity_type=EntityType.ANSWER,
                entity_id=answer_id,
                decision_type=DecisionType.INACTIVATE,
                reason=ReasonCode.ORPHANED_ANSWER,
                details={
                    "question_id": question_id,
                    "previous_checksum": context.previous_checksum,
                    "valid_source_count": 0,
                    "reason_detail": "All sources for this answer are invalid or deleted"
                }
            )
            decisions.append(answer_decision)

        # Case 2: Has remaining sources (sole or multi) - regenerate
        else:
            logger.info(
                f"Answer {answer_id} has {source_count_result.valid_source_count} sources - "
                f"regenerating answer"
            )

            answer_decision = self._create_decision(
                context=context,
                entity_type=EntityType.ANSWER,
                entity_id=answer_id,
                decision_type=DecisionType.REGEN_A,
                reason=ReasonCode.ANSWER_FACTS_CHANGED,
                details={
                    "question_id": question_id,
                    "previous_checksum": context.previous_checksum,
                    "valid_source_count": source_count_result.valid_source_count,
                    "remaining_checksums": source_count_result.source_checksums,
                    "reason_detail": "Answer source deleted, regenerate with remaining sources"
                }
            )
            decisions.append(answer_decision)

        return decisions

    def _cascade_inactivate_answers(
        self,
        question_id: int,
        context: DetectionContext
    ) -> List[ImpactDecision]:
        """
        Generate INACTIVATE decisions for all answers of an inactivated question.

        When a question is inactivated, all its associated answers must also
        be inactivated (cascading inactivation). This method finds all answers
        for the question and generates INACTIVATE decisions with reason
        ORPHANED_ANSWER.

        Args:
            question_id: ID of the question being inactivated
            context: DetectionContext with change information

        Returns:
            List of ImpactDecision objects (one per answer)

        Example:
            >>> decisions = strategy._cascade_inactivate_answers(42, context)
            >>> for decision in decisions:
            ...     assert decision.decision == DecisionType.INACTIVATE
            ...     assert decision.reason == ReasonCode.ORPHANED_ANSWER
        """
        decisions: List[ImpactDecision] = []

        # Find all answers for this question
        query = """
            SELECT answer_id
            FROM faq_answers
            WHERE question_id = ?
              AND status = 'active'
            ORDER BY answer_id
        """

        rows = self.backend.execute_query(query, (question_id,))
        answer_ids = [row['answer_id'] for row in rows]

        logger.info(
            f"Cascading inactivation from question {question_id} to "
            f"{len(answer_ids)} answers"
        )

        # Generate INACTIVATE decision for each answer
        for answer_id in answer_ids:
            answer_decision = self._create_decision(
                context=context,
                entity_type=EntityType.ANSWER,
                entity_id=answer_id,
                decision_type=DecisionType.INACTIVATE,
                reason=ReasonCode.ORPHANED_ANSWER,
                details={
                    "question_id": question_id,
                    "previous_checksum": context.previous_checksum,
                    "reason_detail": f"Cascaded inactivation from parent question {question_id}"
                }
            )
            decisions.append(answer_decision)

        return decisions

    def _get_question_id_for_answer(self, answer_id: int) -> Optional[int]:
        """
        Get the parent question_id for a given answer.

        Args:
            answer_id: ID of the answer

        Returns:
            question_id if found, None otherwise
        """
        query = """
            SELECT question_id
            FROM faq_answers
            WHERE answer_id = ?
        """

        rows = self.backend.execute_query(query, (answer_id,))

        if not rows:
            logger.warning(f"Answer {answer_id} not found in faq_answers table")
            return None

        return rows[0]['question_id']

    def _create_decision(
        self,
        context: DetectionContext,
        entity_type: EntityType,
        entity_id: int,
        decision_type: DecisionType,
        reason: ReasonCode,
        details: dict
    ) -> ImpactDecision:
        """
        Create an ImpactDecision object with consistent fields.

        Args:
            context: DetectionContext with change information
            entity_type: Type of entity (QUESTION or ANSWER)
            entity_id: ID of the entity
            decision_type: Type of decision (INACTIVATE, REGEN_Q, REGEN_A)
            reason: Reason code for the decision
            details: Additional details dictionary

        Returns:
            ImpactDecision object
        """
        return ImpactDecision(
            impact_id=0,  # Will be assigned by database on insert
            entity_type=entity_type,
            entity_id=entity_id,
            change_id=context.change_id,
            detection_run_id=context.detection_run_id,
            decision=decision_type,
            reason=reason,
            details=details,
            created_at=datetime.now(),
            applied=False,
            applied_at=None,
            applied_by=None,
            application_error=None
        )


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "DeletedContentStrategy",
]
