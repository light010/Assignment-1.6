# NewContentStrategy - Decision Logic Documentation

## Overview

The `NewContentStrategy` is responsible for analyzing newly detected content chunks and generating appropriate impact decisions for the FAQ generation system. This strategy handles the `NEW_CONTENT` change type and determines whether to create new FAQ questions from the content.

**Primary Responsibility**: Detect unique new content and generate `PLAN_CREATE` decisions to trigger FAQ question generation.

**Change Type**: `NEW_CONTENT`

**Output Decisions**:
- `PLAN_CREATE` - Generate new FAQ question/answer from unique content
- `NOOP` - Content already indexed (duplicate checksum detected)

---

## Decision Tree

```
┌─────────────────────────────────┐
│  NEW_CONTENT Change Detected    │
│  (DetectionContext received)    │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Step 1: Validate Context       │
│  - change_type == "NEW_CONTENT" │
│  - content_checksum not null    │
│  - checksum length == 64 chars  │
│  - detection_run_id present     │
│  - change_id > 0                │
└────────────┬────────────────────┘
             │
             ├─── INVALID ──► ValueError
             │                (Validation failed)
             ▼ VALID
┌─────────────────────────────────┐
│  Step 2: Extract Metadata       │
│  - chunk_id from metadata       │
│  - content_checksum             │
│  - file_name                    │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Step 3: Validate Checksum      │
│  (ChecksumValidator)            │
│  - Format: 64-char hex (SHA256) │
│  - Existence: Query DB          │
└────────────┬────────────────────┘
             │
             ├─── INVALID FORMAT ──► ValueError
             │                        (Invalid checksum)
             ▼ VALID FORMAT
┌─────────────────────────────────┐
│  Step 4: Check for Duplicates   │
│  Does checksum exist in active  │
│  chunks?                        │
└────────────┬────────────────────┘
             │
             ├─── YES (Duplicate) ──► NOOP Decision
             │                        (content_already_indexed)
             │                        └─► Log warning
             │                        └─► Return [NOOP]
             │
             ▼ NO (Unique)
┌─────────────────────────────────┐
│  Step 5: Generate PLAN_CREATE   │
│  - Decision: PLAN_CREATE        │
│  - Reason: NEW_CONTENT_ADDED    │
│  - Entity Type: QUESTION        │
│  - Entity ID: None (new)        │
│  - Estimate cost (Q + A gen)    │
│  - Populate details JSON        │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Return [PLAN_CREATE Decision]  │
│  ✓ Ready for FAQ generation     │
└─────────────────────────────────┘
```

---

## Processing Steps

### Step 1: Context Validation

**Purpose**: Ensure the `DetectionContext` has all required fields for NEW_CONTENT analysis.

**Validations**:
1. `change_type` must be `"NEW_CONTENT"` exactly (case-sensitive)
2. `content_checksum` must not be None or empty
3. `content_checksum` must be exactly 64 characters (SHA-256 hex)
4. `detection_run_id` must not be None or empty
5. `change_id` must be > 0

**Error Handling**:
- Raises `ValueError` with descriptive message if any validation fails
- Logs error before raising exception

**Example**:
```python
# Valid context
context = DetectionContext(
    detection_run_id="run_001",
    change_id=123,
    change_type="NEW_CONTENT",
    content_checksum="abc123...",  # 64-char SHA-256 hex
    previous_checksum=None,
    file_name="doc.pdf",
    metadata={"chunk_id": 456}
)

# Invalid: wrong change_type
context = DetectionContext(
    change_type="MODIFIED_CONTENT",  # ❌ NewContentStrategy can't handle this
    ...
)
# Raises: ValueError: NewContentStrategy received non-NEW_CONTENT change type
```

---

### Step 2: Extract Metadata

**Purpose**: Extract relevant metadata from the `DetectionContext` for decision creation.

**Extracted Fields**:
- `chunk_id`: From `context.metadata.get("chunk_id")` (may be None)
- `content_checksum`: From `context.content_checksum`
- `file_name`: From `context.file_name` (defaults to "unknown" if None)

**Additional Metadata** (optional):
- `chunk_index`: Sequence number of chunk in document
- `page_number`: Page number from source document

---

### Step 3: Validate Checksum

**Purpose**: Validate checksum format and check existence in database.

**Validation Process**:
1. Use `ChecksumValidator.validate_checksum(content_checksum)`
2. Check format: 64-character hexadecimal (0-9, a-f)
3. Query database: Check if checksum exists in active `content_chunks`

**Possible Outcomes**:
- **Valid + Not Exists**: ✅ Unique content, proceed to Step 4
- **Valid + Exists**: ⚠️ Duplicate detected, return NOOP
- **Invalid Format**: ❌ Raise ValueError

**Example**:
```python
# Valid SHA-256 hex (64 chars)
valid_checksum = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

# Invalid: wrong length
invalid_checksum = "abc123"  # Only 6 chars
# Raises: ValueError: Invalid content_checksum length

# Invalid: not hexadecimal
invalid_checksum = "z" * 64  # 'z' is not hex
# Raises: ValueError: Invalid format: must be hexadecimal (0-9, a-f)
```

---

### Step 4: Check for Duplicates

**Purpose**: Prevent creating duplicate FAQ questions from the same content.

**Duplicate Detection Logic**:
```sql
SELECT COUNT(*)
FROM content_chunks
WHERE content_checksum = ?
  AND is_active = 1
```

**If Duplicate Detected** (`count > 0`):
- **Decision**: Return `NOOP` decision
- **Reason**: `ALREADY_HANDLED`
- **Details JSON**:
  ```json
  {
    "noop_reason": "content_already_indexed",
    "explanation": "Checksum is valid and exists in active chunks",
    "content_checksum": "abc123...",
    "chunk_id": 456
  }
  ```
- **Log**: Warning message with checksum prefix (first 8 chars)

**If Unique Content** (`count == 0`):
- Proceed to Step 5 (generate PLAN_CREATE)

---

### Step 5: Generate PLAN_CREATE Decision

**Purpose**: Create an `ImpactDecision` record for FAQ generation.

**Decision Fields**:

| Field | Value | Description |
|-------|-------|-------------|
| `impact_id` | Generated ID | Unique identifier for this decision |
| `entity_type` | `EntityType.QUESTION` | Decision targets question creation |
| `entity_id` | `None` | Question doesn't exist yet |
| `change_id` | From context | ID of the content change |
| `detection_run_id` | From context | Detection run identifier |
| `decision` | `DecisionType.PLAN_CREATE` | Create new FAQ |
| `reason` | `ReasonCode.NEW_CONTENT_ADDED` | Why: new content detected |
| `details` | See below | Metadata JSON |
| `created_at` | `datetime.now()` | Timestamp |
| `applied` | `False` | Not yet executed |
| `applied_at` | `None` | N/A |
| `applied_by` | `None` | N/A |
| `application_error` | `None` | N/A |

**Details JSON Schema**:
```json
{
  "chunk_id": 456,
  "content_checksum": "abc123def456...",
  "file_name": "policy_doc.pdf",
  "estimated_cost_usd": 0.08,
  "estimated_question_count": 1,
  "estimated_answer_count": 1,
  "chunk_sequence": 5,
  "page_number": 10
}
```

**Cost Estimation**:
- `estimated_cost_usd` = `cost_per_question_gen` + `cost_per_answer_gen`
- Default: $0.05 (question) + $0.03 (answer) = $0.08
- Configurable via `CostEstimator` constructor

---

## Examples

### Example 1: Normal New Content

**Scenario**: New PDF page added to knowledge base.

**Input**:
```python
context = DetectionContext(
    detection_run_id="run_20251102_001",
    change_id=123,
    change_type="NEW_CONTENT",
    content_checksum="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    previous_checksum=None,
    file_name="employee_handbook.pdf",
    metadata={"chunk_id": 789, "page_number": 15, "chunk_index": 14}
)
```

**Processing**:
1. ✅ Context valid (NEW_CONTENT, checksum present)
2. ✅ Metadata extracted: chunk_id=789, file_name="employee_handbook.pdf"
3. ✅ Checksum valid: format OK, 64-char hex
4. ✅ Checksum unique: not found in active chunks
5. ✅ Generate PLAN_CREATE decision

**Output**:
```python
[
  ImpactDecision(
    impact_id=1001,
    entity_type=EntityType.QUESTION,
    entity_id=None,
    change_id=123,
    detection_run_id="run_20251102_001",
    decision=DecisionType.PLAN_CREATE,
    reason=ReasonCode.NEW_CONTENT_ADDED,
    details={
      "chunk_id": 789,
      "content_checksum": "e3b0c44...",
      "file_name": "employee_handbook.pdf",
      "estimated_cost_usd": 0.08,
      "estimated_question_count": 1,
      "estimated_answer_count": 1,
      "chunk_sequence": 14,
      "page_number": 15
    },
    created_at=datetime(2025, 11, 2, 10, 30, 0),
    applied=False
  )
]
```

---

### Example 2: Duplicate Checksum Detected

**Scenario**: Content re-uploaded or re-processed.

**Input**:
```python
context = DetectionContext(
    detection_run_id="run_20251102_002",
    change_id=124,
    change_type="NEW_CONTENT",
    content_checksum="a1b2c3d4...",  # Already exists in DB
    previous_checksum=None,
    file_name="policy_doc.pdf",
    metadata={"chunk_id": 800}
)
```

**Processing**:
1. ✅ Context valid
2. ✅ Metadata extracted
3. ✅ Checksum valid
4. ⚠️ **Duplicate detected**: checksum exists in active chunks
5. ✅ Generate NOOP decision

**Output**:
```python
[
  ImpactDecision(
    impact_id=1002,
    entity_type=EntityType.CHANGE,
    entity_id=124,  # NOOP targets the change itself
    change_id=124,
    detection_run_id="run_20251102_002",
    decision=DecisionType.NOOP,
    reason=ReasonCode.ALREADY_HANDLED,
    details={
      "noop_reason": "content_already_indexed",
      "explanation": "Checksum is valid and exists in active chunks",
      "content_checksum": "a1b2c3d4...",
      "chunk_id": 800
    },
    created_at=datetime(2025, 11, 2, 10, 35, 0),
    applied=False
  )
]
```

**Log Message**:
```
WARNING: Duplicate checksum detected for change_id=124: a1b2c3d4... already exists in active chunks
```

---

### Example 3: Invalid Checksum Format

**Scenario**: Data quality issue - invalid checksum in change log.

**Input**:
```python
context = DetectionContext(
    detection_run_id="run_20251102_003",
    change_id=125,
    change_type="NEW_CONTENT",
    content_checksum="invalid",  # ❌ Only 7 chars, not 64
    previous_checksum=None,
    file_name="bad_data.pdf",
    metadata={"chunk_id": 900}
)
```

**Processing**:
1. ✅ Context validation passes (length check happens in checksum validator)
2. ✅ Metadata extracted
3. ❌ **Checksum validation fails**: invalid length

**Output**:
```python
ValueError: Invalid content_checksum length: expected 64, got 7 for change_id=125
```

**Log Message**:
```
ERROR: Invalid checksum format for change_id=125: Invalid length: expected 64, got 7
```

---

### Example 4: Minimal Metadata

**Scenario**: Content detected with minimal context (no chunk_id, no file_name).

**Input**:
```python
context = DetectionContext(
    detection_run_id="run_20251102_004",
    change_id=126,
    change_type="NEW_CONTENT",
    content_checksum="abc123def456...",
    previous_checksum=None,
    file_name=None,  # Missing
    metadata={}  # Empty metadata, no chunk_id
)
```

**Processing**:
1. ✅ Context valid
2. ✅ Metadata extracted: chunk_id=None, file_name="unknown" (default)
3. ✅ Checksum valid and unique
4. ✅ Generate PLAN_CREATE decision

**Output**:
```python
[
  ImpactDecision(
    ...
    details={
      "chunk_id": None,
      "content_checksum": "abc123def456...",
      "file_name": "unknown",  # Default value
      "estimated_cost_usd": 0.08,
      "estimated_question_count": 1,
      "estimated_answer_count": 1,
      "chunk_sequence": None,
      "page_number": None
    },
    ...
  )
]
```

---

## Edge Cases

### Edge Case 1: NEW_CONTENT with previous_checksum

**Scenario**: DetectionContext has `previous_checksum` set (should be None for NEW_CONTENT).

**Behavior**:
- ❌ **Prevented by DetectionContext validation**
- DetectionContext `__post_init__` validates this and raises `ValueError`

**Example**:
```python
context = DetectionContext(
    change_type="NEW_CONTENT",
    content_checksum="abc...",
    previous_checksum="def...",  # ❌ Invalid
    ...
)
# Raises: ValueError: NEW_CONTENT should not have previous_checksum
```

**Result**: Strategy never receives this invalid context.

---

### Edge Case 2: Empty detection_run_id

**Scenario**: DetectionContext missing `detection_run_id`.

**Behavior**:
- ❌ Validation fails in Step 1
- Raises `ValueError`

---

### Edge Case 3: Negative or Zero change_id

**Scenario**: Invalid `change_id` value.

**Behavior**:
- ❌ Validation fails in Step 1
- Raises `ValueError: Invalid change_id: 0 (must be > 0)`

---

## Dependencies

### Services Used

1. **ChecksumValidator** (`faq_impact.analysis.services.checksum_validator`)
   - Purpose: Validate checksum format and detect duplicates
   - Methods:
     - `validate_checksum(checksum: str) -> ValidationResult`
   - Returns: `ValidationResult(checksum, is_valid, exists, explanation)`

2. **CostEstimator** (`faq_impact.analysis.services.cost_estimator`)
   - Purpose: Estimate FAQ generation costs
   - Attributes:
     - `cost_per_question_gen`: Cost for question generation (default $0.05)
     - `cost_per_answer_gen`: Cost for answer generation (default $0.03)
   - Calculation: `total_cost = cost_per_question_gen + cost_per_answer_gen`

3. **IBackend** (`faq_update.database.backends.base`)
   - Purpose: Database access for checksum validation
   - Injected into ChecksumValidator

---

## Database Queries

NewContentStrategy doesn't query the database directly - it delegates to ChecksumValidator.

**Checksum Existence Check** (via ChecksumValidator):
```sql
SELECT COUNT(*) as count
FROM content_chunks
WHERE content_checksum = ?
  AND is_active = 1
```

**Result**:
- `count = 0`: Unique content → Generate PLAN_CREATE
- `count > 0`: Duplicate content → Generate NOOP

---

## Testing

### Test Coverage

Comprehensive unit tests in `tests/analysis/strategies/test_new_content_strategy.py`:

**Test Suites**:
1. `TestNewContentStrategyCanHandle` - 5 tests
   - Test `can_handle()` for all change types
   - Verify case-sensitivity

2. `TestNewContentStrategyAnalyzeNormalCases` - 3 tests
   - Normal new unique content
   - New content with minimal metadata
   - Decision details schema validation

3. `TestNewContentStrategyDuplicateDetection` - 1 test
   - Duplicate checksum returns NOOP

4. `TestNewContentStrategyValidation` - 5 tests
   - Invalid change_type raises error
   - Missing checksum raises error
   - Invalid checksum length raises error
   - Invalid checksum format raises error
   - Invalid change_id raises error

5. `TestNewContentStrategyEdgeCases` - 1 test
   - Context validation prevents invalid scenarios

6. `TestNewContentStrategyCostEstimation` - 2 tests
   - Cost includes question + answer generation
   - Default cost estimation works

7. `TestNewContentStrategyIntegration` - 2 tests
   - Initialization with defaults
   - Initialization with custom dependencies

**Total**: 19 tests, 100% pass rate

### Running Tests

```bash
cd /path/to/FAQ_combined
python -m pytest faq_update/faq_impact/tests/analysis/strategies/test_new_content_strategy.py -v
```

**Expected Output**:
```
============================= 19 passed in 0.82s ==============================
```

---

## Integration with Impact Analysis System

### Analyzer Integration

NewContentStrategy is used by the `ImpactAnalyzer`:

```python
from faq_impact.analysis.strategies import NewContentStrategy

# Initialize strategy
strategy = NewContentStrategy(backend)

# Analyzer selects strategy based on change_type
if strategy.can_handle(context.change_type):
    decisions = strategy.analyze(context)
    # Record decisions in faq_impact table
```

### Execution Flow

```
1. Content Detection Phase
   └─► DetectionContext created
   └─► change_type = "NEW_CONTENT"

2. Impact Analysis Phase
   └─► Analyzer receives DetectionContext
   └─► Selects NewContentStrategy (can_handle check)
   └─► Strategy.analyze(context)
   └─► Returns [ImpactDecision]
   └─► Decisions recorded in faq_impact table

3. Apply Plan Phase (Later)
   └─► Read PLAN_CREATE decisions
   └─► Execute FAQ generation
   └─► Create questions and answers
   └─► Update decision.applied = True
```

---

## Configuration

### Cost Configuration

Customize generation costs:

```python
from faq_impact.analysis.services.cost_estimator import CostEstimator

# Custom costs (Azure OpenAI GPT-4 example)
estimator = CostEstimator(
    cost_per_question_gen=0.10,  # $0.10 per question
    cost_per_answer_gen=0.05     # $0.05 per answer
)

strategy = NewContentStrategy(backend, estimator=estimator)
# Now estimated_cost_usd will be 0.15 instead of 0.08
```

### Checksum Validation

Use custom ChecksumValidator:

```python
from faq_impact.analysis.services.checksum_validator import ChecksumValidator

validator = ChecksumValidator(backend)
strategy = NewContentStrategy(backend, validator=validator)
```

---

## Logging

NewContentStrategy logs at multiple levels:

### INFO Level
- Strategy initialization
- Analysis start (with change_id and checksum prefix)
- PLAN_CREATE decision generation
- Analysis completion

### WARNING Level
- Duplicate checksum detected

### ERROR Level
- Context validation failures
- Invalid checksum format

### DEBUG Level
- can_handle() checks
- Context validation passed
- Decision creation details

**Example Log Output**:
```
2025-11-02 10:30:00 | INFO  | Initialized NewContentStrategy with ChecksumValidator and CostEstimator
2025-11-02 10:30:05 | INFO  | Analyzing NEW_CONTENT change: change_id=123, checksum=e3b0c442...
2025-11-02 10:30:05 | DEBUG | Context validation passed for change_id=123
2025-11-02 10:30:06 | INFO  | Generating PLAN_CREATE decision for change_id=123, chunk_id=789
2025-11-02 10:30:06 | INFO  | NewContentStrategy analysis complete: generated 1 decision(s) for change_id=123
```

---

## Performance Considerations

### Database Queries
- **1 query per analyze()** call (checksum existence check)
- Query is indexed on `content_checksum` column
- Fast lookup (O(log n) with B-tree index)

### Memory Usage
- Minimal: Single ImpactDecision object created
- No large data structures retained

### Typical Execution Time
- < 10ms per analyze() call (excluding DB query)
- DB query: ~1-5ms (depends on database performance)
- **Total**: ~5-15ms per new content change

---

## Future Enhancements

### Potential Improvements
1. **Batch Processing**: Support analyzing multiple contexts in single DB query
2. **Token-Based Cost Estimation**: Use actual token counts instead of fixed costs
3. **Intelligent Question Count**: Estimate multiple questions per chunk based on content length
4. **Duplicate Content Analytics**: Track and report duplicate content trends
5. **Priority Scoring**: Assign priority based on content importance (e.g., page 1 > page 100)

### Extensibility Points
- Custom validators (e.g., content quality checks)
- Custom cost estimators (e.g., different LLM pricing)
- Additional metadata fields in details JSON
- Pluggable ID generation strategies

---

## Related Documentation

- [IAnalysisStrategy Interface](../../core/interfaces/analyzer.py)
- [DetectionContext Model](../../core/models/detection_context.py)
- [ImpactDecision Model](../../core/models/impact_decision.py)
- [ChecksumValidator Service](../services/checksum_validator.py)
- [CostEstimator Service](../services/cost_estimator.py)
- [Decision Type Enum](../../core/enums/decision_type.py)
- [Reason Code Enum](../../core/enums/reason_code.py)

---

## Contact

For questions or issues with NewContentStrategy:
- Email: analytics-assist-team@example.com
- GitHub Issues: https://github.com/your-org/faq-impact/issues
- Documentation: https://docs.example.com/faq-impact/strategies

---

**Last Updated**: 2025-11-02
**Version**: 1.0.0
**Author**: Analytics Assist Team
