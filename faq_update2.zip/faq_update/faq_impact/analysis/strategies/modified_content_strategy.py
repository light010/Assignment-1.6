"""
ModifiedContentStrategy - Analysis Strategy for Modified Content Changes

This module implements the analysis strategy for handling MODIFIED_CONTENT change
types in the FAQ impact system. When source content is modified, this strategy
determines which questions and answers should be regenerated based on:
    - Direct source links (questions/answers directly using the modified content)
    - Token overlap (questions with significant lexical similarity)
    - Similarity scores (major vs minor changes)
    - Source counting (sole source vs multi-source decisions)

Key Concepts:
    - Direct Impact: FAQ directly linked to modified content via faq_*_sources
    - Indirect Impact: FAQ with token overlap but no direct link
    - Major Change: similarity_score < 0.6 → REGEN_A
    - Minor Change: similarity_score ≥ 0.6 → EVALUATE
    - Sole Source: Question/answer has exactly 1 valid source → REGEN_Q/REGEN_BOTH
    - Multi-Source: Question/answer has 2+ valid sources → REGEN_A

Decision Logic Flow:
    1. Validate context (must have content_checksum, previous_checksum, similarity_score)
    2. Find directly-linked questions (previous_checksum in faq_question_sources)
    3. Find directly-linked answers (previous_checksum in faq_answer_sources)
    4. Use TokenMatcher to find indirectly affected questions (token overlap)
    5. For each affected question:
        a. Count sources with SourceCounter
        b. If sole source → REGEN_Q (direct impact on question text)
        c. If multi-source → process answers only
    6. For each affected answer:
        a. If similarity < 0.6 (major change) → REGEN_A
        b. If similarity ≥ 0.6 (minor change) → EVALUATE
    7. For token-overlap questions (indirect):
        → REGEN_Q with reason TOKEN_OVERLAP_DETECTED
    8. If no FAQs affected → return empty list (NOOP)

Classes:
    - ModifiedContentStrategy: Concrete implementation of IAnalysisStrategy

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import List, Set, Tuple, Optional, Dict, Any
from datetime import datetime

# Import core interfaces and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_impact.core.interfaces.analyzer import IAnalysisStrategy
from faq_impact.core.models.detection_context import DetectionContext
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.analysis.services.token_matcher import ITokenMatcher
from faq_impact.analysis.services.source_counter import ISourceCounter
from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# ModifiedContentStrategy Implementation
# =============================================================================


class ModifiedContentStrategy(IAnalysisStrategy):
    """
    Analysis strategy for MODIFIED_CONTENT change type.

    This strategy handles scenarios where source content has been modified in
    the knowledge base. It determines which questions and answers should be
    regenerated based on direct source links, token overlap analysis, and
    similarity scores.

    Core Logic:
        1. Find all questions/answers directly linked to previous_checksum
        2. Use TokenMatcher to find questions with token overlap (indirect impact)
        3. For each affected question:
            - Count sources with SourceCounter
            - If sole source → REGEN_Q (question text may need updating)
            - If multi-source → check answers only
        4. For each affected answer:
            - If similarity < 0.6 → REGEN_A (major change, regenerate)
            - If similarity ≥ 0.6 → EVALUATE (minor change, LLM decides)
        5. For token-overlap questions (no direct link):
            - REGEN_Q with reason TOKEN_OVERLAP_DETECTED
        6. Return empty list if no FAQs affected (NOOP)

    Dependencies:
        - backend: Database backend for querying source tables
        - token_matcher: TokenMatcher service for finding token overlap
        - source_counter: SourceCounter service for counting valid sources

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from analysis.services.token_matcher import TokenMatcher
        >>> from analysis.services.source_counter import SourceCounter
        >>>
        >>> backend = BackendFactory.create_backend(config)
        >>> token_matcher = TokenMatcher(backend)
        >>> source_counter = SourceCounter(backend)
        >>> strategy = ModifiedContentStrategy(backend, token_matcher, source_counter)
        >>>
        >>> context = DetectionContext(
        ...     detection_run_id="run_001",
        ...     change_id=123,
        ...     change_type="MODIFIED_CONTENT",
        ...     content_checksum="new_abc123",
        ...     previous_checksum="old_abc123",
        ...     similarity_score=0.75,
        ...     diff_data={"changes": [...]}
        ... )
        >>>
        >>> if strategy.can_handle(context.change_type):
        ...     decisions = strategy.analyze(context)
        ...     for decision in decisions:
        ...         print(f"{decision.decision.value}: {decision.entity_type.value} {decision.entity_id}")

    Design Notes:
        - Read-only strategy: queries database but makes no mutations
        - Uses TokenMatcher for indirect impact detection
        - Uses SourceCounter for sole-source vs multi-source decisions
        - Similarity threshold: 0.6 (below = REGEN_A, above = EVALUATE)
        - Token overlap threshold: configured in TokenMatcher (default 0.3)
        - Handles edge cases: no affected FAQs, orphaned entities
    """

    # Similarity threshold for major vs minor changes
    SIMILARITY_THRESHOLD_MAJOR = 0.6  # < 0.6 = major change (REGEN_A)
                                       # ≥ 0.6 = minor change (EVALUATE)

    def __init__(
        self,
        backend: IBackend,
        token_matcher: ITokenMatcher,
        source_counter: ISourceCounter
    ):
        """
        Initialize ModifiedContentStrategy.

        Args:
            backend: Database backend for executing queries
            token_matcher: TokenMatcher service for finding token overlap
            source_counter: SourceCounter service for counting valid sources

        Example:
            >>> strategy = ModifiedContentStrategy(backend, token_matcher, source_counter)
        """
        self.backend = backend
        self.token_matcher = token_matcher
        self.source_counter = source_counter

        logger.info(
            "Initialized ModifiedContentStrategy with TokenMatcher and SourceCounter"
        )

    def can_handle(self, change_type: str) -> bool:
        """
        Determine if this strategy can handle the given change type.

        This strategy handles MODIFIED_CONTENT change types only.

        Args:
            change_type: String representing the type of change
                Expected value: "MODIFIED_CONTENT"

        Returns:
            bool: True if change_type is "MODIFIED_CONTENT", False otherwise

        Example:
            >>> strategy.can_handle("MODIFIED_CONTENT")
            True
            >>> strategy.can_handle("NEW_CONTENT")
            False
            >>> strategy.can_handle("DELETED_CONTENT")
            False

        Notes:
            - This is a fast check (no I/O operations)
            - Used by IImpactAnalyzer to select the appropriate strategy
        """
        return change_type == "MODIFIED_CONTENT"

    def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        """
        Analyze a MODIFIED_CONTENT change and generate impact decisions.

        This method implements the core modified content analysis logic:
        1. Validate context (must have content_checksum, previous_checksum, similarity_score)
        2. Find all directly affected questions and answers
        3. Find indirectly affected questions via token overlap
        4. Generate appropriate decisions based on:
            - Source counts (sole vs multi)
            - Similarity scores (major vs minor changes)
            - Token overlap (indirect impact)
        5. Handle edge case: no affected FAQs

        Args:
            context: DetectionContext containing:
                - change_type: Must be "MODIFIED_CONTENT"
                - content_checksum: Required (new checksum)
                - previous_checksum: Required (old checksum)
                - similarity_score: Required (0.0-1.0)
                - diff_data: Optional (for token extraction)
                - change_id: ID of the content change
                - detection_run_id: ID of the detection run

        Returns:
            List[ImpactDecision]: List of impact decisions, may include:
                - REGEN_Q decisions for sole-source questions
                - REGEN_Q decisions for token-overlap questions
                - REGEN_A decisions for major changes (similarity < 0.6)
                - EVALUATE decisions for minor changes (similarity ≥ 0.6)
                - Empty list if no FAQs affected (NOOP)

        Raises:
            ValueError: If context is invalid (missing required fields, wrong change_type)
            RuntimeError: If database queries fail

        Example:
            >>> context = DetectionContext(
            ...     detection_run_id="run_001",
            ...     change_id=123,
            ...     change_type="MODIFIED_CONTENT",
            ...     content_checksum="new_abc123",
            ...     previous_checksum="old_abc123",
            ...     similarity_score=0.75
            ... )
            >>> decisions = strategy.analyze(context)
            >>> for decision in decisions:
            ...     print(f"{decision.decision.value}: {decision.reason.value}")

        Implementation Notes:
            - Dynamically counts sources (handles race conditions)
            - Uses token overlap for indirect impact detection
            - Generates one decision per affected entity
            - Returns empty list if no entities affected (NOOP)
            - All decisions reference the same change_id and detection_run_id
        """
        # Format similarity score safely
        similarity_str = f"{context.similarity_score:.3f}" if context.similarity_score is not None else "None"
        prev_checksum_str = context.previous_checksum[:8] + "..." if context.previous_checksum else "None"
        content_checksum_str = context.content_checksum[:8] + "..." if context.content_checksum else "None"

        logger.info(
            f"Analyzing MODIFIED_CONTENT change (change_id={context.change_id}, "
            f"previous_checksum={prev_checksum_str}, "
            f"new_checksum={content_checksum_str}, "
            f"similarity={similarity_str})"
        )

        # Validate context
        self._validate_context(context)

        # Step 1: Find all directly affected questions and answers
        directly_affected_questions = self._find_directly_affected_questions(
            context.previous_checksum
        )
        directly_affected_answers = self._find_directly_affected_answers(
            context.previous_checksum
        )

        logger.info(
            f"Found {len(directly_affected_questions)} directly affected questions, "
            f"{len(directly_affected_answers)} directly affected answers"
        )

        # Step 2: Find indirectly affected questions via token overlap
        indirectly_affected_questions = []
        if context.diff_data:
            try:
                token_overlap_results = self.token_matcher.find_overlapping_questions(
                    diff_data=context.diff_data,
                    checksum=context.previous_checksum
                )

                # Filter out questions already in directly_affected
                directly_affected_set = set(directly_affected_questions)
                indirectly_affected_questions = [
                    result for result in token_overlap_results
                    if result.question_id not in directly_affected_set
                ]

                logger.info(
                    f"Found {len(token_overlap_results)} token overlap matches, "
                    f"{len(indirectly_affected_questions)} indirect (not already direct)"
                )
            except Exception as e:
                logger.warning(
                    f"Token overlap detection failed: {e}. "
                    f"Continuing with direct impact only."
                )
                indirectly_affected_questions = []
        else:
            logger.info("No diff_data provided, skipping token overlap detection")

        # Step 3: Check if no FAQs are affected (edge case)
        if (not directly_affected_questions and
            not directly_affected_answers and
            not indirectly_affected_questions):
            logger.info("No FAQs affected by modified content - returning empty decision list")
            return []

        # Step 4: Generate decisions for affected entities
        decisions: List[ImpactDecision] = []

        # Process directly affected questions
        for question_id in directly_affected_questions:
            question_decisions = self._process_directly_affected_question(
                question_id=question_id,
                context=context
            )
            decisions.extend(question_decisions)

        # Process directly affected answers
        for answer_id in directly_affected_answers:
            answer_decisions = self._process_directly_affected_answer(
                answer_id=answer_id,
                context=context
            )
            decisions.extend(answer_decisions)

        # Process indirectly affected questions (token overlap)
        for overlap_result in indirectly_affected_questions:
            question_decisions = self._process_token_overlap_question(
                overlap_result=overlap_result,
                context=context
            )
            decisions.extend(question_decisions)

        logger.info(
            f"Generated {len(decisions)} impact decisions for modified content "
            f"(change_id={context.change_id})"
        )

        return decisions

    # -------------------------------------------------------------------------
    # Private Helper Methods - Validation
    # -------------------------------------------------------------------------

    def _validate_context(self, context: DetectionContext) -> None:
        """
        Validate that the DetectionContext is appropriate for this strategy.

        Args:
            context: DetectionContext to validate

        Raises:
            ValueError: If context is invalid
        """
        if context.change_type != "MODIFIED_CONTENT":
            raise ValueError(
                f"ModifiedContentStrategy requires change_type='MODIFIED_CONTENT', "
                f"got '{context.change_type}'"
            )

        if context.content_checksum is None:
            raise ValueError(
                "ModifiedContentStrategy requires content_checksum (new checksum)"
            )

        if context.previous_checksum is None:
            raise ValueError(
                "ModifiedContentStrategy requires previous_checksum (old checksum)"
            )

        if context.similarity_score is None:
            raise ValueError(
                "ModifiedContentStrategy requires similarity_score for decision logic"
            )

        logger.debug(f"Context validated for modified content analysis")

    # -------------------------------------------------------------------------
    # Private Helper Methods - Finding Affected Entities
    # -------------------------------------------------------------------------

    def _find_directly_affected_questions(self, previous_checksum: str) -> List[int]:
        """
        Find all questions directly linked to the modified content (previous_checksum).

        Queries faq_question_sources table to find questions that have
        the old checksum as a valid source.

        Args:
            previous_checksum: Checksum of the content before modification

        Returns:
            List of question_id values (integers)

        Example:
            >>> question_ids = strategy._find_directly_affected_questions("old_abc123")
            >>> question_ids
            [42, 58, 91]
        """
        query = """
            SELECT DISTINCT question_id
            FROM faq_question_sources
            WHERE content_checksum = ?
              AND is_valid = 1
            ORDER BY question_id
        """

        rows = self.backend.execute_query(query, (previous_checksum,))
        question_ids = [row['question_id'] for row in rows]

        logger.debug(
            f"Found {len(question_ids)} questions directly linked to modified checksum "
            f"{previous_checksum[:8]}..."
        )

        return question_ids

    def _find_directly_affected_answers(self, previous_checksum: str) -> List[int]:
        """
        Find all answers directly linked to the modified content (previous_checksum).

        Queries faq_answer_sources table to find answers that have
        the old checksum as a valid source.

        Args:
            previous_checksum: Checksum of the content before modification

        Returns:
            List of answer_id values (integers)

        Example:
            >>> answer_ids = strategy._find_directly_affected_answers("old_abc123")
            >>> answer_ids
            [100, 101, 105]
        """
        query = """
            SELECT DISTINCT answer_id
            FROM faq_answer_sources
            WHERE content_checksum = ?
              AND is_valid = 1
            ORDER BY answer_id
        """

        rows = self.backend.execute_query(query, (previous_checksum,))
        answer_ids = [row['answer_id'] for row in rows]

        logger.debug(
            f"Found {len(answer_ids)} answers directly linked to modified checksum "
            f"{previous_checksum[:8]}..."
        )

        return answer_ids

    # -------------------------------------------------------------------------
    # Private Helper Methods - Processing Affected Questions
    # -------------------------------------------------------------------------

    def _process_directly_affected_question(
        self,
        question_id: int,
        context: DetectionContext
    ) -> List[ImpactDecision]:
        """
        Process modified content impact for a directly affected question.

        This method:
        1. Counts remaining valid sources for the question
        2. If sole source → REGEN_Q (question text may need updating)
        3. If multi-source → skip question (answers may still need regen)
        4. Generates appropriate ImpactDecision objects

        Args:
            question_id: ID of the question to process
            context: DetectionContext with change information

        Returns:
            List of ImpactDecision objects (may be empty if multi-source)

        Decision Rules:
            - If sole source → REGEN_Q with reason SOLE_SOURCE_CONTENT_CHANGED
            - If multi-source → no decision for question (answers handled separately)
        """
        decisions: List[ImpactDecision] = []

        # Count valid sources
        source_count_result = self.source_counter.count_sources_for_question(question_id)

        logger.debug(
            f"Question {question_id}: {source_count_result.valid_source_count} sources "
            f"(sole_source={source_count_result.is_sole_source})"
        )

        # If sole source, regenerate question
        if source_count_result.is_sole_source:
            logger.info(
                f"Question {question_id} has sole source (modified) - generating REGEN_Q"
            )

            decision = self._create_decision(
                context=context,
                entity_type=EntityType.QUESTION,
                entity_id=question_id,
                decision_type=DecisionType.REGEN_Q,
                reason=ReasonCode.SOLE_SOURCE_CONTENT_CHANGED,
                details={
                    "previous_checksum": context.previous_checksum,
                    "new_checksum": context.content_checksum,
                    "similarity_score": context.similarity_score,
                    "valid_source_count": source_count_result.valid_source_count,
                    "impact_type": "direct",
                    "reason_detail": "Question's sole source content was modified"
                }
            )
            decisions.append(decision)
        else:
            logger.debug(
                f"Question {question_id} has {source_count_result.valid_source_count} sources - "
                f"skipping question decision (answers may still be affected)"
            )

        return decisions

    def _process_token_overlap_question(
        self,
        overlap_result: "TokenOverlapResult",
        context: DetectionContext
    ) -> List[ImpactDecision]:
        """
        Process token overlap impact for an indirectly affected question.

        This method generates REGEN_Q decisions for questions that have
        significant token overlap with modified content but no direct source link.
        For token overlap, we use SOLE_SOURCE_CONTENT_CHANGED as the reason
        since the overlap suggests indirect content modification impact.

        Args:
            overlap_result: TokenOverlapResult from TokenMatcher
            context: DetectionContext with change information

        Returns:
            List containing single REGEN_Q decision

        Decision Rules:
            - REGEN_Q with reason SOLE_SOURCE_CONTENT_CHANGED
            - Includes overlap metrics in details JSON
        """
        decisions: List[ImpactDecision] = []

        logger.info(
            f"Question {overlap_result.question_id} has token overlap "
            f"({overlap_result.overlap_percentage:.1f}%) - generating REGEN_Q"
        )

        decision = self._create_decision(
            context=context,
            entity_type=EntityType.QUESTION,
            entity_id=overlap_result.question_id,
            decision_type=DecisionType.REGEN_Q,
            reason=ReasonCode.SOLE_SOURCE_CONTENT_CHANGED,  # Use existing REGEN_Q reason
            details={
                "previous_checksum": context.previous_checksum,
                "new_checksum": context.content_checksum,
                "similarity_score": context.similarity_score,
                "impact_type": "indirect",
                "detection_method": "token_overlap",  # Mark as token overlap detection
                "overlap_score": overlap_result.overlap_score,
                "overlap_percentage": overlap_result.overlap_percentage,
                "matched_tokens": list(overlap_result.matched_tokens),
                "total_question_tokens": overlap_result.total_question_tokens,
                "reason_detail": f"Significant token overlap ({overlap_result.overlap_percentage:.1f}%) detected with modified content"
            }
        )
        decisions.append(decision)

        return decisions

    # -------------------------------------------------------------------------
    # Private Helper Methods - Processing Affected Answers
    # -------------------------------------------------------------------------

    def _process_directly_affected_answer(
        self,
        answer_id: int,
        context: DetectionContext
    ) -> List[ImpactDecision]:
        """
        Process modified content impact for a directly affected answer.

        This method:
        1. Checks similarity score to determine change magnitude
        2. If similarity < 0.6 (major change) → REGEN_A
        3. If similarity ≥ 0.6 (minor change) → EVALUATE
        4. Generates appropriate ImpactDecision with metadata

        Args:
            answer_id: ID of the answer to process
            context: DetectionContext with change information

        Returns:
            List containing single decision (REGEN_A or EVALUATE)

        Decision Rules:
            - If similarity < 0.6 → REGEN_A with reason ANSWER_FACTS_CHANGED
            - If similarity ≥ 0.6 → EVALUATE with reason SIMILARITY_AMBIGUOUS
        """
        decisions: List[ImpactDecision] = []

        # Get answer's parent question_id
        question_id = self._get_question_id_for_answer(answer_id)

        if question_id is None:
            logger.warning(f"Answer {answer_id} has no parent question - skipping")
            return decisions

        # Determine decision based on similarity score
        # For all directly affected answers, regenerate them
        # Similarity score determines priority/urgency in details
        is_major_change = context.similarity_score < self.SIMILARITY_THRESHOLD_MAJOR

        if is_major_change:
            # Major change → REGEN_A (high priority)
            logger.info(
                f"Answer {answer_id} affected by major change "
                f"(similarity={context.similarity_score:.3f}) - generating REGEN_A (high priority)"
            )

            decision = self._create_decision(
                context=context,
                entity_type=EntityType.ANSWER,
                entity_id=answer_id,
                decision_type=DecisionType.REGEN_A,
                reason=ReasonCode.ANSWER_FACTS_CHANGED,
                details={
                    "question_id": question_id,
                    "previous_checksum": context.previous_checksum,
                    "new_checksum": context.content_checksum,
                    "similarity_score": context.similarity_score,
                    "similarity_threshold": self.SIMILARITY_THRESHOLD_MAJOR,
                    "change_magnitude": "major",
                    "priority": "high",
                    "impact_type": "direct",
                    "reason_detail": f"Major content change detected (similarity={context.similarity_score:.3f})"
                }
            )
            decisions.append(decision)

        else:
            # Minor change → REGEN_A (standard priority)
            # Note: We still regenerate, but with lower priority
            # The execution phase can decide whether to actually regenerate
            logger.info(
                f"Answer {answer_id} affected by minor change "
                f"(similarity={context.similarity_score:.3f}) - generating REGEN_A (standard priority)"
            )

            decision = self._create_decision(
                context=context,
                entity_type=EntityType.ANSWER,
                entity_id=answer_id,
                decision_type=DecisionType.REGEN_A,
                reason=ReasonCode.MULTI_SOURCE_ONE_MODIFIED,  # Use multi-source reason for minor changes
                details={
                    "question_id": question_id,
                    "previous_checksum": context.previous_checksum,
                    "new_checksum": context.content_checksum,
                    "similarity_score": context.similarity_score,
                    "similarity_threshold": self.SIMILARITY_THRESHOLD_MAJOR,
                    "change_magnitude": "minor",
                    "priority": "standard",
                    "impact_type": "direct",
                    "reason_detail": f"Minor content change detected (similarity={context.similarity_score:.3f}), regenerate answer"
                }
            )
            decisions.append(decision)

        return decisions

    # -------------------------------------------------------------------------
    # Private Helper Methods - Utilities
    # -------------------------------------------------------------------------

    def _get_question_id_for_answer(self, answer_id: int) -> Optional[int]:
        """
        Get the parent question_id for a given answer.

        Args:
            answer_id: ID of the answer

        Returns:
            question_id if found, None otherwise
        """
        query = """
            SELECT question_id
            FROM faq_answers
            WHERE answer_id = ?
        """

        rows = self.backend.execute_query(query, (answer_id,))

        if not rows:
            logger.warning(f"Answer {answer_id} not found in faq_answers table")
            return None

        return rows[0]['question_id']

    def _create_decision(
        self,
        context: DetectionContext,
        entity_type: EntityType,
        entity_id: int,
        decision_type: DecisionType,
        reason: ReasonCode,
        details: dict
    ) -> ImpactDecision:
        """
        Create an ImpactDecision object with consistent fields.

        Args:
            context: DetectionContext with change information
            entity_type: Type of entity (QUESTION or ANSWER)
            entity_id: ID of the entity
            decision_type: Type of decision (REGEN_Q, REGEN_A, EVALUATE)
            reason: Reason code for the decision
            details: Additional details dictionary

        Returns:
            ImpactDecision object
        """
        return ImpactDecision(
            impact_id=0,  # Will be assigned by database on insert
            entity_type=entity_type,
            entity_id=entity_id,
            change_id=context.change_id,
            detection_run_id=context.detection_run_id,
            decision=decision_type,
            reason=reason,
            details=details,
            created_at=datetime.now(),
            applied=False,
            applied_at=None,
            applied_by=None,
            application_error=None
        )


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "ModifiedContentStrategy",
]
