"""
NewContentStrategy - Analysis Strategy for New Content Changes

This module implements the NewContentStrategy class for analyzing NEW_CONTENT
change types in the FAQ impact analysis system. This strategy handles the
creation of PLAN_CREATE decisions when new content is detected.

Classes:
    - NewContentStrategy: Concrete implementation of IAnalysisStrategy for new content

Author: Analytics Assist Team
Date: 2025-11-02
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid

# Import core interfaces and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger
from faq_impact.core.interfaces.analyzer import IAnalysisStrategy
from faq_impact.core.models.detection_context import DetectionContext
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.analysis.services.checksum_validator import ChecksumValidator, ValidationResult
from faq_impact.analysis.services.cost_estimator import CostEstimator

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# NewContentStrategy Implementation
# =============================================================================


class NewContentStrategy(IAnalysisStrategy):
    """
    Analysis strategy for handling NEW_CONTENT change types.

    NewContentStrategy is responsible for analyzing newly detected content chunks
    and generating PLAN_CREATE decisions to create FAQ questions from that content.

    **Responsibilities**:
        - Detect when a content change is truly new content
        - Validate content checksums and detect duplicates
        - Generate PLAN_CREATE decisions for new, unique content
        - Handle edge cases (duplicate checksums, invalid context, etc.)
        - Provide cost estimation for FAQ generation

    **Decision Logic**:
        1. Validate context is NEW_CONTENT type
        2. Validate content_checksum format and existence
        3. Check for duplicate checksums (content already indexed)
        4. If duplicate → return NOOP (content already processed)
        5. If unique → return PLAN_CREATE (generate new FAQ)
        6. Handle edge cases with appropriate warnings/errors

    **Output Decisions**:
        - PLAN_CREATE: New, unique content detected → generate FAQ
        - NOOP: Duplicate content detected → no action needed
        - EVALUATE: Edge case or ambiguous scenario → manual review

    Attributes:
        backend: Database backend for querying data
        validator: ChecksumValidator for validating content checksums
        estimator: CostEstimator for estimating generation costs

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> # Initialize strategy
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> strategy = NewContentStrategy(backend)
        >>>
        >>> # Create detection context for new content
        >>> context = DetectionContext(
        ...     detection_run_id="run_001",
        ...     change_id=123,
        ...     change_type="NEW_CONTENT",
        ...     content_checksum="abc123def456...",
        ...     previous_checksum=None,
        ...     file_name="policy_doc.pdf",
        ...     metadata={"chunk_id": 456, "page_number": 10}
        ... )
        >>>
        >>> # Check if strategy can handle this context
        >>> if strategy.can_handle(context.change_type):
        ...     decisions = strategy.analyze(context)
        ...     for decision in decisions:
        ...         print(f"{decision.decision.value}: {decision.reason.value}")
        PLAN_CREATE: NEW_CONTENT_ADDED

    Design Notes:
        - Stateless: Each analyze() call is independent
        - Idempotent: Same context always produces same decisions
        - Defensive: Validates all inputs thoroughly
        - Auditable: Logs all decisions and edge cases
        - Cost-aware: Includes cost estimation in details
    """

    def __init__(
        self,
        backend: IBackend,
        validator: Optional[ChecksumValidator] = None,
        estimator: Optional[CostEstimator] = None
    ):
        """
        Initialize NewContentStrategy with required dependencies.

        Args:
            backend: Database backend for executing queries
            validator: Optional ChecksumValidator instance (creates default if None)
            estimator: Optional CostEstimator instance (creates default if None)

        Example:
            >>> backend = BackendFactory.create_backend(config)
            >>> strategy = NewContentStrategy(backend)
            >>>
            >>> # Or with custom validator/estimator
            >>> validator = ChecksumValidator(backend)
            >>> estimator = CostEstimator(cost_per_question_gen=0.10)
            >>> strategy = NewContentStrategy(backend, validator, estimator)
        """
        self.backend = backend
        self.validator = validator or ChecksumValidator(backend)
        self.estimator = estimator or CostEstimator()

        logger.info("Initialized NewContentStrategy with ChecksumValidator and CostEstimator")

    def can_handle(self, change_type: str) -> bool:
        """
        Determine if this strategy can handle the given change type.

        NewContentStrategy handles only "NEW_CONTENT" change types. Other change
        types (MODIFIED_CONTENT, DELETED_CONTENT) are handled by other strategies.

        Args:
            change_type: String representing the type of change
                Expected values: "NEW_CONTENT", "MODIFIED_CONTENT", "DELETED_CONTENT"

        Returns:
            bool: True if change_type == "NEW_CONTENT", False otherwise

        Example:
            >>> strategy = NewContentStrategy(backend)
            >>> strategy.can_handle("NEW_CONTENT")
            True
            >>> strategy.can_handle("MODIFIED_CONTENT")
            False
            >>> strategy.can_handle("DELETED_CONTENT")
            False

        Notes:
            - This is a fast, simple check (no I/O operations)
            - Case-sensitive comparison: must be exact "NEW_CONTENT"
            - Used by analyzer to select appropriate strategy
        """
        can_handle = (change_type == "NEW_CONTENT")
        logger.debug(f"can_handle('{change_type}'): {can_handle}")
        return can_handle

    def analyze(self, context: DetectionContext) -> List[ImpactDecision]:
        """
        Analyze a NEW_CONTENT change and generate impact decisions.

        This is the main entry point for NewContentStrategy. It processes a
        DetectionContext for new content and returns a list of ImpactDecision
        objects representing planned actions.

        **Processing Steps**:
            1. Validate context completeness and type
            2. Validate content checksum format
            3. Check for duplicate checksums (already indexed)
            4. Handle edge cases (e.g., previous_checksum present)
            5. Generate PLAN_CREATE decision with metadata
            6. Estimate generation cost
            7. Return decision list

        Args:
            context: DetectionContext containing new content information
                Required fields:
                - detection_run_id: Detection run identifier
                - change_id: Content change ID
                - change_type: Must be "NEW_CONTENT"
                - content_checksum: New content checksum (SHA-256 hex)
                - file_name: Source file name (optional)
                - metadata: Dict with chunk_id and other metadata

        Returns:
            List[ImpactDecision]: List of impact decisions (typically 1 decision)
                Possible outcomes:
                - [PLAN_CREATE]: New unique content → generate FAQ
                - [NOOP]: Duplicate checksum → content already indexed
                - []: Empty list if validation fails critically

        Raises:
            ValueError: If context validation fails (invalid type, missing fields)
            RuntimeError: If database query fails

        Example:
            >>> context = DetectionContext(
            ...     detection_run_id="run_001",
            ...     change_id=123,
            ...     change_type="NEW_CONTENT",
            ...     content_checksum="abc123...",
            ...     previous_checksum=None,
            ...     file_name="doc.pdf",
            ...     metadata={"chunk_id": 456}
            ... )
            >>> decisions = strategy.analyze(context)
            >>> assert len(decisions) == 1
            >>> assert decisions[0].decision == DecisionType.PLAN_CREATE

        Implementation Notes:
            - Logs all decision paths for debugging
            - Handles edge cases gracefully with warnings
            - Includes cost estimation in decision details
            - Validates checksum before creating decision
        """
        logger.info(
            f"Analyzing NEW_CONTENT change: change_id={context.change_id}, "
            f"checksum={context.content_checksum[:8] if context.content_checksum else 'None'}..."
        )

        # Step 1: Validate context
        try:
            self._validate_context(context)
        except ValueError as e:
            logger.error(f"Context validation failed: {e}")
            raise

        # Step 2: Extract metadata
        chunk_id = context.get_chunk_id()
        content_checksum = context.content_checksum
        file_name = context.file_name or "unknown"

        # Step 3: Validate checksum format and check for duplicates
        validation_result = self.validator.validate_checksum(content_checksum)

        if not validation_result.is_valid:
            # Invalid checksum format
            logger.error(
                f"Invalid checksum format for change_id={context.change_id}: "
                f"{validation_result.explanation}"
            )
            raise ValueError(
                f"Invalid content_checksum: {validation_result.explanation}"
            )

        # Step 4: Check for duplicate checksums
        if validation_result.exists:
            # Checksum already exists in active chunks
            logger.warning(
                f"Duplicate checksum detected for change_id={context.change_id}: "
                f"{content_checksum[:8]}... already exists in active chunks"
            )
            return self._create_noop_decision(
                context=context,
                reason="content_already_indexed",
                explanation=validation_result.explanation
            )

        # Step 5: Generate PLAN_CREATE decision
        # Note: Edge case of NEW_CONTENT with previous_checksum is prevented by
        # DetectionContext validation, so we don't need to handle it here
        logger.info(
            f"Generating PLAN_CREATE decision for change_id={context.change_id}, "
            f"chunk_id={chunk_id}, checksum={content_checksum[:8]}..."
        )

        decision = self._create_plan_create_decision(
            context=context,
            chunk_id=chunk_id,
            content_checksum=content_checksum,
            file_name=file_name
        )

        logger.info(
            f"NewContentStrategy analysis complete: generated {len([decision])} decision(s) "
            f"for change_id={context.change_id}"
        )

        return [decision]

    # -------------------------------------------------------------------------
    # Private Helper Methods
    # -------------------------------------------------------------------------

    def _validate_context(self, context: DetectionContext) -> None:
        """
        Validate that DetectionContext has all required fields for NEW_CONTENT.

        Validates:
        - change_type is "NEW_CONTENT"
        - content_checksum is not None/empty
        - checksum has valid format (64-char hex)
        - detection_run_id is not None/empty
        - change_id is valid (> 0)

        Args:
            context: DetectionContext to validate

        Raises:
            ValueError: If any validation check fails

        Example:
            >>> context = DetectionContext(...)
            >>> strategy._validate_context(context)  # No exception = valid
        """
        # Check change_type
        if not context.is_new_content():
            raise ValueError(
                f"NewContentStrategy received non-NEW_CONTENT change type: "
                f"{context.change_type}. Use can_handle() to check compatibility."
            )

        # Check content_checksum
        if not context.content_checksum:
            raise ValueError(
                f"NEW_CONTENT context missing content_checksum for change_id={context.change_id}"
            )

        # Check checksum format (basic length check)
        if len(context.content_checksum) != 64:
            raise ValueError(
                f"Invalid content_checksum length: expected 64 chars (SHA-256), "
                f"got {len(context.content_checksum)} for change_id={context.change_id}"
            )

        # Check detection_run_id
        if not context.detection_run_id:
            raise ValueError(
                f"DetectionContext missing detection_run_id for change_id={context.change_id}"
            )

        # Check change_id
        if context.change_id <= 0:
            raise ValueError(
                f"Invalid change_id: {context.change_id} (must be > 0)"
            )

        logger.debug(f"Context validation passed for change_id={context.change_id}")

    def _create_plan_create_decision(
        self,
        context: DetectionContext,
        chunk_id: Optional[int],
        content_checksum: str,
        file_name: str
    ) -> ImpactDecision:
        """
        Create a PLAN_CREATE decision for new content.

        Generates an ImpactDecision with:
        - decision = PLAN_CREATE
        - reason = NEW_CONTENT_ADDED
        - entity_type = QUESTION
        - entity_id = None (question doesn't exist yet)
        - details = metadata including checksum, file_name, chunk_id, cost estimate

        Args:
            context: DetectionContext with change information
            chunk_id: Chunk ID from metadata (may be None)
            content_checksum: Validated content checksum
            file_name: Source file name

        Returns:
            ImpactDecision ready to be recorded

        Example:
            >>> decision = strategy._create_plan_create_decision(
            ...     context=context,
            ...     chunk_id=456,
            ...     content_checksum="abc123...",
            ...     file_name="doc.pdf"
            ... )
            >>> assert decision.decision == DecisionType.PLAN_CREATE
            >>> assert decision.entity_id is None
        """
        # Estimate generation cost
        # PLAN_CREATE = question + answer generation
        estimated_cost = self.estimator.cost_per_question_gen + self.estimator.cost_per_answer_gen

        # Build details JSON with comprehensive metadata
        details: Dict[str, Any] = {
            "chunk_id": chunk_id,
            "content_checksum": content_checksum,
            "file_name": file_name,
            "estimated_cost_usd": round(estimated_cost, 4),
            "estimated_question_count": 1,  # Typically 1 question per chunk
            "estimated_answer_count": 1,
            "chunk_sequence": context.metadata.get("chunk_index"),
            "page_number": context.metadata.get("page_number")
        }

        # Generate unique impact_id
        impact_id = self._generate_impact_id()

        # Create ImpactDecision
        decision = ImpactDecision(
            impact_id=impact_id,
            entity_type=EntityType.QUESTION,
            entity_id=None,  # Question doesn't exist yet (will be created)
            change_id=context.change_id,
            detection_run_id=context.detection_run_id,
            decision=DecisionType.PLAN_CREATE,
            reason=ReasonCode.NEW_CONTENT_ADDED,
            details=details,
            created_at=datetime.now(),
            applied=False,
            applied_at=None,
            applied_by=None,
            application_error=None
        )

        logger.debug(
            f"Created PLAN_CREATE decision: impact_id={impact_id}, "
            f"change_id={context.change_id}, estimated_cost=${estimated_cost:.4f}"
        )

        return decision

    def _create_noop_decision(
        self,
        context: DetectionContext,
        reason: str,
        explanation: str
    ) -> List[ImpactDecision]:
        """
        Create a NOOP decision for duplicate or already-handled content.

        Args:
            context: DetectionContext with change information
            reason: Short reason code for NOOP
            explanation: Detailed explanation

        Returns:
            List containing single NOOP decision

        Example:
            >>> decisions = strategy._create_noop_decision(
            ...     context=context,
            ...     reason="content_already_indexed",
            ...     explanation="Checksum exists in active chunks"
            ... )
            >>> assert decisions[0].decision == DecisionType.NOOP
        """
        # Build details JSON
        details: Dict[str, Any] = {
            "noop_reason": reason,
            "explanation": explanation,
            "content_checksum": context.content_checksum,
            "chunk_id": context.get_chunk_id()
        }

        # Generate unique impact_id
        impact_id = self._generate_impact_id()

        # Create NOOP decision
        decision = ImpactDecision(
            impact_id=impact_id,
            entity_type=EntityType.CHANGE,
            entity_id=context.change_id,  # NOOP targets the change itself
            change_id=context.change_id,
            detection_run_id=context.detection_run_id,
            decision=DecisionType.NOOP,
            reason=ReasonCode.ALREADY_HANDLED,
            details=details,
            created_at=datetime.now(),
            applied=False,
            applied_at=None,
            applied_by=None,
            application_error=None
        )

        logger.debug(
            f"Created NOOP decision: impact_id={impact_id}, "
            f"change_id={context.change_id}, reason={reason}"
        )

        return [decision]

    def _generate_impact_id(self) -> int:
        """
        Generate a unique impact ID for new decisions.

        In production, this would query the database for the next available ID
        or use a sequence. For now, we'll use a simple timestamp-based approach.

        Returns:
            Unique integer impact ID

        Note:
            This is a placeholder implementation. In production, replace with
            proper ID generation (database sequence, UUID, etc.)
        """
        # Placeholder: Use timestamp-based ID
        # In production, replace with proper ID generation
        import time
        return int(time.time() * 1000000) % 2147483647  # Keep within INT range


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "NewContentStrategy",
]
