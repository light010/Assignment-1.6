"""
SourceCounter Service - Dynamic Source Counting for Orphan Detection

This module provides the SourceCounter service class for dynamically counting valid
sources for questions and answers. Used by DeletedContentStrategy to determine if
entities should be inactivated (sole source/orphaned) or remain active (multi-source).

Classes:
    - ISourceCounter: Abstract interface for source counting
    - SourceCounter: Concrete implementation with optional caching

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from typing import Dict, Tuple, Optional
from datetime import datetime, timedelta
import time

# Import backend and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger
from faq_impact.core.models.detection_context import SourceCountResult
from faq_impact.core.enums.entity_type import EntityType

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Abstract Interface
# =============================================================================


class ISourceCounter(ABC):
    """
    Abstract interface for source counting service.

    Defines the contract for counting valid sources for questions and answers.
    Implementations may provide caching, batch operations, or other optimizations.

    Methods:
        count_sources_for_question: Count valid sources for a specific question
        count_sources_for_answer: Count valid sources for a specific answer
        clear_cache: Clear any cached results (optional, for cached implementations)

    Example:
        >>> counter = SourceCounter(backend)
        >>> result = counter.count_sources_for_question(question_id=123)
        >>> print(f"Question has {result.valid_source_count} sources")
    """

    @abstractmethod
    def count_sources_for_question(self, question_id: int) -> SourceCountResult:
        """
        Count valid sources for a specific question.

        Args:
            question_id: ID of the question to analyze

        Returns:
            SourceCountResult with count and source details

        Raises:
            QueryError: If database query fails
        """
        pass

    @abstractmethod
    def count_sources_for_answer(self, answer_id: int) -> SourceCountResult:
        """
        Count valid sources for a specific answer.

        Args:
            answer_id: ID of the answer to analyze

        Returns:
            SourceCountResult with count and source details

        Raises:
            QueryError: If database query fails
        """
        pass

    @abstractmethod
    def clear_cache(self) -> None:
        """
        Clear any cached results.

        Should be called between analysis runs to ensure fresh data.
        For non-cached implementations, this is a no-op.
        """
        pass


# =============================================================================
# Concrete Implementation
# =============================================================================


class SourceCounter(ISourceCounter):
    """
    Concrete implementation of source counting service with optional caching.

    Queries faq_question_sources and faq_answer_sources tables to count active
    sources (is_valid=1) for questions and answers. Supports optional in-memory
    caching to avoid repeated database queries during single analysis run.

    Attributes:
        backend: Database backend for executing queries
        enable_cache: Whether to cache results (default True)
        cache_ttl_seconds: Time-to-live for cache entries (default 300 = 5 minutes)
        _cache: Internal cache storage {(entity_type, entity_id): (result, timestamp)}
        _cache_hits: Counter for cache hits (metrics)
        _cache_misses: Counter for cache misses (metrics)

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> counter = SourceCounter(backend, enable_cache=True, cache_ttl_seconds=300)
        >>>
        >>> # Count sources for question
        >>> result = counter.count_sources_for_question(123)
        >>> print(f"Question 123: {result.valid_source_count} sources")
        >>> print(f"Is sole source: {result.is_sole_source}")
        >>> print(f"Is orphaned: {result.is_orphaned()}")
        >>>
        >>> # Second call uses cache
        >>> result2 = counter.count_sources_for_question(123)  # Cache hit!
        >>>
        >>> # Clear cache between analysis runs
        >>> counter.clear_cache()
        >>> print(f"Cache stats: {counter.get_cache_stats()}")

    Cache Design:
        - Cache key: (entity_type, entity_id) tuple
        - Cache value: (SourceCountResult, timestamp) tuple
        - TTL-based expiration (configurable, default 5 minutes)
        - Thread-safe for single-threaded analysis runs
        - Cleared between detection runs to ensure fresh data

    Query Design:
        - Questions: SELECT from faq_question_sources WHERE question_id=? AND is_valid=1
        - Answers: SELECT from faq_answer_sources WHERE answer_id=? AND is_valid=1
        - Returns checksums, count, and sole_source flag
    """

    def __init__(
        self,
        backend: IBackend,
        enable_cache: bool = True,
        cache_ttl_seconds: int = 300
    ):
        """
        Initialize SourceCounter service.

        Args:
            backend: Database backend for queries
            enable_cache: Whether to enable caching (default True)
            cache_ttl_seconds: Cache TTL in seconds (default 300 = 5 minutes)
        """
        self.backend = backend
        self.enable_cache = enable_cache
        self.cache_ttl_seconds = cache_ttl_seconds

        # Cache storage: {(entity_type, entity_id): (result, timestamp)}
        self._cache: Dict[Tuple[str, int], Tuple[SourceCountResult, float]] = {}

        # Cache metrics
        self._cache_hits = 0
        self._cache_misses = 0

        logger.info(
            f"Initialized SourceCounter (cache={'enabled' if enable_cache else 'disabled'}, "
            f"TTL={cache_ttl_seconds}s)"
        )

    def count_sources_for_question(self, question_id: int) -> SourceCountResult:
        """
        Count valid sources for a specific question.

        Args:
            question_id: ID of the question to analyze

        Returns:
            SourceCountResult with:
                - question_id: The question ID
                - answer_id: Associated answer ID (from faq_questions table)
                - valid_source_count: Number of valid sources
                - is_sole_source: True if count == 1
                - source_checksums: List of valid source checksums

        Raises:
            QueryError: If database query fails

        Example:
            >>> result = counter.count_sources_for_question(123)
            >>> if result.is_orphaned():
            ...     print("Question has no valid sources - should be inactivated")
            >>> elif result.is_sole_source:
            ...     print("Question has one source - check if source was deleted")
            >>> else:
            ...     print(f"Question has {result.valid_source_count} sources - multi-source")
        """
        cache_key = (EntityType.QUESTION.value, question_id)

        # Check cache first
        if self.enable_cache:
            cached_result = self._get_from_cache(cache_key)
            if cached_result is not None:
                self._cache_hits += 1
                logger.debug(f"Cache HIT for question {question_id}")
                return cached_result
            self._cache_misses += 1
            logger.debug(f"Cache MISS for question {question_id}")

        # Query database
        logger.debug(f"Querying sources for question {question_id}")

        # First, get the answer_id for this question
        question_query = """
            SELECT answer_id
            FROM faq_questions
            WHERE question_id = ?
        """
        question_rows = self.backend.execute_query(question_query, (question_id,))

        if not question_rows:
            logger.warning(f"Question {question_id} not found in database")
            # Return empty result
            result = SourceCountResult(
                question_id=question_id,
                answer_id=None,
                valid_source_count=0,
                is_sole_source=False,
                source_checksums=[]
            )
            self._put_in_cache(cache_key, result)
            return result

        answer_id = question_rows[0]['answer_id']

        # Query valid sources for this question
        source_query = """
            SELECT content_checksum
            FROM faq_question_sources
            WHERE question_id = ?
              AND is_valid = 1
            ORDER BY created_at DESC
        """

        source_rows = self.backend.execute_query(source_query, (question_id,))

        # Process results
        source_checksums = [row['content_checksum'] for row in source_rows]
        valid_source_count = len(source_checksums)
        is_sole_source = (valid_source_count == 1)

        # Create result
        result = SourceCountResult(
            question_id=question_id,
            answer_id=answer_id,
            valid_source_count=valid_source_count,
            is_sole_source=is_sole_source,
            source_checksums=source_checksums
        )

        # Cache result
        if self.enable_cache:
            self._put_in_cache(cache_key, result)

        logger.debug(
            f"Question {question_id}: {valid_source_count} sources "
            f"(sole_source={is_sole_source})"
        )

        return result

    def count_sources_for_answer(self, answer_id: int) -> SourceCountResult:
        """
        Count valid sources for a specific answer.

        Args:
            answer_id: ID of the answer to analyze

        Returns:
            SourceCountResult with:
                - question_id: None (not applicable for answer-only query)
                - answer_id: The answer ID
                - valid_source_count: Number of valid sources
                - is_sole_source: True if count == 1
                - source_checksums: List of valid source checksums

        Raises:
            QueryError: If database query fails

        Example:
            >>> result = counter.count_sources_for_answer(456)
            >>> if result.is_orphaned():
            ...     print("Answer has no valid sources - should be inactivated")
            >>> elif result.is_sole_source:
            ...     print("Answer has one source - check if source was deleted")
            >>> else:
            ...     print(f"Answer has {result.valid_source_count} sources - multi-source")
        """
        cache_key = (EntityType.ANSWER.value, answer_id)

        # Check cache first
        if self.enable_cache:
            cached_result = self._get_from_cache(cache_key)
            if cached_result is not None:
                self._cache_hits += 1
                logger.debug(f"Cache HIT for answer {answer_id}")
                return cached_result
            self._cache_misses += 1
            logger.debug(f"Cache MISS for answer {answer_id}")

        # Query database
        logger.debug(f"Querying sources for answer {answer_id}")

        source_query = """
            SELECT content_checksum
            FROM faq_answer_sources
            WHERE answer_id = ?
              AND is_valid = 1
            ORDER BY created_at DESC
        """

        source_rows = self.backend.execute_query(source_query, (answer_id,))

        # Process results
        source_checksums = [row['content_checksum'] for row in source_rows]
        valid_source_count = len(source_checksums)
        is_sole_source = (valid_source_count == 1)

        # Create result
        result = SourceCountResult(
            question_id=None,  # Not applicable for answer-only query
            answer_id=answer_id,
            valid_source_count=valid_source_count,
            is_sole_source=is_sole_source,
            source_checksums=source_checksums
        )

        # Cache result
        if self.enable_cache:
            self._put_in_cache(cache_key, result)

        logger.debug(
            f"Answer {answer_id}: {valid_source_count} sources "
            f"(sole_source={is_sole_source})"
        )

        return result

    def clear_cache(self) -> None:
        """
        Clear all cached results.

        Should be called between analysis runs to ensure fresh data.
        Also resets cache metrics.

        Example:
            >>> counter.clear_cache()
            >>> print("Cache cleared - next queries will hit database")
        """
        if self.enable_cache:
            cache_size = len(self._cache)
            self._cache.clear()
            logger.info(
                f"Cache cleared: {cache_size} entries removed "
                f"(hits={self._cache_hits}, misses={self._cache_misses})"
            )
            self._cache_hits = 0
            self._cache_misses = 0
        else:
            logger.debug("Cache not enabled - clear_cache is no-op")

    def get_cache_stats(self) -> Dict[str, int]:
        """
        Get cache performance statistics.

        Returns:
            Dictionary with cache metrics:
                - entries: Number of cached entries
                - hits: Number of cache hits
                - misses: Number of cache misses
                - hit_rate: Cache hit rate (0.0-1.0)

        Example:
            >>> stats = counter.get_cache_stats()
            >>> print(f"Cache hit rate: {stats['hit_rate']:.2%}")
        """
        total_requests = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total_requests if total_requests > 0 else 0.0

        return {
            "entries": len(self._cache),
            "hits": self._cache_hits,
            "misses": self._cache_misses,
            "hit_rate": hit_rate
        }

    # -------------------------------------------------------------------------
    # Private Cache Methods
    # -------------------------------------------------------------------------

    def _get_from_cache(self, key: Tuple[str, int]) -> Optional[SourceCountResult]:
        """
        Retrieve result from cache if not expired.

        Args:
            key: Cache key (entity_type, entity_id)

        Returns:
            Cached SourceCountResult if found and not expired, None otherwise
        """
        if key not in self._cache:
            return None

        result, timestamp = self._cache[key]

        # Check if expired
        age_seconds = time.time() - timestamp
        if age_seconds > self.cache_ttl_seconds:
            # Expired - remove from cache
            del self._cache[key]
            logger.debug(f"Cache entry expired for {key} (age={age_seconds:.1f}s)")
            return None

        return result

    def _put_in_cache(self, key: Tuple[str, int], result: SourceCountResult) -> None:
        """
        Store result in cache with current timestamp.

        Args:
            key: Cache key (entity_type, entity_id)
            result: SourceCountResult to cache
        """
        self._cache[key] = (result, time.time())
        logger.debug(f"Cached result for {key} (TTL={self.cache_ttl_seconds}s)")


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "ISourceCounter",
    "SourceCounter",
]
