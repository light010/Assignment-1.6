"""
CostEstimator Service - Cost Estimation for Impact Decisions

This module provides the CostEstimator service class for estimating regeneration costs
for impact decisions. Used to forecast LLM API costs before applying plans, enabling
cost-aware decision making and budget planning.

Classes:
    - ICostEstimator: Abstract interface for cost estimation
    - CostEstimator: Concrete implementation with configurable pricing
    - CostEstimate: Detailed cost breakdown result

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Optional
from decimal import Decimal

# Import models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.utility.logging import get_logger
from faq_impact.core.models.impact_decision import ImpactDecision, ImpactSummary
from faq_impact.core.enums.decision_type import DecisionType

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================


@dataclass(frozen=True)
class CostEstimate:
    """
    Detailed cost estimate for impact decisions.

    Attributes:
        total_cost_usd: Total estimated cost in USD
        question_generation_cost: Cost for question generation operations
        answer_generation_cost: Cost for answer generation operations
        evaluation_cost: Cost for LLM evaluations
        generation_count: Number of generation operations
        evaluation_count: Number of evaluation operations
        cost_by_decision_type: Cost breakdown by decision type

    Example:
        >>> estimate = CostEstimate(
        ...     total_cost_usd=1.25,
        ...     question_generation_cost=0.75,
        ...     answer_generation_cost=0.40,
        ...     evaluation_cost=0.10,
        ...     generation_count=25,
        ...     evaluation_count=5,
        ...     cost_by_decision_type={
        ...         "REGEN_Q": 0.60,
        ...         "REGEN_A": 0.40,
        ...         "EVALUATE": 0.10
        ...     }
        ... )
        >>> print(f"Total cost: ${estimate.total_cost_usd:.2f}")
    """
    total_cost_usd: float
    question_generation_cost: float
    answer_generation_cost: float
    evaluation_cost: float
    generation_count: int
    evaluation_count: int
    cost_by_decision_type: Dict[str, float]

    def format_summary(self) -> str:
        """
        Format cost estimate as human-readable summary.

        Returns:
            Multi-line summary string

        Example:
            >>> print(estimate.format_summary())
            Cost Estimate:
              Total: $1.25
              Question Generation: $0.75 (15 ops)
              Answer Generation: $0.40 (10 ops)
              Evaluation: $0.10 (5 ops)
        """
        lines = [
            "Cost Estimate:",
            f"  Total: ${self.total_cost_usd:.2f}",
            f"  Question Generation: ${self.question_generation_cost:.2f} ({self.generation_count} ops)",
            f"  Answer Generation: ${self.answer_generation_cost:.2f}",
            f"  Evaluation: ${self.evaluation_cost:.2f} ({self.evaluation_count} ops)"
        ]
        return "\n".join(lines)


# =============================================================================
# Abstract Interface
# =============================================================================


class ICostEstimator(ABC):
    """
    Abstract interface for cost estimation service.

    Defines the contract for estimating LLM API costs for impact decisions.

    Methods:
        estimate_decision_cost: Estimate cost for a single decision
        estimate_decisions_batch: Estimate cost for multiple decisions
        estimate_summary_cost: Estimate cost from ImpactSummary

    Example:
        >>> estimator = CostEstimator()
        >>> estimate = estimator.estimate_decisions_batch(decisions)
        >>> print(f"Total cost: ${estimate.total_cost_usd:.2f}")
    """

    @abstractmethod
    def estimate_decision_cost(self, decision: ImpactDecision) -> float:
        """
        Estimate cost for a single decision.

        Args:
            decision: ImpactDecision to estimate

        Returns:
            Estimated cost in USD
        """
        pass

    @abstractmethod
    def estimate_decisions_batch(self, decisions: List[ImpactDecision]) -> CostEstimate:
        """
        Estimate cost for multiple decisions with detailed breakdown.

        Args:
            decisions: List of impact decisions

        Returns:
            CostEstimate with detailed breakdown
        """
        pass

    @abstractmethod
    def estimate_summary_cost(self, summary: ImpactSummary) -> CostEstimate:
        """
        Estimate cost from ImpactSummary.

        Args:
            summary: ImpactSummary with aggregated metrics

        Returns:
            CostEstimate with detailed breakdown
        """
        pass


# =============================================================================
# Concrete Implementation
# =============================================================================


class CostEstimator(ICostEstimator):
    """
    Concrete implementation of cost estimation service.

    Estimates LLM API costs based on decision types and token counts. Uses
    configurable per-operation costs with defaults based on Azure OpenAI pricing.

    Default Cost Structure (Azure OpenAI GPT-4 approximate):
        - Question Generation: $0.05 per operation
        - Answer Generation: $0.03 per operation
        - Evaluation: $0.02 per operation
        - No cost for NOOP, INACTIVATE

    Cost Calculation:
        1. PLAN_CREATE → 1 question generation + 1 answer generation
        2. REGEN_Q → 1 question generation
        3. REGEN_A → 1 answer generation
        4. REGEN_BOTH → 1 question generation + 1 answer generation
        5. EVALUATE → 1 evaluation operation
        6. INACTIVATE → no cost (database operation only)
        7. NOOP → no cost

    Token-Based Adjustment (Optional):
        - If token counts available in decision.details, can scale costs
        - Current implementation uses fixed per-operation costs

    Attributes:
        cost_per_question_gen: Cost per question generation (default $0.05)
        cost_per_answer_gen: Cost per answer generation (default $0.03)
        cost_per_evaluation: Cost per evaluation (default $0.02)

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> # Use default costs
        >>> estimator = CostEstimator()
        >>>
        >>> # Or custom costs
        >>> estimator = CostEstimator(
        ...     cost_per_question_gen=0.10,
        ...     cost_per_answer_gen=0.05,
        ...     cost_per_evaluation=0.03
        ... )
        >>>
        >>> # Estimate single decision
        >>> decision = ImpactDecision(decision=DecisionType.REGEN_Q, ...)
        >>> cost = estimator.estimate_decision_cost(decision)
        >>> print(f"Cost: ${cost:.2f}")
        >>>
        >>> # Estimate batch
        >>> decisions = [decision1, decision2, decision3]
        >>> estimate = estimator.estimate_decisions_batch(decisions)
        >>> print(estimate.format_summary())
        >>>
        >>> # Estimate from summary
        >>> summary = ImpactSummary.from_decisions(decisions)
        >>> estimate = estimator.estimate_summary_cost(summary)
        >>> print(f"Total: ${estimate.total_cost_usd:.2f}")
    """

    # Default costs (USD) based on Azure OpenAI GPT-4 approximate pricing
    DEFAULT_COST_PER_QUESTION_GEN = 0.05
    DEFAULT_COST_PER_ANSWER_GEN = 0.03
    DEFAULT_COST_PER_EVALUATION = 0.02

    def __init__(
        self,
        cost_per_question_gen: float = DEFAULT_COST_PER_QUESTION_GEN,
        cost_per_answer_gen: float = DEFAULT_COST_PER_ANSWER_GEN,
        cost_per_evaluation: float = DEFAULT_COST_PER_EVALUATION
    ):
        """
        Initialize CostEstimator service.

        Args:
            cost_per_question_gen: Cost per question generation (default $0.05)
            cost_per_answer_gen: Cost per answer generation (default $0.03)
            cost_per_evaluation: Cost per evaluation (default $0.02)

        Raises:
            ValueError: If any cost is negative
        """
        if cost_per_question_gen < 0:
            raise ValueError(f"cost_per_question_gen cannot be negative: {cost_per_question_gen}")
        if cost_per_answer_gen < 0:
            raise ValueError(f"cost_per_answer_gen cannot be negative: {cost_per_answer_gen}")
        if cost_per_evaluation < 0:
            raise ValueError(f"cost_per_evaluation cannot be negative: {cost_per_evaluation}")

        self.cost_per_question_gen = cost_per_question_gen
        self.cost_per_answer_gen = cost_per_answer_gen
        self.cost_per_evaluation = cost_per_evaluation

        logger.info(
            f"Initialized CostEstimator "
            f"(Q=${cost_per_question_gen:.3f}, A=${cost_per_answer_gen:.3f}, "
            f"E=${cost_per_evaluation:.3f})"
        )

    def estimate_decision_cost(self, decision: ImpactDecision) -> float:
        """
        Estimate cost for a single decision.

        Maps decision types to generation operations and calculates cost:
        - PLAN_CREATE: question + answer generation
        - REGEN_Q: question generation only
        - REGEN_A: answer generation only
        - REGEN_BOTH: question + answer generation
        - EVALUATE: evaluation operation
        - INACTIVATE: no cost
        - NOOP: no cost

        Args:
            decision: ImpactDecision to estimate

        Returns:
            Estimated cost in USD

        Example:
            >>> decision = ImpactDecision(decision=DecisionType.REGEN_Q, ...)
            >>> cost = estimator.estimate_decision_cost(decision)
            >>> print(f"${cost:.2f}")  # $0.05
        """
        decision_type = decision.decision

        if decision_type == DecisionType.PLAN_CREATE:
            # Question + Answer generation
            cost = self.cost_per_question_gen + self.cost_per_answer_gen
        elif decision_type == DecisionType.REGEN_Q:
            # Question generation only
            cost = self.cost_per_question_gen
        elif decision_type == DecisionType.REGEN_A:
            # Answer generation only
            cost = self.cost_per_answer_gen
        elif decision_type == DecisionType.REGEN_BOTH:
            # Question + Answer generation
            cost = self.cost_per_question_gen + self.cost_per_answer_gen
        elif decision_type == DecisionType.EVALUATE:
            # Evaluation operation
            cost = self.cost_per_evaluation
        elif decision_type in {DecisionType.INACTIVATE, DecisionType.NOOP}:
            # No LLM cost (database operations only)
            cost = 0.0
        else:
            logger.warning(f"Unknown decision type: {decision_type}, assuming zero cost")
            cost = 0.0

        logger.debug(f"Decision {decision.impact_id} ({decision_type.value}): ${cost:.3f}")

        return cost

    def estimate_decisions_batch(self, decisions: List[ImpactDecision]) -> CostEstimate:
        """
        Estimate cost for multiple decisions with detailed breakdown.

        Args:
            decisions: List of impact decisions

        Returns:
            CostEstimate with:
                - total_cost_usd: Sum of all decision costs
                - question_generation_cost: Cost for Q generation
                - answer_generation_cost: Cost for A generation
                - evaluation_cost: Cost for evaluations
                - generation_count: Total generation operations
                - evaluation_count: Total evaluation operations
                - cost_by_decision_type: Cost breakdown by type

        Example:
            >>> decisions = [decision1, decision2, decision3]
            >>> estimate = estimator.estimate_decisions_batch(decisions)
            >>> print(estimate.format_summary())
            >>> for dt, cost in estimate.cost_by_decision_type.items():
            ...     print(f"{dt}: ${cost:.2f}")
        """
        if not decisions:
            logger.debug("Empty decisions list - returning zero cost estimate")
            return CostEstimate(
                total_cost_usd=0.0,
                question_generation_cost=0.0,
                answer_generation_cost=0.0,
                evaluation_cost=0.0,
                generation_count=0,
                evaluation_count=0,
                cost_by_decision_type={}
            )

        logger.debug(f"Estimating cost for {len(decisions)} decisions")

        # Initialize counters
        question_gen_cost = 0.0
        answer_gen_cost = 0.0
        evaluation_cost = 0.0
        generation_count = 0
        evaluation_count = 0
        cost_by_type: Dict[str, float] = {}

        # Process each decision
        for decision in decisions:
            decision_type = decision.decision
            type_name = decision_type.value

            # Initialize type cost if needed
            if type_name not in cost_by_type:
                cost_by_type[type_name] = 0.0

            # Calculate costs based on type
            if decision_type == DecisionType.PLAN_CREATE:
                question_gen_cost += self.cost_per_question_gen
                answer_gen_cost += self.cost_per_answer_gen
                generation_count += 2
                cost_by_type[type_name] += self.cost_per_question_gen + self.cost_per_answer_gen

            elif decision_type == DecisionType.REGEN_Q:
                question_gen_cost += self.cost_per_question_gen
                generation_count += 1
                cost_by_type[type_name] += self.cost_per_question_gen

            elif decision_type == DecisionType.REGEN_A:
                answer_gen_cost += self.cost_per_answer_gen
                generation_count += 1
                cost_by_type[type_name] += self.cost_per_answer_gen

            elif decision_type == DecisionType.REGEN_BOTH:
                question_gen_cost += self.cost_per_question_gen
                answer_gen_cost += self.cost_per_answer_gen
                generation_count += 2
                cost_by_type[type_name] += self.cost_per_question_gen + self.cost_per_answer_gen

            elif decision_type == DecisionType.EVALUATE:
                evaluation_cost += self.cost_per_evaluation
                evaluation_count += 1
                cost_by_type[type_name] += self.cost_per_evaluation

            # INACTIVATE and NOOP have zero cost (already initialized to 0.0)

        # Calculate total
        total_cost = question_gen_cost + answer_gen_cost + evaluation_cost

        # Create estimate
        estimate = CostEstimate(
            total_cost_usd=total_cost,
            question_generation_cost=question_gen_cost,
            answer_generation_cost=answer_gen_cost,
            evaluation_cost=evaluation_cost,
            generation_count=generation_count,
            evaluation_count=evaluation_count,
            cost_by_decision_type=cost_by_type
        )

        logger.info(
            f"Cost estimate for {len(decisions)} decisions: "
            f"${total_cost:.2f} "
            f"({generation_count} generations, {evaluation_count} evaluations)"
        )

        return estimate

    def estimate_summary_cost(self, summary: ImpactSummary) -> CostEstimate:
        """
        Estimate cost from ImpactSummary aggregated metrics.

        More efficient than processing individual decisions when summary
        is already available.

        Args:
            summary: ImpactSummary with decision counts by type

        Returns:
            CostEstimate with detailed breakdown

        Example:
            >>> decisions = [decision1, decision2, decision3]
            >>> summary = ImpactSummary.from_decisions(decisions)
            >>> estimate = estimator.estimate_summary_cost(summary)
            >>> print(f"Total: ${estimate.total_cost_usd:.2f}")
        """
        logger.debug(f"Estimating cost from ImpactSummary ({summary.total_impacts} decisions)")

        # Initialize counters
        question_gen_cost = 0.0
        answer_gen_cost = 0.0
        evaluation_cost = 0.0
        generation_count = 0
        evaluation_count = 0
        cost_by_type: Dict[str, float] = {}

        # Process each decision type in summary
        for type_name, count in summary.decisions_by_type.items():
            if count == 0:
                continue

            # Calculate cost based on type
            if type_name == DecisionType.PLAN_CREATE.value:
                q_cost = self.cost_per_question_gen * count
                a_cost = self.cost_per_answer_gen * count
                question_gen_cost += q_cost
                answer_gen_cost += a_cost
                generation_count += 2 * count
                cost_by_type[type_name] = q_cost + a_cost

            elif type_name == DecisionType.REGEN_Q.value:
                q_cost = self.cost_per_question_gen * count
                question_gen_cost += q_cost
                generation_count += count
                cost_by_type[type_name] = q_cost

            elif type_name == DecisionType.REGEN_A.value:
                a_cost = self.cost_per_answer_gen * count
                answer_gen_cost += a_cost
                generation_count += count
                cost_by_type[type_name] = a_cost

            elif type_name == DecisionType.REGEN_BOTH.value:
                q_cost = self.cost_per_question_gen * count
                a_cost = self.cost_per_answer_gen * count
                question_gen_cost += q_cost
                answer_gen_cost += a_cost
                generation_count += 2 * count
                cost_by_type[type_name] = q_cost + a_cost

            elif type_name == DecisionType.EVALUATE.value:
                e_cost = self.cost_per_evaluation * count
                evaluation_cost += e_cost
                evaluation_count += count
                cost_by_type[type_name] = e_cost

            elif type_name in {DecisionType.INACTIVATE.value, DecisionType.NOOP.value}:
                cost_by_type[type_name] = 0.0

        # Calculate total
        total_cost = question_gen_cost + answer_gen_cost + evaluation_cost

        # Create estimate
        estimate = CostEstimate(
            total_cost_usd=total_cost,
            question_generation_cost=question_gen_cost,
            answer_generation_cost=answer_gen_cost,
            evaluation_cost=evaluation_cost,
            generation_count=generation_count,
            evaluation_count=evaluation_count,
            cost_by_decision_type=cost_by_type
        )

        logger.info(
            f"Cost estimate from summary: ${total_cost:.2f} "
            f"({generation_count} generations, {evaluation_count} evaluations)"
        )

        return estimate


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "ICostEstimator",
    "CostEstimator",
    "CostEstimate",
]
