"""
Analysis Services - Composable Components for Impact Analysis

This module provides focused, single-responsibility services that support
impact analysis strategies. Services are stateless, testable, and reusable.

Design Principles:
    - Single Responsibility: Each service has one job
    - Dependency Injection: Services are injected, not created internally
    - Testability: Each service can be tested independently
    - Reusability: Services can be used across strategies
    - Stateless: Services are stateless or have minimal state

Available Services:

1. SourceCounter
   Purpose: Dynamically count valid sources for questions/answers
   Methods:
   - count_sources_for_question(question_id) → SourceCountResult
   - count_sources_for_answer(answer_id) → SourceCountResult
   - clear_cache() → None
   Example:
   >>> counter = SourceCounter(backend, enable_cache=True)
   >>> result = counter.count_sources_for_question(123)
   >>> if result.is_orphaned(): print("Question has no valid sources")

2. TokenMatcher
   Purpose: Token-based overlap detection for modified content
   Methods:
   - extract_tokens_from_diff_data(diff_data) → Set[str]
   - calculate_token_overlap(changed_tokens, question_text) → float
   - find_overlapping_questions(diff_data, checksum) → List[TokenOverlapResult]
   Example:
   >>> matcher = TokenMatcher(backend, overlap_threshold=0.3)
   >>> results = matcher.find_overlapping_questions(diff_data, checksum)

3. ChecksumValidator
   Purpose: Validate checksums and detect duplicates
   Methods:
   - validate_checksum(checksum) → ValidationResult
   - validate_checksums_batch(checksums) → Dict[str, ValidationResult]
   - is_duplicate_checksum(checksum) → bool
   Example:
   >>> validator = ChecksumValidator(backend)
   >>> result = validator.validate_checksum("abc123...")
   >>> if result.is_ok(): print("Checksum valid and exists")

4. DecisionPrioritizer
   Purpose: Assign priority scores to impact decisions
   Methods:
   - get_priority_score(decision) → int
   - sort_by_priority(decisions) → List[ImpactDecision]
   - add_custom_rule(rule) → None
   Example:
   >>> prioritizer = DecisionPrioritizer()
   >>> sorted_decisions = prioritizer.sort_by_priority(decisions)

5. CostEstimator
   Purpose: Estimate regeneration costs for impact decisions
   Methods:
   - estimate_decision_cost(decision) → float
   - estimate_decisions_batch(decisions) → CostEstimate
   - estimate_summary_cost(summary) → CostEstimate
   Example:
   >>> estimator = CostEstimator()
   >>> estimate = estimator.estimate_decisions_batch(decisions)
   >>> print(f"Total cost: ${estimate.total_cost_usd:.2f}")

Integration:
    Services are composed by strategies:

    class ModifiedContentStrategy(ImpactStrategy):
        def __init__(
            self,
            provenance_analyzer: ProvenanceAnalyzer,
            diff_evaluator: DiffEvaluator,
            regeneration_planner: RegenerationPlanner
        ):
            self.provenance = provenance_analyzer
            self.diff_eval = diff_evaluator
            self.planner = regeneration_planner

        def analyze(self, change, repository):
            questions = self.provenance.get_questions_by_chunk(change.chunk_id)
            evaluation = self.diff_eval.evaluate_diff(...)
            plan = self.planner.plan_for_modified_content(...)
            return ChangeImpact(...)

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Service imports
from .source_counter import (
    ISourceCounter,
    SourceCounter
)

from .token_matcher import (
    ITokenMatcher,
    TokenMatcher
)

from .checksum_validator import (
    IChecksumValidator,
    ChecksumValidator,
    ValidationResult
)

from .decision_prioritizer import (
    IDecisionPrioritizer,
    DecisionPrioritizer,
    PriorityRule
)

from .cost_estimator import (
    ICostEstimator,
    CostEstimator,
    CostEstimate
)

# Exports
__all__ = [
    # Interfaces
    "ISourceCounter",
    "ITokenMatcher",
    "IChecksumValidator",
    "IDecisionPrioritizer",
    "ICostEstimator",

    # Implementations
    "SourceCounter",
    "TokenMatcher",
    "ChecksumValidator",
    "DecisionPrioritizer",
    "CostEstimator",

    # Data Models
    "ValidationResult",
    "PriorityRule",
    "CostEstimate"
]
