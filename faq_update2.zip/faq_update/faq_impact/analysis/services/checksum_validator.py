"""
ChecksumValidator Service - Checksum Validation and Duplicate Detection

This module provides the ChecksumValidator service class for validating content checksums
and detecting duplicates. Used throughout impact analysis to ensure checksum references
are valid and to identify potential data quality issues.

Classes:
    - IChecksumValidator: Abstract interface for checksum validation
    - ChecksumValidator: Concrete implementation with batch support
    - ValidationResult: Result of checksum validation

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional
import re

# Import backend and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================


@dataclass(frozen=True)
class ValidationResult:
    """
    Result of checksum validation.

    Attributes:
        checksum: The checksum being validated
        is_valid: Whether checksum format is valid (SHA-256 hex)
        exists: Whether checksum exists in active content_chunks
        explanation: Human-readable explanation of result

    Example:
        >>> result = ValidationResult(
        ...     checksum="abc123...",
        ...     is_valid=True,
        ...     exists=True,
        ...     explanation="Checksum is valid and exists in active chunks"
        ... )
        >>> if result.is_valid and result.exists:
        ...     print("Checksum OK")
    """
    checksum: str
    is_valid: bool
    exists: bool
    explanation: str

    def is_ok(self) -> bool:
        """Check if checksum is both valid format and exists."""
        return self.is_valid and self.exists

    def has_error(self) -> bool:
        """Check if there's any validation error."""
        return not self.is_ok()


# =============================================================================
# Abstract Interface
# =============================================================================


class IChecksumValidator(ABC):
    """
    Abstract interface for checksum validation service.

    Defines the contract for validating content checksums and detecting duplicates.
    Implementations should check both format validity and existence in database.

    Methods:
        validate_checksum: Validate a single checksum
        validate_checksums_batch: Validate multiple checksums efficiently
        is_duplicate_checksum: Check if checksum appears multiple times

    Example:
        >>> validator = ChecksumValidator(backend)
        >>> result = validator.validate_checksum("abc123...")
        >>> if result.is_ok():
        ...     print("Checksum is valid and exists")
    """

    @abstractmethod
    def validate_checksum(self, checksum: str) -> ValidationResult:
        """
        Validate a single checksum.

        Args:
            checksum: Content checksum to validate

        Returns:
            ValidationResult with validity and existence info
        """
        pass

    @abstractmethod
    def validate_checksums_batch(self, checksums: List[str]) -> Dict[str, ValidationResult]:
        """
        Validate multiple checksums in a single database query.

        Args:
            checksums: List of checksums to validate

        Returns:
            Dictionary mapping checksum -> ValidationResult
        """
        pass

    @abstractmethod
    def is_duplicate_checksum(self, checksum: str) -> bool:
        """
        Check if checksum appears in multiple active chunks.

        Args:
            checksum: Content checksum to check

        Returns:
            True if checksum appears more than once
        """
        pass


# =============================================================================
# Concrete Implementation
# =============================================================================


class ChecksumValidator(IChecksumValidator):
    """
    Concrete implementation of checksum validation service.

    Validates checksum format (SHA-256: 64-character hex string) and checks
    existence in content_chunks table. Supports efficient batch validation
    using SQL IN clause.

    Attributes:
        backend: Database backend for executing queries
        expected_length: Expected checksum length (64 for SHA-256)
        hex_pattern: Regex pattern for hexadecimal validation

    Checksum Format:
        - Algorithm: SHA-256
        - Length: 64 characters
        - Character set: 0-9, a-f (lowercase hex)
        - Example: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

    Validation Steps:
        1. Format validation: Check length and hex characters
        2. Existence check: Query content_chunks for active entries
        3. Return result with explanation

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> validator = ChecksumValidator(backend)
        >>>
        >>> # Validate single checksum
        >>> result = validator.validate_checksum("abc123...")
        >>> if result.is_valid:
        ...     print("Format is valid")
        >>> if result.exists:
        ...     print("Checksum exists in database")
        >>>
        >>> # Batch validation (more efficient)
        >>> checksums = ["abc123...", "def456...", "ghi789..."]
        >>> results = validator.validate_checksums_batch(checksums)
        >>> for checksum, result in results.items():
        ...     print(f"{checksum[:8]}: {result.explanation}")
        >>>
        >>> # Check for duplicates
        >>> if validator.is_duplicate_checksum("abc123..."):
        ...     print("WARNING: Duplicate checksum detected!")
    """

    # SHA-256 produces 64-character hex strings
    EXPECTED_LENGTH = 64
    HEX_PATTERN = re.compile(r'^[0-9a-f]{64}$', re.IGNORECASE)

    def __init__(self, backend: IBackend):
        """
        Initialize ChecksumValidator service.

        Args:
            backend: Database backend for queries
        """
        self.backend = backend
        logger.info("Initialized ChecksumValidator (SHA-256, 64-char hex)")

    def validate_checksum(self, checksum: str) -> ValidationResult:
        """
        Validate a single checksum for format and existence.

        Checks:
        1. Format: 64-character hexadecimal string (SHA-256)
        2. Existence: Present in content_chunks with status='active'

        Args:
            checksum: Content checksum to validate

        Returns:
            ValidationResult with validation outcome and explanation

        Example:
            >>> result = validator.validate_checksum("abc123...")
            >>> print(result.explanation)
            "Checksum is valid and exists in active chunks"
            >>> if not result.is_ok():
            ...     print(f"ERROR: {result.explanation}")
        """
        # Validate format first
        if not checksum:
            return ValidationResult(
                checksum=checksum,
                is_valid=False,
                exists=False,
                explanation="Checksum is empty or None"
            )

        if len(checksum) != self.EXPECTED_LENGTH:
            return ValidationResult(
                checksum=checksum,
                is_valid=False,
                exists=False,
                explanation=f"Invalid length: expected {self.EXPECTED_LENGTH}, got {len(checksum)}"
            )

        if not self.HEX_PATTERN.match(checksum):
            return ValidationResult(
                checksum=checksum,
                is_valid=False,
                exists=False,
                explanation="Invalid format: must be hexadecimal (0-9, a-f)"
            )

        # Format is valid - now check existence
        logger.debug(f"Checking existence for checksum {checksum[:8]}...")

        query = """
            SELECT COUNT(*) as count
            FROM content_chunks
            WHERE content_checksum = ?
              AND status = 'active'
        """

        rows = self.backend.execute_query(query, (checksum,))

        if not rows:
            return ValidationResult(
                checksum=checksum,
                is_valid=True,
                exists=False,
                explanation="Checksum format is valid but not found in active chunks"
            )

        count = rows[0]['count']
        exists = (count > 0)

        if exists:
            explanation = "Checksum is valid and exists in active chunks"
            if count > 1:
                explanation += f" (WARNING: {count} duplicates found)"
                logger.warning(f"Duplicate checksum detected: {checksum} appears {count} times")
        else:
            explanation = "Checksum format is valid but not found in active chunks"

        logger.debug(f"Checksum {checksum[:8]}: valid={True}, exists={exists}")

        return ValidationResult(
            checksum=checksum,
            is_valid=True,
            exists=exists,
            explanation=explanation
        )

    def validate_checksums_batch(self, checksums: List[str]) -> Dict[str, ValidationResult]:
        """
        Validate multiple checksums efficiently using a single database query.

        Uses SQL IN clause to check all checksums at once, reducing database
        round trips. Format validation is done in-memory for each checksum.

        Args:
            checksums: List of checksums to validate (can be empty)

        Returns:
            Dictionary mapping checksum -> ValidationResult
            Empty dict if input list is empty

        Example:
            >>> checksums = ["abc123...", "def456...", "invalid"]
            >>> results = validator.validate_checksums_batch(checksums)
            >>> valid_checksums = [c for c, r in results.items() if r.is_ok()]
            >>> invalid_checksums = [c for c, r in results.items() if r.has_error()]
            >>> print(f"{len(valid_checksums)} valid, {len(invalid_checksums)} invalid")
        """
        if not checksums:
            logger.debug("Empty checksums list - returning empty results")
            return {}

        logger.debug(f"Batch validating {len(checksums)} checksums")

        results = {}

        # First pass: Format validation (in-memory, fast)
        format_valid_checksums = []
        for checksum in checksums:
            # Validate format
            if not checksum:
                results[checksum] = ValidationResult(
                    checksum=checksum,
                    is_valid=False,
                    exists=False,
                    explanation="Checksum is empty or None"
                )
                continue

            if len(checksum) != self.EXPECTED_LENGTH:
                results[checksum] = ValidationResult(
                    checksum=checksum,
                    is_valid=False,
                    exists=False,
                    explanation=f"Invalid length: expected {self.EXPECTED_LENGTH}, got {len(checksum)}"
                )
                continue

            if not self.HEX_PATTERN.match(checksum):
                results[checksum] = ValidationResult(
                    checksum=checksum,
                    is_valid=False,
                    exists=False,
                    explanation="Invalid format: must be hexadecimal (0-9, a-f)"
                )
                continue

            # Format is valid - add to list for existence check
            format_valid_checksums.append(checksum)

        # Second pass: Existence check (database query)
        if format_valid_checksums:
            logger.debug(f"Checking existence for {len(format_valid_checksums)} format-valid checksums")

            # Build parameterized query with IN clause
            placeholders = ','.join('?' * len(format_valid_checksums))
            query = f"""
                SELECT content_checksum, COUNT(*) as count
                FROM content_chunks
                WHERE content_checksum IN ({placeholders})
                  AND status = 'active'
                GROUP BY content_checksum
            """

            rows = self.backend.execute_query(query, tuple(format_valid_checksums))

            # Build existence map
            existence_map = {row['content_checksum']: row['count'] for row in rows}

            # Create results for format-valid checksums
            for checksum in format_valid_checksums:
                count = existence_map.get(checksum, 0)
                exists = (count > 0)

                if exists:
                    explanation = "Checksum is valid and exists in active chunks"
                    if count > 1:
                        explanation += f" (WARNING: {count} duplicates found)"
                        logger.warning(f"Duplicate checksum: {checksum[:8]} appears {count} times")
                else:
                    explanation = "Checksum format is valid but not found in active chunks"

                results[checksum] = ValidationResult(
                    checksum=checksum,
                    is_valid=True,
                    exists=exists,
                    explanation=explanation
                )

        # Log summary
        valid_and_exists = sum(1 for r in results.values() if r.is_ok())
        format_invalid = sum(1 for r in results.values() if not r.is_valid)
        not_found = sum(1 for r in results.values() if r.is_valid and not r.exists)

        logger.info(
            f"Batch validation complete: {len(checksums)} total, "
            f"{valid_and_exists} valid+exists, {format_invalid} format-invalid, "
            f"{not_found} not-found"
        )

        return results

    def is_duplicate_checksum(self, checksum: str) -> bool:
        """
        Check if checksum appears in multiple active content chunks.

        This can indicate data quality issues or legitimate content reuse
        (e.g., same content in multiple locations).

        Args:
            checksum: Content checksum to check

        Returns:
            True if checksum appears more than once in active chunks

        Example:
            >>> if validator.is_duplicate_checksum("abc123..."):
            ...     print("WARNING: Duplicate content detected")
            ...     # Decide how to handle: log warning, create single question, etc.
        """
        if not checksum:
            return False

        logger.debug(f"Checking for duplicates: {checksum[:8]}...")

        query = """
            SELECT COUNT(*) as count
            FROM content_chunks
            WHERE content_checksum = ?
              AND status = 'active'
        """

        rows = self.backend.execute_query(query, (checksum,))

        if not rows:
            return False

        count = rows[0]['count']
        is_duplicate = (count > 1)

        if is_duplicate:
            logger.warning(
                f"Duplicate checksum detected: {checksum} appears {count} times in active chunks"
            )

        return is_duplicate

    def get_chunks_for_checksum(self, checksum: str) -> List[Dict]:
        """
        Get all active chunks with the given checksum.

        Helper method for investigating duplicates or understanding
        which chunks use a specific checksum.

        Args:
            checksum: Content checksum to look up

        Returns:
            List of chunk records (dicts with chunk metadata)

        Example:
            >>> chunks = validator.get_chunks_for_checksum("abc123...")
            >>> for chunk in chunks:
            ...     print(f"Chunk {chunk['chunk_id']}: {chunk['file_name']}")
        """
        if not checksum:
            return []

        query = """
            SELECT
                chunk_id,
                content_checksum,
                file_name,
                chunk_index,
                created_at,
                updated_at
            FROM content_chunks
            WHERE content_checksum = ?
              AND status = 'active'
            ORDER BY created_at DESC
        """

        rows = self.backend.execute_query(query, (checksum,))

        logger.debug(f"Found {len(rows)} active chunks for checksum {checksum[:8]}")

        return rows


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "IChecksumValidator",
    "ChecksumValidator",
    "ValidationResult",
]
