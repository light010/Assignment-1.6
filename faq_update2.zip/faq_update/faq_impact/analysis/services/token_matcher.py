"""
TokenMatcher Service - Token-Based Overlap Detection for Modified Content

This module provides the TokenMatcher service class for detecting token overlap between
modified content and existing questions. Uses Jaccard similarity for determining if
questions need regeneration based on content changes.

Classes:
    - ITokenMatcher: Abstract interface for token matching
    - TokenMatcher: Concrete implementation with configurable thresholds

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Set, Optional, Any
import json
import re
import string

# Import backend and models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger
from faq_impact.core.models.detection_context import TokenOverlapResult

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Abstract Interface
# =============================================================================


class ITokenMatcher(ABC):
    """
    Abstract interface for token matching service.

    Defines the contract for token-based overlap detection between modified
    content and existing questions. Used by ModifiedContentStrategy to determine
    which questions need regeneration.

    Methods:
        extract_tokens_from_diff_data: Extract changed tokens from diff_data JSON
        calculate_token_overlap: Calculate Jaccard similarity between token sets
        find_overlapping_questions: Find questions with significant token overlap

    Example:
        >>> matcher = TokenMatcher(backend, overlap_threshold=0.3)
        >>> diff_data = {...}  # From content_change_log
        >>> results = matcher.find_overlapping_questions(diff_data)
        >>> for result in results:
        ...     if result.has_significant_overlap():
        ...         print(f"Question {result.question_id} needs regeneration")
    """

    @abstractmethod
    def extract_tokens_from_diff_data(self, diff_data: Dict[str, Any]) -> Set[str]:
        """
        Extract changed tokens from diff_data JSON.

        Args:
            diff_data: Diff data from content_change_log.diff_data column

        Returns:
            Set of normalized tokens from changed content

        Example:
            >>> diff_data = {
            ...     "changes": [
            ...         {"token_changes": [
            ...             {"type": "replace", "old_value": "12", "new_value": "10"}
            ...         ]}
            ...     ]
            ... }
            >>> tokens = matcher.extract_tokens_from_diff_data(diff_data)
            >>> print(tokens)
            {'12', '10'}
        """
        pass

    @abstractmethod
    def calculate_token_overlap(
        self,
        changed_tokens: Set[str],
        question_text: str
    ) -> float:
        """
        Calculate Jaccard similarity between changed tokens and question tokens.

        Args:
            changed_tokens: Set of tokens from changed content
            question_text: Text of the question to compare

        Returns:
            Jaccard similarity score (0.0-1.0)

        Example:
            >>> changed_tokens = {"limit", "annual", "contribution"}
            >>> question_text = "What is the annual contribution limit?"
            >>> score = matcher.calculate_token_overlap(changed_tokens, question_text)
            >>> print(f"Overlap: {score:.2%}")
        """
        pass

    @abstractmethod
    def find_overlapping_questions(
        self,
        diff_data: Dict[str, Any],
        checksum: str
    ) -> List[TokenOverlapResult]:
        """
        Find questions with significant token overlap to changed content.

        Args:
            diff_data: Diff data from content_change_log
            checksum: Content checksum to find associated questions

        Returns:
            List of TokenOverlapResult for questions exceeding threshold

        Example:
            >>> results = matcher.find_overlapping_questions(diff_data, checksum)
            >>> print(f"Found {len(results)} questions with significant overlap")
        """
        pass


# =============================================================================
# Concrete Implementation
# =============================================================================


class TokenMatcher(ITokenMatcher):
    """
    Concrete implementation of token matching service with Jaccard similarity.

    Extracts tokens from diff_data JSON structure, normalizes them, and calculates
    Jaccard similarity with existing question text. Queries database for questions
    associated with the modified content checksum.

    Attributes:
        backend: Database backend for executing queries
        overlap_threshold: Minimum Jaccard similarity to consider significant (default 0.3)
        fuzzy_match: Enable fuzzy matching with stemming (default False)
        normalize_tokens: Apply normalization (lowercase, punctuation removal)

    Token Extraction:
        1. Parse diff_data JSON structure
        2. Extract token_changes from each change
        3. Collect old_value and new_value tokens
        4. Normalize: lowercase, remove punctuation
        5. Return unique token set

    Jaccard Similarity:
        J(A, B) = |A ∩ B| / |A ∪ B|
        Where A = changed tokens, B = question tokens

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> matcher = TokenMatcher(
        ...     backend,
        ...     overlap_threshold=0.3,
        ...     fuzzy_match=False
        ... )
        >>>
        >>> # Find overlapping questions
        >>> diff_data = {
        ...     "total_changes": 2,
        ...     "changes": [
        ...         {
        ...             "change_type": "replace",
        ...             "token_changes": [
        ...                 {"type": "replace", "old_value": "12", "new_value": "10"}
        ...             ]
        ...         }
        ...     ]
        ... }
        >>> results = matcher.find_overlapping_questions(diff_data, "checksum123")
        >>> for result in results:
        ...     print(f"Q{result.question_id}: {result.overlap_score:.2%} overlap")
    """

    def __init__(
        self,
        backend: IBackend,
        overlap_threshold: float = 0.3,
        fuzzy_match: bool = False
    ):
        """
        Initialize TokenMatcher service.

        Args:
            backend: Database backend for queries
            overlap_threshold: Minimum Jaccard similarity (default 0.3 = 30%)
            fuzzy_match: Enable fuzzy matching (default False, future enhancement)

        Raises:
            ValueError: If overlap_threshold not in range [0.0, 1.0]
        """
        if not (0.0 <= overlap_threshold <= 1.0):
            raise ValueError(
                f"overlap_threshold must be between 0.0 and 1.0, got {overlap_threshold}"
            )

        self.backend = backend
        self.overlap_threshold = overlap_threshold
        self.fuzzy_match = fuzzy_match

        logger.info(
            f"Initialized TokenMatcher (threshold={overlap_threshold:.1%}, "
            f"fuzzy={fuzzy_match})"
        )

    def extract_tokens_from_diff_data(self, diff_data: Dict[str, Any]) -> Set[str]:
        """
        Extract changed tokens from diff_data JSON structure.

        Handles all change types (replace, insert, delete) and extracts tokens from
        both old_value and new_value fields. Normalizes tokens to lowercase and
        removes punctuation.

        Args:
            diff_data: Diff data structure from content_change_log.diff_data
                Expected schema:
                {
                    "total_changes": int,
                    "changes": [
                        {
                            "change_type": "replace|insert|delete",
                            "token_changes": [
                                {
                                    "type": "replace|insert|delete",
                                    "old_value": str (optional),
                                    "new_value": str (optional)
                                }
                            ]
                        }
                    ]
                }

        Returns:
            Set of normalized tokens from changed content

        Example:
            >>> diff_data = {
            ...     "total_changes": 2,
            ...     "changes": [
            ...         {
            ...             "change_type": "replace",
            ...             "token_changes": [
            ...                 {"type": "replace", "old_value": "12 days", "new_value": "10 days"},
            ...                 {"type": "replace", "old_value": "$1,000", "new_value": "$1,500"}
            ...             ]
            ...         }
            ...     ]
            ... }
            >>> tokens = matcher.extract_tokens_from_diff_data(diff_data)
            >>> print(sorted(tokens))
            ['10', '12', '1000', '1500', 'days']
        """
        if not diff_data or not isinstance(diff_data, dict):
            logger.warning("Invalid diff_data: expected dict, got empty or wrong type")
            return set()

        all_tokens = set()

        # Extract changes array
        changes = diff_data.get("changes", [])
        if not changes:
            logger.debug("No changes found in diff_data")
            return set()

        logger.debug(f"Processing {len(changes)} changes from diff_data")

        # Process each change
        for change_idx, change in enumerate(changes):
            if not isinstance(change, dict):
                logger.warning(f"Invalid change at index {change_idx}: not a dict")
                continue

            # Extract token_changes
            token_changes = change.get("token_changes", [])
            if not token_changes:
                logger.debug(f"No token_changes in change {change_idx}")
                continue

            # Process each token change
            for token_change in token_changes:
                if not isinstance(token_change, dict):
                    continue

                # Extract old_value tokens
                old_value = token_change.get("old_value")
                if old_value:
                    old_tokens = self._tokenize_and_normalize(str(old_value))
                    all_tokens.update(old_tokens)

                # Extract new_value tokens
                new_value = token_change.get("new_value")
                if new_value:
                    new_tokens = self._tokenize_and_normalize(str(new_value))
                    all_tokens.update(new_tokens)

        logger.debug(f"Extracted {len(all_tokens)} unique tokens from diff_data")
        return all_tokens

    def calculate_token_overlap(
        self,
        changed_tokens: Set[str],
        question_text: str
    ) -> float:
        """
        Calculate Jaccard similarity between changed tokens and question tokens.

        Jaccard similarity = |intersection| / |union|
        - intersection: tokens present in both sets
        - union: all unique tokens from both sets

        Args:
            changed_tokens: Set of normalized tokens from changed content
            question_text: Text of the question to compare against

        Returns:
            Jaccard similarity score (0.0-1.0)
                - 0.0: No overlap
                - 1.0: Perfect overlap (all tokens match)

        Example:
            >>> changed_tokens = {"annual", "contribution", "limit", "12", "10"}
            >>> question_text = "What is the annual contribution limit?"
            >>> score = matcher.calculate_token_overlap(changed_tokens, question_text)
            >>> # Tokens in question: {what, is, the, annual, contribution, limit}
            >>> # Intersection: {annual, contribution, limit} = 3 tokens
            >>> # Union: {annual, contribution, limit, 12, 10, what, is, the} = 8 tokens
            >>> # Jaccard = 3/8 = 0.375
            >>> print(f"{score:.3f}")  # 0.375
        """
        if not changed_tokens:
            logger.debug("Empty changed_tokens set - returning 0.0 overlap")
            return 0.0

        if not question_text:
            logger.debug("Empty question_text - returning 0.0 overlap")
            return 0.0

        # Tokenize and normalize question text
        question_tokens = self._tokenize_and_normalize(question_text)

        if not question_tokens:
            logger.debug("No tokens in question after normalization - returning 0.0")
            return 0.0

        # Calculate Jaccard similarity
        intersection = changed_tokens & question_tokens
        union = changed_tokens | question_tokens

        if not union:
            return 0.0

        jaccard_score = len(intersection) / len(union)

        logger.debug(
            f"Token overlap: {len(intersection)}/{len(union)} = {jaccard_score:.3f} "
            f"(changed={len(changed_tokens)}, question={len(question_tokens)})"
        )

        return jaccard_score

    def find_overlapping_questions(
        self,
        diff_data: Dict[str, Any],
        checksum: str
    ) -> List[TokenOverlapResult]:
        """
        Find questions with significant token overlap to changed content.

        Queries database for questions associated with the content checksum,
        calculates token overlap for each, and returns results exceeding threshold.

        Args:
            diff_data: Diff data structure from content_change_log
            checksum: Content checksum to find associated questions

        Returns:
            List of TokenOverlapResult for questions with overlap >= threshold,
            sorted by overlap_score descending (highest overlap first)

        Raises:
            QueryError: If database query fails

        Example:
            >>> diff_data = {...}  # From content_change_log
            >>> results = matcher.find_overlapping_questions(diff_data, "abc123")
            >>> print(f"Found {len(results)} overlapping questions")
            >>> for result in results:
            ...     if result.has_high_overlap():
            ...         print(f"Q{result.question_id}: {result.overlap_score:.1%} - REGEN")
            ...     elif result.is_ambiguous():
            ...         print(f"Q{result.question_id}: {result.overlap_score:.1%} - EVALUATE")
        """
        # Extract changed tokens
        changed_tokens = self.extract_tokens_from_diff_data(diff_data)

        if not changed_tokens:
            logger.warning("No tokens extracted from diff_data - returning empty results")
            return []

        logger.debug(
            f"Finding questions for checksum {checksum} with {len(changed_tokens)} changed tokens"
        )

        # Query questions associated with this checksum
        query = """
            SELECT DISTINCT q.question_id, q.question_text
            FROM faq_questions q
            INNER JOIN faq_question_sources qs
                ON q.question_id = qs.question_id
            WHERE qs.content_checksum = ?
              AND qs.is_valid = 1
              AND q.is_active = 1
        """

        rows = self.backend.execute_query(query, (checksum,))

        if not rows:
            logger.info(f"No active questions found for checksum {checksum}")
            return []

        logger.debug(f"Found {len(rows)} questions to analyze for overlap")

        # Calculate overlap for each question
        results = []
        for row in rows:
            question_id = row['question_id']
            question_text = row['question_text']

            # Calculate overlap
            overlap_score = self.calculate_token_overlap(changed_tokens, question_text)

            # Only include if exceeds threshold
            if overlap_score >= self.overlap_threshold:
                # Tokenize question for detailed results
                question_tokens = self._tokenize_and_normalize(question_text)
                matched_tokens = list(changed_tokens & question_tokens)
                overlap_percentage = overlap_score * 100.0

                result = TokenOverlapResult(
                    question_id=question_id,
                    overlap_score=overlap_score,
                    matched_tokens=matched_tokens,
                    total_question_tokens=len(question_tokens),
                    overlap_percentage=overlap_percentage
                )

                results.append(result)

                logger.debug(
                    f"Question {question_id}: {overlap_score:.1%} overlap "
                    f"({len(matched_tokens)} matched tokens)"
                )

        # Sort by overlap score descending (highest first)
        results.sort(key=lambda r: r.overlap_score, reverse=True)

        logger.info(
            f"Found {len(results)} questions with overlap >= {self.overlap_threshold:.1%} "
            f"for checksum {checksum}"
        )

        return results

    # -------------------------------------------------------------------------
    # Private Helper Methods
    # -------------------------------------------------------------------------

    def _tokenize_and_normalize(self, text: str) -> Set[str]:
        """
        Tokenize text and normalize tokens.

        Normalization steps:
        1. Convert to lowercase
        2. Remove punctuation
        3. Split on whitespace
        4. Filter out empty strings
        5. Return unique tokens

        Args:
            text: Text to tokenize

        Returns:
            Set of normalized tokens

        Example:
            >>> text = "What's the annual limit? $1,500!"
            >>> tokens = matcher._tokenize_and_normalize(text)
            >>> print(sorted(tokens))
            ['1500', 'annual', 'limit', 'the', 'what', 'whats']
        """
        if not text:
            return set()

        # Convert to lowercase
        text = text.lower()

        # Remove punctuation (but keep spaces)
        # This creates variants like "what's" -> "whats"
        translator = str.maketrans('', '', string.punctuation)
        text = text.translate(translator)

        # Split on whitespace and filter empty strings
        tokens = [token.strip() for token in text.split() if token.strip()]

        return set(tokens)


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "ITokenMatcher",
    "TokenMatcher",
]
