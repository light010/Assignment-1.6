"""
DecisionPrioritizer Service - Priority Scoring for Impact Decisions

This module provides the DecisionPrioritizer service class for assigning priority scores
to impact decisions. Used to order execution of decisions when applying plans, ensuring
critical operations (inactivations, regenerations) are handled before optional ones.

Classes:
    - IDecisionPrioritizer: Abstract interface for decision prioritization
    - DecisionPrioritizer: Concrete implementation with configurable rules
    - PriorityRule: Custom priority rule definition

Author: Analytics Assist Team
Date: 2025-11-02
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Optional, Callable
from enum import Enum

# Import models
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.utility.logging import get_logger
from faq_impact.core.models.impact_decision import ImpactDecision
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================


@dataclass
class PriorityRule:
    """
    Custom priority rule for decision prioritization.

    Allows defining custom priority logic based on decision attributes.

    Attributes:
        name: Human-readable rule name
        condition: Function that checks if rule applies to a decision
        priority_adjustment: Score adjustment if rule matches (added to base priority)

    Example:
        >>> # Rule: Bump priority for high similarity changes
        >>> high_similarity_rule = PriorityRule(
        ...     name="high_similarity_regen",
        ...     condition=lambda d: d.details.get('similarity_score', 0) > 0.9,
        ...     priority_adjustment=10
        ... )
        >>> prioritizer.add_custom_rule(high_similarity_rule)
    """
    name: str
    condition: Callable[[ImpactDecision], bool]
    priority_adjustment: int


# =============================================================================
# Abstract Interface
# =============================================================================


class IDecisionPrioritizer(ABC):
    """
    Abstract interface for decision prioritization service.

    Defines the contract for assigning priority scores to impact decisions.
    Higher scores = higher priority (execute first).

    Methods:
        get_priority_score: Get priority score for a single decision
        sort_by_priority: Sort list of decisions by priority
        add_custom_rule: Add custom prioritization rule

    Example:
        >>> prioritizer = DecisionPrioritizer()
        >>> decisions = [decision1, decision2, decision3]
        >>> sorted_decisions = prioritizer.sort_by_priority(decisions)
        >>> for decision in sorted_decisions:
        ...     print(f"{decision.decision}: priority={prioritizer.get_priority_score(decision)}")
    """

    @abstractmethod
    def get_priority_score(self, decision: ImpactDecision) -> int:
        """
        Get priority score for a decision.

        Args:
            decision: ImpactDecision to score

        Returns:
            Priority score (higher = more urgent)
        """
        pass

    @abstractmethod
    def sort_by_priority(
        self,
        decisions: List[ImpactDecision],
        descending: bool = True
    ) -> List[ImpactDecision]:
        """
        Sort decisions by priority score.

        Args:
            decisions: List of impact decisions
            descending: If True, highest priority first (default)

        Returns:
            Sorted list of decisions
        """
        pass

    @abstractmethod
    def add_custom_rule(self, rule: PriorityRule) -> None:
        """
        Add custom prioritization rule.

        Args:
            rule: PriorityRule to add
        """
        pass


# =============================================================================
# Concrete Implementation
# =============================================================================


class DecisionPrioritizer(IDecisionPrioritizer):
    """
    Concrete implementation of decision prioritization service.

    Assigns priority scores based on decision type and reason code, with support
    for custom rules. Default priorities ensure critical operations (inactivations)
    are handled before optional ones (evaluations).

    Default Priority Scores (by DecisionType):
        - INACTIVATE: 100 (highest - data integrity critical)
        - REGEN_Q: 80 (high - question accuracy important)
        - REGEN_A: 60 (medium-high - answer accuracy important)
        - REGEN_BOTH: 90 (very high - complete regeneration)
        - PLAN_CREATE: 40 (medium - new content, less urgent)
        - EVALUATE: 20 (low - manual review needed)
        - NOOP: 0 (lowest - no action needed)

    Priority Adjustments (by ReasonCode):
        - SOLE_SOURCE_DELETED_REGEN: +20 (critical data loss prevention)
        - SOLE_SOURCE_MODIFIED_MAJOR: +15 (significant impact)
        - TOKEN_OVERLAP_HIGH: +10 (high confidence change needed)
        - SOLE_SOURCE_MODIFIED_MINOR: +5 (minor change)
        - MULTI_SOURCE_DELETED: +0 (other sources exist)

    Custom Rules:
        - Additional priority adjustments can be added via add_custom_rule()
        - Rules are evaluated in order and adjustments are cumulative

    Attributes:
        base_priorities: Default priority scores by decision type
        reason_adjustments: Priority adjustments by reason code
        custom_rules: List of custom priority rules

    Example:
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>>
        >>> prioritizer = DecisionPrioritizer()
        >>>
        >>> # Get priority for a decision
        >>> decision = ImpactDecision(...)
        >>> priority = prioritizer.get_priority_score(decision)
        >>> print(f"Priority: {priority}")
        >>>
        >>> # Sort decisions by priority
        >>> decisions = [decision1, decision2, decision3]
        >>> sorted_decisions = prioritizer.sort_by_priority(decisions)
        >>> for i, d in enumerate(sorted_decisions, 1):
        ...     score = prioritizer.get_priority_score(d)
        ...     print(f"{i}. {d.decision.value} (priority={score})")
        >>>
        >>> # Add custom rule
        >>> high_overlap_rule = PriorityRule(
        ...     name="high_token_overlap",
        ...     condition=lambda d: d.details.get('token_overlap_score', 0) > 0.8,
        ...     priority_adjustment=15
        ... )
        >>> prioritizer.add_custom_rule(high_overlap_rule)
    """

    # Default base priorities by decision type
    DEFAULT_BASE_PRIORITIES = {
        DecisionType.INACTIVATE: 100,
        DecisionType.REGEN_BOTH: 90,
        DecisionType.REGEN_Q: 80,
        DecisionType.REGEN_A: 60,
        DecisionType.PLAN_CREATE: 40,
        DecisionType.EVALUATE: 20,
        DecisionType.NOOP: 0,
    }

    # Default priority adjustments by reason code
    DEFAULT_REASON_ADJUSTMENTS = {
        ReasonCode.SOLE_SOURCE_DELETED_REGEN: 20,
        ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR: 15,
        ReasonCode.TOKEN_OVERLAP_DETECTED: 10,
        ReasonCode.SOLE_SOURCE_CONTENT_CHANGED: 5,
        ReasonCode.MULTI_SOURCE_ONE_MODIFIED: 0,
        ReasonCode.MULTIPLE_SOURCES_MODIFIED: 0,
        ReasonCode.NEW_CONTENT_ADDED: 0,
        ReasonCode.CONTENT_DELETED: 15,
        ReasonCode.SIMILARITY_AMBIGUOUS: 5,
        ReasonCode.CONTENT_UNCHANGED: 0,
    }

    def __init__(
        self,
        base_priorities: Optional[Dict[DecisionType, int]] = None,
        reason_adjustments: Optional[Dict[ReasonCode, int]] = None
    ):
        """
        Initialize DecisionPrioritizer service.

        Args:
            base_priorities: Custom base priorities by decision type (optional)
            reason_adjustments: Custom reason adjustments (optional)
        """
        # Use provided priorities or defaults
        self.base_priorities = base_priorities or self.DEFAULT_BASE_PRIORITIES.copy()
        self.reason_adjustments = reason_adjustments or self.DEFAULT_REASON_ADJUSTMENTS.copy()

        # Custom rules (empty initially)
        self.custom_rules: List[PriorityRule] = []

        logger.info(
            f"Initialized DecisionPrioritizer with {len(self.base_priorities)} decision types, "
            f"{len(self.reason_adjustments)} reason adjustments"
        )

    def get_priority_score(self, decision: ImpactDecision) -> int:
        """
        Calculate priority score for a decision.

        Priority calculation:
        1. Start with base priority for decision type
        2. Add adjustment for reason code
        3. Apply custom rules (cumulative adjustments)
        4. Return final score

        Args:
            decision: ImpactDecision to score

        Returns:
            Priority score (higher = more urgent)
            Minimum score is 0 (negative scores are clamped to 0)

        Example:
            >>> decision = ImpactDecision(
            ...     decision=DecisionType.INACTIVATE,
            ...     reason=ReasonCode.SOLE_SOURCE_DELETED,
            ...     ...
            ... )
            >>> priority = prioritizer.get_priority_score(decision)
            >>> # Base: 100 (INACTIVATE) + 20 (SOLE_SOURCE_DELETED) = 120
            >>> print(priority)  # 120
        """
        # Start with base priority
        base_score = self.base_priorities.get(decision.decision, 0)

        # Add reason adjustment
        reason_adjustment = self.reason_adjustments.get(decision.reason, 0)

        # Apply custom rules
        custom_adjustment = 0
        for rule in self.custom_rules:
            try:
                if rule.condition(decision):
                    custom_adjustment += rule.priority_adjustment
                    logger.debug(
                        f"Applied custom rule '{rule.name}': +{rule.priority_adjustment} "
                        f"for decision {decision.impact_id}"
                    )
            except Exception as e:
                logger.warning(
                    f"Custom rule '{rule.name}' failed for decision {decision.impact_id}: {e}"
                )

        # Calculate final score
        final_score = base_score + reason_adjustment + custom_adjustment

        # Clamp to minimum of 0
        final_score = max(0, final_score)

        logger.debug(
            f"Priority for decision {decision.impact_id}: {final_score} "
            f"(base={base_score}, reason={reason_adjustment}, custom={custom_adjustment})"
        )

        return final_score

    def sort_by_priority(
        self,
        decisions: List[ImpactDecision],
        descending: bool = True
    ) -> List[ImpactDecision]:
        """
        Sort decisions by priority score.

        Args:
            decisions: List of impact decisions to sort
            descending: If True, highest priority first (default: True)

        Returns:
            Sorted list of decisions (new list, original unchanged)

        Example:
            >>> decisions = [low_priority, high_priority, medium_priority]
            >>> sorted_decisions = prioritizer.sort_by_priority(decisions)
            >>> # Returns: [high_priority, medium_priority, low_priority]
            >>> for d in sorted_decisions:
            ...     print(f"{d.decision}: {prioritizer.get_priority_score(d)}")
        """
        if not decisions:
            return []

        logger.debug(f"Sorting {len(decisions)} decisions by priority (descending={descending})")

        # Create list of (decision, priority) tuples
        scored_decisions = [(d, self.get_priority_score(d)) for d in decisions]

        # Sort by priority
        scored_decisions.sort(key=lambda x: x[1], reverse=descending)

        # Extract sorted decisions
        sorted_decisions = [d for d, _ in scored_decisions]

        # Log summary
        if sorted_decisions:
            highest = self.get_priority_score(sorted_decisions[0])
            lowest = self.get_priority_score(sorted_decisions[-1])
            logger.info(
                f"Sorted {len(decisions)} decisions: "
                f"priority range {lowest} to {highest}"
            )

        return sorted_decisions

    def add_custom_rule(self, rule: PriorityRule) -> None:
        """
        Add custom prioritization rule.

        Custom rules are applied after base priorities and reason adjustments.
        Multiple rules can be added and their adjustments are cumulative.

        Args:
            rule: PriorityRule to add

        Example:
            >>> # Boost priority for high-confidence changes
            >>> high_confidence_rule = PriorityRule(
            ...     name="high_confidence_boost",
            ...     condition=lambda d: d.details.get('confidence', 0) > 0.9,
            ...     priority_adjustment=10
            ... )
            >>> prioritizer.add_custom_rule(high_confidence_rule)
            >>>
            >>> # Reduce priority for manual-review decisions
            >>> manual_review_rule = PriorityRule(
            ...     name="manual_review_penalty",
            ...     condition=lambda d: d.decision == DecisionType.EVALUATE,
            ...     priority_adjustment=-5
            ... )
            >>> prioritizer.add_custom_rule(manual_review_rule)
        """
        self.custom_rules.append(rule)
        logger.info(
            f"Added custom priority rule '{rule.name}' "
            f"(adjustment={rule.priority_adjustment:+d})"
        )

    def remove_custom_rule(self, rule_name: str) -> bool:
        """
        Remove custom rule by name.

        Args:
            rule_name: Name of the rule to remove

        Returns:
            True if rule was found and removed, False otherwise

        Example:
            >>> prioritizer.remove_custom_rule("high_confidence_boost")
            True
        """
        initial_count = len(self.custom_rules)
        self.custom_rules = [r for r in self.custom_rules if r.name != rule_name]
        removed = len(self.custom_rules) < initial_count

        if removed:
            logger.info(f"Removed custom priority rule '{rule_name}'")
        else:
            logger.warning(f"Custom priority rule '{rule_name}' not found")

        return removed

    def clear_custom_rules(self) -> None:
        """
        Clear all custom priority rules.

        Example:
            >>> prioritizer.clear_custom_rules()
            >>> # Back to default priorities only
        """
        count = len(self.custom_rules)
        self.custom_rules.clear()
        logger.info(f"Cleared {count} custom priority rules")

    def get_priority_breakdown(self, decision: ImpactDecision) -> Dict[str, int]:
        """
        Get detailed breakdown of priority calculation for a decision.

        Useful for debugging and understanding why a decision has a certain priority.

        Args:
            decision: ImpactDecision to analyze

        Returns:
            Dictionary with priority components:
                - base_priority: Base score for decision type
                - reason_adjustment: Adjustment for reason code
                - custom_adjustments: Total custom rule adjustments
                - final_score: Final priority score

        Example:
            >>> breakdown = prioritizer.get_priority_breakdown(decision)
            >>> print(f"Base: {breakdown['base_priority']}")
            >>> print(f"Reason: {breakdown['reason_adjustment']}")
            >>> print(f"Custom: {breakdown['custom_adjustments']}")
            >>> print(f"Final: {breakdown['final_score']}")
        """
        base_priority = self.base_priorities.get(decision.decision, 0)
        reason_adjustment = self.reason_adjustments.get(decision.reason, 0)

        custom_adjustments = 0
        for rule in self.custom_rules:
            try:
                if rule.condition(decision):
                    custom_adjustments += rule.priority_adjustment
            except Exception:
                pass

        final_score = max(0, base_priority + reason_adjustment + custom_adjustments)

        return {
            "base_priority": base_priority,
            "reason_adjustment": reason_adjustment,
            "custom_adjustments": custom_adjustments,
            "final_score": final_score
        }


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    "IDecisionPrioritizer",
    "DecisionPrioritizer",
    "PriorityRule",
]
