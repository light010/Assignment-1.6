"""
Analysis Module - Impact Analysis Without Modification

This module implements the ANALYSIS phase of FAQ impact management.
It identifies changes and their impacts WITHOUT modifying any data.
The output is an ImpactAnalysisReport that can be reviewed before execution.

Key Principle: SEPARATION OF ANALYSIS FROM APPLICATION
    - Analysis = "What changed and what's affected?"
    - Application = "How should we respond?" (separate module)

Core Components:
    1. ImpactAnalyzer (Main Entry Point)
       - Coordinates the analysis process
       - Produces ImpactAnalysisReport
       - Uses strategies for different change types

    2. Impact Strategies (Strategy Pattern)
       - NewContentStrategy: Handles new chunks
       - ModifiedContentStrategy: Handles modified chunks
       - DeletedContentStrategy: Handles deleted chunks

    3. Analysis Services (Composable Helpers)
       - ProvenanceAnalyzer: Maps chunks to questions
       - DiffEvaluator: Determines if changes are meaningful
       - ImpactScorer: Prioritizes affected questions

Workflow:
    1. Detect changes using existing detection.ChecksumChangeDetector
    2. For each change, apply appropriate strategy
    3. Strategies query provenance to find affected Q/A pairs
    4. Analyze diffs to determine if regeneration needed
    5. Build comprehensive ImpactAnalysisReport

Data Flow:
    DetectionResult (from detection module)
         ↓
    ImpactAnalyzer (coordinates analysis)
         ↓
    Impact Strategies (analyze each change type)
         ↓
    Analysis Services (helper operations)
         ↓
    ImpactAnalysisReport (output for review)

Example:
    >>> from faq_impact.analysis import ImpactAnalyzer
    >>> from database.backends.factory import BackendFactory
    >>>
    >>> backend = BackendFactory.create_backend(config)
    >>> analyzer = ImpactAnalyzer(backend)
    >>>
    >>> # Run analysis (doesn't modify data)
    >>> report = analyzer.analyze_changes()
    >>>
    >>> # Review the report
    >>> print(f"New chunks: {report.new_content_count}")
    >>> print(f"Modified chunks: {report.modified_content_count}")
    >>> print(f"Questions needing regeneration: {len(report.questions_to_regenerate)}")
    >>>
    >>> # Optionally apply changes (separate step)
    >>> from faq_impact.application import ChangeExecutor
    >>> executor = ChangeExecutor(backend)
    >>> results = executor.apply_changes(report)

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Imports will be added as components are implemented
__all__ = []
