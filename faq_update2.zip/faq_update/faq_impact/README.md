# FAQ Impact Analysis Module

Comprehensive impact analysis and automated change propagation for FAQ content management.

## Overview

The `faq_impact` module provides intelligent impact analysis when source content changes, automatically determining which FAQ questions and answers need regeneration. It implements a **two-phase approach**:

1. **Analysis Phase** - Identifies what changed and what's affected (read-only)
2. **Application Phase** - Executes the planned changes (write operations)

This separation enables review workflows where stakeholders can examine the proposed changes before execution.

## Key Features

- **Automatic Impact Detection**: Identifies all Q/A pairs affected by content changes
- **Intelligent Regeneration**: Only regenerates Q/A pairs when truly necessary
- **Provenance Tracking**: Maintains links between Q/A pairs and source content via checksums
- **Selective Updates**: Differentiates between new, modified, and deleted content
- **LLM-Friendly Diffs**: Uses semantic diffs to help LLMs understand changes
- **Transaction Safety**: All-or-nothing execution with automatic rollback on errors
- **Dry-Run Mode**: Preview changes before committing

## Architecture

### Module Structure

```
faq_impact/
├── core/              # Domain models, interfaces, enums
│   ├── models/        # Immutable value objects
│   ├── interfaces/    # Abstract base classes
│   └── enums/         # Type-safe enumerations
├── database/          # Data access layer
│   ├── sql/           # SQL definitions
│   │   ├── schema/    # DDL statements
│   │   └── queries/   # Parameterized queries
│   └── repository/    # Repository pattern implementation
├── analysis/          # Analysis phase (read-only)
│   ├── strategies/    # Strategy pattern for change types
│   └── services/      # Composable analysis helpers
├── application/       # Application phase (writes)
│   ├── executors/     # Execute specific change types
│   └── services/      # Q/A generation and updates
├── config/            # Configuration classes
├── utility/           # Helpers, validators, metrics
└── tests/             # Comprehensive test suite
    ├── analysis/      # Analysis phase tests
    ├── application/   # Application phase tests
    └── integration/   # End-to-end tests
```

### Design Patterns

- **Strategy Pattern**: Pluggable handlers for different change types
- **Repository Pattern**: Clean database abstraction
- **Service Layer**: Composable, single-responsibility services
- **Value Objects**: Immutable domain models with validation
- **Dependency Injection**: All dependencies injected, not created

## Quick Start

### Installation

```python
# The module is part of the faq_update package
from faq_impact.analysis import ImpactAnalyzer
from faq_impact.application import ChangeExecutor
```

### Basic Usage

```python
from faq_impact.analysis import ImpactAnalyzer
from faq_impact.application import ChangeExecutor
from database.backends.factory import BackendFactory
from config import DatabaseConfig

# Setup
config = DatabaseConfig.from_env()
backend = BackendFactory.create_backend(config)

# Phase 1: Analyze Changes (Read-Only)
analyzer = ImpactAnalyzer(backend)
report = analyzer.analyze_changes()

# Review the report
print(f"📊 Impact Analysis Report")
print(f"  New chunks: {report.new_content_count}")
print(f"  Modified chunks: {report.modified_content_count}")
print(f"  Deleted chunks: {report.deleted_content_count}")
print(f"  Questions to regenerate: {len(report.questions_to_regenerate)}")
print(f"  Questions to deactivate: {len(report.questions_to_deactivate)}")

# Phase 2: Execute Changes (if approved)
if user_approves(report):
    executor = ChangeExecutor(backend, llm_client)
    result = executor.apply_changes(report)

    print(f"✅ Execution Complete")
    print(f"  Questions created: {result.questions_created}")
    print(f"  Questions regenerated: {result.questions_regenerated}")
    print(f"  Questions deactivated: {result.questions_deactivated}")
```

### Dry-Run Mode

Preview changes without committing:

```python
executor = ChangeExecutor(backend, llm_client, dry_run=True)
preview = executor.apply_changes(report)

print(f"Would create {preview.questions_created} questions")
print(f"Would regenerate {preview.questions_regenerated} questions")
# No actual database changes made
```

## Change Handling Logic

### New Content

When new content chunks are added:

1. **Generate questions** from the new chunk (same as `3_question_source_gen.ipynb`)
2. **Generate answers** for those questions (same as `4_answer_source_gen.ipynb`)
3. **Link Q/A pairs** to the new chunk's checksum in provenance table
4. **Set status** to Active

### Modified Content

When content chunks are modified:

1. **Identify affected questions** using provenance (chunk-to-question mapping)
2. **Evaluate changes** using `llm_friendly_diff` to determine if regeneration needed
3. **Regenerate questions** that are affected by the changes
4. **Regenerate answers** for those questions
5. **Update provenance**: Invalidate old checksum, add new checksum
6. **Keep unaffected Q/A pairs** unchanged (optimization)

### Deleted Content

When content chunks are deleted:

1. **Find dependent questions** using provenance (question-to-sources mapping)
2. **Single-source questions**: Set question and all answers to Inactive
3. **Multi-source questions**: Regenerate using remaining sources only
4. **Update provenance**: Remove deleted checksum from source links

## Configuration

### Environment Variables

```bash
# Analysis Configuration
IMPACT_ANALYSIS_CACHE_ENABLED=true
IMPACT_ANALYSIS_BATCH_SIZE=10
IMPACT_DIFF_THRESHOLD=0.7

# Regeneration Configuration
REGENERATION_QUESTION_COUNT=5
REGENERATION_MODEL=gpt-4
REGENERATION_TEMPERATURE=0.7

# Execution Configuration
EXECUTION_DRY_RUN=false
EXECUTION_USE_TRANSACTIONS=true
EXECUTION_ROLLBACK_ON_ERROR=true
```

### Configuration File

```python
from faq_impact.config import ImpactModuleConfig

config = ImpactModuleConfig.from_file("config/impact.yaml")
```

## Integration with Existing Modules

The `faq_impact` module integrates with existing FAQ update modules:

### Change Detection Integration

```python
from detection import ChecksumChangeDetector
from faq_impact.analysis import ImpactAnalyzer

# Use existing change detector
detector = ChecksumChangeDetector(backend)
detection_result = detector.detect_changes()

# Analyze impact of detected changes
analyzer = ImpactAnalyzer(backend)
impact_report = analyzer.analyze_from_detection(detection_result)
```

### Database Schema

The module extends the existing schema with:

- `impact_analysis_runs`: Tracks analysis executions
- `chunk_impact_cache`: Caches chunk-to-question mappings for performance
- `regeneration_queue`: Tracks Q/A pairs pending regeneration
- `impact_metrics`: Stores detailed metrics

See [database/sql/schema/README.md](database/sql/schema/README.md) for details.

## Testing

### Run All Tests

```bash
pytest faq_update/faq_impact/tests/
```

### Run Only Fast Tests (Unit Tests)

```bash
pytest faq_update/faq_impact/tests/ -m "not integration"
```

### Run Integration Tests

```bash
pytest faq_update/faq_impact/tests/integration/
```

### Run with Coverage

```bash
pytest faq_update/faq_impact/tests/ --cov=faq_impact --cov-report=html
```

## Development Workflow

### Adding a New Strategy

1. Create strategy class in `analysis/strategies/`
2. Implement `ImpactStrategy` interface
3. Add tests in `tests/analysis/`
4. Register strategy in `ImpactAnalyzer`

### Adding a New Service

1. Create service class in `analysis/services/` or `application/services/`
2. Make service stateless and testable
3. Add tests in `tests/analysis/` or `tests/application/`
4. Inject service into strategies/executors

## Performance Considerations

### Caching

Enable the chunk-to-question cache for faster impact analysis:

```python
from faq_impact.config import ImpactAnalysisConfig

config = ImpactAnalysisConfig(enable_cache=True)
analyzer = ImpactAnalyzer(backend, config=config)
```

### Batch Processing

Process multiple items in parallel:

```python
from faq_impact.config import ExecutionConfig

config = ExecutionConfig(
    batch_size=10,
    parallel_execution=True
)
executor = ChangeExecutor(backend, llm_client, config=config)
```

### LLM Optimizations

- **Cache LLM responses**: Avoid regenerating identical content
- **Batch API calls**: Reduce API overhead
- **Selective regeneration**: Only regenerate when truly necessary

## Error Handling

The module provides robust error handling:

- **Transaction Rollback**: Automatic rollback on errors
- **Retry Logic**: Exponential backoff for transient failures
- **Partial Failure Tracking**: Records what succeeded vs. failed
- **Detailed Logging**: Comprehensive logs for debugging

## Monitoring and Observability

### Metrics Collection

```python
from faq_impact.utility import ImpactMetricsCollector

metrics = ImpactMetricsCollector()
with metrics.track("analysis_phase"):
    report = analyzer.analyze_changes()

print(f"Analysis took {metrics.get_duration('analysis_phase')}s")
print(f"Processed {metrics.get_counter('chunks_analyzed')} chunks")
```

### Health Checks

```python
from faq_impact.utility import HealthChecker

health = HealthChecker(backend, llm_client)
is_healthy = health.check_all()
if not is_healthy:
    print(f"Errors: {health.errors}")
```

## Roadmap

### Phase 1: Foundation (Current)
- ✅ Module structure and documentation
- ⏳ Core models and interfaces
- ⏳ Database schema and repositories

### Phase 2: Analysis
- ⏳ Impact analysis strategies
- ⏳ Analysis services
- ⏳ Integration with change detection

### Phase 3: Application
- ⏳ Change executors
- ⏳ Q/A generation services
- ⏳ Provenance management

### Phase 4: Optimization
- ⏳ Caching layer
- ⏳ Batch processing
- ⏳ Performance tuning

### Phase 5: Production
- ⏳ Monitoring and alerting
- ⏳ Advanced error recovery
- ⏳ Production deployment

## Contributing

### Code Style

- Follow PEP 8 conventions
- Use type hints throughout
- Write comprehensive docstrings
- Add tests for all new code

### Pull Request Process

1. Create feature branch from `main`
2. Implement changes with tests
3. Run full test suite
4. Update documentation
5. Submit PR for review

## Support

For questions or issues:

1. Check the [ARCHITECTURE.md](ARCHITECTURE.md) for design details
2. Review the [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) for task breakdown
3. Examine existing tests for usage examples
4. Contact the Analytics Assist Team

## License

Copyright 2025 Analytics Assist Team. All rights reserved.

---

**Author**: Analytics Assist Team
**Date**: 2025-11-02
**Version**: 1.0.0
