# Dependency Notes for Enhanced faq_questions Schema

## Overview
This document describes the dependency relationships for the enhanced `faq_questions` table with inactivation tracking.

## Schema Dependencies

### Original Dependency (Unchanged)
```yaml
faq_questions:
  file: "tables/02_faq_questions.sql"
  dependencies: []
  order: 2
  description: "FAQ questions (content-agnostic)"
```

**Status**: No dependencies - faq_questions is a foundation table

### New Logical Dependency (Application-Level)
```yaml
faq_questions:
  file: "faq_impact/database/sql/schema/02_faq_questions_enhanced.sql"
  dependencies:
    - "content_change_log"  # NEW: Logical FK via inactivated_by_change_id
  logical_dependencies:
    - table: "content_change_log"
      column: "inactivated_by_change_id"
      references: "change_id"
      enforcement: "application-level"
      nullable: true
      description: "Tracks which content change triggered question inactivation"
  order: 2  # Can remain order 2 since FK is not enforced at DB level
  description: "FAQ questions with inactivation tracking"
```

## Creation Order Analysis

### Option 1: Keep Current Order (Recommended)
**Order**: content_chunks (1) → faq_questions (2) → content_change_log (6)

**Rationale**:
- FK from faq_questions to content_change_log is **application-level** only
- No database-level constraint requires content_change_log to exist first
- Maintains backward compatibility with existing schema
- faq_questions can be created independently

**Pros**:
- No migration required
- Existing tools/scripts unchanged
- Clear separation of concerns

**Cons**:
- Logical dependency not reflected in creation order
- Could be confusing to developers

### Option 2: Reorder for Logical Clarity (Not Recommended)
**Order**: content_chunks (1) → content_change_log (2) → faq_questions (3) → faq_answers (4) → ...

**Rationale**:
- Reflects logical FK dependency in creation order
- Makes dependency clear to developers

**Pros**:
- Creation order matches logical dependencies

**Cons**:
- Requires renumbering all schema files after faq_questions
- Breaking change for existing system
- Overkill for application-level FK

## Recommendation: Keep Current Order

**Decision**: Keep faq_questions at order 2 (before content_change_log at order 6)

**Reasoning**:
1. **No Database-Level FK**: The FK is application-level only, so database creation order doesn't matter
2. **Backward Compatible**: No changes needed to existing schema files or tooling
3. **Minimal Impact**: Application code handles FK validation, not database
4. **SQLite/Databricks Compatible**: Both backends support application-level FK equally

## Updated Dependency Graph Section

For reference, here's how the dependency graph in `database/sql/schema/_meta/dependency_graph.yaml` should document this relationship:

```yaml
faq_questions:
  file: "tables/02_faq_questions.sql"
  dependencies: []  # No DATABASE-level dependencies
  order: 2
  description: "FAQ questions (content-agnostic)"
  notes: |
    Questions can exist without answers (draft state)
    LOGICAL FK (application-level): inactivated_by_change_id → content_change_log.change_id
    - Not enforced by database (SQLite/Databricks limitation)
    - Validated by application code (see VALIDATION_LOGIC.md)
    - Nullable: Yes (only populated when question inactivated)
```

**Alternative** (if using enhanced schema):
```yaml
faq_questions:
  file: "tables/02_faq_questions_enhanced.sql"  # Enhanced version
  dependencies: []  # No DATABASE-level dependencies
  logical_dependencies:  # NEW: Application-level dependencies
    - table: "content_change_log"
      enforcement: "application"
      description: "inactivated_by_change_id references change_id"
  order: 2
  description: "FAQ questions with inactivation tracking"
  notes: |
    Enhanced schema with inactivation audit trail:
    - inactivation_reason: Why was question inactivated
    - inactivated_by_change_id: Which change triggered inactivation (logical FK)
    - inactivated_at: When was question inactivated
    See: faq_impact/database/sql/schema/INACTIVATION_COLUMNS_DESIGN.md
```

## Foreign Key Validation Strategy

### Database Level (Not Used)
```sql
-- NOT USED: SQLite/Databricks don't enforce FKs reliably
-- FOREIGN KEY (inactivated_by_change_id) REFERENCES content_change_log(change_id)
```

### Application Level (Used)
```python
# Validation before insert/update
def validate_change_id_exists(question: dict, db_connection) -> None:
    change_id = question.get('inactivated_by_change_id')
    if change_id is not None:
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM content_change_log WHERE change_id = ?",
            (change_id,)
        )
        if cursor.fetchone()[0] == 0:
            raise ValidationError(f"Invalid change_id: {change_id}")
```

See [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) for complete implementation.

## Impact on Schema Management

### SchemaManager Considerations
If you have a SchemaManager class that reads dependency_graph.yaml:

**Option A: No Changes Needed**
- Keep current implementation
- FK validation happens in application layer
- No schema manager changes required

**Option B: Add Logical Dependency Support**
```python
class SchemaManager:
    def validate_logical_dependencies(self):
        """Validate application-level FK relationships."""
        # Check that logical dependencies are documented
        # but don't enforce creation order
        pass

    def get_table_notes(self, table_name: str) -> dict:
        """Return notes including logical dependencies."""
        # Include logical_dependencies in metadata
        pass
```

## Related Tables

### Tables Referenced By faq_questions (NEW)
- `content_change_log` (logical FK via inactivated_by_change_id)

### Tables That Reference faq_questions (Existing)
- `faq_answers` (FK via question_id) - CASCADE DELETE
- `faq_question_sources` (FK via question_id)

### Complete Dependency Chain
```
content_repo (0)
  └─> content_chunks (1)
        ├─> faq_questions (2)
        │     ├─> faq_answers (3)
        │     │     └─> faq_answer_sources (5)
        │     └─> faq_question_sources (4)
        └─> content_change_log (6)
              └─> faq_questions.inactivated_by_change_id (NEW, logical)
```

**Note**: The logical FK from faq_questions back to content_change_log creates a "soft cycle" but this is OK since:
1. It's application-level only
2. It's nullable (not required for all questions)
3. It references past changes (temporal, not structural)

## Testing Recommendations

### Dependency Validation Tests
```python
def test_faq_questions_can_be_created_before_change_log():
    """Verify faq_questions doesn't require content_change_log to exist."""
    # Create faq_questions table
    # Should succeed even if content_change_log doesn't exist yet
    pass

def test_inactivated_by_change_id_validated_at_runtime():
    """Verify change_id validation happens in application code."""
    # Try to set invalid change_id
    # Should raise ValidationError from application, not database
    pass

def test_null_change_id_allowed():
    """Verify inactivated_by_change_id can be NULL."""
    # Create inactive question with change_id=NULL and reason=MANUAL
    # Should succeed
    pass
```

## Migration Impact

### Schema Migration
- **No impact**: Enhanced schema is backward compatible
- New columns added with ALTER TABLE (see MIGRATION_GUIDE.md)
- Existing rows have NULL for new columns (correct for active questions)

### Dependency Graph Updates
- **No file changes required**: dependency_graph.yaml doesn't need updates
- Optional: Add notes about logical FK for documentation
- SchemaManager code unchanged

## Documentation Cross-References

Related documentation:
- [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) - Column design
- [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) - Application-level FK validation
- [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) - Schema migration steps
- [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) - Enhanced schema
- `database/sql/schema/_meta/dependency_graph.yaml` - Main dependency graph

## Conclusion

**Summary**:
- Enhanced faq_questions has a **logical FK** to content_change_log
- FK is **application-level** (not database-enforced)
- **No changes needed** to dependency_graph.yaml or creation order
- **Optional**: Add notes to document logical dependency

**Recommendation**: Keep current schema creation order; document logical FK in table notes.

## Version History
- 2025-11-02: Initial dependency analysis (Item 60)

## Authors
Analytics Assist Team
