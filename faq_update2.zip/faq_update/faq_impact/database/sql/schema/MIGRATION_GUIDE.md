# Migration Guide: faq_questions Table Enhancement

## Overview
This guide provides step-by-step instructions for migrating the `faq_questions` table from the original schema to the enhanced schema with inactivation tracking.

**Target Tables**: `faq_questions`
**New Columns**: `inactivation_reason`, `inactivated_by_change_id`, `inactivated_at`
**Impact**: Low - Only adds columns, no data transformation required

## Migration Strategy

### Approach
Use SQLite's `ALTER TABLE ADD COLUMN` capability to add new columns to the existing table.

**Advantages**:
- No data migration required
- Minimal downtime
- Preserves all existing data and indexes
- Backward compatible (existing queries unaffected)

**Limitations**:
- SQLite cannot add NOT NULL columns without a DEFAULT value
- All new columns must be nullable (validation handled by application)

## Prerequisites

### 1. Backup Database
```bash
# Create a backup before migration
cp faq_database.db faq_database_backup_$(date +%Y%m%d_%H%M%S).db

# Or use SQLite backup command
sqlite3 faq_database.db ".backup faq_database_backup.db"
```

### 2. Verify Current Schema
```sql
-- Check current table structure
PRAGMA table_info(faq_questions);

-- Expected output (original schema):
-- cid | name              | type     | notnull | dflt_value | pk
-- 0   | question_id       | TEXT     | 0       | NULL       | 1
-- 1   | question_text     | TEXT     | 1       | NULL       | 0
-- 2   | source_type       | TEXT     | 0       | NULL       | 0
-- 3   | generation_method | TEXT     | 0       | NULL       | 0
-- 4   | status            | TEXT     | 1       | 'active'   | 0
-- 5   | created_at        | DATETIME | 1       | CURRENT_TIMESTAMP | 0
-- 6   | modified_at       | DATETIME | 1       | CURRENT_TIMESTAMP | 0
```

### 3. Check for Active Transactions
```sql
-- Ensure no other connections have open transactions
-- Close all other database connections before migration
```

## Migration Steps

### Step 1: Add inactivation_reason Column
```sql
-- Add inactivation_reason column
ALTER TABLE faq_questions
ADD COLUMN inactivation_reason TEXT;

-- Verify column added
PRAGMA table_info(faq_questions);
-- Should show new column with type=TEXT, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values (correct for active questions)
SELECT COUNT(*) as total_questions,
       SUM(CASE WHEN inactivation_reason IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_questions;
-- null_count should equal total_questions
```

### Step 2: Add inactivated_by_change_id Column
```sql
-- Add inactivated_by_change_id column
ALTER TABLE faq_questions
ADD COLUMN inactivated_by_change_id INTEGER;

-- Verify column added
PRAGMA table_info(faq_questions);
-- Should show new column with type=INTEGER, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values
SELECT COUNT(*) as total_questions,
       SUM(CASE WHEN inactivated_by_change_id IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_questions;
-- null_count should equal total_questions
```

### Step 3: Add inactivated_at Column
```sql
-- Add inactivated_at column
ALTER TABLE faq_questions
ADD COLUMN inactivated_at DATETIME;

-- Verify column added
PRAGMA table_info(faq_questions);
-- Should show new column with type=DATETIME, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values
SELECT COUNT(*) as total_questions,
       SUM(CASE WHEN inactivated_at IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_questions;
-- null_count should equal total_questions
```

### Step 4: Create New Indexes
```sql
-- Create index on inactivation_reason
CREATE INDEX IF NOT EXISTS idx_faq_questions_inactivation_reason
    ON faq_questions(inactivation_reason);

-- Create composite index on status and inactivation fields
CREATE INDEX IF NOT EXISTS idx_faq_questions_status_inactivation
    ON faq_questions(status, inactivation_reason, inactivated_at);

-- Verify indexes created
SELECT name, sql
FROM sqlite_master
WHERE type = 'index'
  AND tbl_name = 'faq_questions'
ORDER BY name;
```

**Expected Indexes**:
- `idx_faq_questions_created`
- `idx_faq_questions_inactivation_reason` (NEW)
- `idx_faq_questions_source_type`
- `idx_faq_questions_status`
- `idx_faq_questions_status_inactivation` (NEW)

### Step 5: Verify Schema Consistency
```sql
-- Verify all active questions have NULL inactivation fields
SELECT COUNT(*) as active_questions_with_invalid_state
FROM faq_questions
WHERE status = 'active'
  AND (inactivation_reason IS NOT NULL
       OR inactivated_by_change_id IS NOT NULL
       OR inactivated_at IS NOT NULL);
-- Should return 0

-- Verify table structure matches expected schema
PRAGMA table_info(faq_questions);
-- Should show 10 columns total (7 original + 3 new)
```

### Step 6: Update Application Code
After database migration, update application code to:
1. Use new inactivation fields when marking questions inactive
2. Validate consistency rules (see VALIDATION_LOGIC.md)
3. Include inactivation fields in audit queries

**No code changes required for existing functionality** - new columns are NULL for active questions.

## Complete Migration Script

```sql
-- ============================================================================
-- MIGRATION SCRIPT: Add Inactivation Tracking to faq_questions
-- ============================================================================
-- Purpose: Enhance faq_questions table with inactivation audit trail
-- Date: 2025-11-02
-- Author: Analytics Assist Team
-- ============================================================================

-- Transaction wrapper for atomic migration
BEGIN TRANSACTION;

-- Step 1: Add inactivation_reason column
ALTER TABLE faq_questions
ADD COLUMN inactivation_reason TEXT;

-- Step 2: Add inactivated_by_change_id column
ALTER TABLE faq_questions
ADD COLUMN inactivated_by_change_id INTEGER;

-- Step 3: Add inactivated_at column
ALTER TABLE faq_questions
ADD COLUMN inactivated_at DATETIME;

-- Step 4: Create new indexes
CREATE INDEX IF NOT EXISTS idx_faq_questions_inactivation_reason
    ON faq_questions(inactivation_reason);

CREATE INDEX IF NOT EXISTS idx_faq_questions_status_inactivation
    ON faq_questions(status, inactivation_reason, inactivated_at);

-- Step 5: Verify migration
-- All existing rows should have NULL for new columns (correct for active questions)
SELECT
    'Migration Verification' as check_name,
    COUNT(*) as total_questions,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count,
    SUM(CASE WHEN inactivation_reason IS NOT NULL THEN 1 ELSE 0 END) as with_reason,
    SUM(CASE WHEN inactivated_by_change_id IS NOT NULL THEN 1 ELSE 0 END) as with_change_id,
    SUM(CASE WHEN inactivated_at IS NOT NULL THEN 1 ELSE 0 END) as with_timestamp
FROM faq_questions;
-- Expected: with_reason, with_change_id, with_timestamp should all be 0

COMMIT;

-- ============================================================================
-- POST-MIGRATION VERIFICATION
-- ============================================================================

-- Verify table structure
PRAGMA table_info(faq_questions);
-- Should show 10 columns

-- Verify indexes
SELECT name FROM sqlite_master
WHERE type = 'index' AND tbl_name = 'faq_questions'
ORDER BY name;
-- Should show 5 indexes

-- Verify no data corruption
SELECT COUNT(*) as total_questions FROM faq_questions;
-- Should match pre-migration count

-- ============================================================================
-- END OF MIGRATION SCRIPT
-- ============================================================================
```

## Rollback Procedure

### If Migration Fails (Before COMMIT)
```sql
-- Simply rollback the transaction
ROLLBACK;
```

### If Migration Succeeds But Issues Found (After COMMIT)
SQLite has limited ALTER TABLE support. Cannot easily drop columns.

**Option 1: Keep columns, ignore in application**
```sql
-- Do nothing - columns remain but are not used
-- Application code ignores new columns
-- Low risk, no data loss
```

**Option 2: Full table recreation (COMPLEX - Not Recommended)**
```sql
-- WARNING: High risk operation, only if absolutely necessary
-- Requires rebuilding table without new columns

BEGIN TRANSACTION;

-- 1. Create original schema table with temporary name
CREATE TABLE faq_questions_old AS
SELECT
    question_id,
    question_text,
    source_type,
    generation_method,
    status,
    created_at,
    modified_at
FROM faq_questions;

-- 2. Drop enhanced table
DROP TABLE faq_questions;

-- 3. Rename old table back
ALTER TABLE faq_questions_old RENAME TO faq_questions;

-- 4. Recreate original indexes
CREATE INDEX IF NOT EXISTS idx_faq_questions_status ON faq_questions(status);
CREATE INDEX IF NOT EXISTS idx_faq_questions_source_type ON faq_questions(source_type);
CREATE INDEX IF NOT EXISTS idx_faq_questions_created ON faq_questions(created_at);

COMMIT;
```

**Recommendation**: Use Option 1 (keep columns) unless critical issue. Option 2 has high risk of data loss.

## Testing Recommendations

### Pre-Migration Testing (Development Environment)
1. Restore production backup to development database
2. Run migration script on development database
3. Verify schema with PRAGMA table_info
4. Verify indexes with SELECT from sqlite_master
5. Run sample queries to ensure performance
6. Test application code with enhanced schema

### Post-Migration Testing (Production)
1. Verify schema matches expected structure
2. Check all existing queries still work
3. Test inactivation workflow end-to-end
4. Monitor query performance on new indexes
5. Verify application validation logic

## Migration Checklist

- [ ] Backup current database
- [ ] Verify current schema structure
- [ ] Close all other database connections
- [ ] Run migration script (in transaction)
- [ ] Verify schema with PRAGMA table_info
- [ ] Verify indexes created
- [ ] Verify no data corruption (row count matches)
- [ ] Verify all active questions have NULL inactivation fields
- [ ] Test sample queries (SELECT with new columns)
- [ ] Update application code to use new fields
- [ ] Test inactivation workflow
- [ ] Monitor production for issues
- [ ] Document migration completion

## Databricks Migration

### Differences from SQLite
Databricks Delta Lake has more flexible ALTER TABLE support:

```sql
-- Add columns (similar to SQLite)
ALTER TABLE faq_questions
ADD COLUMNS (
    inactivation_reason STRING,
    inactivated_by_change_id INT,
    inactivated_at TIMESTAMP
);

-- Create indexes (slightly different syntax)
-- Note: Databricks uses CREATE INDEX without IF NOT EXISTS
CREATE INDEX idx_faq_questions_inactivation_reason
    ON faq_questions(inactivation_reason);

CREATE INDEX idx_faq_questions_status_inactivation
    ON faq_questions(status, inactivation_reason, inactivated_at);
```

### Databricks Considerations
1. ALTER TABLE ADD COLUMNS supports multiple columns in single statement
2. Indexes created differently (no IF NOT EXISTS)
3. TIMESTAMP type instead of DATETIME
4. Foreign keys are metadata only (not enforced)

## Frequently Asked Questions

### Q: Will this break existing queries?
**A**: No. New columns are nullable and default to NULL. Existing queries that don't reference new columns will work unchanged.

### Q: Do I need to migrate data?
**A**: No. Existing questions are all active, so NULL values for inactivation fields are correct.

### Q: What if I have inactive questions already?
**A**: After migration, you'll need to backfill inactivation data if you have questions with status='inactive'. Create a manual script to set inactivation_reason='MANUAL' and inactivated_at=modified_at for these questions.

### Q: Can I run this migration on a production database?
**A**: Yes, but follow best practices:
1. Schedule during low-traffic period
2. Backup first
3. Test in development environment first
4. Use transaction to enable rollback
5. Monitor closely after migration

### Q: How long will migration take?
**A**: Very fast - ALTER TABLE ADD COLUMN is a metadata operation in SQLite. Even with millions of rows, should complete in seconds.

### Q: Will this impact performance?
**A**: Minimal impact. New indexes may slightly increase INSERT/UPDATE time, but improve query performance for inactivation reporting.

## Related Documentation
- [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) - Design rationale
- [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) - Enhanced schema
- [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) - Application validation rules

## Version History
- 2025-11-02: Initial migration guide (Item 57)

## Authors
Analytics Assist Team
