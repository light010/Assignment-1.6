-- ============================================================================
-- TABLE: faq_questions (SQLite) - Enhanced with Inactivation Tracking
-- ============================================================================
-- Description: FAQ questions - content-agnostic with full inactivation audit trail
-- Dependencies: None (independent of content)
--               Logical FK to content_change_log (application-level validation)
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Questions can exist without answers (draft state)
--              Questions track inactivation reason, trigger change, and timestamp
--
-- Enhancement: Added inactivation tracking columns for audit trail
--              - inactivation_reason: WHY was the question inactivated
--              - inactivated_by_change_id: WHICH content change triggered it
--              - inactivated_at: WHEN was it inactivated
--
-- SQLite Features Used:
--   - TEXT PRIMARY KEY (no autoincrement - using custom IDs)
--   - CHECK constraints for status validation (application-level)
--   - DEFAULT values supported
--   - DATETIME stored as TEXT in ISO-8601 format
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_questions (
    -- Primary Identity
    question_id TEXT PRIMARY KEY,

    -- Question Content
    question_text TEXT NOT NULL,

    -- Metadata
    source_type TEXT,  -- 'from_documents', 'from_user_queries', 'from_manual', 'from_validation'
    generation_method TEXT,  -- 'llm_generated', 'human_written', 'extracted'

    -- Status
    status TEXT NOT NULL DEFAULT 'active',             -- 'active', 'inactive'
                                                       -- Status validation handled by application code

    -- ========================================================================
    -- INACTIVATION TRACKING (Added in Phase 2)
    -- ========================================================================
    -- Purpose: Full audit trail for why/when/how questions were inactivated
    -- Consistency Rules (enforced by application code):
    --   1. If status='active': all inactivation fields MUST be NULL
    --   2. If status='inactive': inactivation_reason and inactivated_at MUST be NOT NULL
    --   3. If status='inactive' AND inactivation_reason != 'MANUAL':
    --        inactivated_by_change_id MUST be NOT NULL
    --   4. If status='inactive' AND inactivation_reason = 'MANUAL':
    --        inactivated_by_change_id is OPTIONAL (may be NULL)
    -- ========================================================================

    inactivation_reason TEXT,                          -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Valid values (application-enforced):
                                                       --   'CONTENT_DELETED' - Source content deleted
                                                       --   'ALL_SOURCES_INVALID' - All sources invalid
                                                       --   'MANUAL' - Manual inactivation
                                                       --   'QUALITY_ISSUE' - Quality check failed
                                                       -- See: InactivationReason enum

    inactivated_by_change_id INTEGER,                  -- NULL when active
                                                       -- NULL when inactivation_reason='MANUAL' (optional)
                                                       -- NOT NULL for other inactivation reasons
                                                       -- Logical FK to content_change_log.change_id
                                                       -- (application-level validation only)

    inactivated_at DATETIME,                           -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Timestamp of inactivation (ISO-8601 format)

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- CONSTRAINTS
-- ============================================================================
-- Note: All constraint validation handled by application code to match
--       Databricks limitations and maintain consistency across backends
--
-- Application-Level Constraints:
--   1. status IN ('active', 'inactive')
--   2. inactivation_reason IN ('CONTENT_DELETED', 'ALL_SOURCES_INVALID', 'MANUAL', 'QUALITY_ISSUE') OR NULL
--   3. Consistency rules (see inactivation tracking section above)
--   4. inactivated_by_change_id references content_change_log.change_id (when NOT NULL)
-- ============================================================================

-- ============================================================================
-- INDEXES
-- ============================================================================
-- Core indexes (original schema)
CREATE INDEX IF NOT EXISTS idx_faq_questions_status ON faq_questions(status);
CREATE INDEX IF NOT EXISTS idx_faq_questions_source_type ON faq_questions(source_type);
CREATE INDEX IF NOT EXISTS idx_faq_questions_created ON faq_questions(created_at);

-- ============================================================================
-- INACTIVATION TRACKING INDEXES (Added in Phase 2)
-- ============================================================================

-- Single-column index for filtering by inactivation reason
-- Use case: "Show all questions inactivated due to CONTENT_DELETED"
-- Query pattern: WHERE inactivation_reason = 'CONTENT_DELETED'
CREATE INDEX IF NOT EXISTS idx_faq_questions_inactivation_reason
    ON faq_questions(inactivation_reason);

-- Composite index for audit and reporting queries
-- Use case: "Show all inactive questions, grouped by reason, sorted by time"
-- Query pattern: WHERE status='inactive' ORDER BY inactivation_reason, inactivated_at
-- Query pattern: WHERE status='inactive' AND inactivation_reason='X' ORDER BY inactivated_at
-- Query pattern: WHERE status='active' (NULL filtering for inactivation_reason)
--
-- Index column order rationale:
--   1. status - Most selective filter (active vs inactive)
--   2. inactivation_reason - Common grouping/filtering
--   3. inactivated_at - Common sorting for temporal analysis
CREATE INDEX IF NOT EXISTS idx_faq_questions_status_inactivation
    ON faq_questions(status, inactivation_reason, inactivated_at);

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

-- Example 1: Inactivate a question due to content deletion
-- UPDATE faq_questions
-- SET status = 'inactive',
--     inactivation_reason = 'CONTENT_DELETED',
--     inactivated_by_change_id = 12345,
--     inactivated_at = CURRENT_TIMESTAMP,
--     modified_at = CURRENT_TIMESTAMP
-- WHERE question_id = 'Q001';

-- Example 2: Find all questions inactivated by a specific change
-- SELECT
--     q.question_id,
--     q.question_text,
--     q.inactivation_reason,
--     q.inactivated_at,
--     ccl.change_type,
--     ccl.file_name
-- FROM faq_questions q
-- INNER JOIN content_change_log ccl ON q.inactivated_by_change_id = ccl.change_id
-- WHERE q.inactivated_by_change_id = 12345;

-- Example 3: Audit report - questions inactivated in last 7 days
-- SELECT
--     inactivation_reason,
--     COUNT(*) as question_count,
--     MIN(inactivated_at) as first_inactivation,
--     MAX(inactivated_at) as last_inactivation
-- FROM faq_questions
-- WHERE status = 'inactive'
--   AND inactivated_at >= datetime('now', '-7 days')
-- GROUP BY inactivation_reason
-- ORDER BY question_count DESC;

-- Example 4: Find active questions (uses composite index efficiently)
-- SELECT question_id, question_text
-- FROM faq_questions
-- WHERE status = 'active'
-- ORDER BY created_at DESC;

-- Example 5: Find all inactive questions with their triggering changes
-- SELECT
--     q.question_id,
--     q.question_text,
--     q.inactivation_reason,
--     q.inactivated_at,
--     ccl.change_id,
--     ccl.change_type,
--     ccl.file_name,
--     ccl.detection_timestamp
-- FROM faq_questions q
-- LEFT JOIN content_change_log ccl ON q.inactivated_by_change_id = ccl.change_id
-- WHERE q.status = 'inactive'
-- ORDER BY q.inactivated_at DESC;

-- ============================================================================
-- MIGRATION NOTES
-- ============================================================================
-- To migrate from original schema to enhanced schema:
--   1. Add new columns using ALTER TABLE (SQLite supports adding columns)
--   2. Existing rows will have NULL values for new columns (correct for active questions)
--   3. No data migration needed (all existing questions are active)
--   4. See MIGRATION_GUIDE.md for detailed step-by-step instructions
--
-- SQLite ALTER TABLE limitations:
--   - Can ADD columns
--   - Cannot DROP columns (requires table recreation)
--   - Cannot modify column types (requires table recreation)
--   - Cannot add NOT NULL constraints without DEFAULT (use application validation)
-- ============================================================================

-- ============================================================================
-- DATABRICKS COMPATIBILITY
-- ============================================================================
-- This schema is compatible with Databricks Delta Lake with these mappings:
--   - TEXT → STRING
--   - INTEGER → INT
--   - DATETIME → TIMESTAMP
--   - CREATE INDEX IF NOT EXISTS → CREATE INDEX (remove IF NOT EXISTS)
--
-- Foreign key relationships:
--   - Databricks supports FK syntax but does NOT enforce (metadata only)
--   - Application-level validation required for referential integrity
-- ============================================================================

-- ============================================================================
-- RELATED DOCUMENTATION
-- ============================================================================
-- - INACTIVATION_COLUMNS_DESIGN.md: Design rationale and specifications
-- - MIGRATION_GUIDE.md: Step-by-step migration from old schema
-- - VALIDATION_LOGIC.md: Application-level validation rules
-- - ../../core/enums/entity_type.py: InactivationReason enum definition
-- - 06_content_change_log.sql: Referenced table (logical FK)
-- ============================================================================

-- ============================================================================
-- VERSION HISTORY
-- ============================================================================
-- 2025-11-02: Enhanced schema with inactivation tracking (Phase 2, Items 53-56)
-- Original:   Basic faq_questions schema (Phase 1)
-- ============================================================================
