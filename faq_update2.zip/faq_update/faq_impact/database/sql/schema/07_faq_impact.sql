-- ============================================================================
-- TABLE: faq_impact (SQLite) - Impact Analysis and Application Tracking
-- ============================================================================
-- Description: Tracks impact decisions and their execution status for FAQ updates
-- Dependencies: Logical FK to content_change_log.change_id
--               Logical FK to faq_questions.question_id (when entity_type='QUESTION')
--               Logical FK to faq_answers.answer_id (when entity_type='ANSWER')
-- Owner: Analytics Assist Team
--
-- Key Concept: Separates ANALYSIS (read-only planning) from APPLICATION (mutation execution)
--              - Analysis Phase: Analyze content changes, create impact decisions (read-only)
--              - Apply Plan Phase: Execute selected decisions, mutate FAQ tables
--              - Append-only design: New decisions added, never updated (audit trail)
--
-- Design Philosophy:
--   1. Impact decisions are immutable once created (append-only)
--   2. Each decision has: WHAT (decision), WHY (reason), HOW (details)
--   3. Execution tracking: applied flag, timestamps, errors
--   4. No unique constraints (allows historical analysis records)
--   5. Partial unique index prevents duplicate PENDING decisions
--
-- SQLite Features Used:
--   - INTEGER PRIMARY KEY AUTOINCREMENT
--   - CHECK constraints for validation (application-level)
--   - Partial unique index (SQLite 3.8+) for duplicate prevention
--   - JSON stored as TEXT (application parses)
--   - DATETIME stored as TEXT in ISO-8601 format
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_impact (
    -- ========================================================================
    -- PRIMARY STRUCTURE (Item 71)
    -- ========================================================================
    -- Purpose: Core identity and relationship tracking
    -- Links impact decisions to content changes and affected entities
    -- ========================================================================

    -- Primary Identity
    impact_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Entity Classification
    -- Identifies WHAT entity this decision applies to
    entity_type TEXT NOT NULL,                         -- EntityType enum
                                                       -- Valid values (application-enforced):
                                                       --   'QUESTION' - Decision applies to a question
                                                       --   'ANSWER'   - Decision applies to an answer
                                                       --   'CHANGE'   - Decision applies to change itself
                                                       -- See: EntityType enum in core/enums/entity_type.py

    -- Entity Identity
    -- Identifies WHICH specific entity (can be NULL for new creations)
    entity_id TEXT NOT NULL,                           -- Polymorphic reference based on entity_type:
                                                       --   entity_type='QUESTION' → faq_questions.question_id
                                                       --   entity_type='ANSWER'   → faq_answers.answer_id
                                                       --   entity_type='CHANGE'   → content_change_log.change_id (as TEXT)
                                                       -- NULL allowed for PLAN_CREATE (entity doesn't exist yet)
                                                       -- Application-level validation for referential integrity

    -- Change Tracking
    -- Links decision to triggering content change
    change_id INTEGER NOT NULL,                        -- Logical FK to content_change_log.change_id
                                                       -- The content change that triggered this decision
                                                       -- Application-level validation only

    -- Detection Run Tracking
    -- Groups decisions by analysis run (batch processing)
    detection_run_id TEXT NOT NULL,                    -- Identifies the analysis run that created this decision
                                                       -- Format: 'RUN_YYYYMMDD_HHMMSS' or UUID
                                                       -- Enables querying all decisions from a single run

    -- ========================================================================
    -- DECISION COLUMNS (Item 72)
    -- ========================================================================
    -- Purpose: Captures WHAT action to take and WHY
    -- Decision logic is documented in analysis strategies
    -- ========================================================================

    -- Decision Type
    -- WHAT action should be taken
    decision TEXT NOT NULL,                            -- DecisionType enum
                                                       -- Valid values (application-enforced):
                                                       --   'PLAN_CREATE'  - Create new question from new content
                                                       --   'REGEN_Q'      - Regenerate question only
                                                       --   'REGEN_A'      - Regenerate answer only
                                                       --   'REGEN_BOTH'   - Regenerate both Q and A
                                                       --   'INACTIVATE'   - Mark question/answer as inactive
                                                       --   'EVALUATE'     - Needs LLM evaluation to decide
                                                       --   'NOOP'         - No operation needed
                                                       -- See: DecisionType enum in core/enums/decision_type.py

    -- Reason Code
    -- WHY this decision was made
    reason TEXT NOT NULL,                              -- ReasonCode enum
                                                       -- Valid values depend on decision type
                                                       -- Examples:
                                                       --   decision='PLAN_CREATE' → reason='NEW_CONTENT_ADDED'
                                                       --   decision='REGEN_A'     → reason='TOKEN_OVERLAP_DETECTED'
                                                       --   decision='INACTIVATE'  → reason='CONTENT_DELETED'
                                                       -- See: ReasonCode enum in core/enums/reason_code.py
                                                       -- Validation: ReasonCode.is_compatible(decision, reason)

    -- Decision Details
    -- HOW to execute the decision (decision-specific metadata)
    details TEXT,                                      -- JSON blob (stored as TEXT in SQLite)
                                                       -- Structure varies by decision type
                                                       -- See: FAQ_IMPACT_DETAILS_SCHEMA.md for JSON schemas
                                                       -- Examples:
                                                       --   PLAN_CREATE: {"content_id": "chunk123", "source_type": "pdf"}
                                                       --   REGEN_A: {"overlap_score": 0.75, "affected_sources": ["s1", "s2"]}
                                                       --   INACTIVATE: {"inactivation_reason": "CONTENT_DELETED"}
                                                       -- NULL allowed for simple decisions (e.g., NOOP)

    -- ========================================================================
    -- EXECUTION TRACKING COLUMNS (Item 73)
    -- ========================================================================
    -- Purpose: Track whether and how decisions were executed
    -- Enables idempotent re-application, error recovery, and audit trails
    -- ========================================================================

    -- Application Status
    -- Has this decision been executed?
    applied INTEGER NOT NULL DEFAULT 0,                -- SQLite boolean (0 = pending, 1 = applied)
                                                       -- 0 = Decision created but not yet executed
                                                       -- 1 = Decision successfully executed
                                                       -- Idempotent: Can re-run apply plan, already-applied skipped

    -- Application Timestamp
    -- WHEN was the decision executed?
    applied_at DATETIME,                               -- NULL when applied=0
                                                       -- NOT NULL when applied=1
                                                       -- ISO-8601 format: '2025-11-02T14:30:00Z'
                                                       -- Constraint (application-enforced):
                                                       --   IF applied=1 THEN applied_at NOT NULL

    -- Application Actor
    -- WHO executed the decision?
    applied_by TEXT,                                   -- NULL when applied=0
                                                       -- Optional when applied=1 (may be 'system')
                                                       -- Values: username, 'system', 'batch_process', etc.
                                                       -- Used for audit trails and accountability

    -- Application Error
    -- Error message if execution failed
    application_error TEXT,                            -- NULL when successful or not attempted
                                                       -- NOT NULL if execution failed
                                                       -- Stores exception message, stack trace, or error code
                                                       -- Enables debugging failed applications
                                                       -- Note: Failed applications have applied=0, error NOT NULL

    -- ========================================================================
    -- TIMESTAMPS AND METADATA (Item 74)
    -- ========================================================================
    -- Purpose: Track record lifecycle and cost estimation
    -- Matches existing table patterns (02_faq_questions, 03_faq_answers)
    -- ========================================================================

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                                       -- When impact decision was created (analysis phase)
                                                       -- Immutable (append-only design)
                                                       -- ISO-8601 format

    modified_at DATETIME,                              -- When record was last modified
                                                       -- Updated when applied flag changes
                                                       -- NULL if never modified after creation
                                                       -- Note: Append-only design means rare updates

    -- Cost Estimation
    estimated_cost REAL,                               -- Estimated cost to execute this decision
                                                       -- Units: USD or API tokens
                                                       -- NULL if cost not estimated
                                                       -- Used for budgeting before apply plan execution
                                                       -- Examples:
                                                       --   PLAN_CREATE: ~$0.05 (LLM generation)
                                                       --   REGEN_A: ~$0.03 (answer regeneration)
                                                       --   INACTIVATE: $0 (simple UPDATE)
                                                       -- See: config/cost_estimates.py

    -- Priority
    priority INTEGER,                                  -- Execution priority (higher = more important)
                                                       -- NULL = default priority
                                                       -- Range: 1-10 (application-enforced)
                                                       -- Used to order execution in apply plan phase
                                                       -- Examples:
                                                       --   INACTIVATE (deleted content): priority=10 (high)
                                                       --   REGEN_A (minor change): priority=5 (medium)
                                                       --   EVALUATE: priority=1 (low, deferred)
                                                       -- Constraint (application-enforced):
                                                       --   priority BETWEEN 1 AND 10 OR NULL
);

-- ============================================================================
-- CONSTRAINTS
-- ============================================================================
-- Note: All constraint validation handled by application code to match
--       Databricks limitations and maintain consistency across backends
--
-- Application-Level Constraints:
--   1. entity_type IN ('QUESTION', 'ANSWER', 'CHANGE')
--   2. decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE', 'EVALUATE', 'NOOP')
--   3. reason IN (valid ReasonCode values) - see ReasonCode enum
--   4. ReasonCode.is_compatible(decision, reason) = TRUE
--   5. applied IN (0, 1)
--   6. IF applied=1 THEN applied_at NOT NULL
--   7. priority BETWEEN 1 AND 10 OR NULL
--   8. details is valid JSON OR NULL
--   9. change_id references content_change_log.change_id (when NOT NULL)
--   10. entity_id references appropriate table based on entity_type:
--       - entity_type='QUESTION' → faq_questions.question_id
--       - entity_type='ANSWER'   → faq_answers.answer_id
--       - entity_type='CHANGE'   → content_change_log.change_id
--   11. Polymorphic validation logic in repository layer
--
-- See: core/enums/validators.py for validation functions
-- See: database/repository/impact_repository.py for enforcement
-- ============================================================================

-- ============================================================================
-- INDEXES (Items 76-77, 80)
-- ============================================================================

-- ============================================================================
-- SINGLE-COLUMN INDEXES (Item 76)
-- ============================================================================
-- Purpose: Support common query patterns for filtering and joining

-- Index for filtering by change_id
-- Use case: "Get all impact decisions for change 12345"
-- Query pattern: WHERE change_id = 12345
CREATE INDEX IF NOT EXISTS idx_faq_impact_change
    ON faq_impact(change_id);

-- Index for filtering by detection_run_id
-- Use case: "Get all decisions from analysis run RUN_20251102_143000"
-- Query pattern: WHERE detection_run_id = 'RUN_20251102_143000'
CREATE INDEX IF NOT EXISTS idx_faq_impact_run
    ON faq_impact(detection_run_id);

-- Composite index for filtering by entity
-- Use case: "Get all decisions for question Q123"
-- Query pattern: WHERE entity_type = 'QUESTION' AND entity_id = 'Q123'
-- Index column order: entity_type first (low cardinality), entity_id second (high cardinality)
CREATE INDEX IF NOT EXISTS idx_faq_impact_entity
    ON faq_impact(entity_type, entity_id);

-- Composite index for filtering by decision and application status
-- Use case: "Get all pending REGEN_A decisions"
-- Use case: "Get all applied INACTIVATE decisions"
-- Query pattern: WHERE decision = 'REGEN_A' AND applied = 0
-- Query pattern: WHERE decision = 'INACTIVATE' AND applied = 1
CREATE INDEX IF NOT EXISTS idx_faq_impact_decision
    ON faq_impact(decision, applied);

-- ============================================================================
-- COMPOSITE INDEX FOR APPLY PLAN QUERIES (Item 77)
-- ============================================================================
-- Purpose: Optimize "get pending actions to apply" workflow
-- This is the CRITICAL query for the Apply Plan phase

-- Composite index for Apply Plan workflow
-- Use case: "Get all pending decisions for change 12345, ordered by priority"
-- Query pattern:
--   SELECT impact_id, entity_type, entity_id, decision, reason, details, priority
--   FROM faq_impact
--   WHERE change_id = 12345
--     AND applied = 0
--     AND decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE')
--   ORDER BY priority DESC, impact_id ASC
--
-- Index column order rationale:
--   1. change_id - Most selective filter (specific change)
--   2. applied - Binary filter (pending vs applied)
--   3. decision - Filter out EVALUATE/NOOP
--   4. impact_id - Provides deterministic ordering
--
-- Query plan analysis:
--   - Seek on change_id (very selective)
--   - Filter on applied=0 (removes ~50% of rows)
--   - Filter on decision (removes EVALUATE/NOOP)
--   - Return rows in impact_id order
--   - Application sorts by priority (small result set)
CREATE INDEX IF NOT EXISTS idx_faq_impact_apply
    ON faq_impact(change_id, applied, decision, impact_id);

-- ============================================================================
-- PARTIAL UNIQUE INDEX FOR DUPLICATE PREVENTION (Item 80)
-- ============================================================================
-- Purpose: Prevent duplicate pending impact decisions
-- Rationale: Same entity + change + decision shouldn't exist twice in PENDING state
-- Historical records: Allow duplicates for applied=1 (audit trail)

-- Partial unique index for preventing duplicate pending impacts
-- Use case: Prevent creating duplicate "REGEN_A for answer A123 due to change 999"
-- Constraint: UNIQUE(entity_type, entity_id, change_id, decision) WHERE applied = 0
-- SQLite 3.8+ feature: Partial indexes with WHERE clause
--
-- How it works:
--   - When applied=0 (PENDING): Index enforces uniqueness
--   - When applied=1 (APPLIED): Row not in index, no uniqueness check
--   - Allows historical records of same decision being applied multiple times
--
-- Example:
--   INSERT #1: (entity_type='ANSWER', entity_id='A123', change_id=999, decision='REGEN_A', applied=0)
--     → SUCCESS (first pending decision)
--   INSERT #2: (entity_type='ANSWER', entity_id='A123', change_id=999, decision='REGEN_A', applied=0)
--     → ERROR (duplicate pending decision - UNIQUE constraint violation)
--   UPDATE #1: SET applied=1, applied_at='2025-11-02T14:30:00Z'
--     → SUCCESS (removes from index)
--   INSERT #3: (entity_type='ANSWER', entity_id='A123', change_id=999, decision='REGEN_A', applied=0)
--     → SUCCESS (no conflict, previous decision applied)
--
-- Edge cases:
--   - Different decisions for same entity: Allowed (e.g., REGEN_A + INACTIVATE)
--   - Same decision for different entities: Allowed (e.g., REGEN_A for A123 and A456)
--   - Same decision applied multiple times historically: Allowed (applied=1 not in index)
CREATE UNIQUE INDEX IF NOT EXISTS idx_faq_impact_unique_pending
    ON faq_impact(entity_type, entity_id, change_id, decision)
    WHERE applied = 0;

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

-- Example 1: Create new impact decision (analysis phase)
-- INSERT INTO faq_impact (
--     entity_type, entity_id, change_id, detection_run_id,
--     decision, reason, details,
--     applied, estimated_cost, priority,
--     created_at
-- ) VALUES (
--     'QUESTION',                              -- entity_type
--     'Q123',                                  -- entity_id
--     12345,                                   -- change_id
--     'RUN_20251102_143000',                   -- detection_run_id
--     'REGEN_Q',                               -- decision
--     'SOLE_SOURCE_MODIFIED_MAJOR',            -- reason
--     '{"similarity_score": 0.65, "token_overlap": 0.72}',  -- details (JSON)
--     0,                                       -- applied (pending)
--     0.04,                                    -- estimated_cost ($0.04)
--     7,                                       -- priority (high)
--     CURRENT_TIMESTAMP                        -- created_at
-- );

-- Example 2: Get all pending decisions for a change (Apply Plan phase)
-- SELECT
--     impact_id,
--     entity_type,
--     entity_id,
--     decision,
--     reason,
--     details,
--     estimated_cost,
--     priority
-- FROM faq_impact
-- WHERE change_id = 12345
--   AND applied = 0
--   AND decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE')
-- ORDER BY priority DESC, impact_id ASC;

-- Example 3: Mark decision as applied (execution tracking)
-- UPDATE faq_impact
-- SET applied = 1,
--     applied_at = CURRENT_TIMESTAMP,
--     applied_by = 'user123',
--     modified_at = CURRENT_TIMESTAMP
-- WHERE impact_id = 456;

-- Example 4: Record application error
-- UPDATE faq_impact
-- SET application_error = 'LLM API timeout after 3 retries',
--     modified_at = CURRENT_TIMESTAMP
-- WHERE impact_id = 789;
-- -- Note: applied remains 0 (not successfully applied)

-- Example 5: Get all decisions for a specific question
-- SELECT
--     i.impact_id,
--     i.decision,
--     i.reason,
--     i.applied,
--     i.applied_at,
--     i.created_at,
--     ccl.change_type,
--     ccl.file_name
-- FROM faq_impact i
-- INNER JOIN content_change_log ccl ON i.change_id = ccl.change_id
-- WHERE i.entity_type = 'QUESTION'
--   AND i.entity_id = 'Q123'
-- ORDER BY i.created_at DESC;

-- Example 6: Get impact summary for a detection run
-- SELECT
--     decision,
--     COUNT(*) as total_decisions,
--     SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as applied_count,
--     SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending_count,
--     SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) as error_count,
--     SUM(estimated_cost) as total_estimated_cost
-- FROM faq_impact
-- WHERE detection_run_id = 'RUN_20251102_143000'
-- GROUP BY decision
-- ORDER BY total_decisions DESC;

-- Example 7: Find failed applications for retry
-- SELECT
--     impact_id,
--     entity_type,
--     entity_id,
--     decision,
--     reason,
--     application_error,
--     created_at
-- FROM faq_impact
-- WHERE applied = 0
--   AND application_error IS NOT NULL
-- ORDER BY created_at DESC;

-- Example 8: Audit trail - all actions taken for a change
-- SELECT
--     i.impact_id,
--     i.entity_type,
--     i.entity_id,
--     i.decision,
--     i.reason,
--     i.applied,
--     i.applied_at,
--     i.applied_by,
--     ccl.change_type,
--     ccl.file_name,
--     ccl.detection_timestamp
-- FROM faq_impact i
-- INNER JOIN content_change_log ccl ON i.change_id = ccl.change_id
-- WHERE i.change_id = 12345
-- ORDER BY i.created_at ASC;

-- Example 9: Get all EVALUATE decisions needing LLM review
-- SELECT
--     impact_id,
--     entity_type,
--     entity_id,
--     change_id,
--     reason,
--     details,
--     created_at
-- FROM faq_impact
-- WHERE decision = 'EVALUATE'
--   AND applied = 0
-- ORDER BY priority DESC, created_at ASC;

-- Example 10: Cost estimation for pending decisions
-- SELECT
--     decision,
--     COUNT(*) as decision_count,
--     SUM(estimated_cost) as total_cost,
--     AVG(estimated_cost) as avg_cost_per_decision
-- FROM faq_impact
-- WHERE applied = 0
--   AND decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH')
-- GROUP BY decision
-- ORDER BY total_cost DESC;

-- ============================================================================
-- DATABRICKS COMPATIBILITY
-- ============================================================================
-- This schema is compatible with Databricks Delta Lake with these mappings:
--   - TEXT → STRING
--   - INTEGER → INT (except PRIMARY KEY)
--   - REAL → DOUBLE
--   - DATETIME → TIMESTAMP
--   - CREATE INDEX IF NOT EXISTS → CREATE INDEX (remove IF NOT EXISTS)
--   - AUTOINCREMENT → GENERATED ALWAYS AS IDENTITY (or use separate sequence)
--
-- Partial unique index (SQLite 3.8+):
--   - Databricks does NOT support partial indexes (WHERE clause)
--   - Alternative: Application-level duplicate detection before INSERT
--   - Or: Use Databricks MERGE with duplicate check in WHEN NOT MATCHED clause
--
-- Foreign key relationships:
--   - Databricks supports FK syntax but does NOT enforce (metadata only)
--   - Application-level validation REQUIRED for referential integrity
--
-- JSON support:
--   - SQLite: JSON stored as TEXT, parsed by application
--   - Databricks: Can use STRING or native JSON type (SQL:2016)
--   - Application handles JSON parsing/serialization for both backends
-- ============================================================================

-- ============================================================================
-- RELATED DOCUMENTATION
-- ============================================================================
-- - FAQ_IMPACT_DETAILS_SCHEMA.md: JSON schema for details column (Item 78)
-- - CHECK_CONSTRAINTS.md: Application-level constraint documentation (Item 79)
-- - IMPLEMENTATION_PLAN.md: Section 2.3 (Items 71-80)
-- - core/enums/entity_type.py: EntityType enum definition
-- - core/enums/decision_type.py: DecisionType enum definition
-- - core/enums/reason_code.py: ReasonCode enum definition
-- - core/models/impact_decision.py: ImpactDecision dataclass
-- - database/repository/impact_repository.py: Repository with validation
-- - config/cost_estimates.py: Cost estimation logic
-- ============================================================================

-- ============================================================================
-- VERSION HISTORY
-- ============================================================================
-- 2025-11-02: Initial schema creation (Phase 2, Items 71-80)
--             - Primary structure (Item 71)
--             - Decision columns (Item 72)
--             - Execution tracking (Item 73)
--             - Timestamps and metadata (Item 74)
--             - Complete schema file (Item 75)
--             - Query indexes (Item 76)
--             - Apply plan composite index (Item 77)
--             - Partial unique index for duplicate prevention (Item 80)
-- ============================================================================
