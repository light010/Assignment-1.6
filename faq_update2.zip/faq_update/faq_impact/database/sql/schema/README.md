# FAQ Questions Enhanced Schema - Phase 2 Implementation

## Overview
This directory contains the enhanced schema for the `faq_questions` table with comprehensive inactivation tracking capabilities, implemented as part of Phase 2, Section 2.1 of the FAQ Impact Analysis system.

## What's New
The enhanced schema adds three new columns to track **why**, **when**, and **how** FAQ questions become inactive:
- `inactivation_reason` - Categorical reason (CONTENT_DELETED, ALL_SOURCES_INVALID, MANUAL, QUALITY_ISSUE)
- `inactivated_by_change_id` - Foreign key to the content change that triggered inactivation
- `inactivated_at` - Timestamp of when the question was inactivated

## Files in This Directory

### Core Schema Files
| File | Purpose | Status |
|------|---------|--------|
| [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) | Enhanced table schema with inactivation columns and indexes | ✅ Complete |

### Documentation
| File | Purpose | Status |
|------|---------|--------|
| [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) | Design rationale, specifications, and usage for new columns | ✅ Complete |
| [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) | Step-by-step migration from original to enhanced schema | ✅ Complete |
| [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) | Application-level validation rules with Python examples | ✅ Complete |
| [DEPENDENCY_NOTES.md](./DEPENDENCY_NOTES.md) | Analysis of schema dependencies and FK relationships | ✅ Complete |

### Test Data
| File | Purpose | Status |
|------|---------|--------|
| [test_data_inactivation.sql](./test_data_inactivation.sql) | Comprehensive test data covering all inactivation scenarios | ✅ Complete |

### This File
| File | Purpose | Status |
|------|---------|--------|
| [README.md](./README.md) | This overview document | ✅ Complete |

## Quick Start

### 1. Review the Design
Start with [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) to understand:
- Why these columns were added
- What each column means
- How they work together
- Consistency rules

### 2. Understand the Schema
Review [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) to see:
- Complete table definition
- New column specifications
- Index definitions
- Usage examples

### 3. Plan Your Migration
Follow [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) for:
- Pre-migration checklist
- Step-by-step SQL commands
- Verification queries
- Rollback procedures

### 4. Implement Validation
Use [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) to:
- Implement consistency checks
- Validate FK relationships
- Handle errors gracefully
- Test validation logic

### 5. Test With Sample Data
Load [test_data_inactivation.sql](./test_data_inactivation.sql) to:
- Verify schema works correctly
- Test all inactivation scenarios
- Validate queries and indexes
- Check application integration

## Implementation Status

### Phase 2, Section 2.1: Schema Enhancements (Items 61-70) ✅ COMPLETE

| Item | Description | Status | File(s) |
|------|-------------|--------|---------|
| 61 | Review existing faq_questions.sql schema | ✅ Complete | Analysis documented in INACTIVATION_COLUMNS_DESIGN.md |
| 52 | Design inactivation columns | ✅ Complete | INACTIVATION_COLUMNS_DESIGN.md |
| 53 | Create enhanced schema file | ✅ Complete | 02_faq_questions_enhanced.sql |
| 54 | Add FK for inactivated_by_change_id | ✅ Complete | 02_faq_questions_enhanced.sql, DEPENDENCY_NOTES.md |
| 55 | Create index on inactivation_reason | ✅ Complete | 02_faq_questions_enhanced.sql (line 145) |
| 56 | Create composite index | ✅ Complete | 02_faq_questions_enhanced.sql (line 161) |
| 57 | Document migration path | ✅ Complete | MIGRATION_GUIDE.md |
| 58 | Create validation logic | ✅ Complete | VALIDATION_LOGIC.md |
| 59 | Add sample test data | ✅ Complete | test_data_inactivation.sql |
| 60 | Update dependency graph | ✅ Complete | DEPENDENCY_NOTES.md |

**Total**: 10/10 items complete ✅

## Key Features

### 1. Comprehensive Inactivation Tracking
- **Why**: `inactivation_reason` captures the categorical cause
- **What**: `inactivated_by_change_id` links to specific content change
- **When**: `inactivated_at` records the exact timestamp

### 2. Application-Level Validation
- Enforces consistency rules in Python code (not database)
- Works across SQLite (dev) and Databricks (prod)
- Comprehensive error messages for debugging
- See: [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md)

### 3. Optimized Indexes
- Single-column index on `inactivation_reason` for filtering
- Composite index on `(status, inactivation_reason, inactivated_at)` for audit queries
- Supports common query patterns efficiently
- See: [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql)

### 4. Backward Compatible Migration
- Uses SQLite ALTER TABLE ADD COLUMN
- No data migration required
- Preserves all existing data and indexes
- See: [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)

### 5. Complete Test Coverage
- 14 test questions covering all scenarios
- 4 content change log entries
- Verification queries included
- See: [test_data_inactivation.sql](./test_data_inactivation.sql)

## Architecture Decisions

### Why Application-Level FK Validation?
**Decision**: Use application code to validate `inactivated_by_change_id` FK

**Rationale**:
- SQLite FK enforcement is opt-in and inconsistent
- Databricks FK constraints are metadata only (not enforced)
- Application-level validation works consistently across both
- Enables better error messages and logging

**Tradeoff**: Requires discipline to always validate in application layer

### Why NULL for Inactive Fields on Active Questions?
**Decision**: All inactivation fields are NULL when `status='active'`

**Rationale**:
- Clear semantic: NULL = "not applicable"
- No DEFAULT values needed (simpler migration)
- Easy to query: `WHERE inactivation_reason IS NULL` = active
- Validates at application layer

**Tradeoff**: Must enforce consistency in code (not database)

### Why Composite Index on (status, reason, timestamp)?
**Decision**: Create index on `(status, inactivation_reason, inactivated_at)`

**Rationale**:
- Supports common audit queries: "Show inactive questions by reason, sorted by time"
- Covers queries filtering by status (most selective)
- Enables efficient temporal analysis
- Small table size makes multi-column index cheap

**Tradeoff**: Slight overhead on INSERT/UPDATE (acceptable)

## Usage Examples

### Inactivate a Question (Python)
```python
from faq_impact.core.enums import InactivationReason
from datetime import datetime

# Inactivate due to content deletion
question_repo.inactivate_question(
    question_id="Q001",
    reason=InactivationReason.CONTENT_DELETED,
    change_id=12345
)
```

### Query Inactive Questions (SQL)
```sql
-- Find all questions inactivated in last 7 days
SELECT
    question_id,
    question_text,
    inactivation_reason,
    inactivated_at
FROM faq_questions
WHERE status = 'inactive'
  AND inactivated_at >= datetime('now', '-7 days')
ORDER BY inactivated_at DESC;
```

### Audit Report (SQL)
```sql
-- Count questions by inactivation reason
SELECT
    inactivation_reason,
    COUNT(*) as question_count,
    MIN(inactivated_at) as first_inactivation,
    MAX(inactivated_at) as last_inactivation
FROM faq_questions
WHERE status = 'inactive'
GROUP BY inactivation_reason
ORDER BY question_count DESC;
```

## Next Steps

### Phase 2, Section 2.2: Schema Enhancements - faq_answers Table (Items 71-80)
The same inactivation tracking should be added to `faq_answers` table:
- `inactivation_reason` (includes QUESTION_INACTIVATED for cascading)
- `inactivated_by_change_id`
- `inactivated_at`

Similar deliverables:
- Enhanced schema file
- Design documentation
- Migration guide
- Validation logic
- Test data

### Phase 2, Section 2.3: Repository Layer Implementation (Items 81-90)
Implement Python repository classes that:
- Use enhanced schema
- Apply validation logic
- Handle inactivation workflows
- Support audit queries

### Phase 2, Section 2.4: Service Layer Integration (Items 91-100)
Integrate inactivation tracking into:
- Content change detection service
- FAQ impact analysis service
- Regeneration orchestration
- Quality control workflows

## Related Documentation

### Core Enums
- [InactivationReason Enum](../../core/enums/entity_type.py) - Python enum definition

### Original Schema
- [Original faq_questions Schema](../../../../database/sql/schema/tables/02_faq_questions.sql) - Base schema
- [content_change_log Schema](../../../../database/sql/schema/tables/06_content_change_log.sql) - Referenced table

### Dependency Management
- [Dependency Graph](../../../../database/sql/schema/_meta/dependency_graph.yaml) - Schema creation order

### Implementation Plan
- [IMPLEMENTATION_PLAN.md](../../IMPLEMENTATION_PLAN.md) - Complete project plan

## Testing Checklist

Before deploying enhanced schema:

- [ ] Read and understand design documentation
- [ ] Review enhanced schema SQL file
- [ ] Test migration in development environment
- [ ] Verify all validation rules work correctly
- [ ] Load and verify test data
- [ ] Run performance tests on indexes
- [ ] Test application integration end-to-end
- [ ] Review rollback procedure
- [ ] Document any environment-specific considerations
- [ ] Get peer review of implementation

## Support

### Questions About Design
See [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) for:
- Column specifications
- Valid values
- Consistency rules
- Use cases

### Questions About Migration
See [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) for:
- Pre-migration checklist
- Step-by-step commands
- Verification queries
- Rollback procedures
- Troubleshooting

### Questions About Validation
See [VALIDATION_LOGIC.md](./VALIDATION_LOGIC.md) for:
- Validation rules
- Python implementations
- Integration examples
- Test cases

### Questions About Testing
See [test_data_inactivation.sql](./test_data_inactivation.sql) for:
- Sample data
- Test scenarios
- Verification queries
- Edge cases

## Version History
- 2025-11-02: Initial implementation (Phase 2, Section 2.1, Items 61-70)

## Authors
Analytics Assist Team

## License
Internal use only - Analytics Assist Team

---

**Status**: Phase 2, Section 2.1 Complete ✅

**Last Updated**: 2025-11-02
