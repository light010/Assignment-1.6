# FAQ Impact Details JSON Schema

**Version**: 1.0.0
**Date**: 2025-11-02
**Owner**: Analytics Assist Team
**Status**: Final

---

## Overview

This document defines the JSON schema for the `details` column in the `faq_impact` table. The `details` column stores decision-specific metadata as a JSON blob, enabling flexible, type-safe storage of contextual information needed to execute each impact decision.

---

## Design Principles

1. **Decision-Type Specific**: Each `DecisionType` has its own JSON schema
2. **Optional Field**: The `details` column is nullable; simple decisions may not need details
3. **Validation**: Application code validates JSON structure before INSERT
4. **Extensibility**: New fields can be added without breaking existing code
5. **Type Safety**: Python dataclasses enforce schema at application level

---

## General Schema Structure

All `details` JSON objects share this common structure:

```json
{
  "schema_version": "1.0",
  "decision_type": "<DecisionType>",
  "<decision_specific_fields>": "..."
}
```

### Common Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `schema_version` | string | Yes | Schema version for migration compatibility (e.g., "1.0") |
| `decision_type` | string | Yes | DecisionType enum value (redundant with `faq_impact.decision`, but aids validation) |

---

## Decision-Type Specific Schemas

### 1. PLAN_CREATE - Create New Question

**Purpose**: Store context needed to generate new questions from new content

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "PLAN_CREATE",
  "content_id": "string",
  "source_type": "string",
  "content_preview": "string (optional)",
  "generation_params": {
    "max_questions": "integer (optional)",
    "temperature": "float (optional)",
    "model": "string (optional)"
  }
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `content_id` | string | Yes | ID of the new content chunk (e.g., "chunk_12345") |
| `source_type` | string | Yes | Content source type ("pdf", "manual", "user_query", etc.) |
| `content_preview` | string | No | First 200 chars of content for preview (debugging/audit) |
| `generation_params.max_questions` | integer | No | Max questions to generate from this content (default: 3) |
| `generation_params.temperature` | float | No | LLM temperature for generation (default: 0.7) |
| `generation_params.model` | string | No | Specific model to use (default: from config) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "PLAN_CREATE",
  "content_id": "chunk_doc123_page5",
  "source_type": "pdf",
  "content_preview": "The return policy allows customers to return items within 30 days of purchase. Items must be unused and in original packaging...",
  "generation_params": {
    "max_questions": 5,
    "temperature": 0.7
  }
}
```

---

### 2. REGEN_Q - Regenerate Question Only

**Purpose**: Store context for regenerating question text when sole source changed

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_Q",
  "similarity_score": "float",
  "token_overlap": "float (optional)",
  "previous_content_id": "string",
  "new_content_id": "string",
  "change_summary": "string (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `similarity_score` | float | Yes | Similarity score between old and new content (0.0-1.0) |
| `token_overlap` | float | No | Token overlap ratio (0.0-1.0) |
| `previous_content_id` | string | Yes | ID of original content chunk |
| `new_content_id` | string | Yes | ID of modified content chunk |
| `change_summary` | string | No | Brief description of what changed (for audit) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_Q",
  "similarity_score": 0.68,
  "token_overlap": 0.72,
  "previous_content_id": "chunk_doc123_page5_v1",
  "new_content_id": "chunk_doc123_page5_v2",
  "change_summary": "Return policy changed from 30 days to 60 days"
}
```

---

### 3. REGEN_A - Regenerate Answer Only

**Purpose**: Store context for regenerating answer when content affecting answer changed

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_A",
  "affected_sources": ["string"],
  "token_overlap": "float (optional)",
  "overlap_tokens": ["string"] (optional),
  "change_type": "string (optional)",
  "confidence_threshold": "float (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `affected_sources` | array[string] | Yes | List of source content IDs that changed |
| `token_overlap` | float | No | Token overlap ratio between answer and modified content (0.0-1.0) |
| `overlap_tokens` | array[string] | No | Sample of overlapping tokens (debugging, max 20 tokens) |
| `change_type` | string | No | Type of change ("fact_update", "content_addition", "content_removal") |
| `confidence_threshold` | float | No | Minimum confidence for regenerated answer (0.0-1.0, default: 0.7) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_A",
  "affected_sources": ["chunk_doc123_page5", "chunk_doc456_page2"],
  "token_overlap": 0.78,
  "overlap_tokens": ["return", "policy", "30", "days", "unused", "original", "packaging"],
  "change_type": "fact_update"
}
```

---

### 4. REGEN_BOTH - Regenerate Both Question and Answer

**Purpose**: Store context for full FAQ pair regeneration

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_BOTH",
  "reason_category": "string",
  "affected_sources": ["string"],
  "similarity_score": "float (optional)",
  "restructure_type": "string (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `reason_category` | string | Yes | High-level reason category ("sole_source_deleted", "major_restructure", "multiple_sources_changed") |
| `affected_sources` | array[string] | Yes | List of all affected source content IDs |
| `similarity_score` | float | No | Average similarity score across sources (0.0-1.0) |
| `restructure_type` | string | No | Type of restructure ("section_merge", "section_split", "content_rewrite") |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "REGEN_BOTH",
  "reason_category": "major_restructure",
  "affected_sources": ["chunk_doc123_page5", "chunk_doc123_page6", "chunk_doc123_page7"],
  "similarity_score": 0.55,
  "restructure_type": "section_merge"
}
```

---

### 5. INACTIVATE - Mark Question or Answer Inactive

**Purpose**: Store context for inactivation decisions

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "INACTIVATE",
  "inactivation_reason": "string",
  "deleted_content_ids": ["string"] (optional),
  "cascade_to_answers": "boolean (optional)",
  "quality_score": "float (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `inactivation_reason` | string | Yes | InactivationReason enum value ("CONTENT_DELETED", "ALL_SOURCES_INVALID", "QUALITY_ISSUE", etc.) |
| `deleted_content_ids` | array[string] | No | List of deleted content chunk IDs (for CONTENT_DELETED reason) |
| `cascade_to_answers` | boolean | No | Whether to cascade inactivation to answers (entity_type=QUESTION only, default: true) |
| `quality_score` | float | No | Quality score if reason is QUALITY_ISSUE (0.0-1.0) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "INACTIVATE",
  "inactivation_reason": "CONTENT_DELETED",
  "deleted_content_ids": ["chunk_doc123_page5"],
  "cascade_to_answers": true
}
```

---

### 6. EVALUATE - Needs LLM Evaluation

**Purpose**: Store context for decisions requiring LLM review

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "EVALUATE",
  "evaluation_reason": "string",
  "ambiguity_factors": ["string"],
  "candidate_decisions": ["string"] (optional),
  "similarity_score": "float (optional)",
  "token_overlap": "float (optional)",
  "llm_prompt_template": "string (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `evaluation_reason` | string | Yes | ReasonCode enum value ("SIMILARITY_AMBIGUOUS", "PARTIAL_TOKEN_OVERLAP", etc.) |
| `ambiguity_factors` | array[string] | Yes | List of factors causing ambiguity (e.g., ["similarity in gray zone", "conflicting indicators"]) |
| `candidate_decisions` | array[string] | No | Possible decision types LLM should choose from (e.g., ["REGEN_Q", "REGEN_A", "NOOP"]) |
| `similarity_score` | float | No | Similarity score causing ambiguity (0.0-1.0) |
| `token_overlap` | float | No | Token overlap ratio causing ambiguity (0.0-1.0) |
| `llm_prompt_template` | string | No | Custom prompt template for evaluation (default: use standard template) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "EVALUATE",
  "evaluation_reason": "SIMILARITY_AMBIGUOUS",
  "ambiguity_factors": ["similarity_score 0.72 in gray zone (0.70-0.80)", "token overlap 0.65 suggests change"],
  "candidate_decisions": ["REGEN_A", "NOOP"],
  "similarity_score": 0.72,
  "token_overlap": 0.65
}
```

---

### 7. NOOP - No Operation Needed

**Purpose**: Store reason for no-op decision (audit trail)

**Schema**:
```json
{
  "schema_version": "1.0",
  "decision_type": "NOOP",
  "noop_reason": "string",
  "similarity_score": "float (optional)",
  "threshold_used": "float (optional)"
}
```

**Field Definitions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `noop_reason` | string | Yes | ReasonCode enum value ("CONTENT_UNCHANGED", "MINOR_FORMATTING_CHANGE", etc.) |
| `similarity_score` | float | No | High similarity score (>0.95) indicating no change |
| `threshold_used` | float | No | Threshold value used to determine NOOP (e.g., 0.95) |

**Example**:
```json
{
  "schema_version": "1.0",
  "decision_type": "NOOP",
  "noop_reason": "BELOW_SIMILARITY_THRESHOLD",
  "similarity_score": 0.98,
  "threshold_used": 0.95
}
```

---

## Validation Rules

### Application-Level Validation

All `details` JSON must be validated before INSERT using these rules:

1. **Schema Version**: Must be present and valid (currently "1.0")
2. **Decision Type**: Must match `faq_impact.decision` column
3. **Required Fields**: All required fields for decision type must be present
4. **Type Safety**: Field types must match schema (string, integer, float, boolean, array)
5. **Value Ranges**:
   - Similarity scores: 0.0 ≤ score ≤ 1.0
   - Token overlap: 0.0 ≤ overlap ≤ 1.0
   - Temperature: 0.0 ≤ temp ≤ 2.0
   - Priority: 1 ≤ priority ≤ 10
6. **Enum Values**: All enum references must be valid (DecisionType, ReasonCode, InactivationReason)
7. **JSON Syntax**: Must be valid JSON (no syntax errors)

### Python Validation Example

```python
from typing import Dict, Any
import json
from faq_impact.core.enums import DecisionType, ReasonCode

def validate_details_schema(decision_type: DecisionType, details_json: str) -> bool:
    """
    Validate details JSON against schema for decision type.

    Args:
        decision_type: The decision type enum
        details_json: JSON string to validate

    Returns:
        True if valid

    Raises:
        ValueError: If validation fails with detailed error message
    """
    # Parse JSON
    try:
        details = json.loads(details_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON syntax: {e}")

    # Check schema version
    if "schema_version" not in details:
        raise ValueError("Missing required field: schema_version")
    if details["schema_version"] != "1.0":
        raise ValueError(f"Unsupported schema version: {details['schema_version']}")

    # Check decision type match
    if details.get("decision_type") != decision_type.value:
        raise ValueError(
            f"Decision type mismatch: expected {decision_type.value}, "
            f"got {details.get('decision_type')}"
        )

    # Decision-specific validation
    if decision_type == DecisionType.PLAN_CREATE:
        if "content_id" not in details:
            raise ValueError("PLAN_CREATE requires 'content_id' field")
        if "source_type" not in details:
            raise ValueError("PLAN_CREATE requires 'source_type' field")

    elif decision_type == DecisionType.REGEN_Q:
        if "similarity_score" not in details:
            raise ValueError("REGEN_Q requires 'similarity_score' field")
        score = details["similarity_score"]
        if not (0.0 <= score <= 1.0):
            raise ValueError(f"similarity_score must be 0.0-1.0, got {score}")

    elif decision_type == DecisionType.REGEN_A:
        if "affected_sources" not in details:
            raise ValueError("REGEN_A requires 'affected_sources' field")
        if not isinstance(details["affected_sources"], list):
            raise ValueError("affected_sources must be an array")

    # ... (similar validation for other decision types)

    return True
```

---

## Migration and Versioning

### Schema Evolution

When the `details` JSON schema needs to change:

1. **Increment Schema Version**: Change `"schema_version": "1.0"` to `"1.1"`, `"2.0"`, etc.
2. **Add New Fields**: Always optional (backward compatible)
3. **Deprecate Old Fields**: Mark as deprecated in docs, keep parsing for backward compatibility
4. **Never Remove Fields**: Breaks old records; instead, mark as deprecated and ignore

### Example Migration (1.0 → 1.1)

Suppose we want to add `execution_priority` to `PLAN_CREATE`:

**Old Schema (1.0)**:
```json
{
  "schema_version": "1.0",
  "decision_type": "PLAN_CREATE",
  "content_id": "chunk123"
}
```

**New Schema (1.1)**:
```json
{
  "schema_version": "1.1",
  "decision_type": "PLAN_CREATE",
  "content_id": "chunk123",
  "execution_priority": 5  // NEW FIELD (optional)
}
```

**Handling Both Versions**:
```python
def parse_plan_create_details(details: Dict[str, Any]) -> PlanCreateDetails:
    schema_version = details.get("schema_version", "1.0")

    if schema_version == "1.0":
        # Old schema: no execution_priority
        return PlanCreateDetails(
            content_id=details["content_id"],
            execution_priority=None  # Default for old records
        )
    elif schema_version == "1.1":
        # New schema: execution_priority may be present
        return PlanCreateDetails(
            content_id=details["content_id"],
            execution_priority=details.get("execution_priority")
        )
    else:
        raise ValueError(f"Unsupported schema version: {schema_version}")
```

---

## Usage in Code

### Creating Impact Decision with Details

```python
from faq_impact.core.models import ImpactDecision
from faq_impact.core.enums import DecisionType, ReasonCode, EntityType
import json

# Create REGEN_A decision with details
decision = ImpactDecision(
    entity_type=EntityType.ANSWER,
    entity_id="A123",
    change_id=12345,
    detection_run_id="RUN_20251102_143000",
    decision=DecisionType.REGEN_A,
    reason=ReasonCode.TOKEN_OVERLAP_DETECTED,
    details=json.dumps({
        "schema_version": "1.0",
        "decision_type": "REGEN_A",
        "affected_sources": ["chunk_doc123_page5", "chunk_doc456_page2"],
        "token_overlap": 0.78,
        "overlap_tokens": ["return", "policy", "30", "days"],
        "change_type": "fact_update"
    }),
    applied=False,
    estimated_cost=0.03,
    priority=7
)
```

### Parsing Details for Execution

```python
import json
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class RegenADetails:
    schema_version: str
    decision_type: str
    affected_sources: List[str]
    token_overlap: Optional[float] = None
    overlap_tokens: Optional[List[str]] = None
    change_type: Optional[str] = None

def parse_regen_a_details(details_json: str) -> RegenADetails:
    """Parse REGEN_A details JSON into typed dataclass."""
    details = json.loads(details_json)
    return RegenADetails(
        schema_version=details["schema_version"],
        decision_type=details["decision_type"],
        affected_sources=details["affected_sources"],
        token_overlap=details.get("token_overlap"),
        overlap_tokens=details.get("overlap_tokens"),
        change_type=details.get("change_type")
    )

# Usage
impact = repository.get_impact_by_id(456)
details = parse_regen_a_details(impact.details)
print(f"Affected sources: {details.affected_sources}")
print(f"Token overlap: {details.token_overlap}")
```

---

## Testing

### Sample Test Cases

```python
import pytest
import json
from faq_impact.core.enums import DecisionType

def test_plan_create_details_valid():
    """Test valid PLAN_CREATE details."""
    details = {
        "schema_version": "1.0",
        "decision_type": "PLAN_CREATE",
        "content_id": "chunk123",
        "source_type": "pdf"
    }
    assert validate_details_schema(DecisionType.PLAN_CREATE, json.dumps(details))

def test_regen_a_details_missing_required_field():
    """Test REGEN_A details with missing required field."""
    details = {
        "schema_version": "1.0",
        "decision_type": "REGEN_A"
        # Missing: affected_sources
    }
    with pytest.raises(ValueError, match="requires 'affected_sources'"):
        validate_details_schema(DecisionType.REGEN_A, json.dumps(details))

def test_similarity_score_out_of_range():
    """Test similarity score validation."""
    details = {
        "schema_version": "1.0",
        "decision_type": "REGEN_Q",
        "similarity_score": 1.5,  # Invalid: > 1.0
        "previous_content_id": "chunk1",
        "new_content_id": "chunk2"
    }
    with pytest.raises(ValueError, match="similarity_score must be 0.0-1.0"):
        validate_details_schema(DecisionType.REGEN_Q, json.dumps(details))
```

---

## Related Documentation

- [07_faq_impact.sql](07_faq_impact.sql): Table schema with `details` column definition
- [core/enums/decision_type.py](../../core/enums/decision_type.py): DecisionType enum
- [core/enums/reason_code.py](../../core/enums/reason_code.py): ReasonCode enum
- [core/models/impact_decision.py](../../core/models/impact_decision.py): ImpactDecision dataclass
- [IMPLEMENTATION_PLAN.md](../../../IMPLEMENTATION_PLAN.md): Section 2.3, Item 78

---

## Version History

- **2025-11-02**: Initial schema documentation (v1.0)
  - Defined schemas for all 7 decision types
  - Added validation rules and examples
  - Documented migration strategy
