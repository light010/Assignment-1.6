-- ============================================================================
-- TEST DATA: Inactivation Scenarios for faq_questions
-- ============================================================================
-- Purpose: Comprehensive test data covering all inactivation scenarios
-- Usage: Load this data into test database to verify inactivation logic
-- Dependencies: Requires content_change_log entries to exist
-- Owner: Analytics Assist Team
--
-- Coverage:
--   1. Active questions (baseline)
--   2. Inactivated due to CONTENT_DELETED
--   3. Inactivated due to ALL_SOURCES_INVALID
--   4. Inactivated due to MANUAL
--   5. Inactivated due to QUALITY_ISSUE
--   6. Edge cases (manual with change_id, etc.)
-- ============================================================================

-- ============================================================================
-- STEP 1: Create Content Change Log Entries (Referenced by FK)
-- ============================================================================

INSERT INTO content_change_log (
    change_id, content_checksum, previous_checksum, file_name,
    requires_faq_regeneration, change_type, similarity_score,
    similarity_method, total_faqs_at_risk, affected_question_count,
    affected_answer_count, detection_run_id, detection_timestamp
) VALUES
    -- Change 1: Content deletion
    (1001, 'del_abc123', 'prev_abc123', 'deleted_policy.pdf', 1, 'deleted_content',
     0.0, 'difflib', 5, 3, 2, 'test_run_001', '2025-10-15T09:00:00'),

    -- Change 2: Content modification (sources invalid)
    (1002, 'mod_def456', 'prev_def456', 'modified_guide.pdf', 1, 'modified_content',
     0.35, 'hybrid', 8, 4, 4, 'test_run_002', '2025-10-20T14:30:00'),

    -- Change 3: Quality check trigger
    (1003, 'chk_ghi789', 'prev_ghi789', 'questionable_doc.pdf', 0, 'unchanged_content',
     0.95, 'jaccard', 2, 0, 0, 'test_run_003', '2025-10-25T11:15:00'),

    -- Change 4: Recent deletion
    (1004, 'del_jkl012', 'prev_jkl012', 'recent_delete.pdf', 1, 'deleted_content',
     0.0, 'difflib', 3, 2, 1, 'test_run_004', '2025-11-01T16:45:00');

-- ============================================================================
-- STEP 2: Create Test Questions - Active (Baseline)
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- Active question 1: Normal active question
    ('TEST_Q_ACTIVE_001',
     'What is the current vacation policy?',
     'from_documents', 'llm_generated',
     'active', NULL, NULL, NULL,
     '2025-09-01T10:00:00', '2025-09-01T10:00:00'),

    -- Active question 2: Recently created
    ('TEST_Q_ACTIVE_002',
     'How do I submit an expense report?',
     'from_documents', 'llm_generated',
     'active', NULL, NULL, NULL,
     '2025-10-28T14:20:00', '2025-10-28T14:20:00'),

    -- Active question 3: Manual question
    ('TEST_Q_ACTIVE_003',
     'What are the office hours?',
     'from_manual', 'human_written',
     'active', NULL, NULL, NULL,
     '2025-08-15T08:30:00', '2025-08-15T08:30:00');

-- ============================================================================
-- STEP 3: Inactivated Due to CONTENT_DELETED
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- Content deleted scenario 1: Single source deleted
    ('TEST_Q_DELETED_001',
     'What was the old sick leave policy?',
     'from_documents', 'llm_generated',
     'inactive', 'CONTENT_DELETED', 1001, '2025-10-15T09:30:00',
     '2025-08-01T11:00:00', '2025-10-15T09:30:00'),

    -- Content deleted scenario 2: Multiple deletions
    ('TEST_Q_DELETED_002',
     'How did the previous bonus structure work?',
     'from_documents', 'llm_generated',
     'inactive', 'CONTENT_DELETED', 1001, '2025-10-15T09:30:00',
     '2025-07-10T15:45:00', '2025-10-15T09:30:00'),

    -- Content deleted scenario 3: Recent deletion
    ('TEST_Q_DELETED_003',
     'What were the temporary COVID protocols?',
     'from_documents', 'extracted',
     'inactive', 'CONTENT_DELETED', 1004, '2025-11-01T16:50:00',
     '2025-09-20T13:00:00', '2025-11-01T16:50:00');

-- ============================================================================
-- STEP 4: Inactivated Due to ALL_SOURCES_INVALID
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- All sources invalid scenario 1: Content heavily modified
    ('TEST_Q_INVALID_001',
     'What is the outdated reimbursement policy?',
     'from_documents', 'llm_generated',
     'inactive', 'ALL_SOURCES_INVALID', 1002, '2025-10-20T15:00:00',
     '2025-06-15T09:20:00', '2025-10-20T15:00:00'),

    -- All sources invalid scenario 2: Multiple sources all invalid
    ('TEST_Q_INVALID_002',
     'How do I use the old HR portal?',
     'from_documents', 'llm_generated',
     'inactive', 'ALL_SOURCES_INVALID', 1002, '2025-10-20T15:00:00',
     '2025-05-30T14:10:00', '2025-10-20T15:00:00');

-- ============================================================================
-- STEP 5: Inactivated Due to MANUAL (No change_id required)
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- Manual inactivation scenario 1: User decision (no change_id)
    ('TEST_Q_MANUAL_001',
     'What is the policy for pet dinosaurs in the office?',
     'from_manual', 'human_written',
     'inactive', 'MANUAL', NULL, '2025-10-10T10:00:00',
     '2025-09-01T08:00:00', '2025-10-10T10:00:00'),

    -- Manual inactivation scenario 2: Outdated question
    ('TEST_Q_MANUAL_002',
     'How do I use the deprecated software version?',
     'from_documents', 'llm_generated',
     'inactive', 'MANUAL', NULL, '2025-10-18T13:45:00',
     '2025-04-20T11:30:00', '2025-10-18T13:45:00'),

    -- Manual inactivation scenario 3: With optional change_id reference
    ('TEST_Q_MANUAL_003',
     'This question is related to a change but manually reviewed',
     'from_documents', 'llm_generated',
     'inactive', 'MANUAL', 1002, '2025-10-21T09:15:00',
     '2025-08-05T10:20:00', '2025-10-21T09:15:00');

-- ============================================================================
-- STEP 6: Inactivated Due to QUALITY_ISSUE
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- Quality issue scenario 1: Low coherence score
    ('TEST_Q_QUALITY_001',
     'What is the thing about stuff?',  -- Vague, low quality
     'from_documents', 'llm_generated',
     'inactive', 'QUALITY_ISSUE', 1003, '2025-10-25T11:30:00',
     '2025-10-24T16:00:00', '2025-10-25T11:30:00'),

    -- Quality issue scenario 2: Failed validation
    ('TEST_Q_QUALITY_002',
     'How can I do the process for the procedure?',  -- Redundant, unclear
     'from_documents', 'llm_generated',
     'inactive', 'QUALITY_ISSUE', 1003, '2025-10-25T11:30:00',
     '2025-10-23T14:30:00', '2025-10-25T11:30:00');

-- ============================================================================
-- STEP 7: Edge Cases
-- ============================================================================

INSERT INTO faq_questions (
    question_id, question_text, source_type, generation_method,
    status, inactivation_reason, inactivated_by_change_id, inactivated_at,
    created_at, modified_at
) VALUES
    -- Edge case 1: Question created then immediately inactivated
    ('TEST_Q_EDGE_001',
     'What is this question about?',
     'from_documents', 'llm_generated',
     'inactive', 'QUALITY_ISSUE', 1003, '2025-10-25T11:35:00',
     '2025-10-25T11:30:00', '2025-10-25T11:35:00'),

    -- Edge case 2: Old question recently inactivated
    ('TEST_Q_EDGE_002',
     'What was the 2020 holiday schedule?',
     'from_documents', 'extracted',
     'inactive', 'CONTENT_DELETED', 1004, '2025-11-01T17:00:00',
     '2025-01-05T09:00:00', '2025-11-01T17:00:00'),

    -- Edge case 3: Question with all source types
    ('TEST_Q_EDGE_003',
     'Comprehensive question from multiple sources',
     'from_validation', 'llm_generated',
     'active', NULL, NULL, NULL,
     '2025-10-30T12:00:00', '2025-10-30T12:00:00');

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Query 1: Count questions by status and inactivation reason
-- SELECT
--     status,
--     inactivation_reason,
--     COUNT(*) as question_count
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
-- GROUP BY status, inactivation_reason
-- ORDER BY status, inactivation_reason;
--
-- Expected output:
--   status   | inactivation_reason  | question_count
--   active   | NULL                 | 4
--   inactive | ALL_SOURCES_INVALID  | 2
--   inactive | CONTENT_DELETED      | 3
--   inactive | MANUAL               | 3
--   inactive | QUALITY_ISSUE        | 2

-- Query 2: Verify all inactive questions have required fields
-- SELECT
--     question_id,
--     status,
--     CASE
--         WHEN inactivation_reason IS NULL THEN 'MISSING REASON'
--         WHEN inactivated_at IS NULL THEN 'MISSING TIMESTAMP'
--         ELSE 'OK'
--     END as validation_status
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
--   AND status = 'inactive';
--
-- Expected: All rows should have validation_status = 'OK'

-- Query 3: Verify active questions have no inactivation data
-- SELECT
--     question_id,
--     status,
--     CASE
--         WHEN inactivation_reason IS NOT NULL THEN 'INVALID: HAS REASON'
--         WHEN inactivated_by_change_id IS NOT NULL THEN 'INVALID: HAS CHANGE_ID'
--         WHEN inactivated_at IS NOT NULL THEN 'INVALID: HAS TIMESTAMP'
--         ELSE 'OK'
--     END as validation_status
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
--   AND status = 'active';
--
-- Expected: All rows should have validation_status = 'OK'

-- Query 4: Verify change_id references exist
-- SELECT
--     q.question_id,
--     q.inactivation_reason,
--     q.inactivated_by_change_id,
--     CASE
--         WHEN ccl.change_id IS NULL THEN 'MISSING FK'
--         ELSE 'OK'
--     END as fk_validation
-- FROM faq_questions q
-- LEFT JOIN content_change_log ccl ON q.inactivated_by_change_id = ccl.change_id
-- WHERE q.question_id LIKE 'TEST_Q_%'
--   AND q.inactivated_by_change_id IS NOT NULL;
--
-- Expected: All rows should have fk_validation = 'OK'

-- Query 5: Verify MANUAL inactivations (change_id optional)
-- SELECT
--     question_id,
--     inactivation_reason,
--     inactivated_by_change_id,
--     CASE
--         WHEN inactivated_by_change_id IS NULL THEN 'change_id: NULL (OK for MANUAL)'
--         ELSE 'change_id: PROVIDED (also OK for MANUAL)'
--     END as manual_validation
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
--   AND inactivation_reason = 'MANUAL';
--
-- Expected: Mix of NULL and non-NULL change_ids (both valid)

-- Query 6: Verify non-MANUAL inactivations have change_id
-- SELECT
--     question_id,
--     inactivation_reason,
--     inactivated_by_change_id,
--     CASE
--         WHEN inactivated_by_change_id IS NULL THEN 'INVALID: MISSING CHANGE_ID'
--         ELSE 'OK'
--     END as validation_status
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
--   AND status = 'inactive'
--   AND inactivation_reason != 'MANUAL';
--
-- Expected: All rows should have validation_status = 'OK'

-- Query 7: Inactivation timeline (temporal analysis)
-- SELECT
--     DATE(inactivated_at) as inactivation_date,
--     inactivation_reason,
--     COUNT(*) as question_count
-- FROM faq_questions
-- WHERE question_id LIKE 'TEST_Q_%'
--   AND status = 'inactive'
-- GROUP BY DATE(inactivated_at), inactivation_reason
-- ORDER BY inactivation_date, inactivation_reason;

-- Query 8: Questions inactivated by specific change
-- SELECT
--     ccl.change_id,
--     ccl.file_name,
--     ccl.change_type,
--     COUNT(q.question_id) as affected_questions
-- FROM content_change_log ccl
-- LEFT JOIN faq_questions q ON ccl.change_id = q.inactivated_by_change_id
-- WHERE ccl.change_id IN (1001, 1002, 1003, 1004)
-- GROUP BY ccl.change_id, ccl.file_name, ccl.change_type
-- ORDER BY ccl.change_id;

-- ============================================================================
-- CLEANUP (Run to remove test data)
-- ============================================================================

-- DELETE FROM faq_questions WHERE question_id LIKE 'TEST_Q_%';
-- DELETE FROM content_change_log WHERE change_id BETWEEN 1001 AND 1004;

-- ============================================================================
-- TEST SCENARIOS SUMMARY
-- ============================================================================
-- Active Questions: 4
--   - TEST_Q_ACTIVE_001: Normal active question
--   - TEST_Q_ACTIVE_002: Recently created
--   - TEST_Q_ACTIVE_003: Manual/human-written
--   - TEST_Q_EDGE_003: From validation source
--
-- Inactive - CONTENT_DELETED: 3
--   - TEST_Q_DELETED_001: Single source deleted
--   - TEST_Q_DELETED_002: Multiple deletions
--   - TEST_Q_DELETED_003: Recent deletion
--
-- Inactive - ALL_SOURCES_INVALID: 2
--   - TEST_Q_INVALID_001: Content heavily modified
--   - TEST_Q_INVALID_002: Multiple sources invalid
--
-- Inactive - MANUAL: 3
--   - TEST_Q_MANUAL_001: User decision (no change_id)
--   - TEST_Q_MANUAL_002: Outdated question (no change_id)
--   - TEST_Q_MANUAL_003: With optional change_id
--
-- Inactive - QUALITY_ISSUE: 2
--   - TEST_Q_QUALITY_001: Low coherence
--   - TEST_Q_QUALITY_002: Failed validation
--
-- Edge Cases: 2
--   - TEST_Q_EDGE_001: Created then immediately inactivated
--   - TEST_Q_EDGE_002: Old question recently inactivated
--
-- Total Test Questions: 14
-- Total Content Changes: 4
-- ============================================================================

-- ============================================================================
-- USAGE INSTRUCTIONS
-- ============================================================================
-- 1. Load this file into your test database:
--    sqlite3 test_faq.db < test_data_inactivation.sql
--
-- 2. Run verification queries (commented out above)
--
-- 3. Test application validation logic against this data
--
-- 4. Clean up test data when done (see CLEANUP section)
--
-- 5. Use this data for:
--    - Unit tests (validation logic)
--    - Integration tests (repository methods)
--    - Manual testing (UI displays)
--    - Performance testing (query optimization)
-- ============================================================================

-- ============================================================================
-- RELATED DOCUMENTATION
-- ============================================================================
-- - VALIDATION_LOGIC.md: Application-level validation rules
-- - 02_faq_questions_enhanced.sql: Enhanced schema definition
-- - INACTIVATION_COLUMNS_DESIGN.md: Column design rationale
-- - ../../core/enums/entity_type.py: InactivationReason enum
-- ============================================================================

-- ============================================================================
-- VERSION HISTORY
-- ============================================================================
-- 2025-11-02: Initial test data for inactivation scenarios (Item 59)
-- ============================================================================
