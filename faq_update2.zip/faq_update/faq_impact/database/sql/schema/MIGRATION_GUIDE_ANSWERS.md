# Migration Guide: faq_answers Table Enhancement

## Overview
This guide provides step-by-step instructions for migrating the `faq_answers` table from the original schema to the enhanced schema with inactivation tracking.

**Target Tables**: `faq_answers`
**New Columns**: `inactivation_reason`, `inactivated_by_change_id`, `inactivated_at`
**Impact**: Low - Only adds columns, no data transformation required
**Dependencies**: Should be performed AFTER faq_questions migration (see MIGRATION_GUIDE.md)

## Migration Strategy

### Approach
Use SQLite's `ALTER TABLE ADD COLUMN` capability to add new columns to the existing table.

**Advantages**:
- No data migration required
- Minimal downtime
- Preserves all existing data and indexes
- Backward compatible (existing queries unaffected)

**Limitations**:
- SQLite cannot add NOT NULL columns without a DEFAULT value
- All new columns must be nullable (validation handled by application)

## Prerequisites

### 1. Complete faq_questions Migration First
**IMPORTANT**: The faq_questions table MUST be migrated first because:
- Cascade logic depends on question inactivation tracking
- Application validation requires question.inactivated_by_change_id
- Testing cascade requires enhanced question schema

```sql
-- Verify faq_questions has been migrated
PRAGMA table_info(faq_questions);
-- Should show inactivation_reason, inactivated_by_change_id, inactivated_at columns
```

### 2. Backup Database
```bash
# Create a backup before migration
cp faq_database.db faq_database_backup_$(date +%Y%m%d_%H%M%S).db

# Or use SQLite backup command
sqlite3 faq_database.db ".backup faq_database_backup.db"
```

### 3. Verify Current Schema
```sql
-- Check current table structure
PRAGMA table_info(faq_answers);

-- Expected output (original schema):
-- cid | name             | type     | notnull | dflt_value        | pk
-- 0   | answer_id        | TEXT     | 0       | NULL              | 1
-- 1   | question_id      | TEXT     | 1       | NULL              | 0
-- 2   | answer_text      | TEXT     | 1       | NULL              | 0
-- 3   | answer_format    | TEXT     | 0       | 'html'            | 0
-- 4   | confidence_score | REAL     | 0       | NULL              | 0
-- 5   | status           | TEXT     | 1       | 'active'          | 0
-- 6   | created_at       | DATETIME | 1       | CURRENT_TIMESTAMP | 0
-- 7   | modified_at      | DATETIME | 1       | CURRENT_TIMESTAMP | 0
```

### 4. Check for Data Integrity Issues
```sql
-- Find orphaned active answers (active answer with inactive question)
-- This MUST be resolved before migration
SELECT
    a.answer_id,
    a.question_id,
    a.status as answer_status,
    q.status as question_status,
    q.inactivation_reason as question_reason,
    q.inactivated_at as question_inactivated_at
FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.status = 'active'
  AND q.status = 'inactive';

-- Expected: 0 rows (no orphans)
-- If found: Fix by inactivating these answers before migration
```

**If orphaned active answers are found, fix them first**:
```sql
-- Fix orphaned answers before migration
UPDATE faq_answers
SET status = 'inactive',
    modified_at = CURRENT_TIMESTAMP
WHERE answer_id IN (
    SELECT a.answer_id
    FROM faq_answers a
    INNER JOIN faq_questions q ON a.question_id = q.question_id
    WHERE a.status = 'active'
      AND q.status = 'inactive'
);
```

### 5. Check for Active Transactions
```sql
-- Ensure no other connections have open transactions
-- Close all other database connections before migration
```

## Migration Steps

### Step 1: Add inactivation_reason Column
```sql
-- Add inactivation_reason column
ALTER TABLE faq_answers
ADD COLUMN inactivation_reason TEXT;

-- Verify column added
PRAGMA table_info(faq_answers);
-- Should show new column with type=TEXT, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values (correct for active answers)
SELECT COUNT(*) as total_answers,
       SUM(CASE WHEN inactivation_reason IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_answers;
-- null_count should equal total_answers
```

### Step 2: Add inactivated_by_change_id Column
```sql
-- Add inactivated_by_change_id column
ALTER TABLE faq_answers
ADD COLUMN inactivated_by_change_id INTEGER;

-- Verify column added
PRAGMA table_info(faq_answers);
-- Should show new column with type=INTEGER, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values
SELECT COUNT(*) as total_answers,
       SUM(CASE WHEN inactivated_by_change_id IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_answers;
-- null_count should equal total_answers
```

### Step 3: Add inactivated_at Column
```sql
-- Add inactivated_at column
ALTER TABLE faq_answers
ADD COLUMN inactivated_at DATETIME;

-- Verify column added
PRAGMA table_info(faq_answers);
-- Should show new column with type=DATETIME, notnull=0, dflt_value=NULL
```

**Validation**:
```sql
-- Verify existing rows have NULL values
SELECT COUNT(*) as total_answers,
       SUM(CASE WHEN inactivated_at IS NULL THEN 1 ELSE 0 END) as null_count
FROM faq_answers;
-- null_count should equal total_answers
```

### Step 4: Create New Indexes
```sql
-- Create index on inactivation_reason
CREATE INDEX IF NOT EXISTS idx_faq_answers_inactivation_reason
    ON faq_answers(inactivation_reason);

-- Create composite index on question_id, status, and inactivated_at
-- This index is CRITICAL for cascade queries and orphan detection
CREATE INDEX IF NOT EXISTS idx_faq_answers_question_status
    ON faq_answers(question_id, status, inactivated_at);

-- Verify indexes created
SELECT name, sql
FROM sqlite_master
WHERE type = 'index'
  AND tbl_name = 'faq_answers'
ORDER BY name;
```

**Expected Indexes**:
- `idx_faq_answers_created` (original)
- `idx_faq_answers_inactivation_reason` (NEW)
- `idx_faq_answers_question_id` (original)
- `idx_faq_answers_question_status` (NEW - critical for cascade)
- `idx_faq_answers_status` (original)

### Step 5: Backfill Cascaded Inactivation Data (If Needed)
If you have inactive answers whose questions are also inactive, backfill their inactivation data:

```sql
-- Backfill cascaded inactivation data
-- For answers that are inactive with inactive questions
UPDATE faq_answers
SET inactivation_reason = 'QUESTION_INACTIVATED',
    inactivated_by_change_id = (
        SELECT q.inactivated_by_change_id
        FROM faq_questions q
        WHERE q.question_id = faq_answers.question_id
    ),
    inactivated_at = (
        SELECT q.inactivated_at
        FROM faq_questions q
        WHERE q.question_id = faq_answers.question_id
    ),
    modified_at = CURRENT_TIMESTAMP
WHERE status = 'inactive'
  AND EXISTS (
      SELECT 1
      FROM faq_questions q
      WHERE q.question_id = faq_answers.question_id
        AND q.status = 'inactive'
  );

-- Verify backfill
SELECT COUNT(*) as backfilled_answers
FROM faq_answers
WHERE inactivation_reason = 'QUESTION_INACTIVATED';
```

### Step 6: Verify Schema Consistency
```sql
-- Verify all active answers have NULL inactivation fields
SELECT COUNT(*) as active_answers_with_invalid_state
FROM faq_answers
WHERE status = 'active'
  AND (inactivation_reason IS NOT NULL
       OR inactivated_by_change_id IS NOT NULL
       OR inactivated_at IS NOT NULL);
-- Should return 0

-- Verify no orphaned active answers exist
SELECT COUNT(*) as orphaned_active_answers
FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.status = 'active'
  AND q.status = 'inactive';
-- Should return 0

-- Verify table structure matches expected schema
PRAGMA table_info(faq_answers);
-- Should show 11 columns total (8 original + 3 new)
```

### Step 7: Update Application Code
After database migration, update application code to:
1. Use new inactivation fields when marking answers inactive
2. Implement cascade logic when inactivating questions
3. Validate consistency rules (see VALIDATION_LOGIC_ANSWERS.md)
4. Include inactivation fields in audit queries

**No code changes required for existing functionality** - new columns are NULL for active answers.

## Complete Migration Script

```sql
-- ============================================================================
-- MIGRATION SCRIPT: Add Inactivation Tracking to faq_answers
-- ============================================================================
-- Purpose: Enhance faq_answers table with inactivation audit trail
-- Date: 2025-11-02
-- Author: Analytics Assist Team
-- Prerequisite: faq_questions table must be migrated first
-- ============================================================================

-- Transaction wrapper for atomic migration
BEGIN TRANSACTION;

-- ============================================================================
-- PRE-MIGRATION VALIDATION
-- ============================================================================

-- Check 1: Verify faq_questions has been migrated
SELECT CASE
    WHEN EXISTS (
        SELECT 1 FROM pragma_table_info('faq_questions')
        WHERE name = 'inactivation_reason'
    )
    THEN 'PASS: faq_questions migrated'
    ELSE 'FAIL: faq_questions NOT migrated - run MIGRATION_GUIDE.md first'
END as prereq_check;

-- Check 2: Find orphaned active answers (must be fixed before migration)
SELECT
    COUNT(*) as orphaned_count,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS: No orphaned active answers'
        ELSE 'FAIL: Orphaned active answers found - fix before migration'
    END as orphan_check
FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.status = 'active'
  AND q.status = 'inactive';

-- If orphan_check shows FAIL, rollback and fix orphans first
-- ROLLBACK;

-- ============================================================================
-- SCHEMA MIGRATION
-- ============================================================================

-- Step 1: Add inactivation_reason column
ALTER TABLE faq_answers
ADD COLUMN inactivation_reason TEXT;

-- Step 2: Add inactivated_by_change_id column
ALTER TABLE faq_answers
ADD COLUMN inactivated_by_change_id INTEGER;

-- Step 3: Add inactivated_at column
ALTER TABLE faq_answers
ADD COLUMN inactivated_at DATETIME;

-- Step 4: Create new indexes
CREATE INDEX IF NOT EXISTS idx_faq_answers_inactivation_reason
    ON faq_answers(inactivation_reason);

CREATE INDEX IF NOT EXISTS idx_faq_answers_question_status
    ON faq_answers(question_id, status, inactivated_at);

-- ============================================================================
-- DATA BACKFILL (Optional - only if you have existing inactive answers)
-- ============================================================================

-- Backfill cascaded inactivation data for existing inactive answers
UPDATE faq_answers
SET inactivation_reason = 'QUESTION_INACTIVATED',
    inactivated_by_change_id = (
        SELECT q.inactivated_by_change_id
        FROM faq_questions q
        WHERE q.question_id = faq_answers.question_id
    ),
    inactivated_at = (
        SELECT q.inactivated_at
        FROM faq_questions q
        WHERE q.question_id = faq_answers.question_id
    ),
    modified_at = CURRENT_TIMESTAMP
WHERE status = 'inactive'
  AND EXISTS (
      SELECT 1
      FROM faq_questions q
      WHERE q.question_id = faq_answers.question_id
        AND q.status = 'inactive'
  );

-- ============================================================================
-- POST-MIGRATION VERIFICATION
-- ============================================================================

-- Verification 1: Check migration success
SELECT
    'Migration Verification' as check_name,
    COUNT(*) as total_answers,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count,
    SUM(CASE WHEN inactivation_reason IS NOT NULL THEN 1 ELSE 0 END) as with_reason,
    SUM(CASE WHEN inactivated_by_change_id IS NOT NULL THEN 1 ELSE 0 END) as with_change_id,
    SUM(CASE WHEN inactivated_at IS NOT NULL THEN 1 ELSE 0 END) as with_timestamp
FROM faq_answers;

-- Verification 2: Check for orphaned active answers
SELECT
    'Orphan Check' as check_name,
    COUNT(*) as orphaned_active_answers,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as result
FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.status = 'active'
  AND q.status = 'inactive';

-- Verification 3: Check consistency for active answers
SELECT
    'Active Answer Consistency' as check_name,
    COUNT(*) as invalid_active_answers,
    CASE
        WHEN COUNT(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END as result
FROM faq_answers
WHERE status = 'active'
  AND (inactivation_reason IS NOT NULL
       OR inactivated_by_change_id IS NOT NULL
       OR inactivated_at IS NOT NULL);

-- If all verifications PASS, commit; otherwise ROLLBACK
COMMIT;

-- ============================================================================
-- END OF MIGRATION SCRIPT
-- ============================================================================
```

## Post-Migration Verification

### Verify Schema
```sql
-- Check table structure
PRAGMA table_info(faq_answers);
-- Should show 11 columns

-- Check indexes
SELECT name FROM sqlite_master
WHERE type = 'index' AND tbl_name = 'faq_answers'
ORDER BY name;
-- Should show 5 indexes
```

### Verify Data Integrity
```sql
-- Verify no data corruption
SELECT COUNT(*) as total_answers FROM faq_answers;
-- Should match pre-migration count

-- Verify no orphaned active answers
SELECT COUNT(*) FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.status = 'active' AND q.status = 'inactive';
-- Should return 0

-- Verify active answers have NULL inactivation fields
SELECT COUNT(*) FROM faq_answers
WHERE status = 'active'
  AND (inactivation_reason IS NOT NULL
       OR inactivated_by_change_id IS NOT NULL
       OR inactivated_at IS NOT NULL);
-- Should return 0
```

### Test Cascade Functionality
```sql
-- Test cascade with a sample question (in development environment only)
BEGIN TRANSACTION;

-- Create test question
INSERT INTO faq_questions (question_id, question_text, status, created_at, modified_at)
VALUES ('Q_TEST_CASCADE', 'Test cascade question', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Create test answers
INSERT INTO faq_answers (answer_id, question_id, answer_text, status, created_at, modified_at)
VALUES
    ('A_TEST_CASCADE_1', 'Q_TEST_CASCADE', 'Test answer 1', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('A_TEST_CASCADE_2', 'Q_TEST_CASCADE', 'Test answer 2', 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Inactivate question with cascade
UPDATE faq_questions
SET status = 'inactive',
    inactivation_reason = 'MANUAL',
    inactivated_at = CURRENT_TIMESTAMP,
    modified_at = CURRENT_TIMESTAMP
WHERE question_id = 'Q_TEST_CASCADE';

-- Cascade to answers
UPDATE faq_answers
SET status = 'inactive',
    inactivation_reason = 'QUESTION_INACTIVATED',
    inactivated_at = (
        SELECT inactivated_at FROM faq_questions WHERE question_id = 'Q_TEST_CASCADE'
    ),
    modified_at = CURRENT_TIMESTAMP
WHERE question_id = 'Q_TEST_CASCADE'
  AND status = 'active';

-- Verify cascade worked
SELECT
    a.answer_id,
    a.status,
    a.inactivation_reason,
    q.status as question_status,
    q.inactivation_reason as question_reason
FROM faq_answers a
INNER JOIN faq_questions q ON a.question_id = q.question_id
WHERE a.question_id = 'Q_TEST_CASCADE';
-- All answers should be inactive with reason 'QUESTION_INACTIVATED'

-- Verify no orphans
SELECT COUNT(*) FROM faq_answers
WHERE question_id = 'Q_TEST_CASCADE' AND status = 'active';
-- Should return 0

-- Clean up test data
ROLLBACK;
```

## Rollback Procedure

### If Migration Fails (Before COMMIT)
```sql
-- Simply rollback the transaction
ROLLBACK;
```

### If Migration Succeeds But Issues Found (After COMMIT)
SQLite has limited ALTER TABLE support. Cannot easily drop columns.

**Option 1: Keep columns, ignore in application**
```sql
-- Do nothing - columns remain but are not used
-- Application code ignores new columns
-- Low risk, no data loss
```

**Option 2: Full table recreation (COMPLEX - Not Recommended)**
```sql
-- WARNING: High risk operation, only if absolutely necessary
-- Requires rebuilding table without new columns

BEGIN TRANSACTION;

-- 1. Create original schema table with temporary name
CREATE TABLE faq_answers_old AS
SELECT
    answer_id,
    question_id,
    answer_text,
    answer_format,
    confidence_score,
    status,
    created_at,
    modified_at
FROM faq_answers;

-- 2. Drop enhanced table
DROP TABLE faq_answers;

-- 3. Rename old table back
ALTER TABLE faq_answers_old RENAME TO faq_answers;

-- 4. Recreate original indexes
CREATE INDEX IF NOT EXISTS idx_faq_answers_question_id ON faq_answers(question_id);
CREATE INDEX IF NOT EXISTS idx_faq_answers_status ON faq_answers(status);
CREATE INDEX IF NOT EXISTS idx_faq_answers_created ON faq_answers(created_at);

COMMIT;
```

**Recommendation**: Use Option 1 (keep columns) unless critical issue. Option 2 has high risk of data loss.

## Testing Recommendations

### Pre-Migration Testing (Development Environment)
1. Restore production backup to development database
2. Verify faq_questions migration completed
3. Run orphan detection query
4. Run migration script on development database
5. Verify schema with PRAGMA table_info
6. Verify indexes with SELECT from sqlite_master
7. Test cascade functionality with sample data
8. Run sample queries to ensure performance
9. Test application code with enhanced schema

### Post-Migration Testing (Production)
1. Verify schema matches expected structure
2. Check all existing queries still work
3. Test inactivation workflow end-to-end
4. Test cascade workflow (question → answers)
5. Run orphan detection audit
6. Monitor query performance on new indexes
7. Verify application validation logic

## Migration Checklist

- [ ] Verify faq_questions migration completed
- [ ] Backup current database
- [ ] Verify current schema structure
- [ ] Run orphan detection query (fix if found)
- [ ] Close all other database connections
- [ ] Run migration script (in transaction)
- [ ] Verify schema with PRAGMA table_info (11 columns)
- [ ] Verify indexes created (5 indexes)
- [ ] Verify no data corruption (row count matches)
- [ ] Verify all active answers have NULL inactivation fields
- [ ] Verify no orphaned active answers
- [ ] Backfill existing inactive answers (if applicable)
- [ ] Test cascade functionality (dev environment)
- [ ] Test sample queries (SELECT with new columns)
- [ ] Update application code to use new fields
- [ ] Implement cascade logic in application
- [ ] Test inactivation workflow end-to-end
- [ ] Monitor production for issues
- [ ] Document migration completion

## Databricks Migration

### Differences from SQLite
Databricks Delta Lake has more flexible ALTER TABLE support:

```sql
-- Add columns (can add multiple at once)
ALTER TABLE faq_answers
ADD COLUMNS (
    inactivation_reason STRING,
    inactivated_by_change_id INT,
    inactivated_at TIMESTAMP
);

-- Create indexes (slightly different syntax)
-- Note: Databricks uses CREATE INDEX without IF NOT EXISTS
CREATE INDEX idx_faq_answers_inactivation_reason
    ON faq_answers(inactivation_reason);

CREATE INDEX idx_faq_answers_question_status
    ON faq_answers(question_id, status, inactivated_at);
```

### Databricks Considerations
1. ALTER TABLE ADD COLUMNS supports multiple columns in single statement
2. Indexes created differently (no IF NOT EXISTS)
3. TIMESTAMP type instead of DATETIME
4. Foreign keys are metadata only (not enforced)
5. CASCADE logic MUST be implemented in application code

## Frequently Asked Questions

### Q: Will this break existing queries?
**A**: No. New columns are nullable and default to NULL. Existing queries that don't reference new columns will work unchanged.

### Q: Do I need to migrate data?
**A**: Only if you have existing inactive answers. For active answers, NULL values are correct. For inactive answers, you should backfill with 'QUESTION_INACTIVATED' if the question is also inactive.

### Q: What if I have inactive answers with active questions?
**A**: This is a data integrity issue that should be investigated. Options:
1. Reactivate the answers (if appropriate)
2. Inactivate the question (if appropriate)
3. Document as exceptional case and add manual inactivation_reason

### Q: What if I have active answers with inactive questions?
**A**: This is an orphan that MUST be fixed before migration. Run the orphan detection query and inactivate these answers first.

### Q: How do I test cascade functionality?
**A**: See "Test Cascade Functionality" section above. Always test in development environment first.

### Q: Can I run this migration on a production database?
**A**: Yes, but follow best practices:
1. Complete faq_questions migration first
2. Schedule during low-traffic period
3. Backup first
4. Test in development environment first
5. Use transaction to enable rollback
6. Monitor closely after migration

### Q: How long will migration take?
**A**: Very fast - ALTER TABLE ADD COLUMN is a metadata operation in SQLite. Even with millions of rows, should complete in seconds. Backfill (if needed) may take longer depending on number of inactive answers.

### Q: Will this impact performance?
**A**: Minimal impact. New indexes may slightly increase INSERT/UPDATE time, but improve query performance for cascade queries and orphan detection.

### Q: What happens if cascade logic is not implemented correctly?
**A**: You may end up with orphaned active answers (active answers for inactive questions), which violates data integrity. Run periodic audits to detect and fix orphans.

## Related Documentation
- [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) - faq_questions migration (prerequisite)
- [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) - Design rationale
- [03_faq_answers_enhanced.sql](./03_faq_answers_enhanced.sql) - Enhanced schema
- [CASCADE_LOGIC.md](./CASCADE_LOGIC.md) - Cascade implementation guide
- [VALIDATION_LOGIC_ANSWERS.md](./VALIDATION_LOGIC_ANSWERS.md) - Application validation rules

## Version History
- 2025-11-02: Initial migration guide (Item 70)

## Authors
Analytics Assist Team
