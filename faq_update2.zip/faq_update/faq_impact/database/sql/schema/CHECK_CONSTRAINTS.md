# FAQ Impact Table - CHECK Constraints Documentation

**Version**: 1.0.0
**Date**: 2025-11-02
**Owner**: Analytics Assist Team
**Status**: Final

---

## Overview

This document specifies all application-level CHECK constraints for the `faq_impact` table. These constraints are **NOT enforced by the database** (to maintain Databricks compatibility) but are **REQUIRED to be validated** by application code before any INSERT or UPDATE operation.

---

## Why Application-Level Constraints?

### Design Decision

The `faq_impact` table uses **application-level constraint validation** instead of database-level CHECK constraints for these reasons:

1. **Databricks Compatibility**: Databricks Delta Lake has limited support for CHECK constraints
2. **Cross-Database Consistency**: Ensures identical validation logic for SQLite and Databricks
3. **Rich Error Messages**: Application code can provide detailed, user-friendly error messages
4. **Complex Validation**: Some constraints require lookups or business logic beyond simple CHECK syntax
5. **Centralized Logic**: All validation in one place (Python code) rather than split between SQL and Python

### Enforcement Strategy

```
┌─────────────────────────────────────────────────────────────┐
│  Application Layer (Python)                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ImpactRepository.create_impact_decision()            │   │
│  │   1. Validate all CHECK constraints                 │   │
│  │   2. Raise ValueError if validation fails           │   │
│  │   3. Insert only if validation passes               │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│  Database Layer (SQLite/Databricks)                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ faq_impact table                                     │   │
│  │   - No database-level CHECK constraints             │   │
│  │   - Relies on application validation                │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## Constraint Catalog

### Constraint 1: entity_type Enum Validation

**Rule**: `entity_type` must be one of the valid `EntityType` enum values

**SQL Equivalent (not enforced)**:
```sql
CHECK (entity_type IN ('QUESTION', 'ANSWER', 'CHANGE'))
```

**Validation Logic**:
```python
from faq_impact.core.enums import EntityType

def validate_entity_type(entity_type: str) -> None:
    """
    Validate entity_type is a valid EntityType enum value.

    Args:
        entity_type: The entity type string to validate

    Raises:
        ValueError: If entity_type is not valid
    """
    try:
        EntityType.from_string(entity_type)
    except ValueError as e:
        raise ValueError(
            f"Invalid entity_type: '{entity_type}'. "
            f"Must be one of: {[e.value for e in EntityType]}"
        ) from e
```

**Valid Values**:
- `'QUESTION'` - Decision applies to a question entity
- `'ANSWER'` - Decision applies to an answer entity
- `'CHANGE'` - Decision applies to a change entity

**Example Violations**:
```python
# INVALID: Typo in enum value
entity_type = "QUESTIONS"  # Should be "QUESTION"
# INVALID: Lowercase
entity_type = "question"   # Must be uppercase
# INVALID: Non-existent type
entity_type = "CONTENT"    # Not a valid EntityType
```

**Rationale**: Ensures polymorphic entity_id references are valid and type-safe

---

### Constraint 2: decision Enum Validation

**Rule**: `decision` must be one of the valid `DecisionType` enum values

**SQL Equivalent (not enforced)**:
```sql
CHECK (decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE', 'EVALUATE', 'NOOP'))
```

**Validation Logic**:
```python
from faq_impact.core.enums import DecisionType

def validate_decision(decision: str) -> None:
    """
    Validate decision is a valid DecisionType enum value.

    Args:
        decision: The decision type string to validate

    Raises:
        ValueError: If decision is not valid
    """
    try:
        DecisionType.from_string(decision)
    except ValueError as e:
        raise ValueError(
            f"Invalid decision: '{decision}'. "
            f"Must be one of: {[d.value for d in DecisionType]}"
        ) from e
```

**Valid Values**:
- `'PLAN_CREATE'` - Create new question from new content
- `'REGEN_Q'` - Regenerate question only
- `'REGEN_A'` - Regenerate answer only
- `'REGEN_BOTH'` - Regenerate both question and answer
- `'INACTIVATE'` - Mark question or answer as inactive
- `'EVALUATE'` - Needs LLM evaluation to decide
- `'NOOP'` - No operation needed

**Example Violations**:
```python
# INVALID: Typo
decision = "REGENERATE_A"  # Should be "REGEN_A"
# INVALID: Wrong format
decision = "create_plan"   # Should be "PLAN_CREATE"
```

**Rationale**: Ensures decision types are recognized by execution engine

---

### Constraint 3: reason Enum Validation

**Rule**: `reason` must be one of the valid `ReasonCode` enum values

**SQL Equivalent (not enforced)**:
```sql
CHECK (reason IN ('NEW_CONTENT_ADDED', 'SOLE_SOURCE_MODIFIED_MAJOR', 'TOKEN_OVERLAP_DETECTED', ...))
-- (Full list of 24 reason codes)
```

**Validation Logic**:
```python
from faq_impact.core.enums import ReasonCode

def validate_reason(reason: str) -> None:
    """
    Validate reason is a valid ReasonCode enum value.

    Args:
        reason: The reason code string to validate

    Raises:
        ValueError: If reason is not valid
    """
    try:
        ReasonCode.from_string(reason)
    except ValueError as e:
        raise ValueError(
            f"Invalid reason: '{reason}'. "
            f"Must be one of: {[r.value for r in ReasonCode]}"
        ) from e
```

**Valid Values**: See [ReasonCode enum](../../core/enums/reason_code.py) for full list (24 values)

**Rationale**: Ensures audit trail has valid, documented reasons

---

### Constraint 4: Decision-Reason Compatibility

**Rule**: `reason` must be compatible with `decision` (each reason maps to exactly one decision type)

**SQL Equivalent (not enforced)**:
```sql
-- Too complex for SQL CHECK constraint
-- Requires mapping table or complex CASE statement
```

**Validation Logic**:
```python
from faq_impact.core.enums import DecisionType, ReasonCode

def validate_decision_reason_compatibility(decision: str, reason: str) -> None:
    """
    Validate that reason code is compatible with decision type.

    Args:
        decision: DecisionType enum value
        reason: ReasonCode enum value

    Raises:
        ValueError: If reason is not compatible with decision
    """
    decision_enum = DecisionType.from_string(decision)
    reason_enum = ReasonCode.from_string(reason)

    if not ReasonCode.is_compatible(decision_enum, reason_enum):
        expected_decision = reason_enum.get_decision_type()
        valid_reasons = ReasonCode.get_reasons_for_decision(decision_enum)
        raise ValueError(
            f"Incompatible decision-reason pair: "
            f"decision='{decision}', reason='{reason}'. "
            f"Reason '{reason}' is valid for decision '{expected_decision.value}', not '{decision}'. "
            f"Valid reasons for '{decision}': {[r.value for r in valid_reasons]}"
        )
```

**Example Valid Pairs**:
```python
# Valid: NEW_CONTENT_ADDED is for PLAN_CREATE
decision = "PLAN_CREATE", reason = "NEW_CONTENT_ADDED"

# Valid: TOKEN_OVERLAP_DETECTED is for REGEN_A
decision = "REGEN_A", reason = "TOKEN_OVERLAP_DETECTED"
```

**Example Violations**:
```python
# INVALID: NEW_CONTENT_ADDED is for PLAN_CREATE, not REGEN_A
decision = "REGEN_A", reason = "NEW_CONTENT_ADDED"

# INVALID: TOKEN_OVERLAP_DETECTED is for REGEN_A, not INACTIVATE
decision = "INACTIVATE", reason = "TOKEN_OVERLAP_DETECTED"
```

**Rationale**: Prevents illogical decision-reason combinations that would confuse audit analysis

---

### Constraint 5: applied Boolean Validation

**Rule**: `applied` must be 0 (pending) or 1 (applied)

**SQL Equivalent (not enforced)**:
```sql
CHECK (applied IN (0, 1))
```

**Validation Logic**:
```python
def validate_applied(applied: int) -> None:
    """
    Validate applied flag is 0 or 1 (SQLite boolean).

    Args:
        applied: The applied flag value

    Raises:
        ValueError: If applied is not 0 or 1
    """
    if applied not in (0, 1):
        raise ValueError(
            f"Invalid applied flag: {applied}. Must be 0 (pending) or 1 (applied)."
        )
```

**Valid Values**:
- `0` - Decision pending (not yet executed)
- `1` - Decision applied (successfully executed)

**Example Violations**:
```python
# INVALID: Not a boolean
applied = 2
# INVALID: String instead of integer
applied = "true"
```

**Rationale**: Ensures boolean flag is stored correctly for SQLite (which doesn't have native BOOLEAN type)

---

### Constraint 6: applied=1 Implies applied_at NOT NULL

**Rule**: If `applied = 1`, then `applied_at` must NOT be NULL

**SQL Equivalent (not enforced)**:
```sql
CHECK (applied = 0 OR applied_at IS NOT NULL)
```

**Validation Logic**:
```python
from datetime import datetime
from typing import Optional

def validate_applied_timestamp(applied: int, applied_at: Optional[str]) -> None:
    """
    Validate that if applied=1, then applied_at is NOT NULL.

    Args:
        applied: Applied flag (0 or 1)
        applied_at: Applied timestamp (ISO-8601 string or None)

    Raises:
        ValueError: If applied=1 but applied_at is NULL
    """
    if applied == 1 and applied_at is None:
        raise ValueError(
            "If applied=1 (decision executed), applied_at timestamp must be NOT NULL. "
            "Set applied_at to CURRENT_TIMESTAMP when marking decision as applied."
        )

    # Optional: Validate timestamp format if present
    if applied_at is not None:
        try:
            datetime.fromisoformat(applied_at.replace('Z', '+00:00'))
        except ValueError as e:
            raise ValueError(
                f"Invalid applied_at timestamp format: '{applied_at}'. "
                f"Must be ISO-8601 format (e.g., '2025-11-02T14:30:00Z')"
            ) from e
```

**Example Valid Cases**:
```python
# Valid: Pending decision (applied=0, applied_at=NULL)
applied=0, applied_at=None

# Valid: Applied decision (applied=1, applied_at set)
applied=1, applied_at="2025-11-02T14:30:00Z"
```

**Example Violations**:
```python
# INVALID: Applied but no timestamp
applied=1, applied_at=None  # Violates constraint
```

**Rationale**: Ensures audit trail records when decisions were executed

---

### Constraint 7: priority Range Validation

**Rule**: `priority` must be between 1 and 10 (inclusive), or NULL

**SQL Equivalent (not enforced)**:
```sql
CHECK (priority BETWEEN 1 AND 10 OR priority IS NULL)
```

**Validation Logic**:
```python
from typing import Optional

def validate_priority(priority: Optional[int]) -> None:
    """
    Validate priority is in range 1-10 or NULL.

    Args:
        priority: Priority value (1-10 or None)

    Raises:
        ValueError: If priority is out of range
    """
    if priority is not None:
        if not isinstance(priority, int):
            raise ValueError(
                f"Invalid priority type: {type(priority).__name__}. Must be integer or None."
            )
        if priority < 1 or priority > 10:
            raise ValueError(
                f"Invalid priority: {priority}. Must be between 1 and 10 (inclusive), or NULL. "
                f"Priority scale: 1=low, 5=medium, 10=high"
            )
```

**Valid Values**:
- `NULL` - Default priority
- `1-10` - Explicit priority (1=low, 5=medium, 10=high)

**Example Violations**:
```python
# INVALID: Below range
priority = 0
# INVALID: Above range
priority = 11
# INVALID: Negative
priority = -5
```

**Rationale**: Ensures priority values are in documented range for execution ordering

---

### Constraint 8: details JSON Validity

**Rule**: `details` must be valid JSON or NULL

**SQL Equivalent (not enforced)**:
```sql
-- No direct SQL equivalent
-- SQLite json_valid() function exists but not enforced via CHECK
```

**Validation Logic**:
```python
import json
from typing import Optional

def validate_details_json(details: Optional[str]) -> None:
    """
    Validate details is valid JSON or NULL.

    Args:
        details: JSON string or None

    Raises:
        ValueError: If details is not valid JSON
    """
    if details is not None:
        try:
            json.loads(details)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in details column: {e}. "
                f"Details must be valid JSON or NULL."
            ) from e
```

**Valid Values**:
- `NULL` - No details (simple decisions like NOOP)
- Valid JSON string - Decision-specific metadata

**Example Violations**:
```python
# INVALID: Malformed JSON
details = '{"key": "value"'  # Missing closing brace

# INVALID: Single quotes (not valid JSON)
details = "{'key': 'value'}"  # Must use double quotes
```

**Rationale**: Ensures details can be parsed without errors during execution

---

### Constraint 9: change_id Foreign Key Validation

**Rule**: `change_id` must reference an existing `content_change_log.change_id`

**SQL Equivalent (not enforced)**:
```sql
-- Foreign key declared but not enforced in Databricks
FOREIGN KEY (change_id) REFERENCES content_change_log(change_id)
```

**Validation Logic**:
```python
from typing import Any
from faq_impact.database.repository import ChangeLogRepository

def validate_change_id_fk(change_id: int, db_connection: Any) -> None:
    """
    Validate change_id references existing content_change_log record.

    Args:
        change_id: The change ID to validate
        db_connection: Database connection for lookup

    Raises:
        ValueError: If change_id does not exist in content_change_log
    """
    repo = ChangeLogRepository(db_connection)
    if not repo.change_exists(change_id):
        raise ValueError(
            f"Invalid change_id: {change_id}. "
            f"No matching record found in content_change_log table. "
            f"Change must be created before impact decisions can reference it."
        )
```

**Rationale**: Maintains referential integrity (not enforced by Databricks)

---

### Constraint 10: entity_id Polymorphic Foreign Key Validation

**Rule**: `entity_id` must reference the appropriate table based on `entity_type`

**SQL Equivalent (not enforced)**:
```sql
-- Too complex for SQL CHECK constraint
-- Polymorphic foreign key requires conditional logic
```

**Validation Logic**:
```python
from typing import Any
from faq_impact.core.enums import EntityType
from faq_impact.database.repository import QuestionRepository, AnswerRepository, ChangeLogRepository

def validate_entity_id_polymorphic_fk(
    entity_type: str,
    entity_id: str,
    db_connection: Any
) -> None:
    """
    Validate entity_id references correct table based on entity_type.

    Polymorphic FK validation:
      - entity_type='QUESTION' → faq_questions.question_id
      - entity_type='ANSWER'   → faq_answers.answer_id
      - entity_type='CHANGE'   → content_change_log.change_id (as TEXT)

    Args:
        entity_type: EntityType enum value
        entity_id: Entity ID to validate
        db_connection: Database connection for lookup

    Raises:
        ValueError: If entity_id does not exist in appropriate table
    """
    entity_type_enum = EntityType.from_string(entity_type)

    if entity_type_enum == EntityType.QUESTION:
        # Validate against faq_questions
        repo = QuestionRepository(db_connection)
        if not repo.question_exists(entity_id):
            raise ValueError(
                f"Invalid entity_id for entity_type='QUESTION': '{entity_id}'. "
                f"No matching question_id found in faq_questions table."
            )

    elif entity_type_enum == EntityType.ANSWER:
        # Validate against faq_answers
        repo = AnswerRepository(db_connection)
        if not repo.answer_exists(entity_id):
            raise ValueError(
                f"Invalid entity_id for entity_type='ANSWER': '{entity_id}'. "
                f"No matching answer_id found in faq_answers table."
            )

    elif entity_type_enum == EntityType.CHANGE:
        # Validate against content_change_log
        repo = ChangeLogRepository(db_connection)
        change_id_int = int(entity_id)  # Convert TEXT to INT
        if not repo.change_exists(change_id_int):
            raise ValueError(
                f"Invalid entity_id for entity_type='CHANGE': '{entity_id}'. "
                f"No matching change_id found in content_change_log table."
            )
```

**Special Case**: `entity_type='QUESTION'` and `decision='PLAN_CREATE'`

For `PLAN_CREATE` decisions, the question doesn't exist yet (it will be created during execution). In this case, `entity_id` can be:
- `NULL` (preferred)
- Placeholder value like `"PENDING_CREATION"` (if NULL not allowed by application logic)

**Validation Logic for PLAN_CREATE**:
```python
def validate_entity_id_plan_create(
    decision: str,
    entity_type: str,
    entity_id: str,
    db_connection: Any
) -> None:
    """
    Special validation for PLAN_CREATE: entity may not exist yet.

    Args:
        decision: DecisionType enum value
        entity_type: EntityType enum value
        entity_id: Entity ID (may be placeholder)
        db_connection: Database connection

    Raises:
        ValueError: If validation fails
    """
    if decision == "PLAN_CREATE":
        # For PLAN_CREATE, entity_id can be NULL or placeholder
        if entity_id not in (None, "", "PENDING_CREATION"):
            # If entity_id is specified, warn (but don't fail)
            print(
                f"Warning: PLAN_CREATE decision has entity_id='{entity_id}'. "
                f"Entity may not exist yet; this will be set after creation."
            )
    else:
        # For all other decisions, entity must exist
        validate_entity_id_polymorphic_fk(entity_type, entity_id, db_connection)
```

**Rationale**: Maintains referential integrity for polymorphic relationships

---

## Complete Validation Function

### All Constraints in One Function

```python
from typing import Optional, Any
from faq_impact.core.enums import EntityType, DecisionType, ReasonCode

def validate_all_constraints(
    entity_type: str,
    entity_id: str,
    change_id: int,
    decision: str,
    reason: str,
    details: Optional[str],
    applied: int,
    applied_at: Optional[str],
    priority: Optional[int],
    db_connection: Any
) -> None:
    """
    Validate ALL application-level CHECK constraints for faq_impact table.

    This function MUST be called before any INSERT or UPDATE to faq_impact table.

    Args:
        entity_type: EntityType enum value
        entity_id: Entity ID (polymorphic reference)
        change_id: Content change ID
        decision: DecisionType enum value
        reason: ReasonCode enum value
        details: JSON string or None
        applied: Applied flag (0 or 1)
        applied_at: Applied timestamp or None
        priority: Priority (1-10 or None)
        db_connection: Database connection for FK validation

    Raises:
        ValueError: If any constraint validation fails (with detailed message)

    Example:
        >>> try:
        ...     validate_all_constraints(
        ...         entity_type="QUESTION",
        ...         entity_id="Q123",
        ...         change_id=12345,
        ...         decision="REGEN_Q",
        ...         reason="SOLE_SOURCE_MODIFIED_MAJOR",
        ...         details='{"similarity_score": 0.65}',
        ...         applied=0,
        ...         applied_at=None,
        ...         priority=7,
        ...         db_connection=conn
        ...     )
        ... except ValueError as e:
        ...     print(f"Validation failed: {e}")
        ...     # Handle error (e.g., return error to user, log, etc.)
    """
    # Constraint 1: entity_type enum
    validate_entity_type(entity_type)

    # Constraint 2: decision enum
    validate_decision(decision)

    # Constraint 3: reason enum
    validate_reason(reason)

    # Constraint 4: decision-reason compatibility
    validate_decision_reason_compatibility(decision, reason)

    # Constraint 5: applied boolean
    validate_applied(applied)

    # Constraint 6: applied=1 implies applied_at NOT NULL
    validate_applied_timestamp(applied, applied_at)

    # Constraint 7: priority range
    validate_priority(priority)

    # Constraint 8: details JSON validity
    validate_details_json(details)

    # Constraint 9: change_id FK
    validate_change_id_fk(change_id, db_connection)

    # Constraint 10: entity_id polymorphic FK
    validate_entity_id_plan_create(decision, entity_type, entity_id, db_connection)
```

---

## Error Handling

### Validation Error Examples

```python
# Example 1: Invalid entity_type
try:
    validate_all_constraints(
        entity_type="INVALID",  # Not in EntityType enum
        entity_id="Q123",
        change_id=12345,
        decision="REGEN_Q",
        reason="SOLE_SOURCE_MODIFIED_MAJOR",
        details=None,
        applied=0,
        applied_at=None,
        priority=5,
        db_connection=conn
    )
except ValueError as e:
    # Error message:
    # "Invalid entity_type: 'INVALID'. Must be one of: ['QUESTION', 'ANSWER', 'CHANGE']"
    print(e)

# Example 2: Incompatible decision-reason
try:
    validate_all_constraints(
        entity_type="QUESTION",
        entity_id="Q123",
        change_id=12345,
        decision="REGEN_Q",
        reason="NEW_CONTENT_ADDED",  # Wrong! This reason is for PLAN_CREATE
        details=None,
        applied=0,
        applied_at=None,
        priority=5,
        db_connection=conn
    )
except ValueError as e:
    # Error message:
    # "Incompatible decision-reason pair: decision='REGEN_Q', reason='NEW_CONTENT_ADDED'.
    #  Reason 'NEW_CONTENT_ADDED' is valid for decision 'PLAN_CREATE', not 'REGEN_Q'.
    #  Valid reasons for 'REGEN_Q': ['SOLE_SOURCE_MODIFIED_MAJOR', 'SOLE_SOURCE_CONTENT_CHANGED']"
    print(e)
```

---

## Testing

### Unit Tests for Constraints

```python
import pytest
from faq_impact.database.validation import validate_all_constraints

def test_constraint_entity_type_invalid():
    """Test constraint 1: invalid entity_type."""
    with pytest.raises(ValueError, match="Invalid entity_type"):
        validate_entity_type("INVALID_TYPE")

def test_constraint_decision_reason_compatibility():
    """Test constraint 4: incompatible decision-reason pair."""
    with pytest.raises(ValueError, match="Incompatible decision-reason pair"):
        validate_decision_reason_compatibility("REGEN_Q", "NEW_CONTENT_ADDED")

def test_constraint_applied_timestamp_missing():
    """Test constraint 6: applied=1 but applied_at is NULL."""
    with pytest.raises(ValueError, match="applied_at timestamp must be NOT NULL"):
        validate_applied_timestamp(applied=1, applied_at=None)

def test_constraint_priority_out_of_range():
    """Test constraint 7: priority out of range."""
    with pytest.raises(ValueError, match="Must be between 1 and 10"):
        validate_priority(priority=15)

def test_constraint_details_invalid_json():
    """Test constraint 8: invalid JSON in details."""
    with pytest.raises(ValueError, match="Invalid JSON"):
        validate_details_json('{"key": "value"')  # Missing closing brace
```

---

## Related Documentation

- [07_faq_impact.sql](07_faq_impact.sql): Table schema with constraint comments
- [core/enums/validators.py](../../core/enums/validators.py): Enum validation functions
- [database/repository/impact_repository.py](../../database/repository/impact_repository.py): Repository with constraint enforcement
- [IMPLEMENTATION_PLAN.md](../../../IMPLEMENTATION_PLAN.md): Section 2.3, Item 79

---

## Version History

- **2025-11-02**: Initial constraints documentation
  - Documented all 10 application-level CHECK constraints
  - Provided validation logic and examples
  - Added complete validation function
  - Included error handling and testing examples
