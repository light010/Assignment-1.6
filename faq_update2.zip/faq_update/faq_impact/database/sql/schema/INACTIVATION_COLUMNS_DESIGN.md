# Inactivation Columns Design for faq_questions Table

## Overview
This document describes the design of three new columns added to the `faq_questions` table to support comprehensive inactivation tracking and audit trails.

## Design Rationale

### Business Need
When FAQ questions become invalid due to:
- Source content deletion
- All source content becoming invalid
- Manual quality control decisions
- Automated quality checks failing

...we need to:
1. Track WHY the question was inactivated (audit trail)
2. Link the inactivation to the specific content change that triggered it (traceability)
3. Record WHEN the inactivation occurred (temporal tracking)

### Technical Requirements
- Must work in both SQLite (development) and Databricks (production)
- Must maintain referential integrity with content_change_log
- Must support NULL values (only populated when status='inactive')
- Must enable efficient querying for audit reports

## Column Specifications

### 1. inactivation_reason (TEXT)

**Purpose**: Records the specific reason a question was marked inactive

**Data Type**: TEXT
- SQLite: TEXT
- Databricks: STRING (equivalent)

**Nullability**: NULL allowed
- NULL when status='active'
- NOT NULL when status='inactive' (enforced by application)

**Valid Values**: Must match InactivationReason enum values
- `CONTENT_DELETED` - Source content chunk was deleted
- `ALL_SOURCES_INVALID` - All source content is now invalid
- `MANUAL` - Manual inactivation by user/admin
- `QUALITY_ISSUE` - Automated quality check failed

**Validation**: Application-level CHECK constraint
```python
# Pseudo-code validation
if status == 'inactive':
    assert inactivation_reason is not None
    assert inactivation_reason in InactivationReason.values()
else:
    assert inactivation_reason is None
```

**Default Value**: NULL

**Usage Example**:
```sql
-- Question inactivated due to content deletion
UPDATE faq_questions
SET status = 'inactive',
    inactivation_reason = 'CONTENT_DELETED',
    inactivated_by_change_id = 12345,
    inactivated_at = CURRENT_TIMESTAMP
WHERE question_id = 'Q001';
```

### 2. inactivated_by_change_id (INTEGER)

**Purpose**: Foreign key reference to the content_change_log entry that triggered this inactivation

**Data Type**: INTEGER
- SQLite: INTEGER
- Databricks: INT (equivalent)

**Nullability**: NULL allowed
- NULL when status='active'
- NULL when inactivation_reason='MANUAL' (no specific change triggered it)
- NOT NULL for other inactivation_reason values (enforced by application)

**Foreign Key Relationship**:
- References: `content_change_log.change_id`
- Type: Application-level validation (no database FK constraint)
- Cascade: None (manual handling if change_log entry deleted)

**Validation**: Application-level constraint
```python
# Pseudo-code validation
if status == 'inactive' and inactivation_reason != 'MANUAL':
    assert inactivated_by_change_id is not None
    assert exists(content_change_log.change_id == inactivated_by_change_id)
elif status == 'inactive' and inactivation_reason == 'MANUAL':
    # change_id is optional for manual inactivations
    pass
else:
    assert inactivated_by_change_id is None
```

**Default Value**: NULL

**Usage Example**:
```sql
-- Question inactivated by change_id 12345
SELECT
    q.question_id,
    q.question_text,
    q.inactivation_reason,
    ccl.change_type,
    ccl.file_name,
    ccl.detection_timestamp
FROM faq_questions q
LEFT JOIN content_change_log ccl ON q.inactivated_by_change_id = ccl.change_id
WHERE q.status = 'inactive';
```

### 3. inactivated_at (DATETIME)

**Purpose**: Timestamp recording when the question was marked inactive

**Data Type**: DATETIME
- SQLite: DATETIME (stored as TEXT in ISO-8601 format)
- Databricks: TIMESTAMP (equivalent)

**Nullability**: NULL allowed
- NULL when status='active'
- NOT NULL when status='inactive' (enforced by application)

**Default Value**: NULL (set to CURRENT_TIMESTAMP on inactivation)

**Validation**: Application-level constraint
```python
# Pseudo-code validation
if status == 'inactive':
    assert inactivated_at is not None
else:
    assert inactivated_at is None
```

**Usage Example**:
```sql
-- Find questions inactivated in the last 7 days
SELECT
    question_id,
    question_text,
    inactivation_reason,
    inactivated_at
FROM faq_questions
WHERE status = 'inactive'
  AND inactivated_at >= datetime('now', '-7 days')
ORDER BY inactivated_at DESC;
```

## Consistency Rules (Application-Level Validation)

### Rule 1: Active Questions
```python
if status == 'active':
    assert inactivation_reason is None
    assert inactivated_by_change_id is None
    assert inactivated_at is None
```

### Rule 2: Inactive Questions - Required Fields
```python
if status == 'inactive':
    assert inactivation_reason is not None
    assert inactivated_at is not None
```

### Rule 3: Inactive Questions - Change ID Logic
```python
if status == 'inactive' and inactivation_reason == 'MANUAL':
    # change_id is optional
    pass
elif status == 'inactive':
    # change_id is required for automated inactivations
    assert inactivated_by_change_id is not None
```

### Rule 4: Immutability
Once a question is inactivated, the inactivation fields should NOT be modified.
- If a question needs to be reactivated, create a NEW question instead
- Preserves complete audit trail

## Database Compatibility

### SQLite Specifics
- TEXT primary keys supported (question_id)
- DATETIME stored as TEXT in ISO-8601 format
- No native enum type (use TEXT with application validation)
- No native foreign key enforcement (use application-level validation)

### Databricks Specifics
- STRING primary keys supported
- TIMESTAMP native type
- No native enum type (use STRING with application validation)
- Foreign key constraints are metadata only (not enforced)

## Migration Considerations

### Adding Columns to Existing Table
SQLite has limited ALTER TABLE support. See [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) for detailed steps.

Summary approach:
1. Add new columns with ALTER TABLE ADD COLUMN
2. Set defaults to NULL
3. Existing rows will have NULL values (correct for active questions)
4. No data migration needed

## Performance Considerations

### Indexes
Two indexes will be created to support common query patterns:
1. Single-column index on `inactivation_reason` for filtering by reason
2. Composite index on `(status, inactivation_reason, inactivated_at)` for audit queries

See [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) for index definitions.

## Related Documentation
- [InactivationReason Enum](../../core/enums/entity_type.py)
- [content_change_log Schema](../../../database/sql/schema/tables/06_content_change_log.sql)
- [Migration Guide](./MIGRATION_GUIDE.md)
- [Validation Logic](./VALIDATION_LOGIC.md)

## Version History
- 2025-11-02: Initial design (Item 52)

## Authors
Analytics Assist Team
