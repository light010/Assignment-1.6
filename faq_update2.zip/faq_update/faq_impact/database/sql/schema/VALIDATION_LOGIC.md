# Validation Logic for Inactivation Consistency

## Overview
This document specifies the application-level validation rules that ensure data consistency for the inactivation tracking columns in the `faq_questions` table.

**Why Application-Level?**
- SQLite and Databricks have limited CHECK constraint support for complex logic
- Application-level validation is consistent across both backends
- Easier to test and maintain in Python code
- Enables custom error messages for better debugging

## Core Validation Rules

### Rule 1: Active Questions Have No Inactivation Data
**Logic**: If a question is active, all inactivation fields must be NULL

**Python Implementation**:
```python
def validate_active_question(question: dict) -> None:
    """
    Validate that active questions have no inactivation data.

    Args:
        question: Dictionary with keys: status, inactivation_reason,
                  inactivated_by_change_id, inactivated_at

    Raises:
        ValidationError: If active question has any inactivation fields set
    """
    if question['status'] == 'active':
        errors = []

        if question.get('inactivation_reason') is not None:
            errors.append("Active question cannot have inactivation_reason set")

        if question.get('inactivated_by_change_id') is not None:
            errors.append("Active question cannot have inactivated_by_change_id set")

        if question.get('inactivated_at') is not None:
            errors.append("Active question cannot have inactivated_at set")

        if errors:
            raise ValidationError(
                f"Invalid active question {question['question_id']}: "
                + "; ".join(errors)
            )
```

**Test Cases**:
```python
# VALID: Active question with all NULL inactivation fields
{
    "question_id": "Q001",
    "status": "active",
    "inactivation_reason": None,
    "inactivated_by_change_id": None,
    "inactivated_at": None
}

# INVALID: Active question with inactivation_reason set
{
    "question_id": "Q002",
    "status": "active",
    "inactivation_reason": "CONTENT_DELETED",  # ERROR
    "inactivated_by_change_id": None,
    "inactivated_at": None
}
```

### Rule 2: Inactive Questions Must Have Reason and Timestamp
**Logic**: If a question is inactive, `inactivation_reason` and `inactivated_at` must be NOT NULL

**Python Implementation**:
```python
def validate_inactive_question_required_fields(question: dict) -> None:
    """
    Validate that inactive questions have required inactivation fields.

    Args:
        question: Dictionary with keys: status, inactivation_reason, inactivated_at

    Raises:
        ValidationError: If inactive question is missing required fields
    """
    if question['status'] == 'inactive':
        errors = []

        if question.get('inactivation_reason') is None:
            errors.append("Inactive question must have inactivation_reason")

        if question.get('inactivated_at') is None:
            errors.append("Inactive question must have inactivated_at timestamp")

        if errors:
            raise ValidationError(
                f"Invalid inactive question {question['question_id']}: "
                + "; ".join(errors)
            )
```

**Test Cases**:
```python
# VALID: Inactive question with reason and timestamp
{
    "question_id": "Q003",
    "status": "inactive",
    "inactivation_reason": "CONTENT_DELETED",
    "inactivated_by_change_id": 12345,
    "inactivated_at": "2025-11-02T10:30:00"
}

# INVALID: Inactive question missing inactivation_reason
{
    "question_id": "Q004",
    "status": "inactive",
    "inactivation_reason": None,  # ERROR
    "inactivated_by_change_id": 12345,
    "inactivated_at": "2025-11-02T10:30:00"
}
```

### Rule 3: Inactivation Reason Must Be Valid Enum Value
**Logic**: `inactivation_reason` must match a value from `InactivationReason` enum

**Python Implementation**:
```python
from faq_impact.core.enums import InactivationReason

def validate_inactivation_reason(question: dict) -> None:
    """
    Validate that inactivation_reason is a valid enum value.

    Args:
        question: Dictionary with keys: inactivation_reason

    Raises:
        ValidationError: If inactivation_reason is not valid
    """
    reason = question.get('inactivation_reason')

    if reason is not None:
        try:
            InactivationReason.from_string(reason)
        except ValueError as e:
            raise ValidationError(
                f"Invalid inactivation_reason for question {question['question_id']}: {e}"
            )
```

**Test Cases**:
```python
# VALID: Uses enum value
{
    "question_id": "Q005",
    "status": "inactive",
    "inactivation_reason": "CONTENT_DELETED",  # Valid enum
    "inactivated_at": "2025-11-02T10:30:00"
}

# INVALID: Invalid enum value
{
    "question_id": "Q006",
    "status": "inactive",
    "inactivation_reason": "INVALID_REASON",  # ERROR
    "inactivated_at": "2025-11-02T10:30:00"
}
```

### Rule 4: Change ID Required for Non-Manual Inactivations
**Logic**: If `inactivation_reason` is not 'MANUAL', then `inactivated_by_change_id` must be NOT NULL

**Python Implementation**:
```python
def validate_inactivation_change_id(question: dict) -> None:
    """
    Validate that non-manual inactivations have a change_id.

    Args:
        question: Dictionary with keys: inactivation_reason, inactivated_by_change_id

    Raises:
        ValidationError: If non-manual inactivation missing change_id
    """
    reason = question.get('inactivation_reason')
    change_id = question.get('inactivated_by_change_id')

    if reason is not None and reason != 'MANUAL':
        if change_id is None:
            raise ValidationError(
                f"Question {question['question_id']} has inactivation_reason='{reason}' "
                f"but is missing inactivated_by_change_id. Non-manual inactivations "
                f"must reference a content change."
            )
```

**Test Cases**:
```python
# VALID: Non-manual inactivation with change_id
{
    "question_id": "Q007",
    "status": "inactive",
    "inactivation_reason": "CONTENT_DELETED",
    "inactivated_by_change_id": 12345,  # Required
    "inactivated_at": "2025-11-02T10:30:00"
}

# VALID: Manual inactivation without change_id
{
    "question_id": "Q008",
    "status": "inactive",
    "inactivation_reason": "MANUAL",
    "inactivated_by_change_id": None,  # OK for MANUAL
    "inactivated_at": "2025-11-02T10:30:00"
}

# INVALID: Non-manual inactivation missing change_id
{
    "question_id": "Q009",
    "status": "inactive",
    "inactivation_reason": "QUALITY_ISSUE",
    "inactivated_by_change_id": None,  # ERROR
    "inactivated_at": "2025-11-02T10:30:00"
}
```

### Rule 5: Change ID Must Reference Valid Change Log Entry
**Logic**: If `inactivated_by_change_id` is NOT NULL, it must reference an existing `content_change_log.change_id`

**Python Implementation**:
```python
def validate_change_id_exists(question: dict, db_connection) -> None:
    """
    Validate that inactivated_by_change_id references a real change log entry.

    Args:
        question: Dictionary with keys: inactivated_by_change_id
        db_connection: Database connection for validation query

    Raises:
        ValidationError: If change_id doesn't exist in content_change_log
    """
    change_id = question.get('inactivated_by_change_id')

    if change_id is not None:
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM content_change_log WHERE change_id = ?",
            (change_id,)
        )
        exists = cursor.fetchone()[0] > 0

        if not exists:
            raise ValidationError(
                f"Question {question['question_id']} references non-existent "
                f"change_id {change_id} in inactivated_by_change_id"
            )
```

**Test Cases**:
```python
# VALID: change_id exists in content_change_log
{
    "question_id": "Q010",
    "status": "inactive",
    "inactivation_reason": "CONTENT_DELETED",
    "inactivated_by_change_id": 12345,  # Exists in DB
    "inactivated_at": "2025-11-02T10:30:00"
}

# INVALID: change_id doesn't exist
{
    "question_id": "Q011",
    "status": "inactive",
    "inactivation_reason": "CONTENT_DELETED",
    "inactivated_by_change_id": 99999,  # ERROR: Not in DB
    "inactivated_at": "2025-11-02T10:30:00"
}
```

### Rule 6: Timestamp Format Validation
**Logic**: `inactivated_at` must be valid ISO-8601 datetime format

**Python Implementation**:
```python
from datetime import datetime

def validate_inactivation_timestamp(question: dict) -> None:
    """
    Validate that inactivated_at is a valid datetime.

    Args:
        question: Dictionary with keys: inactivated_at

    Raises:
        ValidationError: If timestamp is invalid format
    """
    timestamp = question.get('inactivated_at')

    if timestamp is not None:
        try:
            # Try to parse as ISO-8601 format
            if isinstance(timestamp, str):
                datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            elif not isinstance(timestamp, datetime):
                raise ValueError("Must be string or datetime object")
        except (ValueError, AttributeError) as e:
            raise ValidationError(
                f"Invalid inactivated_at timestamp for question {question['question_id']}: {e}"
            )
```

**Test Cases**:
```python
# VALID: ISO-8601 format
{
    "question_id": "Q012",
    "status": "inactive",
    "inactivation_reason": "MANUAL",
    "inactivated_at": "2025-11-02T10:30:00"  # Valid format
}

# INVALID: Bad format
{
    "question_id": "Q013",
    "status": "inactive",
    "inactivation_reason": "MANUAL",
    "inactivated_at": "11/02/2025"  # ERROR: Wrong format
}
```

## Composite Validator

### Complete Validation Function
```python
from typing import Optional
import sqlite3
from datetime import datetime
from faq_impact.core.enums import InactivationReason

class ValidationError(Exception):
    """Custom exception for validation errors."""
    pass

def validate_question_inactivation(
    question: dict,
    db_connection: Optional[sqlite3.Connection] = None
) -> None:
    """
    Complete validation for question inactivation consistency.

    Validates all inactivation rules:
    1. Active questions have no inactivation data
    2. Inactive questions have required fields
    3. Inactivation reason is valid enum
    4. Change ID required for non-manual inactivations
    5. Change ID exists in database (if connection provided)
    6. Timestamp format is valid

    Args:
        question: Dictionary with question data
        db_connection: Optional database connection for FK validation

    Raises:
        ValidationError: If any validation rule fails

    Example:
        >>> question = {
        ...     "question_id": "Q001",
        ...     "status": "inactive",
        ...     "inactivation_reason": "CONTENT_DELETED",
        ...     "inactivated_by_change_id": 12345,
        ...     "inactivated_at": "2025-11-02T10:30:00"
        ... }
        >>> validate_question_inactivation(question, db_conn)
        # Passes validation
    """
    # Rule 1: Active questions have no inactivation data
    if question['status'] == 'active':
        validate_active_question(question)
        return  # No further validation needed for active questions

    # Rule 2: Inactive questions have required fields
    if question['status'] == 'inactive':
        validate_inactive_question_required_fields(question)

        # Rule 3: Inactivation reason is valid enum
        validate_inactivation_reason(question)

        # Rule 4: Change ID required for non-manual inactivations
        validate_inactivation_change_id(question)

        # Rule 5: Change ID exists (if connection provided)
        if db_connection is not None:
            validate_change_id_exists(question, db_connection)

        # Rule 6: Timestamp format validation
        validate_inactivation_timestamp(question)


def validate_question_before_insert(question: dict, db_connection) -> None:
    """
    Validate question before INSERT operation.

    Args:
        question: Question data to insert
        db_connection: Database connection

    Raises:
        ValidationError: If validation fails
    """
    validate_question_inactivation(question, db_connection)


def validate_question_before_update(
    question: dict,
    db_connection,
    allow_reactivation: bool = False
) -> None:
    """
    Validate question before UPDATE operation.

    Args:
        question: Question data to update
        db_connection: Database connection
        allow_reactivation: If False, prevent reactivating inactive questions

    Raises:
        ValidationError: If validation fails
    """
    validate_question_inactivation(question, db_connection)

    if not allow_reactivation:
        # Prevent reactivating inactive questions
        # (requires fetching current state from DB)
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT status FROM faq_questions WHERE question_id = ?",
            (question['question_id'],)
        )
        row = cursor.fetchone()

        if row and row[0] == 'inactive' and question['status'] == 'active':
            raise ValidationError(
                f"Cannot reactivate inactive question {question['question_id']}. "
                f"Create a new question instead to preserve audit trail."
            )
```

## Integration Points

### Repository Layer
```python
class FAQQuestionRepository:
    """Repository for FAQ questions with validation."""

    def __init__(self, db_connection):
        self.db = db_connection

    def create_question(self, question: dict) -> str:
        """Create a new question with validation."""
        # Validate before insert
        validate_question_before_insert(question, self.db)

        # Insert into database
        cursor = self.db.cursor()
        cursor.execute("""
            INSERT INTO faq_questions (
                question_id, question_text, source_type, generation_method,
                status, inactivation_reason, inactivated_by_change_id,
                inactivated_at, created_at, modified_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            question['question_id'],
            question['question_text'],
            question.get('source_type'),
            question.get('generation_method'),
            question['status'],
            question.get('inactivation_reason'),
            question.get('inactivated_by_change_id'),
            question.get('inactivated_at'),
            question.get('created_at', datetime.now()),
            question.get('modified_at', datetime.now())
        ))

        return question['question_id']

    def inactivate_question(
        self,
        question_id: str,
        reason: InactivationReason,
        change_id: Optional[int] = None
    ) -> None:
        """Inactivate a question with validation."""
        question = {
            'question_id': question_id,
            'status': 'inactive',
            'inactivation_reason': reason.value,
            'inactivated_by_change_id': change_id,
            'inactivated_at': datetime.now().isoformat()
        }

        # Validate before update
        validate_question_inactivation(question, self.db)

        # Update database
        cursor = self.db.cursor()
        cursor.execute("""
            UPDATE faq_questions
            SET status = 'inactive',
                inactivation_reason = ?,
                inactivated_by_change_id = ?,
                inactivated_at = ?,
                modified_at = CURRENT_TIMESTAMP
            WHERE question_id = ?
        """, (
            question['inactivation_reason'],
            question['inactivated_by_change_id'],
            question['inactivated_at'],
            question_id
        ))
```

### Service Layer
```python
class FAQImpactService:
    """Service for FAQ impact analysis."""

    def __init__(self, question_repo: FAQQuestionRepository):
        self.question_repo = question_repo

    def handle_content_deleted(self, change_id: int, affected_questions: list[str]) -> None:
        """Handle content deletion impact on questions."""
        for question_id in affected_questions:
            try:
                self.question_repo.inactivate_question(
                    question_id=question_id,
                    reason=InactivationReason.CONTENT_DELETED,
                    change_id=change_id
                )
            except ValidationError as e:
                # Log validation error and continue
                print(f"Validation error for {question_id}: {e}")
```

## Testing Strategy

### Unit Tests
```python
import pytest
from unittest.mock import Mock

def test_active_question_with_null_inactivation_fields():
    """Test that active questions pass validation."""
    question = {
        "question_id": "Q001",
        "status": "active",
        "inactivation_reason": None,
        "inactivated_by_change_id": None,
        "inactivated_at": None
    }
    # Should not raise
    validate_question_inactivation(question)

def test_active_question_with_inactivation_reason_fails():
    """Test that active question with reason fails validation."""
    question = {
        "question_id": "Q002",
        "status": "active",
        "inactivation_reason": "CONTENT_DELETED",
        "inactivated_by_change_id": None,
        "inactivated_at": None
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_question_inactivation(question)
    assert "cannot have inactivation_reason" in str(exc_info.value)

def test_inactive_question_without_reason_fails():
    """Test that inactive question without reason fails validation."""
    question = {
        "question_id": "Q003",
        "status": "inactive",
        "inactivation_reason": None,
        "inactivated_by_change_id": 12345,
        "inactivated_at": "2025-11-02T10:30:00"
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_question_inactivation(question)
    assert "must have inactivation_reason" in str(exc_info.value)

def test_invalid_inactivation_reason_fails():
    """Test that invalid enum value fails validation."""
    question = {
        "question_id": "Q004",
        "status": "inactive",
        "inactivation_reason": "INVALID_REASON",
        "inactivated_by_change_id": 12345,
        "inactivated_at": "2025-11-02T10:30:00"
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_question_inactivation(question)
    assert "not a valid InactivationReason" in str(exc_info.value)

def test_non_manual_inactivation_without_change_id_fails():
    """Test that non-manual inactivation requires change_id."""
    question = {
        "question_id": "Q005",
        "status": "inactive",
        "inactivation_reason": "CONTENT_DELETED",
        "inactivated_by_change_id": None,
        "inactivated_at": "2025-11-02T10:30:00"
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_question_inactivation(question)
    assert "missing inactivated_by_change_id" in str(exc_info.value)

def test_manual_inactivation_without_change_id_passes():
    """Test that manual inactivation doesn't require change_id."""
    question = {
        "question_id": "Q006",
        "status": "inactive",
        "inactivation_reason": "MANUAL",
        "inactivated_by_change_id": None,
        "inactivated_at": "2025-11-02T10:30:00"
    }
    # Should not raise
    validate_question_inactivation(question)

def test_change_id_must_exist_in_database():
    """Test that change_id is validated against database."""
    question = {
        "question_id": "Q007",
        "status": "inactive",
        "inactivation_reason": "CONTENT_DELETED",
        "inactivated_by_change_id": 99999,
        "inactivated_at": "2025-11-02T10:30:00"
    }

    # Mock database connection that returns 0 for COUNT
    mock_db = Mock()
    mock_cursor = Mock()
    mock_cursor.fetchone.return_value = (0,)
    mock_db.cursor.return_value = mock_cursor

    with pytest.raises(ValidationError) as exc_info:
        validate_question_inactivation(question, mock_db)
    assert "non-existent change_id" in str(exc_info.value)
```

### Integration Tests
```python
def test_end_to_end_inactivation_workflow(test_db):
    """Test complete inactivation workflow with database."""
    # Setup: Create question and change log entry
    question_repo = FAQQuestionRepository(test_db)

    # Insert change log entry
    test_db.execute("""
        INSERT INTO content_change_log (change_id, content_checksum, file_name,
                                        requires_faq_regeneration, detection_run_id)
        VALUES (12345, 'abc123', 'test.pdf', 1, 'run001')
    """)

    # Create active question
    question = {
        "question_id": "Q001",
        "question_text": "What is the policy?",
        "status": "active",
        "inactivation_reason": None,
        "inactivated_by_change_id": None,
        "inactivated_at": None
    }
    question_repo.create_question(question)

    # Inactivate question
    question_repo.inactivate_question(
        question_id="Q001",
        reason=InactivationReason.CONTENT_DELETED,
        change_id=12345
    )

    # Verify inactivation
    cursor = test_db.cursor()
    cursor.execute("SELECT * FROM faq_questions WHERE question_id = 'Q001'")
    row = cursor.fetchone()

    assert row['status'] == 'inactive'
    assert row['inactivation_reason'] == 'CONTENT_DELETED'
    assert row['inactivated_by_change_id'] == 12345
    assert row['inactivated_at'] is not None
```

## Error Messages

### Validation Error Format
```python
# Format: Clear description with question ID and specific issue
"Invalid active question Q002: Active question cannot have inactivation_reason set"

"Invalid inactive question Q003: Inactive question must have inactivation_reason; Inactive question must have inactivated_at timestamp"

"Question Q005 has inactivation_reason='CONTENT_DELETED' but is missing inactivated_by_change_id. Non-manual inactivations must reference a content change."

"Question Q007 references non-existent change_id 99999 in inactivated_by_change_id"
```

## Performance Considerations

### Validation Overhead
- Rule 1-4, 6: In-memory validation (< 1ms)
- Rule 5: Database query (1-5ms depending on index)

**Optimization**: Batch validate change_id existence:
```python
def validate_change_ids_batch(questions: list[dict], db_connection) -> None:
    """Validate multiple change_ids in single query."""
    change_ids = [q['inactivated_by_change_id'] for q in questions
                  if q.get('inactivated_by_change_id') is not None]

    if not change_ids:
        return

    placeholders = ','.join('?' * len(change_ids))
    cursor = db_connection.cursor()
    cursor.execute(
        f"SELECT change_id FROM content_change_log WHERE change_id IN ({placeholders})",
        change_ids
    )

    existing_ids = {row[0] for row in cursor.fetchall()}
    missing_ids = set(change_ids) - existing_ids

    if missing_ids:
        raise ValidationError(f"Non-existent change_ids: {missing_ids}")
```

## Related Documentation
- [INACTIVATION_COLUMNS_DESIGN.md](./INACTIVATION_COLUMNS_DESIGN.md) - Column design
- [InactivationReason Enum](../../core/enums/entity_type.py) - Enum definition
- [02_faq_questions_enhanced.sql](./02_faq_questions_enhanced.sql) - Schema

## Version History
- 2025-11-02: Initial validation logic (Item 58)

## Authors
Analytics Assist Team
