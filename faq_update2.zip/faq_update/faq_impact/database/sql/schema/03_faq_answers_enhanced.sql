-- ============================================================================
-- TABLE: faq_answers (SQLite) - Enhanced with Inactivation Tracking
-- ============================================================================
-- Description: FAQ answers - linked to questions (1:1) with full inactivation audit trail
-- Dependencies: faq_questions (FK: question_id)
--               Logical FK to content_change_log (application-level validation)
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Each answer is linked to exactly one question
--              Answers track inactivation reason, trigger change, and timestamp
--              Answers can be inactivated directly OR via cascade from question inactivation
--
-- Enhancement: Added inactivation tracking columns for audit trail
--              - inactivation_reason: WHY was the answer inactivated
--              - inactivated_by_change_id: WHICH content change triggered it
--              - inactivated_at: WHEN was it inactivated
--
-- SQLite Features Used:
--   - TEXT PRIMARY KEY (no autoincrement - using custom IDs)
--   - CHECK constraints for status and format validation (application-level)
--   - Foreign key constraint (application-level validation to match Databricks)
--   - DEFAULT values supported
--   - DATETIME stored as TEXT in ISO-8601 format
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answers (
    -- Primary Identity
    answer_id TEXT PRIMARY KEY,

    -- Link to Question (1:1)
    question_id TEXT NOT NULL,

    -- Answer Content
    answer_text TEXT NOT NULL,
    answer_format TEXT DEFAULT 'html',                 -- Format validation in app code
                                                       -- Valid values: 'html', 'markdown', 'plain'

    -- Quality Metrics
    confidence_score REAL,                             -- Range validation in app code (0.0 to 1.0)

    -- Status
    status TEXT NOT NULL DEFAULT 'active',             -- 'active', 'inactive'
                                                       -- Status validation handled by application code

    -- ========================================================================
    -- INACTIVATION TRACKING (Added in Phase 2)
    -- ========================================================================
    -- Purpose: Full audit trail for why/when/how answers were inactivated
    -- Consistency Rules (enforced by application code):
    --   1. If status='active': all inactivation fields MUST be NULL
    --   2. If status='inactive': inactivation_reason and inactivated_at MUST be NOT NULL
    --   3. If status='inactive' AND inactivation_reason NOT IN ('MANUAL', 'QUESTION_INACTIVATED'):
    --        inactivated_by_change_id MUST be NOT NULL
    --   4. If status='inactive' AND inactivation_reason IN ('MANUAL', 'QUESTION_INACTIVATED'):
    --        inactivated_by_change_id is OPTIONAL (may be NULL or NOT NULL)
    --   5. CASCADE RULE: If question is inactive, ALL its answers MUST be inactive
    --   6. ORPHAN PREVENTION: Active answers can only exist for active questions
    -- ========================================================================

    inactivation_reason TEXT,                          -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Valid values (application-enforced):
                                                       --   'CONTENT_DELETED' - Source content deleted
                                                       --   'QUALITY_ISSUE' - Quality check failed
                                                       --   'MANUAL' - Manual inactivation
                                                       --   'QUESTION_INACTIVATED' - Cascaded from question
                                                       -- See: InactivationReason enum

    inactivated_by_change_id INTEGER,                  -- NULL when active
                                                       -- NULL when inactivation_reason IN ('MANUAL', 'QUESTION_INACTIVATED') (optional)
                                                       -- NOT NULL for other inactivation reasons
                                                       -- When inactivation_reason='QUESTION_INACTIVATED':
                                                       --   - If question was inactivated by change, copy change_id
                                                       --   - If question was manually inactivated, may be NULL
                                                       -- Logical FK to content_change_log.change_id
                                                       -- (application-level validation only)

    inactivated_at DATETIME,                           -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Timestamp of inactivation (ISO-8601 format)
                                                       -- When cascaded: same timestamp as question inactivation

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Foreign Key (application-level validation to match Databricks)
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
);

-- ============================================================================
-- CONSTRAINTS
-- ============================================================================
-- Note: All constraint validation handled by application code to match
--       Databricks limitations and maintain consistency across backends
--
-- Application-Level Constraints:
--   1. status IN ('active', 'inactive')
--   2. answer_format IN ('html', 'markdown', 'plain')
--   3. confidence_score BETWEEN 0.0 AND 1.0 OR NULL
--   4. inactivation_reason IN ('CONTENT_DELETED', 'QUALITY_ISSUE', 'MANUAL', 'QUESTION_INACTIVATED') OR NULL
--   5. Consistency rules (see inactivation tracking section above)
--   6. question_id references faq_questions.question_id (application validation)
--   7. inactivated_by_change_id references content_change_log.change_id (when NOT NULL)
--
-- CASCADE RULES (enforced by application code, NOT database):
--   - When a question is inactivated:
--     * ALL answers for that question MUST be inactivated atomically
--     * Set inactivation_reason='QUESTION_INACTIVATED'
--     * Copy inactivated_by_change_id from question (if present)
--     * Set inactivated_at to same timestamp as question
--     * All updates in a single transaction (commit or rollback together)
--   - When a question is reactivated:
--     * Application decides whether to reactivate answers (business logic)
--     * Not automatic - requires explicit business decision
-- ============================================================================

-- ============================================================================
-- INDEXES
-- ============================================================================
-- Core indexes (original schema)
CREATE INDEX IF NOT EXISTS idx_faq_answers_question_id ON faq_answers(question_id);
CREATE INDEX IF NOT EXISTS idx_faq_answers_status ON faq_answers(status);
CREATE INDEX IF NOT EXISTS idx_faq_answers_created ON faq_answers(created_at);

-- ============================================================================
-- INACTIVATION TRACKING INDEXES (Added in Phase 2)
-- ============================================================================

-- Single-column index for filtering by inactivation reason
-- Use case: "Show all answers inactivated due to QUESTION_INACTIVATED"
-- Query pattern: WHERE inactivation_reason = 'QUESTION_INACTIVATED'
CREATE INDEX IF NOT EXISTS idx_faq_answers_inactivation_reason
    ON faq_answers(inactivation_reason);

-- Composite index for cascade queries and orphan detection
-- Use case: "Find all answers for an inactive question"
-- Use case: "Verify no active answers exist for inactive question"
-- Query pattern: WHERE question_id='Q001' AND status='active'
-- Query pattern: WHERE question_id='Q001' ORDER BY inactivated_at
--
-- Index column order rationale:
--   1. question_id - Most selective filter (specific question)
--   2. status - Common filter (active vs inactive)
--   3. inactivated_at - Sorting for temporal analysis
CREATE INDEX IF NOT EXISTS idx_faq_answers_question_status
    ON faq_answers(question_id, status, inactivated_at);

-- ============================================================================
-- CASCADE INACTIVATION LOGIC
-- ============================================================================
-- This section documents the application-level cascade logic that MUST be
-- implemented when a question is inactivated. This is NOT enforced by the
-- database due to Databricks compatibility requirements.
--
-- TRANSACTION BOUNDARY:
-- All operations MUST occur within a single database transaction to ensure
-- atomicity. If ANY operation fails, ALL changes must be rolled back.
--
-- PROCEDURE: InactivateQuestion(question_id, change_id, reason, timestamp)
--   BEGIN TRANSACTION;
--
--   -- Step 1: Inactivate the question
--   UPDATE faq_questions
--   SET status = 'inactive',
--       inactivation_reason = reason,
--       inactivated_by_change_id = change_id,
--       inactivated_at = timestamp,
--       modified_at = timestamp
--   WHERE question_id = question_id;
--
--   -- Step 2: Cascade to all answers for this question
--   UPDATE faq_answers
--   SET status = 'inactive',
--       inactivation_reason = 'QUESTION_INACTIVATED',
--       inactivated_by_change_id = change_id,  -- Copy from question (may be NULL)
--       inactivated_at = timestamp,            -- Same timestamp as question
--       modified_at = timestamp
--   WHERE question_id = question_id
--     AND status = 'active';                   -- Only update active answers
--
--   -- Step 3: Verify cascade (optional safety check)
--   SELECT COUNT(*) FROM faq_answers
--   WHERE question_id = question_id
--     AND status = 'active';
--   -- Expected: 0 (no active answers remain)
--
--   COMMIT;  -- Or ROLLBACK on any error
--
-- ROLLBACK BEHAVIOR:
-- If any step fails (constraint violation, database error, etc.):
--   - All changes are reverted
--   - Question remains in original state
--   - All answers remain in original state
--   - Error is propagated to caller for handling
--
-- VALIDATION BEFORE CASCADE:
-- Before executing cascade, validate:
--   1. Question exists and is currently active
--   2. change_id exists in content_change_log (if NOT NULL)
--   3. reason is valid InactivationReason enum value
--   4. timestamp is valid ISO-8601 datetime
-- ============================================================================

-- ============================================================================
-- VALIDATION LOGIC FOR ANSWER INACTIVATION
-- ============================================================================
-- This section documents the application-level validation that MUST be
-- performed before inactivating an answer. These rules prevent orphaned
-- active answers and ensure data consistency.
--
-- RULE 1: Direct Answer Inactivation (Non-Cascaded)
-- An answer can be inactivated directly (not due to question inactivation) IF:
--   - inactivation_reason IN ('CONTENT_DELETED', 'QUALITY_ISSUE', 'MANUAL')
--   - The parent question is ACTIVE or INACTIVE (doesn't matter)
--   - All inactivation fields are properly set according to consistency rules
--
-- RULE 2: Cascaded Answer Inactivation
-- An answer MUST be inactivated when its question is inactivated:
--   - inactivation_reason = 'QUESTION_INACTIVATED'
--   - inactivated_by_change_id copied from question (may be NULL)
--   - inactivated_at = same timestamp as question
--   - Performed atomically with question inactivation
--
-- RULE 3: Orphan Prevention
-- The system MUST prevent active answers for inactive questions:
--   - Before committing question inactivation, cascade to all answers
--   - Validation query after cascade: ensure no active answers remain
--   - Periodic audit job: find and fix orphaned active answers
--
-- VALIDATION PROCEDURE: ValidateAnswerInactivation(answer_id, reason, change_id, timestamp)
--   -- Check 1: Answer exists and is currently active
--   IF answer.status != 'active' THEN
--     RAISE ERROR "Answer is already inactive"
--   END IF
--
--   -- Check 2: Reason is valid
--   IF reason NOT IN ('CONTENT_DELETED', 'QUALITY_ISSUE', 'MANUAL', 'QUESTION_INACTIVATED') THEN
--     RAISE ERROR "Invalid inactivation reason"
--   END IF
--
--   -- Check 3: change_id validation (if NOT NULL)
--   IF change_id IS NOT NULL AND reason NOT IN ('MANUAL', 'QUESTION_INACTIVATED') THEN
--     IF NOT EXISTS (SELECT 1 FROM content_change_log WHERE change_id = change_id) THEN
--       RAISE ERROR "Invalid change_id reference"
--     END IF
--   END IF
--
--   -- Check 4: For cascaded inactivation, verify question is inactive
--   IF reason = 'QUESTION_INACTIVATED' THEN
--     question = GET_QUESTION(answer.question_id)
--     IF question.status = 'active' THEN
--       RAISE ERROR "Cannot cascade from active question"
--     END IF
--   END IF
--
--   -- Check 5: Timestamp is valid ISO-8601
--   IF NOT IS_VALID_ISO8601(timestamp) THEN
--     RAISE ERROR "Invalid timestamp format"
--   END IF
--
-- AUDIT PROCEDURE: FindOrphanedActiveAnswers()
--   -- Find active answers whose questions are inactive
--   SELECT a.answer_id, a.question_id, q.inactivated_at
--   FROM faq_answers a
--   INNER JOIN faq_questions q ON a.question_id = q.question_id
--   WHERE a.status = 'active'
--     AND q.status = 'inactive';
--   -- Expected: 0 rows (no orphans)
--   -- If found: Log as data integrity issue, auto-fix or alert
-- ============================================================================

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

-- Example 1: Direct answer inactivation (quality issue)
-- UPDATE faq_answers
-- SET status = 'inactive',
--     inactivation_reason = 'QUALITY_ISSUE',
--     inactivated_by_change_id = 12345,
--     inactivated_at = CURRENT_TIMESTAMP,
--     modified_at = CURRENT_TIMESTAMP
-- WHERE answer_id = 'A001';

-- Example 2: Cascaded inactivation (question was inactivated)
-- UPDATE faq_answers
-- SET status = 'inactive',
--     inactivation_reason = 'QUESTION_INACTIVATED',
--     inactivated_by_change_id = 12345,  -- Copied from question
--     inactivated_at = '2025-11-02T10:30:00Z',  -- Same as question
--     modified_at = CURRENT_TIMESTAMP
-- WHERE question_id = 'Q001'
--   AND status = 'active';

-- Example 3: Find all answers inactivated due to question inactivation
-- SELECT
--     a.answer_id,
--     a.answer_text,
--     a.inactivation_reason,
--     a.inactivated_at,
--     q.question_id,
--     q.question_text,
--     q.inactivation_reason as question_reason
-- FROM faq_answers a
-- INNER JOIN faq_questions q ON a.question_id = q.question_id
-- WHERE a.inactivation_reason = 'QUESTION_INACTIVATED'
-- ORDER BY a.inactivated_at DESC;

-- Example 4: Audit - find orphaned active answers (should return 0 rows)
-- SELECT
--     a.answer_id,
--     a.answer_text,
--     a.question_id,
--     q.question_text,
--     q.status as question_status,
--     q.inactivated_at as question_inactivated_at
-- FROM faq_answers a
-- INNER JOIN faq_questions q ON a.question_id = q.question_id
-- WHERE a.status = 'active'
--   AND q.status = 'inactive';

-- Example 5: Find all inactive answers with their triggering changes
-- SELECT
--     a.answer_id,
--     a.answer_text,
--     a.inactivation_reason,
--     a.inactivated_at,
--     ccl.change_id,
--     ccl.change_type,
--     ccl.file_name,
--     ccl.detection_timestamp
-- FROM faq_answers a
-- LEFT JOIN content_change_log ccl ON a.inactivated_by_change_id = ccl.change_id
-- WHERE a.status = 'inactive'
-- ORDER BY a.inactivated_at DESC;

-- Example 6: Complete cascade transaction (pseudo-code)
-- BEGIN TRANSACTION;
--
-- -- Inactivate question
-- UPDATE faq_questions
-- SET status = 'inactive',
--     inactivation_reason = 'CONTENT_DELETED',
--     inactivated_by_change_id = 12345,
--     inactivated_at = '2025-11-02T10:30:00Z',
--     modified_at = CURRENT_TIMESTAMP
-- WHERE question_id = 'Q001';
--
-- -- Cascade to all answers
-- UPDATE faq_answers
-- SET status = 'inactive',
--     inactivation_reason = 'QUESTION_INACTIVATED',
--     inactivated_by_change_id = 12345,
--     inactivated_at = '2025-11-02T10:30:00Z',
--     modified_at = CURRENT_TIMESTAMP
-- WHERE question_id = 'Q001'
--   AND status = 'active';
--
-- COMMIT;

-- Example 7: Audit report - answers inactivated in last 7 days by reason
-- SELECT
--     inactivation_reason,
--     COUNT(*) as answer_count,
--     MIN(inactivated_at) as first_inactivation,
--     MAX(inactivated_at) as last_inactivation
-- FROM faq_answers
-- WHERE status = 'inactive'
--   AND inactivated_at >= datetime('now', '-7 days')
-- GROUP BY inactivation_reason
-- ORDER BY answer_count DESC;

-- ============================================================================
-- SAMPLE TEST DATA
-- ============================================================================
-- This section provides sample data demonstrating both cascaded and direct
-- inactivation scenarios for testing and validation.

-- SCENARIO 1: Cascaded Inactivation
-- A question is deleted from source content, triggering cascade to its answers

-- Insert active question
-- INSERT INTO faq_questions (question_id, question_text, status, created_at, modified_at)
-- VALUES ('Q_CASCADE_001', 'What is the return policy?', 'active', '2025-11-01T09:00:00Z', '2025-11-01T09:00:00Z');

-- Insert multiple answers for this question
-- INSERT INTO faq_answers (answer_id, question_id, answer_text, status, created_at, modified_at)
-- VALUES
--   ('A_CASCADE_001', 'Q_CASCADE_001', 'You can return items within 30 days.', 'active', '2025-11-01T09:00:00Z', '2025-11-01T09:00:00Z'),
--   ('A_CASCADE_002', 'Q_CASCADE_001', 'Full refund is provided for unused items.', 'active', '2025-11-01T09:00:00Z', '2025-11-01T09:00:00Z'),
--   ('A_CASCADE_003', 'Q_CASCADE_001', 'Return shipping is free.', 'active', '2025-11-01T09:00:00Z', '2025-11-01T09:00:00Z');

-- Simulate question inactivation with cascade (in transaction)
-- BEGIN TRANSACTION;
--
-- UPDATE faq_questions
-- SET status = 'inactive',
--     inactivation_reason = 'CONTENT_DELETED',
--     inactivated_by_change_id = 999,
--     inactivated_at = '2025-11-02T14:30:00Z',
--     modified_at = '2025-11-02T14:30:00Z'
-- WHERE question_id = 'Q_CASCADE_001';
--
-- UPDATE faq_answers
-- SET status = 'inactive',
--     inactivation_reason = 'QUESTION_INACTIVATED',
--     inactivated_by_change_id = 999,
--     inactivated_at = '2025-11-02T14:30:00Z',
--     modified_at = '2025-11-02T14:30:00Z'
-- WHERE question_id = 'Q_CASCADE_001'
--   AND status = 'active';
--
-- COMMIT;

-- Verify cascade: Should return 0 active answers
-- SELECT COUNT(*) FROM faq_answers
-- WHERE question_id = 'Q_CASCADE_001' AND status = 'active';
-- Expected: 0

-- SCENARIO 2: Direct Answer Inactivation (Independent of Question)
-- An answer is inactivated directly due to quality issue, question remains active

-- Insert active question
-- INSERT INTO faq_questions (question_id, question_text, status, created_at, modified_at)
-- VALUES ('Q_DIRECT_001', 'How do I reset my password?', 'active', '2025-11-01T10:00:00Z', '2025-11-01T10:00:00Z');

-- Insert multiple answers
-- INSERT INTO faq_answers (answer_id, question_id, answer_text, status, created_at, modified_at)
-- VALUES
--   ('A_DIRECT_001', 'Q_DIRECT_001', 'Click "Forgot Password" on login page.', 'active', '2025-11-01T10:00:00Z', '2025-11-01T10:00:00Z'),
--   ('A_DIRECT_002', 'Q_DIRECT_001', 'This answer contains incorrect information.', 'active', '2025-11-01T10:00:00Z', '2025-11-01T10:00:00Z');

-- Inactivate one answer due to quality issue (question stays active)
-- UPDATE faq_answers
-- SET status = 'inactive',
--     inactivation_reason = 'QUALITY_ISSUE',
--     inactivated_by_change_id = 1000,
--     inactivated_at = '2025-11-02T15:00:00Z',
--     modified_at = '2025-11-02T15:00:00Z'
-- WHERE answer_id = 'A_DIRECT_002';

-- Verify: Question is still active, one answer is active, one is inactive
-- SELECT q.status as question_status, a.answer_id, a.status as answer_status, a.inactivation_reason
-- FROM faq_questions q
-- LEFT JOIN faq_answers a ON q.question_id = a.question_id
-- WHERE q.question_id = 'Q_DIRECT_001';
-- Expected: question_status='active', A_DIRECT_001 status='active', A_DIRECT_002 status='inactive' reason='QUALITY_ISSUE'

-- SCENARIO 3: Counter-example - Orphan Prevention Test
-- This demonstrates what should NOT happen: active answer with inactive question

-- This is INVALID and should be prevented by application validation:
-- INSERT INTO faq_questions (question_id, question_text, status, inactivation_reason, inactivated_at, created_at, modified_at)
-- VALUES ('Q_ORPHAN_001', 'Invalid question', 'inactive', 'MANUAL', '2025-11-02T16:00:00Z', '2025-11-01T11:00:00Z', '2025-11-02T16:00:00Z');
--
-- INSERT INTO faq_answers (answer_id, question_id, answer_text, status, created_at, modified_at)
-- VALUES ('A_ORPHAN_001', 'Q_ORPHAN_001', 'Orphaned active answer', 'active', '2025-11-01T11:00:00Z', '2025-11-01T11:00:00Z');
-- -- This should be detected and prevented by validation logic!

-- ============================================================================
-- MIGRATION NOTES
-- ============================================================================
-- To migrate from original schema to enhanced schema:
--   1. Add new columns using ALTER TABLE (SQLite supports adding columns)
--   2. Existing rows will have NULL values for new columns (correct for active answers)
--   3. No data migration needed (all existing answers are active)
--   4. See MIGRATION_GUIDE_ANSWERS.md for detailed step-by-step instructions
--
-- SQLite ALTER TABLE limitations:
--   - Can ADD columns
--   - Cannot DROP columns (requires table recreation)
--   - Cannot modify column types (requires table recreation)
--   - Cannot add NOT NULL constraints without DEFAULT (use application validation)
--
-- Migration script will be provided in separate file (Item 70)
-- ============================================================================

-- ============================================================================
-- DATABRICKS COMPATIBILITY
-- ============================================================================
-- This schema is compatible with Databricks Delta Lake with these mappings:
--   - TEXT → STRING
--   - INTEGER → INT
--   - REAL → DOUBLE
--   - DATETIME → TIMESTAMP
--   - CREATE INDEX IF NOT EXISTS → CREATE INDEX (remove IF NOT EXISTS)
--
-- Foreign key relationships:
--   - Databricks supports FK syntax but does NOT enforce (metadata only)
--   - Application-level validation REQUIRED for referential integrity
--   - NO CASCADE DELETE/UPDATE support in Databricks
--   - ALL cascade logic MUST be implemented in application code
--
-- Transaction support:
--   - Databricks Delta Lake supports ACID transactions
--   - Use BEGIN TRANSACTION / COMMIT / ROLLBACK for cascade operations
--   - Same transaction semantics as SQLite for this use case
-- ============================================================================

-- ============================================================================
-- RELATED DOCUMENTATION
-- ============================================================================
-- - INACTIVATION_COLUMNS_DESIGN.md: Design rationale and specifications
-- - MIGRATION_GUIDE_ANSWERS.md: Step-by-step migration from old schema
-- - VALIDATION_LOGIC_ANSWERS.md: Application-level validation rules
-- - CASCADE_LOGIC.md: Cascade inactivation implementation guide
-- - ../../core/enums/entity_type.py: InactivationReason enum definition
-- - 02_faq_questions_enhanced.sql: Parent table schema
-- - 06_content_change_log.sql: Referenced table (logical FK)
-- ============================================================================

-- ============================================================================
-- VERSION HISTORY
-- ============================================================================
-- 2025-11-02: Enhanced schema with inactivation tracking (Phase 2, Items 61-70)
-- Original:   Basic faq_answers schema (Phase 1)
-- ============================================================================
