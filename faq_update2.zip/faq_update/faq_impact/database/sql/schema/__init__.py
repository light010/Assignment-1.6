"""
Database Schema - DDL Statements for Impact Analysis Tables

This module defines the database schema for FAQ impact analysis:

Tables:
    1. impact_analysis_runs
       - Tracks each impact analysis execution
       - Records detection run ID, timestamp, summary statistics
       - Links to detection.detection_runs for full change details

    2. chunk_impact_cache
       - Caches which questions depend on which chunks
       - Speeds up impact analysis by avoiding expensive joins
       - Invalidated and rebuilt when provenance changes

    3. regeneration_queue
       - Tracks Q/A pairs that need regeneration
       - Prioritizes work (e.g., high-traffic questions first)
       - Records reason for regeneration and current status

    4. impact_metrics
       - Stores detailed metrics about each impact analysis
       - Tracks regeneration rates, affected questions, etc.
       - Supports observability and optimization

Schema Versioning:
    - Each schema file is versioned (e.g., schema_v1.sql)
    - Migration scripts handle upgrades between versions
    - Backwards compatibility maintained where possible

Example:
    >>> from faq_impact.database.sql.schema import get_schema_ddl
    >>> ddl = get_schema_ddl(version="v1")
    >>> backend.execute(ddl)

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Schema DDL will be added as tables are designed
__all__ = []
