-- ============================================================================
-- QUERY: get_duplicate_checksums.sql
-- ============================================================================
-- Description: Find content_checksums that already exist in content_chunks with status='active'
-- Purpose: Duplicate detection - check if new content already exists in database
-- Dependencies: content_chunks table
-- Item: 87
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :checksum (TEXT) - Single checksum to check for duplicates
-- :checksum_list (TEXT[]) - List of checksums to batch check (for batch processing)
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - Single checksum duplicate check
-- ============================================================================
-- Returns: Rows if checksum exists, empty if new
-- Use case: Check if a single checksum already exists before inserting
-- ============================================================================

SELECT
    content_checksum,
    chunk_id,
    ud_source_file_id,
    chunk_index,
    chunk_text,
    chunk_page_number,
    status,
    created_at

FROM content_chunks

WHERE
    content_checksum = :checksum
    AND status = 'active'  -- Only check active content

ORDER BY
    created_at DESC;  -- Most recent first

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Batch checksum duplicate check (optimized)
-- ============================================================================
-- Use case: Check multiple checksums at once (bulk insert scenario)
-- Returns: Only checksums that already exist (duplicates)
-- ============================================================================

SELECT DISTINCT
    content_checksum

FROM content_chunks

WHERE
    content_checksum IN :checksum_list  -- List of checksums to check
    AND status = 'active';

-- ============================================================================
-- VARIANT 2: Batch checksum check with existence flag
-- ============================================================================
-- Use case: For each input checksum, return whether it exists or not
-- Note: Requires application-side processing or temp table
-- ============================================================================

-- Example using temp table approach:
-- CREATE TEMP TABLE temp_checksums (checksum TEXT);
-- INSERT INTO temp_checksums VALUES ('checksum1'), ('checksum2'), ('checksum3');

SELECT
    tc.checksum,
    CASE
        WHEN cc.content_checksum IS NOT NULL THEN 1
        ELSE 0
    END as is_duplicate,
    cc.chunk_id,
    cc.created_at

FROM temp_checksums tc

LEFT JOIN content_chunks cc
    ON tc.checksum = cc.content_checksum
    AND cc.status = 'active'

ORDER BY tc.checksum;

-- ============================================================================
-- VARIANT 3: Duplicate check with count (how many times does it appear)
-- ============================================================================
-- Use case: Understand how many active chunks share this checksum
-- ============================================================================

SELECT
    content_checksum,
    COUNT(*) as occurrence_count,
    COUNT(DISTINCT ud_source_file_id) as file_count,
    MIN(created_at) as first_seen,
    MAX(created_at) as last_seen,
    GROUP_CONCAT(DISTINCT ud_source_file_id) as file_ids

FROM content_chunks

WHERE
    content_checksum = :checksum
    AND status = 'active'

GROUP BY content_checksum;

-- ============================================================================
-- VARIANT 4: New vs existing checksums (batch analysis)
-- ============================================================================
-- Use case: Categorize a batch of checksums into new and existing
-- Returns: Two result sets - duplicates and new checksums
-- ============================================================================

-- Duplicates (already exist)
SELECT DISTINCT
    content_checksum,
    'DUPLICATE' as category,
    COUNT(*) as existing_count

FROM content_chunks

WHERE
    content_checksum IN :checksum_list
    AND status = 'active'

GROUP BY content_checksum

UNION ALL

-- New checksums (don't exist) - requires application-side set difference
-- This part needs to be computed in application code:
-- new_checksums = input_checksums - duplicate_checksums

SELECT
    checksum as content_checksum,
    'NEW' as category,
    0 as existing_count

FROM (
    -- Application must provide this list (checksums NOT in duplicates)
    SELECT 'placeholder' as checksum
)

ORDER BY category, content_checksum;

-- ============================================================================
-- VARIANT 5: Duplicate check with full chunk details
-- ============================================================================
-- Use case: Get complete information about existing chunks
-- ============================================================================

SELECT
    cc.content_checksum,
    cc.chunk_id,
    cc.ud_source_file_id,
    cc.chunk_index,
    cc.chunk_text,
    cc.chunk_page_number,
    cc.chunk_start_char,
    cc.chunk_end_char,
    cc.chunk_method,
    cc.chunk_headers,
    cc.status,
    cc.created_at,

    -- Count how many times this checksum appears
    COUNT(*) OVER (PARTITION BY cc.content_checksum) as total_occurrences

FROM content_chunks cc

WHERE
    cc.content_checksum IN :checksum_list
    AND cc.status = 'active'

ORDER BY
    cc.content_checksum,
    cc.created_at DESC;

-- ============================================================================
-- VARIANT 6: Duplicate detection with file context
-- ============================================================================
-- Use case: JOIN with content_repo to get file information
-- ============================================================================

SELECT
    cc.content_checksum,
    cc.chunk_id,
    cc.chunk_index,
    cc.chunk_text,

    -- File information from content_repo
    cr.file_name,
    cr.file_path,
    cr.version_id,
    cr.uploaded_at,

    cc.created_at as chunk_created_at

FROM content_chunks cc

INNER JOIN content_repo cr
    ON cc.ud_source_file_id = cr.ud_source_file_id

WHERE
    cc.content_checksum = :checksum
    AND cc.status = 'active'

ORDER BY
    cc.created_at DESC;

-- ============================================================================
-- VARIANT 7: Fast EXISTS check (boolean result)
-- ============================================================================
-- Use case: Quick check - just need to know if it exists (yes/no)
-- Returns: 1 if exists, 0 if not
-- ============================================================================

SELECT
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM content_chunks
            WHERE content_checksum = :checksum
              AND status = 'active'
        ) THEN 1
        ELSE 0
    END as checksum_exists;

-- ============================================================================
-- VARIANT 8: Batch EXISTS check (multiple checksums)
-- ============================================================================
-- Use case: For each checksum, return 1 if exists, 0 if not
-- ============================================================================

-- Using temp table or VALUES clause:
SELECT
    checksums.checksum,
    CASE
        WHEN cc.content_checksum IS NOT NULL THEN 1
        ELSE 0
    END as exists

FROM (
    -- List of checksums to check
    VALUES
        ('checksum1'),
        ('checksum2'),
        ('checksum3')
) AS checksums(checksum)

LEFT JOIN (
    SELECT DISTINCT content_checksum
    FROM content_chunks
    WHERE status = 'active'
) cc ON checksums.checksum = cc.content_checksum

ORDER BY checksums.checksum;

-- ============================================================================
-- VARIANT 9: Duplicate check excluding specific files
-- ============================================================================
-- Use case: Check for duplicates but ignore current file (update scenario)
-- ============================================================================

SELECT
    content_checksum,
    chunk_id,
    ud_source_file_id,
    chunk_text,
    created_at

FROM content_chunks

WHERE
    content_checksum = :checksum
    AND status = 'active'
    AND ud_source_file_id != :current_file_id  -- Exclude current file

ORDER BY created_at DESC;

-- ============================================================================
-- VARIANT 10: Duplicate statistics summary
-- ============================================================================
-- Use case: Overall duplicate analysis for reporting
-- ============================================================================

SELECT
    COUNT(DISTINCT content_checksum) as unique_checksums,
    COUNT(*) as total_chunks,
    COUNT(*) - COUNT(DISTINCT content_checksum) as duplicate_chunks,
    ROUND(
        100.0 * (COUNT(*) - COUNT(DISTINCT content_checksum)) / COUNT(*),
        2
    ) as duplicate_percentage

FROM content_chunks

WHERE status = 'active';

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage: Index on content_checksum column (CRITICAL for performance)
--   - Recommended: CREATE INDEX idx_content_chunks_checksum ON content_chunks(content_checksum)
--   - Composite: CREATE INDEX idx_content_chunks_checksum_status ON content_chunks(content_checksum, status)
-- Query plan:
--   - Without index: Full table scan (SLOW for large tables)
--   - With index: Index seek on content_checksum (FAST)
-- Expected rows: 0-10 duplicates per checksum (typical)
-- Execution time:
--   - With index: < 10ms per checksum
--   - Without index: 100ms-1000ms per checksum (depends on table size)
-- Optimization:
--   - Batch queries (VARIANT 1) more efficient than multiple single queries
--   - Use VARIANT 7 (EXISTS) for boolean checks (fastest)
--   - Filter by status='active' to reduce result set
-- ============================================================================

-- ============================================================================
-- INDEX RECOMMENDATIONS
-- ============================================================================
-- Essential index for duplicate detection:
--
-- CREATE INDEX IF NOT EXISTS idx_content_chunks_checksum
--     ON content_chunks(content_checksum);
--
-- Composite index for status filtering:
--
-- CREATE INDEX IF NOT EXISTS idx_content_chunks_checksum_status
--     ON content_chunks(content_checksum, status);
--
-- This composite index enables:
--   - Fast lookups by checksum
--   - Efficient filtering by status='active'
--   - Index-only scans (covering index)
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 87)
-- ============================================================================
-- [✓] Query finds content_checksums that exist in content_chunks with status='active'
-- [✓] Supports batch checking of multiple checksums (VARIANT 1)
-- [✓] Optimized with index usage (idx_content_chunks_checksum)
-- [✓] Returns duplicate information efficiently
-- [✓] Provides variants for different use cases (single, batch, EXISTS)
-- [✓] Includes performance recommendations for indexing
-- ============================================================================
