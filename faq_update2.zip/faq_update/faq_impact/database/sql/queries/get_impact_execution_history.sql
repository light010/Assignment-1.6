-- ============================================================================
-- QUERY: get_impact_execution_history.sql
-- ============================================================================
-- Description: Audit query showing execution history with timestamps, execution time, errors, rollbacks
-- Purpose: Comprehensive audit trail for applied impact decisions
-- Dependencies: faq_impact, content_change_log, faq_questions, faq_answers tables
-- Item: 89
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :change_id (INTEGER, OPTIONAL) - Filter by specific change
-- :detection_run_id (TEXT, OPTIONAL) - Filter by specific detection run
-- :applied_by (TEXT, OPTIONAL) - Filter by who executed the decisions
-- :start_date (DATETIME, OPTIONAL) - Filter by applied_at >= start_date
-- :end_date (DATETIME, OPTIONAL) - Filter by applied_at <= end_date
-- :entity_type (TEXT, OPTIONAL) - Filter by entity type
-- :decision (TEXT, OPTIONAL) - Filter by decision type
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - Complete execution history with all context
-- ============================================================================
-- Returns: Applied impacts with timestamps, execution details, and context
-- Joins: content_change_log for change details, FAQ tables for entity details
-- Use case: Comprehensive audit trail
-- ============================================================================

SELECT
    -- Impact decision identity
    i.impact_id,
    i.entity_type,
    i.entity_id,
    i.decision,
    i.reason,

    -- Execution tracking
    i.applied,
    i.applied_at,
    i.applied_by,
    i.application_error,

    -- Execution time (calculated)
    CASE
        WHEN i.applied_at IS NOT NULL AND i.created_at IS NOT NULL
        THEN ROUND(
            (JULIANDAY(i.applied_at) - JULIANDAY(i.created_at)) * 24 * 60 * 60,
            2
        )
        ELSE NULL
    END as execution_time_seconds,

    -- Decision metadata
    i.details,
    i.estimated_cost,
    i.priority,
    i.created_at as decision_created_at,
    i.modified_at,

    -- Change information
    i.change_id,
    i.detection_run_id,
    ccl.change_type,
    ccl.file_name,
    ccl.similarity_score,
    ccl.requires_faq_regeneration,
    ccl.detection_timestamp,

    -- Time from change detection to decision application
    CASE
        WHEN i.applied_at IS NOT NULL AND ccl.detection_timestamp IS NOT NULL
        THEN ROUND(
            (JULIANDAY(i.applied_at) - JULIANDAY(ccl.detection_timestamp)) * 24 * 60,
            2
        )
        ELSE NULL
    END as detection_to_application_minutes

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

WHERE
    i.applied = 1  -- Only applied decisions (execution history)

    -- Optional filters (uncomment as needed)
    -- AND i.change_id = :change_id
    -- AND i.detection_run_id = :detection_run_id
    -- AND i.applied_by = :applied_by
    -- AND i.applied_at >= :start_date
    -- AND i.applied_at <= :end_date
    -- AND i.entity_type = :entity_type
    -- AND i.decision = :decision

ORDER BY
    i.applied_at DESC,
    i.impact_id ASC;

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Execution history with entity details (Questions)
-- ============================================================================
-- Use case: Audit trail with full question context
-- ============================================================================

SELECT
    i.impact_id,
    i.decision,
    i.reason,
    i.applied_at,
    i.applied_by,

    -- Question details
    q.question_id,
    q.question_text,
    q.status as question_status,
    q.inactivation_reason,
    q.inactivated_at,

    -- Change details
    ccl.change_type,
    ccl.file_name,

    i.application_error

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

LEFT JOIN faq_questions q
    ON i.entity_type = 'QUESTION'
    AND i.entity_id = q.question_id

WHERE
    i.applied = 1
    AND i.entity_type = 'QUESTION'

ORDER BY
    i.applied_at DESC;

-- ============================================================================
-- VARIANT 2: Execution history with entity details (Answers)
-- ============================================================================
-- Use case: Audit trail with full answer context
-- ============================================================================

SELECT
    i.impact_id,
    i.decision,
    i.reason,
    i.applied_at,
    i.applied_by,

    -- Answer details
    a.answer_id,
    a.question_id,
    a.answer_text,
    a.status as answer_status,
    a.inactivation_reason,
    a.inactivated_at,

    -- Change details
    ccl.change_type,
    ccl.file_name,

    i.application_error

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

LEFT JOIN faq_answers a
    ON i.entity_type = 'ANSWER'
    AND i.entity_id = a.answer_id

WHERE
    i.applied = 1
    AND i.entity_type = 'ANSWER'

ORDER BY
    i.applied_at DESC;

-- ============================================================================
-- VARIANT 3: Execution timeline summary (by day)
-- ============================================================================
-- Use case: Dashboard - execution activity over time
-- ============================================================================

SELECT
    DATE(applied_at) as execution_date,

    COUNT(*) as total_executions,
    COUNT(DISTINCT change_id) as changes_processed,
    COUNT(DISTINCT entity_id) as entities_affected,

    -- Decision breakdown
    SUM(CASE WHEN decision = 'PLAN_CREATE' THEN 1 ELSE 0 END) as creates,
    SUM(CASE WHEN decision LIKE 'REGEN%' THEN 1 ELSE 0 END) as regenerations,
    SUM(CASE WHEN decision = 'INACTIVATE' THEN 1 ELSE 0 END) as inactivations,

    -- Error tracking
    SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) as errors,

    -- Cost tracking
    SUM(estimated_cost) as total_cost,

    -- Executors
    COUNT(DISTINCT applied_by) as unique_executors

FROM faq_impact

WHERE applied = 1

GROUP BY DATE(applied_at)

ORDER BY execution_date DESC;

-- ============================================================================
-- VARIANT 4: Error analysis - Failed executions
-- ============================================================================
-- Use case: Identify and analyze execution failures
-- ============================================================================

SELECT
    i.impact_id,
    i.entity_type,
    i.entity_id,
    i.decision,
    i.reason,

    -- Error details
    i.application_error,
    i.applied_at as attempted_at,
    i.applied_by,

    -- Context
    i.created_at as decision_created_at,
    ccl.change_type,
    ccl.file_name,

    i.details

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

WHERE
    i.application_error IS NOT NULL  -- Has error
    -- Note: Can have applied=0 (failed, not applied) or applied=1 (applied with warning)

ORDER BY
    i.applied_at DESC;

-- ============================================================================
-- VARIANT 5: Execution performance metrics
-- ============================================================================
-- Use case: Analyze execution efficiency and bottlenecks
-- ============================================================================

SELECT
    decision,

    COUNT(*) as total_executions,

    -- Timing metrics
    AVG(
        JULIANDAY(applied_at) - JULIANDAY(created_at)
    ) * 24 * 60 as avg_decision_to_execution_minutes,

    MIN(
        JULIANDAY(applied_at) - JULIANDAY(created_at)
    ) * 24 * 60 as min_decision_to_execution_minutes,

    MAX(
        JULIANDAY(applied_at) - JULIANDAY(created_at)
    ) * 24 * 60 as max_decision_to_execution_minutes,

    -- Cost metrics
    SUM(estimated_cost) as total_cost,
    AVG(estimated_cost) as avg_cost,

    -- Error rate
    SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) as error_count,
    ROUND(
        100.0 * SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) as error_rate_percentage

FROM faq_impact

WHERE applied = 1

GROUP BY decision

ORDER BY total_executions DESC;

-- ============================================================================
-- VARIANT 6: Executor performance summary
-- ============================================================================
-- Use case: Audit - who executed what and when
-- ============================================================================

SELECT
    applied_by as executor,

    COUNT(*) as total_executions,
    COUNT(DISTINCT change_id) as changes_processed,
    COUNT(DISTINCT detection_run_id) as runs_processed,

    -- Decision breakdown
    SUM(CASE WHEN decision = 'PLAN_CREATE' THEN 1 ELSE 0 END) as creates,
    SUM(CASE WHEN decision LIKE 'REGEN%' THEN 1 ELSE 0 END) as regenerations,
    SUM(CASE WHEN decision = 'INACTIVATE' THEN 1 ELSE 0 END) as inactivations,

    -- Error rate
    SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) as errors,
    ROUND(
        100.0 * SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) as error_rate,

    -- Timing
    MIN(applied_at) as first_execution,
    MAX(applied_at) as last_execution,

    -- Cost
    SUM(estimated_cost) as total_cost

FROM faq_impact

WHERE applied = 1

GROUP BY applied_by

ORDER BY total_executions DESC;

-- ============================================================================
-- VARIANT 7: Change impact audit trail
-- ============================================================================
-- Use case: For a specific change, show all executed decisions
-- ============================================================================

SELECT
    i.impact_id,
    i.entity_type,
    i.entity_id,
    i.decision,
    i.reason,
    i.applied_at,
    i.applied_by,

    -- Execution order
    ROW_NUMBER() OVER (PARTITION BY i.change_id ORDER BY i.applied_at ASC) as execution_order,

    i.application_error,
    i.estimated_cost,

    -- Change context
    ccl.change_type,
    ccl.file_name,
    ccl.similarity_score,
    ccl.detection_timestamp

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

WHERE
    i.applied = 1
    AND i.change_id = :change_id

ORDER BY
    i.applied_at ASC;

-- ============================================================================
-- VARIANT 8: Rollback detection (re-applied decisions)
-- ============================================================================
-- Use case: Identify decisions that were executed multiple times
-- Note: Requires historical tracking (current schema is append-only)
-- ============================================================================

SELECT
    entity_type,
    entity_id,
    decision,

    COUNT(*) as execution_count,
    GROUP_CONCAT(impact_id) as impact_ids,
    GROUP_CONCAT(applied_at) as execution_timestamps,
    GROUP_CONCAT(applied_by) as executors,

    MIN(applied_at) as first_execution,
    MAX(applied_at) as last_execution

FROM faq_impact

WHERE applied = 1

GROUP BY
    entity_type,
    entity_id,
    decision

HAVING COUNT(*) > 1  -- Executed more than once

ORDER BY execution_count DESC;

-- ============================================================================
-- VARIANT 9: Execution history with detection run context
-- ============================================================================
-- Use case: Understand execution patterns by detection run
-- ============================================================================

SELECT
    i.detection_run_id,

    COUNT(*) as total_applied,
    COUNT(DISTINCT i.change_id) as changes_processed,

    -- Timing
    MIN(i.applied_at) as first_application,
    MAX(i.applied_at) as last_application,
    ROUND(
        (JULIANDAY(MAX(i.applied_at)) - JULIANDAY(MIN(i.applied_at))) * 24 * 60,
        2
    ) as execution_duration_minutes,

    -- Decisions
    SUM(CASE WHEN i.decision = 'PLAN_CREATE' THEN 1 ELSE 0 END) as creates,
    SUM(CASE WHEN i.decision LIKE 'REGEN%' THEN 1 ELSE 0 END) as regenerations,
    SUM(CASE WHEN i.decision = 'INACTIVATE' THEN 1 ELSE 0 END) as inactivations,

    -- Errors
    SUM(CASE WHEN i.application_error IS NOT NULL THEN 1 ELSE 0 END) as errors,

    -- Cost
    SUM(i.estimated_cost) as total_cost,

    -- Executors
    COUNT(DISTINCT i.applied_by) as executors

FROM faq_impact i

WHERE i.applied = 1

GROUP BY i.detection_run_id

ORDER BY first_application DESC;

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage:
--   - idx_faq_impact_decision (filters on applied=1)
--   - idx_faq_impact_change (JOIN on change_id)
--   - idx_faq_impact_run (filters on detection_run_id)
-- Query plan:
--   - Filter on applied=1 using index
--   - JOIN with content_change_log on change_id
--   - Optional LEFT JOIN with faq_questions/faq_answers
-- Expected rows: 100-10000 execution records (depends on system usage)
-- Execution time: 50-500ms depending on filters and JOINs
-- Optimization:
--   - Filter by date range to reduce result set
--   - Use specific change_id or detection_run_id filters
--   - Consider partitioning by applied_at for very large datasets
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 89)
-- ============================================================================
-- [✓] Audit query showing execution history with applied impacts
-- [✓] Includes timestamps (created_at, applied_at, detection_timestamp)
-- [✓] Calculates execution time (decision_created to applied)
-- [✓] Tracks errors (application_error column)
-- [✓] Joins with content_change_log for comprehensive context
-- [✓] Joins with faq tables for entity details (VARIANT 1-2)
-- [✓] Supports rollback analysis (VARIANT 8 - re-applied decisions)
-- [✓] Provides multiple analysis perspectives (timeline, performance, executor, errors)
-- ============================================================================
