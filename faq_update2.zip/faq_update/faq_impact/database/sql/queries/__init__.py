"""
Database Queries - Parameterized SQL Statements

This module contains parameterized SQL queries for common impact analysis
operations. Queries are organized by functional area and designed for reuse.

Query Categories:
    1. Impact Analysis Queries
       - get_affected_questions_by_chunk
       - get_chunks_by_question
       - get_all_active_provenance

    2. Regeneration Queue Queries
       - enqueue_for_regeneration
       - get_next_regeneration_batch
       - mark_regeneration_complete

    3. Cache Management Queries
       - rebuild_impact_cache
       - invalidate_cache_for_chunk
       - get_cache_statistics

    4. Metrics and Reporting Queries
       - get_impact_summary
       - get_regeneration_metrics
       - get_analysis_history

Design Principles:
    - SQL Injection Safe: All queries use parameterization
    - Performance Optimized: Queries use indexes and avoid N+1
    - Backend Agnostic: Compatible with SQLite and Databricks
    - Testable: Queries can be tested in isolation

Example:
    >>> from faq_impact.database.sql.queries import get_affected_questions_by_chunk
    >>> query, params = get_affected_questions_by_chunk(chunk_id=123)
    >>> results = backend.execute_query(query, params)

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Query definitions will be added as operations are implemented
__all__ = []
