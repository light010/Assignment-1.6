# SQL Query Templates - Usage Guide

**Document Version**: 1.0
**Last Updated**: 2025-11-02
**Section**: Phase 2, Item 90
**Dependencies**: Items 81-89 (SQL query templates)

---

## Table of Contents

1. [Overview](#overview)
2. [Query Index](#query-index)
3. [Query Usage Patterns](#query-usage-patterns)
4. [Parameter Formats](#parameter-formats)
5. [Expected Result Schemas](#expected-result-schemas)
6. [Performance Considerations](#performance-considerations)
7. [Index Requirements](#index-requirements)
8. [Common Use Cases](#common-use-cases)
9. [Integration Examples](#integration-examples)

---

## Overview

This directory contains SQL query templates for the FAQ Impact Analysis system. Each query template is designed to support specific workflows in the impact detection and application phases.

### Query Organization

- **Impact Queries** (Items 81-84): Query impact decisions and summaries
- **FAQ Analysis Queries** (Items 85-86): Analyze FAQ data quality and relationships
- **Content Queries** (Items 87-88): Content chunk analysis and token matching
- **Audit Queries** (Item 89): Execution history and audit trails

### Template Format

All query templates follow this structure:

1. **Header**: Description, purpose, dependencies, item number
2. **Parameters**: Parameterized inputs with types
3. **Main Query**: Primary use case query
4. **Variant Queries**: Alternative query patterns for different scenarios
5. **Performance Notes**: Index usage, query plan, optimization tips
6. **Acceptance Criteria**: Validation checklist

---

## Query Index

| Query File | Purpose | Priority | Item |
|------------|---------|----------|------|
| `get_impact_by_change.sql` | Retrieve all impacts for a specific change | HIGH | 81 |
| `get_impact_by_run.sql` | Retrieve all impacts for a detection run | HIGH | 82 |
| `get_pending_applications.sql` | Find all pending impact decisions | CRITICAL | 83 |
| `get_impact_summary.sql` | Aggregate impact statistics for reporting | MEDIUM | 84 |
| `get_orphaned_questions.sql` | Find questions with zero valid sources | HIGH | 85 |
| `get_affected_faqs_for_checksum.sql` | Find FAQs linked to a content checksum | HIGH | 86 |
| `get_duplicate_checksums.sql` | Check for duplicate content checksums | MEDIUM | 87 |
| `get_token_overlap_candidates.sql` | Find questions containing changed tokens | HIGH | 88 |
| `get_impact_execution_history.sql` | Audit trail of executed decisions | MEDIUM | 89 |

---

## Query Usage Patterns

### 1. Impact Decision Queries

#### **get_impact_by_change.sql**

**When to use**:
- Apply Plan phase: Get all pending decisions for a specific content change
- Review phase: Understand what impacts a change triggered
- Debugging: Trace decisions back to triggering change

**Key variants**:
- Main query: All impacts for a change, ordered by priority
- Variant 1: Only actionable decisions (exclude EVALUATE/NOOP)
- Variant 2: Grouped summary by decision type
- Variant 3: With content change details (JOIN)

**Example**:
```sql
-- Get all pending decisions for change_id = 12345
SELECT * FROM faq_impact
WHERE change_id = 12345 AND applied = 0
ORDER BY priority DESC, impact_id ASC;
```

---

#### **get_impact_by_run.sql**

**When to use**:
- Reporting: Summarize results of a detection run
- Dashboard: Display run statistics and decision breakdown
- Pagination: Browse large result sets from a run

**Key variants**:
- Main query: Paginated list of all impacts
- Aggregated summary: Counts by decision type (for dashboards)
- Variant 1: Breakdown by decision and reason
- Variant 5: Complete run report with change details

**Example**:
```sql
-- Get summary for detection run
SELECT decision, COUNT(*) as total_decisions,
       SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending_count
FROM faq_impact
WHERE detection_run_id = 'RUN_20251102_143000'
GROUP BY decision;
```

---

#### **get_pending_applications.sql** (CRITICAL)

**When to use**:
- Apply Plan phase: Get all pending decisions to execute
- Prioritization: Identify high-priority pending actions
- Cost estimation: Calculate total cost before execution

**Key variants**:
- Main query: All pending, ordered by change_id and priority
- Variant 1: High-priority only (priority >= 7)
- Variant 3: Pending INACTIVATE decisions (highest priority)
- Variant 7: Execution plan estimate (cost and count)

**Example**:
```sql
-- Get all pending decisions, high priority first
SELECT impact_id, entity_type, entity_id, decision, priority
FROM faq_impact
WHERE applied = 0
  AND decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE')
ORDER BY change_id ASC, priority DESC;
```

**⚠️ CRITICAL USAGE NOTE**: This query is the core of the Apply Plan workflow. Always filter by actionable decisions (exclude EVALUATE/NOOP).

---

#### **get_impact_summary.sql**

**When to use**:
- Dashboard reporting: Executive summary of impact analysis
- Trend analysis: Decision distribution over time
- Cost tracking: Total estimated costs by decision type

**Key variants**:
- Main query: Full breakdown by decision, reason, entity_type
- Variant 1: Summary by decision type only
- Variant 4: Overall executive summary (single row)
- Variant 5: Time-series summary (daily aggregation)

**Example**:
```sql
-- Executive summary (single row)
SELECT COUNT(*) as total_decisions,
       SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending,
       SUM(estimated_cost) as total_cost
FROM faq_impact;
```

---

### 2. FAQ Analysis Queries

#### **get_orphaned_questions.sql**

**When to use**:
- Data quality checks: Find questions that lost all sources
- Proactive monitoring: Identify at-risk questions (1 valid source)
- Cleanup: Find questions to inactivate or regenerate

**Key variants**:
- Main query: All questions with zero valid sources
- Variant 1: Active orphans only (HIGH PRIORITY)
- Variant 2: With invalidation details (understand WHY)
- Variant 4: At-risk questions (only 1 valid source)

**Example**:
```sql
-- Active questions with no valid sources
SELECT q.question_id, q.question_text,
       COUNT(qs.source_id) as total_sources,
       SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_sources
FROM faq_questions q
LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id
WHERE q.status = 'active'
GROUP BY q.question_id
HAVING COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0;
```

---

#### **get_affected_faqs_for_checksum.sql**

**When to use**:
- Impact analysis: Determine which FAQs reference a changed content chunk
- Analysis strategies: Source impact, sole source, primary source analysis
- Decision creation: Find entities to create impact decisions for

**Key variants**:
- Main query: All FAQs (questions + answers) linked to checksum
- Variant 1: Simple entity list (minimal response)
- Variant 5: With primary source impact analysis (severity classification)
- Variant 6: Batch checksum lookup (multiple checksums)

**Example**:
```sql
-- Simple list of affected entities
SELECT DISTINCT 'QUESTION' as entity_type, question_id as entity_id
FROM faq_question_sources
WHERE content_checksum = 'abc123' AND is_valid = 1
UNION
SELECT DISTINCT 'ANSWER' as entity_type, answer_id as entity_id
FROM faq_answer_sources
WHERE content_checksum = 'abc123' AND is_valid = 1;
```

---

### 3. Content Queries

#### **get_duplicate_checksums.sql**

**When to use**:
- Before insert: Check if content already exists
- Batch insert: Validate multiple checksums at once
- Deduplication: Identify duplicate content chunks

**Key variants**:
- Main query: Single checksum lookup
- Variant 1: Batch checksum check (optimized for multiple)
- Variant 7: Fast EXISTS check (boolean result)
- Variant 8: Batch EXISTS check with results per checksum

**Example**:
```sql
-- Check if checksum exists (boolean)
SELECT CASE
    WHEN EXISTS (
        SELECT 1 FROM content_chunks
        WHERE content_checksum = 'abc123' AND status = 'active'
    ) THEN 1 ELSE 0
END as checksum_exists;
```

---

#### **get_token_overlap_candidates.sql**

**When to use**:
- Token overlap analysis: Find questions containing changed tokens
- Semantic impact: Identify questions affected by token-level changes
- Fuzzy matching: Broad search for potential impacts

**Key variants**:
- Main query: Single token exact match (word boundaries)
- Variant 1: Fuzzy substring match
- Variant 2: Multiple token matching (OR logic)
- Variant 7: Batch token processing with temp table

**Example**:
```sql
-- Find questions containing token (word boundary)
SELECT question_id, question_text
FROM faq_questions
WHERE (
    LOWER(question_text) LIKE LOWER('token')
    OR LOWER(question_text) LIKE LOWER('token %')
    OR LOWER(question_text) LIKE LOWER('% token')
    OR LOWER(question_text) LIKE LOWER('% token %')
)
AND status = 'active';
```

**⚠️ PERFORMANCE NOTE**: LIKE queries with leading wildcards cannot use indexes. Consider Full-Text Search (FTS5) for production use.

---

### 4. Audit Queries

#### **get_impact_execution_history.sql**

**When to use**:
- Audit trails: Track who executed what and when
- Performance analysis: Measure execution times
- Error analysis: Identify failed executions
- Rollback detection: Find re-applied decisions

**Key variants**:
- Main query: Complete execution history with change context
- Variant 4: Error analysis (failed executions)
- Variant 5: Execution performance metrics
- Variant 8: Rollback detection (re-applied decisions)

**Example**:
```sql
-- Execution history for a change
SELECT impact_id, decision, applied_at, applied_by, application_error
FROM faq_impact
WHERE change_id = 12345 AND applied = 1
ORDER BY applied_at ASC;
```

---

## Parameter Formats

### Common Parameter Types

| Parameter | Type | Example | Description |
|-----------|------|---------|-------------|
| `:change_id` | INTEGER | `12345` | Content change ID |
| `:detection_run_id` | TEXT | `'RUN_20251102_143000'` | Detection run identifier |
| `:entity_id` | TEXT | `'Q123'` or `'A456'` | Question/Answer ID |
| `:content_checksum` | TEXT | `'abc123...'` | SHA-256 checksum |
| `:token` | TEXT | `'employee'` | Token to search for |
| `:applied_status` | INTEGER | `0` or `1` | 0=pending, 1=applied |
| `:status_filter` | TEXT | `'active'` or `'inactive'` | Entity status |
| `:start_date` | DATETIME | `'2025-11-01T00:00:00'` | ISO-8601 format |
| `:limit` | INTEGER | `100` | Pagination limit |
| `:offset` | INTEGER | `0` | Pagination offset |

### Array Parameters

For batch operations (SQLite does not have native array type):

**Option 1: IN clause with comma-separated values**
```sql
-- Application builds this string dynamically
WHERE content_checksum IN ('checksum1', 'checksum2', 'checksum3')
```

**Option 2: Temporary table**
```sql
CREATE TEMP TABLE temp_checksums (checksum TEXT);
INSERT INTO temp_checksums VALUES ('checksum1'), ('checksum2');
-- Use temp table in query
```

**Option 3: VALUES clause (SQLite 3.7.11+)**
```sql
SELECT * FROM (VALUES ('checksum1'), ('checksum2')) AS t(checksum)
```

---

## Expected Result Schemas

### get_impact_by_change.sql
```
impact_id: INTEGER
entity_type: TEXT
entity_id: TEXT
change_id: INTEGER
detection_run_id: TEXT
decision: TEXT
reason: TEXT
details: TEXT (JSON)
applied: INTEGER (0 or 1)
applied_at: DATETIME
applied_by: TEXT
application_error: TEXT
estimated_cost: REAL
priority: INTEGER
created_at: DATETIME
modified_at: DATETIME
```

### get_impact_summary.sql (Main query)
```
decision: TEXT
reason: TEXT
entity_type: TEXT
total_count: INTEGER
pending_count: INTEGER
applied_count: INTEGER
error_count: INTEGER
affected_entity_count: INTEGER
affected_change_count: INTEGER
total_estimated_cost: REAL
avg_cost_per_decision: REAL
avg_priority: REAL
...
```

### get_orphaned_questions.sql
```
question_id: TEXT
question_text: TEXT
status: TEXT
total_source_count: INTEGER
valid_source_count: INTEGER
invalid_source_count: INTEGER
created_at: DATETIME
inactivation_reason: TEXT
...
```

### get_affected_faqs_for_checksum.sql (Variant 1)
```
entity_type: TEXT ('QUESTION' or 'ANSWER')
entity_id: TEXT
```

### get_duplicate_checksums.sql (Variant 7)
```
checksum_exists: INTEGER (0 or 1)
```

---

## Performance Considerations

### Index Usage Summary

| Query | Primary Index | Query Plan | Expected Time |
|-------|---------------|------------|---------------|
| get_impact_by_change | `idx_faq_impact_change` | Index seek | < 10ms |
| get_impact_by_run | `idx_faq_impact_run` | Index seek | < 20ms |
| get_pending_applications | `idx_faq_impact_apply` | Index scan + filter | < 20ms |
| get_impact_summary | N/A (aggregation) | Full scan + hash aggregate | 50-200ms |
| get_orphaned_questions | FK indexes | LEFT JOIN + GROUP BY | 50-200ms |
| get_affected_faqs_for_checksum | `idx_*_sources_checksum` | Index seek (if exists) | < 50ms |
| get_duplicate_checksums | `idx_content_chunks_checksum` | Index seek | < 10ms |
| get_token_overlap_candidates | N/A (LIKE %...%) | Full table scan | 100-500ms |
| get_impact_execution_history | `idx_faq_impact_decision` | Index scan + JOIN | 50-500ms |

### Query Optimization Tips

1. **Always filter by indexed columns first**
   - `WHERE change_id = X` (uses index) before other filters
   - `WHERE applied = 0` before complex predicates

2. **Use specific variants for common patterns**
   - Variant 1 queries are typically optimized for specific use cases
   - Summary variants (aggregation) are pre-optimized

3. **Batch queries when possible**
   - Variant 6 (batch checksum lookup) is more efficient than N single queries
   - Use temp tables for large lists

4. **Pagination for large result sets**
   - Use LIMIT/OFFSET for browsing
   - Default LIMIT to 100 for UI queries

5. **Avoid LIKE with leading wildcards**
   - `LIKE '%token%'` cannot use index (full scan)
   - Consider FTS5 for production text search

---

## Index Requirements

### Critical Indexes (Must Have)

```sql
-- faq_impact table
CREATE INDEX idx_faq_impact_change ON faq_impact(change_id);
CREATE INDEX idx_faq_impact_run ON faq_impact(detection_run_id);
CREATE INDEX idx_faq_impact_entity ON faq_impact(entity_type, entity_id);
CREATE INDEX idx_faq_impact_decision ON faq_impact(decision, applied);
CREATE INDEX idx_faq_impact_apply ON faq_impact(change_id, applied, decision, impact_id);

-- content_chunks table
CREATE INDEX idx_content_chunks_checksum ON content_chunks(content_checksum);

-- faq_question_sources and faq_answer_sources
CREATE INDEX idx_faq_question_sources_checksum ON faq_question_sources(content_checksum);
CREATE INDEX idx_faq_answer_sources_checksum ON faq_answer_sources(content_checksum);
```

### Optional Indexes (Performance Boost)

```sql
-- Composite index for status filtering
CREATE INDEX idx_content_chunks_checksum_status ON content_chunks(content_checksum, status);

-- Partial index for pending decisions
CREATE UNIQUE INDEX idx_faq_impact_unique_pending
    ON faq_impact(entity_type, entity_id, change_id, decision)
    WHERE applied = 0;
```

---

## Common Use Cases

### Use Case 1: Apply Plan Workflow

**Scenario**: Execute all pending decisions for a content change

**Steps**:
1. Get pending decisions: `get_pending_applications.sql` (Variant 1 - high priority)
2. For each decision, execute business logic
3. Mark as applied: `UPDATE faq_impact SET applied = 1, applied_at = CURRENT_TIMESTAMP WHERE impact_id = X`
4. Audit: `get_impact_execution_history.sql` (Variant 7)

**Query sequence**:
```sql
-- Step 1: Get pending high-priority decisions
SELECT * FROM get_pending_applications WHERE priority >= 7;

-- Step 2: Execute (application logic)

-- Step 3: Mark applied
UPDATE faq_impact SET applied = 1, applied_at = CURRENT_TIMESTAMP, applied_by = 'user123'
WHERE impact_id = 456;

-- Step 4: Audit trail
SELECT * FROM get_impact_execution_history WHERE change_id = 12345;
```

---

### Use Case 2: Impact Analysis for New Content Change

**Scenario**: Analyze a new content change and create impact decisions

**Steps**:
1. Check for duplicate content: `get_duplicate_checksums.sql` (Variant 7)
2. Find affected FAQs: `get_affected_faqs_for_checksum.sql` (Variant 1)
3. Analyze token overlap: `get_token_overlap_candidates.sql` (Variant 2)
4. Create impact decisions (application logic)
5. Review summary: `get_impact_summary.sql` (Variant 1)

**Query sequence**:
```sql
-- Step 1: Check duplicate
SELECT checksum_exists FROM get_duplicate_checksums WHERE checksum = 'abc123';

-- Step 2: Find affected FAQs
SELECT entity_type, entity_id FROM get_affected_faqs_for_checksum WHERE checksum = 'abc123';

-- Step 3: Token overlap
SELECT question_id FROM get_token_overlap_candidates WHERE token IN ('employee', 'benefit');

-- Step 4: Create decisions (INSERT INTO faq_impact ...)

-- Step 5: Summary
SELECT decision, COUNT(*) FROM get_impact_summary GROUP BY decision;
```

---

### Use Case 3: Data Quality Monitoring

**Scenario**: Daily data quality check for orphaned FAQs

**Steps**:
1. Find active orphaned questions: `get_orphaned_questions.sql` (Variant 1)
2. Find at-risk questions: `get_orphaned_questions.sql` (Variant 4)
3. Generate report with recommendations

**Query sequence**:
```sql
-- Step 1: Active orphans (should be inactivated)
SELECT question_id, question_text FROM get_orphaned_questions WHERE status = 'active';

-- Step 2: At-risk (1 valid source - monitor)
SELECT question_id, valid_sources FROM get_orphaned_questions WHERE valid_sources = 1;
```

---

## Integration Examples

### Python Integration (using parameterized queries)

```python
import sqlite3
from pathlib import Path

# Read query template
query_file = Path("database/sql/queries/get_impact_by_change.sql")
query = query_file.read_text()

# Extract main query (simple approach - parse between markers)
# In production, use proper SQL parser or load specific queries

# Execute with parameters
conn = sqlite3.connect("faq.db")
cursor = conn.cursor()

params = {"change_id": 12345, "applied_status": 0}
cursor.execute(query, params)

results = cursor.fetchall()
for row in results:
    print(f"Impact {row['impact_id']}: {row['decision']} for {row['entity_type']} {row['entity_id']}")
```

### Repository Pattern

```python
class ImpactRepository:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.queries = self._load_queries()

    def _load_queries(self):
        """Load all query templates"""
        queries_dir = Path("database/sql/queries")
        return {
            "get_impact_by_change": (queries_dir / "get_impact_by_change.sql").read_text(),
            "get_pending_applications": (queries_dir / "get_pending_applications.sql").read_text(),
            # ... load all queries
        }

    def get_pending_applications(self, change_id=None, min_priority=None):
        """Get pending impact decisions"""
        query = self.queries["get_pending_applications"]
        # Parse and execute main query
        # Add parameter binding logic
        pass

    def get_impact_by_change(self, change_id, applied_status=None):
        """Get all impacts for a change"""
        query = self.queries["get_impact_by_change"]
        # Execute with parameters
        pass
```

---

## Troubleshooting

### Common Issues

#### Issue 1: Query returns no results

**Possible causes**:
- Incorrect parameter values (check case sensitivity for TEXT parameters)
- Status filter too restrictive (e.g., filtering `status='active'` when all are inactive)
- Missing data (run summary query to check data exists)

**Debug steps**:
```sql
-- Check if data exists
SELECT COUNT(*) FROM faq_impact WHERE change_id = 12345;

-- Remove filters incrementally
SELECT COUNT(*) FROM faq_impact WHERE change_id = 12345 AND applied = 0;
```

#### Issue 2: Query is slow

**Possible causes**:
- Missing indexes (check EXPLAIN QUERY PLAN)
- Large result set (use pagination)
- LIKE query with leading wildcard (full table scan)

**Debug steps**:
```sql
-- Check query plan
EXPLAIN QUERY PLAN
SELECT * FROM faq_impact WHERE change_id = 12345;

-- Check index usage
SELECT * FROM sqlite_master WHERE type = 'index' AND tbl_name = 'faq_impact';
```

#### Issue 3: Duplicate results

**Possible causes**:
- Missing DISTINCT in multi-table JOINs
- Cartesian product from incorrect JOIN condition
- Multiple source records per entity

**Fix**:
- Add `SELECT DISTINCT`
- Verify JOIN conditions
- Use Variant 1 queries (optimized for unique results)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2025-11-02 | Initial query guide (Items 81-90) |

---

## Related Documentation

- `../schema/07_faq_impact.sql` - faq_impact table schema
- `../schema/02_faq_questions_enhanced.sql` - Enhanced questions schema
- `../schema/03_faq_answers_enhanced.sql` - Enhanced answers schema
- `../../IMPLEMENTATION_PLAN.md` - Section 2.4 (Items 81-90)
- `../../core/enums/` - Enum definitions (DecisionType, ReasonCode, EntityType)

---

**End of Query Guide**
