-- ============================================================================
-- QUERY: get_orphaned_questions.sql
-- ============================================================================
-- Description: Find questions with zero valid sources (orphan detection edge case)
-- Purpose: Data quality check - identify questions that lost all their sources
-- Dependencies: faq_questions, faq_question_sources tables
-- Item: 85
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :status (TEXT, OPTIONAL) - Filter by question status ('active', 'inactive', or NULL for all)
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - Questions with zero valid sources
-- ============================================================================
-- Returns: Questions with no valid sources (is_valid=1)
-- Use case: Identify orphaned questions that should be reviewed/inactivated
-- Uses: LEFT JOIN to find questions with COUNT(valid sources) = 0
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,
    q.source_type,
    q.generation_method,

    -- Source counts
    COUNT(qs.source_id) as total_source_count,
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_source_count,
    SUM(CASE WHEN qs.is_valid = 0 THEN 1 ELSE 0 END) as invalid_source_count,

    -- Metadata for debugging
    q.created_at,
    q.modified_at,

    -- Inactivation tracking (if question is inactive)
    q.inactivation_reason,
    q.inactivated_by_change_id,
    q.inactivated_at

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

-- Optional: Filter by question status
-- WHERE q.status = :status
-- WHERE q.status = 'active'  -- Only active questions
-- WHERE q.status = 'inactive'  -- Only inactive questions

GROUP BY
    q.question_id,
    q.question_text,
    q.status,
    q.source_type,
    q.generation_method,
    q.created_at,
    q.modified_at,
    q.inactivation_reason,
    q.inactivated_by_change_id,
    q.inactivated_at

HAVING
    -- CRITICAL: Questions with zero valid sources
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) = 0
    OR SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) IS NULL

ORDER BY
    q.status ASC,      -- Active orphans first (higher priority)
    q.created_at DESC; -- Newest first

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Active orphaned questions only (HIGH PRIORITY)
-- ============================================================================
-- Use case: Questions that are active but have no valid sources
-- These should likely be inactivated or have their sources fixed
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,

    -- How many sources did it have?
    COUNT(qs.source_id) as total_sources,
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_sources,

    -- When was it created?
    q.created_at,

    -- Why did sources become invalid?
    GROUP_CONCAT(DISTINCT qs.invalidation_reason) as invalidation_reasons

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

WHERE
    q.status = 'active'  -- Only active questions

GROUP BY
    q.question_id,
    q.question_text,
    q.status,
    q.created_at

HAVING
    -- Zero valid sources
    COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0

ORDER BY
    q.created_at DESC;

-- ============================================================================
-- VARIANT 2: Orphaned questions with invalidation details
-- ============================================================================
-- Use case: Understand WHY questions became orphaned
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,

    -- Source invalidation breakdown
    COUNT(qs.source_id) as total_sources,
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_sources,
    SUM(CASE WHEN qs.is_valid = 0 THEN 1 ELSE 0 END) as invalid_sources,

    -- Invalidation reasons
    SUM(CASE WHEN qs.invalidation_reason = 'content_changed' THEN 1 ELSE 0 END) as content_changed_count,
    SUM(CASE WHEN qs.invalidation_reason = 'content_deleted' THEN 1 ELSE 0 END) as content_deleted_count,
    SUM(CASE WHEN qs.invalidation_reason = 'quality_issue' THEN 1 ELSE 0 END) as quality_issue_count,
    SUM(CASE WHEN qs.invalidation_reason = 'manual' THEN 1 ELSE 0 END) as manual_count,
    SUM(CASE WHEN qs.invalidation_reason = 'selective_impact' THEN 1 ELSE 0 END) as selective_impact_count,

    -- Timing
    q.created_at as question_created,
    MAX(qs.valid_until) as last_source_invalidated

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

GROUP BY
    q.question_id,
    q.question_text,
    q.status,
    q.created_at

HAVING
    COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0

ORDER BY
    last_source_invalidated DESC;

-- ============================================================================
-- VARIANT 3: Orphaned questions with triggering changes
-- ============================================================================
-- Use case: Trace orphaned questions back to content changes
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,

    COUNT(DISTINCT qs.source_id) as total_sources,
    COUNT(DISTINCT qs.invalidated_by_change_id) as unique_triggering_changes,

    -- List of triggering change IDs
    GROUP_CONCAT(DISTINCT qs.invalidated_by_change_id) as change_ids,

    -- Invalidation reasons
    GROUP_CONCAT(DISTINCT qs.invalidation_reason) as invalidation_reasons

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

WHERE
    q.status = 'active'  -- Focus on active questions

GROUP BY
    q.question_id,
    q.question_text,
    q.status

HAVING
    COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0
    AND COUNT(qs.source_id) > 0  -- Had sources but they were invalidated

ORDER BY
    unique_triggering_changes DESC;

-- ============================================================================
-- VARIANT 4: Questions with low valid source count (at-risk)
-- ============================================================================
-- Use case: Proactive monitoring - questions with only 1 valid source
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,

    COUNT(qs.source_id) as total_sources,
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_sources,
    SUM(CASE WHEN qs.is_valid = 0 THEN 1 ELSE 0 END) as invalid_sources,

    q.created_at

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

WHERE
    q.status = 'active'

GROUP BY
    q.question_id,
    q.question_text,
    q.status,
    q.created_at

HAVING
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) = 1  -- Only 1 valid source (at-risk)

ORDER BY
    q.created_at DESC;

-- ============================================================================
-- VARIANT 5: Orphaned questions summary (dashboard)
-- ============================================================================
-- Use case: Executive summary - how many orphaned questions exist
-- ============================================================================

SELECT
    q.status,

    COUNT(DISTINCT q.question_id) as orphaned_question_count,

    -- Breakdown by source type
    SUM(CASE WHEN q.source_type = 'from_documents' THEN 1 ELSE 0 END) as from_documents,
    SUM(CASE WHEN q.source_type = 'from_user_queries' THEN 1 ELSE 0 END) as from_user_queries,
    SUM(CASE WHEN q.source_type = 'from_manual' THEN 1 ELSE 0 END) as from_manual,

    -- Timing
    MIN(q.created_at) as oldest_orphan,
    MAX(q.created_at) as newest_orphan

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

GROUP BY q.question_id, q.status, q.source_type, q.created_at

HAVING
    COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0

-- Outer aggregation
SELECT
    status,
    COUNT(*) as orphaned_count,
    SUM(from_documents) as from_documents_count,
    SUM(from_user_queries) as from_user_queries_count,
    SUM(from_manual) as from_manual_count,
    MIN(oldest_orphan) as oldest_orphan_created,
    MAX(newest_orphan) as newest_orphan_created
FROM (
    SELECT
        q.status,
        q.question_id,
        CASE WHEN q.source_type = 'from_documents' THEN 1 ELSE 0 END as from_documents,
        CASE WHEN q.source_type = 'from_user_queries' THEN 1 ELSE 0 END as from_user_queries,
        CASE WHEN q.source_type = 'from_manual' THEN 1 ELSE 0 END as from_manual,
        q.created_at as oldest_orphan,
        q.created_at as newest_orphan
    FROM faq_questions q
    LEFT JOIN faq_question_sources qs ON q.question_id = qs.question_id
    GROUP BY q.question_id, q.status, q.source_type, q.created_at
    HAVING COALESCE(SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END), 0) = 0
) subquery
GROUP BY status
ORDER BY status ASC;

-- ============================================================================
-- VARIANT 6: Questions that never had sources (edge case)
-- ============================================================================
-- Use case: Find questions created without any source links
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    q.status,
    q.source_type,
    q.generation_method,
    q.created_at

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

WHERE
    qs.source_id IS NULL  -- No source records at all

ORDER BY
    q.created_at DESC;

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage:
--   - faq_questions: idx_faq_questions_status (if filtering by status)
--   - faq_question_sources: FK index on question_id (for JOIN)
-- Query plan:
--   - LEFT JOIN between faq_questions and faq_question_sources
--   - GROUP BY question_id with HAVING filter
--   - COUNT aggregation to find zero valid sources
-- Expected rows: 0-50 orphaned questions (should be rare in healthy system)
-- Execution time: 50-200ms depending on source table size
-- Optimization: Index on (question_id, is_valid) in faq_question_sources helps aggregation
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 85)
-- ============================================================================
-- [✓] Query uses LEFT JOIN to find questions with COUNT(valid sources) = 0
-- [✓] Includes question text for debugging
-- [✓] Returns questions with no is_valid=1 sources
-- [✓] Handles NULL cases (questions with no source records)
-- [✓] Ordered by status and creation date
-- [✓] Provides variants for different analysis perspectives
-- [✓] Includes invalidation reasons for context
-- ============================================================================
