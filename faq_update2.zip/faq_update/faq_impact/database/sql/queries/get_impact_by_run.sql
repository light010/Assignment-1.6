-- ============================================================================
-- QUERY: get_impact_by_run.sql
-- ============================================================================
-- Description: Retrieve all impact decisions for a detection run, grouped by decision type
-- Purpose: Reporting and analysis - understand what decisions were made in a run
-- Dependencies: faq_impact table (07_faq_impact.sql)
-- Item: 82
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :detection_run_id (TEXT) - The detection run ID to filter by (e.g., 'RUN_20251102_143000')
-- :limit (INTEGER, OPTIONAL) - Limit for pagination (default: 100)
-- :offset (INTEGER, OPTIONAL) - Offset for pagination (default: 0)
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - All impacts for a detection run with pagination
-- ============================================================================
-- Returns: All impact decisions from a specific detection run
-- Grouping: Results ordered by decision type, then priority
-- Pagination: LIMIT/OFFSET support for large result sets
-- ============================================================================

SELECT
    -- Primary Identity
    impact_id,

    -- Entity Information
    entity_type,
    entity_id,

    -- Change Tracking
    change_id,
    detection_run_id,

    -- Decision Information
    decision,
    reason,
    details,

    -- Execution Status
    applied,
    applied_at,
    applied_by,
    application_error,

    -- Metadata
    estimated_cost,
    priority,
    created_at,
    modified_at

FROM faq_impact

WHERE
    detection_run_id = :detection_run_id

ORDER BY
    -- Group by decision type first
    decision ASC,

    -- Within each decision type, prioritize by priority
    priority DESC,

    -- Deterministic ordering
    impact_id ASC

-- Pagination support (uncomment and set parameters as needed)
-- LIMIT :limit OFFSET :offset;
LIMIT 100 OFFSET 0;

-- ============================================================================
-- AGGREGATED SUMMARY - Counts by decision type
-- ============================================================================
-- Use case: Dashboard reporting - summary statistics for detection run
-- Returns: Aggregated counts, costs, and status by decision type
-- ============================================================================

SELECT
    -- Decision type grouping
    decision,

    -- Counts
    COUNT(*) as total_decisions,
    SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending_count,
    SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as applied_count,
    SUM(CASE WHEN application_error IS NOT NULL THEN 1 ELSE 0 END) as error_count,

    -- Entity type breakdown
    SUM(CASE WHEN entity_type = 'QUESTION' THEN 1 ELSE 0 END) as question_count,
    SUM(CASE WHEN entity_type = 'ANSWER' THEN 1 ELSE 0 END) as answer_count,
    SUM(CASE WHEN entity_type = 'CHANGE' THEN 1 ELSE 0 END) as change_count,

    -- Cost and priority metrics
    SUM(estimated_cost) as total_estimated_cost,
    AVG(estimated_cost) as avg_cost_per_decision,
    AVG(priority) as avg_priority,
    MAX(priority) as max_priority,
    MIN(priority) as min_priority,

    -- Timing metrics
    MIN(created_at) as first_created,
    MAX(created_at) as last_created,
    MIN(applied_at) as first_applied,
    MAX(applied_at) as last_applied

FROM faq_impact

WHERE detection_run_id = :detection_run_id

GROUP BY decision

ORDER BY total_decisions DESC;

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Breakdown by decision and reason
-- ============================================================================
-- Use case: Detailed analysis - understand WHY each decision was made
-- ============================================================================

SELECT
    decision,
    reason,

    COUNT(*) as count,
    SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as applied,

    SUM(estimated_cost) as total_cost,
    AVG(priority) as avg_priority

FROM faq_impact

WHERE detection_run_id = :detection_run_id

GROUP BY decision, reason

ORDER BY decision ASC, count DESC;

-- ============================================================================
-- VARIANT 2: Entity type distribution
-- ============================================================================
-- Use case: Understand which entity types were most affected
-- ============================================================================

SELECT
    entity_type,
    decision,

    COUNT(*) as total_count,
    SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending_count,
    SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as applied_count,

    SUM(estimated_cost) as total_cost

FROM faq_impact

WHERE detection_run_id = :detection_run_id

GROUP BY entity_type, decision

ORDER BY entity_type ASC, total_count DESC;

-- ============================================================================
-- VARIANT 3: Affected changes summary
-- ============================================================================
-- Use case: How many unique content changes triggered impacts in this run
-- ============================================================================

SELECT
    COUNT(DISTINCT change_id) as unique_changes_count,
    COUNT(*) as total_impact_decisions,
    ROUND(CAST(COUNT(*) AS REAL) / COUNT(DISTINCT change_id), 2) as avg_decisions_per_change,

    SUM(estimated_cost) as total_estimated_cost,
    SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as total_applied,
    SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as total_pending

FROM faq_impact

WHERE detection_run_id = :detection_run_id;

-- ============================================================================
-- VARIANT 4: Top priority pending decisions
-- ============================================================================
-- Use case: Show high-priority items that need immediate attention
-- ============================================================================

SELECT
    impact_id,
    entity_type,
    entity_id,
    decision,
    reason,
    priority,
    estimated_cost,
    created_at

FROM faq_impact

WHERE
    detection_run_id = :detection_run_id
    AND applied = 0  -- Only pending
    AND decision != 'NOOP'  -- Exclude no-ops

ORDER BY
    priority DESC,
    estimated_cost DESC

LIMIT 20;

-- ============================================================================
-- VARIANT 5: Complete run report with change details
-- ============================================================================
-- Use case: Comprehensive reporting - join with content_change_log
-- ============================================================================

SELECT
    i.decision,
    i.reason,
    COUNT(*) as count,

    -- Change type breakdown
    SUM(CASE WHEN ccl.change_type = 'new_content' THEN 1 ELSE 0 END) as new_content_count,
    SUM(CASE WHEN ccl.change_type = 'modified_content' THEN 1 ELSE 0 END) as modified_content_count,
    SUM(CASE WHEN ccl.change_type = 'deleted_content' THEN 1 ELSE 0 END) as deleted_content_count,

    -- Application status
    SUM(CASE WHEN i.applied = 1 THEN 1 ELSE 0 END) as applied_count,

    -- Cost metrics
    SUM(i.estimated_cost) as total_cost,
    AVG(ccl.similarity_score) as avg_similarity_score

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

WHERE i.detection_run_id = :detection_run_id

GROUP BY i.decision, i.reason

ORDER BY count DESC;

-- ============================================================================
-- VARIANT 6: Execution timeline (for applied decisions)
-- ============================================================================
-- Use case: Audit trail - when were decisions executed
-- ============================================================================

SELECT
    DATE(applied_at) as application_date,
    applied_by,
    decision,

    COUNT(*) as decisions_applied,
    SUM(estimated_cost) as total_cost,
    COUNT(CASE WHEN application_error IS NOT NULL THEN 1 END) as error_count

FROM faq_impact

WHERE
    detection_run_id = :detection_run_id
    AND applied = 1

GROUP BY
    DATE(applied_at),
    applied_by,
    decision

ORDER BY
    application_date DESC,
    decisions_applied DESC;

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage: idx_faq_impact_run (on detection_run_id column)
-- Query plan: Index seek on detection_run_id, then sort by decision/priority
-- Expected rows: 50-500 per detection run (typical)
-- Pagination: Use LIMIT/OFFSET for large result sets
-- Aggregation: GROUP BY queries use index scan + hash aggregation
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 82)
-- ============================================================================
-- [✓] Query supports pagination via LIMIT/OFFSET parameters
-- [✓] Includes aggregated counts by decision type
-- [✓] Formatted for reporting with summary statistics
-- [✓] Grouped by decision type with detailed breakdowns
-- [✓] Uses idx_faq_impact_run index for performance
-- [✓] Supports multiple reporting formats (detailed, summary, timeline)
-- ============================================================================
