-- ============================================================================
-- QUERY: get_token_overlap_candidates.sql
-- ============================================================================
-- Description: Find questions whose text contains any of a list of changed tokens
-- Purpose: Token overlap analysis - identify questions potentially affected by token changes
-- Dependencies: faq_questions table
-- Item: 88
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :token (TEXT) - Single token to search for
-- :token_list (TEXT[]) - List of changed tokens (for batch processing)
-- :match_mode (TEXT) - Matching mode: 'exact' or 'fuzzy'
-- :status_filter (TEXT, OPTIONAL) - Filter by question status ('active', 'inactive', or NULL for all)
-- ============================================================================

-- ============================================================================
-- IMPORTANT NOTES ON TOKEN MATCHING
-- ============================================================================
-- SQLite supports two main approaches for token matching:
--
-- 1. LIKE operator (Pattern matching)
--    - Supports wildcards: % (any characters), _ (single character)
--    - Case-insensitive by default (depends on collation)
--    - Examples:
--      - LIKE '%token%' - Contains token anywhere
--      - LIKE '% token %' - Token as whole word (with spaces)
--      - LIKE 'token%' - Starts with token
--
-- 2. Full-Text Search (FTS5) - NOT USED HERE
--    - Requires FTS virtual table creation
--    - More powerful but requires schema changes
--    - For this query, we use LIKE for simplicity
--
-- Token normalization (application-side):
--   - Lowercase conversion: 'Token' → 'token'
--   - Punctuation handling: 'token.' → 'token'
--   - Stemming: 'running' → 'run' (optional)
--
-- This query template uses LIKE - application should pre-process tokens
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - Single token exact match (LIKE with word boundaries)
-- ============================================================================
-- Returns: Questions containing the specified token
-- Match mode: Exact word match (case-insensitive LIKE)
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,
    source_type,
    generation_method,
    created_at,
    modified_at

FROM faq_questions

WHERE
    -- Exact match: Token appears as whole word or part of compound word
    -- Use LOWER() for case-insensitive matching
    (
        LOWER(question_text) LIKE LOWER(:token)                    -- Exact match
        OR LOWER(question_text) LIKE LOWER(:token || ' %')         -- Token at start
        OR LOWER(question_text) LIKE LOWER('% ' || :token)         -- Token at end
        OR LOWER(question_text) LIKE LOWER('% ' || :token || ' %') -- Token in middle
        OR LOWER(question_text) LIKE LOWER('% ' || :token || '%')  -- Token at word boundary
        OR LOWER(question_text) LIKE LOWER('%' || :token || ' %')  -- Token at word boundary
    )

    -- Optional: Filter by status
    -- AND status = :status_filter
    -- AND status = 'active'  -- Only active questions

ORDER BY
    created_at DESC;

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Simple substring match (fuzzy mode)
-- ============================================================================
-- Use case: Broad matching - find any occurrence of token substring
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,

    -- Highlight where token appears (for debugging)
    CASE
        WHEN INSTR(LOWER(question_text), LOWER(:token)) > 0
        THEN SUBSTR(question_text,
                    MAX(1, INSTR(LOWER(question_text), LOWER(:token)) - 20),
                    40 + LENGTH(:token))
        ELSE NULL
    END as token_context

FROM faq_questions

WHERE
    LOWER(question_text) LIKE '%' || LOWER(:token) || '%'
    -- Optional: Filter by status
    -- AND status = 'active'

ORDER BY
    created_at DESC;

-- ============================================================================
-- VARIANT 2: Multiple token matching (OR logic)
-- ============================================================================
-- Use case: Find questions matching ANY token in the list
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,

    -- Track which tokens matched (for analysis)
    CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token1) || '%' THEN :token1 ELSE NULL END as matched_token_1,
    CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token2) || '%' THEN :token2 ELSE NULL END as matched_token_2,
    CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token3) || '%' THEN :token3 ELSE NULL END as matched_token_3
    -- Add more as needed...

FROM faq_questions

WHERE
    LOWER(question_text) LIKE '%' || LOWER(:token1) || '%'
    OR LOWER(question_text) LIKE '%' || LOWER(:token2) || '%'
    OR LOWER(question_text) LIKE '%' || LOWER(:token3) || '%'
    -- Add more OR clauses for additional tokens...

    -- Optional: Filter by status
    -- AND status = 'active'

ORDER BY
    created_at DESC;

-- ============================================================================
-- VARIANT 3: Token match with count (how many tokens matched)
-- ============================================================================
-- Use case: Prioritize questions matching multiple tokens
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,

    -- Count how many tokens matched
    (
        CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token1) || '%' THEN 1 ELSE 0 END +
        CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token2) || '%' THEN 1 ELSE 0 END +
        CASE WHEN LOWER(question_text) LIKE '%' || LOWER(:token3) || '%' THEN 1 ELSE 0 END
        -- Add more for additional tokens...
    ) as token_match_count,

    created_at

FROM faq_questions

WHERE
    -- At least one token matches
    LOWER(question_text) LIKE '%' || LOWER(:token1) || '%'
    OR LOWER(question_text) LIKE '%' || LOWER(:token2) || '%'
    OR LOWER(question_text) LIKE '%' || LOWER(:token3) || '%'

    -- Optional: Filter by status
    -- AND status = 'active'

ORDER BY
    token_match_count DESC,  -- Most matches first
    created_at DESC;

-- ============================================================================
-- VARIANT 4: Case-sensitive exact match (strict mode)
-- ============================================================================
-- Use case: When token casing matters (e.g., acronyms like 'FAQ' vs 'faq')
-- ============================================================================

SELECT
    question_id,
    question_text,
    status

FROM faq_questions

WHERE
    -- Case-sensitive match (no LOWER())
    (
        question_text LIKE :token
        OR question_text LIKE :token || ' %'
        OR question_text LIKE '% ' || :token
        OR question_text LIKE '% ' || :token || ' %'
    )

    -- Optional: Filter by status
    -- AND status = 'active'

ORDER BY
    created_at DESC;

-- ============================================================================
-- VARIANT 5: Token match with source tracking
-- ============================================================================
-- Use case: JOIN with sources to understand FAQ provenance
-- ============================================================================

SELECT DISTINCT
    q.question_id,
    q.question_text,
    q.status,

    -- Source information
    COUNT(DISTINCT qs.source_id) as total_sources,
    SUM(CASE WHEN qs.is_valid = 1 THEN 1 ELSE 0 END) as valid_sources,

    q.created_at

FROM faq_questions q

LEFT JOIN faq_question_sources qs
    ON q.question_id = qs.question_id

WHERE
    LOWER(q.question_text) LIKE '%' || LOWER(:token) || '%'
    AND q.status = 'active'

GROUP BY
    q.question_id,
    q.question_text,
    q.status,
    q.created_at

ORDER BY
    valid_sources DESC,  -- Prioritize questions with more valid sources
    q.created_at DESC;

-- ============================================================================
-- VARIANT 6: Token match candidates with regex-like pattern
-- ============================================================================
-- Use case: Advanced pattern matching (word boundary simulation)
-- Note: SQLite doesn't have native regex, use LIKE with patterns
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,

    -- Extract word context around token
    SUBSTR(
        question_text,
        MAX(1, INSTR(LOWER(question_text), LOWER(:token)) - 30),
        60
    ) as context_snippet

FROM faq_questions

WHERE
    -- Match token with word boundaries (space, punctuation, start/end)
    (
        LOWER(question_text) LIKE LOWER(:token || ' %')      -- Start of text
        OR LOWER(question_text) LIKE LOWER('% ' || :token)   -- End of text
        OR LOWER(question_text) LIKE LOWER('% ' || :token || ' %')  -- Middle
        OR LOWER(question_text) LIKE LOWER('% ' || :token || ',%')  -- Before comma
        OR LOWER(question_text) LIKE LOWER('% ' || :token || '.%')  -- Before period
        OR LOWER(question_text) LIKE LOWER('% ' || :token || '?%')  -- Before question mark
        OR LOWER(question_text) LIKE LOWER('% ' || :token || '!%')  -- Before exclamation
    )

    -- Optional: Filter by status
    AND status = 'active'

ORDER BY
    created_at DESC;

-- ============================================================================
-- VARIANT 7: Batch token processing with temp table
-- ============================================================================
-- Use case: Large list of tokens - use temp table for efficiency
-- ============================================================================

-- Step 1: Create temp table (run once)
-- CREATE TEMP TABLE temp_tokens (token TEXT);

-- Step 2: Insert tokens
-- INSERT INTO temp_tokens VALUES ('token1'), ('token2'), ('token3');

-- Step 3: Query with temp table
SELECT DISTINCT
    q.question_id,
    q.question_text,
    q.status,

    -- Which tokens matched
    GROUP_CONCAT(DISTINCT t.token) as matched_tokens,
    COUNT(DISTINCT t.token) as match_count

FROM faq_questions q

CROSS JOIN temp_tokens t

WHERE
    LOWER(q.question_text) LIKE '%' || LOWER(t.token) || '%'
    AND q.status = 'active'

GROUP BY
    q.question_id,
    q.question_text,
    q.status

ORDER BY
    match_count DESC,
    q.created_at DESC;

-- ============================================================================
-- VARIANT 8: Token overlap summary (aggregated)
-- ============================================================================
-- Use case: How many questions contain each token
-- ============================================================================

SELECT
    :token as search_token,
    COUNT(*) as matching_questions,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_matches,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_matches,
    MIN(created_at) as oldest_match,
    MAX(created_at) as newest_match

FROM faq_questions

WHERE
    LOWER(question_text) LIKE '%' || LOWER(:token) || '%';

-- ============================================================================
-- VARIANT 9: Token match with inactivation tracking
-- ============================================================================
-- Use case: Understand if matched questions have been inactivated
-- ============================================================================

SELECT
    question_id,
    question_text,
    status,

    -- Inactivation details (if applicable)
    inactivation_reason,
    inactivated_by_change_id,
    inactivated_at,

    created_at

FROM faq_questions

WHERE
    LOWER(question_text) LIKE '%' || LOWER(:token) || '%'

ORDER BY
    status ASC,  -- Active first, then inactive
    created_at DESC;

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage: LIKE queries with leading wildcard ('%token%') CANNOT use index
--   - Pattern '%token' - Cannot use index (leading wildcard)
--   - Pattern 'token%' - CAN use index (no leading wildcard)
--   - Full scan required for flexible matching
--
-- Optimization strategies:
--   1. Filter by status first (uses idx_faq_questions_status)
--   2. Use question_text index if available (rare, not recommended for TEXT)
--   3. Consider Full-Text Search (FTS5) for production use
--   4. Batch tokens with temp table (VARIANT 7) for multiple tokens
--   5. Application-side filtering for very large result sets
--
-- Expected rows: 10-100 matches per token (typical)
-- Execution time: 100-500ms for full table scan (depends on table size)
--
-- FTS5 Alternative (requires schema change):
--   - CREATE VIRTUAL TABLE faq_questions_fts USING fts5(question_text, content=faq_questions);
--   - SELECT * FROM faq_questions_fts WHERE faq_questions_fts MATCH 'token';
--   - Much faster for text search, but requires maintenance
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 88)
-- ============================================================================
-- [✓] Query template for finding questions containing tokens from a list
-- [✓] Uses parameterized token list (:token, :token_list)
-- [✓] Supports both exact and fuzzy matching modes
-- [✓] LIKE operator with word boundary patterns (exact mode)
-- [✓] Simple substring matching (fuzzy mode)
-- [✓] Batch processing support via temp table (VARIANT 7)
-- [✓] Case-insensitive matching with LOWER()
-- [✓] Performance notes and FTS5 alternative documentation
-- ============================================================================
