-- ============================================================================
-- QUERY: get_impact_by_change.sql
-- ============================================================================
-- Description: Retrieve all impact decisions for a specific change_id
-- Purpose: Used in Apply Plan workflow to get all pending/applied actions for a change
-- Dependencies: faq_impact table (07_faq_impact.sql)
-- Item: 81
-- ============================================================================

-- ============================================================================
-- PARAMETERS (Replace with actual values or use parameterized queries)
-- ============================================================================
-- :change_id (INTEGER) - The content change ID to filter by
-- :applied_status (INTEGER, OPTIONAL) - Filter by applied status (0=pending, 1=applied, NULL=all)
-- ============================================================================

-- ============================================================================
-- MAIN QUERY - All impacts for a change, ordered by priority
-- ============================================================================
-- Returns: All columns from faq_impact table
-- Ordering: Priority DESC (high priority first), then impact_id ASC (deterministic)
-- Filtering: By change_id (required), optionally by applied status
-- ============================================================================

SELECT
    -- Primary Identity
    impact_id,

    -- Entity Information
    entity_type,
    entity_id,

    -- Change Tracking
    change_id,
    detection_run_id,

    -- Decision Information
    decision,
    reason,
    details,

    -- Execution Status
    applied,
    applied_at,
    applied_by,
    application_error,

    -- Metadata
    estimated_cost,
    priority,
    created_at,
    modified_at

FROM faq_impact

WHERE
    -- Required: Filter by specific change_id
    change_id = :change_id

    -- Optional: Filter by applied status (comment out if not needed)
    -- Uncomment one of the following lines:
    -- AND applied = 0                    -- Only pending (not yet applied)
    -- AND applied = 1                    -- Only applied (already executed)
    -- AND applied = :applied_status      -- Parameterized filter

ORDER BY
    -- High priority decisions first
    priority DESC,

    -- Deterministic ordering for same priority
    impact_id ASC;

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

-- Example 1: Get all impacts for change_id = 12345
-- SELECT * FROM (above query) WHERE change_id = 12345;

-- Example 2: Get only pending impacts for change_id = 12345
-- SELECT * FROM (above query) WHERE change_id = 12345 AND applied = 0;

-- Example 3: Get only applied impacts for change_id = 12345
-- SELECT * FROM (above query) WHERE change_id = 12345 AND applied = 1;

-- ============================================================================
-- VARIANT QUERIES
-- ============================================================================

-- ============================================================================
-- VARIANT 1: Only actionable decisions (exclude EVALUATE/NOOP)
-- ============================================================================
-- Use case: Apply Plan phase - get only executable decisions
-- ============================================================================

SELECT
    impact_id,
    entity_type,
    entity_id,
    decision,
    reason,
    details,
    priority,
    estimated_cost,
    applied

FROM faq_impact

WHERE
    change_id = :change_id
    AND applied = 0  -- Only pending
    AND decision IN ('PLAN_CREATE', 'REGEN_Q', 'REGEN_A', 'REGEN_BOTH', 'INACTIVATE')

ORDER BY
    priority DESC,
    impact_id ASC;

-- ============================================================================
-- VARIANT 2: Grouped by decision type with counts
-- ============================================================================
-- Use case: Summary view - how many of each decision type for this change
-- ============================================================================

SELECT
    decision,
    COUNT(*) as total_count,
    SUM(CASE WHEN applied = 0 THEN 1 ELSE 0 END) as pending_count,
    SUM(CASE WHEN applied = 1 THEN 1 ELSE 0 END) as applied_count,
    SUM(estimated_cost) as total_cost,
    AVG(priority) as avg_priority

FROM faq_impact

WHERE change_id = :change_id

GROUP BY decision

ORDER BY total_count DESC;

-- ============================================================================
-- VARIANT 3: With content change details (JOIN)
-- ============================================================================
-- Use case: Full context - impact decisions with triggering change info
-- ============================================================================

SELECT
    i.impact_id,
    i.entity_type,
    i.entity_id,
    i.decision,
    i.reason,
    i.details,
    i.applied,
    i.priority,

    -- Content change information
    ccl.change_type,
    ccl.file_name,
    ccl.similarity_score,
    ccl.detection_timestamp,
    ccl.requires_faq_regeneration

FROM faq_impact i

INNER JOIN content_change_log ccl
    ON i.change_id = ccl.change_id

WHERE i.change_id = :change_id

ORDER BY i.priority DESC, i.impact_id ASC;

-- ============================================================================
-- PERFORMANCE NOTES
-- ============================================================================
-- Index usage: idx_faq_impact_change (on change_id column)
-- Query plan: Index seek on change_id, then sort by priority
-- Expected rows: 1-50 per change (typical)
-- Execution time: < 10ms for typical datasets
-- ============================================================================

-- ============================================================================
-- ACCEPTANCE CRITERIA (Item 81)
-- ============================================================================
-- [✓] Query includes all columns from faq_impact table
-- [✓] Supports filtering by applied status (0, 1, or all)
-- [✓] Parameterized for change_id (:change_id placeholder)
-- [✓] Ordered by priority DESC, impact_id ASC
-- [✓] Uses idx_faq_impact_change index for performance
-- ============================================================================
