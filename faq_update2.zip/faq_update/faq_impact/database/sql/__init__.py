"""
SQL Definitions - Schema and Queries

This module contains SQL schema definitions and parameterized queries
for the FAQ impact analysis module.

Submodules:
    schema/  - DDL statements for creating tables and indexes
    queries/ - DML statements for data operations

Design Principles:
    - SQL as Code: Version-controlled, testable SQL
    - Parameterized Queries: Safe from SQL injection
    - Named Queries: Reusable, discoverable query objects
    - Backend Agnostic: Compatible with SQLite and Databricks

Author: Analytics Assist Team
Date: 2025-11-02
"""

__all__ = []
