"""
Database Layer - Schema, Queries, and Repository

This module provides the database layer for FAQ impact analysis, following
the repository pattern for clean separation between business logic and
data access.

Architecture:
    Application Code (analysis, application modules)
         ↓
    Repository Layer (this module) ← Impact-specific database operations
         ↓
    Core Database Backend (faq_update.database) ← Shared infrastructure
         ↓
    Actual Database (SQLite, Databricks)

Submodules:
    sql/schema/    - SQL schema definitions for impact analysis tables
    sql/queries/   - Parameterized SQL queries for common operations
    repository/    - Repository classes with business logic

Design Patterns:
    - Repository Pattern: Business-focused data access API
    - Query Object: Reusable, tested SQL queries
    - Unit of Work: Transaction management

Schema Design:
    The impact analysis module extends the existing schema with:
    - impact_analysis_runs: Tracks each analysis execution
    - chunk_impact_cache: Caches chunk-to-question mappings
    - regeneration_queue: Tracks Q/A pairs pending regeneration

Example:
    >>> from faq_impact.database.repository import ImpactRepository
    >>> from database.backends.factory import BackendFactory
    >>>
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = ImpactRepository(backend)
    >>> impacts = repo.get_affected_questions(chunk_id=123)

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Imports will be added as components are implemented
__all__ = []
