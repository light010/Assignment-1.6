"""
Decision Repository - Simple CRUD for faq_impact_decisions table

This repository provides basic database operations for storing and retrieving
impact decisions. Decisions are POST-EXECUTION audit logs with real entity IDs.

Key Changes (2025-11-03):
- Removed pre-execution fields (executed, execution_status, etc.)
- All decisions are logged AFTER execution with real entity_ids
- Simplified schema for pure audit trail

Author: Analytics Assist Team
Date: 2025-11-03
"""

from typing import List, Optional, Dict, Any
from datetime import datetime

from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger

logger = get_logger(__name__)


class DecisionRepository:
    """Simple repository for faq_impact_decisions table"""

    def __init__(self, backend: IBackend):
        self.backend = backend

    def insert(self, decision: Dict[str, Any]) -> int:
        """
        Insert a POST-EXECUTION decision with real entity ID.

        Args:
            decision: Dict with keys:
                - change_id (required)
                - change_type (required)
                - entity_type (required)
                - entity_id (required) - MUST be real database ID
                - action (required)
                - reason_code (required)
                - content_checksum (optional)
                - source_count (optional)
                - similarity_score (optional)
                - impact_type (optional)
                - created_at (optional)

        Returns:
            decision_id of inserted record
        """
        query = """
            INSERT INTO faq_impact_decisions (
                change_id, change_type, entity_type, entity_id,
                action, reason_code,
                source_count, similarity_score, impact_type, content_checksum,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        params = (
            decision['change_id'],
            decision['change_type'],
            decision['entity_type'],
            decision['entity_id'],
            decision['action'],
            decision['reason_code'],
            decision.get('source_count'),
            decision.get('similarity_score'),
            decision.get('impact_type'),
            decision.get('content_checksum'),
            decision.get('created_at', datetime.now().isoformat())
        )

        self.backend.execute_update(query, params)

        # Get inserted ID
        id_rows = self.backend.execute_query("SELECT last_insert_rowid() as id")
        return id_rows[0]['id']

    def insert_batch(self, decisions: List[Dict[str, Any]]) -> List[int]:
        """Insert multiple decisions"""
        ids = []
        for decision in decisions:
            decision_id = self.insert(decision)
            ids.append(decision_id)
        return ids

    def get_by_change_id(self, change_id: int) -> List[Dict[str, Any]]:
        """
        Get all decisions for a change.

        Returns POST-EXECUTION audit trail showing what was actually done.
        """
        query = "SELECT * FROM faq_impact_decisions WHERE change_id = ? ORDER BY created_at"
        rows = self.backend.execute_query(query, (change_id,))
        return [dict(row) for row in rows]

    def get_by_entity(self, entity_type: str, entity_id: str) -> List[Dict[str, Any]]:
        """
        Get all decisions affecting a specific entity.

        Args:
            entity_type: 'question' or 'answer'
            entity_id: The entity's database ID

        Returns:
            List of decisions that affected this entity
        """
        query = """
            SELECT * FROM faq_impact_decisions
            WHERE entity_type = ? AND entity_id = ?
            ORDER BY created_at DESC
        """
        rows = self.backend.execute_query(query, (entity_type, entity_id))
        return [dict(row) for row in rows]

    def get_by_action(self, action: str) -> List[Dict[str, Any]]:
        """
        Get all decisions by action type.

        Args:
            action: 'CREATE', 'INACTIVATE', or 'REGENERATE'

        Returns:
            List of decisions with that action
        """
        query = "SELECT * FROM faq_impact_decisions WHERE action = ? ORDER BY created_at DESC"
        rows = self.backend.execute_query(query, (action,))
        return [dict(row) for row in rows]


__all__ = ['DecisionRepository']
