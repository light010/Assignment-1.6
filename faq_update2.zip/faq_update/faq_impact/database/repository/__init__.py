"""
Repository Layer - Impact Analysis Data Access

This module provides repository classes for FAQ impact analysis database
operations, following the repository pattern to separate business logic
from database implementation details.

Repositories:
    1. ImpactRepository
       - Core impact analysis operations
       - Get affected questions, check provenance, analyze impacts
       - Primary interface for impact analysis workflows

    2. RegenerationQueueRepository
       - Manage regeneration queue
       - Enqueue, dequeue, prioritize regeneration tasks
       - Track regeneration status and metrics

    3. CacheRepository
       - Manage chunk-to-question impact cache
       - Rebuild, invalidate, query cache
       - Optimize impact analysis performance

Architecture:
    Application Code (analysis, application services)
         ↓
    Repository Layer (this module) ← Clean, business-focused API
         ↓
    SQL Queries (sql/queries) ← Reusable, parameterized SQL
         ↓
    Backend Layer (faq_update.database) ← Database implementation
         ↓
    Actual Database (SQLite, Databricks)

Design Patterns:
    - Repository Pattern: Database operations as domain methods
    - Unit of Work: Transaction management
    - Query Object: Reusable SQL queries
    - Dependency Injection: Backend passed to constructor

Error Handling:
    Repositories raise domain-specific exceptions:
    - ImpactRepositoryError: Base exception
    - ChunkNotFoundError: Referenced chunk doesn't exist
    - QuestionNotFoundError: Referenced question doesn't exist
    - CacheInvalidError: Cache is stale or corrupted

Example:
    >>> from faq_impact.database.repository import ImpactRepository
    >>> from database.backends.factory import BackendFactory
    >>>
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = ImpactRepository(backend)
    >>>
    >>> # Get all questions affected by a chunk change
    >>> affected = repo.get_affected_questions(chunk_id=123)
    >>> for question_id in affected:
    ...     print(f"Question {question_id} needs review")

Author: Analytics Assist Team
Date: 2025-11-02
"""

# Import ImpactRepository (Items 91-100)
from .impact_repository import (
    ImpactRepository,
    ImpactRepositoryError,
    ImpactNotFoundError,
    DuplicateImpactError,
    ImpactValidationError,
    ImpactApplicationError,
)

# Import DecisionRepository (NEW - Analyze-Execute Architecture)
from .decision_repository import DecisionRepository

__all__ = [
    # Repositories
    "ImpactRepository",
    "DecisionRepository",

    # Exceptions
    "ImpactRepositoryError",
    "ImpactNotFoundError",
    "DuplicateImpactError",
    "ImpactValidationError",
    "ImpactApplicationError",
]
