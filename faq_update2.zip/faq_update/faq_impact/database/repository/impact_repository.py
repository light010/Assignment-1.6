"""
ImpactRepository - Database operations for impact analysis and application tracking

This module provides the ImpactRepository class for managing impact decisions and their
execution status. It follows the Repository Pattern to keep business logic separate from
database implementation.

Responsibilities:
    - Impact decision CRUD operations
    - Batch insertion of impact decisions
    - Querying impacts by change, run, entity
    - Tracking execution status (applied flag, timestamps, errors)
    - Preventing duplicate pending decisions
    - Cost estimation and priority management
    - Aggregated impact summaries

Design Principles:
    - Single Responsibility: Only impact decision operations
    - Database-Agnostic: Works with SQLite, Databricks, or any IBackend
    - Validation: Enforces business rules before database operations
    - Transaction Safety: Uses transactions for multi-step operations
    - Append-Only: Impact decisions are immutable once created

Tables Managed:
    - faq_impact: Impact decisions and execution tracking

Example Usage:
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>> from faq_impact.core.models import ImpactDecision
    >>> from faq_impact.core.enums import EntityType, DecisionType, ReasonCode
    >>>
    >>> # Create backend and repository
    >>> config = DatabaseConfig.from_env()
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = ImpactRepository(backend)
    >>>
    >>> # Insert impact decision
    >>> decision = ImpactDecision(
    ...     impact_id=0,
    ...     entity_type=EntityType.QUESTION,
    ...     entity_id='Q123',
    ...     change_id=12345,
    ...     detection_run_id='RUN_001',
    ...     decision=DecisionType.REGEN_Q,
    ...     reason=ReasonCode.SOLE_SOURCE_MODIFIED_MAJOR,
    ...     details={'similarity_score': 0.65},
    ...     created_at=datetime.now(),
    ...     applied=False,
    ...     applied_at=None,
    ...     applied_by=None,
    ...     application_error=None
    ... )
    >>> impact_id = repo.insert_impact(decision)
    >>> print(f"Created impact decision: {impact_id}")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import json

# Import base repository and exceptions
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from faq_update.database.repository.base import (
    BaseRepository,
    RepositoryError,
    QueryError,
    DataValidationError,
    TransactionError,
)
from faq_update.database.backends.base import IBackend
from faq_update.utility.logging import get_logger

# Import impact-specific models
from faq_impact.core.models.impact_decision import ImpactDecision, ImpactSummary
from faq_impact.core.enums.entity_type import EntityType
from faq_impact.core.enums.decision_type import DecisionType
from faq_impact.core.enums.reason_code import ReasonCode

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Impact Repository Exceptions
# =============================================================================


class ImpactRepositoryError(RepositoryError):
    """Base exception for Impact repository errors."""
    pass


class ImpactNotFoundError(ImpactRepositoryError):
    """Raised when impact decision cannot be found."""
    pass


class DuplicateImpactError(ImpactRepositoryError):
    """Raised when attempting to insert duplicate pending impact decision."""
    pass


class ImpactValidationError(ImpactRepositoryError):
    """Raised when impact decision validation fails."""
    pass


class ImpactApplicationError(ImpactRepositoryError):
    """Raised when impact application (execution) fails."""
    pass


# =============================================================================
# Impact Repository Implementation
# =============================================================================


class ImpactRepository(BaseRepository[ImpactDecision]):
    """
    Repository for impact decisions and execution tracking.

    Provides database-agnostic operations for:
    - Impact decision creation and retrieval
    - Batch insertion of decisions
    - Filtering by change, run, entity
    - Execution status tracking (applied flag, timestamps, errors)
    - Duplicate prevention for pending decisions
    - Aggregated summaries and cost estimation

    All methods handle both SQLite and Databricks transparently via IBackend interface.

    Attributes:
        backend: Database backend instance (IBackend)
        logger: Logger instance for this repository

    Example:
        >>> repo = ImpactRepository(backend)
        >>>
        >>> # Insert impact decision
        >>> impact_id = repo.insert_impact(decision)
        >>>
        >>> # Get impacts for a change
        >>> impacts = repo.get_impacts_by_change(change_id=12345)
        >>>
        >>> # Mark impact as applied
        >>> repo.mark_applied(impact_id=456, applied_by='user123')
    """

    def __init__(self, backend: IBackend, **kwargs):
        """
        Initialize ImpactRepository.

        Args:
            backend: Database backend (SQLite, Databricks, etc.)
            **kwargs: Additional arguments passed to BaseRepository

        Example:
            >>> from database.backends.sqlite import SQLiteBackend
            >>> backend = SQLiteBackend(db_path="faq_impact.db")
            >>> repo = ImpactRepository(backend)
        """
        super().__init__(backend, **kwargs)
        self._logger = get_logger(f"{self.__class__.__name__}")

    # =========================================================================
    # Item 99: Error Handling and Retries
    # =========================================================================

    def _handle_impact_error(
        self,
        error: Exception,
        operation: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Exception:
        """
        Handle impact-specific errors with contextual logging.

        Point 99 in implementation plan - Enhanced error handling.

        Args:
            error: Original exception
            operation: Description of operation that failed
            context: Optional context dictionary (e.g., impact_id, change_id)

        Returns:
            Wrapped impact-specific exception

        Example:
            >>> try:
            ...     self.execute_query(...)
            ... except Exception as e:
            ...     raise self._handle_impact_error(
            ...         e, "insert impact", {"change_id": 12345}
            ...     )
        """
        # Build context string for logging
        context_str = ""
        if context:
            context_str = ", ".join([f"{k}={v}" for k, v in context.items()])

        # Log with full context
        self._logger.error(
            f"Impact repository error during {operation}: {error}",
            extra={"context": context, "operation": operation},
            exc_info=True
        )

        # Map to appropriate exception type
        error_msg = str(error).lower()

        # Duplicate detection
        if 'unique' in error_msg or 'duplicate' in error_msg:
            return DuplicateImpactError(
                f"Duplicate impact detected during {operation}"
                f"{' (' + context_str + ')' if context_str else ''}: {error}"
            )

        # Not found errors
        if 'not found' in error_msg or 'no rows' in error_msg:
            return ImpactNotFoundError(
                f"Impact not found during {operation}"
                f"{' (' + context_str + ')' if context_str else ''}: {error}"
            )

        # Validation errors
        if 'validation' in error_msg or 'invalid' in error_msg:
            return ImpactValidationError(
                f"Validation failed during {operation}"
                f"{' (' + context_str + ')' if context_str else ''}: {error}"
            )

        # Application/execution errors
        if 'application' in error_msg or 'execution' in error_msg:
            return ImpactApplicationError(
                f"Application failed during {operation}"
                f"{' (' + context_str + ')' if context_str else ''}: {error}"
            )

        # Generic impact error
        return ImpactRepositoryError(
            f"Impact repository error during {operation}"
            f"{' (' + context_str + ')' if context_str else ''}: {error}"
        )

    # =========================================================================
    # Item 92: Insert Impact Decision
    # =========================================================================

    def insert_impact(self, decision: ImpactDecision) -> int:
        """
        Insert single impact decision and return impact_id.

        Point 92 in implementation plan.

        Args:
            decision: ImpactDecision dataclass instance

        Returns:
            impact_id of inserted record

        Raises:
            ImpactValidationError: If decision validation fails
            DuplicateImpactError: If duplicate pending decision exists
            QueryError: If insert fails

        Example:
            >>> decision = ImpactDecision(...)
            >>> impact_id = repo.insert_impact(decision)
            >>> print(f"Created impact: {impact_id}")
        """
        self._logger.info(
            f"Inserting impact decision: {decision.decision.value} for "
            f"{decision.entity_type.value}={decision.entity_id}"
        )

        # Validate decision using dataclass validation
        try:
            decision.validate_decision_reason_compatibility()
            decision.validate_entity_reference()
            decision.validate_details_schema()
        except ValueError as e:
            raise ImpactValidationError(f"Decision validation failed: {e}") from e

        # Convert dataclass to dict for insertion
        decision_dict = decision.to_dict()

        # Build INSERT command
        # Note: impact_id is auto-increment, so we don't include it
        columns = [
            'entity_type', 'entity_id', 'change_id', 'detection_run_id',
            'decision', 'reason', 'details',
            'applied', 'applied_at', 'applied_by', 'application_error',
            'created_at', 'estimated_cost', 'priority'
        ]

        # Filter to only include columns that exist in decision_dict
        values = []
        included_columns = []
        for col in columns:
            if col in decision_dict:
                included_columns.append(col)
                values.append(decision_dict[col])

        placeholders = ','.join(['?' for _ in included_columns])
        columns_str = ','.join(included_columns)

        command = f"""
            INSERT INTO faq_impact ({columns_str})
            VALUES ({placeholders})
        """

        try:
            with self.transaction():
                impact_id = self.execute_insert(command, tuple(values))

            self._logger.info(
                f"Successfully inserted impact decision: impact_id={impact_id}"
            )
            return impact_id

        except Exception as e:
            error_msg = str(e).lower()
            # Check for unique constraint violation (duplicate pending decision)
            if 'unique' in error_msg or 'duplicate' in error_msg:
                raise DuplicateImpactError(
                    f"Duplicate pending impact decision: {decision.entity_type.value} "
                    f"{decision.entity_id}, change_id={decision.change_id}, "
                    f"decision={decision.decision.value}"
                ) from e

            self._logger.error(f"Failed to insert impact decision: {e}")
            raise QueryError(f"Impact decision insertion failed: {e}") from e

    # =========================================================================
    # Item 93: Batch Insert Impact Decisions
    # =========================================================================

    def insert_impacts_batch(self, decisions: List[ImpactDecision]) -> List[int]:
        """
        Batch insert impact decisions with transaction support.

        Point 93 in implementation plan.

        Args:
            decisions: List of ImpactDecision dataclass instances

        Returns:
            List of impact_ids of inserted records (in same order as input)

        Raises:
            ImpactValidationError: If any decision validation fails
            DuplicateImpactError: If any duplicate pending decision exists
            TransactionError: If transaction fails
            QueryError: If insert fails

        Example:
            >>> decisions = [decision1, decision2, decision3]
            >>> impact_ids = repo.insert_impacts_batch(decisions)
            >>> print(f"Created {len(impact_ids)} impact decisions")
        """
        if not decisions:
            raise ValueError("Cannot insert empty list of decisions")

        self._logger.info(f"Batch inserting {len(decisions)} impact decisions")

        # Validate all decisions first
        for i, decision in enumerate(decisions):
            try:
                decision.validate_decision_reason_compatibility()
                decision.validate_entity_reference()
                decision.validate_details_schema()
            except ValueError as e:
                raise ImpactValidationError(
                    f"Decision #{i} validation failed: {e}"
                ) from e

        impact_ids = []

        try:
            with self.transaction():
                for decision in decisions:
                    impact_id = self.insert_impact(decision)
                    impact_ids.append(impact_id)

            self._logger.info(
                f"Successfully batch inserted {len(impact_ids)} impact decisions"
            )
            return impact_ids

        except Exception as e:
            self._logger.error(
                f"Batch insert failed after {len(impact_ids)} successful inserts: {e}"
            )
            raise TransactionError(
                f"Batch insert failed (rolled back): {e}"
            ) from e

    # =========================================================================
    # Item 94: Get Impacts by Change
    # =========================================================================

    def get_impacts_by_change(
        self,
        change_id: int,
        applied: Optional[bool] = None
    ) -> List[ImpactDecision]:
        """
        Get all impact decisions for a specific change_id.

        Point 94 in implementation plan.

        Args:
            change_id: Content change ID
            applied: Optional filter by applied status (True/False/None for all)

        Returns:
            List of ImpactDecision dataclass instances

        Raises:
            QueryError: If query execution fails
            ValueError: If change_id is invalid

        Example:
            >>> # Get all impacts for change
            >>> impacts = repo.get_impacts_by_change(change_id=12345)
            >>>
            >>> # Get only pending impacts
            >>> pending = repo.get_impacts_by_change(change_id=12345, applied=False)
            >>>
            >>> # Get only applied impacts
            >>> applied = repo.get_impacts_by_change(change_id=12345, applied=True)
        """
        if change_id is None or change_id <= 0:
            raise ValueError(f"Invalid change_id: {change_id}")

        self._logger.debug(
            f"Retrieving impacts for change_id={change_id}, applied={applied}"
        )

        try:
            # Build query - use SQL template
            query = """
                SELECT
                    impact_id, entity_type, entity_id, change_id, detection_run_id,
                    decision, reason, details,
                    applied, applied_at, applied_by, application_error,
                    estimated_cost, priority, created_at, modified_at
                FROM faq_impact
                WHERE change_id = ?
            """

            params = [change_id]

            # Add applied filter if specified
            if applied is not None:
                query += " AND applied = ?"
                params.append(1 if applied else 0)

            # Order by priority DESC, impact_id ASC (deterministic)
            query += " ORDER BY priority DESC, impact_id ASC"

            results = self.execute_query(query, tuple(params))

            # Map results to ImpactDecision dataclass
            impacts = [ImpactDecision.from_dict(row) for row in results]

            self._logger.debug(
                f"Found {len(impacts)} impacts for change_id={change_id}"
            )
            return impacts

        except Exception as e:
            self._logger.error(
                f"Failed to get impacts for change_id={change_id}: {e}"
            )
            raise QueryError(
                f"Failed to retrieve impacts for change: {e}"
            ) from e

    # =========================================================================
    # Item 95: Get Impacts by Run
    # =========================================================================

    def get_impacts_by_run(
        self,
        detection_run_id: str
    ) -> List[ImpactDecision]:
        """
        Get all impact decisions for a detection run.

        Point 95 in implementation plan.

        Args:
            detection_run_id: Detection run ID (e.g., 'RUN_20251102_143000')

        Returns:
            List of ImpactDecision dataclass instances

        Raises:
            QueryError: If query execution fails
            ValueError: If detection_run_id is invalid

        Example:
            >>> impacts = repo.get_impacts_by_run('RUN_20251102_143000')
            >>> print(f"Found {len(impacts)} impacts in this run")
        """
        if not detection_run_id or not detection_run_id.strip():
            raise ValueError("detection_run_id cannot be empty")

        self._logger.debug(
            f"Retrieving impacts for detection_run_id={detection_run_id}"
        )

        try:
            query = """
                SELECT
                    impact_id, entity_type, entity_id, change_id, detection_run_id,
                    decision, reason, details,
                    applied, applied_at, applied_by, application_error,
                    estimated_cost, priority, created_at, modified_at
                FROM faq_impact
                WHERE detection_run_id = ?
                ORDER BY created_at DESC, impact_id ASC
            """

            results = self.execute_query(query, (detection_run_id,))

            # Map results to ImpactDecision dataclass
            impacts = [ImpactDecision.from_dict(row) for row in results]

            self._logger.debug(
                f"Found {len(impacts)} impacts for run {detection_run_id}"
            )
            return impacts

        except Exception as e:
            self._logger.error(
                f"Failed to get impacts for run {detection_run_id}: {e}"
            )
            raise QueryError(
                f"Failed to retrieve impacts for detection run: {e}"
            ) from e

    # =========================================================================
    # Item 96: Get Pending Applications
    # =========================================================================

    def get_pending_applications(
        self,
        limit: Optional[int] = None
    ) -> List[ImpactDecision]:
        """
        Get all pending impact decisions (applied=0).

        Point 96 in implementation plan.

        Returns decisions ordered by change_id and priority for batch processing.

        Args:
            limit: Optional maximum number of results

        Returns:
            List of ImpactDecision dataclass instances

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all pending impacts
            >>> pending = repo.get_pending_applications()
            >>>
            >>> # Get top 100 pending impacts
            >>> batch = repo.get_pending_applications(limit=100)
        """
        self._logger.debug(f"Retrieving pending applications (limit={limit})")

        try:
            query = """
                SELECT
                    impact_id, entity_type, entity_id, change_id, detection_run_id,
                    decision, reason, details,
                    applied, applied_at, applied_by, application_error,
                    estimated_cost, priority, created_at, modified_at
                FROM faq_impact
                WHERE applied = 0
                ORDER BY change_id ASC, priority DESC, impact_id ASC
            """

            # Add LIMIT if specified
            if limit is not None and limit > 0:
                query += f" LIMIT {limit}"

            results = self.execute_query(query)

            # Map results to ImpactDecision dataclass
            impacts = [ImpactDecision.from_dict(row) for row in results]

            self._logger.debug(f"Found {len(impacts)} pending applications")
            return impacts

        except Exception as e:
            self._logger.error(f"Failed to get pending applications: {e}")
            raise QueryError(
                f"Failed to retrieve pending applications: {e}"
            ) from e

    # =========================================================================
    # Item 97: Mark Applied
    # =========================================================================

    def mark_applied(
        self,
        impact_id: int,
        applied_by: str,
        application_error: Optional[str] = None
    ) -> None:
        """
        Mark impact decision as applied (executed).

        Point 97 in implementation plan.

        Sets applied=1, applied_at=now, applied_by, and optionally application_error.

        Args:
            impact_id: Impact decision ID
            applied_by: Who/what executed the decision (username, 'system', etc.)
            application_error: Optional error message if execution failed

        Raises:
            ImpactNotFoundError: If impact_id not found
            QueryError: If update fails
            ValueError: If impact_id is invalid or applied_by is empty

        Example:
            >>> # Mark as successfully applied
            >>> repo.mark_applied(impact_id=456, applied_by='user123')
            >>>
            >>> # Mark with error
            >>> repo.mark_applied(
            ...     impact_id=789,
            ...     applied_by='system',
            ...     application_error='LLM API timeout'
            ... )
        """
        if impact_id is None or impact_id <= 0:
            raise ValueError(f"Invalid impact_id: {impact_id}")

        if not applied_by or not applied_by.strip():
            raise ValueError("applied_by cannot be empty")

        self._logger.info(
            f"Marking impact {impact_id} as applied by {applied_by}"
        )

        try:
            # First check if impact exists
            check_query = "SELECT impact_id FROM faq_impact WHERE impact_id = ?"
            result = self.execute_query_single(check_query, (impact_id,))

            if not result:
                raise ImpactNotFoundError(
                    f"Impact decision with ID {impact_id} not found"
                )

            # Update applied status
            command = """
                UPDATE faq_impact
                SET applied = 1,
                    applied_at = ?,
                    applied_by = ?,
                    application_error = ?,
                    modified_at = ?
                WHERE impact_id = ?
            """

            now = datetime.now()
            params = (
                now.isoformat(),
                applied_by,
                application_error,
                now.isoformat(),
                impact_id
            )

            with self.transaction():
                rows_updated = self.execute_command(command, params)

            if rows_updated == 0:
                raise ImpactNotFoundError(
                    f"Impact decision with ID {impact_id} not found"
                )

            self._logger.info(
                f"Successfully marked impact {impact_id} as applied"
            )

        except ImpactNotFoundError:
            raise
        except Exception as e:
            self._logger.error(
                f"Failed to mark impact {impact_id} as applied: {e}"
            )
            raise QueryError(
                f"Failed to update impact execution status: {e}"
            ) from e

    # =========================================================================
    # Item 98: Get Impact Summary
    # =========================================================================

    def get_impact_summary(
        self,
        detection_run_id: Optional[str] = None
    ) -> ImpactSummary:
        """
        Get aggregated metrics for impact decisions.

        Point 98 in implementation plan.

        Returns ImpactSummary with counts by decision type, reason, entity type,
        and estimated cost.

        Args:
            detection_run_id: Optional filter by detection run ID

        Returns:
            ImpactSummary dataclass instance

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get summary for all impacts
            >>> summary = repo.get_impact_summary()
            >>> print(f"Total impacts: {summary.total_impacts}")
            >>> print(f"By decision: {summary.decisions_by_type}")
            >>>
            >>> # Get summary for specific run
            >>> run_summary = repo.get_impact_summary('RUN_20251102_143000')
        """
        self._logger.debug(
            f"Calculating impact summary (run={detection_run_id})"
        )

        try:
            # Build WHERE clause for optional run filter
            where_clause = ""
            params = ()
            if detection_run_id:
                where_clause = "WHERE detection_run_id = ?"
                params = (detection_run_id,)

            # Query 1: Count by decision type
            query_by_decision = f"""
                SELECT decision, COUNT(*) as count
                FROM faq_impact
                {where_clause}
                GROUP BY decision
            """
            decision_results = self.execute_query(query_by_decision, params)
            decisions_by_type = {
                row['decision']: row['count']
                for row in decision_results
            }

            # Query 2: Count by reason
            query_by_reason = f"""
                SELECT reason, COUNT(*) as count
                FROM faq_impact
                {where_clause}
                GROUP BY reason
            """
            reason_results = self.execute_query(query_by_reason, params)
            decisions_by_reason = {
                row['reason']: row['count']
                for row in reason_results
            }

            # Query 3: Count by entity type
            query_by_entity = f"""
                SELECT entity_type, COUNT(*) as count
                FROM faq_impact
                {where_clause}
                GROUP BY entity_type
            """
            entity_results = self.execute_query(query_by_entity, params)
            entities_affected = {
                row['entity_type']: row['count']
                for row in entity_results
            }

            # Query 4: Total count and estimated cost
            query_totals = f"""
                SELECT
                    COUNT(*) as total_count,
                    SUM(estimated_cost) as total_cost
                FROM faq_impact
                {where_clause}
            """
            totals = self.execute_query_single(query_totals, params)
            total_impacts = totals['total_count'] if totals else 0
            estimated_cost = totals['total_cost'] if totals else 0.0

            # Build ImpactSummary
            summary = ImpactSummary(
                total_impacts=total_impacts,
                decisions_by_type=decisions_by_type,
                decisions_by_reason=decisions_by_reason,
                entities_affected=entities_affected,
                estimated_cost=estimated_cost if estimated_cost else 0.0
            )

            self._logger.debug(
                f"Impact summary: {summary.total_impacts} total, "
                f"${summary.estimated_cost:.2f} estimated cost"
            )
            return summary

        except Exception as e:
            self._logger.error(f"Failed to calculate impact summary: {e}")
            raise QueryError(
                f"Failed to get impact summary: {e}"
            ) from e


__all__ = [
    # Main class
    "ImpactRepository",

    # Exceptions
    "ImpactRepositoryError",
    "ImpactNotFoundError",
    "DuplicateImpactError",
    "ImpactValidationError",
    "ImpactApplicationError",
]
