"""
Configuration module for FAQ Update system.

Provides centralized constants and configuration that must be consistent
across the entire pipeline.
"""

from config.constants import (
    CHECKSUM_ALGORITHM,
    CHECKSUM_DISPLAY_LENGTH,
    DEFAULT_CHUNK_SIZE,
    DEFAULT_SIMILARITY_THRESHOLD,
    DEFAULT_COMPUTE_LLM_DIFFS,
    DEFAULT_DIFF_CONTEXT_LINES,
    validate_constants,
)

__all__ = [
    "CHECKSUM_ALGORITHM",
    "CHECKSUM_DISPLAY_LENGTH",
    "DEFAULT_CHUNK_SIZE",
    "DEFAULT_SIMILARITY_THRESHOLD",
    "DEFAULT_COMPUTE_LLM_DIFFS",
    "DEFAULT_DIFF_CONTEXT_LINES",
    "validate_constants",
]
