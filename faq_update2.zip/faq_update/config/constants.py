"""
Central Configuration Constants

This module defines system-wide constants that MUST be consistent across the entire pipeline.
DO NOT modify these values unless you understand the full impact.

Key Principle: These constants ensure consistency across:
- Chunking (SimpleChunker)
- Change Detection (ContentChangeDetector)
- Checksum Extraction (ChecksumExtractor)
- Notebooks (2_chunk_table_ingestion.ipynb, 7_change_detection_unified.ipynb)
"""

# =============================================================================
# CHECKSUM CONFIGURATION
# =============================================================================

# CRITICAL: This MUST be consistent across entire pipeline
# Changing this will invalidate ALL existing checksums in database!
CHECKSUM_ALGORITHM = "sha256"

# Checksum display length for logs (number of characters to show)
CHECKSUM_DISPLAY_LENGTH = 8

# =============================================================================
# CHUNKING CONFIGURATION
# =============================================================================

# Default chunk size in characters (~750 tokens for FAQ/technical docs)
# Based on 2025 RAG best practices for optimal retrieval + context balance
#
# Research shows:
# - 512-1024 tokens optimal for technical documentation (FAQs, APIs, guides)
# - Modern embedding models support up to 8K tokens
# - GPT-4/Claude 3.5 have 100K+ context windows
#
# 3000 chars ≈ 750 tokens - Sweet spot for:
# ✅ Full concept/example capture
# ✅ Better semantic coherence
# ✅ Cost efficiency (fewer embeddings)
# ✅ Modern LLM compatibility
DEFAULT_CHUNK_SIZE = 3000

# Default chunk overlap in characters (20% of chunk_size)
# Ensures context continuity across chunk boundaries
DEFAULT_CHUNK_OVERLAP = 600

# =============================================================================
# CHANGE DETECTION CONFIGURATION
# =============================================================================

# Default similarity threshold for modification detection (0.0 - 1.0)
# Higher = more strict (only very similar content classified as MODIFIED)
# Lower = more permissive (more content classified as MODIFIED)
DEFAULT_SIMILARITY_THRESHOLD = 0.8

# Whether to compute LLM-friendly diffs by default
DEFAULT_COMPUTE_LLM_DIFFS = True

# Number of context lines in diffs
DEFAULT_DIFF_CONTEXT_LINES = 1

# =============================================================================
# VALIDATION
# =============================================================================

def validate_constants():
    """
    Validate that all constants are correctly configured.

    Raises:
        ValueError: If any constant is invalid
    """
    # Validate checksum algorithm
    valid_algorithms = ["sha256", "sha512", "sha1", "md5"]
    if CHECKSUM_ALGORITHM not in valid_algorithms:
        raise ValueError(
            f"CHECKSUM_ALGORITHM must be one of {valid_algorithms}, "
            f"got {CHECKSUM_ALGORITHM}"
        )

    # Validate similarity threshold
    if not (0.0 <= DEFAULT_SIMILARITY_THRESHOLD <= 1.0):
        raise ValueError(
            f"DEFAULT_SIMILARITY_THRESHOLD must be between 0.0 and 1.0, "
            f"got {DEFAULT_SIMILARITY_THRESHOLD}"
        )

    # Validate chunk size
    if DEFAULT_CHUNK_SIZE <= 0:
        raise ValueError(
            f"DEFAULT_CHUNK_SIZE must be positive, got {DEFAULT_CHUNK_SIZE}"
        )


# Run validation on import
validate_constants()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "CHECKSUM_ALGORITHM",
    "CHECKSUM_DISPLAY_LENGTH",
    "DEFAULT_CHUNK_SIZE",
    "DEFAULT_CHUNK_OVERLAP",
    "DEFAULT_SIMILARITY_THRESHOLD",
    "DEFAULT_COMPUTE_LLM_DIFFS",
    "DEFAULT_DIFF_CONTEXT_LINES",
    "validate_constants",
]
