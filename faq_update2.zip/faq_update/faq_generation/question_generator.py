"""
FAQ Question Generator

This module provides the QuestionGenerator class for generating FAQ questions from
content chunks using LLM (Large Language Models). It orchestrates the question
generation process and handles document transformation.

Architecture:
- QuestionGenerator: Main class for question generation
- Uses oneailib for LLM integration (Azure OpenAI)
- Supports both batch processing (Documents) and single chunk processing
- Integrates with prompts and schemas modules

Design Principles:
- Single Responsibility: Only question generation logic
- Dependency Injection: LLM models injected or created internally
- Configurability: All parameters configurable via constructor
- Error Handling: Comprehensive error handling and retry logic
- Logging: Detailed logging for debugging and monitoring

Tables/Data Models:
- Input: oneailib.Document objects or raw text
- Output: Documents with metadata or dicts with question data

Example Usage:
    >>> # Batch processing (for notebook 3)
    >>> from faq_generation import QuestionGenerator
    >>> from oneailib.document_loaders.sql import SQLLoader
    >>>
    >>> gen = QuestionGenerator(
    ...     chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
    ...     temperature=0.0,
    ...     max_questions=5
    ... )
    >>> documents = sql_loader.load()
    >>> questions_docs = gen.generate_from_documents(documents)
    >>>
    >>> # Single chunk processing (for notebook 8)
    >>> questions = gen.generate_from_text(
    ...     chunk_text="Health insurance enrollment...",
    ...     content_checksum="abc123def456"
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import List, Dict, Any, Optional
from oneailib.core.documents.base import Document
from oneailib.chat_models.azure_openai import AzureOpenAIChatModel
from oneailib.document_transformers.metadata_transformers import (
    DecomposeKeysTransformer,
    AddDocumentIDTransformer,
    AddDocumentVersionTransformer,
)
from utility.logging import get_logger

from faq_generation.prompts import FAQ_QUESTION_GENERATION_PROMPT
from faq_generation.schemas import FAQ_QUESTION_GENERATION_SCHEMA

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Question Generator Exceptions
# =============================================================================


class QuestionGeneratorError(Exception):
    """Base exception for question generator errors."""
    pass


class LLMGenerationError(QuestionGeneratorError):
    """Raised when LLM generation fails."""
    pass


class DocumentTransformationError(QuestionGeneratorError):
    """Raised when document transformation fails."""
    pass


# =============================================================================
# Question Generator
# =============================================================================


class QuestionGenerator:
    """
    Generates FAQ questions from content chunks using LLM.

    This class orchestrates the question generation process:
    1. Accepts content (Documents or text)
    2. Calls LLM to generate questions
    3. Decomposes structured output into individual questions
    4. Adds metadata (IDs, versions)
    5. Returns processed data

    Attributes:
        chat_model_name: Azure OpenAI model name (e.g., "gpt-4o_2024-11-20-pgo-amrs")
        temperature: LLM temperature (0.0 = deterministic, 1.0 = creative)
        max_tokens: Maximum tokens for LLM response
        max_retries: Number of retries on LLM failure
        seconds_between_retries: Delay between retries
        max_questions: Maximum questions to generate per chunk

    Example:
        >>> gen = QuestionGenerator(
        ...     chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
        ...     temperature=0.0,
        ...     max_questions=5
        ... )
        >>> questions = gen.generate_from_text("Content here...")
    """

    def __init__(
        self,
        chat_model_name: str = "gpt-4o_2024-11-20-pgo-amrs",
        temperature: float = 0.0,
        max_tokens: int = 4000,
        max_retries: int = 10,
        seconds_between_retries: int = 5,
        max_questions: int = 5,
    ):
        """
        Initialize QuestionGenerator with configuration.

        Args:
            chat_model_name: Azure OpenAI engine name
            temperature: LLM temperature (0.0-1.0)
            max_tokens: Maximum tokens in LLM response
            max_retries: Number of retry attempts on failure
            seconds_between_retries: Delay between retries (seconds)
            max_questions: Maximum questions per chunk

        Raises:
            ValueError: If invalid parameter values provided
        """
        # Validate parameters
        if not 0.0 <= temperature <= 1.0:
            raise ValueError(f"temperature must be between 0.0 and 1.0, got {temperature}")
        if max_tokens <= 0:
            raise ValueError(f"max_tokens must be positive, got {max_tokens}")
        if max_retries < 0:
            raise ValueError(f"max_retries must be non-negative, got {max_retries}")
        if max_questions <= 0:
            raise ValueError(f"max_questions must be positive, got {max_questions}")

        self.chat_model_name = chat_model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        self.seconds_between_retries = seconds_between_retries
        self.max_questions = max_questions

        # Initialize LLM model
        self._question_generator_model = None
        self._question_decomposer = None
        self._id_transformer = None
        self._version_transformer = None

        logger.debug(
            f"QuestionGenerator initialized with model={chat_model_name}, "
            f"temperature={temperature}, max_questions={max_questions}"
        )

    def _get_question_generator_model(self) -> AzureOpenAIChatModel:
        """
        Get or create the LLM model for question generation (lazy initialization).

        Returns:
            Configured AzureOpenAIChatModel instance
        """
        if self._question_generator_model is None:
            logger.info(f"Initializing Azure OpenAI model: {self.chat_model_name}")
            self._question_generator_model = AzureOpenAIChatModel(
                engine_name=self.chat_model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                max_retries=self.max_retries,
                seconds_between_retries=self.seconds_between_retries,
                prompt=FAQ_QUESTION_GENERATION_PROMPT,
                function_calling=FAQ_QUESTION_GENERATION_SCHEMA,
            )
        return self._question_generator_model

    def _get_question_decomposer(self) -> DecomposeKeysTransformer:
        """
        Get or create the document decomposer (lazy initialization).

        Returns:
            Configured DecomposeKeysTransformer instance
        """
        if self._question_decomposer is None:
            logger.debug("Initializing question decomposer")
            self._question_decomposer = DecomposeKeysTransformer(
                keys_to_decompose={"questions_for_single_cluster": ["question"]}
            )
        return self._question_decomposer

    def _get_id_transformer(self) -> AddDocumentIDTransformer:
        """
        Get or create the ID transformer (lazy initialization).

        Returns:
            AddDocumentIDTransformer instance
        """
        if self._id_transformer is None:
            logger.debug("Initializing ID transformer")
            self._id_transformer = AddDocumentIDTransformer()
        return self._id_transformer

    def _get_version_transformer(self) -> AddDocumentVersionTransformer:
        """
        Get or create the version transformer (lazy initialization).

        Returns:
            AddDocumentVersionTransformer instance
        """
        if self._version_transformer is None:
            logger.debug("Initializing version transformer")
            self._version_transformer = AddDocumentVersionTransformer()
        return self._version_transformer

    def generate_from_documents(
        self,
        documents: List[Document],
        add_ids: bool = True,
        add_versions: bool = True,
    ) -> List[Document]:
        """
        Generate questions from a list of Documents (batch processing).

        This method is designed for notebook 3's batch processing workflow:
        1. Generate questions from documents using LLM
        2. Decompose structured output into individual question documents
        3. Add document IDs and versions
        4. Return processed documents

        Args:
            documents: List of Document objects with content
            add_ids: Whether to add document IDs
            add_versions: Whether to add document versions

        Returns:
            List of Document objects with question metadata

        Raises:
            LLMGenerationError: If LLM generation fails
            DocumentTransformationError: If document transformation fails

        Example:
            >>> from oneailib.document_loaders.sql import SQLLoader
            >>> loader = SQLLoader(query="SELECT * FROM content_chunks", ...)
            >>> documents = loader.load()
            >>> gen = QuestionGenerator()
            >>> question_docs = gen.generate_from_documents(documents)
            >>> print(len(question_docs))
            150
        """
        logger.info(f"Generating questions from {len(documents)} documents")

        try:
            # Step 1: Generate questions using LLM
            model = self._get_question_generator_model()
            logger.debug("Calling LLM for question generation")
            question_generated_docs = model(documents)
            logger.info(f"LLM generated {len(question_generated_docs)} question documents")

            # Step 2: Decompose questions
            decomposer = self._get_question_decomposer()
            logger.debug("Decomposing question documents")
            decomposed_docs = decomposer.transform_documents(question_generated_docs)
            logger.info(f"Decomposed into {len(decomposed_docs)} individual questions")

            # Step 3: Add document IDs (optional)
            if add_ids:
                id_transformer = self._get_id_transformer()
                logger.debug("Adding document IDs")
                decomposed_docs = id_transformer.transform_documents(decomposed_docs)

            # Step 4: Add document versions (optional)
            if add_versions:
                version_transformer = self._get_version_transformer()
                logger.debug("Adding document versions")
                decomposed_docs = version_transformer.transform_documents(decomposed_docs)

            logger.info(f"Successfully generated {len(decomposed_docs)} questions")
            return decomposed_docs

        except Exception as e:
            logger.error(f"Failed to generate questions from documents: {e}")
            raise LLMGenerationError(f"Question generation failed: {e}") from e

    def generate_from_text(
        self,
        chunk_text: str,
        content_checksum: str,
        source_type: str = "document",
        generation_method: str = "LLM",
        status: str = "active",
    ) -> List[Dict[str, Any]]:
        """
        Generate questions from a single text chunk (single chunk processing).

        This method is designed for notebook 8's pipeline workflow where we need
        to generate questions for individual chunks in response to content changes.

        Args:
            chunk_text: Text content to generate questions from
            content_checksum: Checksum of the content chunk (for provenance)
            source_type: Type of source ("document", "user_query", etc.)
            generation_method: How questions were generated ("LLM", "manual", etc.)
            status: Question status ("active", "inactive")

        Returns:
            List of dicts with question data ready for database insertion:
            [
                {
                    'question_id': str,  # Generated question ID
                    'question_text': str,  # The generated question
                    'source_type': str,  # "document"
                    'generation_method': str,  # "LLM"
                    'status': str,  # "active"
                    'content_checksum': str,  # For provenance linking
                },
                ...
            ]

        Raises:
            LLMGenerationError: If LLM generation fails
            ValueError: If chunk_text is empty

        Example:
            >>> gen = QuestionGenerator()
            >>> questions = gen.generate_from_text(
            ...     chunk_text="Health insurance enrollment period...",
            ...     content_checksum="abc123def456"
            ... )
            >>> print(questions[0]['question_text'])
            'When does the health insurance enrollment period start?'
        """
        if not chunk_text or not chunk_text.strip():
            raise ValueError("chunk_text cannot be empty")

        if not content_checksum:
            raise ValueError("content_checksum cannot be empty")

        logger.info(f"Generating questions for checksum {content_checksum[:8]}...")

        try:
            # Step 1: Create a Document from the text
            doc = Document(
                page_content=chunk_text,
                metadata={
                    "content_checksum": content_checksum,
                }
            )

            # Step 2: Generate questions using the document-based method
            question_docs = self.generate_from_documents(
                documents=[doc],
                add_ids=True,
                add_versions=True,
            )

            # Step 3: Transform to dict format for database insertion
            questions = []
            for q_doc in question_docs:
                question_data = {
                    'question_id': q_doc.metadata.get('id'),
                    'question_text': q_doc.metadata.get('question', ''),
                    'source_type': source_type,
                    'generation_method': generation_method,
                    'status': status,
                    'content_checksum': content_checksum,
                }
                questions.append(question_data)

            logger.info(f"Generated {len(questions)} questions for checksum {content_checksum[:8]}")
            return questions

        except Exception as e:
            logger.error(f"Failed to generate questions from text: {e}")
            raise LLMGenerationError(f"Question generation failed: {e}") from e

    def get_question_documents_as_dataframe(
        self,
        documents: List[Document]
    ):
        """
        Convert question documents to a pandas DataFrame (for notebook 3).

        This is a utility method to help with the transition from documents
        to database-ready format.

        Args:
            documents: List of question documents with metadata

        Returns:
            pandas DataFrame with question data

        Example:
            >>> question_docs = gen.generate_from_documents(chunks)
            >>> df = gen.get_question_documents_as_dataframe(question_docs)
            >>> df.to_csv('questions.csv', index=False)
        """
        import pandas as pd

        question_data = []
        for doc in documents:
            question_data.append({
                'question_id': doc.metadata.get('id'),
                'question_text': doc.metadata.get('question', ''),
                'source_type': 'document',
                'generation_method': 'LLM',
                'status': doc.metadata.get('status', 'active'),
            })

        return pd.DataFrame(question_data)

    def get_question_sources_as_dataframe(
        self,
        documents: List[Document]
    ):
        """
        Extract question source provenance from documents to DataFrame (for notebook 3).

        Args:
            documents: List of question documents with metadata

        Returns:
            pandas DataFrame with question source data

        Example:
            >>> question_docs = gen.generate_from_documents(chunks)
            >>> df_sources = gen.get_question_sources_as_dataframe(question_docs)
            >>> df_sources.to_csv('question_sources.csv', index=False)
        """
        import pandas as pd

        sources_data = []
        for doc in documents:
            content_checksum = doc.metadata.get('content_checksum')
            if content_checksum:
                sources_data.append({
                    'question_id': doc.metadata.get('id'),
                    'content_checksum': content_checksum,
                    'is_primary_source': True,
                    'contribution_weight': 1.0,
                    'is_valid': True,
                })

        return pd.DataFrame(sources_data)


# =============================================================================
# Convenience Functions
# =============================================================================


def create_question_generator(
    model_name: str = "gpt-4o_2024-11-20-pgo-amrs",
    **kwargs
) -> QuestionGenerator:
    """
    Factory function to create a QuestionGenerator instance.

    Args:
        model_name: Azure OpenAI model name
        **kwargs: Additional parameters passed to QuestionGenerator

    Returns:
        Configured QuestionGenerator instance

    Example:
        >>> gen = create_question_generator(
        ...     model_name="gpt-4o_2024-11-20-pgo-amrs",
        ...     temperature=0.0,
        ...     max_questions=5
        ... )
    """
    return QuestionGenerator(chat_model_name=model_name, **kwargs)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "QuestionGenerator",
    "QuestionGeneratorError",
    "LLMGenerationError",
    "DocumentTransformationError",
    "create_question_generator",
]
