"""
FAQ Generation Function Calling Schemas

This module contains all function calling schemas used for structured LLM outputs.
Schemas define the expected JSON structure for LLM responses, ensuring type safety
and validation.

Architecture:
- Schemas are defined using oneailib's FunctionCalling framework
- Each schema specifies the exact output structure expected from LLM
- Supports nested structures and type validation

Design Principles:
- Single Responsibility: Only schema definitions
- Type Safety: Explicit type definitions for all fields
- Validation: Built-in validation through schema structure
- Documentation: Clear descriptions for LLM understanding

Example Usage:
    >>> from faq_generation.schemas import FAQ_QUESTION_GENERATION_SCHEMA
    >>> from oneailib.chat_models.azure_openai import AzureOpenAIChatModel
    >>>
    >>> model = AzureOpenAIChatModel(
    ...     engine_name="gpt-4o",
    ...     function_calling=FAQ_QUESTION_GENERATION_SCHEMA
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from oneailib.core.chat_models.base import (
    FunctionCalling,
    FunctionCallingParameters,
    FunctionCallingPropertiesDocumentKey,
)

# =============================================================================
# Question Generation Schema
# =============================================================================

FAQ_QUESTION_GENERATION_SCHEMA = FunctionCalling(
    name="get_list_format",
    description=(
        "List with a valid json format. Each element of the list must include the following key: 'question'."
        "Example:\n---------------------\n"
        '[{"question": "How do I apply for unemployment insurance?"},'
        '{"question": "What is my state unemployment tax rate?"},'
        '{"question": "How do I check PTO?"}]\n---------------------'
    ),
    parameters=FunctionCallingParameters(
        type="object",
        properties={
            "questions_for_single_cluster": FunctionCallingPropertiesDocumentKey(
                type="array",
                description="A list of dictionaries with the generated questions. Every element of the list should contain the key: 'question'.",
                items={
                    "question": {
                        "type": "string",
                        "description": "Generated question."
                    }
                }
            )
        }
    )
)

# =============================================================================
# Answer Generation Schema
# =============================================================================

FAQ_ANSWER_GENERATION_SCHEMA = FunctionCalling(
    name="get_list_format",
    description=(
        "List with a valid json format. Each element of the list must include the following keys: 'answer', 'context_indexes'.\n"
        "- answer: The answer to the question.\n"
        "- context_indexes: The indexes of the documents used to generate the answer.\n\n"
        "Example:\n---------------------\n"
        '[{"answer_for_each_question": [{"answer": "To change your profile, you can go to settings", "context_indexes": [0]}]},\n'
        '{"answer_for_each_question": [{"answer": "No more than 14 days off are allowed.", "context_indexes": [2, 0]}]},\n'
        '{"answer_for_each_question": [{"answer": "I do not have enough information to answer this question", "context_indexes": []}]}]'
        "\n---------------------"
    ),
    parameters=FunctionCallingParameters(
        type="object",
        properties={
            "answer_for_each_question": FunctionCallingPropertiesDocumentKey(
                type="array",
                description="A list of dictionaries with the generated answers. Every element of the list should contain the keys: 'answer', 'context_indexes'.",
                items={
                    "answer": {
                        "type": "string",
                        "description": "Answer for the given question."
                    },
                    "context_indexes": {
                        "type": "array",
                        "description": "Ordered array with the context indexes used to generate the answer, where the first position is the most relevant and the last position is the least relevant. "
                                    "- The first document will correspond to the index 0. "
                                    "- Only add those documents used for generating the answer, if no documents were used, return an empty list."
                    }
                }
            )
        }
    )
)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "FAQ_QUESTION_GENERATION_SCHEMA",
    "FAQ_ANSWER_GENERATION_SCHEMA",
]
