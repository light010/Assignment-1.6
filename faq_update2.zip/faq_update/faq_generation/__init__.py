"""
FAQ Generation Module

This module provides utilities for generating FAQ questions and answers using LLMs.
It follows the repository pattern and clean architecture principles used throughout
the faq_update system.

Architecture:
- prompts.py: LLM prompt templates for question/answer generation
- schemas.py: Function calling schemas for structured LLM outputs
- question_generator.py: Main QuestionGenerator class for question generation
- answer_generator.py: (Future) AnswerGenerator class for answer generation

Design Principles:
- Single Responsibility: Each module has one clear purpose
- Dependency Injection: LLM models and configurations are injected
- Separation of Concerns: Prompts, schemas, and logic are separated
- Database-Agnostic: Works with any backend (SQLite, Databricks)
- Testability: All components can be tested independently

Usage Patterns:

1. Batch Processing (Notebook 3 - Question Generation):
    ```python
    from faq_generation import QuestionGenerator
    from oneailib.document_loaders.sql import SQLLoader

    # Load content chunks
    loader = SQLLoader(query="SELECT * FROM content_chunks", ...)
    documents = loader.load()

    # Generate questions
    gen = QuestionGenerator(
        chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
        temperature=0.0,
        max_questions=5
    )
    question_docs = gen.generate_from_documents(documents)

    # Convert to DataFrames for database insertion
    df_questions = gen.get_question_documents_as_dataframe(question_docs)
    df_sources = gen.get_question_sources_as_dataframe(question_docs)
    ```

2. Single Chunk Processing (Notebook 8 - Update Pipeline):
    ```python
    from faq_generation import QuestionGenerator

    # Initialize generator
    gen = QuestionGenerator()

    # Generate questions for a single chunk
    questions = gen.generate_from_text(
        chunk_text="Health insurance enrollment...",
        content_checksum="abc123def456"
    )

    # Insert into database
    for q in questions:
        backend.execute_update(
            "INSERT INTO faq_questions (...) VALUES (...)",
            (q['question_text'], q['source_type'], ...)
        )
    ```

Dependencies:
- oneailib: LLM integration (Azure OpenAI)
- utility: Logging and environment detection
- database: Optional, for direct database integration

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

# Import question generation classes and functions
from faq_generation.question_generator import (
    QuestionGenerator,
    QuestionGeneratorError,
    LLMGenerationError,
    DocumentTransformationError,
    create_question_generator,
)

# Import answer generation classes and functions
from faq_generation.answer_generator import (
    AnswerGenerator,
    AnswerGeneratorError,
    LLMAnswerGenerationError,
    AnswerTransformationError,
    create_answer_generator,
)

# Import prompts and schemas (optional, for advanced usage)
from faq_generation.prompts import (
    FAQ_QUESTION_GENERATION_PROMPT,
    FAQ_ANSWER_GENERATION_PROMPT,
)

from faq_generation.schemas import (
    FAQ_QUESTION_GENERATION_SCHEMA,
    FAQ_ANSWER_GENERATION_SCHEMA,
)

# Module metadata
__version__ = "1.0.0"
__author__ = "Analytics Assist Team"
__all__ = [
    # Question generation classes
    "QuestionGenerator",
    "QuestionGeneratorError",
    "LLMGenerationError",
    "DocumentTransformationError",
    "create_question_generator",
    # Answer generation classes
    "AnswerGenerator",
    "AnswerGeneratorError",
    "LLMAnswerGenerationError",
    "AnswerTransformationError",
    "create_answer_generator",
    # Prompts (advanced usage)
    "FAQ_QUESTION_GENERATION_PROMPT",
    "FAQ_ANSWER_GENERATION_PROMPT",
    # Schemas (advanced usage)
    "FAQ_QUESTION_GENERATION_SCHEMA",
    "FAQ_ANSWER_GENERATION_SCHEMA",
]
