"""
FAQ Answer Generator

This module provides the AnswerGenerator class for generating FAQ answers from
questions and context using LLM (Large Language Models). It orchestrates the answer
generation process and handles document transformation.

Architecture:
- AnswerGenerator: Main class for answer generation
- Uses oneailib for LLM integration (Azure OpenAI)
- Supports both batch processing (Documents) and single question processing
- Integrates with prompts and schemas modules

Design Principles:
- Single Responsibility: Only answer generation logic
- Dependency Injection: LLM models injected or created internally
- Configurability: All parameters configurable via constructor
- Error Handling: Comprehensive error handling and retry logic
- Logging: Detailed logging for debugging and monitoring

Tables/Data Models:
- Input: oneailib.Document objects or question/context pairs
- Output: Documents with metadata or dicts with answer data

Example Usage:
    >>> # Batch processing (for notebook 4)
    >>> from faq_generation import AnswerGenerator
    >>> from oneailib.document_loaders.sql import SQLLoader
    >>>
    >>> gen = AnswerGenerator(
    ...     chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
    ...     temperature=0.0
    ... )
    >>> documents = sql_loader.load()  # Documents with question + context
    >>> answer_docs = gen.generate_from_documents(documents)
    >>>
    >>> # Single question processing (for notebook 8)
    >>> answer = gen.generate_from_question(
    ...     question_text="When does health insurance enrollment start?",
    ...     context_text="Health insurance enrollment starts January 1st.",
    ...     question_id="q123",
    ...     content_checksum="abc123"
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import List, Dict, Any, Optional
from oneailib.core.documents.base import Document
from oneailib.chat_models.azure_openai import AzureOpenAIChatModel
from oneailib.document_transformers.metadata_transformers import (
    DecomposeKeysTransformer,
    AddDocumentIDTransformer,
    AddDocumentVersionTransformer,
)
from oneailib.embeddings.azure_openai import AzureOpenAIEmbedding
from oneailib.document_transformers.transformers import EmbedKeyTransformer
from utility.logging import get_logger

from faq_generation.prompts import FAQ_ANSWER_GENERATION_PROMPT
from faq_generation.schemas import FAQ_ANSWER_GENERATION_SCHEMA

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Answer Generator Exceptions
# =============================================================================


class AnswerGeneratorError(Exception):
    """Base exception for answer generator errors."""
    pass


class LLMAnswerGenerationError(AnswerGeneratorError):
    """Raised when LLM answer generation fails."""
    pass


class AnswerTransformationError(AnswerGeneratorError):
    """Raised when answer document transformation fails."""
    pass


# =============================================================================
# Answer Generator
# =============================================================================


class AnswerGenerator:
    """
    Generates FAQ answers from questions and context using LLM.

    This class orchestrates the answer generation process:
    1. Accepts content (Documents or question/context pairs)
    2. Optionally generates embeddings for semantic search
    3. Calls LLM to generate answers
    4. Decomposes structured output into individual answers
    5. Adds metadata (IDs, versions)
    6. Returns processed data

    Attributes:
        chat_model_name: Azure OpenAI model name (e.g., "gpt-4o_2024-11-20-pgo-amrs")
        embedding_model_name: Azure OpenAI embedding model name
        temperature: LLM temperature (0.0 = deterministic, 1.0 = creative)
        max_tokens: Maximum tokens for LLM response
        max_retries: Number of retries on LLM failure
        seconds_between_retries: Delay between retries
        use_embeddings: Whether to generate embeddings for context/questions

    Example:
        >>> gen = AnswerGenerator(
        ...     chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
        ...     temperature=0.0
        ... )
        >>> answer = gen.generate_from_question("What is...?", "Context here...")
    """

    def __init__(
        self,
        chat_model_name: str = "gpt-4o_2024-11-20-pgo-amrs",
        embedding_model_name: str = "text-embedding-ada-002_2-pgo-amrs",
        temperature: float = 0.0,
        max_tokens: int = 4000,
        max_retries: int = 10,
        seconds_between_retries: int = 5,
        use_embeddings: bool = False,
    ):
        """
        Initialize AnswerGenerator with configuration.

        Args:
            chat_model_name: Azure OpenAI engine name for chat
            embedding_model_name: Azure OpenAI engine name for embeddings
            temperature: LLM temperature (0.0-1.0)
            max_tokens: Maximum tokens in LLM response
            max_retries: Number of retry attempts on failure
            seconds_between_retries: Delay between retries (seconds)
            use_embeddings: Whether to generate embeddings (for semantic search)

        Raises:
            ValueError: If invalid parameter values provided
        """
        # Validate parameters
        if not 0.0 <= temperature <= 1.0:
            raise ValueError(f"temperature must be between 0.0 and 1.0, got {temperature}")
        if max_tokens <= 0:
            raise ValueError(f"max_tokens must be positive, got {max_tokens}")
        if max_retries < 0:
            raise ValueError(f"max_retries must be non-negative, got {max_retries}")

        self.chat_model_name = chat_model_name
        self.embedding_model_name = embedding_model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        self.seconds_between_retries = seconds_between_retries
        self.use_embeddings = use_embeddings

        # Lazy initialization of components
        self._answer_generator_model = None
        self._answer_decomposer = None
        self._id_transformer = None
        self._version_transformer = None
        self._embedding_model = None
        self._context_embedding_transformer = None
        self._question_embedding_transformer = None

        logger.debug(
            f"AnswerGenerator initialized with model={chat_model_name}, "
            f"temperature={temperature}, use_embeddings={use_embeddings}"
        )

    def _get_answer_generator_model(self) -> AzureOpenAIChatModel:
        """
        Get or create the LLM model for answer generation (lazy initialization).

        Returns:
            Configured AzureOpenAIChatModel instance
        """
        if self._answer_generator_model is None:
            logger.info(f"Initializing Azure OpenAI model: {self.chat_model_name}")
            self._answer_generator_model = AzureOpenAIChatModel(
                engine_name=self.chat_model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                max_retries=self.max_retries,
                seconds_between_retries=self.seconds_between_retries,
                prompt=FAQ_ANSWER_GENERATION_PROMPT,
                function_calling=FAQ_ANSWER_GENERATION_SCHEMA,
            )
        return self._answer_generator_model

    def _get_answer_decomposer(self) -> DecomposeKeysTransformer:
        """
        Get or create the answer decomposer (lazy initialization).

        Returns:
            Configured DecomposeKeysTransformer instance
        """
        if self._answer_decomposer is None:
            logger.debug("Initializing answer decomposer")
            self._answer_decomposer = DecomposeKeysTransformer(
                keys_to_decompose={"answer_for_each_question": ["answer", "context_indexes"]}
            )
        return self._answer_decomposer

    def _get_id_transformer(self) -> AddDocumentIDTransformer:
        """
        Get or create the ID transformer (lazy initialization).

        Returns:
            AddDocumentIDTransformer instance
        """
        if self._id_transformer is None:
            logger.debug("Initializing ID transformer")
            self._id_transformer = AddDocumentIDTransformer()
        return self._id_transformer

    def _get_version_transformer(self) -> AddDocumentVersionTransformer:
        """
        Get or create the version transformer (lazy initialization).

        Returns:
            AddDocumentVersionTransformer instance
        """
        if self._version_transformer is None:
            logger.debug("Initializing version transformer")
            self._version_transformer = AddDocumentVersionTransformer()
        return self._version_transformer

    def _get_embedding_model(self) -> AzureOpenAIEmbedding:
        """
        Get or create the embedding model (lazy initialization).

        Returns:
            AzureOpenAIEmbedding instance
        """
        if self._embedding_model is None:
            logger.info(f"Initializing embedding model: {self.embedding_model_name}")
            self._embedding_model = AzureOpenAIEmbedding(
                engine_name=self.embedding_model_name
            )
        return self._embedding_model

    def _get_context_embedding_transformer(self) -> EmbedKeyTransformer:
        """
        Get or create the context embedding transformer (lazy initialization).

        Returns:
            EmbedKeyTransformer instance for context
        """
        if self._context_embedding_transformer is None:
            logger.debug("Initializing context embedding transformer")
            embedding_model = self._get_embedding_model()
            self._context_embedding_transformer = EmbedKeyTransformer(
                key="context",
                embeddings=embedding_model
            )
        return self._context_embedding_transformer

    def _get_question_embedding_transformer(self) -> EmbedKeyTransformer:
        """
        Get or create the question embedding transformer (lazy initialization).

        Returns:
            EmbedKeyTransformer instance for questions
        """
        if self._question_embedding_transformer is None:
            logger.debug("Initializing question embedding transformer")
            embedding_model = self._get_embedding_model()
            self._question_embedding_transformer = EmbedKeyTransformer(
                key="question",
                embeddings=embedding_model
            )
        return self._question_embedding_transformer

    def _validate_documents_have_questions(self, documents: List[Document]) -> None:
        """
        Validate that all documents have questions in their metadata.

        An answer cannot exist without a question. This method ensures that
        all documents have a valid question field before attempting answer generation.

        Args:
            documents: List of Document objects to validate

        Raises:
            ValueError: If any document is missing a question or has an empty question

        Example:
            >>> docs = [Document(page_content="...", metadata={"question": "What is...?"})]
            >>> gen._validate_documents_have_questions(docs)  # OK
            >>>
            >>> bad_docs = [Document(page_content="...", metadata={})]
            >>> gen._validate_documents_have_questions(bad_docs)  # Raises ValueError
        """
        logger.debug(f"Validating {len(documents)} documents have questions")

        missing_questions = []
        for i, doc in enumerate(documents):
            # Check if question exists in metadata
            question = doc.metadata.get("question")

            # Validate question is present and not empty
            if not question or (isinstance(question, str) and not question.strip()):
                missing_questions.append({
                    'index': i,
                    'metadata': doc.metadata,
                    'has_question_key': 'question' in doc.metadata,
                    'question_value': question
                })

        if missing_questions:
            error_msg = (
                f"Cannot generate answers without questions! "
                f"Found {len(missing_questions)} documents missing valid questions out of {len(documents)} total.\n"
                f"An answer MUST have a question. Please ensure all documents have a 'question' field in metadata.\n"
                f"\nFirst few problematic documents:\n"
            )

            for item in missing_questions[:3]:  # Show first 3 examples
                error_msg += (
                    f"  - Document #{item['index']}: "
                    f"has_question_key={item['has_question_key']}, "
                    f"question_value={repr(item['question_value'])}, "
                    f"metadata_keys={list(item['metadata'].keys())}\n"
                )

            if len(missing_questions) > 3:
                error_msg += f"  ... and {len(missing_questions) - 3} more\n"

            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.debug(f"✓ All {len(documents)} documents have valid questions")

    def generate_from_documents(
        self,
        documents: List[Document],
        add_ids: bool = True,
        add_versions: bool = True,
        generate_embeddings: bool = None,
    ) -> List[Document]:
        """
        Generate answers from a list of Documents (batch processing).

        This method is designed for notebook 4's batch processing workflow:
        1. Validate that all documents have questions
        2. Optionally generate embeddings for questions and context
        3. Generate answers from documents using LLM
        4. Decompose structured output into individual answer documents
        5. Add document IDs and versions
        6. Return processed documents

        Args:
            documents: List of Document objects with question and context in metadata
            add_ids: Whether to add document IDs
            add_versions: Whether to add document versions
            generate_embeddings: Whether to generate embeddings (overrides constructor)

        Returns:
            List of Document objects with answer metadata

        Raises:
            ValueError: If any document is missing a question
            LLMAnswerGenerationError: If LLM generation fails
            AnswerTransformationError: If document transformation fails

        Example:
            >>> from oneailib.document_loaders.sql import SQLLoader
            >>> loader = SQLLoader(query="SELECT question, context FROM ...", ...)
            >>> documents = loader.load()
            >>> gen = AnswerGenerator()
            >>> answer_docs = gen.generate_from_documents(documents)
            >>> print(len(answer_docs))
            75
        """
        logger.info(f"Generating answers from {len(documents)} documents")

        # Step 0: VALIDATE - All documents must have questions
        self._validate_documents_have_questions(documents)

        # Determine if embeddings should be generated
        use_emb = generate_embeddings if generate_embeddings is not None else self.use_embeddings

        try:
            processed_docs = documents

            # Step 1: Generate embeddings (optional)
            if use_emb:
                logger.debug("Generating context embeddings")
                context_transformer = self._get_context_embedding_transformer()
                processed_docs = context_transformer.transform_documents(processed_docs)

                logger.debug("Generating question embeddings")
                question_transformer = self._get_question_embedding_transformer()
                processed_docs = question_transformer.transform_documents(processed_docs)

                logger.info("Embeddings generated for questions and context")

            # Step 2: Generate answers using LLM
            model = self._get_answer_generator_model()
            logger.debug("Calling LLM for answer generation")
            answer_generated_docs = model(processed_docs)
            logger.info(f"LLM generated {len(answer_generated_docs)} answer documents")

            # Step 3: Decompose answers
            decomposer = self._get_answer_decomposer()
            logger.debug("Decomposing answer documents")
            decomposed_docs = decomposer.transform_documents(answer_generated_docs)
            logger.info(f"Decomposed into {len(decomposed_docs)} individual answers")

            # Step 4: Add document IDs (optional)
            if add_ids:
                id_transformer = self._get_id_transformer()
                logger.debug("Adding document IDs")
                decomposed_docs = id_transformer.transform_documents(decomposed_docs)

            # Step 5: Add document versions (optional)
            if add_versions:
                version_transformer = self._get_version_transformer()
                logger.debug("Adding document versions")
                decomposed_docs = version_transformer.transform_documents(decomposed_docs)

            logger.info(f"Successfully generated {len(decomposed_docs)} answers")
            return decomposed_docs

        except Exception as e:
            logger.error(f"Failed to generate answers from documents: {e}")
            raise LLMAnswerGenerationError(f"Answer generation failed: {e}") from e

    def generate_from_question(
        self,
        question_text: str,
        context_text: str,
        question_id: str,
        content_checksum: str,
        status: str = "active",
        confidence_score: float = 0.95,
    ) -> Dict[str, Any]:
        """
        Generate answer for a single question with context (single question processing).

        This method is designed for notebook 8's pipeline workflow where we need
        to generate an answer for a single question in response to content changes.

        IMPORTANT: An answer MUST have a question. This method enforces strict validation
        that question_text is provided and not empty.

        Args:
            question_text: Question to answer (REQUIRED - cannot be empty)
            context_text: Context/content to use for answer generation
            question_id: ID of the question (REQUIRED - cannot be empty)
            content_checksum: Checksum of the content chunk (for provenance)
            status: Answer status ("active", "inactive")
            confidence_score: Confidence score for the answer (0.0-1.0)

        Returns:
            Dict with answer data ready for database insertion:
            {
                'answer_id': str,  # Generated answer ID
                'answer_text': str,  # The generated answer
                'question_id': str,  # Original question ID
                'content_checksum': str,  # For provenance linking
                'confidence_score': float,  # Confidence score
                'generation_method': str,  # "LLM"
                'status': str,  # "active"
                'context_employed': str,  # Context used
                'context_indexes': list,  # Indexes of context used
            }

        Raises:
            ValueError: If question_text, question_id, context_text, or content_checksum is empty
            LLMAnswerGenerationError: If LLM generation fails

        Example:
            >>> gen = AnswerGenerator()
            >>> answer = gen.generate_from_question(
            ...     question_text="When does health insurance enrollment start?",
            ...     context_text="Health insurance enrollment starts on January 1st.",
            ...     question_id="q123",
            ...     content_checksum="abc123def456"
            ... )
            >>> print(answer['answer_text'])
            'Health insurance enrollment starts on January 1st.'
        """
        # CRITICAL VALIDATION: An answer MUST have a question
        if not question_text or not question_text.strip():
            error_msg = (
                "Cannot generate answer without a question! "
                "question_text is required and cannot be empty. "
                "An answer MUST be associated with a valid question."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        if not question_id or not question_id.strip():
            error_msg = (
                "Cannot generate answer without a question_id! "
                "question_id is required and cannot be empty. "
                "Each answer must be linked to a specific question."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        if not context_text or not context_text.strip():
            logger.warning(f"context_text is empty for question_id={question_id}")
            raise ValueError("context_text cannot be empty")

        if not content_checksum:
            logger.warning(f"content_checksum is empty for question_id={question_id}")
            raise ValueError("content_checksum cannot be empty")

        logger.info(f"Generating answer for question {question_id[:8]}...")

        try:
            # Step 1: Create a Document from the question and context
            doc = Document(
                page_content=context_text,  # Use context as page_content
                metadata={
                    "question": question_text,
                    "context": context_text,
                    "question_id": question_id,
                    "content_checksum": content_checksum,
                }
            )

            # Step 2: Generate answer using the document-based method
            answer_docs = self.generate_from_documents(
                documents=[doc],
                add_ids=True,
                add_versions=True,
                generate_embeddings=False  # Don't generate embeddings for single question
            )

            # Step 3: Transform to dict format for database insertion
            if not answer_docs:
                raise LLMAnswerGenerationError("No answers generated")

            answer_doc = answer_docs[0]
            answer_data = {
                'answer_id': answer_doc.metadata.get('id'),
                'answer_text': answer_doc.metadata.get('answer', ''),
                'question_id': question_id,
                'content_checksum': content_checksum,
                'confidence_score': confidence_score,
                'generation_method': 'LLM',
                'status': status,
                'context_employed': context_text,
                'context_indexes': answer_doc.metadata.get('context_indexes', []),
            }

            logger.info(f"Generated answer for question {question_id[:8]}")
            return answer_data

        except Exception as e:
            logger.error(f"Failed to generate answer for question: {e}")
            raise LLMAnswerGenerationError(f"Answer generation failed: {e}") from e

    def get_answer_documents_as_dataframe(
        self,
        documents: List[Document]
    ):
        """
        Convert answer documents to a pandas DataFrame (for notebook 4).

        This is a utility method to help with the transition from documents
        to database-ready format.

        Args:
            documents: List of answer documents with metadata

        Returns:
            pandas DataFrame with answer data

        Example:
            >>> answer_docs = gen.generate_from_documents(questions_with_context)
            >>> df = gen.get_answer_documents_as_dataframe(answer_docs)
            >>> df.to_csv('answers.csv', index=False)
        """
        import pandas as pd

        answer_data = []
        for doc in documents:
            answer_data.append({
                'answer_id': doc.metadata.get('id'),
                'question_id': doc.metadata.get('question_id'),
                'answer_text': doc.metadata.get('answer', ''),
                'status': 'active',
            })

        return pd.DataFrame(answer_data)

    def get_answer_sources_as_dataframe(
        self,
        documents: List[Document]
    ):
        """
        Extract answer source provenance from documents to DataFrame (for notebook 4).

        Args:
            documents: List of answer documents with metadata

        Returns:
            pandas DataFrame with answer source data

        Example:
            >>> answer_docs = gen.generate_from_documents(questions_with_context)
            >>> df_sources = gen.get_answer_sources_as_dataframe(answer_docs)
            >>> df_sources.to_csv('answer_sources.csv', index=False)
        """
        import pandas as pd

        sources_data = []
        for doc in documents:
            content_checksum = doc.metadata.get('content_checksum')
            if content_checksum:
                sources_data.append({
                    'answer_id': doc.metadata.get('id'),
                    'content_checksum': content_checksum,
                    'context_employed': doc.metadata.get('context', ''),
                    'is_primary_source': True,
                    'contribution_weight': 1.0,
                    'is_valid': True,
                })

        return pd.DataFrame(sources_data)


# =============================================================================
# Convenience Functions
# =============================================================================


def create_answer_generator(
    model_name: str = "gpt-4o_2024-11-20-pgo-amrs",
    **kwargs
) -> AnswerGenerator:
    """
    Factory function to create an AnswerGenerator instance.

    Args:
        model_name: Azure OpenAI model name
        **kwargs: Additional parameters passed to AnswerGenerator

    Returns:
        Configured AnswerGenerator instance

    Example:
        >>> gen = create_answer_generator(
        ...     model_name="gpt-4o_2024-11-20-pgo-amrs",
        ...     temperature=0.0,
        ...     use_embeddings=True
        ... )
    """
    return AnswerGenerator(chat_model_name=model_name, **kwargs)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "AnswerGenerator",
    "AnswerGeneratorError",
    "LLMAnswerGenerationError",
    "AnswerTransformationError",
    "create_answer_generator",
]
