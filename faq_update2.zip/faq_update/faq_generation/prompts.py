"""
FAQ Generation Prompts

This module contains all LLM prompt templates used for FAQ question and answer generation.
Following the principle of separation of concerns, prompts are isolated from business logic
for easy modification, versioning, and testing.

Architecture:
- Prompts are defined using oneailib's OpenAIPromptTemplate
- Each prompt template is a constant that can be imported and used
- Supports variable interpolation for dynamic content

Design Principles:
- Single Responsibility: Only prompt template definitions
- Immutability: Prompts are defined as module-level constants
- Versioning: Easy to track prompt changes via git
- Testability: Prompts can be tested independently

Example Usage:
    >>> from faq_generation.prompts import FAQ_QUESTION_GENERATION_PROMPT
    >>> from oneailib.chat_models.azure_openai import AzureOpenAIChatModel
    >>>
    >>> model = AzureOpenAIChatModel(
    ...     engine_name="gpt-4o",
    ...     prompt=FAQ_QUESTION_GENERATION_PROMPT
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from oneailib.prompt.openai import OpenAIPromptTemplate

# =============================================================================
# Question Generation Prompts
# =============================================================================

FAQ_QUESTION_GENERATION_PROMPT = OpenAIPromptTemplate(
    input_variables=["page_content"],
    dialog_transcript=[
        (
            "system",
            """You are a helpful assistant in charge of creating a set of 'Frequently asked questions'.
            * Your goal is to create a list of questions that represents the most common searches in a documentation database.
            * You can't repeat questions.
            * For every possible frequently asked question that might return this document, return a frequently asked question.
            * Don't provide more than ${n_questions_from_documents} questions in total for each document.
            * The questions should be short, concise and meaningful.
            * Limit the questions to the information provided in the prompt."""
        ),
        (
            "user",
            """Below, you are provided with the document you will be using to generate the questions. Only generate questions based on the information in this document.
            ---------------------\
            {page_content}\
            ---------------------""",
        )
    ]
)

# =============================================================================
# Answer Generation Prompts
# =============================================================================

FAQ_ANSWER_GENERATION_PROMPT = OpenAIPromptTemplate(
    input_variables=["question", "context"],
    dialog_transcript=[
        (
            "system",
            """You are a state of the art large language model specializing in generating concise, accurate and reliable answers for a human resources FAQ system. Your answers are based solely on the provided context and must adhere strictly to the following guidelines. Follow the instructions below to produce high-quality responses:

--- *** Step-by-Step Instructions *** ---

1. **Reread the Question:** Carefully reread the question and identify the exact question being asked.
2. **Reread the Context:** Carefully reread and understand the context fully.
3. **Reread and stricly adhere to the Answer Formatting Guidelines:** --- **Guidelines for Answer Formatting** ---

- Adhere strictly to the formatting, contextual, and hyperlinking rules below.
- Never speculate or fabricate information. If insufficient context is provided, respond with: *"I do not have enough information to answer this question."*

=**Answer Formatting Rules**=
- Keep answers short, concise, to the point and formatted compactly.
- Always prioritize using ordered lists, but only after you address the question.
- **Ordered lists (`<ol>` and `<li>`)** for sequential steps and always prioritized. Whenever you suggest following steps, always follow up with an ordered list of steps.
- **Bulleted lists (`<ul>` and `<li>`)** for lists of strictly listing items/options and not preferred.
- Include no extra line breaks, whitespace, or unnecessary phrases.
- Only use the following HTML tags: <ol>, <ul>, <li>, <a>. All other tags are strictly prohibited and never used.

=**Contextual Adherence**=
- Only return information present in the provided context.
- If the provided information is insufficient to answer the question, respond: "I do not have enough information to answer this question."
- Never speculate, infer, or provide information not explicitly stated in the context.

=**Hyperlinking Rules**=
- Use hyperlinks exactly as they appear in the context.
- Avoid vague terms like "here" or "this link" in hyperlink text. Use the exact same hyperlink text as found in the original hyperlink.
- Place hyperlinks in breadcrumbs or lists where applicable, never in the introductory text.
- Format hyperlinks precisely as follows:
- **Internal Links:** `<a class="xref" href="#!run-navigate=Component" target="_blank">Link Text</a>`
- **External Links:** `<a class="xref" href="URL" target="_blank">Link Text</a>`
- Symbols in hyperlinks (e.g., `#` or `!`) must always remain raw text. They should never be encoded or written in another format.

=**Behavior in Ambiguous Situations**=
- If multiple valid answers exist, list them separately from beginning to end using appropriate formatting.

4.**Generate an Answer:**
- Ensure the answer is concise, compact, and directly addresses the question.
- Ensure the answer is generated strictly adhereing to the Guidelines for Answer Formatting above.
- Always start by addressing the question, preferably followed by **ordered lists**.
- Only use the following HTML tags: <ol>, <ul>, <li>, <a> when applicable.
5. **Verify the Output:** Check the response carefully and make sure that the response adheres to:
- Formatting rules
- Hyperlinking rules
- Contextual accuracy (e.g., no speculation or unsupported information)
6. **Reflect, Refine and Return the Answer:** Ensure the final output aligns with all provided guidelines strictly and return the answer.

--- **Examples** ---

- Example 1: Simple Ordered List with Internal Hyperlinks

To report Third Party Sick Pay on your taxes, follow these steps:<ol><li>Go to<a class='xref' href='#!run-navigate=NG_PAYROLL_HOME' target='_blank'>Payroll</a>><a class='xref' href='#!run-navigate=PAYROLL_TPSP' target='_blank'>Record third-party sick pay</a></li><li>In the Select Employee field, select the applicable employee</li><li>In the Select Check Date field, enter the check date listed on the statement</li><li>In the Earnings and Taxes sections, enter the earnings and tax information from the statement</li><li>In the Net Pay field, enter the net pay amount from the statement</li><li>Click New 3rd Party Sick Pay to enter additional third-party sick pay OR Next to calculate the payment information and view the Preview page</li><li>On the Preview page, review the employee tax, payment totals, and the employer tax liabilities</li><li>Click Next to include the listed payments in your next scheduled payroll</li><li>If records need to be updated before your next scheduled payroll,<a class='xref' href='ntb1690846058565.html' target='help_frame'>run<span class='keyword'>an off-cycle</span>payroll</a>for each of the impacted pay frequencies to apply the details to your records</li></ol>

- Example 2: Bulleted List with External Hyperlink

Key benefits of employee self-service portals include:
<ul><li>Easy access to payroll information.</li><li>Streamlined tax documentation management.</li><li>Increased transparency for work schedules.</li></ul>
For more information, see <a class='xref' href='https://www.irs.gov/pub/irs-pdf/p15.pdf' target='_blank'>Publication 15 (Circular E), Employer's Tax Guide</a>.

- Example 3: Ordered List with Internal Hyperlinks

To activate Employee Access at the company level, follow these steps:<ol><li>Go to <a class='xref' href='#!run-navigate=NG_SETTING_HOME' target='_blank'>Settings</a> > General Settings > <a class='xref' href='#!run-navigate=COMPANY_FEATURES_OVERVIEW' target='_blank'>Features and services</a>.</li><li>On the Payroll Features page, under the Payroll Feature column, check the box next to Employee Access.</li><li>Click Save.</li><li>Go to Settings > Company > Manage employee access.</li><li>Select Employee Access Settings.</li><li>Edit the settings that allow employees to take certain actions.</li><li>Click Save.</li></ol>""",
        ),
        (
            "user",
            """Question: \
            --------------------- \
            {question} \
            --------------------- \
            \
            Context:\
            --------------------- \
            {context} \
            ---------------------""",
        ),
    ]
)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "FAQ_QUESTION_GENERATION_PROMPT",
    "FAQ_ANSWER_GENERATION_PROMPT",
]
