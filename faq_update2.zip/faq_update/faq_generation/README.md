# FAQ Generation Module

A reusable Python module for generating FAQ questions from content chunks using Large Language Models (LLMs). This module is used across multiple notebooks in the FAQ update system.

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Installation](#installation)
- [Usage](#usage)
  - [Batch Processing (Notebook 3)](#batch-processing-notebook-3)
  - [Single Chunk Processing (Notebook 8)](#single-chunk-processing-notebook-8)
- [API Reference](#api-reference)
- [Configuration](#configuration)
- [Testing](#testing)
- [Error Handling](#error-handling)
- [Contributing](#contributing)

## 🎯 Overview

The `faq_generation` module provides a clean, testable, and reusable abstraction for generating FAQ questions using Azure OpenAI. It eliminates code duplication between notebooks and provides a single source of truth for prompt templates and generation logic.

**Key Features:**
- ✅ Unified question generation logic across notebooks
- ✅ Configurable LLM parameters (model, temperature, retries, etc.)
- ✅ Support for both batch and single-chunk processing
- ✅ Comprehensive error handling and retry logic
- ✅ Full unit test coverage
- ✅ Type hints and detailed documentation
- ✅ Database-agnostic (works with SQLite, Databricks, etc.)

**Used In:**
- `3_question_source_gen.ipynb` - Batch question generation from content chunks
- `8_faq_update_pipeline.ipynb` - Single chunk processing for content updates

## 🏗️ Architecture

```
faq_generation/
├── __init__.py                 # Module exports
├── prompts.py                  # LLM prompt templates
├── schemas.py                  # Function calling schemas
├── question_generator.py       # Main QuestionGenerator class
└── README.md                   # This file
```

### Design Principles

1. **Separation of Concerns**: Prompts, schemas, and logic are in separate files
2. **Single Responsibility**: Each module has one clear purpose
3. **Dependency Injection**: LLM models are lazily initialized
4. **Testability**: All components can be mocked and tested independently
5. **Configuration Over Code**: Behavior controlled via constructor parameters

## 📦 Installation

The module is part of the `faq_update` project and has the following dependencies:

```bash
# Core dependencies (from oneailib)
oneailib>=1.13

# Already available in faq_update environment
pandas
pydantic
```

Ensure `oneailib` is installed:

```bash
pip install oneailib==1.13 --extra-index-url https://artifactory.us.caas.oneadp.com/artifactory/api/pypi/datacloud-datascience-pypi-local/simple
```

## 🚀 Usage

### Batch Processing (Notebook 3)

Generate questions from multiple content chunks at once:

```python
from faq_generation import QuestionGenerator
from oneailib.document_loaders.sql import SQLLoader

# Step 1: Load content chunks from database
loader = SQLLoader(
    query="SELECT * FROM content_chunks",
    content_column="chunk_text",
    fields_schema={"chunk_id": "", "chunk_text": "", "content_checksum": ""}
)
documents = loader.load()

# Step 2: Create question generator
gen = QuestionGenerator(
    chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
    temperature=0.0,
    max_tokens=4000,
    max_retries=10,
    max_questions=5
)

# Step 3: Generate questions (batch processing)
question_docs = gen.generate_from_documents(
    documents=documents,
    add_ids=True,
    add_versions=True
)

print(f"Generated {len(question_docs)} questions")

# Step 4: Convert to DataFrames for database insertion
df_questions = gen.get_question_documents_as_dataframe(question_docs)
df_sources = gen.get_question_sources_as_dataframe(question_docs)

# Step 5: Save to database
faq_repo.ingest_questions(df_questions)
faq_repo.ingest_question_sources(df_sources)
```

### Single Chunk Processing (Notebook 8)

Generate questions for a single content chunk (e.g., in response to content changes):

```python
from faq_generation import QuestionGenerator

# Step 1: Initialize generator (singleton pattern)
gen = QuestionGenerator(
    chat_model_name="gpt-4o_2024-11-20-pgo-amrs",
    temperature=0.0,
    max_questions=5
)

# Step 2: Generate questions for a single chunk
questions = gen.generate_from_text(
    chunk_text="Health insurance enrollment period starts on January 1st and ends on March 31st.",
    content_checksum="abc123def456",
    source_type='document',
    generation_method='LLM',
    status='active'
)

# Step 3: Insert into database
for q in questions:
    backend.execute_update(
        """INSERT INTO faq_questions
           (question_id, question_text, source_type, generation_method, status)
           VALUES (?, ?, ?, ?, ?)""",
        (q['question_id'], q['question_text'], q['source_type'],
         q['generation_method'], q['status'])
    )

    # Link to source content
    backend.execute_update(
        """INSERT INTO faq_question_sources
           (question_id, content_checksum, is_primary_source, contribution_weight, is_valid)
           VALUES (?, ?, ?, ?, ?)""",
        (q['question_id'], q['content_checksum'], True, 1.0, True)
    )
```

## 📚 API Reference

### QuestionGenerator

Main class for generating FAQ questions using LLM.

#### Constructor

```python
QuestionGenerator(
    chat_model_name: str = "gpt-4o_2024-11-20-pgo-amrs",
    temperature: float = 0.0,
    max_tokens: int = 4000,
    max_retries: int = 10,
    seconds_between_retries: int = 5,
    max_questions: int = 5,
)
```

**Parameters:**
- `chat_model_name` - Azure OpenAI engine name
- `temperature` - LLM temperature (0.0 = deterministic, 1.0 = creative)
- `max_tokens` - Maximum tokens in LLM response
- `max_retries` - Number of retry attempts on failure
- `seconds_between_retries` - Delay between retries (seconds)
- `max_questions` - Maximum questions to generate per chunk

**Raises:**
- `ValueError` - If invalid parameter values provided

#### Methods

##### `generate_from_documents(documents, add_ids=True, add_versions=True)`

Generate questions from a list of Documents (batch processing).

**Parameters:**
- `documents` (List[Document]) - List of Document objects with content
- `add_ids` (bool) - Whether to add document IDs
- `add_versions` (bool) - Whether to add document versions

**Returns:**
- List[Document] - List of Document objects with question metadata

**Raises:**
- `LLMGenerationError` - If LLM generation fails

**Example:**
```python
question_docs = gen.generate_from_documents(chunks)
```

##### `generate_from_text(chunk_text, content_checksum, source_type='document', generation_method='LLM', status='active')`

Generate questions from a single text chunk (single chunk processing).

**Parameters:**
- `chunk_text` (str) - Text content to generate questions from
- `content_checksum` (str) - Checksum of the content chunk (for provenance)
- `source_type` (str) - Type of source ("document", "user_query", etc.)
- `generation_method` (str) - How questions were generated ("LLM", "manual", etc.)
- `status` (str) - Question status ("active", "inactive")

**Returns:**
- List[Dict[str, Any]] - List of dicts with question data ready for database insertion

**Raises:**
- `LLMGenerationError` - If LLM generation fails
- `ValueError` - If chunk_text or content_checksum is empty

**Example:**
```python
questions = gen.generate_from_text(
    chunk_text="Health insurance enrollment...",
    content_checksum="abc123def456"
)
```

##### `get_question_documents_as_dataframe(documents)`

Convert question documents to a pandas DataFrame.

**Parameters:**
- `documents` (List[Document]) - List of question documents with metadata

**Returns:**
- pd.DataFrame - DataFrame with question data

**Example:**
```python
df = gen.get_question_documents_as_dataframe(question_docs)
df.to_csv('questions.csv', index=False)
```

##### `get_question_sources_as_dataframe(documents)`

Extract question source provenance from documents to DataFrame.

**Parameters:**
- `documents` (List[Document]) - List of question documents with metadata

**Returns:**
- pd.DataFrame - DataFrame with question source data

**Example:**
```python
df_sources = gen.get_question_sources_as_dataframe(question_docs)
df_sources.to_csv('question_sources.csv', index=False)
```

### Factory Functions

#### `create_question_generator(model_name, **kwargs)`

Factory function to create a QuestionGenerator instance.

**Example:**
```python
gen = create_question_generator(
    model_name="gpt-4o_2024-11-20-pgo-amrs",
    temperature=0.0,
    max_questions=5
)
```

### Exceptions

- `QuestionGeneratorError` - Base exception for question generator errors
- `LLMGenerationError` - Raised when LLM generation fails
- `DocumentTransformationError` - Raised when document transformation fails

## ⚙️ Configuration

### Environment Variables

The module uses Azure OpenAI credentials from environment variables (set via Databricks secrets or local environment):

```bash
AZURE_TENANT_ID=<your-tenant-id>
AZURE_CLIENT_ID=<your-client-id>
AZURE_CLIENT_SECRET=<your-client-secret>
```

### Model Configuration

Recommended models:
- `gpt-4o_2024-11-20-pgo-amrs` - Latest GPT-4o with function calling (recommended)
- `gpt-4-turbo` - GPT-4 Turbo for faster responses
- `gpt-3.5-turbo` - Faster, cheaper option for simple questions

### Temperature Settings

- `0.0` - Deterministic, consistent outputs (recommended for production)
- `0.3-0.5` - Slight variation while staying focused
- `0.7-1.0` - Creative, diverse outputs (use for exploration)

## 🧪 Testing

The module includes comprehensive unit tests:

```bash
# Run all tests
pytest tests/test_faq_generation.py -v

# Run specific test class
pytest tests/test_faq_generation.py::TestQuestionGenerator -v

# Run with coverage
pytest tests/test_faq_generation.py --cov=faq_generation --cov-report=html
```

### Test Coverage

- ✅ Initialization and configuration validation
- ✅ Batch processing (generate_from_documents)
- ✅ Single chunk processing (generate_from_text)
- ✅ Error handling and edge cases
- ✅ DataFrame conversion utilities
- ✅ Prompt and schema validation

## 🚨 Error Handling

The module provides comprehensive error handling:

```python
from faq_generation import QuestionGenerator, LLMGenerationError

gen = QuestionGenerator()

try:
    questions = gen.generate_from_text(
        chunk_text="...",
        content_checksum="abc123"
    )
except LLMGenerationError as e:
    print(f"LLM generation failed: {e}")
    # Handle error (e.g., log, retry, use fallback)
except ValueError as e:
    print(f"Invalid input: {e}")
    # Handle validation error
```

### Common Errors

1. **Empty chunk_text**: Raises `ValueError`
2. **LLM API timeout**: Automatically retries (configurable)
3. **Invalid temperature**: Raises `ValueError` during initialization
4. **Azure credentials missing**: Raises error from oneailib

## 🤝 Contributing

### Adding New Features

When adding new features to the module:

1. **Update the appropriate file**:
   - Prompts → `prompts.py`
   - Schemas → `schemas.py`
   - Logic → `question_generator.py`

2. **Add tests**: Create corresponding tests in `tests/test_faq_generation.py`

3. **Update documentation**: Add examples and API documentation

4. **Update notebooks**: Ensure notebooks 3 and 8 work with changes

### Code Style

- Follow PEP 8 style guide
- Use type hints for all function parameters and returns
- Add docstrings for all public methods
- Keep functions focused (single responsibility)
- Use descriptive variable names

## 📝 Version History

### v1.0.0 (2025-11-02)
- Initial release
- QuestionGenerator class with batch and single-chunk processing
- Prompt and schema separation
- Comprehensive unit tests
- Integration with notebooks 3 and 8

## 📄 License

Internal use only - Analytics Assist Team

## 👥 Authors

Analytics Assist Team

## 📞 Support

For questions or issues:
1. Check this README
2. Review unit tests for usage examples
3. Contact the Analytics Assist Team

---

**Happy FAQ Generation! 🚀**
