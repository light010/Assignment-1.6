"""
Recursive Character-Based Chunker with Semantic Boundaries.

Implements the industry-standard recursive splitting strategy used by LangChain
and other modern RAG systems. Tries to split on semantic boundaries in order:
1. Double newlines (paragraphs)
2. Single newlines (lines)
3. Sentence boundaries (". ")
4. Word boundaries (" ")
5. Character-level (last resort)

This ensures chunks respect natural document structure while staying within size limits.
"""

from typing import List, Tuple
from utility import compute_checksum
from core import IChunker, ChunkMetadata, ChunkSizeError, ChunkOverlapError
from config.constants import DEFAULT_CHUNK_SIZE, DEFAULT_CHUNK_OVERLAP


class RecursiveCharacterChunker(IChunker):
    """
    Recursive character-based chunker with semantic boundary awareness.

    Splits text using a hierarchy of separators, attempting high-level splits first
    (paragraphs), then progressively finer splits (sentences, words, characters).

    Best for: General text that needs semantic coherence
    Performance: Fast (no ML models)
    Output: Semantically coherent chunks with configurable overlap

    Example:
        >>> chunker = RecursiveCharacterChunker(chunk_size=1000, chunk_overlap=200)
        >>> chunks = chunker.chunk(long_markdown_text)
        >>> chunks_with_meta = chunker.chunk_with_checksums(long_markdown_text)
    """

    def __init__(
        self,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
        separators: List[str] = None,
    ):
        """
        Initialize recursive chunker.

        Args:
            chunk_size: Target size for each chunk in characters (default from config: 3000 ≈ 750 tokens)
            chunk_overlap: Number of overlapping characters between chunks (default from config: 600 ≈ 20%)
            separators: List of separators to try in order (default: paragraph/line/sentence/word/char)

        Raises:
            ChunkSizeError: If chunk_size <= 0
            ChunkOverlapError: If chunk_overlap >= chunk_size
        """
        if chunk_size <= 0:
            raise ChunkSizeError(f"chunk_size must be positive, got {chunk_size}")

        if chunk_overlap >= chunk_size:
            raise ChunkOverlapError(
                f"chunk_overlap ({chunk_overlap}) must be less than chunk_size ({chunk_size})"
            )

        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

        # Default separators from LangChain RecursiveCharacterTextSplitter
        if separators is None:
            self.separators = [
                "\n\n",  # Paragraphs
                "\n",    # Lines
                ". ",    # Sentences
                " ",     # Words
                "",      # Characters
            ]
        else:
            self.separators = separators

    def chunk(self, content: str) -> List[str]:
        """
        Split content into chunks using recursive strategy.

        Args:
            content: Text content to chunk

        Returns:
            List of text chunks

        Example:
            >>> chunker = RecursiveCharacterChunker(chunk_size=50, chunk_overlap=10)
            >>> chunks = chunker.chunk("Para 1.\\n\\nPara 2.\\n\\nPara 3.")
            >>> len(chunks)
            3
        """
        if not content:
            return []

        # Early exit: if content is already small enough, no chunking needed
        if len(content) <= self.chunk_size:
            return [content]

        return self._split_text_recursively(content, self.separators)

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        """
        Split content into chunks with checksums and metadata.

        Args:
            content: Text content to chunk

        Returns:
            List of (chunk_text, checksum, metadata) tuples where metadata is
            a ChunkMetadata dataclass containing:
            - chunk_index: Position in sequence (0-based)
            - start_pos: Start position in original content
            - end_pos: End position in original content
            - chunk_method: Always 'recursive'
            - headers: Empty dict (recursive chunking doesn't extract headers)

        Example:
            >>> chunker = RecursiveCharacterChunker()
            >>> results = chunker.chunk_with_checksums("Long text...")
            >>> chunk_text, checksum, metadata = results[0]
            >>> metadata.chunk_index
            0
            >>> metadata.chunk_method
            'recursive'
        """
        chunks = self.chunk(content)

        results = []
        current_pos = 0

        for idx, chunk_text in enumerate(chunks):
            # Find actual position in content (accounting for overlap)
            start_pos = content.find(chunk_text, current_pos)
            if start_pos == -1:
                start_pos = current_pos

            end_pos = start_pos + len(chunk_text)

            checksum = compute_checksum(chunk_text)

            metadata = ChunkMetadata(
                chunk_index=idx,
                chunk_method="recursive",
                headers={},
                start_pos=start_pos,
                end_pos=end_pos,
            )

            results.append((chunk_text, checksum, metadata))

            # Update position for next chunk (accounting for overlap)
            current_pos = end_pos - self.chunk_overlap

        return results

    def _split_text_recursively(
        self,
        text: str,
        separators: List[str]
    ) -> List[str]:
        """
        Recursively split text using separators.

        Tries each separator in order. If chunks are still too large,
        recursively tries next separator.

        Args:
            text: Text to split
            separators: List of separators to try

        Returns:
            List of text chunks
        """
        if not text:
            return []

        # Base case: text is small enough
        if len(text) <= self.chunk_size:
            return [text]

        # Try each separator
        for i, separator in enumerate(separators):
            if separator == "":
                # Last resort: split by character
                return self._split_by_character(text)

            if separator in text:
                # Split by this separator
                splits = text.split(separator)

                # Recombine splits into chunks
                chunks = self._merge_splits(splits, separator)

                # Check if any chunk is still too large
                final_chunks = []
                for chunk in chunks:
                    if len(chunk) > self.chunk_size and i < len(separators) - 1:
                        # Chunk too large, try next separator
                        sub_chunks = self._split_text_recursively(
                            chunk,
                            separators[i + 1:]
                        )
                        final_chunks.extend(sub_chunks)
                    else:
                        final_chunks.append(chunk)

                return final_chunks

        # Fallback: split by character
        return self._split_by_character(text)

    def _merge_splits(self, splits: List[str], separator: str) -> List[str]:
        """
        Merge split pieces into chunks of appropriate size with overlap.

        Args:
            splits: List of text pieces after splitting
            separator: The separator used for splitting

        Returns:
            List of merged chunks
        """
        # Filter out empty splits
        splits = [s for s in splits if s]

        if not splits:
            return []

        chunks = []
        current_chunk_parts = []

        for split in splits:
            # Calculate what the length would be if we add this split
            if current_chunk_parts:
                # Length with separator
                test_text = separator.join(current_chunk_parts + [split])
            else:
                test_text = split

            if len(test_text) <= self.chunk_size:
                # Fits, add it
                current_chunk_parts.append(split)
            else:
                # Doesn't fit
                if current_chunk_parts:
                    # Save current chunk
                    chunks.append(separator.join(current_chunk_parts))

                    # Start new chunk with potential overlap
                    if self.chunk_overlap > 0 and len(split) <= self.chunk_size:
                        # Try to include overlap from previous chunk
                        overlap_parts = self._get_overlap_parts(
                            current_chunk_parts,
                            separator
                        )
                        current_chunk_parts = overlap_parts + [split]
                    else:
                        current_chunk_parts = [split]
                else:
                    # Single split is too large, add it anyway
                    current_chunk_parts = [split]

        # Add final chunk
        if current_chunk_parts:
            chunks.append(separator.join(current_chunk_parts))

        return chunks

    def _get_overlap_parts(
        self,
        parts: List[str],
        separator: str
    ) -> List[str]:
        """
        Get parts from end of list that fit within overlap size.

        Args:
            parts: List of text parts
            separator: Separator between parts

        Returns:
            List of parts for overlap
        """
        overlap_parts = []
        overlap_length = 0

        for part in reversed(parts):
            test_length = overlap_length + len(part)
            if overlap_parts:
                test_length += len(separator)

            if test_length <= self.chunk_overlap:
                overlap_parts.insert(0, part)
                overlap_length = test_length
            else:
                break

        return overlap_parts

    def _split_by_character(self, text: str) -> List[str]:
        """
        Split text by character when no other separator works.

        Args:
            text: Text to split

        Returns:
            List of character-based chunks
        """
        chunks = []
        start = 0

        while start < len(text):
            end = start + self.chunk_size
            chunks.append(text[start:end])

            # Move start position accounting for overlap
            start = end - self.chunk_overlap

            # Ensure progress (avoid infinite loop)
            if start <= start:
                start = end

        return chunks
