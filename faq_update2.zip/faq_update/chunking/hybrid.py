"""
Hybrid Markdown Chunker - Production-Ready Strategy.

Combines the best of both worlds:
1. First splits by markdown headers (structure-aware)
2. Then applies recursive splitting within large sections (size-aware)

This is the RECOMMENDED approach for production markdown chunking,
following best practices from LangChain, LlamaIndex, and modern RAG systems.

Advantages:
- Preserves document structure (headers)
- Respects semantic boundaries (paragraphs, sentences)
- Controls chunk size (embedding-friendly)
- Includes rich metadata (header hierarchy + positions)
"""

from typing import List, Tuple
from chunking.markdown_header import MarkdownHeaderChunker
from chunking.recursive import RecursiveCharacterChunker
from utility import compute_checksum
from core import IChunker, ChunkMetadata
from config.constants import DEFAULT_CHUNK_SIZE, DEFAULT_CHUNK_OVERLAP


class HybridMarkdownChunker(IChunker):
    """
    Hybrid markdown chunker combining header and recursive strategies.

    Workflow:
    1. Split by markdown headers (H1, H2, H3)
    2. For each section, if too large, apply recursive splitting
    3. Return chunks with rich metadata (headers + positions)

    This is the **production-recommended** chunker for markdown documents.

    Best for: Markdown documents (any size, any structure)
    Performance: Fast (no ML models)
    Output: Structure-aware, size-controlled chunks with rich metadata

    Example:
        >>> chunker = HybridMarkdownChunker(chunk_size=1000, chunk_overlap=200)
        >>> results = chunker.chunk_with_checksums(markdown_content)
        >>> for chunk_text, checksum, metadata in results:
        ...     print(f"Headers: {metadata['headers']}")
        ...     print(f"Method: {metadata['chunk_method']}")
    """

    def __init__(
        self,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
        headers_to_split_on: List[Tuple[str, str]] = None,
        separators: List[str] = None,
    ):
        """
        Initialize hybrid markdown chunker.

        Args:
            chunk_size: Target size for chunks (default from config: 3000 ≈ 750 tokens)
            chunk_overlap: Overlap between chunks (default from config: 600 ≈ 20%)
            headers_to_split_on: Headers to split on (default: H1, H2, H3)
            separators: Recursive separators (default: paragraph/line/sentence/word/char)
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.headers_to_split_on = headers_to_split_on or [
            ("#", "h1"),
            ("##", "h2"),
            ("###", "h3"),
        ]

        # Initialize sub-chunkers
        self.header_chunker = MarkdownHeaderChunker(
            headers_to_split_on=self.headers_to_split_on
        )

        self.recursive_chunker = RecursiveCharacterChunker(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=separators,
        )

    def chunk(self, content: str) -> List[str]:
        """
        Split markdown content using hybrid strategy.

        Args:
            content: Markdown text content

        Returns:
            List of text chunks

        Example:
            >>> chunker = HybridMarkdownChunker()
            >>> chunks = chunker.chunk(markdown_text)
        """
        if not content:
            return []

        # Early exit: if content is already small enough, no chunking needed
        if len(content) <= self.chunk_size:
            return [content]

        # Step 1: Split by headers
        header_results = self.header_chunker.chunk_with_checksums(content)

        all_chunks = []

        # Step 2: Apply recursive splitting to large sections
        for section_text, _, _ in header_results:
            if len(section_text) <= self.chunk_size:
                # Section is small enough, keep as-is
                all_chunks.append(section_text)
            else:
                # Section too large, apply recursive splitting
                sub_chunks = self.recursive_chunker.chunk(section_text)
                all_chunks.extend(sub_chunks)

        return all_chunks

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        """
        Split markdown content with checksums and rich metadata.

        Args:
            content: Markdown text content

        Returns:
            List of (chunk_text, checksum, metadata) tuples where metadata is
            a ChunkMetadata dataclass containing:
            - chunk_index: Global position in sequence
            - headers: Header hierarchy dict (e.g., {"h1": "Title", "h2": "Section"})
            - chunk_method: How chunk was created ('header', 'recursive', or 'no_split')
            - start_pos/end_pos: Positions in original content (for recursive chunks)

        Example:
            >>> chunker = HybridMarkdownChunker()
            >>> results = chunker.chunk_with_checksums(markdown_text)
            >>> chunk_text, checksum, metadata = results[0]
            >>> print(metadata.chunk_method)  # 'header', 'recursive', or 'no_split'
        """
        if not content:
            return []

        # Early exit: if content is already small enough, no chunking needed
        if len(content) <= self.chunk_size:
            checksum = compute_checksum(content)
            metadata = ChunkMetadata(
                chunk_index=0,
                chunk_method="no_split",
                headers={},
                start_pos=0,
                end_pos=len(content),
            )
            return [(content, checksum, metadata)]

        # Step 1: Split by headers
        header_results = self.header_chunker.chunk_with_checksums(content)

        all_results = []
        global_chunk_index = 0

        # Step 2: Process each header section
        for section_text, _, section_metadata in header_results:
            section_headers = section_metadata.headers

            if len(section_text) <= self.chunk_size:
                # Section is small enough, keep as single chunk
                checksum = compute_checksum(section_text)

                metadata = ChunkMetadata(
                    chunk_index=global_chunk_index,
                    chunk_method="header",
                    headers=section_headers.copy(),
                    start_pos=None,
                    end_pos=None,
                )

                all_results.append((section_text, checksum, metadata))
                global_chunk_index += 1

            else:
                # Section too large, apply recursive splitting
                recursive_results = self.recursive_chunker.chunk_with_checksums(section_text)

                for sub_text, sub_checksum, sub_metadata in recursive_results:
                    # Merge metadata from both strategies
                    combined_metadata = ChunkMetadata(
                        chunk_index=global_chunk_index,
                        chunk_method="recursive",
                        headers=section_headers.copy(),  # Preserve header context
                        start_pos=sub_metadata.start_pos,
                        end_pos=sub_metadata.end_pos,
                    )

                    all_results.append((sub_text, sub_checksum, combined_metadata))
                    global_chunk_index += 1

        return all_results
