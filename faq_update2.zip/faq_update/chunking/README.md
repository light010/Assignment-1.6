# Markdown-Aware Content Chunking

Industry-standard chunking strategies for markdown documents, following best practices from LangChain, LlamaIndex, and modern RAG systems (2025).

## Overview

This module provides three production-ready chunking strategies:

1. **RecursiveCharacterChunker** - Semantic boundary-aware splitting
2. **MarkdownHeaderChunker** - Structure-aware splitting by headers
3. **HybridMarkdownChunker** - **RECOMMENDED** combined approach

## Quick Start

### Recommended: Hybrid Markdown Chunker

```python
from chunking import HybridMarkdownChunker

# Initialize with sensible defaults
chunker = HybridMarkdownChunker(
    chunk_size=1000,      # Target chunk size
    chunk_overlap=200,    # Overlap for context
)

# Chunk markdown content
markdown_text = Path("document.md").read_text()
results = chunker.chunk_with_checksums(markdown_text)

for chunk_text, checksum, metadata in results:
    print(f"Chunk {metadata['chunk_index']}")
    print(f"Headers: {metadata['headers']}")
    print(f"Method: {metadata['chunk_method']}")  # 'header' or 'recursive'
    print(f"Checksum: {checksum[:16]}...")
    print(f"Text: {chunk_text[:100]}...\n")
```

## Chunking Strategies

### 1. RecursiveCharacterChunker

**Best for:** General text, mixed content
**Speed:** Fast (no ML models)
**Output:** Semantic boundary-aware chunks

Tries to split on semantic boundaries in order:
1. Paragraphs (`\n\n`)
2. Lines (`\n`)
3. Sentences (`. `)
4. Words (` `)
5. Characters (last resort)

```python
from chunking import RecursiveCharacterChunker

chunker = RecursiveCharacterChunker(
    chunk_size=1000,
    chunk_overlap=200,
    separators=["\n\n", "\n", ". ", " ", ""]  # Default
)

chunks = chunker.chunk(text)
chunks_with_meta = chunker.chunk_with_checksums(text)
```

**Metadata includes:**
- `chunk_index`: Position in sequence
- `start_pos`: Start position in original text
- `end_pos`: End position in original text
- `chunk_method`: Always 'recursive'

### 2. MarkdownHeaderChunker

**Best for:** Well-structured markdown documents
**Speed:** Very fast (regex-based)
**Output:** Structure-aware chunks with header hierarchy

Splits by markdown headers while preserving context:

```python
from chunking import MarkdownHeaderChunker

chunker = MarkdownHeaderChunker(
    headers_to_split_on=[
        ("#", "h1"),
        ("##", "h2"),
        ("###", "h3"),
    ]
)

chunks = chunker.chunk(markdown_text)
chunks_with_meta = chunker.chunk_with_checksums(markdown_text)
```

**Metadata includes:**
- `chunk_index`: Position in sequence
- `headers`: Dict of header hierarchy (e.g., `{"h1": "Chapter", "h2": "Section"}`)
- `chunk_method`: Always 'header'

**Example:**
```markdown
# Introduction

Welcome to the guide.

## Setup

Install the dependencies.

### Prerequisites

- Python 3.11+
- pip
```

Produces chunks with metadata:
- Chunk 0: `headers={"h1": "Introduction"}`
- Chunk 1: `headers={"h1": "Introduction", "h2": "Setup"}`
- Chunk 2: `headers={"h1": "Introduction", "h2": "Setup", "h3": "Prerequisites"}`

### 3. HybridMarkdownChunker (RECOMMENDED)

**Best for:** Production markdown chunking
**Speed:** Fast
**Output:** Best of both worlds

Combines header and recursive strategies:
1. First splits by markdown headers (structure-aware)
2. Then applies recursive splitting within large sections (size-aware)

```python
from chunking import HybridMarkdownChunker

chunker = HybridMarkdownChunker(
    chunk_size=1000,
    chunk_overlap=200,
    headers_to_split_on=[("#", "h1"), ("##", "h2"), ("###", "h3")]
)

chunks_with_meta = chunker.chunk_with_checksums(markdown_text)
```

**Metadata includes:**
- `chunk_index`: Global position
- `headers`: Header hierarchy
- `chunk_method`: 'header' or 'recursive' (how chunk was created)
- `start_pos`, `end_pos`: Positions (for recursive chunks)

## Checksum Computation

All chunkers use centralized SHA-256 checksum computation:

```python
from chunking import compute_checksum

checksum = compute_checksum("Hello world")
# Returns: "64ec88ca00b268e5ba1a...fb23" (64-char hex string)
```

## Best Practices (2025)

### Chunk Size Selection

| Use Case | Recommended Size | Overlap |
|----------|------------------|---------|
| Embedding models (ada-002) | 500-1000 chars | 100-200 |
| Embedding models (text-embedding-3) | 1000-2000 chars | 200-400 |
| LLM context retrieval | 1500-3000 chars | 300-500 |
| Fine-grained search | 500-800 chars | 100-150 |

### Chunk Overlap

- **Why?** Prevents losing context at chunk boundaries
- **Rule of thumb:** 10-20% of chunk_size
- **Too much:** Wastes storage/computation
- **Too little:** Loses context

### Markdown-Specific Considerations

1. **Preserve headers:** Use MarkdownHeaderChunker or HybridMarkdownChunker
2. **Code blocks:** Keep together when possible (HybridMarkdownChunker handles this)
3. **Lists:** Keep items together (RecursiveCharacterChunker respects `\n`)
4. **Tables:** May need custom handling (future enhancement)

## Migration from SimpleChunker (v1.x)

**Old code (v1.x):**
```python
from chunking import SimpleChunker

chunker = SimpleChunker(chunk_size=1000)
chunks = chunker.chunk(text)
chunks_with_checksums = chunker.chunk_with_checksums(text)
```

**New code (v2.0):**
```python
from chunking import HybridMarkdownChunker

chunker = HybridMarkdownChunker(
    chunk_size=1000,
    chunk_overlap=0,  # No overlap for exact SimpleChunker behavior
    headers_to_split_on=[]  # Disable header splitting
)
chunks = chunker.chunk(text)
results = chunker.chunk_with_checksums(text)

# Note: chunk_with_checksums now returns (text, checksum, metadata) tuples
chunks_with_checksums = [(text, checksum) for text, checksum, _ in results]
```

**Breaking Changes:**
- `SimpleChunker` removed
- `chunk_with_checksums()` returns 3-tuple instead of 2-tuple
- Adds metadata with chunk positions and context

**Benefits:**
- Better semantic coherence
- Markdown structure awareness
- Rich metadata for debugging
- Industry-standard algorithms

## Architecture

```
chunking/
├── __init__.py              # Public API exports
├── checksum.py              # Centralized checksum computation
├── recursive.py             # RecursiveCharacterChunker
├── markdown_header.py       # MarkdownHeaderChunker
└── hybrid.py                # HybridMarkdownChunker (recommended)
```

## References

- [LangChain Text Splitters](https://python.langchain.com/docs/modules/data_connection/document_transformers/)
- [LlamaIndex Node Parsers](https://docs.llamaindex.ai/en/stable/module_guides/loading/node_parsers/)
- [Chunking Strategies for RAG (Pinecone)](https://www.pinecone.io/learn/chunking-strategies/)
- [Weaviate Chunking Best Practices](https://weaviate.io/blog/chunking-strategies-for-rag)

## Testing

Comprehensive test coverage in `tests/test_chunking.py` (39 tests):

```bash
pytest tests/test_chunking.py -v
```

## Version History

- **v2.0.0** (2025-10-31): Industry-standard markdown chunking
  - Added RecursiveCharacterChunker
  - Added MarkdownHeaderChunker
  - Added HybridMarkdownChunker (recommended)
  - Removed SimpleChunker (breaking change)
  - Centralized checksum computation

- **v1.0.0**: Simple fixed-size chunking (deprecated)
