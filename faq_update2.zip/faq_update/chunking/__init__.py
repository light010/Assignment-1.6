"""
Markdown-Aware Content Chunking Module

Industry-standard chunking strategies for markdown documents, following best practices
from LangChain, LlamaIndex, and modern RAG systems (2025).

Key Features:
- Structure-aware: Respects markdown headers, paragraphs, code blocks
- Semantic boundaries: Uses recursive splitting with smart separators
- Embedding-friendly: Creates coherent chunks suitable for vector embeddings
- Deterministic: Same input always produces same output
- Production-ready: Battle-tested strategies from tech giants

Chunkers:
- RecursiveCharacterChunker: Semantic boundary-aware splitting with overlap
- MarkdownHeaderChunker: Structure-aware splitting by markdown headers
- HybridMarkdownChunker: Combined approach (RECOMMENDED for production)

Note: compute_checksum has been moved to utility module. Import from utility instead:
  from utility import compute_checksum

Author: Analytics Assist Team
Date: 2025-10-31
Version: 3.0.0 (Breaking changes: compute_checksum moved to utility module)
"""

from chunking.recursive import RecursiveCharacterChunker
from chunking.markdown_header import MarkdownHeaderChunker
from chunking.hybrid import HybridMarkdownChunker

__all__ = [
    "RecursiveCharacterChunker",
    "MarkdownHeaderChunker",
    "HybridMarkdownChunker",
]

__version__ = "3.0.0"
