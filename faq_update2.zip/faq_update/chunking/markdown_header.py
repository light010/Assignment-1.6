"""
Markdown Header-Based Chunker.

Implements structure-aware chunking that respects markdown document hierarchy.
Splits content by markdown headers (H1, H2, H3, etc.) while preserving header
context in metadata.

Based on LangChain's MarkdownHeaderTextSplitter approach.
"""

import re
from typing import List, Tuple, Dict, Any
from utility import compute_checksum
from core import IChunker, ChunkMetadata


class MarkdownHeaderChunker(IChunker):
    """
    Markdown header-aware chunker that respects document structure.

    Splits markdown by headers while preserving hierarchical context.
    Each chunk includes metadata about its position in the header hierarchy.

    Best for: Markdown documents with clear structure
    Performance: Very fast (regex-based)
    Output: Structure-aware chunks with header metadata

    Example:
        >>> chunker = MarkdownHeaderChunker(headers_to_split_on=[("#", "h1"), ("##", "h2")])
        >>> chunks = chunker.chunk(markdown_content)
        >>> chunks_with_meta = chunker.chunk_with_checksums(markdown_content)
    """

    def __init__(
        self,
        headers_to_split_on: List[Tuple[str, str]] = None,
        return_each_line: bool = False,
    ):
        """
        Initialize markdown header chunker.

        Args:
            headers_to_split_on: List of (markdown_header, header_name) tuples
                                Default: [("#", "h1"), ("##", "h2"), ("###", "h3")]
            return_each_line: If True, return each line as separate chunk (rarely used)
        """
        if headers_to_split_on is None:
            self.headers_to_split_on = [
                ("#", "h1"),
                ("##", "h2"),
                ("###", "h3"),
            ]
        else:
            self.headers_to_split_on = headers_to_split_on

        self.return_each_line = return_each_line

        # Create sorted version for matching (longest first to avoid sub-patterns)
        # But keep original order in headers_to_split_on for external access
        self._sorted_headers = sorted(
            self.headers_to_split_on,
            key=lambda x: len(x[0]),
            reverse=True
        )

    def chunk(self, content: str) -> List[str]:
        """
        Split markdown content by headers.

        Args:
            content: Markdown text content

        Returns:
            List of text chunks (one per section)

        Example:
            >>> chunker = MarkdownHeaderChunker()
            >>> markdown = "# Title\\nContent\\n## Section\\nMore content"
            >>> chunks = chunker.chunk(markdown)
            >>> len(chunks)
            2
        """
        if not content:
            return []

        # Early exit: if no headers present, no splitting needed
        has_headers = any(
            marker in content
            for marker, _ in self.headers_to_split_on
        )
        if not has_headers:
            return [content]

        # Parse markdown into sections
        sections = self._parse_markdown_sections(content)

        # Extract just the text
        return [section["content"] for section in sections]

    def chunk_with_checksums(self, content: str) -> List[Tuple[str, str, ChunkMetadata]]:
        """
        Split markdown content with checksums and header metadata.

        Args:
            content: Markdown text content

        Returns:
            List of (chunk_text, checksum, metadata) tuples where metadata is
            a ChunkMetadata dataclass containing:
            - chunk_index: Position in sequence
            - headers: Dict of header hierarchy (e.g., {"h1": "Title", "h2": "Section"})
            - chunk_method: Always 'header'
            - start_pos/end_pos: None (header chunking doesn't track positions)

        Example:
            >>> chunker = MarkdownHeaderChunker()
            >>> results = chunker.chunk_with_checksums("# Title\\nContent")
            >>> chunk_text, checksum, metadata = results[0]
            >>> metadata.headers
            {'h1': 'Title'}
        """
        if not content:
            return []

        sections = self._parse_markdown_sections(content)

        results = []
        for idx, section in enumerate(sections):
            chunk_text = section["content"]
            checksum = compute_checksum(chunk_text)

            metadata = ChunkMetadata(
                chunk_index=idx,
                chunk_method="header",
                headers=section["headers"].copy(),
                start_pos=None,
                end_pos=None,
            )

            results.append((chunk_text, checksum, metadata))

        return results

    def _parse_markdown_sections(self, content: str) -> List[Dict[str, Any]]:
        """
        Parse markdown into sections based on headers.

        Args:
            content: Markdown text

        Returns:
            List of section dictionaries with 'content' and 'headers'
        """
        lines = content.split("\n")

        sections = []
        current_section_lines = []
        current_headers = {}

        for line in lines:
            # Check if this line is a header
            header_match = self._match_header(line)

            if header_match:
                # Save previous section if it has content
                if current_section_lines:
                    section_content = "\n".join(current_section_lines)
                    sections.append({
                        "content": section_content,
                        "headers": current_headers.copy(),
                    })
                    current_section_lines = []

                # Update header hierarchy
                header_level, header_name, header_text = header_match
                current_headers = self._update_header_hierarchy(
                    current_headers,
                    header_level,
                    header_text
                )

                # Include header in next section
                current_section_lines.append(line)
            else:
                # Regular content line
                current_section_lines.append(line)

        # Add final section
        if current_section_lines:
            section_content = "\n".join(current_section_lines)
            sections.append({
                "content": section_content,
                "headers": current_headers.copy(),
            })

        # If no headers found, return entire content as single section
        if not sections:
            sections.append({
                "content": content,
                "headers": {},
            })

        return sections

    def _match_header(self, line: str) -> Tuple[str, str, str]:
        """
        Check if line is a markdown header.

        Args:
            line: Line of text

        Returns:
            (header_level, header_name, header_text) or None if not a header
        """
        line = line.strip()

        # Use sorted headers for matching (longest first to avoid sub-pattern matches)
        for header_marker, header_name in self._sorted_headers:
            # Match header pattern: "### Header Text" -> extract "Header Text"
            pattern = rf"^{re.escape(header_marker)}\s+(.+)$"
            match = re.match(pattern, line)

            if match:
                header_text = match.group(1).strip()
                return (header_marker, header_name, header_text)

        return None

    def _update_header_hierarchy(
        self,
        current_headers: Dict[str, str],
        new_header_level: str,
        new_header_text: str
    ) -> Dict[str, str]:
        """
        Update header hierarchy when encountering a new header.

        When we see a new header, we need to:
        1. Set that header level
        2. Clear all deeper levels (e.g., seeing H2 clears H3, H4, etc.)

        Args:
            current_headers: Current header state
            new_header_level: The markdown marker ("#", "##", etc.)
            new_header_text: The header text

        Returns:
            Updated headers dict
        """
        # Create mapping of header level to name
        level_to_name = {marker: name for marker, name in self.headers_to_split_on}

        new_header_name = level_to_name.get(new_header_level)
        if not new_header_name:
            return current_headers

        # Determine depth of new header
        new_depth = len(new_header_level)

        # Clear headers at this level and deeper
        updated_headers = {}
        for marker, name in self.headers_to_split_on:
            depth = len(marker)

            if depth < new_depth:
                # Keep shallower headers
                if name in current_headers:
                    updated_headers[name] = current_headers[name]
            elif depth == new_depth:
                # Set this header
                updated_headers[name] = new_header_text
            # else: Clear deeper headers (don't copy them)

        return updated_headers
