#!/usr/bin/env python
"""
Create database for granular impact analysis.

Supports multiple database backends:
- SQLite (local development/testing)
- Databricks (production)

NOTE: For most use cases, use the simpler auto-detection approach:
    from database.setup import quick_setup
    db = quick_setup()

This script is for manual configuration and CI/CD pipelines.

Usage:
    # SQLite (default)
    python create_database.py

    # SQLite with custom path
    python create_database.py --sqlite --path data/my_database.db

    # Databricks
    python create_database.py --databricks --catalog my_catalog --schema my_schema

    # Dry-run (see what would be created without executing)
    python create_database.py --dry-run
"""

import argparse
import sys
from pathlib import Path

# Ensure imports work from FAQ_update directory (parent of database/)
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configuration paths (configurable, not hardcoded)
DEFAULT_SCHEMA_DIR = Path(__file__).parent / "sql" / "schema"
DEFAULT_DEPENDENCY_GRAPH_PATH = Path(__file__).parent / "sql" / "schema" / "_meta" / "dependency_graph.yaml"

from database import (
    DatabaseDialect,
    create_adapter,
    SchemaManager,
)


def create_sqlite_database(
    db_path: str, 
    dry_run: bool = False,
    schema_dir: Path = DEFAULT_SCHEMA_DIR,
    dependency_graph_path: Path = DEFAULT_DEPENDENCY_GRAPH_PATH
) -> int:
    """
    Create SQLite database.

    Args:
        db_path: Path to database file
        dry_run: If True, show what would be created without executing

    Returns:
        Exit code (0 = success, 1 = failure)
    """
    db_file = Path(db_path)
    db_file.parent.mkdir(parents=True, exist_ok=True)

    # Check if database already exists
    if db_file.exists() and not dry_run:
        print(f"⚠️  Database already exists at: {db_file}")
        print(f"   Size: {db_file.stat().st_size / 1024:.1f} KB")
        print()
        response = input("Overwrite existing database? (yes/no): ").strip().lower()
        if response != 'yes':
            print("❌ Cancelled. Database not modified.")
            return 1
        print()
        db_file.unlink()
        print("🗑️  Deleted existing database")

    # Create adapter
    print(f"📁 Database path: {db_file.absolute()}")
    print(f"🔧 Dialect: SQLite")
    print()

    adapter = create_adapter(
        DatabaseDialect.SQLITE,
        database_path=str(db_path)
    )

    # Create schema
    print("📊 Creating schema (7 tables)...")
    print()
    manager = SchemaManager(
        adapter=adapter,
        schema_dir=schema_dir,
        dependency_graph_path=dependency_graph_path
    )
    manager.create_schema(dry_run=dry_run)

    if dry_run:
        print()
        print("✅ Dry-run completed (no changes made)")
        adapter.close()
        return 0

    # Validate
    print()
    print("✅ Validating schema...")
    result = manager.validate_schema()

    if not result.is_valid:
        print("❌ Schema validation failed!")
        print(result)
        adapter.close()
        return 1

    # List tables
    tables = adapter.fetchall(
        "SELECT name FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
        "ORDER BY name"
    )

    adapter.close()

    # Success summary
    file_size_kb = db_file.stat().st_size / 1024
    print()
    print("=" * 70)
    print("✅ SQLITE DATABASE CREATED SUCCESSFULLY!")
    print("=" * 70)
    print()
    print(f"📁 Location: {db_file.absolute()}")
    print(f"📊 Size: {file_size_kb:.1f} KB")
    print()
    print(f"📋 Tables Created ({len(tables)}):")
    for table in tables:
        print(f"   ✓ {table[0]}")
    print()

    return 0


def enable_databricks_features(adapter, dry_run: bool = False):
    """
    Enable required Databricks table features for schema creation.
    
    Note: The primary enablement of allowColumnDefaults happens at the table level
    via TBLPROPERTIES in the CREATE TABLE statements. This function provides
    session-level configuration as additional support.
    
    Args:
        adapter: Databricks adapter
        dry_run: If True, show what would be configured without executing
    """
    from loguru import logger
    
    # Enable allowColumnDefaults feature for DEFAULT values support
    config_sql = "SET spark.databricks.delta.properties.defaults.allowColumnDefaults = true"
    
    if dry_run:
        logger.info("[DRY RUN] Would configure: Enable allowColumnDefaults feature (session-level)")
        logger.debug(f"SQL: {config_sql}")
    else:
        logger.info("🔧 Configuring Databricks: Enable allowColumnDefaults feature (session-level)")
        try:
            adapter.execute(config_sql)
            logger.success("✅ Databricks session configuration completed")
        except Exception as e:
            logger.info(f"⚠️  Session config not applied: {e}")
        
        logger.info("✅ Table-level allowColumnDefaults will be set via TBLPROPERTIES")


def create_databricks_database(
    catalog: str, 
    schema: str, 
    dry_run: bool = False,
    schema_dir: Path = DEFAULT_SCHEMA_DIR,
    dependency_graph_path: Path = DEFAULT_DEPENDENCY_GRAPH_PATH
) -> int:
    """
    Create Databricks database.

    Args:
        catalog: Unity Catalog name
        schema: Database schema name
        dry_run: If True, show what would be created without executing

    Returns:
        Exit code (0 = success, 1 = failure)
    """
    print(f"📁 Catalog: {catalog}")
    print(f"📁 Schema: {schema}")
    print(f"🔧 Dialect: Databricks Unity Catalog")
    print()

    try:
        # Create adapter
        adapter = create_adapter(
            DatabaseDialect.DATABRICKS,
            catalog=catalog,
            schema=schema
        )

        # Configure Databricks features for DEFAULT values support
        enable_databricks_features(adapter, dry_run=dry_run)
        print()

        # Create schema
        print("📊 Creating schema (7 tables)...")
        print()
        manager = SchemaManager(
            adapter=adapter,
            schema_dir=schema_dir,
            dependency_graph_path=dependency_graph_path
        )
        manager.create_schema(dry_run=dry_run)

        if dry_run:
            print()
            print("✅ Dry-run completed (no changes made)")
            return 0

        # Validate (skip for now - Databricks validation not fully implemented)
        print()
        print("✅ Schema creation completed")
        print()
        print("=" * 70)
        print("✅ DATABRICKS DATABASE CREATED SUCCESSFULLY!")
        print("=" * 70)
        print()
        print(f"📁 Catalog: {catalog}")
        print(f"📁 Schema: {schema}")
        print(f"📋 Tables: 7 created")
        print()
        print("Verify with:")
        print(f"   USE CATALOG {catalog};")
        print(f"   USE SCHEMA {schema};")
        print(f"   SHOW TABLES;")
        print()

        return 0

    except ImportError:
        print("❌ Error: PySpark not installed")
        print()
        print("Databricks requires PySpark. Install with:")
        print("   pip install pyspark")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Create database for granular impact analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # SQLite (default - creates databases/granular_impact.db)
  python create_database.py

  # SQLite with custom path
  python create_database.py --sqlite --path data/my_db.db

  # Databricks
  python create_database.py --databricks --catalog prod --schema faq

  # Dry-run (preview without creating)
  python create_database.py --dry-run
        """
    )

    # Database type
    db_type = parser.add_mutually_exclusive_group()
    db_type.add_argument(
        '--sqlite',
        action='store_true',
        help='Create SQLite database (default)'
    )
    db_type.add_argument(
        '--databricks',
        action='store_true',
        help='Create Databricks database'
    )

    # SQLite options
    parser.add_argument(
        '--path',
        type=str,
        default='databases/granular_impact.db',
        help='SQLite database file path (default: databases/granular_impact.db)'
    )

    # Databricks options
    parser.add_argument(
        '--catalog',
        type=str,
        help='Databricks Unity Catalog name (required for --databricks)'
    )
    parser.add_argument(
        '--schema',
        type=str,
        help='Databricks schema name (required for --databricks)'
    )

    # Schema configuration options
    parser.add_argument(
        '--schema-dir',
        type=Path,
        default=DEFAULT_SCHEMA_DIR,
        help=f'Path to schema directory (default: {DEFAULT_SCHEMA_DIR})'
    )
    parser.add_argument(
        '--dependency-graph',
        type=Path,
        default=DEFAULT_DEPENDENCY_GRAPH_PATH,
        help=f'Path to dependency graph YAML file (default: {DEFAULT_DEPENDENCY_GRAPH_PATH})'
    )

    # Common options
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Show what would be created without executing'
    )

    args = parser.parse_args()

    # Determine database type
    if args.databricks:
        # Databricks mode
        if not args.catalog or not args.schema:
            parser.error("--databricks requires --catalog and --schema")

        print("=" * 70)
        print("CREATE DATABRICKS DATABASE")
        print("=" * 70)
        print()

        return create_databricks_database(
            catalog=args.catalog,
            schema=args.schema,
            dry_run=args.dry_run,
            schema_dir=args.schema_dir,
            dependency_graph_path=args.dependency_graph
        )
    else:
        # SQLite mode (default)
        print("=" * 70)
        print("CREATE SQLITE DATABASE")
        print("=" * 70)
        print()

        return create_sqlite_database(
            db_path=args.path,
            dry_run=args.dry_run,
            schema_dir=args.schema_dir,
            dependency_graph_path=args.dependency_graph
        )


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n❌ Interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
