"""
Content Repository - Database operations for content_repo and content_chunks tables

This module provides the ContentRepository class for managing content and chunks.
It follows the Repository Pattern to keep business logic separate from database implementation.

Responsibilities:
    - File ingestion (single and bulk)
    - Chunk ingestion and management
    - File and chunk retrieval
    - Status updates
    - Statistics and aggregations
    - Foreign key validation (application-level)

Design Principles:
    - Single Responsibility: Only content and chunk operations
    - Database-Agnostic: Works with SQLite, Databricks, or any IBackend
    - Validation: Enforces business rules before database operations
    - Transaction Safety: Uses transactions for multi-step operations
    - Idempotency: Safe to retry operations

Tables Managed:
    - content_repo: Source files and metadata
    - content_chunks: Individual content chunks with checksums

Example Usage:
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Create backend and repository
    >>> config = DatabaseConfig.from_env()
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = ContentRepository(backend)
    >>>
    >>> # Get file by name
    >>> file = repo.get_file_by_name("policy.pdf")
    >>> print(file.ud_source_file_id)
    >>>
    >>> # Ingest files in bulk
    >>> df = pd.DataFrame({
    ...     'raw_file_nme': ['file1.pdf', 'file2.pdf'],
    ...     'file_status': ['Active', 'Active']
    ... })
    >>> result = repo.ingest_files_bulk(df)
    >>> print(result['rows_inserted'])

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import pandas as pd

from database.repository.base import (
    BaseRepository,
    RepositoryError,
    QueryError,
    DataValidationError,
)
from database.models import (
    ContentRepo,
    FileStatus,
    ValidationError,
)
from database.backends.base import IBackend
from utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Content Repository Exceptions
# =============================================================================


class ContentRepositoryError(RepositoryError):
    """Base exception for content repository errors."""
    pass


class FileNotFoundError(ContentRepositoryError):
    """Raised when file cannot be found."""
    pass


class ChunkNotFoundError(ContentRepositoryError):
    """Raised when chunk cannot be found."""
    pass


class DuplicateFileError(ContentRepositoryError):
    """Raised when attempting to insert duplicate file."""
    pass


class ForeignKeyViolationError(ContentRepositoryError):
    """Raised when foreign key constraint would be violated."""
    pass


# =============================================================================
# Content Repository Implementation
# =============================================================================


class ContentRepository(BaseRepository[ContentRepo]):
    """
    Repository for content_repo and content_chunks tables.

    Provides database-agnostic operations for:
    - File management (CRUD)
    - Chunk management (CRUD)
    - Statistics and reporting
    - Foreign key validation

    All methods handle both SQLite and Databricks transparently via IBackend interface.

    Attributes:
        backend: Database backend instance (IBackend)
        logger: Logger instance for this repository

    Example:
        >>> repo = ContentRepository(backend)
        >>>
        >>> # Retrieve file
        >>> file = repo.get_file_by_name("handbook.pdf")
        >>> if file:
        ...     print(f"Found file with ID: {file['ud_source_file_id']}")
        >>>
        >>> # Ingest files
        >>> files_df = pd.DataFrame(...)
        >>> result = repo.ingest_files_bulk(files_df)
        >>> print(f"Inserted {result['rows_inserted']} files")
    """

    def __init__(self, backend: IBackend, **kwargs):
        """
        Initialize ContentRepository.

        Args:
            backend: Database backend (SQLite, Databricks, etc.)
            **kwargs: Additional arguments passed to BaseRepository

        Example:
            >>> backend = SQLiteBackend(db_path="faq.db")
            >>> repo = ContentRepository(backend)
        """
        super().__init__(backend, **kwargs)
        self._logger = get_logger(f"{self.__class__.__name__}")

    # =========================================================================
    # Helper Methods for Chunk Metadata (Phase 8)
    # =========================================================================

    @staticmethod
    def parse_chunk_headers(chunk_headers_json: Optional[str]) -> Dict[str, str]:
        """
        Parse JSON headers string from database into dictionary.

        Helper method to convert stored JSON metadata into usable format.

        Args:
            chunk_headers_json: JSON string like '{"h1": "Title", "h2": "Section"}'

        Returns:
            Dictionary of headers, or empty dict if None/invalid

        Example:
            >>> headers_json = '{"h1": "Introduction", "h2": "Overview"}'
            >>> headers = ContentRepository.parse_chunk_headers(headers_json)
            >>> headers
            {'h1': 'Introduction', 'h2': 'Overview'}
            >>>
            >>> # Handle None gracefully
            >>> ContentRepository.parse_chunk_headers(None)
            {}
        """
        if not chunk_headers_json:
            return {}

        try:
            import json
            return json.loads(chunk_headers_json)
        except (json.JSONDecodeError, TypeError) as e:
            logger.warning(f"Failed to parse chunk_headers JSON: {e}")
            return {}

    # =========================================================================
    # File Retrieval Operations (Points 87-89)
    # =========================================================================

    def get_file_by_name(
        self,
        file_name: str,
        version: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get file from content_repo by filename.

        Point 87 in migration plan.

        Args:
            file_name: Name of the file (raw_file_nme)
            version: Optional version number (default: latest version)

        Returns:
            Dictionary with file data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If file_name is empty

        Example:
            >>> file = repo.get_file_by_name("policy.pdf")
            >>> if file:
            ...     print(f"File ID: {file['ud_source_file_id']}")
            ...     print(f"Status: {file['file_status']}")
            >>>
            >>> # Get specific version
            >>> file_v2 = repo.get_file_by_name("policy.pdf", version=2)
        """
        # Validation
        if not file_name or not file_name.strip():
            raise ValueError("file_name cannot be empty")

        self._logger.debug(f"Retrieving file: {file_name} (version: {version or 'latest'})")

        try:
            if version is not None:
                # Get specific version
                query = """
                    SELECT * FROM content_repo
                    WHERE raw_file_nme = ?
                    AND raw_file_version_nbr = ?
                """
                result = self.execute_query_single(query, (file_name, version))
            else:
                # Get latest version
                query = """
                    SELECT * FROM content_repo
                    WHERE raw_file_nme = ?
                    ORDER BY raw_file_version_nbr DESC
                    LIMIT 1
                """
                result = self.execute_query_single(query, (file_name,))

            if result:
                self._logger.debug(f"Found file: {file_name} with ID {result['ud_source_file_id']}")
            else:
                self._logger.debug(f"File not found: {file_name}")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get file by name '{file_name}': {e}")
            raise QueryError(f"Failed to retrieve file '{file_name}': {e}") from e

    def get_file_by_id(self, file_id: int) -> Optional[Dict[str, Any]]:
        """
        Get file from content_repo by ID.

        Point 88 in migration plan.

        Args:
            file_id: File ID (ud_source_file_id)

        Returns:
            Dictionary with file data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If file_id is invalid

        Example:
            >>> file = repo.get_file_by_id(42)
            >>> if file:
            ...     print(f"File name: {file['raw_file_nme']}")
            ...     print(f"Version: {file['raw_file_version_nbr']}")
        """
        # Validation - accept both Python int and numpy integer types
        try:
            file_id = int(file_id)  # Convert numpy.int64 to Python int
            if file_id <= 0:
                raise ValueError(f"file_id must be positive, got {file_id}")
        except (TypeError, ValueError) as e:
            raise ValueError(f"file_id must be a positive integer, got {file_id} (type: {type(file_id)})") from e

        self._logger.debug(f"Retrieving file by ID: {file_id}")

        try:
            query = "SELECT * FROM content_repo WHERE ud_source_file_id = ?"
            result = self.execute_query_single(query, (file_id,))

            if result:
                self._logger.debug(f"Found file ID {file_id}: {result['raw_file_nme']}")
            else:
                self._logger.debug(f"File ID not found: {file_id}")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get file by ID {file_id}: {e}")
            raise QueryError(f"Failed to retrieve file ID {file_id}: {e}") from e

    def list_files(
        self,
        status: Optional[str] = None,
        file_type: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        order_by: str = "created_dt DESC"
    ) -> List[Dict[str, Any]]:
        """
        List files with optional filtering.

        Point 89 in migration plan.

        Args:
            status: Optional file status filter (Active, Inactive, Archived)
            file_type: Optional file type filter (pdf, html, etc.)
            limit: Maximum number of results
            offset: Number of results to skip (for pagination)
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with file data

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all active files
            >>> files = repo.list_files(status="Active")
            >>> print(f"Found {len(files)} active files")
            >>>
            >>> # Get first 10 PDF files
            >>> pdfs = repo.list_files(file_type="pdf", limit=10)
            >>>
            >>> # Pagination (page 2, 20 items per page)
            >>> page_2 = repo.list_files(limit=20, offset=20)
        """
        self._logger.debug(
            f"Listing files (status={status}, type={file_type}, "
            f"limit={limit}, offset={offset})"
        )

        try:
            # Build query dynamically based on filters
            query_parts = ["SELECT * FROM content_repo"]
            where_clauses = []
            params = []

            # Add filters
            if status:
                where_clauses.append("file_status = ?")
                params.append(status)

            if file_type:
                where_clauses.append("raw_file_type = ?")
                params.append(file_type)

            # Add WHERE clause if filters exist
            if where_clauses:
                query_parts.append("WHERE " + " AND ".join(where_clauses))

            # Add ORDER BY
            query_parts.append(f"ORDER BY {order_by}")

            # Add LIMIT and OFFSET
            if limit is not None:
                query_parts.append(f"LIMIT {limit}")
            if offset is not None:
                query_parts.append(f"OFFSET {offset}")

            query = " ".join(query_parts)

            results = self.execute_query(query, tuple(params) if params else None)

            self._logger.debug(f"Found {len(results)} files")
            return results

        except Exception as e:
            self._logger.error(f"Failed to list files: {e}")
            raise QueryError(f"Failed to list files: {e}") from e

    def get_files_modified_after(
        self,
        since_date: str,
        status: str = "Active",
        order_by: str = "last_modified_dt DESC"
    ) -> List[Dict[str, Any]]:
        """
        Get files modified after a specific date.

        Useful for change detection workflows - finds files that have been
        modified since a given timestamp.

        Args:
            since_date: Date/timestamp string (format: 'YYYY-MM-DD HH:MM:SS' or 'YYYY-MM-DD')
            status: File status filter (default: "Active")
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with file data for files modified after since_date

        Raises:
            QueryError: If query execution fails
            ValueError: If since_date is empty

        Example:
            >>> # Get all files modified since a specific date
            >>> files = repo.get_files_modified_after("2025-10-27 17:41:10")
            >>> print(f"Found {len(files)} modified files")
            >>>
            >>> # Get all files (including inactive) modified since date
            >>> all_files = repo.get_files_modified_after(
            ...     "2025-10-27",
            ...     status=None
            ... )
        """
        # Validation
        if not since_date or not since_date.strip():
            raise ValueError("since_date cannot be empty")

        self._logger.debug(
            f"Retrieving files modified after '{since_date}' "
            f"(status={status})"
        )

        try:
            # Build query with optional status filter
            if status:
                query = f"""
                    SELECT *
                    FROM content_repo
                    WHERE last_modified_dt > ?
                    AND file_status = ?
                    ORDER BY {order_by}
                """
                params = (since_date, status)
            else:
                query = f"""
                    SELECT *
                    FROM content_repo
                    WHERE last_modified_dt > ?
                    ORDER BY {order_by}
                """
                params = (since_date,)

            results = self.execute_query(query, params)

            self._logger.debug(
                f"Found {len(results)} files modified after '{since_date}'"
            )
            return results

        except Exception as e:
            self._logger.error(
                f"Failed to get files modified after '{since_date}': {e}"
            )
            raise QueryError(
                f"Failed to retrieve files modified after '{since_date}': {e}"
            ) from e

    # =========================================================================
    # File Ingestion Operations (Points 90-91)
    # =========================================================================

    def ingest_file(
        self,
        file_name: str,
        file_type: Optional[str] = None,
        file_path: Optional[str] = None,
        extracted_markdown_path: Optional[str] = None,
        title: Optional[str] = None,
        status: str = "Active",
        version: int = 1,
        validate: bool = True
    ) -> int:
        """
        Insert single file into content_repo.

        Point 90 in migration plan.

        Args:
            file_name: Name of the file (required)
            file_type: File type (pdf, html, etc.)
            file_path: Path to raw file
            extracted_markdown_path: Path to extracted markdown
            title: Human-readable title
            status: File status (Active, Inactive, Archived)
            version: Version number (default: 1)
            validate: Validate data before insert (default: True)

        Returns:
            ID of inserted file (ud_source_file_id)

        Raises:
            DataValidationError: If validation fails
            QueryError: If insert fails
            DuplicateFileError: If file with same name and version exists

        Example:
            >>> file_id = repo.ingest_file(
            ...     file_name="handbook.pdf",
            ...     file_type="pdf",
            ...     file_path="/data/handbook.pdf",
            ...     status="Active"
            ... )
            >>> print(f"Inserted file with ID: {file_id}")
        """
        self._logger.info(f"Ingesting single file: {file_name} (version {version})")

        # Validation
        if validate:
            if not file_name or not file_name.strip():
                raise DataValidationError("file_name is required and cannot be empty")

            if version < 1:
                raise DataValidationError(f"version must be >= 1, got {version}")

            # Validate status if provided
            if status:
                try:
                    FileStatus(status)
                except ValueError:
                    valid_statuses = [s.value for s in FileStatus]
                    raise DataValidationError(
                        f"Invalid status '{status}'. Must be one of: {valid_statuses}"
                    )

            # Check for duplicate (same name + version)
            existing = self.get_file_by_name(file_name, version)
            if existing:
                raise DuplicateFileError(
                    f"File '{file_name}' version {version} already exists "
                    f"with ID {existing['ud_source_file_id']}"
                )

        try:
            # Prepare INSERT command
            command = """
                INSERT INTO content_repo (
                    raw_file_nme,
                    raw_file_type,
                    raw_file_version_nbr,
                    raw_file_path,
                    extracted_markdown_file_path,
                    title_nme,
                    file_status,
                    created_dt,
                    last_modified_dt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """

            now = datetime.now()
            params = (
                file_name,
                file_type,
                version,
                file_path,
                extracted_markdown_path,
                title,
                status,
                now,
                now
            )

            # Execute insert
            with self.transaction():
                file_id = self.execute_insert(command, params)

            self._logger.info(f"Successfully inserted file '{file_name}' with ID {file_id}")
            return file_id

        except DuplicateFileError:
            raise
        except Exception as e:
            self._logger.error(f"Failed to ingest file '{file_name}': {e}")
            raise QueryError(f"Failed to ingest file '{file_name}': {e}") from e

    def ingest_files_bulk(
        self,
        files_df: pd.DataFrame,
        validate: bool = True,
        if_exists: str = "append"
    ) -> Dict[str, Any]:
        """
        Bulk insert files into content_repo.

        Point 91 in migration plan.

        Args:
            files_df: DataFrame with file data
            validate: Validate data before insert (default: True)
            if_exists: What to do if data exists:
                - 'append': Insert new rows (default)
                - 'replace': Drop and recreate table (dangerous!)
                - 'fail': Raise error if table has data

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - errors (List[str], optional): Validation errors if any

        Raises:
            DataValidationError: If validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - raw_file_nme (required)

        Optional DataFrame Columns:
            - raw_file_type
            - raw_file_version_nbr (default: 1)
            - raw_file_path
            - extracted_markdown_file_path
            - title_nme
            - file_status (default: "Active")
            - created_dt (default: now)
            - last_modified_dt (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'raw_file_nme': ['file1.pdf', 'file2.html'],
            ...     'raw_file_type': ['pdf', 'html'],
            ...     'file_status': ['Active', 'Active']
            ... })
            >>> result = repo.ingest_files_bulk(df)
            >>> print(f"Success: {result['success']}")
            >>> print(f"Inserted: {result['rows_inserted']} rows")
        """
        self._logger.info(f"Ingesting {len(files_df)} files in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if files_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            if 'raw_file_nme' not in files_df.columns:
                errors.append("Missing required column: raw_file_nme")

            # Validate raw_file_nme values
            if 'raw_file_nme' in files_df.columns:
                empty_names = files_df['raw_file_nme'].isna() | (files_df['raw_file_nme'].str.strip() == '')
                if empty_names.any():
                    count = empty_names.sum()
                    errors.append(f"{count} rows have empty raw_file_nme")

            # Validate file_status if present
            if 'file_status' in files_df.columns:
                valid_statuses = {s.value for s in FileStatus}
                invalid_statuses = ~files_df['file_status'].isna() & \
                                 ~files_df['file_status'].isin(valid_statuses)
                if invalid_statuses.any():
                    invalid_values = files_df.loc[invalid_statuses, 'file_status'].unique()
                    errors.append(
                        f"Invalid file_status values: {list(invalid_values)}. "
                        f"Must be one of: {list(valid_statuses)}"
                    )

            # Validate version numbers if present
            if 'raw_file_version_nbr' in files_df.columns:
                invalid_versions = files_df['raw_file_version_nbr'] < 1
                if invalid_versions.any():
                    count = invalid_versions.sum()
                    errors.append(f"{count} rows have invalid version numbers (< 1)")

            # If validation errors, return error result
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

        # Prepare DataFrame for ingestion
        df_prepared = files_df.copy()

        # Add default columns if missing
        now = datetime.now()

        if 'raw_file_version_nbr' not in df_prepared.columns:
            df_prepared['raw_file_version_nbr'] = 1

        if 'file_status' not in df_prepared.columns:
            df_prepared['file_status'] = 'Active'

        if 'created_dt' not in df_prepared.columns:
            df_prepared['created_dt'] = now

        if 'last_modified_dt' not in df_prepared.columns:
            df_prepared['last_modified_dt'] = now

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="content_repo",
                    if_exists=if_exists,
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} files"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest files: {e}")
            raise QueryError(f"Bulk ingestion failed: {e}") from e

    # =========================================================================
    # File Update Operations (Point 92)
    # =========================================================================

    def update_file_status(
        self,
        file_id: int,
        new_status: str,
        validate: bool = True
    ) -> int:
        """
        Update file status in content_repo.

        Point 92 in migration plan.

        Args:
            file_id: File ID (ud_source_file_id)
            new_status: New status value (Active, Inactive, Archived)
            validate: Validate status value (default: True)

        Returns:
            Number of rows updated (should be 1)

        Raises:
            DataValidationError: If validation fails
            FileNotFoundError: If file doesn't exist
            QueryError: If update fails

        Example:
            >>> # Archive a file
            >>> rows = repo.update_file_status(42, "Archived")
            >>> print(f"Updated {rows} file(s)")
            >>>
            >>> # Reactivate a file
            >>> repo.update_file_status(42, "Active")
        """
        self._logger.info(f"Updating file {file_id} status to '{new_status}'")

        # Validation
        if validate:
            # Accept both Python int and numpy integer types
            try:
                file_id = int(file_id)  # Convert numpy.int64 to Python int
                if file_id <= 0:
                    raise ValueError(f"file_id must be positive, got {file_id}")
            except (TypeError, ValueError) as e:
                raise ValueError(f"file_id must be a positive integer, got {file_id} (type: {type(file_id)})") from e

            # Validate status value
            try:
                FileStatus(new_status)
            except ValueError:
                valid_statuses = [s.value for s in FileStatus]
                raise DataValidationError(
                    f"Invalid status '{new_status}'. Must be one of: {valid_statuses}"
                )

            # Check file exists
            file = self.get_file_by_id(file_id)
            if not file:
                raise FileNotFoundError(f"File with ID {file_id} not found")

        try:
            command = """
                UPDATE content_repo
                SET file_status = ?,
                    last_modified_dt = ?
                WHERE ud_source_file_id = ?
            """

            with self.transaction():
                rows_updated = self.execute_command(
                    command,
                    (new_status, datetime.now(), file_id)
                )

            if rows_updated == 0:
                raise FileNotFoundError(f"File with ID {file_id} not found")

            self._logger.info(f"Successfully updated file {file_id} status to '{new_status}'")
            return rows_updated

        except FileNotFoundError:
            raise
        except Exception as e:
            self._logger.error(f"Failed to update file {file_id} status: {e}")
            raise QueryError(f"Failed to update file status: {e}") from e

    # =========================================================================
    # File Statistics (Point 93)
    # =========================================================================

    def get_file_stats(self) -> Dict[str, Any]:
        """
        Get aggregate statistics for content_repo table.

        Point 93 in migration plan.

        Returns:
            Dictionary with statistics:
                - total_files: Total number of files
                - by_status: Count by file status
                - by_type: Count by file type
                - total_versions: Total number of file versions
                - unique_files: Number of unique file names
                - latest_file: Most recently created file

        Raises:
            QueryError: If query execution fails

        Example:
            >>> stats = repo.get_file_stats()
            >>> print(f"Total files: {stats['total_files']}")
            >>> print(f"Active files: {stats['by_status']['Active']}")
            >>> print(f"PDF files: {stats['by_type']['pdf']}")
        """
        self._logger.debug("Calculating file statistics")

        try:
            stats = {}

            # Total files
            result = self.execute_query_single(
                "SELECT COUNT(*) as count FROM content_repo"
            )
            stats['total_files'] = result['count'] if result else 0

            # Count by status
            results = self.execute_query(
                """
                SELECT file_status, COUNT(*) as count
                FROM content_repo
                GROUP BY file_status
                """
            )
            stats['by_status'] = {row['file_status']: row['count'] for row in results}

            # Count by file type
            results = self.execute_query(
                """
                SELECT raw_file_type, COUNT(*) as count
                FROM content_repo
                WHERE raw_file_type IS NOT NULL
                GROUP BY raw_file_type
                """
            )
            stats['by_type'] = {row['raw_file_type']: row['count'] for row in results}

            # Total versions
            result = self.execute_query_single(
                "SELECT SUM(raw_file_version_nbr) as total FROM content_repo"
            )
            stats['total_versions'] = result['total'] if result and result['total'] else 0

            # Unique file names
            result = self.execute_query_single(
                "SELECT COUNT(DISTINCT raw_file_nme) as count FROM content_repo"
            )
            stats['unique_files'] = result['count'] if result else 0

            # Latest file
            result = self.execute_query_single(
                """
                SELECT raw_file_nme, created_dt
                FROM content_repo
                ORDER BY created_dt DESC
                LIMIT 1
                """
            )
            stats['latest_file'] = {
                'name': result['raw_file_nme'] if result else None,
                'created_at': result['created_dt'] if result else None
            }

            self._logger.debug(f"File statistics: {stats['total_files']} total files")
            return stats

        except Exception as e:
            self._logger.error(f"Failed to calculate file statistics: {e}")
            raise QueryError(f"Failed to get file statistics: {e}") from e

    # =========================================================================
    # Foreign Key Validation (Point 94)
    # =========================================================================

    def validate_file_exists(self, file_id: int) -> bool:
        """
        Validate that a file exists in content_repo.

        Point 94 in migration plan - Foreign key validation.

        This is used for application-level FK validation since Databricks
        has limited FK constraint support.

        Args:
            file_id: File ID (ud_source_file_id)

        Returns:
            True if file exists, False otherwise

        Example:
            >>> if repo.validate_file_exists(42):
            ...     print("File exists, safe to create chunks")
            ... else:
            ...     raise ValueError("Cannot create chunks for non-existent file")
        """
        try:
            result = self.execute_query_single(
                "SELECT 1 FROM content_repo WHERE ud_source_file_id = ?",
                (file_id,)
            )
            return result is not None
        except Exception as e:
            self._logger.error(f"Failed to validate file {file_id}: {e}")
            return False

    def validate_file_ids(self, file_ids: List[int]) -> Tuple[List[int], List[int]]:
        """
        Validate multiple file IDs at once.

        Point 94 in migration plan - Batch FK validation.

        Args:
            file_ids: List of file IDs to validate

        Returns:
            Tuple of (valid_ids, invalid_ids)

        Example:
            >>> valid, invalid = repo.validate_file_ids([1, 2, 3, 999])
            >>> print(f"Valid: {valid}")
            >>> print(f"Invalid: {invalid}")
            >>> if invalid:
            ...     raise ValueError(f"Invalid file IDs: {invalid}")
        """
        if not file_ids:
            return [], []

        try:
            # Query for all IDs in one go
            placeholders = ','.join(['?'] * len(file_ids))
            query = f"""
                SELECT ud_source_file_id
                FROM content_repo
                WHERE ud_source_file_id IN ({placeholders})
            """

            results = self.execute_query(query, tuple(file_ids))
            valid_ids = [row['ud_source_file_id'] for row in results]
            invalid_ids = [fid for fid in file_ids if fid not in valid_ids]

            return valid_ids, invalid_ids

        except Exception as e:
            self._logger.error(f"Failed to validate file IDs: {e}")
            # On error, assume all invalid to be safe
            return [], file_ids

    # =========================================================================
    # Chunk Operations (Phase 3C: Points 96-105)
    # =========================================================================

    def get_chunks_by_file(
        self,
        file_id: int,
        order_by: str = "chunk_index ASC"
    ) -> List[Dict[str, Any]]:
        """
        Get all chunks for a specific file.

        Point 97 in migration plan.

        Args:
            file_id: File ID (ud_source_file_id)
            order_by: Sort order (default: by chunk index ascending)

        Returns:
            List of dictionaries with chunk data, ordered as specified

        Raises:
            QueryError: If query execution fails
            ValueError: If file_id is invalid

        Example:
            >>> chunks = repo.get_chunks_by_file(42)
            >>> print(f"File has {len(chunks)} chunks")
            >>> for chunk in chunks:
            ...     print(f"Chunk {chunk['chunk_index']}: {chunk['content_checksum']}")
        """
        # Validation - accept both Python int and numpy integer types
        try:
            file_id = int(file_id)  # Convert numpy.int64 to Python int
            if file_id <= 0:
                raise ValueError(f"file_id must be positive, got {file_id}")
        except (TypeError, ValueError) as e:
            raise ValueError(f"file_id must be a positive integer, got {file_id} (type: {type(file_id)})") from e

        self._logger.debug(f"Retrieving chunks for file ID: {file_id}")

        try:
            query = f"""
                SELECT * FROM content_chunks
                WHERE ud_source_file_id = ?
                ORDER BY {order_by}
            """

            results = self.execute_query(query, (file_id,))

            self._logger.debug(f"Found {len(results)} chunks for file {file_id}")
            return results

        except Exception as e:
            self._logger.error(f"Failed to get chunks for file {file_id}: {e}")
            raise QueryError(f"Failed to retrieve chunks for file {file_id}: {e}") from e

    def get_chunk_by_checksum(
        self,
        checksum: str,
        file_id: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get chunk by content checksum.

        Point 98 in migration plan.

        Note: Multiple chunks may have the same checksum (e.g., repeated headers/footers).
        If file_id is not provided, returns the first match.

        Args:
            checksum: Content checksum (SHA-256, 64 characters)
            file_id: Optional file ID to narrow search

        Returns:
            Dictionary with chunk data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If checksum is invalid

        Example:
            >>> # Find chunk by checksum
            >>> chunk = repo.get_chunk_by_checksum("abc123...")
            >>> if chunk:
            ...     print(f"Found in file: {chunk['ud_source_file_id']}")
            >>>
            >>> # Find chunk in specific file
            >>> chunk = repo.get_chunk_by_checksum("abc123...", file_id=42)
        """
        # Validation
        if not checksum or not isinstance(checksum, str):
            raise ValueError("checksum must be a non-empty string")

        if len(checksum) != 64:
            raise ValueError(f"checksum must be 64 characters (SHA-256), got {len(checksum)}")

        self._logger.debug(f"Retrieving chunk by checksum: {checksum[:16]}...")

        try:
            if file_id is not None:
                # Search within specific file
                query = """
                    SELECT * FROM content_chunks
                    WHERE content_checksum = ?
                    AND ud_source_file_id = ?
                    LIMIT 1
                """
                result = self.execute_query_single(query, (checksum, file_id))
            else:
                # Search across all files
                query = """
                    SELECT * FROM content_chunks
                    WHERE content_checksum = ?
                    LIMIT 1
                """
                result = self.execute_query_single(query, (checksum,))

            if result:
                self._logger.debug(f"Found chunk with checksum {checksum[:16]}...")
            else:
                self._logger.debug(f"Chunk not found with checksum {checksum[:16]}...")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get chunk by checksum: {e}")
            raise QueryError(f"Failed to retrieve chunk by checksum: {e}") from e

    def ingest_chunks(
        self,
        chunks_df: pd.DataFrame,
        validate: bool = True,
        validate_fk: bool = True
    ) -> Dict[str, Any]:
        """
        Batch insert chunks into content_chunks table.

        Point 99 in migration plan.

        Args:
            chunks_df: DataFrame with chunk data
            validate: Validate data before insert (default: True)
            validate_fk: Validate foreign keys exist (default: True)

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - errors (List[str], optional): Validation errors if any

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If FK validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - ud_source_file_id (required, must exist in content_repo)
            - chunk_index (required, integer >= 0)
            - content_checksum (required, 64-char SHA-256 hash)
            - chunk_text (required)

        Optional DataFrame Columns:
            - chunk_page_number
            - chunk_start_char
            - chunk_end_char
            - status (default: "active")
            - created_at (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'ud_source_file_id': [1, 1, 1],
            ...     'chunk_index': [0, 1, 2],
            ...     'content_checksum': ['abc...', 'def...', 'ghi...'],
            ...     'chunk_text': ['Chapter 1...', 'Chapter 2...', 'Chapter 3...']
            ... })
            >>> result = repo.ingest_chunks(df)
            >>> print(f"Inserted {result['rows_inserted']} chunks")
        """
        self._logger.info(f"Ingesting {len(chunks_df)} chunks in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if chunks_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            required_cols = ['ud_source_file_id', 'chunk_index', 'content_checksum', 'chunk_text']
            missing_cols = [col for col in required_cols if col not in chunks_df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")

            if not errors:  # Only validate values if columns exist
                # Validate ud_source_file_id
                if chunks_df['ud_source_file_id'].isna().any():
                    count = chunks_df['ud_source_file_id'].isna().sum()
                    errors.append(f"{count} rows have null ud_source_file_id")

                # Validate chunk_index (must be >= 0)
                invalid_index = chunks_df['chunk_index'].isna() | (chunks_df['chunk_index'] < 0)
                if invalid_index.any():
                    count = invalid_index.sum()
                    errors.append(f"{count} rows have invalid chunk_index (< 0 or null)")

                # Validate content_checksum format
                invalid_checksum = chunks_df['content_checksum'].isna() | \
                                 (chunks_df['content_checksum'].str.len() != 64)
                if invalid_checksum.any():
                    count = invalid_checksum.sum()
                    errors.append(
                        f"{count} rows have invalid content_checksum "
                        "(must be 64-char SHA-256 hash)"
                    )

                # Validate chunk_text is not empty
                empty_text = chunks_df['chunk_text'].isna() | \
                           (chunks_df['chunk_text'].str.strip() == '')
                if empty_text.any():
                    count = empty_text.sum()
                    errors.append(f"{count} rows have empty chunk_text")

            # If validation errors, raise exception
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

            # Foreign key validation
            if validate_fk:
                unique_file_ids = chunks_df['ud_source_file_id'].unique().tolist()
                valid_ids, invalid_ids = self.validate_file_ids(unique_file_ids)

                if invalid_ids:
                    raise ForeignKeyViolationError(
                        f"Foreign key violation: file IDs do not exist in content_repo: {invalid_ids}"
                    )

        # Prepare DataFrame for ingestion
        df_prepared = chunks_df.copy()

        # Add default columns if missing
        if 'status' not in df_prepared.columns:
            df_prepared['status'] = 'active'

        if 'created_at' not in df_prepared.columns:
            df_prepared['created_at'] = datetime.now()

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="content_chunks",
                    if_exists="append",
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} chunks"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest chunks: {e}")
            raise QueryError(f"Chunk ingestion failed: {e}") from e

    def clear_chunks_for_file(self, file_id: int) -> int:
        """
        Delete all chunks for a specific file.

        Point 100 in migration plan.

        Use case: Before re-ingesting chunks for a file, clear old chunks.

        Args:
            file_id: File ID (ud_source_file_id)

        Returns:
            Number of chunks deleted

        Raises:
            QueryError: If delete fails
            ValueError: If file_id is invalid

        Example:
            >>> # Clear old chunks before re-ingesting
            >>> deleted = repo.clear_chunks_for_file(42)
            >>> print(f"Deleted {deleted} old chunks")
            >>> # Now safe to ingest new chunks
            >>> repo.ingest_chunks(new_chunks_df)
        """
        # Validation - accept both Python int and numpy integer types
        try:
            file_id = int(file_id)  # Convert numpy.int64 to Python int
            if file_id <= 0:
                raise ValueError(f"file_id must be positive, got {file_id}")
        except (TypeError, ValueError) as e:
            raise ValueError(f"file_id must be a positive integer, got {file_id} (type: {type(file_id)})") from e

        self._logger.info(f"Clearing all chunks for file ID: {file_id}")

        try:
            command = "DELETE FROM content_chunks WHERE ud_source_file_id = ?"

            with self.transaction():
                rows_deleted = self.execute_command(command, (file_id,))

            self._logger.info(f"Deleted {rows_deleted} chunks for file {file_id}")
            return rows_deleted

        except Exception as e:
            self._logger.error(f"Failed to clear chunks for file {file_id}: {e}")
            raise QueryError(f"Failed to clear chunks: {e}") from e

    def get_chunk_stats(self, file_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Get chunk statistics.

        Point 101 in migration plan.

        Args:
            file_id: Optional file ID to get stats for specific file

        Returns:
            Dictionary with statistics:
                - total_chunks: Total number of chunks
                - unique_checksums: Number of unique content checksums
                - avg_chunks_per_file: Average chunks per file
                - by_status: Count by status
                - file_chunk_count: Chunks for specific file (if file_id provided)

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get overall stats
            >>> stats = repo.get_chunk_stats()
            >>> print(f"Total chunks: {stats['total_chunks']}")
            >>> print(f"Unique content: {stats['unique_checksums']}")
            >>>
            >>> # Get stats for specific file
            >>> file_stats = repo.get_chunk_stats(file_id=42)
            >>> print(f"File has {file_stats['file_chunk_count']} chunks")
        """
        self._logger.debug(f"Calculating chunk statistics (file_id={file_id})")

        try:
            stats = {}

            if file_id is not None:
                # Stats for specific file
                result = self.execute_query_single(
                    "SELECT COUNT(*) as count FROM content_chunks WHERE ud_source_file_id = ?",
                    (file_id,)
                )
                stats['file_chunk_count'] = result['count'] if result else 0

                result = self.execute_query_single(
                    """
                    SELECT COUNT(DISTINCT content_checksum) as count
                    FROM content_chunks
                    WHERE ud_source_file_id = ?
                    """,
                    (file_id,)
                )
                stats['unique_checksums_in_file'] = result['count'] if result else 0

            else:
                # Overall stats
                result = self.execute_query_single(
                    "SELECT COUNT(*) as count FROM content_chunks"
                )
                stats['total_chunks'] = result['count'] if result else 0

                result = self.execute_query_single(
                    "SELECT COUNT(DISTINCT content_checksum) as count FROM content_chunks"
                )
                stats['unique_checksums'] = result['count'] if result else 0

                # Average chunks per file
                result = self.execute_query_single(
                    """
                    SELECT AVG(chunk_count) as avg_count
                    FROM (
                        SELECT COUNT(*) as chunk_count
                        FROM content_chunks
                        GROUP BY ud_source_file_id
                    )
                    """
                )
                stats['avg_chunks_per_file'] = round(result['avg_count'], 2) if result and result['avg_count'] else 0

                # Count by status
                results = self.execute_query(
                    """
                    SELECT status, COUNT(*) as count
                    FROM content_chunks
                    GROUP BY status
                    """
                )
                stats['by_status'] = {row['status']: row['count'] for row in results}

            self._logger.debug(f"Chunk statistics: {stats}")
            return stats

        except Exception as e:
            self._logger.error(f"Failed to calculate chunk statistics: {e}")
            raise QueryError(f"Failed to get chunk statistics: {e}") from e

    def find_chunks_by_text(
        self,
        search_text: str,
        file_id: Optional[int] = None,
        case_sensitive: bool = False,
        limit: Optional[int] = 100
    ) -> List[Dict[str, Any]]:
        """
        Find chunks containing specific text (full-text search).

        Point 102 in migration plan.

        Args:
            search_text: Text to search for
            file_id: Optional file ID to limit search
            case_sensitive: Perform case-sensitive search (default: False)
            limit: Maximum number of results (default: 100)

        Returns:
            List of dictionaries with matching chunks

        Raises:
            QueryError: If search fails
            ValueError: If search_text is empty

        Example:
            >>> # Find all chunks mentioning "refund policy"
            >>> chunks = repo.find_chunks_by_text("refund policy")
            >>> for chunk in chunks:
            ...     print(f"Found in file {chunk['ud_source_file_id']}, chunk {chunk['chunk_index']}")
            >>>
            >>> # Case-sensitive search within specific file
            >>> chunks = repo.find_chunks_by_text(
            ...     "API",
            ...     file_id=42,
            ...     case_sensitive=True
            ... )
        """
        # Validation
        if not search_text or not search_text.strip():
            raise ValueError("search_text cannot be empty")

        self._logger.debug(
            f"Searching chunks for text: '{search_text[:50]}...' "
            f"(file_id={file_id}, case_sensitive={case_sensitive})"
        )

        try:
            # Build query based on parameters
            if case_sensitive:
                # Case-sensitive: use LIKE with GLOB or direct comparison
                like_operator = "LIKE"
                search_pattern = f"%{search_text}%"
            else:
                # Case-insensitive: use LIKE (SQLite default) or ILIKE (PostgreSQL)
                like_operator = "LIKE"
                search_pattern = f"%{search_text}%"

            if file_id is not None:
                query = f"""
                    SELECT * FROM content_chunks
                    WHERE ud_source_file_id = ?
                    AND chunk_text {like_operator} ?
                    ORDER BY chunk_index
                    LIMIT {limit if limit else 100}
                """
                params = (file_id, search_pattern)
            else:
                query = f"""
                    SELECT * FROM content_chunks
                    WHERE chunk_text {like_operator} ?
                    ORDER BY ud_source_file_id, chunk_index
                    LIMIT {limit if limit else 100}
                """
                params = (search_pattern,)

            results = self.execute_query(query, params)

            self._logger.debug(f"Found {len(results)} chunks matching '{search_text[:50]}...'")
            return results

        except Exception as e:
            self._logger.error(f"Failed to search chunks: {e}")
            raise QueryError(f"Chunk search failed: {e}") from e

    def validate_chunk_checksum(
        self,
        checksum: str,
        chunk_text: str,
        hash_algorithm: str = "sha256"
    ) -> bool:
        """
        Validate that checksum matches chunk text.

        Point 103 in migration plan - Checksum collision detection.

        Args:
            checksum: Content checksum to validate
            chunk_text: Actual chunk text
            hash_algorithm: Hash algorithm (default: sha256)

        Returns:
            True if checksum matches text, False otherwise

        Example:
            >>> checksum = "abc123..."
            >>> text = "This is the chunk content"
            >>> if repo.validate_chunk_checksum(checksum, text):
            ...     print("Checksum is valid")
            ... else:
            ...     print("WARNING: Checksum mismatch!")
        """
        import hashlib

        try:
            # Calculate checksum from text
            if hash_algorithm == "sha256":
                calculated = hashlib.sha256(chunk_text.encode('utf-8')).hexdigest()
            else:
                raise ValueError(f"Unsupported hash algorithm: {hash_algorithm}")

            # Compare
            is_valid = calculated == checksum

            if not is_valid:
                self._logger.warning(
                    f"Checksum mismatch! Expected: {checksum[:16]}..., "
                    f"Calculated: {calculated[:16]}..."
                )

            return is_valid

        except Exception as e:
            self._logger.error(f"Failed to validate checksum: {e}")
            return False

    def detect_duplicate_chunks(self, file_id: int) -> List[Dict[str, Any]]:
        """
        Detect duplicate chunk checksums within a file.

        Point 103 in migration plan - Checksum collision detection.

        Args:
            file_id: File ID to check for duplicates

        Returns:
            List of dictionaries with duplicate information:
                - content_checksum: The duplicate checksum
                - occurrence_count: How many times it appears
                - chunk_indices: List of chunk indices with this checksum

        Example:
            >>> duplicates = repo.detect_duplicate_chunks(42)
            >>> if duplicates:
            ...     for dup in duplicates:
            ...         print(f"Checksum {dup['content_checksum'][:16]} "
            ...               f"appears {dup['occurrence_count']} times "
            ...               f"at indices {dup['chunk_indices']}")
        """
        self._logger.debug(f"Detecting duplicate chunks in file {file_id}")

        try:
            query = """
                SELECT
                    content_checksum,
                    COUNT(*) as occurrence_count,
                    GROUP_CONCAT(chunk_index) as chunk_indices
                FROM content_chunks
                WHERE ud_source_file_id = ?
                GROUP BY content_checksum
                HAVING COUNT(*) > 1
                ORDER BY occurrence_count DESC
            """

            results = self.execute_query(query, (file_id,))

            # Parse chunk_indices from comma-separated string to list
            for row in results:
                if row['chunk_indices']:
                    row['chunk_indices'] = [
                        int(idx) for idx in row['chunk_indices'].split(',')
                    ]

            if results:
                self._logger.warning(
                    f"Found {len(results)} duplicate checksums in file {file_id}"
                )
            else:
                self._logger.debug(f"No duplicate chunks found in file {file_id}")

            return results

        except Exception as e:
            self._logger.error(f"Failed to detect duplicates: {e}")
            raise QueryError(f"Failed to detect duplicate chunks: {e}") from e


__all__ = [
    # Main class
    "ContentRepository",

    # Exceptions
    "ContentRepositoryError",
    "FileNotFoundError",
    "ChunkNotFoundError",
    "DuplicateFileError",
    "ForeignKeyViolationError",
]
