"""
Audit Repository - Database operations for content_change_log and faq_audit_log tables

This module provides the AuditRepository class for managing change detection logs and audit trails.
It follows the Repository Pattern to keep business logic separate from database implementation.

Responsibilities:
    - Content change logging (single and bulk)
    - Change history retrieval
    - Detection run management
    - Detection results storage
    - FAQ invalidation tracking
    - Baseline data retrieval for change detection
    - Performance-optimized queries for change analysis

Design Principles:
    - Single Responsibility: Only audit and change detection operations
    - Database-Agnostic: Works with SQLite, Databricks, or any IBackend
    - Validation: Enforces business rules before database operations
    - Transaction Safety: Uses transactions for multi-step operations
    - Idempotency: Safe to retry operations

Tables Managed:
    - content_change_log: Change detection records with similarity scores and impact metrics
    - faq_audit_log: Audit trail for FAQ operations with FK references

Example Usage:
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>> from core.models.detection import DetectionResult
    >>>
    >>> # Create backend and repository
    >>> config = DatabaseConfig.from_env()
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = AuditRepository(backend)
    >>>
    >>> # Log a single change
    >>> change_log = repo.log_change(
    ...     content_checksum="abc123...",
    ...     file_name="policy.pdf",
    ...     requires_faq_regeneration=True,
    ...     change_type=ChangeType.MODIFIED_CONTENT,
    ...     detection_run_id="run_2025_11_02_001"
    ... )
    >>>
    >>> # Get detection run summary
    >>> summary = repo.get_run_summary("run_2025_11_02_001")
    >>> print(f"Total changes: {summary['total_changes_detected']}")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import pandas as pd
import json

from database.repository.base import (
    BaseRepository,
    RepositoryError,
    QueryError,
    DataValidationError,
)
from database.models import (
    ContentChangeLog,
    AuditLogEntry,
    ChangeType,
    ValidationError,
    ChecksumValidationError,
    ScoreValidationError,
)
from database.backends.base import IBackend
from utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# Audit Repository Exceptions
# =============================================================================


class AuditRepositoryError(RepositoryError):
    """Base exception for audit repository errors."""
    pass


class ChangeLogNotFoundError(AuditRepositoryError):
    """Raised when change log cannot be found."""
    pass


class DetectionRunNotFoundError(AuditRepositoryError):
    """Raised when detection run cannot be found."""
    pass


class InvalidDetectionResultError(AuditRepositoryError):
    """Raised when detection result is invalid."""
    pass


class DuplicateChangeLogError(AuditRepositoryError):
    """Raised when attempting to insert duplicate change log."""
    pass


# =============================================================================
# Audit Repository Class
# =============================================================================


class AuditRepository(BaseRepository[ContentChangeLog]):
    """
    Repository for content_change_log and faq_audit_log tables.

    Handles:
    - Content change logging
    - Audit trail management
    - Detection results storage
    - Change history retrieval
    - FAQ invalidation tracking
    - Baseline data for change detection

    Business logic only - NO database-specific code!

    All methods enforce validation and use transactions where appropriate.
    """

    def __init__(
        self,
        backend: IBackend,
        auto_connect: bool = True,
    ):
        """
        Initialize audit repository with database backend.

        Args:
            backend: Database backend (SQLite, Databricks, etc.)
            auto_connect: Automatically connect to backend on initialization

        Raises:
            TypeError: If backend is not an IBackend instance
            ConnectionError: If auto_connect=True and connection fails
        """
        super().__init__(backend, auto_connect=auto_connect)
        logger.info("AuditRepository initialized")

    # =========================================================================
    # Content Change Log Operations (Points 127-129)
    # =========================================================================

    def log_change(
        self,
        content_checksum: str,
        file_name: str,
        requires_faq_regeneration: bool,
        detection_run_id: str,
        previous_checksum: Optional[str] = None,
        change_type: Optional[ChangeType] = None,
        similarity_score: Optional[float] = None,
        similarity_method: Optional[str] = None,
        diff_data: Optional[Dict[str, Any]] = None,
        total_faqs_at_risk: int = 0,
        affected_question_count: int = 0,
        affected_answer_count: int = 0,
        detection_timestamp: Optional[datetime] = None,
    ) -> ContentChangeLog:
        """
        Log a single content change to content_change_log table.

        This method validates the change data and inserts it into the database.
        It returns the created ContentChangeLog with the generated change_id.

        Args:
            content_checksum: New content checksum (SHA-256, 64 chars)
            file_name: Name of file where change occurred
            requires_faq_regeneration: Whether FAQs need regeneration
            detection_run_id: Unique identifier for this detection run
            previous_checksum: Previous content checksum (None for new content)
            change_type: Type of change (new, modified, deleted, unchanged)
            similarity_score: Similarity score (0.0-1.0) for modified content
            similarity_method: Method used for similarity calculation
            diff_data: Structured diff data (will be JSON-serialized)
            total_faqs_at_risk: Total FAQs linked to old checksum
            affected_question_count: Questions actually affected
            affected_answer_count: Answers actually affected
            detection_timestamp: When change was detected (default: now)

        Returns:
            ContentChangeLog object with generated change_id

        Raises:
            DataValidationError: If validation fails
            QueryError: If database insert fails

        Example:
            >>> change_log = repo.log_change(
            ...     content_checksum="abc123...",
            ...     file_name="policy.pdf",
            ...     requires_faq_regeneration=True,
            ...     change_type=ChangeType.MODIFIED_CONTENT,
            ...     detection_run_id="run_001",
            ...     previous_checksum="xyz789...",
            ...     similarity_score=0.85
            ... )
            >>> print(change_log.change_id)
            42
        """
        # Create ContentChangeLog model (validates automatically via __post_init__)
        try:
            change_log = ContentChangeLog(
                content_checksum=content_checksum,
                file_name=file_name,
                requires_faq_regeneration=requires_faq_regeneration,
                detection_run_id=detection_run_id,
                previous_checksum=previous_checksum,
                change_type=change_type,
                similarity_score=similarity_score,
                similarity_method=similarity_method,
                diff_data=json.dumps(diff_data) if diff_data else None,
                total_faqs_at_risk=total_faqs_at_risk,
                affected_question_count=affected_question_count,
                affected_answer_count=affected_answer_count,
                detection_timestamp=detection_timestamp or datetime.now(),
            )
        except (ValidationError, ChecksumValidationError, ScoreValidationError) as e:
            logger.error(f"Validation failed for change log: {e}")
            raise DataValidationError(f"Invalid change log data: {e}") from e

        # Insert into database
        insert_sql = """
            INSERT INTO content_change_log (
                content_checksum,
                previous_checksum,
                file_name,
                requires_faq_regeneration,
                change_type,
                similarity_score,
                similarity_method,
                diff_data,
                total_faqs_at_risk,
                affected_question_count,
                affected_answer_count,
                detection_run_id,
                detection_timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        params = (
            change_log.content_checksum,
            change_log.previous_checksum,
            change_log.file_name,
            1 if change_log.requires_faq_regeneration else 0,  # SQLite uses INTEGER for BOOLEAN
            change_log.change_type.value if change_log.change_type else None,
            change_log.similarity_score,
            change_log.similarity_method,
            change_log.diff_data,
            change_log.total_faqs_at_risk,
            change_log.affected_question_count,
            change_log.affected_answer_count,
            change_log.detection_run_id,
            change_log.detection_timestamp,
        )

        try:
            change_id = self.execute_insert(insert_sql, params)
            change_log.change_id = change_id

            logger.info(
                f"Logged change {change_id}: {file_name} "
                f"(type={change_type.value if change_type else 'unknown'}, "
                f"requires_regen={requires_faq_regeneration})"
            )

            return change_log

        except QueryError as e:
            logger.error(f"Failed to insert change log: {e}")
            raise

    def log_changes_bulk(
        self,
        changes_df: pd.DataFrame,
    ) -> Dict[str, Any]:
        """
        Bulk insert content changes into content_change_log table.

        This method is optimized for batch inserts and validates all rows before insertion.
        It uses backend-specific bulk insert capabilities for performance.

        Args:
            changes_df: DataFrame with columns matching ContentChangeLog fields
                Required columns: content_checksum, file_name, requires_faq_regeneration,
                                 detection_run_id
                Optional columns: previous_checksum, change_type, similarity_score,
                                 similarity_method, diff_data, total_faqs_at_risk,
                                 affected_question_count, affected_answer_count,
                                 detection_timestamp

        Returns:
            Dictionary with:
                - success: bool
                - rows_inserted: int
                - message: str
                - errors: List[str] (if any validation errors)

        Raises:
            DataValidationError: If DataFrame is empty or missing required columns
            QueryError: If database bulk insert fails

        Example:
            >>> df = pd.DataFrame([
            ...     {
            ...         'content_checksum': 'abc123...',
            ...         'file_name': 'file1.pdf',
            ...         'requires_faq_regeneration': True,
            ...         'detection_run_id': 'run_001',
            ...         'change_type': 'modified_content',
            ...         'similarity_score': 0.85
            ...     },
            ...     {
            ...         'content_checksum': 'def456...',
            ...         'file_name': 'file2.pdf',
            ...         'requires_faq_regeneration': False,
            ...         'detection_run_id': 'run_001',
            ...         'change_type': 'new_content'
            ...     }
            ... ])
            >>> result = repo.log_changes_bulk(df)
            >>> print(result['rows_inserted'])
            2
        """
        # Validation
        if changes_df.empty:
            raise DataValidationError("Cannot insert empty DataFrame")

        required_columns = {
            'content_checksum',
            'file_name',
            'requires_faq_regeneration',
            'detection_run_id'
        }
        missing_columns = required_columns - set(changes_df.columns)
        if missing_columns:
            raise DataValidationError(
                f"Missing required columns: {missing_columns}"
            )

        # Add default values for optional columns
        if 'detection_timestamp' not in changes_df.columns:
            changes_df = changes_df.copy()
            changes_df['detection_timestamp'] = datetime.now()

        # Validate each row using ContentChangeLog model
        errors = []
        for idx, row in changes_df.iterrows():
            try:
                # This will raise ValidationError if invalid
                ContentChangeLog(
                    content_checksum=row['content_checksum'],
                    file_name=row['file_name'],
                    requires_faq_regeneration=bool(row['requires_faq_regeneration']),
                    detection_run_id=row['detection_run_id'],
                    previous_checksum=row.get('previous_checksum'),
                    change_type=ChangeType(row['change_type']) if 'change_type' in row and row['change_type'] else None,
                    similarity_score=row.get('similarity_score'),
                    similarity_method=row.get('similarity_method'),
                    diff_data=row.get('diff_data'),
                    total_faqs_at_risk=int(row.get('total_faqs_at_risk', 0)),
                    affected_question_count=int(row.get('affected_question_count', 0)),
                    affected_answer_count=int(row.get('affected_answer_count', 0)),
                    detection_timestamp=row.get('detection_timestamp', datetime.now()),
                )
            except (ValidationError, ChecksumValidationError, ScoreValidationError) as e:
                errors.append(f"Row {idx}: {e}")

        if errors:
            error_msg = f"Validation failed for {len(errors)} rows:\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                error_msg += f"\n... and {len(errors) - 10} more errors"
            logger.error(error_msg)
            return {
                'success': False,
                'rows_inserted': 0,
                'message': error_msg,
                'errors': errors
            }

        # Convert boolean to integer for SQLite
        if 'requires_faq_regeneration' in changes_df.columns:
            changes_df = changes_df.copy()
            changes_df['requires_faq_regeneration'] = changes_df['requires_faq_regeneration'].astype(int)

        # Delegate to backend for bulk insert
        try:
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=changes_df,
                    table_name="content_change_log"
                )

                logger.info(
                    f"Bulk inserted {result.get('rows_inserted', 0)} changes "
                    f"for detection run: {changes_df['detection_run_id'].iloc[0]}"
                )

                return result

        except QueryError as e:
            logger.error(f"Bulk insert failed: {e}")
            raise

    def get_changes_for_file(
        self,
        file_name: str,
        limit: Optional[int] = None,
        include_unchanged: bool = False,
    ) -> List[ContentChangeLog]:
        """
        Get change history for a specific file.

        Retrieves all changes detected for a given file, ordered by most recent first.
        Optionally filters out unchanged content for concise history.

        Args:
            file_name: Name of file to get changes for
            limit: Maximum number of changes to return (None = all)
            include_unchanged: Include unchanged_content changes (default: False)

        Returns:
            List of ContentChangeLog objects ordered by detection_timestamp DESC

        Raises:
            QueryError: If database query fails

        Example:
            >>> changes = repo.get_changes_for_file("policy.pdf", limit=10)
            >>> for change in changes:
            ...     print(f"{change.detection_timestamp}: {change.change_type.value}")
        """
        query = """
            SELECT
                change_id,
                content_checksum,
                previous_checksum,
                file_name,
                requires_faq_regeneration,
                change_type,
                similarity_score,
                similarity_method,
                diff_data,
                total_faqs_at_risk,
                affected_question_count,
                affected_answer_count,
                detection_run_id,
                detection_timestamp
            FROM content_change_log
            WHERE file_name = ?
        """

        if not include_unchanged:
            query += " AND change_type != 'unchanged_content'"

        query += " ORDER BY detection_timestamp DESC"

        if limit:
            query += f" LIMIT {limit}"

        try:
            results = self.execute_query(query, (file_name,))

            # Convert to ContentChangeLog objects
            change_logs = []
            for row in results:
                change_log = ContentChangeLog(
                    change_id=row['change_id'],
                    content_checksum=row['content_checksum'],
                    previous_checksum=row['previous_checksum'],
                    file_name=row['file_name'],
                    requires_faq_regeneration=bool(row['requires_faq_regeneration']),
                    change_type=ChangeType(row['change_type']) if row['change_type'] else None,
                    similarity_score=row['similarity_score'],
                    similarity_method=row['similarity_method'],
                    diff_data=row['diff_data'],
                    total_faqs_at_risk=row['total_faqs_at_risk'],
                    affected_question_count=row['affected_question_count'],
                    affected_answer_count=row['affected_answer_count'],
                    detection_run_id=row['detection_run_id'],
                    detection_timestamp=row['detection_timestamp'],
                )
                change_logs.append(change_log)

            logger.info(f"Retrieved {len(change_logs)} changes for file: {file_name}")
            return change_logs

        except QueryError as e:
            logger.error(f"Failed to get changes for file {file_name}: {e}")
            raise

    def get_changes_by_run(
        self,
        detection_run_id: str,
        include_unchanged: bool = False,
    ) -> List[ContentChangeLog]:
        """
        Get all changes for a specific detection run.

        Args:
            detection_run_id: Detection run identifier
            include_unchanged: Include unchanged_content changes (default: False)

        Returns:
            List of ContentChangeLog objects for the run

        Raises:
            DetectionRunNotFoundError: If run_id not found
            QueryError: If database query fails

        Example:
            >>> changes = repo.get_changes_by_run("run_2025_11_02_001")
            >>> print(f"Total changes in run: {len(changes)}")
        """
        query = """
            SELECT
                change_id,
                content_checksum,
                previous_checksum,
                file_name,
                requires_faq_regeneration,
                change_type,
                similarity_score,
                similarity_method,
                diff_data,
                total_faqs_at_risk,
                affected_question_count,
                affected_answer_count,
                detection_run_id,
                detection_timestamp
            FROM content_change_log
            WHERE detection_run_id = ?
        """

        if not include_unchanged:
            query += " AND change_type != 'unchanged_content'"

        query += " ORDER BY detection_timestamp, file_name"

        try:
            results = self.execute_query(query, (detection_run_id,))

            if not results:
                raise DetectionRunNotFoundError(
                    f"No changes found for detection run: {detection_run_id}"
                )

            # Convert to ContentChangeLog objects
            change_logs = []
            for row in results:
                change_log = ContentChangeLog(
                    change_id=row['change_id'],
                    content_checksum=row['content_checksum'],
                    previous_checksum=row['previous_checksum'],
                    file_name=row['file_name'],
                    requires_faq_regeneration=bool(row['requires_faq_regeneration']),
                    change_type=ChangeType(row['change_type']) if row['change_type'] else None,
                    similarity_score=row['similarity_score'],
                    similarity_method=row['similarity_method'],
                    diff_data=row['diff_data'],
                    total_faqs_at_risk=row['total_faqs_at_risk'],
                    affected_question_count=row['affected_question_count'],
                    affected_answer_count=row['affected_answer_count'],
                    detection_run_id=row['detection_run_id'],
                    detection_timestamp=row['detection_timestamp'],
                )
                change_logs.append(change_log)

            logger.info(f"Retrieved {len(change_logs)} changes for run: {detection_run_id}")
            return change_logs

        except QueryError as e:
            logger.error(f"Failed to get changes for run {detection_run_id}: {e}")
            raise

    def get_latest_run_id(self) -> Optional[str]:
        """
        Get the most recent detection run ID.

        Returns:
            Most recent detection_run_id, or None if no runs exist

        Raises:
            QueryError: If database query fails

        Example:
            >>> latest_run = repo.get_latest_run_id()
            >>> print(f"Latest run: {latest_run}")
            Latest run: run_2025_11_02_001
        """
        query = """
            SELECT detection_run_id
            FROM content_change_log
            ORDER BY detection_timestamp DESC
            LIMIT 1
        """

        try:
            result = self.execute_query_single(query)

            if result:
                run_id = result['detection_run_id']
                logger.info(f"Latest detection run: {run_id}")
                return run_id
            else:
                logger.info("No detection runs found")
                return None

        except QueryError as e:
            logger.error(f"Failed to get latest run ID: {e}")
            raise

    def get_run_summary(
        self,
        detection_run_id: Optional[str] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Get summary statistics for detection runs showing granular impact savings.

        If detection_run_id is provided, returns summary for that specific run.
        Otherwise, returns summaries for the most recent N runs.

        Args:
            detection_run_id: Specific run to summarize (None = latest N runs)
            limit: Number of recent runs to show if detection_run_id is None

        Returns:
            List of dictionaries with run statistics:
                - detection_run_id: str
                - detection_started_at: datetime
                - detection_completed_at: datetime
                - total_changes_detected: int
                - unique_files_changed: int
                - total_faqs_at_risk: int
                - questions_actually_affected: int
                - answers_actually_affected: int
                - faqs_saved_from_regeneration: int
                - savings_percentage: float
                - avg_similarity_score: float
                - min_similarity_score: float
                - max_similarity_score: float

        Raises:
            DetectionRunNotFoundError: If specific run_id not found
            QueryError: If database query fails

        Example:
            >>> summaries = repo.get_run_summary(limit=5)
            >>> for summary in summaries:
            ...     print(f"{summary['detection_run_id']}: "
            ...           f"{summary['savings_percentage']}% savings")
        """
        query = """
            SELECT
                ccl.detection_run_id,
                MIN(ccl.detection_timestamp) AS detection_started_at,
                MAX(ccl.detection_timestamp) AS detection_completed_at,

                COUNT(*) AS total_changes_detected,
                COUNT(DISTINCT ccl.file_name) AS unique_files_changed,

                SUM(ccl.total_faqs_at_risk) AS total_faqs_at_risk,
                SUM(ccl.affected_question_count) AS questions_actually_affected,
                SUM(ccl.affected_answer_count) AS answers_actually_affected,

                SUM(ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count))
                    AS faqs_saved_from_regeneration,
                ROUND(
                    100.0 * SUM(ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count)) /
                    NULLIF(SUM(ccl.total_faqs_at_risk), 0),
                    2
                ) AS savings_percentage,

                ROUND(AVG(ccl.similarity_score), 3) AS avg_similarity_score,
                ROUND(MIN(ccl.similarity_score), 3) AS min_similarity_score,
                ROUND(MAX(ccl.similarity_score), 3) AS max_similarity_score

            FROM content_change_log ccl
            WHERE ccl.requires_faq_regeneration = 1
        """

        if detection_run_id:
            query += " AND ccl.detection_run_id = ?"
            params = (detection_run_id,)
        else:
            params = ()

        query += """
            GROUP BY ccl.detection_run_id
            ORDER BY detection_started_at DESC
        """

        if not detection_run_id:
            query += f" LIMIT {limit}"

        try:
            results = self.execute_query(query, params)

            if detection_run_id and not results:
                raise DetectionRunNotFoundError(
                    f"No summary found for detection run: {detection_run_id}"
                )

            logger.info(f"Retrieved summaries for {len(results)} detection run(s)")
            return results

        except QueryError as e:
            logger.error(f"Failed to get run summary: {e}")
            raise

    # =========================================================================
    # Detection Operations (Points 137-145)
    # =========================================================================

    def get_previous_checksums(
        self,
        file_name: Optional[str] = None,
        since_timestamp: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get baseline data (previous checksums) for change detection.

        This method retrieves checksums for content chunks created before a baseline
        timestamp, which serves as the baseline for detecting new changes. If file_name
        is provided, only returns checksums for that file.

        Args:
            file_name: Optional file name to filter by
            since_timestamp: Optional timestamp to use as baseline cutoff.
                Only returns chunks created before this timestamp (created_at < since_timestamp).
                Format: 'YYYY-MM-DD HH:MM:SS'

        Returns:
            Dictionary mapping checksum -> content metadata:
                {
                    "abc123...": {
                        "content_text": "...",
                        "file_name": "policy.pdf",
                        "page_number": 1,
                        ...
                    },
                    ...
                }

        Raises:
            QueryError: If database query fails

        Example:
            >>> # Get all baseline checksums created before a specific date
            >>> baseline = repo.get_previous_checksums(
            ...     file_name="policy.pdf",
            ...     since_timestamp="2025-11-02 10:24:29"
            ... )
            >>> print(f"Found {len(baseline)} previous checksums")
        """
        # Build query based on parameters
        if file_name or since_timestamp:
            # Join with content_repo to filter by file name and/or timestamp
            query = """
                SELECT
                    cc.content_checksum,
                    cc.chunk_text AS content_text,
                    cc.chunk_index,
                    cc.ud_source_file_id,
                    cr.raw_file_nme AS file_name
                FROM content_chunks cc
                INNER JOIN content_repo cr
                    ON cr.ud_source_file_id = cc.ud_source_file_id
                WHERE cc.status = 'active'
                  AND cr.file_status = 'Active'
            """

            params = []

            # Add baseline timestamp filter
            if since_timestamp:
                query += " AND cc.created_at < ?"
                params.append(since_timestamp)

            # Add file name filter
            if file_name:
                query += " AND cr.raw_file_nme = ?"
                params.append(file_name)

            params = tuple(params)
        else:
            # No filters - return all active chunks
            query = """
                SELECT
                    content_checksum,
                    chunk_text AS content_text,
                    chunk_index,
                    ud_source_file_id
                FROM content_chunks
                WHERE status = 'active'
            """
            params = ()

        try:
            results = self.execute_query(query, params)

            # Convert to dictionary format expected by change detector
            baseline_data = {}
            for row in results:
                baseline_data[row['content_checksum']] = {
                    'content_text': row['content_text'],
                    'page_number': row.get('chunk_index', 0),
                    'ud_source_file_id': row['ud_source_file_id'],
                }
                if file_name or since_timestamp:
                    # Include file_name when we joined with content_repo
                    baseline_data[row['content_checksum']]['file_name'] = row.get('file_name', '')

            logger.info(
                f"Retrieved {len(baseline_data)} previous checksums "
                f"(file_name={file_name}, since_timestamp={since_timestamp})"
            )
            return baseline_data

        except QueryError as e:
            logger.error(f"Failed to get previous checksums: {e}")
            raise

    def get_new_checksums(
        self,
        file_name: Optional[str] = None,
        since_timestamp: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get new data (checksums created since a timestamp) for change detection.

        This method retrieves checksums for content chunks created on or after a since
        timestamp, which serves as the new content for detecting changes. If file_name
        is provided, only returns checksums for that file.

        Args:
            file_name: Optional file name to filter by
            since_timestamp: Optional timestamp to use as cutoff.
                Only returns chunks created on or after this timestamp (created_at >= since_timestamp).
                Format: 'YYYY-MM-DD HH:MM:SS'

        Returns:
            Dictionary mapping checksum -> content metadata:
                {
                    "abc123...": {
                        "content_text": "...",
                        "file_name": "policy.pdf",
                        "page_number": 1,
                        ...
                    },
                    ...
                }

        Raises:
            QueryError: If database query fails

        Example:
            >>> # Get all new checksums created since a specific date
            >>> new_content = repo.get_new_checksums(
            ...     file_name="policy.pdf",
            ...     since_timestamp="2025-11-02 10:24:29"
            ... )
            >>> print(f"Found {len(new_content)} new checksums")
        """
        # Build query based on parameters
        if file_name or since_timestamp:
            # Join with content_repo to filter by file name and/or timestamp
            query = """
                SELECT
                    cc.content_checksum,
                    cc.chunk_text AS content_text,
                    cc.chunk_index,
                    cc.ud_source_file_id,
                    cr.raw_file_nme AS file_name
                FROM content_chunks cc
                INNER JOIN content_repo cr
                    ON cr.ud_source_file_id = cc.ud_source_file_id
                WHERE cc.status = 'active'
                  AND cr.file_status = 'Active'
            """

            params = []

            # Add since timestamp filter (>= instead of <)
            if since_timestamp:
                query += " AND cc.created_at >= ?"
                params.append(since_timestamp)

            # Add file name filter
            if file_name:
                query += " AND cr.raw_file_nme = ?"
                params.append(file_name)

            params = tuple(params)
        else:
            # No filters - return all active chunks
            query = """
                SELECT
                    content_checksum,
                    chunk_text AS content_text,
                    chunk_index,
                    ud_source_file_id
                FROM content_chunks
                WHERE status = 'active'
            """
            params = ()

        try:
            results = self.execute_query(query, params)

            # Convert to dictionary format expected by change detector
            # NOTE: current_data uses 'text' and 'page_num' (different from previous_data!)
            new_data = {}
            for row in results:
                new_data[row['content_checksum']] = {
                    'text': row['content_text'],  # ✅ Use 'text' for current data
                    'page_num': row.get('chunk_index', 0),  # ✅ Use 'page_num' for current data
                    'ud_source_file_id': row['ud_source_file_id'],
                }
                if file_name or since_timestamp:
                    # Include file_name when we joined with content_repo
                    new_data[row['content_checksum']]['file_name'] = row.get('file_name', '')

            logger.info(
                f"Retrieved {len(new_data)} new checksums "
                f"(file_name={file_name}, since_timestamp={since_timestamp})"
            )
            return new_data

        except QueryError as e:
            logger.error(f"Failed to get new checksums: {e}")
            raise

    def store_detection_results(
        self,
        detection_results: List[Any],  # List[DetectionResult]
        detection_run_id: str,
    ) -> Dict[str, Any]:
        """
        Store detection results into content_change_log table.

        This method converts DetectionResult objects (from change detection)
        into ContentChangeLog records and bulk inserts them. It handles
        validation and provides detailed feedback on success/failure.

        Args:
            detection_results: List of DetectionResult objects from change detection
            detection_run_id: Unique identifier for this detection run

        Returns:
            Dictionary with:
                - success: bool
                - rows_inserted: int
                - message: str
                - errors: List[str] (if any)

        Raises:
            InvalidDetectionResultError: If results are invalid
            QueryError: If database insert fails

        Example:
            >>> from detection.checksum_detector import ChecksumChangeDetector
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> results = detector.detect_changes("file.md", current, previous, "run_001")
            >>>
            >>> result = repo.store_detection_results(results, "run_001")
            >>> print(f"Stored {result['rows_inserted']} changes")
        """
        if not detection_results:
            logger.warning("No detection results to store")
            return {
                'success': True,
                'rows_inserted': 0,
                'message': 'No results to store'
            }

        # Convert DetectionResult objects to DataFrame
        try:
            changes_data = []
            for result in detection_results:
                # Convert DetectionResult to ContentChangeLog format
                # ✅ FIX: For DELETED content, use old_checksum as content_checksum
                content_checksum = result.new_checksum if result.new_checksum else result.old_checksum
                previous_checksum = result.old_checksum if result.new_checksum else None

                change_data = {
                    'content_checksum': content_checksum,  # ✅ Never empty
                    'previous_checksum': previous_checksum,
                    'file_name': result.file_name,
                    'requires_faq_regeneration': result.requires_faq_regeneration,
                    'change_type': result.change_type.value if result.change_type else None,
                    'similarity_score': result.similarity_score,
                    'similarity_method': result.similarity_method,
                    'diff_data': result.llm_diff,  # LLM-friendly diff
                    'total_faqs_at_risk': 0,  # Will be calculated later
                    'affected_question_count': 0,  # Will be calculated later
                    'affected_answer_count': 0,  # Will be calculated later
                    'detection_run_id': detection_run_id,
                    'detection_timestamp': datetime.now(),
                }
                changes_data.append(change_data)

            changes_df = pd.DataFrame(changes_data)

            # Use bulk insert
            return self.log_changes_bulk(changes_df)

        except Exception as e:
            logger.error(f"Failed to convert detection results: {e}")
            raise InvalidDetectionResultError(
                f"Could not convert detection results to change logs: {e}"
            ) from e

    def get_faqs_requiring_regeneration(
        self,
        detection_run_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get FAQs that need regeneration based on content changes.

        Retrieves FAQs linked to changed content via provenance tables.
        Identifies which component (question/answer) is affected.

        Args:
            detection_run_id: Filter by specific detection run (None = all)
            limit: Maximum number of FAQs to return (None = all)

        Returns:
            List of dictionaries with FAQ information:
                - question_id: str
                - question_text: str
                - answer_id: str
                - answer_preview: str (first 200 chars)
                - change_id: int
                - file_name: str
                - old_checksum: str
                - new_checksum: str
                - change_type: str
                - similarity_score: float
                - detection_run_id: str
                - detection_timestamp: datetime
                - faq_component_affected: str ('question', 'answer', or 'both')

        Raises:
            QueryError: If database query fails

        Example:
            >>> faqs = repo.get_faqs_requiring_regeneration("run_001", limit=50)
            >>> for faq in faqs:
            ...     print(f"FAQ {faq['question_id']}: {faq['faq_component_affected']} affected")
        """
        # Build query with optional run filter
        run_filter = ""
        params = ()

        if detection_run_id:
            run_filter = "AND ccl.detection_run_id = ?"
            params = (detection_run_id,)

        # Query for questions affected by content changes
        query = f"""
            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                SUBSTR(a.answer_text, 1, 200) AS answer_preview,
                ccl.change_id,
                ccl.file_name,
                ccl.previous_checksum AS old_checksum,
                ccl.content_checksum AS new_checksum,
                ccl.change_type,
                ccl.similarity_score,
                ccl.detection_run_id,
                ccl.detection_timestamp,
                CASE
                    WHEN qsrc.content_checksum = ccl.previous_checksum THEN 'question'
                    WHEN asrc.content_checksum = ccl.previous_checksum THEN 'answer'
                    ELSE 'both'
                END AS faq_component_affected
            FROM content_change_log ccl
            INNER JOIN faq_question_sources qsrc
                ON qsrc.content_checksum = ccl.previous_checksum
                AND qsrc.is_valid = 1
            INNER JOIN faq_questions q
                ON q.question_id = qsrc.question_id
                AND q.status = 'active'
            LEFT JOIN faq_answers a
                ON a.question_id = q.question_id
                AND a.status = 'active'
            LEFT JOIN faq_answer_sources asrc
                ON asrc.answer_id = a.answer_id
                AND asrc.content_checksum = ccl.previous_checksum
                AND asrc.is_valid = 1
            WHERE ccl.requires_faq_regeneration = 1
              {run_filter}

            UNION

            SELECT DISTINCT
                q.question_id,
                q.question_text,
                a.answer_id,
                SUBSTR(a.answer_text, 1, 200) AS answer_preview,
                ccl.change_id,
                ccl.file_name,
                ccl.previous_checksum AS old_checksum,
                ccl.content_checksum AS new_checksum,
                ccl.change_type,
                ccl.similarity_score,
                ccl.detection_run_id,
                ccl.detection_timestamp,
                'answer' AS faq_component_affected
            FROM content_change_log ccl
            INNER JOIN faq_answer_sources asrc
                ON asrc.content_checksum = ccl.previous_checksum
                AND asrc.is_valid = 1
            INNER JOIN faq_answers a
                ON a.answer_id = asrc.answer_id
                AND a.status = 'active'
            INNER JOIN faq_questions q
                ON q.question_id = a.question_id
                AND q.status = 'active'
            WHERE ccl.requires_faq_regeneration = 1
              {run_filter}

            ORDER BY detection_timestamp DESC, question_id
        """

        if limit:
            query += f" LIMIT {limit}"

        try:
            # Execute query twice (once for each part of UNION) if params provided
            if params:
                results = self.execute_query(query, params + params)  # Double params for UNION
            else:
                results = self.execute_query(query)

            logger.info(f"Found {len(results)} FAQs requiring regeneration")
            return results

        except QueryError as e:
            logger.error(f"Failed to get FAQs requiring regeneration: {e}")
            raise

    def mark_faq_invalidated(
        self,
        question_id: str,
        change_id: int,
        detection_run_id: str,
        answer_id: Optional[str] = None,
    ) -> AuditLogEntry:
        """
        Mark FAQ as invalidated by creating audit log entry.

        This creates a record in faq_audit_log linking the FAQ to the content
        change that invalidated it. This enables traceability and rollback.

        Args:
            question_id: ID of affected question
            change_id: ID of content change that triggered invalidation
            detection_run_id: Detection run identifier
            answer_id: Optional ID of affected answer

        Returns:
            AuditLogEntry object with generated audit_id

        Raises:
            DataValidationError: If validation fails
            QueryError: If database insert fails

        Example:
            >>> audit = repo.mark_faq_invalidated(
            ...     question_id="q_001",
            ...     change_id=42,
            ...     detection_run_id="run_001",
            ...     answer_id="a_001"
            ... )
            >>> print(f"Created audit entry: {audit.audit_id}")
        """
        # Create AuditLogEntry (validates automatically)
        try:
            audit_entry = AuditLogEntry(
                change_id=change_id,
                question_id=question_id,
                answer_id=answer_id,
                detection_run_id=detection_run_id,
                created_at=datetime.now(),
            )
        except ValidationError as e:
            logger.error(f"Validation failed for audit entry: {e}")
            raise DataValidationError(f"Invalid audit entry data: {e}") from e

        # Insert into database
        insert_sql = """
            INSERT INTO faq_audit_log (
                change_id,
                question_id,
                answer_id,
                detection_run_id,
                created_at
            ) VALUES (?, ?, ?, ?, ?)
        """

        params = (
            audit_entry.change_id,
            audit_entry.question_id,
            audit_entry.answer_id,
            audit_entry.detection_run_id,
            audit_entry.created_at,
        )

        try:
            audit_id = self.execute_insert(insert_sql, params)
            audit_entry.audit_id = audit_id

            logger.info(
                f"Created audit entry {audit_id}: question={question_id}, "
                f"answer={answer_id}, change={change_id}"
            )

            return audit_entry

        except QueryError as e:
            logger.error(f"Failed to create audit entry: {e}")
            raise

    def get_content_changes_summary(
        self,
        detection_run_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get summary of content changes with diff data and impact metrics.

        Args:
            detection_run_id: Filter by specific detection run (None = all)
            limit: Maximum number of changes to return (None = all)

        Returns:
            List of dictionaries with change details:
                - change_id: int
                - file_name: str
                - old_checksum: str
                - new_checksum: str
                - change_type: str
                - similarity_score: float
                - similarity_method: str
                - diff_data: str (JSON)
                - total_faqs_at_risk: int
                - affected_question_count: int
                - affected_answer_count: int
                - faqs_saved: int (calculated)
                - detection_run_id: str
                - detection_timestamp: datetime

        Raises:
            QueryError: If database query fails

        Example:
            >>> changes = repo.get_content_changes_summary("run_001")
            >>> for change in changes:
            ...     print(f"{change['file_name']}: {change['faqs_saved']} FAQs saved")
        """
        query = """
            SELECT
                ccl.change_id,
                ccl.file_name,
                ccl.previous_checksum AS old_checksum,
                ccl.content_checksum AS new_checksum,
                ccl.change_type,
                ccl.similarity_score,
                ccl.similarity_method,
                ccl.diff_data,
                ccl.total_faqs_at_risk,
                ccl.affected_question_count,
                ccl.affected_answer_count,
                (ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count)) AS faqs_saved,
                ccl.detection_run_id,
                ccl.detection_timestamp
            FROM content_change_log ccl
        """

        params = ()
        if detection_run_id:
            query += " WHERE ccl.detection_run_id = ?"
            params = (detection_run_id,)

        query += " ORDER BY ccl.detection_timestamp DESC"

        if limit:
            query += f" LIMIT {limit}"

        try:
            results = self.execute_query(query, params)

            logger.info(f"Retrieved {len(results)} content changes")
            return results

        except QueryError as e:
            logger.error(f"Failed to get content changes summary: {e}")
            raise

    # =========================================================================
    # Validation Helpers (Point 133)
    # =========================================================================

    def validate_change_log(
        self,
        content_checksum: str,
        file_name: str,
        detection_run_id: str,
        similarity_score: Optional[float] = None,
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate change log data before insertion.

        This method performs application-level validation beyond what the
        database enforces. It's useful for providing user-friendly error messages.

        Args:
            content_checksum: Content checksum to validate
            file_name: File name to validate
            detection_run_id: Detection run ID to validate
            similarity_score: Optional similarity score to validate

        Returns:
            Tuple of (is_valid: bool, error_message: Optional[str])

        Example:
            >>> is_valid, error = repo.validate_change_log(
            ...     content_checksum="abc123...",
            ...     file_name="policy.pdf",
            ...     detection_run_id="run_001",
            ...     similarity_score=0.85
            ... )
            >>> if not is_valid:
            ...     print(f"Validation error: {error}")
        """
        # Checksum validation
        if not content_checksum or len(content_checksum) != 64:
            return False, "content_checksum must be exactly 64 characters (SHA-256)"

        try:
            int(content_checksum, 16)
        except ValueError:
            return False, "content_checksum must be a valid hexadecimal string"

        # File name validation
        if not file_name or not file_name.strip():
            return False, "file_name is required and cannot be empty"

        # Detection run ID validation
        if not detection_run_id or not detection_run_id.strip():
            return False, "detection_run_id is required and cannot be empty"

        # Similarity score validation
        if similarity_score is not None:
            if not isinstance(similarity_score, (int, float)):
                return False, "similarity_score must be a number"
            if not (0.0 <= similarity_score <= 1.0):
                return False, f"similarity_score must be between 0.0 and 1.0, got {similarity_score}"

        return True, None


# =============================================================================
# Module Exports
# =============================================================================


__all__ = [
    # Main class
    "AuditRepository",

    # Exceptions
    "AuditRepositoryError",
    "ChangeLogNotFoundError",
    "DetectionRunNotFoundError",
    "InvalidDetectionResultError",
    "DuplicateChangeLogError",
]
