"""
Repository Layer - Business Logic for Database Operations

This module provides the repository pattern implementation for database operations.
Repositories sit between business logic and database backends, providing:

- Database-agnostic API for CRUD operations
- Transaction management
- Error handling and retry logic
- Query result mapping to domain models
- Logging and observability

Architecture:
    Application Code
         ↓
    Repository Layer (this module) ← Database-agnostic business logic
         ↓
    Backend Layer (database.backends) ← Database-specific implementation
         ↓
    Actual Database (SQLite, Databricks, etc.)

Design Pattern:
    Repository Pattern + Backend Pattern = Clean Separation of Concerns

Available Repositories:
    - BaseRepository: Base class with common operations
    - ContentRepository: Content & chunks operations
    - FAQRepository: FAQ questions/answers operations
    - AuditRepository: Audit & change detection operations

Example:
    >>> from database.repository import BaseRepository
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Create backend
    >>> config = DatabaseConfig.from_env()
    >>> backend = BackendFactory.create_backend(config)
    >>>
    >>> # Create repository
    >>> class UserRepository(BaseRepository):
    ...     def get_user_by_id(self, user_id: int):
    ...         return self.execute_query_single(
    ...             "SELECT * FROM users WHERE id = ?",
    ...             (user_id,)
    ...         )
    >>>
    >>> # Use repository
    >>> repo = UserRepository(backend)
    >>> user = repo.get_user_by_id(1)

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from database.repository.base import (
    BaseRepository,
    RepositoryError,
    ConnectionError,
    TransactionError,
    QueryError,
    DataValidationError,
    RetryExhaustedError,
)

from database.repository.content_repository import (
    ContentRepository,
    ContentRepositoryError,
    FileNotFoundError,
    ChunkNotFoundError,
    DuplicateFileError,
    ForeignKeyViolationError,
)

from database.repository.faq_repository import (
    FAQRepository,
    FAQRepositoryError,
    QuestionNotFoundError,
    AnswerNotFoundError,
    SourceNotFoundError,
    DuplicateQuestionError,
    DuplicateAnswerError,
    ProvenanceValidationError,
)

from database.repository.audit_repository import (
    AuditRepository,
    AuditRepositoryError,
    ChangeLogNotFoundError,
    DetectionRunNotFoundError,
    InvalidDetectionResultError,
    DuplicateChangeLogError,
)

__all__ = [
    # Base Repository
    "BaseRepository",

    # Content Repository
    "ContentRepository",

    # FAQ Repository
    "FAQRepository",

    # Audit Repository
    "AuditRepository",

    # Base Exceptions
    "RepositoryError",
    "ConnectionError",
    "TransactionError",
    "QueryError",
    "DataValidationError",
    "RetryExhaustedError",

    # Content Repository Exceptions
    "ContentRepositoryError",
    "FileNotFoundError",
    "ChunkNotFoundError",
    "DuplicateFileError",
    "ForeignKeyViolationError",

    # FAQ Repository Exceptions
    "FAQRepositoryError",
    "QuestionNotFoundError",
    "AnswerNotFoundError",
    "SourceNotFoundError",
    "DuplicateQuestionError",
    "DuplicateAnswerError",
    "ProvenanceValidationError",

    # Audit Repository Exceptions
    "AuditRepositoryError",
    "ChangeLogNotFoundError",
    "DetectionRunNotFoundError",
    "InvalidDetectionResultError",
    "DuplicateChangeLogError",
]

__version__ = "1.0.0"
