"""
Base Repository - Foundation for All Repository Classes

This module provides the BaseRepository abstract class that all concrete repositories
inherit from. It encapsulates common database operations while remaining backend-agnostic.

Design Principles:
    - Single Responsibility: Business logic only, no database-specific code
    - Open/Closed: Easy to extend for new repositories
    - Liskov Substitution: All repositories follow same interface
    - Dependency Inversion: Depends on IBackend abstraction, not concrete backends

Features:
    - Connection management via context managers
    - Transaction support with automatic rollback on error
    - Error handling with repository-specific exceptions
    - Structured logging with contextual information
    - Retry logic for transient failures
    - Query result mapping to domain models
    - Generic CRUD operations

Example:
    >>> from database.repository.base import BaseRepository
    >>> from database.backends.sqlite import SQLiteBackend
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Create a concrete repository
    >>> class UserRepository(BaseRepository):
    ...     def get_user_by_id(self, user_id: int):
    ...         return self.execute_query_single(
    ...             "SELECT * FROM users WHERE id = ?",
    ...             (user_id,)
    ...         )
    ...
    ...     def create_user(self, name: str, email: str) -> int:
    ...         with self.transaction():
    ...             user_id = self.execute_insert(
    ...                 "INSERT INTO users (name, email) VALUES (?, ?)",
    ...                 (name, email)
    ...             )
    ...             self.logger.info(f"Created user {user_id}")
    ...             return user_id
    >>>
    >>> # Use repository with automatic connection management
    >>> config = DatabaseConfig(backend="sqlite", db_path="app.db")
    >>> backend = SQLiteBackend(config)
    >>> repo = UserRepository(backend)
    >>>
    >>> with repo:
    ...     user = repo.get_user_by_id(1)
    ...     new_user_id = repo.create_user("Alice", "alice@example.com")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from abc import ABC
from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Tuple, TypeVar, Generic, Type, Callable
from dataclasses import is_dataclass, asdict
import time
from functools import wraps

from database.backends.base import (
    IBackend,
    BackendError,
    ConnectionError as BackendConnectionError,
    QueryError as BackendQueryError,
    CommandError as BackendCommandError,
    TransactionError as BackendTransactionError,
)
from utility.logging import get_logger

# Type variable for generic repository operations
T = TypeVar('T')


# =============================================================================
# Repository-Specific Exceptions
# =============================================================================


class RepositoryError(Exception):
    """Base exception for all repository errors."""
    pass


class ConnectionError(RepositoryError):
    """Raised when repository cannot connect to backend."""
    pass


class TransactionError(RepositoryError):
    """Raised when transaction operation fails."""
    pass


class QueryError(RepositoryError):
    """Raised when query execution fails."""
    pass


class DataValidationError(RepositoryError):
    """Raised when data validation fails."""
    pass


class RetryExhaustedError(RepositoryError):
    """Raised when all retry attempts are exhausted."""
    pass


# =============================================================================
# Retry Configuration
# =============================================================================


class RetryConfig:
    """Configuration for retry logic."""

    def __init__(
        self,
        max_attempts: int = 3,
        initial_delay: float = 0.1,
        max_delay: float = 10.0,
        exponential_base: float = 2.0,
        jitter: bool = True,
    ):
        """
        Initialize retry configuration.

        Args:
            max_attempts: Maximum number of retry attempts (default: 3)
            initial_delay: Initial delay in seconds (default: 0.1)
            max_delay: Maximum delay in seconds (default: 10.0)
            exponential_base: Base for exponential backoff (default: 2.0)
            jitter: Add random jitter to delay (default: True)

        Example:
            >>> config = RetryConfig(max_attempts=5, initial_delay=0.5)
        """
        self.max_attempts = max_attempts
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter

    def get_delay(self, attempt: int) -> float:
        """
        Calculate delay for given attempt number.

        Uses exponential backoff with optional jitter.

        Args:
            attempt: Current attempt number (0-indexed)

        Returns:
            Delay in seconds

        Example:
            >>> config = RetryConfig()
            >>> config.get_delay(0)  # First retry
            0.1
            >>> config.get_delay(1)  # Second retry
            0.2
            >>> config.get_delay(2)  # Third retry
            0.4
        """
        delay = min(
            self.initial_delay * (self.exponential_base ** attempt),
            self.max_delay
        )

        if self.jitter:
            import random
            delay = delay * (0.5 + random.random())

        return delay


# =============================================================================
# Base Repository Class
# =============================================================================


class BaseRepository(ABC, Generic[T]):
    """
    Abstract base class for all repository implementations.

    Provides common database operations with:
    - Connection management
    - Transaction support
    - Error handling
    - Logging
    - Retry logic
    - Query result mapping

    Type Parameter:
        T: Type of domain model this repository works with

    Attributes:
        backend: Database backend (IBackend implementation)
        logger: Structured logger instance
        retry_config: Retry configuration for transient failures

    Example:
        >>> class UserRepository(BaseRepository[User]):
        ...     def get_by_id(self, user_id: int) -> Optional[User]:
        ...         result = self.execute_query_single(
        ...             "SELECT * FROM users WHERE id = ?",
        ...             (user_id,)
        ...         )
        ...         return self.map_to_model(result, User) if result else None
        >>>
        >>> backend = SQLiteBackend(config)
        >>> repo = UserRepository(backend)
    """

    def __init__(
        self,
        backend: IBackend,
        retry_config: Optional[RetryConfig] = None,
        auto_connect: bool = True,
    ):
        """
        Initialize repository with database backend.

        Args:
            backend: Database backend (SQLite, Databricks, etc.)
            retry_config: Optional retry configuration (uses defaults if None)
            auto_connect: Automatically connect to backend on initialization

        Raises:
            TypeError: If backend is not an IBackend instance
            ConnectionError: If auto_connect=True and connection fails

        Example:
            >>> backend = SQLiteBackend(config)
            >>> repo = MyRepository(backend)
            >>> # Repository is now ready to use
        """
        # Validate backend
        if not isinstance(backend, IBackend):
            raise TypeError(
                f"backend must be an IBackend instance, got {type(backend).__name__}"
            )

        self.backend = backend
        self.retry_config = retry_config or RetryConfig()
        self._logger = get_logger(self.__class__.__name__)

        # Auto-connect if requested
        if auto_connect and not self.backend.is_connected:
            try:
                self.backend.connect()
                self._logger.info(f"Repository connected to {self.backend}")
            except BackendConnectionError as e:
                self._logger.error(f"Failed to connect to backend: {e}")
                raise ConnectionError(f"Could not connect to backend: {e}") from e

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def logger(self):
        """Get logger instance."""
        return self._logger

    @property
    def is_connected(self) -> bool:
        """Check if repository is connected to backend."""
        return self.backend.is_connected

    # =========================================================================
    # Connection Management (Point 79)
    # =========================================================================

    def connect(self) -> None:
        """
        Explicitly connect to database backend.

        Usually not needed as repositories auto-connect by default.

        Raises:
            ConnectionError: If connection fails

        Example:
            >>> repo = MyRepository(backend, auto_connect=False)
            >>> repo.connect()
        """
        try:
            self.backend.connect()
            self._logger.info("Repository connected to backend")
        except BackendConnectionError as e:
            self._logger.error(f"Connection failed: {e}")
            raise ConnectionError(f"Could not connect: {e}") from e

    def close(self) -> None:
        """
        Close connection to database backend.

        Safe to call multiple times. Will rollback any active transaction.

        Example:
            >>> repo.close()
        """
        try:
            self.backend.close()
            self._logger.info("Repository connection closed")
        except Exception as e:
            self._logger.error(f"Error closing connection: {e}")

    @contextmanager
    def connection(self):
        """
        Context manager for connection lifecycle.

        Automatically connects on enter and closes on exit.

        Yields:
            Self reference for chaining

        Example:
            >>> with repo.connection():
            ...     users = repo.get_all_users()
            ...     # Connection automatically closed after block
        """
        was_connected = self.is_connected

        try:
            if not was_connected:
                self.connect()
            yield self
        finally:
            if not was_connected:
                self.close()

    # =========================================================================
    # Transaction Management (Point 80)
    # =========================================================================

    @contextmanager
    def transaction(self):
        """
        Context manager for database transactions.

        Automatically commits on success or rolls back on error.
        Supports nested transactions (innermost wins).

        Yields:
            Self reference for chaining

        Raises:
            TransactionError: If transaction operation fails

        Example:
            >>> with repo.transaction():
            ...     repo.execute_command("INSERT INTO users ...")
            ...     repo.execute_command("INSERT INTO audit_log ...")
            ...     # Both succeed or both fail atomically
        """
        try:
            self.backend.begin_transaction()
            self._logger.debug("Transaction started")

            yield self

            self.backend.commit()
            self._logger.debug("Transaction committed successfully")

        except Exception as e:
            self._logger.error(f"Transaction failed, rolling back: {e}")
            try:
                self.backend.rollback()
                self._logger.debug("Transaction rolled back")
            except BackendTransactionError as rollback_error:
                self._logger.error(f"Rollback failed: {rollback_error}")
                raise TransactionError(
                    f"Transaction failed and rollback failed: {rollback_error}"
                ) from rollback_error

            # Re-raise original error wrapped in TransactionError
            raise TransactionError(f"Transaction failed: {e}") from e

    # =========================================================================
    # Error Handling (Point 81)
    # =========================================================================

    def _handle_backend_error(self, error: Exception, operation: str) -> Exception:
        """
        Convert backend errors to repository errors.

        Wraps backend-specific exceptions in repository-level exceptions,
        adding context and logging.

        Args:
            error: Original backend error
            operation: Description of operation that failed

        Returns:
            Wrapped repository exception

        Example:
            >>> try:
            ...     self.backend.execute_query("INVALID SQL")
            ... except BackendQueryError as e:
            ...     raise self._handle_backend_error(e, "fetch users")
        """
        self._logger.error(f"{operation} failed: {error}", exc_info=True)

        if isinstance(error, BackendConnectionError):
            return ConnectionError(f"{operation}: {error}")
        elif isinstance(error, BackendQueryError):
            return QueryError(f"{operation}: {error}")
        elif isinstance(error, BackendCommandError):
            return QueryError(f"{operation}: {error}")
        elif isinstance(error, BackendTransactionError):
            return TransactionError(f"{operation}: {error}")
        else:
            return RepositoryError(f"{operation}: {error}")

    # =========================================================================
    # Retry Logic (Point 83)
    # =========================================================================

    def _should_retry(self, error: Exception) -> bool:
        """
        Determine if operation should be retried based on error type.

        Args:
            error: Exception that occurred

        Returns:
            True if operation should be retried

        Example:
            >>> error = ConnectionError("Timeout")
            >>> repo._should_retry(error)
            True
        """
        # Retry on transient connection errors
        if isinstance(error, (ConnectionError, BackendConnectionError)):
            return True

        # Retry on database lock errors (SQLite)
        if isinstance(error, (BackendQueryError, BackendCommandError)):
            error_msg = str(error).lower()
            if any(keyword in error_msg for keyword in ["locked", "timeout", "busy"]):
                return True

        # Don't retry data validation or transaction errors
        return False

    def _retry_with_backoff(
        self,
        operation: Callable[[], T],
        operation_name: str,
    ) -> T:
        """
        Execute operation with exponential backoff retry logic.

        Args:
            operation: Function to execute
            operation_name: Human-readable operation name (for logging)

        Returns:
            Result of operation

        Raises:
            RetryExhaustedError: If all retry attempts fail

        Example:
            >>> def fetch_data():
            ...     return self.backend.execute_query("SELECT * FROM users")
            >>> result = self._retry_with_backoff(fetch_data, "fetch users")
        """
        last_error = None

        for attempt in range(self.retry_config.max_attempts):
            try:
                if attempt > 0:
                    self._logger.debug(
                        f"Retry attempt {attempt + 1}/{self.retry_config.max_attempts} "
                        f"for {operation_name}"
                    )

                return operation()

            except Exception as e:
                last_error = e

                if not self._should_retry(e):
                    self._logger.debug(f"Error not retryable: {e}")
                    raise

                if attempt < self.retry_config.max_attempts - 1:
                    delay = self.retry_config.get_delay(attempt)
                    self._logger.warning(
                        f"{operation_name} failed (attempt {attempt + 1}), "
                        f"retrying in {delay:.2f}s: {e}"
                    )
                    time.sleep(delay)
                else:
                    self._logger.error(
                        f"{operation_name} failed after {self.retry_config.max_attempts} attempts"
                    )

        # All retries exhausted
        raise RetryExhaustedError(
            f"{operation_name} failed after {self.retry_config.max_attempts} attempts. "
            f"Last error: {last_error}"
        ) from last_error

    def with_retry(self, func: Callable) -> Callable:
        """
        Decorator to add retry logic to repository methods.

        Args:
            func: Function to wrap with retry logic

        Returns:
            Wrapped function

        Example:
            >>> class MyRepository(BaseRepository):
            ...     @with_retry
            ...     def get_user(self, user_id: int):
            ...         return self.execute_query_single(
            ...             "SELECT * FROM users WHERE id = ?",
            ...             (user_id,)
            ...         )
        """
        @wraps(func)
        def wrapper(*args, **kwargs):
            return self._retry_with_backoff(
                lambda: func(*args, **kwargs),
                func.__name__
            )
        return wrapper

    # =========================================================================
    # Query Execution (Read Operations)
    # =========================================================================

    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None,
        with_retry: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Execute SELECT query and return results as list of dictionaries.

        Args:
            query: SQL SELECT statement
            params: Optional query parameters (for parameterized queries)
            timeout: Optional timeout in seconds
            with_retry: Enable retry logic for transient failures

        Returns:
            List of dictionaries (column_name → value)

        Raises:
            QueryError: If query execution fails
            ConnectionError: If not connected

        Example:
            >>> users = repo.execute_query(
            ...     "SELECT * FROM users WHERE status = ?",
            ...     ("active",)
            ... )
            >>> len(users)
            42
        """
        if not self.is_connected:
            raise ConnectionError("Repository not connected to backend")

        operation = lambda: self.backend.execute_query(query, params, timeout)
        operation_name = f"execute_query: {query[:50]}..."

        try:
            if with_retry:
                results = self._retry_with_backoff(operation, operation_name)
            else:
                results = operation()

            self._logger.debug(f"Query returned {len(results)} rows")
            return results

        except BackendError as e:
            raise self._handle_backend_error(e, "Query execution")

    def execute_query_single(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None,
        with_retry: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """
        Execute SELECT query expecting 0 or 1 result.

        Args:
            query: SQL SELECT statement
            params: Optional query parameters
            timeout: Optional timeout in seconds
            with_retry: Enable retry logic

        Returns:
            Dictionary representing the row, or None if no results

        Raises:
            QueryError: If query execution fails or returns multiple rows
            ConnectionError: If not connected

        Example:
            >>> user = repo.execute_query_single(
            ...     "SELECT * FROM users WHERE id = ?",
            ...     (1,)
            ... )
            >>> user['name']
            'Alice'
        """
        results = self.execute_query(query, params, timeout, with_retry)

        if len(results) == 0:
            return None
        elif len(results) == 1:
            return results[0]
        else:
            raise QueryError(
                f"Query expected to return 0 or 1 row, got {len(results)} rows. "
                f"Query: {query[:100]}..."
            )

    def execute_command(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None,
        with_retry: bool = True,
    ) -> int:
        """
        Execute INSERT, UPDATE, or DELETE command.

        Args:
            command: SQL INSERT/UPDATE/DELETE statement
            params: Optional command parameters
            timeout: Optional timeout in seconds
            with_retry: Enable retry logic

        Returns:
            Number of rows affected

        Raises:
            QueryError: If command execution fails
            ConnectionError: If not connected

        Example:
            >>> rows = repo.execute_command(
            ...     "UPDATE users SET status = ? WHERE id = ?",
            ...     ("inactive", 42)
            ... )
            >>> rows
            1
        """
        if not self.is_connected:
            raise ConnectionError("Repository not connected to backend")

        operation = lambda: self.backend.execute_command(command, params, timeout)
        operation_name = f"execute_command: {command[:50]}..."

        try:
            if with_retry:
                rows_affected = self._retry_with_backoff(operation, operation_name)
            else:
                rows_affected = operation()

            self._logger.debug(f"Command affected {rows_affected} rows")
            return rows_affected

        except BackendError as e:
            raise self._handle_backend_error(e, "Command execution")

    def execute_insert(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None,
        with_retry: bool = True,
    ) -> int:
        """
        Execute INSERT and return the inserted row ID.

        Convenience method for INSERT operations that need the new ID.

        Args:
            command: SQL INSERT statement
            params: Optional command parameters
            timeout: Optional timeout in seconds
            with_retry: Enable retry logic

        Returns:
            ID of inserted row (last insert rowid)

        Raises:
            QueryError: If insert fails
            ConnectionError: If not connected

        Example:
            >>> user_id = repo.execute_insert(
            ...     "INSERT INTO users (name, email) VALUES (?, ?)",
            ...     ("Bob", "bob@example.com")
            ... )
            >>> user_id
            43
        """
        self.execute_command(command, params, timeout, with_retry)

        # Get last inserted ID
        result = self.execute_query_single("SELECT last_insert_rowid() as id")
        return result['id'] if result else -1

    # =========================================================================
    # Query Result Mapping (Point 84)
    # =========================================================================

    def map_to_model(
        self,
        data: Dict[str, Any],
        model_class: Type[T],
        strict: bool = False,
    ) -> T:
        """
        Map dictionary result to domain model instance.

        Supports dataclasses and regular classes with __init__.

        Args:
            data: Dictionary with column data
            model_class: Target model class
            strict: If True, raise error if extra keys in data

        Returns:
            Instance of model_class

        Raises:
            DataValidationError: If mapping fails

        Example:
            >>> @dataclass
            ... class User:
            ...     id: int
            ...     name: str
            ...     email: str
            >>>
            >>> result = {"id": 1, "name": "Alice", "email": "alice@example.com"}
            >>> user = repo.map_to_model(result, User)
            >>> user.name
            'Alice'
        """
        try:
            # Handle dataclasses
            if is_dataclass(model_class):
                # Filter to only fields that exist in dataclass
                field_names = {f.name for f in model_class.__dataclass_fields__.values()}
                filtered_data = {k: v for k, v in data.items() if k in field_names}

                if strict and len(filtered_data) != len(data):
                    extra_keys = set(data.keys()) - field_names
                    raise DataValidationError(
                        f"Extra keys not in {model_class.__name__}: {extra_keys}"
                    )

                return model_class(**filtered_data)

            # Handle regular classes
            else:
                return model_class(**data)

        except TypeError as e:
            self._logger.error(f"Failed to map data to {model_class.__name__}: {e}")
            raise DataValidationError(
                f"Could not map data to {model_class.__name__}: {e}"
            ) from e

    def map_to_models(
        self,
        data_list: List[Dict[str, Any]],
        model_class: Type[T],
        strict: bool = False,
    ) -> List[T]:
        """
        Map list of dictionaries to list of model instances.

        Args:
            data_list: List of dictionaries
            model_class: Target model class
            strict: If True, raise error if extra keys in data

        Returns:
            List of model instances

        Raises:
            DataValidationError: If mapping fails for any item

        Example:
            >>> results = [
            ...     {"id": 1, "name": "Alice"},
            ...     {"id": 2, "name": "Bob"}
            ... ]
            >>> users = repo.map_to_models(results, User)
            >>> len(users)
            2
        """
        try:
            return [
                self.map_to_model(data, model_class, strict)
                for data in data_list
            ]
        except DataValidationError:
            raise

    def model_to_dict(self, model: T) -> Dict[str, Any]:
        """
        Convert model instance to dictionary.

        Supports dataclasses and models with to_dict() method.

        Args:
            model: Model instance

        Returns:
            Dictionary representation

        Example:
            >>> user = User(id=1, name="Alice", email="alice@example.com")
            >>> data = repo.model_to_dict(user)
            >>> data['name']
            'Alice'
        """
        if is_dataclass(model):
            return asdict(model)
        elif hasattr(model, 'to_dict'):
            return model.to_dict()
        elif hasattr(model, '__dict__'):
            return model.__dict__
        else:
            raise DataValidationError(
                f"Cannot convert {type(model).__name__} to dict"
            )

    # =========================================================================
    # Context Manager Support
    # =========================================================================

    def __enter__(self):
        """
        Context manager entry - ensure connection.

        Example:
            >>> with repo:
            ...     users = repo.get_all_users()
        """
        if not self.is_connected:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close connection."""
        self.close()
        return False  # Don't suppress exceptions

    # =========================================================================
    # String Representation
    # =========================================================================

    def __repr__(self) -> str:
        """String representation."""
        status = "connected" if self.is_connected else "disconnected"
        return (
            f"{self.__class__.__name__}("
            f"backend={self.backend.backend_type.value}, "
            f"status={status})"
        )


__all__ = [
    # Main class
    "BaseRepository",

    # Exceptions
    "RepositoryError",
    "ConnectionError",
    "TransactionError",
    "QueryError",
    "DataValidationError",
    "RetryExhaustedError",

    # Configuration
    "RetryConfig",
]
