"""
FAQ Repository - Database operations for FAQ questions, answers, and provenance

This module provides the FAQRepository class for managing FAQ data and source tracking.
It follows the Repository Pattern to keep business logic separate from database implementation.

Responsibilities:
    - FAQ question management (CRUD operations)
    - FAQ answer management (CRUD operations)
    - Question source tracking (provenance)
    - Answer source tracking (provenance)
    - Checksum-based FAQ lookup
    - FAQ invalidation and status updates
    - Statistics and reporting

Design Principles:
    - Single Responsibility: Only FAQ and provenance operations
    - Database-Agnostic: Works with SQLite, Databricks, or any IBackend
    - Validation: Enforces business rules before database operations
    - Transaction Safety: Uses transactions for multi-step operations
    - Temporal Validity: Supports time-based provenance tracking

Tables Managed:
    - faq_questions: FAQ questions with metadata
    - faq_answers: FAQ answers (1:1 with questions)
    - faq_question_sources: Question provenance (M:N with content_chunks)
    - faq_answer_sources: Answer provenance (M:N with content_chunks)

Example Usage:
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Create backend and repository
    >>> config = DatabaseConfig.from_env()
    >>> backend = BackendFactory.create_backend(config)
    >>> repo = FAQRepository(backend)
    >>>
    >>> # Get question by ID
    >>> question = repo.get_question_by_id("Q001")
    >>> print(question['question_text'])
    >>>
    >>> # Ingest questions in bulk
    >>> df = pd.DataFrame({
    ...     'question_id': ['Q001', 'Q002'],
    ...     'question_text': ['What is...?', 'How do...?']
    ... })
    >>> result = repo.ingest_questions(df)
    >>> print(result['rows_inserted'])

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import pandas as pd

from database.repository.base import (
    BaseRepository,
    RepositoryError,
    QueryError,
    DataValidationError,
)
from database.models import (
    FAQQuestion,
    FAQAnswer,
    FAQQuestionSource,
    FAQAnswerSource,
    FAQStatus,
    SourceType,
    GenerationMethod,
    InvalidationReason,
    AnswerFormat,
    ValidationError,
)
from database.backends.base import IBackend
from utility.logging import get_logger

# Module-level logger
logger = get_logger(__name__)


# =============================================================================
# FAQ Repository Exceptions
# =============================================================================


class FAQRepositoryError(RepositoryError):
    """Base exception for FAQ repository errors."""
    pass


class QuestionNotFoundError(FAQRepositoryError):
    """Raised when question cannot be found."""
    pass


class AnswerNotFoundError(FAQRepositoryError):
    """Raised when answer cannot be found."""
    pass


class SourceNotFoundError(FAQRepositoryError):
    """Raised when source cannot be found."""
    pass


class DuplicateQuestionError(FAQRepositoryError):
    """Raised when attempting to insert duplicate question."""
    pass


class DuplicateAnswerError(FAQRepositoryError):
    """Raised when attempting to insert duplicate answer."""
    pass


class ForeignKeyViolationError(FAQRepositoryError):
    """Raised when foreign key constraint would be violated."""
    pass


class ProvenanceValidationError(FAQRepositoryError):
    """Raised when provenance data validation fails."""
    pass


# =============================================================================
# FAQ Repository Implementation
# =============================================================================


class FAQRepository(BaseRepository[FAQQuestion]):
    """
    Repository for FAQ questions, answers, and source provenance.

    Provides database-agnostic operations for:
    - Question management (CRUD)
    - Answer management (CRUD)
    - Question source tracking (provenance)
    - Answer source tracking (provenance)
    - FAQ statistics and reporting
    - Temporal validity tracking

    All methods handle both SQLite and Databricks transparently via IBackend interface.

    Attributes:
        backend: Database backend instance (IBackend)
        logger: Logger instance for this repository

    Example:
        >>> repo = FAQRepository(backend)
        >>>
        >>> # Retrieve question
        >>> question = repo.get_question_by_id("Q001")
        >>> if question:
        ...     print(f"Question: {question['question_text']}")
        >>>
        >>> # Ingest questions
        >>> questions_df = pd.DataFrame(...)
        >>> result = repo.ingest_questions(questions_df)
        >>> print(f"Inserted {result['rows_inserted']} questions")
    """

    def __init__(self, backend: IBackend, **kwargs):
        """
        Initialize FAQRepository.

        Args:
            backend: Database backend (SQLite, Databricks, etc.)
            **kwargs: Additional arguments passed to BaseRepository

        Example:
            >>> backend = SQLiteBackend(db_path="faq.db")
            >>> repo = FAQRepository(backend)
        """
        super().__init__(backend, **kwargs)
        self._logger = get_logger(f"{self.__class__.__name__}")

    # =========================================================================
    # Question Retrieval Operations (Point 107)
    # =========================================================================

    def get_question_by_id(
        self,
        question_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get FAQ question by ID.

        Point 107 in migration plan.

        Args:
            question_id: Question ID (primary key)

        Returns:
            Dictionary with question data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If question_id is empty

        Example:
            >>> question = repo.get_question_by_id("Q001")
            >>> if question:
            ...     print(f"Question: {question['question_text']}")
            ...     print(f"Status: {question['status']}")
        """
        # Validation
        if not question_id or not question_id.strip():
            raise ValueError("question_id cannot be empty")

        self._logger.debug(f"Retrieving question: {question_id}")

        try:
            query = "SELECT * FROM faq_questions WHERE question_id = ?"
            result = self.execute_query_single(query, (question_id,))

            if result:
                self._logger.debug(f"Found question: {question_id}")
            else:
                self._logger.debug(f"Question not found: {question_id}")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get question '{question_id}': {e}")
            raise QueryError(f"Failed to retrieve question '{question_id}': {e}") from e

    def list_questions(
        self,
        status: Optional[str] = None,
        source_type: Optional[str] = None,
        generation_method: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        order_by: str = "created_at DESC"
    ) -> List[Dict[str, Any]]:
        """
        List questions with optional filtering.

        Similar to ContentRepository.list_files() for consistency.

        Args:
            status: Optional status filter (active, invalidated, archived, deleted)
            source_type: Optional source type filter (document, synthetic, hybrid)
            generation_method: Optional generation method filter (LLM, manual, hybrid)
            limit: Maximum number of results
            offset: Number of results to skip (for pagination)
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with question data

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all active questions
            >>> questions = repo.list_questions(status="active")
            >>> print(f"Found {len(questions)} active questions")
            >>>
            >>> # Get first 10 LLM-generated questions
            >>> questions = repo.list_questions(generation_method="LLM", limit=10)
            >>>
            >>> # Pagination (page 2, 20 items per page)
            >>> page_2 = repo.list_questions(limit=20, offset=20)
        """
        self._logger.debug(
            f"Listing questions (status={status}, source_type={source_type}, "
            f"generation_method={generation_method}, limit={limit}, offset={offset})"
        )

        try:
            # Build query dynamically based on filters
            query_parts = ["SELECT * FROM faq_questions"]
            where_clauses = []
            params = []

            # Add filters
            if status:
                where_clauses.append("status = ?")
                params.append(status)

            if source_type:
                where_clauses.append("source_type = ?")
                params.append(source_type)

            if generation_method:
                where_clauses.append("generation_method = ?")
                params.append(generation_method)

            # Add WHERE clause if filters exist
            if where_clauses:
                query_parts.append("WHERE " + " AND ".join(where_clauses))

            # Add ORDER BY
            query_parts.append(f"ORDER BY {order_by}")

            # Add LIMIT and OFFSET
            if limit is not None:
                query_parts.append(f"LIMIT {limit}")
            if offset is not None:
                query_parts.append(f"OFFSET {offset}")

            query = " ".join(query_parts)

            results = self.execute_query(query, tuple(params) if params else None)

            self._logger.debug(f"Found {len(results)} questions")
            return results

        except Exception as e:
            self._logger.error(f"Failed to list questions: {e}")
            raise QueryError(f"Failed to list questions: {e}") from e

    # =========================================================================
    # Answer Retrieval Operations (Point 108)
    # =========================================================================

    def get_answer_by_id(
        self,
        answer_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get FAQ answer by ID.

        Point 108 in migration plan.

        Args:
            answer_id: Answer ID (primary key)

        Returns:
            Dictionary with answer data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If answer_id is empty

        Example:
            >>> answer = repo.get_answer_by_id("A001")
            >>> if answer:
            ...     print(f"Answer: {answer['answer_text'][:100]}...")
            ...     print(f"Question ID: {answer['question_id']}")
        """
        # Validation
        if not answer_id or not answer_id.strip():
            raise ValueError("answer_id cannot be empty")

        self._logger.debug(f"Retrieving answer: {answer_id}")

        try:
            query = "SELECT * FROM faq_answers WHERE answer_id = ?"
            result = self.execute_query_single(query, (answer_id,))

            if result:
                self._logger.debug(f"Found answer: {answer_id}")
            else:
                self._logger.debug(f"Answer not found: {answer_id}")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get answer '{answer_id}': {e}")
            raise QueryError(f"Failed to retrieve answer '{answer_id}': {e}") from e

    def get_answer_by_question_id(
        self,
        question_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get FAQ answer by question ID (1:1 relationship).

        Args:
            question_id: Question ID

        Returns:
            Dictionary with answer data, or None if not found

        Raises:
            QueryError: If query execution fails
            ValueError: If question_id is empty

        Example:
            >>> answer = repo.get_answer_by_question_id("Q001")
            >>> if answer:
            ...     print(f"Answer ID: {answer['answer_id']}")
        """
        # Validation
        if not question_id or not question_id.strip():
            raise ValueError("question_id cannot be empty")

        self._logger.debug(f"Retrieving answer for question: {question_id}")

        try:
            query = "SELECT * FROM faq_answers WHERE question_id = ?"
            result = self.execute_query_single(query, (question_id,))

            if result:
                self._logger.debug(f"Found answer for question: {question_id}")
            else:
                self._logger.debug(f"No answer found for question: {question_id}")

            return result

        except Exception as e:
            self._logger.error(f"Failed to get answer for question '{question_id}': {e}")
            raise QueryError(f"Failed to retrieve answer for question '{question_id}': {e}") from e

    def list_answers(
        self,
        question_id: Optional[str] = None,
        status: Optional[str] = None,
        answer_format: Optional[str] = None,
        min_confidence: Optional[float] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        order_by: str = "created_at DESC"
    ) -> List[Dict[str, Any]]:
        """
        List answers with optional filtering.

        Similar to list_questions() for consistency.

        Args:
            question_id: Optional question ID filter
            status: Optional status filter (active, invalidated, archived, deleted)
            answer_format: Optional format filter (html, markdown, plain)
            min_confidence: Optional minimum confidence score (0.0 to 1.0)
            limit: Maximum number of results
            offset: Number of results to skip (for pagination)
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with answer data

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all active answers
            >>> answers = repo.list_answers(status="active")
            >>> print(f"Found {len(answers)} active answers")
            >>>
            >>> # Get high-confidence HTML answers
            >>> answers = repo.list_answers(
            ...     answer_format="html",
            ...     min_confidence=0.8,
            ...     limit=10
            ... )
            >>>
            >>> # Get answers for a specific question
            >>> answers = repo.list_answers(question_id="Q001")
        """
        self._logger.debug(
            f"Listing answers (question_id={question_id}, status={status}, "
            f"format={answer_format}, min_confidence={min_confidence}, limit={limit})"
        )

        try:
            # Build query dynamically based on filters
            query_parts = ["SELECT * FROM faq_answers"]
            where_clauses = []
            params = []

            # Add filters
            if question_id:
                where_clauses.append("question_id = ?")
                params.append(question_id)

            if status:
                where_clauses.append("status = ?")
                params.append(status)

            if answer_format:
                where_clauses.append("answer_format = ?")
                params.append(answer_format)

            if min_confidence is not None:
                where_clauses.append("confidence_score >= ?")
                params.append(min_confidence)

            # Add WHERE clause if filters exist
            if where_clauses:
                query_parts.append("WHERE " + " AND ".join(where_clauses))

            # Add ORDER BY
            query_parts.append(f"ORDER BY {order_by}")

            # Add LIMIT and OFFSET
            if limit is not None:
                query_parts.append(f"LIMIT {limit}")
            if offset is not None:
                query_parts.append(f"OFFSET {offset}")

            query = " ".join(query_parts)

            results = self.execute_query(query, tuple(params) if params else None)

            self._logger.debug(f"Found {len(results)} answers")
            return results

        except Exception as e:
            self._logger.error(f"Failed to list answers: {e}")
            raise QueryError(f"Failed to list answers: {e}") from e

    # =========================================================================
    # Checksum-based FAQ Lookup (Point 109)
    # =========================================================================

    def get_faqs_by_checksum(
        self,
        content_checksum: str,
        include_invalid: bool = False
    ) -> Dict[str, Any]:
        """
        Find FAQs linked to a specific content checksum.

        Point 109 in migration plan.

        Returns both questions and answers that reference the given checksum.

        Args:
            content_checksum: Content checksum (SHA-256, 64 characters)
            include_invalid: Include invalidated FAQs (default: False)

        Returns:
            Dictionary with:
                - questions: List of question dicts
                - answers: List of answer dicts
                - total_questions: Count of questions
                - total_answers: Count of answers

        Raises:
            QueryError: If query execution fails
            ValueError: If checksum is invalid

        Example:
            >>> checksum = "abc123..."
            >>> faqs = repo.get_faqs_by_checksum(checksum)
            >>> print(f"Found {faqs['total_questions']} questions")
            >>> print(f"Found {faqs['total_answers']} answers")
            >>> for q in faqs['questions']:
            ...     print(f"  - {q['question_text']}")
        """
        # Validation
        if not content_checksum or not isinstance(content_checksum, str):
            raise ValueError("content_checksum must be a non-empty string")

        if len(content_checksum) != 64:
            raise ValueError(f"content_checksum must be 64 characters (SHA-256), got {len(content_checksum)}")

        self._logger.debug(
            f"Finding FAQs for checksum: {content_checksum[:16]}... "
            f"(include_invalid={include_invalid})"
        )

        try:
            # Build query for questions
            question_query = """
                SELECT DISTINCT q.*
                FROM faq_questions q
                JOIN faq_question_sources qs ON q.question_id = qs.question_id
                WHERE qs.content_checksum = ?
            """
            if not include_invalid:
                question_query += " AND qs.is_valid = 1"

            questions = self.execute_query(question_query, (content_checksum,))

            # Build query for answers
            answer_query = """
                SELECT DISTINCT a.*
                FROM faq_answers a
                JOIN faq_answer_sources asrc ON a.answer_id = asrc.answer_id
                WHERE asrc.content_checksum = ?
            """
            if not include_invalid:
                answer_query += " AND asrc.is_valid = 1"

            answers = self.execute_query(answer_query, (content_checksum,))

            result = {
                'questions': questions,
                'answers': answers,
                'total_questions': len(questions),
                'total_answers': len(answers)
            }

            self._logger.debug(
                f"Found {result['total_questions']} questions and "
                f"{result['total_answers']} answers for checksum"
            )

            return result

        except Exception as e:
            self._logger.error(f"Failed to get FAQs by checksum: {e}")
            raise QueryError(f"Failed to retrieve FAQs by checksum: {e}") from e

    # =========================================================================
    # Question Ingestion Operations (Point 110)
    # =========================================================================

    def ingest_questions(
        self,
        questions_df: pd.DataFrame,
        validate: bool = True,
        if_exists: str = "append"
    ) -> Dict[str, Any]:
        """
        Batch insert questions into faq_questions table.

        Point 110 in migration plan.

        Args:
            questions_df: DataFrame with question data
            validate: Validate data before insert (default: True)
            if_exists: What to do if data exists:
                - 'append': Insert new rows (default)
                - 'replace': Drop and recreate table (dangerous!)
                - 'fail': Raise error if table has data

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - errors (List[str], optional): Validation errors if any

        Raises:
            DataValidationError: If validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - question_id (required, unique)
            - question_text (required)

        Optional DataFrame Columns:
            - source_type
            - generation_method
            - status (default: "active")
            - created_at (default: now)
            - modified_at (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'question_id': ['Q001', 'Q002'],
            ...     'question_text': ['What is...?', 'How do...?'],
            ...     'status': ['active', 'active']
            ... })
            >>> result = repo.ingest_questions(df)
            >>> print(f"Inserted {result['rows_inserted']} questions")
        """
        self._logger.info(f"Ingesting {len(questions_df)} questions in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if questions_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            required_cols = ['question_id', 'question_text']
            missing_cols = [col for col in required_cols if col not in questions_df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")

            if not errors:  # Only validate values if columns exist
                # Validate question_id (not empty)
                if questions_df['question_id'].isna().any():
                    count = questions_df['question_id'].isna().sum()
                    errors.append(f"{count} rows have null question_id")

                empty_ids = questions_df['question_id'].str.strip() == ''
                if empty_ids.any():
                    count = empty_ids.sum()
                    errors.append(f"{count} rows have empty question_id")

                # Validate question_text (not empty)
                if questions_df['question_text'].isna().any():
                    count = questions_df['question_text'].isna().sum()
                    errors.append(f"{count} rows have null question_text")

                empty_text = questions_df['question_text'].str.strip() == ''
                if empty_text.any():
                    count = empty_text.sum()
                    errors.append(f"{count} rows have empty question_text")

                # Validate status if present
                if 'status' in questions_df.columns:
                    valid_statuses = {s.value for s in FAQStatus}
                    invalid_statuses = ~questions_df['status'].isna() & \
                                     ~questions_df['status'].isin(valid_statuses)
                    if invalid_statuses.any():
                        invalid_values = questions_df.loc[invalid_statuses, 'status'].unique()
                        errors.append(
                            f"Invalid status values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_statuses)}"
                        )

                # Validate source_type if present
                if 'source_type' in questions_df.columns:
                    valid_types = {s.value for s in SourceType}
                    invalid_types = ~questions_df['source_type'].isna() & \
                                  ~questions_df['source_type'].isin(valid_types)
                    if invalid_types.any():
                        invalid_values = questions_df.loc[invalid_types, 'source_type'].unique()
                        errors.append(
                            f"Invalid source_type values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_types)}"
                        )

                # Validate generation_method if present
                if 'generation_method' in questions_df.columns:
                    valid_methods = {g.value for g in GenerationMethod}
                    invalid_methods = ~questions_df['generation_method'].isna() & \
                                    ~questions_df['generation_method'].isin(valid_methods)
                    if invalid_methods.any():
                        invalid_values = questions_df.loc[invalid_methods, 'generation_method'].unique()
                        errors.append(
                            f"Invalid generation_method values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_methods)}"
                        )

            # If validation errors, raise exception
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

        # Prepare DataFrame for ingestion
        df_prepared = questions_df.copy()

        # Add default columns if missing
        now = datetime.now()

        if 'status' not in df_prepared.columns:
            df_prepared['status'] = 'active'

        if 'created_at' not in df_prepared.columns:
            df_prepared['created_at'] = now

        if 'modified_at' not in df_prepared.columns:
            df_prepared['modified_at'] = now

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="faq_questions",
                    if_exists=if_exists,
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} questions"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest questions: {e}")
            raise QueryError(f"Question ingestion failed: {e}") from e

    # =========================================================================
    # Answer Ingestion Operations (Point 111)
    # =========================================================================

    def ingest_answers(
        self,
        answers_df: pd.DataFrame,
        validate: bool = True,
        validate_fk: bool = True,
        if_exists: str = "append"
    ) -> Dict[str, Any]:
        """
        Batch insert answers into faq_answers table.

        Point 111 in migration plan.

        Args:
            answers_df: DataFrame with answer data
            validate: Validate data before insert (default: True)
            validate_fk: Validate foreign keys exist (default: True)
            if_exists: What to do if data exists:
                - 'append': Insert new rows (default)
                - 'replace': Drop and recreate table (dangerous!)
                - 'fail': Raise error if table has data

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - errors (List[str], optional): Validation errors if any

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If FK validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - answer_id (required, unique)
            - question_id (required, must exist in faq_questions)
            - answer_text (required)

        Optional DataFrame Columns:
            - answer_format (default: "html")
            - confidence_score (0.0 to 1.0)
            - status (default: "active")
            - created_at (default: now)
            - modified_at (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'answer_id': ['A001', 'A002'],
            ...     'question_id': ['Q001', 'Q002'],
            ...     'answer_text': ['The answer is...', 'You can do this by...']
            ... })
            >>> result = repo.ingest_answers(df)
            >>> print(f"Inserted {result['rows_inserted']} answers")
        """
        self._logger.info(f"Ingesting {len(answers_df)} answers in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if answers_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            required_cols = ['answer_id', 'question_id', 'answer_text']
            missing_cols = [col for col in required_cols if col not in answers_df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")

            if not errors:  # Only validate values if columns exist
                # Validate answer_id (not empty)
                if answers_df['answer_id'].isna().any():
                    count = answers_df['answer_id'].isna().sum()
                    errors.append(f"{count} rows have null answer_id")

                empty_ids = answers_df['answer_id'].str.strip() == ''
                if empty_ids.any():
                    count = empty_ids.sum()
                    errors.append(f"{count} rows have empty answer_id")

                # Validate question_id (not empty)
                if answers_df['question_id'].isna().any():
                    count = answers_df['question_id'].isna().sum()
                    errors.append(f"{count} rows have null question_id")

                empty_qids = answers_df['question_id'].str.strip() == ''
                if empty_qids.any():
                    count = empty_qids.sum()
                    errors.append(f"{count} rows have empty question_id")

                # Validate answer_text (not empty)
                if answers_df['answer_text'].isna().any():
                    count = answers_df['answer_text'].isna().sum()
                    errors.append(f"{count} rows have null answer_text")

                empty_text = answers_df['answer_text'].str.strip() == ''
                if empty_text.any():
                    count = empty_text.sum()
                    errors.append(f"{count} rows have empty answer_text")

                # Validate status if present
                if 'status' in answers_df.columns:
                    valid_statuses = {s.value for s in FAQStatus}
                    invalid_statuses = ~answers_df['status'].isna() & \
                                     ~answers_df['status'].isin(valid_statuses)
                    if invalid_statuses.any():
                        invalid_values = answers_df.loc[invalid_statuses, 'status'].unique()
                        errors.append(
                            f"Invalid status values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_statuses)}"
                        )

                # Validate answer_format if present
                if 'answer_format' in answers_df.columns:
                    valid_formats = {f.value for f in AnswerFormat}
                    invalid_formats = ~answers_df['answer_format'].isna() & \
                                    ~answers_df['answer_format'].isin(valid_formats)
                    if invalid_formats.any():
                        invalid_values = answers_df.loc[invalid_formats, 'answer_format'].unique()
                        errors.append(
                            f"Invalid answer_format values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_formats)}"
                        )

                # Validate confidence_score if present
                if 'confidence_score' in answers_df.columns:
                    invalid_scores = ~answers_df['confidence_score'].isna() & \
                                   ((answers_df['confidence_score'] < 0.0) | \
                                    (answers_df['confidence_score'] > 1.0))
                    if invalid_scores.any():
                        count = invalid_scores.sum()
                        errors.append(
                            f"{count} rows have invalid confidence_score (must be 0.0 to 1.0)"
                        )

            # If validation errors, raise exception
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

            # Foreign key validation - check that question_ids exist
            if validate_fk and 'question_id' in answers_df.columns:
                unique_question_ids = answers_df['question_id'].dropna().unique().tolist()
                if unique_question_ids:
                    placeholders = ','.join(['?'] * len(unique_question_ids))
                    query = f"""
                        SELECT question_id
                        FROM faq_questions
                        WHERE question_id IN ({placeholders})
                    """
                    existing_questions = self.execute_query(query, tuple(unique_question_ids))
                    existing_ids = {row['question_id'] for row in existing_questions}

                    invalid_ids = [qid for qid in unique_question_ids if qid not in existing_ids]
                    if invalid_ids:
                        raise ForeignKeyViolationError(
                            f"Foreign key violation: question IDs do not exist in faq_questions: {invalid_ids}"
                        )

        # Prepare DataFrame for ingestion
        df_prepared = answers_df.copy()

        # Add default columns if missing
        now = datetime.now()

        if 'status' not in df_prepared.columns:
            df_prepared['status'] = 'active'

        if 'answer_format' not in df_prepared.columns:
            df_prepared['answer_format'] = 'html'

        if 'created_at' not in df_prepared.columns:
            df_prepared['created_at'] = now

        if 'modified_at' not in df_prepared.columns:
            df_prepared['modified_at'] = now

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="faq_answers",
                    if_exists=if_exists,
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} answers"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest answers: {e}")
            raise QueryError(f"Answer ingestion failed: {e}") from e

    # =========================================================================
    # FAQ Status Update Operations (Point 112)
    # =========================================================================

    def update_faq_status(
        self,
        faq_id: str,
        new_status: str,
        faq_type: str = "question",
        validate: bool = True
    ) -> int:
        """
        Update FAQ status (question or answer).

        Point 112 in migration plan.

        Args:
            faq_id: Question ID or Answer ID
            new_status: New status value (active, invalidated, archived, deleted)
            faq_type: Type of FAQ ("question" or "answer", default: "question")
            validate: Validate status value (default: True)

        Returns:
            Number of rows updated (should be 1)

        Raises:
            DataValidationError: If validation fails
            QuestionNotFoundError: If question doesn't exist
            AnswerNotFoundError: If answer doesn't exist
            QueryError: If update fails
            ValueError: If faq_type is invalid

        Example:
            >>> # Mark question as invalidated
            >>> rows = repo.update_faq_status("Q001", "invalidated", faq_type="question")
            >>> print(f"Updated {rows} question(s)")
            >>>
            >>> # Archive answer
            >>> repo.update_faq_status("A001", "archived", faq_type="answer")
        """
        # Validate faq_type
        if faq_type not in ("question", "answer"):
            raise ValueError(f"faq_type must be 'question' or 'answer', got '{faq_type}'")

        self._logger.info(f"Updating {faq_type} {faq_id} status to '{new_status}'")

        # Validation
        if validate:
            if not faq_id or not faq_id.strip():
                raise ValueError("faq_id cannot be empty")

            # Validate status value
            try:
                FAQStatus(new_status)
            except ValueError:
                valid_statuses = [s.value for s in FAQStatus]
                raise DataValidationError(
                    f"Invalid status '{new_status}'. Must be one of: {valid_statuses}"
                )

            # Check FAQ exists
            if faq_type == "question":
                faq = self.get_question_by_id(faq_id)
                if not faq:
                    raise QuestionNotFoundError(f"Question with ID {faq_id} not found")
            else:  # answer
                faq = self.get_answer_by_id(faq_id)
                if not faq:
                    raise AnswerNotFoundError(f"Answer with ID {faq_id} not found")

        try:
            # Build update command based on FAQ type
            if faq_type == "question":
                table_name = "faq_questions"
                id_column = "question_id"
            else:  # answer
                table_name = "faq_answers"
                id_column = "answer_id"

            command = f"""
                UPDATE {table_name}
                SET status = ?,
                    modified_at = ?
                WHERE {id_column} = ?
            """

            with self.transaction():
                rows_updated = self.execute_command(
                    command,
                    (new_status, datetime.now(), faq_id)
                )

            if rows_updated == 0:
                if faq_type == "question":
                    raise QuestionNotFoundError(f"Question with ID {faq_id} not found")
                else:
                    raise AnswerNotFoundError(f"Answer with ID {faq_id} not found")

            self._logger.info(f"Successfully updated {faq_type} {faq_id} status to '{new_status}'")
            return rows_updated

        except (QuestionNotFoundError, AnswerNotFoundError):
            raise
        except Exception as e:
            self._logger.error(f"Failed to update {faq_type} {faq_id} status: {e}")
            raise QueryError(f"Failed to update {faq_type} status: {e}") from e

    # =========================================================================
    # FAQ Statistics (Point 113)
    # =========================================================================

    def get_faq_stats(self) -> Dict[str, Any]:
        """
        Get aggregate statistics for FAQ tables.

        Point 113 in migration plan.

        Returns:
            Dictionary with statistics:
                - total_questions: Total number of questions
                - total_answers: Total number of answers
                - questions_by_status: Count by question status
                - answers_by_status: Count by answer status
                - questions_by_source_type: Count by source type
                - questions_by_generation_method: Count by generation method
                - questions_without_answers: Count of questions with no answer
                - avg_confidence_score: Average answer confidence score

        Raises:
            QueryError: If query execution fails

        Example:
            >>> stats = repo.get_faq_stats()
            >>> print(f"Total questions: {stats['total_questions']}")
            >>> print(f"Total answers: {stats['total_answers']}")
            >>> print(f"Active questions: {stats['questions_by_status']['active']}")
            >>> print(f"Questions without answers: {stats['questions_without_answers']}")
        """
        self._logger.debug("Calculating FAQ statistics")

        try:
            stats = {}

            # Total questions
            result = self.execute_query_single(
                "SELECT COUNT(*) as count FROM faq_questions"
            )
            stats['total_questions'] = result['count'] if result else 0

            # Total answers
            result = self.execute_query_single(
                "SELECT COUNT(*) as count FROM faq_answers"
            )
            stats['total_answers'] = result['count'] if result else 0

            # Questions by status
            results = self.execute_query(
                """
                SELECT status, COUNT(*) as count
                FROM faq_questions
                GROUP BY status
                """
            )
            stats['questions_by_status'] = {row['status']: row['count'] for row in results}

            # Answers by status
            results = self.execute_query(
                """
                SELECT status, COUNT(*) as count
                FROM faq_answers
                GROUP BY status
                """
            )
            stats['answers_by_status'] = {row['status']: row['count'] for row in results}

            # Questions by source type
            results = self.execute_query(
                """
                SELECT source_type, COUNT(*) as count
                FROM faq_questions
                WHERE source_type IS NOT NULL
                GROUP BY source_type
                """
            )
            stats['questions_by_source_type'] = {row['source_type']: row['count'] for row in results}

            # Questions by generation method
            results = self.execute_query(
                """
                SELECT generation_method, COUNT(*) as count
                FROM faq_questions
                WHERE generation_method IS NOT NULL
                GROUP BY generation_method
                """
            )
            stats['questions_by_generation_method'] = {
                row['generation_method']: row['count'] for row in results
            }

            # Questions without answers
            result = self.execute_query_single(
                """
                SELECT COUNT(*) as count
                FROM faq_questions q
                LEFT JOIN faq_answers a ON q.question_id = a.question_id
                WHERE a.answer_id IS NULL
                """
            )
            stats['questions_without_answers'] = result['count'] if result else 0

            # Average confidence score for answers
            result = self.execute_query_single(
                """
                SELECT AVG(confidence_score) as avg_score
                FROM faq_answers
                WHERE confidence_score IS NOT NULL
                """
            )
            stats['avg_confidence_score'] = (
                round(result['avg_score'], 3) if result and result['avg_score'] else None
            )

            self._logger.debug(
                f"FAQ statistics: {stats['total_questions']} questions, "
                f"{stats['total_answers']} answers"
            )
            return stats

        except Exception as e:
            self._logger.error(f"Failed to calculate FAQ statistics: {e}")
            raise QueryError(f"Failed to get FAQ statistics: {e}") from e


    # =========================================================================
    # Question Source Operations (Points 117, 119, 121)
    # =========================================================================

    def link_question_sources(
        self,
        question_id: str,
        content_checksums: List[str],
        is_primary_source: Optional[List[bool]] = None,
        contribution_weights: Optional[List[float]] = None,
        validate: bool = True
    ) -> Dict[str, Any]:
        """
        Link question to source content checksums.

        Point 117 in migration plan.

        Creates provenance records linking a question to the content that inspired it.

        Args:
            question_id: Question ID to link sources to
            content_checksums: List of content checksums (SHA-256)
            is_primary_source: Optional list of primary source flags (default: all False)
            contribution_weights: Optional list of weights 0.0-1.0 (default: equal weights)
            validate: Validate checksums exist (default: True)

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - sources_linked (int): Number of sources linked
                - question_id (str): Question ID
                - message (str): Status message

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If checksums don't exist
            QuestionNotFoundError: If question doesn't exist
            QueryError: If insert fails

        Example:
            >>> checksums = ["abc123...", "def456..."]
            >>> result = repo.link_question_sources(
            ...     "Q001",
            ...     checksums,
            ...     is_primary_source=[True, False],
            ...     contribution_weights=[0.7, 0.3]
            ... )
            >>> print(f"Linked {result['sources_linked']} sources to question")
        """
        self._logger.info(
            f"Linking {len(content_checksums)} sources to question {question_id}"
        )

        # Validation
        if validate:
            if not question_id or not question_id.strip():
                raise ValueError("question_id cannot be empty")

            if not content_checksums:
                raise ValueError("content_checksums cannot be empty")

            # Check question exists
            question = self.get_question_by_id(question_id)
            if not question:
                raise QuestionNotFoundError(f"Question {question_id} not found")

            # Validate checksums format
            for checksum in content_checksums:
                if not checksum or len(checksum) != 64:
                    raise DataValidationError(
                        f"Invalid checksum format (must be 64-char SHA-256): {checksum}"
                    )

            # Validate weights if provided
            if contribution_weights:
                if len(contribution_weights) != len(content_checksums):
                    raise DataValidationError(
                        "contribution_weights length must match content_checksums length"
                    )
                for weight in contribution_weights:
                    if not (0.0 <= weight <= 1.0):
                        raise DataValidationError(
                            f"contribution_weight must be 0.0 to 1.0, got {weight}"
                        )

            # Validate is_primary_source if provided
            if is_primary_source:
                if len(is_primary_source) != len(content_checksums):
                    raise DataValidationError(
                        "is_primary_source length must match content_checksums length"
                    )

        # Prepare defaults
        if is_primary_source is None:
            is_primary_source = [False] * len(content_checksums)

        if contribution_weights is None:
            # Equal weights
            contribution_weights = [1.0 / len(content_checksums)] * len(content_checksums)

        try:
            # Build DataFrame for bulk insert
            now = datetime.now()
            sources_df = pd.DataFrame({
                'question_id': [question_id] * len(content_checksums),
                'content_checksum': content_checksums,
                'is_primary_source': is_primary_source,
                'contribution_weight': contribution_weights,
                'is_valid': [True] * len(content_checksums),
                'valid_from': [now] * len(content_checksums),
                'created_at': [now] * len(content_checksums)
            })

            # Insert using ingest_question_sources
            result = self.ingest_question_sources(
                sources_df,
                validate=False,  # Already validated
                validate_fk=validate
            )

            return {
                'success': result.get('success', False),
                'sources_linked': result.get('rows_inserted', 0),
                'question_id': question_id,
                'message': f"Linked {result.get('rows_inserted', 0)} sources to question {question_id}"
            }

        except Exception as e:
            self._logger.error(f"Failed to link sources to question {question_id}: {e}")
            raise QueryError(f"Failed to link question sources: {e}") from e

    def get_sources_for_question(
        self,
        question_id: str,
        valid_only: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get all source provenance records for a question.

        Point 119 in migration plan.

        Args:
            question_id: Question ID
            valid_only: Only return valid sources (default: True)

        Returns:
            List of dictionaries with source data

        Raises:
            QueryError: If query execution fails
            ValueError: If question_id is empty

        Example:
            >>> sources = repo.get_sources_for_question("Q001")
            >>> for source in sources:
            ...     print(f"Checksum: {source['content_checksum'][:16]}...")
            ...     print(f"Weight: {source['contribution_weight']}")
            ...     print(f"Valid: {source['is_valid']}")
        """
        # Validation
        if not question_id or not question_id.strip():
            raise ValueError("question_id cannot be empty")

        self._logger.debug(f"Retrieving sources for question: {question_id}")

        try:
            query = """
                SELECT *
                FROM faq_question_sources
                WHERE question_id = ?
            """

            if valid_only:
                query += " AND is_valid = 1"

            query += " ORDER BY contribution_weight DESC, created_at"

            results = self.execute_query(query, (question_id,))

            self._logger.debug(f"Found {len(results)} sources for question {question_id}")
            return results

        except Exception as e:
            self._logger.error(f"Failed to get sources for question {question_id}: {e}")
            raise QueryError(f"Failed to retrieve question sources: {e}") from e

    def list_question_sources(
        self,
        question_id: Optional[str] = None,
        is_valid: Optional[bool] = None,
        is_primary: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        order_by: str = "created_at DESC"
    ) -> List[Dict[str, Any]]:
        """
        List question sources with optional filtering.

        Similar to list_questions() for consistency.

        Args:
            question_id: Optional question ID filter
            is_valid: Optional validity filter (True/False/None for all)
            is_primary: Optional primary source filter (True/False/None for all)
            limit: Maximum number of results
            offset: Number of results to skip (for pagination)
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with question source data

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all question sources
            >>> sources = repo.list_question_sources(limit=5)
            >>> print(f"Found {len(sources)} question sources")
            >>>
            >>> # Get valid sources for a specific question
            >>> sources = repo.list_question_sources(
            ...     question_id="Q001",
            ...     is_valid=True
            ... )
            >>>
            >>> # Get primary sources only
            >>> primary_sources = repo.list_question_sources(is_primary=True, limit=10)
        """
        self._logger.debug(
            f"Listing question sources (question_id={question_id}, "
            f"is_valid={is_valid}, is_primary={is_primary}, limit={limit})"
        )

        try:
            # Build query dynamically based on filters
            query_parts = ["SELECT * FROM faq_question_sources"]
            where_clauses = []
            params = []

            # Add filters
            if question_id is not None:
                where_clauses.append("question_id = ?")
                params.append(question_id)

            if is_valid is not None:
                where_clauses.append("is_valid = ?")
                params.append(1 if is_valid else 0)

            if is_primary is not None:
                where_clauses.append("is_primary_source = ?")
                params.append(1 if is_primary else 0)

            # Add WHERE clause if filters exist
            if where_clauses:
                query_parts.append("WHERE " + " AND ".join(where_clauses))

            # Add ORDER BY
            query_parts.append(f"ORDER BY {order_by}")

            # Add LIMIT and OFFSET
            if limit is not None:
                query_parts.append(f"LIMIT {limit}")
            if offset is not None:
                query_parts.append(f"OFFSET {offset}")

            query = " ".join(query_parts)

            results = self.execute_query(query, tuple(params) if params else None)

            self._logger.debug(f"Found {len(results)} question sources")
            return results

        except Exception as e:
            self._logger.error(f"Failed to list question sources: {e}")
            raise QueryError(f"Failed to list question sources: {e}") from e

    def ingest_question_sources(
        self,
        sources_df: pd.DataFrame,
        validate: bool = True,
        validate_fk: bool = True
    ) -> Dict[str, Any]:
        """
        Batch insert question sources into faq_question_sources table.

        Point 121 in migration plan.

        Args:
            sources_df: DataFrame with question source data
            validate: Validate data before insert (default: True)
            validate_fk: Validate foreign keys exist (default: True)

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If FK validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - question_id (required, must exist in faq_questions)
            - content_checksum (required, 64-char SHA-256)

        Optional DataFrame Columns:
            - is_primary_source (default: False)
            - contribution_weight (0.0 to 1.0)
            - is_valid (default: True)
            - valid_from (default: now)
            - valid_until
            - invalidation_reason
            - invalidated_by_change_id
            - created_at (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'question_id': ['Q001', 'Q001', 'Q002'],
            ...     'content_checksum': ['abc...', 'def...', 'ghi...'],
            ...     'contribution_weight': [0.7, 0.3, 1.0]
            ... })
            >>> result = repo.ingest_question_sources(df)
            >>> print(f"Inserted {result['rows_inserted']} sources")
        """
        self._logger.info(f"Ingesting {len(sources_df)} question sources in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if sources_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            required_cols = ['question_id', 'content_checksum']
            missing_cols = [col for col in required_cols if col not in sources_df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")

            if not errors:  # Only validate values if columns exist
                # Validate question_id (not empty)
                if sources_df['question_id'].isna().any():
                    count = sources_df['question_id'].isna().sum()
                    errors.append(f"{count} rows have null question_id")

                # Validate content_checksum format
                invalid_checksums = sources_df['content_checksum'].isna() | \
                                  (sources_df['content_checksum'].str.len() != 64)
                if invalid_checksums.any():
                    count = invalid_checksums.sum()
                    errors.append(
                        f"{count} rows have invalid content_checksum "
                        "(must be 64-char SHA-256 hash)"
                    )

                # Validate contribution_weight if present
                if 'contribution_weight' in sources_df.columns:
                    invalid_weights = ~sources_df['contribution_weight'].isna() & \
                                    ((sources_df['contribution_weight'] < 0.0) | \
                                     (sources_df['contribution_weight'] > 1.0))
                    if invalid_weights.any():
                        count = invalid_weights.sum()
                        errors.append(
                            f"{count} rows have invalid contribution_weight (must be 0.0 to 1.0)"
                        )

                # Validate invalidation_reason if present
                if 'invalidation_reason' in sources_df.columns:
                    valid_reasons = {r.value for r in InvalidationReason}
                    invalid_reasons = ~sources_df['invalidation_reason'].isna() & \
                                    ~sources_df['invalidation_reason'].isin(valid_reasons)
                    if invalid_reasons.any():
                        invalid_values = sources_df.loc[invalid_reasons, 'invalidation_reason'].unique()
                        errors.append(
                            f"Invalid invalidation_reason values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_reasons)}"
                        )

            # If validation errors, raise exception
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

            # Foreign key validation - check that question_ids exist
            if validate_fk and 'question_id' in sources_df.columns:
                unique_question_ids = sources_df['question_id'].dropna().unique().tolist()
                if unique_question_ids:
                    placeholders = ','.join(['?'] * len(unique_question_ids))
                    query = f"""
                        SELECT question_id
                        FROM faq_questions
                        WHERE question_id IN ({placeholders})
                    """
                    existing_questions = self.execute_query(query, tuple(unique_question_ids))
                    existing_ids = {row['question_id'] for row in existing_questions}

                    invalid_ids = [qid for qid in unique_question_ids if qid not in existing_ids]
                    if invalid_ids:
                        raise ForeignKeyViolationError(
                            f"Foreign key violation: question IDs do not exist in faq_questions: {invalid_ids}"
                        )

        # Prepare DataFrame for ingestion
        df_prepared = sources_df.copy()

        # Add default columns if missing
        now = datetime.now()

        if 'is_primary_source' not in df_prepared.columns:
            df_prepared['is_primary_source'] = False

        if 'is_valid' not in df_prepared.columns:
            df_prepared['is_valid'] = True

        if 'valid_from' not in df_prepared.columns:
            df_prepared['valid_from'] = now

        if 'created_at' not in df_prepared.columns:
            df_prepared['created_at'] = now

        # Convert boolean columns to integers for SQLite compatibility
        if 'is_primary_source' in df_prepared.columns:
            df_prepared['is_primary_source'] = df_prepared['is_primary_source'].astype(int)

        if 'is_valid' in df_prepared.columns:
            df_prepared['is_valid'] = df_prepared['is_valid'].astype(int)

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="faq_question_sources",
                    if_exists="append",
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} question sources"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest question sources: {e}")
            raise QueryError(f"Question sources ingestion failed: {e}") from e

    # =========================================================================
    # Answer Source Operations (Points 118, 120, 122)
    # =========================================================================

    def link_answer_sources(
        self,
        answer_id: str,
        content_checksums: List[str],
        is_primary_source: Optional[List[bool]] = None,
        contribution_weights: Optional[List[float]] = None,
        context_employed: Optional[List[str]] = None,
        validate: bool = True
    ) -> Dict[str, Any]:
        """
        Link answer to source content checksums.

        Point 118 in migration plan.

        Creates provenance records linking an answer to the content used to generate it.

        Args:
            answer_id: Answer ID to link sources to
            content_checksums: List of content checksums (SHA-256)
            is_primary_source: Optional list of primary source flags (default: all False)
            contribution_weights: Optional list of weights 0.0-1.0 (default: equal weights)
            context_employed: Optional list of JSON strings describing context used
            validate: Validate checksums exist (default: True)

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - sources_linked (int): Number of sources linked
                - answer_id (str): Answer ID
                - message (str): Status message

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If checksums don't exist
            AnswerNotFoundError: If answer doesn't exist
            QueryError: If insert fails

        Example:
            >>> checksums = ["abc123...", "def456..."]
            >>> contexts = ['{"section": "refund_policy"}', '{"section": "terms"}']
            >>> result = repo.link_answer_sources(
            ...     "A001",
            ...     checksums,
            ...     is_primary_source=[True, False],
            ...     contribution_weights=[0.8, 0.2],
            ...     context_employed=contexts
            ... )
            >>> print(f"Linked {result['sources_linked']} sources to answer")
        """
        self._logger.info(
            f"Linking {len(content_checksums)} sources to answer {answer_id}"
        )

        # Validation
        if validate:
            if not answer_id or not answer_id.strip():
                raise ValueError("answer_id cannot be empty")

            if not content_checksums:
                raise ValueError("content_checksums cannot be empty")

            # Check answer exists
            answer = self.get_answer_by_id(answer_id)
            if not answer:
                raise AnswerNotFoundError(f"Answer {answer_id} not found")

            # Validate checksums format
            for checksum in content_checksums:
                if not checksum or len(checksum) != 64:
                    raise DataValidationError(
                        f"Invalid checksum format (must be 64-char SHA-256): {checksum}"
                    )

            # Validate weights if provided
            if contribution_weights:
                if len(contribution_weights) != len(content_checksums):
                    raise DataValidationError(
                        "contribution_weights length must match content_checksums length"
                    )
                for weight in contribution_weights:
                    if not (0.0 <= weight <= 1.0):
                        raise DataValidationError(
                            f"contribution_weight must be 0.0 to 1.0, got {weight}"
                        )

            # Validate is_primary_source if provided
            if is_primary_source:
                if len(is_primary_source) != len(content_checksums):
                    raise DataValidationError(
                        "is_primary_source length must match content_checksums length"
                    )

            # Validate context_employed if provided
            if context_employed:
                if len(context_employed) != len(content_checksums):
                    raise DataValidationError(
                        "context_employed length must match content_checksums length"
                    )

        # Prepare defaults
        if is_primary_source is None:
            is_primary_source = [False] * len(content_checksums)

        if contribution_weights is None:
            # Equal weights
            contribution_weights = [1.0 / len(content_checksums)] * len(content_checksums)

        if context_employed is None:
            context_employed = [None] * len(content_checksums)

        try:
            # Build DataFrame for bulk insert
            now = datetime.now()
            sources_df = pd.DataFrame({
                'answer_id': [answer_id] * len(content_checksums),
                'content_checksum': content_checksums,
                'is_primary_source': is_primary_source,
                'contribution_weight': contribution_weights,
                'context_employed': context_employed,
                'is_valid': [True] * len(content_checksums),
                'valid_from': [now] * len(content_checksums),
                'created_at': [now] * len(content_checksums)
            })

            # Insert using ingest_answer_sources
            result = self.ingest_answer_sources(
                sources_df,
                validate=False,  # Already validated
                validate_fk=validate
            )

            return {
                'success': result.get('success', False),
                'sources_linked': result.get('rows_inserted', 0),
                'answer_id': answer_id,
                'message': f"Linked {result.get('rows_inserted', 0)} sources to answer {answer_id}"
            }

        except Exception as e:
            self._logger.error(f"Failed to link sources to answer {answer_id}: {e}")
            raise QueryError(f"Failed to link answer sources: {e}") from e

    def get_sources_for_answer(
        self,
        answer_id: str,
        valid_only: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get all source provenance records for an answer.

        Point 120 in migration plan.

        Args:
            answer_id: Answer ID
            valid_only: Only return valid sources (default: True)

        Returns:
            List of dictionaries with source data

        Raises:
            QueryError: If query execution fails
            ValueError: If answer_id is empty

        Example:
            >>> sources = repo.get_sources_for_answer("A001")
            >>> for source in sources:
            ...     print(f"Checksum: {source['content_checksum'][:16]}...")
            ...     print(f"Weight: {source['contribution_weight']}")
            ...     print(f"Context: {source['context_employed']}")
        """
        # Validation
        if not answer_id or not answer_id.strip():
            raise ValueError("answer_id cannot be empty")

        self._logger.debug(f"Retrieving sources for answer: {answer_id}")

        try:
            query = """
                SELECT *
                FROM faq_answer_sources
                WHERE answer_id = ?
            """

            if valid_only:
                query += " AND is_valid = 1"

            query += " ORDER BY contribution_weight DESC, created_at"

            results = self.execute_query(query, (answer_id,))

            self._logger.debug(f"Found {len(results)} sources for answer {answer_id}")
            return results

        except Exception as e:
            self._logger.error(f"Failed to get sources for answer {answer_id}: {e}")
            raise QueryError(f"Failed to retrieve answer sources: {e}") from e

    def list_answer_sources(
        self,
        answer_id: Optional[str] = None,
        is_valid: Optional[bool] = None,
        is_primary: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        order_by: str = "created_at DESC"
    ) -> List[Dict[str, Any]]:
        """
        List answer sources with optional filtering.

        Similar to list_question_sources() for consistency.

        Args:
            answer_id: Optional answer ID filter
            is_valid: Optional validity filter (True/False/None for all)
            is_primary: Optional primary source filter (True/False/None for all)
            limit: Maximum number of results
            offset: Number of results to skip (for pagination)
            order_by: Sort order (default: newest first)

        Returns:
            List of dictionaries with answer source data

        Raises:
            QueryError: If query execution fails

        Example:
            >>> # Get all answer sources
            >>> sources = repo.list_answer_sources(limit=5)
            >>> print(f"Found {len(sources)} answer sources")
            >>>
            >>> # Get valid sources for a specific answer
            >>> sources = repo.list_answer_sources(
            ...     answer_id="A001",
            ...     is_valid=True
            ... )
            >>>
            >>> # Get primary sources only
            >>> primary_sources = repo.list_answer_sources(is_primary=True, limit=10)
        """
        self._logger.debug(
            f"Listing answer sources (answer_id={answer_id}, "
            f"is_valid={is_valid}, is_primary={is_primary}, limit={limit})"
        )

        try:
            # Build query dynamically based on filters
            query_parts = ["SELECT * FROM faq_answer_sources"]
            where_clauses = []
            params = []

            # Add filters
            if answer_id is not None:
                where_clauses.append("answer_id = ?")
                params.append(answer_id)

            if is_valid is not None:
                where_clauses.append("is_valid = ?")
                params.append(1 if is_valid else 0)

            if is_primary is not None:
                where_clauses.append("is_primary_source = ?")
                params.append(1 if is_primary else 0)

            # Add WHERE clause if filters exist
            if where_clauses:
                query_parts.append("WHERE " + " AND ".join(where_clauses))

            # Add ORDER BY
            query_parts.append(f"ORDER BY {order_by}")

            # Add LIMIT and OFFSET
            if limit is not None:
                query_parts.append(f"LIMIT {limit}")
            if offset is not None:
                query_parts.append(f"OFFSET {offset}")

            query = " ".join(query_parts)

            results = self.execute_query(query, tuple(params) if params else None)

            self._logger.debug(f"Found {len(results)} answer sources")
            return results

        except Exception as e:
            self._logger.error(f"Failed to list answer sources: {e}")
            raise QueryError(f"Failed to list answer sources: {e}") from e

    def ingest_answer_sources(
        self,
        sources_df: pd.DataFrame,
        validate: bool = True,
        validate_fk: bool = True
    ) -> Dict[str, Any]:
        """
        Batch insert answer sources into faq_answer_sources table.

        Point 122 in migration plan.

        Args:
            sources_df: DataFrame with answer source data
            validate: Validate data before insert (default: True)
            validate_fk: Validate foreign keys exist (default: True)

        Returns:
            Dictionary with:
                - success (bool): True if successful
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message

        Raises:
            DataValidationError: If validation fails
            ForeignKeyViolationError: If FK validation fails
            QueryError: If insert fails

        Required DataFrame Columns:
            - answer_id (required, must exist in faq_answers)
            - content_checksum (required, 64-char SHA-256)

        Optional DataFrame Columns:
            - is_primary_source (default: False)
            - contribution_weight (0.0 to 1.0)
            - context_employed (JSON string)
            - is_valid (default: True)
            - valid_from (default: now)
            - valid_until
            - invalidation_reason
            - invalidated_by_change_id
            - created_at (default: now)

        Example:
            >>> df = pd.DataFrame({
            ...     'answer_id': ['A001', 'A001', 'A002'],
            ...     'content_checksum': ['abc...', 'def...', 'ghi...'],
            ...     'contribution_weight': [0.6, 0.4, 1.0]
            ... })
            >>> result = repo.ingest_answer_sources(df)
            >>> print(f"Inserted {result['rows_inserted']} sources")
        """
        self._logger.info(f"Ingesting {len(sources_df)} answer sources in bulk")

        # Validation
        if validate:
            errors = []

            # Check DataFrame is not empty
            if sources_df.empty:
                raise DataValidationError("Cannot ingest empty DataFrame")

            # Check required columns
            required_cols = ['answer_id', 'content_checksum']
            missing_cols = [col for col in required_cols if col not in sources_df.columns]
            if missing_cols:
                errors.append(f"Missing required columns: {missing_cols}")

            if not errors:  # Only validate values if columns exist
                # Validate answer_id (not empty)
                if sources_df['answer_id'].isna().any():
                    count = sources_df['answer_id'].isna().sum()
                    errors.append(f"{count} rows have null answer_id")

                # Validate content_checksum format
                invalid_checksums = sources_df['content_checksum'].isna() | \
                                  (sources_df['content_checksum'].str.len() != 64)
                if invalid_checksums.any():
                    count = invalid_checksums.sum()
                    errors.append(
                        f"{count} rows have invalid content_checksum "
                        "(must be 64-char SHA-256 hash)"
                    )

                # Validate contribution_weight if present
                if 'contribution_weight' in sources_df.columns:
                    invalid_weights = ~sources_df['contribution_weight'].isna() & \
                                    ((sources_df['contribution_weight'] < 0.0) | \
                                     (sources_df['contribution_weight'] > 1.0))
                    if invalid_weights.any():
                        count = invalid_weights.sum()
                        errors.append(
                            f"{count} rows have invalid contribution_weight (must be 0.0 to 1.0)"
                        )

                # Validate invalidation_reason if present
                if 'invalidation_reason' in sources_df.columns:
                    valid_reasons = {r.value for r in InvalidationReason}
                    invalid_reasons = ~sources_df['invalidation_reason'].isna() & \
                                    ~sources_df['invalidation_reason'].isin(valid_reasons)
                    if invalid_reasons.any():
                        invalid_values = sources_df.loc[invalid_reasons, 'invalidation_reason'].unique()
                        errors.append(
                            f"Invalid invalidation_reason values: {list(invalid_values)}. "
                            f"Must be one of: {list(valid_reasons)}"
                        )

            # If validation errors, raise exception
            if errors:
                error_msg = "; ".join(errors)
                self._logger.error(f"Validation failed: {error_msg}")
                raise DataValidationError(f"Validation failed: {error_msg}")

            # Foreign key validation - check that answer_ids exist
            if validate_fk and 'answer_id' in sources_df.columns:
                unique_answer_ids = sources_df['answer_id'].dropna().unique().tolist()
                if unique_answer_ids:
                    placeholders = ','.join(['?'] * len(unique_answer_ids))
                    query = f"""
                        SELECT answer_id
                        FROM faq_answers
                        WHERE answer_id IN ({placeholders})
                    """
                    existing_answers = self.execute_query(query, tuple(unique_answer_ids))
                    existing_ids = {row['answer_id'] for row in existing_answers}

                    invalid_ids = [aid for aid in unique_answer_ids if aid not in existing_ids]
                    if invalid_ids:
                        raise ForeignKeyViolationError(
                            f"Foreign key violation: answer IDs do not exist in faq_answers: {invalid_ids}"
                        )

        # Prepare DataFrame for ingestion
        df_prepared = sources_df.copy()

        # Add default columns if missing
        now = datetime.now()

        if 'is_primary_source' not in df_prepared.columns:
            df_prepared['is_primary_source'] = False

        if 'is_valid' not in df_prepared.columns:
            df_prepared['is_valid'] = True

        if 'valid_from' not in df_prepared.columns:
            df_prepared['valid_from'] = now

        if 'created_at' not in df_prepared.columns:
            df_prepared['created_at'] = now

        # Convert boolean columns to integers for SQLite compatibility
        if 'is_primary_source' in df_prepared.columns:
            df_prepared['is_primary_source'] = df_prepared['is_primary_source'].astype(int)

        if 'is_valid' in df_prepared.columns:
            df_prepared['is_valid'] = df_prepared['is_valid'].astype(int)

        try:
            # Use backend's bulk insert capability
            with self.transaction():
                result = self.backend.ingest_dataframe(
                    df=df_prepared,
                    table_name="faq_answer_sources",
                    if_exists="append",
                    index=False
                )

            self._logger.info(
                f"Successfully ingested {result.get('rows_inserted', 0)} answer sources"
            )
            return result

        except Exception as e:
            self._logger.error(f"Failed to bulk ingest answer sources: {e}")
            raise QueryError(f"Answer sources ingestion failed: {e}") from e

    # =========================================================================
    # Provenance Validation (Point 123)
    # =========================================================================

    def validate_content_checksum_exists(
        self,
        content_checksum: str,
        table_name: str = "content_chunks"
    ) -> bool:
        """
        Validate that a content checksum exists in the content tables.

        Point 123 in migration plan - Provenance validation.

        This is used for application-level FK validation since Databricks
        doesn't support FK constraints to non-primary key columns.

        Args:
            content_checksum: Content checksum (SHA-256)
            table_name: Table to check (default: "content_chunks")

        Returns:
            True if checksum exists, False otherwise

        Example:
            >>> if repo.validate_content_checksum_exists("abc123..."):
            ...     print("Checksum exists, safe to create provenance")
            ... else:
            ...     raise ValueError("Cannot link to non-existent content")
        """
        try:
            result = self.execute_query_single(
                f"SELECT 1 FROM {table_name} WHERE content_checksum = ?",
                (content_checksum,)
            )
            return result is not None
        except Exception as e:
            self._logger.error(f"Failed to validate checksum {content_checksum}: {e}")
            return False

    def validate_content_checksums(
        self,
        content_checksums: List[str],
        table_name: str = "content_chunks"
    ) -> Tuple[List[str], List[str]]:
        """
        Validate multiple content checksums at once.

        Point 123 in migration plan - Batch provenance validation.

        Args:
            content_checksums: List of content checksums to validate
            table_name: Table to check (default: "content_chunks")

        Returns:
            Tuple of (valid_checksums, invalid_checksums)

        Example:
            >>> checksums = ["abc123...", "def456...", "invalid..."]
            >>> valid, invalid = repo.validate_content_checksums(checksums)
            >>> print(f"Valid: {len(valid)}")
            >>> print(f"Invalid: {len(invalid)}")
            >>> if invalid:
            ...     raise ValueError(f"Invalid checksums: {invalid}")
        """
        if not content_checksums:
            return [], []

        try:
            # Query for all checksums in one go
            placeholders = ','.join(['?'] * len(content_checksums))
            query = f"""
                SELECT DISTINCT content_checksum
                FROM {table_name}
                WHERE content_checksum IN ({placeholders})
            """

            results = self.execute_query(query, tuple(content_checksums))
            valid_checksums = [row['content_checksum'] for row in results]
            invalid_checksums = [cs for cs in content_checksums if cs not in valid_checksums]

            return valid_checksums, invalid_checksums

        except Exception as e:
            self._logger.error(f"Failed to validate checksums: {e}")
            # On error, assume all invalid to be safe
            return [], content_checksums

    # =========================================================================
    # Source Tracking (Point 124)
    # =========================================================================

    def track_source_lineage(
        self,
        faq_id: str,
        faq_type: str = "question"
    ) -> Dict[str, Any]:
        """
        Track complete source lineage for an FAQ.

        Point 124 in migration plan - Source tracking.

        Returns full provenance tree showing all content sources and their validity.

        Args:
            faq_id: Question ID or Answer ID
            faq_type: Type of FAQ ("question" or "answer", default: "question")

        Returns:
            Dictionary with lineage information:
                - faq_id: The FAQ ID
                - faq_type: "question" or "answer"
                - faq_data: The question or answer data
                - sources: List of source records with metadata
                - total_sources: Total number of sources
                - valid_sources: Number of currently valid sources
                - invalid_sources: Number of invalidated sources

        Raises:
            QueryError: If query execution fails
            ValueError: If faq_id is empty or faq_type is invalid

        Example:
            >>> lineage = repo.track_source_lineage("Q001", "question")
            >>> print(f"Question has {lineage['total_sources']} sources")
            >>> print(f"Valid: {lineage['valid_sources']}, Invalid: {lineage['invalid_sources']}")
            >>> for source in lineage['sources']:
            ...     print(f"  - {source['content_checksum'][:16]}... "
            ...           f"(valid: {source['is_valid']})")
        """
        # Validate faq_type
        if faq_type not in ("question", "answer"):
            raise ValueError(f"faq_type must be 'question' or 'answer', got '{faq_type}'")

        if not faq_id or not faq_id.strip():
            raise ValueError("faq_id cannot be empty")

        self._logger.debug(f"Tracking lineage for {faq_type} {faq_id}")

        try:
            # Get FAQ data
            if faq_type == "question":
                faq_data = self.get_question_by_id(faq_id)
                sources = self.get_sources_for_question(faq_id, valid_only=False)
            else:  # answer
                faq_data = self.get_answer_by_id(faq_id)
                sources = self.get_sources_for_answer(faq_id, valid_only=False)

            # Count valid and invalid sources
            valid_count = sum(1 for s in sources if s.get('is_valid', 0) == 1)
            invalid_count = len(sources) - valid_count

            lineage = {
                'faq_id': faq_id,
                'faq_type': faq_type,
                'faq_data': faq_data,
                'sources': sources,
                'total_sources': len(sources),
                'valid_sources': valid_count,
                'invalid_sources': invalid_count
            }

            self._logger.debug(
                f"Lineage for {faq_type} {faq_id}: {lineage['total_sources']} sources "
                f"({valid_count} valid, {invalid_count} invalid)"
            )

            return lineage

        except Exception as e:
            self._logger.error(f"Failed to track lineage for {faq_type} {faq_id}: {e}")
            raise QueryError(f"Failed to track source lineage: {e}") from e


__all__ = [
    # Main class
    "FAQRepository",

    # Exceptions
    "FAQRepositoryError",
    "QuestionNotFoundError",
    "AnswerNotFoundError",
    "SourceNotFoundError",
    "DuplicateQuestionError",
    "DuplicateAnswerError",
    "ForeignKeyViolationError",
    "ProvenanceValidationError",
]
