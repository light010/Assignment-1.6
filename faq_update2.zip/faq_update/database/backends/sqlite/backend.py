"""
SQLite Backend Implementation

Complete implementation of IBackend interface for SQLite databases.

This is the main entry point for all SQLite database operations. It consolidates:
- Connection management (from connection.py)
- CRUD operations (implementing IBackend)
- Bulk operations (DataFrame ingestion)
- Transaction management
- Error handling

When migrating to Databricks, this entire file can be deleted.

Author: Analytics Assist Team
Date: 2025-11-02
Version: 2.0.0
"""

import sqlite3
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
from pathlib import Path

from database.backends.base import (
    IBackend,
    BackendType,
    ConnectionError as BackendConnectionError,
    QueryError,
    CommandError,
    TransactionError,
    TableNotFoundError,
    MultipleResultsError,
    ConfigurationError,
)
from database.config import DatabaseConfig
from database.dialect import DatabaseDialect
from database.backends.sqlite.connection import SQLiteConnectionManager
from database.backends.sqlite.utilities import (
    close_all_sqlite_connections,
    validate_database_file,
)
from utility.logging import get_logger

logger = get_logger(__name__)


class SQLiteBackend(IBackend):
    """
    SQLite implementation of IBackend interface.

    Provides full database backend functionality using SQLite, including:
    - CRUD operations with parameterized queries
    - Bulk DataFrame operations
    - Transaction management (ACID guarantees)
    - Connection pooling
    - Windows file locking handling
    - Performance optimizations (WAL mode, pragmas)

    Thread Safety:
        Read operations are thread-safe.
        Write operations should use transactions for multi-threading.

    Example:
        >>> from database.backends.sqlite import SQLiteBackend
        >>> from database.config import DatabaseConfig
        >>>
        >>> config = DatabaseConfig(backend="sqlite", db_path="faq.db")
        >>> backend = SQLiteBackend(config)
        >>> backend.connect()
        >>>
        >>> # Query
        >>> results = backend.execute_query(
        ...     "SELECT * FROM content_repo WHERE file_status = ?",
        ...     ("Active",)
        ... )
        >>>
        >>> # Command
        >>> backend.execute_command(
        ...     "UPDATE content_repo SET file_status = ? WHERE ud_source_file_id = ?",
        ...     ("Archived", 1)
        ... )
        >>>
        >>> # Bulk insert
        >>> import pandas as pd
        >>> df = pd.DataFrame({'raw_file_nme': ['file1.pdf'], 'file_status': ['Active']})
        >>> result = backend.ingest_dataframe(df, "content_repo")
        >>>
        >>> backend.close()
    """

    def __init__(self, config: DatabaseConfig):
        """
        Initialize SQLite backend.

        Args:
            config: Database configuration

        Raises:
            ConfigurationError: If configuration is invalid
        """
        super().__init__()

        # Validate configuration
        if not config.is_sqlite():
            raise ConfigurationError(
                f"SQLiteBackend requires SQLite configuration, "
                f"got backend={config.backend}"
            )

        if not config.db_path:
            raise ConfigurationError("SQLiteBackend requires db_path in configuration")

        self.config = config
        self.db_path = config.db_path
        self._backend_type = BackendType.SQLITE
        self._is_connected = False
        self._in_transaction = False

        # Connection manager
        self.conn_manager = SQLiteConnectionManager(
            db_path=self.db_path,
            timeout=config.timeout,
            enable_foreign_keys=config.enable_foreign_keys,
            journal_mode=config.journal_mode,
        )

        logger.info(f"SQLiteBackend initialized: db_path={self.db_path}")

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def backend_type(self) -> BackendType:
        """Get backend type."""
        return self._backend_type

    @property
    def dialect(self) -> DatabaseDialect:
        """Get database dialect."""
        return DatabaseDialect.SQLITE

    @property
    def is_connected(self) -> bool:
        """Check if connected to database."""
        return self._is_connected and self.conn_manager.is_connected()

    # =========================================================================
    # Connection Management
    # =========================================================================

    def connect(self) -> None:
        """
        Establish connection to SQLite database.

        Creates database file if it doesn't exist (except for invalid paths).

        Raises:
            ConnectionError: If connection fails
        """
        try:
            # Validate database path
            if self.db_path != ":memory:":
                db_file = Path(self.db_path)
                # Create parent directory if needed
                db_file.parent.mkdir(parents=True, exist_ok=True)

            # Get connection (creates file if doesn't exist)
            conn = self.conn_manager.get_connection()

            # Verify connection works
            conn.execute("SELECT 1")

            self._is_connected = True
            logger.info(f"Connected to SQLite database: {self.db_path}")

        except sqlite3.Error as e:
            self._is_connected = False
            logger.error(f"Failed to connect to SQLite: {e}", exc_info=True)
            raise BackendConnectionError(
                f"Could not connect to SQLite database '{self.db_path}': {e}"
            ) from e

    def close(self) -> None:
        """Close database connection and clean up resources."""
        try:
            if self._in_transaction:
                logger.warning("Closing connection with active transaction - rolling back")
                self.rollback()

            self.conn_manager.close()
            self._is_connected = False
            logger.info("SQLite connection closed")

        except Exception as e:
            logger.error(f"Error closing connection: {e}", exc_info=True)

    # =========================================================================
    # Query Execution (Read Operations)
    # =========================================================================

    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute SELECT query and return results as list of dictionaries.

        Args:
            query: SQL SELECT statement
            params: Optional parameters for query
            timeout: Optional timeout (not used in SQLite)

        Returns:
            List of dictionaries (column_name → value)

        Raises:
            QueryError: If query execution fails
        """
        if not self.is_connected:
            raise QueryError("Not connected to database")

        if params is None:
            params = ()

        try:
            conn = self.conn_manager.get_connection()
            conn.row_factory = sqlite3.Row  # Enable column access by name

            cursor = conn.execute(query, params)
            rows = cursor.fetchall()

            # Convert Row objects to dictionaries
            results = [dict(row) for row in rows]

            logger.debug(f"Query returned {len(results)} rows")
            return results

        except sqlite3.Error as e:
            logger.error(f"Query failed: {query[:100]}... Error: {e}", exc_info=True)
            raise QueryError(f"Query execution failed: {e}") from e

        finally:
            # Reset row factory
            conn.row_factory = None

    def execute_query_single(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Execute SELECT query and return single result (or None).

        Args:
            query: SQL SELECT statement
            params: Optional parameters
            timeout: Optional timeout (not used in SQLite)

        Returns:
            Dictionary or None

        Raises:
            MultipleResultsError: If query returns more than one row
            QueryError: If query execution fails
        """
        results = self.execute_query(query, params, timeout)

        if len(results) == 0:
            return None
        elif len(results) == 1:
            return results[0]
        else:
            raise MultipleResultsError(
                f"Query expected to return 0 or 1 row, got {len(results)} rows"
            )

    # =========================================================================
    # Command Execution (Write Operations)
    # =========================================================================

    def execute_command(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute INSERT, UPDATE, or DELETE command.

        Args:
            command: SQL command
            params: Optional parameters
            timeout: Optional timeout (not used in SQLite)

        Returns:
            Number of rows affected

        Raises:
            CommandError: If command execution fails
        """
        if not self.is_connected:
            raise CommandError("Not connected to database")

        if params is None:
            params = ()

        try:
            conn = self.conn_manager.get_connection()
            cursor = conn.execute(command, params)

            # Commit if not in transaction
            if not self._in_transaction:
                conn.commit()

            rows_affected = cursor.rowcount
            logger.debug(f"Command affected {rows_affected} rows")
            return rows_affected

        except sqlite3.Error as e:
            logger.error(f"Command failed: {command[:100]}... Error: {e}", exc_info=True)
            raise CommandError(f"Command execution failed: {e}") from e

    def execute_many(
        self,
        command: str,
        params_list: List[Tuple],
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute command multiple times with different parameters.

        Args:
            command: SQL command
            params_list: List of parameter tuples
            timeout: Optional timeout (not used in SQLite)

        Returns:
            Total rows affected

        Raises:
            CommandError: If execution fails
        """
        if not self.is_connected:
            raise CommandError("Not connected to database")

        try:
            conn = self.conn_manager.get_connection()
            cursor = conn.executemany(command, params_list)

            # Commit if not in transaction
            if not self._in_transaction:
                conn.commit()

            rows_affected = cursor.rowcount
            logger.debug(f"Batch command affected {rows_affected} rows")
            return rows_affected

        except sqlite3.Error as e:
            logger.error(
                f"Batch command failed: {command[:100]}... Error: {e}",
                exc_info=True
            )
            raise CommandError(f"Batch command execution failed: {e}") from e

    # =========================================================================
    # Bulk Operations (DataFrame)
    # =========================================================================

    def ingest_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "append",
        index: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Bulk insert DataFrame into table using pandas.to_sql.

        Args:
            df: DataFrame to insert
            table_name: Target table name
            if_exists: 'append', 'replace', or 'fail'
            index: Whether to write DataFrame index
            **kwargs: Additional arguments for to_sql

        Returns:
            Dict with success, rows_inserted, message

        Raises:
            CommandError: If ingestion fails
        """
        if not self.is_connected:
            raise CommandError("Not connected to database")

        if df.empty:
            logger.warning("Attempted to ingest empty DataFrame")
            return {
                'success': True,
                'rows_inserted': 0,
                'message': 'No rows to insert (empty DataFrame)'
            }

        try:
            conn = self.conn_manager.get_connection()

            # Use pandas to_sql for efficient bulk insert
            df.to_sql(
                name=table_name,
                con=conn,
                if_exists=if_exists,
                index=index,
                **kwargs
            )

            # Commit if not in transaction
            if not self._in_transaction:
                conn.commit()

            rows_inserted = len(df)
            logger.info(f"Inserted {rows_inserted} rows into {table_name}")

            return {
                'success': True,
                'rows_inserted': rows_inserted,
                'message': f'Successfully inserted {rows_inserted} rows into {table_name}'
            }

        except Exception as e:
            logger.error(
                f"DataFrame ingestion failed for table {table_name}: {e}",
                exc_info=True
            )
            return {
                'success': False,
                'rows_inserted': 0,
                'message': f'Ingestion failed: {str(e)}',
                'error': str(e)
            }

    def read_table(
        self,
        table_name: str,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> pd.DataFrame:
        """
        Read table into DataFrame.

        Args:
            table_name: Name of table
            columns: Optional list of columns (None = all)
            where: Optional WHERE clause
            params: Optional parameters for WHERE
            limit: Optional row limit

        Returns:
            pandas DataFrame

        Raises:
            QueryError: If query fails
        """
        if not self.is_connected:
            raise QueryError("Not connected to database")

        # Build query
        cols = ", ".join(columns) if columns else "*"
        query = f"SELECT {cols} FROM {table_name}"

        if where:
            query += f" WHERE {where}"

        if limit:
            query += f" LIMIT {limit}"

        try:
            conn = self.conn_manager.get_connection()
            df = pd.read_sql_query(query, conn, params=params)
            logger.debug(f"Read {len(df)} rows from {table_name}")
            return df

        except Exception as e:
            logger.error(f"Failed to read table {table_name}: {e}", exc_info=True)
            raise QueryError(f"Could not read table {table_name}: {e}") from e

    # =========================================================================
    # Transaction Management
    # =========================================================================

    def begin_transaction(self) -> None:
        """Start a transaction."""
        if not self.is_connected:
            raise TransactionError("Not connected to database")

        if self._in_transaction:
            logger.warning("Already in transaction")
            return

        try:
            conn = self.conn_manager.get_connection()
            conn.execute("BEGIN")
            self._in_transaction = True
            logger.debug("Transaction started")

        except sqlite3.Error as e:
            logger.error(f"Could not start transaction: {e}", exc_info=True)
            raise TransactionError(f"Failed to start transaction: {e}") from e

    def commit(self) -> None:
        """Commit current transaction."""
        if not self.is_connected:
            raise TransactionError("Not connected to database")

        if not self._in_transaction:
            logger.warning("No active transaction to commit")
            return

        try:
            conn = self.conn_manager.get_connection()
            conn.commit()
            self._in_transaction = False
            logger.debug("Transaction committed")

        except sqlite3.Error as e:
            logger.error(f"Commit failed: {e}", exc_info=True)
            raise TransactionError(f"Failed to commit transaction: {e}") from e

    def rollback(self) -> None:
        """Roll back current transaction."""
        if not self.is_connected:
            raise TransactionError("Not connected to database")

        if not self._in_transaction:
            logger.warning("No active transaction to rollback")
            return

        try:
            conn = self.conn_manager.get_connection()
            conn.rollback()
            self._in_transaction = False
            logger.debug("Transaction rolled back")

        except sqlite3.Error as e:
            logger.error(f"Rollback failed: {e}", exc_info=True)
            raise TransactionError(f"Failed to rollback transaction: {e}") from e

    # =========================================================================
    # Schema Operations
    # =========================================================================

    def table_exists(self, table_name: str) -> bool:
        """Check if table exists."""
        try:
            result = self.execute_query(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table_name,)
            )
            return len(result) > 0

        except QueryError:
            return False

    def get_table_schema(self, table_name: str) -> List[Dict[str, str]]:
        """Get table schema information."""
        if not self.table_exists(table_name):
            raise TableNotFoundError(f"Table '{table_name}' does not exist")

        try:
            # Get column information using PRAGMA
            conn = self.conn_manager.get_connection()
            cursor = conn.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()

            schema = []
            for col in columns:
                schema.append({
                    'name': col[1],
                    'type': col[2],
                    'nullable': not bool(col[3]),
                    'default': col[4],
                    'primary_key': bool(col[5])
                })

            return schema

        except sqlite3.Error as e:
            logger.error(f"Could not get schema for {table_name}: {e}", exc_info=True)
            raise QueryError(f"Failed to get table schema: {e}") from e

    def list_tables(self) -> List[str]:
        """List all tables in database."""
        try:
            results = self.execute_query(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
            return [row['name'] for row in results]

        except QueryError as e:
            logger.error(f"Could not list tables: {e}", exc_info=True)
            return []

    # =========================================================================
    # Utility Methods
    # =========================================================================

    def get_row_count(
        self,
        table_name: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None
    ) -> int:
        """Get count of rows in table."""
        query = f"SELECT COUNT(*) as count FROM {table_name}"

        if where:
            query += f" WHERE {where}"

        try:
            result = self.execute_query_single(query, params)
            return result['count'] if result else 0

        except QueryError:
            return 0

    def get_distinct_values(
        self,
        table_name: str,
        column: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> List[Any]:
        """Get distinct values from column."""
        query = f"SELECT DISTINCT {column} FROM {table_name}"

        if where:
            query += f" WHERE {where}"

        query += f" ORDER BY {column}"

        if limit:
            query += f" LIMIT {limit}"

        try:
            results = self.execute_query(query, params)
            return [row[column] for row in results]

        except QueryError:
            return []

    # =========================================================================
    # String Representation
    # =========================================================================

    def __repr__(self) -> str:
        """String representation."""
        status = "connected" if self.is_connected else "disconnected"
        return f"SQLiteBackend(db_path='{self.db_path}', status={status})"


__all__ = ["SQLiteBackend"]
