"""
SQLite Connection Management

Consolidated SQLite connection utilities with optimizations and error handling.

This module handles all SQLite connection management including:
- Connection pooling and reuse
- PRAGMA settings (foreign keys, WAL mode)
- Windows file locking handling
- Thread safety
- Context manager support

Moved from:
- database/utils/connection_helpers.py
- Parts of utility/database.py (get_sqlite_connection)

Author: Analytics Assist Team
Date: 2025-11-02
Version: 2.0.0 (Consolidated)
"""

import sqlite3
from typing import Optional
from pathlib import Path
from utility.logging import get_logger

logger = get_logger(__name__)


class SQLiteConnectionManager:
    """
    Manages SQLite database connections with consistent configuration.

    Features:
    - Automatic PRAGMA foreign_keys = ON
    - WAL mode for better concurrency
    - Connection pooling (reuses connection if not closed)
    - Context manager support for automatic cleanup
    - Validation of database file existence
    - Configurable timeout and pragmas

    Example:
        >>> manager = SQLiteConnectionManager("faq.db")
        >>> conn = manager.get_connection()
        >>> conn.execute("INSERT INTO ...")
        >>> conn.close()
        >>>
        >>> # Or use as context manager:
        >>> with SQLiteConnectionManager("faq.db") as conn:
        ...     conn.execute("INSERT INTO ...")
        ...     conn.commit()
    """

    def __init__(
        self,
        db_path: str,
        check_same_thread: bool = True,
        timeout: float = 30.0,
        enable_foreign_keys: bool = True,
        journal_mode: str = "WAL"
    ):
        """
        Initialize connection manager.

        Args:
            db_path: Path to SQLite database file (or ":memory:")
            check_same_thread: If False, allows connection use across threads
            timeout: Connection timeout in seconds (default: 30)
            enable_foreign_keys: Enable foreign key constraints (default: True)
            journal_mode: SQLite journal mode (default: "WAL")
                         Options: "DELETE", "TRUNCATE", "PERSIST", "MEMORY", "WAL", "OFF"

        Example:
            >>> # Standard connection
            >>> manager = SQLiteConnectionManager("faq.db")
            >>>
            >>> # In-memory database for testing
            >>> manager = SQLiteConnectionManager(":memory:")
            >>>
            >>> # Multi-threaded use (be careful!)
            >>> manager = SQLiteConnectionManager("faq.db", check_same_thread=False)
        """
        self.db_path = db_path
        self.check_same_thread = check_same_thread
        self.timeout = timeout
        self.enable_foreign_keys = enable_foreign_keys
        self.journal_mode = journal_mode
        self._connection: Optional[sqlite3.Connection] = None

        logger.debug(
            f"SQLiteConnectionManager initialized: db_path={db_path}, "
            f"timeout={timeout}, journal_mode={journal_mode}"
        )

    def get_connection(self) -> sqlite3.Connection:
        """
        Get a SQLite connection with PRAGMA settings applied.

        Creates a new connection if one doesn't exist, otherwise reuses existing.

        Returns:
            sqlite3.Connection: Database connection ready to use

        Example:
            >>> manager = SQLiteConnectionManager("faq.db")
            >>> conn = manager.get_connection()
            >>> cursor = conn.execute("SELECT * FROM content_chunks")
        """
        if self._connection is None:
            logger.debug(f"Creating new SQLite connection to {self.db_path}")

            self._connection = sqlite3.connect(
                self.db_path,
                timeout=self.timeout,
                check_same_thread=self.check_same_thread
            )

            # Apply PRAGMA settings
            self._apply_pragma_settings()

        return self._connection

    def _apply_pragma_settings(self) -> None:
        """Apply SQLite PRAGMA settings to optimize performance and behavior."""
        if self._connection is None:
            return

        # Enable foreign key constraints (not enabled by default in SQLite)
        if self.enable_foreign_keys:
            self._connection.execute("PRAGMA foreign_keys = ON")
            logger.debug("Foreign keys enabled")

        # Set journal mode for better concurrency
        if self.journal_mode:
            try:
                result = self._connection.execute(f"PRAGMA journal_mode = {self.journal_mode}")
                actual_mode = result.fetchone()[0]
                logger.debug(f"Journal mode set to: {actual_mode}")
            except sqlite3.Error as e:
                logger.warning(f"Could not set journal_mode to {self.journal_mode}: {e}")

        # Additional optimizations
        try:
            # Improve query performance
            self._connection.execute("PRAGMA synchronous = NORMAL")
            # Cache size (negative value = KB, positive = pages)
            self._connection.execute("PRAGMA cache_size = -10000")  # 10MB cache
        except sqlite3.Error as e:
            logger.warning(f"Could not apply performance optimizations: {e}")

    def close(self) -> None:
        """
        Close the database connection.

        Example:
            >>> manager = SQLiteConnectionManager("faq.db")
            >>> conn = manager.get_connection()
            >>> # ... use connection ...
            >>> manager.close()
        """
        if self._connection is not None:
            try:
                self._connection.close()
                logger.debug(f"Closed connection to {self.db_path}")
            except sqlite3.Error as e:
                logger.error(f"Error closing connection: {e}")
            finally:
                self._connection = None

    def validate_database_exists(self) -> bool:
        """
        Check if the database file exists.

        Returns:
            bool: True if database file exists, False otherwise

        Example:
            >>> manager = SQLiteConnectionManager("faq.db")
            >>> if not manager.validate_database_exists():
            ...     print("ERROR: Database file not found!")
        """
        if self.db_path == ":memory:":
            return True  # In-memory databases always "exist"
        return Path(self.db_path).exists()

    def is_connected(self) -> bool:
        """
        Check if connection is active.

        Returns:
            bool: True if connection exists and is open

        Example:
            >>> manager = SQLiteConnectionManager("faq.db")
            >>> manager.is_connected()
            False
            >>> conn = manager.get_connection()
            >>> manager.is_connected()
            True
        """
        if self._connection is None:
            return False

        try:
            # Test if connection is alive
            self._connection.execute("SELECT 1")
            return True
        except sqlite3.Error:
            return False

    def __enter__(self) -> sqlite3.Connection:
        """
        Context manager entry: returns connection.

        Example:
            >>> with SQLiteConnectionManager("faq.db") as conn:
            ...     conn.execute("INSERT INTO ...")
            ...     conn.commit()
        """
        return self.get_connection()

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit: closes connection.

        Automatically rolls back if there was an exception.
        """
        if exc_type is not None and self._connection is not None:
            # Exception occurred, rollback
            try:
                self._connection.rollback()
                logger.warning("Transaction rolled back due to exception")
            except Exception as e:
                logger.error(f"Rollback failed: {e}")

        self.close()
        return False  # Don't suppress exceptions

    def __del__(self):
        """Ensure connection is closed when object is garbage collected."""
        self.close()

    def __repr__(self) -> str:
        """String representation."""
        status = "connected" if self.is_connected() else "disconnected"
        return f"SQLiteConnectionManager(db_path='{self.db_path}', status={status})"


def create_sqlite_connection(
    db_path: str,
    enable_foreign_keys: bool = True,
    timeout: float = 30.0,
    journal_mode: str = "WAL"
) -> sqlite3.Connection:
    """
    Create a SQLite connection with standard configuration.

    This is a convenience function for one-off connections.
    For repeated use, prefer SQLiteConnectionManager.

    Args:
        db_path: Path to database file (or ":memory:")
        enable_foreign_keys: If True, enable foreign key constraints
        timeout: Connection timeout in seconds
        journal_mode: SQLite journal mode

    Returns:
        sqlite3.Connection: Configured database connection

    Example:
        >>> conn = create_sqlite_connection("faq.db")
        >>> try:
        ...     conn.execute("INSERT INTO ...")
        ...     conn.commit()
        ... finally:
        ...     conn.close()
    """
    logger.debug(f"Creating one-off SQLite connection to {db_path}")

    conn = sqlite3.connect(db_path, timeout=timeout)

    # Apply PRAGMA settings
    if enable_foreign_keys:
        conn.execute("PRAGMA foreign_keys = ON")

    if journal_mode:
        try:
            conn.execute(f"PRAGMA journal_mode = {journal_mode}")
        except sqlite3.Error as e:
            logger.warning(f"Could not set journal_mode: {e}")

    # Performance optimizations
    try:
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA cache_size = -10000")
    except sqlite3.Error as e:
        logger.warning(f"Could not apply optimizations: {e}")

    return conn


__all__ = [
    "SQLiteConnectionManager",
    "create_sqlite_connection",
]
