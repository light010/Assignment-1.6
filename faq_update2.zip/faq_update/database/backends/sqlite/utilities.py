"""
SQLite Utility Functions

Safe database operations for notebooks and scripts, including:
- Safe table dropping (closes connections properly)
- Connection cleanup
- File locking handling (Windows compatibility)
- Database validation

Moved from: utility/database.py

All SQLite-specific utilities are now consolidated here.
When migrating to Databricks, this entire file can be deleted.

Author: Analytics Assist Team
Date: 2025-11-02
Version: 2.0.0 (Moved to backends/sqlite/)
"""

import sqlite3
import os
import time
from pathlib import Path
from typing import List, Optional
import gc

from utility.logging import get_logger

logger = get_logger(__name__)


def close_all_sqlite_connections():
    """
    Force close all SQLite connections in the current process.

    This is necessary before dropping tables or deleting database files,
    especially on Windows where file locks prevent deletion.

    Call this before DROP_EXISTING_TABLES operations.

    Example:
        >>> close_all_sqlite_connections()
        >>> drop_sqlite_database("databases/faq.db")  # Now succeeds
    """
    logger.debug("Forcing garbage collection to close SQLite connections")
    # Force garbage collection to close lingering connections
    gc.collect()

    # Small delay to allow OS to release file locks
    time.sleep(0.1)


def drop_sqlite_database(db_path: str, max_retries: int = 3) -> bool:
    """
    Safely drop (delete) a SQLite database file.

    Handles Windows file locking issues by:
    1. Closing all connections
    2. Forcing garbage collection
    3. Retrying with delays

    Args:
        db_path: Path to SQLite database file
        max_retries: Number of retry attempts (default: 3)

    Returns:
        True if successfully deleted, False otherwise

    Example:
        >>> drop_sqlite_database("databases/my.db")
        ✓ Deleted database file: databases/my.db
        True
    """
    if not os.path.exists(db_path):
        logger.info(f"Database file does not exist: {db_path}")
        print(f"   Database file does not exist: {db_path}")
        return True

    logger.info(f"Attempting to delete database: {db_path}")

    # Close all connections first
    close_all_sqlite_connections()

    # Try to delete with retries
    for attempt in range(max_retries):
        try:
            os.remove(db_path)
            logger.info(f"Successfully deleted database: {db_path}")
            print(f"   ✓ Deleted database file: {db_path}")
            return True
        except PermissionError as e:
            if attempt < max_retries - 1:
                logger.warning(
                    f"Database file locked, retrying... "
                    f"(attempt {attempt + 1}/{max_retries})"
                )
                print(
                    f"   ⚠ File locked, retrying... "
                    f"(attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(0.5)  # Wait before retry
                close_all_sqlite_connections()  # Try closing again
            else:
                logger.error(
                    f"Could not delete database file (in use): {db_path}",
                    exc_info=True
                )
                print(f"   ❌ Could not delete database file (in use by another process)")
                print(f"   Error: {e}")
                print(
                    f"   Solution: Close any open database connections "
                    f"or restart the notebook kernel"
                )
                return False
        except Exception as e:
            logger.error(f"Unexpected error deleting database: {e}", exc_info=True)
            print(f"   ❌ Unexpected error: {e}")
            return False

    return False


def drop_sqlite_tables(
    db_path: str,
    tables: Optional[List[str]] = None
) -> bool:
    """
    Safely drop tables from SQLite database.

    Preferred over deleting the entire file when you want to keep the database
    but clear the data.

    Args:
        db_path: Path to SQLite database file
        tables: List of table names to drop (if None, drops all non-system tables)

    Returns:
        True if successful

    Example:
        >>> drop_sqlite_tables("databases/my.db", ["content_repo", "faq_questions"])
        ✓ Dropped table: content_repo
        ✓ Dropped table: faq_questions
        Total tables dropped: 2
        True
    """
    if not os.path.exists(db_path):
        logger.error(f"Database file does not exist: {db_path}")
        print(f"   Database file does not exist: {db_path}")
        return False

    try:
        logger.info(f"Dropping tables from {db_path}")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Get table list if not provided
        if tables is None:
            cursor.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
            """)
            tables = [row[0] for row in cursor.fetchall()]
            logger.debug(f"Found {len(tables)} tables to drop")

        # Drop each table
        dropped = []
        for table in tables:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {table}")
                dropped.append(table)
                logger.debug(f"Dropped table: {table}")
                print(f"   ✓ Dropped table: {table}")
            except sqlite3.Error as e:
                logger.warning(f"Could not drop table {table}: {e}")
                print(f"   ⚠ Could not drop table {table}: {e}")

        conn.commit()
        conn.close()

        # Close connections to release locks
        close_all_sqlite_connections()

        logger.info(f"Successfully dropped {len(dropped)} tables")
        print(f"   Total tables dropped: {len(dropped)}")
        return True

    except Exception as e:
        logger.error(f"Error dropping tables: {e}", exc_info=True)
        print(f"   ❌ Error dropping tables: {e}")
        return False


def get_sqlite_connection(
    db_path: str,
    timeout: float = 30.0
) -> sqlite3.Connection:
    """
    Get a SQLite connection with proper settings for notebooks.

    Applies standard PRAGMA settings:
    - foreign_keys = ON
    - journal_mode = WAL

    Args:
        db_path: Path to database file
        timeout: How long to wait for locks (default: 30 seconds)

    Returns:
        SQLite connection with optimizations applied

    Example:
        >>> conn = get_sqlite_connection("databases/my.db")
        >>> cursor = conn.cursor()
        >>> cursor.execute("SELECT * FROM content_repo")
    """
    logger.debug(f"Creating connection to {db_path} with timeout={timeout}")

    conn = sqlite3.connect(db_path, timeout=timeout)

    # Enable foreign keys (important!)
    conn.execute("PRAGMA foreign_keys = ON")

    # Use WAL mode for better concurrency
    try:
        conn.execute("PRAGMA journal_mode = WAL")
    except sqlite3.Error as e:
        logger.warning(f"Could not set WAL mode: {e}")

    # Performance optimizations
    try:
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA cache_size = -10000")  # 10MB cache
    except sqlite3.Error as e:
        logger.warning(f"Could not apply performance optimizations: {e}")

    return conn


def safe_close_connection(conn: Optional[sqlite3.Connection]):
    """
    Safely close a SQLite connection.

    Handles errors gracefully and forces garbage collection to release locks.

    Args:
        conn: Connection to close (can be None)

    Example:
        >>> conn = sqlite3.connect("my.db")
        >>> # ... do work ...
        >>> safe_close_connection(conn)
    """
    if conn is not None:
        try:
            conn.close()
            logger.debug("Connection closed successfully")
        except Exception as e:
            logger.warning(f"Error closing connection: {e}")
            pass  # Already closed or invalid

    # Force cleanup
    close_all_sqlite_connections()


def check_database_locked(db_path: str) -> bool:
    """
    Check if database is locked/in use.

    Attempts to acquire an IMMEDIATE lock to test if database is available.

    Args:
        db_path: Path to database file

    Returns:
        True if locked, False if available

    Example:
        >>> if check_database_locked("databases/my.db"):
        >>>     print("Database is in use!")
    """
    if not os.path.exists(db_path):
        logger.debug(f"Database {db_path} does not exist (not locked)")
        return False

    try:
        # Try to open exclusively with minimal timeout
        conn = sqlite3.connect(db_path, timeout=0.1)
        conn.execute("BEGIN IMMEDIATE")
        conn.rollback()
        conn.close()
        logger.debug(f"Database {db_path} is available (not locked)")
        return False  # Not locked
    except sqlite3.OperationalError:
        logger.debug(f"Database {db_path} is locked")
        return True  # Locked


def validate_database_file(db_path: str) -> bool:
    """
    Validate that a file is a valid SQLite database.

    Args:
        db_path: Path to database file

    Returns:
        True if valid SQLite database, False otherwise

    Example:
        >>> validate_database_file("databases/faq.db")
        True
        >>> validate_database_file("not_a_database.txt")
        False
    """
    if not os.path.exists(db_path):
        logger.warning(f"Database file does not exist: {db_path}")
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # Try to read sqlite_master table (exists in all SQLite databases)
        cursor.execute("SELECT name FROM sqlite_master LIMIT 1")
        conn.close()
        logger.debug(f"Validated database file: {db_path}")
        return True
    except sqlite3.DatabaseError:
        logger.error(f"Invalid SQLite database file: {db_path}")
        return False
    except Exception as e:
        logger.error(f"Error validating database: {e}", exc_info=True)
        return False


def get_database_info(db_path: str) -> dict:
    """
    Get information about a SQLite database.

    Args:
        db_path: Path to database file

    Returns:
        Dictionary with database information:
            - file_size: Size in bytes
            - table_count: Number of tables
            - tables: List of table names
            - journal_mode: Current journal mode
            - page_size: Database page size

    Example:
        >>> info = get_database_info("databases/faq.db")
        >>> info
        {
            'file_size': 1024000,
            'table_count': 7,
            'tables': ['content_repo', 'content_chunks', ...],
            'journal_mode': 'wal',
            'page_size': 4096
        }
    """
    if not os.path.exists(db_path):
        logger.error(f"Database file does not exist: {db_path}")
        return {}

    try:
        # File size
        file_size = os.path.getsize(db_path)

        # Connect and query metadata
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Get tables
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """)
        tables = [row[0] for row in cursor.fetchall()]

        # Get journal mode
        cursor.execute("PRAGMA journal_mode")
        journal_mode = cursor.fetchone()[0]

        # Get page size
        cursor.execute("PRAGMA page_size")
        page_size = cursor.fetchone()[0]

        conn.close()

        info = {
            'file_size': file_size,
            'table_count': len(tables),
            'tables': tables,
            'journal_mode': journal_mode,
            'page_size': page_size,
        }

        logger.debug(f"Database info for {db_path}: {info}")
        return info

    except Exception as e:
        logger.error(f"Error getting database info: {e}", exc_info=True)
        return {}


# Export main functions
__all__ = [
    'close_all_sqlite_connections',
    'drop_sqlite_database',
    'drop_sqlite_tables',
    'get_sqlite_connection',
    'safe_close_connection',
    'check_database_locked',
    'validate_database_file',
    'get_database_info',
]
