# SQLite Backend

**Complete SQLite database backend implementation**

This directory contains ALL SQLite-specific code for the FAQ Update system. It implements the `IBackend` interface for SQLite databases with optimizations and error handling.

---

## ⚠️ Migration Notice

**This entire directory can be deleted when migrating to Databricks.**

All SQLite code is isolated here so migration to Databricks requires zero SQLite residue in the codebase.

```bash
# After migrating to Databricks
rm -rf database/backends/sqlite/
```

---

## Architecture

```
database/backends/sqlite/
├── backend.py          # Main SQLiteBackend class (implements IBackend)
├── connection.py       # Connection management
├── utilities.py        # SQLite-specific utilities
├── __init__.py         # Module exports
└── README.md           # This file
```

---

## Modules

### `backend.py` - Main Backend Class

**SQLiteBackend** implements the full `IBackend` interface:

```python
from database.backends.sqlite import SQLiteBackend
from database.config import DatabaseConfig

config = DatabaseConfig(backend="sqlite", db_path="faq.db")
backend = SQLiteBackend(config)

# Connect
backend.connect()

# Query
results = backend.execute_query(
    "SELECT * FROM content_repo WHERE file_status = ?",
    ("Active",)
)

# Command
backend.execute_command(
    "UPDATE content_repo SET file_status = ? WHERE ud_source_file_id = ?",
    ("Archived", 1)
)

# Bulk insert
import pandas as pd
df = pd.DataFrame({'raw_file_nme': ['file1.pdf'], 'file_status': ['Active']})
result = backend.ingest_dataframe(df, "content_repo")

# Transaction
backend.begin_transaction()
backend.execute_command("INSERT INTO ...")
backend.execute_command("UPDATE ...")
backend.commit()

# Close
backend.close()
```

**Key Features:**
- ✅ Full IBackend interface implementation
- ✅ Parameterized queries (SQL injection safe)
- ✅ Bulk DataFrame operations via pandas.to_sql
- ✅ ACID transaction support
- ✅ Connection pooling
- ✅ Windows file locking handling
- ✅ WAL mode for better concurrency
- ✅ Foreign key enforcement
- ✅ Performance optimizations (pragmas, caching)

---

### `connection.py` - Connection Management

**SQLiteConnectionManager** handles connection lifecycle:

```python
from database.backends.sqlite.connection import SQLiteConnectionManager

# Standard usage
manager = SQLiteConnectionManager("faq.db")
conn = manager.get_connection()
conn.execute("INSERT INTO ...")
conn.commit()
manager.close()

# Context manager
with SQLiteConnectionManager("faq.db") as conn:
    conn.execute("INSERT INTO ...")
    conn.commit()
```

**Configuration Options:**
- `db_path`: Path to database file or ":memory:"
- `timeout`: Connection timeout (default: 30s)
- `enable_foreign_keys`: Enable FK constraints (default: True)
- `journal_mode`: Journal mode (default: "WAL")
- `check_same_thread`: Allow multi-threading (default: True)

**PRAGMA Settings Applied:**
- `PRAGMA foreign_keys = ON` - Foreign key enforcement
- `PRAGMA journal_mode = WAL` - Write-Ahead Logging for concurrency
- `PRAGMA synchronous = NORMAL` - Performance optimization
- `PRAGMA cache_size = -10000` - 10MB cache

---

### `utilities.py` - SQLite Utilities

**Database Utilities:**

```python
from database.backends.sqlite.utilities import (
    close_all_sqlite_connections,
    drop_sqlite_database,
    drop_sqlite_tables,
    get_sqlite_connection,
    safe_close_connection,
    check_database_locked,
    validate_database_file,
    get_database_info,
)

# Close all connections (useful before dropping)
close_all_sqlite_connections()

# Drop database file
drop_sqlite_database("databases/faq.db")

# Drop specific tables
drop_sqlite_tables("databases/faq.db", ["content_repo", "content_chunks"])

# Check if database is locked
if check_database_locked("databases/faq.db"):
    print("Database is in use!")

# Validate database file
if validate_database_file("databases/faq.db"):
    print("Valid SQLite database")

# Get database info
info = get_database_info("databases/faq.db")
print(f"Tables: {info['tables']}")
print(f"Size: {info['file_size']} bytes")
```

---

## Migration History

This module consolidates code from:

| Original Location | New Location | Date |
|------------------|--------------|------|
| `database/utils/connection_helpers.py` | `connection.py` | 2025-11-02 |
| `utility/database.py` | `utilities.py` | 2025-11-02 |
| New implementation | `backend.py` | 2025-11-02 |

---

## Performance Optimizations

### WAL Mode (Write-Ahead Logging)
- **Benefit:** Better concurrency - readers don't block writers
- **Trade-off:** Slightly larger disk usage
- **Setting:** `PRAGMA journal_mode = WAL`

### Cache Size
- **Benefit:** Faster query performance
- **Setting:** 10MB cache (`PRAGMA cache_size = -10000`)

### Synchronous Mode
- **Benefit:** Faster writes
- **Trade-off:** Slightly less durable (but still ACID compliant)
- **Setting:** `PRAGMA synchronous = NORMAL`

### Foreign Keys
- **Benefit:** Data integrity enforcement
- **Note:** Must be enabled explicitly in SQLite
- **Setting:** `PRAGMA foreign_keys = ON`

---

## Error Handling

### Windows File Locking
SQLite on Windows can have file locking issues. The backend handles this:

```python
# Retry logic for file operations
close_all_sqlite_connections()  # Force close all connections
drop_sqlite_database("faq.db", max_retries=3)  # Retry with delays
```

### Connection Errors
```python
try:
    backend = SQLiteBackend(config)
    backend.connect()
except ConnectionError as e:
    print(f"Could not connect: {e}")
```

### Query Errors
```python
try:
    results = backend.execute_query("SELECT * FROM invalid_table")
except QueryError as e:
    print(f"Query failed: {e}")
```

### Transaction Errors
```python
try:
    backend.begin_transaction()
    backend.execute_command("INSERT ...")
    backend.commit()
except TransactionError as e:
    backend.rollback()
    print(f"Transaction failed: {e}")
```

---

## Thread Safety

### Read Operations
- ✅ Thread-safe
- Multiple threads can read concurrently (WAL mode)

### Write Operations
- ⚠️ Use transactions for multi-threading
- SQLite has database-level write lock
- Recommended: Use connection pool or queue for writes

### Multi-Threading Example
```python
from concurrent.futures import ThreadPoolExecutor

def read_data(backend):
    return backend.execute_query("SELECT * FROM content_repo")

# Safe - multiple readers
with ThreadPoolExecutor(max_workers=5) as executor:
    futures = [executor.submit(read_data, backend) for _ in range(5)]
    results = [f.result() for f in futures]

# For writes, use queue or serialize
def write_data(data):
    backend = SQLiteBackend(config)  # Each thread gets own connection
    backend.connect()
    try:
        backend.execute_command("INSERT INTO ...", data)
    finally:
        backend.close()
```

---

## Testing

### Unit Tests
Located in `tests/backend/test_sqlite_backend.py`

```python
# Run SQLite backend tests
pytest tests/backend/test_sqlite_backend.py -v
```

### Integration Tests
```python
# Test with actual database
pytest tests/integration/test_sqlite_integration.py -v
```

### In-Memory Testing
```python
# Fast tests with in-memory database
config = DatabaseConfig(backend="sqlite", db_path=":memory:")
backend = SQLiteBackend(config)
```

---

## Comparison: SQLite vs Databricks

| Feature | SQLite | Databricks |
|---------|--------|------------|
| **Scale** | Single machine | Distributed cluster |
| **Concurrency** | Limited (WAL helps) | High (Spark parallelism) |
| **Data Format** | SQLite file | Delta Lake |
| **Query Engine** | SQLite | Spark SQL |
| **ACID** | ✅ Yes | ✅ Yes |
| **Foreign Keys** | ✅ Yes (must enable) | ⚠️ Not enforced |
| **Transactions** | ✅ Yes | ✅ Yes |
| **Use Case** | Local dev, testing | Production, big data |
| **Cost** | Free | Databricks pricing |

---

## Best Practices

### 1. Always Use Parameterized Queries
```python
# GOOD ✅
results = backend.execute_query(
    "SELECT * FROM users WHERE id = ?",
    (user_id,)
)

# BAD ❌ - SQL INJECTION RISK!
results = backend.execute_query(
    f"SELECT * FROM users WHERE id = {user_id}"
)
```

### 2. Use Transactions for Multi-Step Operations
```python
# GOOD ✅
backend.begin_transaction()
try:
    backend.execute_command("INSERT INTO content_repo ...")
    backend.execute_command("INSERT INTO content_chunks ...")
    backend.commit()
except Exception:
    backend.rollback()
    raise

# BAD ❌
backend.execute_command("INSERT INTO content_repo ...")
backend.execute_command("INSERT INTO content_chunks ...")  # If this fails, first insert persists!
```

### 3. Use Context Managers
```python
# GOOD ✅
with backend:
    results = backend.execute_query("SELECT ...")

# BAD ❌
backend.connect()
results = backend.execute_query("SELECT ...")
# Forgot to close!
```

### 4. Bulk Operations for Performance
```python
# GOOD ✅ - Single operation
df = pd.DataFrame(lots_of_data)
backend.ingest_dataframe(df, "content_chunks")

# BAD ❌ - Loop with individual inserts
for row in lots_of_data:
    backend.execute_command("INSERT INTO content_chunks ...", row)
```

---

## Troubleshooting

### Database Locked Error
```
sqlite3.OperationalError: database is locked
```

**Solution:**
```python
# 1. Close all connections
close_all_sqlite_connections()

# 2. Increase timeout
config = DatabaseConfig(backend="sqlite", db_path="faq.db", timeout=60)

# 3. Use WAL mode (enabled by default)
# WAL allows readers and writers to work concurrently
```

### Foreign Key Constraint Failed
```
sqlite3.IntegrityError: FOREIGN KEY constraint failed
```

**Solution:**
```python
# 1. Verify referenced record exists
exists = backend.execute_query(
    "SELECT 1 FROM content_repo WHERE ud_source_file_id = ?",
    (file_id,)
)

# 2. Insert in correct order (parent before child)
backend.execute_command("INSERT INTO content_repo ...")
backend.execute_command("INSERT INTO content_chunks ...")  # References content_repo
```

### File Permission Error
```
PermissionError: [Errno 13] Permission denied
```

**Solution:**
```python
# 1. Check file permissions
os.chmod("faq.db", 0o666)

# 2. Ensure directory exists and is writable
Path("databases").mkdir(parents=True, exist_ok=True)

# 3. Close all connections before file operations
close_all_sqlite_connections()
drop_sqlite_database("databases/faq.db")
```

---

## Future Enhancements

Potential improvements (not currently implemented):

1. **Connection Pooling** - Reuse connections across requests
2. **Read Replicas** - Multiple read-only database files
3. **Automatic Vacuum** - Reclaim space after deletes
4. **Encryption** - SQLCipher integration for encrypted databases
5. **Monitoring** - Query performance tracking
6. **Backup** - Automated backup functionality

---

## Related Documentation

- [IBackend Interface](../base.py) - Interface specification
- [Configuration](../../config.py) - Database configuration
- [Migration Plan](../../../MIGRATION_PLAN_SQLITE_TO_DATABRICKS.md) - Full migration guide

---

**Version:** 2.0.0
**Last Updated:** 2025-11-02
**Status:** ✅ Production Ready
