"""
SQLite Backend Implementation

Provides SQLite database backend with all utilities consolidated in one place.

This module contains ALL SQLite-specific code. When migrating to Databricks,
you can delete this entire directory without affecting Databricks functionality.

Modules:
- backend.py: Main SQLiteBackend class (implements IBackend)
- connection.py: Connection management (moved from utils/connection_helpers.py)
- utilities.py: SQLite utilities (moved from utility/database.py)

Example:
    >>> from database.backends.sqlite import SQLiteBackend
    >>> from database.config import DatabaseConfig
    >>>
    >>> config = DatabaseConfig(backend="sqlite", db_path="faq.db")
    >>> backend = SQLiteBackend(config)
    >>> backend.connect()
    >>> results = backend.execute_query("SELECT * FROM content_repo")
    >>> backend.close()

Author: Analytics Assist Team
Date: 2025-11-02
Version: 2.0.0 (Completed)
"""

# Main backend class
from database.backends.sqlite.backend import SQLiteBackend

# Connection management
from database.backends.sqlite.connection import (
    SQLiteConnectionManager,
    create_sqlite_connection,
)

# Utilities
from database.backends.sqlite.utilities import (
    close_all_sqlite_connections,
    drop_sqlite_database,
    drop_sqlite_tables,
    get_sqlite_connection,
    safe_close_connection,
    check_database_locked,
    validate_database_file,
    get_database_info,
)

__all__ = [
    # Main backend
    "SQLiteBackend",

    # Connection management
    "SQLiteConnectionManager",
    "create_sqlite_connection",

    # Utilities
    "close_all_sqlite_connections",
    "drop_sqlite_database",
    "drop_sqlite_tables",
    "get_sqlite_connection",
    "safe_close_connection",
    "check_database_locked",
    "validate_database_file",
    "get_database_info",
]
