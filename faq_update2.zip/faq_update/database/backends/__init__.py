"""
Database Backends Module

This module provides database backend implementations for different database systems.
All backends implement the IBackend interface for interchangeable use.

Supported Backends:
- SQLite: Local development and testing
- Databricks: Production environment with Unity Catalog and Delta Lake

Architecture:
    Application Code
         ↓
    Repository Layer
         ↓
    IBackend Interface
         ↓
    Backend Implementation (SQLite or Databricks)
         ↓
    Actual Database

Usage:
    >>> # Auto-detect backend from environment
    >>> from database.backends import get_backend
    >>> backend = get_backend()

    >>> # Explicit backend creation
    >>> from database.backends import BackendFactory
    >>> from database.config import DatabaseConfig
    >>>
    >>> config = DatabaseConfig(backend="sqlite", db_path="faq.db")
    >>> backend = BackendFactory.create_backend(config)

    >>> # Use backend (same interface for all backends!)
    >>> results = backend.execute_query("SELECT * FROM content_repo WHERE file_status = ?", ("Active",))
    >>> backend.execute_command("UPDATE content_repo SET file_status = ? WHERE ud_source_file_id = ?", ("Archived", 1))

Backend Selection:
    The factory automatically selects the appropriate backend based on:
    1. Explicit configuration (DatabaseConfig)
    2. Environment variables (DATABASE_BACKEND)
    3. Auto-detection (DATABRICKS_RUNTIME_VERSION for Databricks)
    4. Default (SQLite)

Environment Variables:
    DATABASE_BACKEND: Backend type ('sqlite' or 'databricks')
    DATABASE_PATH: SQLite database file path
    DATABASE_CATALOG: Databricks Unity Catalog name
    DATABASE_SCHEMA: Databricks schema name

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

# Core interfaces and types
from database.backends.base import (
    IBackend,
    BackendType,
    # Exceptions
    BackendError,
    ConnectionError,
    QueryError,
    CommandError,
    TransactionError,
    TableNotFoundError,
    MultipleResultsError,
    ConfigurationError,
)

# Factory and convenience functions
from database.backends.factory import (
    BackendFactory,
    get_backend,
    reset_backend,
)

# Configuration
from database.config import (
    DatabaseConfig,
    load_config,
)

# Try to import concrete backends (graceful degradation if dependencies missing)
try:
    from database.backends.sqlite import SQLiteBackend
    _SQLITE_AVAILABLE = True
except ImportError as e:
    print(f"Warning: SQLite backend not available: {e}")
    SQLiteBackend = None
    _SQLITE_AVAILABLE = False

try:
    from database.backends.databricks import DatabricksBackend
    _DATABRICKS_AVAILABLE = True
except ImportError as e:
    # Databricks backend not available (likely pyspark not installed)
    DatabricksBackend = None
    _DATABRICKS_AVAILABLE = False


def is_backend_available(backend_type: str) -> bool:
    """
    Check if a backend type is available (dependencies installed).

    Args:
        backend_type: Backend type ('sqlite', 'databricks', etc.)

    Returns:
        True if backend dependencies are available

    Example:
        >>> is_backend_available('sqlite')
        True
        >>> is_backend_available('databricks')
        False  # If pyspark not installed
    """
    if backend_type == BackendType.SQLITE.value:
        return _SQLITE_AVAILABLE
    elif backend_type == BackendType.DATABRICKS.value:
        return _DATABRICKS_AVAILABLE
    else:
        return False


def list_available_backends() -> list[str]:
    """
    List all available backends (with dependencies installed).

    Returns:
        List of backend names

    Example:
        >>> list_available_backends()
        ['sqlite', 'databricks']
    """
    available = []
    if _SQLITE_AVAILABLE:
        available.append(BackendType.SQLITE.value)
    if _DATABRICKS_AVAILABLE:
        available.append(BackendType.DATABRICKS.value)
    return available


__all__ = [
    # Core Interface
    "IBackend",
    "BackendType",

    # Factory
    "BackendFactory",
    "get_backend",
    "reset_backend",

    # Configuration
    "DatabaseConfig",
    "load_config",

    # Concrete Backends (may be None if dependencies missing)
    "SQLiteBackend",
    "DatabricksBackend",

    # Exceptions
    "BackendError",
    "ConnectionError",
    "QueryError",
    "CommandError",
    "TransactionError",
    "TableNotFoundError",
    "MultipleResultsError",
    "ConfigurationError",

    # Utility Functions
    "is_backend_available",
    "list_available_backends",
]

# Module-level docstring for help()
__doc__ = """
Database Backends Module
========================

Provides database backend implementations with a unified interface.

Quick Start:
-----------
    >>> from database.backends import get_backend
    >>> backend = get_backend()  # Auto-detects environment
    >>> backend.execute_query("SELECT * FROM content_repo")

Available Backends: {backends}

For detailed documentation, see:
- database/backends/base.py: IBackend interface
- database/backends/factory.py: BackendFactory
- database/backends/sqlite/: SQLite implementation
- database/backends/databricks/: Databricks implementation
""".format(backends=", ".join(list_available_backends()) or "None (install dependencies)")
