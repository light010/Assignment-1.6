"""
Databricks Backend - Complete IBackend Implementation for Spark/Databricks

This module provides a complete implementation of the IBackend interface for
Databricks environments using Spark SQL and Delta tables.

Key Features:
    - Full IBackend interface implementation
    - Spark SQL for all database operations
    - Unity Catalog three-level namespace support
    - Delta Lake ACID transactions
    - Distributed query execution
    - Efficient DataFrame operations
    - Production-ready error handling

Design Principles:
    - Backend Pattern: Isolates all Databricks/Spark code
    - Single Responsibility: Only database I/O
    - Liskov Substitution: Drop-in replacement for SQLiteBackend
    - Fail-fast: Clear error messages
    - Logging: Comprehensive debug/info logging

Example:
    >>> from database.backends.databricks import DatabricksBackend
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Create configuration
    >>> config = DatabaseConfig(
    ...     backend="databricks",
    ...     catalog="prod_catalog",
    ...     schema="faq_schema"
    ... )
    >>>
    >>> # Create backend
    >>> backend = DatabricksBackend(config)
    >>> backend.connect()
    >>>
    >>> # Query
    >>> results = backend.execute_query("SELECT * FROM content_repo LIMIT 10")
    >>> print(f"Found {len(results)} files")
    >>>
    >>> # Close
    >>> backend.close()

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Any, Dict, List, Optional, Tuple
import pandas as pd

from database.backends.base import IBackend, BackendType
from database.backends.base import (
    BackendError,
    ConnectionError as BackendConnectionError,
    QueryError,
    CommandError,
    TransactionError,
    TableNotFoundError,
    MultipleResultsError,
    ConfigurationError
)
from database.config import DatabaseConfig
from database.dialect import DatabaseDialect
from database.backends.databricks.connection import SparkConnectionManager
from loguru import logger


class DatabricksBackend(IBackend):
    """
    Databricks implementation of IBackend using Spark SQL.

    This backend provides complete database operations for Databricks environments
    using Delta tables and Unity Catalog. It implements all IBackend methods using
    Spark SQL and DataFrame API.

    Attributes:
        config: DatabaseConfig with Databricks settings
        conn_manager: SparkConnectionManager for session management
        spark: Active Spark session (lazy-loaded)
        catalog_name: Unity Catalog name
        schema_name: Schema name within catalog

    Example:
        >>> config = DatabaseConfig(backend="databricks", catalog="prod", schema="faq")
        >>> backend = DatabricksBackend(config)
        >>> with backend:
        ...     results = backend.execute_query("SELECT * FROM content_repo")
    """

    def __init__(self, config: DatabaseConfig):
        """
        Initialize Databricks backend.

        Args:
            config: DatabaseConfig with backend='databricks'

        Raises:
            ConfigurationError: If config is invalid or missing required fields
            ImportError: If pyspark not available

        Example:
            >>> config = DatabaseConfig(
            ...     backend="databricks",
            ...     catalog="my_catalog",
            ...     schema="my_schema"
            ... )
            >>> backend = DatabricksBackend(config)
        """
        super().__init__()

        # Validate configuration
        if not isinstance(config, DatabaseConfig):
            raise ConfigurationError(
                f"Expected DatabaseConfig, got {type(config).__name__}"
            )

        if config.backend != "databricks":
            raise ConfigurationError(
                f"Expected backend='databricks', got backend='{config.backend}'"
            )

        if not config.catalog:
            raise ConfigurationError("catalog is required for Databricks backend")

        if not config.schema:
            raise ConfigurationError("schema is required for Databricks backend")

        self.config = config
        self.catalog_name = config.catalog
        self.schema_name = config.schema

        # Create connection manager (session lazy-loaded on first use)
        try:
            self.conn_manager = SparkConnectionManager()
        except ImportError as e:
            raise ConfigurationError(f"PySpark not available: {e}")

        self.spark = None
        self._in_transaction = False

        logger.info(
            f"DatabricksBackend initialized: catalog={self.catalog_name}, "
            f"schema={self.schema_name}"
        )

    @property
    def backend_type(self) -> BackendType:
        """Get backend type."""
        return BackendType.DATABRICKS

    @property
    def dialect(self) -> DatabaseDialect:
        """Get database dialect."""
        return DatabaseDialect.DATABRICKS

    @property
    def is_connected(self) -> bool:
        """Check if connected to Spark session."""
        return self.spark is not None and self.conn_manager.is_active()

    def _get_full_table_name(self, table_name: str) -> str:
        """
        Get fully qualified table name (catalog.schema.table).

        Args:
            table_name: Simple table name

        Returns:
            Fully qualified name

        Example:
            >>> backend._get_full_table_name("content_repo")
            'prod_catalog.faq_schema.content_repo'
        """
        return f"{self.catalog_name}.{self.schema_name}.{table_name}"

    # =========================================================================
    # Connection Management
    # =========================================================================

    def connect(self) -> None:
        """
        Establish connection to Spark session.

        In Databricks, the Spark session is managed by the cluster, so this
        method retrieves the active session rather than creating one.

        Raises:
            ConnectionError: If no active Spark session found

        Example:
            >>> backend = DatabricksBackend(config)
            >>> backend.connect()
            >>> assert backend.is_connected
        """
        if self.is_connected:
            logger.debug("Already connected to Spark session")
            return

        try:
            self.spark = self.conn_manager.get_session("connecting DatabricksBackend")
            logger.info(
                f"Connected to Spark session (catalog={self.catalog_name}, "
                f"schema={self.schema_name})"
            )

        except RuntimeError as e:
            raise BackendConnectionError(f"Failed to connect to Spark session: {e}") from e

    def close(self) -> None:
        """
        Close connection (no-op for Databricks).

        In Databricks, the Spark session is managed by the cluster and should
        NOT be stopped manually. This method is provided for interface compatibility.

        If a transaction is active, it will be rolled back.

        Example:
            >>> backend = DatabricksBackend(config)
            >>> backend.connect()
            >>> backend.close()  # No-op, but safe to call
        """
        if self._in_transaction:
            logger.warning("Closing connection with active transaction - rolling back")
            self.rollback()

        # Don't actually close the Spark session
        self.conn_manager.close()
        self.spark = None

        logger.info("DatabricksBackend closed (Spark session still managed by cluster)")

    # =========================================================================
    # Query Execution (Read Operations)
    # =========================================================================

    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute SELECT query and return results as list of dictionaries.

        NOTE: Spark SQL does not support ? placeholders. Parameters are currently
        NOT supported. This is a known limitation - use with caution.

        Args:
            query: SQL SELECT statement
            params: NOT SUPPORTED (Spark SQL doesn't support parameterized queries)
            timeout: NOT SUPPORTED (included for interface compatibility)

        Returns:
            List of dictionaries (column_name → value)

        Raises:
            QueryError: If query execution fails
            ConnectionError: If not connected

        Warning:
            Spark SQL doesn't support ? placeholders. Ensure query is safe before
            executing. Validate/escape any dynamic values before including in query.

        Example:
            >>> results = backend.execute_query(
            ...     "SELECT * FROM content_repo WHERE file_status = 'Active'"
            ... )
            >>> len(results)
            42
        """
        if not self.is_connected:
            raise QueryError("Not connected to Spark session")

        if params:
            logger.warning(
                "Parameterized queries not supported in Spark SQL. "
                "Params will be ignored. Ensure query is safe!"
            )

        try:
            df = self.spark.sql(query)
            rows = df.collect()

            # Convert Row objects to dictionaries
            results = [row.asDict() for row in rows]

            logger.debug(f"Query returned {len(results)} rows")
            return results

        except Exception as e:
            logger.error(f"Query failed: {query[:100]}... Error: {e}", exc_info=True)
            raise QueryError(f"Query execution failed: {e}") from e

    def execute_query_single(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Execute SELECT query expecting 0 or 1 result.

        Args:
            query: SQL SELECT statement
            params: NOT SUPPORTED
            timeout: NOT SUPPORTED

        Returns:
            Dictionary representing the row, or None if no results

        Raises:
            MultipleResultsError: If query returns multiple rows
            QueryError: If query execution fails

        Example:
            >>> result = backend.execute_query_single(
            ...     "SELECT * FROM content_repo WHERE ud_source_file_id = 1"
            ... )
            >>> result['raw_file_nme']
            'handbook.pdf'
        """
        results = self.execute_query(query, params, timeout)

        if len(results) == 0:
            return None
        elif len(results) == 1:
            return results[0]
        else:
            raise MultipleResultsError(
                f"Expected 0 or 1 results, got {len(results)}. "
                f"Query: {query[:100]}..."
            )

    # =========================================================================
    # Command Execution (Write Operations)
    # =========================================================================

    def execute_command(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute INSERT, UPDATE, or DELETE command.

        Args:
            command: SQL INSERT/UPDATE/DELETE statement
            params: NOT SUPPORTED
            timeout: NOT SUPPORTED

        Returns:
            Number of rows affected (Note: Spark may return -1 for some operations)

        Raises:
            CommandError: If command execution fails
            ConnectionError: If not connected

        Example:
            >>> rows = backend.execute_command(
            ...     "UPDATE content_repo SET file_status = 'Archived' "
            ...     "WHERE ud_source_file_id = 1"
            ... )
            >>> rows  # May be -1 for Delta tables
            -1
        """
        if not self.is_connected:
            raise CommandError("Not connected to Spark session")

        if params:
            logger.warning(
                "Parameterized queries not supported in Spark SQL. "
                "Params will be ignored. Ensure command is safe!"
            )

        try:
            # Execute command
            self.spark.sql(command)

            # Spark SQL doesn't return row count for most operations
            # Return -1 to indicate "affected rows unknown"
            rows_affected = -1

            logger.debug(f"Command executed successfully")
            return rows_affected

        except Exception as e:
            logger.error(f"Command failed: {command[:100]}... Error: {e}", exc_info=True)
            raise CommandError(f"Command execution failed: {e}") from e

    def execute_many(
        self,
        command: str,
        params_list: List[Tuple],
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute command multiple times with different parameters.

        For Databricks, this is implemented as individual executions since Spark
        SQL doesn't have a native executemany() method. Consider using ingest_dataframe()
        for bulk operations instead.

        Args:
            command: SQL INSERT/UPDATE/DELETE statement
            params_list: NOT SUPPORTED (Spark SQL doesn't support parameterized queries)
            timeout: NOT SUPPORTED

        Returns:
            Total rows affected (-1 for Spark)

        Warning:
            This is inefficient for large batches. Use ingest_dataframe() instead.

        Example:
            >>> # NOT RECOMMENDED - Use ingest_dataframe() instead!
            >>> backend.execute_many(
            ...     "INSERT INTO content_repo (raw_file_nme) VALUES (?)",
            ...     [("file1.pdf",), ("file2.pdf",)]
            ... )
        """
        if not self.is_connected:
            raise CommandError("Not connected to Spark session")

        logger.warning(
            "execute_many() is inefficient for Spark. "
            "Consider using ingest_dataframe() for bulk operations."
        )

        if params_list:
            raise CommandError(
                "Parameterized queries not supported in Spark SQL. "
                "Use ingest_dataframe() for bulk operations instead."
            )

        # Spark doesn't support batch execution with params
        # This is a limitation of the interface
        total_affected = 0
        for _ in params_list:
            rows = self.execute_command(command, None, timeout)
            if rows > 0:
                total_affected += rows

        return total_affected

    # =========================================================================
    # Bulk Operations (DataFrame)
    # =========================================================================

    def ingest_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "append",
        index: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Bulk insert a pandas DataFrame into a Delta table.

        Args:
            df: pandas DataFrame to ingest
            table_name: Simple table name (will be qualified with catalog.schema)
            if_exists: 'append', 'replace', or 'fail' (default: 'append')
            index: Whether to write DataFrame index (default: False)
            **kwargs: Additional options

        Returns:
            Dict with success, rows_inserted, and message

        Example:
            >>> df = pd.DataFrame({
            ...     'raw_file_nme': ['file1.pdf', 'file2.pdf'],
            ...     'file_status': ['Active', 'Active']
            ... })
            >>> result = backend.ingest_dataframe(df, "content_repo")
            >>> result['success']
            True
        """
        if not self.is_connected:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": "Not connected to Spark session",
                "error": "Not connected"
            }

        if df.empty:
            logger.warning(f"Attempted to ingest empty DataFrame into {table_name}")
            return {
                "success": True,
                "rows_inserted": 0,
                "message": "No data to ingest (DataFrame is empty)"
            }

        full_table_name = self._get_full_table_name(table_name)

        try:
            # Get row count before insert
            rows_before = self._get_row_count(full_table_name)

            # Convert pandas DataFrame to Spark DataFrame
            spark_df = self.spark.createDataFrame(df)

            # Map if_exists to Spark write mode
            mode_map = {
                "append": "append",
                "replace": "overwrite",
                "fail": "error"
            }
            mode = mode_map.get(if_exists, "append")

            # Write to Delta table
            spark_df.write.format("delta").mode(mode).saveAsTable(full_table_name)

            # Get row count after insert
            rows_after = self._get_row_count(full_table_name)
            rows_inserted = rows_after - rows_before if mode == "append" else len(df)

            logger.info(f"Successfully inserted {rows_inserted} rows into {full_table_name}")

            return {
                "success": True,
                "rows_inserted": rows_inserted,
                "message": f"Successfully inserted {rows_inserted} rows into {full_table_name}"
            }

        except Exception as e:
            logger.error(f"Error inserting into {full_table_name}: {str(e)}")

            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Database error: {str(e)}",
                "error": str(e)
            }

    def read_table(
        self,
        table_name: str,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> pd.DataFrame:
        """
        Read table into pandas DataFrame.

        Args:
            table_name: Simple table name
            columns: Optional list of columns to select
            where: Optional WHERE clause (without WHERE keyword)
            params: NOT SUPPORTED
            limit: Optional row limit

        Returns:
            pandas DataFrame

        Example:
            >>> df = backend.read_table(
            ...     "content_repo",
            ...     columns=["ud_source_file_id", "raw_file_nme"],
            ...     where="file_status = 'Active'",
            ...     limit=100
            ... )
        """
        if not self.is_connected:
            raise QueryError("Not connected to Spark session")

        full_table_name = self._get_full_table_name(table_name)

        try:
            # Build query
            cols = ", ".join(columns) if columns else "*"
            query = f"SELECT {cols} FROM {full_table_name}"

            if where:
                query += f" WHERE {where}"

            if limit:
                query += f" LIMIT {limit}"

            # Execute and convert to pandas
            spark_df = self.spark.sql(query)
            df = spark_df.toPandas()

            logger.debug(f"Read {len(df)} rows from {full_table_name}")
            return df

        except Exception as e:
            logger.error(f"Error reading {full_table_name}: {e}")
            raise QueryError(f"Failed to read table: {e}") from e

    # =========================================================================
    # Transaction Management
    # =========================================================================

    def begin_transaction(self) -> None:
        """
        Start a new transaction.

        NOTE: Databricks/Spark uses Delta Lake's ACID transactions automatically.
        This method is provided for interface compatibility but doesn't explicitly
        start a transaction - Delta handles it internally.

        Example:
            >>> backend.begin_transaction()
            >>> backend.execute_command("INSERT INTO ...")
            >>> backend.commit()
        """
        if self._in_transaction:
            logger.warning("Transaction already active")
            return

        self._in_transaction = True
        logger.debug("Transaction started (Delta Lake ACID)")

    def commit(self) -> None:
        """
        Commit current transaction.

        NOTE: Delta Lake commits transactions automatically. This method is
        provided for interface compatibility.

        Example:
            >>> backend.begin_transaction()
            >>> backend.execute_command("INSERT INTO ...")
            >>> backend.commit()
        """
        if not self._in_transaction:
            logger.warning("No active transaction to commit")
            return

        # Delta Lake commits automatically
        self._in_transaction = False
        logger.debug("Transaction committed (Delta Lake ACID)")

    def rollback(self) -> None:
        """
        Rollback current transaction.

        NOTE: Delta Lake doesn't support explicit rollback. Once a write operation
        completes, it's committed. This method is provided for interface compatibility.

        Example:
            >>> backend.begin_transaction()
            >>> try:
            ...     backend.execute_command("INSERT INTO ...")
            >>> except Exception:
            ...     backend.rollback()
        """
        if not self._in_transaction:
            logger.warning("No active transaction to rollback")
            return

        # Delta Lake doesn't support explicit rollback
        self._in_transaction = False
        logger.debug("Transaction rolled back (best-effort)")

    # =========================================================================
    # Schema Operations
    # =========================================================================

    def table_exists(self, table_name: str) -> bool:
        """
        Check if table exists.

        Args:
            table_name: Simple table name

        Returns:
            True if table exists

        Example:
            >>> backend.table_exists("content_repo")
            True
        """
        if not self.is_connected:
            return False

        full_table_name = self._get_full_table_name(table_name)

        try:
            self.spark.sql(f"SELECT 1 FROM {full_table_name} LIMIT 0")
            return True
        except Exception:
            return False

    def get_table_schema(self, table_name: str) -> List[Dict[str, str]]:
        """
        Get table schema.

        Args:
            table_name: Simple table name

        Returns:
            List of column definitions

        Raises:
            TableNotFoundError: If table doesn't exist

        Example:
            >>> schema = backend.get_table_schema("content_repo")
            >>> schema[0]
            {'name': 'ud_source_file_id', 'type': 'INTEGER', ...}
        """
        if not self.is_connected:
            raise TableNotFoundError(f"Not connected to Spark session")

        full_table_name = self._get_full_table_name(table_name)

        try:
            result = self.spark.sql(f"DESCRIBE {full_table_name}").collect()

            schema = []
            for row in result:
                row_dict = row.asDict()
                if row_dict['col_name'] and not row_dict['col_name'].startswith('#'):
                    schema.append({
                        'name': row_dict['col_name'],
                        'type': row_dict['data_type'],
                        'nullable': True,  # Spark doesn't provide this easily
                        'default': None,
                        'primary_key': False  # Spark doesn't have PKs
                    })

            return schema

        except Exception as e:
            raise TableNotFoundError(f"Table {full_table_name} not found") from e

    def list_tables(self) -> List[str]:
        """
        List all tables in current catalog.schema.

        Returns:
            List of table names (simple names)

        Example:
            >>> tables = backend.list_tables()
            >>> 'content_repo' in tables
            True
        """
        if not self.is_connected:
            return []

        try:
            df = self.spark.sql(f"SHOW TABLES IN {self.catalog_name}.{self.schema_name}")
            tables = [row['tableName'] for row in df.collect()]
            return tables
        except Exception as e:
            logger.error(f"Failed to list tables: {e}")
            return []

    # =========================================================================
    # Utility Methods
    # =========================================================================

    def get_row_count(
        self,
        table_name: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None
    ) -> int:
        """
        Get row count.

        Args:
            table_name: Simple table name
            where: Optional WHERE clause
            params: NOT SUPPORTED

        Returns:
            Number of rows

        Example:
            >>> backend.get_row_count("content_repo")
            150
        """
        full_table_name = self._get_full_table_name(table_name)
        return self._get_row_count(full_table_name, where)

    def _get_row_count(self, full_table_name: str, where: Optional[str] = None) -> int:
        """Helper to get row count from fully qualified table name."""
        if not self.is_connected:
            return 0

        try:
            query = f"SELECT COUNT(*) as count FROM {full_table_name}"
            if where:
                query += f" WHERE {where}"

            result = self.spark.sql(query).collect()
            return result[0]['count']
        except Exception:
            return 0

    def get_distinct_values(
        self,
        table_name: str,
        column: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> List[Any]:
        """
        Get distinct values from column.

        Args:
            table_name: Simple table name
            column: Column name
            where: Optional WHERE clause
            params: NOT SUPPORTED
            limit: Optional limit

        Returns:
            List of distinct values

        Example:
            >>> values = backend.get_distinct_values("content_repo", "file_status")
            >>> values
            ['Active', 'Archived', 'Inactive']
        """
        if not self.is_connected:
            return []

        full_table_name = self._get_full_table_name(table_name)

        try:
            query = f"SELECT DISTINCT {column} FROM {full_table_name}"
            if where:
                query += f" WHERE {where}"
            query += f" WHERE {column} IS NOT NULL ORDER BY {column}"
            if limit:
                query += f" LIMIT {limit}"

            result = self.spark.sql(query).collect()
            values = [row[column] for row in result]
            return values

        except Exception as e:
            logger.error(f"Error getting distinct values: {e}")
            return []

    # =========================================================================
    # Context Manager Support
    # =========================================================================

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"DatabricksBackend(catalog='{self.catalog_name}', "
            f"schema='{self.schema_name}', connected={self.is_connected})"
        )


__all__ = ["DatabricksBackend"]
