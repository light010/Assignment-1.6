"""
Databricks/Spark Connection Management

This module provides Spark session management and validation utilities for
Databricks environments. It handles connection lifecycle, validation, and
environment detection for Unity Catalog-enabled Spark sessions.

Key Features:
    - Spark session validation and retrieval
    - Environment detection (Databricks vs local Spark)
    - Unity Catalog support
    - Graceful error handling with descriptive messages
    - No-op close (Spark sessions managed externally)

Design Principles:
    - Fail-fast with clear error messages
    - Validation before operations
    - External session management (Databricks-controlled)
    - Import-time error handling

Example:
    >>> from database.backends.databricks.connection import SparkConnectionManager
    >>>
    >>> # Create connection manager
    >>> manager = SparkConnectionManager()
    >>>
    >>> # Get active session
    >>> spark = manager.get_session()
    >>> df = spark.sql("SELECT * FROM my_catalog.my_schema.my_table")
    >>>
    >>> # Validate session
    >>> if manager.is_active():
    ...     print(f"Spark {manager.get_version()} is active")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Optional
from loguru import logger


class SparkConnectionManager:
    """
    Manages Spark session lifecycle for Databricks backend.

    Unlike SQLiteConnectionManager which creates connections, this manager
    validates and retrieves the externally-managed Spark session (managed by
    Databricks cluster).

    Attributes:
        _spark_session: Cached reference to active Spark session (lazy-loaded)

    Example:
        >>> manager = SparkConnectionManager()
        >>> spark = manager.get_session()
        >>> df = spark.sql("SELECT 1 as test")
        >>> df.show()
        +----+
        |test|
        +----+
        |   1|
        +----+
    """

    def __init__(self):
        """
        Initialize Spark connection manager.

        Does not create a Spark session - it will be retrieved on first use.
        In Databricks, the session is created and managed by the cluster.

        Raises:
            ImportError: If pyspark is not available
        """
        self._spark_session = None

        # Validate pyspark availability at init time
        try:
            from pyspark.sql import SparkSession
        except ImportError:
            raise ImportError(
                "PySpark not available. This backend requires a Databricks or Spark environment. "
                "Install with: pip install pyspark"
            )

        logger.debug("SparkConnectionManager initialized")

    def get_session(self, operation_name: str = "database operation"):
        """
        Get active Spark session or raise descriptive error.

        This replaces the pattern scattered across adapters:
            spark = SparkSession.getActiveSession()
            if spark is None:
                return {"success": False, "message": "No Spark session"}

        Args:
            operation_name: Description of operation needing Spark (for error messages)

        Returns:
            SparkSession: Active Spark session

        Raises:
            RuntimeError: If no active Spark session found

        Example:
            >>> manager = SparkConnectionManager()
            >>> spark = manager.get_session("querying content_chunks")
            >>> df = spark.sql("SELECT * FROM content_chunks LIMIT 10")
        """
        # Return cached session if available
        if self._spark_session is not None:
            return self._spark_session

        # Import here to avoid dependency issues
        from pyspark.sql import SparkSession

        # Get active session
        spark = SparkSession.getActiveSession()

        if spark is None:
            raise RuntimeError(
                f"Cannot perform {operation_name}: No active Spark session found. "
                "Ensure you are running in a Databricks notebook or have initialized SparkSession."
            )

        # Cache for future calls
        self._spark_session = spark

        logger.debug(f"Retrieved active Spark session for: {operation_name}")
        return spark

    def is_active(self) -> bool:
        """
        Check if a Spark session is currently active.

        This is a non-raising version of get_session() for conditional logic.

        Returns:
            bool: True if Spark session is active, False otherwise

        Example:
            >>> manager = SparkConnectionManager()
            >>> if manager.is_active():
            ...     print("Running in Spark environment")
            ... else:
            ...     print("Running in local environment")
        """
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.getActiveSession()
            return spark is not None
        except ImportError:
            return False

    def get_version(self) -> Optional[str]:
        """
        Get Spark version if session is active.

        Returns:
            str: Spark version string (e.g., "3.3.0"), or None if no session

        Example:
            >>> manager = SparkConnectionManager()
            >>> version = manager.get_version()
            >>> if version:
            ...     print(f"Spark version: {version}")
            Spark version: 3.3.0
        """
        try:
            spark = self.get_session("getting version")
            return spark.version
        except (ImportError, RuntimeError):
            return None

    def get_catalog_info(self) -> Optional[dict]:
        """
        Get Unity Catalog information if available.

        Returns:
            dict: Catalog metadata, or None if not available
                {
                    'current_catalog': str,
                    'current_schema': str,
                    'unity_catalog_enabled': bool
                }

        Example:
            >>> manager = SparkConnectionManager()
            >>> info = manager.get_catalog_info()
            >>> if info and info['unity_catalog_enabled']:
            ...     print(f"Using {info['current_catalog']}.{info['current_schema']}")
        """
        try:
            spark = self.get_session("getting catalog info")

            # Try to get current catalog/schema (Unity Catalog feature)
            try:
                current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
                current_schema = spark.sql("SELECT current_schema()").collect()[0][0]

                return {
                    'current_catalog': current_catalog,
                    'current_schema': current_schema,
                    'unity_catalog_enabled': True
                }
            except Exception as e:
                # Unity Catalog not enabled or other error
                logger.debug(f"Unity Catalog not available: {e}")
                return {
                    'current_catalog': None,
                    'current_schema': None,
                    'unity_catalog_enabled': False
                }

        except (ImportError, RuntimeError):
            return None

    def close(self) -> None:
        """
        Close Spark session (no-op for Databricks).

        In Databricks, Spark sessions are managed by the cluster and should NOT
        be stopped manually. This method is provided for interface compatibility
        and logs a debug message.

        Note:
            Unlike SQLiteConnectionManager.close() which actually closes connections,
            this is a no-op. The Databricks cluster manages the session lifecycle.

        Example:
            >>> manager = SparkConnectionManager()
            >>> spark = manager.get_session()
            >>> # ... use spark ...
            >>> manager.close()  # Safe to call, but does nothing
        """
        logger.debug("SparkConnectionManager.close() called - no-op (session managed by Databricks)")
        # Don't stop the Spark session - it's managed by Databricks cluster
        # Just clear our cached reference
        self._spark_session = None

    def __enter__(self):
        """Context manager entry - returns self for with statements."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - calls close() for cleanup."""
        self.close()
        return False  # Don't suppress exceptions

    def __repr__(self) -> str:
        """String representation."""
        version = self.get_version()
        active = self.is_active()
        return f"SparkConnectionManager(active={active}, version={version})"


# =============================================================================
# Convenience Functions (for backward compatibility)
# =============================================================================

def get_spark_or_fail(operation_name: str = "database operation"):
    """
    Get active Spark session or raise descriptive error.

    This is a convenience function that creates a connection manager internally.
    For repeated use, prefer creating a SparkConnectionManager instance.

    Args:
        operation_name: Description of the operation needing Spark (for error message)

    Returns:
        SparkSession: Active Spark session

    Raises:
        RuntimeError: If no active Spark session found
        ImportError: If pyspark not available

    Example:
        >>> from database.backends.databricks.connection import get_spark_or_fail
        >>>
        >>> # Instead of this pattern:
        >>> spark = SparkSession.getActiveSession()
        >>> if spark is None:
        ...     raise RuntimeError("No Spark session")
        >>>
        >>> # Do this:
        >>> spark = get_spark_or_fail("ingesting chunks")
        >>> df = spark.sql("SELECT * FROM content_chunks")
    """
    manager = SparkConnectionManager()
    return manager.get_session(operation_name)


def validate_spark_session() -> bool:
    """
    Check if a Spark session is available (without raising error).

    Returns:
        bool: True if Spark session is active, False otherwise

    Example:
        >>> from database.backends.databricks.connection import validate_spark_session
        >>>
        >>> if validate_spark_session():
        ...     print("Running in Spark environment")
        ... else:
        ...     print("Running in local environment")
    """
    try:
        manager = SparkConnectionManager()
        return manager.is_active()
    except ImportError:
        return False


def get_spark_version() -> Optional[str]:
    """
    Get Spark version if available.

    Returns:
        str: Spark version string (e.g., "3.3.0"), or None if no session

    Example:
        >>> version = get_spark_version()
        >>> if version:
        ...     print(f"Spark version: {version}")
    """
    try:
        manager = SparkConnectionManager()
        return manager.get_version()
    except ImportError:
        return None


__all__ = [
    "SparkConnectionManager",
    "get_spark_or_fail",
    "validate_spark_session",
    "get_spark_version",
]
