"""
Databricks Detection Adapter - Spark/Databricks Implementation

This module provides Spark SQL-specific database operations for change detection
in Databricks environments using Unity Catalog and Delta tables.

Key Features:
    - Implements IDetectionAdapter interface
    - Uses V8.2 schema (Delta tables)
    - Optimized for Databricks production environment
    - Supports distributed processing with Spark
    - Delta Lake ACID transactions
    - Unity Catalog three-level namespace support

Design Principles:
    - Adapter Pattern: Wraps Spark-specific operations
    - Single Responsibility: Only database I/O
    - No Business Logic: Pure data access
    - Framework Agnostic: No detection logic
    - Separation of Concerns: Detection logic separate from persistence

Example:
    >>> from database.backends.databricks.detection import SparkDetectionAdapter
    >>> from detection import ChecksumChangeDetector
    >>>
    >>> # Create adapter (Spark session managed by Databricks)
    >>> adapter = SparkDetectionAdapter()
    >>>
    >>> # Load previous checksums
    >>> previous = adapter.get_previous_checksums("handbook.pdf")
    >>>
    >>> # Run detection
    >>> detector = ChecksumChangeDetector.for_faq_updates()
    >>> results = detector.detect_changes("handbook.pdf", current, previous, "run_001")
    >>>
    >>> # Store results
    >>> count = adapter.store_detection_results(results, run_id="run_001")
    >>> print(f"Stored {count} changes")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0 (Moved from database/adapters/spark_adapter.py)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from core.interfaces.detection_adapter import IDetectionAdapter
from core.models.detection import DetectionResult
from database.backends.databricks.connection import get_spark_or_fail
from utility.logging import get_logger

logger = get_logger(__name__)


class SparkDetectionAdapter(IDetectionAdapter):
    """
    Spark/Databricks implementation of IDetectionAdapter.

    This adapter uses Spark SQL and DataFrames for distributed processing.
    It's optimized for production environments using Databricks and Delta Lake.

    The adapter assumes Delta tables exist in Unity Catalog with V8.2 schema:
        - content_checksums (historical checksum data)
        - content_change_log (detection results)
        - faq_questions (FAQ question data)
        - faq_answers (FAQ answer data)

    Attributes:
        spark: SparkSession object (retrieved from active session)
        catalog_name: Optional Unity Catalog name (for three-level namespace)
        schema_name: Optional schema name (for three-level namespace)

    Example:
        >>> # Basic usage (uses current catalog/schema)
        >>> adapter = SparkDetectionAdapter()
        >>> previous = adapter.get_previous_checksums("handbook.pdf")
        >>> len(previous)
        42
        >>>
        >>> # With explicit catalog/schema
        >>> adapter = SparkDetectionAdapter(
        ...     catalog_name="prod_catalog",
        ...     schema_name="faq_schema"
        ... )
    """

    def __init__(
        self,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        spark_session=None
    ):
        """
        Initialize Spark detection adapter.

        Args:
            catalog_name: Optional Unity Catalog name (uses current if None)
            schema_name: Optional schema name (uses current if None)
            spark_session: Optional SparkSession (uses active session if None)

        Raises:
            ImportError: If pyspark is not available
            RuntimeError: If no active Spark session found and spark_session not provided
            TypeError: If spark_session is provided but not a SparkSession

        Example:
            >>> # Auto-detect from environment
            >>> adapter = SparkDetectionAdapter()
            >>>
            >>> # Explicit catalog/schema
            >>> adapter = SparkDetectionAdapter(
            ...     catalog_name="my_catalog",
            ...     schema_name="my_schema"
            ... )
            >>>
            >>> # Provide spark session (testing)
            >>> from pyspark.sql import SparkSession
            >>> spark = SparkSession.builder.appName("test").getOrCreate()
            >>> adapter = SparkDetectionAdapter(spark_session=spark)
        """
        # Validate pyspark availability
        try:
            from pyspark.sql import SparkSession
        except ImportError:
            raise ImportError(
                "pyspark not available. Install with: pip install pyspark"
            )

        # Get Spark session
        if spark_session is not None:
            # Validate provided session
            if not isinstance(spark_session, SparkSession):
                raise TypeError(
                    f"Expected SparkSession, got {type(spark_session).__name__}"
                )
            self.spark = spark_session
        else:
            # Get active session
            self.spark = get_spark_or_fail("initializing SparkDetectionAdapter")

        self.catalog_name = catalog_name
        self.schema_name = schema_name

        logger.info(
            f"SparkDetectionAdapter initialized "
            f"(catalog={catalog_name or 'current'}, schema={schema_name or 'current'})"
        )

    def _get_table_name(self, simple_name: str) -> str:
        """
        Get fully qualified table name (catalog.schema.table or just table).

        Args:
            simple_name: Simple table name (e.g., "content_checksums")

        Returns:
            str: Fully qualified name or simple name

        Example:
            >>> adapter = SparkDetectionAdapter(catalog="prod", schema="faq")
            >>> adapter._get_table_name("content_checksums")
            'prod.faq.content_checksums'
            >>>
            >>> adapter = SparkDetectionAdapter()
            >>> adapter._get_table_name("content_checksums")
            'content_checksums'
        """
        if self.catalog_name and self.schema_name:
            return f"{self.catalog_name}.{self.schema_name}.{simple_name}"
        elif self.schema_name:
            return f"{self.schema_name}.{simple_name}"
        else:
            return simple_name

    def get_previous_checksums(
        self,
        file_name: str,
        since_date: Optional[datetime] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Retrieve previous checksums for a file from Delta table.

        Uses V8.2 schema: content_checksums Delta table.
        Queries with Spark SQL (uses string formatting for table/column names,
        but validates file_name before use).

        Args:
            file_name: Name of file to query
            since_date: Only get checksums created before this date (optional)

        Returns:
            Dictionary mapping checksums to content metadata

        Raises:
            Exception: If query fails
            ValueError: If file_name is empty

        Example:
            >>> adapter = SparkDetectionAdapter()
            >>> previous = adapter.get_previous_checksums("handbook.pdf")
            >>> previous['abc123...']['content_text']
            'How do I reset my password?'
            >>>
            >>> # With date filter
            >>> from datetime import datetime
            >>> cutoff = datetime(2025, 10, 1)
            >>> previous = adapter.get_previous_checksums("handbook.pdf", since_date=cutoff)
        """
        if not file_name:
            raise ValueError("file_name cannot be empty")

        table_name = self._get_table_name("content_checksums")

        # Build query with optional date filter
        # Note: Spark SQL doesn't support ? placeholders like SQLite
        # We use f-strings but ensure file_name is validated first
        if since_date:
            query = f"""
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at
                FROM {table_name} cc
                WHERE cc.file_name = '{file_name}'
                  AND cc.created_at < '{since_date.isoformat()}'
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """
        else:
            query = f"""
                SELECT DISTINCT
                    cc.content_checksum,
                    cc.content_text,
                    cc.file_name,
                    cc.page_number,
                    cc.section_name,
                    cc.created_at
                FROM {table_name} cc
                WHERE cc.file_name = '{file_name}'
                  AND cc.status = 'active'
                ORDER BY cc.page_number
            """

        try:
            df = self.spark.sql(query)
            rows = df.collect()

            checksums_data = {}
            for row in rows:
                row_dict = row.asDict()
                checksum = row_dict["content_checksum"]
                checksums_data[checksum] = row_dict

            logger.info(
                f"📊 Retrieved {len(checksums_data)} previous checksums for {file_name} "
                f"from {table_name}"
            )

            return checksums_data

        except Exception as e:
            logger.error(f"❌ Failed to retrieve checksums for {file_name} from {table_name}: {e}")
            raise

    def store_detection_results(
        self,
        results: List[DetectionResult],
        run_id: str,
    ) -> int:
        """
        Store detection results in Delta table.

        Uses V8.2 schema: content_change_log Delta table.
        Converts DetectionResult domain models to Spark DataFrame and writes to Delta.

        Args:
            results: List of DetectionResult objects to store
            run_id: Unique identifier for this detection run

        Returns:
            Number of records successfully inserted

        Raises:
            Exception: If insert operation fails
            ValueError: If run_id is empty

        Example:
            >>> results = detector.detect_changes("file.pdf", current, previous, "run_001")
            >>> count = adapter.store_detection_results(results, run_id="run_001")
            >>> print(f"Stored {count} changes")
        """
        if not run_id:
            raise ValueError("run_id cannot be empty")

        if not results:
            logger.warning("⚠️ No results to store")
            return 0

        table_name = self._get_table_name("content_change_log")

        try:
            # Convert DetectionResult objects to list of dicts
            records = []
            for result in results:
                # Determine if FAQ regeneration required
                requires_regen = result.change_type.value in (
                    "new_content",
                    "modified_content",
                    "deleted_content",
                )

                # Map DetectionResult to database schema
                if result.change_type.value == "deleted_content":
                    content_checksum = result.old_checksum
                    previous_checksum = None
                else:
                    content_checksum = result.new_checksum
                    previous_checksum = result.old_checksum if result.old_checksum else None

                # Extract LLM diff from metadata if present
                diff_data = result.metadata.get("llm_diff") if result.metadata else None

                record = {
                    "content_checksum": content_checksum,
                    "previous_checksum": previous_checksum,
                    "file_name": result.file_name,
                    "requires_faq_regeneration": requires_regen,
                    "change_type": result.change_type.value,
                    "similarity_score": result.similarity_score,
                    "similarity_method": "hybrid",
                    "diff_data": diff_data,
                    "total_faqs_at_risk": 0,
                    "affected_question_count": 0,
                    "affected_answer_count": 0,
                    "detection_run_id": run_id,
                    "detection_timestamp": result.detected_at.isoformat(),
                }
                records.append(record)

            # Create DataFrame
            df = self.spark.createDataFrame(records)

            # Write to Delta table (append mode)
            df.write.format("delta").mode("append").saveAsTable(table_name)

            inserted = len(records)
            logger.info(f"✅ Stored {inserted} detection results to {table_name} (run_id: {run_id})")
            return inserted

        except Exception as e:
            logger.error(f"❌ Failed to store detection results to {table_name}: {e}")
            raise

    def get_faqs_by_checksum(
        self,
        checksum: str,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve FAQs associated with a specific content checksum.

        Queries both faq_questions and faq_answers Delta tables to find all FAQs
        that reference this checksum as their source.

        Args:
            checksum: Content checksum to query

        Returns:
            List of FAQ records

        Raises:
            Exception: If query fails
            ValueError: If checksum is empty

        Example:
            >>> faqs = adapter.get_faqs_by_checksum("abc123...")
            >>> for faq in faqs:
            ...     print(f"FAQ {faq['faq_id']}: {faq['question_text']}")
        """
        if not checksum:
            raise ValueError("checksum cannot be empty")

        questions_table = self._get_table_name("faq_questions")
        answers_table = self._get_table_name("faq_answers")

        # Query both questions and answers
        query = f"""
            SELECT
                q.faq_id,
                q.question_text,
                a.answer_text,
                q.source_checksum,
                q.created_at,
                q.status,
                'question' as source_type
            FROM {questions_table} q
            LEFT JOIN {answers_table} a ON q.faq_id = a.faq_id
            WHERE q.source_checksum = '{checksum}'

            UNION

            SELECT
                a.faq_id,
                q.question_text,
                a.answer_text,
                a.source_checksum,
                a.created_at,
                a.status,
                'answer' as source_type
            FROM {answers_table} a
            LEFT JOIN {questions_table} q ON a.faq_id = q.faq_id
            WHERE a.source_checksum = '{checksum}'
        """

        try:
            df = self.spark.sql(query)
            rows = df.collect()

            faqs = [row.asDict() for row in rows]

            logger.info(
                f"📋 Found {len(faqs)} FAQs for checksum {checksum[:8]}... "
                f"from {questions_table}/{answers_table}"
            )

            return faqs

        except Exception as e:
            logger.error(f"❌ Failed to retrieve FAQs for checksum {checksum[:8]}...: {e}")
            raise

    def close(self) -> None:
        """
        Close Spark session (optional, usually managed externally).

        Note: In Databricks, the SparkSession is typically managed by the cluster
        and shouldn't be stopped manually. This method is a no-op.

        Example:
            >>> adapter = SparkDetectionAdapter()
            >>> try:
            ...     previous = adapter.get_previous_checksums("file.pdf")
            ... finally:
            ...     adapter.close()  # No-op for Spark
        """
        # Spark sessions are typically managed externally (e.g., by Databricks)
        # Don't stop the session here
        logger.info("SparkDetectionAdapter.close() called (no-op for Spark)")

    def __enter__(self):
        """Context manager entry - returns self."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - calls close()."""
        self.close()
        return False  # Don't suppress exceptions

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"SparkDetectionAdapter("
            f"catalog={self.catalog_name or 'current'}, "
            f"schema={self.schema_name or 'current'})"
        )


# Convenience exports
__all__ = [
    "SparkDetectionAdapter",
]
