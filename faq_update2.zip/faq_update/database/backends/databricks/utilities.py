"""
Databricks-Specific Utility Functions

This module provides utility functions specific to Databricks and Spark environments.
These complement the connection manager and provide common operations for Delta tables,
Unity Catalog management, and Spark-specific database operations.

Key Features:
    - Delta table operations (OPTIMIZE, VACUUM, DESCRIBE)
    - Unity Catalog metadata queries
    - Table schema validation
    - Spark environment detection
    - Performance optimization utilities

Design Principles:
    - Databricks-specific (not general Spark)
    - Reusable across different adapters
    - Fail-fast with clear error messages
    - Logging for debugging
    - No business logic

Example:
    >>> from database.backends.databricks.utilities import optimize_delta_table
    >>>
    >>> # Optimize a Delta table
    >>> optimize_delta_table("my_catalog.my_schema.content_chunks")
    >>>
    >>> # Get table metadata
    >>> metadata = get_table_metadata("my_catalog.my_schema.content_chunks")
    >>> print(f"Table has {metadata['num_rows']} rows")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Any, Dict, List, Optional
from loguru import logger


def optimize_delta_table(
    table_name: str,
    zorder_by: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Optimize a Delta table for better query performance.

    Runs OPTIMIZE command to compact small files into larger ones.
    Optionally applies ZORDER clustering for faster queries.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)
        zorder_by: Optional list of columns to ZORDER by

    Returns:
        Dict with success status and message

    Example:
        >>> # Basic optimize
        >>> optimize_delta_table("my_catalog.my_schema.content_chunks")
        >>>
        >>> # Optimize with ZORDER (faster queries on these columns)
        >>> optimize_delta_table(
        ...     "my_catalog.my_schema.content_chunks",
        ...     zorder_by=["ud_source_file_id", "created_at"]
        ... )
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("optimizing Delta table")

        if zorder_by:
            zorder_clause = ", ".join(zorder_by)
            sql = f"OPTIMIZE {table_name} ZORDER BY ({zorder_clause})"
            logger.info(f"Optimizing {table_name} with ZORDER BY {zorder_clause}")
        else:
            sql = f"OPTIMIZE {table_name}"
            logger.info(f"Optimizing {table_name}")

        result = spark.sql(sql)
        logger.info(f"✅ Successfully optimized {table_name}")

        return {
            "success": True,
            "message": f"Successfully optimized {table_name}"
        }

    except Exception as e:
        logger.error(f"❌ Failed to optimize {table_name}: {e}")
        return {
            "success": False,
            "message": f"Failed to optimize table: {str(e)}",
            "error": str(e)
        }


def vacuum_delta_table(
    table_name: str,
    retention_hours: int = 168  # 7 days default
) -> Dict[str, Any]:
    """
    Remove old data files from a Delta table.

    Runs VACUUM command to delete files older than retention threshold.
    This reclaims storage space from deleted/updated data.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)
        retention_hours: Retention threshold in hours (default: 168 = 7 days)

    Returns:
        Dict with success status and message

    Warning:
        VACUUM permanently deletes data files. Cannot time travel beyond retention.

    Example:
        >>> # Vacuum with default 7-day retention
        >>> vacuum_delta_table("my_catalog.my_schema.content_chunks")
        >>>
        >>> # Vacuum with custom retention (24 hours)
        >>> vacuum_delta_table("my_catalog.my_schema.content_chunks", retention_hours=24)
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("vacuuming Delta table")

        sql = f"VACUUM {table_name} RETAIN {retention_hours} HOURS"
        logger.info(f"Vacuuming {table_name} (retention: {retention_hours} hours)")

        result = spark.sql(sql)
        logger.info(f"✅ Successfully vacuumed {table_name}")

        return {
            "success": True,
            "message": f"Successfully vacuumed {table_name}"
        }

    except Exception as e:
        logger.error(f"❌ Failed to vacuum {table_name}: {e}")
        return {
            "success": False,
            "message": f"Failed to vacuum table: {str(e)}",
            "error": str(e)
        }


def get_table_metadata(table_name: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed metadata about a Delta table.

    Retrieves table properties, schema, partitioning, and statistics.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)

    Returns:
        Dict with table metadata, or None if table doesn't exist
            {
                'name': str,
                'format': str,
                'num_rows': int,
                'size_bytes': int,
                'columns': List[Dict],
                'partitioned_by': List[str],
                'properties': Dict[str, str]
            }

    Example:
        >>> metadata = get_table_metadata("my_catalog.my_schema.content_chunks")
        >>> if metadata:
        ...     print(f"Table has {metadata['num_rows']} rows")
        ...     print(f"Columns: {[col['name'] for col in metadata['columns']]}")
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("getting table metadata")

        # Get table description
        desc_result = spark.sql(f"DESCRIBE DETAIL {table_name}").collect()

        if not desc_result:
            logger.warning(f"Table {table_name} not found")
            return None

        row = desc_result[0]

        # Get column schema
        schema_result = spark.sql(f"DESCRIBE {table_name}").collect()
        columns = [
            {
                'name': row['col_name'],
                'type': row['data_type'],
                'comment': row['comment'] if 'comment' in row.asDict() else None
            }
            for row in schema_result
            if row['col_name'] != '' and not row['col_name'].startswith('#')
        ]

        metadata = {
            'name': row['name'],
            'format': row['format'],
            'num_rows': row['numFiles'] if 'numFiles' in row.asDict() else None,
            'size_bytes': row['sizeInBytes'] if 'sizeInBytes' in row.asDict() else None,
            'columns': columns,
            'partitioned_by': row['partitionColumns'] if 'partitionColumns' in row.asDict() else [],
            'properties': row['properties'] if 'properties' in row.asDict() else {}
        }

        logger.debug(f"Retrieved metadata for {table_name}")
        return metadata

    except Exception as e:
        logger.error(f"❌ Failed to get metadata for {table_name}: {e}")
        return None


def list_tables_in_schema(
    catalog_name: str,
    schema_name: str
) -> List[str]:
    """
    List all tables in a Unity Catalog schema.

    Args:
        catalog_name: Catalog name
        schema_name: Schema name

    Returns:
        List of table names (simple names, not fully qualified)

    Example:
        >>> tables = list_tables_in_schema("my_catalog", "my_schema")
        >>> for table in tables:
        ...     print(f"Found table: {table}")
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("listing tables")

        # Use SHOW TABLES to get all tables in schema
        df = spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}")
        tables = [row['tableName'] for row in df.collect()]

        logger.debug(f"Found {len(tables)} tables in {catalog_name}.{schema_name}")
        return tables

    except Exception as e:
        logger.error(f"❌ Failed to list tables in {catalog_name}.{schema_name}: {e}")
        return []


def table_exists(
    catalog_name: str,
    schema_name: str,
    table_name: str
) -> bool:
    """
    Check if a table exists in Unity Catalog.

    Args:
        catalog_name: Catalog name
        schema_name: Schema name
        table_name: Table name (simple name)

    Returns:
        bool: True if table exists, False otherwise

    Example:
        >>> if table_exists("my_catalog", "my_schema", "content_chunks"):
        ...     print("Table exists!")
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("checking table existence")

        full_name = f"{catalog_name}.{schema_name}.{table_name}"

        # Try to query the table
        spark.sql(f"SELECT 1 FROM {full_name} LIMIT 0")

        logger.debug(f"Table {full_name} exists")
        return True

    except Exception:
        # Table doesn't exist or other error
        logger.debug(f"Table {catalog_name}.{schema_name}.{table_name} does not exist")
        return False


def is_databricks_environment() -> bool:
    """
    Detect if running in Databricks environment.

    Checks for Databricks-specific environment variables and modules.

    Returns:
        bool: True if running in Databricks, False otherwise

    Example:
        >>> if is_databricks_environment():
        ...     print("Running in Databricks")
        ... else:
        ...     print("Running locally")
    """
    import os

    # Check for Databricks-specific environment variables
    databricks_markers = [
        'DATABRICKS_RUNTIME_VERSION',
        'DB_HOME',
        'DB_DRIVER_IP',
    ]

    for marker in databricks_markers:
        if marker in os.environ:
            logger.debug(f"Detected Databricks environment (marker: {marker})")
            return True

    # Check if we can import databricks modules
    try:
        import databricks
        logger.debug("Detected Databricks environment (databricks module available)")
        return True
    except ImportError:
        pass

    logger.debug("Not running in Databricks environment")
    return False


def get_current_catalog_schema() -> Optional[Dict[str, str]]:
    """
    Get currently active catalog and schema.

    Returns:
        Dict with current_catalog and current_schema, or None if not available

    Example:
        >>> info = get_current_catalog_schema()
        >>> if info:
        ...     print(f"Using {info['current_catalog']}.{info['current_schema']}")
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("getting current catalog/schema")

        # Get current catalog and schema using Spark SQL functions
        current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
        current_schema = spark.sql("SELECT current_schema()").collect()[0][0]

        return {
            'current_catalog': current_catalog,
            'current_schema': current_schema
        }

    except Exception as e:
        logger.debug(f"Failed to get current catalog/schema: {e}")
        return None


def analyze_table_statistics(table_name: str) -> Dict[str, Any]:
    """
    Analyze table and compute fresh statistics.

    Runs ANALYZE TABLE to update statistics used by query optimizer.
    This improves query performance by providing accurate cardinality estimates.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)

    Returns:
        Dict with success status and message

    Example:
        >>> # Analyze table to update statistics
        >>> result = analyze_table_statistics("my_catalog.my_schema.content_chunks")
        >>> print(result['message'])
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("analyzing table statistics")

        sql = f"ANALYZE TABLE {table_name} COMPUTE STATISTICS"
        logger.info(f"Analyzing statistics for {table_name}")

        spark.sql(sql)
        logger.info(f"✅ Successfully analyzed {table_name}")

        return {
            "success": True,
            "message": f"Successfully analyzed {table_name}"
        }

    except Exception as e:
        logger.error(f"❌ Failed to analyze {table_name}: {e}")
        return {
            "success": False,
            "message": f"Failed to analyze table: {str(e)}",
            "error": str(e)
        }


def get_delta_log_info(table_name: str) -> Optional[Dict[str, Any]]:
    """
    Get Delta Lake transaction log information.

    Provides insights into Delta table history and versioning.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)

    Returns:
        Dict with Delta log information, or None if not a Delta table

    Example:
        >>> info = get_delta_log_info("my_catalog.my_schema.content_chunks")
        >>> if info:
        ...     print(f"Table version: {info['version']}")
    """
    from database.backends.databricks.connection import get_spark_or_fail

    try:
        spark = get_spark_or_fail("getting Delta log info")

        # Get Delta history
        history = spark.sql(f"DESCRIBE HISTORY {table_name} LIMIT 1").collect()

        if not history:
            return None

        row = history[0].asDict()

        return {
            'version': row.get('version'),
            'operation': row.get('operation'),
            'timestamp': row.get('timestamp'),
            'user': row.get('userIdentity'),
        }

    except Exception as e:
        logger.debug(f"Failed to get Delta log info for {table_name}: {e}")
        return None


__all__ = [
    "optimize_delta_table",
    "vacuum_delta_table",
    "get_table_metadata",
    "list_tables_in_schema",
    "table_exists",
    "is_databricks_environment",
    "get_current_catalog_schema",
    "analyze_table_statistics",
    "get_delta_log_info",
]
