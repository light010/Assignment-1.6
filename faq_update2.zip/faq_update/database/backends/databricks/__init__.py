"""
Databricks Backend Module

This module provides complete Databricks/Spark database backend implementation
for the FAQ system. All Databricks-specific code is isolated in this directory,
making it easy to delete when no longer needed.

Components:
    - DatabricksBackend: Complete IBackend implementation for Spark/Delta
    - SparkConnectionManager: Spark session management
    - Utilities: Delta table operations, Unity Catalog helpers

Directory Structure:
    backend.py      - DatabricksBackend (IBackend implementation)
    connection.py   - Spark session management
    utilities.py    - Databricks-specific utilities

Migration Note:
    When migrating away from Databricks, this entire directory can be deleted:
        rm -rf database/backends/databricks/

Usage Examples:

    Backend API (IBackend):
        >>> from database.backends.databricks import DatabricksBackend
        >>> from database.config import DatabaseConfig
        >>>
        >>> config = DatabaseConfig(
        ...     backend="databricks",
        ...     catalog="prod_catalog",
        ...     schema="faq_schema"
        ... )
        >>> backend = DatabricksBackend(config)
        >>> with backend:
        ...     results = backend.execute_query("SELECT * FROM content_repo")

    Connection Management:
        >>> from database.backends.databricks import SparkConnectionManager
        >>>
        >>> manager = SparkConnectionManager()
        >>> spark = manager.get_session()
        >>> df = spark.sql("SELECT 1")

    Utilities:
        >>> from database.backends.databricks import optimize_delta_table
        >>>
        >>> optimize_delta_table("my_catalog.my_schema.content_chunks")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

# Graceful imports with error handling
_import_errors = []

# Import backend (core)
try:
    from database.backends.databricks.backend import DatabricksBackend
except ImportError as e:
    _import_errors.append(f"DatabricksBackend: {e}")
    DatabricksBackend = None

# Import connection management
try:
    from database.backends.databricks.connection import (
        SparkConnectionManager,
        get_spark_or_fail,
        validate_spark_session,
        get_spark_version,
    )
except ImportError as e:
    _import_errors.append(f"connection: {e}")
    SparkConnectionManager = None
    get_spark_or_fail = None
    validate_spark_session = None
    get_spark_version = None

# Note: SparkDetectionAdapter and SparkIngestionAdapter have been removed
# Use AuditRepository, ContentRepository, and FAQRepository instead

# Import utilities
try:
    from database.backends.databricks.utilities import (
        optimize_delta_table,
        vacuum_delta_table,
        get_table_metadata,
        list_tables_in_schema,
        table_exists,
        is_databricks_environment,
        get_current_catalog_schema,
        analyze_table_statistics,
        get_delta_log_info,
    )
except ImportError as e:
    _import_errors.append(f"utilities: {e}")
    optimize_delta_table = None
    vacuum_delta_table = None
    get_table_metadata = None
    list_tables_in_schema = None
    table_exists = None
    is_databricks_environment = None
    get_current_catalog_schema = None
    analyze_table_statistics = None
    get_delta_log_info = None


# Log import errors if any
if _import_errors:
    import warnings
    warnings.warn(
        f"Some Databricks backend components failed to import: {', '.join(_import_errors)}. "
        "This is expected if PySpark is not installed or not in Databricks environment."
    )


# Public API
__all__ = [
    # Core backend
    "DatabricksBackend",

    # Connection management
    "SparkConnectionManager",
    "get_spark_or_fail",
    "validate_spark_session",
    "get_spark_version",

    # Utilities
    "optimize_delta_table",
    "vacuum_delta_table",
    "get_table_metadata",
    "list_tables_in_schema",
    "table_exists",
    "is_databricks_environment",
    "get_current_catalog_schema",
    "analyze_table_statistics",
    "get_delta_log_info",
]


def get_backend_info() -> dict:
    """
    Get information about Databricks backend availability.

    Returns:
        Dict with availability status and version info

    Example:
        >>> info = get_backend_info()
        >>> if info['available']:
        ...     print(f"Databricks backend available (Spark {info['spark_version']})")
    """
    available = DatabricksBackend is not None and validate_spark_session is not None

    if available and validate_spark_session:
        spark_available = validate_spark_session()
        spark_ver = get_spark_version() if get_spark_version else None
    else:
        spark_available = False
        spark_ver = None

    return {
        'backend': 'databricks',
        'available': available,
        'spark_session_active': spark_available,
        'spark_version': spark_ver,
        'import_errors': _import_errors if _import_errors else None,
        'is_databricks_env': is_databricks_environment() if is_databricks_environment else False
    }
