"""
Databricks Ingestion Adapter - Spark/Databricks Implementation

This module provides Spark-specific database operations for data ingestion in
Databricks environments using Unity Catalog and Delta tables.

Key Features:
    - Implements IIngestionAdapter interface
    - Uses Spark SQL for all operations
    - Unity Catalog support (catalog.schema.table naming)
    - Delta table optimizations (ACID transactions)
    - Distributed operations (scales with cluster size)
    - Efficient bulk loading with DataFrame API

Design Principles:
    - Adapter Pattern: Wraps Spark-specific operations
    - Single Responsibility: Only database I/O
    - No Business Logic: Pure data access layer
    - Framework Agnostic: No ingestion logic mixed in
    - Separation of Concerns: Data access separate from business logic

Example:
    >>> from database.backends.databricks.ingestion import SparkIngestionAdapter
    >>> import pandas as pd
    >>>
    >>> # Create adapter (in Databricks notebook)
    >>> adapter = SparkIngestionAdapter(
    ...     catalog_name="my_catalog",
    ...     schema_name="my_schema"
    ... )
    >>>
    >>> # Ingest data
    >>> df = pd.DataFrame({'chunk_text': ['Hello'], 'checksum': ['abc123']})
    >>> result = adapter.ingest_dataframe(df, table_name="content_chunks")
    >>> print(f"Inserted {result['rows_inserted']} rows")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0 (Moved from database/adapters/spark_ingestion_adapter.py)
"""

from typing import Any, Dict, List, Optional
import pandas as pd

from core.interfaces.ingestion_adapter import IIngestionAdapter
from database.backends.databricks.connection import get_spark_or_fail
from utility.logging import get_logger


logger = get_logger(__name__)


class SparkIngestionAdapter(IIngestionAdapter):
    """
    Spark/Databricks implementation of the ingestion adapter interface.

    This adapter consolidates all Spark database operations for ingestion.
    It uses Unity Catalog's three-level namespace (catalog.schema.table) and
    Delta Lake for ACID transactions and optimized storage.

    The adapter assumes Delta tables exist with proper schema defined.

    Attributes:
        catalog_name: Unity Catalog name
        schema_name: Schema name within catalog
        spark: Active Spark session (lazy-loaded)

    Example:
        >>> adapter = SparkIngestionAdapter(
        ...     catalog_name="prod_catalog",
        ...     schema_name="faq_schema"
        ... )
        >>> result = adapter.ingest_dataframe(df, "content_chunks")
        >>> print(f"Success: {result['success']}")
    """

    def __init__(self, catalog_name: str, schema_name: str):
        """
        Initialize Spark ingestion adapter.

        Args:
            catalog_name: Unity Catalog name (e.g., "prod_catalog")
            schema_name: Schema name (e.g., "faq_schema")

        Raises:
            ValueError: If catalog_name or schema_name is missing
            RuntimeError: If no active Spark session found

        Example:
            >>> adapter = SparkIngestionAdapter(
            ...     catalog_name="my_catalog",
            ...     schema_name="my_schema"
            ... )
        """
        if not catalog_name:
            raise ValueError("catalog_name is required for Spark adapter")
        if not schema_name:
            raise ValueError("schema_name is required for Spark adapter")

        self.catalog_name = catalog_name
        self.schema_name = schema_name

        # Get Spark session (will raise if not available)
        self.spark = get_spark_or_fail("initializing SparkIngestionAdapter")

        logger.info(
            f"Initialized SparkIngestionAdapter with "
            f"catalog={catalog_name}, schema={schema_name}"
        )

    def _get_full_table_name(self, table_name: str) -> str:
        """
        Get fully qualified table name.

        Args:
            table_name: Simple table name (e.g., "content_chunks")

        Returns:
            str: Fully qualified name (e.g., "catalog.schema.content_chunks")

        Example:
            >>> adapter = SparkIngestionAdapter("cat", "sch")
            >>> adapter._get_full_table_name("content_chunks")
            'cat.sch.content_chunks'
        """
        return f"{self.catalog_name}.{self.schema_name}.{table_name}"

    def ingest_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        clear_existing: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Ingest a pandas DataFrame into a Spark table.

        Converts pandas DataFrame to Spark DataFrame and writes to Delta table.

        Args:
            df: pandas DataFrame containing data to insert
            table_name: Simple table name (will be qualified with catalog.schema)
            clear_existing: If True, delete all existing data first
            **kwargs: Additional arguments (e.g., mode='append')

        Returns:
            Dict with success, rows_inserted, and message

        Example:
            >>> df = pd.DataFrame({
            ...     'ud_source_file_id': [1, 1],
            ...     'chunk_text': ['Hello', 'World'],
            ...     'content_checksum': ['abc', 'def']
            ... })
            >>> result = adapter.ingest_dataframe(df, "content_chunks")
            >>> assert result['success'] == True
        """
        if df.empty:
            logger.warning(f"Attempted to ingest empty DataFrame into {table_name}")
            return {
                "success": True,
                "rows_inserted": 0,
                "message": "No data to ingest (DataFrame is empty)"
            }

        full_table_name = self._get_full_table_name(table_name)

        try:
            # Clear existing data if requested
            if clear_existing:
                logger.info(f"Clearing existing data from {full_table_name}")
                self.spark.sql(f"DELETE FROM {full_table_name}")

            # Get row count before insert
            rows_before = self._get_row_count(full_table_name)

            # Convert pandas DataFrame to Spark DataFrame
            spark_df = self.spark.createDataFrame(df)

            # Write to Delta table
            mode = kwargs.get('mode', 'append')
            spark_df.write.format("delta").mode(mode).saveAsTable(full_table_name)

            # Get row count after insert
            rows_after = self._get_row_count(full_table_name)
            rows_inserted = rows_after - rows_before

            logger.info(f"Successfully inserted {rows_inserted} rows into {full_table_name}")

            return {
                "success": True,
                "rows_inserted": rows_inserted,
                "message": f"Successfully inserted {rows_inserted} rows into {full_table_name}"
            }

        except Exception as e:
            logger.error(f"Error inserting into {full_table_name}: {str(e)}")

            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Database error: {str(e)}",
                "error": str(e)
            }

    def clear_table(
        self,
        table_name: str,
        condition: Optional[str] = None,
        params: Optional[tuple] = None
    ) -> Dict[str, Any]:
        """
        Delete rows from a table with optional WHERE condition.

        Args:
            table_name: Simple table name
            condition: Optional WHERE clause (Spark SQL syntax)
            params: Not used in Spark (included for interface compatibility)

        Returns:
            Dict with success, rows_deleted, and message

        Note:
            Spark SQL doesn't use ? placeholders. Ensure condition is properly
            escaped if it contains user input.

        Example:
            >>> # Clear entire table
            >>> result = adapter.clear_table("content_chunks")
            >>>
            >>> # Clear specific file's chunks
            >>> result = adapter.clear_table(
            ...     "content_chunks",
            ...     condition="ud_source_file_id = 42"
            ... )
        """
        full_table_name = self._get_full_table_name(table_name)

        try:
            rows_before = self._get_row_count(full_table_name)

            if condition:
                sql = f"DELETE FROM {full_table_name} WHERE {condition}"
                logger.info(f"Deleting from {full_table_name} with condition: {condition}")
            else:
                sql = f"DELETE FROM {full_table_name}"
                logger.info(f"Clearing all data from {full_table_name}")

            self.spark.sql(sql)

            rows_after = self._get_row_count(full_table_name)
            rows_deleted = rows_before - rows_after

            logger.info(f"Deleted {rows_deleted} rows from {full_table_name}")

            return {
                "success": True,
                "rows_deleted": rows_deleted,
                "message": f"Deleted {rows_deleted} rows from {full_table_name}"
            }

        except Exception as e:
            logger.error(f"Error clearing {full_table_name}: {str(e)}")

            return {
                "success": False,
                "rows_deleted": 0,
                "message": f"Error clearing table: {str(e)}",
                "error": str(e)
            }

    def get_table_stats(
        self,
        table_name: str,
        groupby_column: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get statistics about a table.

        Args:
            table_name: Simple table name
            groupby_column: Optional column to group by

        Returns:
            Dict with success, total_rows, and optionally distinct_values

        Example:
            >>> stats = adapter.get_table_stats("content_chunks")
            >>> print(f"Total: {stats['total_rows']}")
            >>>
            >>> stats = adapter.get_table_stats("content_chunks", groupby_column="ud_source_file_id")
            >>> for file_id, count in stats['distinct_values'].items():
            ...     print(f"File {file_id}: {count} chunks")
        """
        full_table_name = self._get_full_table_name(table_name)

        try:
            # Get total row count
            total_rows = self._get_row_count(full_table_name)

            result = {
                "success": True,
                "total_rows": total_rows,
                "message": f"Retrieved stats for {full_table_name}"
            }

            # Get grouped counts if requested
            if groupby_column:
                df = self.spark.sql(f"""
                    SELECT {groupby_column}, COUNT(*) as count
                    FROM {full_table_name}
                    WHERE {groupby_column} IS NOT NULL
                    GROUP BY {groupby_column}
                    ORDER BY {groupby_column}
                """)

                rows = df.collect()
                grouped_counts = {row[groupby_column]: row['count'] for row in rows}
                result["distinct_values"] = grouped_counts
                result["num_groups"] = len(grouped_counts)

            logger.debug(f"Stats for {full_table_name}: total_rows={total_rows}")
            return result

        except Exception as e:
            logger.error(f"Error getting stats for {full_table_name}: {str(e)}")

            return {
                "success": False,
                "total_rows": 0,
                "message": f"Error retrieving stats: {str(e)}",
                "error": str(e)
            }

    def validate_foreign_key(
        self,
        fk_table: str,
        fk_column: str,
        fk_value: Any
    ) -> bool:
        """
        Check if a foreign key value exists in the referenced table.

        Args:
            fk_table: Simple table name (e.g., "content_repo")
            fk_column: Foreign key column name
            fk_value: Value to check

        Returns:
            bool: True if value exists, False otherwise

        Example:
            >>> if adapter.validate_foreign_key("content_repo", "ud_source_file_id", 42):
            ...     print("File ID 42 exists")
        """
        full_table_name = self._get_full_table_name(fk_table)

        try:
            # Use Spark SQL to check existence
            df = self.spark.sql(f"""
                SELECT COUNT(*) as count
                FROM {full_table_name}
                WHERE {fk_column} = {fk_value}
                LIMIT 1
            """)

            count = df.collect()[0]['count']
            exists = count > 0

            logger.debug(f"FK validation: {full_table_name}.{fk_column}={fk_value} exists={exists}")
            return exists

        except Exception as e:
            logger.error(f"Error validating FK {full_table_name}.{fk_column}={fk_value}: {str(e)}")
            return False

    def table_exists(self, table_name: str) -> bool:
        """
        Check if a table exists in the catalog.

        Args:
            table_name: Simple table name

        Returns:
            bool: True if table exists, False otherwise

        Example:
            >>> if not adapter.table_exists("content_chunks"):
            ...     print("ERROR: Table not found!")
        """
        full_table_name = self._get_full_table_name(table_name)

        try:
            # Try to query the table
            df = self.spark.sql(f"SELECT 1 FROM {full_table_name} LIMIT 0")
            exists = True

            logger.debug(f"Table {full_table_name} exists: {exists}")
            return exists

        except Exception as e:
            # Table doesn't exist or other error
            logger.debug(f"Table {full_table_name} does not exist: {str(e)}")
            return False

    def get_distinct_values(
        self,
        table_name: str,
        column: str,
        limit: Optional[int] = None
    ) -> List[Any]:
        """
        Get distinct values from a column.

        Args:
            table_name: Simple table name
            column: Column name
            limit: Optional limit on results

        Returns:
            List of distinct values (sorted)

        Example:
            >>> file_ids = adapter.get_distinct_values("content_chunks", "ud_source_file_id")
            >>> print(f"Found {len(file_ids)} distinct files")
        """
        full_table_name = self._get_full_table_name(table_name)

        try:
            sql = f"""
                SELECT DISTINCT {column}
                FROM {full_table_name}
                WHERE {column} IS NOT NULL
                ORDER BY {column}
            """

            if limit:
                sql += f" LIMIT {limit}"

            df = self.spark.sql(sql)
            values = [row[column] for row in df.collect()]

            logger.debug(f"Found {len(values)} distinct values in {full_table_name}.{column}")
            return values

        except Exception as e:
            logger.error(f"Error getting distinct values from {full_table_name}.{column}: {str(e)}")
            return []

    def close(self) -> None:
        """
        Close resources (no-op for Spark adapter).

        Spark session is managed externally in Databricks, so we don't close it.

        Example:
            >>> adapter.close()  # Safe to call, but doesn't do anything
        """
        logger.info(
            f"Close called on SparkIngestionAdapter "
            f"({self.catalog_name}.{self.schema_name}) - no action needed"
        )
        # Spark session is managed by Databricks, don't close it

    def _get_row_count(self, full_table_name: str) -> int:
        """
        Helper to get row count from a table.

        Args:
            full_table_name: Fully qualified table name

        Returns:
            int: Number of rows in table
        """
        df = self.spark.sql(f"SELECT COUNT(*) as count FROM {full_table_name}")
        return df.collect()[0]['count']

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

    def __repr__(self) -> str:
        """String representation."""
        return f"SparkIngestionAdapter(catalog='{self.catalog_name}', schema='{self.schema_name}')"


__all__ = ["SparkIngestionAdapter"]
