"""
Backend Interface - Abstract Base for All Database Backends

This module defines the IBackend interface that all database backends must implement.
Backends are the lowest level of abstraction - they handle actual database operations.

Architecture:
    Application Code
         ↓
    Repository Layer (business logic)
         ↓
    IBackend Interface (this file)
         ↓
    Concrete Backends (SQLite, Databricks, PostgreSQL)
         ↓
    Actual Database

Design Principles:
- Single Responsibility: Only database I/O operations
- Open/Closed: Easy to add new backends without changing interface
- Liskov Substitution: All backends are interchangeable
- Interface Segregation: Minimal required methods
- Dependency Inversion: High-level code depends on this abstraction

Example:
    >>> from database.backends.sqlite.backend import SQLiteBackend
    >>> from database.backends.databricks.backend import DatabricksBackend
    >>>
    >>> # Both implement IBackend - interchangeable
    >>> sqlite_backend = SQLiteBackend(db_path="faq.db")
    >>> databricks_backend = DatabricksBackend(catalog="prod", schema="faq")
    >>>
    >>> # Same interface for both
    >>> results = sqlite_backend.execute_query("SELECT * FROM content_repo")
    >>> results = databricks_backend.execute_query("SELECT * FROM content_repo")

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import pandas as pd


class BackendType(Enum):
    """Enumeration of supported backend types."""
    SQLITE = "sqlite"
    DATABRICKS = "databricks"
    POSTGRESQL = "postgresql"  # Future support
    MYSQL = "mysql"  # Future support


class IBackend(ABC):
    """
    Abstract interface for database backends.

    All database backends (SQLite, Databricks, PostgreSQL) must implement this interface.
    This ensures that repositories can work with any backend interchangeably.

    The interface is intentionally minimal - only core CRUD operations are required.
    Backends can provide additional capabilities, but repositories should only depend
    on this interface.

    Attributes:
        backend_type: Type of backend (SQLITE, DATABRICKS, etc.)

    Thread Safety:
        Implementations must be thread-safe for read operations.
        Write operations should use appropriate locking/transactions.
    """

    def __init__(self):
        """Initialize backend. Subclasses should call super().__init__()."""
        self._backend_type: Optional[BackendType] = None
        self._is_connected: bool = False

    @property
    @abstractmethod
    def backend_type(self) -> BackendType:
        """
        Get the type of this backend.

        Returns:
            BackendType enum value

        Example:
            >>> backend = SQLiteBackend("faq.db")
            >>> backend.backend_type
            <BackendType.SQLITE: 'sqlite'>
        """
        pass

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """
        Check if backend is connected to database.

        Returns:
            True if connected, False otherwise

        Example:
            >>> backend = SQLiteBackend("faq.db")
            >>> backend.is_connected
            False
            >>> backend.connect()
            >>> backend.is_connected
            True
        """
        pass

    # =========================================================================
    # Connection Management
    # =========================================================================

    @abstractmethod
    def connect(self) -> None:
        """
        Establish connection to database.

        Should be idempotent - calling multiple times should not cause errors.

        Raises:
            ConnectionError: If connection fails
            PermissionError: If authentication fails

        Example:
            >>> backend = SQLiteBackend("faq.db")
            >>> backend.connect()
            >>> backend.is_connected
            True
        """
        pass

    @abstractmethod
    def close(self) -> None:
        """
        Close database connection and clean up resources.

        Should be idempotent - calling multiple times should not cause errors.
        Should be called in __exit__ for context manager support.

        Example:
            >>> backend = SQLiteBackend("faq.db")
            >>> backend.connect()
            >>> backend.close()
            >>> backend.is_connected
            False
        """
        pass

    # =========================================================================
    # Query Execution (Read Operations)
    # =========================================================================

    @abstractmethod
    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute a SELECT query and return results as list of dictionaries.

        Args:
            query: SQL SELECT statement
            params: Optional tuple of parameters for parameterized queries
            timeout: Optional timeout in seconds

        Returns:
            List of dictionaries, where each dict represents a row
            Empty list if no results

        Raises:
            ValueError: If query is not a SELECT statement
            TimeoutError: If query exceeds timeout
            DatabaseError: If query execution fails

        Security:
            ALWAYS use parameterized queries to prevent SQL injection!

            GOOD:
                execute_query("SELECT * FROM users WHERE id = ?", (user_id,))

            BAD:
                execute_query(f"SELECT * FROM users WHERE id = {user_id}")  # SQL INJECTION!

        Example:
            >>> results = backend.execute_query(
            ...     "SELECT * FROM content_repo WHERE file_status = ?",
            ...     ("Active",)
            ... )
            >>> results
            [{'ud_source_file_id': 1, 'raw_file_nme': 'policy.pdf', 'file_status': 'Active'}]
        """
        pass

    @abstractmethod
    def execute_query_single(
        self,
        query: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Execute a SELECT query and return single result (or None).

        Convenience method for queries expected to return 0 or 1 row.

        Args:
            query: SQL SELECT statement
            params: Optional tuple of parameters
            timeout: Optional timeout in seconds

        Returns:
            Dictionary representing the row, or None if no results

        Raises:
            MultipleResultsError: If query returns more than one row
            DatabaseError: If query execution fails

        Example:
            >>> result = backend.execute_query_single(
            ...     "SELECT * FROM content_repo WHERE ud_source_file_id = ?",
            ...     (1,)
            ... )
            >>> result
            {'ud_source_file_id': 1, 'raw_file_nme': 'policy.pdf'}
        """
        pass

    # =========================================================================
    # Command Execution (Write Operations)
    # =========================================================================

    @abstractmethod
    def execute_command(
        self,
        command: str,
        params: Optional[Tuple] = None,
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute an INSERT, UPDATE, or DELETE command.

        Args:
            command: SQL INSERT/UPDATE/DELETE statement
            params: Optional tuple of parameters
            timeout: Optional timeout in seconds

        Returns:
            Number of rows affected

        Raises:
            ValueError: If command is a SELECT statement
            DatabaseError: If command execution fails

        Example:
            >>> rows_affected = backend.execute_command(
            ...     "UPDATE content_repo SET file_status = ? WHERE ud_source_file_id = ?",
            ...     ("Archived", 1)
            ... )
            >>> rows_affected
            1
        """
        pass

    @abstractmethod
    def execute_many(
        self,
        command: str,
        params_list: List[Tuple],
        timeout: Optional[int] = None
    ) -> int:
        """
        Execute a command multiple times with different parameters (batch operation).

        More efficient than calling execute_command in a loop.

        Args:
            command: SQL INSERT/UPDATE/DELETE statement
            params_list: List of parameter tuples
            timeout: Optional timeout in seconds

        Returns:
            Total number of rows affected

        Example:
            >>> rows = [
            ...     ("file1.pdf", "Active"),
            ...     ("file2.pdf", "Active"),
            ...     ("file3.pdf", "Inactive")
            ... ]
            >>> backend.execute_many(
            ...     "INSERT INTO content_repo (raw_file_nme, file_status) VALUES (?, ?)",
            ...     rows
            ... )
            3
        """
        pass

    # =========================================================================
    # Bulk Operations (DataFrame)
    # =========================================================================

    @abstractmethod
    def ingest_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "append",
        index: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Bulk insert a pandas DataFrame into a table.

        This is the primary method for efficient batch inserts.

        Args:
            df: pandas DataFrame to ingest
            table_name: Name of target table (simple name, backend handles qualification)
            if_exists: What to do if table exists:
                - 'append': Insert data (default)
                - 'replace': Drop table and recreate
                - 'fail': Raise error if table exists
            index: Whether to write DataFrame index as a column
            **kwargs: Backend-specific options

        Returns:
            Dictionary with:
                - success (bool): True if ingestion succeeded
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - error (str, optional): Error details if failed

        Raises:
            ValueError: If DataFrame is empty or invalid
            DatabaseError: If ingestion fails

        Example:
            >>> df = pd.DataFrame({
            ...     'raw_file_nme': ['file1.pdf', 'file2.pdf'],
            ...     'file_status': ['Active', 'Active']
            ... })
            >>> result = backend.ingest_dataframe(df, "content_repo")
            >>> result
            {'success': True, 'rows_inserted': 2, 'message': 'Inserted 2 rows'}
        """
        pass

    @abstractmethod
    def read_table(
        self,
        table_name: str,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> pd.DataFrame:
        """
        Read entire table (or filtered subset) into a DataFrame.

        Args:
            table_name: Name of table to read
            columns: Optional list of columns to select (None = all columns)
            where: Optional WHERE clause (without the WHERE keyword)
            params: Optional parameters for WHERE clause
            limit: Optional maximum number of rows

        Returns:
            pandas DataFrame with table data

        Example:
            >>> df = backend.read_table(
            ...     "content_repo",
            ...     columns=["ud_source_file_id", "raw_file_nme"],
            ...     where="file_status = ?",
            ...     params=("Active",),
            ...     limit=100
            ... )
        """
        pass

    # =========================================================================
    # Transaction Management
    # =========================================================================

    @abstractmethod
    def begin_transaction(self) -> None:
        """
        Start a new transaction.

        All subsequent commands will be part of this transaction until
        commit() or rollback() is called.

        Raises:
            DatabaseError: If transaction cannot be started

        Example:
            >>> backend.begin_transaction()
            >>> backend.execute_command("INSERT INTO content_repo ...")
            >>> backend.execute_command("INSERT INTO content_chunks ...")
            >>> backend.commit()  # Both inserts succeed or both fail
        """
        pass

    @abstractmethod
    def commit(self) -> None:
        """
        Commit the current transaction.

        Makes all changes since begin_transaction() permanent.

        Raises:
            DatabaseError: If no transaction is active

        Example:
            >>> backend.begin_transaction()
            >>> backend.execute_command("DELETE FROM content_repo WHERE ...")
            >>> backend.commit()  # Changes are now permanent
        """
        pass

    @abstractmethod
    def rollback(self) -> None:
        """
        Roll back the current transaction.

        Undoes all changes since begin_transaction().

        Raises:
            DatabaseError: If no transaction is active

        Example:
            >>> backend.begin_transaction()
            >>> try:
            ...     backend.execute_command("INSERT INTO ...")
            ...     backend.execute_command("UPDATE ...")
            ...     backend.commit()
            >>> except Exception:
            ...     backend.rollback()  # Undo all changes
        """
        pass

    # =========================================================================
    # Schema Operations
    # =========================================================================

    @abstractmethod
    def table_exists(self, table_name: str) -> bool:
        """
        Check if a table exists in the database.

        Args:
            table_name: Name of table to check

        Returns:
            True if table exists, False otherwise

        Example:
            >>> backend.table_exists("content_repo")
            True
            >>> backend.table_exists("nonexistent_table")
            False
        """
        pass

    @abstractmethod
    def get_table_schema(self, table_name: str) -> List[Dict[str, str]]:
        """
        Get schema information for a table.

        Args:
            table_name: Name of table

        Returns:
            List of column definitions, each containing:
                - name: Column name
                - type: Data type
                - nullable: Whether column allows NULL
                - default: Default value (if any)
                - primary_key: Whether column is part of primary key

        Raises:
            TableNotFoundError: If table doesn't exist

        Example:
            >>> schema = backend.get_table_schema("content_repo")
            >>> schema[0]
            {
                'name': 'ud_source_file_id',
                'type': 'INTEGER',
                'nullable': False,
                'default': None,
                'primary_key': True
            }
        """
        pass

    @abstractmethod
    def list_tables(self) -> List[str]:
        """
        List all tables in the database.

        Returns:
            List of table names

        Example:
            >>> backend.list_tables()
            ['content_repo', 'content_chunks', 'faq_questions', ...]
        """
        pass

    # =========================================================================
    # Utility Methods
    # =========================================================================

    @abstractmethod
    def get_row_count(self, table_name: str, where: Optional[str] = None, params: Optional[Tuple] = None) -> int:
        """
        Get count of rows in a table.

        Args:
            table_name: Name of table
            where: Optional WHERE clause
            params: Optional parameters for WHERE clause

        Returns:
            Number of rows

        Example:
            >>> backend.get_row_count("content_repo")
            150
            >>> backend.get_row_count("content_repo", "file_status = ?", ("Active",))
            120
        """
        pass

    @abstractmethod
    def get_distinct_values(
        self,
        table_name: str,
        column: str,
        where: Optional[str] = None,
        params: Optional[Tuple] = None,
        limit: Optional[int] = None
    ) -> List[Any]:
        """
        Get distinct values from a column.

        Args:
            table_name: Name of table
            column: Name of column
            where: Optional WHERE clause
            params: Optional parameters for WHERE clause
            limit: Optional maximum number of values

        Returns:
            List of distinct values (sorted)

        Example:
            >>> backend.get_distinct_values("content_repo", "file_status")
            ['Active', 'Archived', 'Inactive']
        """
        pass

    # =========================================================================
    # Context Manager Support
    # =========================================================================

    def __enter__(self):
        """Context manager entry - connect to database."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close connection."""
        self.close()
        return False  # Don't suppress exceptions

    # =========================================================================
    # String Representation
    # =========================================================================

    def __repr__(self) -> str:
        """String representation of backend."""
        return f"{self.__class__.__name__}(type={self.backend_type.value}, connected={self.is_connected})"


# =============================================================================
# Custom Exceptions
# =============================================================================

class BackendError(Exception):
    """Base exception for all backend errors."""
    pass


class ConnectionError(BackendError):
    """Raised when connection to database fails."""
    pass


class QueryError(BackendError):
    """Raised when query execution fails."""
    pass


class CommandError(BackendError):
    """Raised when command execution fails."""
    pass


class TransactionError(BackendError):
    """Raised when transaction operation fails."""
    pass


class TableNotFoundError(BackendError):
    """Raised when referenced table doesn't exist."""
    pass


class MultipleResultsError(BackendError):
    """Raised when query expected to return single result returns multiple."""
    pass


class ConfigurationError(BackendError):
    """Raised when backend configuration is invalid."""
    pass


__all__ = [
    # Main interface
    "IBackend",
    "BackendType",
    # Exceptions
    "BackendError",
    "ConnectionError",
    "QueryError",
    "CommandError",
    "TransactionError",
    "TableNotFoundError",
    "MultipleResultsError",
    "ConfigurationError",
]
