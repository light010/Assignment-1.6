"""
Backend Factory - Single Point for Backend Creation

The factory provides a centralized way to create database backends based on
configuration. It implements the Factory Pattern with singleton support for
connection pooling.

Design Principles:
- Single Responsibility: Only creates backends
- Open/Closed: Easy to add new backends without changing factory
- Dependency Inversion: Returns IBackend interface, not concrete class
- Singleton Pattern: Reuse connections within a session

Example:
    >>> from database.backends.factory import BackendFactory
    >>> from database.config import DatabaseConfig
    >>>
    >>> # Auto-detect from environment
    >>> backend = BackendFactory.create_backend()
    >>>
    >>> # With explicit config
    >>> config = DatabaseConfig(backend="sqlite", db_path="faq.db")
    >>> backend = BackendFactory.create_backend(config)
    >>>
    >>> # Singleton pattern - same instance
    >>> backend2 = BackendFactory.create_backend()
    >>> backend is backend2
    True

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Optional
import threading

from database.config import DatabaseConfig, BackendType, load_config
from database.backends.base import IBackend, ConfigurationError
from utility.logging import get_logger

logger = get_logger(__name__)


class BackendFactory:
    """
    Factory for creating database backends.

    Implements singleton pattern to reuse backend instances within a session.
    Thread-safe for concurrent access.

    Class Attributes:
        _instance: Singleton backend instance (shared across calls)
        _lock: Thread lock for singleton creation
        _instance_lock: Thread lock for instance operations

    Example:
        >>> # First call creates backend
        >>> backend1 = BackendFactory.create_backend()
        >>> backend1.backend_type
        <BackendType.SQLITE: 'sqlite'>

        >>> # Second call returns same instance
        >>> backend2 = BackendFactory.create_backend()
        >>> backend1 is backend2
        True

        >>> # Reset singleton (testing or re-initialization)
        >>> BackendFactory.reset()
        >>> backend3 = BackendFactory.create_backend()
        >>> backend1 is backend3
        False
    """

    # Singleton instance and lock
    _instance: Optional[IBackend] = None
    _lock: threading.Lock = threading.Lock()
    _instance_lock: threading.Lock = threading.Lock()

    @classmethod
    def create_backend(
        cls,
        config: Optional[DatabaseConfig] = None,
        force_new: bool = False
    ) -> IBackend:
        """
        Create database backend based on configuration.

        Uses singleton pattern by default - returns cached instance if available.
        Set force_new=True to create a new instance.

        Args:
            config: Database configuration (None = auto-detect from environment)
            force_new: If True, create new instance even if singleton exists

        Returns:
            IBackend implementation (SQLiteBackend, DatabricksBackend, etc.)

        Raises:
            ConfigurationError: If configuration is invalid
            ImportError: If required backend dependencies are missing

        Example:
            >>> # Auto-detect from environment
            >>> backend = BackendFactory.create_backend()

            >>> # Explicit configuration
            >>> config = DatabaseConfig(backend="sqlite", db_path="test.db")
            >>> backend = BackendFactory.create_backend(config)

            >>> # Force new instance (no singleton)
            >>> backend = BackendFactory.create_backend(force_new=True)
        """
        # If not forcing new and singleton exists, return it
        if not force_new and cls._instance is not None:
            logger.debug("Returning existing backend singleton")
            return cls._instance

        # Thread-safe singleton creation
        with cls._lock:
            # Double-check after acquiring lock
            if not force_new and cls._instance is not None:
                return cls._instance

            # Load configuration
            if config is None:
                logger.debug("Loading database configuration from environment")
                config = load_config()
            elif not isinstance(config, DatabaseConfig):
                logger.debug(f"Loading database configuration from {type(config).__name__}")
                config = load_config(config)

            logger.info(f"Creating backend: {config.backend} ({config.get_connection_string()})")

            # Create backend based on type
            backend = cls._create_backend_instance(config)

            # Store as singleton (unless force_new)
            if not force_new:
                cls._instance = backend
                logger.debug("Backend stored as singleton")

            return backend

    @classmethod
    def _create_backend_instance(cls, config: DatabaseConfig) -> IBackend:
        """
        Internal method to create backend instance.

        Args:
            config: Validated database configuration

        Returns:
            IBackend implementation

        Raises:
            ConfigurationError: If backend type is unsupported
            ImportError: If backend dependencies are missing
        """
        backend_type = config.backend

        # SQLite Backend
        if backend_type == BackendType.SQLITE.value:
            try:
                from database.backends.sqlite.backend import SQLiteBackend
                return SQLiteBackend(config)
            except ImportError as e:
                raise ImportError(
                    f"SQLite backend dependencies not available: {e}\n"
                    "Install with: pip install pandas"
                ) from e

        # Databricks Backend
        elif backend_type == BackendType.DATABRICKS.value:
            try:
                from database.backends.databricks.backend import DatabricksBackend
                return DatabricksBackend(config)
            except ImportError as e:
                raise ImportError(
                    f"Databricks backend dependencies not available: {e}\n"
                    "Install with: pip install pyspark databricks-sql-connector"
                ) from e

        # PostgreSQL Backend (Future)
        elif backend_type == BackendType.POSTGRESQL.value:
            raise ConfigurationError(
                "PostgreSQL backend not yet implemented. "
                "Supported backends: sqlite, databricks"
            )

        # MySQL Backend (Future)
        elif backend_type == BackendType.MYSQL.value:
            raise ConfigurationError(
                "MySQL backend not yet implemented. "
                "Supported backends: sqlite, databricks"
            )

        # Unknown backend
        else:
            supported = ", ".join([b.value for b in BackendType])
            raise ConfigurationError(
                f"Unknown backend type: {backend_type}\n"
                f"Supported backends: {supported}"
            )

    @classmethod
    def create_sqlite_backend(
        cls,
        db_path: str = "databases/granular_impact.db",
        **kwargs
    ) -> IBackend:
        """
        Convenience method to create SQLite backend directly.

        Args:
            db_path: Path to SQLite database file
            **kwargs: Additional configuration options

        Returns:
            SQLiteBackend instance

        Example:
            >>> backend = BackendFactory.create_sqlite_backend("test.db")
            >>> backend.backend_type
            <BackendType.SQLITE: 'sqlite'>
        """
        config = DatabaseConfig(
            backend=BackendType.SQLITE.value,
            db_path=db_path,
            **kwargs
        )
        return cls.create_backend(config, force_new=True)

    @classmethod
    def create_databricks_backend(
        cls,
        catalog: str,
        schema: str,
        **kwargs
    ) -> IBackend:
        """
        Convenience method to create Databricks backend directly.

        Args:
            catalog: Unity Catalog name
            schema: Schema name
            **kwargs: Additional configuration options

        Returns:
            DatabricksBackend instance

        Example:
            >>> backend = BackendFactory.create_databricks_backend(
            ...     catalog="prod_catalog",
            ...     schema="faq_schema"
            ... )
        """
        config = DatabaseConfig(
            backend=BackendType.DATABRICKS.value,
            catalog=catalog,
            schema=schema,
            **kwargs
        )
        return cls.create_backend(config, force_new=True)

    @classmethod
    def create_in_memory_backend(cls) -> IBackend:
        """
        Convenience method to create in-memory SQLite backend (for testing).

        Returns:
            SQLiteBackend with in-memory database

        Example:
            >>> backend = BackendFactory.create_in_memory_backend()
            >>> backend.backend_type
            <BackendType.SQLITE: 'sqlite'>
        """
        config = DatabaseConfig(
            backend=BackendType.SQLITE.value,
            db_path=":memory:"
        )
        return cls.create_backend(config, force_new=True)

    @classmethod
    def reset(cls) -> None:
        """
        Reset singleton instance.

        Closes the existing backend connection and clears the singleton.
        Useful for testing or when you need to change configuration.

        Thread-safe operation.

        Example:
            >>> backend1 = BackendFactory.create_backend()
            >>> BackendFactory.reset()
            >>> backend2 = BackendFactory.create_backend()
            >>> backend1 is backend2
            False
        """
        with cls._lock:
            if cls._instance is not None:
                logger.debug("Resetting backend singleton")
                try:
                    cls._instance.close()
                except Exception as e:
                    logger.warning(f"Error closing backend during reset: {e}")
                finally:
                    cls._instance = None

    @classmethod
    def get_instance(cls) -> Optional[IBackend]:
        """
        Get current singleton instance without creating one.

        Returns:
            Current backend instance or None if not created yet

        Example:
            >>> BackendFactory.get_instance()
            None
            >>> backend = BackendFactory.create_backend()
            >>> BackendFactory.get_instance() is backend
            True
        """
        return cls._instance

    @classmethod
    def is_initialized(cls) -> bool:
        """
        Check if singleton backend is initialized.

        Returns:
            True if backend singleton exists

        Example:
            >>> BackendFactory.is_initialized()
            False
            >>> backend = BackendFactory.create_backend()
            >>> BackendFactory.is_initialized()
            True
        """
        return cls._instance is not None


# =============================================================================
# Convenience Functions
# =============================================================================

def get_backend(config: Optional[DatabaseConfig] = None) -> IBackend:
    """
    Get or create database backend (singleton pattern).

    This is the primary entry point for most applications.

    Args:
        config: Optional database configuration (None = auto-detect)

    Returns:
        IBackend instance

    Example:
        >>> from database.backends.factory import get_backend
        >>>
        >>> # Auto-detect from environment
        >>> backend = get_backend()
        >>>
        >>> # Explicit config
        >>> from database.config import DatabaseConfig
        >>> config = DatabaseConfig(backend="sqlite", db_path="test.db")
        >>> backend = get_backend(config)
    """
    return BackendFactory.create_backend(config)


def reset_backend() -> None:
    """
    Reset backend singleton.

    Closes existing backend and clears singleton. Next call to get_backend()
    will create a new instance.

    Example:
        >>> from database.backends.factory import get_backend, reset_backend
        >>>
        >>> backend1 = get_backend()
        >>> reset_backend()
        >>> backend2 = get_backend()
        >>> backend1 is backend2
        False
    """
    BackendFactory.reset()


__all__ = [
    "BackendFactory",
    "get_backend",
    "reset_backend",
]
