# Migration Guide: Legacy Adapters to Backends

**Date:** 2025-11-02
**Phase:** 2D - Update Legacy Adapters
**Status:** In Progress

---

## Overview

This guide helps you migrate from the deprecated legacy adapter system to the new backend architecture.

### What Changed?

- **Old System:** `database.adapters_old` - Legacy adapter pattern with `DatabaseAdapter`, `SQLiteAdapter`, `DatabricksAdapter`
- **New System:** `database.backends` - Modern backend pattern with `IBackend`, `SQLiteBackend`, `DatabricksBackend`

### Why Change?

The new backend system provides:
1. **Better Separation of Concerns** - Business logic is separate from persistence
2. **Cleaner Interfaces** - IBackend interface is more consistent and easier to use
3. **Improved Configuration** - Centralized configuration via `DatabaseConfig`
4. **Factory Pattern** - Single point for backend creation
5. **Better Error Handling** - Custom exceptions for different error types
6. **Easier Testing** - Mock backends are simpler to create

---

## Quick Migration

### For Schema Manager Users

**Before (Old):**
```python
from database.adapters_old import SQLiteAdapter, create_adapter
from database.dialect import DatabaseDialect
from database.schema_manager import SchemaManager

# Create adapter
adapter = SQLiteAdapter(database_path="faq.db")
# Or use factory
adapter = create_adapter(DatabaseDialect.SQLITE, database_path="faq.db")

# Create schema manager
manager = SchemaManager(adapter=adapter)
manager.create_schema()
```

**After (New):**
```python
from database.backends import get_backend, BackendFactory
from database.config import DatabaseConfig
from database.schema_manager import SchemaManager

# Option 1: Auto-detect from environment
backend = get_backend()

# Option 2: Explicit configuration
config = DatabaseConfig(backend="sqlite", db_path="faq.db")
backend = BackendFactory.create_backend(config)

# Create schema manager (both old and new parameters work!)
manager = SchemaManager(backend=backend)  # New way (preferred)
# OR for backward compatibility:
# manager = SchemaManager(adapter=old_adapter)  # Still works but deprecated

manager.create_schema()
```

### For Direct Database Access

**Before (Old):**
```python
from database.adapters_old import SQLiteAdapter

adapter = SQLiteAdapter(database_path="faq.db")
conn = adapter.connect()
cursor = adapter.execute("SELECT * FROM content_repo WHERE file_status = ?", ("Active",))
rows = adapter.fetchall("SELECT COUNT(*) FROM content_repo")
adapter.commit()
adapter.close()
```

**After (New):**
```python
from database.backends import BackendFactory
from database.config import DatabaseConfig

config = DatabaseConfig(backend="sqlite", db_path="faq.db")
backend = BackendFactory.create_backend(config)

# Query (SELECT)
results = backend.execute_query(
    "SELECT * FROM content_repo WHERE file_status = ?",
    ("Active",)
)
# Returns: List[Dict[str, Any]]

# Command (INSERT/UPDATE/DELETE)
rows_affected = backend.execute_command(
    "UPDATE content_repo SET file_status = ? WHERE ud_source_file_id = ?",
    ("Archived", 1)
)
# Returns: int (number of rows affected)

# Bulk insert with DataFrame
import pandas as pd
df = pd.DataFrame({
    'raw_file_nme': ['file1.pdf', 'file2.pdf'],
    'file_status': ['Active', 'Active']
})
result = backend.ingest_dataframe(df, "content_repo")
# Returns: Dict with success status

backend.close()
```

---

## Module-by-Module Migration

### database.adapters_old

| Old Import | New Import |
|------------|------------|
| `from database.adapters_old import DatabaseAdapter` | `from database.backends.base import IBackend` |
| `from database.adapters_old import SQLiteAdapter` | `from database.backends.sqlite import SQLiteBackend` |
| `from database.adapters_old import DatabricksAdapter` | `from database.backends.databricks import DatabricksBackend` |
| `from database.adapters_old import create_adapter` | `from database.backends import BackendFactory` |

### database.utils

| Old Import | New Import |
|------------|------------|
| `from database.utils import SQLiteConnectionManager` | `from database.backends.sqlite.connection import SQLiteConnectionManager` |
| `from database.utils import get_spark_or_fail` | `from database.backends.databricks.connection import get_spark_or_fail` |

### utility.database

| Old Import | New Import |
|------------|------------|
| `from utility.database import close_all_sqlite_connections` | `from database.backends.sqlite.utilities import close_all_sqlite_connections` |
| `from utility.database import drop_sqlite_database` | `from database.backends.sqlite.utilities import drop_sqlite_database` |
| `from utility.database import get_sqlite_connection` | `from database.backends.sqlite.utilities import get_sqlite_connection` |

---

## Configuration System

The new backend system uses a centralized configuration approach.

### Configuration via Environment Variables

**Set environment variables:**
```bash
# For SQLite
export DATABASE_BACKEND=sqlite
export DATABASE_PATH=databases/faq.db

# For Databricks
export DATABASE_BACKEND=databricks
export DATABASE_CATALOG=prod_catalog
export DATABASE_SCHEMA=faq_schema
```

**Use in code:**
```python
from database.backends import get_backend

# Auto-detects from environment variables
backend = get_backend()
```

### Configuration via DatabaseConfig

```python
from database.config import DatabaseConfig
from database.backends import BackendFactory

# SQLite configuration
config = DatabaseConfig(
    backend="sqlite",
    db_path="databases/faq.db"
)

# Databricks configuration
config = DatabaseConfig(
    backend="databricks",
    catalog="prod_catalog",
    schema="faq_schema"
)

backend = BackendFactory.create_backend(config)
```

---

## API Differences

### Methods Renamed/Changed

| Old Method (DatabaseAdapter) | New Method (IBackend) | Notes |
|------------------------------|----------------------|-------|
| `adapter.execute(sql)` | `backend.execute_command(sql)` or `backend.execute_query(sql)` | Split into query vs command |
| `adapter.fetchall(sql)` | `backend.execute_query(sql)` | Returns List[Dict] instead of List[Tuple] |
| `adapter.commit()` | Automatic | Backends auto-commit commands |
| `adapter.connect()` | Automatic | Connection managed internally |
| `adapter.close()` | `backend.close()` | Same |

### Return Types

**Old System:**
```python
# fetchall returns List[Tuple]
rows = adapter.fetchall("SELECT id, name FROM content_repo")
for row in rows:
    id = row[0]  # Access by index
    name = row[1]
```

**New System:**
```python
# execute_query returns List[Dict]
rows = backend.execute_query("SELECT ud_source_file_id, raw_file_nme FROM content_repo")
for row in rows:
    id = row['ud_source_file_id']  # Access by column name
    name = row['raw_file_nme']
```

---

## Backward Compatibility

### Still Works (Deprecated)

The old system still works but will show deprecation warnings:

```python
# This will work but show a warning
from database.adapters_old import SQLiteAdapter
adapter = SQLiteAdapter(":memory:")
# DeprecationWarning: database.adapters_old is deprecated...

# Schema manager accepts both old and new
from database.schema_manager import SchemaManager
manager = SchemaManager(adapter=old_adapter)  # Deprecated but works
manager = SchemaManager(backend=new_backend)  # Preferred
```

### Breaking Changes

None yet! All deprecated APIs still work with warnings.

### Timeline

- **Now (Phase 2D):** Deprecation warnings added, both systems work
- **Phase 5:** Business logic migrated to use backends
- **Phase 7:** Legacy adapter modules removed

---

## Common Patterns

### Pattern 1: Schema Setup

**Old:**
```python
from database.adapters_old import SQLiteAdapter
from database.schema_manager import SchemaManager

adapter = SQLiteAdapter(":memory:")
manager = SchemaManager(adapter=adapter)
manager.create_schema()
```

**New:**
```python
from database.backends import BackendFactory
from database.schema_manager import SchemaManager

backend = BackendFactory.create_in_memory_backend()
manager = SchemaManager(backend=backend)
manager.create_schema()
```

### Pattern 2: Environment-Aware Database Access

**Old:**
```python
from database.adapters_old import create_adapter
from database.dialect import DatabaseDialect
from utility.environment import is_databricks

if is_databricks():
    adapter = create_adapter(
        DatabaseDialect.DATABRICKS,
        catalog="prod",
        schema="faq"
    )
else:
    adapter = create_adapter(
        DatabaseDialect.SQLITE,
        database_path="faq.db"
    )
```

**New:**
```python
from database.backends import get_backend

# Auto-detects Databricks vs SQLite
backend = get_backend()
# That's it! Configuration handled automatically via environment
```

### Pattern 3: Testing with In-Memory Database

**Old:**
```python
from database.adapters_old import SQLiteAdapter

adapter = SQLiteAdapter(in_memory=True)
# ... test code ...
adapter.close()
```

**New:**
```python
from database.backends import BackendFactory

backend = BackendFactory.create_in_memory_backend()
# ... test code ...
backend.close()
```

---

## Troubleshooting

### Error: "ConfigurationError: backend type is invalid"

**Cause:** Invalid backend type in configuration

**Solution:**
```python
# Valid backend types: "sqlite", "databricks"
config = DatabaseConfig(backend="sqlite", ...)  # Correct
# NOT: backend="SQLITE" or backend="postgres"
```

### Error: "Either 'adapter' or 'backend' must be provided"

**Cause:** SchemaManager requires either adapter (old) or backend (new)

**Solution:**
```python
# Provide backend (new way)
manager = SchemaManager(backend=backend)

# OR provide adapter (old way, deprecated)
manager = SchemaManager(adapter=adapter)
```

### Warning: "DeprecationWarning: database.adapters_old is deprecated"

**Cause:** Using deprecated module

**Solution:** Migrate to new backends system using this guide

---

## Need Help?

- See the [Backend README](README.md) for architecture details
- Check [database/backends/sqlite/README.md](sqlite/README.md) for SQLite backend docs
- Review test files in `tests/backends/` for usage examples
- Read the [Migration Plan](../../MIGRATION_PLAN_SQLITE_TO_DATABRICKS.md) for full context

---

## Checklist for Migration

- [ ] Identified all uses of `database.adapters_old`
- [ ] Replaced `DatabaseAdapter` with `IBackend`
- [ ] Replaced `SQLiteAdapter`/`DatabricksAdapter` with `SQLiteBackend`/`DatabricksBackend`
- [ ] Updated `create_adapter()` calls to use `BackendFactory`
- [ ] Changed `adapter.execute()` to `backend.execute_query()` or `backend.execute_command()`
- [ ] Changed `adapter.fetchall()` to `backend.execute_query()`
- [ ] Updated row access from `row[0]` to `row['column_name']`
- [ ] Tested with both SQLite and Databricks (if applicable)
- [ ] Updated imports from `database.utils` to `database.backends.sqlite/databricks`
- [ ] Updated imports from `utility.database` to `database.backends.sqlite.utilities`
- [ ] Verified no deprecation warnings in tests

---

**Last Updated:** 2025-11-02
**Migration Phase:** 2D Complete
