-- ============================================================================
-- TABLE: faq_questions
-- ============================================================================
-- Description: FAQ questions - content-agnostic
-- Dependencies: None (independent of content)
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Questions can exist without answers (draft state)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_questions (
    -- Primary Identity
    question_id STRING NOT NULL,

    -- Question Content
    question_text STRING NOT NULL,

    -- Metadata
    source_type STRING COMMENT 'from_documents, from_user_queries, from_manual, from_validation',
    generation_method STRING COMMENT 'llm_generated, human_written, extracted',

    -- Status
    status STRING NOT NULL DEFAULT 'active' COMMENT 'active, invalidated, archived, deleted',

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'FAQ questions - content-agnostic'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.feature.allowColumnDefaults' = 'supported'
);

-- Primary Key
ALTER TABLE faq_questions ADD CONSTRAINT IF NOT EXISTS pk_faq_questions
    PRIMARY KEY (question_id);

-- Check Constraints
ALTER TABLE faq_questions ADD CONSTRAINT IF NOT EXISTS chk_question_status
    CHECK (status IN ('active', 'invalidated', 'archived', 'deleted'));
