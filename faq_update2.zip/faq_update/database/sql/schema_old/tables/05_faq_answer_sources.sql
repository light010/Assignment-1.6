-- ============================================================================
-- TABLE: faq_answer_sources
-- ============================================================================
-- Description: Answer provenance - which content provided answer info
-- Dependencies: faq_answers, content_chunks
-- Owner: Analytics Assist Team
--
-- Key Concept: Temporal validity tracking (same as faq_question_sources)
--              Tracks which specific content sections were used for answers
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answer_sources (
    -- Primary Identity
    source_id BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY,

    -- Links
    answer_id STRING NOT NULL,
    content_checksum STRING NOT NULL,

    -- Source Attribution
    is_primary_source BOOLEAN DEFAULT FALSE,
    contribution_weight DOUBLE,
    context_employed STRING COMMENT 'JSON: which sections/paragraphs were used',

    -- Temporal Validity
    is_valid BOOLEAN NOT NULL DEFAULT TRUE,
    valid_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    valid_until TIMESTAMP,

    -- Invalidation Tracking
    invalidation_reason STRING COMMENT 'content_changed, content_deleted, quality_issue, manual, selective_impact',
    invalidated_by_change_id BIGINT,

    -- Timestamps
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
COMMENT 'Answer provenance - which content provided answer info'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.feature.allowColumnDefaults' = 'supported'
);

-- Primary Key
ALTER TABLE faq_answer_sources ADD CONSTRAINT IF NOT EXISTS pk_faq_answer_sources
    PRIMARY KEY (source_id);

-- Check Constraints
ALTER TABLE faq_answer_sources ADD CONSTRAINT IF NOT EXISTS chk_asrc_contribution
    CHECK (contribution_weight IS NULL OR (contribution_weight >= 0.0 AND contribution_weight <= 1.0));

-- Foreign Key Constraints
ALTER TABLE faq_answer_sources ADD CONSTRAINT IF NOT EXISTS fk_asrc_answer
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id) ON DELETE CASCADE;

-- NOTE: No FK for content_checksum - it references a non-primary key column in content_chunks
-- Databricks Unity Catalog only supports FK constraints to PRIMARY KEY columns
-- Referential integrity for content_checksum is maintained by application logic (utils.validators)
-- Use validate_answer_sources(df, adapter) before inserting data

-- NOTE: NO UNIQUE constraint on (answer_id, content_checksum)
-- Reason: Same answer can use same source across different validity periods
-- Temporal uniqueness is enforced via (is_valid, valid_from, valid_until) logic instead
-- This allows regeneration to reuse sources without constraint violations
