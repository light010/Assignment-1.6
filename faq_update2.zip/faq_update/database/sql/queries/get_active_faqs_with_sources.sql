-- ============================================================================
-- Query: Get Active FAQs with Source Content
-- ============================================================================
-- Purpose: Retrieve active FAQs with their source content relationships
--
-- Parameters:
--   {catalog} - Database catalog name
--   {schema} - Database schema name
--   {faq_filter} - Optional: specific FAQ ID filter
-- ============================================================================

SELECT
    q.question_id,
    q.question_text,
    a.answer_id,
    SUBSTR(a.answer_text, 1, 500) AS answer_preview,
    q.status,
    q.created_at,
    q.modified_at,

    -- Question sources
    COLLECT_LIST(DISTINCT qsrc.content_checksum) AS question_source_checksums,
    COUNT(DISTINCT qsrc.content_checksum) AS question_source_count,

    -- Answer sources
    COLLECT_LIST(DISTINCT asrc.content_checksum) AS answer_source_checksums,
    COUNT(DISTINCT asrc.content_checksum) AS answer_source_count,

    -- All sources combined
    COUNT(DISTINCT COALESCE(qsrc.content_checksum, asrc.content_checksum)) AS total_unique_sources

FROM {catalog}.{schema}.faq_questions q
LEFT JOIN {catalog}.{schema}.faq_answers a
    ON q.question_id = a.question_id AND a.status = 'active'
LEFT JOIN {catalog}.{schema}.faq_question_sources qsrc
    ON q.question_id = qsrc.question_id AND qsrc.is_valid = TRUE
LEFT JOIN {catalog}.{schema}.faq_answer_sources asrc
    ON a.answer_id = asrc.answer_id AND asrc.is_valid = TRUE

WHERE q.status = 'active'
  {faq_filter}

GROUP BY
    q.question_id, q.question_text, a.answer_id, a.answer_text,
    q.status, q.created_at, q.modified_at

ORDER BY q.modified_at DESC;
