-- ============================================================================
-- Query: Get Detection Run Summary
-- ============================================================================
-- Purpose: Summary statistics for detection runs showing granular impact savings
--
-- Parameters:
--   {catalog} - Database catalog name
--   {schema} - Database schema name
--   {limit} - Number of recent runs to show (default: 10)
-- ============================================================================

SELECT
    ccl.detection_run_id,
    MIN(ccl.detection_timestamp) AS detection_started_at,
    MAX(ccl.detection_timestamp) AS detection_completed_at,

    -- Analysis scope
    COUNT(*) AS total_changes_detected,
    COUNT(DISTINCT ccl.file_name) AS unique_files_changed,

    -- Impact metrics
    SUM(ccl.total_faqs_at_risk) AS total_faqs_at_risk,
    SUM(ccl.affected_question_count) AS questions_actually_affected,
    SUM(ccl.affected_answer_count) AS answers_actually_affected,

    -- Savings calculation
    SUM(ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count)) AS faqs_saved_from_regeneration,
    ROUND(100.0 * SUM(ccl.total_faqs_at_risk - (ccl.affected_question_count + ccl.affected_answer_count)) /
          NULLIF(SUM(ccl.total_faqs_at_risk), 0), 2) AS savings_percentage,

    -- Similarity statistics
    ROUND(AVG(ccl.similarity_score), 3) AS avg_similarity_score,
    ROUND(MIN(ccl.similarity_score), 3) AS min_similarity_score,
    ROUND(MAX(ccl.similarity_score), 3) AS max_similarity_score

FROM {catalog}.{schema}.content_change_log ccl
WHERE ccl.requires_faq_regeneration = TRUE
GROUP BY ccl.detection_run_id
ORDER BY detection_started_at DESC
LIMIT {limit};
