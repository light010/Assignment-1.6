-- ============================================================================
-- TABLE: faq_answer_sources (SQLite)
-- ============================================================================
-- Description: Answer provenance - which content provided answer info
-- Dependencies: faq_answers, content_chunks
-- Owner: Analytics Assist Team
--
-- Key Concept: Temporal validity tracking (same as faq_question_sources)
--              Tracks which specific content sections were used for answers
--
-- SQLite Features Used:
--   - AUTOINCREMENT for primary key
--   - Multiple foreign key constraints with CASCADE
--   - CHECK constraints for validation
--   - JSON stored as TEXT (SQLite has JSON functions)
--   - No temporal unique constraints (allows regeneration flexibility)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answer_sources (
    -- Primary Identity
    source_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Links
    answer_id TEXT NOT NULL,
    content_checksum TEXT NOT NULL,

    -- Source Attribution
    is_primary_source INTEGER DEFAULT 0,  -- SQLite uses INTEGER for BOOLEAN (0/1)
    contribution_weight REAL,                          -- Range validation in app code
    context_employed TEXT,  -- JSON: which sections/paragraphs were used (stored as TEXT)

    -- Temporal Validity
    is_valid INTEGER NOT NULL DEFAULT 1,  -- SQLite uses INTEGER for BOOLEAN (0/1)
    valid_from DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME,

    -- Invalidation Tracking
    invalidation_reason TEXT,  -- 'content_changed', 'content_deleted', 'quality_issue', 'manual', 'selective_impact'
    invalidated_by_change_id INTEGER,  -- FK to content_change_log

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Foreign Key Constraints (without CASCADE to match Databricks)
    FOREIGN KEY (answer_id) REFERENCES faq_answers(answer_id)
    -- NOTE: No FK for content_checksum - it references a non-unique field in content_chunks
    -- Referential integrity is maintained by application logic instead
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_asrc_answer_id ON faq_answer_sources(answer_id);
CREATE INDEX IF NOT EXISTS idx_asrc_content_checksum ON faq_answer_sources(content_checksum);
CREATE INDEX IF NOT EXISTS idx_asrc_is_valid ON faq_answer_sources(is_valid);
CREATE INDEX IF NOT EXISTS idx_asrc_valid_from ON faq_answer_sources(valid_from);

-- NOTE: NO UNIQUE constraint on (answer_id, content_checksum)
-- Reason: Same answer can use same source across different validity periods
-- Temporal uniqueness is enforced via (is_valid, valid_from, valid_until) logic instead
-- This allows regeneration to reuse sources without constraint violations