-- ============================================================================
-- TABLE: content_change_log (SQLite)
-- ============================================================================
-- Description: Content change detection log with granular impact analysis
-- Dependencies: content_chunks
-- Owner: Analytics Assist Team
--
-- Key Concept: Tracks content changes with similarity scores and diff data
--              Records granular impact counts (affected vs at-risk FAQs)
--              Enables calculation of regeneration savings percentage
--
-- SQLite Features Used:
--   - AUTOINCREMENT for primary key
--   - CHECK constraints for validation
--   - JSON stored as TEXT (SQLite has JSON functions)
--   - REAL for floating point numbers
--   - All constraints and logic preserved from Databricks version
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_change_log (
    -- Primary Identity
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Content Identity
    content_checksum TEXT,                             -- NULL allowed for deleted_content; Length validation in app code
    previous_checksum TEXT,                            -- Length validation in app code

    -- Location Metadata (for human reference)
    file_name TEXT NOT NULL,

    -- Change Classification
    requires_faq_regeneration INTEGER NOT NULL,  -- SQLite uses INTEGER for BOOLEAN (0/1)
    change_type TEXT,  -- 'new_content', 'modified_content', 'unchanged_content', 'deleted_content'

    -- Similarity to previous content
    similarity_score REAL,                             -- Range validation in app code
    similarity_method TEXT,  -- 'difflib', 'jaccard', 'hybrid'

    -- Diff Content (JSON for programmatic access)
    diff_data TEXT,  -- JSON: structured diff data with token-level changes (stored as TEXT)
    -- Example structure (valid JSON):
    -- {
    --   "total_changes": 2,
    --   "change_types": {"replace": 2, "insert": 0, "delete": 0},
    --   "changes": [
    --     {
    --       "change_num": 1,
    --       "change_type": "replace",
    --       "before": "Employees get 12 sick days per year",
    --       "after": "Employees get 10 sick days per year",
    --       "token_changes": [
    --         {"type": "replace", "old_value": "12", "new_value": "10"}
    --       ]
    --     },
    --     {
    --       "change_num": 2,
    --       "change_type": "replace",
    --       "before": "Submit within 30 days",
    --       "after": "Submit within 45 days",
    --       "token_changes": [
    --         {"type": "replace", "old_value": "30", "new_value": "45"}
    --       ]
    --     }
    --   ]
    -- }

    -- FAQ Impact Metrics
    total_faqs_at_risk INTEGER NOT NULL DEFAULT 0,
    affected_question_count INTEGER NOT NULL DEFAULT 0,
    affected_answer_count INTEGER NOT NULL DEFAULT 0,
    -- NOTE: Savings = total_faqs_at_risk - (affected_question_count + affected_answer_count)

    -- Processing Status
    processed INTEGER NOT NULL DEFAULT 0,    -- SQLite uses INTEGER for BOOLEAN (0=pending, 1=processed)
    processed_at DATETIME,                   -- When this change was processed
    processing_error TEXT,                   -- Error message if processing failed

    -- Detection Context
    detection_run_id TEXT NOT NULL,
    detection_timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_ccl_content_checksum ON content_change_log(content_checksum);
CREATE INDEX IF NOT EXISTS idx_ccl_previous_checksum ON content_change_log(previous_checksum);
CREATE INDEX IF NOT EXISTS idx_ccl_detection_run ON content_change_log(detection_run_id);
CREATE INDEX IF NOT EXISTS idx_ccl_requires_regen ON content_change_log(requires_faq_regeneration);
CREATE INDEX IF NOT EXISTS idx_ccl_timestamp ON content_change_log(detection_timestamp);
CREATE INDEX IF NOT EXISTS idx_ccl_processed ON content_change_log(processed);

-- Composite index for finding unprocessed changes
CREATE INDEX IF NOT EXISTS idx_ccl_unprocessed
    ON content_change_log(processed, requires_faq_regeneration)
    WHERE processed = 0;

-- NO location-based unique constraints
-- Reason: Change detection is based on checksums, not locations
-- Same location can have multiple changes over time