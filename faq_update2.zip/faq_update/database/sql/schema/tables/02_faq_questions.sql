-- ============================================================================
-- TABLE: faq_questions (SQLite)
-- ============================================================================
-- Description: FAQ questions - content-agnostic
-- Dependencies: None (independent of content)
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Questions can exist without answers (draft state)
--
-- SQLite Features Used:
--   - TEXT PRIMARY KEY (no autoincrement - using custom IDs)
--   - CHECK constraints for status validation
--   - DEFAULT values supported
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_questions (
    -- Primary Identity
    question_id TEXT PRIMARY KEY,

    -- Question Content
    question_text TEXT NOT NULL,

    -- Metadata
    source_type TEXT,  -- 'from_documents', 'from_user_queries', 'from_manual', 'from_validation'
    generation_method TEXT,  -- 'llm_generated', 'human_written', 'extracted'

    -- Status
    status TEXT NOT NULL DEFAULT 'active',             -- Status validation handled by application code

    -- ========================================================================
    -- INACTIVATION TRACKING (Audit Trail)
    -- ========================================================================
    -- Purpose: Full audit trail for why/when/how questions were inactivated
    -- Consistency Rules (enforced by application code):
    --   1. If status='active': all inactivation fields MUST be NULL
    --   2. If status='inactive': inactivation_reason and inactivated_at MUST be NOT NULL
    --   3. If status='inactive' AND inactivation_reason != 'MANUAL':
    --        inactivated_by_change_id MUST be NOT NULL
    --   4. If status='inactive' AND inactivation_reason = 'MANUAL':
    --        inactivated_by_change_id is OPTIONAL (may be NULL)
    -- ========================================================================

    inactivation_reason TEXT,                          -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Valid values (application-enforced):
                                                       --   'CONTENT_DELETED' - Source content deleted
                                                       --   'ALL_SOURCES_INVALID' - All sources invalid
                                                       --   'MANUAL' - Manual inactivation
                                                       --   'QUALITY_ISSUE' - Quality check failed
                                                       -- See: InactivationReason enum

    inactivated_by_change_id INTEGER,                  -- NULL when active
                                                       -- NULL when inactivation_reason='MANUAL' (optional)
                                                       -- NOT NULL for other inactivation reasons
                                                       -- Logical FK to content_change_log.change_id
                                                       -- (application-level validation only)

    inactivated_at DATETIME,                           -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- ISO-8601 format (YYYY-MM-DD HH:MM:SS)

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_faq_questions_status ON faq_questions(status);
CREATE INDEX IF NOT EXISTS idx_faq_questions_source_type ON faq_questions(source_type);
CREATE INDEX IF NOT EXISTS idx_faq_questions_created ON faq_questions(created_at);