-- ============================================================================
-- TABLE: content_chunks (SQLite)
-- ============================================================================
-- Description: Stores individual content chunks with checksums
-- Dependencies: content_repo (FK: ud_source_file_id)
-- Owner: Analytics Assist Team
--
-- Key Concept: Each row represents ONE chunk of content from a source file.
--              Multiple chunks belong to one file version.
--              Chunks are identified by their SHA-256 checksum.
--              Foreign key to content_repo enables version tracking.
--
-- Design Principles:
--   - Same content can appear in different files (shared boilerplate)
--   - Same content can appear at different positions in same file (repeated headers/footers)
--   - No duplicate checksums allowed within same file
--
-- SQLite Features Used:
--   - AUTOINCREMENT for primary key
--   - UNIQUE constraints supported
--   - CHECK constraints for validation
--   - Foreign key constraints with CASCADE
--   - Standard SQLite data types
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_chunks (
    -- Primary Key
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Foreign Key to content_repo
    ud_source_file_id INTEGER NOT NULL,

    -- Chunk Identity
    chunk_index INTEGER NOT NULL,                      -- Position in file (0, 1, 2, ...)
    content_checksum TEXT NOT NULL,                    -- SHA-256 hash - length validation in app code

    -- Chunk Content
    chunk_text TEXT NOT NULL,                          -- Actual chunk text

    -- Optional Metadata
    chunk_page_number INTEGER,                         -- Page number (if applicable)
    chunk_start_char INTEGER,                          -- Character position start (maps to ChunkMetadata.start_pos)
    chunk_end_char INTEGER,                            -- Character position end (maps to ChunkMetadata.end_pos)

    -- Rich Metadata from HybridMarkdownChunker (Phase 8)
    chunk_method TEXT,                                 -- Chunking strategy: "recursive", "header", "no_split"
    chunk_headers TEXT,                                -- JSON string of header hierarchy: '{"h1": "Title", "h2": "Section"}'

    -- Timestamps and Status
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active',             -- Status validation in app code

    -- Foreign Key (without CASCADE to match Databricks)
    FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
    
    -- Note: No UNIQUE constraint - uniqueness validation handled by application code
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_chunks_file_id ON content_chunks(ud_source_file_id);
CREATE INDEX IF NOT EXISTS idx_chunks_checksum ON content_chunks(content_checksum);
CREATE INDEX IF NOT EXISTS idx_chunks_status ON content_chunks(status);
CREATE INDEX IF NOT EXISTS idx_chunks_method ON content_chunks(chunk_method);

-- ============================================================================
-- USAGE EXAMPLES (SQLite)
-- ============================================================================
--
-- Insert chunks with metadata:
--   INSERT INTO content_chunks
--   (ud_source_file_id, chunk_index, content_checksum, chunk_text,
--    chunk_method, chunk_headers, chunk_start_char, chunk_end_char, status)
--   VALUES (1, 0, 'abc123...', 'Chapter 1 content...',
--           'recursive', '{"h1": "Introduction", "h2": "Overview"}', 0, 3000, 'active');
--
-- Get all chunks for file version:
--   SELECT cc.* FROM content_chunks cc
--   JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
--   WHERE cr.raw_file_nme = 'handbook.pdf' AND cr.raw_file_version_nbr = 1
--   ORDER BY cc.chunk_index;
--
-- Query chunks by header context:
--   SELECT * FROM content_chunks
--   WHERE chunk_headers LIKE '%"h1": "Introduction"%'
--   AND status = 'active';
--
-- Analyze chunking strategy distribution:
--   SELECT chunk_method, COUNT(*) as count
--   FROM content_chunks
--   GROUP BY chunk_method;
-- ============================================================================