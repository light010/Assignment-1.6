-- ============================================================================
-- TABLE: faq_impact_decisions (SQLite)
-- ============================================================================
-- Description: POST-EXECUTION audit log of FAQ impacts
-- Dependencies: content_change_log, faq_questions, faq_answers
-- Owner: Analytics Assist Team
--
-- Key Concept: Records WHAT WAS DONE after execution (not before)
--              All entity_ids are real database IDs (no placeholders)
--              Complete audit trail for all change types
--
-- SQLite Features Used:
--   - AUTOINCREMENT for primary key
--   - Foreign key constraints
--   - CHECK constraints for validation (handled in app code)
--   - Multiple indexes for query performance
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_impact_decisions (
    -- ========================================================================
    -- Primary Identity
    -- ========================================================================
    decision_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- ========================================================================
    -- Link to Change
    -- ========================================================================
    change_id INTEGER NOT NULL,              -- FK to content_change_log
    change_type TEXT NOT NULL,               -- 'new_content', 'deleted_content', 'modified_content'

    -- ========================================================================
    -- Affected Entity (REAL IDs - recorded after execution)
    -- ========================================================================
    entity_type TEXT NOT NULL,               -- 'question' or 'answer'
    entity_id TEXT NOT NULL,                 -- Real question_id or answer_id (exists in DB)

    -- ========================================================================
    -- What Was Done
    -- ========================================================================
    action TEXT NOT NULL,                    -- 'CREATE', 'INACTIVATE', 'REGENERATE'
    reason_code TEXT NOT NULL,               -- Why (e.g., 'SOLE_SOURCE_DELETED', 'NEW_CONTENT')

    -- ========================================================================
    -- Context Metadata
    -- ========================================================================
    content_checksum TEXT,                   -- Which checksum triggered this
    source_count INTEGER,                    -- How many sources entity had at decision time
    similarity_score REAL,                   -- For modified_content (0.0-1.0)
    impact_type TEXT,                        -- 'direct', 'indirect_token_overlap', 'cascade'

    -- ========================================================================
    -- Audit Trail
    -- ========================================================================
    created_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- ========================================================================
    -- Foreign Keys
    -- ========================================================================
    FOREIGN KEY (change_id) REFERENCES content_change_log(change_id)
);

-- ========================================================================
-- Indexes for Performance
-- ========================================================================
CREATE INDEX IF NOT EXISTS idx_impact_change_id ON faq_impact_decisions(change_id);
CREATE INDEX IF NOT EXISTS idx_impact_entity ON faq_impact_decisions(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_impact_action ON faq_impact_decisions(action);
CREATE INDEX IF NOT EXISTS idx_impact_change_type ON faq_impact_decisions(change_type);
CREATE INDEX IF NOT EXISTS idx_impact_created_at ON faq_impact_decisions(created_at);
CREATE INDEX IF NOT EXISTS idx_impact_impact_type ON faq_impact_decisions(impact_type);
CREATE INDEX IF NOT EXISTS idx_impact_checksum ON faq_impact_decisions(content_checksum);

-- ========================================================================
-- Composite Indexes for Common Queries
-- ========================================================================
-- Decisions by change and entity
CREATE INDEX IF NOT EXISTS idx_impact_change_entity
    ON faq_impact_decisions(change_id, entity_type, entity_id);

-- Decisions by action and change type
CREATE INDEX IF NOT EXISTS idx_impact_action_changetype
    ON faq_impact_decisions(action, change_type);
