-- ============================================================================
-- TABLE: faq_answers (SQLite)
-- ============================================================================
-- Description: FAQ answers - linked to questions (1:1)
-- Dependencies: faq_questions
-- Owner: Analytics Assist Team
--
-- Key Concept: Questions are separate from answers (1:1 relationship via faq_answers)
--              Each answer is linked to exactly one question
--
-- SQLite Features Used:
--   - TEXT PRIMARY KEY (no autoincrement - using custom IDs)
--   - CHECK constraints for status and format validation
--   - Foreign key constraint with CASCADE DELETE
--   - DEFAULT values supported
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_answers (
    -- Primary Identity
    answer_id TEXT PRIMARY KEY,

    -- Link to Question (1:1)
    question_id TEXT NOT NULL,

    -- Answer Content
    answer_text TEXT NOT NULL,
    answer_format TEXT DEFAULT 'html',                 -- Format validation in app code

    -- Quality Metrics
    confidence_score REAL,                             -- Range validation in app code

    -- Status
    status TEXT NOT NULL DEFAULT 'active',             -- Status validation in app code

    -- ========================================================================
    -- INACTIVATION TRACKING (Audit Trail)
    -- ========================================================================
    -- Purpose: Full audit trail for why/when/how answers were inactivated
    -- Consistency Rules (enforced by application code):
    --   1. If status='active': all inactivation fields MUST be NULL
    --   2. If status='inactive': inactivation_reason and inactivated_at MUST be NOT NULL
    --   3. If status='inactive' AND inactivation_reason NOT IN ('MANUAL', 'QUESTION_INACTIVATED'):
    --        inactivated_by_change_id MUST be NOT NULL
    --   4. If status='inactive' AND inactivation_reason IN ('MANUAL', 'QUESTION_INACTIVATED'):
    --        inactivated_by_change_id is OPTIONAL (may be NULL or NOT NULL)
    --   5. CASCADE RULE: If question is inactive, ALL its answers MUST be inactive
    --   6. ORPHAN PREVENTION: Active answers can only exist for active questions
    -- ========================================================================

    inactivation_reason TEXT,                          -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- Valid values (application-enforced):
                                                       --   'CONTENT_DELETED' - Source content deleted
                                                       --   'QUALITY_ISSUE' - Quality check failed
                                                       --   'MANUAL' - Manual inactivation
                                                       --   'QUESTION_INACTIVATED' - Cascaded from question
                                                       -- See: InactivationReason enum

    inactivated_by_change_id INTEGER,                  -- NULL when active
                                                       -- OPTIONAL when inactivation_reason='MANUAL' or 'QUESTION_INACTIVATED'
                                                       -- NOT NULL for other inactivation reasons
                                                       -- Logical FK to content_change_log.change_id
                                                       -- (application-level validation only)

    inactivated_at DATETIME,                           -- NULL when active
                                                       -- NOT NULL when inactive
                                                       -- ISO-8601 format (YYYY-MM-DD HH:MM:SS)

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Foreign Key (without CASCADE to match Databricks)
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_faq_answers_question_id ON faq_answers(question_id);
CREATE INDEX IF NOT EXISTS idx_faq_answers_status ON faq_answers(status);
CREATE INDEX IF NOT EXISTS idx_faq_answers_created ON faq_answers(created_at);