-- ============================================================================
-- TABLE: faq_question_sources (SQLite)
-- ============================================================================
-- Description: Question provenance - which content inspired each question
-- Dependencies: faq_questions, content_chunks
-- Owner: Analytics Assist Team
--
-- Key Concept: Temporal validity tracking
--              is_valid + valid_from + valid_until = time-based provenance
--              Allows tracking which content was valid when
--              Supports regeneration without unique constraint violations
--
-- SQLite Features Used:
--   - AUTOINCREMENT for primary key
--   - Multiple foreign key constraints with CASCADE
--   - CHECK constraints for validation
--   - No temporal unique constraints (allows regeneration flexibility)
-- ============================================================================

CREATE TABLE IF NOT EXISTS faq_question_sources (
    -- Primary Identity
    source_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Links
    question_id TEXT NOT NULL,
    content_checksum TEXT NOT NULL,

    -- Source Attribution
    is_primary_source INTEGER DEFAULT 0,  -- SQLite uses INTEGER for BOOLEAN (0/1)
    contribution_weight REAL,                          -- Range validation in app code

    -- Temporal Validity
    is_valid INTEGER NOT NULL DEFAULT 1,  -- SQLite uses INTEGER for BOOLEAN (0/1)
    valid_from DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME,

    -- Invalidation Tracking
    invalidation_reason TEXT,  -- 'content_changed', 'content_deleted', 'quality_issue', 'manual', 'selective_impact'
    invalidated_by_change_id INTEGER,  -- FK to content_change_log

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Foreign Key Constraints (without CASCADE to match Databricks)
    FOREIGN KEY (question_id) REFERENCES faq_questions(question_id)
    -- NOTE: No FK for content_checksum - it references a non-unique field in content_chunks
    -- Referential integrity is maintained by application logic instead
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_qsrc_question_id ON faq_question_sources(question_id);
CREATE INDEX IF NOT EXISTS idx_qsrc_content_checksum ON faq_question_sources(content_checksum);
CREATE INDEX IF NOT EXISTS idx_qsrc_is_valid ON faq_question_sources(is_valid);
CREATE INDEX IF NOT EXISTS idx_qsrc_valid_from ON faq_question_sources(valid_from);

-- NOTE: NO UNIQUE constraint on (question_id, content_checksum)
-- Reason: Same question can use same source across different validity periods
-- Temporal uniqueness is enforced via (is_valid, valid_from, valid_until) logic instead
-- This allows regeneration to reuse sources without constraint violations