-- ============================================================================
-- TABLE: content_repo (SQLite)
-- ============================================================================
-- Description: Repository of source content files and their metadata
-- Dependencies: None (foundation table)
-- Owner: Analytics Assist Team
--
-- Key Concept: Tracks raw source files with their extracted content paths
--              This table serves as the source-of-truth for content ingestion
--
-- SQLite Features Used:
-- - AUTOINCREMENT for primary key
-- - CHECK constraints inline
-- - DEFAULT values supported
-- - Standard SQLite data types
-- ============================================================================

CREATE TABLE IF NOT EXISTS content_repo (
    -- Primary key
    ud_source_file_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- File identification
    raw_file_nme TEXT NOT NULL,
    raw_file_type TEXT,
    raw_file_version_nbr INTEGER DEFAULT 1,

    -- Source information
    raw_file_path TEXT,

    -- Content paths
    extracted_markdown_file_path TEXT,

    -- Content metadata
    title_nme TEXT,
    file_status TEXT,  -- No constraints - validation handled by application code like Databricks

    -- Timestamps
    created_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_dt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Note: All constraint validation handled by application code to match Databricks limitations

-- Create index for performance (optional but recommended)
CREATE INDEX IF NOT EXISTS idx_content_repo_file_name ON content_repo(raw_file_nme);
CREATE INDEX IF NOT EXISTS idx_content_repo_status ON content_repo(file_status);