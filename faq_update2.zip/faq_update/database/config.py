"""
Database Configuration System

Centralized configuration for all database backends. Supports multiple
configuration sources with priority order:

1. Environment variables (highest priority)
2. YAML configuration file
3. Python dict (programmatic)
4. Default values (lowest priority)

Design Principles:
- Single Source of Truth: All database config in one place
- Environment Agnostic: Works in local, Databricks, production
- Validation: Fail fast with clear error messages
- Type Safety: Dataclasses with type hints
- Immutability: Config objects are frozen after creation

Example:
    >>> # Auto-detect from environment
    >>> config = DatabaseConfig.from_env()
    >>> config.backend
    'sqlite'

    >>> # Load from YAML
    >>> config = DatabaseConfig.from_yaml("config/database.yaml")

    >>> # Programmatic
    >>> config = DatabaseConfig(
    ...     backend="databricks",
    ...     catalog="prod_catalog",
    ...     schema="faq_schema"
    ... )

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

import os
import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Dict, Any
from enum import Enum


class BackendType(str, Enum):
    """Supported database backends."""
    SQLITE = "sqlite"
    DATABRICKS = "databricks"
    POSTGRESQL = "postgresql"  # Future
    MYSQL = "mysql"  # Future


@dataclass(frozen=True)
class DatabaseConfig:
    """
    Immutable database configuration.

    Attributes:
        backend: Type of database backend ('sqlite', 'databricks', etc.)

        # SQLite-specific
        db_path: Path to SQLite database file
        timeout: SQLite connection timeout (seconds)
        enable_foreign_keys: Enable foreign key constraints
        journal_mode: SQLite journal mode ('WAL', 'DELETE', etc.)

        # Databricks-specific
        catalog: Unity Catalog name
        schema: Schema name within catalog
        cluster_id: Databricks cluster ID (optional)

        # Common settings
        pool_size: Connection pool size
        max_overflow: Maximum overflow connections
        echo_sql: Print all SQL statements (debugging)
        autocommit: Auto-commit mode

    Example:
        >>> # SQLite config
        >>> config = DatabaseConfig(
        ...     backend="sqlite",
        ...     db_path="databases/faq.db"
        ... )

        >>> # Databricks config
        >>> config = DatabaseConfig(
        ...     backend="databricks",
        ...     catalog="prod_catalog",
        ...     schema="faq_schema"
        ... )
    """

    # Backend type (required)
    backend: str

    # SQLite settings
    db_path: Optional[str] = None
    timeout: float = 30.0
    enable_foreign_keys: bool = True
    journal_mode: str = "WAL"

    # Databricks settings
    catalog: Optional[str] = None
    schema: Optional[str] = None
    cluster_id: Optional[str] = None

    # Common settings
    pool_size: int = 5
    max_overflow: int = 10
    echo_sql: bool = False
    autocommit: bool = False

    # Additional backend-specific settings
    extra: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration after initialization."""
        # Convert backend string to BackendType (validates it's supported)
        try:
            BackendType(self.backend)
        except ValueError:
            supported = ", ".join([b.value for b in BackendType])
            raise ValueError(
                f"Invalid backend '{self.backend}'. "
                f"Supported backends: {supported}"
            )

        # Validate backend-specific requirements
        if self.backend == BackendType.SQLITE:
            if not self.db_path:
                raise ValueError("SQLite backend requires 'db_path'")

        elif self.backend == BackendType.DATABRICKS:
            if not self.catalog:
                raise ValueError("Databricks backend requires 'catalog'")
            if not self.schema:
                raise ValueError("Databricks backend requires 'schema'")

        # Validate timeout
        if self.timeout <= 0:
            raise ValueError(f"timeout must be positive, got {self.timeout}")

        # Validate pool settings
        if self.pool_size <= 0:
            raise ValueError(f"pool_size must be positive, got {self.pool_size}")
        if self.max_overflow < 0:
            raise ValueError(f"max_overflow must be non-negative, got {self.max_overflow}")

    @classmethod
    def from_env(cls, prefix: str = "DATABASE_") -> "DatabaseConfig":
        """
        Load configuration from environment variables.

        Environment variables:
            DATABASE_BACKEND: Backend type ('sqlite' or 'databricks')

            # SQLite
            DATABASE_PATH: Path to SQLite file
            DATABASE_TIMEOUT: Connection timeout (default: 30)
            DATABASE_FOREIGN_KEYS: Enable foreign keys (default: true)
            DATABASE_JOURNAL_MODE: Journal mode (default: WAL)

            # Databricks
            DATABASE_CATALOG: Unity Catalog name
            DATABASE_SCHEMA: Schema name
            DATABASE_CLUSTER_ID: Cluster ID (optional)

            # Common
            DATABASE_POOL_SIZE: Connection pool size (default: 5)
            DATABASE_MAX_OVERFLOW: Max overflow connections (default: 10)
            DATABASE_ECHO_SQL: Echo SQL statements (default: false)

        Args:
            prefix: Environment variable prefix (default: "DATABASE_")

        Returns:
            DatabaseConfig instance

        Raises:
            ValueError: If required environment variables are missing

        Example:
            >>> # Set environment variables
            >>> os.environ['DATABASE_BACKEND'] = 'sqlite'
            >>> os.environ['DATABASE_PATH'] = 'databases/faq.db'
            >>> config = DatabaseConfig.from_env()
            >>> config.backend
            'sqlite'
        """
        def get_env(key: str, default: Any = None) -> Any:
            """Get environment variable with prefix."""
            full_key = f"{prefix}{key}"
            value = os.getenv(full_key, default)

            # Convert string booleans
            if isinstance(value, str):
                if value.lower() in ("true", "1", "yes", "on"):
                    return True
                elif value.lower() in ("false", "0", "no", "off"):
                    return False

            # Convert string numbers
            if isinstance(value, str) and value.replace(".", "").isdigit():
                return float(value) if "." in value else int(value)

            return value

        # Required: backend type
        backend = get_env("BACKEND")
        if not backend:
            # Try to auto-detect
            if "DATABRICKS_RUNTIME_VERSION" in os.environ:
                backend = "databricks"
            else:
                backend = "sqlite"  # Default to SQLite

        # Build config kwargs
        kwargs = {"backend": backend}

        # SQLite settings
        if backend == BackendType.SQLITE.value:
            kwargs["db_path"] = get_env("PATH", "databases/granular_impact.db")
            kwargs["timeout"] = get_env("TIMEOUT", 30.0)
            kwargs["enable_foreign_keys"] = get_env("FOREIGN_KEYS", True)
            kwargs["journal_mode"] = get_env("JOURNAL_MODE", "WAL")

        # Databricks settings
        elif backend == BackendType.DATABRICKS.value:
            kwargs["catalog"] = get_env("CATALOG")
            kwargs["schema"] = get_env("SCHEMA")
            kwargs["cluster_id"] = get_env("CLUSTER_ID")

        # Common settings
        kwargs["pool_size"] = get_env("POOL_SIZE", 5)
        kwargs["max_overflow"] = get_env("MAX_OVERFLOW", 10)
        kwargs["echo_sql"] = get_env("ECHO_SQL", False)
        kwargs["autocommit"] = get_env("AUTOCOMMIT", False)

        return cls(**kwargs)

    @classmethod
    def from_yaml(cls, path: Path) -> "DatabaseConfig":
        """
        Load configuration from YAML file.

        YAML format:
            database:
              backend: sqlite
              db_path: databases/faq.db
              timeout: 30
              enable_foreign_keys: true
              journal_mode: WAL

        Or for Databricks:
            database:
              backend: databricks
              catalog: prod_catalog
              schema: faq_schema

        Args:
            path: Path to YAML file

        Returns:
            DatabaseConfig instance

        Raises:
            FileNotFoundError: If YAML file doesn't exist
            ValueError: If YAML is invalid

        Example:
            >>> config = DatabaseConfig.from_yaml("config/database.yaml")
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path, 'r') as f:
            data = yaml.safe_load(f)

        if 'database' not in data:
            raise ValueError("YAML must contain 'database' key")

        return cls(**data['database'])

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "DatabaseConfig":
        """
        Load configuration from dictionary.

        Args:
            config_dict: Configuration dictionary

        Returns:
            DatabaseConfig instance

        Example:
            >>> config = DatabaseConfig.from_dict({
            ...     'backend': 'sqlite',
            ...     'db_path': 'test.db'
            ... })
        """
        return cls(**config_dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.

        Returns:
            Dictionary representation

        Example:
            >>> config = DatabaseConfig(backend="sqlite", db_path="test.db")
            >>> config.to_dict()
            {'backend': 'sqlite', 'db_path': 'test.db', ...}
        """
        return {
            'backend': self.backend,
            'db_path': self.db_path,
            'timeout': self.timeout,
            'enable_foreign_keys': self.enable_foreign_keys,
            'journal_mode': self.journal_mode,
            'catalog': self.catalog,
            'schema': self.schema,
            'cluster_id': self.cluster_id,
            'pool_size': self.pool_size,
            'max_overflow': self.max_overflow,
            'echo_sql': self.echo_sql,
            'autocommit': self.autocommit,
            'extra': self.extra,
        }

    def to_yaml(self, path: Path) -> None:
        """
        Write configuration to YAML file.

        Args:
            path: Path to write YAML file

        Example:
            >>> config = DatabaseConfig(backend="sqlite", db_path="test.db")
            >>> config.to_yaml("config/database.yaml")
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, 'w') as f:
            yaml.dump({'database': self.to_dict()}, f, default_flow_style=False)

    def is_sqlite(self) -> bool:
        """Check if this is a SQLite configuration."""
        return self.backend == BackendType.SQLITE.value

    def is_databricks(self) -> bool:
        """Check if this is a Databricks configuration."""
        return self.backend == BackendType.DATABRICKS.value

    def get_connection_string(self) -> str:
        """
        Get a connection string representation (for logging/debugging).

        Returns:
            Human-readable connection string (NO SENSITIVE DATA)

        Example:
            >>> config = DatabaseConfig(backend="sqlite", db_path="faq.db")
            >>> config.get_connection_string()
            'sqlite://faq.db'
        """
        if self.is_sqlite():
            return f"sqlite://{self.db_path}"
        elif self.is_databricks():
            return f"databricks://{self.catalog}.{self.schema}"
        else:
            return f"{self.backend}://<unknown>"

    def __str__(self) -> str:
        """String representation (safe for logging)."""
        return f"DatabaseConfig(backend={self.backend}, connection={self.get_connection_string()})"


# =============================================================================
# Helper Functions
# =============================================================================

def load_config(
    source: Optional[Any] = None,
    prefer_env: bool = True
) -> DatabaseConfig:
    """
    Load database configuration from various sources.

    This is a convenience function that tries multiple sources in order:
    1. If source is a DatabaseConfig, return it
    2. If source is a Path/str, load from YAML
    3. If source is a dict, load from dict
    4. If source is None and prefer_env=True, load from environment
    5. Otherwise, use defaults

    Args:
        source: Configuration source (None, Path, dict, or DatabaseConfig)
        prefer_env: If True and source is None, load from environment

    Returns:
        DatabaseConfig instance

    Example:
        >>> # Auto-detect from environment
        >>> config = load_config()

        >>> # From YAML file
        >>> config = load_config("config/database.yaml")

        >>> # From dict
        >>> config = load_config({'backend': 'sqlite', 'db_path': 'test.db'})

        >>> # Already a config - pass through
        >>> existing_config = DatabaseConfig(backend="sqlite", db_path="test.db")
        >>> config = load_config(existing_config)
        >>> config is existing_config
        True
    """
    # Already a DatabaseConfig - return as-is
    if isinstance(source, DatabaseConfig):
        return source

    # Path or string - load from YAML
    if isinstance(source, (Path, str)):
        return DatabaseConfig.from_yaml(Path(source))

    # Dictionary - load from dict
    if isinstance(source, dict):
        return DatabaseConfig.from_dict(source)

    # None - load from environment or defaults
    if source is None:
        if prefer_env:
            return DatabaseConfig.from_env()
        else:
            # Default: SQLite in-memory
            return DatabaseConfig(backend="sqlite", db_path=":memory:")

    raise ValueError(f"Invalid config source type: {type(source)}")


__all__ = [
    "DatabaseConfig",
    "BackendType",
    "load_config",
]
