"""
SQL query templates for granular impact analysis.

Provides query templates and utilities for loading SQL files from sql/ directory.

Database Schema (7 tables):
1. content_checksums - Master content table
2. faq_questions - FAQ questions
3. faq_answers - FAQ answers
4. faq_question_sources - Question provenance
5. faq_answer_sources - Answer provenance
6. content_change_log - Change detection with diff_data (JSON)
7. faq_audit_log - Minimal audit trail

All queries use parameterized templates with format() substitution.
"""

from pathlib import Path
from typing import Dict, Optional


class QueryTemplates:
    """SQL query templates and SQL file loader."""

    SQL_DIR = Path(__file__).parent / "sql"

    @staticmethod
    def load_sql_file(file_path: str, params: Optional[Dict[str, str]] = None) -> str:
        """
        Load SQL from file and optionally substitute parameters.

        Args:
            file_path: Relative path from sql/ directory
            params: Dictionary of parameters to substitute

        Returns:
            SQL string with parameters substituted

        Example:
            >>> sql = QueryTemplates.load_sql_file(
            ...     "queries/get_faqs_requiring_regeneration.sql",
            ...     {
            ...         "catalog": "prod",
            ...         "schema": "faq",
            ...         "detection_run_filter": "AND ccl.detection_run_id = 'RUN_123'"
            ...     }
            ... )
        """
        full_path = QueryTemplates.SQL_DIR / file_path

        if not full_path.exists():
            raise FileNotFoundError(f"SQL file not found: {full_path}")

        with open(full_path, "r", encoding="utf-8") as f:
            sql = f.read()

        if params:
            sql = sql.format(**params)

        return sql

    # ========================================================================
    # QUERY METHODS
    # ========================================================================

    @staticmethod
    def get_faqs_requiring_regeneration(
        catalog: str,
        schema: str,
        detection_run_id: Optional[str] = None,
    ) -> str:
        """
        Get FAQs that need regeneration based on content changes.

        Args:
            catalog: Database catalog
            schema: Database schema
            detection_run_id: Optional specific detection run ID

        Returns:
            SQL query string
        """
        detection_run_filter = (
            f'AND ccl.detection_run_id = "{detection_run_id}"' if detection_run_id else ""
        )

        return QueryTemplates.load_sql_file(
            "queries/get_faqs_requiring_regeneration.sql",
            {
                "catalog": catalog,
                "schema": schema,
                "detection_run_filter": detection_run_filter,
            },
        )

    @staticmethod
    def get_content_changes_summary(
        catalog: str, schema: str, detection_run_id: Optional[str] = None
    ) -> str:
        """
        Get summary of content changes with diff data.

        Args:
            catalog: Database catalog
            schema: Database schema
            detection_run_id: Optional specific detection run ID

        Returns:
            SQL query string
        """
        detection_run_filter = (
            f'WHERE ccl.detection_run_id = "{detection_run_id}"' if detection_run_id else ""
        )

        return QueryTemplates.load_sql_file(
            "queries/get_content_diffs_summary.sql",
            {
                "catalog": catalog,
                "schema": schema,
                "detection_run_filter": detection_run_filter,
            },
        )

    @staticmethod
    def get_detection_run_summary(catalog: str, schema: str, limit: int = 10) -> str:
        """
        Get summary statistics for detection runs showing savings.

        Args:
            catalog: Database catalog
            schema: Database schema
            limit: Number of recent runs to show (default: 10)

        Returns:
            SQL query string
        """
        return QueryTemplates.load_sql_file(
            "queries/get_detection_run_summary.sql",
            {"catalog": catalog, "schema": schema, "limit": str(limit)},
        )

    @staticmethod
    def get_active_faqs_with_sources(
        catalog: str, schema: str, faq_id: Optional[int] = None
    ) -> str:
        """
        Get active FAQs with their source content relationships.

        Args:
            catalog: Database catalog
            schema: Database schema
            faq_id: Optional specific FAQ question ID filter

        Returns:
            SQL query string
        """
        faq_filter = f"AND q.question_id = {faq_id}" if faq_id else ""

        return QueryTemplates.load_sql_file(
            "queries/get_active_faqs_with_sources.sql",
            {
                "catalog": catalog,
                "schema": schema,
                "faq_filter": faq_filter,
            },
        )

    # ========================================================================
    # BATCH QUERY HELPERS
    # ========================================================================

    @staticmethod
    def get_faqs_by_checksums_batch(catalog: str, schema: str) -> str:
        """
        Get FAQs linked to a batch of content checksums.

        Returns both questions and answers linked to the provided checksums.

        Args:
            catalog: Database catalog
            schema: Database schema

        Returns:
            SQL template with {checksums} placeholder

        Usage:
            >>> template = QueryTemplates.get_faqs_by_checksums_batch("prod", "faq")
            >>> checksums = ["abc123...", "def456..."]
            >>> checksum_list = ", ".join(f"'{c}'" for c in checksums)
            >>> sql = template.format(checksums=checksum_list)
        """
        return f"""
        -- Questions linked to batch of checksums
        SELECT DISTINCT
            qsrc.content_checksum,
            q.question_id,
            q.question_text,
            NULL as answer_id,
            NULL as answer_text,
            'question' as faq_component
        FROM {catalog}.{schema}.faq_question_sources qsrc
        INNER JOIN {catalog}.{schema}.faq_questions q
            ON qsrc.question_id = q.question_id
        WHERE qsrc.content_checksum IN ({{checksums}})
          AND qsrc.is_valid = TRUE
          AND q.status = 'active'

        UNION ALL

        -- Answers linked to batch of checksums
        SELECT DISTINCT
            asrc.content_checksum,
            q.question_id,
            q.question_text,
            a.answer_id,
            a.answer_text,
            'answer' as faq_component
        FROM {catalog}.{schema}.faq_answer_sources asrc
        INNER JOIN {catalog}.{schema}.faq_answers a
            ON asrc.answer_id = a.answer_id
        INNER JOIN {catalog}.{schema}.faq_questions q
            ON a.question_id = q.question_id
        WHERE asrc.content_checksum IN ({{checksums}})
          AND asrc.is_valid = TRUE
          AND a.status = 'active'
          AND q.status = 'active'

        ORDER BY content_checksum, question_id, faq_component
        """

    @staticmethod
    def invalidate_faq_sources_batch(catalog: str, schema: str) -> str:
        """
        Batch invalidate FAQ sources for a specific change.

        Args:
            catalog: Database catalog
            schema: Database schema

        Returns:
            SQL template with {change_id} and {checksum} placeholders

        Usage:
            >>> template = QueryTemplates.invalidate_faq_sources_batch("prod", "faq")
            >>> sql = template.format(change_id=12345, checksum="'abc123...'")
        """
        return f"""
        -- Invalidate question sources
        UPDATE {catalog}.{schema}.faq_question_sources
        SET
            is_valid = FALSE,
            valid_until = CURRENT_TIMESTAMP(),
            invalidation_reason = 'content_changed',
            invalidated_by_change_id = {{change_id}}
        WHERE content_checksum = {{checksum}}
          AND is_valid = TRUE;

        -- Invalidate answer sources
        UPDATE {catalog}.{schema}.faq_answer_sources
        SET
            is_valid = FALSE,
            valid_until = CURRENT_TIMESTAMP(),
            invalidation_reason = 'content_changed',
            invalidated_by_change_id = {{change_id}}
        WHERE content_checksum = {{checksum}}
          AND is_valid = TRUE;
        """

    # ========================================================================
    # AUDIT AND LOGGING
    # ========================================================================

    @staticmethod
    def insert_audit_log(catalog: str, schema: str) -> str:
        """
        Insert audit log entry.

        Args:
            catalog: Database catalog
            schema: Database schema

        Returns:
            SQL template for inserting audit log entry
        """
        return f"""
        INSERT INTO {catalog}.{schema}.faq_audit_log (
            change_id,
            question_id,
            answer_id,
            detection_run_id,
            created_at
        ) VALUES (
            {{change_id}},
            {{question_id}},
            {{answer_id}},
            {{detection_run_id}},
            CURRENT_TIMESTAMP()
        )
        """
