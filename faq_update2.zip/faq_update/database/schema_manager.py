"""
Schema management for granular impact analysis.

Provides unified schema manager supporting multiple database backends:
- Databricks Unity Catalog (Spark SQL + Delta Lake)
- SQLite (local development/testing)
- PostgreSQL (future)

Features:
- Dependency-aware table creation (respects FK relationships)
- Fine-grained control (create specific components)
- Dry-run mode for validation
- Schema validation against expected structure
- Multi-dialect support via adapters

Architecture:
- SQLiteDialectConverter: Handles SQLite → Databricks SQL conversion
- StatementSplitter: Intelligent SQL statement boundary detection
- SchemaManager: Orchestrates schema operations across backends
"""

import re
import yaml
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from loguru import logger

from database.dialect import DatabaseDialect, SQLRenderer
# Use new backend interface
from database.backends.base import IBackend


# ============================================================================
# Data Classes and Enums
# ============================================================================

class SchemaComponent(str, Enum):
    """Schema component types."""
    TABLES = "tables"
    CONSTRAINTS = "constraints"
    INDEXES = "indexes"
    VIEWS = "views"
    ALL = "all"


class DeploymentMode(str, Enum):
    """Schema deployment modes."""
    CREATE = "create"
    UPDATE = "update"
    MIGRATE = "migrate"
    VALIDATE = "validate"


@dataclass
class ConversionRule:
    """
    Declarative SQL conversion rule.
    
    Attributes:
        pattern: Regex pattern to match
        replacement: Replacement string (supports backreferences)
        flags: Regex flags (default: case-insensitive)
        description: Human-readable description for logging
    """
    pattern: str
    replacement: str
    flags: int = re.IGNORECASE
    description: str = ""
    
    def apply(self, text: str) -> str:
        """Apply this conversion rule to text."""
        return re.sub(self.pattern, self.replacement, text, flags=self.flags)


@dataclass
class StatementFix:
    """
    Databricks-specific statement fix rule.
    
    Attributes:
        condition: Function to check if fix applies to statement
        action: Function to fix the statement (returns None to skip)
        description: Human-readable description
    """
    condition: Callable[[str], bool]
    action: Callable[[str], Optional[str]]
    description: str


@dataclass
class SchemaValidationResult:
    """Result of schema validation."""

    is_valid: bool
    missing_tables: List[str] = field(default_factory=list)
    missing_constraints: List[str] = field(default_factory=list)
    missing_indexes: List[str] = field(default_factory=list)
    missing_views: List[str] = field(default_factory=list)
    extra_tables: List[str] = field(default_factory=list)
    validation_timestamp: datetime = field(default_factory=datetime.now)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def __str__(self) -> str:
        """Human-readable validation report."""
        lines = [
            f"Schema Validation Report ({self.validation_timestamp})",
            f"Status: {'✅ VALID' if self.is_valid else '❌ INVALID'}",
            "",
        ]

        if self.missing_tables:
            lines.append(f"Missing Tables ({len(self.missing_tables)}):")
            for table in self.missing_tables:
                lines.append(f"  - {table}")
            lines.append("")

        if self.missing_views:
            lines.append(f"Missing Views ({len(self.missing_views)}):")
            for view in self.missing_views:
                lines.append(f"  - {view}")
            lines.append("")

        if self.errors:
            lines.append(f"Errors ({len(self.errors)}):")
            for error in self.errors:
                lines.append(f"  ❌ {error}")
            lines.append("")

        if self.warnings:
            lines.append(f"Warnings ({len(self.warnings)}):")
            for warning in self.warnings:
                lines.append(f"  ⚠️  {warning}")

        return "\n".join(lines)


class SchemaManager:
    """
    Unified schema manager supporting multiple database backends.

    Supports:
    - Databricks Unity Catalog (Spark SQL + Delta Lake)
    - SQLite (local development/testing)
    - PostgreSQL (future)

    Example:
        >>> from database.backends import BackendFactory, DatabaseConfig
        >>> from database.dialect import DatabaseDialect
        >>>
        >>> # SQLite for local testing
        >>> config = DatabaseConfig(backend="sqlite", db_path=":memory:")
        >>> backend = BackendFactory.create_backend(config)
        >>> manager = SchemaManager(backend=backend)
        >>> manager.create_schema()
        >>>
        >>> # Databricks for production
        >>> config = DatabaseConfig(
        ...     backend="databricks",
        ...     catalog="prod",
        ...     schema="faq"
        ... )
        >>> backend = BackendFactory.create_backend(config)
        >>> manager = SchemaManager(backend=backend)
        >>> manager.create_schema()
    """

    def __init__(
        self,
        backend: IBackend,
        schema_dir: Optional[Path] = None,
        dependency_graph_path: Optional[Path] = None,
    ):
        """
        Initialize schema manager.

        Args:
            backend: IBackend implementation (SQLiteBackend or DatabricksBackend)
            schema_dir: Path to schema directory (auto-detected based on dialect)
            dependency_graph_path: Path to dependency graph YAML file (auto-detected if not provided)

        Raises:
            ValueError: If backend is not provided

        Example:
            >>> from database.backends import get_backend
            >>> backend = get_backend()
            >>> manager = SchemaManager(backend=backend)
        """
        if backend is None:
            raise ValueError("'backend' parameter is required")

        self.backend = backend
        self.dialect = backend.dialect

        if schema_dir is None:
            schema_dir = self._get_default_schema_dir()

        self.schema_dir = Path(schema_dir)
        
        if dependency_graph_path is None:
            dependency_graph_path = self._get_default_dependency_graph_path()
            
        self.dependency_graph_path = Path(dependency_graph_path)
        self.dependency_graph = self._load_dependency_graph()

        logger.info(
            f"SchemaManager initialized for dialect={self.dialect.value} "
            f"with {len(self.dependency_graph.get('tables', {}))} tables"
        )

    def _get_default_schema_dir(self) -> Path:
        """Get default schema directory - always use SQLite as source."""
        base_path = Path(__file__).parent / "sql"
        # Always use SQLite schema as single source of truth
        # SQL will be converted at runtime based on target dialect
        return base_path / "schema"
    
    def _get_default_dependency_graph_path(self) -> Path:
        """Get default dependency graph path - use original schema directory."""
        base_path = Path(__file__).parent / "sql"
        # Use the original schema directory for dependency graph since it's platform-agnostic
        return base_path / "schema" / "_meta" / "dependency_graph.yaml"

    def _load_dependency_graph(self) -> Dict:
        """
        Load dependency graph from YAML with comprehensive error handling.
        
        Returns:
            Dictionary containing table dependencies and creation order
            
        Raises:
            FileNotFoundError: If dependency graph file doesn't exist
            yaml.YAMLError: If YAML parsing fails
        """
        try:
            if not self.dependency_graph_path.exists():
                logger.error(f"Dependency graph not found at: {self.dependency_graph_path}")
                logger.error(f"Expected path: {self.dependency_graph_path.absolute()}")
                raise FileNotFoundError(f"Dependency graph not found: {self.dependency_graph_path}")

            logger.debug(f"Loading dependency graph from: {self.dependency_graph_path}")
            
            with open(self.dependency_graph_path, "r", encoding="utf-8") as f:
                graph = yaml.safe_load(f)
                
            if not graph or 'tables' not in graph:
                logger.warning(f"Dependency graph is empty or missing 'tables' key: {self.dependency_graph_path}")
                
            return graph
            
        except yaml.YAMLError as e:
            logger.error(f"Failed to parse YAML dependency graph: {self.dependency_graph_path}")
            logger.error(f"YAML error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error loading dependency graph: {str(e)}")
            raise

    def _load_sql_file(self, relative_path: str) -> str:
        """
        Load SQL file content and convert to target dialect with comprehensive error handling.
        
        Args:
            relative_path: Path relative to schema_dir
            
        Returns:
            SQL content converted to target dialect
            
        Raises:
            FileNotFoundError: If SQL file doesn't exist
            IOError: If file read fails
        """
        file_path = self.schema_dir / relative_path

        try:
            if not file_path.exists():
                logger.error(f"SQL file not found: {file_path}")
                logger.error(f"Schema directory: {self.schema_dir.absolute()}")
                logger.error(f"Relative path requested: {relative_path}")
                raise FileNotFoundError(f"SQL file not found: {file_path}")

            logger.debug(f"Loading SQL file: {file_path}")
            
            with open(file_path, "r", encoding="utf-8") as f:
                sqlite_sql = f.read()
                
            if not sqlite_sql or not sqlite_sql.strip():
                logger.warning(f"SQL file is empty: {file_path}")

            # Convert SQLite SQL to target dialect if needed
            if self.dialect == DatabaseDialect.SQLITE:
                return sqlite_sql
            elif self.dialect == DatabaseDialect.DATABRICKS:
                logger.debug(f"Converting SQL to Databricks dialect: {relative_path}")
                return self._convert_sqlite_to_databricks(sqlite_sql)
            else:
                # For other dialects, return as-is for now
                logger.warning(f"No conversion implemented for dialect: {self.dialect}")
                return sqlite_sql
                
        except FileNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Failed to load SQL file {file_path}: {str(e)}")
            raise

    def _convert_sqlite_to_databricks(self, sqlite_sql: str) -> str:
        """
        Convert SQLite SQL to Databricks SQL with comprehensive dialect transformation.
        
        Transformations:
        - Data type conversions (INTEGER→BIGINT, TEXT→STRING, DATETIME→TIMESTAMP)
        - Auto-increment syntax (INTEGER PRIMARY KEY AUTOINCREMENT → BIGINT ... IDENTITY PRIMARY KEY)
        - Function calls (CURRENT_TIMESTAMP → CURRENT_TIMESTAMP())
        - Delta Lake properties (adds USING DELTA and TBLPROPERTIES)
        - Removes unsupported statements (CREATE INDEX)
        """
        if not sqlite_sql or not sqlite_sql.strip():
            return sqlite_sql
        
        # Define conversion rules using the module-level ConversionRule dataclass
        conversion_rules = [
            ConversionRule(
                pattern=r'\bTEXT\b',
                replacement='STRING',
                description="Convert TEXT to STRING"
            ),
            ConversionRule(
                pattern=r'\bDATETIME\b',
                replacement='TIMESTAMP',
                description="Convert DATETIME to TIMESTAMP"
            ),
            ConversionRule(
                pattern=r'\bINTEGER\b(?!\s+PRIMARY\s+KEY\s+AUTOINCREMENT)',
                replacement='BIGINT',
                description="Convert INTEGER to BIGINT (except auto-increment columns)"
            ),
            ConversionRule(
                pattern=r'(\w+)\s+INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT',
                replacement=r'\1 BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY',
                description="Convert auto-increment primary key syntax"
            ),
            ConversionRule(
                pattern=r'\bCURRENT_TIMESTAMP\b(?!\()',
                replacement='CURRENT_TIMESTAMP()',
                description="Add parentheses to CURRENT_TIMESTAMP function"
            ),
            ConversionRule(
                pattern=r'CREATE\s+INDEX\s+IF\s+NOT\s+EXISTS\s+\w+\s+ON\s+\w+\([^)]+\);\s*',
                replacement='',
                flags=re.IGNORECASE | re.MULTILINE,
                description="Remove CREATE INDEX statements"
            ),
        ]
        
        # Apply conversions line by line to preserve comments
        def convert_line(line: str) -> str:
            """Apply conversions to a single line, skipping comment lines."""
            if line.strip().startswith('--'):
                return line  # Preserve comments unchanged
            
            result = line
            for rule in conversion_rules:
                result = re.sub(rule.pattern, rule.replacement, result, flags=rule.flags)
            return result
        
        # Process line by line
        lines = sqlite_sql.split('\n')
        converted_lines = [convert_line(line) for line in lines]
        databricks_sql = '\n'.join(converted_lines)
        
        # Add Delta Lake properties to CREATE TABLE statements
        databricks_sql = self._add_delta_properties(databricks_sql)
        
        return databricks_sql
    
    def _add_delta_properties(self, sql: str) -> str:
        """
        Add USING DELTA and TBLPROPERTIES to CREATE TABLE statements.
        
        Ensures that USING DELTA and TBLPROPERTIES are properly integrated
        into the CREATE TABLE statement, not treated as separate statements.
        """
        if 'CREATE TABLE' not in sql.upper() or 'TBLPROPERTIES' in sql.upper():
            return sql
        
        return self._find_and_enhance_create_table_statements(sql)
    
    def _find_and_enhance_create_table_statements(self, text: str) -> str:
        """
        Find and enhance CREATE TABLE statements with Delta Lake properties.
        
        Iterates through SQL text, identifies CREATE TABLE statements, and adds
        USING DELTA and TBLPROPERTIES if not already present.
        
        Args:
            text: SQL text potentially containing CREATE TABLE statements
            
        Returns:
            Enhanced SQL with Delta properties added to CREATE TABLE statements
        """
        import re
        
        result = ""
        i = 0
        
        while i < len(text):
            # Find next CREATE TABLE
            match = re.search(r'\bCREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\w+', text[i:], re.IGNORECASE)
            if not match:
                result += text[i:]
                break
            
            # Add everything before this CREATE TABLE
            result += text[i:i + match.start()]
            
            # Find the complete CREATE TABLE statement
            start_pos = i + match.start()
            end_pos = self._find_create_table_boundary(text, start_pos, check_delta_properties=False)
            
            create_table_stmt = text[start_pos:end_pos + 1]
            
            # Enhance this CREATE TABLE statement if not already enhanced
            if 'TBLPROPERTIES' not in create_table_stmt.upper() and 'USING DELTA' not in create_table_stmt.upper():
                enhanced_stmt = self._enhance_create_table_with_delta(create_table_stmt)
                result += enhanced_stmt
            else:
                result += create_table_stmt
            
            i = end_pos + 1
        
        return result
    
    def _enhance_create_table_with_delta(self, statement: str) -> str:
        """
        Transform a CREATE TABLE statement to include Delta Lake properties.
        
        Args:
            statement: A complete CREATE TABLE statement
            
        Returns:
            The statement with USING DELTA and TBLPROPERTIES added
        """
        # Remove the trailing semicolon and whitespace
        statement = statement.rstrip().rstrip(';')
        
        # Add Delta properties as part of the same statement
        enhanced = f"""{statement}
USING DELTA
TBLPROPERTIES(
    'delta.feature.allowColumnDefaults' = 'supported',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
);"""
        
        return enhanced
    
    def _find_create_table_boundary(
        self, 
        sql: str, 
        start: int, 
        check_delta_properties: bool = False
    ) -> int:
        """
        Find the complete end of a CREATE TABLE statement, handling nested parentheses properly.
        
        This method correctly handles:
        - Nested parentheses (e.g., FOREIGN KEY constraints)
        - String literals with SQL-standard escaping ('')
        - Optional USING DELTA and TBLPROPERTIES clauses
        
        Args:
            sql: The full SQL text
            start: Start position of the CREATE TABLE statement
            check_delta_properties: If True, continues parsing past semicolons
                                   if followed by USING DELTA or TBLPROPERTIES
            
        Returns:
            End position of the complete CREATE TABLE statement
            
        Examples:
            >>> # Simple CREATE TABLE
            >>> sql = "CREATE TABLE foo (id INT);"
            >>> end = manager._find_create_table_boundary(sql, 0)
            >>> sql[:end+1]
            'CREATE TABLE foo (id INT);'
            
            >>> # CREATE TABLE with USING DELTA
            >>> sql = "CREATE TABLE foo (id INT);\\nUSING DELTA\\nTBLPROPERTIES(...);"
            >>> end = manager._find_create_table_boundary(sql, 0, check_delta_properties=True)
            >>> # Returns position after final semicolon
        """
        if not sql or start >= len(sql):
            return len(sql) - 1 if sql else 0
        
        i = start
        paren_depth = 0
        in_string = False
        quote_char = None
        
        while i < len(sql):
            char = sql[i]
            
            if not in_string:
                if char in ("'", '"'):
                    in_string = True
                    quote_char = char
                elif char == '(':
                    paren_depth += 1
                elif char == ')':
                    paren_depth -= 1
                elif char == ';' and paren_depth == 0:
                    if check_delta_properties:
                        # Check if followed by USING DELTA or TBLPROPERTIES
                        next_content = sql[i+1:i+100].strip().upper()
                        if next_content.startswith(('USING DELTA', 'TBLPROPERTIES')):
                            # Continue parsing - this semicolon is not the end
                            i += 1
                            continue
                    # This is the end of the CREATE TABLE statement
                    return i
            else:
                # SQL-standard string escaping: '' (doubled quote)
                if char == quote_char:
                    # Check if this is an escaped quote
                    if i + 1 < len(sql) and sql[i + 1] == quote_char:
                        # Escaped quote, skip both characters
                        i += 1
                    else:
                        # End of string
                        in_string = False
                        quote_char = None
            
            i += 1
        
        return len(sql) - 1

    def _execute_sql(self, sql: str, description: str, dry_run: bool = False):
        """
        Execute SQL with comprehensive logging, error handling, and dry-run support.
        
        Args:
            sql: SQL to execute (may contain multiple statements)
            description: Human-readable description for logging
            dry_run: If True, only log what would be executed
        
        Raises:
            Exception: Re-raises any database execution errors with context
        """
        if dry_run:
            logger.info(f"[DRY RUN] Would execute: {description}")
            logger.debug(f"SQL preview:\n{sql[:500]}{'...' if len(sql) > 500 else ''}")
            return
        
        logger.info(f"Executing: {description}")

        try:
            if self.dialect == DatabaseDialect.DATABRICKS:
                # Databricks requires statement-by-statement execution
                statements = self._split_sql_statements(sql)
                self._execute_databricks_statements(statements, description)
            elif self.dialect == DatabaseDialect.SQLITE:
                # SQLite's execute_command can only handle one statement at a time
                # Split and execute each statement separately
                statements = self._split_sql_statements(sql)
                self._execute_sqlite_statements(statements, description)
            else:
                # PostgreSQL and others - attempt multi-statement execution
                # Use backend interface - try execute_command first (for DDL)
                self.backend.execute_command(sql)

            logger.success(f"✅ Completed: {description}")
            
        except Exception as e:
            logger.error(f"❌ Failed: {description}")
            logger.error(f"Error: {str(e)}")
            
            # Log the problematic SQL for debugging (truncated)
            sql_preview = sql[:1000] + "..." if len(sql) > 1000 else sql
            logger.debug(f"SQL that failed:\n{sql_preview}")
            
            raise
    
    def _execute_databricks_statements(self, statements: List[str], description: str):
        """
        Execute a list of SQL statements for Databricks with detailed logging.
        
        Args:
            statements: List of SQL statements to execute
            description: Description for logging context
        """
        if not statements:
            logger.warning(f"No statements to execute for: {description}")
            return
        
        total_statements = len(statements)
        logger.info(f"  Executing {total_statements} statement{'s' if total_statements > 1 else ''}")
        
        for i, stmt in enumerate(statements, 1):
            if not stmt or not stmt.strip():
                continue
                
            logger.info(f"  Executing statement {i}/{total_statements}")

            try:
                # Use backend interface
                self.backend.execute_command(stmt)
                
            except Exception as e:
                # Enhanced error reporting for statement-level failures
                logger.error(f"  ❌ Statement {i}/{total_statements} failed")
                logger.error(f"  Statement preview: {stmt[:200]}{'...' if len(stmt) > 200 else ''}")
                
                # Re-raise with additional context
                raise Exception(f"Statement {i}/{total_statements} failed in {description}: {str(e)}") from e

    def _execute_sqlite_statements(self, statements: List[str], description: str):
        """
        Execute a list of SQL statements for SQLite with detailed logging.

        Args:
            statements: List of SQL statements to execute
            description: Description for logging context
        """
        if not statements:
            logger.warning(f"No statements to execute for: {description}")
            return

        total_statements = len(statements)
        logger.debug(f"  Executing {total_statements} statement{'s' if total_statements > 1 else ''}")

        for i, stmt in enumerate(statements, 1):
            if not stmt or not stmt.strip():
                continue

            logger.debug(f"  Executing statement {i}/{total_statements}")

            try:
                # Use backend interface
                self.backend.execute_command(stmt)

            except Exception as e:
                # Enhanced error reporting for statement-level failures
                logger.error(f"  ❌ Statement {i}/{total_statements} failed")
                logger.error(f"  Statement preview: {stmt[:200]}{'...' if len(stmt) > 200 else ''}")

                # Re-raise with additional context
                raise Exception(f"Statement {i}/{total_statements} failed in {description}: {str(e)}") from e

    def _split_sql_statements(self, sql: str) -> List[str]:
        """
        Split SQL into individual statements for Databricks with proper handling of multi-clause statements.
        
        Args:
            sql: Multi-statement SQL string
            
        Returns:
            List of individual SQL statements, properly formed for Databricks execution
        """
        import re
        from typing import List, Tuple
        
        def clean_sql(sql: str) -> str:
            """Remove comments and normalize whitespace."""
            # Remove -- comments
            sql = re.sub(r'--.*?$', '', sql, flags=re.MULTILINE)
            # Remove /* */ comments
            sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
            return sql.strip()
        
        def find_statement_boundaries(sql: str) -> List[Tuple[int, int]]:
            """Find proper statement boundaries considering Databricks syntax."""
            boundaries = []
            i = 0
            while i < len(sql):
                # Find start of next statement (skip whitespace)
                while i < len(sql) and sql[i].isspace():
                    i += 1
                if i >= len(sql):
                    break
                    
                start = i
                
                # Determine statement type
                statement_upper = sql[i:i+50].upper()
                
                if statement_upper.startswith('CREATE TABLE'):
                    # For CREATE TABLE, find the complete statement including USING DELTA and TBLPROPERTIES
                    end = self._find_create_table_boundary(sql, i, check_delta_properties=True)
                elif statement_upper.startswith(('ALTER TABLE', 'DROP TABLE', 'CREATE INDEX')):
                    # For other statements, find next semicolon
                    end = self._find_simple_statement_end(sql, i)
                else:
                    # Default: find next semicolon
                    end = self._find_simple_statement_end(sql, i)
                
                if end > start:
                    boundaries.append((start, end))
                    i = end + 1
                else:
                    break
            
            return boundaries
        
        def extract_statements(sql: str, boundaries: List[Tuple[int, int]]) -> List[str]:
            """Extract statements based on boundaries."""
            statements = []
            for start, end in boundaries:
                stmt = sql[start:end+1].strip()
                if stmt and not stmt.isspace():
                    statements.append(stmt)
            return statements
        
        # Process the SQL
        clean_sql_text = clean_sql(sql)
        if not clean_sql_text:
            return []
            
        boundaries = find_statement_boundaries(clean_sql_text)
        statements = extract_statements(clean_sql_text, boundaries)
        
        # Apply Databricks-specific syntax fixes
        if self.dialect == DatabaseDialect.DATABRICKS:
            statements = self._apply_databricks_syntax_fixes(statements)
            
        return statements
    
    def _find_simple_statement_end(self, sql: str, start: int) -> int:
        """
        Find the end of a simple SQL statement (next semicolon not in string).
        
        Handles SQL-standard string escaping where quotes are doubled ('').
        
        Args:
            sql: The full SQL text
            start: Start position to search from
            
        Returns:
            Position of the statement-ending semicolon
        """
        if not sql or start >= len(sql):
            return len(sql) - 1 if sql else 0
        
        i = start
        in_string = False
        quote_char = None
        
        while i < len(sql):
            char = sql[i]
            
            if not in_string:
                if char in ("'", '"'):
                    in_string = True
                    quote_char = char
                elif char == ';':
                    return i
            else:
                # SQL-standard string escaping: '' (doubled quote)
                if char == quote_char:
                    # Check if this is an escaped quote
                    if i + 1 < len(sql) and sql[i + 1] == quote_char:
                        # Escaped quote, skip both characters
                        i += 1
                    else:
                        # End of string
                        in_string = False
                        quote_char = None
            
            i += 1
        
        return len(sql) - 1

    def _apply_databricks_syntax_fixes(self, statements: List[str]) -> List[str]:
        """
        Apply Databricks-specific syntax fixes to SQL statements.
        
        Handles Databricks limitations and requirements:
        - Removes unsupported "IF NOT EXISTS" in ALTER TABLE constraints
        - Removes unsupported ON DELETE/UPDATE cascade actions
        - Filters out foreign key constraints to non-primary key columns
        - Processes CREATE TABLE constraints for Unity Catalog compatibility
        
        Args:
            statements: List of SQL statements to fix
            
        Returns:
            List of Databricks-compatible SQL statements
        """
        import re
        
        def is_alter_table_add_constraint(stmt: str) -> bool:
            return stmt.strip().upper().startswith('ALTER TABLE') and 'ADD CONSTRAINT' in stmt.upper()
        
        def is_create_table(stmt: str) -> bool:
            return stmt.strip().upper().startswith('CREATE TABLE')
        
        def fix_alter_table_constraints(stmt: str) -> Optional[str]:
            """Fix ALTER TABLE ADD CONSTRAINT statements for Databricks."""
            # Skip foreign key constraints that reference non-primary key columns
            if 'REFERENCES CONTENT_CHUNKS(CONTENT_CHECKSUM)' in stmt.upper():
                logger.warning(f"Skipping FK constraint to non-primary key: {stmt.strip()[:100]}...")
                return None  # Skip this statement
            
            # Remove "IF NOT EXISTS" (not supported in Databricks)
            stmt = re.sub(
                r'ADD\s+CONSTRAINT\s+IF\s+NOT\s+EXISTS\s+',
                'ADD CONSTRAINT ',
                stmt,
                flags=re.IGNORECASE
            )
            
            # Remove ON DELETE/UPDATE actions (not supported in Databricks)
            stmt = re.sub(
                r'\s+ON\s+(DELETE|UPDATE)\s+(CASCADE|SET\s+NULL|SET\s+DEFAULT|RESTRICT|NO\s+ACTION)',
                '',
                stmt,
                flags=re.IGNORECASE
            )
            
            return stmt
        
        def fix_create_table(stmt: str) -> Optional[str]:
            """Fix CREATE TABLE statements for Databricks Unity Catalog."""
            return self._remove_unsupported_constraints_from_create_table(stmt)
        
        # Define fix rules
        fix_rules = [
            StatementFix(
                condition=is_alter_table_add_constraint,
                action=fix_alter_table_constraints,
                description="Fix ALTER TABLE ADD CONSTRAINT for Databricks"
            ),
            StatementFix(
                condition=is_create_table,
                action=fix_create_table,
                description="Fix CREATE TABLE for Unity Catalog"
            ),
        ]
        
        # Apply fixes
        fixed_statements = []
        
        for stmt in statements:
            if not stmt or not stmt.strip():
                continue
                
            # Apply applicable fixes
            fixed_stmt = stmt
            for rule in fix_rules:
                if rule.condition(stmt):
                    result = rule.action(fixed_stmt)
                    if result is None:
                        # Statement should be skipped
                        fixed_stmt = None
                        break
                    else:
                        fixed_stmt = result
            
            # Add to results if not skipped
            if fixed_stmt is not None:
                fixed_statements.append(fixed_stmt)
        
        return fixed_statements
    
    def _remove_unsupported_constraints_from_create_table(self, sql: str) -> str:
        """
        Remove unsupported constraints from CREATE TABLE statements for Databricks.
        
        Databricks limitations in CREATE TABLE:
        - Only supports PRIMARY KEY and FOREIGN KEY constraints  
        - UNIQUE and CHECK constraints must be added separately or omitted
        - LOCATION clause conflicts with Unity Catalog managed tables
        
        Databricks enhancements applied:
        - DEFAULT values are preserved and enabled via TBLPROPERTIES
        - Automatically adds 'delta.feature.allowColumnDefaults' = 'supported'
        - Maintains proper Unity Catalog compatibility
        
        Args:
            sql: CREATE TABLE SQL statement (may already include USING DELTA/TBLPROPERTIES)
            
        Returns:
            Fixed SQL statement with unsupported constraints removed, 
            DEFAULT values preserved, and proper Databricks syntax
        """
        import re
        
        # First, extract everything after the table definition closing parenthesis
        # This includes: COMMENT, USING DELTA, TBLPROPERTIES, LOCATION, etc.
        # We need to preserve these while processing the table definition itself
        
        # Find the closing parenthesis of the table definition
        # We need to be careful not to match parentheses inside the column definitions
        paren_depth = 0
        table_def_end = -1
        in_string = False
        quote_char = None
        
        for i, char in enumerate(sql):
            if not in_string:
                if char in ("'", '"'):
                    in_string = True
                    quote_char = char
                elif char == '(':
                    paren_depth += 1
                elif char == ')':
                    paren_depth -= 1
                    if paren_depth == 0:
                        # Found the closing parenthesis of the table definition
                        table_def_end = i
                        break
            else:
                # Handle SQL-standard string escaping
                if char == quote_char:
                    if i + 1 < len(sql) and sql[i + 1] == quote_char:
                        # Escaped quote, skip next char
                        continue
                    else:
                        in_string = False
                        quote_char = None
        
        # Split into table definition and post-table clauses
        if table_def_end > 0:
            table_definition = sql[:table_def_end]
            post_table_clauses = sql[table_def_end + 1:].strip()  # +1 to skip the closing )
        else:
            # No closing parenthesis found, treat entire SQL as table definition
            table_definition = sql
            post_table_clauses = ""
        
        # Process the table definition to remove unsupported constraints
        # Split by lines and filter out UNIQUE and CHECK constraints
        lines = table_definition.split('\n')
        filtered_lines = []
        
        skip_next_lines = False
        constraint_depth = 0
        
        for line in lines:
            line_upper = line.strip().upper()
            
            # Skip empty lines during processing but keep structure
            if not line_upper:
                if not skip_next_lines:
                    filtered_lines.append(line)
                continue
            
            # Check if this line starts a UNIQUE constraint
            if re.match(r'.*CONSTRAINT\s+\w+\s+UNIQUE\s*', line_upper):
                skip_next_lines = True
                constraint_depth = line.count('(') - line.count(')')
                continue
            
            # Check if this line starts a CHECK constraint  
            elif re.match(r'.*CONSTRAINT\s+\w+\s+CHECK\s*', line_upper):
                skip_next_lines = True
                constraint_depth = line.count('(') - line.count(')')
                continue
            
            # If we're skipping constraint lines, track parentheses depth
            elif skip_next_lines:
                constraint_depth += line.count('(') - line.count(')')
                if constraint_depth <= 0:
                    skip_next_lines = False
                continue
            
            # Keep this line (column definition, supported constraint, etc.)
            else:
                filtered_lines.append(line)
        
        # Rejoin the filtered table definition
        table_definition = '\n'.join(filtered_lines)
        
        # Clean up trailing commas from the table definition
        lines = table_definition.split('\n')
        
        # Find the last line with actual content
        for i in range(len(lines) - 1, -1, -1):
            line = lines[i].strip()
            if line:
                # Remove trailing comma from the last content line
                if line.endswith(','):
                    lines[i] = lines[i].rstrip().rstrip(',')
                break
        
        # Rejoin table definition
        table_definition = '\n'.join(lines).rstrip()
        
        # Now process the post-table clauses
        # Remove LOCATION clause (Unity Catalog manages this)
        post_table_clauses = re.sub(
            r'\s*LOCATION\s+[\'"][^\'\"]*[\'"]',
            '',
            post_table_clauses,
            flags=re.IGNORECASE
        )
        
        # Reconstruct the complete CREATE TABLE statement
        sql = table_definition + '\n)'
        
        # Add back post-table clauses if they exist
        if post_table_clauses.strip():
            # Clean up: remove leading/trailing semicolons and whitespace
            post_table_clauses = post_table_clauses.strip().lstrip(';').strip().rstrip(';').strip()
            if post_table_clauses:
                sql += '\n' + post_table_clauses
        
        # Check if we need to add allowColumnDefaults for DEFAULT values
        # Only add if it's not already present
        has_default_values = 'DEFAULT' in sql.upper()
        already_has_allowcolumndefaults = 'allowColumnDefaults' in sql
        
        if has_default_values and not already_has_allowcolumndefaults:
            if 'TBLPROPERTIES' in sql.upper():
                # Find existing TBLPROPERTIES and append to them
                # Must handle TBLPROPERTIES that might span multiple lines
                tblprops_pattern = r'(TBLPROPERTIES\s*\(\s*(?:[^()]*|\([^)]*\))*)\)'
                match = re.search(tblprops_pattern, sql, re.DOTALL | re.IGNORECASE)
                if match:
                    existing_props = match.group(1).rstrip()
                    # Add comma if there are existing properties
                    if existing_props.strip().endswith(',') or "'" in existing_props:
                        separator = ",\n    "
                    else:
                        separator = "\n    "
                    sql = sql.replace(
                        match.group(0), 
                        f"{existing_props}{separator}'delta.feature.allowColumnDefaults' = 'supported'\n)"
                    )
            else:
                # No existing TBLPROPERTIES, add new one
                # Must add TBLPROPERTIES before any semicolon
                # Check if we have USING DELTA already
                if 'USING DELTA' not in sql.upper():
                    sql += "\nUSING DELTA"
                
                # Add TBLPROPERTIES at the end (before semicolon if present)
                sql += "\nTBLPROPERTIES('delta.feature.allowColumnDefaults' = 'supported')"
        
        # Ensure the statement ends with a semicolon
        if not sql.rstrip().endswith(';'):
            sql += ';'
        
        return sql

    def create_schema(
        self,
        components: Optional[List[SchemaComponent]] = None,
        specific_tables: Optional[List[str]] = None,
        dry_run: bool = False,
    ) -> Dict[str, List[str]]:
        """
        Create schema with fine-grained control.

        Args:
            components: Which components to create (default: TABLES only)
            specific_tables: Create only these tables (with dependencies)
            dry_run: Print SQL without executing

        Returns:
            Dictionary of created objects by component type

        Example:
            >>> # Create all tables
            >>> manager.create_schema()
            >>>
            >>> # Create specific table with dependencies
            >>> manager.create_schema(specific_tables=["faq_audit_log"])
            >>>
            >>> # Dry run to see execution plan
            >>> manager.create_schema(dry_run=True)
        """
        if components is None:
            # Default: only tables (constraints are inline)
            components = [SchemaComponent.TABLES]

        # Expand ALL to specific components
        if SchemaComponent.ALL in components:
            components = [SchemaComponent.TABLES]

        created = {comp.value: [] for comp in components}

        logger.info(f"Creating schema for dialect={self.dialect.value}")
        logger.info(f"Components: {[c.value for c in components]}")

        # Phase 1: Tables
        if SchemaComponent.TABLES in components:
            tables_created = self._create_tables(specific_tables, dry_run)
            created[SchemaComponent.TABLES.value] = tables_created

        logger.success("✅ Schema creation completed")
        self._print_summary(created)

        return created

    def _create_tables(
        self,
        specific_tables: Optional[List[str]],
        dry_run: bool,
    ) -> List[str]:
        """Create tables in dependency order."""
        tables_config = self.dependency_graph.get("tables", {})

        if specific_tables:
            tables_to_create = self._resolve_dependencies(specific_tables, tables_config)
        else:
            tables_to_create = list(tables_config.keys())

        # Sort by dependency order
        tables_to_create.sort(key=lambda t: tables_config[t].get("order", 999))

        created = []
        for table_name in tables_to_create:
            table_info = tables_config[table_name]
            sql_file = table_info["file"]
            sql = self._load_sql_file(sql_file)

            self._execute_sql(sql, f"Creating table: {table_name}", dry_run)
            created.append(table_name)

        return created

    def _resolve_dependencies(
        self, table_names: List[str], tables_config: Dict
    ) -> List[str]:
        """Resolve table dependencies recursively."""
        resolved = set()
        to_process = set(table_names)

        while to_process:
            table = to_process.pop()
            if table in resolved:
                continue

            table_info = tables_config.get(table)
            if not table_info:
                logger.warning(f"Table not found in config: {table}")
                continue

            # Add dependencies to processing queue
            deps = table_info.get("dependencies", [])
            for dep in deps:
                if dep not in resolved:
                    to_process.add(dep)

            resolved.add(table)

        return list(resolved)

    def _print_summary(self, created: Dict[str, List[str]]):
        """Print creation summary."""
        logger.info("=" * 70)
        logger.info("SCHEMA CREATION SUMMARY")
        logger.info("=" * 70)

        for component, objects in created.items():
            if objects:
                logger.info(f"{component.upper()}: {len(objects)} created")
                for obj in objects:
                    logger.info(f"  ✅ {obj}")

        logger.info("=" * 70)

    def validate_schema(self) -> SchemaValidationResult:
        """
        Validate current schema against expected schema.

        Returns:
            SchemaValidationResult with validation details

        Example:
            >>> result = manager.validate_schema()
            >>> print(result)
            >>> if not result.is_valid:
            ...     print("Missing tables:", result.missing_tables)
        """
        result = SchemaValidationResult(is_valid=True)

        try:
            # Get current tables
            if self.dialect == DatabaseDialect.SQLITE:
                query = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                # Use backend interface
                results = self.backend.execute_query(query)
                current_tables = set(row['name'] if isinstance(row, dict) else row[0] for row in results)
            else:
                # For Databricks, validation requires Spark-specific logic
                logger.warning("Schema validation not yet implemented for Databricks")
                return result

            # Expected tables
            expected_tables = set(self.dependency_graph.get("tables", {}).keys())

            # Check tables
            result.missing_tables = list(expected_tables - current_tables)
            result.extra_tables = list(current_tables - expected_tables)

            # Determine validity
            if result.missing_tables:
                result.is_valid = False

            if result.extra_tables:
                result.warnings.append(
                    f"Found {len(result.extra_tables)} unexpected tables"
                )

        except Exception as e:
            result.is_valid = False
            result.errors.append(f"Validation error: {str(e)}")

        return result

    def drop_schema(self, cascade: bool = False, dry_run: bool = False):
        """
        Drop all schema objects in reverse dependency order.

        Args:
            cascade: Use CASCADE for drops
            dry_run: Print SQL without executing

        DANGER: This drops all tables and data!
        """
        logger.warning("⚠️  DROP SCHEMA REQUESTED - THIS WILL DELETE ALL DATA!")

        if not dry_run:
            confirmation = input("Type 'DELETE ALL DATA' to confirm: ")
            if confirmation != "DELETE ALL DATA":
                logger.info("Drop cancelled by user")
                return

        cascade_clause = "CASCADE" if cascade else ""

        # Drop tables in reverse order
        tables = list(self.dependency_graph.get("tables", {}).items())
        tables.sort(key=lambda t: t[1].get("order", 999), reverse=True)

        for table_name, _ in tables:
            sql = f"DROP TABLE IF EXISTS {table_name} {cascade_clause}"
            self._execute_sql(sql, f"Dropping table: {table_name}", dry_run)

        logger.success("Schema drop completed")
