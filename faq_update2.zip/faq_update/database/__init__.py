"""
Database access module for granular impact analysis.

Provides:
- SchemaManager: Unified schema manager (Databricks + SQLite + PostgreSQL)
- DatabaseAdapter: Unified database access interface
- DatabaseConnection: Spark session and catalog access (optional, requires pyspark)
- QueryTemplates: SQL query templates and file loading
- TransactionManager: Retry logic and transaction management
- Data models: Python dataclasses for 7-table schema

Schema Tables (7):
1. content_checksums - Master content table
2. faq_questions - FAQ questions
3. faq_answers - FAQ answers
4. faq_question_sources - Question provenance
5. faq_answer_sources - Answer provenance
6. content_change_log - Change detection with diff_data (JSON)
7. faq_audit_log - Minimal audit trail

Supported Dialects:
- Databricks Unity Catalog (production)
- SQLite (local development, testing)
- PostgreSQL (future)
"""

# Dialect support (always available)
from database.dialect import (
    DatabaseDialect,
    DataTypeMapper,
    DialectFeatures,
    SQLRenderer,
)

# Backend system (Modern architecture)
from database.backends import (
    # Core interface
    IBackend,
    BackendType,
    # Factory
    BackendFactory,
    get_backend,
    reset_backend,
    # Configuration
    DatabaseConfig,
    load_config,
    # Backends
    SQLiteBackend,
    DatabricksBackend,
    # Exceptions
    BackendError,
    ConnectionError,
    QueryError,
    CommandError,
    TransactionError,
    TableNotFoundError,
    MultipleResultsError,
    ConfigurationError,
)

from database.schema_manager import (
    SchemaManager,
    SchemaComponent,
    DeploymentMode,
    SchemaValidationResult,
)

# Optional Spark dependency
try:
    from database.connection import DatabaseConnection
except ImportError:
    DatabaseConnection = None  # Spark not available

from database.models import (
    # Core Models (7 tables)
    ContentChecksum,
    FAQQuestion,
    FAQAnswer,
    FAQQuestionSource,
    FAQAnswerSource,
    ContentChangeLog,
    AuditLogEntry,
    # Helper Models
    ContentChange,
    # Enums
    ContentStatus,
    FAQStatus,
    SourceType,
    GenerationMethod,
    ChangeType,
    InvalidationReason,
    AnswerFormat,
)

# Optional Spark-dependent modules
try:
    from database.queries import QueryTemplates
except ImportError:
    QueryTemplates = None

try:
    from database.transactions import TransactionManager
except ImportError:
    TransactionManager = None

__all__ = [
    # Dialect Support
    "DatabaseDialect",
    "DataTypeMapper",
    "DialectFeatures",
    "SQLRenderer",

    # ========== Backend System ==========
    # Core Interface
    "IBackend",
    "BackendType",
    # Factory
    "BackendFactory",
    "get_backend",
    "reset_backend",
    # Configuration
    "DatabaseConfig",
    "load_config",
    # Backends
    "SQLiteBackend",
    "DatabricksBackend",
    # Exceptions
    "BackendError",
    "ConnectionError",
    "QueryError",
    "CommandError",
    "TransactionError",
    "TableNotFoundError",
    "MultipleResultsError",
    "ConfigurationError",

    # ========== Schema Management ==========
    # Schema Manager (Unified)
    "SchemaManager",
    "SchemaComponent",
    "DeploymentMode",
    "SchemaValidationResult",

    # ========== Optional Components ==========
    # Core Components
    "DatabaseConnection",
    "QueryTemplates",
    "TransactionManager",

    # ========== Data Models ==========
    # Core Models (7 tables)
    "ContentChecksum",
    "FAQQuestion",
    "FAQAnswer",
    "FAQQuestionSource",
    "FAQAnswerSource",
    "ContentChangeLog",
    "AuditLogEntry",
    # Helper Models
    "ContentChange",
    # Enums
    "ContentStatus",
    "FAQStatus",
    "SourceType",
    "GenerationMethod",
    "ChangeType",
    "InvalidationReason",
    "AnswerFormat",
]
