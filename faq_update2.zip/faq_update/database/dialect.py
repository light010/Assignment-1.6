"""
Database dialect abstraction for multi-database support.

Supports:
- Databricks Unity Catalog with Delta Lake
- SQLite (for local development/testing)
- PostgreSQL (optional, for production alternatives)
"""

from enum import Enum
from typing import Dict, Optional


class DatabaseDialect(str, Enum):
    """Supported database dialects."""

    DATABRICKS = "databricks"
    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"


class DataTypeMapper:
    """Maps data types across different SQL dialects."""

    # Type mapping: canonical_type -> {dialect: dialect_type}
    TYPE_MAPPINGS = {
        "STRING": {
            DatabaseDialect.DATABRICKS: "STRING",
            DatabaseDialect.SQLITE: "TEXT",
            DatabaseDialect.POSTGRESQL: "TEXT",
        },
        "BIGINT": {
            DatabaseDialect.DATABRICKS: "BIGINT",
            DatabaseDialect.SQLITE: "INTEGER",
            DatabaseDialect.POSTGRESQL: "BIGINT",
        },
        "DOUBLE": {
            DatabaseDialect.DATABRICKS: "DOUBLE",
            DatabaseDialect.SQLITE: "REAL",
            DatabaseDialect.POSTGRESQL: "DOUBLE PRECISION",
        },
        "BOOLEAN": {
            DatabaseDialect.DATABRICKS: "BOOLEAN",
            DatabaseDialect.SQLITE: "INTEGER",  # 0/1
            DatabaseDialect.POSTGRESQL: "BOOLEAN",
        },
        "TIMESTAMP": {
            DatabaseDialect.DATABRICKS: "TIMESTAMP",
            DatabaseDialect.SQLITE: "TEXT",  # ISO8601 format
            DatabaseDialect.POSTGRESQL: "TIMESTAMP",
        },
    }

    @classmethod
    def map_type(cls, canonical_type: str, dialect: DatabaseDialect) -> str:
        """
        Map canonical type to dialect-specific type.

        Args:
            canonical_type: Canonical type name (e.g., "STRING")
            dialect: Target database dialect

        Returns:
            Dialect-specific type (e.g., "TEXT" for SQLite)
        """
        if canonical_type not in cls.TYPE_MAPPINGS:
            raise ValueError(f"Unknown type: {canonical_type}")

        return cls.TYPE_MAPPINGS[canonical_type][dialect]


class DialectFeatures:
    """Feature support matrix for different dialects."""

    FEATURES = {
        "supports_if_not_exists": {
            DatabaseDialect.DATABRICKS: True,
            DatabaseDialect.SQLITE: True,
            DatabaseDialect.POSTGRESQL: True,
        },
        "supports_alter_table_constraints": {
            DatabaseDialect.DATABRICKS: True,
            DatabaseDialect.SQLITE: False,  # Must be inline
            DatabaseDialect.POSTGRESQL: True,
        },
        "supports_generated_identity": {
            DatabaseDialect.DATABRICKS: True,
            DatabaseDialect.SQLITE: False,  # Uses AUTOINCREMENT
            DatabaseDialect.POSTGRESQL: True,
        },
        "supports_table_properties": {
            DatabaseDialect.DATABRICKS: True,  # TBLPROPERTIES
            DatabaseDialect.SQLITE: False,
            DatabaseDialect.POSTGRESQL: False,
        },
        "supports_cascade_delete": {
            DatabaseDialect.DATABRICKS: True,
            DatabaseDialect.SQLITE: True,  # With PRAGMA foreign_keys=ON
            DatabaseDialect.POSTGRESQL: True,
        },
        "supports_check_constraints": {
            DatabaseDialect.DATABRICKS: True,
            DatabaseDialect.SQLITE: True,
            DatabaseDialect.POSTGRESQL: True,
        },
        "requires_foreign_key_pragma": {
            DatabaseDialect.DATABRICKS: False,
            DatabaseDialect.SQLITE: True,  # PRAGMA foreign_keys = ON
            DatabaseDialect.POSTGRESQL: False,
        },
    }

    @classmethod
    def supports(cls, feature: str, dialect: DatabaseDialect) -> bool:
        """
        Check if dialect supports a feature.

        Args:
            feature: Feature name
            dialect: Database dialect

        Returns:
            True if supported, False otherwise
        """
        if feature not in cls.FEATURES:
            raise ValueError(f"Unknown feature: {feature}")

        return cls.FEATURES[feature][dialect]


class SQLRenderer:
    """Renders SQL statements for different dialects."""

    @staticmethod
    def render_identity_column(
        column_name: str,
        dialect: DatabaseDialect,
        not_null: bool = True,
    ) -> str:
        """
        Render auto-incrementing identity column.

        Args:
            column_name: Column name
            dialect: Target dialect
            not_null: Whether column is NOT NULL

        Returns:
            SQL fragment for identity column
        """
        if dialect == DatabaseDialect.DATABRICKS:
            null_spec = " NOT NULL" if not_null else ""
            return f"{column_name} BIGINT{null_spec} GENERATED ALWAYS AS IDENTITY"

        elif dialect == DatabaseDialect.SQLITE:
            # SQLite AUTOINCREMENT requires PRIMARY KEY
            return f"{column_name} INTEGER PRIMARY KEY AUTOINCREMENT"

        elif dialect == DatabaseDialect.POSTGRESQL:
            # PostgreSQL supports both BIGSERIAL and GENERATED ALWAYS
            null_spec = " NOT NULL" if not_null else ""
            return f"{column_name} BIGINT{null_spec} GENERATED ALWAYS AS IDENTITY"

        else:
            raise ValueError(f"Unsupported dialect: {dialect}")

    @staticmethod
    def render_current_timestamp(dialect: DatabaseDialect) -> str:
        """
        Render CURRENT_TIMESTAMP for dialect.

        Args:
            dialect: Target dialect

        Returns:
            SQL fragment for current timestamp
        """
        if dialect == DatabaseDialect.DATABRICKS:
            return "CURRENT_TIMESTAMP()"
        else:
            # SQLite and PostgreSQL both use CURRENT_TIMESTAMP
            return "CURRENT_TIMESTAMP"

    @staticmethod
    def render_boolean_value(value: bool, dialect: DatabaseDialect) -> str:
        """
        Render boolean value for dialect.

        Args:
            value: Boolean value
            dialect: Target dialect

        Returns:
            SQL representation of boolean
        """
        if dialect == DatabaseDialect.SQLITE:
            return "1" if value else "0"
        else:
            return "TRUE" if value else "FALSE"

    @staticmethod
    def render_table_properties(
        dialect: DatabaseDialect,
        properties: Optional[Dict[str, str]] = None,
    ) -> str:
        """
        Render table properties clause (Databricks only).

        Args:
            dialect: Target dialect
            properties: Table properties dict

        Returns:
            SQL fragment for table properties (empty string for non-Databricks)
        """
        if dialect != DatabaseDialect.DATABRICKS:
            return ""

        if not properties:
            # Default Databricks Delta Lake properties
            properties = {
                "delta.enableChangeDataFeed": "true",
                "delta.autoOptimize.optimizeWrite": "true",
                "delta.feature.allowColumnDefaults": "supported",
            }

        props_list = [f"    '{k}' = '{v}'" for k, v in properties.items()]
        props_str = ",\n".join(props_list)
        return f"\nTBLPROPERTIES (\n{props_str}\n)"

    @staticmethod
    def render_constraint_definition(
        table_name: str,
        constraint_name: str,
        constraint_sql: str,
        dialect: DatabaseDialect,
        inline: bool = False,
    ) -> str:
        """
        Render constraint definition.

        Args:
            table_name: Table name
            constraint_name: Constraint name
            constraint_sql: Constraint SQL (e.g., "PRIMARY KEY (id)")
            dialect: Target dialect
            inline: Whether to render inline (for SQLite CREATE TABLE)

        Returns:
            SQL fragment for constraint
        """
        if inline:
            # Inline constraint (used in CREATE TABLE for SQLite)
            return f"CONSTRAINT {constraint_name} {constraint_sql}"

        # ALTER TABLE constraint (Databricks, PostgreSQL)
        if DialectFeatures.supports("supports_alter_table_constraints", dialect):
            if_not_exists = "IF NOT EXISTS " if dialect == DatabaseDialect.DATABRICKS else ""
            return (
                f"ALTER TABLE {table_name} ADD CONSTRAINT {if_not_exists}"
                f"{constraint_name} {constraint_sql};"
            )
        else:
            raise ValueError(
                f"Dialect {dialect} does not support ALTER TABLE constraints. "
                f"Use inline=True."
            )
