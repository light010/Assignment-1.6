"""
Generate SQLite schemas from Databricks schemas.

This script automatically converts Databricks SQL table definitions
to SQLite-compatible SQL, eliminating the need to maintain duplicate schemas.

Usage:
    python generate_sqlite_schemas.py
    python generate_sqlite_schemas.py --dry-run
    python generate_sqlite_schemas.py --validate

Design:
- Databricks schema is canonical (source of truth)
- SQLite schema is generated (never edit manually)
- Simple, single-purpose script
"""

import argparse
import sys
from pathlib import Path
from typing import List, Tuple

from loguru import logger

from granular_impact.database.schema_converter import SchemaConverter


class SQLiteSchemaGenerator:
    """
    Generates SQLite schemas from Databricks schemas.

    Architecture:
    - Reads all .sql files from schema/tables/
    - Converts each using SchemaConverter
    - Writes to schema_sqlite/tables/
    - Also handles dependency_graph.yaml
    """

    def __init__(self, base_dir: Path = None):
        """
        Initialize generator.

        Args:
            base_dir: Base directory (default: granular_impact/database/sql)
        """
        if base_dir is None:
            base_dir = Path(__file__).parent / "sql"

        self.base_dir = Path(base_dir)
        self.databricks_dir = self.base_dir / "schema" / "tables"
        self.sqlite_dir = self.base_dir / "schema_sqlite" / "tables"

        logger.info(f"Databricks schema dir: {self.databricks_dir}")
        logger.info(f"SQLite schema dir: {self.sqlite_dir}")

    def generate_all(self, dry_run: bool = False) -> List[Tuple[str, str]]:
        """
        Generate all SQLite schemas from Databricks schemas.

        Args:
            dry_run: If True, don't write files

        Returns:
            List of (file_name, status) tuples
        """
        if not self.databricks_dir.exists():
            logger.error(f"Databricks schema directory not found: {self.databricks_dir}")
            sys.exit(1)

        # Create SQLite directory if needed
        if not dry_run and not self.sqlite_dir.exists():
            self.sqlite_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created SQLite schema directory: {self.sqlite_dir}")

        # Get all Databricks SQL files
        sql_files = sorted(self.databricks_dir.glob("*.sql"))

        if not sql_files:
            logger.warning(f"No SQL files found in {self.databricks_dir}")
            return []

        logger.info(f"Found {len(sql_files)} Databricks schema files")

        results = []
        for sql_file in sql_files:
            result = self._generate_single(sql_file, dry_run=dry_run)
            results.append((sql_file.name, result))

        return results

    def _generate_single(self, databricks_file: Path, dry_run: bool = False) -> str:
        """
        Generate single SQLite schema from Databricks schema.

        Args:
            databricks_file: Path to Databricks SQL file
            dry_run: If True, don't write file

        Returns:
            Status message
        """
        logger.info(f"Processing: {databricks_file.name}")

        # Read Databricks SQL
        try:
            databricks_sql = databricks_file.read_text(encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to read {databricks_file.name}: {e}")
            return f"ERROR: {e}"

        # Convert to SQLite
        try:
            sqlite_sql = SchemaConverter.databricks_to_sqlite(databricks_sql)
        except Exception as e:
            logger.error(f"Failed to convert {databricks_file.name}: {e}")
            return f"ERROR: {e}"

        # Write SQLite SQL
        sqlite_file = self.sqlite_dir / databricks_file.name

        if dry_run:
            logger.info(f"[DRY RUN] Would write: {sqlite_file}")
            return "DRY_RUN"
        else:
            try:
                sqlite_file.write_text(sqlite_sql, encoding="utf-8")
                logger.success(f"Generated: {sqlite_file.name}")
                return "SUCCESS"
            except Exception as e:
                logger.error(f"Failed to write {sqlite_file.name}: {e}")
                return f"ERROR: {e}"

    def validate_schemas(self) -> bool:
        """
        Validate that SQLite schemas match what would be generated.

        Returns:
            True if all schemas match, False otherwise
        """
        logger.info("Validating SQLite schemas...")

        sql_files = sorted(self.databricks_dir.glob("*.sql"))
        all_match = True

        for databricks_file in sql_files:
            sqlite_file = self.sqlite_dir / databricks_file.name

            if not sqlite_file.exists():
                logger.error(f"Missing SQLite schema: {sqlite_file.name}")
                all_match = False
                continue

            # Read both files
            databricks_sql = databricks_file.read_text(encoding="utf-8")
            existing_sqlite_sql = sqlite_file.read_text(encoding="utf-8")

            # Generate what SQLite should be
            expected_sqlite_sql = SchemaConverter.databricks_to_sqlite(databricks_sql)

            # Compare (normalize whitespace)
            existing_normalized = "\n".join(line.rstrip() for line in existing_sqlite_sql.split("\n")).strip()
            expected_normalized = "\n".join(line.rstrip() for line in expected_sqlite_sql.split("\n")).strip()

            if existing_normalized == expected_normalized:
                logger.success(f"✅ {sqlite_file.name} matches generated schema")
            else:
                logger.error(f"❌ {sqlite_file.name} does NOT match generated schema")
                logger.debug(f"Expected:\n{expected_normalized[:500]}")
                logger.debug(f"Actual:\n{existing_normalized[:500]}")
                all_match = False

        return all_match


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Generate SQLite schemas from Databricks schemas",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate all SQLite schemas
  python generate_sqlite_schemas.py

  # Dry run (don't write files)
  python generate_sqlite_schemas.py --dry-run

  # Validate existing schemas
  python generate_sqlite_schemas.py --validate
        """,
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be generated without writing files",
    )

    parser.add_argument(
        "--validate",
        action="store_true",
        help="Validate that existing SQLite schemas match generated schemas",
    )

    args = parser.parse_args()

    generator = SQLiteSchemaGenerator()

    if args.validate:
        logger.info("=" * 70)
        logger.info("VALIDATION MODE")
        logger.info("=" * 70)

        all_match = generator.validate_schemas()

        logger.info("=" * 70)
        if all_match:
            logger.success("✅ All SQLite schemas are up-to-date")
            sys.exit(0)
        else:
            logger.error("❌ Some SQLite schemas are out of date")
            logger.info("Run without --validate to regenerate schemas")
            sys.exit(1)

    else:
        logger.info("=" * 70)
        logger.info("GENERATING SQLITE SCHEMAS FROM DATABRICKS")
        logger.info("=" * 70)

        if args.dry_run:
            logger.info("[DRY RUN MODE]")

        results = generator.generate_all(dry_run=args.dry_run)

        # Print summary
        logger.info("=" * 70)
        logger.info("GENERATION SUMMARY")
        logger.info("=" * 70)

        success_count = sum(1 for _, status in results if status == "SUCCESS" or status == "DRY_RUN")
        error_count = sum(1 for _, status in results if status.startswith("ERROR"))

        logger.info(f"Total files: {len(results)}")
        logger.info(f"Success: {success_count}")
        if error_count > 0:
            logger.error(f"Errors: {error_count}")

        for file_name, status in results:
            if status.startswith("ERROR"):
                logger.error(f"  ❌ {file_name}: {status}")
            elif status == "DRY_RUN":
                logger.info(f"  🔍 {file_name}: {status}")
            else:
                logger.success(f"  ✅ {file_name}: {status}")

        logger.info("=" * 70)

        if error_count > 0:
            sys.exit(1)
        else:
            if args.dry_run:
                logger.info("Dry run completed successfully")
            else:
                logger.success("All SQLite schemas generated successfully!")


if __name__ == "__main__":
    main()
