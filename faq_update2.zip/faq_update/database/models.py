"""
Data models for granular impact analysis.

Defines dataclass models matching the 9-table database schema:

Core Tables (9):
0. ContentRepo - Repository of source content files and metadata
1. ContentChecksum - Master content table (checksum is THE identity)
2. FAQQuestion - FAQ questions (content-agnostic)
3. FAQAnswer - FAQ answers (1:1 with questions)
4. FAQQuestionSource - Question provenance with temporal validity
5. FAQAnswerSource - Answer provenance with temporal validity
6. ContentChangeLog - Change detection with diff_data (JSON), similarity scores, impact metrics
7. AuditLogEntry - Minimal audit trail (FK references only)
8. FAQImpactDecision - POST-EXECUTION audit log of FAQ impacts (what was done)

Helper Models:
- ContentChange - Transient model for change detection phase (not persisted)

Enums:
- ContentStatus, FAQStatus, SourceType, GenerationMethod
- ChangeType, InvalidationReason, AnswerFormat, FileStatus
- ImpactAction, ImpactReasonCode, ImpactType

IMPORTANT - Referential Integrity:
    Databricks Unity Catalog only supports FK constraints to PRIMARY KEY columns.
    FK constraints to content_chunks.content_checksum (non-PK) cannot be enforced
    at database level and are documented as "maintained by application logic".

    Use utils.validators for application-level FK validation:
        from utils.validators import validate_question_sources, validate_answer_sources

        # Before inserting to faq_question_sources
        validate_question_sources(question_sources_df, adapter)

        # Before inserting to faq_answer_sources
        validate_answer_sources(answer_sources_df, adapter)
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


# ============================================================================
# VALIDATION EXCEPTIONS
# ============================================================================


class ValidationError(Exception):
    """Base exception for all validation errors."""
    pass


class ChecksumValidationError(ValidationError):
    """Raised when checksum validation fails."""
    pass


class ScoreValidationError(ValidationError):
    """Raised when score validation fails."""
    pass


class StatusValidationError(ValidationError):
    """Raised when status validation fails."""
    pass


class FormatValidationError(ValidationError):
    """Raised when format validation fails."""
    pass


# Note: ReferentialIntegrityError moved to utils.validators
# Import from utils.validators for application-level FK validation


# ============================================================================
# ENUMS
# ============================================================================


class ContentStatus(str, Enum):
    """Content status values."""

    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"


class FAQStatus(str, Enum):
    """FAQ status values."""

    ACTIVE = "active"
    INVALIDATED = "invalidated"
    ARCHIVED = "archived"
    DELETED = "deleted"


class SourceType(str, Enum):
    """FAQ source types."""

    FROM_DOCUMENTS = "from_documents"
    FROM_USER_QUERIES = "from_user_queries"
    FROM_MANUAL = "from_manual"
    FROM_VALIDATION = "from_validation"


class GenerationMethod(str, Enum):
    """FAQ generation methods."""

    LLM_GENERATED = "llm_generated"
    HUMAN_WRITTEN = "human_written"
    EXTRACTED = "extracted"


class ChangeType(str, Enum):
    """Content change types."""

    NEW_CONTENT = "new_content"
    MODIFIED_CONTENT = "modified_content"
    UNCHANGED_CONTENT = "unchanged_content"
    DELETED_CONTENT = "deleted_content"
    LOCATION_CHANGE = "location_change"


class InvalidationReason(str, Enum):
    """Provenance invalidation reasons."""

    CONTENT_CHANGED = "content_changed"
    CONTENT_DELETED = "content_deleted"
    QUALITY_ISSUE = "quality_issue"
    MANUAL = "manual"
    SELECTIVE_IMPACT = "selective_impact"


class AnswerFormat(str, Enum):
    """Answer text formats."""

    HTML = "html"
    MARKDOWN = "markdown"
    PLAIN = "plain"


class FileStatus(str, Enum):
    """File status values for content_repo."""

    ACTIVE = "Active"
    INACTIVE = "Inactive"
    ARCHIVED = "Archived"


class ImpactAction(str, Enum):
    """Impact action types for faq_impact_decisions."""

    CREATE = "CREATE"
    INACTIVATE = "INACTIVATE"
    REGENERATE = "REGENERATE"


class ImpactReasonCode(str, Enum):
    """Impact reason codes for faq_impact_decisions."""

    # New content reasons
    NEW_CONTENT = "NEW_CONTENT"
    NEW_CONTENT_ADDED = "NEW_CONTENT_ADDED"

    # Deleted content reasons
    SOLE_SOURCE_DELETED = "SOLE_SOURCE_DELETED"
    PRIMARY_SOURCE_DELETED = "PRIMARY_SOURCE_DELETED"
    PARTIAL_SOURCE_DELETED = "PARTIAL_SOURCE_DELETED"

    # Modified content reasons
    HIGH_SIMILARITY_CHANGE = "HIGH_SIMILARITY_CHANGE"
    MODERATE_SIMILARITY_CHANGE = "MODERATE_SIMILARITY_CHANGE"
    LOW_SIMILARITY_CHANGE = "LOW_SIMILARITY_CHANGE"
    TOKEN_OVERLAP_DETECTED = "TOKEN_OVERLAP_DETECTED"
    SEMANTIC_DRIFT_DETECTED = "SEMANTIC_DRIFT_DETECTED"

    # Cascade reasons
    CASCADE_FROM_QUESTION = "CASCADE_FROM_QUESTION"
    CASCADE_FROM_ANSWER = "CASCADE_FROM_ANSWER"

    # Manual reasons
    MANUAL_OVERRIDE = "MANUAL_OVERRIDE"


class ImpactType(str, Enum):
    """Impact type classification for faq_impact_decisions."""

    DIRECT = "direct"
    INDIRECT_TOKEN_OVERLAP = "indirect_token_overlap"
    CASCADE = "cascade"


# ============================================================================
# CORE TABLES (from V8)
# ============================================================================


@dataclass
class ContentRepo:
    """
    Repository of source content files and their metadata.

    Maps to: content_repo table

    Tracks raw source files with their extracted content paths.
    This table serves as the source-of-truth for content ingestion.
    """

    raw_file_nme: str
    created_dt: datetime = field(default_factory=datetime.now)
    last_modified_dt: datetime = field(default_factory=datetime.now)

    ud_source_file_id: Optional[int] = None  # AUTOINCREMENT primary key
    raw_file_type: Optional[str] = None
    raw_file_version_nbr: int = 1
    raw_file_path: Optional[str] = None
    extracted_markdown_file_path: Optional[str] = None
    title_nme: Optional[str] = None
    file_status: Optional[FileStatus] = None

    def __post_init__(self):
        """Validate ContentRepo data."""
        # Required field validation
        if not self.raw_file_nme or not self.raw_file_nme.strip():
            raise ValidationError("raw_file_nme is required and cannot be empty")
        
        # File status validation
        if self.file_status is not None and self.file_status not in FileStatus:
            raise StatusValidationError(f"file_status must be one of: {[fs.value for fs in FileStatus]}")
        
        # Version number validation
        if self.raw_file_version_nbr < 1:
            raise ValidationError("raw_file_version_nbr must be >= 1")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "ud_source_file_id": self.ud_source_file_id,
            "raw_file_nme": self.raw_file_nme,
            "raw_file_type": self.raw_file_type,
            "raw_file_version_nbr": self.raw_file_version_nbr,
            "raw_file_path": self.raw_file_path,
            "extracted_markdown_file_path": self.extracted_markdown_file_path,
            "title_nme": self.title_nme,
            "file_status": self.file_status.value if self.file_status else None,
            "created_dt": self.created_dt,
            "last_modified_dt": self.last_modified_dt,
        }


@dataclass
class ContentChecksum:
    """
    Represents a unique content identity (master content table).

    Maps to: content_checksums table

    The content_checksum is THE identity. Location metadata (file_name,
    page_number, etc.) is for human reference only, NOT for content analysis.
    """

    content_checksum: str  # SHA-256 hash (64 chars) - THE identity
    status: ContentStatus = ContentStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)

    # Content Properties
    file_type: Optional[str] = None  # pdf, html, docx, xml, confluence
    content_format: Optional[str] = None  # markdown, html, plain_text
    title: Optional[str] = None

    # METADATA: Location information (for human reference only)
    file_name: Optional[str] = None
    url: Optional[str] = None
    source_file_path: Optional[str] = None
    file_version: Optional[str] = None

    # Content Storage
    markdown_file_path: Optional[str] = None

    def __post_init__(self):
        """Validate ContentChecksum data."""
        # Checksum validation (SHA-256 format)
        if not self.content_checksum or not isinstance(self.content_checksum, str):
            raise ChecksumValidationError("content_checksum is required and must be a string")
        
        if len(self.content_checksum) != 64:
            raise ChecksumValidationError(f"content_checksum must be exactly 64 characters (SHA-256), got {len(self.content_checksum)}")
        
        # Verify hexadecimal format
        try:
            int(self.content_checksum, 16)
        except ValueError:
            raise ChecksumValidationError("content_checksum must be a valid hexadecimal string")
        
        # Status validation
        if self.status not in ContentStatus:
            raise StatusValidationError(f"status must be one of: {[cs.value for cs in ContentStatus]}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "content_checksum": self.content_checksum,
            "file_type": self.file_type,
            "content_format": self.content_format,
            "title": self.title,
            "status": self.status.value,
            "file_name": self.file_name,
            "url": self.url,
            "source_file_path": self.source_file_path,
            "file_version": self.file_version,
            "markdown_file_path": self.markdown_file_path,
            "created_at": self.created_at,
        }


@dataclass
class FAQQuestion:
    """
    Represents an FAQ question (content-agnostic).

    Maps to: faq_questions table
    """

    question_id: Optional[str] = None  # Primary key
    question_text: str = ""
    status: FAQStatus = FAQStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    modified_at: datetime = field(default_factory=datetime.now)

    # Metadata
    source_type: Optional[SourceType] = None
    generation_method: Optional[GenerationMethod] = None

    def __post_init__(self):
        """Validate FAQQuestion data."""
        # Question text validation
        if not self.question_text or not self.question_text.strip():
            raise ValidationError("question_text is required and cannot be empty")
        
        # Status validation
        if self.status not in FAQStatus:
            raise StatusValidationError(f"status must be one of: {[fs.value for fs in FAQStatus]}")
        
        # Source type validation
        if self.source_type is not None and self.source_type not in SourceType:
            raise ValidationError(f"source_type must be one of: {[st.value for st in SourceType]}")
        
        # Generation method validation
        if self.generation_method is not None and self.generation_method not in GenerationMethod:
            raise ValidationError(f"generation_method must be one of: {[gm.value for gm in GenerationMethod]}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "question_id": self.question_id,
            "question_text": self.question_text,
            "source_type": self.source_type.value if self.source_type else None,
            "generation_method": self.generation_method.value if self.generation_method else None,
            "status": self.status.value,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
        }


@dataclass
class FAQQuestionSource:
    """
    Question provenance - which content inspired each question.

    Maps to: faq_question_sources table

    Supports temporal validity:
    - is_valid: Current validity status
    - valid_from/valid_until: Validity time range
    - invalidation_reason: Why it was invalidated
    - invalidated_by_change_id: Which content change caused invalidation
    
    ⚠️ IMPORTANT - Referential Integrity:
    The content_checksum field references content_chunks.content_checksum,
    which is NOT a primary key in Databricks. This foreign key constraint
    is NOT enforced at the database level due to Databricks limitations.
    
    Application code MUST validate that:
    1. content_checksum exists in content_chunks table before insert
    2. Do not delete from content_chunks if referenced here
    
    Use validate_content_checksum_exists() method before persisting.
    """

    question_id: str
    content_checksum: str
    is_valid: bool = True
    valid_from: datetime = field(default_factory=datetime.now)
    created_at: datetime = field(default_factory=datetime.now)

    source_id: Optional[int] = None  # IDENTITY column
    is_primary_source: bool = False
    contribution_weight: Optional[float] = None  # 0.0 to 1.0
    valid_until: Optional[datetime] = None
    invalidation_reason: Optional[InvalidationReason] = None
    invalidated_by_change_id: Optional[int] = None

    def __post_init__(self):
        """Validate FAQQuestionSource data."""
        # Required fields validation
        if not self.question_id or not self.question_id.strip():
            raise ValidationError("question_id is required and cannot be empty")
        
        if not self.content_checksum or not isinstance(self.content_checksum, str):
            raise ChecksumValidationError("content_checksum is required and must be a string")
        
        # Checksum validation (SHA-256 format)
        if len(self.content_checksum) != 64:
            raise ChecksumValidationError(f"content_checksum must be exactly 64 characters (SHA-256), got {len(self.content_checksum)}")
        
        try:
            int(self.content_checksum, 16)
        except ValueError:
            raise ChecksumValidationError("content_checksum must be a valid hexadecimal string")
        
        # Contribution weight validation
        if self.contribution_weight is not None:
            if not isinstance(self.contribution_weight, (int, float)):
                raise ScoreValidationError("contribution_weight must be a number")
            if not (0.0 <= self.contribution_weight <= 1.0):
                raise ScoreValidationError(f"contribution_weight must be between 0.0 and 1.0, got {self.contribution_weight}")
        
        # Invalidation reason validation
        if self.invalidation_reason is not None and self.invalidation_reason not in InvalidationReason:
            raise ValidationError(f"invalidation_reason must be one of: {[ir.value for ir in InvalidationReason]}")

    # Note: FK validation to content_chunks.content_checksum moved to utils.validators
    # Use validate_question_sources(df, adapter) for batch validation before insert

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "source_id": self.source_id,
            "question_id": self.question_id,
            "content_checksum": self.content_checksum,
            "is_primary_source": self.is_primary_source,
            "contribution_weight": self.contribution_weight,
            "is_valid": self.is_valid,
            "valid_from": self.valid_from,
            "valid_until": self.valid_until,
            "invalidation_reason": self.invalidation_reason.value if self.invalidation_reason else None,
            "invalidated_by_change_id": self.invalidated_by_change_id,
            "created_at": self.created_at,
        }


@dataclass
class FAQAnswer:
    """
    Represents an FAQ answer (linked to question 1:1).

    Maps to: faq_answers table
    """

    question_id: str
    answer_text: str
    status: FAQStatus = FAQStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    modified_at: datetime = field(default_factory=datetime.now)

    answer_id: Optional[str] = None  # String ID
    answer_format: AnswerFormat = AnswerFormat.HTML
    confidence_score: Optional[float] = None  # 0.0 to 1.0

    def __post_init__(self):
        """Validate FAQAnswer data."""
        # Required fields validation
        if not self.question_id or not self.question_id.strip():
            raise ValidationError("question_id is required and cannot be empty")
        
        if not self.answer_text or not self.answer_text.strip():
            raise ValidationError("answer_text is required and cannot be empty")
        
        # Status validation
        if self.status not in FAQStatus:
            raise StatusValidationError(f"status must be one of: {[fs.value for fs in FAQStatus]}")
        
        # Answer format validation
        if self.answer_format not in AnswerFormat:
            raise FormatValidationError(f"answer_format must be one of: {[af.value for af in AnswerFormat]}")
        
        # Confidence score validation
        if self.confidence_score is not None:
            if not isinstance(self.confidence_score, (int, float)):
                raise ScoreValidationError("confidence_score must be a number")
            if not (0.0 <= self.confidence_score <= 1.0):
                raise ScoreValidationError(f"confidence_score must be between 0.0 and 1.0, got {self.confidence_score}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "answer_id": self.answer_id,
            "question_id": self.question_id,
            "answer_text": self.answer_text,
            "answer_format": self.answer_format.value,
            "confidence_score": self.confidence_score,
            "status": self.status.value,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
        }


@dataclass
class FAQAnswerSource:
    """
    Answer provenance - which content provided answer information.

    Maps to: faq_answer_sources table

    Supports temporal validity similar to FAQQuestionSource.
    
    ⚠️ IMPORTANT - Referential Integrity:
    The content_checksum field references content_chunks.content_checksum,
    which is NOT a primary key in Databricks. This foreign key constraint
    is NOT enforced at the database level due to Databricks limitations.
    
    Application code MUST validate that:
    1. content_checksum exists in content_chunks table before insert
    2. Do not delete from content_chunks if referenced here
    
    Use validate_content_checksum_exists() method before persisting.
    """

    answer_id: str
    content_checksum: str
    is_valid: bool = True
    valid_from: datetime = field(default_factory=datetime.now)
    created_at: datetime = field(default_factory=datetime.now)

    source_id: Optional[int] = None  # IDENTITY column
    is_primary_source: bool = False
    contribution_weight: Optional[float] = None  # 0.0 to 1.0
    context_employed: Optional[str] = None  # JSON: which sections/paragraphs used
    valid_until: Optional[datetime] = None
    invalidation_reason: Optional[InvalidationReason] = None
    invalidated_by_change_id: Optional[int] = None

    def __post_init__(self):
        """Validate FAQAnswerSource data."""
        # Required fields validation
        if not self.answer_id or not self.answer_id.strip():
            raise ValidationError("answer_id is required and cannot be empty")
        
        if not self.content_checksum or not isinstance(self.content_checksum, str):
            raise ChecksumValidationError("content_checksum is required and must be a string")
        
        # Checksum validation (SHA-256 format)
        if len(self.content_checksum) != 64:
            raise ChecksumValidationError(f"content_checksum must be exactly 64 characters (SHA-256), got {len(self.content_checksum)}")
        
        try:
            int(self.content_checksum, 16)
        except ValueError:
            raise ChecksumValidationError("content_checksum must be a valid hexadecimal string")
        
        # Contribution weight validation
        if self.contribution_weight is not None:
            if not isinstance(self.contribution_weight, (int, float)):
                raise ScoreValidationError("contribution_weight must be a number")
            if not (0.0 <= self.contribution_weight <= 1.0):
                raise ScoreValidationError(f"contribution_weight must be between 0.0 and 1.0, got {self.contribution_weight}")
        
        # Invalidation reason validation
        if self.invalidation_reason is not None and self.invalidation_reason not in InvalidationReason:
            raise ValidationError(f"invalidation_reason must be one of: {[ir.value for ir in InvalidationReason]}")

    # Note: FK validation to content_chunks.content_checksum moved to utils.validators
    # Use validate_answer_sources(df, adapter) for batch validation before insert

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "source_id": self.source_id,
            "answer_id": self.answer_id,
            "content_checksum": self.content_checksum,
            "is_primary_source": self.is_primary_source,
            "contribution_weight": self.contribution_weight,
            "context_employed": self.context_employed,
            "is_valid": self.is_valid,
            "valid_from": self.valid_from,
            "valid_until": self.valid_until,
            "invalidation_reason": self.invalidation_reason.value if self.invalidation_reason else None,
            "invalidated_by_change_id": self.invalidated_by_change_id,
            "created_at": self.created_at,
        }


@dataclass
class ContentChangeLog:
    """
    Content change detection log with granular impact analysis.

    Maps to: content_change_log table

    Tracks similarity scores and granular impact counts
    (affected_question_count, affected_answer_count) instead of blanket invalidation.
    """

    file_name: str
    requires_faq_regeneration: bool
    detection_run_id: str
    content_checksum: Optional[str] = None  # NEW checksum (NULL for deleted_content)
    detection_timestamp: datetime = field(default_factory=datetime.now)
    total_faqs_at_risk: int = 0  # Total FAQs linked to old checksum
    affected_question_count: int = 0  # Questions actually affected
    affected_answer_count: int = 0  # Answers actually affected

    change_id: Optional[int] = None  # IDENTITY column
    previous_checksum: Optional[str] = None  # NULL for new content
    change_type: Optional[ChangeType] = None
    similarity_score: Optional[float] = None  # 0.0 to 1.0
    similarity_method: Optional[str] = None  # bm25, jaccard, cosine, levenshtein, hybrid
    diff_data: Optional[str] = None  # JSON: structured diff data

    def __post_init__(self):
        """Validate ContentChangeLog data."""
        # File name validation
        if not self.file_name or not self.file_name.strip():
            raise ValidationError("file_name is required and cannot be empty")

        if not self.detection_run_id or not self.detection_run_id.strip():
            raise ValidationError("detection_run_id is required and cannot be empty")

        # Current checksum validation (SHA-256 format)
        # Allow empty/None for deleted_content
        if self.content_checksum:
            if not isinstance(self.content_checksum, str):
                raise ChecksumValidationError("content_checksum must be a string")

            if len(self.content_checksum) != 64:
                raise ChecksumValidationError(f"content_checksum must be exactly 64 characters (SHA-256), got {len(self.content_checksum)}")

            try:
                int(self.content_checksum, 16)
            except ValueError:
                raise ChecksumValidationError("content_checksum must be a valid hexadecimal string")
        elif self.change_type != ChangeType.DELETED_CONTENT:
            # content_checksum is required for all change types except DELETED_CONTENT
            raise ChecksumValidationError("content_checksum is required and must be a string (except for deleted_content)")
        
        # Previous checksum validation (if provided)
        if self.previous_checksum:
            if not isinstance(self.previous_checksum, str):
                raise ChecksumValidationError("previous_checksum must be a string")
            if len(self.previous_checksum) != 64:
                raise ChecksumValidationError(f"previous_checksum must be exactly 64 characters (SHA-256), got {len(self.previous_checksum)}")
            try:
                int(self.previous_checksum, 16)
            except ValueError:
                raise ChecksumValidationError("previous_checksum must be a valid hexadecimal string")
        
        # Similarity score validation
        if self.similarity_score is not None:
            if not isinstance(self.similarity_score, (int, float)):
                raise ScoreValidationError("similarity_score must be a number")
            if not (0.0 <= self.similarity_score <= 1.0):
                raise ScoreValidationError(f"similarity_score must be between 0.0 and 1.0, got {self.similarity_score}")
        
        # Change type validation
        if self.change_type is not None and self.change_type not in ChangeType:
            raise ValidationError(f"change_type must be one of: {[ct.value for ct in ChangeType]}")
        
        # Count validation (must be non-negative)
        for field_name, value in [
            ("total_faqs_at_risk", self.total_faqs_at_risk),
            ("affected_question_count", self.affected_question_count), 
            ("affected_answer_count", self.affected_answer_count)
        ]:
            if not isinstance(value, int) or value < 0:
                raise ValidationError(f"{field_name} must be a non-negative integer, got {value}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "change_id": self.change_id,
            "content_checksum": self.content_checksum,
            "previous_checksum": self.previous_checksum,
            "file_name": self.file_name,
            "requires_faq_regeneration": self.requires_faq_regeneration,
            "change_type": self.change_type.value if self.change_type else None,
            "similarity_score": self.similarity_score,
            "similarity_method": self.similarity_method,
            "diff_data": self.diff_data,
            "total_faqs_at_risk": self.total_faqs_at_risk,
            "affected_question_count": self.affected_question_count,
            "affected_answer_count": self.affected_answer_count,
            "detection_run_id": self.detection_run_id,
            "detection_timestamp": self.detection_timestamp,
        }


@dataclass
class AuditLogEntry:
    """
    Minimal audit trail for FAQ operations.

    Maps to: faq_audit_log table

    Tracks which FAQs were affected by which content changes via foreign key references.
    """

    audit_id: Optional[int] = None  # IDENTITY column
    change_id: Optional[int] = None  # FK to content_change_log
    question_id: Optional[str] = None  # FK to faq_questions
    answer_id: Optional[str] = None  # FK to faq_answers
    detection_run_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        """Validate AuditLogEntry data."""
        # At least one reference must be provided (either question_id or answer_id)
        if not self.question_id and not self.answer_id:
            raise ValidationError("At least one of question_id or answer_id must be provided")
        
        # If provided, IDs must not be empty strings
        if self.question_id is not None and not self.question_id.strip():
            raise ValidationError("question_id cannot be empty if provided")
        
        if self.answer_id is not None and not self.answer_id.strip():
            raise ValidationError("answer_id cannot be empty if provided")
        
        if self.detection_run_id is not None and not self.detection_run_id.strip():
            raise ValidationError("detection_run_id cannot be empty if provided")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "audit_id": self.audit_id,
            "change_id": self.change_id,
            "question_id": self.question_id,
            "answer_id": self.answer_id,
            "detection_run_id": self.detection_run_id,
            "created_at": self.created_at,
        }


@dataclass
class FAQImpactDecision:
    """
    POST-EXECUTION audit log of FAQ impacts.

    Maps to: faq_impact_decisions table

    Records WHAT WAS DONE after execution (not before).
    All entity_ids are real database IDs (no placeholders).
    Complete audit trail for all change types.

    This table differs from the ImpactDecision model in faq_impact/core/models
    which is used for PLANNING decisions. This model records actual EXECUTED decisions.
    """

    change_id: int
    change_type: ChangeType
    entity_type: str  # 'question' or 'answer'
    entity_id: str  # Real question_id or answer_id (exists in DB)
    action: ImpactAction
    reason_code: ImpactReasonCode
    created_at: datetime = field(default_factory=datetime.now)

    decision_id: Optional[int] = None  # AUTOINCREMENT primary key
    content_checksum: Optional[str] = None  # Which checksum triggered this
    source_count: Optional[int] = None  # How many sources entity had at decision time
    similarity_score: Optional[float] = None  # For modified_content (0.0-1.0)
    impact_type: Optional[ImpactType] = None  # 'direct', 'indirect_token_overlap', 'cascade'

    def __post_init__(self):
        """Validate FAQImpactDecision data."""
        # Required fields validation
        if not isinstance(self.change_id, int) or self.change_id <= 0:
            raise ValidationError("change_id must be a positive integer")

        if self.change_type not in ChangeType:
            raise ValidationError(f"change_type must be one of: {[ct.value for ct in ChangeType]}")

        if not self.entity_type or self.entity_type not in ['question', 'answer']:
            raise ValidationError("entity_type must be 'question' or 'answer'")

        if not self.entity_id or not self.entity_id.strip():
            raise ValidationError("entity_id is required and cannot be empty")

        if self.action not in ImpactAction:
            raise ValidationError(f"action must be one of: {[a.value for a in ImpactAction]}")

        if self.reason_code not in ImpactReasonCode:
            raise ValidationError(f"reason_code must be one of: {[r.value for r in ImpactReasonCode]}")

        # Content checksum validation (if provided)
        if self.content_checksum is not None:
            if not isinstance(self.content_checksum, str):
                raise ChecksumValidationError("content_checksum must be a string")
            if len(self.content_checksum) != 64:
                raise ChecksumValidationError(f"content_checksum must be exactly 64 characters (SHA-256), got {len(self.content_checksum)}")
            try:
                int(self.content_checksum, 16)
            except ValueError:
                raise ChecksumValidationError("content_checksum must be a valid hexadecimal string")

        # Source count validation
        if self.source_count is not None:
            if not isinstance(self.source_count, int) or self.source_count < 0:
                raise ValidationError("source_count must be a non-negative integer")

        # Similarity score validation
        if self.similarity_score is not None:
            if not isinstance(self.similarity_score, (int, float)):
                raise ScoreValidationError("similarity_score must be a number")
            if not (0.0 <= self.similarity_score <= 1.0):
                raise ScoreValidationError(f"similarity_score must be between 0.0 and 1.0, got {self.similarity_score}")

        # Impact type validation
        if self.impact_type is not None and self.impact_type not in ImpactType:
            raise ValidationError(f"impact_type must be one of: {[it.value for it in ImpactType]}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for DataFrame."""
        return {
            "decision_id": self.decision_id,
            "change_id": self.change_id,
            "change_type": self.change_type.value,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "action": self.action.value,
            "reason_code": self.reason_code.value,
            "content_checksum": self.content_checksum,
            "source_count": self.source_count,
            "similarity_score": self.similarity_score,
            "impact_type": self.impact_type.value if self.impact_type else None,
            "created_at": self.created_at,
        }


# ============================================================================
# HELPER MODELS (not directly mapped to tables)
# ============================================================================


@dataclass
class ContentChange:
    """
    Represents a detected change in content (used during change detection phase).

    This is a transient model used before persisting to ContentChangeLog.
    """

    old_checksum: str  # Previous content checksum
    new_checksum: str  # New content checksum
    change_type: ChangeType
    detected_at: datetime = field(default_factory=datetime.now)

    file_name: Optional[str] = None
    page_number: Optional[int] = None
    old_content: Optional[str] = None
    new_content: Optional[str] = None
    similarity_score: Optional[float] = None
    llm_friendly_diff: Optional[str] = None  # LLM-friendly diff for MODIFIED content

    @property
    def requires_faq_regeneration(self) -> bool:
        """
        Calculate whether this change requires FAQ regeneration.

        Only UNCHANGED_CONTENT does NOT require regeneration.

        Returns:
            True for NEW/MODIFIED/DELETED changes, False for UNCHANGED
        """
        return self.change_type in [
            ChangeType.NEW_CONTENT,
            ChangeType.MODIFIED_CONTENT,
            ChangeType.DELETED_CONTENT,
        ]

    @property
    def similarity_method(self) -> str:
        """
        Return the similarity method used.

        Always returns "hybrid" for this implementation.

        Returns:
            "hybrid"
        """
        return "hybrid"

    @property
    def llm_diff(self) -> Optional[str]:
        """
        Alias for llm_friendly_diff for compatibility with DetectionResult interface.

        Returns:
            llm_friendly_diff value
        """
        return self.llm_friendly_diff

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "old_checksum": self.old_checksum,
            "new_checksum": self.new_checksum,
            "change_type": self.change_type.value,
            "detected_at": self.detected_at,
            "file_name": self.file_name,
            "page_number": self.page_number,
            "old_content": self.old_content,
            "new_content": self.new_content,
            "similarity_score": self.similarity_score,
            "llm_friendly_diff": self.llm_friendly_diff,
        }

    def to_change_log_dict(self, run_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Convert ContentChange to database ContentChangeLog format.

        This method converts a transient ContentChange object (used during detection)
        to the format expected by the content_change_log table in the database.

        Args:
            run_id: Optional detection run ID. If not provided, uses empty string.

        Returns:
            Dictionary with all required fields for content_change_log table

        Field Mapping:
            - content_checksum: new_checksum (current version)
            - previous_checksum: old_checksum (None if new content)
            - file_name: file_name
            - requires_faq_regeneration: 1 for changes, 0 for unchanged
            - change_type: change_type enum value
            - similarity_score: similarity_score (0.0 to 1.0)
            - similarity_method: "hybrid" (hardcoded)
            - diff_data: llm_friendly_diff (JSON string or None)
            - total_faqs_at_risk: 0 (calculated later by FAQ impact analysis)
            - affected_question_count: 0 (calculated later)
            - affected_answer_count: 0 (calculated later)
            - detection_run_id: run_id
            - detection_timestamp: detected_at

        Example:
            >>> change = ContentChange(
            ...     old_checksum="abc123",
            ...     new_checksum="def456",
            ...     change_type=ChangeType.MODIFIED_CONTENT,
            ...     similarity_score=0.95,
            ...     detected_at=datetime.now(),
            ...     file_name="test.pdf"
            ... )
            >>> db_dict = change.to_change_log_dict(run_id="run_001")
            >>> db_dict['requires_faq_regeneration']
            1
            >>> db_dict['similarity_method']
            'hybrid'
        """
        # Calculate requires_faq_regeneration based on change type
        # Only UNCHANGED_CONTENT does NOT require regeneration
        requires_regen = self.change_type in [
            ChangeType.NEW_CONTENT,
            ChangeType.MODIFIED_CONTENT,
            ChangeType.DELETED_CONTENT,
        ]

        # ✅ FIX: For DELETED content, use old_checksum as content_checksum
        # content_checksum must never be empty (database constraint)
        content_checksum = self.new_checksum if self.new_checksum else self.old_checksum
        previous_checksum = self.old_checksum if self.new_checksum else None

        return {
            # Checksums
            'content_checksum': content_checksum,  # ✅ Never empty
            'previous_checksum': previous_checksum,

            # File metadata
            'file_name': self.file_name,

            # Change classification
            'requires_faq_regeneration': 1 if requires_regen else 0,
            'change_type': self.change_type.value,

            # Similarity metrics
            'similarity_score': self.similarity_score,
            'similarity_method': 'hybrid',  # Always "hybrid" for this implementation

            # Diff data (JSON string or None)
            'diff_data': self.llm_friendly_diff,

            # Impact metrics (initialized to 0, calculated later)
            'total_faqs_at_risk': 0,
            'affected_question_count': 0,
            'affected_answer_count': 0,

            # Detection metadata
            'detection_run_id': run_id or "",
            'detection_timestamp': self.detected_at,
        }
