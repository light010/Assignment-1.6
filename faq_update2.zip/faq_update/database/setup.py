"""
Unified Database Setup - Environment Agnostic

This module provides a SIMPLE, unified interface for database setup that works
automatically in both Databricks and local environments.

Design Principles:
- SIMPLICITY FIRST: One function call to setup everything
- AUTO-DETECTION: No manual configuration needed
- TDD: All functionality is test-driven
- BACKWARD COMPATIBLE: Doesn't break existing code

Usage:
    # Notebook (simplest)
    from database.setup import quick_setup
    adapter = quick_setup()

    # Python script (more control)
    from database.setup import setup_database
    result = setup_database()
    adapter = result['adapter']

    # Get existing adapter (singleton pattern)
    from database.setup import get_adapter
    adapter = get_adapter()
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
from database import DatabaseDialect, create_adapter, SchemaManager

# Import environment detection from utility (shared across all notebooks)
sys.path.insert(0, str(Path(__file__).parent.parent))  # Ensure utility is importable
from utility.environment import is_databricks, get_workspace_root


# Singleton adapter for notebook sessions
_global_adapter = None


def get_environment_config(
    catalog: str = None,
    schema: str = None,
    db_path: str = None,
    workspace_root: Path = None
) -> Dict[str, Any]:
    """
    Auto-detect environment and return configuration.

    NO DEFAULTS - all values must be provided by caller (notebook).

    Args:
        catalog: Databricks catalog (REQUIRED for Databricks)
        schema: Databricks schema (REQUIRED for Databricks)
        db_path: Local SQLite database path (REQUIRED for local, default: "databases/granular_impact.db")
        workspace_root: Databricks workspace root (optional, will auto-detect if not provided)

    Returns:
        Configuration dictionary with all necessary settings

    Raises:
        ValueError: If required parameters are missing

    Examples:
        >>> # Local
        >>> config = get_environment_config(db_path="my.db")

        >>> # Databricks
        >>> config = get_environment_config(catalog="my_catalog", schema="my_schema")
    """
    if is_databricks():
        # Databricks environment
        if not catalog:
            raise ValueError(
                "Databricks catalog is required. "
                "Pass catalog='your_catalog' or set it in notebook."
            )
        if not schema:
            raise ValueError(
                "Databricks schema is required. "
                "Pass schema='your_schema' or set it in notebook."
            )

        # Detect or use provided workspace root
        if workspace_root is None:
            workspace_root = get_workspace_root()

        schema_dir = workspace_root / 'database' / 'sql' / 'schema'
        dependency_graph_path = workspace_root / 'database' / 'sql' / 'schema' / '_meta' / 'dependency_graph.yaml'

        return {
            'env_type': 'databricks',
            'catalog': catalog,
            'schema': schema,
            'workspace_root': workspace_root,
            'schema_dir': schema_dir,
            'dependency_graph_path': dependency_graph_path,
        }
    else:
        # Local environment
        # Detect project root
        current_file = Path(__file__).resolve()
        project_root = current_file.parent.parent  # database/setup.py -> faq_update/

        # Use same schema directory for both - dialect converter handles the differences
        schema_dir = project_root / 'database' / 'sql' / 'schema'
        dependency_graph_path = project_root / 'database' / 'sql' / 'schema' / '_meta' / 'dependency_graph.yaml'

        # Default db path if not provided
        if db_path is None:
            db_path = "databases/granular_impact.db"

        return {
            'env_type': 'local',
            'db_path': db_path,
            'project_root': project_root,
            'schema_dir': schema_dir,
            'dependency_graph_path': dependency_graph_path,
        }


def setup_database(
    catalog: Optional[str] = None,
    schema: Optional[str] = None,
    db_path: Optional[str] = None,
    workspace_root: Optional[Path] = None,
    in_memory: bool = False,
    dry_run: bool = False,
    create_tables: bool = True,
) -> Dict[str, Any]:
    """
    Setup database with auto-environment detection.

    This is the main setup function. It:
    1. Detects environment (Databricks or local)
    2. Creates appropriate adapter
    3. Creates schema tables (optional)
    4. Returns configuration and adapter

    Args:
        db_path: SQLite database path (local only, optional)
        catalog: Databricks catalog (Databricks only, optional)
        schema: Databricks schema (Databricks only, optional)
        in_memory: Use in-memory SQLite (local only, for testing)
        dry_run: Don't actually create database, just show plan
        create_tables: Whether to create tables (default: True)

    Returns:
        Dictionary with:
        - success: bool
        - env_type: 'databricks' or 'local'
        - adapter: DatabaseAdapter instance
        - config: Full configuration dict
        - db_path: (local only) Path to database
        - catalog/schema: (Databricks only)

    Examples:
        >>> # Local environment
        >>> result = setup_database()
        >>> adapter = result['adapter']
        >>> adapter.execute("SELECT * FROM faq_questions")

        >>> # In-memory for testing
        >>> result = setup_database(in_memory=True)
        >>> result['success']
        True

        >>> # Custom path
        >>> result = setup_database(db_path="data/my_db.db")
        >>> result['db_path']
        'data/my_db.db'
    """
    # Get environment configuration
    config = get_environment_config(
        catalog=catalog,
        schema=schema,
        db_path=db_path,
        workspace_root=workspace_root
    )

    # Create adapter based on environment
    if config['env_type'] == 'databricks':
        adapter = create_adapter(
            DatabaseDialect.DATABRICKS,
            catalog=config['catalog'],
            schema=config['schema']
        )

        result = {
            'success': True,
            'env_type': 'databricks',
            'adapter': adapter,
            'config': config,
            'catalog': config['catalog'],
            'schema': config['schema'],
        }
    else:
        # Local SQLite
        if in_memory:
            adapter = create_adapter(DatabaseDialect.SQLITE, in_memory=True)
            actual_db_path = ":memory:"
        else:
            actual_db_path = db_path or config['db_path']

            # Create parent directory if needed
            if not dry_run:
                Path(actual_db_path).parent.mkdir(parents=True, exist_ok=True)

            adapter = create_adapter(
                DatabaseDialect.SQLITE,
                database_path=actual_db_path
            )

        result = {
            'success': True,
            'env_type': 'local',
            'adapter': adapter,
            'config': config,
            'db_path': actual_db_path,
        }

    # Create schema if requested
    if create_tables and not dry_run:
        manager = SchemaManager(
            adapter=adapter,
            schema_dir=config.get('schema_dir'),
            dependency_graph_path=config.get('dependency_graph_path')
        )
        manager.create_schema()
        result['tables_created'] = True
    else:
        result['tables_created'] = False

    return result


def quick_setup(
    in_memory: bool = False,
    **kwargs
) -> Any:
    """
    Quick one-line setup for notebooks.

    This is the simplest way to get a working database adapter.
    Perfect for interactive notebooks.

    Args:
        in_memory: Use in-memory database (for testing)
        **kwargs: Additional arguments passed to setup_database()

    Returns:
        DatabaseAdapter ready to use

    Examples:
        >>> # In a notebook (simplest!)
        >>> from database.setup import quick_setup
        >>> db = quick_setup()
        >>> db.execute("SELECT * FROM faq_questions")

        >>> # In-memory for testing
        >>> db = quick_setup(in_memory=True)
        >>> db.fetchall("SELECT COUNT(*) FROM faq_questions")
        [(0,)]
    """
    result = setup_database(in_memory=in_memory, **kwargs)

    # Store globally for get_adapter()
    global _global_adapter
    _global_adapter = result['adapter']

    return result['adapter']


def get_adapter(**kwargs) -> Any:
    """
    Get or create database adapter (singleton pattern).

    This function maintains a single adapter per session.
    Useful in notebooks where you want to reuse the same connection.

    Args:
        **kwargs: Arguments passed to quick_setup if adapter doesn't exist

    Returns:
        DatabaseAdapter instance

    Examples:
        >>> # First call creates adapter
        >>> db1 = get_adapter()
        >>> # Second call returns same adapter
        >>> db2 = get_adapter()
        >>> db1 is db2
        True
    """
    global _global_adapter

    if _global_adapter is None:
        _global_adapter = quick_setup(**kwargs)

    return _global_adapter


def _reset_adapter():
    """
    Reset the global adapter (for testing).

    Internal use only. Tests use this to ensure clean state.
    """
    global _global_adapter
    if _global_adapter is not None:
        try:
            _global_adapter.close()
        except Exception:
            pass
    _global_adapter = None


# Convenient exports for notebooks
__all__ = [
    'quick_setup',
    'get_adapter',
    'setup_database',
    'is_databricks',
    'get_environment_config',
]
