"""
Content Chunks Ingestion

Simplified ingestion for content_chunks table using the repository pattern.
Stores individual content chunks with their checksums and text.

Design Principles:
- Simplicity first: Direct chunk insertion with FK to content_repo
- No redundant storage: Links to content_repo instead of duplicating metadata
- Efficient: Stores chunk text to avoid re-chunking
- Database agnostic: Uses repository pattern for SQLite and Databricks

Architecture:
- Business logic: ChunkIngestion class (this file)
- Database operations: Delegated to ContentRepository
- Separation of concerns: No SQL/Spark code in business logic

Version: 3.0.0 (Refactored to use repository pattern - Phase 5)
"""

from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import warnings

from database.repository import ContentRepository, ForeignKeyViolationError
from database.backends.factory import BackendFactory
from database.config import DatabaseConfig


class ChunkIngestion:
    """
    Ingest content chunks linked to files in content_repo.

    This class handles the business logic for chunk ingestion while delegating
    all database operations to ContentRepository implementation.

    The repository handles environment detection (SQLite vs Databricks) automatically,
    eliminating the need for is_databricks checks and database-specific code.

    Attributes:
        repository: ContentRepository instance for database operations
        table_name: Name of the chunks table (simple name, not qualified)

    Example:
        >>> # Local SQLite
        >>> ingestion = ChunkIngestion(db_path="databases/faq.db")
        >>>
        >>> # Databricks
        >>> ingestion = ChunkIngestion(catalog_name="prod", schema_name="faq")
        >>>
        >>> # Ingest chunks
        >>> chunks = [("Hello world", "abc123"), ("Goodbye", "def456")]
        >>> result = ingestion.ingest_chunks_for_file(
        ...     ud_source_file_id=1,
        ...     chunks_with_checksums=chunks
        ... )
        >>> print(f"Inserted {result['rows_inserted']} chunks")
    """

    def __init__(
        self,
        db_path: Optional[str] = None,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        repository: Optional[ContentRepository] = None,
        config: Optional[DatabaseConfig] = None
    ):
        """
        Initialize chunk ingestion with database configuration.

        You can either provide database parameters, config object, or inject
        a pre-configured repository directly.

        Args:
            db_path: Path to SQLite database file (for local environment)
            catalog_name: Unity Catalog name (for Databricks)
            schema_name: Schema name (for Databricks)
            repository: Optional pre-configured repository (overrides other params)
            config: Optional DatabaseConfig instance

        Raises:
            ValueError: If required parameters are missing

        Example:
            >>> # Auto-detect with factory
            >>> ingestion = ChunkIngestion(db_path="faq.db")
            >>>
            >>> # Inject custom repository (useful for testing)
            >>> from database.repository import ContentRepository
            >>> from database.backends.sqlite import SQLiteBackend
            >>> backend = SQLiteBackend(":memory:")
            >>> repo = ContentRepository(backend)
            >>> ingestion = ChunkIngestion(repository=repo)
        """
        if repository is not None:
            # Use injected repository (useful for testing)
            self.repository = repository
        else:
            # Create repository using factory
            if config is None:
                # Build config from parameters
                if db_path:
                    config = DatabaseConfig(backend='sqlite', db_path=db_path)
                elif catalog_name and schema_name:
                    config = DatabaseConfig(
                        backend='databricks',
                        catalog=catalog_name,
                        schema=schema_name
                    )
                else:
                    # Auto-detect from environment
                    config = DatabaseConfig.from_env()

            # Create backend and repository
            backend = BackendFactory.create_backend(config)
            self.repository = ContentRepository(backend)

        self.table_name = "content_chunks"

    def ingest_chunks_for_file(
        self,
        ud_source_file_id: int,
        chunks_with_checksums: List[Tuple],
        clear_existing: bool = False,
    ) -> Dict[str, Any]:
        """
        Ingest chunks for a specific file.

        This method prepares chunk data as a DataFrame and delegates insertion
        to the repository. It handles both 2-tuple and 3-tuple formats.

        Args:
            ud_source_file_id: Foreign key to content_repo
            chunks_with_checksums: List of (chunk_text, checksum) or
                                  (chunk_text, checksum, metadata) tuples
            clear_existing: If True, delete existing chunks for this file first

        Returns:
            Dict with:
                - success (bool): True if ingestion succeeded
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - error (str, optional): Error details if failed

        Example:
            >>> chunks = [
            ...     ("First chunk text", "abc123"),
            ...     ("Second chunk text", "def456")
            ... ]
            >>> result = ingestion.ingest_chunks_for_file(
            ...     ud_source_file_id=42,
            ...     chunks_with_checksums=chunks,
            ...     clear_existing=True
            ... )
            >>> assert result['success'] == True
        """
        try:
            # Validate foreign key before attempting insert
            if not self.repository.validate_file_exists(ud_source_file_id):
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": f"Invalid file_id {ud_source_file_id}: file not found in content_repo",
                }

            # Clear existing chunks for this file if requested
            if clear_existing:
                self.repository.clear_chunks_for_file(ud_source_file_id)

            # Handle empty chunks list
            if not chunks_with_checksums:
                return {
                    "success": True,
                    "rows_inserted": 0,
                    "message": "No chunks to insert",
                }

            # Prepare data: Convert tuples to DataFrame
            chunk_data = []
            for chunk_index, chunk_tuple in enumerate(chunks_with_checksums):
                # Handle both 2-tuple (chunk_text, checksum) and 3-tuple formats
                if len(chunk_tuple) == 2:
                    # Legacy format: (chunk_text, checksum)
                    chunk_text, checksum = chunk_tuple
                    metadata = None
                elif len(chunk_tuple) == 3:
                    # New format: (chunk_text, checksum, ChunkMetadata)
                    chunk_text, checksum, metadata = chunk_tuple
                else:
                    raise ValueError(
                        f"Expected 2 or 3 elements in chunk tuple, got {len(chunk_tuple)}"
                    )

                # Build chunk record with basic fields
                chunk_record = {
                    "ud_source_file_id": ud_source_file_id,
                    "chunk_index": chunk_index,
                    "content_checksum": checksum,
                    "chunk_text": chunk_text,
                    "status": "active"
                }

                # Add rich metadata if available (from HybridMarkdownChunker)
                if metadata is not None:
                    import json

                    # Store chunk_method: "recursive", "header", "no_split"
                    chunk_record["chunk_method"] = metadata.chunk_method

                    # Store headers as JSON string: '{"h1": "Title", "h2": "Section"}'
                    if metadata.headers:
                        chunk_record["chunk_headers"] = json.dumps(metadata.headers)
                    else:
                        chunk_record["chunk_headers"] = None

                    # Store position information
                    chunk_record["chunk_start_char"] = metadata.start_pos
                    chunk_record["chunk_end_char"] = metadata.end_pos
                else:
                    # No metadata available (legacy chunker or old data)
                    chunk_record["chunk_method"] = None
                    chunk_record["chunk_headers"] = None
                    chunk_record["chunk_start_char"] = None
                    chunk_record["chunk_end_char"] = None

                chunk_data.append(chunk_record)

            # Convert to DataFrame
            df = pd.DataFrame(chunk_data)

            # Ensure proper data types
            df['ud_source_file_id'] = df['ud_source_file_id'].astype('int64')
            df['chunk_index'] = df['chunk_index'].astype('int64')

            # Delegate to repository for insertion
            result = self.repository.ingest_chunks(
                chunks_df=df,
                validate=False,  # Already validated above
                validate_fk=False  # Already validated above
            )

            return result

        except ForeignKeyViolationError as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Foreign key violation: {str(e)}",
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error: {str(e)}",
                "error": str(e)
            }

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about stored chunks.

        Delegates to repository to retrieve counts and breakdowns.

        Returns:
            Dict with:
                - success (bool): True if query succeeded
                - total_chunks (int): Total number of chunks
                - unique_checksums (int): Number of unique content checksums
                - by_status (dict): Counts grouped by status
                - message (str): Status message

        Example:
            >>> stats = ingestion.get_stats()
            >>> print(f"Total chunks: {stats['total_chunks']}")
            >>> print(f"Unique content: {stats['unique_checksums']}")
        """
        try:
            # Get overall stats from repository
            stats = self.repository.get_chunk_stats()

            # Add success flag for backward compatibility
            return {
                "success": True,
                "total_chunks": stats.get('total_chunks', 0),
                "unique_checksums": stats.get('unique_checksums', 0),
                "by_status": stats.get('by_status', {}),
                "avg_chunks_per_file": stats.get('avg_chunks_per_file', 0),
                "message": "Statistics retrieved successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "total_chunks": 0,
                "unique_checksums": 0,
                "by_status": {},
                "message": f"Error retrieving stats: {str(e)}",
                "error": str(e)
            }

    def clear_all_chunks(self) -> Dict[str, Any]:
        """
        Clear all chunks from table.

        DEPRECATED: Use repository methods directly.
        This method is kept for backward compatibility.

        Returns:
            Dict with success status and message

        Example:
            >>> result = ingestion.clear_all_chunks()
            >>> print(f"Cleared {result.get('rows_deleted', 0)} chunks")
        """
        warnings.warn(
            "ChunkIngestion.clear_all_chunks() is deprecated. "
            "Use repository methods directly instead.",
            DeprecationWarning,
            stacklevel=2
        )
        try:
            result = self.repository.backend.clear_table(self.table_name)
            return result
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to clear table: {str(e)}",
                "error": str(e)
            }

    def get_chunks_for_file(
        self,
        ud_source_file_id: int,
        status: str = "active",
    ) -> List[Dict[str, Any]]:
        """
        Retrieve chunks for a specific file.

        Now uses repository method for querying.

        Args:
            ud_source_file_id: Foreign key to content_repo
            status: Filter by status (default: 'active' - currently unused)

        Returns:
            List of dicts with chunk data

        Example:
            >>> chunks = ingestion.get_chunks_for_file(ud_source_file_id=1)
            >>> for chunk in chunks:
            ...     print(f"Chunk {chunk['chunk_index']}: {chunk['chunk_text'][:50]}...")
        """
        try:
            return self.repository.get_chunks_by_file(ud_source_file_id)
        except Exception as e:
            print(f"Error retrieving chunks: {e}")
            return []

    def get_chunks_by_checksums(
        self,
        checksums: List[str],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Retrieve chunks by their checksums.

        Now uses repository method for querying.

        Args:
            checksums: List of checksums to look up

        Returns:
            Dict mapping checksum to chunk data

        Example:
            >>> checksums = ["abc123", "def456"]
            >>> chunks = ingestion.get_chunks_by_checksums(checksums)
            >>> if "abc123" in chunks:
            ...     print(chunks["abc123"]["chunk_text"])
        """
        if not checksums:
            return {}

        try:
            result_dict = {}
            for checksum in checksums:
                chunk = self.repository.get_chunk_by_checksum(checksum)
                if chunk:
                    result_dict[checksum] = chunk
            return result_dict
        except Exception as e:
            print(f"Error retrieving chunks by checksums: {e}")
            return {}

    def close(self) -> None:
        """
        Close database connections and clean up resources.

        Delegates to repository backend for cleanup.

        Example:
            >>> ingestion = ChunkIngestion(db_path="faq.db")
            >>> try:
            ...     ingestion.ingest_chunks_for_file(...)
            ... finally:
            ...     ingestion.close()
        """
        if hasattr(self.repository, 'backend') and hasattr(self.repository.backend, 'close'):
            self.repository.backend.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

    def __repr__(self) -> str:
        """String representation."""
        return f"ChunkIngestion(repository={self.repository})"


# Factory function for backward compatibility
def create_chunk_ingestion(
    db_path: Optional[str] = None,
    catalog_name: Optional[str] = None,
    schema_name: Optional[str] = None
):
    """
    Factory function to create ChunkIngestion instance with automatic environment detection.

    DEPRECATED: Use ChunkIngestion(...) directly instead.
    This function is provided for backward compatibility with existing code.

    Args:
        db_path: Path to SQLite database (for local environment)
        catalog_name: Unity Catalog name (for Databricks)
        schema_name: Schema name (for Databricks)

    Returns:
        ChunkIngestion instance configured for the current environment

    Example:
        >>> # Local environment (DEPRECATED)
        >>> ingestion = create_chunk_ingestion(db_path="/path/to/db.sqlite")
        >>>
        >>> # NEW WAY - Use ChunkIngestion directly
        >>> ingestion = ChunkIngestion(db_path="/path/to/db.sqlite")
        >>>
        >>> # Or use repository directly
        >>> from database.repository import ContentRepository
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> repo = ContentRepository(backend)
    """
    warnings.warn(
        "create_chunk_ingestion() is deprecated. "
        "Use ChunkIngestion() directly or use ContentRepository for new code.",
        DeprecationWarning,
        stacklevel=2
    )
    return ChunkIngestion(
        db_path=db_path,
        catalog_name=catalog_name,
        schema_name=schema_name
    )
