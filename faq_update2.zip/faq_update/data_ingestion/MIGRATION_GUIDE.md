# Migration Guide: Adding New Ingestion Tables

**Last Updated**: November 2025
**Architecture Version**: 2.0 (Adapter Pattern)

## Overview

This guide shows you how to create new data ingestion modules for additional database tables using the refactored adapter architecture. By following this pattern, you'll get:

- ✅ **Environment-agnostic code** (works in both SQLite and Databricks)
- ✅ **No database code to write** (reuse existing adapters)
- ✅ **Automatic error handling** (friendly messages for constraint violations)
- ✅ **Easy testing** (inject mock adapters)
- ✅ **Clean separation** (business logic vs infrastructure)

## Quick Reference

### 5-Step Process

1. **Define the table** (in SQL schema if not already done)
2. **Create ingestion class** (validation + preparation logic)
3. **Write tests** (TDD approach)
4. **Export in `__init__.py`** (make it importable)
5. **Document usage** (update README)

**Time required**: ~2 hours for a simple table, ~4 hours for complex validation

## Step-by-Step Guide

### Step 1: Define Your Table Schema

**Example**: Let's create an ingestion module for a `faq_metadata` table.

```sql
-- database/sql/schema/faq_metadata.sql
CREATE TABLE IF NOT EXISTS faq_metadata (
    metadata_id INTEGER PRIMARY KEY AUTOINCREMENT,
    faq_question_id INTEGER NOT NULL,
    metadata_key TEXT NOT NULL,
    metadata_value TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (faq_question_id) REFERENCES faq_questions(question_id),
    UNIQUE(faq_question_id, metadata_key)
);
```

**Key points**:
- Identify required columns (`NOT NULL`)
- Identify unique constraints
- Identify foreign keys
- Identify default values

### Step 2: Create Ingestion Class

Create `data_ingestion/faq_metadata_ingestion.py`:

```python
"""
FAQ Metadata Ingestion

Ingest metadata key-value pairs for FAQ questions into the faq_metadata table.

This module follows the adapter pattern - all database operations are delegated
to IIngestionAdapter implementations (SQLiteIngestionAdapter or SparkIngestionAdapter).

Author: Analytics Assist Team
Date: 2025-11-02
Version: 1.0.0
"""

from typing import Any, Dict, Optional, List
import pandas as pd

from core.interfaces.ingestion_adapter import IIngestionAdapter
from database.adapters import create_ingestion_adapter
from utils.logging_utils import get_logger

logger = get_logger(__name__)


class FAQMetadataIngestion:
    """
    FAQ metadata ingestion using adapter pattern.

    This class handles validation and preparation of metadata data,
    delegating all database operations to the configured adapter.

    Example:
        >>> ingestion = FAQMetadataIngestion(db_path="databases/faq.db")
        >>> df = pd.DataFrame({
        ...     'faq_question_id': [1, 1],
        ...     'metadata_key': ['category', 'priority'],
        ...     'metadata_value': ['HR', 'high']
        ... })
        >>> result = ingestion.ingest_from_dataframe(df)
        >>> print(result['success'])
        True
    """

    def __init__(
        self,
        db_path: Optional[str] = None,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        adapter: Optional[IIngestionAdapter] = None
    ):
        """
        Initialize FAQ metadata ingestion with auto-detection or custom adapter.

        Args:
            db_path: SQLite database path (for local environment)
            catalog_name: Databricks catalog (for Databricks environment)
            schema_name: Databricks schema (for Databricks environment)
            adapter: Custom adapter (for testing/dependency injection)

        Example:
            >>> # Auto-detection (local)
            >>> ingestion = FAQMetadataIngestion(db_path="databases/faq.db")

            >>> # Auto-detection (Databricks)
            >>> ingestion = FAQMetadataIngestion(
            ...     catalog_name="my_catalog",
            ...     schema_name="my_schema"
            ... )

            >>> # Dependency injection (testing)
            >>> from database.adapters import SQLiteIngestionAdapter
            >>> adapter = SQLiteIngestionAdapter(db_path=":memory:")
            >>> ingestion = FAQMetadataIngestion(adapter=adapter)
        """
        if adapter is not None:
            # Use provided adapter (dependency injection)
            self.adapter = adapter
        else:
            # Auto-detect environment and create adapter
            self.adapter = create_ingestion_adapter(
                db_path=db_path,
                catalog_name=catalog_name,
                schema_name=schema_name
            )

        self.table_name = "faq_metadata"
        logger.info(f"Initialized FAQMetadataIngestion for table '{self.table_name}'")

    def ingest_from_dataframe(
        self,
        df: pd.DataFrame,
        clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest FAQ metadata from a pandas DataFrame.

        Args:
            df: DataFrame with columns: faq_question_id, metadata_key, metadata_value
            clear_existing: If True, delete all existing metadata first

        Returns:
            Dict with success, rows_inserted, and message

        Example:
            >>> df = pd.DataFrame({
            ...     'faq_question_id': [1, 2],
            ...     'metadata_key': ['category', 'priority'],
            ...     'metadata_value': ['HR', 'high']
            ... })
            >>> result = ingestion.ingest_from_dataframe(df)
            >>> print(f"Inserted {result['rows_inserted']} rows")
        """
        try:
            # STEP 1: Validate (business logic)
            validation_result = self._validate_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"]
                }

            # STEP 2: Prepare (business logic)
            df_clean = self._prepare_dataframe(df)

            # STEP 3: Delegate to adapter (infrastructure)
            return self.adapter.ingest_dataframe(
                df=df_clean,
                table_name=self.table_name,
                clear_existing=clear_existing
            )

        except Exception as e:
            logger.error(f"Unexpected error during ingestion: {str(e)}")
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error: {str(e)}"
            }

    def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate DataFrame schema and constraints.

        Checks:
        - Required columns present
        - Foreign key values exist (faq_question_id)
        - No NULL values in required fields

        Args:
            df: DataFrame to validate

        Returns:
            Dict with valid (bool) and message (str)
        """
        # Check required columns
        required_columns = ['faq_question_id', 'metadata_key']
        missing_columns = [col for col in required_columns if col not in df.columns]

        if missing_columns:
            return {
                "valid": False,
                "message": f"Missing required columns: {', '.join(missing_columns)}"
            }

        # Check for NULL values in required fields
        for col in required_columns:
            if df[col].isnull().any():
                null_count = df[col].isnull().sum()
                return {
                    "valid": False,
                    "message": f"NULL values found in required column '{col}' ({null_count} rows)"
                }

        # Validate foreign keys
        invalid_fks = []
        for faq_id in df['faq_question_id'].unique():
            if not self.adapter.validate_foreign_key(
                fk_table="faq_questions",
                fk_column="question_id",
                fk_value=faq_id
            ):
                invalid_fks.append(faq_id)

        if invalid_fks:
            return {
                "valid": False,
                "message": f"Invalid faq_question_ids (not found in faq_questions): {invalid_fks}"
            }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare DataFrame for insertion.

        Applies:
        - Type conversions
        - Default values
        - Column ordering

        Args:
            df: Validated DataFrame

        Returns:
            Prepared DataFrame ready for insertion
        """
        df_clean = df.copy()

        # Ensure correct types
        df_clean['faq_question_id'] = df_clean['faq_question_id'].astype('int64')
        df_clean['metadata_key'] = df_clean['metadata_key'].astype(str)

        # Apply default for metadata_value if not present
        if 'metadata_value' not in df_clean.columns:
            df_clean['metadata_value'] = None
        else:
            df_clean['metadata_value'] = df_clean['metadata_value'].astype(str)

        return df_clean

    def ingest_from_csv(
        self,
        csv_path: str,
        clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest FAQ metadata from CSV file.

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, delete all existing metadata first

        Returns:
            Dict with success, rows_inserted, and message

        Example:
            >>> result = ingestion.ingest_from_csv("data/faq_metadata.csv")
            >>> print(result['message'])
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_from_dataframe(df, clear_existing=clear_existing)
        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}"
            }
        except pd.errors.EmptyDataError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file is empty: {csv_path}"
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}"
            }

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about ingested metadata.

        Returns:
            Dict with total_records, unique_questions, unique_keys

        Example:
            >>> stats = ingestion.get_stats()
            >>> print(f"Total metadata: {stats['total_records']}")
            >>> print(f"Unique keys: {stats['unique_keys']}")
        """
        result = self.adapter.get_table_stats(self.table_name)

        if not result['success']:
            return result

        # Get distinct metadata keys
        metadata_keys = self.adapter.get_distinct_values(
            self.table_name,
            "metadata_key"
        )

        # Get distinct question IDs
        question_ids = self.adapter.get_distinct_values(
            self.table_name,
            "faq_question_id"
        )

        return {
            "total_records": result['total_rows'],
            "unique_questions": len(question_ids),
            "unique_keys": len(metadata_keys),
            "metadata_keys": metadata_keys
        }

    def clear_metadata_for_question(
        self,
        faq_question_id: int
    ) -> Dict[str, Any]:
        """
        Clear all metadata for a specific FAQ question.

        Args:
            faq_question_id: Question ID to clear metadata for

        Returns:
            Dict with success, rows_deleted, and message

        Example:
            >>> result = ingestion.clear_metadata_for_question(faq_question_id=42)
            >>> print(f"Deleted {result['rows_deleted']} metadata entries")
        """
        return self.adapter.clear_table(
            table_name=self.table_name,
            condition="faq_question_id = ?",
            params=(faq_question_id,)
        )

    def close(self) -> None:
        """
        Close adapter and clean up resources.

        Example:
            >>> ingestion = FAQMetadataIngestion(db_path="faq.db")
            >>> try:
            ...     ingestion.ingest_from_csv("data.csv")
            ... finally:
            ...     ingestion.close()
        """
        self.adapter.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False


__all__ = ["FAQMetadataIngestion"]
```

### Step 3: Write Tests

Create `tests/test_faq_metadata_ingestion.py`:

```python
"""
Tests for FAQ Metadata Ingestion

Tests the FAQMetadataIngestion class using the adapter pattern.
"""

import pytest
import pandas as pd
from data_ingestion.faq_metadata_ingestion import FAQMetadataIngestion
from database.setup import setup_database


class TestFAQMetadataIngestionBasics:
    """Test basic ingestion functionality."""

    def test_initialization_local(self):
        """Test initialization with local SQLite database."""
        ingestion = FAQMetadataIngestion(db_path="databases/test.db")
        assert ingestion.table_name == "faq_metadata"
        assert ingestion.adapter is not None

    def test_initialization_databricks(self):
        """Test initialization with Databricks parameters."""
        ingestion = FAQMetadataIngestion(
            catalog_name="test_catalog",
            schema_name="test_schema"
        )
        assert ingestion.table_name == "faq_metadata"
        assert ingestion.adapter is not None

    def test_initialization_with_adapter(self):
        """Test initialization with custom adapter (dependency injection)."""
        from database.adapters import SQLiteIngestionAdapter

        adapter = SQLiteIngestionAdapter(db_path=":memory:")
        ingestion = FAQMetadataIngestion(adapter=adapter)

        assert ingestion.adapter is adapter


class TestDataValidation:
    """Test data validation logic."""

    def test_validate_missing_required_column(self):
        """Test validation fails when required column is missing."""
        # Setup
        result = setup_database(in_memory=True, create_tables=True)
        adapter = result['adapter']
        ingestion = FAQMetadataIngestion(adapter=adapter)

        # Missing 'metadata_key' column
        df = pd.DataFrame({'faq_question_id': [1]})

        # Ingest
        result = ingestion.ingest_from_dataframe(df)

        # Verify
        assert result['success'] == False
        assert "Missing required columns" in result['message']

        adapter.close()

    def test_validate_null_in_required_column(self):
        """Test validation fails when required column has NULL."""
        # Setup
        result = setup_database(in_memory=True, create_tables=True)
        adapter = result['adapter']
        ingestion = FAQMetadataIngestion(adapter=adapter)

        # NULL in 'metadata_key'
        df = pd.DataFrame({
            'faq_question_id': [1],
            'metadata_key': [None]
        })

        # Ingest
        result = ingestion.ingest_from_dataframe(df)

        # Verify
        assert result['success'] == False
        assert "NULL values found" in result['message']

        adapter.close()


class TestIngestion:
    """Test data ingestion."""

    def test_ingest_from_dataframe_success(self):
        """Test successful ingestion from DataFrame."""
        # Setup database with tables
        result = setup_database(in_memory=True, create_tables=True)
        adapter = result['adapter']

        # First create a question to reference
        from data_ingestion import FAQQuestionIngestion
        question_ingestion = FAQQuestionIngestion(adapter=adapter)
        q_df = pd.DataFrame({
            'question_text': ['What is the policy?'],
            'status': ['active']
        })
        q_result = question_ingestion.ingest_from_dataframe(q_df)
        question_id = 1  # Assuming first question gets ID 1

        # Now ingest metadata
        ingestion = FAQMetadataIngestion(adapter=adapter)
        df = pd.DataFrame({
            'faq_question_id': [question_id, question_id],
            'metadata_key': ['category', 'priority'],
            'metadata_value': ['HR', 'high']
        })

        result = ingestion.ingest_from_dataframe(df)

        # Verify
        assert result['success'] == True
        assert result['rows_inserted'] == 2

        adapter.close()

    def test_get_stats(self):
        """Test statistics retrieval."""
        # Setup and ingest data (same as above)
        result = setup_database(in_memory=True, create_tables=True)
        adapter = result['adapter']

        # Create question first
        from data_ingestion import FAQQuestionIngestion
        question_ingestion = FAQQuestionIngestion(adapter=adapter)
        q_df = pd.DataFrame({
            'question_text': ['What is the policy?'],
            'status': ['active']
        })
        question_ingestion.ingest_from_dataframe(q_df)

        # Ingest metadata
        ingestion = FAQMetadataIngestion(adapter=adapter)
        df = pd.DataFrame({
            'faq_question_id': [1, 1],
            'metadata_key': ['category', 'priority'],
            'metadata_value': ['HR', 'high']
        })
        ingestion.ingest_from_dataframe(df)

        # Get stats
        stats = ingestion.get_stats()

        # Verify
        assert stats['total_records'] == 2
        assert stats['unique_questions'] == 1
        assert stats['unique_keys'] == 2
        assert 'category' in stats['metadata_keys']
        assert 'priority' in stats['metadata_keys']

        adapter.close()


class TestContextManager:
    """Test context manager support."""

    def test_context_manager(self):
        """Test using ingestion as context manager."""
        result = setup_database(in_memory=True, create_tables=True)
        adapter = result['adapter']

        with FAQMetadataIngestion(adapter=adapter) as ingestion:
            assert ingestion is not None
            assert ingestion.table_name == "faq_metadata"

        # Connection should be closed after context manager exit
        adapter.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
```

### Step 4: Export in `__init__.py`

Update `data_ingestion/__init__.py`:

```python
from data_ingestion.chunk_ingestion import ChunkIngestion
from data_ingestion.A_content_repo_ingestion import ContentRepoIngestion
from data_ingestion.faq_metadata_ingestion import FAQMetadataIngestion  # NEW

__all__ = [
    "ChunkIngestion",
    "ContentRepoIngestion",
    "FAQMetadataIngestion",  # NEW
]
```

### Step 5: Document Usage

Update `data_ingestion/README.md` to include your new ingestion class:

````markdown
### FAQMetadataIngestion

Ingest metadata key-value pairs for FAQ questions.

**Example**:
```python
from data_ingestion import FAQMetadataIngestion
import pandas as pd

ingestion = FAQMetadataIngestion(db_path="databases/faq.db")

df = pd.DataFrame({
    'faq_question_id': [1, 1, 2],
    'metadata_key': ['category', 'priority', 'category'],
    'metadata_value': ['HR', 'high', 'IT']
})

result = ingestion.ingest_from_dataframe(df)
print(f"Inserted {result['rows_inserted']} metadata entries")

stats = ingestion.get_stats()
print(f"Total: {stats['total_records']}, Unique keys: {stats['unique_keys']}")
```
````

## Common Patterns

### Pattern 1: Foreign Key Validation

```python
def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
    """Validate foreign keys exist in parent table."""
    invalid_fks = []
    for fk_value in df['parent_id'].unique():
        if not self.adapter.validate_foreign_key(
            fk_table="parent_table",
            fk_column="id",
            fk_value=fk_value
        ):
            invalid_fks.append(fk_value)

    if invalid_fks:
        return {
            "valid": False,
            "message": f"Invalid parent_ids: {invalid_fks}"
        }

    return {"valid": True, "message": "Validation passed"}
```

### Pattern 2: Enum Validation

```python
def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
    """Validate enum fields have valid values."""
    valid_statuses = ['active', 'inactive', 'archived']
    invalid_statuses = df[~df['status'].isin(valid_statuses)]['status'].unique()

    if len(invalid_statuses) > 0:
        return {
            "valid": False,
            "message": f"Invalid statuses: {list(invalid_statuses)}. Must be one of: {valid_statuses}"
        }

    return {"valid": True, "message": "Validation passed"}
```

### Pattern 3: Range Validation

```python
def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
    """Validate numeric fields are in valid range."""
    if 'confidence_score' in df.columns:
        invalid_scores = df[
            (df['confidence_score'] < 0) | (df['confidence_score'] > 1)
        ]

        if not invalid_scores.empty:
            return {
                "valid": False,
                "message": f"confidence_score must be between 0.0 and 1.0 (found {len(invalid_scores)} invalid rows)"
            }

    return {"valid": True, "message": "Validation passed"}
```

### Pattern 4: Type Preparation

```python
def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
    """Prepare DataFrame with correct types."""
    df_clean = df.copy()

    # Integers
    df_clean['id'] = df_clean['id'].astype('int64')

    # Strings
    df_clean['name'] = df_clean['name'].astype(str)

    # Floats
    if 'score' in df_clean.columns:
        df_clean['score'] = df_clean['score'].astype('float64')

    # Booleans
    if 'is_active' in df_clean.columns:
        df_clean['is_active'] = df_clean['is_active'].astype(bool)

    # Dates (if needed)
    if 'created_date' in df_clean.columns:
        df_clean['created_date'] = pd.to_datetime(df_clean['created_date'])

    return df_clean
```

### Pattern 5: Default Values

```python
def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
    """Apply default values for optional fields."""
    df_clean = df.copy()

    # Apply defaults for missing columns
    if 'status' not in df_clean.columns:
        df_clean['status'] = 'active'  # Default status

    if 'priority' not in df_clean.columns:
        df_clean['priority'] = 'medium'  # Default priority

    # Replace NaN with defaults in existing columns
    df_clean['description'] = df_clean['description'].fillna('')
    df_clean['confidence_score'] = df_clean['confidence_score'].fillna(0.5)

    return df_clean
```

## Testing Checklist

When writing tests for your new ingestion class, ensure you cover:

- [ ] Initialization with local database path
- [ ] Initialization with Databricks parameters
- [ ] Initialization with custom adapter (dependency injection)
- [ ] Validation of missing required columns
- [ ] Validation of NULL values in required columns
- [ ] Validation of foreign keys
- [ ] Validation of enum fields
- [ ] Validation of numeric ranges
- [ ] Successful ingestion from DataFrame
- [ ] Successful ingestion from CSV
- [ ] Statistics retrieval
- [ ] Table clearing (whole table or conditional)
- [ ] Context manager support
- [ ] Error handling for empty DataFrame
- [ ] Error handling for missing CSV file
- [ ] Error handling for database constraint violations

## Common Pitfalls to Avoid

### ❌ DON'T: Write database code in ingestion class

```python
# BAD - Database operations in ingestion class
class BadIngestion:
    def ingest_data(self, df):
        conn = sqlite3.connect(self.db_path)
        df.to_sql('table', conn, if_exists='append')  # Direct DB operation
        conn.close()
```

### ✅ DO: Delegate to adapter

```python
# GOOD - Delegate to adapter
class GoodIngestion:
    def ingest_from_dataframe(self, df):
        df_clean = self._prepare_dataframe(df)
        return self.adapter.ingest_dataframe(df_clean, self.table_name)
```

### ❌ DON'T: Mix validation and database operations

```python
# BAD - Mixed concerns
def ingest_data(self, df):
    # Validation
    if 'required_col' not in df.columns:
        return {"success": False}

    # Database operation (mixed!)
    conn.execute("INSERT INTO ...")
```

### ✅ DO: Separate concerns

```python
# GOOD - Separated concerns
def ingest_from_dataframe(self, df):
    # 1. Validate (business logic)
    validation_result = self._validate_dataframe(df)
    if not validation_result["valid"]:
        return {"success": False, "message": validation_result["message"]}

    # 2. Prepare (business logic)
    df_clean = self._prepare_dataframe(df)

    # 3. Delegate to adapter (infrastructure)
    return self.adapter.ingest_dataframe(df_clean, self.table_name)
```

### ❌ DON'T: Hardcode environment detection

```python
# BAD - Hardcoded detection
def __init__(self):
    if is_databricks():
        self.use_spark = True
    else:
        self.use_sqlite = True
```

### ✅ DO: Use adapter factory

```python
# GOOD - Factory handles detection
def __init__(self, adapter=None, **kwargs):
    if adapter is not None:
        self.adapter = adapter
    else:
        self.adapter = create_ingestion_adapter(**kwargs)
```

## Performance Tips

1. **Batch inserts**: Use DataFrames for bulk operations (adapters handle this automatically)
2. **Foreign key validation**: Cache results if validating same FK multiple times
3. **Clear before insert**: Use `clear_existing=True` instead of manual delete + insert
4. **Index hints**: Ensure your table has indexes on frequently queried columns

## Troubleshooting

### Issue: "Foreign key constraint failed"

**Cause**: Trying to insert data that references non-existent parent record

**Solution**: Use `validate_foreign_key()` in your `_validate_dataframe()` method

```python
if not self.adapter.validate_foreign_key("parent_table", "id", fk_value):
    return {"valid": False, "message": f"Invalid FK: {fk_value}"}
```

### Issue: "UNIQUE constraint failed"

**Cause**: Trying to insert duplicate data with unique constraint

**Solution**: Either:
1. Use `clear_existing=True` to replace data
2. Or use `adapter.clear_table()` with condition to remove specific duplicates first

```python
# Option 1: Clear and replace
result = ingestion.ingest_from_dataframe(df, clear_existing=True)

# Option 2: Conditional clear
ingestion.adapter.clear_table(
    "my_table",
    condition="some_id = ?",
    params=(specific_id,)
)
```

### Issue: "Table does not exist"

**Cause**: Database schema not created yet

**Solution**: Run `0_database_setup.ipynb` or use `setup_database()`:

```python
from database.setup import setup_database

result = setup_database(db_path="databases/faq.db", create_tables=True)
```

## Summary

By following this guide, you can create new ingestion modules that:

✅ Work in both SQLite and Databricks environments
✅ Have clean separation between business logic and infrastructure
✅ Reuse existing database adapters (no duplicate code)
✅ Are easy to test (dependency injection support)
✅ Follow consistent patterns across the codebase

**Questions?** Check existing ingestion classes (`ChunkIngestion`, `ContentRepoIngestion`) for reference implementations.
