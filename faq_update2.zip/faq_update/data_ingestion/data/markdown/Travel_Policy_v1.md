# Business Travel Policy - Domestic Travel

## Travel Approval

All business travel must be pre-approved by your manager.

## Airfare

Book economy class for domestic flights.

## Hotels

Hotel accommodations should not exceed $200 per night.

## Meals

Meal reimbursement up to $50 per day for domestic travel.
