# Email Policy

Company email must be used for business purposes.
Personal use should be limited and not interfere with work.
Employees are responsible for the content of their messages.
Email may be monitored and reviewed by the company.
Confidential information should be clearly marked.
Encryption is required for sensitive data.
All attachments must be scanned for viruses.
Emails should be retained according to company retention policy.
