# Employee Handbook 2025 - Updated

## Time Off Policy

Employees are entitled to 12 sick days per calendar year. Sick days do not roll over to the next year.

## Work Schedule

Standard work hours are Monday through Friday, 9:00 AM to 5:00 PM.

## Benefits Overview

All full-time employees are eligible for health insurance, dental coverage, and vision benefits after 90 days of employment.
