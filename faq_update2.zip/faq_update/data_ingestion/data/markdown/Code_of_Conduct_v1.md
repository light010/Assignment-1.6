# Code of Conduct - Ethics and Compliance

## Professional Behavior

All employees must maintain professional conduct in the workplace.

## Harassment Policy

Harassment of any kind will not be tolerated.

## Conflicts of Interest

Employees must disclose any conflicts of interest to their manager.

## Confidentiality

Employees must protect confidential company information.
