# Remote Work Policy - Updated Guidelines (3 days/week)

## Remote Work Eligibility

Employees may work remotely up to 3 days per week with manager approval.

## Equipment

Company will provide laptop and necessary equipment for remote work.

## Availability

Remote employees must be available during core business hours (10 AM - 3 PM EST).
