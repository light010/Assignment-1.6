# Parental Leave Policy - Enhanced Benefits (16 weeks)

## Eligibility

All full-time employees are eligible for parental leave.

## Leave Duration

Birth parents receive 16 weeks of paid parental leave.
Non-birth parents receive 8 weeks of paid parental leave.

## Leave Request

Notify HR at least 30 days before anticipated leave start date.

## Benefits

Health insurance and other benefits continue during leave period.
