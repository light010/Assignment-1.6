# IT Security Policy - Enhanced Password Requirements

## Password Standards

All employees must use strong passwords with a minimum of 12 characters.

## Password Changes

Passwords must be changed every 90 days.

## Multi-Factor Authentication

MFA is required for all systems containing sensitive data.
