# Parking Policy

Employees may park in designated company parking areas.
Parking permits are required and available from facilities.
Visitor parking is available in the front lot.
Do not park in reserved or handicap spaces without authorization.
Overnight parking requires security approval.
The company is not responsible for damage or theft.
Violations may result in towing at owner's expense.
Contact facilities@company.com for parking issues.
