# Email Policy

Company email should be used for business purposes.
Personal use should be minimal and not interfere with work.
Employees are responsible for the content of their emails.
Email is subject to monitoring and review by the company.
Confidential information should be marked as such.
Use encryption for sensitive data.
Attachments should be scanned for viruses.
Retain emails according to the company retention policy.
