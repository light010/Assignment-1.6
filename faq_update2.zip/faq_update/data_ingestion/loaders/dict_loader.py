"""Dictionary List Loader - Load from in-memory data."""

from config.constants import CHECKSUM_ALGORITHM
from data_ingestion.loaders.base_loader import BaseFileLoader


class DictListFileLoader(BaseFileLoader):
    """Load checksums from in-memory list of dictionaries."""

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM, content_field: str = "content_text"):
        BaseFileLoader.__init__(self, checksum_algorithm)
        self.content_field = content_field
        self._logger.info(f"DictListFileLoader initialized: content_field={content_field}")

    def load_from_dict_list(self, data):
        """Load checksums from list of dictionaries."""
        if not data:
            raise ValueError("Data list is empty")

        checksums_data = {}
        self._logger.info(f"📊 Loading checksums from {len(data)} records")

        for idx, record in enumerate(data):
            try:
                content_text = record.get(self.content_field)
                if not content_text:
                    self._logger.warning(f"   ⚠️  Record {idx}: Missing {self.content_field}, skipping")
                    continue

                checksum = self._compute_checksum(content_text)

                # Include all fields from original record + normalized fields
                result_data = dict(record)
                result_data.update(
                    self._normalize_fields(
                        text=content_text,
                        page_num=record.get("page_number"),
                    )
                )

                checksums_data[checksum] = result_data

            except Exception as e:
                self._logger.error(f"   ✗ Record {idx}: Error: {e}")

        self._logger.info(f"✅ Loaded {len(checksums_data)} unique checksums")
        return checksums_data


__all__ = ['DictListFileLoader']
