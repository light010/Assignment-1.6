"""
Data Ingestion Loaders - File Loading Utilities

This module provides file loaders for ingesting data from various sources
into the FAQ update system. All loaders implement the IFileLoader interface
and return standardized dictionaries mapping checksums to content.

Loaders:
    - MarkdownFileLoader: Load content from markdown files
    - CSVFileLoader: Load content from CSV files
    - DictListFileLoader: Load content from in-memory dictionaries

Example:
    >>> from data_ingestion.loaders import MarkdownFileLoader, CSVFileLoader
    >>>
    >>> # Load from markdown directory
    >>> md_loader = MarkdownFileLoader()
    >>> current_data = md_loader.load_from_markdown("./data/current/")
    >>>
    >>> # Load from CSV file
    >>> csv_loader = CSVFileLoader()
    >>> previous_data = csv_loader.load_from_csv("./data/previous.csv")
    >>>
    >>> # Use with detection module
    >>> from detection import ChecksumChangeDetector
    >>> detector = ChecksumChangeDetector.for_faq_updates()
    >>> results = detector.detect_changes("faq.pdf", current_data, previous_data, "run_1")

Architecture:
    Loaders are part of the Data Ingestion layer, separate from the Detection layer.
    This separation allows:
    - Using different data sources (files, databases, APIs)
    - Testing detection logic without file I/O
    - Flexible data pipeline composition

Refactoring Note (2025-11-01):
    The loaders have been refactored into separate modules for better maintainability:
    - base_loader.py: Abstract base class with shared infrastructure
    - markdown_loader.py: MarkdownFileLoader implementation
    - csv_loader.py: CSVFileLoader implementation
    - dict_loader.py: DictListFileLoader implementation
    - parsers.py: Filename parsing utilities

    This refactoring maintains 100% backward compatibility - all imports work exactly as before.

Date: 2025-11-01
"""

from data_ingestion.loaders.csv_loader import CSVFileLoader
from data_ingestion.loaders.dict_loader import DictListFileLoader
from data_ingestion.loaders.markdown_loader import MarkdownFileLoader

__all__ = [
    "MarkdownFileLoader",
    "CSVFileLoader",
    "DictListFileLoader",
]
