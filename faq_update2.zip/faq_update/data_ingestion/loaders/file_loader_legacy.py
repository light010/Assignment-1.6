"""
⚠️  LEGACY FILE - REFACTORED ON 2025-11-01 ⚠️

This file has been refactored into separate modules for better maintainability.
DO NOT MODIFY THIS FILE. Use the new modular structure instead.

NEW STRUCTURE:
    - base_loader.py: Abstract base class with shared infrastructure
    - markdown_loader.py: MarkdownFileLoader implementation
    - csv_loader.py: CSVFileLoader implementation
    - dict_loader.py: DictListFileLoader implementation
    - parsers.py: Filename parsing utilities

BACKWARD COMPATIBILITY:
    All imports still work via __init__.py:
    >>> from data_ingestion.loaders import MarkdownFileLoader, CSVFileLoader

    This maintains 100% backward compatibility while improving code organization.

ORIGINAL DOCUMENTATION:
================================================================================

File Loaders - Data Ingestion Layer

This module provides file loaders for the data ingestion layer. Loaders implement
the IFileLoader interface and convert various file formats into a standardized
checksum dictionary format for use with the detection module.

Location: data_ingestion/loaders/file_loader.py (moved from detection/ on 2025-11-01)

Key Features:
    - Implements IFileLoader interface
    - Supports markdown files, CSV files, and in-memory data
    - Consistent output format for all loaders
    - Checksum computation using centralized utility
    - Part of Data Ingestion layer (separated from Detection layer)

Design Principles:
    - Strategy Pattern: IFileLoader interface
    - Single Responsibility: Focus on file loading only
    - Separation of Concerns: Data loading ≠ Change detection
    - Framework Agnostic: No dependencies on detection logic
    - Consistent Output: All loaders return Dict[str, Dict[str, Any]]

Architecture:
    Data Ingestion (loaders) → Detection (change detection)
    - Loaders: File I/O, parsing, checksum computation
    - Detectors: Comparing checksums, finding changes

Example:
    >>> from data_ingestion.loaders import MarkdownFileLoader, CSVFileLoader
    >>>
    >>> # Load from markdown
    >>> md_loader = MarkdownFileLoader()
    >>> current_data = md_loader.load_from_markdown("./data/current/")
    >>> len(current_data)
    42
    >>>
    >>> # Load from CSV
    >>> csv_loader = CSVFileLoader()
    >>> previous_data = csv_loader.load_from_csv("./data/previous_checksums.csv")
    >>> len(previous_data)
    38
    >>>
    >>> # Use with detection module
    >>> from detection import ChecksumChangeDetector
    >>> detector = ChecksumChangeDetector.for_faq_updates()
    >>> results = detector.detect_changes("faq.pdf", current_data, previous_data, "run_1")
"""

import csv
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from config.constants import CHECKSUM_ALGORITHM
from core.interfaces.detection import IFileLoader
from utility.hashing import compute_checksum
from utility.logging import get_logger

logger = get_logger(__name__)


class MarkdownFileLoader(IFileLoader):
    """
    Load checksums and content from markdown files.

    This loader scans a directory of markdown files, computes checksums for each file,
    and returns a standardized dictionary mapping checksums to content and metadata.

    File naming convention:
        - {file_name}_page_{page_num}.md
        - {file_name}_p{page_num}.md
        - {file_name}_{page_num}.md

    Attributes:
        checksum_algorithm: Hash algorithm to use (default: from config)

    Example:
        >>> loader = MarkdownFileLoader()
        >>> data = loader.load_from_markdown("./data/markdown/")
        >>> data
        {
            'abc123...': {
                'text': 'How do I reset my password?',
                'page_num': 1,
                'markdown_path': './data/markdown/faq_page_1.md',
                'file_name': 'faq_page_1.md'
            },
            'def456...': {...}
        }
    """

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM):
        """
        Initialize markdown file loader.

        Args:
            checksum_algorithm: Hash algorithm (default: from config)

        Example:
            >>> loader = MarkdownFileLoader()
            >>> loader.checksum_algorithm
            'sha256'
        """
        self.checksum_algorithm = checksum_algorithm
        logger.info(f"MarkdownFileLoader initialized with {checksum_algorithm}")

    def load_from_markdown(
        self, path: str, file_name_pattern: str = "*.md"
    ) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from markdown files.

        Scans a directory of markdown files, computes checksums for each content
        section, and returns a dictionary mapping checksums to their content and metadata.

        Args:
            path: Path to markdown directory
            file_name_pattern: Glob pattern for files (default: *.md)

        Returns:
            Dictionary mapping checksums to content metadata:
                {
                    "checksum1": {
                        "text": "Content text...",
                        "page_num": 42,
                        "markdown_path": "path/to/file.md",
                        "file_name": "file.md"
                    },
                    "checksum2": {...},
                }

        Raises:
            FileNotFoundError: If path does not exist
            ValueError: If no markdown files found

        Example:
            >>> loader = MarkdownFileLoader()
            >>> data = loader.load_from_markdown("./data/markdown/")
            >>> len(data)
            42
            >>> list(data.keys())[0]
            'a1b2c3d4e5f6...'
        """
        markdown_dir = Path(path)

        if not markdown_dir.exists():
            raise FileNotFoundError(f"Markdown directory not found: {markdown_dir}")

        if not markdown_dir.is_dir():
            raise ValueError(f"Path must be a directory, got: {markdown_dir}")

        checksums_data = {}
        files = list(markdown_dir.glob(file_name_pattern))

        if not files:
            raise ValueError(
                f"No markdown files found in {markdown_dir} matching pattern {file_name_pattern}"
            )

        logger.info(f"📂 Loading checksums from {len(files)} markdown files in {markdown_dir}")

        for md_file in files:
            try:
                # Read content
                with open(md_file, "r", encoding="utf-8") as f:
                    content = f.read()

                # Compute checksum using centralized utility
                checksum = compute_checksum(content, algorithm=self.checksum_algorithm)

                # Extract page number from filename (if present)
                page_num = self._extract_page_number(md_file.stem)

                checksums_data[checksum] = {
                    "text": content,
                    "markdown_path": str(md_file),
                    "file_name": md_file.name,
                    "page_num": page_num,
                }

                logger.debug(f"   ✓ {md_file.name} → {checksum[:8]}... (page {page_num})")

            except Exception as e:
                logger.error(f"   ✗ Error processing {md_file.name}: {e}")
                # Continue processing other files instead of failing completely

        logger.info(f"✅ Loaded {len(checksums_data)} unique checksums")

        return checksums_data

    def load_from_csv(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from CSV file (not implemented for markdown loader).

        This method is part of the IFileLoader interface but is not the primary
        use case for MarkdownFileLoader. Use CSVFileLoader instead.

        Args:
            path: Path to CSV file

        Raises:
            NotImplementedError: This loader is for markdown files only

        Example:
            >>> loader = MarkdownFileLoader()
            >>> loader.load_from_csv("data.csv")
            NotImplementedError: Use CSVFileLoader for CSV files
        """
        raise NotImplementedError(
            "MarkdownFileLoader is for markdown files. Use CSVFileLoader for CSV files."
        )

    def _extract_page_number(self, filename_stem: str) -> Optional[int]:
        """
        Extract page number from filename.

        Supports patterns:
        - {name}_page_{num}
        - {name}_p{num}
        - {name}_{num}

        Args:
            filename_stem: Filename without extension

        Returns:
            Page number or None if not found

        Example:
            >>> loader = MarkdownFileLoader()
            >>> loader._extract_page_number("faq_page_5")
            5
            >>> loader._extract_page_number("handbook_p10")
            10
            >>> loader._extract_page_number("document_42")
            42
            >>> loader._extract_page_number("readme")
            None
        """
        # Pattern: _page_42, _p42, _42
        patterns = [
            r"_page_(\d+)$",  # handbook_page_5
            r"_p(\d+)$",  # handbook_p5
            r"_(\d+)$",  # handbook_5
        ]

        for pattern in patterns:
            match = re.search(pattern, filename_stem)
            if match:
                return int(match.group(1))

        return None


class CSVFileLoader(IFileLoader):
    """
    Load checksums and content from CSV files.

    This loader reads a CSV file containing content data, computes checksums for each row,
    and returns a standardized dictionary mapping checksums to content and metadata.

    Expected CSV columns:
        - content_text (required): The actual content
        - file_name (optional): Source file name
        - page_number (optional): Page number
        - content_checksum (optional): Pre-computed checksum (will verify)

    Attributes:
        checksum_algorithm: Hash algorithm to use (default: from config)

    Example:
        >>> loader = CSVFileLoader()
        >>> data = loader.load_from_csv("./data/previous_checksums.csv")
        >>> data
        {
            'xyz789...': {
                'content_text': 'Previous FAQ content...',
                'text': 'Previous FAQ content...',
                'page_number': 42,
                'page_num': 42,
                'file_name': 'faq.pdf'
            },
            'abc123...': {...}
        }
    """

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM):
        """
        Initialize CSV file loader.

        Args:
            checksum_algorithm: Hash algorithm (default: from config)

        Example:
            >>> loader = CSVFileLoader()
            >>> loader.checksum_algorithm
            'sha256'
        """
        self.checksum_algorithm = checksum_algorithm
        logger.info(f"CSVFileLoader initialized with {checksum_algorithm}")

    def load_from_markdown(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from markdown files (not implemented for CSV loader).

        This method is part of the IFileLoader interface but is not the primary
        use case for CSVFileLoader. Use MarkdownFileLoader instead.

        Args:
            path: Path to markdown directory

        Raises:
            NotImplementedError: This loader is for CSV files only

        Example:
            >>> loader = CSVFileLoader()
            >>> loader.load_from_markdown("./markdown/")
            NotImplementedError: Use MarkdownFileLoader for markdown files
        """
        raise NotImplementedError(
            "CSVFileLoader is for CSV files. Use MarkdownFileLoader for markdown files."
        )

    def load_from_csv(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums and content from CSV file.

        Reads a CSV file containing content and checksums, and returns a dictionary
        mapping checksums to their content and metadata.

        Args:
            path: Path to CSV file

        Returns:
            Dictionary mapping checksums to content metadata:
                {
                    "checksum1": {
                        "content_text": "Content text...",
                        "text": "Content text...",  # Alias
                        "page_number": 42,
                        "page_num": 42,  # Alias
                        "file_name": "source.pdf"
                    },
                    "checksum2": {...},
                }

        Raises:
            FileNotFoundError: If CSV file does not exist
            ValueError: If CSV format is invalid or no content found

        Example:
            >>> loader = CSVFileLoader()
            >>> data = loader.load_from_csv("./data/previous_checksums.csv")
            >>> len(data)
            38
        """
        csv_path = Path(path)

        if not csv_path.exists():
            raise FileNotFoundError(f"CSV file not found: {csv_path}")

        if not csv_path.is_file():
            raise ValueError(f"Path must be a file, got: {csv_path}")

        checksums_data = {}

        logger.info(f"📄 Loading checksums from CSV: {csv_path}")

        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            if not reader.fieldnames:
                raise ValueError(f"CSV file has no headers: {csv_path}")

            for row_num, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                try:
                    content_text = row.get("content_text")

                    if not content_text:
                        logger.warning(f"   ⚠️  Row {row_num}: Missing content_text, skipping")
                        continue

                    # Compute checksum using centralized utility
                    checksum = compute_checksum(content_text, algorithm=self.checksum_algorithm)

                    # Verify pre-computed checksum if provided
                    if "content_checksum" in row and row["content_checksum"]:
                        if row["content_checksum"] != checksum:
                            logger.warning(
                                f"   ⚠️  Row {row_num}: Checksum mismatch! "
                                f"Provided: {row['content_checksum'][:8]}..., "
                                f"Computed: {checksum[:8]}..."
                            )

                    checksums_data[checksum] = {
                        "text": content_text,  # Standardized field
                        "content_text": content_text,  # Alias for compatibility
                        "file_name": row.get("file_name", ""),
                        "page_number": int(row["page_number"]) if row.get("page_number") else None,
                        "page_num": int(row["page_number"]) if row.get("page_number") else None,  # Alias
                        "row_num": row_num,
                    }

                except Exception as e:
                    logger.error(f"   ✗ Row {row_num}: Error processing: {e}")
                    # Continue processing other rows instead of failing completely

        if not checksums_data:
            raise ValueError(f"No valid content found in CSV file: {csv_path}")

        logger.info(f"✅ Loaded {len(checksums_data)} unique checksums from CSV")

        return checksums_data


class DictListFileLoader(IFileLoader):
    """
    Load checksums and content from in-memory list of dictionaries.

    This loader is useful for loading data from Spark DataFrames, API responses,
    or other in-memory data structures that have already been loaded.

    Attributes:
        checksum_algorithm: Hash algorithm to use (default: from config)
        content_field: Name of field containing text content

    Example:
        >>> data = [
        ...     {'content_text': 'FAQ 1', 'page_number': 1, 'file_name': 'faq.pdf'},
        ...     {'content_text': 'FAQ 2', 'page_number': 2, 'file_name': 'faq.pdf'}
        ... ]
        >>> loader = DictListFileLoader()
        >>> result = loader.load_from_dict_list(data)
        >>> len(result)
        2
    """

    def __init__(
        self,
        checksum_algorithm: str = CHECKSUM_ALGORITHM,
        content_field: str = "content_text",
    ):
        """
        Initialize dict list file loader.

        Args:
            checksum_algorithm: Hash algorithm (default: from config)
            content_field: Name of field containing text content (default: "content_text")

        Example:
            >>> loader = DictListFileLoader(content_field="text")
        """
        self.checksum_algorithm = checksum_algorithm
        self.content_field = content_field
        logger.info(f"DictListFileLoader initialized with {checksum_algorithm}")

    def load_from_markdown(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Not implemented for dict list loader.

        Args:
            path: Not used

        Raises:
            NotImplementedError: This loader is for in-memory data only
        """
        raise NotImplementedError(
            "DictListFileLoader is for in-memory data. Use MarkdownFileLoader for markdown files."
        )

    def load_from_csv(self, path: str) -> Dict[str, Dict[str, Any]]:
        """
        Not implemented for dict list loader.

        Args:
            path: Not used

        Raises:
            NotImplementedError: This loader is for in-memory data only
        """
        raise NotImplementedError(
            "DictListFileLoader is for in-memory data. Use CSVFileLoader for CSV files."
        )

    def load_from_dict_list(
        self, data: List[Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Load checksums from a list of dictionaries.

        Args:
            data: List of dictionaries containing content data

        Returns:
            Dictionary mapping checksums to content metadata

        Raises:
            ValueError: If data is empty or invalid

        Example:
            >>> data = [{'content_text': 'Hello', 'page_number': 1}]
            >>> loader = DictListFileLoader()
            >>> result = loader.load_from_dict_list(data)
            >>> len(result)
            1
        """
        if not data:
            raise ValueError("Data list is empty")

        checksums_data = {}

        logger.info(f"📊 Loading checksums from {len(data)} records")

        for idx, record in enumerate(data):
            try:
                content_text = record.get(self.content_field)

                if not content_text:
                    logger.warning(f"   ⚠️  Record {idx}: Missing {self.content_field}, skipping")
                    continue

                # Compute checksum using centralized utility
                checksum = compute_checksum(content_text, algorithm=self.checksum_algorithm)

                # Include all fields from original record
                checksums_data[checksum] = {
                    **record,
                    "text": content_text,  # Standardized field
                    "content_text": content_text,  # Alias
                    "page_num": record.get("page_number"),  # Standardized field
                }

            except Exception as e:
                logger.error(f"   ✗ Record {idx}: Error processing: {e}")

        logger.info(f"✅ Loaded {len(checksums_data)} unique checksums")

        return checksums_data


# Convenience exports
__all__ = [
    "MarkdownFileLoader",
    "CSVFileLoader",
    "DictListFileLoader",
]
