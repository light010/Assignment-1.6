"""Base utilities for file loaders."""

from config.constants import CHECKSUM_ALGORITHM
from utility.hashing import compute_checksum
from utility.logging import get_logger


class BaseFileLoader:
    """Shared utilities for file loaders (not abstract - just helpers)."""

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM):
        self.checksum_algorithm = checksum_algorithm
        self._logger = get_logger(self.__class__.__name__)

    def _compute_checksum(self, text: str) -> str:
        return compute_checksum(text)

    def _normalize_fields(self, **kwargs):
        """Add text/content_text and page_num/page_number aliases."""
        result = dict(kwargs)
        if 'text' in result:
            result.setdefault('content_text', result['text'])
        if 'content_text' in result:
            result.setdefault('text', result['content_text'])
        if 'page_num' in result:
            result.setdefault('page_number', result['page_num'])
        if 'page_number' in result:
            result.setdefault('page_num', result['page_number'])
        return result


__all__ = ['BaseFileLoader']
