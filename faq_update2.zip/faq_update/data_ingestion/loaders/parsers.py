"""Filename parsing utilities."""

import re


def extract_page_number(filename_stem: str):
    """
    Extract page number from filename.

    Supports: handbook_page_5, handbook_p10, document_42
    """
    if not filename_stem:
        return None

    patterns = [r"_page_(\d+)$", r"_p(\d+)$", r"_(\d+)$"]

    for pattern in patterns:
        match = re.search(pattern, filename_stem)
        if match:
            return int(match.group(1))

    return None


__all__ = ['extract_page_number']
