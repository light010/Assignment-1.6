# Data Ingestion Loaders

File loading utilities for ingesting data from various sources into the FAQ update system.

## Overview

Loaders are part of the **Data Ingestion layer**, responsible for loading and parsing data from files, databases, or APIs into a standardized format for the detection module.

## Architecture

```
┌─────────────────────────────────────────┐
│  Data Ingestion Layer                   │
│  data_ingestion/loaders/                │
│                                         │
│  • MarkdownFileLoader                  │
│  • CSVFileLoader                       │
│  • DictListFileLoader                  │
└─────────────────┬───────────────────────┘
                  │ Output: Dict[checksum, data]
                  ▼
┌─────────────────────────────────────────┐
│  Detection Layer                        │
│  detection/ChecksumChangeDetector       │
│                                         │
│  • detect_changes(current, previous)    │
└─────────────────────────────────────────┘
```

## Available Loaders

### MarkdownFileLoader

Loads content from markdown files in a directory.

**Use Case:** Loading current FAQ content from extracted markdown files

```python
from data_ingestion.loaders import MarkdownFileLoader

loader = MarkdownFileLoader()
data = loader.load_from_markdown("./data/current/")

# Returns: {checksum: {'text': '...', 'page_num': 1, 'markdown_path': '...', ...}, ...}
```

**File Naming Convention:**
- `{file_name}_page_{page_num}.md`
- `{file_name}_p{page_num}.md`
- `{file_name}_{page_num}.md`

### CSVFileLoader

Loads content from CSV files with checksums.

**Use Case:** Loading historical FAQ data from database exports

```python
from data_ingestion.loaders import CSVFileLoader

loader = CSVFileLoader()
data = loader.load_from_csv("./data/previous_checksums.csv")

# Returns: {checksum: {'content_text': '...', 'page_number': 1, ...}, ...}
```

**Expected CSV Format:**
- Must have `checksum` column
- Should have `content_text`, `page_number`, etc.

### DictListFileLoader

Loads content from in-memory Python dictionaries.

**Use Case:** Testing, API responses, database queries

```python
from data_ingestion.loaders import DictListFileLoader

loader = DictListFileLoader()
content_list = [
    {'text': 'FAQ 1', 'page_num': 1},
    {'text': 'FAQ 2', 'page_num': 2},
]
data = loader.load_from_dict_list(content_list)

# Returns: {checksum: {'text': '...', 'page_num': 1}, ...}
```

## Integration with Detection

Loaders output data in the format expected by `ChecksumChangeDetector`:

```python
from data_ingestion.loaders import MarkdownFileLoader, CSVFileLoader
from detection import ChecksumChangeDetector

# Load data
md_loader = MarkdownFileLoader()
csv_loader = CSVFileLoader()

current_data = md_loader.load_from_markdown("./data/current/")
previous_data = csv_loader.load_from_csv("./data/previous.csv")

# Detect changes
detector = ChecksumChangeDetector.for_faq_updates()
results = detector.detect_changes("handbook.pdf", current_data, previous_data, "run_1")

# Process results
for result in results:
    print(f"{result.change_type}: {result.similarity_score}")
```

## Design Principles

1. **Separation of Concerns**
   - Loaders: File I/O and parsing
   - Detectors: Change detection logic
   - Clear boundaries between layers

2. **Interface-Based**
   - All loaders implement `IFileLoader` interface
   - Consistent API across all loaders
   - Easy to add new loaders

3. **Standardized Output**
   - All loaders return `Dict[str, Dict[str, Any]]`
   - Checksums as keys
   - Metadata as nested dictionaries

4. **Framework Agnostic**
   - No dependencies on detection logic
   - Can be used independently
   - Reusable across different modules

## Adding New Loaders

To add a new loader (e.g., API loader, database loader):

1. Implement `IFileLoader` interface
2. Add to `data_ingestion/loaders/`
3. Export in `__init__.py`
4. Add tests in `tests/data_ingestion/loaders/`

Example:

```python
from core.interfaces.detection import IFileLoader
from typing import Dict, Any

class APIFileLoader(IFileLoader):
    """Load content from REST API."""

    def load_from_api(self, url: str) -> Dict[str, Dict[str, Any]]:
        # Implementation
        pass
```

## Testing

```bash
# Run loader tests
cd faq_update
python -m pytest tests/data_ingestion/loaders/ -v
```

## References

- **Interface**: [core/interfaces/detection.py](../../core/interfaces/detection.py)
- **Detection Module**: [detection/](../../detection/)
- **Usage Examples**: See ARCHITECTURE.md

---

**Date:** 2025-11-01
**Location:** `data_ingestion/loaders/`
