"""CSV File Loader."""

import csv
from pathlib import Path
from config.constants import CHECKSUM_ALGORITHM
from data_ingestion.loaders.base_loader import BaseFileLoader


class CSVFileLoader(BaseFileLoader):
    """Load checksums and content from CSV files."""

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM):
        BaseFileLoader.__init__(self, checksum_algorithm)
        self._logger.info(f"CSVFileLoader initialized with {checksum_algorithm}")

    def load_from_csv(self, path: str):
        """Load checksums from CSV file."""
        csv_path = Path(path)

        if not csv_path.exists():
            raise FileNotFoundError(f"File not found: {csv_path}")
        if not csv_path.is_file():
            raise ValueError(f"Path must be a file: {csv_path}")

        checksums_data = {}
        self._logger.info(f"📄 Loading checksums from CSV: {csv_path}")

        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            if not reader.fieldnames:
                raise ValueError(f"CSV file has no headers: {csv_path}")

            for row_num, row in enumerate(reader, start=2):
                try:
                    content_text = row.get("content_text")
                    if not content_text:
                        self._logger.warning(f"   ⚠️  Row {row_num}: Missing content_text, skipping")
                        continue

                    checksum = self._compute_checksum(content_text)

                    # Verify pre-computed checksum if provided
                    if "content_checksum" in row and row["content_checksum"]:
                        if row["content_checksum"] != checksum:
                            self._logger.warning(
                                f"   ⚠️  Row {row_num}: Checksum mismatch! "
                                f"Provided: {row['content_checksum'][:8]}..., "
                                f"Computed: {checksum[:8]}..."
                            )

                    # Parse page number
                    page_number = None
                    if row.get("page_number"):
                        try:
                            page_number = int(row["page_number"])
                        except (ValueError, TypeError):
                            self._logger.warning(f"   ⚠️  Row {row_num}: Invalid page_number")

                    checksums_data[checksum] = self._normalize_fields(
                        text=content_text,
                        file_name=row.get("file_name", ""),
                        page_number=page_number,
                        row_num=row_num,
                    )

                except Exception as e:
                    self._logger.error(f"   ✗ Row {row_num}: Error: {e}")

        if not checksums_data:
            raise ValueError(f"No valid content found in CSV: {csv_path}")

        self._logger.info(f"✅ Loaded {len(checksums_data)} unique checksums from CSV")
        return checksums_data


__all__ = ['CSVFileLoader']
