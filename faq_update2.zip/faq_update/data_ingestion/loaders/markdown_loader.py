"""Markdown File Loader."""

from pathlib import Path
from config.constants import CHECKSUM_ALGORITHM
from data_ingestion.loaders.base_loader import BaseFileLoader
from data_ingestion.loaders.parsers import extract_page_number


class MarkdownFileLoader(BaseFileLoader):
    """Load checksums and content from markdown files."""

    def __init__(self, checksum_algorithm: str = CHECKSUM_ALGORITHM):
        BaseFileLoader.__init__(self, checksum_algorithm)
        self._logger.info(f"MarkdownFileLoader initialized with {checksum_algorithm}")

    def load_from_markdown(self, path: str, file_name_pattern: str = "*.md"):
        """Load checksums from markdown directory."""
        markdown_dir = Path(path)

        if not markdown_dir.exists():
            raise FileNotFoundError(f"Directory not found: {markdown_dir}")
        if not markdown_dir.is_dir():
            raise ValueError(f"Path must be a directory: {markdown_dir}")

        files = list(markdown_dir.glob(file_name_pattern))
        if not files:
            raise ValueError(f"No markdown files found in {markdown_dir}")

        checksums_data = {}
        self._logger.info(f"📂 Loading {len(files)} markdown files from {markdown_dir}")

        for md_file in files:
            try:
                with open(md_file, "r", encoding="utf-8") as f:
                    content = f.read()

                checksum = self._compute_checksum(content)
                page_num = extract_page_number(md_file.stem)

                checksums_data[checksum] = self._normalize_fields(
                    text=content,
                    markdown_path=str(md_file),
                    file_name=md_file.name,
                    page_num=page_num,
                )

                self._logger.debug(f"   ✓ {md_file.name} → {checksum[:8]}...")

            except Exception as e:
                self._logger.error(f"   ✗ Error processing {md_file.name}: {e}")

        self._logger.info(f"✅ Loaded {len(checksums_data)} unique checksums")
        return checksums_data


__all__ = ['MarkdownFileLoader']
