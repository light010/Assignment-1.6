"""
Content Repository Data Ingestion

Simplified ingestion for content_repo table using the repository pattern.
Handles CSV files and DataFrames with validation, batch inserts, and error handling.

Design Principles:
- Simplicity first: One table, one responsibility
- Database agnostic: Uses repository pattern for SQLite and Databricks
- Validation: Required fields, unique constraints, file status validation
- Batch efficiency: Delegates to ContentRepository for optimal insertion

Architecture:
- Business logic: ContentRepoIngestion class (this file)
- Database operations: Delegated to ContentRepository
- Separation of concerns: No SQL/Spark code in business logic

Version: 3.0.0 (Refactored to use repository pattern - Phase 5)
"""

from pathlib import Path
from typing import Dict, Any, Optional
import pandas as pd
import warnings

from database.repository import ContentRepository
from database.backends.factory import BackendFactory
from database.config import DatabaseConfig


class ContentRepoIngestion:
    """
    Ingest content_repo data from CSV or DataFrame.

    This class handles the business logic for content repository ingestion while
    delegating all database operations to ContentRepository implementation.

    The repository handles environment detection (SQLite vs Databricks) automatically,
    eliminating the need for is_databricks checks and database-specific code.

    Attributes:
        repository: ContentRepository instance for database operations
        table_name: Name of the content_repo table (simple name, not qualified)

    Example:
        >>> # Local SQLite
        >>> ingestion = ContentRepoIngestion(db_path="databases/faq.db")
        >>>
        >>> # Databricks
        >>> ingestion = ContentRepoIngestion(catalog_name="prod", schema_name="faq")
        >>>
        >>> # Ingest from CSV
        >>> result = ingestion.ingest_from_csv("data/content_repo.csv")
        >>> print(f"Inserted {result['rows_inserted']} rows")
    """

    def __init__(
        self,
        db_path: Optional[str] = None,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        repository: Optional[ContentRepository] = None,
        config: Optional[DatabaseConfig] = None
    ):
        """
        Initialize content repo ingestion with database configuration.

        You can either provide database parameters, config object, or inject
        a pre-configured repository directly.

        Args:
            db_path: Path to SQLite database file (for local environment)
            catalog_name: Unity Catalog name (for Databricks)
            schema_name: Schema name (for Databricks)
            repository: Optional pre-configured repository (overrides other params)
            config: Optional DatabaseConfig instance

        Raises:
            ValueError: If required parameters are missing

        Example:
            >>> # Auto-detect with factory
            >>> ingestion = ContentRepoIngestion(db_path="faq.db")
            >>>
            >>> # Inject custom repository (useful for testing)
            >>> from database.repository import ContentRepository
            >>> from database.backends.sqlite import SQLiteBackend
            >>> backend = SQLiteBackend(":memory:")
            >>> repo = ContentRepository(backend)
            >>> ingestion = ContentRepoIngestion(repository=repo)
        """
        if repository is not None:
            # Use injected repository (useful for testing)
            self.repository = repository
        else:
            # Create repository using factory
            if config is None:
                # Build config from parameters
                if db_path:
                    config = DatabaseConfig(backend='sqlite', db_path=db_path)
                elif catalog_name and schema_name:
                    config = DatabaseConfig(
                        backend='databricks',
                        catalog=catalog_name,
                        schema=schema_name
                    )
                else:
                    # Auto-detect from environment
                    config = DatabaseConfig.from_env()

            # Create backend and repository
            backend = BackendFactory.create_backend(config)
            self.repository = ContentRepository(backend)

        self.table_name = "content_repo"

    def ingest_from_csv(
        self, csv_path: str, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest data from CSV file.

        Reads CSV, validates, and delegates to ingest_from_dataframe().

        Args:
            csv_path: Path to CSV file
            clear_existing: If True, clear table before insert

        Returns:
            Dict with:
                - success (bool): True if ingestion succeeded
                - rows_inserted (int): Number of rows inserted
                - message (str): Status message
                - error (str, optional): Error details if failed

        Example:
            >>> result = ingestion.ingest_from_csv("data/content_repo.csv")
            >>> if result['success']:
            ...     print(f"Loaded {result['rows_inserted']} files")
        """
        try:
            df = pd.read_csv(csv_path)
            return self.ingest_from_dataframe(df, clear_existing=clear_existing)

        except FileNotFoundError:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"CSV file not found: {csv_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Error reading CSV: {str(e)}",
                "error": str(e)
            }

    def ingest_from_dataframe(
        self, df: pd.DataFrame, clear_existing: bool = False
    ) -> Dict[str, Any]:
        """
        Ingest data from pandas DataFrame.

        Validates data, prepares it, and delegates insertion to repository.

        Args:
            df: DataFrame with content_repo columns
            clear_existing: If True, clear table before insert (NOT RECOMMENDED)

        Returns:
            Dict with success status, rows_inserted, and message

        Example:
            >>> df = pd.DataFrame({
            ...     'raw_file_nme': ['file1.pdf', 'file2.pdf'],
            ...     'raw_file_type': ['pdf', 'pdf'],
            ...     'file_status': ['Active', 'Active']
            ... })
            >>> result = ingestion.ingest_from_dataframe(df)
            >>> assert result['success'] == True
        """
        try:
            # Validate required fields
            validation_result = self._validate_dataframe(df)
            if not validation_result["valid"]:
                return {
                    "success": False,
                    "rows_inserted": 0,
                    "message": validation_result["message"],
                }

            # Prepare DataFrame (clean, defaults, type conversions)
            df_clean = self._prepare_dataframe(df)

            # Warning about clear_existing
            if clear_existing:
                warnings.warn(
                    "clear_existing=True is not supported with repository pattern. "
                    "Use repository.clear_table() manually before ingestion if needed.",
                    DeprecationWarning,
                    stacklevel=2
                )

            # Delegate to repository for insertion
            result = self.repository.ingest_files_bulk(
                files_df=df_clean,
                validate=False,  # Already validated above
                if_exists="append"
            )

            return result

        except Exception as e:
            return {
                "success": False,
                "rows_inserted": 0,
                "message": f"Unexpected error during ingestion: {str(e)}",
                "error": str(e)
            }

    def _validate_dataframe(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate DataFrame against schema requirements.

        Business logic validation only - adapter handles database constraints.

        Args:
            df: DataFrame to validate

        Returns:
            Dict with 'valid' bool and 'message' str

        Example:
            >>> result = ingestion._validate_dataframe(df)
            >>> if not result['valid']:
            ...     print(f"Validation failed: {result['message']}")
        """
        # Check required fields (per schema: only raw_file_nme is NOT NULL)
        required_fields = ["raw_file_nme"]

        missing = [field for field in required_fields if field not in df.columns]
        if missing:
            return {
                "valid": False,
                "message": f"Missing required fields: {', '.join(missing)}",
            }

        # Validate raw_file_nme is not null
        if df["raw_file_nme"].isna().any():
            return {
                "valid": False,
                "message": "raw_file_nme cannot be NULL",
            }

        # Validate file_status if present
        if "file_status" in df.columns:
            valid_statuses = ["Active", "Inactive", "Archived"]
            invalid_status = df[
                df["file_status"].notna()
                & (~df["file_status"].isin(valid_statuses))
            ]
            if not invalid_status.empty:
                return {
                    "valid": False,
                    "message": f"Invalid file_status (must be Active, Inactive, or Archived) in {len(invalid_status)} rows",
                }

        return {"valid": True, "message": "Validation passed"}

    def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Prepare DataFrame for insertion.

        Handles defaults, type conversions, and column filtering.
        Only keeps columns that exist in the schema.

        Args:
            df: Raw DataFrame

        Returns:
            Prepared DataFrame with only schema-valid columns

        Example:
            >>> df_clean = ingestion._prepare_dataframe(raw_df)
            >>> assert 'raw_file_nme' in df_clean.columns
        """
        # Schema-valid columns (from 00_content_repo.sql)
        schema_columns = [
            "raw_file_nme",
            "raw_file_type",
            "raw_file_version_nbr",
            "raw_file_path",
            "extracted_markdown_file_path",
            "title_nme",
            "file_status",
            "created_dt",
            "last_modified_dt",
        ]

        # Keep only columns that are both in df AND in schema
        available_columns = [col for col in schema_columns if col in df.columns]
        df_clean = df[available_columns].copy()

        # Set defaults for optional columns
        if "raw_file_version_nbr" not in df_clean.columns:
            df_clean["raw_file_version_nbr"] = 1
        elif df_clean["raw_file_version_nbr"].isna().any():
            df_clean["raw_file_version_nbr"] = df_clean["raw_file_version_nbr"].fillna(1)

        # Ensure proper data types for Databricks compatibility
        if 'raw_file_version_nbr' in df_clean.columns:
            df_clean['raw_file_version_nbr'] = df_clean['raw_file_version_nbr'].astype('int32')

        # Convert datetime columns to proper datetime64 if they exist
        for col in ['created_dt', 'last_modified_dt']:
            if col in df_clean.columns:
                df_clean[col] = pd.to_datetime(df_clean[col])

        return df_clean

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about ingested content.

        Delegates to repository for database queries.

        Returns:
            Dict with stats: total_records, unique_files, file_types, statuses

        Example:
            >>> stats = ingestion.get_stats()
            >>> print(f"Total files: {stats['total_records']}")
            >>> print(f"File types: {stats['file_types']}")
        """
        try:
            # Get stats from repository
            stats = self.repository.get_file_stats()

            # Map to expected format for backward compatibility
            return {
                "total_records": stats.get('total_files', 0),
                "unique_files": stats.get('unique_files', 0),
                "file_types": list(stats.get('by_type', {}).keys()),
                "statuses": list(stats.get('by_status', {}).keys()),
                "by_type": stats.get('by_type', {}),
                "by_status": stats.get('by_status', {}),
                "latest_file": stats.get('latest_file', {})
            }

        except Exception as e:
            return {
                "total_records": 0,
                "unique_files": 0,
                "file_types": [],
                "statuses": [],
                "error": str(e)
            }

    def clear(self) -> Dict[str, Any]:
        """
        Clear all records from content_repo table.

        DEPRECATED: Use repository.backend.clear_table() directly.
        This method is kept for backward compatibility.

        Returns:
            Dict with success status and message

        Example:
            >>> result = ingestion.clear()
            >>> if result['success']:
            ...     print("Table cleared successfully")
        """
        warnings.warn(
            "ContentRepoIngestion.clear() is deprecated. "
            "Use repository methods directly instead.",
            DeprecationWarning,
            stacklevel=2
        )
        try:
            # Use repository backend's clear method
            result = self.repository.backend.clear_table(self.table_name)
            return result
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to clear table: {str(e)}",
                "error": str(e)
            }

    def close(self) -> None:
        """
        Close database connections and clean up resources.

        Delegates to repository backend for cleanup.

        Example:
            >>> ingestion = ContentRepoIngestion(db_path="faq.db")
            >>> try:
            ...     ingestion.ingest_from_csv("data.csv")
            ... finally:
            ...     ingestion.close()
        """
        if hasattr(self.repository, 'backend') and hasattr(self.repository.backend, 'close'):
            self.repository.backend.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

    def __repr__(self) -> str:
        """String representation."""
        return f"ContentRepoIngestion(repository={self.repository})"


# Factory function for backward compatibility
def create_content_repo_ingestion(
    db_path: Optional[str] = None,
    catalog_name: Optional[str] = None,
    schema_name: Optional[str] = None
):
    """
    Factory function to create ContentRepoIngestion instance with automatic environment detection.

    DEPRECATED: Use ContentRepoIngestion(...) directly instead.
    This function is provided for backward compatibility with existing code.

    Args:
        db_path: Path to SQLite database (for local environment)
        catalog_name: Unity Catalog name (for Databricks)
        schema_name: Schema name (for Databricks)

    Returns:
        ContentRepoIngestion instance configured for the current environment

    Example:
        >>> # Local environment (DEPRECATED)
        >>> ingestion = create_content_repo_ingestion(db_path="/path/to/db.sqlite")
        >>>
        >>> # NEW WAY - Use ContentRepoIngestion directly
        >>> ingestion = ContentRepoIngestion(db_path="/path/to/db.sqlite")
        >>>
        >>> # Or use repository directly
        >>> from database.repository import ContentRepository
        >>> from database.backends.factory import BackendFactory
        >>> from database.config import DatabaseConfig
        >>> config = DatabaseConfig.from_env()
        >>> backend = BackendFactory.create_backend(config)
        >>> repo = ContentRepository(backend)
    """
    warnings.warn(
        "create_content_repo_ingestion() is deprecated. "
        "Use ContentRepoIngestion() directly or use ContentRepository for new code.",
        DeprecationWarning,
        stacklevel=2
    )
    return ContentRepoIngestion(
        db_path=db_path,
        catalog_name=catalog_name,
        schema_name=schema_name
    )
