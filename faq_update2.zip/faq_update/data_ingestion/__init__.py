"""
Data ingestion module for granular impact analysis.

Provides simple, focused ingestion utilities for loading source data into the FAQ database.
Each ingestion module handles one or more related tables with minimal dependencies.

Modules:
- A_content_repo_ingestion: Load content_repo table from CSV/dataframe
- checksum_ingestion: Load content_checksums table (chunk checksums)
- content_repo_edit: Manage edited versions with automatic version tracking
- faq_ingestion: Load faq_questions and faq_answers tables from CSV/dataframe
- faq_source_ingestion: Load faq_question_sources and faq_answer_sources tables from CSV/dataframe
- faq_generation: Generate FAQs using oneailib pipeline (based on test2.yaml)
- loaders: File loaders for loading content from various sources (markdown, CSV, etc.)
"""

from .A_content_repo_ingestion import ContentRepoIngestion
from .chunk_ingestion import ChunkIngestion

# Re-export loaders for convenience
from data_ingestion.loaders import (
    MarkdownFileLoader,
    CSVFileLoader,
    DictListFileLoader,
)

__all__ = [
    "ContentRepoIngestion",
    "ChunkIngestion",
    # File loaders
    "MarkdownFileLoader",
    "CSVFileLoader",
    "DictListFileLoader",
]
