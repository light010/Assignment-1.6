# Similarity Module

A comprehensive text similarity calculation module providing multiple algorithms for measuring similarity between text documents.

## Overview

This module implements four core similarity algorithms optimized for FAQ change detection and policy document comparison:

- **Jaccard Similarity** - Token set overlap
- **Difflib Similarity** - Sequence matching (Ratcliff/Obershelp)
- **BM25 Similarity** - Probabilistic ranking function
- **Hybrid Similarity** - Weighted combination of multiple algorithms

## Architecture

The module follows a clean architecture pattern with:

- **Interface-based design** using `ISimilarityCalculator` from `core.interfaces`
- **Composition over inheritance** using utility functions from `utility` module
- **No circular dependencies** between core, utility, and similarity modules
- **Factory methods** for common use cases

```
similarity/
├── jaccard_sim.py          # Jaccard-based calculators
├── difflib_sim.py          # Difflib-based calculators
├── bm25_sim.py             # BM25 calculator
├── hybrid.py               # Hybrid & policy-specific calculators
└── __init__.py             # Public exports
```

## Quick Start

### Basic Usage

```python
from similarity import JaccardSimilarityCalculator

calc = JaccardSimilarityCalculator()
result = calc.compute_similarity("hello world", "hello there")

print(f"Score: {result.score:.3f}")  # 0.333
print(f"Algorithm: {result.algorithm}")  # jaccard
```

### Using Different Algorithms

```python
from similarity import (
    JaccardSimilarityCalculator,
    DifflibSimilarityCalculator,
    BM25SimilarityCalculator,
    HybridSimilarityCalculator,
)

text1 = "Employees receive 10 sick days per year"
text2 = "Employees receive 12 sick days per year"

# Jaccard - token overlap
jaccard = JaccardSimilarityCalculator()
print(f"Jaccard: {jaccard.compute_similarity(text1, text2).score:.3f}")

# Difflib - character sequence matching
difflib = DifflibSimilarityCalculator()
print(f"Difflib: {difflib.compute_similarity(text1, text2).score:.3f}")

# BM25 - probabilistic ranking
bm25 = BM25SimilarityCalculator()
print(f"BM25: {bm25.compute_similarity(text1, text2).score:.3f}")

# Hybrid - weighted combination
hybrid = HybridSimilarityCalculator()
print(f"Hybrid: {hybrid.compute_similarity(text1, text2).score:.3f}")
```

### FAQ Modification Detection

Use the specialized `PolicyContentSimilarity` for detecting changes in policy documents:

```python
from similarity import PolicyContentSimilarity

calc = PolicyContentSimilarity()

old_text = "Employees receive 15 vacation days"
new_text = "Employees receive 20 vacation days"

# Check if it's a modification
is_mod = calc.is_modification(old_text, new_text, threshold=0.80)
print(f"Is modification: {is_mod}")  # True

# Get detailed classification
change_type, score, details = calc.classify_change(old_text, new_text)
print(f"Change type: {change_type}")  # "minor_modification"
print(f"Score: {score:.3f}")
print(f"Breakdown: {details['breakdown']}")
```

## Algorithms

### 1. Jaccard Similarity

Token-based set overlap similarity.

**Best for:** Quick comparisons, early filtering, duplicate detection

**Formula:** `|A ∩ B| / |A ∪ B|`

```python
from similarity import JaccardSimilarityCalculator, WeightedJaccardSimilarityCalculator

# Standard Jaccard
calc = JaccardSimilarityCalculator(
    lowercase=True,
    remove_punctuation=True,
    min_token_length=1
)

# Weighted Jaccard (for term importance)
weighted = WeightedJaccardSimilarityCalculator(
    term_weights={"important": 2.0, "keyword": 1.5}
)
```

### 2. Difflib Similarity

Character-level sequence matching using Python's difflib.

**Best for:** Detecting small changes (e.g., "10" → "12"), character-level edits

**Features:**
- Character-level and token-level modes
- Diff block extraction
- LLM-friendly diff formatting

```python
from similarity import DifflibSimilarityCalculator, create_faq_modification_detector

# Standard difflib
calc = DifflibSimilarityCalculator(
    autojunk=True,
    use_quick_ratio=False,
    lowercase=True,
    remove_punctuation=False  # Keep numbers/dates intact
)

# Factory method for FAQ detection
faq_calc = create_faq_modification_detector()

# Get detailed diff
diff_blocks = calc.get_diff_blocks(text1, text2)
llm_diff = calc.get_llm_friendly_diff_line_based(text1, text2)
```

### 3. BM25 Similarity

Probabilistic ranking function for information retrieval.

**Best for:** Semantic similarity, document ranking, search relevance

**Parameters:**
- `k1` (1.2-2.0): Term frequency saturation
- `b` (0-1): Document length normalization

```python
from similarity import BM25SimilarityCalculator

calc = BM25SimilarityCalculator(
    k1=1.5,
    b=0.75,
    lowercase=True,
    remove_punctuation=True
)

# Factory method for FAQ detection
faq_calc = BM25SimilarityCalculator.for_faq_modification_detection()
```

### 4. Hybrid Similarity

Weighted combination of multiple algorithms with early-exit optimization.

**Best for:** Balanced approach, production use cases, policy comparison

**Features:**
- Configurable algorithm weights
- Early exit optimization (skip expensive calculations if Jaccard < threshold)
- Detailed breakdown of individual scores

```python
from similarity import HybridSimilarityCalculator

# Custom weights
calc = HybridSimilarityCalculator(
    weights={
        "jaccard": 0.40,
        "difflib": 0.60,
    },
    early_exit_threshold=0.3  # Skip if Jaccard < 0.3
)

# Factory methods
mod_detector = HybridSimilarityCalculator.for_modification_detection()
general = HybridSimilarityCalculator.for_general_similarity()

# Get breakdown
breakdown = calc.get_algorithm_breakdown(text1, text2)
print(breakdown)  # {"jaccard": 0.5, "difflib": 0.8}
```

## Factory Methods

Convenient pre-configured calculators for common use cases:

```python
from similarity import (
    create_faq_modification_detector,
    create_character_level_analyzer,
    create_fast_diff_calculator,
)

# FAQ modification detection (preserves numbers/dates)
faq_calc = create_faq_modification_detector()

# Character-level analysis (case-sensitive, no preprocessing)
char_calc = create_character_level_analyzer()

# Fast difflib (uses quick_ratio)
fast_calc = create_fast_diff_calculator()
```

## SimilarityResult Object

All calculators return a `SimilarityResult` object:

```python
result = calc.compute_similarity(text1, text2)

print(result.score)       # Float [0.0, 1.0]
print(result.text1)       # Original text1
print(result.text2)       # Original text2
print(result.algorithm)   # Algorithm name (e.g., "jaccard")
print(result.metadata)    # Dict with algorithm-specific details

# Check against threshold
from similarity import SimilarityThreshold

is_high = result.is_similar(SimilarityThreshold.HIGH)  # >= 0.80
is_medium = result.is_similar(SimilarityThreshold.MEDIUM)  # >= 0.60

# Convert to dict
result_dict = result.to_dict()
```

## Advanced Features

### Policy Content Similarity

Specialized calculator for policy documents:

```python
from similarity import PolicyContentSimilarity

calc = PolicyContentSimilarity()

# Classification categories:
# - "identical": >= 0.95
# - "minor_modification": >= 0.85
# - "major_modification": >= 0.70
# - "significant_change": >= 0.40
# - "new_content": < 0.40

change_type, score, details = calc.classify_change(old_text, new_text)
```

### Difflib Diff Extraction

Get human-readable or JSON diffs:

```python
from similarity import DifflibSimilarityCalculator

calc = DifflibSimilarityCalculator()

# Human-readable diff
diff = calc.get_llm_friendly_diff_line_based(
    text1,
    text2,
    context_lines=2,
    show_inline_changes=True
)
print(diff)

# JSON format
import json
json_diff = calc.get_llm_friendly_diff_json(text1, text2)
diff_data = json.loads(json_diff)
```

### Hybrid Algorithm Breakdown

See individual algorithm contributions:

```python
from similarity import HybridSimilarityCalculator

calc = HybridSimilarityCalculator()
result = calc.compute_similarity(text1, text2)

# Individual scores
print(result.metadata['individual_scores'])
# {"jaccard": 0.5, "difflib": 0.8}

# Early exit info
print(result.metadata['early_exit'])  # True/False
print(result.metadata['algorithms_skipped'])  # ["bm25"] if early exit
```

## Configuration Options

All calculators support these preprocessing options:

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `lowercase` | bool | True | Convert text to lowercase |
| `remove_punctuation` | bool | True | Remove punctuation marks |
| `min_token_length` | int | 1 | Minimum token length to keep |

**Example:**

```python
calc = JaccardSimilarityCalculator(
    lowercase=True,           # Case-insensitive
    remove_punctuation=False, # Keep numbers, dates
    min_token_length=2        # Skip 1-char tokens
)
```

## Performance Tips

1. **Use Early Exit** - For large-scale comparisons, enable early exit in Hybrid:
   ```python
   calc = HybridSimilarityCalculator(early_exit_threshold=0.3)
   ```

2. **Choose the Right Algorithm**:
   - **Jaccard** - Fastest, good for filtering
   - **Difflib** - Best for small edits
   - **BM25** - Best for semantic similarity
   - **Hybrid** - Best accuracy, slower

3. **Use Factory Methods** - Pre-optimized for common use cases

4. **Batch Processing** - Process multiple comparisons efficiently:
   ```python
   calc = JaccardSimilarityCalculator()
   results = [calc.compute_similarity(query, doc) for doc in documents]
   ```

## Testing

Run the similarity module tests:

```bash
# Basic functionality test
python -c "from similarity import *; print('✅ All imports work')"

# Test all calculators
pytest tests/similarity/
```

## Migration from Base Class

If you were using the old `BaseSimilarityCalculator`:

**Before:**
```python
from similarity.base import BaseSimilarityCalculator
```

**After:**
```python
from core.interfaces.similarity import ISimilarityCalculator
from similarity import SimilarityResult
```

The interface remains the same - all calculators implement `compute_similarity()` and `get_algorithm_name()`.

## API Reference

### ISimilarityCalculator Interface

```python
class ISimilarityCalculator(ABC):
    @abstractmethod
    def compute_similarity(self, text1: str, text2: str) -> SimilarityResult:
        """Compute similarity between two texts."""
        pass

    @abstractmethod
    def get_algorithm_name(self) -> str:
        """Get the algorithm name."""
        pass
```

### Exports

```python
from similarity import (
    # Interface
    ISimilarityCalculator,

    # Models
    SimilarityResult,
    SimilarityThreshold,

    # Calculators
    JaccardSimilarityCalculator,
    WeightedJaccardSimilarityCalculator,
    DifflibSimilarityCalculator,
    TokenBasedDifflibCalculator,
    BM25SimilarityCalculator,
    HybridSimilarityCalculator,
    PolicyContentSimilarity,

    # Utilities
    DiffBlock,
    create_faq_modification_detector,
    create_character_level_analyzer,
    create_fast_diff_calculator,
)
```

## Examples

### Example 1: FAQ Change Detection

```python
from similarity import PolicyContentSimilarity

calc = PolicyContentSimilarity()

old_faq = "Q: How many sick days? A: Employees get 10 sick days per year."
new_faq = "Q: How many sick days? A: Employees get 12 sick days per year."

change_type, score, details = calc.classify_change(old_faq, new_faq)

if change_type == "minor_modification":
    print(f"Minor change detected (score: {score:.3f})")
    print(f"Breakdown: {details['breakdown']}")
```

### Example 2: Document Deduplication

```python
from similarity import JaccardSimilarityCalculator, SimilarityThreshold

calc = JaccardSimilarityCalculator()
documents = ["doc1 text...", "doc2 text...", "doc3 text..."]

# Find duplicates
for i, doc1 in enumerate(documents):
    for doc2 in documents[i+1:]:
        result = calc.compute_similarity(doc1, doc2)
        if result.is_similar(SimilarityThreshold.HIGH):
            print(f"Duplicate found: {result.score:.3f}")
```

### Example 3: Hybrid with Custom Weights

```python
from similarity import HybridSimilarityCalculator

# Emphasize difflib for precise change detection
calc = HybridSimilarityCalculator(
    weights={
        "jaccard": 0.20,
        "difflib": 0.80,
    },
    early_exit_threshold=0.25
)

result = calc.compute_similarity(text1, text2)
print(f"Weighted score: {result.score:.3f}")
print(f"Individual scores: {result.metadata['individual_scores']}")
```

## License

Part of the FAQ Combined project.

---

**Last Updated:** 2025-11-01
**Version:** 2.0 (Post-refactoring)
