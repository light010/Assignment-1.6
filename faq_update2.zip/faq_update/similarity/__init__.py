"""
Similarity Module - Text Similarity Algorithms

Provides various algorithms for measuring text similarity.
"""

# Re-export from core for convenience
from core.interfaces.similarity import ISimilarityCalculator
from core.models.similarity import SimilarityResult, SimilarityThreshold

# Export calculator implementations
from similarity.jaccard_sim import (
    JaccardSimilarityCalculator,
    WeightedJaccardSimilarityCalculator,
)
from similarity.difflib_sim import (
    DifflibSimilarityCalculator,
    TokenBasedDifflibCalculator,
    DiffBlock,
    create_faq_modification_detector,
    create_character_level_analyzer,
    create_fast_diff_calculator,
)
from similarity.bm25_sim import BM25SimilarityCalculator
from similarity.hybrid import (
    HybridSimilarityCalculator,
    PolicyContentSimilarity,
)

__all__ = [
    # Interface
    "ISimilarityCalculator",
    # Models
    "SimilarityResult",
    "SimilarityThreshold",
    # Jaccard
    "JaccardSimilarityCalculator",
    "WeightedJaccardSimilarityCalculator",
    # Difflib
    "DifflibSimilarityCalculator",
    "TokenBasedDifflibCalculator",
    "DiffBlock",
    "create_faq_modification_detector",
    "create_character_level_analyzer",
    "create_fast_diff_calculator",
    # BM25
    "BM25SimilarityCalculator",
    # Hybrid
    "HybridSimilarityCalculator",
    "PolicyContentSimilarity",
]
