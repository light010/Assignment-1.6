"""
Data validation utilities.

Provides validators for:
- Text content
- Configuration values
- Database records
- File formats
- Referential integrity
"""

import re
from typing import Dict, Optional

# NOTE: Table-specific validation has been moved to dataclass __post_init__ methods in database/models.py


def validate_text_content(text: str, min_length: int = 1, max_length: Optional[int] = None) -> bool:
    """
    Validate text content.

    Args:
        text: Text to validate
        min_length: Minimum length
        max_length: Maximum length (optional)

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(text, str):
        raise ValueError(f"Text must be string, got {type(text)}")

    if len(text) < min_length:
        raise ValueError(f"Text length {len(text)} below minimum {min_length}")

    if max_length and len(text) > max_length:
        raise ValueError(f"Text length {len(text)} exceeds maximum {max_length}")

    return True


def validate_score(score: float, min_val: float = 0.0, max_val: float = 1.0) -> bool:
    """
    Validate a score is in valid range.

    Args:
        score: Score value
        min_val: Minimum value
        max_val: Maximum value

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(score, (int, float)):
        raise ValueError(f"Score must be numeric, got {type(score)}")

    if not (min_val <= score <= max_val):
        raise ValueError(f"Score {score} not in range [{min_val}, {max_val}]")

    return True


def validate_checksum(checksum: str, algorithm: str = "sha256") -> bool:
    """
    Validate checksum format.

    Args:
        checksum: Checksum string
        algorithm: Algorithm used (sha256, md5, sha1)

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    expected_lengths = {
        "md5": 32,
        "sha1": 40,
        "sha256": 64,
        "sha512": 128,
    }

    if algorithm not in expected_lengths:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    if not isinstance(checksum, str):
        raise ValueError(f"Checksum must be string, got {type(checksum)}")

    if not re.match(r"^[a-f0-9]+$", checksum.lower()):
        raise ValueError("Checksum must contain only hexadecimal characters")

    expected_len = expected_lengths[algorithm]
    if len(checksum) != expected_len:
        raise ValueError(
            f"Checksum length {len(checksum)} doesn't match expected {expected_len} for {algorithm}"
        )

    return True


def validate_content_id(content_id: str) -> bool:
    """
    Validate content ID format.

    Args:
        content_id: Content identifier

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(content_id, str):
        raise ValueError(f"Content ID must be string, got {type(content_id)}")

    if len(content_id.strip()) == 0:
        raise ValueError("Content ID cannot be empty")

    return True


def validate_faq_id(faq_id: str) -> bool:
    """
    Validate FAQ ID format.

    Args:
        faq_id: FAQ identifier

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(faq_id, str):
        raise ValueError(f"FAQ ID must be string, got {type(faq_id)}")

    if len(faq_id.strip()) == 0:
        raise ValueError("FAQ ID cannot be empty")

    return True


def validate_weights(weights: Dict[str, float], tolerance: float = 0.01) -> bool:
    """
    Validate that weights sum to 1.0.

    Args:
        weights: Dictionary of weights
        tolerance: Tolerance for floating point comparison

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(weights, dict):
        raise ValueError(f"Weights must be dict, got {type(weights)}")

    if not weights:
        raise ValueError("Weights dictionary cannot be empty")

    # Check all values are numeric
    for key, val in weights.items():
        if not isinstance(val, (int, float)):
            raise ValueError(f"Weight for '{key}' must be numeric, got {type(val)}")
        if val < 0:
            raise ValueError(f"Weight for '{key}' cannot be negative: {val}")

    # Check sum
    total = sum(weights.values())
    if not (1.0 - tolerance <= total <= 1.0 + tolerance):
        raise ValueError(
            f"Weights must sum to 1.0 (±{tolerance}), got {total}. Weights: {weights}"
        )

    return True


# ==============================================================================
# Referential Integrity Validation
# ==============================================================================
# Application-level foreign key validation for databases that don't support
# FK constraints to non-primary key columns (e.g., Databricks Unity Catalog)


class ReferentialIntegrityError(ValueError):
    """Raised when referential integrity validation fails."""
    pass


def get_valid_content_checksums(adapter, table_name: str = "content_chunks") -> set:
    """
    Get set of valid content checksums from content_chunks table.

    Args:
        adapter: DatabaseAdapter instance (SQLite or Databricks)
        table_name: Name of content chunks table (default: content_chunks)

    Returns:
        Set of valid content_checksum strings

    Example:
        >>> from database.adapters import create_adapter
        >>> adapter = create_adapter("sqlite", db_path="faq.db")
        >>> valid_checksums = get_valid_content_checksums(adapter)
        >>> print(f"Found {len(valid_checksums)} valid checksums")
    """
    query = f"SELECT DISTINCT content_checksum FROM {table_name}"
    result = adapter.execute_query(query)
    return {row[0] for row in result}


def validate_source_checksums(
    df,
    valid_checksums: set,
    checksum_column: str = "content_checksum"
) -> tuple[bool, list]:
    """
    Validate that all checksums in DataFrame exist in valid set.

    Args:
        df: DataFrame (pandas or PySpark) with checksum column
        valid_checksums: Set of valid checksums from content_chunks
        checksum_column: Name of checksum column (default: content_checksum)

    Returns:
        Tuple of (is_valid, invalid_checksums)
        - is_valid: True if all checksums are valid
        - invalid_checksums: List of invalid checksum values

    Raises:
        ReferentialIntegrityError: If invalid checksums found

    Example:
        >>> valid_checksums = get_valid_content_checksums(adapter)
        >>> is_valid, invalid = validate_source_checksums(question_df, valid_checksums)
        >>> if not is_valid:
        ...     raise ReferentialIntegrityError(f"Invalid checksums: {invalid}")
    """
    # Handle both pandas and PySpark DataFrames
    try:
        # Try pandas first
        checksums = set(df[checksum_column].unique())
    except AttributeError:
        # Fall back to PySpark
        checksums = {row[checksum_column] for row in df.select(checksum_column).distinct().collect()}

    invalid_checksums = checksums - valid_checksums

    if invalid_checksums:
        return False, list(invalid_checksums)

    return True, []


def validate_question_sources(df, adapter, raise_on_error: bool = True) -> tuple[bool, list]:
    """
    Validate faq_question_sources DataFrame before insertion.

    Args:
        df: DataFrame with faq_question_sources data
        adapter: DatabaseAdapter instance
        raise_on_error: If True, raises ReferentialIntegrityError on invalid checksums

    Returns:
        Tuple of (is_valid, invalid_checksums)

    Raises:
        ReferentialIntegrityError: If raise_on_error=True and validation fails

    Example:
        >>> from database.adapters import create_adapter
        >>> adapter = create_adapter("sqlite", db_path="faq.db")
        >>> validate_question_sources(question_sources_df, adapter)
        (True, [])
    """
    valid_checksums = get_valid_content_checksums(adapter)
    is_valid, invalid = validate_source_checksums(df, valid_checksums, "content_checksum")

    if not is_valid and raise_on_error:
        raise ReferentialIntegrityError(
            f"Found {len(invalid)} invalid content_checksum references in question sources: {invalid[:10]}"
        )

    return is_valid, invalid


def validate_answer_sources(df, adapter, raise_on_error: bool = True) -> tuple[bool, list]:
    """
    Validate faq_answer_sources DataFrame before insertion.

    Args:
        df: DataFrame with faq_answer_sources data
        adapter: DatabaseAdapter instance
        raise_on_error: If True, raises ReferentialIntegrityError on invalid checksums

    Returns:
        Tuple of (is_valid, invalid_checksums)

    Raises:
        ReferentialIntegrityError: If raise_on_error=True and validation fails

    Example:
        >>> from database.adapters import create_adapter
        >>> adapter = create_adapter("sqlite", db_path="faq.db")
        >>> validate_answer_sources(answer_sources_df, adapter)
        (True, [])
    """
    valid_checksums = get_valid_content_checksums(adapter)
    is_valid, invalid = validate_source_checksums(df, valid_checksums, "content_checksum")

    if not is_valid and raise_on_error:
        raise ReferentialIntegrityError(
            f"Found {len(invalid)} invalid content_checksum references in answer sources: {invalid[:10]}"
        )

    return is_valid, invalid


def get_orphaned_checksums(
    adapter,
    source_table: str,
    chunks_table: str = "content_chunks"
) -> list:
    """
    Find checksums in source table that don't exist in chunks table.

    Useful for debugging data integrity issues.

    Args:
        adapter: DatabaseAdapter instance
        source_table: Name of source table (faq_question_sources or faq_answer_sources)
        chunks_table: Name of chunks table (default: content_chunks)

    Returns:
        List of orphaned checksum values

    Example:
        >>> orphaned = get_orphaned_checksums(adapter, "faq_question_sources")
        >>> if orphaned:
        ...     print(f"Found {len(orphaned)} orphaned checksums")
    """
    query = f"""
        SELECT DISTINCT s.content_checksum
        FROM {source_table} s
        LEFT JOIN {chunks_table} c ON s.content_checksum = c.content_checksum
        WHERE c.content_checksum IS NULL
    """
    result = adapter.execute_query(query)
    return [row[0] for row in result]


def clean_orphaned_sources(
    adapter,
    source_table: str,
    dry_run: bool = True,
    chunks_table: str = "content_chunks"
) -> int:
    """
    Remove orphaned records from source tables.

    WARNING: This modifies data. Use dry_run=True first to preview.

    Args:
        adapter: DatabaseAdapter instance
        source_table: Name of source table to clean
        dry_run: If True, only counts records without deleting
        chunks_table: Name of chunks table (default: content_chunks)

    Returns:
        Number of records that would be/were deleted

    Example:
        >>> # Preview what would be deleted
        >>> count = clean_orphaned_sources(adapter, "faq_question_sources", dry_run=True)
        >>> print(f"Would delete {count} orphaned records")
        >>>
        >>> # Actually delete
        >>> if count > 0:
        ...     deleted = clean_orphaned_sources(adapter, "faq_question_sources", dry_run=False)
        ...     print(f"Deleted {deleted} orphaned records")
    """
    # Count orphaned records
    count_query = f"""
        SELECT COUNT(*)
        FROM {source_table} s
        LEFT JOIN {chunks_table} c ON s.content_checksum = c.content_checksum
        WHERE c.content_checksum IS NULL
    """
    count_result = adapter.execute_query(count_query)
    count = count_result[0][0] if count_result else 0

    if count == 0 or dry_run:
        return count

    # Delete orphaned records
    delete_query = f"""
        DELETE FROM {source_table}
        WHERE content_checksum NOT IN (
            SELECT DISTINCT content_checksum FROM {chunks_table}
        )
    """
    adapter.execute_query(delete_query)
    return count


# NOTE: Table-specific validation has been moved to dataclass __post_init__ methods in database/models.py
# This provides automatic validation when creating model instances and ensures consistency across platforms

__all__ = [
    # Basic validators
    'validate_text_content',
    'validate_score',
    'validate_checksum',
    'validate_content_id',
    'validate_faq_id',
    'validate_weights',
    # Referential integrity validators
    'ReferentialIntegrityError',
    'get_valid_content_checksums',
    'validate_source_checksums',
    'validate_question_sources',
    'validate_answer_sources',
    'get_orphaned_checksums',
    'clean_orphaned_sources',
]
