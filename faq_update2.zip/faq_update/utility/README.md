# Utility Module - Infrastructure Layer

## Overview

The `utility` module represents the **infrastructure layer** of the application - it defines **HOW** the system performs technical operations, not **WHAT** business operations it performs. This module contains technical utilities with **no knowledge of business domain concepts**.

**Version 2.0.0** - Consolidated from the old `utils/` module to provide a unified infrastructure layer.

## Architecture Principles

### Clean Architecture
```
┌─────────────┐         ┌─────────────┐
│  chunking   │────────>│    core     │<────────┤  utility   │
│ (implement) │         │  (domain)   │         │  (infra)   │
└─────────────┘         └─────────────┘         └─────────────┘
```

**Dependency Direction**: `chunking → core ← utility`

- **Utility has NO business logic** - it's pure infrastructure
- **Utility MAY depend on core** - for domain exceptions if needed
- **Chunking uses utility** - for technical operations like hashing

### The "WHAT vs HOW" Test

| Concept | What/How? | Module |
|---------|-----------|--------|
| "Compute SHA-256 hash of text" | HOW | utility |
| "Track chunk changes via checksums" | WHAT | core/chunking |
| "A chunk needs metadata" | WHAT | core |
| "Encode text as UTF-8 for hashing" | HOW | utility |
| "Detect Databricks environment" | HOW | utility |
| "Setup logging for application" | HOW | utility |
| "Validate data before insertion" | HOW | utility |

## Module Structure

```
utility/
├── __init__.py           # Public API exports (unified interface)
├── README.md             # This file
├── hashing.py            # Cryptographic hashing (compute_checksum)
├── text_processing.py    # Text manipulation and validation
├── normalization.py      # Score normalization functions
├── file_io.py            # File I/O operations (CSV, JSON)
├── environment.py        # Environment detection (Databricks vs local)
├── database.py           # Database utilities (SQLite connection management)
├── logging.py            # Logging utilities (loguru integration)
├── metrics.py            # Performance metrics collection
└── validation.py         # Data validation utilities
```

## Components

### Hashing Utilities

**compute_checksum()** - Compute SHA-256 checksum for text content

```python
from utility import compute_checksum

# Compute checksum
checksum = compute_checksum("Hello world")
print(len(checksum))  # 64 (SHA-256 hex digest)

# Empty string has known checksum
empty_checksum = compute_checksum("")
assert empty_checksum == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
```

**Key Features:**
- **Single source of truth** for checksum computation
- Uses algorithm from `config.constants` (currently SHA-256)
- UTF-8 text encoding
- Hexadecimal output (lowercase)
- Deterministic (same input = same output)

**Used By:**
- `chunking` module - for chunk fingerprinting
- `detection` module - for change detection
- `data_ingestion` module - for content tracking

## New in Version 2.0.0

### Environment Detection
```python
from utility import is_databricks, get_workspace_root, setup_widgets

# Detect environment
if is_databricks():
    catalog, schema = setup_widgets("my_catalog", "my_schema")
    workspace_root = get_workspace_root()
else:
    # Local development
    workspace_root = get_workspace_root()
```

### Logging
```python
from utility import get_logger, setup_logging, LogContext

# Setup logging once at application start
setup_logging(log_level="INFO", log_to_console=True)

# Get logger in any module
logger = get_logger(__name__)
logger.info("Processing started")

# Use context for structured logging
with LogContext(user_id="123", operation="import"):
    logger.info("User operation logged with context")
```

### Database Utilities
```python
from utility import get_sqlite_connection, close_all_sqlite_connections

# Get connection with proper settings
conn = get_sqlite_connection("databases/my.db")

# Do work...
cursor = conn.cursor()
cursor.execute("SELECT * FROM content_chunks")

# Clean up properly
conn.close()
close_all_sqlite_connections()
```

### Performance Metrics
```python
from utility import MetricsCollector

collector = MetricsCollector()

# Track an operation
with collector.track_operation("data_ingestion", source="csv"):
    # Do work...
    pass

# Get summary
summary = collector.get_summary()
print(f"Total duration: {summary['total_duration_ms']}ms")
```

### Validation
```python
from utility import validate_checksum, validate_score, ReferentialIntegrityError
from utility import validate_question_sources

# Basic validation
validate_checksum("abc123...")  # Raises ValueError if invalid
validate_score(0.85)  # Validates score is in [0, 1]

# Referential integrity validation
try:
    validate_question_sources(question_df, adapter)
except ReferentialIntegrityError as e:
    print(f"Integrity violation: {e}")
```

## Usage Examples

### Basic Hashing

```python
from utility import compute_checksum

# Hash content
content = "This is my document content"
checksum = compute_checksum(content)

# Use checksum for comparison
previous_checksum = "abc123..."
if checksum != previous_checksum:
    print("Content has changed!")
```

### Integration with Chunking

```python
from utility import compute_checksum

# In a chunker implementation
def chunk_with_checksums(self, content: str):
    chunks = self.chunk(content)
    results = []
    for idx, chunk_text in enumerate(chunks):
        # Use utility for hashing
        checksum = compute_checksum(chunk_text)
        metadata = ChunkMetadata(chunk_index=idx, chunk_method="recursive")
        results.append((chunk_text, checksum, metadata))
    return results
```

### File I/O Operations
```python
from utility import export_to_csv, export_to_json, load_csv

# Export data
checksums_data = {
    "abc123": {"text": "content", "page_num": 1}
}
export_to_csv(checksums_data, "output.csv")
export_to_json(checksums_data, "output.json")

# Load data
loaded_data = load_csv("previous_data.csv")
```

## Design Decisions

### Why Centralized Hashing?

Before refactoring, we had **duplicate** checksum logic:
- `chunking/checksum.py::compute_checksum()` (function)
- `detection/checksum_extractor.py::ChecksumExtractor.compute_checksum()` (method)

**Problems:**
1. Code duplication
2. Risk of inconsistency
3. Harder to change algorithm globally

**Solution:**
Single `utility.hashing.compute_checksum()` function used everywhere.

### Why SHA-256?

Configured in `config.constants.CHECKSUM_ALGORITHM`:
- **Cryptographically strong** - collision resistant
- **Fast** - good performance even for large texts
- **Standard** - widely supported, 64-char hex output
- **Deterministic** - critical for change detection

### Why UTF-8 Encoding?

- **Universal** - handles all languages and characters
- **Standard** - Python 3 default
- **Consistent** - same encoding everywhere

## Testing

Utility module components should be tested with:

```python
# Test determinism
def test_compute_checksum_deterministic():
    text = "test content"
    checksum1 = compute_checksum(text)
    checksum2 = compute_checksum(text)
    assert checksum1 == checksum2

# Test uniqueness
def test_compute_checksum_different_content():
    checksum1 = compute_checksum("text1")
    checksum2 = compute_checksum("text2")
    assert checksum1 != checksum2

# Test empty string
def test_compute_checksum_empty():
    checksum = compute_checksum("")
    # Known SHA-256 hash of empty string
    assert checksum == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
```

## Migration from Duplicate Code

**Before (chunking module):**
```python
from chunking.checksum import compute_checksum
```

**Before (detection module):**
```python
from detection.checksum_extractor import ChecksumExtractor
extractor = ChecksumExtractor()
checksum = extractor.compute_checksum(text)
```

**After (unified):**
```python
from utility import compute_checksum
checksum = compute_checksum(text)
```

**Backward Compatibility:**
- `chunking.checksum` becomes facade (re-exports from utility)
- `ChecksumExtractor` refactored to use utility internally
- Old import paths still work during transition

## FAQs

**Q: Can I add other hashing algorithms?**
A: Yes, but modify `config.constants.CHECKSUM_ALGORITHM`. Current code uses `getattr(hashlib, CHECKSUM_ALGORITHM)` so any hashlib algorithm works (sha256, sha512, md5, etc.).

**Q: Why not use MD5?**
A: MD5 is cryptographically broken. While we're not using checksums for security, SHA-256 provides better collision resistance with minimal performance cost.

**Q: Should I use utility for business logic?**
A: NO. Utility is for infrastructure only. Business logic belongs in `core` or `chunking` modules.

**Q: Can utility import from core?**
A: Yes, if needed for domain exceptions. But avoid it if possible - utility should be as independent as possible.

**Q: What other utilities might go here in the future?**
A: Candidates:
- File I/O helpers (if used by multiple modules)
- Logging utilities (if standardized across modules)
- Data transformation helpers (if generic enough)
- NOT: Chunking-specific code (belongs in chunking module)

## Migration Guide (from old `utils/` module)

### Version 2.0.0 Migration

The old `utils/` module has been consolidated into `utility/` for better organization. Here's how to update your code:

#### Import Changes

**OLD (utils):**
```python
from utils.env_utils import is_databricks, get_workspace_root
from utils.db_utils import get_sqlite_connection, close_all_sqlite_connections
from utils.logging_utils import get_logger, setup_logging
from utils.metrics import MetricsCollector, PerformanceMetrics
from utils.validators import validate_checksum, validate_score
```

**NEW (utility):**
```python
from utility.environment import is_databricks, get_workspace_root
from utility.database import get_sqlite_connection, close_all_sqlite_connections
from utility.logging import get_logger, setup_logging
from utility.metrics import MetricsCollector, PerformanceMetrics
from utility.validation import validate_checksum, validate_score
```

**OR use the unified import:**
```python
from utility import (
    is_databricks, get_workspace_root,
    get_sqlite_connection, close_all_sqlite_connections,
    get_logger, setup_logging,
    MetricsCollector, PerformanceMetrics,
    validate_checksum, validate_score
)
```

#### Module Name Mapping

| Old Module | New Module | Description |
|-----------|-----------|-------------|
| `utils.env_utils` | `utility.environment` | Environment detection |
| `utils.db_utils` | `utility.database` | Database utilities |
| `utils.logging_utils` | `utility.logging` | Logging setup |
| `utils.metrics` | `utility.metrics` | Performance metrics |
| `utils.validators` | `utility.validation` | Data validation |

#### Functional Changes

All functions maintain the same signatures and behavior. No code changes are required beyond updating imports.

#### Deprecated

- The old `utils/` module is deprecated and will be removed in a future version
- All code in `faq_update/` has been updated to use `utility/`
- Update any custom scripts or notebooks to use the new imports

## Version History

- **2.0.0** - Consolidated utils module into utility, added environment, database, logging, metrics, and validation utilities
- **1.0.0** - Initial release with compute_checksum() hashing utility
