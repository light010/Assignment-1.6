"""
Normalization Utilities - Score Normalization Functions

This module provides mathematical normalization functions for converting
unbounded or arbitrary-range scores into normalized [0, 1] ranges.

Functions:
    - sigmoid_normalize: Sigmoid-based normalization for unbounded scores
    - linear_normalize: Linear scaling between min and max values

These utilities are used by similarity algorithms (e.g., BM25) to ensure
all scores are comparable on a [0, 1] scale.
"""

import math


def sigmoid_normalize(score: float, scale: float = 2.0) -> float:
    """
    Normalize unbounded score to [0, 1] range using sigmoid function.

    Uses the logistic sigmoid function:
        σ(x) = 1 / (1 + e^(-x/scale))

    The scale parameter controls the steepness of the sigmoid curve.
    Smaller scale = steeper curve (faster saturation).
    Larger scale = gentler curve (slower saturation).

    Args:
        score: Unbounded score (can be negative, zero, or positive)
        scale: Scaling factor for the sigmoid (default: 2.0)

    Returns:
        Normalized score between 0.0 and 1.0

    Mathematical Properties:
        - σ(-∞) → 0.0
        - σ(0) = 0.5
        - σ(+∞) → 1.0
        - Monotonically increasing
        - Symmetric around 0.5

    Example:
        >>> sigmoid_normalize(0.0)
        0.5
        >>> sigmoid_normalize(10.0)  # Large positive
        0.9933071490757153
        >>> sigmoid_normalize(-10.0)  # Large negative
        0.006692850924284856
        >>> sigmoid_normalize(2.0, scale=1.0)  # Steeper curve
        0.8807970779778823
        >>> sigmoid_normalize(2.0, scale=4.0)  # Gentler curve
        0.6224593312018546
    """
    try:
        return 1.0 / (1.0 + math.exp(-score / scale))
    except OverflowError:
        # Handle extreme negative values that cause exp() overflow
        return 0.0 if score < 0 else 1.0


def linear_normalize(
    score: float, min_val: float, max_val: float, clamp: bool = True
) -> float:
    """
    Normalize score to [0, 1] range using linear scaling.

    Maps [min_val, max_val] → [0.0, 1.0] using linear interpolation:
        normalized = (score - min_val) / (max_val - min_val)

    Args:
        score: Score to normalize
        min_val: Minimum value of input range
        max_val: Maximum value of input range
        clamp: Whether to clamp output to [0, 1] (default: True)

    Returns:
        Normalized score between 0.0 and 1.0 (if clamped)

    Raises:
        ValueError: If min_val >= max_val

    Example:
        >>> linear_normalize(5.0, 0.0, 10.0)
        0.5
        >>> linear_normalize(7.5, 0.0, 10.0)
        0.75
        >>> linear_normalize(-5.0, 0.0, 10.0)  # Below min, clamped
        0.0
        >>> linear_normalize(15.0, 0.0, 10.0)  # Above max, clamped
        1.0
        >>> linear_normalize(15.0, 0.0, 10.0, clamp=False)  # Not clamped
        1.5
    """
    if min_val >= max_val:
        raise ValueError(
            f"min_val must be less than max_val, got min={min_val}, max={max_val}"
        )

    # Linear interpolation
    normalized = (score - min_val) / (max_val - min_val)

    # Clamp to [0, 1] if requested
    if clamp:
        normalized = max(0.0, min(1.0, normalized))

    return normalized


# Convenience exports
__all__ = [
    "sigmoid_normalize",
    "linear_normalize",
]
