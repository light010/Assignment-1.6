"""
File I/O Utility Functions for Detection Module

This module provides reusable file I/O functions for working with checksums and content data.
These functions are extracted from ChecksumFileExtractor to follow the composition pattern
used in the chunking and similarity modules.

Functions:
    - export_to_csv: Export checksums data to CSV file
    - export_to_json: Export checksums data to JSON file
    - load_csv: Load checksums data from CSV file

Design Principles:
    - Pure functions (no side effects except I/O)
    - Framework agnostic (minimal dependencies)
    - Consistent with utility.hashing and utility.text_processing patterns
    - Can be used standalone or composed into classes
"""

import csv
import json
from pathlib import Path
from typing import Any, Dict, Union

from utility.logging import get_logger

logger = get_logger(__name__)


def export_to_csv(
    checksums_data: Dict[str, Dict[str, Any]],
    output_path: Union[str, Path],
    include_content: bool = True,
) -> None:
    """
    Export checksums data to CSV file.

    This utility function writes a dictionary of checksums and their associated data
    to a CSV file. Each row represents one checksum with its metadata.

    Args:
        checksums_data: Dictionary mapping checksums to their data
            Format: {checksum: {'text': '...', 'page_num': 42, ...}, ...}
        output_path: Path to output CSV file
        include_content: Whether to include full content text (can be large, default: True)

    Raises:
        OSError: If file cannot be written
        ValueError: If checksums_data is empty or invalid

    Example:
        >>> from utility.file_io import export_to_csv
        >>> data = {
        ...     "abc123": {"text": "Hello", "page_num": 1, "file_name": "test.md"},
        ...     "def456": {"text": "World", "page_num": 2, "file_name": "test.md"}
        ... }
        >>> export_to_csv(data, "output.csv", include_content=True)
    """
    if not checksums_data:
        raise ValueError("checksums_data cannot be empty")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"💾 Exporting {len(checksums_data)} checksums to {output_path}")

    # Collect all unique fields from all records
    all_fields = {"content_checksum"}
    for data in checksums_data.values():
        all_fields.update(data.keys())

    # Remove content fields if not including content
    if not include_content:
        all_fields.discard("text")
        all_fields.discard("content_text")

    fieldnames = sorted(all_fields)

    try:
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for checksum, data in checksums_data.items():
                row = {"content_checksum": checksum}

                for field in fieldnames:
                    if field == "content_checksum":
                        continue

                    value = data.get(field)

                    # Skip content if not included
                    if not include_content and field in ("text", "content_text"):
                        continue

                    row[field] = value

                writer.writerow(row)

        logger.info(f"✅ Exported to {output_path}")

    except Exception as e:
        logger.error(f"❌ Failed to export to CSV: {e}")
        raise


def export_to_json(
    checksums_data: Dict[str, Dict[str, Any]],
    output_path: Union[str, Path],
    indent: int = 2,
) -> None:
    """
    Export checksums data to JSON file.

    This utility function writes a dictionary of checksums and their associated data
    to a JSON file with pretty printing.

    Args:
        checksums_data: Dictionary mapping checksums to their data
            Format: {checksum: {'text': '...', 'page_num': 42, ...}, ...}
        output_path: Path to output JSON file
        indent: JSON indentation level (default: 2)

    Raises:
        OSError: If file cannot be written
        ValueError: If checksums_data is empty or invalid
        TypeError: If data contains non-serializable objects

    Example:
        >>> from utility.file_io import export_to_json
        >>> data = {
        ...     "abc123": {"text": "Hello", "page_num": 1},
        ...     "def456": {"text": "World", "page_num": 2}
        ... }
        >>> export_to_json(data, "output.json", indent=4)
    """
    if not checksums_data:
        raise ValueError("checksums_data cannot be empty")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"💾 Exporting {len(checksums_data)} checksums to JSON: {output_path}")

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(checksums_data, f, indent=indent, default=str)

        logger.info(f"✅ Exported to {output_path}")

    except Exception as e:
        logger.error(f"❌ Failed to export to JSON: {e}")
        raise


def load_csv(
    csv_path: Union[str, Path],
    content_field: str = "content_text",
    checksum_field: str = "content_checksum",
) -> Dict[str, Dict[str, Any]]:
    """
    Load checksums data from CSV file.

    This utility function reads a CSV file and returns a dictionary mapping checksums
    to their associated data. If a checksum field exists in the CSV, it is used as the
    key; otherwise, checksums must be computed by the caller.

    Args:
        csv_path: Path to CSV file
        content_field: Name of column containing text content (default: "content_text")
        checksum_field: Name of column containing checksums (default: "content_checksum")

    Returns:
        Dictionary mapping checksums to their data:
            {checksum: {'content_text': '...', 'page_number': 42, ...}, ...}
        If no checksum_field exists, returns data indexed by row number

    Raises:
        FileNotFoundError: If CSV file does not exist
        ValueError: If CSV format is invalid or missing required columns
        IOError: If file cannot be read

    Example:
        >>> from utility.file_io import load_csv
        >>> data = load_csv("previous_data.csv", content_field="content_text")
        >>> len(data)
        42
        >>> list(data.keys())[0]
        'abc123def456...'
        >>> data['abc123def456...']['content_text']
        'Previous FAQ content...'
    """
    csv_path = Path(csv_path)

    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    logger.info(f"📄 Loading checksums from CSV: {csv_path}")

    checksums_data = {}

    try:
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            # Check if required fields exist
            fieldnames = reader.fieldnames
            if not fieldnames:
                raise ValueError(f"CSV file is empty or invalid: {csv_path}")

            has_checksum_field = checksum_field in fieldnames
            has_content_field = content_field in fieldnames

            if not has_checksum_field and not has_content_field:
                raise ValueError(
                    f"CSV must contain either '{checksum_field}' or '{content_field}' column"
                )

            for row_num, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                try:
                    # Get checksum (if available)
                    checksum = row.get(checksum_field)

                    # If no checksum field, use row number as temporary key
                    if not checksum:
                        checksum = f"row_{row_num}"
                        logger.debug(
                            f"   Row {row_num}: No checksum field, using temporary key: {checksum}"
                        )

                    # Get content text
                    content_text = row.get(content_field)

                    if not content_text and has_content_field:
                        logger.warning(f"   ⚠️  Row {row_num}: Missing {content_field}, skipping")
                        continue

                    # Build data dictionary with all fields
                    data = dict(row)

                    # Add standardized aliases
                    if content_text:
                        data["text"] = content_text
                        data["content_text"] = content_text

                    # Standardize page number field
                    if "page_number" in data and data["page_number"]:
                        try:
                            data["page_num"] = int(data["page_number"])
                        except (ValueError, TypeError):
                            logger.warning(
                                f"   ⚠️  Row {row_num}: Invalid page_number: {data['page_number']}"
                            )

                    data["row_num"] = row_num

                    checksums_data[checksum] = data

                except Exception as e:
                    logger.error(f"   ✗ Row {row_num}: Error processing: {e}")

        logger.info(f"✅ Loaded {len(checksums_data)} records from CSV")

        return checksums_data

    except Exception as e:
        logger.error(f"❌ Failed to load CSV: {e}")
        raise


# Convenience exports
__all__ = [
    "export_to_csv",
    "export_to_json",
    "load_csv",
]
