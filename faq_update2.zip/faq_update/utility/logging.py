"""
Logging utilities for granular impact analysis.

Provides centralized logging configuration with support for:
- File logging to Databricks volumes
- Console logging
- Structured logging with contextual information
- Integration with loguru
"""

import sys
from pathlib import Path
from typing import Optional

from loguru import logger


def setup_logging(
    log_level: str = "INFO",
    log_to_file: bool = False,
    log_file_path: Optional[Path] = None,
    log_to_console: bool = True,
    rotation: str = "100 MB",
    retention: str = "30 days",
    format_string: Optional[str] = None,
) -> None:
    """
    Set up logging configuration.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_to_file: Whether to log to file
        log_file_path: Path to log file (required if log_to_file=True)
        log_to_console: Whether to log to console
        rotation: Log rotation policy
        retention: Log retention policy
        format_string: Custom format string
    """
    # Remove default handler
    logger.remove()

    # Default format
    if format_string is None:
        format_string = (
            "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
            "<level>{message}</level>"
        )

    # Add console handler
    if log_to_console:
        logger.add(
            sys.stderr,
            format=format_string,
            level=log_level,
            colorize=True,
        )

    # Add file handler
    if log_to_file:
        if log_file_path is None:
            raise ValueError("log_file_path is required when log_to_file=True")

        # Ensure directory exists
        log_file_path.parent.mkdir(parents=True, exist_ok=True)

        logger.add(
            str(log_file_path),
            format=format_string,
            level=log_level,
            rotation=rotation,
            retention=retention,
            compression="zip",
            serialize=False,
        )

    logger.info(f"Logging initialized at level {log_level}")


def get_logger(name: str):
    """
    Get a logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance
    """
    return logger.bind(name=name)


class LogContext:
    """Context manager for adding contextual information to logs."""

    def __init__(self, **kwargs):
        """
        Initialize log context.

        Args:
            **kwargs: Context key-value pairs
        """
        self.context = kwargs
        self.token = None

    def __enter__(self):
        """Enter context."""
        self.token = logger.contextualize(**self.context)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context."""
        pass


__all__ = [
    'setup_logging',
    'get_logger',
    'LogContext',
    'logger',
]
