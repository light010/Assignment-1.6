"""
Text Processing Utilities - Generic Text Manipulation Functions

This module provides infrastructure-level text processing utilities used across
the similarity module. These are pure technical utilities with no business logic.

Functions:
    - normalize_whitespace: Collapse multiple whitespace into single spaces
    - to_lowercase: Convert text to lowercase
    - remove_punctuation: Strip punctuation characters
    - preprocess_text: Combined preprocessing pipeline
    - tokenize: Split text into tokens with filtering
    - validate_text_input: Validate single text input
    - validate_text_pair: Validate pair of texts for comparison

These utilities are analogous to the hashing utility in the utility module -
they provide generic, reusable technical functionality.
"""

import string
from typing import List


def normalize_whitespace(text: str) -> str:
    """
    Normalize whitespace by collapsing multiple spaces/tabs/newlines into single spaces.

    Converts all whitespace characters (spaces, tabs, newlines, etc.) into single
    spaces and strips leading/trailing whitespace.

    Args:
        text: Input text with potentially irregular whitespace

    Returns:
        Text with normalized whitespace

    Example:
        >>> normalize_whitespace("hello    world")
        'hello world'
        >>> normalize_whitespace("hello\\n\\n  world\\t  ")
        'hello world'
        >>> normalize_whitespace("   ")
        ''
    """
    if text is None:
        return ""
    return " ".join(text.split())


def to_lowercase(text: str) -> str:
    """
    Convert text to lowercase.

    Simple wrapper around str.lower() for consistency and potential
    future enhancement (e.g., locale-aware lowercasing).

    Args:
        text: Input text

    Returns:
        Lowercase text

    Example:
        >>> to_lowercase("Hello World")
        'hello world'
        >>> to_lowercase("CAFÉ")
        'café'
        >>> to_lowercase("")
        ''
    """
    if text is None:
        return ""
    return text.lower()


def remove_punctuation(text: str) -> str:
    """
    Remove all punctuation characters from text.

    Uses string.punctuation which includes: !"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~

    Args:
        text: Input text

    Returns:
        Text with punctuation removed

    Example:
        >>> remove_punctuation("Hello, world!")
        'Hello world'
        >>> remove_punctuation("Price: $10.50")
        'Price 1050'
        >>> remove_punctuation("user@email.com")
        'useremailcom'
    """
    if text is None:
        return ""
    return text.translate(str.maketrans("", "", string.punctuation))


def preprocess_text(
    text: str,
    lowercase: bool = True,
    remove_punct: bool = True,
    normalize_ws: bool = True,
) -> str:
    """
    Preprocess text with configurable transformations.

    Applies a pipeline of text transformations in order:
    1. Lowercase conversion (if enabled)
    2. Punctuation removal (if enabled)
    3. Whitespace normalization (if enabled)

    Args:
        text: Input text to preprocess
        lowercase: Whether to convert to lowercase (default: True)
        remove_punct: Whether to remove punctuation (default: True)
        normalize_ws: Whether to normalize whitespace (default: True)

    Returns:
        Preprocessed text

    Example:
        >>> preprocess_text("  Hello,  WORLD!  ")
        'hello world'
        >>> preprocess_text("Hello, WORLD!", lowercase=False)
        'Hello WORLD'
        >>> preprocess_text("Price: $10.50", remove_punct=False)
        'price: $10.50'
        >>> preprocess_text("A B  C", lowercase=False, remove_punct=False)
        'A B C'
    """
    if text is None:
        return ""

    processed = text

    # Apply transformations in order
    if lowercase:
        processed = to_lowercase(processed)

    if remove_punct:
        processed = remove_punctuation(processed)

    if normalize_ws:
        processed = normalize_whitespace(processed)

    return processed


def tokenize(text: str, min_token_length: int = 1) -> List[str]:
    """
    Tokenize preprocessed text into words.

    Simple whitespace-based tokenization with minimum length filtering.
    No lemmatization, no stopword removal, no NLP processing.

    Args:
        text: Preprocessed text (should already be normalized)
        min_token_length: Minimum token length to keep (default: 1)

    Returns:
        List of tokens

    Example:
        >>> tokenize("hello world")
        ['hello', 'world']
        >>> tokenize("hello world", min_token_length=6)
        []
        >>> tokenize("a bb ccc", min_token_length=2)
        ['bb', 'ccc']
        >>> tokenize("  hello   world  ")
        ['hello', 'world']
        >>> tokenize("")
        []
    """
    if text is None or not text.strip():
        return []

    # Basic split on whitespace
    tokens = text.split()

    # Filter by minimum length
    if min_token_length > 1:
        tokens = [t for t in tokens if len(t) >= min_token_length]

    return tokens


def validate_text_input(text: str, param_name: str = "text") -> None:
    """
    Validate a single text input.

    Checks that text is not None and not empty (after stripping whitespace).

    Args:
        text: Text to validate
        param_name: Parameter name for error messages (default: "text")

    Raises:
        ValueError: If text is None or empty

    Example:
        >>> validate_text_input("hello")  # OK
        >>> validate_text_input(None)  # Raises ValueError
        Traceback (most recent call last):
            ...
        ValueError: text cannot be None
        >>> validate_text_input("   ")  # Raises ValueError
        Traceback (most recent call last):
            ...
        ValueError: text cannot be empty
    """
    if text is None:
        raise ValueError(f"{param_name} cannot be None")
    if not text.strip():
        raise ValueError(f"{param_name} cannot be empty")


def validate_text_pair(text1: str, text2: str) -> None:
    """
    Validate a pair of texts for similarity comparison.

    Checks that both texts are not None and not empty (after stripping whitespace).

    Args:
        text1: First text to validate
        text2: Second text to validate

    Raises:
        ValueError: If either text is None or empty

    Example:
        >>> validate_text_pair("hello", "world")  # OK
        >>> validate_text_pair(None, "world")  # Raises ValueError
        Traceback (most recent call last):
            ...
        ValueError: text1 cannot be None
        >>> validate_text_pair("hello", None)  # Raises ValueError
        Traceback (most recent call last):
            ...
        ValueError: text2 cannot be None
        >>> validate_text_pair("hello", "   ")  # Raises ValueError
        Traceback (most recent call last):
            ...
        ValueError: text2 cannot be empty
    """
    validate_text_input(text1, "text1")
    validate_text_input(text2, "text2")


# Convenience exports
__all__ = [
    "normalize_whitespace",
    "to_lowercase",
    "remove_punctuation",
    "preprocess_text",
    "tokenize",
    "validate_text_input",
    "validate_text_pair",
]
