"""
Hashing Utilities - Cryptographic Hashing Functions

This module provides cryptographic hashing utilities for content fingerprinting.
Uses SHA-256 algorithm configured in config.constants for consistency across
the entire application pipeline.

This is infrastructure-level code (HOW to hash), not domain logic (WHAT to hash).
"""

import hashlib
from config.constants import CHECKSUM_ALGORITHM


def compute_checksum(text: str) -> str:
    """
    Compute cryptographic checksum for text content using SHA-256.

    This is the single source of truth for checksum computation across
    the entire application. Used by:
    - chunking module (for chunk fingerprinting)
    - detection module (for change detection)
    - data_ingestion module (for content tracking)

    Args:
        text: Text content to hash

    Returns:
        Hexadecimal checksum string (64 characters for SHA-256)

    Example:
        >>> checksum = compute_checksum("Hello world")
        >>> len(checksum)
        64
        >>> checksum[:8]
        '64ec88ca'

    Implementation Notes:
        - Uses UTF-8 encoding for text
        - Uses algorithm from config.constants (currently sha256)
        - Returns hexadecimal digest (lowercase)
        - Empty string produces known SHA-256 empty hash:
          e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
    """
    hash_func = getattr(hashlib, CHECKSUM_ALGORITHM)
    return hash_func(text.encode("utf-8")).hexdigest()
