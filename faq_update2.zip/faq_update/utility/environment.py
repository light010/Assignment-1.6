"""
Environment Utilities

Provides utilities for detecting execution environment (Databricks vs local)
and handling environment-specific operations.

Used across all notebooks for environment segregation.
"""

import sys
import os
from pathlib import Path


def is_databricks() -> bool:
    """
    Detect if running in Databricks environment.

    Uses multiple detection methods for reliability:
    1. Check for Databricks-specific module imports
    2. Check for Databricks environment variables
    3. Check for Databricks filesystem paths

    Returns:
        True if in Databricks, False if local

    Examples:
        >>> is_databricks()
        False  # in local environment

        >>> # In notebook
        >>> from utility import is_databricks
        >>> if is_databricks():
        >>>     # Databricks-specific code
        >>>     spark.sql("SHOW TABLES")
        >>> else:
        >>>     # Local-specific code
        >>>     db.fetchall("SELECT * FROM sqlite_master")
    """
    # Method 1: Check for Databricks modules
    if 'pyspark.dbutils' in sys.modules or 'databricks' in sys.modules:
        return True

    # Method 2: Check environment variables
    databricks_indicators = [
        'DATABRICKS_RUNTIME_VERSION',
        'DB_HOME',
        'DATABRICKS_ROOT_VIRTUALENV_ENV',
    ]

    for indicator in databricks_indicators:
        if os.getenv(indicator):
            return True

    # Method 3: Check for Databricks paths
    if Path('/databricks').exists() or Path('/Workspace').exists():
        return True

    return False


def get_dbutils():
    """
    Get dbutils instance (works in both new and old Databricks runtimes).

    Returns:
        dbutils instance

    Raises:
        RuntimeError: If not in Databricks environment

    Examples:
        >>> dbutils = get_dbutils()
        >>> dbutils.widgets.get("my_widget")
    """
    if not is_databricks():
        raise RuntimeError("get_dbutils() can only be called in Databricks environment")

    try:
        # Try the standard way (newer runtimes)
        from pyspark.dbutils import DBUtils
        # Get spark from globals
        import __main__
        if hasattr(__main__, 'spark'):
            return DBUtils(__main__.spark)
    except (ImportError, NameError, AttributeError):
        pass

    try:
        # Try getting from globals (older runtimes and notebooks)
        import __main__
        if hasattr(__main__, 'dbutils'):
            return __main__.dbutils
    except Exception:
        pass

    # Last resort: try to get from IPython
    try:
        from IPython import get_ipython
        ipython = get_ipython()
        if ipython and hasattr(ipython, 'user_ns') and 'dbutils' in ipython.user_ns:
            return ipython.user_ns['dbutils']
    except Exception:
        pass

    raise RuntimeError("Cannot get dbutils - not available in current environment")


def setup_widgets(catalog_default: str = None, schema_default: str = None) -> tuple[str, str]:
    """
    Setup Databricks widgets and get their values.

    Only works in Databricks. In local environment, returns None, None.

    Args:
        catalog_default: Default value for catalog widget
        schema_default: Default value for schema widget

    Returns:
        Tuple of (catalog, schema) values, or (None, None) if local

    Examples:
        >>> # In Databricks notebook
        >>> catalog, schema = setup_widgets("my_catalog", "my_schema")
        >>> print(f"Using {catalog}.{schema}")

        >>> # In local notebook
        >>> catalog, schema = setup_widgets()
        >>> # Returns (None, None)
    """
    if not is_databricks():
        return None, None

    try:
        dbutils = get_dbutils()

        # Create or get widgets
        catalog = catalog_default or "onedata_us_east_1_shared_dit"
        schema = schema_default or "ssot_raw_ditagen_dit"

        try:
            dbutils.widgets.text("catalog", catalog, "Catalog")
        except Exception:
            pass  # Widget might already exist

        try:
            dbutils.widgets.text("schema", schema, "Schema")
        except Exception:
            pass  # Widget might already exist

        # Get values
        catalog = dbutils.widgets.get("catalog") or catalog
        schema = dbutils.widgets.get("schema") or schema

        return catalog, schema

    except Exception as e:
        print(f"Warning: Could not setup widgets: {e}")
        return catalog_default, schema_default


def get_workspace_root() -> Path:
    """
    Get the workspace root directory.

    In Databricks: Tries to detect workspace location
    In Local: Returns project root (parent of utility/)

    Returns:
        Path to workspace/project root

    Examples:
        >>> root = get_workspace_root()
        >>> schema_dir = root / 'database' / 'sql' / 'schema'
    """
    if is_databricks():
        # Auto-detect workspace root using current working directory
        workspace_root = Path.cwd()

        # If cwd doesn't contain database/, try to find it
        if not (workspace_root / 'database').exists():
            # Try parent directories
            for parent in workspace_root.parents:
                if (parent / 'database').exists():
                    workspace_root = parent
                    break

        return workspace_root
    else:
        # Local environment - detect project root
        current_file = Path(__file__).resolve()
        return current_file.parent.parent  # utility/environment.py -> faq_update/


# Convenience exports
__all__ = [
    'is_databricks',
    'get_dbutils',
    'setup_widgets',
    'get_workspace_root',
]
