"""
UTILITY Module - Infrastructure Layer (Technical Mechanisms - the "HOW")

This module contains infrastructure-level utilities that define HOW the system
performs technical operations. It has no knowledge of business domain concepts.

Architecture:
- hashing.py: Cryptographic hashing utilities (compute_checksum)
- text_processing.py: Text manipulation and validation utilities
- normalization.py: Score normalization functions
- file_io.py: File I/O operations (CSV, JSON)
- environment.py: Environment detection (Databricks vs local)
- logging.py: Logging utilities (loguru integration)
- metrics.py: Performance metrics collection
- validation.py: Data validation utilities

Phase 7 Cleanup:
✓ database.py - DELETED (moved to database.backends.sqlite.utilities)

Dependency Direction: chunking → core ← utility
                      similarity → core ← utility

Example:
    >>> from utility import compute_checksum
    >>> checksum = compute_checksum("Hello world")
    >>> len(checksum)
    64
    >>> from utility import preprocess_text, tokenize
    >>> processed = preprocess_text("Hello, World!")
    >>> tokens = tokenize(processed)
    >>> from utility import is_databricks, get_logger
    >>> logger = get_logger(__name__)
"""

# Hashing utilities
from utility.hashing import compute_checksum

# Text processing utilities
from utility.text_processing import (
    normalize_whitespace,
    to_lowercase,
    remove_punctuation,
    preprocess_text,
    tokenize,
    validate_text_input,
    validate_text_pair,
)

# Normalization utilities
from utility.normalization import (
    sigmoid_normalize,
    linear_normalize,
)

# File I/O utilities
from utility.file_io import (
    export_to_csv,
    export_to_json,
    load_csv,
)

# Environment utilities
from utility.environment import (
    is_databricks,
    get_dbutils,
    setup_widgets,
    get_workspace_root,
)

# Database utilities - REMOVED in Phase 7
# Migration: Use database.backends.sqlite.utilities instead
# Example:
#   from database.backends.sqlite.utilities import (
#       close_all_sqlite_connections,
#       drop_sqlite_database,
#       get_sqlite_connection,
#       safe_close_connection,
#       check_database_locked,
#   )

# Logging utilities
from utility.logging import (
    setup_logging,
    get_logger,
    LogContext,
    logger,
)

# Metrics utilities
from utility.metrics import (
    PerformanceMetrics,
    MetricsCollector,
)

# Validation utilities
from utility.validation import (
    # Basic validators
    validate_text_content,
    validate_score,
    validate_checksum,
    validate_content_id,
    validate_faq_id,
    validate_weights,
    # Referential integrity validators
    ReferentialIntegrityError,
    get_valid_content_checksums,
    validate_source_checksums,
    validate_question_sources,
    validate_answer_sources,
    get_orphaned_checksums,
    clean_orphaned_sources,
)

__version__ = "2.0.0"

__all__ = [
    # Hashing
    "compute_checksum",
    # Text Processing
    "normalize_whitespace",
    "to_lowercase",
    "remove_punctuation",
    "preprocess_text",
    "tokenize",
    "validate_text_input",
    "validate_text_pair",
    # Normalization
    "sigmoid_normalize",
    "linear_normalize",
    # File I/O
    "export_to_csv",
    "export_to_json",
    "load_csv",
    # Environment
    "is_databricks",
    "get_dbutils",
    "setup_widgets",
    "get_workspace_root",
    # Database utilities removed in Phase 7 - use database.backends.sqlite.utilities
    # Logging
    "setup_logging",
    "get_logger",
    "LogContext",
    "logger",
    # Metrics
    "PerformanceMetrics",
    "MetricsCollector",
    # Validation - Basic
    "validate_text_content",
    "validate_score",
    "validate_checksum",
    "validate_content_id",
    "validate_faq_id",
    "validate_weights",
    # Validation - Referential Integrity
    "ReferentialIntegrityError",
    "get_valid_content_checksums",
    "validate_source_checksums",
    "validate_question_sources",
    "validate_answer_sources",
    "get_orphaned_checksums",
    "clean_orphaned_sources",
]
