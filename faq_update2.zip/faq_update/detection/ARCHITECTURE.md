# Detection Module Architecture

## Overview

The Detection module implements **checksum-based change detection** with **similarity matching** for FAQ content updates. It follows a **clean architecture** pattern with clear separation between interfaces, domain models, and implementations.

**Design Philosophy**: Interface-driven, testable, composable, and aligned with the existing chunking and similarity modules.

**Status**: ✅ **Production-Ready** - Fully refactored with interface-based design (as of 2025-11-01)

## Quick Summary

**Current Status (2025-11-01):**
- ✅ Service-based architecture (579 → 506 lines, 12.5% reduction)
- ✅ 4 focused services with 114 comprehensive tests (100% passing)
- ✅ SOLID principles applied (Single Responsibility, Dependency Injection)
- ✅ 100% backward compatible with existing code
- ✅ Interface-based design with domain models

**Key Components:**
- **Interfaces**: [core/interfaces/detection.py](../core/interfaces/detection.py) - `IChangeDetector`, `IFileLoader`
- **Models**: [core/models/detection.py](../core/models/detection.py) - `DetectionResult`, `DetectionConfig`, `ChangeType`
- **Detector**: [detection/checksum_detector.py](checksum_detector.py) - Service-based orchestrator
- **Services**: [detection/services/](services/) - SimilarityMatcher, DiffGenerator, EdgeCaseAnalyzer, DetectionResultBuilder
- **Loaders**: [data_ingestion/loaders/](../data_ingestion/loaders/) - MarkdownFileLoader, CSVFileLoader (moved 2025-11-01)
- **Tests**: [tests/detection/](../tests/detection/) - 114 tests (86 unit, 28 integration)

---

## Architecture Diagram

### Service-Based Architecture (2025-11-01)

```
┌────────────────────────────────────────────────────────────┐
│       Detection Module (Service-Based, 114 Tests ✅)       │
└────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│  Interfaces  │    │Domain Models │    │ File Loaders │
│IChangeDetec. │    │DetectionResult│   │MarkdownFile  │
│IFileLoader   │    │DetectionConfig│   │CSVFileLoader │
│              │    │ChangeType    │    │DictListLoader│
└──────────────┘    └──────────────┘    └──────────────┘
                              │
                              ▼
        ┌────────────────────────────────────────┐
        │  ChecksumChangeDetector (Orchestrator)  │
        │  506 lines (refactored from 579) ✅     │
        └────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│ Similarity   │    │    Diff      │    │  EdgeCase    │
│   Matcher    │    │  Generator   │    │  Analyzer    │
│  230 lines   │    │  160 lines   │    │  200 lines   │
│  16 tests ✅ │    │  19 tests ✅ │    │  21 tests ✅ │
└──────────────┘    └──────────────┘    └──────────────┘
        │                     │                     │
        ▼                     ▼                     └─────┐
┌──────────────┐    ┌──────────────┐                     │
│ISimilarity   │    │  Difflib     │                     │
│Calculator    │    │Similarity    │                     │
│(Injected)    │    │Calculator    │                     │
└──────────────┘    └──────────────┘                     │
        │                                                 │
        └──────────────────┬──────────────────────────────┘
                           ▼
              ┌────────────────────────┐
              │ DetectionResultBuilder │
              │      240 lines         │
              │      30 tests ✅       │
              └────────────────────────┘
                           │
                           ▼
              ┌────────────────────────┐
              │   DetectionResult      │
              │   (Domain Model)       │
              └────────────────────────┘
```

**Key:**
- **Orchestrator**: Coordinates services, implements IChangeDetector
- **Services**: 4 focused components (830 lines total)
- **Tests**: 114 tests (86 unit, 28 integration) - 100% passing

---

## Core Components

### 1. Interfaces (`core/interfaces/detection.py`)

**Purpose**: Define pure contracts that all implementations must follow.

#### `IChangeDetector`
```python
from core.interfaces.detection import IChangeDetector

class IChangeDetector(ABC):
    @abstractmethod
    def detect_changes(
        self,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
        run_id: str,
    ) -> List[DetectionResult]:
        """Detect changes between current and previous content versions."""
        pass

    @abstractmethod
    def get_config(self) -> DetectionConfig:
        """Get the configuration of this change detector."""
        pass
```

**Responsibilities**:
- Define the contract for change detection algorithms
- Return domain models (`DetectionResult`), not database models
- Support dependency injection (similarity calculators, etc.)

#### `IFileLoader`
```python
from core.interfaces.detection import IFileLoader

class IFileLoader(ABC):
    @abstractmethod
    def load_from_markdown(self, path: str) -> Dict[str, Dict[str, Any]]:
        """Load checksums and content from markdown files."""
        pass

    @abstractmethod
    def load_from_csv(self, path: str) -> Dict[str, Dict[str, Any]]:
        """Load checksums and content from CSV file."""
        pass
```

**Responsibilities**:
- Define the contract for loading content from various sources
- Standardize data format for change detection
- Support multiple file formats (markdown, CSV, etc.)

---

### 2. Domain Models (`core/models/detection.py`)

**Purpose**: Framework-agnostic value objects representing detection concepts.

#### `ChangeType`
```python
from core.models.detection import ChangeType

class ChangeType(str, Enum):
    NEW_CONTENT = "new_content"
    MODIFIED_CONTENT = "modified_content"
    DELETED_CONTENT = "deleted_content"
    UNCHANGED_CONTENT = "unchanged_content"
```

**Business Rules**:
- `NEW_CONTENT`: old_checksum = "", new_checksum != ""
- `MODIFIED_CONTENT`: both checksums != "", similarity >= threshold
- `DELETED_CONTENT`: old_checksum != "", new_checksum = ""
- `UNCHANGED_CONTENT`: old_checksum == new_checksum

#### `DetectionResult`
```python
from core.models.detection import DetectionResult

@dataclass
class DetectionResult:
    old_checksum: str
    new_checksum: str
    change_type: ChangeType
    similarity_score: float
    detected_at: datetime
    file_name: Optional[str]
    page_number: Optional[int]
    old_content: Optional[str]
    new_content: Optional[str]
    metadata: Dict[str, Any]
```

**Key Features**:
- Immutable value object
- Built-in validation (`__post_init__`)
- Conversion to database models (`to_content_change()`)
- Serialization support (`to_dict()`, `from_dict()`)

#### `DetectionConfig`
```python
from core.models.detection import DetectionConfig

@dataclass
class DetectionConfig:
    checksum_algorithm: str = "sha256"
    similarity_threshold: float = 0.8
    compute_llm_diffs: bool = False
    diff_context_lines: int = 3
    similarity_weights: Dict[str, float] = field(default_factory=lambda: {
        "jaccard": 0.40,
        "difflib": 0.60,
    })
```

**Key Features**:
- Centralized configuration
- Validation of weights and thresholds
- Serialization support

---

### 3. Implementations (`detection/`)

#### `ChecksumChangeDetector` (Service-Based Architecture)
```python
from detection import ChecksumChangeDetector

# Factory methods (recommended)
detector = ChecksumChangeDetector.for_faq_updates()
detector = ChecksumChangeDetector.for_policy_tracking()

# Detect changes
results = detector.detect_changes(file_name, current, previous, run_id)
```

**Architecture** (Refactored 2025-11-01):
- **Orchestrator Pattern**: Delegates to 4 focused services
- **Service Composition**: All services injectable for testing
- **SOLID Principles**: Single Responsibility, Dependency Injection
- **114 Tests**: Comprehensive unit and integration test coverage

**Core Services**:
1. **SimilarityMatcher** - Finds best matches (greedy O(N×M) algorithm)
2. **DiffGenerator** - Generates LLM-friendly diffs (exception-safe)
3. **EdgeCaseAnalyzer** - Detects content splits/merges (diagnostic)
4. **DetectionResultBuilder** - Constructs DetectionResult objects

**Features**:
- Implements `IChangeDetector` interface
- Uses injected similarity calculators
- Returns `DetectionResult` domain models
- Factory methods for common configurations
- Supports LLM-friendly diff generation
- **NEW**: Service injection for testing/customization

**Algorithm** (V8.2 - Preserved):
1. Identify NEW content (in current, not in previous)
2. Identify DELETED content (in previous, not in current)
3. Match remaining content using similarity scores (greedy matching)
4. Classify MODIFIED vs UNCHANGED based on threshold (>= 0.8)

#### `MarkdownFileLoader` & `CSVFileLoader`
```python
from detection import MarkdownFileLoader, CSVFileLoader

# Load from markdown
loader = MarkdownFileLoader()
current_data = loader.load_from_markdown("./data/current/")

# Load from CSV
loader = CSVFileLoader()
previous_data = loader.load_from_csv("./data/previous_checksums.csv")
```

**Features**:
- Implement `IFileLoader` interface
- Standardized output format
- Handle various file structures
- Compute checksums using `utility.hashing`

---

## Data Flow

### End-to-End Detection Flow

```
1. Load Data
   ┌─────────────────┐
   │ MarkdownFile    │ → current_data: Dict[checksum, content]
   │ Loader          │
   └─────────────────┘
   ┌─────────────────┐
   │ CSVFileLoader   │ → previous_data: Dict[checksum, content]
   └─────────────────┘

2. Detect Changes
   ┌─────────────────────────────────────────────────────┐
   │ ChecksumChangeDetector                              │
   │                                                     │
   │ 1. NEW: checksums in current, not in previous      │
   │ 2. DELETED: checksums in previous, not in current  │
   │ 3. MODIFIED/UNCHANGED: similarity matching         │
   │    - Use ISimilarityCalculator (injected)          │
   │    - Compare threshold vs similarity_threshold     │
   └─────────────────────────────────────────────────────┘
                         │
                         ▼
                  List[DetectionResult]

3. Persist to Database
   ┌─────────────────┐
   │ result.to_      │ → ContentChange (database model)
   │ content_change()│
   └─────────────────┘
   ┌─────────────────┐
   │ Adapter.save()  │ → SQLite / Spark / etc.
   └─────────────────┘
```

---

## Design Patterns

### 1. Strategy Pattern
**Purpose**: Allow different change detection algorithms to be used interchangeably.

```python
# Different strategies
detector1 = ChecksumChangeDetector(HybridSimilarityCalculator())
detector2 = ChecksumChangeDetector(SemanticSimilarityCalculator())

# Same interface
results = detector1.detect_changes(...)
results = detector2.detect_changes(...)
```

### 2. Dependency Injection
**Purpose**: Decouple detection logic from similarity computation and services.

```python
# Inject similarity calculator
calculator = HybridSimilarityCalculator.for_modification_detection()
detector = ChecksumChangeDetector(calculator, config)

# NEW (2025-11-01): Inject services for testing
from detection.services import SimilarityMatcher, DiffGenerator
matcher = SimilarityMatcher(calculator, threshold=0.9)
diff_gen = DiffGenerator(diff_calculator, context_lines=5)
detector = ChecksumChangeDetector(
    similarity_calculator=calculator,
    similarity_matcher=matcher,
    diff_generator=diff_gen
)
```

### 3. Adapter Pattern
**Purpose**: Separate domain models from database models.

```python
# Domain model (DetectionResult)
result = DetectionResult(
    old_checksum="abc",
    new_checksum="def",
    change_type=ChangeType.MODIFIED_CONTENT,
    similarity_score=0.87
)

# Convert to database model
content_change = result.to_content_change()

# Persist using adapter
adapter = SQLiteDetectionAdapter(session)
adapter.save_detection_result(result)
```

### 4. Factory Method
**Purpose**: Provide convenient constructors for common configurations.

```python
# FAQ-specific configuration
detector = ChecksumChangeDetector.for_faq_updates()

# Semantic change detection
detector = ChecksumChangeDetector.for_semantic_changes()
```

---

## Current Architecture (Interface-Based)

**Status**: ✅ **Active** - This is the only supported architecture as of 2025-11-01

### Complete Workflow Example

```python
from detection import ChecksumChangeDetector, MarkdownFileLoader, CSVFileLoader
from database.adapters.sqlite_adapter import SQLiteDetectionAdapter
import sqlite3

# 1. Setup
conn = sqlite3.connect("faq.db")
adapter = SQLiteDetectionAdapter(connection=conn)
loader = MarkdownFileLoader()
detector = ChecksumChangeDetector.for_faq_updates()

# 2. Load data (separated concern)
current = loader.load_from_markdown("./data/current/")
previous = adapter.get_previous_checksums(file_name="handbook.pdf")

# 3. Detect changes (returns DetectionResult domain models)
results = detector.detect_changes(
    file_name="handbook.pdf",
    current_data=current,
    previous_data=previous,
    run_id="run_001"
)

# 4. Process results
for result in results:
    print(f"{result.change_type}: {result.similarity_score}")

# 5. Persist using adapter (separated concern)
count = adapter.store_detection_results(results, run_id="run_001")
print(f"Stored {count} changes")

conn.close()
```

**Architecture Characteristics**:
- ✅ Separation of concerns (loading, detection, persistence)
- ✅ Returns domain models (DetectionResult), not database models
- ✅ Easy to test with mocked dependencies
- ✅ Flexible and composable
- ✅ Type-safe with interfaces
- ✅ Extensible (add new detectors by implementing IChangeDetector)


---

## Key Principles

### 1. Separation of Concerns
- **File Loading**: `IFileLoader` implementations
- **Change Detection**: `IChangeDetector` implementations
- **Similarity Computation**: `ISimilarityCalculator` (injected)
- **Database Persistence**: Adapter pattern

### 2. Testability
```python
# Mock similarity calculator
mock_calculator = Mock(ISimilarityCalculator)
mock_calculator.calculate.return_value = SimilarityResult(
    jaccard=0.85, difflib=0.90, aggregate=0.88
)

# Test detector with mock
detector = ChecksumChangeDetector(mock_calculator)
results = detector.detect_changes(file_name, current, previous, run_id)

# Assertions
assert len(results) == expected_count
assert results[0].change_type == ChangeType.MODIFIED_CONTENT
```

### 3. Composability
```python
# Compose different components
loader = MarkdownFileLoader()
calculator = HybridSimilarityCalculator.for_modification_detection()
detector = ChecksumChangeDetector(calculator)
adapter = SparkDetectionAdapter(spark_session)

# Pipeline
current = loader.load_from_markdown(path)
previous = loader.load_from_csv(csv_path)
results = detector.detect_changes(file_name, current, previous, run_id)
adapter.save_detection_results(results)
```

### 4. Clean Architecture
- Service-based architecture (2025-11-01 refactoring)
- Single, clean interface-based API
- No deprecated code to maintain
- Comprehensive test coverage (114 tests)

---

## Configuration

### Detection Configuration

```python
from core.models.detection import DetectionConfig

# Default configuration (FAQ updates)
config = DetectionConfig()
# similarity_threshold = 0.8
# checksum_algorithm = "sha256"
# similarity_weights = {"jaccard": 0.40, "difflib": 0.60}

# Custom configuration
config = DetectionConfig(
    similarity_threshold=0.85,
    compute_llm_diffs=True,
    diff_context_lines=5,
    similarity_weights={"jaccard": 0.30, "difflib": 0.70}
)

detector = ChecksumChangeDetector(calculator, config)
```

### Similarity Calculator Configuration

```python
from similarity import HybridSimilarityCalculator

# FAQ modification detection (prefer difflib)
calculator = HybridSimilarityCalculator.for_modification_detection()
# weights: jaccard=0.40, difflib=0.60

# Semantic change detection (prefer Jaccard)
calculator = HybridSimilarityCalculator.for_semantic_changes()
# weights: jaccard=0.70, difflib=0.30

# Custom weights
calculator = HybridSimilarityCalculator(
    weights={"jaccard": 0.50, "difflib": 0.50}
)
```

---

## Service-Based Architecture (2025-11-01 Refactoring)

### Overview

ChecksumChangeDetector has been refactored from a 579-line "God Object" into a clean, testable service-based architecture:

**Before**: Monolithic class doing everything
**After**: Orchestrator + 4 focused services

### Services

#### 1. **SimilarityMatcher** ([services/similarity_matcher.py](services/similarity_matcher.py))
```python
from detection.services import SimilarityMatcher, MatchResult

matcher = SimilarityMatcher(calculator, threshold=0.8)
matches = matcher.find_matches(new_checksums, deleted_checksums, current_data, previous_data)
# Returns: List[MatchResult(new_checksum, best_match_checksum, best_score, is_match)]
```

**Responsibility**: Find best matching pairs between new and deleted checksums
- Greedy O(N×M) algorithm (V8.2 preserved)
- Returns `MatchResult` objects
- Handles missing text with warnings

#### 2. **DiffGenerator** ([services/diff_generator.py](services/diff_generator.py))
```python
from detection.services import DiffGenerator

generator = DiffGenerator(diff_calculator, context_lines=3)
diff = generator.generate_llm_diff(old_text, new_text)  # Returns: Optional[str]
```

**Responsibility**: Generate LLM-friendly diffs between content versions
- Exception-safe (returns None on failure)
- Configurable context lines
- Uses DifflibSimilarityCalculator

#### 3. **EdgeCaseAnalyzer** ([services/edge_case_analyzer.py](services/edge_case_analyzer.py))
```python
from detection.services import EdgeCaseAnalyzer, EdgeCaseReport

analyzer = EdgeCaseAnalyzer(checksum_display_length=8)
splits = analyzer.detect_content_splits(deleted_matched)
# Logs warnings for diagnostic purposes
```

**Responsibility**: Detect and log edge cases (splits, merges)
- Pure analysis (no result modification)
- Logs warnings with exact format preservation
- Extensible for future edge cases

#### 4. **DetectionResultBuilder** ([services/result_builder.py](services/result_builder.py))
```python
from detection.services import DetectionResultBuilder

builder = DetectionResultBuilder()
result = builder.build_modified(match_result, file_name, current_data, previous_data, llm_diff)
result = builder.build_new(new_checksum, file_name, current_data)
result = builder.build_deleted(deleted_checksum, file_name, previous_data)
result = builder.build_unchanged(unchanged_checksum, file_name, current_data)
```

**Responsibility**: Construct DetectionResult objects with correct field mapping
- Handles field name differences (text vs content_text, page_num vs page_number)
- Ensures correct checksum values ("" for NEW/DELETED)
- Ensures correct similarity scores (0.0, 1.0)

### Benefits

| Benefit | Impact |
|---------|--------|
| **Testability** | Each service independently testable (114 tests, 100% passing) |
| **Maintainability** | Single Responsibility Principle (506 lines vs 579 lines) |
| **Extensibility** | Easy to add new edge cases or result types |
| **Composability** | Services can be used independently or replaced |

### Testing

**Unit Tests** (86 tests):
- `test_similarity_matcher.py` - 16 tests
- `test_diff_generator.py` - 19 tests
- `test_edge_case_analyzer.py` - 21 tests
- `test_result_builder.py` - 30 tests

**Integration Tests** (28 tests):
- `test_checksum_detector_integration.py` - End-to-end workflows
- Backward compatibility verified
- Service injection verified

**Run Tests**:
```bash
cd faq_update
python -m pytest tests/detection/ -v
# Expected: 114 passed in 0.20s
```

---

## Extension Points

### Adding a New Change Detector

```python
from core.interfaces.detection import IChangeDetector
from core.models.detection import DetectionResult, DetectionConfig, ChangeType

class SemanticChangeDetector(IChangeDetector):
    def __init__(self, embedding_model, config=None):
        self.embedding_model = embedding_model
        self.config = config or DetectionConfig()

    def detect_changes(self, file_name, current_data, previous_data, run_id):
        results = []

        # Custom semantic detection logic
        # Use embeddings, semantic similarity, etc.

        return results

    def get_config(self):
        return self.config
```

### Adding a New File Loader

```python
from core.interfaces.detection import IFileLoader

class JSONFileLoader(IFileLoader):
    def load_from_markdown(self, path):
        # Implementation for markdown
        pass

    def load_from_csv(self, path):
        # Implementation for CSV
        pass

    def load_from_json(self, path):
        # Custom JSON loading logic
        pass
```

---

## Performance Considerations

### Checksum Computation
- Uses `hashlib.sha256` (fast and collision-resistant)
- Checksums computed once during loading
- Cached for reuse

### Similarity Computation
- Most expensive operation (O(n²) worst case)
- Mitigated by early filtering (exact matches first)
- Hybrid similarity uses weighted average (single pass)

### Memory Usage
- Data loaded into memory as dictionaries
- Suitable for FAQ-sized datasets (thousands of entries)
- For large datasets, consider streaming or chunking

### Optimization Strategies
1. **Exact Match First**: Check `old_checksum == new_checksum` before similarity
2. **Parallel Processing**: Use multiprocessing for large datasets
3. **Caching**: Cache similarity scores for identical pairs
4. **Lazy Loading**: Only load content when needed for diffs

---

## Testing Strategy

### Service Unit Tests (2025-11-01)
```python
# Test individual services in isolation
def test_similarity_matcher():
    calc = Mock(ISimilarityCalculator)
    matcher = SimilarityMatcher(calc, threshold=0.8)

    matches = matcher.find_matches(new_checksums, deleted_checksums, current, previous)
    assert all(isinstance(m, MatchResult) for m in matches)

def test_diff_generator_exception_handling():
    calc = Mock()
    calc.get_llm_friendly_diff_json.side_effect = Exception("Failed")
    generator = DiffGenerator(calc)

    result = generator.generate_llm_diff("old", "new")
    assert result is None  # Exception caught, None returned
```

### Detector Unit Tests
```python
def test_checksum_detector_new_content():
    calculator = MockSimilarityCalculator()
    detector = ChecksumChangeDetector(calculator)

    current = {"abc": {"text": "New", "page_num": 1}}
    previous = {}

    results = detector.detect_changes("test.md", current, previous, "run_1")

    assert len(results) == 1
    assert results[0].change_type == ChangeType.NEW_CONTENT
    assert results[0].old_checksum == ""
    assert results[0].new_checksum == "abc"
```

### Integration Tests
```python
def test_end_to_end_detection():
    # Real components (no mocks)
    loader = MarkdownFileLoader()
    calculator = HybridSimilarityCalculator.for_modification_detection()
    detector = ChecksumChangeDetector(calculator)

    # Load real data
    current = loader.load_from_markdown("./test_data/current/")
    previous = loader.load_from_csv("./test_data/previous.csv")

    # Detect changes
    results = detector.detect_changes("test.md", current, previous, "run_1")

    # Validate results
    assert len(results) > 0
    assert all(isinstance(r, DetectionResult) for r in results)

def test_service_injection():
    # Test with custom injected services
    custom_matcher = SimilarityMatcher(calculator, threshold=0.9)
    detector = ChecksumChangeDetector(similarity_matcher=custom_matcher)

    results = detector.detect_changes(file_name, current, previous, run_id)
    # Verify stricter threshold applied
```

### Test Coverage (As of 2025-11-01)
- **Total**: 114 tests (100% passing)
- **Service Tests**: 86 tests
- **Integration Tests**: 28 tests
- **Pass Rate**: 100%
- **Execution Time**: ~0.20s

---

## Best Practices

### 1. Use Factory Methods
```python
# Good - Clear intent, recommended configurations
detector = ChecksumChangeDetector.for_faq_updates()
detector = ChecksumChangeDetector.for_policy_tracking()

# Avoid - Verbose, error-prone
detector = ChecksumChangeDetector(
    HybridSimilarityCalculator(weights={"jaccard": 0.4, "difflib": 0.6}),
    DetectionConfig(similarity_threshold=0.8)
)
```

### 2. Inject Dependencies for Production
```python
# Good - Explicit dependencies
calculator = HybridSimilarityCalculator.for_modification_detection()
detector = ChecksumChangeDetector(calculator)

# Acceptable - Uses defaults
detector = ChecksumChangeDetector()  # Uses sensible defaults
```

### 3. Inject Services for Testing (NEW 2025-11-01)
```python
# Good - Mockable services for unit testing
mock_matcher = Mock(SimilarityMatcher)
mock_matcher.find_matches.return_value = [MatchResult(...)]

detector = ChecksumChangeDetector(similarity_matcher=mock_matcher)
results = detector.detect_changes(...)

# Test detector orchestration without running real similarity calculations
```

### 4. Use Domain Models
```python
# Good - Work with DetectionResult domain models
results: List[DetectionResult] = detector.detect_changes(...)

# Convert to database models only when needed
content_changes = [r.to_content_change() for r in results]
```

### 5. Separate Loading from Detection
```python
# Good
loader = MarkdownFileLoader()
current = loader.load_from_markdown(path)
results = detector.detect_changes(file_name, current, previous, run_id)

# Avoid
results = detector.detect_changes_from_markdown(path)  # Tight coupling
```

---

## Future Enhancements

### Potential Improvements
- [ ] Add more file loaders (JSON, database query, API)
- [ ] Add semantic change detection (embedding-based)
- [ ] Support batch processing for large datasets
- [ ] Implement caching for repeated operations
- [ ] Add content merge detection (inverse of splits)
- [ ] Support for incremental updates
- [ ] Real-time change detection

---

## References

### Core Components
- **Interface Definitions**: [core/interfaces/detection.py](../core/interfaces/detection.py)
- **Domain Models**: [core/models/detection.py](../core/models/detection.py)
- **Checksum Detector**: [detection/checksum_detector.py](checksum_detector.py)
- **File Loaders**: [detection/file_loader.py](file_loader.py)

### Services (2025-11-01 Refactoring)
- **SimilarityMatcher**: [detection/services/similarity_matcher.py](services/similarity_matcher.py)
- **DiffGenerator**: [detection/services/diff_generator.py](services/diff_generator.py)
- **EdgeCaseAnalyzer**: [detection/services/edge_case_analyzer.py](services/edge_case_analyzer.py)
- **DetectionResultBuilder**: [detection/services/result_builder.py](services/result_builder.py)

### Documentation & Testing
- **Refactoring Details**: [MIGRATION.md](MIGRATION.md) - Complete implementation and testing details
- **Test Suite**: [tests/detection/](../tests/detection/) - 114 comprehensive tests
