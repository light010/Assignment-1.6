# Content Change Detection Module

**Pure checksum-centric change detection with similarity matching (V8.2 Algorithm)**

## Overview

This module implements environment-agnostic content change detection using pure checksum comparison with intelligent similarity matching. The system automatically detects whether it's running in Databricks or local SQLite environment and configures accordingly.

## Key Innovation

**Pure checksum-centric approach**: Changes are detected based solely on content checksums, not location or version metadata. This makes the algorithm:
- **Location-independent**: Same content in different locations = unchanged
- **Version-independent**: Focus on content identity, not version numbers
- **Simple and robust**: Set operations on checksums + similarity scoring

## Algorithm (V8.2)

### Core Strategy - Pure Checksum-Centric

```
┌─────────────────────────────────────────────────────────────┐
│ STEP 1: TIME-BASED FILTERING (Not Version-Based!)         │
│                                                             │
│  Baseline: SELECT * FROM content_chunks                    │
│            WHERE created_at < SINCE_DATE                   │
│                                                             │
│  Current:  SELECT * FROM content_chunks                    │
│            WHERE created_at >= SINCE_DATE                  │
│                                                             │
│  ✅ No version filtering (raw_file_version_nbr)           │
│  ✅ Pure time-based comparison                            │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 2: PER-FILE PROCESSING (Critical!)                    │
│                                                             │
│  For each file in modified_files:                          │
│    1. Filter baseline: file_baseline = baseline_df[        │
│         baseline_df['file_name'] == file_name]            │
│    2. Filter current: file_current = current_df[          │
│         current_df['file_name'] == file_name]             │
│    3. Build checksum dicts (scoped to THIS FILE)          │
│                                                             │
│  ⚠️  Why per-file? Checksums are NOT globally unique!     │
│      Same checksum can appear in multiple files            │
│      (boilerplate, headers, footers, copyright notices)    │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 3: SET OPERATIONS (Per File)                          │
│                                                             │
│  previous_checksums = set(previous_data.keys())            │
│  current_checksums = set(current_data.keys())              │
│                                                             │
│  NEW = current_checksums - previous_checksums              │
│  DELETED = previous_checksums - current_checksums          │
│  UNCHANGED = current_checksums ∩ previous_checksums        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ STEP 4: SIMILARITY MATCHING (NEW × DELETED)                │
│                                                             │
│  For each checksum in NEW:                                 │
│    best_score = 0                                          │
│    For each checksum in DELETED:                           │
│      score = hybrid_similarity(new_text, deleted_text)    │
│      if score > best_score:                                │
│        best_score = score                                  │
│                                                             │
│    If best_score >= threshold (0.8):                       │
│      → MODIFIED                                            │
│    Else:                                                    │
│      → NEW                                                  │
└─────────────────────────────────────────────────────────────┘
```

### Change Types

| Type | Description | Checksum Relationship |
|------|-------------|----------------------|
| **NEW** | Genuinely new content | Checksum only in current set |
| **MODIFIED** | Similar to deleted content | Different checksums, similarity >= 80% |
| **DELETED** | Removed content | Checksum only in previous set |
| **UNCHANGED** | Identical content | Checksum in both sets |

## Architecture

### Database Schema & Relationships

```
┌──────────────────────────────────────────────────────────────┐
│                    content_repo                              │
│  ┌────────────────────────────────────────────────────┐     │
│  │ ud_source_file_id (PK)                             │     │
│  │ raw_file_nme                                       │     │
│  │ raw_file_version_nbr  ⚠️ NOT used in detection!  │     │
│  │ last_modified_dt                                   │     │
│  │ file_status                                        │     │
│  └────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘
                            │
                            │ FK: ud_source_file_id
                            ↓
┌──────────────────────────────────────────────────────────────┐
│                   content_chunks                             │
│  ┌────────────────────────────────────────────────────┐     │
│  │ chunk_id (PK)                                      │     │
│  │ ud_source_file_id (FK) → content_repo              │     │
│  │ content_checksum (SHA-256, 64 chars)               │     │
│  │ chunk_text                                         │     │
│  │ created_at  ✅ USED for time-based filtering      │     │
│  │ status                                             │     │
│  └────────────────────────────────────────────────────┘     │
│                                                              │
│  ⚠️  IMPORTANT: content_checksum is NOT globally unique!   │
│      Same checksum can appear in multiple files             │
│      Uniqueness: (ud_source_file_id, content_checksum)     │
└──────────────────────────────────────────────────────────────┘
                            │
                            │ Referenced by content_checksum
                            ↓
┌──────────────────────────────────────────────────────────────┐
│                 content_change_log                           │
│  ┌────────────────────────────────────────────────────┐     │
│  │ change_id (PK)                                     │     │
│  │ content_checksum (new checksum)                    │     │
│  │ previous_checksum (old checksum, NULL for NEW)     │     │
│  │ file_name  ✅ CRITICAL for scoping                │     │
│  │ change_type (NEW, MODIFIED, DELETED, UNCHANGED)    │     │
│  │ similarity_score (0.0 - 1.0)                       │     │
│  │ similarity_method ('hybrid')                       │     │
│  │ diff_data (JSON)                                   │     │
│  │ requires_faq_regeneration                          │     │
│  │ detection_run_id                                   │     │
│  │ detection_timestamp                                │     │
│  └────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘
```

### Key Tables

- **content_repo**: Source files metadata (version NOT used in detection)
- **content_chunks**: Individual chunks with SHA-256 checksums (created_at used for time filtering)
- **content_change_log**: Detected changes with file_name scoping

### Critical Design Decisions

| Aspect | Decision | Rationale |
|--------|----------|-----------|
| **Checksum Uniqueness** | Per-file, not global | Same content can appear in multiple files |
| **Time Filtering** | Use `created_at` | Version-independent comparison |
| **File Scoping** | Process per file | Handles duplicate checksums correctly |
| **Version Field** | Ignored in detection | Pure checksum-centric (no version metadata) |

### Environment Support

| Environment | Database | Tables Location |
|-------------|----------|----------------|
| **Local** | SQLite | `databases/faq_update.db` |
| **Databricks** | Unity Catalog | `{catalog}.{schema}.*` |

## Usage

### Using the Notebook (Recommended)

```python
# Run the unified notebook
jupyter notebook 7_change_detection_unified.ipynb

# Or in Databricks
# Upload notebook to workspace and run
```

### Using Python API with Repository Pattern (NEW - Recommended)

The detector is **pure and database-agnostic** - it doesn't depend on any database operations. To store results, use the `AuditRepository`:

```python
from detection.checksum_detector import ChecksumChangeDetector
from database.repository import AuditRepository
from database.backends.factory import BackendFactory

# Step 1: Create repository (auto-detects backend from environment)
backend = BackendFactory.create_backend()
repo = AuditRepository(backend)

# Step 2: Get baseline data from database
previous_data = repo.get_previous_checksums(file_name="doc.md")

# Step 3: Prepare current data (checksum -> content mapping)
current_data = {
    "abc123...": {"text": "Old content", "page_num": 1},
    "def456...": {"text": "New content added", "page_num": 2}
}

# Step 4: Create detector and detect changes
detector = ChecksumChangeDetector.for_faq_updates()
results = detector.detect_changes(
    file_name="doc.md",
    current_data=current_data,
    previous_data=previous_data,
    run_id="run_001"
)

# Step 5: Store results in database
storage_result = repo.store_detection_results(results, "run_001")
print(f"Stored {storage_result['rows_inserted']} changes")

# Step 6: Get run summary with savings metrics
summary = repo.get_run_summary("run_001")
print(f"Savings: {summary[0]['savings_percentage']}%")

# Step 7: Get FAQs requiring regeneration
faqs = repo.get_faqs_requiring_regeneration("run_001")
for faq in faqs:
    print(f"FAQ {faq['question_id']}: {faq['faq_component_affected']} affected")
```

**Why this pattern?**
- ✅ **Pure detection logic**: Detector has no database dependencies
- ✅ **Easy to test**: Detector can be tested without database
- ✅ **Flexible storage**: Results can be stored anywhere (DB, file, API)
- ✅ **Backend-agnostic**: Works with SQLite, Databricks, or any backend
- ✅ **Transaction safe**: Repository handles transactions automatically

### Using Python API (Legacy - Without Repository)

```python
from detection.content_change_detector import ContentChangeDetector
from database.adapters import create_adapter, DatabaseDialect

# Initialize detector
detector = ContentChangeDetector(
    checksum_algorithm="sha256",
    similarity_threshold=0.8,
    compute_llm_diffs=True
)

# Prepare data (checksum -> content mapping)
previous_data = {
    "checksum1": {"content_text": "Old content", "page_number": 1},
    "checksum2": {"content_text": "More old content", "page_number": 2}
}

current_data = {
    "checksum1": {"text": "Old content", "file_name": "doc.md"},
    "checksum3": {"text": "New content added", "file_name": "doc.md"}
}

# Detect changes
changes = detector.detect_changes(
    file_name="doc.md",
    current_checksums_data=current_data,
    previous_checksums_data=previous_data,
    detection_run_id="run_001"
)

# Process results
for change in changes:
    print(f"{change.change_type.value}: {change.new_checksum[:8]} "
          f"(similarity: {change.similarity_score})")
```

### Configuration Options

```python
ContentChangeDetector(
    checksum_algorithm="sha256",      # Hash algorithm: sha256, sha512, md5
    similarity_threshold=0.8,         # Modification threshold (0.0 - 1.0)
    compute_llm_diffs=True,          # Generate LLM-friendly diffs
    diff_context_lines=1,            # Context lines in diffs
    similarity_calculator=None        # Custom similarity calculator
)
```

## Components

### Core Classes

#### ContentChangeDetector
Main detection engine implementing V8.2 algorithm.

```python
detector = ContentChangeDetector(similarity_threshold=0.8)

# Detect changes for a file
changes = detector.detect_changes(
    file_name="policy.md",
    current_checksums_data=current,
    previous_checksums_data=previous,
    detection_run_id="run_123"
)

# Simple single-content detection
change = detector.detect_simple_change(
    content_id="chunk1",
    old_content="Old text",
    new_content="New text"
)
```

#### ChecksumExtractor
Computes SHA-256 checksums for content.

```python
from detection.checksum_extractor import ChecksumExtractor

extractor = ChecksumExtractor("sha256")
checksum = extractor.compute_checksum("content text")
# Returns: 64-character hex string
```

#### ChangeDetectionQueries
Database query utilities for storing/retrieving changes.

```python
from detection.database_queries import ChangeDetectionQueries

# Store changes
inserted = ChangeDetectionQueries.store_change_detection_results(
    conn=connection,
    changes=changes_list,
    detection_run_id="run_123",
    use_spark=False  # True for Databricks
)

# Get previous checksums for a file
previous = ChangeDetectionQueries.get_previous_checksums_for_file(
    conn=connection,
    file_name="policy.md",
    since_date=datetime(2025, 1, 1)
)
```

## Similarity Matching

### Hybrid Algorithm

The detector uses a hybrid similarity algorithm combining:

| Algorithm | Weight | Purpose |
|-----------|--------|---------|
| **Jaccard** | 0.20 | Word-level overlap (fast filter) |
| **Difflib** | 0.50 | Sequence matching (main scorer) |
| **BM25** | 0.30 | Term relevance (semantic) |

### Threshold Guidelines

| Threshold | Use Case | Behavior |
|-----------|----------|----------|
| **0.9** | Strict | Only minor edits detected as MODIFIED |
| **0.8** | Standard (default) | Balanced modification detection |
| **0.7** | Permissive | More changes detected as MODIFIED |
| **0.5** | Very permissive | Most changes are MODIFIED |

### Example Similarity Scores

```
"Employees get 12 sick days" → "Employees get 10 sick days"
Similarity: 0.92 (MODIFIED at 0.8 threshold)

"Vacation policy" → "Remote work policy"
Similarity: 0.35 (NEW at 0.8 threshold)

"Same content" → "Same content"
Similarity: 1.0 (UNCHANGED)
```

## Database Compatibility

### Schema Alignment

All components are compatible with the unified schema:

```sql
-- Content chunks (stores chunked content with checksums)
CREATE TABLE content_chunks (
    chunk_id INTEGER PRIMARY KEY,
    ud_source_file_id INTEGER NOT NULL,  -- FK to content_repo
    chunk_index INTEGER NOT NULL,
    content_checksum TEXT NOT NULL,      -- SHA-256 (64 chars)
    chunk_text TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    FOREIGN KEY (ud_source_file_id) REFERENCES content_repo(ud_source_file_id)
);

-- Change detection log (stores detected changes)
CREATE TABLE content_change_log (
    change_id INTEGER PRIMARY KEY,
    content_checksum TEXT NOT NULL,      -- New checksum
    previous_checksum TEXT,              -- Old checksum (NULL for NEW)
    file_name TEXT NOT NULL,
    requires_faq_regeneration INTEGER NOT NULL,
    change_type TEXT,                    -- new_content, modified_content, etc.
    similarity_score REAL,               -- 0.0 - 1.0
    similarity_method TEXT,              -- 'hybrid'
    diff_data TEXT,                      -- JSON diff data
    total_faqs_at_risk INTEGER DEFAULT 0,
    affected_question_count INTEGER DEFAULT 0,
    affected_answer_count INTEGER DEFAULT 0,
    detection_run_id TEXT NOT NULL,
    detection_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Databricks Specifics

In Databricks, all table names are fully qualified:

```python
# Automatic qualification
adapter = create_adapter(
    DatabaseDialect.DATABRICKS,
    catalog="prod",
    schema="faq"
)

# Queries use: prod.faq.content_chunks
table_name = adapter.get_fully_qualified_table("content_chunks")
```

## Testing

### Running Tests

```bash
# Run all detection tests
pytest tests/test_change_detection.py -v

# Run specific test class
pytest tests/test_change_detection.py::TestChecksumCentricDetection -v

# Run with coverage
pytest tests/test_change_detection.py --cov=detection --cov-report=html
```

### Test Structure

```
tests/test_change_detection.py
├── TestChecksumExtractor          # Basic checksum tests
├── TestSimpleChunker              # Chunking tests
├── TestContentChangeDetectorBasics # Basic detection
├── TestChecksumCentricDetection   # V8.2 algorithm tests
├── TestEdgeCases                  # Edge case handling
├── TestSimilarityThresholds       # Threshold behavior
├── TestDatabaseIntegration        # Database operations
└── TestDetectorConfiguration      # Configuration tests
```

## Critical: Handling Duplicate Checksums

### Why Checksums Are NOT Globally Unique

The same content can appear in multiple files (boilerplate, headers, footers, copyright notices).

#### Example: Shared Copyright Notice

```
┌─────────────────────────────────────────────────────────────┐
│ File A: policy.md                                           │
│  Chunk 1: "Employee Benefits Policy"         → checksum_001│
│  Chunk 2: "Copyright 2025 Acme Corp"         → checksum_999│
│  Chunk 3: "All rights reserved"              → checksum_002│
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ File B: handbook.md                                         │
│  Chunk 1: "Employee Handbook"                → checksum_003│
│  Chunk 2: "Copyright 2025 Acme Corp"         → checksum_999│  ← SAME!
│  Chunk 3: "Version 2.0"                      → checksum_004│
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ File C: guide.md                                            │
│  Chunk 1: "Quick Start Guide"                → checksum_005│
│  Chunk 2: "Copyright 2025 Acme Corp"         → checksum_999│  ← SAME!
└─────────────────────────────────────────────────────────────┘

Result: checksum_999 appears in 3 different files!
```

### Incorrect Approach (Global Dictionary) ❌

```python
# ❌ WRONG: Treats checksums as globally unique
previous_data = {}
for _, row in baseline_df.iterrows():
    previous_data[row['content_checksum']] = {
        'content_text': row['chunk_text'],
        'file_name': row['raw_file_nme']
    }

# Problem: checksum_999 gets overwritten!
# Only the LAST file (guide.md) is tracked
# policy.md and handbook.md are LOST
```

**What Happens**:
```
Iteration 1: previous_data['checksum_999'] = {'file_name': 'policy.md', ...}
Iteration 2: previous_data['checksum_999'] = {'file_name': 'handbook.md', ...}  # Overwrites!
Iteration 3: previous_data['checksum_999'] = {'file_name': 'guide.md', ...}     # Overwrites again!

Final state: Only guide.md is tracked for checksum_999
Lost: policy.md and handbook.md ❌
```

### Correct Approach (Per-File Processing) ✅

```python
# ✅ CORRECT: Process each file independently
all_changes = []

for file_name in file_names:
    # Filter baseline for THIS FILE ONLY
    file_baseline = baseline_df[baseline_df['raw_file_nme'] == file_name]
    previous_data = {}
    for _, row in file_baseline.iterrows():
        previous_data[row['content_checksum']] = {
            'content_text': row['chunk_text'],
            'file_name': file_name  # Scoped to THIS file
        }

    # Filter current for THIS FILE ONLY
    file_current = current_df[current_df['raw_file_nme'] == file_name]
    current_data = {}
    for _, row in file_current.iterrows():
        current_data[row['content_checksum']] = {
            'text': row['chunk_text'],
            'file_name': file_name  # Scoped to THIS file
        }

    # Detect changes for THIS FILE
    changes = detector.detect_changes(file_name, current_data, previous_data, run_id)
    all_changes.extend(changes)
```

**What Happens**:
```
Process policy.md:
  previous_data['checksum_999'] = {'file_name': 'policy.md', ...}
  detect_changes('policy.md', ...)  ✅

Process handbook.md:
  previous_data['checksum_999'] = {'file_name': 'handbook.md', ...}
  detect_changes('handbook.md', ...)  ✅

Process guide.md:
  previous_data['checksum_999'] = {'file_name': 'guide.md', ...}
  detect_changes('guide.md', ...)  ✅

Result: All 3 files tracked correctly!
```

### Verification Query

```sql
-- Check for duplicate checksums across files
SELECT
    content_checksum,
    COUNT(DISTINCT ud_source_file_id) as file_count,
    GROUP_CONCAT(DISTINCT cr.raw_file_nme) as files
FROM content_chunks cc
JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
WHERE cc.status = 'active'
GROUP BY content_checksum
HAVING file_count > 1
ORDER BY file_count DESC;

-- Example output:
-- checksum_999 | 3 | "policy.md,handbook.md,guide.md"
-- checksum_888 | 2 | "doc1.md,doc2.md"
```

## Edge Cases

### Content Splits
One chunk becomes multiple chunks (e.g., page split):

```
Previous: [checksum1] → "Long content..."

Current: [checksum2] → "Long con..."
         [checksum3] → "tent..."

Detection: Both match checksum1 with high similarity
Result: 2 MODIFIED changes logged
```

### Content Merges
Multiple chunks become one:

```
Previous: [checksum1] → "Part A"
          [checksum2] → "Part B"

Current: [checksum3] → "Part A Part B"

Detection: checksum3 matches both with moderate similarity
Result: 1 MODIFIED + 1 DELETED logged
```

### Location Changes
Same content at different locations:

```
Previous: page 1, checksum1 → "Unchanged text"
Current:  page 5, checksum1 → "Unchanged text"

Result: UNCHANGED (checksum identity, location irrelevant)
```

## Performance Considerations

### Optimization Strategies

1. **Early exit on Jaccard score**: Skip expensive similarity if Jaccard < 0.3
2. **Batch processing**: Process multiple files in parallel
3. **Index usage**: Ensure checksums are indexed in database
4. **Chunk size**: Balance between granularity and performance (1000 chars recommended)

### Typical Performance

| Operation | SQLite (local) | Databricks (Delta) |
|-----------|---------------|-------------------|
| Chunk 100 pages | ~2 seconds | ~5 seconds |
| Detect changes (1000 chunks) | ~3 seconds | ~8 seconds |
| Store results (1000 records) | ~1 second | ~2 seconds |

## Error Handling

The module handles common errors gracefully:

```python
# Missing file
if not markdown_path.exists():
    print(f"⚠️ WARNING: File not found: {markdown_path}")
    continue

# Database errors
try:
    result = chunk_ingestion.ingest_chunks_for_file(...)
    if not result['success']:
        print(f"Error: {result['message']}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

## Complete Detection Flow (Visual)

```
┌────────────────────────────────────────────────────────────────────────┐
│                    INPUT: SINCE_DATE Parameter                         │
│                  "2025-10-27 17:41:10"                                │
└────────────────────────────────────────────────────────────────────────┘
                                  │
                                  ↓
┌────────────────────────────────────────────────────────────────────────┐
│              QUERY: Load Baseline & Current Chunks                     │
│                                                                         │
│  Baseline: SELECT cc.* FROM content_chunks cc                         │
│            WHERE cc.created_at < SINCE_DATE                           │
│            ✅ Time-based (no version filter!)                         │
│                                                                         │
│  Current:  SELECT cc.* FROM content_chunks cc                         │
│            WHERE cc.created_at >= SINCE_DATE                          │
│            ✅ Time-based (no version filter!)                         │
└────────────────────────────────────────────────────────────────────────┘
                                  │
                                  ↓
┌────────────────────────────────────────────────────────────────────────┐
│            DATAFRAMES: baseline_df, current_df                         │
│                                                                         │
│  Columns: content_checksum, chunk_text, raw_file_nme, created_at     │
│  Example:                                                               │
│    checksum_999 | "Copyright..."  | policy.md   | 2025-10-25         │
│    checksum_999 | "Copyright..."  | handbook.md | 2025-10-25         │
│    checksum_001 | "Benefits..."   | policy.md   | 2025-10-25         │
│                                                                         │
│  ⚠️  Note: checksum_999 appears in MULTIPLE files!                    │
└────────────────────────────────────────────────────────────────────────┘
                                  │
                                  ↓
┌────────────────────────────────────────────────────────────────────────┐
│            LOOP: For each file in modified_content_df                  │
│                                                                         │
│  file_names = ['policy.md', 'handbook.md', 'guide.md']               │
└────────────────────────────────────────────────────────────────────────┘
                                  │
            ┌─────────────────────┴──────────────────────┐
            │                                             │
            ↓                                             ↓
  ┌─────────────────────┐                    ┌─────────────────────┐
  │ Process policy.md   │                    │ Process handbook.md │ ...
  └─────────────────────┘                    └─────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         FILTER: Baseline chunks for THIS FILE ONLY                     │
│                                                                         │
│  file_baseline = baseline_df[baseline_df['file_name'] == 'policy.md']│
│                                                                         │
│  Result for policy.md:                                                │
│    checksum_999 | "Copyright..."  | policy.md                        │
│    checksum_001 | "Benefits..."   | policy.md                        │
│                                                                         │
│  ✅ Checksum_999 from handbook.md is NOT included!                   │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         BUILD: previous_data dictionary (scoped to THIS file)          │
│                                                                         │
│  previous_data = {                                                     │
│    'checksum_999': {                                                   │
│      'content_text': 'Copyright...',                                  │
│      'file_name': 'policy.md'                                         │
│    },                                                                  │
│    'checksum_001': {                                                   │
│      'content_text': 'Benefits...',                                   │
│      'file_name': 'policy.md'                                         │
│    }                                                                   │
│  }                                                                     │
│                                                                         │
│  ✅ Only checksums from policy.md!                                    │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         FILTER: Current chunks for THIS FILE ONLY                      │
│                                                                         │
│  file_current = current_df[current_df['file_name'] == 'policy.md']   │
│                                                                         │
│  Result for policy.md:                                                │
│    checksum_002 | "New Benefits..." | policy.md                      │
│    (checksum_999 deleted)                                             │
│    (checksum_001 modified → checksum_002)                             │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         BUILD: current_data dictionary (scoped to THIS file)           │
│                                                                         │
│  current_data = {                                                      │
│    'checksum_002': {                                                   │
│      'text': 'New Benefits...',                                       │
│      'file_name': 'policy.md'                                         │
│    }                                                                   │
│  }                                                                     │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         DETECT: Run ContentChangeDetector                              │
│                                                                         │
│  changes = detector.detect_changes(                                    │
│    file_name='policy.md',                                             │
│    current_checksums_data=current_data,                               │
│    previous_checksums_data=previous_data,                             │
│    detection_run_id='run_20251031_...'                                │
│  )                                                                     │
│                                                                         │
│  INSIDE detector.detect_changes():                                     │
│    1. prev_set = {'checksum_999', 'checksum_001'}                     │
│    2. curr_set = {'checksum_002'}                                     │
│    3. NEW = curr_set - prev_set = {'checksum_002'}                   │
│    4. DELETED = prev_set - curr_set = {'checksum_999', 'checksum_001'}│
│    5. UNCHANGED = curr_set ∩ prev_set = {}                            │
│    6. SIMILARITY MATCHING:                                             │
│       - Compare checksum_002 with checksum_001                        │
│       - Similarity = 0.92 (> 0.8 threshold)                           │
│       - Result: MODIFIED                                               │
│       - Compare checksum_002 with checksum_999                        │
│       - Similarity = 0.15 (< 0.8 threshold)                           │
│       - No match, so checksum_999 = DELETED                           │
│                                                                         │
│  OUTPUT:                                                               │
│    [                                                                   │
│      ContentChange(old='checksum_001', new='checksum_002',            │
│                    type=MODIFIED, similarity=0.92),                   │
│      ContentChange(old='checksum_999', new='',                        │
│                    type=DELETED, similarity=0.0)                      │
│    ]                                                                   │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         APPEND: Add to all_changes list                                │
│                                                                         │
│  all_changes.extend(changes)                                          │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         LOOP CONTINUES: handbook.md, guide.md, ...                     │
│                                                                         │
│  Each file processed independently with same logic                    │
│  ✅ Duplicate checksums handled correctly per file                    │
└────────────────────────────────────────────────────────────────────────┘
            │
            ↓
┌────────────────────────────────────────────────────────────────────────┐
│         STORE: Save all_changes to content_change_log                  │
│                                                                         │
│  ChangeDetectionQueries.store_change_detection_results(...)           │
│                                                                         │
│  Database rows:                                                        │
│    change_id | content_checksum | previous_checksum | file_name | ... │
│    1         | checksum_002     | checksum_001      | policy.md | ... │
│    2         |                  | checksum_999      | policy.md | ... │
│    ...       | ...              | ...               | ...       | ... │
│                                                                         │
│  ✅ file_name column ensures proper scoping                           │
└────────────────────────────────────────────────────────────────────────┘
```

## Best Practices

### DO

✅ Use similarity threshold 0.8 for balanced detection
✅ Enable LLM diffs for downstream FAQ regeneration
✅ Run detection after content ingestion
✅ Use unified notebook for simplicity
✅ Review MODIFIED changes manually

### DON'T

❌ Don't rely on location metadata for change detection
❌ Don't set threshold too low (<0.5) - too many false MODIFIED
❌ Don't set threshold too high (>0.9) - miss real modifications
❌ Don't skip chunking step - chunks are required for detection
❌ Don't ignore UNCHANGED changes - useful for audit trail

## Examples

### Example 1: Basic Detection

```python
from detection.content_change_detector import ContentChangeDetector

detector = ContentChangeDetector()

# Simple change detection
change = detector.detect_simple_change(
    content_id="policy_v2",
    old_content="Submit expense reports within 30 days",
    new_content="Submit expense reports within 45 days"
)

print(f"Change Type: {change.change_type.value}")
print(f"Similarity: {change.similarity_score:.2f}")
# Output: Change Type: modified_content, Similarity: 0.91
```

### Example 2: Batch File Detection

```python
# Process multiple files
for file_name in ["policy.md", "handbook.md", "faq.md"]:
    current = load_current_chunks(file_name)
    previous = load_previous_chunks(file_name)

    changes = detector.detect_changes(
        file_name=file_name,
        current_checksums_data=current,
        previous_checksums_data=previous,
        detection_run_id=f"batch_{timestamp}"
    )

    print(f"{file_name}: {len(changes)} changes detected")
```

### Example 3: Custom Similarity

```python
from similarity.hybrid import HybridSimilarityCalculator

# Custom weights: emphasize difflib
custom_calc = HybridSimilarityCalculator(
    jaccard_weight=0.1,
    difflib_weight=0.7,
    bm25_weight=0.2
)

detector = ContentChangeDetector(
    similarity_threshold=0.75,
    similarity_calculator=custom_calc
)
```

## Troubleshooting

### Issue: No changes detected

**Possible causes:**
- SINCE_DATE is too recent
- Content hasn't been ingested into content_repo
- Chunks haven't been created

**Solutions:**
```python
# Check content_repo
SELECT COUNT(*) FROM content_repo WHERE last_modified_dt > '2025-10-27';

# Check content_chunks
SELECT COUNT(*) FROM content_chunks WHERE status = 'active';

# Adjust SINCE_DATE
SINCE_DATE = "2025-01-01 00:00:00"  # Use earlier date
```

### Issue: All changes detected as NEW

**Possible causes:**
- Missing baseline chunks (version 1)
- Incorrect similarity threshold

**Solutions:**
```python
# Verify baseline exists
SELECT COUNT(*) FROM content_chunks cc
JOIN content_repo cr ON cc.ud_source_file_id = cr.ud_source_file_id
WHERE cr.raw_file_version_nbr = 1;

# Lower threshold temporarily
detector = ContentChangeDetector(similarity_threshold=0.5)
```

### Issue: Too many MODIFIED detections

**Possible causes:**
- Threshold too low
- Content has minor formatting changes

**Solutions:**
```python
# Raise threshold
detector = ContentChangeDetector(similarity_threshold=0.85)

# Or normalize content before chunking
content = normalize_whitespace(content)
content = remove_markdown_formatting(content)
```

## Migration from V6.x

If upgrading from older versions:

1. **Schema changes**: content_checksums → content_chunks
2. **API changes**: `detect_changes()` signature updated
3. **Configuration**: New parameters for LLM diffs

```python
# Old (V6.x)
from detection.change_detector import ChangeDetector
detector = ChangeDetector(db_path="db.sqlite")
changes = detector.detect(file_name="doc.md")

# New (V8.2)
from detection.content_change_detector import ContentChangeDetector
detector = ContentChangeDetector()
changes = detector.detect_changes(
    file_name="doc.md",
    current_checksums_data=current,
    previous_checksums_data=previous,
    detection_run_id="run_001"
)
```

## References

- **Algorithm Specification**: `docs/granular_impact_algorithm_v8.md`
- **Database Schema**: `database/sql/schema/tables/`
- **Similarity Algorithms**: `similarity/README.md`
- **Chunking Strategy**: `chunking.py`

## Contributing

When contributing to detection module:

1. **Write tests first** (TDD approach)
2. **Maintain simplicity** - no overengineering
3. **Document edge cases** in code comments
4. **Test on both SQLite and Databricks**
5. **Update this README** with new features

## License

© 2025 Analytics Assist Team. All rights reserved.
