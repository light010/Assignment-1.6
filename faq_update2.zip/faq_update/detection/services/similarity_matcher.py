"""
SimilarityMatcher - Find Best Matching Pairs Between Checksums

This service extracts the similarity matching logic from ChecksumChangeDetector,
providing a focused, testable component for finding best matches between
new and deleted checksums.

Algorithm:
    For each new_checksum:
        1. Find best match in deleted_checksums (highest similarity score)
        2. Check if score >= threshold
        3. Return MatchResult

Key Features:
    - Greedy matching (not optimal bipartite matching)
    - O(N×M) complexity (nested loop)
    - Uses injected ISimilarityCalculator
    - Handles missing text gracefully (logs warnings, continues)

Created: 2025-11-01
Extracted from: checksum_detector.py:348-464
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from config.constants import CHECKSUM_DISPLAY_LENGTH
from core.interfaces.similarity import ISimilarityCalculator

logger = logging.getLogger(__name__)


@dataclass
class MatchResult:
    """
    Result of matching a new checksum to deleted checksums.

    Attributes:
        new_checksum: The new checksum being matched
        best_match_checksum: The best matching deleted checksum (None if no match)
        best_score: The similarity score of the best match
        is_match: True if score >= threshold (indicates MODIFIED content)

    Business Rules:
        - is_match = True when best_score >= threshold AND best_match_checksum is not None
        - is_match = False means content will be classified as NEW (no good match found)
    """

    new_checksum: str
    best_match_checksum: Optional[str]
    best_score: float
    is_match: bool


class SimilarityMatcher:
    """
    Finds best matching pairs between new and deleted checksums.

    This service implements the core similarity matching algorithm used in
    change detection. For each new checksum, it finds the best match among
    deleted checksums using a greedy algorithm.

    Design:
        - Dependency Injection: ISimilarityCalculator is injected
        - Single Responsibility: Only handles matching logic
        - Stateless: No state between calls
        - Testable: Can be tested independently with mocked calculator

    Example:
        >>> from similarity.hybrid import HybridSimilarityCalculator
        >>> calc = HybridSimilarityCalculator.for_modification_detection()
        >>> matcher = SimilarityMatcher(calc, threshold=0.8)
        >>>
        >>> new_checksums = {"abc123", "def456"}
        >>> deleted_checksums = {"xyz789", "uvw012"}
        >>> current_data = {
        ...     "abc123": {"text": "New content...", "page_num": 1},
        ...     "def456": {"text": "More new...", "page_num": 2}
        ... }
        >>> previous_data = {
        ...     "xyz789": {"content_text": "Old content...", "page_number": 1},
        ...     "uvw012": {"content_text": "More old...", "page_number": 2}
        ... }
        >>>
        >>> matches = matcher.find_matches(
        ...     new_checksums, deleted_checksums, current_data, previous_data
        ... )
        >>> for match in matches:
        ...     if match.is_match:
        ...         print(f"Match: {match.new_checksum[:8]} → {match.best_match_checksum[:8]} (score: {match.best_score:.3f})")
    """

    def __init__(
        self,
        similarity_calculator: ISimilarityCalculator,
        threshold: float,
    ):
        """
        Initialize SimilarityMatcher.

        Args:
            similarity_calculator: Injected similarity calculator (e.g., HybridSimilarityCalculator)
            threshold: Minimum similarity score for match (0.0 to 1.0)
                      Scores >= threshold indicate MODIFIED content
                      Scores < threshold indicate NEW content (no good match)

        Raises:
            ValueError: If threshold is not between 0.0 and 1.0
        """
        if not (0.0 <= threshold <= 1.0):
            raise ValueError(
                f"threshold must be between 0.0 and 1.0, got {threshold}"
            )

        self.calculator = similarity_calculator
        self.threshold = threshold

    def find_matches(
        self,
        new_checksums: Set[str],
        deleted_checksums: Set[str],
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
    ) -> List[MatchResult]:
        """
        Find best matches between new and deleted checksums.

        This implements the V8.2 greedy matching algorithm:
            1. For each new_checksum, iterate through all deleted_checksums
            2. Compute similarity between new and deleted text
            3. Track the highest scoring match
            4. If best_score >= threshold, mark as match

        Args:
            new_checksums: Set of checksums in current but not in previous
            deleted_checksums: Set of checksums in previous but not in current
            current_data: Current version data
                Format: {checksum: {"text": "...", "page_num": 42, ...}, ...}
            previous_data: Previous version data
                Format: {checksum: {"content_text": "...", "page_number": 42, ...}, ...}

        Returns:
            List of MatchResult, one per new_checksum
            - MatchResult.is_match=True means MODIFIED content
            - MatchResult.is_match=False means NEW content (will be classified separately)

        Algorithm Complexity:
            - Time: O(N×M) where N=len(new_checksums), M=len(deleted_checksums)
            - Space: O(N) for results list

        Note:
            - This is a GREEDY algorithm, not optimal bipartite matching
            - One deleted checksum can match multiple new checksums (content split)
            - Missing text is handled gracefully (logs warning, skips comparison)
            - Uses field names: current_data["text"], previous_data["content_text"]
        """
        results = []

        # For each new checksum, find best match in deleted checksums
        for new_checksum in new_checksums:
            best_match = None
            best_score = 0.0

            # Extract new text (from current data)
            new_text = current_data[new_checksum].get("text", "")
            if not new_text:
                logger.warning(
                    f"⚠️  No text found for new checksum {new_checksum[:CHECKSUM_DISPLAY_LENGTH]}... "
                    f"(skipping similarity matching for this checksum)"
                )
                # Still create MatchResult with no match
                results.append(
                    MatchResult(
                        new_checksum=new_checksum,
                        best_match_checksum=None,
                        best_score=0.0,
                        is_match=False,
                    )
                )
                continue

            # Compare with each deleted checksum (nested loop - O(M))
            for deleted_checksum in deleted_checksums:
                # Extract deleted text (from previous data)
                deleted_text = previous_data[deleted_checksum].get("content_text", "")
                if not deleted_text:
                    logger.warning(
                        f"⚠️  No text found for deleted checksum {deleted_checksum[:CHECKSUM_DISPLAY_LENGTH]}... "
                        f"(skipping this comparison)"
                    )
                    continue

                # Compute similarity
                try:
                    result = self.calculator.compute_similarity(new_text, deleted_text)
                    similarity = result.score

                    # Track best match (greedy: highest score wins)
                    if similarity > best_score:
                        best_score = similarity
                        best_match = deleted_checksum

                except Exception as e:
                    logger.warning(
                        f"⚠️  Failed to compute similarity between "
                        f"{new_checksum[:CHECKSUM_DISPLAY_LENGTH]}... and "
                        f"{deleted_checksum[:CHECKSUM_DISPLAY_LENGTH]}...: {e}"
                    )
                    continue

            # Determine if this is a match (score >= threshold)
            is_match = best_score >= self.threshold and best_match is not None

            # Log match details (debug level)
            if is_match:
                logger.debug(
                    f"   ✓ MODIFIED: {best_match[:CHECKSUM_DISPLAY_LENGTH]}→"
                    f"{new_checksum[:CHECKSUM_DISPLAY_LENGTH]} "
                    f"(similarity: {best_score:.3f})"
                )

            # Create result
            results.append(
                MatchResult(
                    new_checksum=new_checksum,
                    best_match_checksum=best_match,
                    best_score=best_score,
                    is_match=is_match,
                )
            )

        return results
