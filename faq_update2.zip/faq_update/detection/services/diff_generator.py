"""
DiffGenerator - Generate LLM-Friendly Diffs

This service extracts the diff generation logic from ChecksumChangeDetector,
providing a focused, testable component for generating LLM-friendly diffs
between content versions.

Key Features:
    - Exception-safe: Catches all exceptions, returns None on failure
    - Uses DifflibSimilarityCalculator for diff generation
    - Configurable context lines
    - Logs warnings on failure (doesn't crash detection)

Design Philosophy:
    Diffs are an optional enhancement for LLM analysis. If diff generation
    fails, it should NOT break the core change detection logic. The detector
    should continue and return results without diffs.

Created: 2025-11-01
Extracted from: checksum_detector.py:424-440
"""

import logging
from typing import Optional

from config.constants import CHECKSUM_DISPLAY_LENGTH
from similarity.difflib_sim import DifflibSimilarityCalculator

logger = logging.getLogger(__name__)


class DiffGenerator:
    """
    Generates LLM-friendly diffs between content versions.

    This service wraps DifflibSimilarityCalculator to provide exception-safe
    diff generation. Failures are logged but don't propagate - the service
    returns None instead, allowing detection to continue.

    Design:
        - Dependency Injection: DifflibSimilarityCalculator is injected
        - Exception Safety: All exceptions caught and logged
        - Single Responsibility: Only handles diff generation
        - Stateless: No state between calls

    Example:
        >>> from similarity.difflib_sim import DifflibSimilarityCalculator
        >>> diff_calc = DifflibSimilarityCalculator(
        ...     autojunk=True,
        ...     use_quick_ratio=False,
        ...     lowercase=True,
        ...     remove_punctuation=False,
        ... )
        >>> generator = DiffGenerator(diff_calc, context_lines=3)
        >>>
        >>> old_text = "How do I reset my password?"
        >>> new_text = "How do I reset my password and username?"
        >>> diff = generator.generate_llm_diff(old_text, new_text)
        >>> if diff:
        ...     print("Diff generated successfully")
        ... else:
        ...     print("Diff generation failed")
    """

    def __init__(
        self,
        diff_calculator: DifflibSimilarityCalculator,
        context_lines: int = 3,
    ):
        """
        Initialize DiffGenerator.

        Args:
            diff_calculator: Injected DifflibSimilarityCalculator
                Must be configured with desired settings (autojunk, lowercase, etc.)
            context_lines: Number of context lines for diffs (default: 3)
                More lines = more context, but larger diffs

        Raises:
            ValueError: If context_lines is negative
        """
        if context_lines < 0:
            raise ValueError(
                f"context_lines must be non-negative, got {context_lines}"
            )

        self.diff_calculator = diff_calculator
        self.context_lines = context_lines

    def generate_llm_diff(
        self,
        old_text: str,
        new_text: str,
        show_inline_changes: bool = True,
    ) -> Optional[str]:
        """
        Generate LLM-friendly diff in JSON format.

        This method wraps diff_calculator.get_llm_friendly_diff_json() with
        exception handling. If diff generation fails for any reason, it logs
        a warning and returns None (allowing detection to continue).

        Args:
            old_text: Previous version text
            new_text: Current version text
            show_inline_changes: Whether to show inline character-level changes
                (default: True for detailed diffs)

        Returns:
            JSON string with diff structure, or None if generation fails

        Exception Handling:
            - All exceptions are caught (broad exception handler)
            - Logs warning with exception details
            - Returns None (safe fallback)

        Diff Format (when successful):
            JSON string containing:
            - line_changes: List of changed lines
            - inline_changes: Character-level changes (if show_inline_changes=True)
            - context: Surrounding unchanged lines (context_lines before/after)
            - metadata: Statistics (additions, deletions, etc.)

        Note:
            - Empty strings are valid inputs (will generate empty diff)
            - Identical texts return minimal diff (no changes)
            - Large texts may be slow (difflib is O(n*m) worst case)
        """
        try:
            return self.diff_calculator.get_llm_friendly_diff_json(
                text1=old_text,
                text2=new_text,
                context_lines=self.context_lines,
                show_inline_changes=show_inline_changes,
            )
        except Exception as e:
            # Log warning but don't fail detection
            # Note: We don't have checksum context here (stateless service)
            logger.warning(
                f"⚠️  Failed to generate LLM diff: {e}"
            )
            return None

    def generate_llm_diff_with_checksum(
        self,
        old_text: str,
        new_text: str,
        old_checksum: str,
        new_checksum: str,
        show_inline_changes: bool = True,
    ) -> Optional[str]:
        """
        Generate LLM-friendly diff with checksum context for better logging.

        This is a convenience method that includes checksum information in
        warning logs for easier debugging.

        Args:
            old_text: Previous version text
            new_text: Current version text
            old_checksum: Old checksum (for logging)
            new_checksum: New checksum (for logging)
            show_inline_changes: Whether to show inline character-level changes

        Returns:
            JSON string with diff structure, or None if generation fails

        Note:
            This method provides better error messages by including checksum
            context. Use this when checksums are available.
        """
        try:
            return self.diff_calculator.get_llm_friendly_diff_json(
                text1=old_text,
                text2=new_text,
                context_lines=self.context_lines,
                show_inline_changes=show_inline_changes,
            )
        except Exception as e:
            # Log warning with checksum context
            logger.warning(
                f"⚠️  Failed to compute LLM diff for "
                f"{old_checksum[:CHECKSUM_DISPLAY_LENGTH]}... → "
                f"{new_checksum[:CHECKSUM_DISPLAY_LENGTH]}...: {e}"
            )
            return None
