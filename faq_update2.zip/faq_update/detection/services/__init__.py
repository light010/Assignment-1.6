"""
Detection Services - Composable Components for Change Detection

This module provides focused, single-responsibility services that compose
together to implement the ChecksumChangeDetector functionality.

Services:
    - SimilarityMatcher: Finds best matching pairs between checksums
    - DiffGenerator: Generates LLM-friendly diffs
    - EdgeCaseAnalyzer: Detects content splits, merges, relocations
    - DetectionResultBuilder: Constructs DetectionResult objects

Design Principles:
    - Single Responsibility: Each service has one job
    - Dependency Injection: Services are injected, not created internally
    - Testability: Each service can be tested independently
    - Reusability: Services can be used outside ChecksumChangeDetector
    - Stateless: Services are stateless or have minimal state

Created: 2025-11-01
Refactoring: Breaking down ChecksumChangeDetector god object
"""

from detection.services.similarity_matcher import SimilarityMatcher, MatchResult
from detection.services.diff_generator import DiffGenerator
from detection.services.edge_case_analyzer import EdgeCaseAnalyzer, EdgeCaseReport
from detection.services.result_builder import DetectionResultBuilder

__all__ = [
    "SimilarityMatcher",
    "MatchResult",
    "DiffGenerator",
    "EdgeCaseAnalyzer",
    "EdgeCaseReport",
    "DetectionResultBuilder",
]
