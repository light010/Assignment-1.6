"""
DetectionResultBuilder - Construct DetectionResult Objects

This service centralizes the construction logic for DetectionResult objects,
ensuring consistent field mapping and validation across all change types.

Key Responsibilities:
    - Build MODIFIED_CONTENT results from MatchResult
    - Build NEW_CONTENT results
    - Build DELETED_CONTENT results
    - Build UNCHANGED_CONTENT results

Key Features:
    - Handles field name differences (text vs content_text, page_num vs page_number)
    - Ensures correct checksum values ("" for NEW/DELETED)
    - Ensures correct similarity scores (0.0, 1.0)
    - Handles metadata (llm_diff)

Created: 2025-11-01
Extracted from: checksum_detector.py (inline result creation)
"""

from typing import Any, Dict, Optional

from core.models.detection import ChangeType, DetectionResult
from detection.services.similarity_matcher import MatchResult


class DetectionResultBuilder:
    """
    Builds DetectionResult objects from detection data.

    This service provides static methods for constructing DetectionResult
    objects with correct field mappings and validation. It centralizes the
    knowledge of how to map between different data formats.

    Design:
        - Static Methods: No state needed
        - Single Responsibility: Only handles result construction
        - Validation: Relies on DetectionResult.__post_init__ for validation
        - Field Mapping: Handles text vs content_text, page_num vs page_number

    Field Mapping Rules:
        Current Data (current_data):
            - text: Current version content text
            - page_num: Current page number

        Previous Data (previous_data):
            - content_text: Previous version content text (different key!)
            - page_number: Previous page number (different key!)

    Example:
        >>> builder = DetectionResultBuilder()
        >>>
        >>> # Build MODIFIED result
        >>> match = MatchResult(
        ...     new_checksum="abc123",
        ...     best_match_checksum="xyz789",
        ...     best_score=0.87,
        ...     is_match=True
        ... )
        >>> result = builder.build_modified(
        ...     match_result=match,
        ...     file_name="handbook.pdf",
        ...     current_data={"abc123": {"text": "New...", "page_num": 1}},
        ...     previous_data={"xyz789": {"content_text": "Old...", "page_number": 1}},
        ...     llm_diff='{"changes": [...]}',
        ... )
        >>> result.change_type
        <ChangeType.MODIFIED_CONTENT: 'modified_content'>
    """

    @staticmethod
    def build_modified(
        match_result: MatchResult,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
        llm_diff: Optional[str] = None,
    ) -> DetectionResult:
        """
        Build MODIFIED_CONTENT result from MatchResult.

        Args:
            match_result: MatchResult from SimilarityMatcher
                Must have is_match=True and best_match_checksum not None
            file_name: Name of file being analyzed
            current_data: Current version data
            previous_data: Previous version data
            llm_diff: Optional LLM-friendly diff JSON string

        Returns:
            DetectionResult with MODIFIED_CONTENT change type

        Field Extraction:
            - old_checksum: match_result.best_match_checksum
            - new_checksum: match_result.new_checksum
            - similarity_score: match_result.best_score
            - old_content: previous_data[old_checksum]["content_text"]
            - new_content: current_data[new_checksum]["text"]
            - page_number: current_data[new_checksum]["page_num"]
            - metadata: {"llm_diff": llm_diff} if provided

        Note:
            - Uses page_num from CURRENT data (new location)
            - metadata["llm_diff"] only set if llm_diff is not None
        """
        old_checksum = match_result.best_match_checksum
        new_checksum = match_result.new_checksum

        # Build metadata
        metadata = {}
        if llm_diff:
            metadata["llm_diff"] = llm_diff

        return DetectionResult(
            old_checksum=old_checksum,
            new_checksum=new_checksum,
            change_type=ChangeType.MODIFIED_CONTENT,
            similarity_score=match_result.best_score,
            file_name=file_name,
            page_number=current_data[new_checksum].get("page_num"),
            old_content=previous_data[old_checksum].get("content_text"),
            new_content=current_data[new_checksum].get("text"),
            metadata=metadata,
        )

    @staticmethod
    def build_new(
        new_checksum: str,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
    ) -> DetectionResult:
        """
        Build NEW_CONTENT result.

        Args:
            new_checksum: Checksum of new content
            file_name: Name of file being analyzed
            current_data: Current version data

        Returns:
            DetectionResult with NEW_CONTENT change type

        Field Values:
            - old_checksum: "" (empty string - required by DetectionResult)
            - new_checksum: new_checksum
            - similarity_score: 0.0 (semantic: no match)
            - old_content: None (no previous content)
            - new_content: current_data[new_checksum]["text"]
            - page_number: current_data[new_checksum]["page_num"]
            - metadata: {} (empty)

        Note:
            - old_checksum MUST be "" (DetectionResult validates this)
            - similarity_score MUST be 0.0 (semantic meaning: no similarity)
        """
        return DetectionResult(
            old_checksum="",  # Required for NEW_CONTENT
            new_checksum=new_checksum,
            change_type=ChangeType.NEW_CONTENT,
            similarity_score=0.0,  # No match
            file_name=file_name,
            page_number=current_data[new_checksum].get("page_num"),
            old_content=None,
            new_content=current_data[new_checksum].get("text"),
            metadata={},
        )

    @staticmethod
    def build_deleted(
        deleted_checksum: str,
        file_name: str,
        previous_data: Dict[str, Dict[str, Any]],
    ) -> DetectionResult:
        """
        Build DELETED_CONTENT result.

        Args:
            deleted_checksum: Checksum of deleted content
            file_name: Name of file being analyzed
            previous_data: Previous version data

        Returns:
            DetectionResult with DELETED_CONTENT change type

        Field Values:
            - old_checksum: deleted_checksum
            - new_checksum: "" (empty string - required by DetectionResult)
            - similarity_score: 0.0 (semantic: no match)
            - old_content: previous_data[deleted_checksum]["content_text"]
            - new_content: None (no current content)
            - page_number: previous_data[deleted_checksum]["page_number"]
            - metadata: {} (empty)

        Note:
            - new_checksum MUST be "" (DetectionResult validates this)
            - similarity_score MUST be 0.0 (semantic meaning: no similarity)
            - Uses page_number from PREVIOUS data (old location)
        """
        return DetectionResult(
            old_checksum=deleted_checksum,
            new_checksum="",  # Required for DELETED_CONTENT
            change_type=ChangeType.DELETED_CONTENT,
            similarity_score=0.0,  # No match
            file_name=file_name,
            page_number=previous_data[deleted_checksum].get("page_number"),
            old_content=previous_data[deleted_checksum].get("content_text"),
            new_content=None,
            metadata={},
        )

    @staticmethod
    def build_unchanged(
        unchanged_checksum: str,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
    ) -> DetectionResult:
        """
        Build UNCHANGED_CONTENT result.

        Args:
            unchanged_checksum: Checksum that appears in both versions
            file_name: Name of file being analyzed
            current_data: Current version data

        Returns:
            DetectionResult with UNCHANGED_CONTENT change type

        Field Values:
            - old_checksum: unchanged_checksum
            - new_checksum: unchanged_checksum (same as old!)
            - similarity_score: 1.0 (perfect match)
            - old_content: None (optimization: don't load text)
            - new_content: None (optimization: don't load text)
            - page_number: current_data[unchanged_checksum]["page_num"]
            - metadata: {} (empty)

        Note:
            - old_checksum MUST equal new_checksum (DetectionResult validates)
            - similarity_score MUST be 1.0 (semantic: perfect match)
            - Content fields are None (optimization: no need to load text)
            - Uses page_num from CURRENT data (may have moved)
        """
        return DetectionResult(
            old_checksum=unchanged_checksum,
            new_checksum=unchanged_checksum,  # Same as old!
            change_type=ChangeType.UNCHANGED_CONTENT,
            similarity_score=1.0,  # Perfect match
            file_name=file_name,
            page_number=current_data[unchanged_checksum].get("page_num"),
            old_content=None,  # Optimization: don't load
            new_content=None,  # Optimization: don't load
            metadata={},
        )
