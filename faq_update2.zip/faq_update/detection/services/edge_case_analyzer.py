"""
EdgeCaseAnalyzer - Detect and Log Edge Cases in Change Detection

This service extracts edge case detection logic from ChecksumChangeDetector,
providing a focused, testable component for analyzing unusual patterns in
content changes.

Edge Cases Detected:
    - Content Splits: One old content → multiple new contents (1:N mapping)
    - Future: Content Merges, Relocations, etc.

Key Features:
    - Pure analysis (no result modification)
    - Logs warnings for diagnostic purposes
    - Stateless between calls
    - Extensible (easy to add new edge case detections)

Created: 2025-11-01
Extracted from: checksum_detector.py:466-496
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


@dataclass
class EdgeCaseReport:
    """
    Report of detected edge cases in change detection.

    Attributes:
        content_splits: List of detected content splits
            Format: [(old_checksum, [(new_checksum, score), ...]), ...]
            Represents: one old content matched to multiple new contents

    Future Attributes:
        content_merges: Multiple old → one new (N:1 mapping)
        relocations: Content moved to different section/page
        duplications: Same content appears multiple times
    """

    content_splits: List[Tuple[str, List[Tuple[str, float]]]] = field(
        default_factory=list
    )
    # Future: content_merges, relocations, duplications


class EdgeCaseAnalyzer:
    """
    Analyzes edge cases in detection results.

    This service detects unusual patterns in content changes that may require
    special attention or investigation. It's primarily a diagnostic tool that
    logs warnings for review.

    Design:
        - Pure Analysis: Doesn't modify results, only logs warnings
        - Single Responsibility: Only handles edge case detection
        - Extensible: Easy to add new edge case types
        - Stateless: No state between calls

    Example:
        >>> analyzer = EdgeCaseAnalyzer(checksum_display_length=8)
        >>>
        >>> # Build deleted_matched from similarity matching
        >>> deleted_matched = {
        ...     "old_abc123": [("new_def456", 0.85), ("new_ghi789", 0.82)],  # Split!
        ...     "old_xyz999": [("new_uvw000", 0.90)],  # Normal
        ... }
        >>>
        >>> splits = analyzer.detect_content_splits(deleted_matched)
        >>> # Logs: "⚠️  Content SPLIT detected: old_abc1... → 2 new checksums"
    """

    def __init__(self, checksum_display_length: int = 8):
        """
        Initialize EdgeCaseAnalyzer.

        Args:
            checksum_display_length: Number of characters to show in logs
                (default: 8, matches CHECKSUM_DISPLAY_LENGTH constant)
        """
        self.display_len = checksum_display_length

    def detect_content_splits(
        self, deleted_matched: Dict[str, List[Tuple[str, float]]]
    ) -> List[Tuple[str, List[Tuple[str, float]]]]:
        """
        Detect content splits (one old → multiple new).

        A content split occurs when one deleted checksum matches multiple
        new checksums above the similarity threshold. This can happen when:
        - One FAQ is split into multiple FAQs
        - One section is divided into multiple sections
        - Content is reorganized and duplicated

        Args:
            deleted_matched: Mapping of deleted checksums to their matches
                Format: {old_checksum: [(new_checksum, score), ...], ...}
                Only includes matches where score >= threshold

        Returns:
            List of detected splits
            Format: [(old_checksum, [(new_checksum, score), ...]), ...]

        Side Effects:
            - Logs warning for each split detected
            - Warning includes:
                - Old checksum (truncated)
                - Number of new checksums matched
                - New checksums (truncated)
                - Similarity scores

        Note:
            - This is a diagnostic tool, not a blocker
            - Splits may be legitimate (content reorganization)
            - Review logs to understand what happened

        Example Log Output:
            ⚠️  Content SPLIT detected: abc12345... → 3 new checksums
               New checksums: ['def67890...', 'ghi11121...', 'jkl31415...']
               Similarity scores: ['0.850', '0.820', '0.805']
        """
        splits = []

        for deleted_checksum, matches in deleted_matched.items():
            # Split detected if one deleted maps to multiple new
            if len(matches) > 1:
                splits.append((deleted_checksum, matches))

                # Log warning for diagnostic purposes
                logger.warning(
                    f"⚠️  Content SPLIT detected: "
                    f"{deleted_checksum[: self.display_len]}... → "
                    f"{len(matches)} new checksums"
                )
                logger.warning(
                    f"   New checksums: "
                    f"{[m[0][: self.display_len] + '...' for m in matches]}"
                )
                logger.warning(
                    f"   Similarity scores: "
                    f"{[f'{m[1]:.3f}' for m in matches]}"
                )

        return splits

    def detect_content_merges(
        self, new_matched: Dict[str, Tuple[str, float]]
    ) -> List[Tuple[str, List[Tuple[str, float]]]]:
        """
        Detect content merges (multiple old → one new).

        A content merge occurs when one new checksum matches multiple
        deleted checksums. This can happen when:
        - Multiple FAQs are combined into one
        - Multiple sections are merged
        - Content is consolidated

        Args:
            new_matched: Mapping of new checksums to their best match
                Format: {new_checksum: (old_checksum, score), ...}

        Returns:
            List of detected merges
            Format: [(new_checksum, [(old_checksum, score), ...]), ...]

        Side Effects:
            - Logs warning for each merge detected

        Note:
            This is the inverse of content splits. However, due to the
            greedy matching algorithm, merges are less common (each new
            only has one best match, but multiple news can match same old).
        """
        # Build reverse mapping: old_checksum → [(new_checksum, score), ...]
        # Since new_matched only has one best match per new, we need to
        # reverse it to find merges
        old_to_new: Dict[str, List[Tuple[str, float]]] = {}
        for new_checksum, (old_checksum, score) in new_matched.items():
            if old_checksum not in old_to_new:
                old_to_new[old_checksum] = []
            old_to_new[old_checksum].append((new_checksum, score))

        merges = []

        # Actually, with current data structure, merges == splits
        # This is because deleted_matched already captures 1:N relationships
        # We keep this method for future enhancements where we might
        # detect merges differently

        return merges

    def analyze_matches(
        self,
        deleted_matched: Dict[str, List[Tuple[str, float]]],
        new_matched: Dict[str, Tuple[str, float]],
    ) -> EdgeCaseReport:
        """
        Comprehensive edge case analysis.

        This method runs all edge case detections and returns a consolidated
        report.

        Args:
            deleted_matched: {old_checksum: [(new_checksum, score), ...], ...}
            new_matched: {new_checksum: (old_checksum, score), ...}

        Returns:
            EdgeCaseReport with all detected edge cases

        Side Effects:
            - Logs warnings for all detected edge cases

        Example:
            >>> report = analyzer.analyze_matches(deleted_matched, new_matched)
            >>> if report.content_splits:
            ...     print(f"Found {len(report.content_splits)} content splits")
        """
        # Detect content splits
        content_splits = self.detect_content_splits(deleted_matched)

        # Future: Detect other edge cases
        # content_merges = self.detect_content_merges(new_matched)
        # relocations = self.detect_relocations(...)
        # duplications = self.detect_duplications(...)

        return EdgeCaseReport(content_splits=content_splits)
