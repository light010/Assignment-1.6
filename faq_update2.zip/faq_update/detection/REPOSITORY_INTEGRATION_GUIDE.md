# Detection Repository Integration Guide

**Date:** 2025-11-02
**Phase:** 4C - Consolidate Change Detection (Points 146-150)
**Status:** ✅ Complete

---

## Overview

This guide explains how to use the **new repository-integrated change detection** that was implemented as part of Phase 4 of the SQLite to Databricks migration.

### What Changed?

**Before (Old Adapter Pattern):**
```python
from database.adapters import SQLiteDetectionAdapter, create_detection_adapter
from detection import ChecksumChangeDetector

# Create adapter
adapter = create_detection_adapter(db_path="faq.db")

# Load baseline
previous = adapter.get_previous_checksums("file.pdf")

# Detect changes
detector = ChecksumChangeDetector.for_faq_updates()
results = detector.detect_changes("file.pdf", current, previous, "run_1")

# Store results
adapter.store_detection_results(results, "run_1")
```

**After (New Repository Pattern):**
```python
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from detection import ChecksumChangeDetector

# Create backend and repository
backend = BackendFactory.create_backend()  # Auto-detects SQLite or Databricks
repo = AuditRepository(backend)

# Create detector with repository integration
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Load baseline, detect, and store - all through detector!
previous = detector.load_previous_checksums("file.pdf")
results = detector.detect_changes("file.pdf", current, previous, "run_1")
detector.store_detection_results(results, "run_1")

# Or use convenience method for all-in-one:
results, store_result = detector.detect_and_store("file.pdf", current, previous, "run_1")
```

---

## Benefits of Repository Pattern

### ✅ **Database-Agnostic**
- Works with SQLite (local) and Databricks (production) automatically
- No environment detection needed in your code
- Configuration-based backend selection

### ✅ **Cleaner API**
- All operations through one object (detector)
- No need to manage separate adapter objects
- Dependency injection makes testing easier

### ✅ **Better Separation of Concerns**
- Detection logic is pure (no database code)
- Repository handles all database operations
- Backend handles database-specific SQL

### ✅ **Backward Compatible**
- Old adapter-based code still works
- Can gradually migrate to new pattern
- No breaking changes to existing code

---

## Complete Usage Examples

### Example 1: Basic Detection with Repository

```python
"""
Basic change detection with repository integration.
Automatically detects SQLite or Databricks based on configuration.
"""
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from database.config import DatabaseConfig
from detection import ChecksumChangeDetector

# Step 1: Create backend (auto-detects environment)
config = DatabaseConfig.from_env()  # Reads DATABASE_BACKEND env var
backend = BackendFactory.create_backend(config)

# Step 2: Create repository
repo = AuditRepository(backend)

# Step 3: Create detector with repository
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Step 4: Load baseline data from database
previous_data = detector.load_previous_checksums(file_name="Employee_Handbook.pdf")
print(f"Loaded {len(previous_data)} baseline checksums")

# Step 5: Load current data (from files, API, etc.)
# This example assumes you have current data in memory
current_data = {
    "abc123...": {"text": "New content", "page_num": 1},
    "def456...": {"text": "Modified content", "page_num": 2}
}

# Step 6: Detect changes
results = detector.detect_changes(
    file_name="Employee_Handbook.pdf",
    current_data=current_data,
    previous_data=previous_data,
    run_id="run_20251102_001"
)

print(f"Detected {len(results)} changes")

# Step 7: Store results to database
store_result = detector.store_detection_results(results, "run_20251102_001")
print(f"Stored {store_result['rows_inserted']} changes")
```

### Example 2: All-in-One Detection and Storage

```python
"""
Use the convenience method to detect and store in one call.
"""
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from detection import ChecksumChangeDetector

# Setup
backend = BackendFactory.create_backend()
repo = AuditRepository(backend)
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Load data
previous_data = detector.load_previous_checksums("IT_Security_Policy.pdf")
current_data = {...}  # Your current data

# Detect AND store in one call
results, store_result = detector.detect_and_store(
    file_name="IT_Security_Policy.pdf",
    current_data=current_data,
    previous_data=previous_data,
    detection_run_id="run_20251102_002"
)

print(f"Detected: {len(results)} changes")
print(f"Stored: {store_result['rows_inserted']} records")
print(f"Success: {store_result['success']}")
```

### Example 3: Pure Detection (No Database)

```python
"""
Use detector without repository for pure detection logic.
Useful for testing or when you handle database operations separately.
"""
from detection import ChecksumChangeDetector

# Create detector WITHOUT repository
detector = ChecksumChangeDetector.for_faq_updates()

# Pure detection (no database operations)
results = detector.detect_changes(
    file_name="Benefits_Guide.pdf",
    current_data=current_data,
    previous_data=previous_data,
    run_id="run_20251102_003"
)

# Handle results yourself (save to file, API, etc.)
for result in results:
    print(f"{result.change_type}: {result.new_checksum}")
```

### Example 4: Multi-File Detection with Repository

```python
"""
Process multiple files with repository integration.
"""
from database.repository import AuditRepository, ContentRepository
from database.backends.factory import BackendFactory
from detection import ChecksumChangeDetector
from datetime import datetime
import uuid

# Setup
backend = BackendFactory.create_backend()
audit_repo = AuditRepository(backend)
content_repo = ContentRepository(backend)  # For getting file list
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=audit_repo)

# Generate unique run ID
run_id = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

# Get list of files to process
modified_files = content_repo.get_files_modified_after("2025-11-01")

print(f"Processing {len(modified_files)} files...")

all_results = []
for file in modified_files:
    file_name = file['raw_file_nme']

    # Load baseline for this file
    previous_data = detector.load_previous_checksums(file_name=file_name)

    # Load current data (from content_repo, files, etc.)
    current_data = content_repo.get_file_content_as_checksums(file['ud_source_file_id'])

    # Detect changes for this file
    results = detector.detect_changes(file_name, current_data, previous_data, run_id)
    all_results.extend(results)

    print(f"  {file_name}: {len(results)} changes")

# Store all results in one batch
store_result = detector.store_detection_results(all_results, run_id)
print(f"\nStored {store_result['rows_inserted']} total changes")

# Get summary
summary = audit_repo.get_run_summary(run_id)
print(f"\nDetection Run Summary:")
print(f"  Total changes: {summary[0]['total_changes_detected']}")
print(f"  Unique files: {summary[0]['unique_files_changed']}")
print(f"  FAQs saved: {summary[0]['faqs_saved_from_regeneration']}")
```

### Example 5: Databricks-Specific with Unity Catalog

```python
"""
Explicit Databricks configuration with Unity Catalog.
"""
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from database.config import DatabaseConfig
from detection import ChecksumChangeDetector

# Explicit Databricks configuration
config = DatabaseConfig(
    backend='databricks',
    catalog='prod_catalog',
    schema='faq_schema'
)

# Create backend
backend = BackendFactory.create_backend(config)

# Create repository
repo = AuditRepository(backend)

# Create detector
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Use normally - repository handles Spark SQL
previous_data = detector.load_previous_checksums("policy.pdf")
results = detector.detect_changes("policy.pdf", current, previous, "run_001")
detector.store_detection_results(results, "run_001")

print(f"✅ Stored to Unity Catalog: {config.catalog}.{config.schema}.content_change_log")
```

### Example 6: SQLite-Specific for Local Development

```python
"""
Explicit SQLite configuration for local development.
"""
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from database.config import DatabaseConfig
from detection import ChecksumChangeDetector

# Explicit SQLite configuration
config = DatabaseConfig(
    backend='sqlite',
    db_path='databases/faq_update.db'
)

# Create backend
backend = BackendFactory.create_backend(config)

# Create repository
repo = AuditRepository(backend)

# Create detector
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Use normally - repository handles SQLite
previous_data = detector.load_previous_checksums("handbook.pdf")
results = detector.detect_changes("handbook.pdf", current, previous, "run_001")
detector.store_detection_results(results, "run_001")

print(f"✅ Stored to SQLite: {config.db_path}")
```

---

## Environment Configuration

### Local Development (SQLite)

**.env file:**
```bash
DATABASE_BACKEND=sqlite
DATABASE_PATH=databases/faq_update.db
```

**Usage:**
```python
from database.config import DatabaseConfig

config = DatabaseConfig.from_env()
# Reads DATABASE_BACKEND and DATABASE_PATH from environment
```

### Databricks Production (Unity Catalog)

**.env file:**
```bash
DATABASE_BACKEND=databricks
DATABASE_CATALOG=prod_catalog
DATABASE_SCHEMA=faq_schema
```

**Usage:**
```python
from database.config import DatabaseConfig

config = DatabaseConfig.from_env()
# Reads DATABASE_BACKEND, DATABASE_CATALOG, DATABASE_SCHEMA from environment
```

### Auto-Detection

If no environment variables are set, the system auto-detects:
- Databricks: If `DATABRICKS_RUNTIME_VERSION` exists
- SQLite: Default fallback

```python
from database.backends.factory import BackendFactory

# Auto-detects based on environment
backend = BackendFactory.create_backend()
```

---

## Migration Path from Old Adapters

### Step 1: Keep Old Code Working

No changes needed! Old adapter-based code continues to work:

```python
# OLD CODE - Still works!
from database.adapters import create_detection_adapter
adapter = create_detection_adapter(db_path="faq.db")
previous = adapter.get_previous_checksums("file.pdf")
```

### Step 2: Gradually Migrate to Repository Pattern

Start using repository for NEW code:

```python
# NEW CODE - Use repository pattern
from database.repository import AuditRepository
from database.backends.factory import BackendFactory

backend = BackendFactory.create_backend()
repo = AuditRepository(backend)
previous = repo.get_previous_checksums("file.pdf")
```

### Step 3: Update Detector Creation

Add repository to existing detectors:

```python
# OLD
detector = ChecksumChangeDetector.for_faq_updates()

# NEW
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)
```

### Step 4: Remove Adapter Code

Once fully migrated, remove adapter references:

```python
# Remove these imports
# from database.adapters import SQLiteDetectionAdapter, SparkDetectionAdapter

# Keep only these
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
```

---

## Testing with Repository Pattern

### Unit Testing (Mock Repository)

```python
from unittest.mock import Mock
from detection import ChecksumChangeDetector

def test_detection_with_mock_repository():
    # Create mock repository
    mock_repo = Mock()
    mock_repo.get_previous_checksums.return_value = {
        "abc123...": {"content_text": "Old content", "page_number": 1}
    }
    mock_repo.store_detection_results.return_value = {
        'success': True,
        'rows_inserted': 2
    }

    # Create detector with mock
    detector = ChecksumChangeDetector.for_faq_updates(audit_repository=mock_repo)

    # Test detection
    current = {"def456...": {"text": "New content", "page_num": 1}}
    previous = detector.load_previous_checksums("test.pdf")
    results = detector.detect_changes("test.pdf", current, previous, "run_1")

    # Verify mock was called
    mock_repo.get_previous_checksums.assert_called_once_with(file_name="test.pdf")

    # Store and verify
    store_result = detector.store_detection_results(results, "run_1")
    mock_repo.store_detection_results.assert_called_once()
    assert store_result['success'] == True
```

### Integration Testing (In-Memory SQLite)

```python
from database.backends.sqlite import SQLiteBackend
from database.repository import AuditRepository
from detection import ChecksumChangeDetector

def test_detection_with_in_memory_db():
    # Create in-memory SQLite backend
    backend = SQLiteBackend(db_path=":memory:")

    # Setup schema (simplified)
    backend.execute_command("""
        CREATE TABLE content_chunks (
            content_checksum TEXT,
            chunk_text TEXT,
            ud_source_file_id INTEGER
        )
    """)

    # Insert test data
    backend.execute_command("""
        INSERT INTO content_chunks VALUES
        ('abc123...', 'Old content', 1)
    """)

    # Create repository
    repo = AuditRepository(backend)

    # Create detector
    detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

    # Test full workflow
    previous = detector.load_previous_checksums()
    current = {"def456...": {"text": "New content", "page_num": 1}}
    results = detector.detect_changes("test.pdf", current, previous, "run_1")
    store_result = detector.store_detection_results(results, "run_1")

    assert store_result['success'] == True
    assert store_result['rows_inserted'] > 0
```

---

## Performance Considerations

### Batch Processing

For large datasets, process in batches:

```python
from database.repository import AuditRepository
from database.backends.factory import BackendFactory
from detection import ChecksumChangeDetector

backend = BackendFactory.create_backend()
repo = AuditRepository(backend)
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)

# Process files in batches
files = get_all_files()  # Your file list
batch_size = 10

for i in range(0, len(files), batch_size):
    batch = files[i:i+batch_size]

    for file_name in batch:
        previous = detector.load_previous_checksums(file_name)
        current = load_current_data(file_name)
        results = detector.detect_changes(file_name, current, previous, run_id)
        detector.store_detection_results(results, run_id)

    print(f"Processed batch {i//batch_size + 1}")
```

### Caching Baseline Data

If detecting changes for multiple runs on the same file:

```python
# Load baseline once
baseline_cache = {}

for file_name in files:
    if file_name not in baseline_cache:
        baseline_cache[file_name] = detector.load_previous_checksums(file_name)

    previous = baseline_cache[file_name]
    current = load_current_data(file_name)
    results = detector.detect_changes(file_name, current, previous, run_id)
    detector.store_detection_results(results, run_id)
```

---

## Troubleshooting

### Error: "audit_repository not configured"

**Problem:** Trying to use database methods without repository.

**Solution:** Pass `audit_repository` during detector creation:

```python
# WRONG
detector = ChecksumChangeDetector.for_faq_updates()
detector.load_previous_checksums()  # ERROR!

# CORRECT
backend = BackendFactory.create_backend()
repo = AuditRepository(backend)
detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)
detector.load_previous_checksums()  # Works!
```

### Error: "Unknown backend"

**Problem:** Invalid DATABASE_BACKEND environment variable.

**Solution:** Set to 'sqlite' or 'databricks':

```bash
export DATABASE_BACKEND=sqlite
# or
export DATABASE_BACKEND=databricks
```

### Error: "Table not found"

**Problem:** Database schema not initialized.

**Solution:** Run database setup:

```python
from database.create_database import create_all_tables
from database.backends.factory import BackendFactory

backend = BackendFactory.create_backend()
create_all_tables(backend)
```

---

## API Reference

### ChecksumChangeDetector

#### Constructor Parameters

- `similarity_calculator`: Optional[ISimilarityCalculator] - Similarity calculator for modification detection
- `config`: Optional[DetectionConfig] - Configuration settings
- `similarity_matcher`: Optional[SimilarityMatcher] - Service for similarity matching
- `diff_generator`: Optional[DiffGenerator] - Service for diff generation
- `edge_case_analyzer`: Optional[EdgeCaseAnalyzer] - Service for edge case detection
- `result_builder`: Optional[DetectionResultBuilder] - Service for result building
- **`audit_repository`**: Optional[AuditRepository] - **NEW** Repository for database operations

#### Factory Methods

- `for_faq_updates(audit_repository=None)` - Create detector for FAQ updates (threshold=0.8)
- `for_policy_tracking(audit_repository=None)` - Create detector for policy tracking (threshold=0.9)

#### Detection Methods

- `detect_changes(file_name, current_data, previous_data, run_id)` - Detect changes (pure)
- **`load_previous_checksums(file_name=None)`** - **NEW** Load baseline from database
- **`store_detection_results(results, run_id)`** - **NEW** Store results to database
- **`detect_and_store(file_name, current, previous, run_id)`** - **NEW** All-in-one convenience method

---

## Summary

The new repository pattern provides:

✅ **Database-agnostic** detection workflows
✅ **Cleaner API** with dependency injection
✅ **Better separation** of concerns
✅ **Backward compatible** with existing code
✅ **Easier testing** with mock repositories
✅ **Auto-detection** of SQLite vs Databricks

Start using it today for new code, and gradually migrate existing code over time!

---

**Questions?** See [MIGRATION_PLAN_SQLITE_TO_DATABRICKS.md](../MIGRATION_PLAN_SQLITE_TO_DATABRICKS.md) for more details.
