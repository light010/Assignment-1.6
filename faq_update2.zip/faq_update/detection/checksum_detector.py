"""
ChecksumChangeDetector - Interface-Based Implementation with Service Composition

This module implements the IChangeDetector interface using pure checksum comparison
with similarity matching. As of 2025-11-01, it uses a service-based architecture
for better testability and maintainability.

Architecture:
    - ChecksumChangeDetector: Orchestrator (implements IChangeDetector)
    - SimilarityMatcher: Finds best matches between checksums
    - DiffGenerator: Generates LLM-friendly diffs
    - EdgeCaseAnalyzer: Detects content splits/merges
    - DetectionResultBuilder: Constructs DetectionResult objects

Key Features:
    - Service composition (dependency injection)
    - Backward compatible (existing API unchanged)
    - Testable (services can be mocked)
    - Returns DetectionResult domain models
    - Configuration via DetectionConfig dataclass

Design Principles:
    - Strategy Pattern: IChangeDetector interface
    - Dependency Injection: All services injected
    - Single Responsibility: Each service has one job
    - Domain-Driven Design: Uses DetectionResult, DetectionConfig
    - Framework Agnostic: No database or utility dependencies

Comparison with ContentChangeDetector:
    - OLD: Returns List[ContentChange] (database model)
    - NEW: Returns List[DetectionResult] (domain model)
    - OLD: Creates ChecksumExtractor internally
    - NEW: Uses utility.hashing.compute_checksum directly
    - OLD: Mixed concerns (detection + database)
    - NEW: Pure detection logic only

Example:
    >>> from detection.checksum_detector import ChecksumChangeDetector
    >>> from similarity.hybrid import HybridSimilarityCalculator
    >>> from core.models.detection import DetectionConfig
    >>>
    >>> # Create detector with dependency injection
    >>> calc = HybridSimilarityCalculator.for_modification_detection()
    >>> config = DetectionConfig(similarity_threshold=0.8, compute_llm_diffs=True)
    >>> detector = ChecksumChangeDetector(similarity_calculator=calc, config=config)
    >>>
    >>> # Detect changes
    >>> current_data = {"abc123": {"text": "New content", "page_num": 1}}
    >>> previous_data = {"xyz789": {"content_text": "Old content", "page_number": 1}}
    >>> results = detector.detect_changes("file.md", current_data, previous_data, "run_1")
    >>>
    >>> # Convert to database model if needed
    >>> content_changes = [r.to_content_change() for r in results]
"""

import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple

from config.constants import (
    CHECKSUM_ALGORITHM,
    CHECKSUM_DISPLAY_LENGTH,
    DEFAULT_SIMILARITY_THRESHOLD,
    DEFAULT_COMPUTE_LLM_DIFFS,
    DEFAULT_DIFF_CONTEXT_LINES,
)
from core.interfaces.detection import IChangeDetector
from core.interfaces.similarity import ISimilarityCalculator
from core.models.detection import ChangeType, DetectionConfig, DetectionResult
from database.models import ContentChange
from detection.services.similarity_matcher import SimilarityMatcher
from detection.services.diff_generator import DiffGenerator
from detection.services.edge_case_analyzer import EdgeCaseAnalyzer
from detection.services.result_builder import DetectionResultBuilder
from similarity.difflib_sim import DifflibSimilarityCalculator
from similarity.hybrid import HybridSimilarityCalculator
from utility.logging import get_logger

# Optional repository import for database operations (Phase 4 migration)
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from database.repository.audit_repository import AuditRepository

logger = get_logger(__name__)


class ChecksumChangeDetector(IChangeDetector):
    """
    Checksum-based change detector implementing IChangeDetector interface.

    This is a refactored implementation of the V8.2 algorithm that follows the
    interface-based design pattern. It uses pure checksum comparison with
    similarity matching to detect content changes.

    Algorithm:
        1. Extract checksum sets from current and previous data
        2. Perform set operations (new, deleted, unchanged)
        3. Similarity matching between new and deleted checksums
        4. Classify changes as NEW, MODIFIED, DELETED, or UNCHANGED
        5. Return DetectionResult objects (domain models)

    Attributes:
        similarity_calculator: ISimilarityCalculator for modification detection
        config: DetectionConfig containing all configuration
        diff_calculator: Optional DifflibSimilarityCalculator for LLM diffs

    Design Notes:
        - Uses dependency injection (similarity_calculator is injected)
        - Returns DetectionResult (domain model), not ContentChange (database model)
        - Configuration via DetectionConfig dataclass
        - No direct database operations (separation of concerns)
        - Stateless (can be reused for multiple detection runs)

    Example:
        >>> from detection.checksum_detector import ChecksumChangeDetector
        >>> from similarity.hybrid import HybridSimilarityCalculator
        >>> from core.models.detection import DetectionConfig
        >>>
        >>> # Using factory method
        >>> detector = ChecksumChangeDetector.for_faq_updates()
        >>> results = detector.detect_changes("faq.md", current, previous, "run_1")
        >>>
        >>> # Using custom configuration
        >>> calc = HybridSimilarityCalculator.for_modification_detection()
        >>> config = DetectionConfig(
        ...     similarity_threshold=0.85,
        ...     compute_llm_diffs=True,
        ...     diff_context_lines=5
        ... )
        >>> detector = ChecksumChangeDetector(calc, config)
        >>> results = detector.detect_changes("faq.md", current, previous, "run_1")
    """

    def __init__(
        self,
        similarity_calculator: Optional[ISimilarityCalculator] = None,
        config: Optional[DetectionConfig] = None,
        # NEW: Service injection (optional for backward compatibility)
        similarity_matcher: Optional[SimilarityMatcher] = None,
        diff_generator: Optional[DiffGenerator] = None,
        edge_case_analyzer: Optional[EdgeCaseAnalyzer] = None,
        result_builder: Optional[DetectionResultBuilder] = None,
        # NEW: Repository injection for database operations (Phase 4 migration)
        audit_repository: Optional["AuditRepository"] = None,
    ):
        """
        Initialize checksum change detector with service composition.

        Args:
            similarity_calculator: ISimilarityCalculator for modification detection.
                If None, uses HybridSimilarityCalculator.for_modification_detection()
            config: DetectionConfig with configuration settings.
                If None, uses default configuration from constants
            similarity_matcher: Optional SimilarityMatcher service (for testing/customization)
            diff_generator: Optional DiffGenerator service (for testing/customization)
            edge_case_analyzer: Optional EdgeCaseAnalyzer service (for testing/customization)
            result_builder: Optional DetectionResultBuilder service (for testing/customization)
            audit_repository: Optional AuditRepository for database operations (Phase 4 migration)
                If provided, enables database integration for loading baseline data
                and storing detection results directly from the detector

        Raises:
            ValueError: If config contains invalid values

        Backward Compatibility:
            - Old code: `ChecksumChangeDetector()` still works (creates default services)
            - Old code: `ChecksumChangeDetector(calc, config)` still works
            - New code: Can inject custom services for testing/customization

        Example:
            >>> from similarity.hybrid import HybridSimilarityCalculator
            >>> from core.models.detection import DetectionConfig
            >>>
            >>> # Default configuration (backward compatible)
            >>> detector = ChecksumChangeDetector()
            >>>
            >>> # Custom similarity calculator (backward compatible)
            >>> calc = HybridSimilarityCalculator.for_modification_detection()
            >>> detector = ChecksumChangeDetector(similarity_calculator=calc)
            >>>
            >>> # NEW: Inject custom services (for testing)
            >>> from detection.services import SimilarityMatcher
            >>> matcher = SimilarityMatcher(calc, threshold=0.9)
            >>> detector = ChecksumChangeDetector(
            ...     similarity_calculator=calc,
            ...     similarity_matcher=matcher
            ... )
        """
        # Initialize configuration (use defaults from constants if not provided)
        if config is None:
            self.config = DetectionConfig(
                checksum_algorithm=CHECKSUM_ALGORITHM,
                similarity_threshold=DEFAULT_SIMILARITY_THRESHOLD,
                compute_llm_diffs=DEFAULT_COMPUTE_LLM_DIFFS,
                diff_context_lines=DEFAULT_DIFF_CONTEXT_LINES,
            )
        else:
            self.config = config

        # Initialize similarity calculator (use factory method if not provided)
        if similarity_calculator is None:
            self.similarity_calculator = HybridSimilarityCalculator.for_modification_detection()
        else:
            self.similarity_calculator = similarity_calculator

        # Initialize services (create defaults if not provided - backward compatibility)

        # SimilarityMatcher service
        if similarity_matcher is None:
            self.matcher = SimilarityMatcher(
                similarity_calculator=self.similarity_calculator,
                threshold=self.config.similarity_threshold,
            )
        else:
            self.matcher = similarity_matcher

        # DiffGenerator service (only if enabled in config)
        # Also create diff_calculator for backward compatibility with code1
        if diff_generator is None:
            self.diff_generator = None
            self.diff_calculator = None  # For code1 compatibility
            if self.config.compute_llm_diffs:
                diff_calc = DifflibSimilarityCalculator(
                    autojunk=True,
                    use_quick_ratio=False,
                    lowercase=True,
                    remove_punctuation=False,  # Keep numbers/dates intact
                )
                self.diff_calculator = diff_calc  # Store for code1
                self.diff_generator = DiffGenerator(
                    diff_calculator=diff_calc,
                    context_lines=self.config.diff_context_lines,
                )
        else:
            self.diff_generator = diff_generator
            self.diff_calculator = None  # Not available when injected

        # EdgeCaseAnalyzer service
        if edge_case_analyzer is None:
            self.edge_analyzer = EdgeCaseAnalyzer(
                checksum_display_length=CHECKSUM_DISPLAY_LENGTH
            )
        else:
            self.edge_analyzer = edge_case_analyzer

        # DetectionResultBuilder service
        if result_builder is None:
            self.result_builder = DetectionResultBuilder()
        else:
            self.result_builder = result_builder

        # AuditRepository for database operations (optional - Phase 4 migration)
        self.audit_repository = audit_repository

        logger.info(
            f"ChecksumChangeDetector initialized: "
            f"algorithm={self.config.checksum_algorithm}, "
            f"similarity_threshold={self.config.similarity_threshold}, "
            f"compute_llm_diffs={self.config.compute_llm_diffs}, "
            f"repository_mode={'enabled' if audit_repository else 'disabled'}"
        )


    def detect_changes(
        self,
        file_name: str,
        current_checksums_data: Dict[str, Dict],
        previous_checksums_data: Dict[str, Dict],
        detection_run_id: str,
    ) -> List[ContentChange]:
        """
        Detect content changes using PURE CHECKSUM COMPARISON with similarity matching.

        Strategy (from V8.2 algorithm):
        1. Get previous checksums for THIS FILE only (scoped, not global)
        2. Get current checksums for THIS FILE
        3. Find new checksums (not in previous set)
        4. Find deleted checksums (not in current set)
        5. Use SIMILARITY MATCHING to link new → deleted (modified content)

        Args:
            file_name: Name of file being analyzed
            current_checksums_data: Current file checksums
                Format: {checksum: {'text': '...', 'markdown_path': '...', 'page_num': 42}, ...}
            previous_checksums_data: Previous file checksums
                Format: {checksum: {'content_text': '...', 'page_number': 42}, ...}
            detection_run_id: Unique ID for this detection run

        Returns:
            List of ContentChange objects with change type and similarity scores
        """
        start_time = time.perf_counter()

        logger.info(f"🔍 Detecting changes for: {file_name}")
        logger.info(f"   Detection run: {detection_run_id}")

        # Step 1: Extract checksum sets
        current_checksums = set(current_checksums_data.keys())
        previous_checksums = set(previous_checksums_data.keys())

        # Step 2: Set operations (checksums only, NO location comparison!)
        new_checksums = current_checksums - previous_checksums
        deleted_checksums = previous_checksums - current_checksums
        unchanged_checksums = current_checksums & previous_checksums

        logger.info(f"📊 Checksum analysis for {file_name}:")
        logger.info(f"   Current:   {len(current_checksums)} checksums")
        logger.info(f"   Previous:  {len(previous_checksums)} checksums")
        logger.info(f"   New:       {len(new_checksums)} checksums")
        logger.info(f"   Deleted:   {len(deleted_checksums)} checksums")
        logger.info(f"   Unchanged: {len(unchanged_checksums)} checksums")

        # Step 3: SIMILARITY MATCHING (N × M where N and M are typically small)
        changes = []

        if new_checksums and deleted_checksums:
            logger.info(
                f"🧮 Running similarity matching "
                f"({len(new_checksums)} × {len(deleted_checksums)} = "
                f"{len(new_checksums) * len(deleted_checksums)} comparisons)..."
            )

            # Track matching for edge case detection (splits/merges)
            deleted_matched, new_matched = self._perform_similarity_matching(
                new_checksums=new_checksums,
                deleted_checksums=deleted_checksums,
                current_checksums_data=current_checksums_data,
                previous_checksums_data=previous_checksums_data,
                changes=changes,
                file_name=file_name,  # ✅ Pass file_name to similarity matching
            )

            # Handle edge cases
            # self._detect_content_splits(deleted_matched)

        else:
            # No similarity matching needed
            logger.info("⚡ No similarity matching needed (no overlap between new/deleted)")

        # Step 4: Handle NEW content (no match found)
        for new_checksum in new_checksums:
            # Skip if already matched as modified
            if any(c.new_checksum == new_checksum for c in changes):
                continue

            changes.append(
                ContentChange(
                    old_checksum=None,  # ✅ Use None instead of empty string
                    new_checksum=new_checksum,
                    change_type=ChangeType.NEW_CONTENT,
                    detected_at=datetime.now(),
                    file_name=file_name,
                    page_number=current_checksums_data[new_checksum].get("page_num"),
                    old_content=None,
                    new_content=current_checksums_data[new_checksum].get("text"),
                    similarity_score=0.0,
                )
            )

        # Step 5: Handle DELETED checksums (not matched to any new checksum)
        deleted_matched_set = set()
        for c in changes:
            if c.old_checksum:
                deleted_matched_set.add(c.old_checksum)

        for deleted_checksum in deleted_checksums:
            if deleted_checksum not in deleted_matched_set:
                # Truly DELETED content (no similar new content found)
                changes.append(
                    ContentChange(
                        old_checksum=deleted_checksum,
                        new_checksum=None,  # ✅ Use None instead of empty string
                        change_type=ChangeType.DELETED_CONTENT,
                        detected_at=datetime.now(),
                        file_name=file_name,
                        page_number=previous_checksums_data[deleted_checksum].get("page_number"),
                        old_content=previous_checksums_data[deleted_checksum].get("content_text"),
                        new_content=None,
                        similarity_score=0.0,
                    )
                )

        # Step 6: Handle UNCHANGED content (for completeness in reporting)
        for unchanged_checksum in unchanged_checksums:
            # ✅ Populate content for UNCHANGED (same content in both)
            content_text = current_checksums_data.get(unchanged_checksum, {}).get("text")
            changes.append(
                ContentChange(
                    old_checksum=unchanged_checksum,
                    new_checksum=unchanged_checksum,
                    change_type=ChangeType.UNCHANGED_CONTENT,
                    detected_at=datetime.now(),
                    file_name=file_name,
                    page_number=current_checksums_data.get(unchanged_checksum, {}).get("page_num"),
                    old_content=content_text,  # ✅ Same content in both old and new
                    new_content=content_text,  # ✅ Same content in both old and new
                    similarity_score=1.0,  # Perfect match
                )
            )

        end_time = time.perf_counter()
        processing_time_ms = (end_time - start_time) * 1000

        logger.info(f"✅ Changes detected: {len(changes)}")
        logger.info(f"   New:      {sum(1 for c in changes if c.change_type == ChangeType.NEW_CONTENT)}")
        logger.info(f"   Modified: {sum(1 for c in changes if c.change_type == ChangeType.MODIFIED_CONTENT)}")
        logger.info(f"   Deleted:  {sum(1 for c in changes if c.change_type == ChangeType.DELETED_CONTENT)}")
        logger.info(f"   Unchanged: {sum(1 for c in changes if c.change_type == ChangeType.UNCHANGED_CONTENT)}")
        logger.info(f"⏱️  Processing time: {processing_time_ms:.2f}ms")

        return changes

    def _perform_similarity_matching(
        self,
        new_checksums: Set[str],
        deleted_checksums: Set[str],
        current_checksums_data: Dict[str, Dict],
        previous_checksums_data: Dict[str, Dict],
        changes: List[ContentChange],
        file_name: str,  # ✅ Add file_name parameter
    ) -> Tuple[Dict[str, List], Dict[str, Tuple]]:
        """
        Perform similarity matching between new and deleted checksums.

        For each NEW checksum, finds best match in DELETED checksums using hybrid similarity.
        If similarity >= threshold, marks as MODIFIED; otherwise, marks as NEW.

        Args:
            new_checksums: Set of new checksums
            deleted_checksums: Set of deleted checksums
            current_checksums_data: Current file data
            previous_checksums_data: Previous file data
            changes: List to append changes to (mutated)

        Returns:
            Tuple of (deleted_matched dict, new_matched dict) for edge case detection
        """
        deleted_matched = {}  # {deleted_checksum: [(new_checksum, score), ...]}
        new_matched = {}  # {new_checksum: (deleted_checksum, score)}

        for new_checksum in new_checksums:
            new_text = current_checksums_data[new_checksum].get("text", "")

            if not new_text:
                logger.warning(f"⚠️  No text found for new checksum {new_checksum[:8]}...")
                continue

            best_match = None
            best_score = 0.0

            # Find best match among deleted checksums
            for deleted_checksum in deleted_checksums:
                deleted_text = previous_checksums_data[deleted_checksum].get("content_text", "")

                if not deleted_text:
                    continue

                # Compute hybrid similarity (combines multiple algorithms)
                result = self.similarity_calculator.compute_similarity(new_text, deleted_text)
                similarity = result.score

                if similarity > best_score:
                    best_score = similarity
                    best_match = deleted_checksum

            # Decision: Threshold check (default: 0.8 = 80% similarity)
            if best_score >= self.config.similarity_threshold and best_match:
                # This is MODIFIED content
                new_matched[new_checksum] = (best_match, best_score)

                if best_match not in deleted_matched:
                    deleted_matched[best_match] = []
                deleted_matched[best_match].append((new_checksum, best_score))

                # Compute LLM-friendly diff if enabled (JSON format)
                llm_diff = None
                if self.config.compute_llm_diffs and self.diff_calculator:
                    old_text = previous_checksums_data[best_match].get("content_text", "")
                    if old_text and new_text:
                        try:
                            llm_diff = self.diff_calculator.get_llm_friendly_diff_json(
                                text1=old_text,
                                text2=new_text,
                                context_lines=self.config.diff_context_lines,
                                show_inline_changes=True,
                            )
                        except Exception as e:
                            logger.warning(
                                f"⚠️  Failed to compute LLM diff for {new_checksum[:8]}: {e}"
                            )

                changes.append(
                    ContentChange(
                        old_checksum=best_match,
                        new_checksum=new_checksum,
                        change_type=ChangeType.MODIFIED_CONTENT,
                        detected_at=datetime.now(),
                        file_name=file_name,  # ✅ Use parameter instead of checksum data
                        page_number=current_checksums_data[new_checksum].get("page_num"),
                        old_content=previous_checksums_data[best_match].get("content_text"),
                        new_content=new_text,
                        similarity_score=best_score,
                        llm_friendly_diff=llm_diff,
                    )
                )

                logger.debug(
                    f"   ✓ MODIFIED: {best_match[:8]}→{new_checksum[:8]} "
                    f"(similarity: {best_score:.3f})"
                )
            # else: No good match - will be handled as NEW content in main flow

        return deleted_matched, new_matched
    
    # def detect_changes(
    #     self,
    #     file_name: str,
    #     current_data: Dict[str, Dict[str, Any]],
    #     previous_data: Dict[str, Dict[str, Any]],
    #     run_id: str,
    # ) -> List[DetectionResult]:
    #     """
    #     Detect content changes using PURE CHECKSUM COMPARISON with similarity matching.

    #     This implements the V8.2 algorithm:
    #     1. Extract checksum sets (current vs previous)
    #     2. Set operations: new, deleted, unchanged
    #     3. Similarity matching between new and deleted (O(N×M) where N, M typically small)
    #     4. Classify changes: NEW, MODIFIED, DELETED, UNCHANGED
    #     5. Return DetectionResult objects

    #     Args:
    #         file_name: Name of file being analyzed
    #         current_data: Current file checksums and content
    #             Format: {checksum: {'text': '...', 'page_num': 42, ...}, ...}
    #         previous_data: Previous file checksums and content
    #             Format: {checksum: {'content_text': '...', 'page_number': 42, ...}, ...}
    #         run_id: Unique identifier for this detection run

    #     Returns:
    #         List of DetectionResult objects with change classifications

    #     Raises:
    #         ValueError: If data format is invalid

    #     Example:
    #         >>> current = {
    #         ...     "abc123": {"text": "Hello World", "page_num": 1},
    #         ...     "def456": {"text": "New Content", "page_num": 2}
    #         ... }
    #         >>> previous = {
    #         ...     "abc123": {"content_text": "Hello World", "page_number": 1},
    #         ...     "xyz789": {"content_text": "Old Content", "page_number": 3}
    #         ... }
    #         >>> results = detector.detect_changes("test.md", current, previous, "run_1")
    #         >>> len(results)
    #         3
    #         >>> results[0].change_type
    #         <ChangeType.UNCHANGED_CONTENT: 'unchanged_content'>
    #     """
    #     start_time = time.perf_counter()

    #     logger.info(f"🔍 Detecting changes for: {file_name}")
    #     logger.info(f"   Detection run: {run_id}")

    #     # Step 1: Extract checksum sets
    #     current_checksums = set(current_data.keys())
    #     previous_checksums = set(previous_data.keys())

    #     # Step 2: Set operations (checksums only, NO location comparison!)
    #     new_checksums = current_checksums - previous_checksums
    #     deleted_checksums = previous_checksums - current_checksums
    #     unchanged_checksums = current_checksums & previous_checksums

    #     logger.info(f"📊 Checksum analysis for {file_name}:")
    #     logger.info(f"   Current:   {len(current_checksums)} checksums")
    #     logger.info(f"   Previous:  {len(previous_checksums)} checksums")
    #     logger.info(f"   New:       {len(new_checksums)} checksums")
    #     logger.info(f"   Deleted:   {len(deleted_checksums)} checksums")
    #     logger.info(f"   Unchanged: {len(unchanged_checksums)} checksums")

    #     # Step 3: SIMILARITY MATCHING (N × M where N and M are typically small)
    #     results = []

    #     if new_checksums and deleted_checksums:
    #         logger.info(
    #             f"🧮 Running similarity matching "
    #             f"({len(new_checksums)} × {len(deleted_checksums)} = "
    #             f"{len(new_checksums) * len(deleted_checksums)} comparisons)..."
    #         )

    #         # REFACTORED: Use SimilarityMatcher service
    #         match_results = self.matcher.find_matches(
    #             new_checksums=new_checksums,
    #             deleted_checksums=deleted_checksums,
    #             current_data=current_data,
    #             previous_data=previous_data,
    #         )

    #         # Build deleted_matched for edge case detection
    #         deleted_matched = {}
    #         for match in match_results:
    #             if match.is_match and match.best_match_checksum:
    #                 if match.best_match_checksum not in deleted_matched:
    #                     deleted_matched[match.best_match_checksum] = []
    #                 deleted_matched[match.best_match_checksum].append(
    #                     (match.new_checksum, match.best_score)
    #                 )

    #         # REFACTORED: Use EdgeCaseAnalyzer service
    #         self.edge_analyzer.detect_content_splits(deleted_matched)

    #         # Build results for MODIFIED content
    #         for match in match_results:
    #             if match.is_match:
    #                 # REFACTORED: Use DiffGenerator service (if enabled)
    #                 llm_diff = None
    #                 if self.diff_generator:
    #                     old_text = previous_data[match.best_match_checksum].get("content_text", "")
    #                     new_text = current_data[match.new_checksum].get("text", "")
    #                     if old_text and new_text:
    #                         llm_diff = self.diff_generator.generate_llm_diff_with_checksum(
    #                             old_text=old_text,
    #                             new_text=new_text,
    #                             old_checksum=match.best_match_checksum,
    #                             new_checksum=match.new_checksum,
    #                         )

    #                 # REFACTORED: Use DetectionResultBuilder service
    #                 result = self.result_builder.build_modified(
    #                     match_result=match,
    #                     file_name=file_name,
    #                     current_data=current_data,
    #                     previous_data=previous_data,
    #                     llm_diff=llm_diff,
    #                 )
    #                 results.append(result)

    #     else:
    #         # No similarity matching needed
    #         logger.info("⚡ No similarity matching needed (no overlap between new/deleted)")

    #     # Step 4: Handle NEW content (no match found)
    #     # Build set of matched new checksums for O(1) lookup
    #     new_matched_set = {r.new_checksum for r in results if r.new_checksum}

    #     for new_checksum in new_checksums:
    #         # Skip if already matched as modified
    #         if new_checksum in new_matched_set:
    #             continue

    #         # REFACTORED: Use DetectionResultBuilder service
    #         result = self.result_builder.build_new(
    #             new_checksum=new_checksum,
    #             file_name=file_name,
    #             current_data=current_data,
    #         )
    #         results.append(result)

    #     # Step 5: Handle DELETED checksums (not matched to any new checksum)
    #     deleted_matched_set = {r.old_checksum for r in results if r.old_checksum}

    #     for deleted_checksum in deleted_checksums:
    #         if deleted_checksum not in deleted_matched_set:
    #             # Truly DELETED content (no similar new content found)
    #             # REFACTORED: Use DetectionResultBuilder service
    #             result = self.result_builder.build_deleted(
    #                 deleted_checksum=deleted_checksum,
    #                 file_name=file_name,
    #                 previous_data=previous_data,
    #             )
    #             results.append(result)

    #     # Step 6: Handle UNCHANGED content (for completeness in reporting)
    #     for unchanged_checksum in unchanged_checksums:
    #         # REFACTORED: Use DetectionResultBuilder service
    #         result = self.result_builder.build_unchanged(
    #             unchanged_checksum=unchanged_checksum,
    #             file_name=file_name,
    #             current_data=current_data,
    #         )
    #         results.append(result)

    #     end_time = time.perf_counter()
    #     processing_time_ms = (end_time - start_time) * 1000

    #     logger.info(f"✅ Changes detected: {len(results)}")
    #     logger.info(f"   New:      {sum(1 for r in results if r.change_type == ChangeType.NEW_CONTENT)}")
    #     logger.info(f"   Modified: {sum(1 for r in results if r.change_type == ChangeType.MODIFIED_CONTENT)}")
    #     logger.info(f"   Deleted:  {sum(1 for r in results if r.change_type == ChangeType.DELETED_CONTENT)}")
    #     logger.info(f"   Unchanged: {sum(1 for r in results if r.change_type == ChangeType.UNCHANGED_CONTENT)}")
    #     logger.info(f"⏱️  Processing time: {processing_time_ms:.2f}ms")

    #     return results

    def detect_changes_v2(
        self,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
        run_id: str,
    ) -> List[DetectionResult]:
        """
        Detect content changes using SERVICE-BASED architecture with PURE CHECKSUM COMPARISON.

        This is the refactored version (code2) that uses injected services for better
        testability and separation of concerns. It returns DetectionResult objects with
        ALL required fields populated correctly.

        Algorithm (V8.2):
            1. Extract checksum sets (current vs previous)
            2. Set operations: new, deleted, unchanged
            3. Similarity matching using SimilarityMatcher service
            4. Diff generation using DiffGenerator service (if enabled)
            5. Result building using DetectionResultBuilder service
            6. Return DetectionResult objects with:
               - similarity_method: "hybrid"
               - requires_faq_regeneration: auto-calculated
               - llm_diff: JSON string (for MODIFIED content)

        Args:
            file_name: Name of file being analyzed
            current_data: Current file checksums and content
                Format: {checksum: {'text': '...', 'page_num': 42, ...}, ...}
            previous_data: Previous file checksums and content
                Format: {checksum: {'content_text': '...', 'page_number': 42, ...}, ...}
            run_id: Unique identifier for this detection run

        Returns:
            List of DetectionResult objects with all required fields

        Example:
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> results = detector.detect_changes_v2("file.md", current, previous, "run_1")
            >>> results[0].similarity_method
            'hybrid'
            >>> results[0].requires_faq_regeneration
            True
            >>> results[0].llm_diff
            '{"total_changes": 2}'
        """
        start_time = time.perf_counter()

        logger.info(f"🔍 Detecting changes for: {file_name}")
        logger.info(f"   Detection run: {run_id}")

        # Step 1: Extract checksum sets
        current_checksums = set(current_data.keys())
        previous_checksums = set(previous_data.keys())

        # Step 2: Set operations (checksums only, NO location comparison!)
        new_checksums = current_checksums - previous_checksums
        deleted_checksums = previous_checksums - current_checksums
        unchanged_checksums = current_checksums & previous_checksums

        logger.info(f"📊 Checksum analysis for {file_name}:")
        logger.info(f"   Current:   {len(current_checksums)} checksums")
        logger.info(f"   Previous:  {len(previous_checksums)} checksums")
        logger.info(f"   New:       {len(new_checksums)} checksums")
        logger.info(f"   Deleted:   {len(deleted_checksums)} checksums")
        logger.info(f"   Unchanged: {len(unchanged_checksums)} checksums")

        # Step 3: SIMILARITY MATCHING (N × M where N and M are typically small)
        results = []

        if new_checksums and deleted_checksums:
            logger.info(
                f"🧮 Running similarity matching "
                f"({len(new_checksums)} × {len(deleted_checksums)} = "
                f"{len(new_checksums) * len(deleted_checksums)} comparisons)..."
            )

            # ✅ Use SimilarityMatcher service
            match_results = self.matcher.find_matches(
                new_checksums=new_checksums,
                deleted_checksums=deleted_checksums,
                current_data=current_data,
                previous_data=previous_data,
            )

            # Build deleted_matched for edge case detection
            deleted_matched = {}
            for match in match_results:
                if match.is_match and match.best_match_checksum:
                    if match.best_match_checksum not in deleted_matched:
                        deleted_matched[match.best_match_checksum] = []
                    deleted_matched[match.best_match_checksum].append(
                        (match.new_checksum, match.best_score)
                    )

            # ✅ Use EdgeCaseAnalyzer service
            self.edge_analyzer.detect_content_splits(deleted_matched)

            # Build DetectionResult objects for MODIFIED content
            for match in match_results:
                if match.is_match:
                    # ✅ Generate LLM diff using DiffGenerator service (if enabled)
                    llm_diff = None
                    if self.diff_generator:
                        old_text = previous_data[match.best_match_checksum].get("content_text", "")
                        new_text = current_data[match.new_checksum].get("text", "")
                        if old_text and new_text:
                            try:
                                llm_diff = self.diff_generator.generate_llm_diff_with_checksum(
                                    old_text=old_text,
                                    new_text=new_text,
                                    old_checksum=match.best_match_checksum,
                                    new_checksum=match.new_checksum,
                                )
                            except Exception as e:
                                logger.warning(
                                    f"⚠️  Failed to generate LLM diff for {match.new_checksum[:8]}: {e}"
                                )

                    # ✅ Use DetectionResultBuilder service
                    result = self.result_builder.build_modified(
                        match_result=match,
                        file_name=file_name,
                        current_data=current_data,
                        previous_data=previous_data,
                        llm_diff=llm_diff,
                    )
                    results.append(result)

                    logger.debug(
                        f"   ✓ MODIFIED: {match.best_match_checksum[:8]}→{match.new_checksum[:8]} "
                        f"(similarity: {match.best_score:.3f})"
                    )

        else:
            # No similarity matching needed
            logger.info("⚡ No similarity matching needed (no overlap between new/deleted)")

        # Step 4: Handle NEW content (no match found)
        new_matched_set = {r.new_checksum for r in results if r.new_checksum}

        for new_checksum in new_checksums:
            # Skip if already matched as modified
            if new_checksum in new_matched_set:
                continue

            # ✅ Use DetectionResultBuilder service
            result = self.result_builder.build_new(
                new_checksum=new_checksum,
                file_name=file_name,
                current_data=current_data,
            )
            results.append(result)

        # Step 5: Handle DELETED checksums (not matched to any new checksum)
        deleted_matched_set = {r.old_checksum for r in results if r.old_checksum}

        for deleted_checksum in deleted_checksums:
            if deleted_checksum not in deleted_matched_set:
                # Truly DELETED content (no similar new content found)
                # ✅ Use DetectionResultBuilder service
                result = self.result_builder.build_deleted(
                    deleted_checksum=deleted_checksum,
                    file_name=file_name,
                    previous_data=previous_data,
                )
                results.append(result)

        # Step 6: Handle UNCHANGED content (for completeness in reporting)
        for unchanged_checksum in unchanged_checksums:
            # ✅ Use DetectionResultBuilder service
            result = self.result_builder.build_unchanged(
                unchanged_checksum=unchanged_checksum,
                file_name=file_name,
                current_data=current_data,
            )
            results.append(result)

        end_time = time.perf_counter()
        processing_time_ms = (end_time - start_time) * 1000

        logger.info(f"✅ Changes detected: {len(results)}")
        logger.info(f"   New:      {sum(1 for r in results if r.change_type == ChangeType.NEW_CONTENT)}")
        logger.info(f"   Modified: {sum(1 for r in results if r.change_type == ChangeType.MODIFIED_CONTENT)}")
        logger.info(f"   Deleted:  {sum(1 for r in results if r.change_type == ChangeType.DELETED_CONTENT)}")
        logger.info(f"   Unchanged: {sum(1 for r in results if r.change_type == ChangeType.UNCHANGED_CONTENT)}")
        logger.info(f"⏱️  Processing time: {processing_time_ms:.2f}ms")

        return results

    def get_config(self) -> DetectionConfig:
        """
        Get detector configuration.

        Returns:
            DetectionConfig object containing all configuration settings

        Example:
            >>> config = detector.get_config()
            >>> config.similarity_threshold
            0.8
            >>> config.checksum_algorithm
            'sha256'
            >>> config.to_dict()
            {'checksum_algorithm': 'sha256', 'similarity_threshold': 0.8, ...}
        """
        return self.config

    # =========================================================================
    # Database Integration Methods (Phase 4 Migration)
    # =========================================================================

    def load_previous_checksums(
        self,
        file_name: Optional[str] = None,
        baseline_timestamp: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Load baseline data (previous checksums) from database using AuditRepository.

        This method requires audit_repository to be set during initialization.
        It provides a convenient way to load baseline data directly from the detector.

        Args:
            file_name: Optional file name to filter by
            baseline_timestamp: Optional timestamp to use as baseline cutoff.
                Only returns chunks created before this timestamp (created_at < baseline_timestamp).
                Format: 'YYYY-MM-DD HH:MM:SS'

        Returns:
            Dictionary mapping checksum -> content metadata

        Raises:
            RuntimeError: If audit_repository is not configured
            QueryError: If database query fails

        Example:
            >>> from database.repository import AuditRepository
            >>> from database.backends.factory import BackendFactory
            >>>
            >>> backend = BackendFactory.create_backend()
            >>> repo = AuditRepository(backend)
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> detector.audit_repository = repo  # Inject repository
            >>>
            >>> # Load baseline data created before a specific timestamp
            >>> baseline = detector.load_previous_checksums(
            ...     file_name="policy.pdf",
            ...     baseline_timestamp="2025-11-02 10:24:29"
            ... )
            >>> print(f"Loaded {len(baseline)} checksums")
        """
        if self.audit_repository is None:
            raise RuntimeError(
                "audit_repository not configured. Pass audit_repository during "
                "initialization to enable database operations."
            )

        return self.audit_repository.get_previous_checksums(
            file_name=file_name,
            baseline_timestamp=baseline_timestamp
        )

    def store_detection_results(
        self,
        detection_results: List[DetectionResult],
        detection_run_id: str,
    ) -> Dict[str, Any]:
        """
        Store detection results to database using AuditRepository.

        This method requires audit_repository to be set during initialization.
        It provides a convenient way to persist results directly from the detector.

        Args:
            detection_results: List of DetectionResult objects from detect_changes()
            detection_run_id: Unique identifier for this detection run

        Returns:
            Dictionary with success status and rows inserted

        Raises:
            RuntimeError: If audit_repository is not configured
            QueryError: If database insert fails

        Example:
            >>> from database.repository import AuditRepository
            >>> from database.backends.factory import BackendFactory
            >>>
            >>> backend = BackendFactory.create_backend()
            >>> repo = AuditRepository(backend)
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> detector.audit_repository = repo  # Inject repository
            >>>
            >>> # Detect and store in one flow
            >>> results = detector.detect_changes("file.md", current, previous, "run_1")
            >>> result = detector.store_detection_results(results, "run_1")
            >>> print(f"Stored {result['rows_inserted']} changes")
        """
        if self.audit_repository is None:
            raise RuntimeError(
                "audit_repository not configured. Pass audit_repository during "
                "initialization to enable database operations."
            )

        return self.audit_repository.store_detection_results(
            detection_results=detection_results,
            detection_run_id=detection_run_id
        )

    def detect_and_store(
        self,
        file_name: str,
        current_data: Dict[str, Dict[str, Any]],
        previous_data: Dict[str, Dict[str, Any]],
        detection_run_id: str,
    ) -> Tuple[List[DetectionResult], Dict[str, Any]]:
        """
        Convenience method: Detect changes and store to database in one call.

        This method requires audit_repository to be set during initialization.
        It combines detect_changes() and store_detection_results() for convenience.

        Args:
            file_name: Name of file being analyzed
            current_data: Current file checksums and content
            previous_data: Previous file checksums and content
            detection_run_id: Unique identifier for this detection run

        Returns:
            Tuple of (detection_results, store_result)
                - detection_results: List of DetectionResult objects
                - store_result: Dict with success status and rows inserted

        Raises:
            RuntimeError: If audit_repository is not configured
            QueryError: If database operations fail

        Example:
            >>> from database.repository import AuditRepository
            >>> from database.backends.factory import BackendFactory
            >>>
            >>> backend = BackendFactory.create_backend()
            >>> repo = AuditRepository(backend)
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> detector.audit_repository = repo  # Inject repository
            >>>
            >>> # Detect and store in one call
            >>> results, store_result = detector.detect_and_store(
            ...     "file.md", current, previous, "run_1"
            ... )
            >>> print(f"Detected {len(results)} changes")
            >>> print(f"Stored {store_result['rows_inserted']} records")
        """
        if self.audit_repository is None:
            raise RuntimeError(
                "audit_repository not configured. Pass audit_repository during "
                "initialization to enable database operations."
            )

        # Detect changes
        results = self.detect_changes(file_name, current_data, previous_data, detection_run_id)

        # Store to database
        store_result = self.store_detection_results(results, detection_run_id)

        return results, store_result

    @classmethod
    def for_faq_updates(
        cls,
        audit_repository: Optional["AuditRepository"] = None,
    ) -> "ChecksumChangeDetector":
        """
        Factory method: Create detector optimized for FAQ update detection.

        This uses the recommended configuration for FAQ content:
        - Similarity threshold: 0.8 (80% match for MODIFIED classification)
        - Hybrid similarity: Jaccard=0.20, Difflib=0.50, BM25=0.30
        - LLM diffs: Enabled (useful for FAQ regeneration)
        - Context lines: 3 (standard diff context)

        Args:
            audit_repository: Optional AuditRepository for database operations.
                If provided, enables load_previous_checksums() and
                store_detection_results() methods on the detector.

        Returns:
            ChecksumChangeDetector configured for FAQ updates

        Example:
            >>> # Without repository (pure detection)
            >>> detector = ChecksumChangeDetector.for_faq_updates()
            >>> results = detector.detect_changes("faq.md", current, previous, "run_1")
            >>>
            >>> # With repository (integrated workflow)
            >>> from database.repository import AuditRepository
            >>> from database.backends.factory import BackendFactory
            >>> backend = BackendFactory.create_backend()
            >>> repo = AuditRepository(backend)
            >>> detector = ChecksumChangeDetector.for_faq_updates(audit_repository=repo)
            >>>
            >>> # Now you can use convenience methods
            >>> baseline = detector.load_previous_checksums("faq.md")
            >>> results = detector.detect_changes("faq.md", current, baseline, "run_1")
            >>> detector.store_detection_results(results, "run_1")
        """
        config = DetectionConfig(
            checksum_algorithm=CHECKSUM_ALGORITHM,
            similarity_threshold=DEFAULT_SIMILARITY_THRESHOLD,
            compute_llm_diffs=True,  # Enable LLM diffs for FAQ regeneration
            diff_context_lines=DEFAULT_DIFF_CONTEXT_LINES,
        )

        # Use factory method for modification detection
        similarity_calculator = HybridSimilarityCalculator.for_modification_detection()

        return cls(
            similarity_calculator=similarity_calculator,
            config=config,
            audit_repository=audit_repository,
        )

    @classmethod
    def for_policy_tracking(
        cls,
        audit_repository: Optional["AuditRepository"] = None,
    ) -> "ChecksumChangeDetector":
        """
        Factory method: Create detector optimized for policy change tracking.

        This uses stricter configuration for policy documents:
        - Similarity threshold: 0.9 (90% match required for MODIFIED)
        - LLM diffs: Enabled (critical for compliance review)
        - Context lines: 5 (more context for legal review)

        Args:
            audit_repository: Optional AuditRepository for database operations.
                If provided, enables database integration methods.

        Returns:
            ChecksumChangeDetector configured for policy tracking

        Example:
            >>> # Without repository
            >>> detector = ChecksumChangeDetector.for_policy_tracking()
            >>> results = detector.detect_changes("policy.md", current, previous, "run_1")
            >>>
            >>> # With repository
            >>> from database.repository import AuditRepository
            >>> from database.backends.factory import BackendFactory
            >>> backend = BackendFactory.create_backend()
            >>> repo = AuditRepository(backend)
            >>> detector = ChecksumChangeDetector.for_policy_tracking(audit_repository=repo)
        """
        config = DetectionConfig(
            checksum_algorithm=CHECKSUM_ALGORITHM,
            similarity_threshold=0.9,  # Stricter threshold for policy changes
            compute_llm_diffs=True,
            diff_context_lines=5,  # More context for compliance review
        )

        similarity_calculator = HybridSimilarityCalculator.for_modification_detection()

        return cls(
            similarity_calculator=similarity_calculator,
            config=config,
            audit_repository=audit_repository,
        )


# Convenience exports
__all__ = [
    "ChecksumChangeDetector",
]
