"""
Detection Module - Content Change Detection (Interface-Based)

This module provides checksum-based change detection with similarity matching.
It follows the same interface-based design pattern as the chunking and similarity modules.

Architecture:
- Core abstractions: Re-exported from core.interfaces.detection and core.models.detection
- Implementations: ChecksumChangeDetector, MarkdownFileLoader, CSVFileLoader, DictListFileLoader
- Database operations: Use AuditRepository from database.repository

Design Pattern (Aligned with Chunking/Similarity modules):
    1. Interfaces defined in core.interfaces.detection (IChangeDetector, IFileLoader)
    2. Models defined in core.models.detection (DetectionResult, DetectionConfig, ChangeType)
    3. Implementations in detection/ module
    4. Re-export core abstractions for convenience
    5. Database operations handled by repositories (clean separation)

Example Usage:
    >>> from detection import ChecksumChangeDetector, MarkdownFileLoader
    >>> from detection import DetectionResult, ChangeType
    >>> from database.repository import AuditRepository
    >>> from database.backends import get_backend
    >>>
    >>> # Setup repository
    >>> audit_repo = AuditRepository(get_backend())
    >>>
    >>> # Load data
    >>> loader = MarkdownFileLoader()
    >>> current = loader.load_from_markdown("./data/current/")
    >>>
    >>> # Load previous checksums from database
    >>> previous = audit_repo.get_previous_checksums("faq.md")
    >>>
    >>> # Detect changes
    >>> detector = ChecksumChangeDetector.for_faq_updates(audit_repository=audit_repo)
    >>> results = detector.detect_changes("faq.md", current, previous, "run_1")
    >>>
    >>> # Results are DetectionResult domain models
    >>> for result in results:
    ...     if result.change_type == ChangeType.MODIFIED_CONTENT:
    ...         print(f"Modified: {result.similarity_score}")
    >>>
    >>> # Store to database using repository
    >>> audit_repo.store_detection_results(results, run_id="run_1")

Migration from Legacy Code:
    If you're upgrading from the old ContentChangeDetector, see MIGRATION_GUIDE.md
    for a comprehensive migration guide.
"""

# Re-export core abstractions for convenience (following chunking/similarity pattern)
from core.interfaces.detection import IChangeDetector, IFileLoader
from core.models.detection import ChangeType, DetectionConfig, DetectionResult

# Export interface-based implementations
from detection.checksum_detector import ChecksumChangeDetector

# Re-export file loaders from data_ingestion for backward compatibility
from data_ingestion.loaders import CSVFileLoader, MarkdownFileLoader, DictListFileLoader

__all__ = [
    # Core abstractions (re-exported from core for convenience)
    "IChangeDetector",
    "IFileLoader",
    "DetectionResult",
    "DetectionConfig",
    "ChangeType",
    # Interface-based implementations
    "ChecksumChangeDetector",  # IChangeDetector implementation (returns DetectionResult)
    # File loaders (re-exported from data_ingestion.loaders for backward compatibility)
    "MarkdownFileLoader",  # IFileLoader implementation for markdown files
    "CSVFileLoader",  # IFileLoader implementation for CSV files
    "DictListFileLoader",  # IFileLoader implementation for in-memory data
]
