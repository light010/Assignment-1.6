# Utils Module

Utility functions for logging, metrics, and validation.

## Components

### Logging ([logging_utils.py](logging_utils.py))

Loguru-based logging with file rotation and context support.

```python
from granular_impact.utils import setup_logging, get_logger, LogContext
from pathlib import Path

# Setup logging
setup_logging(
    log_level='INFO',
    log_to_file=True,
    log_file_path=Path('/Volumes/.../logs/impact.log'),
    rotation='100 MB',
    retention='30 days'
)

# Get logger
logger = get_logger(__name__)

logger.info('Starting analysis')
logger.warning('High impact detected')
logger.error('Analysis failed', exc_info=True)
```

**Context Logging**:
```python
# Add context to all logs within the block
with LogContext(faq_id='faq_001', operation='impact_analysis'):
    logger.info('Analyzing FAQ')  # Automatically includes context
```

### Metrics ([metrics.py](metrics.py))

Performance tracking and monitoring.

```python
from granular_impact.utils import MetricsCollector

metrics = MetricsCollector()

# Track single operation
with metrics.track_operation('similarity_computation', algorithm='hybrid'):
    result = calc.compute_similarity(text1, text2)

# Get summary
summary = metrics.get_summary()
print(f'Total Operations: {summary["total_operations"]}')
print(f'Success Rate: {summary["success_rate"]:.1%}')
print(f'Average Duration: {summary["average_duration_ms"]:.2f}ms')
print(f'Memory Delta: {summary["total_memory_delta_mb"]:.2f}MB')
```

**Operations Breakdown**:
```python
# Group metrics by operation type
for op_name, stats in summary['operations_by_name'].items():
    print(f'{op_name}:')
    print(f'  Count: {stats["count"]}')
    print(f'  Avg Time: {stats["average_duration_ms"]:.2f}ms')
    print(f'  Success: {stats["successful"]}, Failed: {stats["failed"]}')
```

### Validators ([validators.py](validators.py))

Data validation utilities with informative error messages.

```python
from granular_impact.utils import (
    validate_text_content,
    validate_score,
    validate_checksum,
    validate_weights,
    validate_content_id,
    validate_faq_id
)

# Validate text
try:
    validate_text_content(text, min_length=10, max_length=10000)
except ValueError as e:
    logger.error(f'Invalid text: {e}')

# Validate score in range
validate_score(0.85, min_val=0.0, max_val=1.0)

# Validate checksum format
validate_checksum('abc123...', algorithm='sha256')

# Validate weights sum to 1.0
weights = {'similarity': 0.4, 'diff': 0.3, 'semantic': 0.3}
validate_weights(weights, tolerance=0.01)

# Validate IDs
validate_content_id('content_123')
validate_faq_id('faq_001')
```

## Best Practices

### 1. Always Use Logging

```python
logger = get_logger(__name__)

try:
    result = analyzer.analyze_impact(...)
    logger.info(f'Analysis complete: {result.impact_decision}',
                extra={'faq_id': faq_id, 'score': result.overall_impact_score})
except Exception as e:
    logger.error(f'Analysis failed: {e}', exc_info=True)
    raise
```

### 2. Track Performance

```python
metrics = MetricsCollector()

# Track batch operations
with metrics.track_operation('batch_analysis', batch_size=len(items)):
    for item in items:
        analyze(item)

# Monitor performance
summary = metrics.get_summary()
if summary['average_duration_ms'] > 100:
    logger.warning('Performance degraded', extra=summary)
```

### 3. Validate All Inputs

```python
def process_faq(faq_id: str, faq_text: str, score: float):
    # Validate all inputs
    validate_faq_id(faq_id)
    validate_text_content(faq_text, min_length=10, max_length=10000)
    validate_score(score, min_val=0.0, max_val=1.0)

    # Process with confidence
    # ...
```

## Example: Complete Monitoring

```python
from granular_impact.utils import setup_logging, get_logger, MetricsCollector, LogContext

# Setup
setup_logging(log_level='INFO', log_to_file=True)
logger = get_logger(__name__)
metrics = MetricsCollector()

# Execute with monitoring
with LogContext(job_id='job_123'):
    logger.info('Starting FAQ impact analysis')

    with metrics.track_operation('full_pipeline'):
        try:
            results = run_pipeline()
            logger.info(f'Completed: {len(results)} FAQs analyzed')
        except Exception as e:
            logger.error('Pipeline failed', exc_info=True)
            raise

    # Report metrics
    summary = metrics.get_summary()
    logger.info('Performance summary', extra=summary)
```
