"""
Performance metrics and monitoring utilities.

Provides utilities for tracking:
- Execution time
- Memory usage
- Operation counts
- Success/failure rates
"""

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import psutil


@dataclass
class PerformanceMetrics:
    """Container for performance metrics."""

    operation_name: str
    start_time: float
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None
    memory_start_mb: Optional[float] = None
    memory_end_mb: Optional[float] = None
    memory_delta_mb: Optional[float] = None
    success: bool = True
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def finalize(self, end_time: float, memory_end_mb: float, success: bool = True, error: str = None):
        """
        Finalize metrics.

        Args:
            end_time: End timestamp
            memory_end_mb: Final memory usage in MB
            success: Whether operation succeeded
            error: Error message if failed
        """
        self.end_time = end_time
        self.duration_ms = (end_time - self.start_time) * 1000
        self.memory_end_mb = memory_end_mb
        if self.memory_start_mb is not None:
            self.memory_delta_mb = memory_end_mb - self.memory_start_mb
        self.success = success
        self.error_message = error

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "operation_name": self.operation_name,
            "duration_ms": self.duration_ms,
            "memory_delta_mb": self.memory_delta_mb,
            "success": self.success,
            "error_message": self.error_message,
            "metadata": self.metadata,
        }


class MetricsCollector:
    """Collects and aggregates performance metrics."""

    def __init__(self):
        """Initialize metrics collector."""
        self.metrics: List[PerformanceMetrics] = []
        self._current_metric: Optional[PerformanceMetrics] = None

    def start_operation(self, operation_name: str, **metadata) -> PerformanceMetrics:
        """
        Start tracking an operation.

        Args:
            operation_name: Name of the operation
            **metadata: Additional metadata

        Returns:
            PerformanceMetrics instance
        """
        metric = PerformanceMetrics(
            operation_name=operation_name,
            start_time=time.perf_counter(),
            memory_start_mb=self._get_memory_usage_mb(),
            metadata=metadata,
        )
        self.metrics.append(metric)
        return metric

    def end_operation(
        self, metric: PerformanceMetrics, success: bool = True, error: str = None
    ):
        """
        End tracking an operation.

        Args:
            metric: PerformanceMetrics instance
            success: Whether operation succeeded
            error: Error message if failed
        """
        metric.finalize(
            end_time=time.perf_counter(),
            memory_end_mb=self._get_memory_usage_mb(),
            success=success,
            error=error,
        )

    @contextmanager
    def track_operation(self, operation_name: str, **metadata):
        """
        Context manager for tracking an operation.

        Args:
            operation_name: Name of operation
            **metadata: Additional metadata

        Yields:
            PerformanceMetrics instance
        """
        metric = self.start_operation(operation_name, **metadata)
        error = None
        success = True

        try:
            yield metric
        except Exception as e:
            success = False
            error = str(e)
            raise
        finally:
            self.end_operation(metric, success=success, error=error)

    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary of all metrics.

        Returns:
            Summary dictionary
        """
        if not self.metrics:
            return {"total_operations": 0}

        successful = [m for m in self.metrics if m.success]
        failed = [m for m in self.metrics if not m.success]

        total_duration = sum(
            m.duration_ms for m in self.metrics if m.duration_ms is not None
        )
        total_memory = sum(
            m.memory_delta_mb for m in self.metrics if m.memory_delta_mb is not None
        )

        return {
            "total_operations": len(self.metrics),
            "successful_operations": len(successful),
            "failed_operations": len(failed),
            "success_rate": len(successful) / len(self.metrics) if self.metrics else 0,
            "total_duration_ms": total_duration,
            "average_duration_ms": total_duration / len(self.metrics) if self.metrics else 0,
            "total_memory_delta_mb": total_memory,
            "operations_by_name": self._group_by_operation(),
        }

    def _group_by_operation(self) -> Dict[str, Dict[str, Any]]:
        """Group metrics by operation name."""
        grouped = {}
        for metric in self.metrics:
            name = metric.operation_name
            if name not in grouped:
                grouped[name] = {
                    "count": 0,
                    "total_duration_ms": 0,
                    "successful": 0,
                    "failed": 0,
                }

            grouped[name]["count"] += 1
            if metric.duration_ms:
                grouped[name]["total_duration_ms"] += metric.duration_ms
            if metric.success:
                grouped[name]["successful"] += 1
            else:
                grouped[name]["failed"] += 1

        # Calculate averages
        for name, stats in grouped.items():
            if stats["count"] > 0:
                stats["average_duration_ms"] = stats["total_duration_ms"] / stats["count"]

        return grouped

    def _get_memory_usage_mb(self) -> float:
        """Get current memory usage in MB."""
        process = psutil.Process()
        return process.memory_info().rss / (1024 * 1024)

    def clear(self):
        """Clear all collected metrics."""
        self.metrics.clear()
