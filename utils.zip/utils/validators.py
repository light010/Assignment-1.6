"""
Data validation utilities.

Provides validators for:
- Text content
- Configuration values
- Database records
- File formats
"""

import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ValidationError, validator


def validate_text_content(text: str, min_length: int = 1, max_length: Optional[int] = None) -> bool:
    """
    Validate text content.

    Args:
        text: Text to validate
        min_length: Minimum length
        max_length: Maximum length (optional)

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(text, str):
        raise ValueError(f"Text must be string, got {type(text)}")

    if len(text) < min_length:
        raise ValueError(f"Text length {len(text)} below minimum {min_length}")

    if max_length and len(text) > max_length:
        raise ValueError(f"Text length {len(text)} exceeds maximum {max_length}")

    return True


def validate_score(score: float, min_val: float = 0.0, max_val: float = 1.0) -> bool:
    """
    Validate a score is in valid range.

    Args:
        score: Score value
        min_val: Minimum value
        max_val: Maximum value

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(score, (int, float)):
        raise ValueError(f"Score must be numeric, got {type(score)}")

    if not (min_val <= score <= max_val):
        raise ValueError(f"Score {score} not in range [{min_val}, {max_val}]")

    return True


def validate_checksum(checksum: str, algorithm: str = "sha256") -> bool:
    """
    Validate checksum format.

    Args:
        checksum: Checksum string
        algorithm: Algorithm used (sha256, md5, sha1)

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    expected_lengths = {
        "md5": 32,
        "sha1": 40,
        "sha256": 64,
        "sha512": 128,
    }

    if algorithm not in expected_lengths:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    if not isinstance(checksum, str):
        raise ValueError(f"Checksum must be string, got {type(checksum)}")

    if not re.match(r"^[a-f0-9]+$", checksum.lower()):
        raise ValueError("Checksum must contain only hexadecimal characters")

    expected_len = expected_lengths[algorithm]
    if len(checksum) != expected_len:
        raise ValueError(
            f"Checksum length {len(checksum)} doesn't match expected {expected_len} for {algorithm}"
        )

    return True


def validate_content_id(content_id: str) -> bool:
    """
    Validate content ID format.

    Args:
        content_id: Content identifier

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(content_id, str):
        raise ValueError(f"Content ID must be string, got {type(content_id)}")

    if len(content_id.strip()) == 0:
        raise ValueError("Content ID cannot be empty")

    return True


def validate_faq_id(faq_id: str) -> bool:
    """
    Validate FAQ ID format.

    Args:
        faq_id: FAQ identifier

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(faq_id, str):
        raise ValueError(f"FAQ ID must be string, got {type(faq_id)}")

    if len(faq_id.strip()) == 0:
        raise ValueError("FAQ ID cannot be empty")

    return True


def validate_weights(weights: Dict[str, float], tolerance: float = 0.01) -> bool:
    """
    Validate that weights sum to 1.0.

    Args:
        weights: Dictionary of weights
        tolerance: Tolerance for floating point comparison

    Returns:
        True if valid

    Raises:
        ValueError: If invalid
    """
    if not isinstance(weights, dict):
        raise ValueError(f"Weights must be dict, got {type(weights)}")

    if not weights:
        raise ValueError("Weights dictionary cannot be empty")

    # Check all values are numeric
    for key, val in weights.items():
        if not isinstance(val, (int, float)):
            raise ValueError(f"Weight for '{key}' must be numeric, got {type(val)}")
        if val < 0:
            raise ValueError(f"Weight for '{key}' cannot be negative: {val}")

    # Check sum
    total = sum(weights.values())
    if not (1.0 - tolerance <= total <= 1.0 + tolerance):
        raise ValueError(
            f"Weights must sum to 1.0 (±{tolerance}), got {total}. Weights: {weights}"
        )

    return True


class DataValidator:
    """Generic data validator using pydantic."""

    @staticmethod
    def validate(data: Dict[str, Any], schema: BaseModel) -> bool:
        """
        Validate data against a pydantic schema.

        Args:
            data: Data to validate
            schema: Pydantic model class

        Returns:
            True if valid

        Raises:
            ValidationError: If validation fails
        """
        try:
            schema(**data)
            return True
        except ValidationError as e:
            raise ValueError(f"Validation failed: {e}")
