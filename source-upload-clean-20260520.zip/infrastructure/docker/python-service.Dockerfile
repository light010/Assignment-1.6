FROM python:3.12-slim

WORKDIR /workspace

ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV PYTHONPATH=/workspace/packages/python/ditagen_common:/workspace

RUN apt-get update \
    && apt-get install -y --no-install-recommends pandoc \
    && rm -rf /var/lib/apt/lists/*

COPY pyproject.toml /workspace/pyproject.toml
COPY packages/python/ditagen_common /workspace/packages/python/ditagen_common
COPY services /workspace/services

RUN pip install --no-cache-dir \
    -e /workspace/packages/python/ditagen_common \
    fastapi \
    "uvicorn[standard]" \
    python-multipart \
    pydantic \
    httpx \
    jsonschema \
    mdformat \
    mdformat-gfm \
    python-docx \
    pymupdf

ARG SERVICE_APP_DIR
ENV SERVICE_APP_DIR=${SERVICE_APP_DIR}
ENV PORT=8000

CMD ["sh", "-c", "uvicorn main:app --app-dir ${SERVICE_APP_DIR} --host 0.0.0.0 --port ${PORT}"]
