"""create service-owned JSONB compatibility tables

Revision ID: 0001_service_owned_state
Revises:
Create Date: 2026-05-11
"""

from __future__ import annotations

from alembic import op
from sqlalchemy import Column, DateTime, Text, func
from sqlalchemy.dialects.postgresql import JSONB

revision = "0001_service_owned_state"
down_revision = None
branch_labels = None
depends_on = None


TABLES: dict[str, list[str]] = {
    "api_gateway": ["users", "sessions", "revoked_tokens"],
    "business_unit_service": [
        "tenants",
        "organizations",
        "business_units",
        "business_unit_memberships",
        "business_unit_favorites",
        "projects",
        "project_memberships",
    ],
    "upload_service": ["documents", "jobs", "upload_sessions", "artifact_registry", "exports"],
    "extraction_service": ["extractions"],
    "review_service": ["topics"],
    "audit_service": ["audit_events"],
}


def upgrade() -> None:
    for schema, tables in TABLES.items():
        op.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
        for table in tables:
            op.create_table(
                table,
                Column("record_id", Text, primary_key=True),
                Column("payload", JSONB, nullable=False),
                Column("updated_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
                schema=schema,
                if_not_exists=True,
            )


def downgrade() -> None:
    for schema, tables in reversed(TABLES.items()):
        for table in reversed(tables):
            op.drop_table(table, schema=schema, if_exists=True)
        op.execute(f'DROP SCHEMA IF EXISTS "{schema}"')
