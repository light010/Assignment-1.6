"""Typed `Block` model derived from `contracts/artifacts/source-block.schema.json`.

Phase 2 of `plans/logical-whistling-widget.md` replaces the `dict[str, Any]`
block shape produced by `extraction-service.app.extractors._source_block`
with this Pydantic model. The contract JSON schema is the source of truth;
this module mirrors it.

Phase 2 fields beyond the original schema:
- `char_start`, `char_end` — character offsets within the source paragraph,
  enabling precise highlight-mapping in the workbench.
- `parent_block_id` — for nested relationships (table_row → table).
- `lineage` — the source block IDs this block was derived from. Empty for
  original extraction; populated by Phase 6's edit-op replay (e.g. a Merge
  produces a block whose `lineage` is the merged inputs' ids).

Phase 2b reconciliation: the original producer emitted four duplicate
aliases (`id`/`type`/`page`/top-level `bbox`) plus ten load-bearing fields
(`font`, `order_in_page`, `is_likely_heading`, `confidence_signals`,
`warnings`, `table_id`, `row_index`, `cells`, `numbering`,
`caption_candidate`) that were not yet declared in the schema. Phase 2b
drops the duplicates (no consumer reads them — frontend uses canonical
`block_id`/`block_type`/`source_location.page` plus a defensive
`source_location.bbox || bbox` fallback that survives) and adds the
load-bearing fields to both the schema and this model in lockstep.
Strictness is now `extra="forbid"` — any unmapped field is a bug.
"""

from __future__ import annotations

from typing import Annotated, Literal, TypedDict, cast

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ditagen_common.locator import validate_locator

# Block types — mirrors contracts/artifacts/source-block.schema.json:34-55.
BlockType = Literal[
    "paragraph",
    "possible_heading",
    "heading",
    "running_header",
    "running_footer",
    "ordered_list",
    "unordered_list",
    "procedure_step",
    "table",
    "table_row",
    "figure",
    "caption",
    "note",
    "warning",
    "code_block",
    "quote",
    "glossary_entry",
    "unknown",
]

InlineMark = Literal[
    "bold",
    "italic",
    "underline",
    "monospace",
    "superscript",
    "subscript",
    "link",
    "comment",
]

SemanticHint = Literal[
    "uicontrol",
    "menucascade",
    "codeph",
    "cmdname",
    "filepath",
    "apiname",
    "term",
    "keyword",
    "ph",
]

CandidateRole = Literal[
    "running_header",
    "running_footer",
    "watermark",
    "repeated_table_header",
]

ReviewSeverity = Literal["info", "warning", "error"]

# Canonical review-flag codes — mirrors source-block.schema.json
# `$defs.reviewFlag.code.enum`. Phase 5 introduced these. Producers must
# use one of these exact strings; the workbench triage queue keys off them.
ReviewFlagCode = Literal[
    "LOW_BLOCK_TYPE_CONFIDENCE",
    "ORPHAN_TABLE_ROW",
    "MIXED_HEADING_STYLE",
    "SUSPECTED_HEADING_FRAGMENT",
    "HEADING_BY_FORMATTING",
    "HEADING_IN_CELL",
    "SYNTHETIC_ROOT_HEADING",
    "ASSET_REF_UNRESOLVED",
    "NESTED_TABLE",
    "DEEP_NESTING_UNSUPPORTED",
    "FLOATING_TABLE",
    "POSSIBLY_CALLOUT",
    "SUBDOC_UNSUPPORTED",
    "MATH_CONTENT",
    "HAS_INSERTIONS",
    "HAS_DELETIONS",
    "SMARTART_DROPPED",
    "HIDDEN_TEXT_DROPPED",
    "MULTI_COLUMN",
    "NO_HEADINGS_FOUND",
]

class ReviewFlagCatalogEntry(TypedDict):
    label: str
    severity: ReviewSeverity
    explanation: str
    action: str


REVIEW_FLAG_CATALOG: dict[ReviewFlagCode, ReviewFlagCatalogEntry] = {
    "LOW_BLOCK_TYPE_CONFIDENCE": {
        "label": "Low block type confidence",
        "severity": "warning",
        "explanation": "The classifier is not confident that the assigned source block type is correct.",
        "action": "Compare the row with the source and confirm the block type before approving.",
    },
    "ORPHAN_TABLE_ROW": {
        "label": "Orphan table row",
        "severity": "warning",
        "explanation": "A table row appears without a first-row sibling in the same table, which can mean rows were dropped.",
        "action": "Inspect the source table and verify that all expected rows are represented.",
    },
    "MIXED_HEADING_STYLE": {
        "label": "Mixed heading style",
        "severity": "info",
        "explanation": "The paragraph style is used for both headings and non-heading content, so heading intent is ambiguous.",
        "action": "Check the source style and surrounding structure before relying on this heading.",
    },
    "SUSPECTED_HEADING_FRAGMENT": {
        "label": "Suspected heading fragment",
        "severity": "info",
        "explanation": "A heading ends with sentence punctuation, which can indicate a wrapped paragraph was promoted.",
        "action": "Confirm whether the row is truly a heading or should remain body content.",
    },
    "HEADING_BY_FORMATTING": {
        "label": "Heading inferred by formatting",
        "severity": "info",
        "explanation": "The heading was inferred from formatting or numbering rather than an explicit heading style.",
        "action": "Verify the visual source heading before accepting the inferred hierarchy.",
    },
    "HEADING_IN_CELL": {
        "label": "Heading inside table cell",
        "severity": "warning",
        "explanation": "A paragraph inside a table cell was promoted to a heading, which is usually a false positive.",
        "action": "Check the table cell and demote the block if it is regular cell content.",
    },
    "SYNTHETIC_ROOT_HEADING": {
        "label": "Synthetic root heading",
        "severity": "warning",
        "explanation": "The structure tree created a root heading because body content had no real top-level heading.",
        "action": "Review the document opening and confirm the synthetic container is acceptable.",
    },
    "ASSET_REF_UNRESOLVED": {
        "label": "Unresolved asset reference",
        "severity": "error",
        "explanation": "A source block references an extracted asset that is missing from the asset manifest.",
        "action": "Open the source and asset list, then re-extract or repair the missing asset reference.",
    },
    "NESTED_TABLE": {
        "label": "Nested table",
        "severity": "info",
        "explanation": "A table row contains one or more nested tables emitted as separate source blocks.",
        "action": "Verify the parent row and nested rows preserve the source table relationship.",
    },
    "DEEP_NESTING_UNSUPPORTED": {
        "label": "Deep nested table unsupported",
        "severity": "error",
        "explanation": "A nested table contains another nested table beyond the extractor's supported depth.",
        "action": "Inspect the source table and manually account for content below the supported nesting level.",
    },
    "FLOATING_TABLE": {
        "label": "Floating table",
        "severity": "warning",
        "explanation": "A floating or text-wrapped table may not appear in the same reading order as the source.",
        "action": "Compare the table position in the source with the extracted document order.",
    },
    "POSSIBLY_CALLOUT": {
        "label": "Possible callout",
        "severity": "info",
        "explanation": "A short formatted paragraph may be a callout or note instead of normal body text.",
        "action": "Check the source styling and decide whether the block needs note/callout treatment.",
    },
    "SUBDOC_UNSUPPORTED": {
        "label": "Sub-document unsupported",
        "severity": "error",
        "explanation": "The DOCX references a linked sub-document that this extractor does not follow.",
        "action": "Open the source package and process the linked sub-document separately if needed.",
    },
    "MATH_CONTENT": {
        "label": "Math content",
        "severity": "warning",
        "explanation": "The paragraph contains OOXML math and the extracted text may only be a placeholder.",
        "action": "Compare the equation in the source and capture or repair the math content.",
    },
    "HAS_INSERTIONS": {
        "label": "Tracked insertions present",
        "severity": "warning",
        "explanation": "Tracked-change insertions are present in the source paragraph.",
        "action": "Review the source changes and confirm whether inserted text should be kept.",
    },
    "HAS_DELETIONS": {
        "label": "Tracked deletions present",
        "severity": "warning",
        "explanation": "Tracked-change deletions are present; deleted text is not reflected as normal extracted content.",
        "action": "Review the source changes and confirm the surviving text is correct.",
    },
    "SMARTART_DROPPED": {
        "label": "SmartArt dropped",
        "severity": "error",
        "explanation": "A SmartArt diagram was detected but not extracted.",
        "action": "Inspect the source diagram and capture the missing content manually or re-extract with support.",
    },
    "HIDDEN_TEXT_DROPPED": {
        "label": "Hidden text dropped",
        "severity": "warning",
        "explanation": "Hidden text runs were filtered out of the extracted paragraph.",
        "action": "Open the source paragraph and confirm the hidden content was intentionally excluded.",
    },
    "MULTI_COLUMN": {
        "label": "Multi-column layout",
        "severity": "warning",
        "explanation": "The section uses multi-column layout that may be flattened in a different reading order.",
        "action": "Compare extracted order with the source columns before approving the section.",
    },
    "NO_HEADINGS_FOUND": {
        "label": "No headings found",
        "severity": "warning",
        "explanation": "No high-confidence heading styles were found in the document body.",
        "action": "Review the structure tree and add or confirm section boundaries before downstream use.",
    },
}


def review_flag_payload(
    code: ReviewFlagCode,
    *,
    message: str | None = None,
    extra_context: str | None = None,
) -> dict[str, str]:
    catalog = REVIEW_FLAG_CATALOG[code]
    base_message = message or catalog["explanation"]
    if extra_context:
        base_message = f"{base_message} {extra_context}"
    return {
        "code": cast(str, code),
        "severity": catalog["severity"],
        "message": base_message,
        "action": catalog["action"],
    }


UnitInterval = Annotated[float, Field(ge=0.0, le=1.0)]


class _StrictBase(BaseModel):
    """Base for nested types that the schema marks `additionalProperties: false`."""

    model_config = ConfigDict(extra="forbid")


FontWeight = Literal["regular", "bold"]


class SourceLocation(_StrictBase):
    page: int | None = Field(default=None, ge=1)
    slide: int | None = Field(default=None, ge=1)
    section: str | None = None
    bbox: list[float] | None = Field(default=None, min_length=4, max_length=4)
    pages: list[int] = Field(default_factory=list)

    @field_validator("section")
    @classmethod
    def validate_section_locator(cls, value: str | None) -> str | None:
        if not validate_locator(value):
            raise ValueError(f"Invalid source locator: {value!r}")
        return value


class StyleSummary(BaseModel):
    """The schema marks `additionalProperties: true` here, so we allow extras."""

    model_config = ConfigDict(extra="allow")

    dominant_font_size_pt: float | None = Field(default=None, ge=0.0)
    font_size_rank: int | None = Field(default=None, ge=1)
    bold_ratio: UnitInterval | None = None
    italic_ratio: UnitInterval | None = None
    monospace_ratio: UnitInterval | None = None
    space_before_px: float | None = None
    space_after_px: float | None = None
    indent_left_px: float | None = None
    numbering: str | None = None
    source_style_name: str | None = None


class Repetition(_StrictBase):
    appears_on_pages: list[int] = Field(default_factory=list)
    candidate_role: CandidateRole | None = None
    confidence: UnitInterval | None = None


class InlineRun(_StrictBase):
    start: int = Field(ge=0)
    end: int = Field(ge=0)
    text: str
    marks: list[InlineMark] = Field(default_factory=list)
    source_style: dict | None = None
    semantic_hint: SemanticHint | None = None
    semantic_confidence: UnitInterval | None = None
    href: str | None = None
    comment_id: str | None = None


class ReviewFlag(_StrictBase):
    code: ReviewFlagCode
    severity: ReviewSeverity
    message: str = Field(min_length=1)
    action: str = Field(min_length=1)


class Confidence(_StrictBase):
    extraction: UnitInterval
    block_type: UnitInterval | None = None
    heading: UnitInterval | None = None
    semantic_inline: UnitInterval | None = None


class Font(_StrictBase):
    size: float = Field(ge=0.0)
    family: str | None = None
    weight: FontWeight = "regular"


class ConfidenceSignals(BaseModel):
    """Schema marks `additionalProperties: true` so the producer can keep
    adding signals without churning the contract."""

    model_config = ConfigDict(extra="allow")

    style: str | None = None
    font_size: float | None = None


class Numbering(_StrictBase):
    num_id: str | None = None
    level: int = Field(ge=0)
    format: str | None = None
    level_text: str | None = None
    label: str | None = None


class TableCell(_StrictBase):
    text: str
    colspan: int = Field(ge=1)
    # rowspan=0 means "continuation row from a vertically-merged cell"
    # (DOCX vMerge=continue), per `_docx_cell_shape` in extractors.py.
    rowspan: int = Field(ge=0)


class Block(_StrictBase):
    """A single source block produced by the extraction pipeline.

    Required fields mirror `source-block.schema.json` `required` list.
    Optional fields default to schema-friendly empty values so callers
    don't need to pass them explicitly. Strict (`extra="forbid"`): every
    field the producer emits must be declared here and in the schema.
    """

    block_id: str = Field(min_length=1)
    document_id: str = Field(min_length=1)
    block_type: BlockType
    text: str
    source_location: SourceLocation
    heading_path_ids: list[str] = Field(default_factory=list)
    inline_runs: list[InlineRun] = Field(default_factory=list)
    confidence: Confidence

    source_line_ids: list[str] = Field(default_factory=list)
    inferred_level: int | None = Field(default=None, ge=1, le=6)
    style_summary: StyleSummary | None = None
    repetition: Repetition | None = None
    asset_refs: list[str] = Field(default_factory=list)
    language: str | None = None
    content_hash: str | None = None
    review_flags: list[ReviewFlag] = Field(default_factory=list)
    warnings: list[dict] = Field(default_factory=list)

    # Display + classification fields formerly carried as untyped extras.
    font: Font | None = None
    order_in_page: int | None = Field(default=None, ge=1)
    is_likely_heading: bool = False
    confidence_signals: ConfidenceSignals | None = None

    # table_row-specific fields (None for non-table blocks).
    table_id: str | None = Field(default=None, min_length=1)
    row_index: int | None = Field(default=None, ge=1)
    cells: list[TableCell] = Field(default_factory=list)

    # DOCX-paragraph-specific fields.
    numbering: Numbering | None = None
    caption_candidate: str | None = None

    # Phase 2 additions for traceability (also added to the JSON schema).
    char_start: int | None = Field(default=None, ge=0)
    char_end: int | None = Field(default=None, ge=0)
    parent_block_id: str | None = None
    lineage: list[str] = Field(default_factory=list)
