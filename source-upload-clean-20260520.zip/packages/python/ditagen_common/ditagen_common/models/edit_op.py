"""Typed `EditOperation` discriminated-union model.

Phase 3 of `plans/logical-whistling-widget.md` introduced the data
spine for traceability after edits. Phase 6 adds `RawXmlOverride` so
ADR-006's existing `PATCH /v1/topics/{topic_id}` (body: `{xml: str}`)
keeps working — but routed through the same typed op surface as the
five structural ops, persisted to the same audit log, and replayed
against the same snapshot. The lossy nature of arbitrary XML is
flagged at the variant level (`is_lossy: bool = True`) so callers
that surface op-history can warn the reviewer.

Each operation is a tagged union member (Merge / Split / Move /
Retype / Rename / RawXmlOverride), and the `EditOperation` alias is
the discriminated union over all six. The discriminator field is
`op_type` — Pydantic routes validation to the matching variant.
Replay is exhaustive over the union: any new op type must be added to
the union and to the dispatch in
`ditagen_common.edits.replay.replay()`. The `assert_never` at the end
of the dispatch enforces compile-time exhaustiveness.
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from .topic import TopicType


class _StrictBase(BaseModel):
    model_config = ConfigDict(extra="forbid")


class _OpEnvelope(_StrictBase):
    """Common fields on every op type. Subclasses add `op_type` and `payload`."""

    op_id: str = Field(min_length=1)
    actor_id: str = Field(min_length=1)
    created_at: str = Field(
        min_length=1,
        description="ISO-8601 UTC timestamp from ditagen_common.store.utc_now().",
    )
    parent_op_id: str | None = Field(default=None, min_length=1)
    extraction_snapshot_id: str = Field(min_length=1)


# ---------------------------------------------------------------------------
# Per-op payload models
# ---------------------------------------------------------------------------


class MergePayload(_StrictBase):
    block_ids: list[str] = Field(min_length=2)
    """Two-or-more block IDs to merge into a single derived block.
    Order matters: the merged block's text is the inputs' texts joined
    with a single space, in this order. Lineage on the derived block
    equals this list."""


class SplitPayload(_StrictBase):
    block_id: str = Field(min_length=1)
    char_offset: int = Field(ge=1)
    """Character offset within block.text where the split occurs.
    Must satisfy 0 < char_offset < len(block.text); replay rejects
    out-of-range offsets."""


class MovePayload(_StrictBase):
    block_id: str = Field(min_length=1)
    target_topic_id: str = Field(min_length=1)


class RetypePayload(_StrictBase):
    topic_id: str = Field(min_length=1)
    topic_type: TopicType


class RenamePayload(_StrictBase):
    topic_id: str = Field(min_length=1)
    title: str | None = Field(default=None, min_length=1)
    short_desc: str | None = None


class RawXmlOverridePayload(_StrictBase):
    """Replace the projected DITA XML for a single topic.

    Phase 6 (ADR-006 back-compat). The reviewer-facing
    `PATCH /v1/topics/{id}` endpoint accepts an `xml: str` body;
    review-service translates that into a `RawXmlOverrideOp`. Replay
    sets `topic.dita_xml = xml` on the projected topic. Lossy because
    the override doesn't go back through structural ops, so block-
    level lineage cannot be reconstructed from this op alone — the
    workbench must warn before applying.
    """

    topic_id: str = Field(min_length=1)
    xml: str = Field(min_length=1)


# ---------------------------------------------------------------------------
# Per-op variants — the union members. Each fixes `op_type` to a Literal.
# ---------------------------------------------------------------------------


class MergeOp(_OpEnvelope):
    op_type: Literal["merge"] = "merge"
    payload: MergePayload


class SplitOp(_OpEnvelope):
    op_type: Literal["split"] = "split"
    payload: SplitPayload


class MoveOp(_OpEnvelope):
    op_type: Literal["move"] = "move"
    payload: MovePayload


class RetypeOp(_OpEnvelope):
    op_type: Literal["retype"] = "retype"
    payload: RetypePayload


class RenameOp(_OpEnvelope):
    op_type: Literal["rename"] = "rename"
    payload: RenamePayload


class RawXmlOverrideOp(_OpEnvelope):
    op_type: Literal["raw_xml_override"] = "raw_xml_override"
    payload: RawXmlOverridePayload
    is_lossy: Literal[True] = True


# ---------------------------------------------------------------------------
# Discriminated-union alias for use across the codebase.
# ---------------------------------------------------------------------------


EditOperation = Annotated[
    MergeOp | SplitOp | MoveOp | RetypeOp | RenameOp | RawXmlOverrideOp,
    Field(discriminator="op_type"),
]
"""The discriminated union of every supported edit operation. Use
`EditOperationAdapter.validate_python(...)` to parse arbitrary dicts
into the correct variant."""

EditOperationAdapter: TypeAdapter[EditOperation] = TypeAdapter(EditOperation)
