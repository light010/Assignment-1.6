"""Typed `Topic` model and the snapshot/projection containers.

Phase 3 of `plans/logical-whistling-widget.md` introduces the typed
container types that the edit-operation algebra operates on:

- `Topic` mirrors `contracts/llm/topic-plan.schema.json#topicCandidate`,
  scoped to the fields the edit ops touch (Phase 6 may extend with
  generated_topic-only fields like body, traceability, etc.).
- `ExtractionSnapshot` is the immutable input to replay: the
  snapshot_id (= the artifact_version of source-blocks.jsonl) plus
  the typed blocks and topics that came out of analysis.
- `ProjectedState` is the deterministic output of replay: the
  snapshot_id replayed, the projected blocks (potentially with
  derived blocks from Merge/Split), the projected topics (with
  Retype/Rename/Move applied), the chain of op_ids that produced
  this state, and a `traceability` map from projected block_id back
  to the source_block_ids it derives from.

All three are `extra="forbid"` — drift caught at construction time.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .block import Block

TopicType = Literal["concept", "task", "reference", "troubleshooting", "glossary"]


class _StrictBase(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Topic(_StrictBase):
    """A topic candidate or generated topic, scoped to the edit-op surface.

    Phase 3 introduced the minimal title/topic_type/source_block_ids
    shape to support Merge/Split/Move/Retype/Rename. Phase 6 adds
    `dita_xml` because review-service's RawXmlOverride op writes
    projected XML directly onto the topic — without a slot for it on
    the typed model, that op would have to bypass the projection.
    """

    topic_id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    short_desc: str | None = None
    topic_type: TopicType
    source_block_ids: list[str] = Field(default_factory=list)
    dita_xml: str | None = None


class ExtractionSnapshot(_StrictBase):
    """Immutable input to `replay()`.

    `snapshot_id` is the artifact_version of source-blocks.jsonl that the
    blocks were extracted into. Once produced, an extraction snapshot is
    never mutated — every edit produces a new artifact via
    `write_artifact` with `previous_version_id` pointing at this id.
    """

    snapshot_id: str = Field(min_length=1)
    document_id: str = Field(min_length=1)
    blocks: list[Block] = Field(default_factory=list)
    topics: list[Topic] = Field(default_factory=list)


class ProjectedState(_StrictBase):
    """Deterministic output of `replay(snapshot, ops)`.

    `traceability` maps every projected block_id to the source_block_ids
    it derives from in the snapshot. For non-derived blocks (those
    untouched by any op) the mapping is `{block_id: [block_id]}` — the
    block traces back to itself. For Merge-derived blocks it lists the
    inputs; for Split-derived blocks it lists the single source.
    """

    snapshot_id: str = Field(min_length=1)
    document_id: str = Field(min_length=1)
    blocks: list[Block] = Field(default_factory=list)
    topics: list[Topic] = Field(default_factory=list)
    ops_applied: list[str] = Field(
        default_factory=list,
        description="Ordered list of op_ids that produced this state.",
    )
    traceability: dict[str, list[str]] = Field(
        default_factory=dict,
        description="projected block_id -> list of snapshot block_ids it derives from.",
    )
