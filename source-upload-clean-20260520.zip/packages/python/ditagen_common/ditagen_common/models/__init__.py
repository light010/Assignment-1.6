"""Typed Pydantic models for DITAgen domain objects.

Phase 2 of `plans/logical-whistling-widget.md` introduces typed
representations to replace the `dict[str, Any]` shape that historically
crossed service boundaries. Models are derived from the JSON schemas
under `contracts/`, with each schema as the source of truth.
"""

from __future__ import annotations

from .block import (
    REVIEW_FLAG_CATALOG,
    Block,
    Confidence,
    ConfidenceSignals,
    Font,
    InlineRun,
    Numbering,
    Repetition,
    ReviewFlag,
    ReviewFlagCode,
    SourceLocation,
    StyleSummary,
    TableCell,
    review_flag_payload,
)
from .edit_op import (
    EditOperation,
    EditOperationAdapter,
    MergeOp,
    MergePayload,
    MoveOp,
    MovePayload,
    RawXmlOverrideOp,
    RawXmlOverridePayload,
    RenameOp,
    RenamePayload,
    RetypeOp,
    RetypePayload,
    SplitOp,
    SplitPayload,
)
from .topic import (
    ExtractionSnapshot,
    ProjectedState,
    Topic,
    TopicType,
)

__all__ = [
    # Block + nested types (Phase 2).
    "Block",
    "Confidence",
    "ConfidenceSignals",
    "Font",
    "InlineRun",
    "Numbering",
    "Repetition",
    "ReviewFlag",
    "REVIEW_FLAG_CATALOG",
    "ReviewFlagCode",
    "review_flag_payload",
    "SourceLocation",
    "StyleSummary",
    "TableCell",
    # Topic + projection containers (Phase 3).
    "ExtractionSnapshot",
    "ProjectedState",
    "Topic",
    "TopicType",
    # Edit-operation discriminated union (Phase 3 + RawXmlOverride from Phase 6).
    "EditOperation",
    "EditOperationAdapter",
    "MergeOp",
    "MergePayload",
    "MoveOp",
    "MovePayload",
    "RawXmlOverrideOp",
    "RawXmlOverridePayload",
    "RenameOp",
    "RenamePayload",
    "RetypeOp",
    "RetypePayload",
    "SplitOp",
    "SplitPayload",
]
