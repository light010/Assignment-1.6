from __future__ import annotations

from typing import Any

from fastapi import Header, HTTPException, Request

from .ids import new_id
from .security import verify_token
from .sql_store import StateStore


def public_user(user: dict[str, Any]) -> dict[str, Any]:
    return {
        "user_id": user["user_id"],
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "email": user["email"],
        "name": user["name"],
        "roles": user["roles"],
    }


def current_user_from_token(
    authorization: str | None,
    *,
    access_token: str | None = None,
    store: StateStore | None = None,
) -> dict[str, Any]:
    if access_token:
        token = access_token
    elif authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1]
    else:
        raise HTTPException(status_code=401, detail="Missing bearer token")
    try:
        claims = verify_token(token)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    if store is None:
        from .store_factory import create_store

        store = create_store("auth")
    state = store.read()
    token_id = claims.get("jti")
    if claims.get("type") == "personal_access_token":
        token_record = state.get("revoked_tokens", {}).get(token_id)
        if not token_id or not token_record or token_record.get("user_id") != claims["sub"]:
            raise HTTPException(status_code=401, detail="Unknown personal access token")
        if token_record.get("revoked_at"):
            raise HTTPException(status_code=401, detail="Token revoked")
    elif token_id:
        token_record = state.get("revoked_tokens", {}).get(token_id)
        if token_record and token_record.get("revoked_at"):
            raise HTTPException(status_code=401, detail="Token revoked")
    user = next((item for item in state["users"] if item["user_id"] == claims["sub"]), None)
    if not user:
        raise HTTPException(status_code=401, detail="Unknown user")
    return user


def current_user(
    authorization: str | None = Header(default=None),
    access_token: str | None = None,
) -> dict[str, Any]:
    return current_user_from_token(authorization, access_token=access_token)


def assert_role(user: dict[str, Any], allowed: set[str]) -> None:
    if not set(user.get("roles", [])) & allowed:
        raise HTTPException(status_code=403, detail="Insufficient role")


def business_unit_membership(
    state: dict[str, Any], business_unit_id: str, user_id: str
) -> dict[str, Any] | None:
    return next(
        (
            item
            for item in state.get("business_unit_memberships", {}).values()
            if item["business_unit_id"] == business_unit_id and item["user_id"] == user_id
        ),
        None,
    )


def can_access_business_unit(
    business_unit: dict[str, Any],
    user: dict[str, Any],
    state: dict[str, Any],
    *,
    required_membership_roles: set[str] | None = None,
) -> bool:
    if business_unit.get("tenant_id") != user.get("tenant_id"):
        return False
    if set(user.get("roles", [])) & {"org_admin"}:
        return True
    membership = business_unit_membership(
        state, business_unit["business_unit_id"], user["user_id"]
    )
    if not membership:
        return False
    return required_membership_roles is None or membership.get("role") in required_membership_roles


def require_business_unit(
    state: dict[str, Any],
    business_unit_id: str,
    user: dict[str, Any],
    *,
    include_deleted: bool = False,
    required_membership_roles: set[str] | None = None,
) -> dict[str, Any]:
    business_unit = state.get("business_units", {}).get(business_unit_id)
    if (
        not business_unit
        or business_unit.get("tenant_id") != user.get("tenant_id")
        or (not include_deleted and business_unit.get("status") == "archived")
    ):
        raise HTTPException(status_code=404, detail="Business unit not found")
    if not can_access_business_unit(
        business_unit,
        user,
        state,
        required_membership_roles=required_membership_roles,
    ):
        raise HTTPException(status_code=403, detail="Business unit access denied")
    return business_unit


def context_headers(request: Request, user: dict[str, Any]) -> dict[str, str]:
    headers: dict[str, str] = {}
    if request.headers.get("authorization"):
        headers["Authorization"] = request.headers["authorization"]
    elif request.query_params.get("access_token"):
        headers["Authorization"] = f"Bearer {request.query_params['access_token']}"
    headers["X-Request-ID"] = request.headers.get("x-request-id") or new_id("req")
    headers["X-Actor-ID"] = user["user_id"]
    headers["X-Tenant-ID"] = user["tenant_id"]
    headers["X-Organization-ID"] = user["organization_id"]
    business_unit_id = (
        request.headers.get("x-business-unit-id")
        or request.path_params.get("business_unit_id")
        or request.query_params.get("business_unit_id")
    )
    if business_unit_id:
        headers["X-Business-Unit-ID"] = business_unit_id
    return headers
