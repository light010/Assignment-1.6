from __future__ import annotations

import json
import logging
import threading
import time
from collections import defaultdict
from typing import Any

from fastapi import FastAPI, Request

from .ids import new_id


class ServiceMetrics:
    def __init__(self, service_name: str, started_at: float | None = None) -> None:
        self.service_name = service_name
        self.started_at = started_at or time.time()
        self._lock = threading.Lock()
        self._requests: dict[tuple[str, str, int], int] = defaultdict(int)
        self._duration_sum: dict[tuple[str, str], float] = defaultdict(float)
        self._duration_count: dict[tuple[str, str], int] = defaultdict(int)
        self._errors: dict[tuple[str, str], int] = defaultdict(int)

    def record(self, *, method: str, path: str, status: int, duration_seconds: float) -> None:
        with self._lock:
            self._requests[(method, path, status)] += 1
            self._duration_sum[(method, path)] += duration_seconds
            self._duration_count[(method, path)] += 1
            if status >= 500:
                self._errors[(method, path)] += 1

    def render(self) -> str:
        lines = [
            f'ditagen_service_uptime_seconds{{service="{self.service_name}"}} '
            f"{time.time() - self.started_at:.3f}"
        ]
        with self._lock:
            for (method, path, status), count in sorted(self._requests.items()):
                lines.append(
                    'ditagen_http_requests_total'
                    f'{{service="{self.service_name}",method="{method}",path="{path}",status="{status}"}} '
                    f"{count}"
                )
            for (method, path), total in sorted(self._duration_sum.items()):
                labels = f'{{service="{self.service_name}",method="{method}",path="{path}"}}'
                lines.append(f"ditagen_http_request_duration_seconds_sum{labels} {total:.6f}")
                lines.append(
                    f"ditagen_http_request_duration_seconds_count{labels} "
                    f"{self._duration_count[(method, path)]}"
                )
            for (method, path), count in sorted(self._errors.items()):
                lines.append(
                    'ditagen_http_errors_total'
                    f'{{service="{self.service_name}",method="{method}",path="{path}"}} {count}'
                )
        return "\n".join(lines) + "\n"


def _json_logger(service_name: str) -> logging.Logger:
    logger = logging.getLogger(f"ditagen.{service_name}")
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    return logger


def _route_path(request: Request) -> str:
    route = request.scope.get("route")
    return getattr(route, "path", request.url.path)


def _log(logger: logging.Logger, payload: dict[str, Any]) -> None:
    logger.info(json.dumps(payload, sort_keys=True, separators=(",", ":")))


def install_observability(app: FastAPI, service_name: str) -> ServiceMetrics:
    metrics = ServiceMetrics(service_name)
    logger = _json_logger(service_name)
    app.state.metrics = metrics
    app.state.logger = logger

    @app.middleware("http")
    async def request_observability(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or new_id("req")
        started = time.perf_counter()
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            duration = time.perf_counter() - started
            path = _route_path(request)
            metrics.record(
                method=request.method,
                path=path,
                status=status,
                duration_seconds=duration,
            )
            _log(
                logger,
                {
                    "ts": time.time(),
                    "level": "info" if status < 500 else "error",
                    "service": service_name,
                    "request_id": request_id,
                    "event": "http_request",
                    "method": request.method,
                    "path": path,
                    "status": status,
                    "duration_ms": round(duration * 1000, 3),
                },
            )

    return metrics
