from __future__ import annotations

import os
from typing import Any

from fastapi import FastAPI
from fastapi.responses import PlainTextResponse

from .observability import install_observability
from .security import validate_auth_secret_config


def create_service_app(service_name: str) -> FastAPI:
    validate_auth_secret_config()
    app = FastAPI(title=f"DITAgen {service_name}", version="0.1.0")
    metrics_store = install_observability(app, service_name)

    @app.get("/health/live")
    def live() -> dict[str, Any]:
        return {"service": service_name, "status": "live"}

    @app.get("/health/ready")
    def ready() -> dict[str, Any]:
        return {
            "service": service_name,
            "status": "ready",
            "data_dir": os.getenv("DITAGEN_DATA_DIR", ".ditagen/data"),
        }

    @app.get("/metrics", response_class=PlainTextResponse)
    def metrics() -> str:
        base = metrics_store.render()
        provider = getattr(app.state, "metrics_provider", None)
        if callable(provider):
            return base + provider()
        return base

    return app
