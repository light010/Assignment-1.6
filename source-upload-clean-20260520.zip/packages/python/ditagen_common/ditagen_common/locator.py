from __future__ import annotations

import re
from dataclasses import dataclass

# Step I2: SINGLE source of truth for the locator pattern. This string
# MUST be byte-equal to:
#   - the regex source in `apps/web/src/locator.ts` (modulo JS escape rules),
#   - `contracts/artifacts/source-block.schema.json#section.pattern`,
#   - `contracts/artifacts/source-line.schema.json#section.pattern`.
#
# Drift is locked by `tests/test_locator_pattern_unified.py`.
#
# Section-id charset is `[A-Za-z0-9_.-]+` — enforced by
# `_validate_section_id` below. Audit I-audit-5 documented that this
# charset was previously implicit; it now lives both in the pattern and
# in the validator's error message.
#
# Audit I-audit-3 fix: `pdf:p:` is constrained to `[1-9]\d*` (≥1) so
# regex-validated locators agree with `format_pdf_bbox_locator`'s
# `page < 1` guard. Previously `pdf:p:0:bbox:0:0:0:0` matched the
# regex but the producer would never emit it — a real drift bug.
LOCATOR_PATTERN_STRING: str = (
    r"^(?:"
    r"docx:p:(?P<docx_p>\d+)"
    r"|docx:tbl:(?P<docx_tbl>\d+):r:(?P<docx_tbl_row>\d+)"
    r"|docx:tbl:(?P<docx_outer>\d+):r:(?P<docx_outer_row>\d+):tbl:(?P<docx_inner>\d+):r:(?P<docx_inner_row>\d+)"
    r"|docx:hdr:(?P<docx_hdr_section>[A-Za-z0-9_.-]+):p:(?P<docx_hdr_p>\d+)"
    r"|docx:ftr:(?P<docx_ftr_section>[A-Za-z0-9_.-]+):p:(?P<docx_ftr_p>\d+)"
    r"|docx:footnote:(?P<docx_footnote>\d+)"
    r"|docx:endnote:(?P<docx_endnote>\d+)"
    r"|pdf:p:(?P<pdf_page>[1-9]\d*):bbox:(?P<pdf_left>-?\d+(?:\.\d+)?):(?P<pdf_top>-?\d+(?:\.\d+)?):(?P<pdf_width>-?\d+(?:\.\d+)?):(?P<pdf_height>-?\d+(?:\.\d+)?)"
    r")$"
)

LOCATOR_PATTERN = re.compile(LOCATOR_PATTERN_STRING)


@dataclass(frozen=True)
class ParsedLocator:
    kind: str
    values: tuple[int | float | str, ...]


def format_docx_paragraph_locator(index: int) -> str:
    if index < 0:
        raise ValueError("DOCX paragraph locator index must be >= 0")
    return f"docx:p:{index}"


def format_docx_table_row_locator(table_index: int, row_index: int) -> str:
    if table_index < 0 or row_index < 0:
        raise ValueError("DOCX table and row locator indices must be >= 0")
    return f"docx:tbl:{table_index}:r:{row_index}"


def format_docx_nested_table_row_locator(
    outer_table_index: int,
    outer_row_index: int,
    inner_table_index: int,
    inner_row_index: int,
) -> str:
    if min(outer_table_index, outer_row_index, inner_table_index, inner_row_index) < 0:
        raise ValueError("DOCX nested table locator indices must be >= 0")
    return f"docx:tbl:{outer_table_index}:r:{outer_row_index}:tbl:{inner_table_index}:r:{inner_row_index}"


def format_docx_header_locator(section_id: str, index: int) -> str:
    _validate_section_id(section_id)
    if index < 0:
        raise ValueError("DOCX header locator index must be >= 0")
    return f"docx:hdr:{section_id}:p:{index}"


def format_docx_footer_locator(section_id: str, index: int) -> str:
    _validate_section_id(section_id)
    if index < 0:
        raise ValueError("DOCX footer locator index must be >= 0")
    return f"docx:ftr:{section_id}:p:{index}"


def format_docx_footnote_locator(note_id: int) -> str:
    if note_id < 0:
        raise ValueError("DOCX footnote locator id must be >= 0")
    return f"docx:footnote:{note_id}"


def format_docx_endnote_locator(note_id: int) -> str:
    if note_id < 0:
        raise ValueError("DOCX endnote locator id must be >= 0")
    return f"docx:endnote:{note_id}"


def format_pdf_bbox_locator(page: int, left: float, top: float, width: float, height: float) -> str:
    if page < 1:
        raise ValueError("PDF locator page must be >= 1")
    return (
        f"pdf:p:{page}"
        f":bbox:{_format_bbox_component(left)}"
        f":{_format_bbox_component(top)}"
        f":{_format_bbox_component(width)}"
        f":{_format_bbox_component(height)}"
    )


def _format_bbox_component(value: float) -> str:
    """Format a bbox float so it ALWAYS matches the locator regex
    `-?\\d+(?:\\.\\d+)?`.

    Audit I-audit-4: Python's `f"{value:g}"` can emit scientific notation
    (`1e-06`) for small magnitudes, which the schema regex rejects.
    Likewise `f"{value:f}"` would emit trailing zeros (`12.500000`) and
    blow up byte size. The right thing is fixed-point with up to 6
    fractional digits, trailing zeros stripped, and a stable handling
    of -0.0.
    """
    # Use 6 fractional digits — finer than any reasonable PDF resolution
    # and within float64 round-trip precision for values in typical
    # bbox ranges. Strip trailing zeros, then a trailing dot.
    formatted = f"{value:.6f}".rstrip("0").rstrip(".")
    # Negative zero would surface as `-0`; normalize to `0`.
    if formatted in {"-0", ""}:
        return "0"
    return formatted


def validate_locator(value: str | None) -> bool:
    return value is None or bool(LOCATOR_PATTERN.fullmatch(value))


def parse_locator(value: str) -> ParsedLocator:
    match = LOCATOR_PATTERN.fullmatch(value)
    if not match:
        raise ValueError(f"Invalid source locator: {value!r}")
    groups = match.groupdict()
    if groups["docx_p"] is not None:
        return ParsedLocator("docx_p", (int(groups["docx_p"]),))
    if groups["docx_tbl"] is not None:
        return ParsedLocator("docx_table_row", (int(groups["docx_tbl"]), int(groups["docx_tbl_row"])))
    if groups["docx_outer"] is not None:
        return ParsedLocator(
            "docx_nested_table_row",
            (
                int(groups["docx_outer"]),
                int(groups["docx_outer_row"]),
                int(groups["docx_inner"]),
                int(groups["docx_inner_row"]),
            ),
        )
    if groups["docx_hdr_section"] is not None:
        return ParsedLocator("docx_header", (groups["docx_hdr_section"], int(groups["docx_hdr_p"])))
    if groups["docx_ftr_section"] is not None:
        return ParsedLocator("docx_footer", (groups["docx_ftr_section"], int(groups["docx_ftr_p"])))
    if groups["docx_footnote"] is not None:
        return ParsedLocator("docx_footnote", (int(groups["docx_footnote"]),))
    if groups["docx_endnote"] is not None:
        return ParsedLocator("docx_endnote", (int(groups["docx_endnote"]),))
    return ParsedLocator(
        "pdf_bbox",
        (
            int(groups["pdf_page"]),
            float(groups["pdf_left"]),
            float(groups["pdf_top"]),
            float(groups["pdf_width"]),
            float(groups["pdf_height"]),
        ),
    )


def _validate_section_id(section_id: str) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", section_id):
        raise ValueError(f"Invalid DOCX section id: {section_id!r}")
