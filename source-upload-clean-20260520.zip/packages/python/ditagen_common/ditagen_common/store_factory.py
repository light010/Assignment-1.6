from __future__ import annotations

import os
from typing import Any

from .sql_store import SqlStateStore, StateStore
from .store import JsonStore


def create_store(service_name: str, **kwargs: Any) -> StateStore:
    database_url = os.getenv("DITAGEN_DATABASE_URL")
    backend = os.getenv("DITAGEN_STORE_BACKEND", "json").lower()
    if database_url and backend in {"sql", "postgres", "postgresql", "sqlite"}:
        return SqlStateStore(database_url, service_name=service_name)
    return JsonStore(**kwargs)
