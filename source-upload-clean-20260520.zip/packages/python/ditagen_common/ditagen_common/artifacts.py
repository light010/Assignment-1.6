from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from .ids import new_id
from .store import artifact_dir, utc_now


def sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip().lower()).strip("-")
    return slug or "untitled"


def write_artifact(
    *,
    project_id: str,
    document_id: str,
    name: str,
    content: str | bytes | dict[str, Any] | list[Any],
    content_type: str = "application/json",
    store: Any | None = None,
    created_by: str | None = None,
    producer: str = "upload-service",
) -> dict[str, Any]:
    version, previous_version_id = _next_artifact_version(
        store=store,
        document_id=document_id,
        name=name,
    )
    version_path = f"v{version}" if isinstance(version, int) else str(version)
    root = artifact_dir() / "projects" / project_id / "documents" / document_id / version_path
    root.mkdir(parents=True, exist_ok=True)
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        data = content
        path.write_bytes(data)
    elif isinstance(content, str):
        data = content.encode("utf-8")
        path.write_text(content, encoding="utf-8")
    else:
        text = json.dumps(content, indent=2, sort_keys=True)
        data = text.encode("utf-8")
        path.write_text(text, encoding="utf-8")
    ref = {
        "artifact_version": version,
        "version": version,
        "project_id": project_id,
        "document_id": document_id,
        "name": name,
        "path": str(path),
        "content_type": content_type,
        "hash": sha256_bytes(data),
        "sha256": sha256_bytes(data),
        "size_bytes": len(data),
        "producer": producer,
        "previous_version_id": previous_version_id,
    }
    if store is not None:
        entry = register_artifact(
            store=store,
            project_id=project_id,
            document_id=document_id,
            ref=ref,
            created_by=created_by,
        )
        ref["artifact_id"] = entry["artifact_id"]
        ref["id"] = entry["artifact_id"]
    return ref


def _next_artifact_version(
    *,
    store: Any | None,
    document_id: str,
    name: str,
) -> tuple[int | str, str | None]:
    if store is None:
        return new_id("av"), None
    state = store.read()
    matches = [
        artifact
        for artifact in state.get("artifact_registry", {}).values()
        if artifact.get("document_id") == document_id and artifact.get("name") == name
    ]
    if not matches:
        return 1, None
    latest = max(matches, key=lambda artifact: int(artifact.get("version") or artifact.get("artifact_version") or 0))
    return int(latest.get("version") or latest.get("artifact_version") or 0) + 1, latest["artifact_id"]


def register_artifact(
    *,
    store: Any,
    project_id: str,
    document_id: str,
    ref: dict[str, Any],
    created_by: str | None = None,
) -> dict[str, Any]:
    artifact_id = ref.get("artifact_id") or new_id("art")
    entry = {
        "artifact_id": artifact_id,
        "id": artifact_id,
        "project_id": project_id,
        "document_id": document_id,
        "name": ref["name"],
        "artifact_version": ref["artifact_version"],
        "version": ref.get("version", ref["artifact_version"]),
        "content_type": ref["content_type"],
        "size_bytes": ref["size_bytes"],
        "hash": ref["hash"],
        "sha256": ref.get("sha256", ref["hash"]),
        "path": ref["path"],
        "producer": ref.get("producer", "upload-service"),
        "created_by": created_by,
        "created_at": utc_now(),
        "previous_version_id": ref.get("previous_version_id"),
    }

    # Phase 4 D4.5.b: `register_artifact` no longer mutates the document
    # denorm. Documents are upload-service-owned and live in SQL; the
    # caller is responsible for updating `document.latest_artifacts`
    # when it matters (creation paths build it from the extraction refs
    # directly; reextract updates it explicitly; post-creation writes
    # can call `DocumentRepository().set_latest_artifact(...)` if the
    # name is one a downstream consumer reads via the denorm).
    # Crossing the upload-service repo boundary from `ditagen_common`
    # would be a layering violation; single-responsibility is the
    # cleaner answer.
    def add(state: dict[str, Any]) -> dict[str, Any]:
        state["artifact_registry"][artifact_id] = entry
        return entry

    return store.mutate(add)


def read_artifact_text(ref: dict[str, Any]) -> str:
    return Path(ref["path"]).read_text(encoding="utf-8")


def read_artifact_json(ref: dict[str, Any]) -> Any:
    return json.loads(read_artifact_text(ref))
