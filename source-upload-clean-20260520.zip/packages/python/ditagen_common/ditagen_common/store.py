from __future__ import annotations

import json
import os
import threading
from collections.abc import Callable
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .security import hash_password


def data_dir() -> Path:
    return Path(os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")).resolve()


def artifact_dir() -> Path:
    return data_dir() / "artifacts"


def state_path() -> Path:
    return data_dir() / "state.json"


def initial_state() -> dict[str, Any]:
    tenant_id = "ten_local"
    org_id = "org_local"
    admin_id = "usr_admin"
    reviewer_id = "usr_reviewer"
    bu_docs_ops = "bu_docs_ops"
    bu_product_content = "bu_product_content"
    bu_compliance = "bu_compliance"
    now = utc_now()
    default_policy = {
        "target_dita_version": "1.3",
        "allowed_upload_extensions": [".docx", ".pdf", ".txt", ".md", ".html", ".htm"],
        "max_upload_bytes": 250 * 1024 * 1024,
        "review_policy": "manual_approval",
    }
    return {
        "tenants": [{"tenant_id": tenant_id, "name": "Local Tenant"}],
        "organizations": [
            {"organization_id": org_id, "tenant_id": tenant_id, "name": "DITAgen Local"}
        ],
        "users": [
            {
                "user_id": admin_id,
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "email": "admin@ditagen.local",
                "name": "Local Admin",
                "password_hash": hash_password("admin123"),
                "roles": ["org_admin", "project_admin", "editor", "reviewer"],
            },
            {
                "user_id": reviewer_id,
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "email": "reviewer@ditagen.local",
                "name": "Local Reviewer",
                "password_hash": hash_password("reviewer123"),
                "roles": ["reviewer"],
            },
        ],
        "sessions": {},
        "business_units": {
            bu_docs_ops: {
                "business_unit_id": bu_docs_ops,
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "name": "Documentation Operations",
                "description": "Primary documentation conversion portfolio.",
                "owner_team": "Content Operations",
                "region": "North America",
                "status": "active",
                "policy": deepcopy(default_policy),
                "created_by": admin_id,
                "created_at": now,
                "updated_at": now,
                "deleted_at": None,
            },
            bu_product_content: {
                "business_unit_id": bu_product_content,
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "name": "Product Content",
                "description": "Product-led source content and topic conversion.",
                "owner_team": "Product Enablement",
                "region": "Global",
                "status": "active",
                "policy": deepcopy(default_policy),
                "created_by": admin_id,
                "created_at": now,
                "updated_at": now,
                "deleted_at": None,
            },
            bu_compliance: {
                "business_unit_id": bu_compliance,
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "name": "Compliance Publishing",
                "description": "Regulated review and export programs.",
                "owner_team": "Compliance",
                "region": "Global",
                "status": "active",
                "policy": deepcopy(default_policy),
                "created_by": admin_id,
                "created_at": now,
                "updated_at": now,
                "deleted_at": None,
            },
        },
        "business_unit_memberships": {
            f"bum_{bu_docs_ops}_{admin_id}": {
                "membership_id": f"bum_{bu_docs_ops}_{admin_id}",
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "business_unit_id": bu_docs_ops,
                "user_id": admin_id,
                "role": "bu_admin",
                "created_at": now,
            },
            f"bum_{bu_product_content}_{admin_id}": {
                "membership_id": f"bum_{bu_product_content}_{admin_id}",
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "business_unit_id": bu_product_content,
                "user_id": admin_id,
                "role": "bu_admin",
                "created_at": now,
            },
            f"bum_{bu_compliance}_{admin_id}": {
                "membership_id": f"bum_{bu_compliance}_{admin_id}",
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "business_unit_id": bu_compliance,
                "user_id": admin_id,
                "role": "bu_admin",
                "created_at": now,
            },
            f"bum_{bu_docs_ops}_{reviewer_id}": {
                "membership_id": f"bum_{bu_docs_ops}_{reviewer_id}",
                "tenant_id": tenant_id,
                "organization_id": org_id,
                "business_unit_id": bu_docs_ops,
                "user_id": reviewer_id,
                "role": "reviewer",
                "created_at": now,
            },
        },
        "business_unit_favorites": {
            f"buf_{bu_docs_ops}_{admin_id}": {
                "favorite_id": f"buf_{bu_docs_ops}_{admin_id}",
                "business_unit_id": bu_docs_ops,
                "user_id": admin_id,
                "created_at": now,
            }
        },
        "projects": {},
        "project_memberships": {},
        "documents": {},
        "topics": {},
        "exports": {},
        "jobs": {},
        "upload_sessions": {},
        "extractions": {},
        "artifact_registry": {},
        "audit_events": [],
        "revoked_tokens": {},
    }


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


# Top-level state collections and their default empty shape.
# This map is the single source of truth for which keys exist and what
# their "empty" container looks like. Both initial_state() and the
# migrate-on-read path consult it.  When a new collection is added,
# adding it here is enough — pre-existing on-disk state files are
# migrated forward automatically rather than failing validation.
_COLLECTION_DEFAULTS: dict[str, Any] = {
    "tenants": [],
    "organizations": [],
    "users": [],
    "sessions": {},
    "business_units": {},
    "business_unit_memberships": {},
    "business_unit_favorites": {},
    "projects": {},
    "project_memberships": {},
    "documents": {},
    "topics": {},
    "exports": {},
    "jobs": {},
    "upload_sessions": {},
    "extractions": {},
    "artifact_registry": {},
    "audit_events": [],
    "revoked_tokens": {},
}

_DEFAULT_BUSINESS_UNIT_ID = "bu_docs_ops"
_DEFAULT_PROJECT_ID = "prj_migrated_documents"
_DEFAULT_CONVERSION_PROFILE = {
    "target_dita_version": "1.3",
    "allowed_topic_types": ["concept", "task", "reference", "troubleshooting", "glossary"],
    "review_policy": "allow_alpha_export_with_warnings",
}


def _first_record_id(records: list[dict[str, Any]], key: str, fallback: str) -> str:
    return next((record[key] for record in records if record.get(key)), fallback)


def _migration_context(state: dict[str, Any]) -> dict[str, str]:
    users = state.get("users", [])
    admin = next(
        (user for user in users if "org_admin" in set(user.get("roles", []))),
        users[0] if users else {},
    )
    return {
        "tenant_id": _first_record_id(state.get("tenants", []), "tenant_id", "ten_local"),
        "organization_id": _first_record_id(
            state.get("organizations", []), "organization_id", "org_local"
        ),
        "admin_id": admin.get("user_id") or "usr_admin",
    }


def _ensure_seed_business_units(state: dict[str, Any], context: dict[str, str]) -> bool:
    mutated = False
    seeded = initial_state()
    for business_unit_id, business_unit in seeded["business_units"].items():
        if business_unit_id not in state["business_units"]:
            migrated = deepcopy(business_unit)
            migrated["tenant_id"] = context["tenant_id"]
            migrated["organization_id"] = context["organization_id"]
            migrated["created_by"] = context["admin_id"]
            state["business_units"][business_unit_id] = migrated
            mutated = True

    for user in state.get("users", []):
        user_id = user.get("user_id")
        if not user_id:
            continue
        roles = set(user.get("roles", []))
        if roles & {"org_admin", "project_admin"}:
            role = "bu_admin"
            target_business_unit_ids = list(state["business_units"])
        elif "editor" in roles:
            role = "editor"
            target_business_unit_ids = [_DEFAULT_BUSINESS_UNIT_ID]
        elif "reviewer" in roles:
            role = "reviewer"
            target_business_unit_ids = [_DEFAULT_BUSINESS_UNIT_ID]
        else:
            continue
        for business_unit_id in target_business_unit_ids:
            if business_unit_id not in state["business_units"]:
                continue
            membership_id = f"bum_{business_unit_id}_{user_id}"
            if membership_id not in state["business_unit_memberships"]:
                state["business_unit_memberships"][membership_id] = {
                    "membership_id": membership_id,
                    "tenant_id": user.get("tenant_id") or context["tenant_id"],
                    "organization_id": user.get("organization_id") or context["organization_id"],
                    "business_unit_id": business_unit_id,
                    "user_id": user_id,
                    "role": role,
                    "created_at": utc_now(),
                }
                mutated = True
    return mutated


def _default_business_unit_id(state: dict[str, Any]) -> str:
    if _DEFAULT_BUSINESS_UNIT_ID in state["business_units"]:
        return _DEFAULT_BUSINESS_UNIT_ID
    return next(iter(state["business_units"]), _DEFAULT_BUSINESS_UNIT_ID)


def _ensure_fallback_project(
    state: dict[str, Any], context: dict[str, str], business_unit_id: str
) -> tuple[str, bool]:
    if _DEFAULT_PROJECT_ID in state["projects"]:
        return _DEFAULT_PROJECT_ID, False

    now = utc_now()
    state["projects"][_DEFAULT_PROJECT_ID] = {
        "project_id": _DEFAULT_PROJECT_ID,
        "business_unit_id": business_unit_id,
        "tenant_id": context["tenant_id"],
        "organization_id": context["organization_id"],
        "name": "Migrated Documents",
        "description": "Workspace for documents restored from an older local alpha state.",
        "created_by": context["admin_id"],
        "created_at": now,
        "updated_at": now,
        "status": "active",
        "deleted_at": None,
        "conversion_profile": deepcopy(_DEFAULT_CONVERSION_PROFILE),
        "document_ids": [],
    }
    membership_id = f"mem_{_DEFAULT_PROJECT_ID}_{context['admin_id']}"
    state["project_memberships"][membership_id] = {
        "membership_id": membership_id,
        "tenant_id": context["tenant_id"],
        "organization_id": context["organization_id"],
        "business_unit_id": business_unit_id,
        "project_id": _DEFAULT_PROJECT_ID,
        "user_id": context["admin_id"],
        "role": "project_admin",
        "created_at": now,
    }
    return _DEFAULT_PROJECT_ID, True


def _record_business_unit(
    state: dict[str, Any], record: dict[str, Any], fallback_business_unit_id: str
) -> str:
    if record.get("business_unit_id"):
        return record["business_unit_id"]
    project = state["projects"].get(record.get("project_id"))
    if project and project.get("business_unit_id"):
        return project["business_unit_id"]
    document = state["documents"].get(record.get("document_id"))
    if document and document.get("business_unit_id"):
        return document["business_unit_id"]
    return fallback_business_unit_id


def _apply_state_migrations(state: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    """Forward-compatible migration: fills missing top-level collection
    keys with their canonical empty shape from _COLLECTION_DEFAULTS.

    Returns (state, mutated). If mutated is True, the caller should
    persist the upgraded state back to disk so subsequent reads see the
    migrated layout immediately.
    """

    mutated = False
    for key, default in _COLLECTION_DEFAULTS.items():
        if key not in state:
            state[key] = deepcopy(default)
            mutated = True
    context = _migration_context(state)
    if not state["business_units"] or _DEFAULT_BUSINESS_UNIT_ID not in state["business_units"]:
        mutated = _ensure_seed_business_units(state, context) or mutated
    else:
        mutated = _ensure_seed_business_units(state, context) or mutated

    default_business_unit_id = _default_business_unit_id(state)
    now = utc_now()

    for project_id, project in state["projects"].items():
        if not project.get("business_unit_id"):
            project["business_unit_id"] = default_business_unit_id
            mutated = True
        for field, value in (
            ("project_id", project_id),
            ("tenant_id", context["tenant_id"]),
            ("organization_id", context["organization_id"]),
            ("description", None),
            ("created_by", context["admin_id"]),
            ("created_at", now),
            ("updated_at", project.get("created_at") or now),
            ("status", "active"),
            ("deleted_at", None),
        ):
            if field not in project:
                project[field] = value
                mutated = True
        if "conversion_profile" not in project:
            project["conversion_profile"] = deepcopy(_DEFAULT_CONVERSION_PROFILE)
            mutated = True
        if "document_ids" not in project:
            project["document_ids"] = []
            mutated = True
        membership_id = f"mem_{project_id}_{project.get('created_by') or context['admin_id']}"
        if membership_id not in state["project_memberships"]:
            state["project_memberships"][membership_id] = {
                "membership_id": membership_id,
                "tenant_id": project["tenant_id"],
                "organization_id": project["organization_id"],
                "business_unit_id": project["business_unit_id"],
                "project_id": project_id,
                "user_id": project.get("created_by") or context["admin_id"],
                "role": "project_admin",
                "created_at": project["created_at"],
            }
            mutated = True

    fallback_project_id = _DEFAULT_PROJECT_ID
    for document_id, document in state["documents"].items():
        if not document.get("project_id") or document.get("project_id") not in state["projects"]:
            fallback_project_id, created = _ensure_fallback_project(
                state, context, default_business_unit_id
            )
            document["project_id"] = fallback_project_id
            mutated = created or True
        business_unit_id = _record_business_unit(state, document, default_business_unit_id)
        for field, value in (
            ("document_id", document_id),
            ("tenant_id", context["tenant_id"]),
            ("business_unit_id", business_unit_id),
            ("latest_artifacts", {}),
            ("job_ids", document.get("job_ids") or []),
            ("topic_ids", document.get("topic_ids") or []),
        ):
            if field not in document:
                document[field] = value
                mutated = True
        project = state["projects"].get(document["project_id"])
        if project is not None and document_id not in project.setdefault("document_ids", []):
            project["document_ids"].append(document_id)
            mutated = True

    for collection_name in ("topics", "jobs", "upload_sessions"):
        for record_id, record in state[collection_name].items():
            business_unit_id = _record_business_unit(state, record, default_business_unit_id)
            if not record.get("business_unit_id"):
                record["business_unit_id"] = business_unit_id
                mutated = True
            if "tenant_id" not in record:
                record["tenant_id"] = context["tenant_id"]
                mutated = True
            id_field = {
                "topics": "topic_record_id",
                "jobs": "job_id",
                "upload_sessions": "upload_id",
            }[collection_name]
            if id_field not in record:
                record[id_field] = record_id
                mutated = True

    for artifact_id, artifact in state["artifact_registry"].items():
        defaults = {
            "artifact_id": artifact_id,
            "document_id": artifact.get("document_id") or "",
            "name": artifact.get("name") or Path(str(artifact.get("path") or artifact_id)).name,
            "artifact_version": artifact.get("artifact_version")
            or artifact.get("version")
            or "1",
            "content_type": artifact.get("content_type") or "application/octet-stream",
            "size_bytes": artifact.get("size_bytes") or 0,
            "hash": artifact.get("hash") or artifact.get("sha256") or "",
            "path": artifact.get("path") or "",
            "producer": artifact.get("producer") or "migration",
            "created_at": artifact.get("created_at") or now,
        }
        for field, value in defaults.items():
            if field not in artifact:
                artifact[field] = value
                mutated = True
    return state, mutated


def validate_state_shape(state: dict[str, Any]) -> None:
    required_keys = set(_COLLECTION_DEFAULTS.keys())
    missing_keys = sorted(required_keys - state.keys())
    if missing_keys:
        raise ValueError(f"Invalid alpha state: missing keys {', '.join(missing_keys)}")

    for project_id, project in state["projects"].items():
        if not project.get("business_unit_id"):
            raise ValueError(f"Invalid alpha state: project {project_id} is missing business_unit_id")
        if "status" not in project or "deleted_at" not in project:
            raise ValueError(f"Invalid alpha state: project {project_id} is missing lifecycle fields")

    for collection_name in ("documents", "topics", "jobs", "upload_sessions"):
        for record_id, record in state[collection_name].items():
            if not record.get("business_unit_id"):
                raise ValueError(
                    f"Invalid alpha state: {collection_name} record {record_id} is missing business_unit_id"
                )

    for document_id, document in state["documents"].items():
        if "latest_artifacts" not in document:
            raise ValueError(f"Invalid alpha state: document {document_id} is missing latest_artifacts")

    for artifact_id, artifact in state["artifact_registry"].items():
        for field in (
            "artifact_id",
            "document_id",
            "name",
            "artifact_version",
            "content_type",
            "size_bytes",
            "hash",
            "path",
            "producer",
            "created_at",
        ):
            if field not in artifact:
                raise ValueError(f"Invalid alpha state: artifact {artifact_id} is missing {field}")


class JsonStore:
    """Small shared JSON store for the alpha.

    The production path is PostgreSQL plus object storage. This store keeps the
    local demo runnable before migrations and service-owned tables are built.
    """

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or state_path()
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        artifact_dir().mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            state = initial_state()
            validate_state_shape(state)
            self._write(state)

    def read(self) -> dict[str, Any]:
        with self._lock:
            # Phase 4 D2.7c — audit_events live in audit-service's SQL
            # database, not in `state["audit_events"]`. Callers needing
            # audit events go through `request_service("audit-service")`
            # via `service_clients.list_audit_events`.
            return deepcopy(self._load())

    def mutate(self, callback: Callable[[dict[str, Any]], Any]) -> Any:
        with self._lock:
            state = self._load()
            result = callback(state)
            validate_state_shape(state)
            self._write(state)
            return deepcopy(result)

    def audit(
        self,
        *,
        actor_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        business_unit_id: str | None = None,
        project_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        # Phase 4 D2.7c — JsonStore.audit() is retired. Audit events
        # are owned by audit-service; callers MUST use
        # `service_clients.emit_audit_event(...)` which routes through
        # audit-service via HTTP. The method is kept on the protocol so
        # any straggler caller fails loud at the call site instead of
        # silently disappearing into the JSONL sink that no longer
        # exists.
        raise RuntimeError(
            "JsonStore.audit(...) is retired (Phase 4 D2). Use "
            "`ditagen_common.service_clients.emit_audit_event(...)` "
            f"to record action={action!r}."
        )

    def _load(self) -> dict[str, Any]:
        state = json.loads(self.path.read_text(encoding="utf-8"))
        # Migrate forward — fill missing top-level collections from
        # _COLLECTION_DEFAULTS — before strict validation. This keeps the
        # alpha resilient when new collections are added; without it,
        # any state.json from an earlier deploy crashes the gateway.
        state, mutated = _apply_state_migrations(state)
        validate_state_shape(state)
        if mutated:
            # Persist the upgraded layout so it stops being a deficiency
            # the next read has to repair. Best-effort: a write failure
            # here is non-fatal because the in-memory state we return is
            # already correct.
            try:
                self._write(state)
            except OSError:
                pass
        return state

    def _write(self, state: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)
