from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from .sql_store import StateStore

SERVICE_APP_PATHS = {
    "analysis-service": "services/analysis-service/app/main.py",
    "audit-service": "services/audit-service/app/main.py",
    "extraction-service": "services/extraction-service/app/main.py",
    "llm-gateway-service": "services/llm-gateway-service/app/main.py",
    "business-unit-service": "services/business-unit-service/app/main.py",
    "review-service": "services/review-service/app/main.py",
    "upload-service": "services/upload-service/app/main.py",
    "validation-service": "services/validation-service/app/main.py",
}


def repo_root() -> Path:
    for parent in Path(__file__).resolve().parents:
        if (parent / "services").is_dir() and (parent / "packages").is_dir():
            return parent
    raise RuntimeError("Could not locate DITAgen repository root")


def inprocess_services_enabled() -> bool:
    return os.getenv("DITAGEN_INPROCESS_SERVICES") == "1"


def load_service_app(service_name: str) -> Any:
    relative = SERVICE_APP_PATHS[service_name]
    module_path = repo_root() / relative
    data_dir_key = str(Path(os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")).resolve())
    module_name = f"ditagen_inprocess_{service_name.replace('-', '_')}_{abs(hash(data_dir_key))}"
    if module_name in sys.modules:
        return sys.modules[module_name].app
    app_dir = str(module_path.parent)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if not spec or not spec.loader:
        raise RuntimeError(f"Could not load {service_name} app")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.app


def transport_for_url(base_url: str) -> httpx.ASGITransport | None:
    if not inprocess_services_enabled():
        return None
    host = urlparse(base_url).hostname
    if host not in SERVICE_APP_PATHS:
        return None
    return httpx.ASGITransport(app=load_service_app(host))


async def request_service(
    *,
    method: str,
    base_url: str,
    path: str,
    headers: dict[str, str] | None = None,
    params: Any | None = None,
    content: bytes | None = None,
    json: Any | None = None,
    timeout: float = 60.0,
) -> httpx.Response:
    transport = transport_for_url(base_url)
    async with httpx.AsyncClient(
        transport=transport,
        base_url=base_url.rstrip("/"),
        timeout=timeout,
    ) as client:
        return await client.request(
            method,
            path,
            headers=headers,
            params=params,
            content=content,
            json=json,
        )


async def emit_audit_event(
    payload: dict[str, Any],
    *,
    headers: dict[str, str] | None = None,
    store: StateStore | None = None,
) -> dict[str, Any]:
    audit_url = os.getenv("DITAGEN_AUDIT_SERVICE_URL")
    if audit_url:
        response = await request_service(
            method="POST",
            base_url=audit_url,
            path="/internal/audit-events",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        return response.json()
    if store is None:
        from .store_factory import create_store

        store = create_store("service-client")
    return store.audit(
        actor_id=payload["actor_id"],
        action=payload["action"],
        resource_type=payload["resource_type"],
        resource_id=payload["resource_id"],
        business_unit_id=payload.get("business_unit_id"),
        project_id=payload.get("project_id"),
        metadata=payload.get("metadata"),
    )


async def list_audit_events(
    *,
    headers: dict[str, str] | None = None,
    business_unit_id: str | None = None,
    project_id: str | None = None,
    store: StateStore | None = None,
) -> dict[str, Any]:
    params: dict[str, str] = {}
    if business_unit_id:
        params["business_unit_id"] = business_unit_id
    if project_id:
        params["project_id"] = project_id
    audit_url = os.getenv("DITAGEN_AUDIT_SERVICE_URL")
    if audit_url:
        response = await request_service(
            method="GET",
            base_url=audit_url,
            path="/internal/audit-events",
            headers=headers,
            params=params,
        )
        response.raise_for_status()
        return response.json()
    if store is None:
        from .store_factory import create_store

        store = create_store("service-client")
    events = store.read()["audit_events"]
    if business_unit_id:
        events = [event for event in events if event.get("business_unit_id") == business_unit_id]
    if project_id:
        events = [event for event in events if event.get("project_id") == project_id]
    return {"events": events}
