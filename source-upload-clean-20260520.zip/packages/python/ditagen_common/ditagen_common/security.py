from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Any

DEFAULT_SECRET = "ditagen-local-dev-secret-change-me"
INSECURE_NON_DEV_SECRETS = {DEFAULT_SECRET, "change-me-for-nonlocal"}


def validate_auth_secret_config() -> str:
    env = os.getenv("DITAGEN_ENV", "development")
    secret = os.getenv("DITAGEN_AUTH_SECRET")
    if not secret:
        if env != "development":
            raise RuntimeError(
                "DITAGEN_AUTH_SECRET must be set in non-development environments. "
                f"Refusing to use the local development secret with DITAGEN_ENV={env!r}."
            )
        return DEFAULT_SECRET
    if env != "development" and secret in INSECURE_NON_DEV_SECRETS:
        raise RuntimeError(
            "DITAGEN_AUTH_SECRET is set to a known insecure default in "
            f"DITAGEN_ENV={env!r}. Provide a deployment-specific secret."
        )
    return secret


def _secret() -> bytes:
    return validate_auth_secret_config().encode("utf-8")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _unb64(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def hash_password(password: str, *, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("ascii"), 120_000)
    return f"pbkdf2_sha256${salt}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, salt, expected = encoded.split("$", 2)
    except ValueError:
        return False
    if scheme != "pbkdf2_sha256":
        return False
    candidate = hash_password(password, salt=salt).split("$", 2)[2]
    return hmac.compare_digest(candidate, expected)


def issue_token(payload: dict[str, Any], *, expires_in_seconds: int = 3600) -> str:
    claims = dict(payload)
    claims["exp"] = int(time.time()) + expires_in_seconds
    claims["iat"] = int(time.time())
    header = {"alg": "HS256", "typ": "JWT"}
    signing_input = (
        _b64(json.dumps(header, separators=(",", ":")).encode("utf-8"))
        + "."
        + _b64(json.dumps(claims, separators=(",", ":")).encode("utf-8"))
    )
    signature = hmac.new(_secret(), signing_input.encode("ascii"), hashlib.sha256).digest()
    return f"{signing_input}.{_b64(signature)}"


def verify_token(token: str) -> dict[str, Any]:
    try:
        header_b64, payload_b64, signature_b64 = token.split(".", 2)
    except ValueError as exc:
        raise ValueError("Malformed token") from exc
    signing_input = f"{header_b64}.{payload_b64}"
    expected = hmac.new(_secret(), signing_input.encode("ascii"), hashlib.sha256).digest()
    actual = _unb64(signature_b64)
    if not hmac.compare_digest(actual, expected):
        raise ValueError("Invalid token signature")
    payload = json.loads(_unb64(payload_b64))
    if int(payload.get("exp", 0)) < int(time.time()):
        raise ValueError("Token expired")
    return payload
