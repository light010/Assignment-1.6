"""Shared helpers for the DITAgen alpha services."""

from .ids import new_id

__all__ = ["new_id"]
