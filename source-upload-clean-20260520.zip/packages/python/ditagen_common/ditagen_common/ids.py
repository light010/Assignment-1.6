from __future__ import annotations

import secrets
import time


def new_id(prefix: str) -> str:
    """Return a sortable, URL-safe alpha ID.

    This is ULID-like for the alpha: milliseconds first for sortability, then
    random entropy to avoid coordination between services.
    """

    millis = int(time.time() * 1000)
    return f"{prefix}_{millis:x}_{secrets.token_hex(5)}"
