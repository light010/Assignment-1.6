from __future__ import annotations

import json
import sqlite3
import threading
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

from .store import (
    _COLLECTION_DEFAULTS,
    _apply_state_migrations,
    initial_state,
    validate_state_shape,
)


class StateStore(Protocol):
    def read(self) -> dict[str, Any]: ...

    def mutate(self, callback: Callable[[dict[str, Any]], Any]) -> Any: ...

    def audit(
        self,
        *,
        actor_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        business_unit_id: str | None = None,
        project_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]: ...


LIST_COLLECTION_ID_FIELDS = {
    "tenants": "tenant_id",
    "organizations": "organization_id",
    "users": "user_id",
    "audit_events": "event_id",
}

SERVICE_SCHEMAS = {
    "api-gateway": "api_gateway",
    "business-unit-service": "business_unit_service",
    "upload-service": "upload_service",
    "extraction-service": "extraction_service",
    "review-service": "review_service",
    "analysis-service": "analysis_service",
    "validation-service": "validation_service",
    "audit-service": "audit_service",
    "llm-gateway-service": "llm_gateway_service",
}

COLLECTION_OWNERS = {
    "tenants": "business_unit_service",
    "organizations": "business_unit_service",
    "users": "api_gateway",
    "sessions": "api_gateway",
    "revoked_tokens": "api_gateway",
    "business_units": "business_unit_service",
    "business_unit_memberships": "business_unit_service",
    "business_unit_favorites": "business_unit_service",
    "projects": "business_unit_service",
    "project_memberships": "business_unit_service",
    "documents": "upload_service",
    "jobs": "upload_service",
    "upload_sessions": "upload_service",
    "artifact_registry": "upload_service",
    "exports": "upload_service",
    "topics": "review_service",
    "extractions": "extraction_service",
    "audit_events": "audit_service",
}


def _collection_id(collection_name: str, value: Any, index: int) -> str:
    if isinstance(value, dict):
        id_field = LIST_COLLECTION_ID_FIELDS.get(collection_name)
        if id_field and value.get(id_field):
            return str(value[id_field])
        for key in (
            "tenant_id",
            "organization_id",
            "user_id",
            "event_id",
            "session_id",
            "token_id",
            "business_unit_id",
            "membership_id",
            "favorite_id",
            "project_id",
            "document_id",
            "job_id",
            "upload_id",
            "artifact_id",
            "export_id",
            "topic_record_id",
            "extraction_id",
        ):
            if value.get(key):
                return str(value[key])
    return f"{collection_name}_{index}"


class SqlStateStore:
    """Compatibility SQL state store for the JsonStore-to-Postgres migration.

    It creates service-owned schemas and collection tables, stores each
    record as JSON, and exposes the same read/mutate/audit contract the
    alpha services already use. Route code can move to typed repositories
    incrementally while production data stops living in a shared JSON file.
    """

    def __init__(self, database_url: str, *, service_name: str) -> None:
        self.database_url = database_url
        self.service_name = service_name
        self._lock = threading.RLock()
        self._is_postgres = database_url.startswith(("postgres://", "postgresql://"))
        if not self._is_postgres and not database_url.startswith("sqlite:///"):
            raise ValueError(
                "DITAGEN_DATABASE_URL must be postgresql://... or sqlite:///... "
                f"for SqlStateStore, got {database_url!r}"
            )
        self._ensure_schema()

    def read(self) -> dict[str, Any]:
        with self._lock:
            state = self._load()
            return deepcopy(state)

    def mutate(self, callback: Callable[[dict[str, Any]], Any]) -> Any:
        with self._lock:
            state = self._load()
            result = callback(state)
            validate_state_shape(state)
            self._write(state)
            return deepcopy(result)

    def audit(
        self,
        *,
        actor_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        business_unit_id: str | None = None,
        project_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        # Phase 4 D2.7c — audit events are owned by audit-service. The
        # SqlStateStore compat wrapper no longer mirrors them into its
        # blob table; callers route through
        # `service_clients.emit_audit_event(...)`.
        raise RuntimeError(
            "SqlStateStore.audit(...) is retired (Phase 4 D2). Use "
            "`ditagen_common.service_clients.emit_audit_event(...)` "
            f"to record action={action!r}."
        )

    def _connect_sqlite(self) -> sqlite3.Connection:
        path = Path(urlparse(self.database_url).path)
        path.parent.mkdir(parents=True, exist_ok=True)
        return sqlite3.connect(path)

    def _connect_postgres(self):
        import psycopg

        return psycopg.connect(self.database_url)

    def _ensure_schema(self) -> None:
        if self._is_postgres:
            with self._connect_postgres() as conn:
                with conn.cursor() as cur:
                    for schema in sorted(set(COLLECTION_OWNERS.values())):
                        cur.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
                    for collection_name, schema in COLLECTION_OWNERS.items():
                        table = self._table_name(collection_name)
                        cur.execute(
                            f'''
                            CREATE TABLE IF NOT EXISTS "{schema}"."{table}" (
                                record_id text PRIMARY KEY,
                                payload jsonb NOT NULL,
                                updated_at timestamptz NOT NULL DEFAULT now()
                            )
                            '''
                        )
                conn.commit()
            return

        with self._connect_sqlite() as conn:
            for collection_name in COLLECTION_OWNERS:
                conn.execute(
                    f'''
                    CREATE TABLE IF NOT EXISTS "{self._sqlite_table(collection_name)}" (
                        record_id text PRIMARY KEY,
                        payload text NOT NULL,
                        updated_at text NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                    '''
                )
            conn.commit()

    def _load(self) -> dict[str, Any]:
        state = deepcopy(_COLLECTION_DEFAULTS)
        if self._is_postgres:
            with self._connect_postgres() as conn:
                with conn.cursor() as cur:
                    for collection_name, default in _COLLECTION_DEFAULTS.items():
                        schema = COLLECTION_OWNERS[collection_name]
                        table = self._table_name(collection_name)
                        cur.execute(
                            f'SELECT record_id, payload FROM "{schema}"."{table}" ORDER BY record_id'
                        )
                        records = cur.fetchall()
                        state[collection_name] = self._records_to_collection(
                            collection_name, default, records
                        )
        else:
            with self._connect_sqlite() as conn:
                for collection_name, default in _COLLECTION_DEFAULTS.items():
                    rows = conn.execute(
                        f'SELECT record_id, payload FROM "{self._sqlite_table(collection_name)}" '
                        "ORDER BY record_id"
                    ).fetchall()
                    records = [(row[0], json.loads(row[1])) for row in rows]
                    state[collection_name] = self._records_to_collection(
                        collection_name, default, records
                    )

        if not any(state[key] for key in ("users", "business_units", "projects")):
            state = initial_state()
            self._write(state)
        state, migrated = _apply_state_migrations(state)
        validate_state_shape(state)
        if migrated:
            self._write(state)
        # Phase 4 D2.7c — audit_events are owned by audit-service. The
        # SqlStateStore no longer materializes them into the read shape.
        return state

    def _write(self, state: dict[str, Any]) -> None:
        if self._is_postgres:
            with self._connect_postgres() as conn:
                with conn.cursor() as cur:
                    for collection_name, collection in state.items():
                        if collection_name not in COLLECTION_OWNERS:
                            continue
                        schema = COLLECTION_OWNERS[collection_name]
                        table = self._table_name(collection_name)
                        cur.execute(f'DELETE FROM "{schema}"."{table}"')
                        for record_id, payload in self._collection_records(
                            collection_name, collection
                        ):
                            cur.execute(
                                f'''
                                INSERT INTO "{schema}"."{table}" (record_id, payload, updated_at)
                                VALUES (%s, %s::jsonb, now())
                                ''',
                                (record_id, json.dumps(payload, sort_keys=True)),
                            )
                conn.commit()
            return

        with self._connect_sqlite() as conn:
            for collection_name, collection in state.items():
                if collection_name not in COLLECTION_OWNERS:
                    continue
                table = self._sqlite_table(collection_name)
                conn.execute(f'DELETE FROM "{table}"')
                conn.executemany(
                    f'INSERT INTO "{table}" (record_id, payload, updated_at) '
                    "VALUES (?, ?, CURRENT_TIMESTAMP)",
                    [
                        (record_id, json.dumps(payload, sort_keys=True))
                        for record_id, payload in self._collection_records(
                            collection_name, collection
                        )
                    ],
                )
            conn.commit()

    def _records_to_collection(
        self,
        collection_name: str,
        default: Any,
        records: list[tuple[str, Any]],
    ) -> Any:
        if isinstance(default, list):
            return [payload for _, payload in records]
        return {record_id: payload for record_id, payload in records}

    def _collection_records(self, collection_name: str, collection: Any) -> list[tuple[str, Any]]:
        if isinstance(collection, dict):
            return [(str(record_id), payload) for record_id, payload in collection.items()]
        if isinstance(collection, list):
            return [
                (_collection_id(collection_name, payload, index), payload)
                for index, payload in enumerate(collection)
            ]
        return []

    def _table_name(self, collection_name: str) -> str:
        return collection_name

    def _sqlite_table(self, collection_name: str) -> str:
        return f"{COLLECTION_OWNERS[collection_name]}__{collection_name}"
