from __future__ import annotations

import io
import json
import re
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from .artifacts import sha256_text, slugify
from .models.block import review_flag_payload

TOPIC_TYPES = {"concept", "task", "reference", "troubleshooting", "glossary"}


@dataclass(frozen=True)
class PipelineArtifacts:
    source_lines: list[dict[str, Any]]
    source_blocks: list[dict[str, Any]]
    style_profile: dict[str, Any]
    structure_tree: dict[str, Any]
    asset_manifest: dict[str, Any]
    markdown: str
    topic_plan: dict[str, Any]
    generated_topics: list[dict[str, Any]]
    dita_files: dict[str, str]
    validation_issues: list[dict[str, Any]]
    export_zip: bytes


def run_document_pipeline(
    *,
    document_id: str,
    filename: str,
    data: bytes,
    model_name: str = "fixture-deterministic",
) -> PipelineArtifacts:
    source_lines = extract_source_lines(document_id=document_id, filename=filename, data=data)
    source_blocks = build_source_blocks(document_id=document_id, source_lines=source_lines)
    style_profile = build_style_profile(document_id=document_id)
    structure_tree = build_structure_tree(document_id=document_id, source_blocks=source_blocks)
    asset_manifest = build_asset_manifest(document_id=document_id)
    markdown = build_markdown(source_blocks, asset_manifest=asset_manifest)
    topic_plan = build_topic_plan(
        document_id=document_id,
        source_blocks=source_blocks,
        structure_tree=structure_tree,
        model_name=model_name,
    )
    generated_topics = [
        build_generated_topic(
            candidate=topic_candidate,
            source_blocks=source_blocks,
            model_name=model_name,
            asset_manifest=asset_manifest,
        )
        for topic_candidate in topic_plan["topic_candidates"]
    ]
    dita_files = build_dita_files(generated_topics)
    validation_issues = validate_dita_files(dita_files=dita_files, asset_manifest=asset_manifest)
    export_zip = build_export_zip(
        document_id=document_id,
        topic_plan=topic_plan,
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        markdown=markdown,
    )
    return PipelineArtifacts(
        source_lines=source_lines,
        source_blocks=source_blocks,
        style_profile=style_profile,
        structure_tree=structure_tree,
        asset_manifest=asset_manifest,
        markdown=markdown,
        topic_plan=topic_plan,
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        export_zip=export_zip,
    )


def extract_source_lines(*, document_id: str, filename: str, data: bytes) -> list[dict[str, Any]]:
    suffix = Path(filename).suffix.lower()
    if suffix == ".docx":
        extracted = _extract_docx(data)
    elif suffix == ".pdf":
        extracted = _extract_pdf(data)
    elif suffix in {".html", ".htm"}:
        extracted = _extract_html(data)
    else:
        extracted = _extract_text(data)
    if not extracted:
        extracted = [{"text": Path(filename).stem or "Untitled document", "page": 1}]

    lines: list[dict[str, Any]] = []
    for index, unit in enumerate(extracted, start=1):
        text = unit["text"].strip()
        if not text:
            continue
        line_id = f"line_{index:04d}"
        marks = _source_marks(text)
        lines.append(
            {
                "line_id": line_id,
                "document_id": document_id,
                "page_or_slide": unit.get("page", 1),
                "text": text,
                "source_location": {"page": unit.get("page", 1)},
                "style": {
                    "font_family": None,
                    "font_size_pt": 18 if _looks_like_heading(text, index) else 11,
                    "bold": _looks_like_heading(text, index),
                    "italic": None,
                    "monospace": None,
                    "alignment": "left",
                    "source_style_name": None,
                },
                "text_runs": [{"text": text, "start": 0, "end": len(text), "marks": marks, "style": {}}],
            }
        )
    return lines


def _extract_docx(data: bytes) -> list[dict[str, Any]]:
    try:
        from docx import Document

        with tempfile.NamedTemporaryFile(suffix=".docx") as handle:
            handle.write(data)
            handle.flush()
            doc = Document(handle.name)
            units = [{"text": p.text, "page": 1} for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
                    if any(cells):
                        units.append({"text": " | ".join(cells), "page": 1})
            return units
    except Exception:
        return _extract_text(data)


def _extract_pdf(data: bytes) -> list[dict[str, Any]]:
    try:
        import fitz

        doc = fitz.open(stream=data, filetype="pdf")
        units: list[dict[str, Any]] = []
        for page_index, page in enumerate(doc, start=1):
            text = page.get_text("text")
            for line in text.splitlines():
                if line.strip():
                    units.append({"text": line, "page": page_index})
        return units
    except Exception:
        return _extract_text(data)


def _extract_html(data: bytes) -> list[dict[str, Any]]:
    text = data.decode("utf-8", errors="ignore")
    text = re.sub(r"<(h[1-6]|p|li|tr|br)\b[^>]*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return [{"text": line, "page": 1} for line in text.splitlines() if line.strip()]


def _extract_text(data: bytes) -> list[dict[str, Any]]:
    text = data.decode("utf-8", errors="ignore")
    if not text.strip():
        text = data.decode("latin-1", errors="ignore")
    return [{"text": line, "page": 1} for line in text.splitlines() if line.strip()]


def build_source_blocks(
    *, document_id: str, source_lines: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    heading_path_ids: list[str] = []
    repeated_candidates = _repeated_line_text(source_lines)
    for index, line in enumerate(source_lines, start=1):
        text = line["text"].strip()
        block_id = f"blk_{index:03d}"
        block_type = _block_type(text, index=index, repeated=text in repeated_candidates)
        inferred_level = 1 if block_type == "heading" else None
        block = {
            "block_id": block_id,
            "document_id": document_id,
            "source_line_ids": [line["line_id"]],
            "block_type": block_type,
            "text": _strip_list_marker(text),
            "source_location": line["source_location"],
            "heading_path_ids": list(heading_path_ids),
            "inferred_level": inferred_level,
            "style_summary": {
                "dominant_font_size_pt": 18 if block_type == "heading" else 11,
                "font_size_rank": 1 if block_type == "heading" else 2,
                "bold_ratio": 1 if block_type == "heading" else 0,
                "italic_ratio": 0,
                "monospace_ratio": 1 if "`" in text else 0,
                "source_style_name": None,
            },
            "inline_runs": [
                {
                    "start": 0,
                    "end": len(_strip_list_marker(text)),
                    "text": _strip_list_marker(text),
                    "marks": _source_marks(text),
                    "semantic_hint": _semantic_hint(text),
                }
            ],
            "asset_refs": [],
            "language": "en-US",
            "content_hash": sha256_text(text),
            "confidence": {
                "extraction": 0.86,
                "block_type": 0.84 if block_type != "unknown" else 0.52,
                "heading": 0.84 if block_type == "heading" else None,
                "semantic_inline": 0.75,
            },
            "review_flags": [],
        }
        if block_type in {"running_header", "running_footer"}:
            block["repetition"] = {
                "appears_on_pages": sorted(
                    {
                        int(item["source_location"].get("page") or 1)
                        for item in source_lines
                        if item["text"].strip() == text
                    }
                ),
                "candidate_role": block_type,
                "confidence": 0.8,
            }
        blocks.append(block)
        if block_type == "heading":
            heading_path_ids = [block_id]
    return blocks


def build_style_profile(*, document_id: str) -> dict[str, Any]:
    return {
        "document_id": document_id,
        "artifact_version": None,
        "font_size_clusters": [
            {"rank": 1, "font_size_pt": 18, "block_count": 1, "likely_role": "heading"},
            {"rank": 2, "font_size_pt": 11, "block_count": 1, "likely_role": "body"},
        ],
        "heading_rules": {
            "accept_threshold": 0.78,
            "review_threshold": 0.55,
            "signals": ["font_size_rank", "bold", "short_line", "not_repeated_header_footer"],
        },
        "running_content_rules": {
            "min_page_repetition": 2,
            "top_region_ratio": 0.1,
            "bottom_region_ratio": 0.1,
        },
    }


def build_structure_tree(
    *, document_id: str, source_blocks: list[dict[str, Any]]
) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    nodes_by_id: dict[str, dict[str, Any]] = {}
    root_nodes: list[str] = []
    stack: list[tuple[dict[str, Any], int, str]] = []
    repaired_level_count = 0
    ambiguous_heading_count = 0

    def make_node(block: dict[str, Any]) -> dict[str, Any]:
        # `confidence.heading` is always populated by both the producer
        # (placeholder 0.85 before _compute_review_signals runs, then the
        # computed posterior) and the synthetic-root code path below
        # (hard-coded 0.5). Don't keep a "if missing, fall back to magic
        # number" branch — it can't fire today and would silently mask a
        # producer regression if it ever did.
        confidence = block["confidence"]["heading"]
        negative_signals = [
            flag.get("code")
            for flag in block.get("review_flags", [])
            if isinstance(flag, dict) and flag.get("severity") in {"warning", "error"}
        ]
        # Evidence fields are derived from the block's own style summary
        # rather than hard-coded `True`/`1` defaults. The schema permits
        # `null`, so reporting "unknown" for missing data is more honest
        # than fake-true; consumers can fall back to alternate signals.
        style_summary = block.get("style_summary") or {}
        font_size_rank = style_summary.get("font_size_rank")
        bold_ratio = style_summary.get("bold_ratio")
        bold: bool | None
        if isinstance(bold_ratio, int | float):
            bold = bold_ratio > 0.5
        else:
            bold = None
        return {
            "node_id": f"node_{block['block_id']}",
            "source_block_id": block["block_id"],
            "title": block["text"],
            "inferred_level": int(block.get("inferred_level") or 1),
            "confidence": round(float(confidence), 3),
            "evidence": {
                "font_size_rank": int(font_size_rank) if isinstance(font_size_rank, int | float) else None,
                "bold": bold,
                "space_before_px": None,
                "short_line": len(block["text"]) <= 80,
                "numbering_pattern": None,
                "docx_style_name": style_summary.get("source_style_name"),
                # Headings never coexist with running_header/running_footer
                # block_types (those are separate categories), so this is
                # always True by definition for any node we make here.
                "not_repeated_header_footer": True,
                "negative_signals": [item for item in negative_signals if item],
            },
            "child_node_ids": [],
            # `review_required` reflects only computed signals; synthetic
            # roots flip this on through their own SYNTHETIC_ROOT_HEADING
            # review_flag (which is severity=warning, so it picks up via
            # `negative_signals` above).
            "review_required": bool(negative_signals),
        }

    def append_node(node: dict[str, Any]) -> None:
        nodes.append(node)
        nodes_by_id[node["node_id"]] = node

    for block in source_blocks:
        if block["block_type"] != "heading":
            # Non-heading blocks get the full ancestor chain (in source-block
            # order, oldest to newest) so downstream consumers can render
            # them inside their owning section. When `stack` is empty (the
            # block appeared before any heading), the chain is empty too.
            #
            # We deliberately do NOT append orphan non-heading blocks to
            # `root_nodes`. The structure-tree schema permits it (items are
            # plain strings), but downstream consumers iterate via
            # `nodes_by_id[id]` which would miss block_ids that have no
            # structureNode counterpart. Tree-orphans are an acceptable
            # state for orphan-content docs; the planning service still
            # picks them up from `source_blocks` directly.
            block["heading_path_ids"] = [source_block_id for _, _, source_block_id in stack]
            continue
        level = int(block.get("inferred_level") or 1)
        while stack and stack[-1][1] >= level:
            stack.pop()

        if not stack and level > 1:
            repaired_level_count += 1
            synthetic_id = f"synthetic_root_{len(root_nodes) + 1:03d}"
            synthetic_block = {
                "block_id": synthetic_id,
                "text": "(untitled root)",
                "inferred_level": 1,
                "confidence": {"heading": 0.5},
                "review_flags": [
                    review_flag_payload(
                        "SYNTHETIC_ROOT_HEADING",
                        message="A heading appeared without a valid H1/H2 ancestor.",
                    )
                ],
            }
            synthetic_node = make_node(synthetic_block)
            append_node(synthetic_node)
            root_nodes.append(synthetic_node["node_id"])
            stack.append((synthetic_node, 1, synthetic_id))

        if stack and level > stack[-1][1] + 1:
            repaired_level_count += 1

        block["heading_path_ids"] = [source_block_id for _, _, source_block_id in stack]
        node = make_node(block)
        if any(
            isinstance(flag, dict) and flag.get("code") == "SUSPECTED_HEADING_FRAGMENT"
            for flag in block.get("review_flags", [])
        ):
            ambiguous_heading_count += 1
        append_node(node)
        if stack:
            stack[-1][0]["child_node_ids"].append(node["node_id"])
        else:
            root_nodes.append(node["node_id"])
        stack.append((node, level, block["block_id"]))

    heading_confidences = [
        float(node["confidence"])
        for node in nodes
        if not str(node["source_block_id"]).startswith("synthetic_root_")
    ]
    review_flag_count = sum(len(block.get("review_flags") or []) for block in source_blocks)
    orphan_table_rows = sum(
        1
        for block in source_blocks
        if block.get("block_type") == "table_row"
        and any(
            isinstance(flag, dict) and flag.get("code") == "ORPHAN_TABLE_ROW"
            for flag in block.get("review_flags", [])
        )
    )
    if heading_confidences:
        base_confidence = sum(heading_confidences) / len(heading_confidences)
        penalty = (repaired_level_count * 0.04) + (review_flag_count * 0.01) + (orphan_table_rows * 0.05)
        overall_confidence: float | None = round(max(0.0, min(1.0, base_confidence - penalty)), 3)
    else:
        overall_confidence = None
    return {
        "schema_version": 2,
        "document_id": document_id,
        "artifact_version": None,
        "input_artifact_hashes": [],
        "nodes": nodes,
        "root_nodes": root_nodes,
        "running_content": [
            {
                "block_id": block["block_id"],
                "role": block["block_type"],
                "confidence": 0.8,
                "exclude_from_topic_content": True,
            }
            for block in source_blocks
            if block["block_type"] in {"running_header", "running_footer"}
        ],
        "quality": {
            "overall_confidence": overall_confidence if overall_confidence is not None else 0.5,
            "ambiguous_heading_count": ambiguous_heading_count if nodes else 1,
            "repaired_level_count": repaired_level_count,
            "review_required": bool(not nodes or repaired_level_count),
        },
    }


def build_asset_manifest(*, document_id: str) -> dict[str, Any]:
    return {"document_id": document_id, "artifact_version": None, "assets": []}


def build_markdown(
    source_blocks: list[dict[str, Any]],
    asset_manifest: dict[str, Any] | None = None,
) -> str:
    """Render source blocks as Markdown.

    Step D5 — `figure` blocks (introduced in Step A for image-only DOCX
    paragraphs) render inline as `![alt](dita_href)`. The `asset_manifest`
    argument supplies the `dita_href` and `caption`/`filename` for the
    `alt`. When `asset_manifest` is None (legacy callers), figure blocks
    fall back to a `![image](asset:{asset_id})` reference so the image is
    at least surfaced even without manifest resolution.
    """
    asset_by_id: dict[str, dict[str, Any]] = {}
    if asset_manifest:
        asset_by_id = {a["asset_id"]: a for a in asset_manifest.get("assets", []) if a.get("asset_id")}
    lines: list[str] = []
    for block in source_blocks:
        text = block["text"]
        block_type = block["block_type"]
        if block_type in {"running_header", "running_footer"}:
            continue
        if block_type == "figure":
            asset_refs = block.get("asset_refs") or []
            if not asset_refs:
                continue
            asset = asset_by_id.get(asset_refs[0])
            href = asset["dita_href"] if asset and asset.get("dita_href") else f"asset:{asset_refs[0]}"
            alt = (asset.get("caption") or asset.get("filename")) if asset else "image"
            lines.append(f"<!-- source:{block['block_id']} -->")
            lines.append(f"![{alt}]({href})")
            lines.append("")
            continue
        if block_type == "heading":
            lines.append(f"<!-- source:{block['block_id']} -->")
            lines.append(f"# {text}")
        elif block_type == "procedure_step":
            lines.append(f"<!-- source:{block['block_id']} -->")
            lines.append(f"1. {text}")
        else:
            lines.append(f"<!-- source:{block['block_id']} -->")
            lines.append(text)
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def build_topic_plan(
    *,
    document_id: str,
    source_blocks: list[dict[str, Any]],
    structure_tree: dict[str, Any],
    model_name: str,
) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    current_heading: dict[str, Any] | None = None
    current_blocks: list[dict[str, Any]] = []

    def flush() -> None:
        nonlocal current_heading, current_blocks
        content_blocks = [
            block
            for block in current_blocks
            if block["block_type"] not in {"running_header", "running_footer"}
        ]
        if not content_blocks:
            return
        title = current_heading["text"] if current_heading else _title_from_blocks(content_blocks)
        source_block_ids = [block["block_id"] for block in content_blocks]
        topic_type = _topic_type(content_blocks)
        candidate_id = f"tc_{slugify(title)}"
        candidates.append(
            {
                "topic_candidate_id": candidate_id,
                "title": title,
                "topic_type": topic_type,
                "source_block_ids": source_block_ids,
                "parent_candidate_id": None,
                "context_before": [],
                "context_after": [],
                "asset_refs": [],
                "boundary_confidence": 0.84 if current_heading else 0.64,
                "type_confidence": 0.84,
                "review_required": current_heading is None,
                "reason": "Candidate produced from inferred heading and adjacent source blocks."
                if current_heading
                else "No strong heading was found; the whole document was grouped for review.",
                "review_issues": []
                if current_heading
                else [
                    {
                        "code": "weak_heading_evidence",
                        "severity": "warning",
                        "message": "The document did not contain a high-confidence heading.",
                        "source_block_ids": source_block_ids,
                    }
                ],
            }
        )
        current_heading = None
        current_blocks = []

    for block in source_blocks:
        if block["block_type"] in {"running_header", "running_footer"}:
            continue
        if block["block_type"] == "heading":
            flush()
            current_heading = block
            current_blocks = [block]
        else:
            current_blocks.append(block)
    flush()
    if not candidates:
        candidates.append(
            {
                "topic_candidate_id": "tc_empty-document",
                "title": "Untitled topic",
                "topic_type": "concept",
                "source_block_ids": [source_blocks[0]["block_id"]] if source_blocks else ["blk_001"],
                "parent_candidate_id": None,
                "context_before": [],
                "context_after": [],
                "asset_refs": [],
                "boundary_confidence": 0.3,
                "type_confidence": 0.3,
                "review_required": True,
                "reason": "No usable source content was found.",
                "review_issues": [
                    {
                        "code": "empty_source",
                        "severity": "error",
                        "message": "No usable source content was extracted.",
                        "source_block_ids": [],
                    }
                ],
            }
        )
    review_required = any(candidate["review_required"] for candidate in candidates)
    return {
        "document_id": document_id,
        "artifact_version": "v1",
        "input_artifact_hashes": [sha256_text(json.dumps(source_blocks, sort_keys=True))],
        "topic_candidates": candidates,
        "map_outline": [
            {"topic_candidate_id": candidate["topic_candidate_id"], "children": []}
            for candidate in candidates
        ],
        "confidence": {
            "overall": 0.82 if not review_required else 0.62,
            "boundary": structure_tree["quality"]["overall_confidence"],
            "topic_type": 0.84,
            "map_structure": 0.8,
        },
        "review_required": review_required,
        "review_issues": [
            issue for candidate in candidates for issue in candidate.get("review_issues", [])
        ],
        "llm_metadata": {
            "agent_id": "topic-planning-agent",
            "skill_id": "topic-planning",
            "prompt_version": "1.0.0",
            "model": model_name,
            "repair_attempt": 0,
        },
    }


def build_generated_topic(
    *,
    candidate: dict[str, Any],
    source_blocks: list[dict[str, Any]],
    model_name: str,
    asset_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    by_id = {block["block_id"]: block for block in source_blocks}
    blocks = [by_id[block_id] for block_id in candidate["source_block_ids"] if block_id in by_id]
    body_blocks = [block for block in blocks if block["block_type"] != "heading"]
    # Step D5: pre-compute the asset_id → manifest entry lookup so each
    # `_block_content` call for a figure block resolves its `dita_href`/
    # `alt` without re-scanning the manifest list.
    asset_by_id: dict[str, dict[str, Any]] = {}
    if asset_manifest:
        asset_by_id = {a["asset_id"]: a for a in asset_manifest.get("assets", []) if a.get("asset_id")}
    topic_id = slugify(candidate["title"]).replace("-", "_")
    topic_type = candidate["topic_type"] if candidate["topic_type"] in TOPIC_TYPES else "concept"
    if topic_type == "task":
        steps = [
            {"source_block_ids": [block["block_id"]], "cmd": _inline_content(block["text"]), "info": []}
            for block in body_blocks
            if block["text"].strip()
        ]
        if not steps and body_blocks:
            steps = [
                {
                    "source_block_ids": [body_blocks[0]["block_id"]],
                    "cmd": _inline_content(body_blocks[0]["text"]),
                    "info": [],
                }
            ]
        if not steps and blocks:
            steps = [
                {
                    "source_block_ids": [blocks[0]["block_id"]],
                    "cmd": _inline_content(f"Review {candidate['title']}"),
                    "info": [],
                }
            ]
        body: dict[str, Any] = {"kind": "task", "prereq": [], "steps": steps, "result": []}
        target_root = "/task/taskbody/steps"
    elif topic_type == "reference":
        body = {
            "kind": "reference",
            "sections": [
                {
                    "title": None,
                    "content": [_block_content(block, asset_by_id) for block in body_blocks],
                    "source_block_ids": [block["block_id"] for block in body_blocks],
                }
            ]
            if body_blocks
            else [],
            "tables": [],
        }
        target_root = "/reference/refbody"
    elif topic_type == "troubleshooting":
        body = {
            "kind": "troubleshooting",
            "condition": [_block_content(block, asset_by_id) for block in body_blocks[:1]],
            "cause": [_block_content(block, asset_by_id) for block in body_blocks[1:2]],
            "remedy": [
                {"source_block_ids": [block["block_id"]], "cmd": _inline_content(block["text"]), "info": []}
                for block in body_blocks[2:]
            ],
        }
        target_root = "/troubleshooting/troublebody"
    elif topic_type == "glossary":
        terms = []
        for block in body_blocks:
            term, _, definition = block["text"].partition(":")
            terms.append(
                {
                    "term": _inline_content(term.strip() or block["text"]),
                    "definition": _block_content(
                        {**block, "text": definition.strip() or block["text"]}
                    ),
                    "source_block_ids": [block["block_id"]],
                }
            )
        if not terms and blocks:
            terms = [
                {
                    "term": _inline_content(candidate["title"]),
                    "definition": {
                        "content": _inline_content(candidate["title"]),
                        "source_block_ids": [blocks[0]["block_id"]],
                    },
                    "source_block_ids": [blocks[0]["block_id"]],
                }
            ]
        body = {"kind": "glossary", "terms": terms}
        target_root = "/glossentry"
    else:
        body = {
            "kind": "concept",
            "sections": [
                {
                    "title": None,
                    "content": [_block_content(block, asset_by_id) for block in body_blocks],
                    "source_block_ids": [block["block_id"] for block in body_blocks],
                }
            ]
            if body_blocks
            else [],
        }
        if body_blocks:
            body["shortdesc"] = _inline_content(body_blocks[0]["text"])
        target_root = "/concept/conbody"
    traceability = [
        {"target_path": f"/{topic_type}/title", "source_block_ids": [blocks[0]["block_id"]]}
    ]
    if body_blocks:
        traceability.append(
            {
                "target_path": target_root,
                "source_block_ids": [block["block_id"] for block in body_blocks],
            }
        )
    return {
        "topic_id": topic_id,
        "topic_candidate_id": candidate["topic_candidate_id"],
        "topic_type": topic_type,
        "title": candidate["title"],
        "source_block_ids": candidate["source_block_ids"],
        "language": "en-US",
        "asset_refs": [],
        "body": body,
        "traceability": traceability,
        "confidence": {
            "structure": 0.86,
            "inline_semantics": 0.78,
            "source_coverage": 0.9,
            "constraint_profile": 0.88,
        },
        "review_issues": [],
        "llm_metadata": {
            "agent_id": "dita-refactoring-agent",
            "skill_id": f"dita-{topic_type}-generation",
            "prompt_version": "1.0.0",
            "model": model_name,
            "repair_attempt": 0,
        },
    }


def build_dita_files(generated_topics: list[dict[str, Any]]) -> dict[str, str]:
    files: dict[str, str] = {}
    map_lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<map id="ditagen_map">', "  <title>DITAgen Export</title>"]
    for topic in generated_topics:
        filename = f"topics/{topic['topic_id']}.dita"
        files[filename] = _topic_to_xml(topic)
        map_lines.append(f'  <topicref href="{filename}"/>')
    map_lines.append("</map>")
    files["ditagen.ditamap"] = "\n".join(map_lines) + "\n"
    return files


def validate_dita_files(
    *, dita_files: dict[str, str], asset_manifest: dict[str, Any]
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for path, xml in dita_files.items():
        try:
            root = ET.fromstring(xml.encode("utf-8"))
        except ET.ParseError as exc:
            issues.append(
                {
                    "issue_id": f"val_{slugify(path)}_xml",
                    "severity": "error",
                    "code": "xml_not_well_formed",
                    "message": str(exc),
                    "path": path,
                }
            )
            continue
        if path.endswith(".dita") and root.tag not in {
            "concept",
            "task",
            "reference",
            "troubleshooting",
            "glossentry",
        }:
            issues.append(
                {
                    "issue_id": f"val_{slugify(path)}_root",
                    "severity": "error",
                    "code": "unsupported_topic_root",
                    "message": f"Unsupported DITA root element {root.tag}.",
                    "path": path,
                }
            )
        if path.endswith(".dita") and root.find("title") is None:
            issues.append(
                {
                    "issue_id": f"val_{slugify(path)}_title",
                    "severity": "error",
                    "code": "missing_title",
                    "message": "Topic is missing a title.",
                    "path": path,
                }
            )
    known_assets = {asset["dita_href"] for asset in asset_manifest.get("assets", [])}
    for path, xml in dita_files.items():
        for href in re.findall(r'<image[^>]+href="([^"]+)"', xml):
            if href not in known_assets:
                issues.append(
                    {
                        "issue_id": f"val_{slugify(path)}_image",
                        "severity": "error",
                        "code": "missing_image_asset",
                        "message": f"Referenced image {href} is not present in the asset manifest.",
                        "path": path,
                    }
                )
    return issues


def build_export_zip(
    *,
    document_id: str,
    topic_plan: dict[str, Any],
    generated_topics: list[dict[str, Any]],
    dita_files: dict[str, str],
    validation_issues: list[dict[str, Any]],
    markdown: str,
) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, content in dita_files.items():
            archive.writestr(path, content)
        archive.writestr("reports/topic-plan.json", json.dumps(topic_plan, indent=2, sort_keys=True))
        archive.writestr(
            "reports/generated-topics.json",
            json.dumps(generated_topics, indent=2, sort_keys=True),
        )
        archive.writestr(
            "reports/validation-report.json",
            json.dumps(
                {
                    "document_id": document_id,
                    "issue_count": len(validation_issues),
                    "issues": validation_issues,
                },
                indent=2,
                sort_keys=True,
            ),
        )
        archive.writestr("source/content.md", markdown)
    return output.getvalue()


def _topic_to_xml(topic: dict[str, Any]) -> str:
    topic_type = topic["topic_type"]
    if topic_type == "task":
        root = ET.Element("task", {"id": topic["topic_id"], "{http://www.w3.org/XML/1998/namespace}lang": "en-US"})
        ET.SubElement(root, "title").text = topic["title"]
        taskbody = ET.SubElement(root, "taskbody")
        steps_el = ET.SubElement(taskbody, "steps")
        for step in topic["body"].get("steps", []):
            step_el = ET.SubElement(steps_el, "step")
            cmd = ET.SubElement(step_el, "cmd")
            _append_inline(cmd, step["cmd"])
    elif topic_type == "reference":
        root = ET.Element("reference", {"id": topic["topic_id"], "{http://www.w3.org/XML/1998/namespace}lang": "en-US"})
        ET.SubElement(root, "title").text = topic["title"]
        body = ET.SubElement(root, "refbody")
        _append_sections(body, topic["body"].get("sections", []))
    elif topic_type == "troubleshooting":
        root = ET.Element("troubleshooting", {"id": topic["topic_id"], "{http://www.w3.org/XML/1998/namespace}lang": "en-US"})
        ET.SubElement(root, "title").text = topic["title"]
        body = ET.SubElement(root, "troublebody")
        for item in topic["body"].get("condition", []):
            p = ET.SubElement(body, "p")
            _append_inline(p, item["content"])
        for step in topic["body"].get("remedy", []):
            p = ET.SubElement(body, "p")
            _append_inline(p, step["cmd"])
    elif topic_type == "glossary":
        root = ET.Element("glossentry", {"id": topic["topic_id"], "{http://www.w3.org/XML/1998/namespace}lang": "en-US"})
        ET.SubElement(root, "glossterm").text = topic["title"]
        glossdef = ET.SubElement(root, "glossdef")
        for term in topic["body"].get("terms", []):
            p = ET.SubElement(glossdef, "p")
            _append_inline(p, term["definition"]["content"])
    else:
        root = ET.Element("concept", {"id": topic["topic_id"], "{http://www.w3.org/XML/1998/namespace}lang": "en-US"})
        ET.SubElement(root, "title").text = topic["title"]
        body = ET.SubElement(root, "conbody")
        _append_sections(body, topic["body"].get("sections", []))
    ET.indent(root, space="  ")
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode") + "\n"


def _append_sections(parent: ET.Element, sections: list[dict[str, Any]]) -> None:
    for section in sections:
        if section.get("title"):
            section_el = ET.SubElement(parent, "section")
            ET.SubElement(section_el, "title").text = section["title"]
        else:
            section_el = parent
        for item in section.get("content", []):
            # Step D5: figure-derived content items emit a DITA `<image>`
            # element directly under the section (not wrapped in `<p>`).
            # Carrying `kind="image"` + `href` on the item lets the
            # generator stay table-driven without sniffing inline-run
            # contents.
            if item.get("kind") == "image" and item.get("href"):
                image_attrs = {"href": item["href"]}
                if item.get("alt"):
                    image_attrs["placement"] = "inline"
                image_el = ET.SubElement(section_el, "image", image_attrs)
                if item.get("alt"):
                    alt_el = ET.SubElement(image_el, "alt")
                    alt_el.text = item["alt"]
                continue
            p = ET.SubElement(section_el, "p")
            _append_inline(p, item["content"])


def _append_inline(parent: ET.Element, runs: list[dict[str, Any]]) -> None:
    previous: ET.Element | None = None
    for run in runs:
        text = run.get("text", "")
        dita = run.get("dita")
        if dita in {"uicontrol", "codeph", "filepath", "term", "keyword"}:
            child = ET.SubElement(parent, dita)
            child.text = text
            previous = child
        elif previous is None and parent.text is None:
            parent.text = text
        elif previous is not None:
            previous.tail = (previous.tail or "") + text
        else:
            parent.text = (parent.text or "") + text


def _inline_content(text: str) -> list[dict[str, Any]]:
    text = text.strip()
    if not text:
        return []
    parts: list[dict[str, Any]] = []
    pattern = re.compile(r"(`[^`]+`|\b[A-Z][A-Z0-9_]{2,}\b|\b(?:Save|Install|Open|Choose|Select|Click|Press)\b)")
    cursor = 0
    for match in pattern.finditer(text):
        if match.start() > cursor:
            parts.append({"text": text[cursor : match.start()], "source_marks": []})
        token = match.group(0)
        if token.startswith("`"):
            parts.append({"text": token.strip("`"), "dita": "codeph", "source_marks": ["monospace"]})
        elif token.isupper() and len(token) > 2:
            parts.append({"text": token, "dita": "codeph", "source_marks": ["monospace"]})
        else:
            parts.append({"text": token, "dita": "uicontrol", "source_marks": ["bold"]})
        cursor = match.end()
    if cursor < len(text):
        parts.append({"text": text[cursor:], "source_marks": []})
    return parts


def _block_content(
    block: dict[str, Any],
    asset_by_id: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a content item for a single source block.

    Step D5: when `block_type == "figure"`, return an image-kind item
    so `_append_sections` emits a DITA `<image>` element. The `asset_by_id`
    lookup resolves `asset_refs[0]` to the manifest's `dita_href` / alt.
    Non-figure blocks return inline content as before.
    """
    if block["block_type"] == "figure":
        asset_refs = block.get("asset_refs") or []
        href = None
        alt = None
        if asset_refs and asset_by_id:
            asset = asset_by_id.get(asset_refs[0])
            if asset:
                href = asset.get("dita_href")
                alt = asset.get("caption") or asset.get("filename")
        if href is None and asset_refs:
            href = f"asset:{asset_refs[0]}"
            alt = alt or "image"
        return {
            "kind": "image",
            "href": href,
            "alt": alt,
            "content": [],
            "source_block_ids": [block["block_id"]],
        }
    return {"content": _inline_content(block["text"]), "source_block_ids": [block["block_id"]]}


def _source_marks(text: str) -> list[str]:
    marks: list[str] = []
    if "`" in text:
        marks.append("monospace")
    return marks


def _semantic_hint(text: str) -> str | None:
    if "`" in text or re.search(r"\b[A-Z][A-Z0-9_]{2,}\b", text):
        return "codeph"
    if re.search(r"\b(?:Click|Select|Press|Open|Choose)\b", text, flags=re.I):
        return "uicontrol"
    return None


def _looks_like_heading(text: str, index: int) -> bool:
    stripped = text.strip().strip("#")
    if index == 1 and len(stripped) <= 90:
        return True
    if len(stripped) > 90 or stripped.endswith((".", ":", ";", ",")):
        return False
    if re.match(r"^\d+(\.\d+)*\s+[A-Z]", stripped):
        return True
    words = stripped.split()
    if 1 <= len(words) <= 8 and sum(word[:1].isupper() for word in words) >= max(1, len(words) // 2):
        return True
    return False


def _block_type(text: str, *, index: int, repeated: bool) -> str:
    if repeated:
        return "running_header" if index <= 3 else "running_footer"
    if _looks_like_heading(text, index):
        return "heading"
    if re.match(r"^\s*(\d+[\.)]|[-*])\s+", text) or re.match(
        r"^(click|select|press|open|choose|install|run|enter|verify)\b", text, flags=re.I
    ):
        return "procedure_step"
    if "|" in text:
        return "table_row"
    if re.search(r"\b(warning|caution)\b", text, flags=re.I):
        return "warning"
    if re.search(r"\b(note|tip)\b", text, flags=re.I):
        return "note"
    return "paragraph"


def _topic_type(blocks: list[dict[str, Any]]) -> str:
    text = " ".join(block["text"] for block in blocks).lower()
    if any(block["block_type"] == "procedure_step" for block in blocks) or re.search(
        r"\b(click|select|press|install|run|verify)\b", text
    ):
        return "task"
    if re.search(r"\b(problem|cause|solution|troubleshoot|symptom)\b", text):
        return "troubleshooting"
    if re.search(r"\b(glossary|definition|means|refers to)\b", text):
        return "glossary"
    if "|" in text or re.search(r"\b(parameter|field|option|value)\b", text):
        return "reference"
    return "concept"


def _title_from_blocks(blocks: list[dict[str, Any]]) -> str:
    if not blocks:
        return "Untitled topic"
    title = blocks[0]["text"].strip()
    return title[:80] or "Untitled topic"


def _strip_list_marker(text: str) -> str:
    return re.sub(r"^\s*(\d+[\.)]|[-*])\s+", "", text).strip()


def _repeated_line_text(source_lines: list[dict[str, Any]]) -> set[str]:
    pages_by_text: dict[str, set[int]] = {}
    for line in source_lines:
        pages_by_text.setdefault(line["text"].strip(), set()).add(int(line["source_location"].get("page") or 1))
    return {text for text, pages in pages_by_text.items() if len(pages) >= 2 and len(text) <= 80}
