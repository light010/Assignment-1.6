"""Edit-operation algebra: pure data + pure replay function.

Phase 3 of `plans/logical-whistling-widget.md`. This package contains
zero IO, zero FastAPI, zero JsonStore — just pure functions over the
typed models in `ditagen_common.models`. Phase 6's review-service is
the layer that persists ops and triggers replay on change.
"""

from __future__ import annotations

from .replay import (
    ReplayError,
    SnapshotMismatchError,
    replay,
)

__all__ = [
    "ReplayError",
    "SnapshotMismatchError",
    "replay",
]
