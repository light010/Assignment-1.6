"""Pure deterministic replay of `EditOperation`s over an `ExtractionSnapshot`.

Phase 3 of `plans/logical-whistling-widget.md`. This module is pure:
no IO, no FastAPI, no JsonStore. Phase 6's review-service is the
layer that persists ops and triggers `replay()` on change.

Determinism guarantees (locked by tests):

1. **Pure function**: `replay(snapshot, ops)` returns a new
   `ProjectedState`; the input snapshot is never mutated.
2. **Deterministic**: same `(snapshot, ops)` produces byte-identical
   `model_dump(mode="json")` output. No wall-clock time, no random,
   no dict-iteration order leakage.
3. **Total**: every op variant is exhaustively dispatched. New op
   types must be added to the match block; the `assert_never` at the
   tail catches the gap at static-analysis time (mypy) and runtime.
4. **Snapshot immutability**: blocks/topics in the snapshot are
   `.model_copy(deep=True)`'d into the projection — replay never
   touches the inputs.

Derived block IDs are deterministic functions of `op_id`:

  Merge of N blocks  -> 1 new block  : blk_m_<sha1(op_id)[:12]>
  Split of 1 block   -> 2 new blocks : blk_s_<sha1(op_id+":a")[:12]>
                                       blk_s_<sha1(op_id+":b")[:12]>

This means the same op replayed twice yields the same projected ids,
which is what `test_replay_is_deterministic` asserts.
"""

from __future__ import annotations

import hashlib
from copy import deepcopy
from typing import assert_never

from ..models import (
    Block,
    EditOperation,
    ExtractionSnapshot,
    MergeOp,
    MoveOp,
    ProjectedState,
    RawXmlOverrideOp,
    RenameOp,
    RetypeOp,
    SplitOp,
    Topic,
)


class ReplayError(ValueError):
    """Raised when an op cannot be applied to the current projected state."""


class SnapshotMismatchError(ReplayError):
    """Raised when an op's `extraction_snapshot_id` doesn't match the snapshot."""


def replay(
    snapshot: ExtractionSnapshot,
    ops: list[EditOperation],
) -> ProjectedState:
    """Apply `ops` in order to `snapshot`, returning a new ProjectedState.

    Validation:
    - Every op must target `snapshot.snapshot_id`. Mismatch =>
      SnapshotMismatchError.
    - The parent_op_id chain must be either fresh (first op has None)
      or contiguous (op[i].parent_op_id == op[i-1].op_id).
    - Per-op preconditions (block exists, topic exists, char_offset
      in range, etc.) raise `ReplayError`.

    The snapshot is never mutated. A `model_copy(deep=True)` of every
    block and topic is taken before the dispatch loop.
    """
    _validate_chain(snapshot, ops)

    blocks: list[Block] = [b.model_copy(deep=True) for b in snapshot.blocks]
    topics: list[Topic] = [t.model_copy(deep=True) for t in snapshot.topics]
    traceability: dict[str, list[str]] = {b.block_id: [b.block_id] for b in blocks}

    for op in ops:
        if isinstance(op, MergeOp):
            blocks, topics, traceability = _apply_merge(op, blocks, topics, traceability)
        elif isinstance(op, SplitOp):
            blocks, topics, traceability = _apply_split(op, blocks, topics, traceability)
        elif isinstance(op, MoveOp):
            topics = _apply_move(op, blocks, topics)
        elif isinstance(op, RetypeOp):
            topics = _apply_retype(op, topics)
        elif isinstance(op, RenameOp):
            topics = _apply_rename(op, topics)
        elif isinstance(op, RawXmlOverrideOp):
            topics = _apply_raw_xml_override(op, topics)
        else:
            # Exhaustiveness gate: any new op variant must be added
            # above. mypy catches the gap statically; runtime catches
            # it for callers running without strict type checks.
            assert_never(op)

    return ProjectedState(
        snapshot_id=snapshot.snapshot_id,
        document_id=snapshot.document_id,
        blocks=blocks,
        topics=topics,
        ops_applied=[op.op_id for op in ops],
        traceability=traceability,
    )


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def _validate_chain(snapshot: ExtractionSnapshot, ops: list[EditOperation]) -> None:
    previous_op_id: str | None = None
    for index, op in enumerate(ops):
        if op.extraction_snapshot_id != snapshot.snapshot_id:
            raise SnapshotMismatchError(
                f"op[{index}] (op_id={op.op_id!r}, op_type={op.op_type!r}) targets "
                f"snapshot {op.extraction_snapshot_id!r}, expected {snapshot.snapshot_id!r}"
            )
        if op.parent_op_id != previous_op_id:
            raise ReplayError(
                f"op[{index}] (op_id={op.op_id!r}) has parent_op_id="
                f"{op.parent_op_id!r}, expected {previous_op_id!r} (chain integrity)"
            )
        previous_op_id = op.op_id


# ---------------------------------------------------------------------------
# Per-op handlers — pure: each takes the projected state and returns the next.
# ---------------------------------------------------------------------------


def _apply_merge(
    op: MergeOp,
    blocks: list[Block],
    topics: list[Topic],
    traceability: dict[str, list[str]],
) -> tuple[list[Block], list[Topic], dict[str, list[str]]]:
    by_id = {b.block_id: b for b in blocks}
    inputs: list[Block] = []
    for block_id in op.payload.block_ids:
        block = by_id.get(block_id)
        if block is None:
            raise ReplayError(
                f"merge op {op.op_id!r}: block_id {block_id!r} not found in projected state"
            )
        inputs.append(block)

    derived_id = f"blk_m_{hashlib.sha1(op.op_id.encode('utf-8')).hexdigest()[:12]}"
    derived_text = " ".join(b.text for b in inputs)
    derived = inputs[0].model_copy(
        update={
            "block_id": derived_id,
            "text": derived_text,
            "source_line_ids": [
                line_id for b in inputs for line_id in b.source_line_ids
            ],
            "lineage": list(op.payload.block_ids),
            "char_start": 0,
            "char_end": len(derived_text),
            "parent_block_id": None,
        },
        deep=True,
    )

    # Replace inputs with the derived block at the position of the first input.
    first_pos = blocks.index(inputs[0])
    new_blocks: list[Block] = [b for b in blocks if b.block_id not in set(op.payload.block_ids)]
    new_blocks.insert(first_pos, derived)

    # Drop traceability entries for the removed inputs; record the derived one.
    new_trace = {
        block_id: sources for block_id, sources in traceability.items()
        if block_id not in set(op.payload.block_ids)
    }
    # Lineage of the derived block traces back through any prior derivation.
    sources: list[str] = []
    for block_id in op.payload.block_ids:
        sources.extend(traceability.get(block_id, [block_id]))
    new_trace[derived_id] = sources

    # Update topics that reference any of the merged inputs.
    new_topics = [
        _replace_block_refs(topic, set(op.payload.block_ids), [derived_id])
        for topic in topics
    ]

    return new_blocks, new_topics, new_trace


def _apply_split(
    op: SplitOp,
    blocks: list[Block],
    topics: list[Topic],
    traceability: dict[str, list[str]],
) -> tuple[list[Block], list[Topic], dict[str, list[str]]]:
    by_id = {b.block_id: b for b in blocks}
    src = by_id.get(op.payload.block_id)
    if src is None:
        raise ReplayError(
            f"split op {op.op_id!r}: block_id {op.payload.block_id!r} not found"
        )
    if not (0 < op.payload.char_offset < len(src.text)):
        raise ReplayError(
            f"split op {op.op_id!r}: char_offset {op.payload.char_offset} out of "
            f"range for text of length {len(src.text)}"
        )

    op_seed = op.op_id.encode("utf-8")
    a_id = f"blk_s_{hashlib.sha1(op_seed + b':a').hexdigest()[:12]}"
    b_id = f"blk_s_{hashlib.sha1(op_seed + b':b').hexdigest()[:12]}"

    # Preserve raw text on each side; trimming is a callers' policy choice
    # (Phase 6 may add a per-op `trim` flag). Determinism wins for now.
    a_text = src.text[: op.payload.char_offset]
    b_text = src.text[op.payload.char_offset :]

    a_block = src.model_copy(
        update={
            "block_id": a_id,
            "text": a_text,
            "lineage": [src.block_id],
            "char_start": 0,
            "char_end": op.payload.char_offset,
        },
        deep=True,
    )
    b_block = src.model_copy(
        update={
            "block_id": b_id,
            "text": b_text,
            "lineage": [src.block_id],
            "char_start": op.payload.char_offset,
            "char_end": len(src.text),
        },
        deep=True,
    )

    src_pos = blocks.index(src)
    new_blocks: list[Block] = [b for b in blocks if b.block_id != src.block_id]
    new_blocks[src_pos:src_pos] = [a_block, b_block]

    src_sources = traceability.get(src.block_id, [src.block_id])
    new_trace = {
        block_id: sources for block_id, sources in traceability.items()
        if block_id != src.block_id
    }
    new_trace[a_id] = list(src_sources)
    new_trace[b_id] = list(src_sources)

    new_topics = [
        _replace_block_refs(topic, {src.block_id}, [a_id, b_id])
        for topic in topics
    ]

    return new_blocks, new_topics, new_trace


def _apply_move(op: MoveOp, blocks: list[Block], topics: list[Topic]) -> list[Topic]:
    # Validate the block exists in projected state.
    if op.payload.block_id not in {b.block_id for b in blocks}:
        raise ReplayError(
            f"move op {op.op_id!r}: block_id {op.payload.block_id!r} not found"
        )
    # Validate the target topic exists.
    if op.payload.target_topic_id not in {t.topic_id for t in topics}:
        raise ReplayError(
            f"move op {op.op_id!r}: target_topic_id {op.payload.target_topic_id!r} not found"
        )

    new_topics: list[Topic] = []
    for topic in topics:
        if topic.topic_id == op.payload.target_topic_id:
            if op.payload.block_id in topic.source_block_ids:
                # Already there; no-op for this topic.
                new_topics.append(topic.model_copy(deep=True))
            else:
                new_topics.append(
                    topic.model_copy(
                        update={
                            "source_block_ids": [
                                *topic.source_block_ids,
                                op.payload.block_id,
                            ]
                        },
                        deep=True,
                    )
                )
        else:
            new_topics.append(
                topic.model_copy(
                    update={
                        "source_block_ids": [
                            bid for bid in topic.source_block_ids
                            if bid != op.payload.block_id
                        ]
                    },
                    deep=True,
                )
            )
    return new_topics


def _apply_retype(op: RetypeOp, topics: list[Topic]) -> list[Topic]:
    if op.payload.topic_id not in {t.topic_id for t in topics}:
        raise ReplayError(
            f"retype op {op.op_id!r}: topic_id {op.payload.topic_id!r} not found"
        )
    return [
        topic.model_copy(update={"topic_type": op.payload.topic_type}, deep=True)
        if topic.topic_id == op.payload.topic_id
        else topic.model_copy(deep=True)
        for topic in topics
    ]


def _apply_raw_xml_override(op: RawXmlOverrideOp, topics: list[Topic]) -> list[Topic]:
    if op.payload.topic_id not in {t.topic_id for t in topics}:
        raise ReplayError(
            f"raw_xml_override op {op.op_id!r}: topic_id {op.payload.topic_id!r} not found"
        )
    return [
        topic.model_copy(update={"dita_xml": op.payload.xml}, deep=True)
        if topic.topic_id == op.payload.topic_id
        else topic.model_copy(deep=True)
        for topic in topics
    ]


def _apply_rename(op: RenameOp, topics: list[Topic]) -> list[Topic]:
    if op.payload.topic_id not in {t.topic_id for t in topics}:
        raise ReplayError(
            f"rename op {op.op_id!r}: topic_id {op.payload.topic_id!r} not found"
        )
    new_topics: list[Topic] = []
    for topic in topics:
        if topic.topic_id != op.payload.topic_id:
            new_topics.append(topic.model_copy(deep=True))
            continue
        update: dict[str, str | None] = {}
        if op.payload.title is not None:
            update["title"] = op.payload.title
        if op.payload.short_desc is not None:
            update["short_desc"] = op.payload.short_desc
        new_topics.append(topic.model_copy(update=update, deep=True))
    return new_topics


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _replace_block_refs(
    topic: Topic,
    removed_ids: set[str],
    inserted_ids: list[str],
) -> Topic:
    """Replace any of `removed_ids` in `topic.source_block_ids` with `inserted_ids`.

    The first occurrence is replaced in-place; subsequent occurrences (which
    only happen on duplicate refs, an invalid state) are dropped. If the
    topic has none of the removed_ids, the result is a deep copy of the
    original.
    """
    if not any(bid in removed_ids for bid in topic.source_block_ids):
        return topic.model_copy(deep=True)
    new_refs: list[str] = []
    inserted = False
    for bid in topic.source_block_ids:
        if bid in removed_ids:
            if not inserted:
                new_refs.extend(inserted_ids)
                inserted = True
            # else: skip; second occurrence collapses
        else:
            new_refs.append(bid)
    return topic.model_copy(update={"source_block_ids": new_refs}, deep=True)


# Re-export deepcopy so the signature in the tests is honest about
# what we use, even though the actual deep copy is via Pydantic's
# `model_copy(deep=True)`. Kept for any future direct usage in tests.
__all__ = ["ReplayError", "SnapshotMismatchError", "replay", "deepcopy"]
