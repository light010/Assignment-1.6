# DITAgen Architecture

This file is the navigation index for the DITAgen architecture records. Detailed architecture decisions are split into standalone Markdown files under `adr/`.

## Architecture Records

- [ADR 000: Architecture Index](adr/000-index.md)
- [ADR 001: Product Vision, Scope, And Metrics](adr/001-product-vision-and-scope.md)
- [ADR 002: System And Service Architecture](adr/002-system-and-service-architecture.md)
- [ADR 003: Processing Pipeline And DITA Model](adr/003-processing-pipeline-and-dita-model.md)
- [ADR 004: Data Stores, Events, And Contracts](adr/004-data-stores-events-and-contracts.md)
- [ADR 005: Agentic, LLM, And MCP Architecture](adr/005-agentic-llm-and-mcp-architecture.md)
- [ADR 006: Frontend, API, And User Workflows](adr/006-frontend-api-and-user-workflows.md)
- [ADR 007: Security, Operations, And Deployment](adr/007-security-operations-and-deployment.md)
- [ADR 008: Roadmap, Risks, And Open Decisions](adr/008-roadmap-risks-and-open-decisions.md)
- [ADR 009: Scalability, Bottlenecks, And Large Document Strategy](adr/009-scalability-bottlenecks-and-large-document-strategy.md)
- [ADR 010: Identity, Authorization, Tenancy, And Core Data Model](adr/010-identity-authorization-tenancy-and-data-model.md)
- [ADR 011: Off-The-Shelf Tools And Libraries](adr/011-off-the-shelf-tools-and-libraries.md)
- [ADR 012: DITA 1.3 Constraint Profiles And Element Governance](adr/012-dita-constraint-profiles-and-element-governance.md)
- [ADR 013: Topic JSON Generation From Messy Source](adr/013-topic-json-generation-from-messy-source.md)
- [ADR 014: Edit-Operation Algebra and Snapshot+Replay](adr/014-edit-operation-algebra-and-snapshot-replay.md)
- [ADR 015: review-service as edit-metadata owner](adr/015-review-service-as-edit-metadata-owner.md)

## System Summary

DITAgen converts messy source documents such as Word, PDF, PowerPoint, HTML, images, and scanned files into structured DITA content. The system extracts text, tables, images, metadata, inline formatting, and layout signals into canonical source artifacts, then uses deterministic services plus bounded LLM agents to produce reviewable topic plans, DITA-ready topic JSON, DITA topics, and maps.

The platform uses a microservice-oriented monorepo, object storage for large artifacts, a relational database for project state and metadata, an event bus for long-running jobs, and a modern frontend review workspace.

## Architecture Principles

- Deterministic pipeline first, bounded assistive agents second.
- Human approval for risky or user-visible changes.
- Source traceability from original document blocks to generated DITA.
- DITA validation before review and export.
- Multilingual handling as a first-class concern.
- Object storage for large artifacts; databases store metadata and state.
- Enterprise-scale documents are processed through manifests, block graphs, asset manifests, scoped jobs, and backpressure-aware queues.
- Identity, authorization, tenancy, and the core versioned content model are Phase 1 foundations.
- MCP is a controlled integration layer for agent context and tools, not the internal service bus.
- DITA 1.3 is the production target; project-specific element restrictions are enforced through versioned DITA constraint profiles.
- Topic generation is multi-pass: source evidence first, `topic-plan.json` second, `generated-topic.json` third, and deterministic DITA XML last.
