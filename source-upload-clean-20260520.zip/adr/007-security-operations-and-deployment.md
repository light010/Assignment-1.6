# ADR 007: Security, Operations, And Deployment

Status: Active

## Context

DITAgen processes customer source documents, generated technical content, LLM requests, agent traces, MCP integrations, and export packages. The system must be secure, auditable, observable, resumable, and deployable across local, staging, and production environments.

## Decision

Treat security, auditability, and observability as core architecture requirements. All long-running pipeline work is resumable and traceable.

## Security Requirements

- Authenticate all user-facing APIs.
- Authorize access by project and role.
- Scan uploads for malware where required.
- Validate file types and size limits.
- Isolate tenant data by project or organization.
- Encrypt data at rest and in transit.
- Avoid placing source document content in logs.
- Redact secrets and document text from LLM telemetry.
- Track all LLM requests for auditability.
- Keep provider API keys in a secrets manager.
- Support customer-managed keys for enterprise deployments when required.
- Make data retention configurable by project or organization.
- Treat agent tools as privileged API clients with explicit project, role, artifact, and skill permissions.
- Block hidden external network calls from agents and scripts in MVP.
- Treat MCP servers and tool metadata as untrusted until allowlisted and scoped.
- Require egress controls for server-side MCP connections to reduce SSRF and data exfiltration risk.
- Store MCP credentials as secret references, not plaintext project settings.
- Follow [ADR 010](010-identity-authorization-tenancy-and-data-model.md) for identity, authorization, tenancy, and audit principal rules.

## XML And Document Parsing Hardening

DITA and several source formats use XML internally. Extraction, validation, generation, and editor rendering must treat XML as an attack surface.

Rules:

- Use hardened XML parsers for Python services. Prefer `defusedxml` for stdlib parsing and hardened `lxml` settings when `lxml` is required.
- When using `lxml`, explicitly set `resolve_entities=False`, `load_dtd=False`, `no_network=True`, and `huge_tree=False` unless a signed, allowlisted validation package requires a narrower exception.
- Disable external entity resolution, XInclude, external DTD fetches, and external schema imports by default.
- Allow DTDs, schemas, and Schematron only from versioned, signed, allowlisted packages.
- Enforce XML document size, entity expansion, recursion, and parse-time limits.
- Sanitize SVG before storage and display; remove scripts, event attributes, and external references.
- Run DITA-OT in an isolated worker with restricted filesystem and network access.
- Do not run user-supplied XSLT.
- Protect ZIP-based formats such as DOCX, PPTX, ODT, and EPUB from zip-slip, path traversal, zip bombs, and polyglot file tricks.
- Maintain adversarial fixtures for XXE, entity expansion, path traversal, zip bombs, SVG script injection, and schema poisoning.

## Observability

Every service emits:

- Structured logs with `request_id`, `job_id`, `document_id`, and `project_id`.
- Metrics for job duration, queue latency, extraction failures, validation failures, token usage, and export duration.
- Distributed traces across API, queues, workers, storage, LLM calls, and agent calls.
- Agent traces for model calls, tool calls, handoffs, guardrails, approvals, and artifact hashes.
- Dead-letter queue records for failed events.

## SLOs And Capacity Targets

These are planning targets for MVP capacity and are not customer-facing SLAs until sales and support processes exist.

Availability targets:

- Gateway, project, review, audit, and identity APIs: 99.9% monthly.
- Extraction, normalization, analysis, LLM, validation, agent runtime, MCP Gateway, notification, and export workers: 99.5% monthly.

Latency targets:

- Read APIs: p95 under 300 ms for common project, topic, and document metadata reads.
- Write APIs: p95 under 800 ms for non-upload control-plane writes.
- WebSocket or SSE progress delivery: p95 under 500 ms after event receipt.

Pipeline targets:

- Well-formed source documents under 50 pages reach first reviewable draft within 10 minutes at p80.
- Scanned PDFs under 50 pages reach first reviewable draft within 25 minutes at p80.
- Large enterprise documents are processed asynchronously with progress visibility rather than synchronous time guarantees.

Capacity limits for MVP defaults:

- File size limit: 250 MB per file unless an enterprise profile raises it.
- Pages or slides per document: 1000 by default.
- Concurrent extraction, OCR, LLM, agent, and export jobs are quota-controlled per tenant.
- Error budget burn-rate alerts pause risky deploys for the affected service.

## Product Analytics

Track:

- Funnel from upload to export.
- Drop-off points by pipeline stage.
- Time spent in review.
- Most common validation errors.
- Most common source quality issues.
- Regeneration frequency and reason.
- Agent suggestion acceptance rate.
- Agent guardrail trip rate.
- Agent cost per accepted result.
- Topic approval rate.
- Manual edit distance by topic type.
- Cost per approved topic.
- Conversion profile performance.

Privacy rules:

- Use artifact IDs, hashes, metadata, and aggregate metrics.
- Avoid storing raw customer text in analytics events.
- Make analytics exportable for enterprise customers that require internal reporting.

## Failure Handling

The pipeline must be resumable.

Rules:

- Each stage writes immutable artifacts before publishing completion events.
- Jobs are idempotent by document ID, stage, and input artifact hash.
- Failed jobs move to a retryable state with a clear error category.
- Low-confidence extraction does not block a full project unless configured.
- Users can rerun extraction, analysis, LLM generation, validation, or export per document or topic.
- Agent runs can be cancelled, replayed from the same artifact versions, or superseded by newer artifact versions.

## Reliability, Backup, And Disaster Recovery

Recovery objectives:

- Tier 1 control-plane data, including identity, project, review, and audit metadata: RPO 15 minutes, RTO 4 hours for MVP.
- Object storage artifacts: RPO 15 minutes with versioning and replication where the deployment supports it.
- Worker queues are recoverable from primary stores and idempotent job records.

Backup strategy:

- PostgreSQL uses daily backups plus point-in-time recovery.
- Object storage uses versioning and lifecycle policies.
- Redis is treated as cache and rebuilt from primary stores.
- Search indexes are rebuilt from database and object storage records.

Restore and incident practice:

- Run restore drills at least quarterly.
- Maintain runbooks for LLM provider outage, OCR provider outage, DITA-OT failure, stuck jobs, DLQ triage, restore from backup, region failover, and cost anomalies.
- Audit logs are append-only and stored with stricter retention than project artifacts.

## Backend Technology Baseline

Recommended Python baseline:

- FastAPI for HTTP APIs.
- Pydantic for request, response, event, LLM, and agent schemas.
- SQLAlchemy or SQLModel for database access.
- Alembic for migrations.
- Celery, Dramatiq, RQ, or service-specific workers for async jobs.
- `uv` for dependency and environment management.
- Pytest for tests.
- Ruff for linting and formatting.
- OpenTelemetry for tracing.

Each service exposes:

- `/health/live`
- `/health/ready`
- `/metrics`
- Structured JSON logs.
- OpenAPI docs for HTTP APIs.
- Event contract tests for produced and consumed events.

## Build, Release, And Deployment Pipeline

CI requirements:

- Lint and format checks for Python and TypeScript.
- Unit, integration, and contract tests.
- OpenAPI, event schema, LLM schema, agent schema, and MCP policy validation.
- DITA 1.3, DITA constraint profile, Schematron, and blocked-element fixture validation.
- Type checks for Python and TypeScript.
- Secret scanning, dependency scanning, and container vulnerability scanning.
- Container image build with SBOM generation.
- Signed container images for release candidates and production releases.
- Provenance records for production artifacts.

Release requirements:

- Trunk-based development with short-lived branches.
- Staging deploy on merge to the main branch.
- Production deploy from signed release tags.
- Database migrations follow expand, migrate data, contract.
- Prompt, skill, schema, and policy changes run regression fixtures before promotion.
- DITA constraint profile changes run dry-run validation against representative topics before publication.
- Feature flags use an OpenFeature-compatible abstraction and are scoped by tenant, project, or user.

Supply-chain hardening:

- Use minimal production images such as distroless, Wolfi, or Chainguard-style images where dependency compatibility allows.
- Treat SLSA Build L2 practices as the near-term target and SLSA Build L3 as a maturity goal, not an MVP blocker.
- Evaluate in-toto attestations for signed build provenance once the release process stabilizes.
- Evaluate gVisor or equivalent sandboxing for adversarial-input workers such as extraction, OCR, DITA-OT, LibreOffice, and local STDIO MCP server runners.

## Local Development

Local development should run through Docker Compose.

Suggested local services:

- Frontend web app.
- API gateway.
- Core Python services.
- PostgreSQL.
- Redis.
- MinIO.
- Queue service.
- Optional local OCR worker.
- Optional local DITA-OT container.
- Optional local MCP test server.

Recommended commands:

```bash
docker compose up
```

```bash
uv run pytest
```

```bash
npm run test
```

## Deployment Model

Deploy each service as an independent container.

Recommended environments:

- `local`: Docker Compose.
- `staging`: Kubernetes or managed containers with production-like dependencies.
- `production`: Kubernetes or managed containers with autoscaling and managed storage.

Scaling notes:

- Extraction, OCR, LLM, validation, agent runtime, MCP Gateway, and export workers scale independently.
- Upload and review APIs prioritize low latency.
- LLM orchestration enforces concurrency and cost limits.
- Agent runtime workers enforce per-project concurrency limits.
- OCR and DITA-OT workers may need larger CPU and memory limits than API services.
