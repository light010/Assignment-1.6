# ADR 015: review-service as edit-metadata owner

Status: Active
Last verified: 2026-05-10

## Context

ADR-004 placed review state and edit metadata under `review-service`,
but Phases 0-5 left the service as a 3-line `create_service_app`
skeleton. The actual topic-mutation routes (PATCH, approve, reject,
assign-reviewer, regenerate) lived on `upload-service` because that's
where they grew up. That drift was one of the four root causes the
backend root-cause plan called out.

Phase 6 of `plans/logical-whistling-widget.md` stands the service up
and migrates the routes off `upload-service`. This ADR documents the
boundary, the persistence model, and the architecture invariants that
keep the boundary from drifting again.

## Decision

`review-service` owns the typed edit-operation surface and every
topic-mutation route. `upload-service` retains only ingestion and
read-side topic lookups. The boundary is structurally locked by two
architecture invariants in `scripts/check_architecture_invariants.py`.

## Routes

Implemented (Phase 6):

| Route | Owner | Notes |
|---|---|---|
| `POST /internal/topics/{topic_id}/ops` | review-service | Apply an EditOperation (see ADR-014). |
| `GET  /internal/documents/{document_id}/ops` | review-service | Ordered op log filtered to `edit.*`. |
| `POST /internal/documents/{document_id}/ops/undo` | review-service | Append inverse op for the chain head. |
| `POST /internal/topics/{topic_id}/assign-reviewer` | review-service | Migrated from upload-service. |
| `POST /internal/topics/{topic_id}/approve` | review-service | Migrated from upload-service. |
| `POST /internal/topics/{topic_id}/reject` | review-service | Migrated from upload-service. |

ADR-006 back-compat (Phase 6.D):

| Route | Owner | Behavior |
|---|---|---|
| `PATCH /v1/topics/{topic_id}` | api-gateway → upload-service | Upload-service translates body `{xml: str}` into a `RawXmlOverrideOp` and delegates to review-service via `POST /internal/topics/{id}/ops`. Single `topic.edited` event emitted by review-service; no double-counting. |

Retired (Phase 6.E):

- `POST /internal/topics/{id}/regenerate` and `regenerate-section` were
  stubs returning the unchanged topic. Deleted as dead surface; Phase
  8 brings them back via the real LLM provider once a generate-topic
  route on review-service or analysis-service exists.

## Persistence model

### Snapshot+projection split

Per ADR-014, the audit log is the canonical ledger of edits. But the
`state["topics"][record_id]` dict holds BOTH the immutable original
generated topic AND the mutable projected view:

```
state["topics"][rid] = {
  "topic_record_id": rid,
  "topic_id": ...,
  ...

  # IMMUTABLE — written once by analysis-service, never mutated.
  # ExtractionSnapshot replay reads this view.
  "generated_topic": {
    "topic_id": ...,
    "title": ...,
    "topic_type": ...,
    "source_block_ids": [...],
    "dita_xml": ...,
  },

  # MUTABLE — overwritten by review-service.apply_edit_op after each
  # replay. Frontend reads these top-level fields.
  "title": ...,
  "topic_type": ...,
  "source_block_ids": [...],
  "dita_xml": ...,
  "status": "edited",
  "validation_issues": [...],   # stamped by Phase 7
}
```

`_topic_from_state_dict` in review-service reads `generated_topic.*`
first when reconstructing the snapshot for replay, so the projection
is idempotent regardless of how many ops have already mutated the
top-level view. This discipline is documented in code and locked by
`tests/test_review_service_ops.py::test_undo_rename_restores_previous_title`
— which would fail (and did, before the fix) if the seed lacked the
immutable view.

### Audit-as-truth

Every successful op produces TWO audit events:

1. `edit.{op_type}` — the structural op itself, with the full
   `EditOperation` dump in `metadata.op`.
2. `topic.edited` — the domain event (per ADR-004's catalog), emitted
   to the audit-service via `emit_audit_event`.

`PATCH /v1/topics` does NOT emit `topic.edited` itself; review-service
is the single emitter. This is enforced by
`test_patch_topic_on_upload_delegates_to_review_via_raw_xml_override`
which asserts exactly one `topic.edited` event per legacy-shaped edit.

### Validation post-replay (Phase 7)

After replay, review-service calls validation-service synchronously
and writes the resulting `validation_issues` onto the projected topic
in the same `store.mutate` as the title/topic_type/source_block_ids/dita_xml
update. The 200ms latency budget is locked by
`tests/test_validation_service.py::test_validate_topic_latency_well_under_200ms`
so the workbench can surface issues inline without an async fetch.

## Architecture invariants

Two boundaries locked in `scripts/check_architecture_invariants.py`:

- **`topic_mutations_are_audited`** (activated in Phase 6): every
  service file that mutates `state["topics"]` must also contain an
  `audit()` or `emit_audit_event()` call.
- **`upload_service_owns_no_topic_post_routes`** (activated in
  Phase 6): AST-walks `services/upload-service/app/main.py` and
  rejects any `@app.post("/internal/topics/{...}")` decorator. This
  prevents drift back to the pre-Phase-6 state where topic mutations
  silently moved to upload.

## Consequences

Positive:
- Topic mutations have a single audit trail.
- Restart safety: review-service reconstructs the projected state
  from the audit log alone (cold-start test locks this).
- Adding a 7th `EditOperation` variant (ADR-014) automatically reaches
  review-service through the discriminated union — no route changes.

Negative:
- `state["topics"][rid]` carries duplicate fields (immutable vs
  projected). Disk cost is minor; conceptual cost is the
  snapshot/projection-discipline contributors must follow.
- Upload-service's `PATCH /v1/topics` adds a network hop to
  review-service. Acceptable for an internal call inside the same
  pod / cluster.

## Tests of record

- `tests/test_review_service_ops.py` — 16 tests, including per-op
  variants, error paths, audit envelope, cold-start byte-identical
  replay, undo for rename/retype/move, undo audit-event chain,
  PATCH delegation, Apple CA Merge+Undo end-to-end.
- `tests/test_architecture.py` — locks invariants for both
  `topic_mutations_are_audited` and `upload_service_owns_no_topic_post_routes`.
