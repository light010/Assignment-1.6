# ADR 000: Architecture Index

Status: Active

## Context

The original `architecture.md` grew into a large mixed document covering product scope, microservices, DITA processing, frontend workflows, agentic design, MCP, security, operations, and roadmap. The architecture is now split into standalone records so each topic can evolve without making the root document hard to maintain.

## Decision

Use the `adr/` folder as the detailed architecture source of truth. Keep the root `architecture.md` as a short navigation index.

## Records

- [ADR 001: Product Vision, Scope, And Metrics](001-product-vision-and-scope.md)
- [ADR 002: System And Service Architecture](002-system-and-service-architecture.md)
- [ADR 003: Processing Pipeline And DITA Model](003-processing-pipeline-and-dita-model.md)
- [ADR 004: Data Stores, Events, And Contracts](004-data-stores-events-and-contracts.md)
- [ADR 005: Agentic, LLM, And MCP Architecture](005-agentic-llm-and-mcp-architecture.md)
- [ADR 006: Frontend, API, And User Workflows](006-frontend-api-and-user-workflows.md)
- [ADR 007: Security, Operations, And Deployment](007-security-operations-and-deployment.md)
- [ADR 008: Roadmap, Risks, And Open Decisions](008-roadmap-risks-and-open-decisions.md)
- [ADR 009: Scalability, Bottlenecks, And Large Document Strategy](009-scalability-bottlenecks-and-large-document-strategy.md)
- [ADR 010: Identity, Authorization, Tenancy, And Core Data Model](010-identity-authorization-tenancy-and-data-model.md)
- [ADR 011: Off-The-Shelf Tools And Libraries](011-off-the-shelf-tools-and-libraries.md)
- [ADR 012: DITA 1.3 Constraint Profiles And Element Governance](012-dita-constraint-profiles-and-element-governance.md)
- [ADR 013: Topic JSON Generation From Messy Source](013-topic-json-generation-from-messy-source.md)
- [ADR 014: Edit-Operation Algebra and Snapshot+Replay](014-edit-operation-algebra-and-snapshot-replay.md)
- [ADR 015: review-service as edit-metadata owner](015-review-service-as-edit-metadata-owner.md)
- [ADR 016: Service-Owned Data Contracts](016-service-owned-data-contracts.md)

## System Summary

DITAgen converts messy source documents into reviewable DITA topics and maps. It supports source extraction, canonical source block artifacts, Markdown normalization as a review projection, topic planning, LLM-assisted DITA-ready topic JSON, validation, human review, and export.

The architecture is intentionally microservice-oriented, but early local development may run services together through Docker Compose. Large files and generated artifacts are stored in object storage. Project state, review state, event state, and governance metadata are stored in the relational database.

## Cross-Cutting Principles

- Preserve traceability from source document regions to Markdown blocks and generated DITA.
- Treat generated DITA as draft content until validation and human approval.
- Keep LLM and agent outputs schema-constrained and auditable.
- Use bounded agents and MCP only where they reduce user work without weakening control.
- Keep workflows resumable, observable, and safe for large document sets.
- Avoid direct token-count chunking; preserve topic boundaries through source block graphs and topic candidates.
- Decide identity, authorization, tenancy, and versioned data ownership before service implementation begins.
- Keep topic generation multi-pass and schema-constrained: source evidence, topic plan, generated topic JSON, deterministic DITA XML.

## Key Definitions

- Conversion profile: Versioned project configuration that defines target DITA version, allowed topic types, language defaults, templates, validation thresholds, filename rules, agent autonomy, and export policy.
- Artifact version: Immutable stored output from a pipeline stage, identified by stable ID, content hash, producer, input hashes, and version metadata.
- Confidence score: A 0-1 heuristic signal used for prioritization and review routing. It is not a calibrated probability unless explicitly calibrated later.
- Trust level: MCP server or integration classification such as `untrusted`, `approved_internal`, `approved_vendor`, or `customer_managed`.
- Cost tier: Operational hint for skills, tools, and agents: `low`, `medium`, or `high`, based on expected token, OCR, compute, and external-provider cost.
- Agent proposal: A non-binding generated suggestion that must be accepted before it changes project artifacts.
- DITA constraint profile: Versioned policy that defines target DITA version, allowed and blocked elements, attribute restrictions, preferred substitutions, validation severity, editor behavior, and export gates.
- Topic plan: Schema-valid LLM output that defines topic candidates, boundaries, topic types, parent-child relationships, and map outline before DITA-ready content is generated.
- Generated topic: Schema-valid LLM output for one topic candidate that contains DITA-ready semantic content, inline semantics, confidence, and traceability.
