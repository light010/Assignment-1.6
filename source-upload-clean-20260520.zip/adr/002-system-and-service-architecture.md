# ADR 002: System And Service Architecture

Status: Active

## Context

DITAgen needs separately scalable services for upload, extraction, normalization, analysis, generation, validation, review, export, agents, and integrations. Large document conversion is asynchronous and may involve CPU-heavy OCR, LLM calls, DITA-OT validation, object storage, and human review.

## Decision

Use a microservice-oriented monorepo. Services communicate through typed APIs for request/response interactions and an event bus for long-running pipeline stages.

## High-Level System

```mermaid
flowchart LR
    User[User] --> Frontend[Frontend Web App]
    Frontend --> Gateway[API Gateway]
    Gateway --> Identity[Identity Service]
    Gateway --> Upload[Upload Service]
    Gateway --> Project[Project Service]
    Gateway --> Review[Review Service]
    Gateway --> Terms[Terminology Service]
    Gateway --> Templates[Template Service]
    Gateway --> AgentRuntime[Agent Runtime Service]
    Gateway --> Skills[Skill And Script Registry]
    Gateway --> MCP[MCP Gateway]

    Upload --> ObjectStore[(Object Storage)]
    Upload --> Queue[(Event Bus)]

    Queue --> Extract[Extraction Service]
    Extract --> ObjectStore
    Extract --> Queue

    Queue --> Normalize[Markdown Normalization Service]
    Normalize --> ObjectStore
    Normalize --> Queue

    Queue --> Analyze[Document Analysis Service]
    Analyze --> Queue

    Queue --> LLM[LLM Orchestration Service]
    LLM --> LLMGateway[LLM Gateway]
    AgentRuntime --> LLM
    AgentRuntime --> LLMGateway
    AgentRuntime --> Skills
    AgentRuntime --> MCP
    AgentRuntime --> Audit[Audit Service]
    AgentRuntime --> Evaluation[Evaluation Service]
    MCP --> ExternalMCP[External MCP Servers]

    LLM --> DITA[DITA Generation Service]
    DITA --> Validate[DITA Validation Service]
    Validate --> ObjectStore
    Validate --> ProjectDB[(Project Database)]

    Review --> ProjectDB
    Review --> ObjectStore
    Review --> Audit
    Evaluation --> ProjectDB
    Gateway --> Notify[Notification Service]
    Notify --> Frontend
    Gateway --> Export[Export Service]
    Export --> ObjectStore
```

## Core Services

Frontend Web App:

- Upload documents and folders.
- Show extraction and conversion progress.
- Display source previews, extracted Markdown, generated DITA, validation issues, agent activity, and approval state.
- Provide topic editing, reviewer assignment, comments, approval, rejection, and scoped regeneration.
- Support multilingual editing, terminology hints, and export workflows.

API Gateway:

- Public HTTP API for the frontend.
- Authentication, authorization, routing, upload sessions, rate limiting, and API versioning.

Identity Service:

- Broker OIDC authentication, token refresh, session revocation, service accounts, and personal access tokens.
- Own user identity records, session metadata, and token lifecycle audit events.

Upload Service:

- Accept resumable large uploads.
- Store originals in object storage.
- Detect file type and metadata.
- Publish extraction jobs.

Extraction Service:

- Extract text, images, tables, comments, notes, headings, page numbers, layout hints, and OCR content.
- Use tools such as `python-docx`, OOXML traversal, PyMuPDF, pdfplumber, `python-pptx`, LibreOffice conversion, OCR engines, and structured parsers.
- Store extracted assets with stable IDs.

Markdown Normalization Service:

- Convert raw extraction artifacts into normalized Markdown.
- Repair heading hierarchy where possible.
- Normalize tables, lists, notes, code blocks, captions, and cross references.
- Attach source traceability metadata to Markdown blocks.
- Treat Markdown as a reviewer-facing projection of canonical source blocks, not as the sole source of truth.

Document Analysis Service:

- Detect language per document, section, paragraph, and topic candidate.
- Build source blocks, style profiles, structure trees, and hierarchy evidence from messy source content.
- Identify structure, topic boundaries, duplicate content, repeated headers and footers, broken tables, warnings, procedures, reusable definitions, inline semantic hints, and low-confidence OCR regions.
- Produce or orchestrate `topic-plan.json` before per-topic DITA refactoring.

LLM Orchestration Service:

- Build prompts from normalized Markdown, topic plans, terminology, templates, and project settings.
- Call configured providers through the LLM Gateway and provider abstraction.
- Enforce structured output schemas.
- Record model, prompt, input hash, output hash, token usage, and cost metadata.
- Use separate schema-constrained passes for topic planning and per-topic `generated-topic.json`; do not request production DITA XML directly from the model.

LLM Gateway:

- Centralize provider credentials, model routing, retries, fallbacks, rate limits, request timeouts, token and cost accounting, and LLM telemetry.
- Expose an OpenAI-compatible model-call interface where possible while keeping provider-specific capabilities behind feature flags.
- Avoid owning artifact state, approvals, publishing, or validation decisions.

Agent Runtime Service:

- Run bounded assistive agents for triage, planning, DITA refactoring, asset context, validation explanation, and review assistance.
- Enforce max turns, timeouts, budgets, allowed tools, approval policies, and project autonomy settings.
- Persist traces, tool calls, handoffs, guardrails, model metadata, cost estimates, artifact versions, and hashes.

DITA Generation Service:

- Convert approved, validated `generated-topic.json` into DITA XML.
- Generate `concept`, `task`, `reference`, `troubleshooting`, `glossary`, and `map` content, plus relationship tables, IDs, filenames, links, image references, and language attributes.
- Apply the active DITA constraint profile through the DITA Element Policy Engine before XML is written.
- Record element substitutions and lossy or unresolved constraint decisions as reviewable issues.

DITA Validation Service:

- Validate XML, topic type rules, maps, links, keys, image references, IDs, and language metadata.
- Run DITA-OT, XML schema validation, Schematron, and custom business rules.
- Run DITA constraint profile checks and block export on unresolved error-severity violations.

Review Service:

- Store review state.
- Serve editable topics, generated Markdown, validation errors, comments, and source previews.
- Track approvals, rejections, overrides, and reviewer notes.

Export Service:

- Build DITA source ZIPs.
- Optionally run DITA-OT to produce HTML, PDF, or other outputs.
- Include conversion reports, traceability reports, and validation summaries.

Project Service:

- Manage projects, document sets, settings, locales, users, roles, permissions, conversion profiles, DITA constraint profile bindings, quality gates, and export policy.

Terminology Service:

- Manage approved terms, forbidden terms, abbreviations, aliases, translations, and definitions by organization, project, language, and product line.

Template Service:

- Manage DITA topic templates, map templates, naming conventions, metadata rules, reusable prompt fragments, DITA constraint profile versions, and template versions.

Skill And Script Registry:

- Manage versioned skills and deterministic scripts used by agents.
- Store owner, version, schemas, permissions, timeout, cost tier, approval requirement, and project scope.

MCP Gateway:

- Manage approved Model Context Protocol server connections.
- Discover MCP tools, resources, and prompts.
- Normalize MCP capabilities into DITAgen tool, resource, and prompt contracts.
- Enforce project, user, role, server, tool, resource, and approval policy.

Audit Service:

- Record upload, extraction, generation, validation, edit, approval, export, admin, agent, skill, and MCP events.

Evaluation Service:

- Score generated output against validation, human edits, approval decisions, test fixtures, prompt versions, agent results, and tool-call outcomes.

Notification Service:

- Send job status, failure, completion, review assignment, and validation blocker notifications through WebSocket, Server-Sent Events, email, or in-app notifications.

## Folder Structure

```text
DITAgen/
  architecture.md
  adr/
    000-index.md
    001-product-vision-and-scope.md
    002-system-and-service-architecture.md
    003-processing-pipeline-and-dita-model.md
    004-data-stores-events-and-contracts.md
    005-agentic-llm-and-mcp-architecture.md
    006-frontend-api-and-user-workflows.md
    007-security-operations-and-deployment.md
    008-roadmap-risks-and-open-decisions.md
    009-scalability-bottlenecks-and-large-document-strategy.md
    010-identity-authorization-tenancy-and-data-model.md
    011-off-the-shelf-tools-and-libraries.md
    012-dita-constraint-profiles-and-element-governance.md

  apps/
    web/
      src/
        features/
          upload/
          projects/
          source-quality/
          topic-planning/
          review-workspace/
          dita-editor/
          validation/
          terminology/
          templates/
          dita-constraints/
          agent-activity/
          ask-assistant/
          exports/
          activity/
          settings/

  services/
    identity-service/
    api-gateway/
    upload-service/
    extraction-service/
    markdown-service/
    analysis-service/
    llm-service/
    llm-gateway-service/
    agent-runtime-service/
    dita-service/
    validation-service/
    review-service/
    terminology-service/
    template-service/
    skill-registry-service/
    mcp-gateway-service/
    audit-service/
    evaluation-service/
    export-service/
    notification-service/

  packages/
    python/
      common/
      dita-models/
    typescript/
      api-client/
      ui/

  infrastructure/
    docker/
    k8s/
    terraform/
    scripts/

  database/
    migrations/
    seeds/
    schema/

  contracts/
    openapi/
    events/
    llm/
    agents/
    mcp/

  docs/
    product/
    decisions/
    api/
    operations/
    security/
    user-workflows/

  tests/
    integration/
    e2e/
    fixtures/

  tools/
    local-dev/
    data-migration/
    prompt-evaluation/
    dita-validation/
```

## Consequences

- Services can scale independently for extraction, OCR, LLM, validation, agents, MCP, and export.
- Each service needs clear contracts and observability from the start.
- Local development should hide operational complexity behind Docker Compose.
- The service map is intentionally broad, but early implementation may deploy related services together while preserving boundaries in code.
