# ADR 004: Data Stores, Events, And Contracts

Status: Active

## Context

DITAgen processes large source files, extracted assets, generated DITA, review state, agent traces, validation logs, and export packages. The database must not become a dumping ground for large artifacts.

## Decision

Use object storage for large immutable artifacts, PostgreSQL for metadata and workflow state, an event bus for asynchronous jobs, Redis for short-lived state, and explicit contracts for APIs, events, LLM outputs, agent outputs, and MCP policies.

## Project Database

Use PostgreSQL or a compatible relational database.

Stores:

- Tenants and organizations.
- Users, teams, roles, permissions.
- Service accounts, personal access tokens, and session metadata.
- Projects and document sets.
- Conversion profiles.
- DITA constraint profiles, profile versions, rules, substitutions, violations, and substitution records.
- Templates and template versions.
- Terminology metadata.
- Agent definitions and enabled skills.
- Agent run state, approval requests, and trace metadata.
- MCP server registrations, capability snapshots, scopes, and connection health.
- Document metadata.
- Job status.
- Topic plans.
- Review states.
- Validation issues.
- Export records.
- LLM audit metadata.
- Append-only audit events.
- Product analytics aggregates.

## Object Storage

Use S3-compatible storage such as AWS S3, MinIO, GCS, or Azure Blob Storage.

Stores:

- Original uploaded files.
- Extracted raw artifacts.
- Normalized Markdown.
- Images and media assets.
- Generated DITA XML.
- Export packages.
- Large agent traces and tool outputs.
- Logs and reports too large for the database.

## Event Bus

Use RabbitMQ, Kafka, Redis Streams, or a cloud-native queue. The event bus coordinates long-running and retryable stages.

Events:

- `auth.login.succeeded`
- `auth.login.failed`
- `auth.token.created`
- `auth.token.revoked`
- `document.uploaded`
- `document.manifest.created`
- `document.extraction.requested`
- `document.extraction.completed`
- `source.blocks.extracted`
- `assets.extracted`
- `markdown.normalization.completed`
- `document.analysis.completed`
- `topic.plan.created`
- `topic.plan.approved`
- `topic.boundaries.proposed`
- `topic.boundaries.review_required`
- `asset.alt_text.required`
- `dita.generation.requested`
- `dita.generation.completed`
- `dita.validation.completed`
- `dita.constraint_profile.created`
- `dita.constraint_profile.published`
- `dita.constraint_profile.enabled`
- `dita.constraint_profile.deprecated`
- `dita.element.substituted`
- `dita.constraint.violation_detected`
- `dita.constraint.override_recorded`
- `topic.review.requested`
- `topic.approved`
- `topic.rejected`
- `topic.regeneration.requested`
- `topic.edited` — emitted by review-service after every successful EditOperation replay (Phase 6).
- `edit.merge` — typed structural edit; metadata.op carries the full EditOperation envelope (ADR-014).
- `edit.split`
- `edit.move`
- `edit.retype`
- `edit.rename`
- `edit.raw_xml_override` — ADR-006 PATCH /v1/topics back-compat; metadata.op.is_lossy is always true.
- `document.analysis.fallback_triggered` — emitted by analysis-service when the primary LLM provider fails and the pipeline falls back to fixture-deterministic (Phase 8).
- `agent.run.started`
- `agent.tool.requested`
- `agent.tool.completed`
- `agent.guardrail.triggered`
- `agent.approval.required`
- `agent.run.completed`
- `skill.version.enabled`
- `mcp.server.registered`
- `mcp.capabilities.discovered`
- `mcp.tool.requested`
- `mcp.tool.completed`
- `mcp.policy.blocked`
- `audit.event.recorded`
- `export.smoke_build.completed`
- `export.completed`
- `job.failed`

Event envelope:

- `event_id`: ULID.
- `event_type`: one of the versioned event names.
- `event_version`: semantic event schema version.
- `tenant_id`, `organization_id`, and optional `project_id`.
- `actor_type` and `actor_id`.
- `correlation_id` and `causation_id`.
- `resource_type` and `resource_id`.
- `artifact_versions` when the event refers to generated or extracted artifacts.
- `occurred_at` and `published_at`.

Delivery rules:

- Event producers use the outbox pattern when publishing from database-backed transactions.
- Consumers are idempotent and tolerate duplicate delivery.
- Consumers reject unknown major event versions and tolerate additive minor versions.
- Poison messages move to a dead-letter queue with failure category, retry count, and recovery action.

Job orchestration:

- MVP may use queue-backed workers for straightforward stages.
- Multi-step document conversion jobs persist explicit stage state in the Project Database.
- If cross-service compensation grows complex, introduce Temporal or an equivalent workflow engine before Phase 2 scale-out.
- Long-running jobs are resumable from the last completed artifact version.

## Cache

Use Redis or equivalent for:

- Short-lived upload sessions.
- Job progress snapshots.
- API response caching.
- Distributed locks.
- WebSocket fanout support.

## Search Index

Use OpenSearch, Elasticsearch, PostgreSQL full-text search, or equivalent if users need fast lookup.

Searchable content:

- Project names and document names.
- Extracted Markdown.
- Generated topic titles.
- Topic IDs and filenames.
- Validation issue text.
- Comments and review notes.
- Terminology entries.
- Agent run goals, approval requests, and tool summaries.
- MCP resource names and approved capability metadata.

## Optional Vector Store

Use a vector store only if retrieval is needed for terminology, prior conversions, reusable snippets, semantic duplicate detection, or retrieval-assisted review. It is optional so the core conversion path does not depend on vector search.

Default path:

- Start with PostgreSQL full-text search.
- Use pgvector if early semantic search can remain inside PostgreSQL operational limits.
- Move to Qdrant or an equivalent vector database when vector volume, payload filtering, hybrid retrieval, recall tuning, or horizontal scaling exceed PostgreSQL comfort.

## Contract Folders

```text
contracts/
  openapi/
    api-gateway.yaml
    identity-service.yaml
    review-service.yaml
    agent-runtime-service.yaml
    skill-registry-service.yaml
    mcp-gateway-service.yaml

  events/
    document-events.schema.json
    auth-events.schema.json
    job-events.schema.json
    dita-events.schema.json
    review-events.schema.json
    terminology-events.schema.json
    audit-events.schema.json
    agent-events.schema.json
    skill-events.schema.json
    mcp-events.schema.json

  llm/
    topic-plan.schema.json
    topic-candidate.schema.json
    generated-topic.schema.json
    confidence-score.schema.json
    dita-constraint-profile.schema.json
    dita-element-rule.schema.json
    dita-substitution-rule.schema.json
    dita-element-policy-result.schema.json
    dita-constraint-violation.schema.json

  artifacts/
    document-manifest.schema.json
    source-line.schema.json
    source-block.schema.json
    style-profile.schema.json
    structure-tree.schema.json
    asset-manifest.schema.json
    export-log.schema.json

  agents/
    agent-run.schema.json
    agent-tool.schema.json
    agent-trace.schema.json
    skill-manifest.schema.json
    approval-request.schema.json

  mcp/
    mcp-server-registration.schema.json
    mcp-capability-snapshot.schema.json
    mcp-tool-policy.schema.json
```

## Idempotency And Versioning

- Jobs are idempotent by document ID, stage, and input artifact hash.
- Agent runs are idempotent by agent version, skill versions, prompt version, input artifact hashes, and project configuration.
- All long-running or mutating write APIs accept idempotency keys, including upload completion, generation, regeneration, agent runs, export, MCP capability enablement, and approval actions.
- APIs that expose generated content include artifact version IDs.
- Tool calls with stale artifact versions are rejected.
- Event consumers must tolerate duplicate delivery.

## Core Data Ownership

- Identity Service owns users, sessions, service accounts, and token records.
- Project Service owns tenants, organizations, projects, memberships, conversion profiles, and project settings.
- Review Service owns topic review state, assignments, comments, approvals, and edit metadata.
- Artifact ownership is split by producer service, but artifact metadata follows a shared `Artifact` and `ArtifactVersion` contract.
- Audit Service receives append-only audit events from every service.
- Cross-service references use stable IDs and artifact versions rather than direct table writes.

## Large Artifact Rules

- Store large source files, Markdown artifacts, images, DITA XML, export packages, logs, and traces in object storage.
- Store only metadata, references, hashes, states, and summaries in PostgreSQL.
- Multipart upload is required for large source files.
- Validation and export logs are stored as object storage artifacts and linked from database records.
- Document manifests, source block JSONL, asset manifests, and topic candidates are versioned artifacts.
- Large trace and log artifacts are referenced by hash and artifact version.
