# ADR 010: Identity, Authorization, Tenancy, And Core Data Model

Status: Active

## Context

Identity, authorization, tenancy, and the core data model are foundational decisions. They affect every API, event, audit record, object storage key, service boundary, agent run, MCP call, and export package. These decisions should be made before Phase 1 schemas and service contracts are finalized.

## Decision

Use a shared-tenant platform model for MVP with explicit tenant IDs, centralized identity, policy-based authorization, tenant-scoped object storage prefixes, and immutable version records for documents, artifacts, topics, templates, terminology, skills, and exports.

## Identity And Authentication

Every request, event, agent run, and stored artifact resolves to a known principal.

Principals:

- Human users.
- Service accounts for backend service-to-service calls.
- Personal access tokens for programmatic user access.
- External MCP clients when DITAgen later exposes a hosted MCP server.

Identity provider model:

- MVP supports OIDC through a managed identity provider.
- Internal email/password can be used only for local development and trial environments.
- Enterprise SSO through SAML and SCIM provisioning is Phase 3 unless required by a launch customer.

Session model:

- Short-lived access tokens.
- Rotating refresh tokens stored server-side and revocable.
- Access token claims include `sub`, `tenant_id`, `org_id`, roles, scopes, and session ID.
- Idle and absolute session timeouts are configurable per organization.

Step-up authentication is required for:

- Enabling MCP servers.
- Changing organization-level templates, retention, or security settings.
- Approving destructive agent actions.
- Exporting outside the platform.

Service-to-service authentication:

- Production services use mTLS or platform workload identity.
- Signed service tokens are allowed only where mTLS is unavailable.
- Every service call carries tenant, actor, and request correlation metadata.

Programmatic access:

- Personal access tokens are scoped to one user and explicit projects.
- Service accounts are owned by an admin and scoped to an organization or project.
- Tokens carry scopes, expiration, and last-used timestamps.

## Authorization And Permissions

Authorization is enforced at three layers:

- API Gateway for coarse route and token checks.
- Each service for resource and action checks.
- Agent Runtime and MCP Gateway for tool, skill, and external capability checks.

Resource hierarchy:

- Tenant.
- Organization.
- Project.
- Document set.
- Document.
- Topic.
- Agent run.
- Skill version.
- MCP server.
- Template version.
- Terminology list.
- Export package.

Action vocabulary:

- `read`, `list`, `create`, `update`, `delete`.
- `approve`, `reject`, `override`.
- `regenerate`, `export`, `publish`.
- `run_agent`, `approve_agent_action`, `cancel_agent_run`.
- `register_mcp_server`, `enable_mcp_capability`.
- `change_template`, `change_terminology`, `change_conversion_profile`.
- `change_dita_constraint_profile`, `publish_dita_constraint_profile`, `override_dita_constraint`.

MVP roles:

- `org_admin`: Full organization control.
- `project_admin`: Full project control.
- `information_architect`: Templates, conversion profiles, DITA constraint profiles, terminology, and topic plans.
- `editor`: Topic edits, comments, regeneration requests, and review submissions.
- `reviewer`: Topic review, comments, approvals, and rejections.
- `localization_manager`: Language settings and localization exports.
- `viewer`: Read-only project access.
- `service_account`: Programmatic access scoped to declared actions.

Policy model:

- Use a central policy evaluator. OPA, Cedar, or an equivalent library are acceptable choices.
- Prefer Cedar as the first application-authorization candidate if its principal-action-resource-context model cleanly covers DITAgen projects, documents, topics, agents, skills, and MCP resources.
- Prefer OPA for platform policy, Kubernetes admission, CI/CD policy checks, and broad infrastructure guardrails where its ecosystem is stronger.
- Policies are versioned and tested in CI.
- Services log the policy decision, resource, action, and rule ID for auditability.
- Agents inherit a narrowed subset of the invoking user's permissions and never receive broader access.
- Approvers cannot approve their own edits unless the project explicitly allows single-user mode.

## Multi-Tenancy Model

Tenancy strategy:

- MVP uses a pooled model: shared database schema with `tenant_id` on every tenant-owned row.
- Enterprise bridge model, schema-per-tenant, is reserved for regulated customers.
- Silo model, database-per-tenant, is reserved for large enterprise contracts with customer-managed keys or storage.

PostgreSQL protections:

- `tenant_id` exists on every tenant-owned table.
- Row Level Security is enabled where practical.
- Application queries must include tenant filters.
- Tenant-isolation tests run in CI for every schema change.

Object storage layout:

- Top-level bucket per environment.
- Prefix format: `tenants/{tenant_id}/projects/{project_id}/...`.
- Enterprise deployments may use per-tenant buckets or customer-managed storage.
- Tenant-scoped lifecycle and retention policies are applied where possible.

Tenant controls:

- Storage quota.
- Documents per project quota.
- Concurrent extraction, OCR, LLM, agent, validation, and export jobs.
- API request limits.
- Monthly LLM and OCR cost budgets.

Tenant lifecycle:

- Provision creates default templates, terminology, and a starter conversion profile.
- Suspension pauses new work and keeps existing resources read-only.
- Deletion runs through export, cooling-off, purge, and audit-retention phases.

## Core Data Model

Identifier conventions:

- Public IDs use ULID for sortable, URL-safe identifiers.
- Artifact hashes use SHA-256 over canonical content.
- Object keys include stable IDs and content hashes where useful for deduplication.

Core entities:

- `Tenant`
- `Organization`
- `User`, `ServiceAccount`, `Role`, `Membership`
- `Project`, `ConversionProfile`, `Template`, `TerminologyList`
- `DitaConstraintProfile`, `DitaConstraintProfileVersion`, `DitaConstraintRule`, `DitaSubstitutionRule`
- `Document`, `DocumentVersion`
- `Artifact`, `ArtifactVersion`
- `Topic`, `TopicVersion`, `TopicGeneration`, `TopicEdit`
- `ReviewAssignment`, `Comment`, `Approval`, `RegenerationRequest`
- `AgentRun`, `AgentTrace`, `AgentApprovalRequest`
- `SkillManifest`, `SkillVersion`, `ScriptVersion`
- `MCPServer`, `MCPCapabilitySnapshot`, `MCPToolPolicy`
- `Export`, `ExportPackage`
- `DitaConstraintViolation`, `DitaElementSubstitution`
- `AuditEvent`

Versioning model:

- `Document`, `Topic`, `Template`, `TerminologyList`, `ConversionProfile`, `DitaConstraintProfile`, and `SkillManifest` have immutable version tables.
- The mutable parent record points to the current version.
- Deleting a parent is a soft delete until retention and legal requirements are satisfied.
- Every artifact version stores input artifact hashes for reproducibility.

Textual ERD:

- `Tenant` 1 to N `Organization`
- `Organization` 1 to N `Project`
- `Project` 1 to N `Document` 1 to N `DocumentVersion`
- `DocumentVersion` 1 to N `Artifact` 1 to N `ArtifactVersion`
- `Project` 1 to N `Topic` 1 to N `TopicVersion`
- `TopicVersion` N to 1 `TopicGeneration`
- `TopicVersion` 1 to N `TopicEdit`
- `Topic` 1 to N `ReviewAssignment` 1 to N `Approval`
- `AgentRun` N to 1 `User` and N to 1 `Project`
- `AgentRun` 1 to N `AgentTrace` and `AgentApprovalRequest`
- `Export` references many `TopicVersion` and `ArtifactVersion` records by ID

## Audit And Privacy Boundary

- Audit records are append-only.
- Audit records avoid storing raw source text.
- PII-bearing audit fields are minimized and can be pseudonymized on erasure requests.
- Legal hold can extend audit retention beyond project or tenant retention.
- Security-sensitive changes record actor, subject, tenant, project, action, resource, policy result, and request ID.
