# ADR 012: DITA 1.3 Constraint Profiles And Element Governance

Status: Active

## Context

DITAgen will generate production DITA 1.3 output. Customers may also have house rules that block or discourage some DITA elements, restrict attributes, require preferred replacements, or apply different rules by topic type. The system must respect those rules during generation and editing, not only catch them at export time.

DITA 1.3 has a formal constraint mechanism that can restrict content models, attributes, and domains while keeping valid constrained documents conformant with the original grammar. DITAgen should align with that model, but product users also need a practical UI and policy format for rules such as "do not use `<section>` in task topics" or "prefer `<image>` over `<fig>` when captions are weak."

## Decision

Use versioned DITA constraint profiles as the source of truth for element governance. A constraint profile is pinned by the conversion profile and applied across prompts, structured output schemas, DITA generation, validation, editor behavior, agent tools, and export gates.

Use two enforcement layers:

- Formal grammar layer: DITA 1.3 document-type shells, constraint modules, Relax NG, DTD, XSD, Schematron, and DITA-OT validation where practical.
- DITAgen policy layer: JSON-schema-governed rules that describe blocked elements, allowed attributes, preferred substitutions, severity, UI behavior, and review requirements.

The formal grammar layer gives standards-aligned validation. The DITAgen policy layer gives generation-time guidance, fallback behavior, readable explanations, and UI controls. A profile rule is not considered fully enforced unless both generation and validation paths can see it.

## Constraint Profile Model

Each project selects a conversion profile. Each conversion profile references an immutable DITA constraint profile version.

Profile fields:

- `profile_id` and `version`.
- `target_dita_version`, defaulting to `1.3`.
- `base_topic_types`: `concept`, `task`, `reference`, `troubleshooting`, `glossary`, and `map`.
- `mode`: `denylist_with_defaults` for MVP, with `allowlist_strict` available for mature profiles.
- `rules`: Element, attribute, domain, and structure rules.
- `substitutions`: Preferred replacements by element, semantic intent, topic type, and parent context.
- `validation_severity`: `error`, `warning`, or `needs_review`.
- `editor_behavior`: Hide, disable, warn, or allow-with-reason.
- `generation_behavior`: Avoid, substitute, regenerate, or stop with review issue.
- `rationale`: Human-readable reason shown in admin, review, and validation views.
- `examples`: Positive and negative examples for prompts, tests, and documentation.
- `formal_artifacts`: Optional references to approved DITA shell, constraint module, Schematron, or DITA-OT plugin artifacts.

Example:

```json
{
  "profile_id": "hardware_docs_dita13",
  "version": "3.0.0",
  "target_dita_version": "1.3",
  "mode": "denylist_with_defaults",
  "rules": [
    {
      "rule_id": "no_section_in_task_body",
      "rule_type": "element",
      "element": "section",
      "topic_types": ["task"],
      "contexts": ["task/taskbody"],
      "policy": "blocked",
      "severity": "error",
      "generation_behavior": "substitute_or_review",
      "editor_behavior": "disable",
      "rationale": "Task bodies should use task-specific structure instead of generic sections."
    },
    {
      "rule_id": "limit_note_type",
      "rule_type": "attribute",
      "element": "note",
      "attribute": "type",
      "allowed_values": ["note", "tip", "warning"],
      "severity": "error",
      "rationale": "Only approved note types are supported by the publishing style guide."
    }
  ],
  "substitutions": [
    {
      "from_element": "section",
      "semantic_intent": "subsection",
      "topic_types": ["task"],
      "preferred_strategy": "split_topic_or_flatten_to_paragraphs",
      "fallback_elements": ["p"],
      "requires_review_when_lossy": true
    },
    {
      "from_element": "fig",
      "semantic_intent": "image_with_caption",
      "fallback_elements": ["image", "p"],
      "requires_review_when_lossy": true
    }
  ]
}
```

## Substitution Resolver

"Use the next best tag" must be deterministic and reviewable. Do not leave it to the LLM.

The DITA Element Policy Engine resolves candidate elements in this order:

1. Check whether the candidate element is legal in DITA 1.3 for the topic type and parent context.
2. Check the active DITA constraint profile.
3. If the element is allowed, generate it normally.
4. If blocked, look for an explicit substitution rule matching element, semantic intent, topic type, and parent context.
5. Validate the substitute against the same DITA 1.3 grammar and active profile.
6. If the substitute is meaning-preserving, apply it and record a substitution event.
7. If the substitute may lose meaning, create a review issue and keep source traceability.
8. If no legal substitute exists, fail the generation step for that topic with a constraint violation.

Rules:

- Never generate an element outside DITA 1.3 or outside the active profile.
- Never use `outputclass` as a dumping ground for forbidden semantics unless the profile explicitly allows it.
- Never silently remove source meaning to satisfy an element restriction.
- Prefer semantic restructuring over cosmetic replacement. For example, a blocked wrapper element might require splitting a topic, flattening paragraphs, or requiring human review.
- Every substitution records source block IDs, original candidate element, selected substitute, rule ID, confidence, and whether review is required.

## Pipeline Integration

Project setup:

- User selects a conversion profile.
- Conversion profile pins `target_dita_version` and `dita_constraint_profile_version`.
- In-flight jobs keep using the pinned profile even if a new profile version is published.

Analysis and planning:

- Topic planning reads allowed topic types and structural preferences from the profile.
- Low-confidence cases are flagged when the source structure strongly suggests a blocked element.

LLM and agent generation:

- Prompt builders include a compact element policy summary, not the whole profile.
- Structured LLM outputs describe semantic intent and content blocks, not arbitrary raw XML.
- The DITA Refactoring Agent can call `get_dita_constraint_profile`, `resolve_dita_element`, and `validate_dita_candidate` tools.
- Agents may suggest profile changes, but cannot enable or publish them.

DITA generation:

- DITA Generation Service maps semantic output to DITA elements through the DITA Element Policy Engine.
- Blocked-element substitutions happen before XML is written.
- Generated XML includes enough metadata to trace substitutions back to rules and source blocks.

Validation:

- DITA Validation Service runs base DITA 1.3 validation.
- It then runs profile validation through available formal constraints, Schematron, and DITAgen policy checks.
- Violations are stored as validation issues with rule ID, severity, element path, source blocks, suggested action, and review requirement.

Export:

- Export is blocked when profile violations with `error` severity remain.
- Warnings can export only if project policy allows warnings or a reviewer records an override reason.
- Export reports include active profile version and all unresolved warnings or overrides.

## Frontend Experience

Admin and information architect screens:

- Constraint profile list with status: draft, published, deprecated, archived.
- DITA element catalog with search, topic-type filters, and allowed/blocked/deprecated/preferred states.
- Rule builder for blocking elements, restricting attributes, setting allowed values, selecting severity, and defining substitutions.
- Impact preview showing affected templates, prompts, skills, generated topics, and validation fixtures.
- Dry-run validation against sample topics before publishing a profile.

Review workspace:

- Show active profile name and version on each topic.
- Show profile violations in the validation panel.
- Show substitution history inline, for example: candidate `<fig>` was replaced by `<image>` plus caption paragraph because rule `no_fig_without_strong_caption` applied.
- Let reviewers filter by blocked-element violations, lossy substitutions, missing substitutions, and override-required issues.
- Explain why an expected element was not used.

Editor behavior:

- Hide blocked elements from insert menus.
- Disable blocked elements in structured editing controls.
- Warn immediately when pasted XML contains blocked elements.
- Offer profile-approved replacements when possible.
- Require a reason for overrides where project policy allows them.

## APIs, Events, And Contracts

API additions:

- `GET /projects/{project_id}/dita-constraint-profile`
- `GET /organizations/{organization_id}/dita-constraint-profiles`
- `POST /organizations/{organization_id}/dita-constraint-profiles`
- `GET /dita-constraint-profiles/{profile_id}/versions/{version}`
- `POST /dita-constraint-profiles/{profile_id}/versions/{version}/dry-run`
- `POST /dita-constraint-profiles/{profile_id}/versions/{version}/publish`
- `POST /dita/element-policy/resolve`
- `POST /dita/element-policy/validate-candidate`

Event additions:

- `dita.constraint_profile.created`
- `dita.constraint_profile.published`
- `dita.constraint_profile.enabled`
- `dita.constraint_profile.deprecated`
- `dita.element.substituted`
- `dita.constraint.violation_detected`
- `dita.constraint.override_recorded`

Contract additions:

- `dita-constraint-profile.schema.json`
- `dita-element-rule.schema.json`
- `dita-substitution-rule.schema.json`
- `dita-element-policy-result.schema.json`
- `dita-constraint-violation.schema.json`

Data model additions:

- `DitaConstraintProfile`
- `DitaConstraintProfileVersion`
- `DitaConstraintRule`
- `DitaSubstitutionRule`
- `DitaConstraintViolation`
- `DitaElementSubstitution`

## Governance

- Profile versions are immutable after publishing.
- Draft profiles can be edited only by `information_architect`, `project_admin`, or `org_admin` roles with the required project or organization scope.
- Publishing a profile requires validation against fixtures and an audit record.
- Enabling a new profile for an existing project requires impact analysis.
- Approved topics are not automatically rewritten when a profile changes.
- Revalidation under a new profile creates reviewable issues and does not mutate approved content.
- Destructive profile changes, such as blocking a heavily used element, require approval and dry-run results.

## Test Scenarios

- A blocked element requested by the LLM is replaced only by an allowed, valid substitute.
- A blocked element with no safe substitute creates a validation issue instead of silently dropping content.
- Pasted XML with blocked elements is rejected or flagged in the editor.
- DITA-OT validation runs with the profile's approved grammar artifacts where available.
- Schematron and policy checks catch blocked elements missed by raw XML schema validation.
- Export is blocked when an error-severity profile violation remains.
- Existing approved topics are revalidated but not rewritten when a new profile is enabled.
- Agent tools cannot bypass blocked elements or profile severity.
- Profile changes are versioned, audited, and pinned to in-flight jobs.
- Conref and reuse scenarios are tested for compatibility when formal DITA constraints are active.

## Research Inputs

- DITA 1.3 constraint modules can restrict content models, attributes, and domains while remaining conformant to the original grammar: [OASIS DITA constraints overview](https://docs.oasis-open.org/dita/dita/v1.3/os/part1-base/archSpec/base/constraints-overview.html).
- DITA 1.3 notes that constraints can affect processing and interoperability, including compatibility between documents that use different constraints: [DITA constraints](https://docs.oasis-open.org/dita/dita/v1.3/os/part1-base/archSpec/base/constraints.html).
- OASIS distributes domains and constraints as part of the DITA 1.3 grammar set: [Domains and constraints](https://docs.oasis-open.org/dita/dita/v1.3/os/part2-tech-content/non-normative/oasisdomains.html).
