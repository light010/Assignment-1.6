# ADR 001: Product Vision, Scope, And Metrics

Status: Active

## Context

DITAgen must convert messy, multilingual source documents into DITA topics while keeping users in control. Source files may be incomplete, inconsistent, image-heavy, poorly formatted, duplicated, scanned, or mixed-language. The product must serve technical writers, information architects, reviewers, localization managers, and content operations admins.

## Decision

Build DITAgen as a product workspace for repeatable document conversion programs, not as a one-off conversion script or generic chatbot.

## Core Goals

- Support source documents that are incomplete, inconsistent, multilingual, duplicated, poorly formatted, or image-heavy.
- Preserve source traceability from original document regions to extracted Markdown and generated DITA topics.
- Keep LLM behavior controlled with validation, schema checks, retry policies, review states, and human approval.
- Allow users to make final edits in a modern browser-based workspace before export.
- Support multilingual extraction, language detection, translation workflows, locale-specific terminology, and DITA `xml:lang` metadata.
- Keep every processing stage observable, resumable, and independently deployable.

## Product Owner Gap Analysis

The product needs explicit structure around user value, review confidence, operational ownership, and go-to-market scope. These concerns influence service boundaries, data models, frontend workflows, and LLM evaluation.

Identified gaps to keep visible through implementation:

- User roles and user journeys must remain explicit.
- MVP scope must stay separate from later enterprise capabilities.
- Quality gates must connect technical validation with user-visible confidence and approval decisions.
- Review lifecycle needs statuses, ownership, and rework loops.
- Source traceability must be visible in frontend inspection and audit workflows.
- Multilingual support needs terminology management and translation handoff.
- Export must evolve beyond ZIP packages toward Git, CCMS, CMS, and localization integrations.
- LLM cost, quality evaluation, prompt governance, and customer-specific templates need product controls.
- Administrative settings, templates, terminology, and role management are product areas, not backend-only details.
- Success metrics and adoption metrics must guide roadmap decisions.

## Product Principles

- Make the first useful result fast, even when the source document is messy.
- Keep users in control of final technical content decisions.
- Explain recommendations through source traceability, confidence, and validation evidence.
- Treat generated content as draft content until reviewed, approved, and exported.
- Let teams standardize output through templates, terminology, and project-level rules.
- Keep multilingual handling visible and correct.

## Target Users

Information Architect:

- Configures DITA structure rules, topic policies, maps, relationships, keys, reuse strategy, and templates.
- Defines or reviews DITA constraint profiles, including blocked elements, allowed substitutions, attribute restrictions, and validation severity.
- Success means generated DITA structure requires minimal rework before publishing.

Technical Writer:

- Uploads source documents, reviews Markdown and DITA side by side, edits content, and approves topics.
- Success means time from upload to approved DITA is much lower than manual rewriting.

Localization Manager:

- Reviews language detection, `xml:lang`, terminology, and translation handoff packages.
- Success means multilingual output is consistent, traceable, and localization-ready.

Content Operations Admin:

- Manages users, roles, templates, terminology, provider settings, project defaults, cost, and audit reports.
- Success means conversion work runs reliably across teams and projects.

Reviewer or Subject Matter Expert:

- Reviews assigned topics, compares source evidence, comments, requests changes, or approves.
- Success means review decisions are scoped, fast, and evidence-backed.

## Core Product Workflows

Convert a document set:

1. Create project and choose conversion profile.
2. Upload files.
3. Extract source content and assets.
4. Normalize extraction into Markdown.
5. Propose topic boundaries and topic types.
6. Optionally edit or approve topic plan.
7. Generate DITA topics and maps.
8. Validate output and assign confidence scores.
9. Review generated topics.
10. Approve topics and export DITA.

Fix low-confidence output:

1. System flags low-confidence topics, broken links, table issues, OCR issues, or weak classification.
2. User compares source preview, extracted Markdown, generated DITA, and validation messages.
3. User edits the topic or requests scoped regeneration.
4. System reruns validation.
5. User approves or sends the topic back for rework.

Standardize repeated conversions:

1. Admin creates templates, terminology rules, and naming conventions.
2. Information architect configures DITA constraint profiles for blocked elements, attribute limits, and preferred substitutions.
3. Team runs conversions using the same profile.
4. System tracks quality and failure patterns.
5. Information architect adjusts rules.
6. Future conversions improve through reusable configuration.

## MVP Scope

The MVP proves DITAgen can reliably convert messy source documents into reviewable DITA drafts.

MVP capabilities:

- Tenant, organization, identity, authorization, and audit foundations.
- Project creation.
- Upload for DOCX, PDF, PPTX, images, and HTML.
- Extraction to Markdown with image assets.
- Basic OCR fallback for scanned sources.
- Language detection at document and block level.
- Topic planning for concept, task, reference, troubleshooting, glossary, and map.
- LLM-assisted generation into DITA XML.
- Bounded agent runtime with traces, guardrails, approval requests, and a small skill registry.
- MCP Gateway for approved read-only context and controlled tool access.
- DITA validation with visible issues.
- Review workspace with source, Markdown, DITA, and validation panels.
- Manual topic editing.
- Topic approval workflow.
- Export as DITA ZIP.
- Basic user roles: admin, editor, reviewer.
- Basic audit log for uploads, generation, edits, approvals, and exports.

## Post-MVP Scope

- Real-time collaborative editing.
- Advanced DITA reuse with keys, conrefs, keyrefs, and relationship tables.
- Customer-specific DITA shells and specialization support.
- Translation memory and localization package handoff.
- CCMS, Git, CMS, ticketing, and enterprise integrations.
- Prompt and agent evaluation dashboards.
- Cost controls and per-project LLM budgets.
- Template marketplace or reusable organization templates.
- Human feedback loop for improving prompts, rules, and classifiers.
- Pluggable OCR, LLM, validation providers, and agent runtime adapters.
- Dynamic third-party skill marketplace and marketplace-style MCP connectors.

## Success Metrics

Business and user metrics:

- Median time from upload to first reviewable DITA draft.
- Percentage of generated topics approved without regeneration.
- Average human edit distance per generated topic.
- Validation pass rate before and after human review.
- Percentage of source blocks with traceability to DITA output.
- Number of documents converted per project.
- Export success rate.
- Reviewer turnaround time.
- LLM cost per approved topic.
- User retention across repeated conversion projects.

Quality metrics:

- Topic type classification accuracy.
- Heading hierarchy accuracy.
- Task step extraction accuracy.
- Table preservation accuracy.
- Image and caption preservation accuracy.
- Language detection accuracy.
- Broken link count.
- DITA validation severity count.
- Low-confidence OCR block count.
