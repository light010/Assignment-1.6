# ADR 008: Roadmap, Risks, And Open Decisions

Status: Active

## Context

DITAgen has a large product surface: document conversion, DITA generation, multilingual support, agents, MCP, validation, review, export, enterprise integrations, and operations. The roadmap must deliver core value early without overengineering.

## Decision

Ship in phases. Keep enterprise integrations, marketplaces, advanced collaboration, and broad runtime pluggability out of the MVP unless a customer requirement forces them earlier.

## Product Roadmap

### Phase 1: Foundation

- Identity, authorization, tenancy, and core data model.
- Project setup.
- Upload flow.
- Extraction to Markdown.
- Basic topic planning.
- LLM-assisted DITA generation.
- Bounded agent runtime.
- Initial skill registry.
- MCP Gateway for approved read-only context and controlled tool access.
- Agent guardrails and traces.
- XML parser hardening.
- CI/CD baseline, backup strategy, and SLO targets.
- Validation.
- Review workspace.
- DITA ZIP export.

### Phase 2: Quality And Control

- Source quality triage.
- Large-document manifests, source block browsing, and asset manifest review.
- Confidence scoring.
- Regeneration by section.
- Terminology checks.
- Template management.
- DITA constraint profile management for blocked elements, restricted attributes, substitutions, and dry-run validation.
- Audit reports.
- Prompt evaluation fixtures.
- Agent evaluation fixtures.
- Approval-gated assistant actions.
- Conversion profile reuse.

### Phase 3: Scale And Collaboration

- Batch project analytics.
- Reviewer assignments and reviewer assignment suggestions based on workload, domain match, language, conflict-of-interest rules, and review fatigue signals.
- Additional source formats such as XLSX, Markdown, AsciiDoc, RST, ODT, EPUB, and existing DITA round-trip.
- Advanced roles and permissions.
- Real-time collaborative editing.
- Search across projects.
- Enterprise SSO.
- Cost controls and usage dashboards.
- Additional provider adapters for agent runtime.
- DITAgen-hosted MCP server for approved external assistants.

### Phase 4: Enterprise Ecosystem

- Git export.
- CCMS integration.
- Translation management handoff.
- Customer-managed storage.
- Customer-managed keys.
- Advanced DITA specialization support.
- Webhook and integration marketplace.
- Third-party skill marketplace.
- Marketplace-style MCP connectors.
- Cell-based deployment option for large enterprise isolation, regional data residency, and blast-radius reduction.
- Schema-aware collaborative DITA editing if real-time editing becomes a proven customer need.

## Enterprise Integrations

Potential integrations:

- Git repositories for source-controlled DITA output.
- CCMS platforms for managed technical content.
- CMS or documentation portals for publishing workflows.
- Translation management systems for localization handoff.
- SSO providers through SAML or OIDC.
- Ticketing systems for review assignments and issue tracking.
- Object storage providers for customer-managed document storage.
- Webhooks for pipeline events.
- Approved MCP servers for agent context, read-only resources, and controlled tool execution.

Integration principles:

- Keep export targets behind an adapter interface.
- Keep MCP servers behind the MCP Gateway rather than exposing them directly to agents.
- Store external system IDs with exported artifacts.
- Treat external publishing as separate from DITA generation.
- Do not require enterprise integrations for local development or MVP usage.

## Product Risks And Mitigations

- Risk: Messy documents produce misleading DITA.
  Mitigation: Use source quality triage, confidence scoring, traceability, and required review gates.
- Risk: LLM output looks correct but changes meaning.
  Mitigation: Preserve source evidence, use structured schemas, validate output, and require human approval.
- Risk: Agentic workflows become opaque or overpowered.
  Mitigation: Use bounded agents, typed tools, guardrails, traces, approval gates, and reversible diffs.
- Risk: Conversion cost becomes unpredictable.
  Mitigation: Track token usage, set project budgets, cache intermediate artifacts, and support scoped regeneration.
- Risk: Large documents overload parsers, queues, databases, or browsers.
  Mitigation: Use manifests, object-storage artifacts, source block graphs, cursor APIs, backpressure-aware queues, and frontend virtualization.
- Risk: Naive chunking splits topics, tables, figures, or procedures.
  Mitigation: Use semantic topic candidates from source block graphs and review low-confidence boundaries.
- Risk: Users do not trust generated content.
  Mitigation: Show source comparison, confidence signals, validation results, and audit history.
- Risk: Product becomes too fragmented by microservices early.
  Mitigation: Keep service contracts clean, but allow local deployment as modular services deployed together early.
- Risk: Multilingual output is structurally valid but linguistically inconsistent.
  Mitigation: Use language-specific terminology, locale templates, language validation, and localization review.
- Risk: DITA output passes XML validation but fails publishing expectations.
  Mitigation: Run DITA-OT smoke builds and support customer-specific validation rules.
- Risk: Project-specific blocked DITA elements are treated as prompt-only guidance and leak into exports.
  Mitigation: Use versioned DITA constraint profiles across prompts, generation, editor controls, validation, and export gates.
- Risk: Enterprise integrations delay core product value.
  Mitigation: Ship DITA ZIP export first and keep integrations behind adapter interfaces.
- Risk: MCP expands into an unsafe plugin platform too early.
  Mitigation: Use MCP Gateway, read-only resources first, allowlists, egress controls, approval gates, and audit logs.
- Risk: Foundational identity, tenancy, or data-model choices are deferred.
  Mitigation: Treat ADR 010 as Phase 1 design input before service schemas are finalized.
- Risk: XML parsing exposes XXE, zip-bomb, path traversal, or schema-poisoning attacks.
  Mitigation: Use hardened parsers, allowlisted schemas, isolated DITA-OT workers, and adversarial fixtures.
- Risk: Off-the-shelf document-AI tooling produces clean-looking output without enough source traceability.
  Mitigation: Treat third-party document models as inputs to DITAgen's source block graph, not as replacements for DITAgen block IDs, artifact manifests, or traceability.
- Risk: LLM framework or gateway lock-in makes provider changes expensive.
  Mitigation: Keep DITAgen schemas, agent contracts, provider capabilities, and artifact records independent of the internal framework.

## Architecture Decisions To Finalize

- Frontend framework: Next.js, Remix, or Vite React.
- Queue/event platform: RabbitMQ, Kafka, Redis Streams, or managed cloud queue.
- Workflow orchestration threshold and engine: queue-backed workers for MVP, Temporal or equivalent if compensation grows complex.
- Object storage provider: S3, MinIO, GCS, or Azure Blob Storage.
- Identity provider implementation choice.
- Policy engine choice for authorization: OPA, Cedar, or equivalent.
- Enterprise tenancy upgrade path: bridge model, silo model, or both.
- CI/CD platform, container registry, feature flag provider, and SBOM/scanning toolchain.
- OCR provider: local OCR, cloud OCR, or hybrid.
- LLM provider strategy: single provider, multi-provider, or customer-configured provider.
- LLM observability vendor and prompt evaluation harness.
- LLM gateway choice: LiteLLM, Portkey, Helicone, managed provider gateway, or DITAgen-built minimal gateway.
- DITA version and validation policy.
- Initial DITA constraint profile defaults, blocked element catalog, and substitution policy.
- Collaboration model: single editor lock or real-time collaborative editing.
- CRDT scope for collaboration: comments/simple drafts only, or later schema-aware DITA editing.
- Translation model: source-preserving multilingual generation or separate translation workflow.
- MVP deployment shape: fully separated microservices or modular services deployed together at first.
- Review policy: required approval for every topic or exception-based review for high-confidence topics.
- Confidence threshold policy by topic type and project.
- Export targets for the first release.
- Template ownership model: admin-only, information-architect owned, or project-owned.
- Analytics privacy policy and retention defaults.
- Agent autonomy policy by project and role.
- Initial skill registry ownership and promotion workflow.
- Agent runtime framework evaluation: LangGraph as preferred stateful candidate, OpenAI Agents SDK for bounded OpenAI-specific workflows, or a minimal DITAgen internal runtime.
- MCP server approval process, transport defaults, and local development sandbox policy.
