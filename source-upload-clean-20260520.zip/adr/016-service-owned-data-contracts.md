# ADR-016: Service-Owned Data Contracts

## Status

Accepted (target architecture). Migration in progress; see Phase 4 of
`plans/architecture-hardening.md` for the step-by-step rollout and
`tests/test_jsonstore_key_ownership.py` for the current ownership lock.

This ADR was originally drafted as `009-service-owned-data-contracts.md`
in "Proposed" status. It collided with ADR-009 (Scalability), was never
added to `adr/000-index.md`, and drifted from the actual code as parallel
work landed. Renumbered to ADR-016 on 2026-05-11 and reconciled against
the empirical state captured by Phase 4 D0's `JsonStore` audit.

## Decision

DITAgen will retire shared mutable `JsonStore` as a production data
layer. Each production service owns its metadata in a relational
database, with the same repository interface across deployments.

**Storage target**: PostgreSQL is the production target. SQLite is
permitted only as a hermetic local/test fallback behind identical
repository contracts. `plans/architecture-hardening.md` originally said
"SQLite" for Phase 4 D2-D6 as a shipping pragma; this ADR is the
canonical answer — start with SQLite per-service for hermetic tests and
the alpha deployment, switch the production backend to PostgreSQL behind
the same repository interface before any production traffic. The
repository interface is the contract; the storage engine is an
implementation detail behind it.

## Target Ownership

| State key in `JsonStore` today | Target owner | Notes |
| --- | --- | --- |
| `users`, `sessions`, `revoked_tokens` | api-gateway (becomes identity-service when stood up) | PAT revocation list lives here per Phase 1 S3. identity-service has a `**Status**: deferred-alpha skeleton` README; ADR-004 designs it. |
| `business_units`, `projects`, `business_unit_memberships`, `project_memberships` | business-unit-service | The audit's original "memberships" entry was actually two keys (BU-level + project-level). |
| `documents`, `upload_sessions`, `artifact_registry`, `exports`, `jobs` | upload-service | `jobs` could split to a dedicated job-service later; deferred until the queue model is real. |
| `extractions` | extraction-service | Status, artifacts list, events stream, quality-gate verdict. |
| `topics`, `generated_topics`, edit-operations log | review-service | review-service exists post Phase 6 (see ADR-015). |
| `audit_events`, audit replay cursors | audit-service | Post-Phase-1 S6, daily-rotated JSONL is the interim sink; D2 migrates to relational. |

## Current Reality (2026-05-12, post Phase 4 D2 + D3)

The table below is the *current* footprint per
`tests/test_jsonstore_key_ownership.py::_EXPECTED_KEY_USAGE`. The
ownership-lock test enforces this set — any service touching a key
outside its allowed-set fails. The first column counts the *owned-
collection* drops since the 2026-05-11 baseline (writes retired);
the second lists the remaining keys (foreign reads or owned keys not
yet migrated). `frozenset()` = fully migrated.

| Service | Keys still touched | Status |
| --- | --- | --- |
| api-gateway | `documents`, `revoked_tokens`, `sessions`, `topics`, `users` | D3.6 dropped `projects` (delegates to BU service via `request_service`). Remaining: identity-service stand-up (3 keys) + cross-service reads (`documents`, `topics`). |
| business-unit-service | `artifact_registry`, `documents`, `jobs`, `topics` | **D3.5.c dropped all 4 owned-collection writes** (`business_units`, `business_unit_memberships`, `projects`, `project_memberships`) and `business_unit_favorites` (D3.5.b.3). SQL is authoritative. Remaining 4 are foreign reads in summary-helper joins. |
| upload-service | `artifact_registry`, `documents`, `exports`, `jobs`, `topics`, `upload_sessions` | D3.7.b dropped `project_memberships`, D3.7.c dropped `projects`. Remaining are owned (5 keys: `artifact_registry`, `documents`, `exports`, `jobs`, `upload_sessions`) + 1 cross-service read (`topics`). |
| review-service | `topics`, `extractions` | aligned for `topics` (owned). `extractions` is a cross-service read surfaced by the D3.5.b.1+ lock `.get()` fix — future D-step migrates to extraction-service. |
| analysis-service | `topics`, `generated_topics` | reads what should be review-service-owned. Future D-step. |
| extraction-service | `extractions` | D3.5.c.0 dropped `business_unit_memberships` (delegates to BU service via `request_service`). Remaining: own state only. |
| audit-service | `frozenset()` | **Fully migrated** (D2.6). Tenant-isolation through `request_service` to BU service. |
| validation-service | `frozenset()` | aligned — imports `JsonStore` for artifact-blob reads only; no state-key access. |

**Phase 4 D3 outcome** (Phase 4 D2 + D3 closed):
- 2 services fully migrated (`frozenset()`): audit-service, validation-service.
- BU service: 4 → 0 owned-collection writes; all SQL.
- 6 lock-tightening wins across D3.5.b/c, D3.6, D3.7.b/c: api-gateway.projects, upload.project_memberships, upload.projects, BU.business_unit_favorites, extraction.business_unit_memberships, BU's last 4 owned keys.
- Cross-service auth pattern (`request_service` + async-route promotion) reused in 4 services.

The drift is much smaller now. Remaining work tracked in `plans/architecture-hardening.md` §D4+ (upload-service to SQLite is the next large migration).

## Migration Order

1. **audit-service** ✅ **(done, Phase 4 D2)** — SQLite + repo. Tenant
   isolation flipped to `request_service` against BU service in D2.6;
   JSONL bridge retired in D2.7.
2. **business-unit-service** ✅ **(done, Phase 4 D3)** — SQLite + per-
   service Alembic + 6 typed repos. D3.6 routed `api-gateway.require_project`
   through the BU service; D3.7 retired upload-service's project
   lifecycle leak; D3.5.c inverted authority (SQL canonical, JsonStore
   writes retired, dual-write swallow flipped to raise). Cross-service
   reads now go through `GET /internal/projects/{id}` etc.
3. **upload-service** — `documents`, `jobs`, `artifact_registry`,
   `upload_sessions`, `exports`. Largest write volume. Phase 4 D4.
4. **review-service** — `topics`, `generated_topics`, edit ops. Phase 4 D5.
5. **extraction-service** — `extractions`. Status, artifacts, events. Phase 4 D6.
6. **auth/PAT ownership** — finalize whether identity-service stands up
   or `revoked_tokens` + `sessions` stay in api-gateway permanently. Phase 4 D7.

After each step, the architecture lock
`tests/test_jsonstore_key_ownership.py` relaxes — the migrated keys are
dropped from the per-service allowed-set, and any new cross-service
read fails the test.

## Transitional Event Mechanism

Until a dedicated broker is justified, audit-service exposes audit
event replay by cursor: `GET /internal/events/since/{cursor}`. Each
consumer stores its cursor in its own database. This is **not** the
final event bus — RabbitMQ, Redis Streams, or Kafka enter the picture
only when replay latency, ordering, or throughput proves the HTTP
bridge insufficient. Phase 4 D1's architecture lock pins the
no-duplicates, no-gaps replay contract so a future swap can be tested
against the same invariant.

## Consequences

- Production services must not import or mutate `JsonStore` after the
  migration completes. `tests/test_jsonstore_key_ownership.py` enforces
  the floor today; `tests/test_no_json_store_imports.py` (added in
  Phase 4 D7) will enforce zero imports at the end.
- Repository interfaces must be tested against both the SQLite
  hermetic fallback and the PostgreSQL production backend.
- Cross-service reads happen through typed internal APIs (the
  `request_service` pattern locked by
  `tests/test_async_route_conventions.py`) or replayed events, not
  shared files.
- The ownership table in this ADR is the source of truth for Phase 4
  step ordering; the architecture lock keeps the two in sync.
