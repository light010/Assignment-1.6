# ADR 011: Off-The-Shelf Tools And Libraries

Status: Active

## Context

DITAgen should not build commodity infrastructure, parsers, OCR engines, editors, identity systems, observability pipelines, or supply-chain tooling from scratch. The product value is the DITA-specific document graph, traceability model, topic planning, structured refactoring, review workflow, validation policy, bounded agent runtime, skill registry, and MCP governance layer.

This ADR records practical library and platform choices. It is intentionally open-source-first and Docker/Kubernetes-friendly, but every production dependency still needs license, security, benchmark, and operational review before adoption.

## Decision

Use proven off-the-shelf components where they fit DITAgen's risk profile. Classify tools into:

- `MVP default`: use unless a prototype proves it unsuitable.
- `Evaluate`: benchmark against DITAgen fixtures before choosing.
- `Defer`: useful later, but not required for MVP.

The architecture remains provider-neutral. Tool choices must not remove DITAgen's typed contracts, artifact versioning, human approval gates, auditability, or ability to replace vendors.

## Corrections From Review

Accepted corrections:

- Keep production DITA output on DITA 1.3. DITA 2.0 remains draft/pre-standard; DITA-OT 4.4 only provides preview support for draft grammar features.
- Update MCP references to the 2025-11-25 specification and treat MCP authorization as OAuth-based with resource indicators and protected resource metadata for HTTP transports.
- Prefer explicit `lxml` parser settings for unsafe XML, especially `resolve_entities=False`, `load_dtd=False`, `no_network=True`, and `huge_tree=False`.
- Add a dedicated LLM gateway layer so model routing, rate limits, budgets, retries, fallbacks, and observability are not duplicated in every service.
- Add Docling and PaddleOCR-VL as document-understanding evaluation candidates.
- Add supply-chain hardening, DITA-specific evaluation metrics, vector search defaults, and reviewer assignment automation.

Rejected or softened corrections:

- Do not claim LangGraph is objectively "Tier 1" by standard. Use LangGraph as the preferred stateful agent orchestration candidate because it fits human-in-the-loop, checkpointed, graph-shaped workflows; keep DITAgen's own agent contracts as the source of truth.
- Do not hard-code OCR or vision-LLM per-page cost claims in architecture. Pricing changes too often and depends on deployment, GPU utilization, provider, model, and page complexity.
- Do not make cell-based tenancy, schema-aware CRDT editing, third-party plugin marketplaces, or autonomous reviewer assignment MVP commitments.

## Tooling Matrix

### Backend And Service Framework

MVP default:

- FastAPI for Python HTTP APIs.
- Pydantic v2 for request, response, event, LLM, agent, and artifact schemas.
- SQLAlchemy 2 and Alembic for relational persistence and migrations.
- PostgreSQL for metadata, state, audit metadata, and optional pgvector.
- Redis for cache, short-lived locks, job progress snapshots, and WebSocket/SSE fanout support.
- `uv`, Pytest, Ruff, and Pyright or mypy for Python development quality.

Evaluate:

- SQLModel only if its tradeoff of fewer model classes outweighs reduced flexibility.
- OpenAPI Generator or Orval for generated TypeScript API clients once the first APIs stabilize.

Defer:

- GraphQL. DITAgen's core workflows map cleanly to REST plus cursor APIs and streamed job events.

### Workflow, Queues, And Jobs

MVP default:

- RabbitMQ plus Dramatiq for stage queues, retries, delayed jobs, dead-letter queues, and worker isolation.
- Explicit job state in PostgreSQL for resumability and idempotency.

Evaluate:

- Temporal for the bulk document pipeline if multi-stage compensation, timers, parent-child workflows, and long-running recovery become too complex for queue-backed workers.
- Celery if the team prefers its ecosystem and accepts its operational complexity.

Defer:

- Kafka as the default event bus. It is useful for high-volume event streams, but it is too much for the MVP conversion pipeline unless analytics volume requires it.

### Document Ingestion And Extraction

MVP default:

- Apache Tika for broad file type detection, metadata, and fallback text extraction.
- Pandoc for clean format conversion to Markdown where structure is already good.
- Direct OOXML parsing for DOCX and PPTX through `python-docx`, `python-pptx`, zip/package relationship traversal, and XML parsing.
- PyMuPDF as the preferred PDF extraction candidate only after license review; use pdfplumber for layout and table diagnostics.
- LibreOffice headless in an isolated worker for rendering and conversion fallbacks, not as the primary parser.
- `openpyxl` for XLSX metadata and table extraction when spreadsheets are enabled.

Evaluate:

- Docling as a unified document-understanding layer for PDF, DOCX, PPTX, XLSX, HTML, images, audio, LaTeX, Markdown, JSON, and layout-aware exports.
- Unstructured, Marker, or similar parsers only if Docling and direct extractors leave gaps.
- Tika Server versus embedded CLI based on container overhead, startup time, memory use, and extraction quality.

Defer:

- Fully replacing DITAgen's normalized source block graph with a third-party document model. DITAgen can ingest Docling output, but must still own block IDs, source traceability, topic candidates, and asset manifests.

### OCR And Vision Document Understanding

MVP default:

- OCRmyPDF plus Tesseract for searchable scanned PDF generation and baseline OCR.
- Per-page OCR routing based on scan detection, page image quality, language, and OCR confidence.

Evaluate:

- PaddleOCR-VL for multilingual page-level parsing, tables, formulas, charts, and complex layouts.
- docTR for Python-native OCR experiments.
- Vision LLMs only for selected low-confidence pages, figures, tables, or alt-text candidates where deterministic OCR is insufficient.

Defer:

- Sending every page through a vision LLM. It is too expensive and unnecessary for many digital or well-scanned documents.

### DITA, XML, And Publishing

MVP default:

- DITA 1.3 as the production output target.
- DITA-OT for validation, smoke builds, HTML/PDF export checks, and DITA package testing.
- `defusedxml` for Python stdlib XML parsing.
- `lxml` with hardened parser settings where XPath, Relax NG, XML Schema, or Schematron support is required.
- Schematron and custom business-rule validators for DITAgen-specific quality gates.
- DITAgen DITA constraint profiles for blocked elements, restricted attributes, preferred substitutions, and editor behavior.

Evaluate:

- Saxon-HE if XSLT 2.0 or 3.0 processing is needed outside DITA-OT.
- DITA-OT 4.4 JSON logging for easier parsing of validation and export logs.

Defer:

- DITA 2.0 production output until it becomes an approved OASIS standard and customer tooling supports it.

### LLM Gateway, Agents, And MCP

MVP default:

- A DITAgen LLM Gateway boundary in front of provider calls.
- LiteLLM Proxy as the first gateway candidate for OpenAI-compatible APIs, model routing, retries, fallbacks, budget controls, and centralized logging.
- Langfuse as the first open-source LLM observability and evaluation candidate.
- LangGraph as the preferred stateful agent orchestration candidate when DITAgen needs graph execution, checkpointing, durable human-in-the-loop, replay, or time-travel debugging.
- DITAgen provider-neutral schemas, tool policies, skill manifests, and agent traces remain the durable contracts.
- MCP Gateway for approved external resources/tools and DITAgen-hosted read-only resources.

Evaluate:

- OpenAI Agents SDK for OpenAI-specific agent implementations where tools, handoffs, guardrails, tracing, and hosted MCP integration fit a bounded use case.
- Portkey or Helicone if gateway observability, prompt management, semantic caching, or governance requirements outgrow LiteLLM plus Langfuse.
- Arize Phoenix for open-source evaluation and tracing if it fits the evaluation workflow better than Langfuse.

Defer:

- CrewAI, AutoGen, and autonomous multi-agent frameworks as core runtime dependencies.
- Marketplace-style MCP connectors and third-party dynamic skill installs.
- Agent-written code, unrestricted shell tools, hidden network tools, and autonomous publishing.

### Search, Embeddings, And Retrieval

MVP default:

- PostgreSQL full-text search for projects, documents, topics, validation issues, comments, terminology, and audit summaries.
- pgvector for early semantic search, duplicate detection, reusable snippet lookup, or retrieval-assisted review if embeddings become necessary.

Evaluate:

- Qdrant when vector volume, hybrid search, payload filtering, recall tuning, or horizontal scaling exceed comfortable PostgreSQL limits.
- OpenSearch when keyword search, faceting, relevance tuning, and large cross-project search become important.
- Embedding providers per language and domain; do not choose one model globally until multilingual fixtures are benchmarked.

Defer:

- Vector search as a dependency of the core conversion path.

### Identity, Authorization, And Tenancy

MVP default:

- OIDC through a managed IdP or Keycloak-compatible deployment.
- PostgreSQL tenant scoping with `tenant_id` on tenant-owned rows and Row Level Security where practical.
- Application-level RBAC and resource permission checks backed by versioned policy tests.

Evaluate:

- Cedar for DITAgen application authorization because its principal-action-resource-context model maps well to project, document, topic, agent, skill, and MCP resources.
- OPA for platform policy, Kubernetes admission, CI/CD policy checks, and broad infrastructure guardrails.
- Keycloak, Authentik, Zitadel, or a managed IdP based on enterprise SSO, SCIM, operations, and hosting requirements.

Defer:

- Schema-per-tenant, database-per-tenant, and cell-based tenancy until regulated or large enterprise customers require isolation, residency, or blast-radius boundaries.

### Frontend And Editing

MVP default:

- TypeScript and React.
- Vite React for an app-first workspace if SSR is not needed; Next.js only if server-side auth, route handlers, or BFF behavior are required.
- TanStack Query, Router, Table, and Virtual for API state, routing, data grids, and large lists.
- Radix UI or shadcn/ui primitives for accessible controls.
- TipTap/ProseMirror for structured authoring.
- Monaco Editor for XML inspection and diffs.
- PDF.js for PDF previews.
- Playwright and Vitest for frontend tests.

Evaluate:

- Lexical if the review editor needs a more custom structured editing model than TipTap.
- Yjs only for comment threads or simple collaborative draft editing.

Defer:

- Schema-aware CRDT editing for DITA XML. It is difficult to preserve DITA validity under arbitrary concurrent structural edits and should be a later specialization.

### Observability, Audit, And Lineage

MVP default:

- OpenTelemetry for traces, metrics, logs correlation, and propagation across APIs, queues, workers, LLM gateway, agent runtime, MCP Gateway, and storage calls.
- Prometheus, Grafana, and Loki-compatible logging for platform observability.
- Append-only audit events in DITAgen's audit service.

Evaluate:

- OpenLineage-style event facets for artifact lineage if DITAgen needs ecosystem-compatible data lineage beyond its own traceability reports.
- Langfuse or Phoenix for LLM traces, prompt/version evaluation, and model quality dashboards.

Defer:

- External data catalog integration until enterprise governance requirements are concrete.

### Supply Chain, Runtime Security, And CI/CD

MVP default:

- GitHub Actions or equivalent CI.
- pre-commit, Ruff, Pyright or mypy, eslint, TypeScript type checks, Pytest, Vitest, and Playwright.
- Trivy or Grype for container and dependency scanning.
- Gitleaks for secret scanning.
- Syft for SBOM generation.
- Cosign or Sigstore-compatible signing for release images.
- Distroless, Wolfi, or Chainguard-style minimal images for production services where dependency compatibility allows.

Evaluate:

- SLSA Build L2/L3 practices as the release process matures.
- in-toto attestations for signed build provenance.
- gVisor or equivalent sandboxing for adversarial-input workers such as extraction, OCR, DITA-OT, LibreOffice, and any local MCP STDIO server runner.

Defer:

- Strict SLSA Build L3 as an MVP blocker. Start with SBOMs, signing, scans, and reproducible release discipline.

## Evaluation Fixtures

Before locking parser, OCR, and document-understanding tools, benchmark against:

- DOCX with inline images, floating images, captions, headers, footers, tables, comments, and tracked changes.
- PPTX with image-heavy slides, grouped shapes, speaker notes, and embedded media.
- Digital PDF with tables, bookmarks, links, figures, and multi-column layout.
- Scanned multilingual PDF with rotated pages and mixed OCR quality.
- Large PDF or DOCX above 1000 pages or equivalent blocks.
- Spreadsheet-heavy source with formulas, merged cells, and reference tables.
- Existing DITA package for round-trip and validation tests.

Score each tool on:

- Text extraction quality.
- Reading order preservation.
- Table structure preservation.
- Image extraction and source placement.
- Caption and alt-text evidence.
- Layout and bounding-box metadata.
- Multilingual/OCR quality.
- Memory use and runtime.
- Container complexity.
- License and redistribution risk.
- Traceability into DITAgen source blocks.

## DITA-Specific Quality Metrics

Generic LLM quality metrics are insufficient. DITAgen evaluations must include:

- XML well-formedness.
- DITA 1.3 schema validity.
- Topic-type structural validity for concept, task, reference, troubleshooting, glossary, and map.
- Source block traceability coverage.
- Unsupported-claim or hallucination rate.
- Image reference completeness.
- Alt text review status.
- Table fidelity.
- Cross-reference/key resolution.
- Terminology compliance by language.
- Human edit distance by topic type.
- Approval, rejection, and regeneration rates.
- Conref/keyref reuse opportunity recall when reuse workflows are enabled.

## Build Versus Use

Use off-the-shelf:

- OCR engines.
- PDF, Office, image, spreadsheet, and XML parsing libraries.
- Queue/workflow engines.
- Object storage.
- Identity providers.
- LLM gateway plumbing.
- Observability collectors.
- UI primitives and code editors.
- DITA-OT publishing and validation engine.
- Supply-chain scanning and signing tools.

Build inside DITAgen:

- Source block graph and stable block IDs.
- Asset manifest and DITA image mapping.
- Topic boundary resolver.
- DITA-ready structured output schemas.
- DITA generation rules and validation policy.
- DITA constraint profile authoring, substitution resolution, and profile-aware review explanations.
- Review workflow, approval boundaries, and reversible diffs.
- Skill and script registry.
- Agent tool policy, guardrails, and approval model.
- MCP Gateway policy mapping and capability snapshots.
- DITA-specific quality evaluation.

## Research Inputs

- OASIS DITA 1.3 is an OASIS Standard dated 17 December 2015: [DITA 1.3 specification](https://docs.oasis-open.org/dita/dita/v1.3/os/part0-overview/dita-v1.3-os-part0-overview.html).
- DITA-OT 4.4 documents DITA 2.0 as preview support based on draft grammar files: [DITA 2.0 preview support](https://www.dita-ot.org/dev/reference/dita-v2-0-support.html).
- MCP 2025-11-25 is the latest published MCP specification at the time of this ADR: [MCP specification](https://modelcontextprotocol.io/specification/2025-11-25).
- MCP HTTP authorization requires protected resource metadata and OAuth resource indicators: [MCP authorization](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization).
- RFC 9700 is the OAuth 2.0 Security Best Current Practice: [RFC 9700](https://www.ietf.org/rfc/rfc9700.html).
- OAuth 2.1 remains an active Internet-Draft as `draft-ietf-oauth-v2-1-15`: [IETF datatracker](https://datatracker.ietf.org/doc/draft-ietf-oauth-v2-1/).
- lxml parser options include `load_dtd`, `no_network`, `huge_tree`, and `resolve_entities`: [lxml XMLParser](https://lxml.de/api/lxml.etree.XMLParser-class.html).
- LangGraph supports persistence, human-in-the-loop, fault tolerance, and durable execution: [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence).
- LiteLLM Proxy provides OpenAI-format access to many models, routing, budgets, rate limits, and gateway behavior: [LiteLLM docs](https://docs.litellm.ai/).
- Docling supports many input formats and exports structured representations, Markdown, JSON, and HTML: [Docling supported formats](https://docling-project.github.io/docling/usage/supported_formats/).
- PaddleOCR-VL describes multilingual document parsing support for 109 languages: [PaddleOCR-VL](https://www.paddleocr.ai/v3.3.1/en/version3.x/algorithm/PaddleOCR-VL/PaddleOCR-VL.html).
- pgvector supports exact and approximate vector search inside PostgreSQL: [pgvector](https://github.com/pgvector/pgvector).
- Qdrant documents vector search, hybrid retrieval, filtering, scaling, and payload indexes: [Qdrant overview](https://qdrant.tech/documentation/overview/).
- Cedar is an authorization policy language with a principal-action-resource-context model: [Cedar docs](https://docs.cedarpolicy.com/).
- OPA is a general-purpose policy engine for microservices, Kubernetes, CI/CD, and gateways: [OPA docs](https://www.openpolicyagent.org/docs/latest).
- SLSA 1.2 defines build levels including signed provenance and hardened builds: [SLSA build track](https://slsa.dev/spec/v1.2/build-track-basics).
- gVisor provides sandboxed OCI runtime isolation for Docker and Kubernetes: [gVisor docs](https://gvisor.dev/docs/).
- OpenLineage defines lineage events for jobs, runs, and datasets: [OpenLineage](https://openlineage.io/).
