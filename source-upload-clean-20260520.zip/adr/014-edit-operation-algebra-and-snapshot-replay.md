# ADR 014: Edit-Operation Algebra and Snapshot+Replay

Status: Active
Last verified: 2026-05-10

## Context

ADR-006 established the workbench's edit surface but specified only a
single PATCH `/v1/topics/{id}` route with body `{xml: str}`. That shape
preserves the legacy editor UX but throws away the structural intent of
the edit:

- A reviewer who merges two table rows wants the merged block to trace
  back to both inputs. A raw-XML PATCH loses that lineage at the first
  edit.
- A reviewer who moves a block to a different topic wants the move to
  be reversible without ripple effects on validation issues. A raw-XML
  PATCH treats the move as two unrelated text rewrites.
- A reviewer who renames a topic wants that to be a one-line audit
  entry, not a full XML diff.

Phase 3 of `plans/logical-whistling-widget.md` introduced a typed edit
algebra over an immutable extraction snapshot, with pure replay
producing a projected state on demand. This ADR documents the design.

## Decision

Every workbench edit is an `EditOperation` — a tagged-union value with
one of six variants — appended to the canonical audit log. The
projected topic state is reconstructed at any time by replaying the op
chain against the immutable extraction snapshot. The snapshot is
never mutated; ops produce a new `ProjectedState`.

## Variants

The discriminated union (`packages/python/ditagen_common/ditagen_common/models/edit_op.py`)
has six variants, each with a strict Pydantic payload:

| Variant | Payload | Effect |
|---|---|---|
| `MergeOp` | `block_ids: list[str]` (min 2) | Combines blocks into one derived block; lineage = inputs. |
| `SplitOp` | `block_id`, `char_offset: int >= 1` | Splits one block at the offset; both halves carry the original's lineage. |
| `MoveOp` | `block_id`, `target_topic_id` | Reassigns a block to a different topic's `source_block_ids`. |
| `RetypeOp` | `topic_id`, `topic_type` | Changes `topic_type` (concept/task/reference/troubleshooting/glossary). |
| `RenameOp` | `topic_id`, `title?`, `short_desc?` | Updates topic title and/or short description. |
| `RawXmlOverrideOp` | `topic_id`, `xml`, `is_lossy: Literal[True]` | Replaces `dita_xml` directly. Lossy: block-level lineage cannot be reconstructed from this op alone (Phase 6 ADR-006 back-compat for the legacy PATCH body shape). |

Every variant shares a common envelope:

```
op_id (ULID), op_type, actor_id, created_at (ISO-8601 UTC),
parent_op_id (None for first op in chain), extraction_snapshot_id
```

The JSON schema is at `contracts/edits/edit-operation.schema.json`. The
Pydantic discriminated-union via
`Annotated[Union[...], Field(discriminator="op_type")]` ensures Pydantic
routes deserialization to the correct variant; `EditOperationAdapter`
is the canonical entry point.

## Replay semantics

`ditagen_common.edits.replay(snapshot, ops) -> ProjectedState` is pure.
Guarantees locked by tests in `tests/test_edit_op_replay.py`:

1. **Pure**: never mutates the input `ExtractionSnapshot`. All blocks
   and topics are `.model_copy(deep=True)`'d into the projection.
2. **Deterministic**: same `(snapshot, ops)` produces byte-identical
   `model_dump(mode="json")` output. No wall-clock, no random, no
   dict-iteration-order leakage.
3. **Total**: every op variant is exhaustively dispatched. The trailing
   `assert_never(op)` catches the gap at static-analysis time (mypy)
   AND runtime — adding a 7th variant without updating the dispatch
   fails type-check.
4. **Snapshot-immutable**: ops with mismatched `extraction_snapshot_id`
   raise `SnapshotMismatchError`. The chain integrity check enforces
   `op[i].parent_op_id == op[i-1].op_id`; out-of-order replay raises.

### Derived block identity

Merge/Split produce new blocks whose IDs are deterministic functions
of `op_id`:

```
Merge of N blocks  → 1 derived block: blk_m_<sha1(op_id)[:12]>
Split of 1 block   → 2 derived blocks: blk_s_<sha1(op_id+':a')[:12]>
                                       blk_s_<sha1(op_id+':b')[:12]>
```

Replaying the same op twice yields the same derived IDs — the property
`test_replay_is_deterministic` depends on this.

### Lineage

Every projected block has a `lineage: list[str]` field. For untouched
blocks it's empty. For Merge-derived blocks it's the list of merged
input IDs. For Split-derived blocks it's a single-element list pointing
at the source. `ProjectedState.traceability` maps every projected
`block_id` back to its snapshot-origin set; this is what the workbench
uses to draw evidence connections after edits.

## Persistence and rebuild

- **Source of truth**: per ADR-004 the JsonStore `audit_events` list is
  the canonical ledger. Every `apply_edit_op` call records the op via
  `JsonStore.audit(action=f"edit.{op_type}", ..., metadata={"op": op.model_dump()})`.
- **No parallel cache**: review-service reconstructs the chain by
  scanning `audit_events` filtered to `action.startswith("edit.")` and
  matching `extraction_snapshot_id`. The cost is linear in audit-log
  size; an alpha-scale cost we accept.
- **Cold-start safety**: this design lets a freshly-loaded service
  rebuild the projected state without any in-memory state. Locked by
  `test_cold_start_replay_is_byte_identical` — spin a second service
  instance pointing at the same data dir, ask it to project, byte-for-byte
  match the first instance.

## Undo

`POST /internal/documents/{id}/ops/undo` (Phase 6.C) computes the
inverse of the head op against the projected state BEFORE that op ran,
then appends the inverse as a new op. Inverses:

| Op | Inverse |
|---|---|
| Merge of [a, b] → d | Split of d at `len(text(a))` |
| Split of s @ off → [a, b] | Merge of [a, b] |
| Move b → T | Move b → original_topic |
| Retype t → X | Retype t → previous_topic_type |
| Rename t {title, desc} | Rename t with previous values |
| RawXmlOverride t → xml | RawXmlOverride t → previous_xml (preserves `is_lossy=true`) |

Limitations:
- Merge inverse is only well-defined for 2-block merges (the split
  inverts cleanly). N-way merges are not invertible; replay rejects
  the undo with 422.
- After Split-of-Merge, the resulting block IDs are `blk_s_*`, not the
  original `blk_a`/`blk_b`. Block-content is preserved (concatenated
  texts match), but the literal IDs change. Workbench callers should
  not rely on ID stability across undo.

## RawXmlOverride and the `is_lossy` flag

`RawXmlOverrideOp` exists to preserve the ADR-006 PATCH body shape
without forking the audit log. Replay applies it by setting
`topic.dita_xml = xml` on the projected topic. Because no structural
op precedes it, block-level lineage is broken at this point in the
chain — undo can only restore the previous `dita_xml`, not split the
new XML back into Merge/Split/Move ops.

The variant carries `is_lossy: Literal[True]` so it cannot be
constructed with the flag false. The workbench surfaces this in the
op history so reviewers know lineage stops here.

## Consequences

Positive:
- Reviewer intent is preserved across edits; the audit log answers
  "why did this topic change?" with structural ops, not XML diffs.
- The projected state is rebuildable from cold; no in-memory edit
  cache to drift or get out of sync.
- Phase 6's `topic_mutations_are_audited` architecture invariant has
  teeth because every mutation must go through `JsonStore.audit()`.

Negative:
- Audit-log scan is O(n) per request. Acceptable for alpha; a future
  Postgres migration (ADR-004 long-term goal) will project the chain
  into a fast read view.
- Merge-undo produces new block IDs. Workbench must not key UI state
  on IDs across undo.
- N-way merge undo is unsupported.

## Tests of record

- `tests/test_edit_op_replay.py` — 17 tests covering per-op replay,
  chain integrity, snapshot immutability, determinism, Merge ↔ Split
  inverse property, schema compliance.
- `tests/test_review_service_ops.py::test_cold_start_replay_is_byte_identical`
  — load two service instances on the same data dir; rebuild projected
  state matches byte-for-byte.
- `tests/test_review_service_ops.py::test_apple_ca_merge_then_undo_restores_block_count_via_split_inverse`
  — real Apple CA fixture round-trip: extract → seed topic with two
  real table rows → Merge → Undo → block count N → N-1 → N, lineage
  chains across both ops.
