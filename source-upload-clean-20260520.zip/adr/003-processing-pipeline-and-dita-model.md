# ADR 003: Processing Pipeline And DITA Model

Status: Active

## Context

DITAgen must convert messy source documents into structured DITA without losing topic boundaries, images, tables, multilingual context, or traceability. Source files may include scanned pages, split tables, inconsistent headings, repeated headers and footers, screenshots, manual numbering, mixed languages, and procedures written as prose.

## Decision

Use a staged, resumable pipeline that first creates canonical source artifacts and a topic plan, then generates DITA-ready topic JSON from approved or high-confidence topic candidates. DITA XML is generated deterministically from validated topic JSON.

## Processing Pipeline

1. User creates a project and uploads documents.
2. Upload Service stores originals and publishes extraction jobs.
3. Extraction Service extracts text, images, tables, layout, and OCR content.
4. Markdown Normalization Service creates clean Markdown and asset references as a reviewer-facing projection.
5. Document Analysis Service creates source blocks, style profiles, structure trees, detects language, and identifies structure, topic boundaries, and topic types.
6. Agent Runtime Service can run bounded triage, topic planning, asset context, or validation explanation agents when enabled.
7. System presents the topic plan for human review when confidence is low or project policy requires it.
8. LLM Orchestration Service refactors candidate content into schema-valid `generated-topic.json`.
9. DITA Generation Service writes DITA XML, maps, links, IDs, and language attributes.
10. DITA Validation Service validates output, computes confidence signals, and creates issue records.
11. Review Workspace lets users inspect, edit, regenerate, comment, reject, and approve content.
12. Export Service packages final DITA source and optional rendered outputs.

## Large And Messy Document Handling

Common source problems:

- Scanned pages with low OCR confidence.
- Inconsistent heading levels.
- Repeated headers and footers.
- Screenshots used instead of text.
- Tables split across pages or slides.
- Manual numbering that conflicts with list structure.
- Mixed languages in the same section.
- Embedded images without captions.
- Procedures written as paragraphs.
- Reference data embedded in prose.
- Duplicate content across sections.
- Broken cross references and missing figures.
- PowerPoint speaker notes containing more useful content than the slide.

Product behavior:

- Detect and show source quality warnings before generation.
- Let users exclude noisy pages, slides, sections, headers, and footers.
- Let users merge or split proposed topics before generation.
- Let users mark a section as concept, task, reference, troubleshooting, glossary, or ignore.
- Let users request OCR-only reprocessing for selected pages.
- Preserve original extracted content so users can recover from aggressive cleanup.

## Canonical Source Artifacts

Preprocessing produces a small, predictable artifact set that downstream services can consume without re-parsing the original document. Markdown is retained as a review projection, not as the only source of truth.

Expected artifacts:

- `source-lines.jsonl`: Raw extracted lines and font runs with page, bbox, style, OCR, and repetition evidence.
- `source-blocks.jsonl`: Normalized source blocks with stable IDs, block types, inline runs, style summaries, asset references, and confidence.
- `style-profile.json`: Document-level font clusters, spacing rules, heading thresholds, and repeated-content rules.
- `structure-tree.json`: Inferred hierarchy, repaired heading levels, ambiguous heading flags, and repeated running content.
- `content.md`: Normalized Markdown with stable block IDs and asset references.
- `assets/images/...`: Extracted image assets using stable names or asset IDs.
- `metadata.json`: Document metadata, source file metadata, parser metadata, and extraction profile.
- `traceability.json`: Mapping from source locations to Markdown blocks and generated DITA topics.
- `language.json`: Document, section, block, and topic language detection results.

LLM-facing artifacts:

- `topic-plan.json`: Topic candidates, boundaries, topic types, parent-child relationships, map outline, confidence, and review issues.
- `generated-topic.json`: DITA-ready semantic content for one topic candidate, including inline semantics, traceability, and confidence.

## Topic Boundary Strategy

Do not split directly by token count. Build a normalized document graph first:

- Document.
- Part or chapter.
- Page, slide, or section.
- Block.
- Inline spans.
- Assets.

Each block should have:

- Stable `block_id`.
- Source location.
- Language.
- Bounding box where available.
- Page, slide, or section reference.
- Heading path.
- Asset references.
- Confidence score.
- Content hash.

LLM calls operate on topic candidates plus a bounded context envelope. Topic planning should use heading hierarchy, layout signals, language shifts, procedure markers, tables, images, repeated content, and cross references.

Boundary resolver behavior:

- Merge weak adjacent chunks.
- Split overlarge topics.
- Preserve parent heading context.
- Include nearby preceding and following blocks.
- Flag ambiguous boundaries for human review.
- Keep cross-boundary registries for links, figures, table continuations, glossary terms, duplicate definitions, and unresolved references.
- Generate maps after all topic candidates are validated.

## Image And Asset Pipeline

Every extracted image receives:

- Immutable `asset_id`.
- Source document ID and source location.
- Hash, MIME type, dimensions, and extraction method.
- Nearby caption text.
- OCR text if available.
- Linked source blocks.
- DITA href.
- Alt text status.

Extraction guidance:

- DOCX should use direct OOXML package and relationship traversal as the reliable path. `python-docx` helps for inline pictures but should not be the only extractor because floating images require additional handling.
- PPTX should use `python-pptx` picture blobs plus slide coordinates and speaker-note context.
- PDF should use PyMuPDF image xrefs and `extract_image`; page rasterization is fallback for figure regions or scanned pages.

DITA generation rules:

- Emit `<fig>` with `<title>` when a caption is known.
- Otherwise emit `<image href="..."><alt>...</alt></image>` with reviewable alt text.
- Alt text priority is source alt/caption, nearby paragraph, OCR or vision description, then reviewer-required placeholder.
- Export validation must confirm every referenced image exists in the package.

## Review Lifecycle

Topic states:

- `planned`: Topic candidate exists, but DITA was not generated.
- `generated`: DITA was generated but not reviewed.
- `needs_attention`: Validation errors, low confidence, missing traceability, or terminology issues exist.
- `in_review`: Assigned reviewer is actively reviewing.
- `changes_requested`: Reviewer rejected the topic or requested regeneration.
- `edited`: Human changed generated content.
- `approved`: Topic is approved for export.
- `exported`: Topic was included in an export package.
- `archived`: Topic is no longer active.

Review rules:

- A topic cannot be exported unless approved or project policy allows warnings.
- Blocking validation errors require explicit override.
- Approval, rejection, edit, override, and regeneration events are audited.
- Regeneration supports one topic, section, table, or procedure.
- Human edits are stored separately from generated baselines for evaluation.

## Concurrency, Versioning, And Conflict Resolution

Topic content uses separate versioned streams:

- `approved_baseline`: Latest approved topic version.
- `current_draft`: Human working copy.
- `agent_proposal`: Non-binding agent suggestion.
- `regeneration_candidate`: Regeneration output awaiting review.

Rules:

- Human edits update `current_draft`; they do not overwrite `approved_baseline` until approval.
- Regeneration creates `regeneration_candidate`; it is never auto-applied over human edits.
- Agent suggestions create `agent_proposal`; they must be accepted or discarded by a user.
- Approval promotes `current_draft` to `approved_baseline` only when the draft is based on the latest approved version.
- Every mutable record has an `etag`; stale updates are rejected with a conflict response.
- Active editing uses a soft lock with heartbeat and TTL, not a permanent lock.
- Template, terminology, and conversion profile changes are versioned; in-flight jobs continue with pinned versions.
- Topic splits and merges acquire a topic-level soft lock and preserve in-flight drafts as reviewable versions.

## Quality Gates

- Extraction gate: text, images, tables, and OCR confidence meet thresholds.
- Source artifact gate: source lines, source blocks, style profile, structure tree, normalized Markdown, and assets have stable IDs, valid references, usable hierarchy, and review flags for ambiguous evidence.
- Topic plan gate: topic boundaries and types meet confidence thresholds.
- Generation gate: `generated-topic.json` matches schema, preserves traceability, and is supported by source blocks.
- DITA gate: XML, topic type, map, link, key, image, and language validation pass.
- DITA constraint gate: generated content conforms to the active DITA constraint profile, including blocked elements, attribute restrictions, and substitution rules.
- Terminology gate: required terms are used and forbidden terms are flagged.
- Review gate: reviewers approve or provide override reason.
- Export gate: selected topics, maps, assets, and reports are complete.

Example confidence model:

```json
{
  "topic_id": "top_install_connector",
  "overall_confidence": 0.86,
  "signals": {
    "extraction": 0.91,
    "topic_classification": 0.84,
    "dita_validation": 0.95,
    "terminology": 0.78,
    "traceability": 0.89
  },
  "blocking_issues": 0,
  "warnings": 3
}
```

## DITA Topic Model

Production target:

- MVP generates DITA 1.3 technical-content topics and maps.
- Project conversion profiles pin a DITA constraint profile version that can block or restrict selected DITA elements and attributes.
- DITA 2.0 is not a production target until it is an approved OASIS standard and customer authoring, validation, publishing, and CCMS tooling support it.
- DITA-OT preview support for DITA 2.0 draft features can be evaluated in fixtures, but generated customer packages should stay pinned to the project conversion profile's approved DITA version.

Initial topic types:

- `concept`: Explanatory content, overviews, definitions, background.
- `task`: Step-based procedures with prerequisites, steps, results, and postrequisites.
- `reference`: Tables, parameters, commands, fields, API details, and lookup content.
- `troubleshooting`: Problem, cause, solution, symptoms, and verification.
- `glossary`: Terms, definitions, abbreviations, and aliases.
- `map`: Topic organization, hierarchy, keys, and relationships.

Each generated topic includes:

- Stable topic ID.
- Topic type.
- Source document ID.
- Source block IDs.
- Language.
- Confidence score.
- Validation status.
- Review status.
- Generated XML path.
- Editable content model.
- Assigned owner and reviewer.
- Last generation metadata.
- Last human edit metadata.
- Export eligibility.

## Multilingual Support

DITAgen treats language as a first-class property at document, section, paragraph, block, and topic level.

Requirements:

- Detect source language automatically.
- Allow user override.
- Preserve original language in extracted Markdown.
- Generate DITA topics with correct `xml:lang`.
- Support mixed-language source documents.
- Store terminology per language and project.
- Support locale-specific templates and writing rules.
- Keep translation separate from source refactoring.
- Flag language mixing inside a topic when policy requires one language per topic.
- Export translation handoff packages after source DITA is approved.

Suggested language metadata:

```json
{
  "document_language": "en-US",
  "detected_languages": ["en-US", "de-DE"],
  "blocks": [
    {
      "block_id": "blk_001",
      "language": "en-US",
      "confidence": 0.97
    }
  ]
}
```

Translation workflow:

1. Convert source documents into approved source-language DITA.
2. Lock source topics or create a translation branch.
3. Export localization package with DITA, images, terminology, and context.
4. Import translated DITA or translation memory output.
5. Validate translated topics for DITA structure, terminology, links, and `xml:lang`.
6. Review translated output side by side with source.

## DITA Quality Evaluation Metrics

DITAgen quality evaluation must measure structured technical-content correctness, not only model helpfulness or generic text quality.

Core metrics:

- XML well-formedness.
- DITA 1.3 schema validity.
- Topic-type structural validity.
- Source block traceability coverage.
- Unsupported-claim or hallucination rate.
- Image reference completeness.
- Alt text review status.
- Table fidelity.
- Cross-reference and key resolution.
- Terminology compliance by language.
- Human edit distance by topic type.
- Approval, rejection, and regeneration rates.
- Conref and keyref reuse opportunity recall when reuse workflows are enabled.

## Content Governance

Governance capabilities:

- Conversion profiles.
- DITA constraint profiles for blocked elements, restricted attributes, preferred substitutions, and severity.
- Topic and map templates.
- Required metadata fields.
- Filename and ID conventions.
- Allowed topic types.
- Required review steps.
- Validation severity policies.
- Terminology rules.
- Export target policies.
- Retention policies.
- Agent autonomy policy, enabled skills, allowed tools, and approval requirements.

Example conversion profile:

```json
{
  "profile_id": "hardware_docs_default",
  "target_dita_version": "1.3",
  "dita_constraint_profile_version": "hardware_docs_dita13@3.0.0",
  "allowed_topic_types": ["concept", "task", "reference", "troubleshooting"],
  "blocked_elements": ["section"],
  "require_topic_plan_approval": true,
  "minimum_export_confidence": 0.82,
  "block_export_on_validation_errors": true,
  "default_language": "en-US",
  "filename_strategy": "slug-title-with-topic-id"
}
```
