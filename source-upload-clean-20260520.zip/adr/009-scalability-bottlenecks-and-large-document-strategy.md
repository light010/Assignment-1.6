# ADR 009: Scalability, Bottlenecks, And Large Document Strategy

Status: Active

## Context

DITAgen must handle enterprise-scale source material: 1-2 GB files, thousands of pages or slides, mixed scanned and digital content, image-heavy documents, multilingual sections, and long-running batch conversions. The biggest risk is not just slow processing; it is losing source traceability, topic boundaries, image references, or user trust while trying to fit large documents into parser memory or LLM context windows.

## Decision

Use a manifest-driven, artifact-first, backpressure-aware pipeline. Physical extraction can be split by page, slide, section, or file range, but DITA generation must be based on semantic topic candidates produced from a normalized source block graph.

## Bottleneck Analysis

Primary bottlenecks:

- Upload bottleneck: large files fail or time out if uploaded as single requests.
- Parser memory bottleneck: DOCX, PDF, PPTX, OCR, and conversion tools can load more data than expected.
- OCR bottleneck: scanned pages are CPU-heavy and slow.
- LLM context bottleneck: large documents cannot be sent whole without cost, latency, and context-loss problems.
- Topic boundary bottleneck: naive chunking by token count can split procedures, tables, figures, warnings, or troubleshooting flows.
- Image bottleneck: extracted images can lose captions, placement, alt text, or DITA references.
- Queue bottleneck: long OCR or export jobs can block short metadata or notification jobs.
- Database bottleneck: storing large Markdown, XML, traces, or logs in PostgreSQL causes bloat.
- Frontend bottleneck: loading thousands of blocks, issues, topics, or trace entries can freeze the browser.
- Export bottleneck: DITA-OT builds can be CPU and memory intensive, especially for large maps and image-heavy packages.

## Large Document Processing Strategy

Do not split source content directly by token count. Build a normalized document graph first:

- `document`: Original upload and extraction profile.
- `part`: Chapter, section group, slide deck section, or file member.
- `page_or_slide`: Physical source unit.
- `block`: Paragraph, heading, table, figure, note, warning, step, code block, or list.
- `inline_span`: Inline formatting, term, link, UI label, or cross-reference.
- `asset`: Image, media, embedded object, or extracted figure.

Physical chunking is allowed for extraction and OCR. Semantic chunking is required for topic planning and DITA generation.

Each source block must carry:

- Stable `block_id`.
- Source document ID.
- Source location.
- Page, slide, section, or bounding-box reference.
- Heading path.
- Language and confidence.
- Block type and confidence.
- Asset references.
- Content hash.
- Extraction confidence.

## Manifest Artifacts

Document manifest:

```json
{
  "document_id": "doc_123",
  "source_filename": "install-guide.pdf",
  "source_hash": "sha256:...",
  "file_type": "pdf",
  "page_count": 1840,
  "artifact_version": "v3",
  "extraction_profile": "pdf_mixed_ocr",
  "created_artifacts": [
    "source-lines.jsonl",
    "source-blocks.jsonl",
    "style-profile.json",
    "structure-tree.json",
    "asset-manifest.json",
    "content.md",
    "traceability.json",
    "language.json"
  ]
}
```

Source block:

```json
{
  "block_id": "blk_001",
  "document_id": "doc_123",
  "block_type": "procedure_step",
  "text": "Click Install.",
  "language": "en-US",
  "source_location": {
    "page": 12,
    "bbox": [72, 144, 520, 166]
  },
  "heading_path": ["Install the connector", "Run the installer"],
  "asset_refs": ["asset_009"],
  "content_hash": "sha256:...",
  "confidence": 0.94
}
```

Asset manifest:

```json
{
  "asset_id": "asset_009",
  "document_id": "doc_123",
  "source_location": {
    "page": 12,
    "bbox": [80, 190, 500, 430]
  },
  "mime_type": "image/png",
  "hash": "sha256:...",
  "width": 1200,
  "height": 720,
  "extraction_method": "pdf_xref",
  "nearby_caption": "Installer welcome screen",
  "ocr_text": "Welcome to Setup",
  "dita_href": "images/asset_009.png",
  "alt_text_status": "proposed"
}
```

Topic candidate:

```json
{
  "topic_candidate_id": "tc_042",
  "topic_type": "task",
  "title": "Install the connector",
  "source_block_ids": ["blk_001", "blk_002", "blk_003"],
  "context_before": ["blk_000"],
  "context_after": ["blk_004"],
  "asset_refs": ["asset_009"],
  "boundary_confidence": 0.88,
  "review_required": false
}
```

## Topic Boundary Preservation

Topic planning must use:

- Heading hierarchy.
- Layout and page or slide boundaries.
- Procedure markers.
- Tables and table continuations.
- Figure placement and captions.
- Language shifts.
- Warnings, notes, prerequisites, results, and troubleshooting markers.
- Cross references and repeated definitions.

Boundary resolver behavior:

- Merge weak adjacent candidates.
- Split overlarge candidates only at semantic boundaries.
- Preserve parent heading context.
- Include nearby preceding and following source blocks.
- Flag ambiguous boundaries for human review.
- Keep a cross-boundary registry for links, figures, split tables, glossary terms, duplicate definitions, and unresolved references.
- Generate DITA maps after all topic candidates are validated.

## Image And Asset Preservation

Every image must be extracted once, hashed, stored in object storage, and referenced by `asset_id`.

Rules:

- Preserve original image bytes when available.
- Rasterize source regions only when original embedded bytes are unavailable or source is scanned.
- Store image-to-block and image-to-topic relationships.
- Carry captions, nearby paragraphs, OCR text, and source alt text into the asset context.
- Generate DITA image references only from the asset manifest.
- Validate that every DITA image reference exists before export.
- Require reviewer attention when alt text is missing or generated from weak context.

## Queue And Backpressure Strategy

Use separate queues for:

- Upload finalization.
- Extraction.
- OCR.
- Markdown normalization.
- Document analysis.
- Topic planning.
- LLM generation.
- Agent runs.
- Validation.
- Export.
- Notifications.

Operational rules:

- Long-running workers use low prefetch and late acknowledgements.
- Short metadata and notification tasks can use higher prefetch.
- OCR, LLM, agent, and export queues have per-project concurrency limits.
- Failed jobs include failure category, retry count, stage, input artifact hash, and user-visible recovery action.
- Dead-letter queues are required for non-transient failures.
- Retrying a stage must not rewrite successful immutable artifacts unless the input hash or profile changes.

## Validation And Export Scale Strategy

- Validate each generated topic before package validation.
- Validate maps, links, keys, image references, IDs, and language metadata at package level.
- Run DITA-OT smoke builds with validation enabled before marking an export as ready.
- Keep DITA-OT temp and output directories isolated per export job.
- Store validation and export logs in object storage.
- Link logs and reports from database records.

## Frontend Scale Strategy

- Virtualize source block lists, topic lists, validation issues, comments, agent traces, and activity logs.
- Lazy-load source previews by page, slide, topic, or block range.
- Never load the full DITA package into the browser.
- Edit one topic or bounded topic set at a time.
- Stream progress updates by job stage.
- Use artifact version IDs to prevent stale edits.

## API Additions

- `GET /documents/{document_id}/manifest`
- `GET /documents/{document_id}/blocks?cursor=...`
- `GET /documents/{document_id}/assets`
- `POST /documents/{document_id}/topic-plan/recompute`
- `POST /topics/{topic_id}/regenerate-section`
- `GET /exports/{export_id}/logs`

## Event Additions

- `document.manifest.created`
- `source.blocks.extracted`
- `assets.extracted`
- `topic.boundaries.proposed`
- `topic.boundaries.review_required`
- `asset.alt_text.required`
- `export.smoke_build.completed`

## Contract Additions

- `document-manifest.schema.json`
- `source-line.schema.json`
- `source-block.schema.json`
- `style-profile.schema.json`
- `structure-tree.schema.json`
- `asset-manifest.schema.json`
- `topic-candidate.schema.json`
- `topic-plan.schema.json`
- `generated-topic.schema.json`
- `export-log.schema.json`

## Acceptance Scenarios

- 1 GB PDF with 2,000 pages, mixed scanned and digital text.
- DOCX with inline images, floating images, captions, tables, headers, and footers.
- PPTX with image-heavy slides and speaker notes.
- Mixed-language document where language changes inside sections.
- Procedure split across page boundaries.
- Table split across pages.
- Duplicate image reused in multiple topics.
- Failed OCR or LLM job resumes without redoing successful stages.
- DITA ZIP export includes image references, map links, and validation logs.

## Success Criteria

- No service loads full large documents into memory unless a controlled parser requires local spooling.
- All generated topics retain source block traceability.
- All referenced DITA images exist in the export package.
- Low-confidence topic boundaries and missing alt text are visible to reviewers.
- Large processing jobs are resumable from the last completed artifact stage.
