# ADR 005: Agentic, LLM, And MCP Architecture

Status: Active
Last verified: 2026-05-10

## Context

DITAgen benefits from LLMs and agents for classification, topic planning, refactoring, validation explanation, and review assistance. These capabilities must not become opaque, autonomous, or unsafe. MCP can help connect agents to approved external tools and context, but it must not replace internal workflow architecture.

## Decision

Use a deterministic pipeline first and bounded assistive agents second. Use provider-neutral DITAgen contracts, a central LLM Gateway for provider access, and MCP through a controlled MCP Gateway rather than direct unrestricted agent access.

The first model-call interface should be OpenAI-compatible where possible because many gateways and providers support that shape. This is not the same as making the OpenAI Agents SDK the default orchestration runtime. For stateful human-in-the-loop agent graphs, LangGraph is the preferred off-the-shelf orchestration candidate while DITAgen-owned schemas, tool policies, approval rules, traces, and artifact contracts remain authoritative.

## LLM Governance

Requirements:

- Version every prompt template.
- Record model, provider, prompt version, input artifact hash, and output artifact hash.
- Support per-project model configuration.
- Support per-project token and cost budgets.
- Block or warn when a generation request exceeds budget.
- Allow admins to disable external LLM providers for sensitive projects.
- Keep raw source document content out of analytics and logs.
- Evaluate prompts against fixture documents before promotion.
- Store human feedback, regeneration reasons, and edit distance as quality signals.
- Provide a fallback path when a provider is unavailable.

## LLM Operations

LLM Gateway:

- Route model calls through a central LLM Gateway rather than duplicating provider logic in every service.
- The gateway handles provider credentials, routing, retries, fallbacks, rate limits, budget checks, request timeouts, model canaries, token/cost accounting, and telemetry export.
- The gateway must not decide artifact state, approvals, exports, or validation outcomes; those remain DITAgen service responsibilities.

**LiteLLM Proxy decision (closed Phase 8, 2026-05-09)**: ruled out for the alpha. The original MVP plan suggested evaluating LiteLLM Proxy as a thin OpenAI-compatible front for many providers. In practice the gateway only needs to talk to one provider at a time (operator-chosen), and adding LiteLLM as a middle hop pushes credential and budget management out of DITAgen-owned code paths. Instead, `services/llm-gateway-service` implements the gateway directly:

- One `Provider` abstract base class with typed methods (`topic_plan`, `generate_topic`, `chat_completions`).
- Two registered providers: `fixture-deterministic` (rule-based; default) and `LlamaProvider` (OpenAI-compatible HTTP). The Llama provider is opt-in via `DITAGEN_LLAMA_BASE_URL` + `DITAGEN_LLAMA_MODEL`; without those env vars the registry returns only the fixture and the gateway still functions.
- Routing + credentials + retries + budgets + cost accounting + token telemetry are all in-tree under `services/llm-gateway-service/app/`. Adding a provider (Anthropic, OpenAI direct, Bedrock) is a new `Provider` subclass; the registry composition stays one-line.

Portkey, Helicone, or equivalent gateway products can still be evaluated if governance, semantic caching, prompt management, or observability requirements outgrow the in-tree stack — but the seam is the `Provider` ABC, not a swapped-in third-party proxy.

Provider abstraction:

- All provider calls go through a typed provider interface.
- The first model-call implementation path is OpenAI-compatible, but the interface must not require provider-specific features unless feature-flagged.
- Each provider adapter declares supported capabilities such as structured outputs, tool calling, prompt caching, streaming, vision, and zero-data-retention mode.

Data handling:

- Source document content is treated as data, not instruction.
- Prompt-injection checks run before direct LLM calls and agent calls.
- Projects with sensitive data can enable pre-call redaction for emails, phone numbers, IDs, secrets, and custom patterns.
- Raw source text is excluded from analytics and general logs.
- Enterprise deployments may use customer-provided LLM credentials stored only as secret references.

**Prompt-injection check (Phase 8 implementation)** — `services/llm-gateway-service/app/gateway_safety.py` runs every user-supplied content string through two layers BEFORE the prompt template is rendered:

1. Length cap: content longer than `DITAGEN_LLAMA_MAX_USER_CONTENT_CHARS` (default 120k) is rejected without scanning.
2. Regex denylist for known prompt-injection idioms (ignore/disregard prior instructions with chained qualifiers, role-hijack "you are now …", system-prompt extraction patterns, markdown image data-URLs).

A blocked call raises `ProviderSafetyError`. Analysis-service does NOT fall back to fixture on safety errors — the fixture sees the same content. The route surfaces a structured 422.

**Credential model (Phase 8 implementation)** — `services/llm-gateway-service/app/gateway_credentials.py` provides a `CredentialProvider` Protocol with four implementations. The factory `build_credential_provider()` picks the most specific mode whose env vars are set:

| Mode | Env trigger | Headers attached | Use case |
|---|---|---|---|
| `NoAuthCredentialProvider` | nothing set | (none) | Local Ollama on `http://localhost:11434`. |
| `StaticBearerCredentialProvider` | `DITAGEN_LLAMA_API_KEY` | `Authorization: Bearer <api_key>` | Long-lived hosted-endpoint key. |
| `HeaderBundleCredentialProvider` | `DITAGEN_LLAMA_TENANT_ID` + `_APP_ID` + `_SECRET` (no token endpoint) | `X-Tenant-Id` + `X-App-Id` + `Authorization: Bearer <secret>` | Enterprise LLM gateway that authenticates at the edge and needs the tenancy bundle stamped per request. |
| `OAuth2ClientCredentialsProvider` | triple + `DITAGEN_LLAMA_TOKEN_ENDPOINT` | `Authorization: Bearer <exchanged_token>` (cached with TTL) | Short-lived bearers from an OAuth2 token endpoint (Azure-style, Okta-style, custom IDP). Tenant placement in body / path / header is configurable. |

Mixing `api_key` with the (tenant, app, secret) bundle raises at startup so audit logs never have to disambiguate.

Robustness properties locked by tests:

- The OAuth2 provider caches the exchanged bearer until `expires_in − 60s` and refreshes on 401 from the LLM endpoint (token expiry race).
- A `CredentialError` from the token endpoint surfaces as `ProviderRetryableError` so analysis-service's standard fallback chain handles a flaky auth service, not a separate code path.
- LLM-endpoint 401 invalidates the credential cache and retries with a fresh exchange in the same call. The 4xx fail-fast (other than 401) still applies — a 403 won't loop.

Structured output:

- Use JSON Schema or provider-native structured output when available.
- Use typed tool calls for structured transformations when schema mode is unavailable.
- Validate every model output before it can create artifacts, trigger tools, or update topic state.
- Malformed outputs get a small repair retry budget; repeated failures become reviewable issues.

Routing and fallback:

- Use cheaper models for triage, classification, source quality summaries, and low-risk explanation.
- Use stronger models for DITA refactoring, table repair, and multilingual content where accuracy matters.
- Escalate to a stronger model when confidence is low or validation fails.
- Provider fallback is configured per project or skill and protected by circuit breakers and rate-limit tracking.

Cost and performance:

- Estimate tokens before calls where possible.
- Track provider latency, error rate, token count, cost, cache hit ratio, and output validation failure rate.
- Use prompt caching for stable system instructions, conversion profiles, and templates where supported.
- Enforce per-tenant and per-project monthly token and cost budgets.

Quality evaluation:

- Maintain golden source documents and expected DITA fixtures per skill.
- Run regression evaluation on prompt, skill, schema, provider, or model changes.
- Track human edit distance, rejection reason, regeneration reason, and validation failures as quality signals.
- Use a "no net-new facts" policy: models restructure, classify, and clarify source content, but unsupported claims are flagged.

## Agentic Principles

- Agents are workflow helpers, not platform owners.
- Agents operate inside project, role, artifact, budget, and tool boundaries.
- Agents return typed, schema-validated outputs.
- Agents do not directly mutate approved project artifacts.
- Risky or user-visible changes require human approval.
- Every model call, tool call, handoff, guardrail trip, approval, and artifact change is traceable.

## Agent Runtime

The Agent Runtime Service coordinates bounded agent runs.

Runtime responsibilities:

- Create and resume agent runs.
- Enforce max turns, timeouts, model policy, token budgets, cost budgets, and allowed tools.
- Load context from approved source artifacts, topic plans, terminology, templates, validation reports, and review state.
- Load the active DITA constraint profile and use typed tools to resolve allowed elements instead of asking the model to improvise tag substitutions.
- Run input, tool, and output guardrails.
- Request human approval for restricted actions.
- Persist traces and emit agent events.
- Return typed outputs for downstream validation.

Runtime implementation guidance:

- Prefer LangGraph for stateful agent flows that need graph execution, checkpointing, durable human approval, replay, or long-running recovery.
- Use the OpenAI Agents SDK only for bounded OpenAI-specific workflows where its tools, handoffs, guardrails, tracing, or hosted MCP behavior clearly reduce implementation work.
- Do not make CrewAI, AutoGen, or highly autonomous multi-agent frameworks core MVP dependencies.
- Keep DITAgen's agent-run, trace, tool, skill, approval, and guardrail schemas stable even if the internal framework changes.

## Recommended Agents

- `Document Triage Agent`: detects document quality issues, language, likely structure, and extraction strategy.
- `Topic Planning Agent`: proposes DITA topic boundaries and topic types from normalized blocks.
- `DITA Refactoring Agent`: converts one approved topic candidate into structured DITA-ready JSON.
- `Asset Context Agent`: proposes image placement, caption mapping, and alt text from source context.
- `Validation Explanation Agent`: explains validation errors and suggests safe fixes.
- `Review Assistant Agent`: helps reviewers compare source, Markdown, DITA, traceability, and confidence signals.

MVP should avoid separate agents for every DITA topic type. Use one DITA Refactoring Agent with topic-type-specific skills and templates.

## Topic JSON Generation Workflow

Topic generation is a multi-pass workflow, not a single prompt:

1. Deterministic preprocessing creates source lines, source blocks, style profiles, structure trees, asset manifests, Markdown projections, and source previews.
2. Topic Planning Agent reads approved preprocessing artifacts and returns schema-valid `topic-plan.json`.
3. Human review gates low-confidence boundaries, ambiguous heading hierarchy, unsupported source ranges, or policy-required review.
4. DITA Refactoring Agent reads one approved or high-confidence topic candidate plus bounded context and returns schema-valid `generated-topic.json`.
5. Validation services check schema validity, source block references, source support, DITA constraint profile rules, and traceability.
6. DITA Generation Service writes XML deterministically from `generated-topic.json`.
7. Validation Explanation Agent runs only after concrete validation failures and can produce one bounded repair attempt when policy allows it.

Agents may recommend topic boundaries, DITA-ready JSON, and repair candidates. They do not write final XML, mutate approved topics, bypass validation, or publish/export.

## Skill And Script Registry

Skills are versioned capability packages containing instructions, schemas, allowed tools, examples, evaluation fixtures, and optional deterministic scripts.

Initial skills:

- `docx-extraction`
- `topic-planning`
- `dita-task-generation`
- `dita-reference-generation`
- `table-repair`
- `alt-text-generation`
- `dita-validation-fix`

Script rules:

- Scripts are deterministic helpers called through typed tools.
- Scripts are registered, versioned, reviewed, and allowlisted.
- Scripts declare input schema, output schema, permissions, timeout, cost tier, and approval requirement.
- Agents cannot write or modify scripts at runtime.
- Dynamic third-party skill marketplaces are post-MVP.

Example skill manifest:

```json
{
  "skill_id": "alt-text-generation",
  "version": "1.0.0",
  "owner": "content-platform",
  "input_schema": "asset-context-input.schema.json",
  "output_schema": "asset-alt-text-output.schema.json",
  "allowed_tools": ["read_source_blocks", "read_asset_metadata"],
  "timeout_seconds": 45,
  "cost_tier": "low",
  "approval_required": false
}
```

## Hooks

Hooks are observability and policy extension points, not business-logic containers.

Required hooks:

- `on_agent_start`
- `on_agent_end`
- `on_llm_start`
- `on_llm_end`
- `on_tool_start`
- `on_tool_end`
- `on_handoff`
- `on_guardrail_trip`

Allowed behavior:

- Log structured lifecycle events.
- Meter token and tool usage.
- Emit audit and analytics events.
- Prefetch bounded context.
- Enforce policy checks.
- Attach trace spans and correlation IDs.

Disallowed behavior:

- Mutating approved content directly.
- Bypassing permissions.
- Changing prompts, templates, or terminology without versioned configuration.
- Hiding failures from user-facing job state.

## Guardrails

Input guardrails:

- Verify project access, role permissions, document sensitivity, and operation scope.
- Detect prompt-injection attempts in user instructions and source document text.
- Reject requests that bypass validation, approval, retention, security, or export policy.

Tool guardrails:

- Validate tool input schemas.
- Check project, role, skill, script, and artifact permissions.
- Reject stale artifact versions.
- Enforce rate limits, cost limits, and allowlists.
- Record before and after tool state for audit.

Output guardrails:

- Validate structured output schemas.
- Validate DITA XML when output includes DITA-ready content.
- Reject or flag blocked DITA elements and attribute values according to the active DITA constraint profile.
- Check source traceability coverage.
- Check terminology rules.
- Flag hallucination risk when claims are not supported by source blocks.
- Require review for missing image alt text, low-confidence topic boundaries, or changed meaning.

## Human Approval Boundaries

Auto-allowed:

- Classify source blocks.
- Summarize source quality issues.
- Suggest topic boundaries.
- Explain validation issues.
- Generate non-destructive regeneration drafts.
- Suggest captions, alt text, and terminology fixes.

Approval-required:

- Replace approved content.
- Delete topics, maps, comments, assets, or source artifacts.
- Export or publish content.
- Change templates, terminology, conversion profiles, or validation policy.
- Run expensive batch jobs.
- Enable new skills or scripts.

Never allowed in MVP:

- Unrestricted shell execution.
- Self-modifying prompts or scripts.
- Autonomous publishing.
- Hidden external network calls.
- Cross-project document access.
- Direct mutation of approved artifacts without reversible diff and explicit approval.

## MCP Usage Strategy

MCP connects agents to external tools and context without custom integration code for every system. In DITAgen, MCP is a controlled adapter layer.

Best-fit MCP use cases:

- Read context from approved external repositories, CCMS systems, CMS systems, terminology stores, issue trackers, or design systems.
- Expose DITAgen project context to trusted internal assistants as MCP resources.
- Reuse external tools for ticket lookup, terminology lookup, asset lookup, or publishing preflight checks.
- Provide reusable prompts for organization-specific style, terminology, and review workflows.
- Let enterprise automation query conversion status without direct database access.

MCP should not be used for:

- Internal service-to-service workflow state.
- Upload storage, extraction, validation, export, authentication, billing, or approval decisions.
- Unrestricted filesystem access.
- Hidden agent network calls.
- Running arbitrary scripts from users or third-party MCP servers.

Recommended MCP architecture:

- Agent Runtime Service acts as the MCP host from DITAgen's perspective.
- MCP Gateway owns MCP client sessions, server registration, capability discovery, policy enforcement, and audit logging.
- Internal DITAgen MCP servers can expose read-only resources such as source blocks, asset manifests, validation reports, topic plans, and approved DITA topics.
- External MCP servers connect only through the MCP Gateway and only after admin approval.
- MCP tools are mapped into DITAgen's typed tool registry before agents can use them.
- MCP resources are copied or referenced by artifact version so agent output remains reproducible.

MVP MCP capabilities:

- Register approved MCP servers per organization or project.
- Discover MCP tools, resources, and prompts.
- Expose read-only MCP resources to bounded agents.
- Allow low-risk read tools after policy checks.
- Require approval for mutating MCP tools.
- Audit every MCP capability discovery and tool call.

MCP security rules:

- Treat MCP servers, tool annotations, and descriptions as untrusted unless trusted and allowlisted.
- Pin supported MCP protocol versions in integration tests and track the current 2025-11-25 specification.
- Require HTTPS and OAuth-based authorization for remote production MCP servers where supported.
- For HTTP transports, follow OAuth 2.0 security best current practice, OAuth 2.1 draft patterns where implemented, OAuth 2.0 Protected Resource Metadata, and OAuth 2.0 Resource Indicators.
- MCP clients must request access tokens for the intended MCP server resource and must not send tokens to a different MCP server.
- Use short-lived credentials stored in the secrets manager.
- Apply least-privilege scopes.
- Block private IP ranges and unsafe redirects for server-side MCP connections unless explicitly allowed for local development.
- Run local STDIO MCP servers only in sandboxed environments with restricted filesystem and network access.
- Require human approval for mutating tools, external writes, publishing, deletion, or high-cost actions.
- Record server identity, capability snapshot, tool input, output summary, artifact version, user, and approval state.

Example MCP server registration:

```json
{
  "server_id": "ccms-readonly",
  "display_name": "Enterprise CCMS Readonly",
  "transport": "streamable_http",
  "base_url": "https://ccms.example.com/mcp",
  "trust_level": "approved_internal",
  "allowed_capabilities": ["resources", "tools"],
  "allowed_tools": ["search_topics", "read_topic", "read_asset"],
  "mutating_tools_allowed": false,
  "approval_required": true,
  "scope": "project"
}
```

## Test Scenarios

- Agent run respects max turns, timeout, allowed tools, and budget.
- Agent cannot access documents outside the user's project.
- Agent cannot call a disabled skill or script.
- Tool call with stale artifact version is rejected.
- Prompt-injection text inside source documents cannot override system policy.
- Topic Planning Agent returns schema-valid `topic-plan.json` with valid source block references and map outline references.
- DITA Refactoring Agent returns schema-valid structured output.
- DITA Refactoring Agent returns one-topic `generated-topic.json`, not final XML, and preserves inline semantics such as UI controls and code phrases when supported by source evidence.
- DITA Refactoring Agent respects active DITA constraint profiles and cannot emit blocked elements as accepted output.
- Asset Context Agent preserves source image references and generates reviewable alt text.
- Validation Explanation Agent explains errors without changing approved topics unless approved.
- Approval-required actions create audit records.
- Agent trace contains model calls, tool calls, guardrails, handoffs, cost, and artifact hashes.
- MCP capability discovery respects allowlists and project scope.
- MCP tool calls are blocked when trust, scope, artifact version, or approval requirements fail.
- Prompt-injection text returned from MCP resources cannot override DITAgen policy.

## Research Inputs

- LangGraph supports persistence, human-in-the-loop workflows, fault tolerance, and durable execution: [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence).
- LiteLLM Proxy provides an OpenAI-compatible gateway with routing, budgets, rate limits, retries, and callbacks: [LiteLLM docs](https://docs.litellm.ai/).
- OpenAI Agents SDK supports tools, handoffs, streaming, guardrails, hosted MCP, and traces: [Agents SDK](https://platform.openai.com/docs/guides/agents-sdk/).
- Structured outputs should constrain model responses to typed schemas: [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs).
- MCP architecture defines hosts, clients, servers, tools, resources, prompts, notifications, sampling, elicitation, and transports: [MCP architecture](https://modelcontextprotocol.io/docs/learn/architecture).
- MCP 2025-11-25 is the current protocol version at the time of this ADR update: [MCP specification](https://modelcontextprotocol.io/specification/2025-11-25).
- MCP tools expose names, descriptions, input schemas, optional output schemas, and structured content: [MCP tools](https://modelcontextprotocol.io/specification/2025-11-25/server/tools).
- MCP authorization for HTTP transports uses OAuth-based flows, Protected Resource Metadata, and Resource Indicators: [MCP authorization](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization).
- OAuth 2.0 security best current practice is RFC 9700, while OAuth 2.1 remains a draft: [RFC 9700](https://www.ietf.org/rfc/rfc9700.html), [OAuth 2.1 draft](https://datatracker.ietf.org/doc/draft-ietf-oauth-v2-1/).
- MCP security guidance calls out SSRF, scope minimization, sandboxing, and least-privilege controls: [MCP security best practices](https://modelcontextprotocol.io/docs/tutorials/security/security_best_practices).
