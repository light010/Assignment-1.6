# ADR 006: Frontend, API, And User Workflows

Status: Active
Last verified: 2026-05-10

## Context

DITAgen needs a modern frontend where users upload documents, monitor processing, review source evidence, edit generated DITA, resolve validation issues, use bounded agent assistance, and export approved content.

## Decision

Build the frontend as a product workspace, not a marketing site or generic chatbot. APIs expose project, document, topic, review, agent, skill, MCP, and export workflows through typed endpoints.

## Frontend Stack

Recommended stack:

- TypeScript.
- React with Next.js, Remix, or Vite-based React.
- Accessible component primitives such as Radix UI, Ariakit, or equivalent.
- Rich editor based on ProseMirror, TipTap, Lexical, or Monaco depending on editing mode.
- TanStack Query or equivalent for API caching.
- State machine or workflow state model for conversion and review flows.

## Frontend Application Areas

- Project dashboard.
- Document upload and ingestion queue.
- Processing timeline with per-stage status.
- Source quality triage.
- Source preview panel.
- Extracted Markdown panel.
- Topic plan review.
- DITA editor.
- Validation issue panel.
- Multilingual and terminology panel.
- Template and conversion profile settings.
- DITA constraint profile settings and element catalog.
- Agent Activity panel.
- Bounded Ask Assistant actions inside review, validation, topic planning, and asset workflows.
- MCP connection settings and capability approval for admins.
- Reviewer assignment and comments.
- Activity and audit history.
- Export center.

## Business Unit Layer

A Business Unit (BU) is the organization-level container above projects.
It maps onto the tenant + organization model in ADR-010. The frontend
exposes BUs through a dedicated dashboard that is the first authenticated
screen for users with access to more than one BU; users with access to a
single BU are routed directly to its Project Hub.

Frontend surface decisions (alpha):

- The BU dashboard ships as an equal-sized card grid
  (`repeat(auto-fill, minmax(300px, 1fr))`), not the previously prescribed
  Bento priority-tile layout. Severity is communicated through sort
  order, a 4-px tone-colored status edge on each card, and per-card meta
  text. The full direction is recorded in
  [`docs/design/screen-bu-dashboard.md`](../docs/design/screen-bu-dashboard.md);
  the high-level rationale is in `DESIGN.md` ("UX Patterns Learned").
- BU deletion is a destructive admin-only operation. The frontend renders
  a hover-revealed trash button on each card (palette-tinted danger by
  default, solid danger on hover, with a `confirm()` dialog before the
  call). The corresponding endpoint is `DELETE
  /v1/business-units/{business_unit_id}`.
- Other BU operations (membership management, policy editing, retention
  configuration) are out of scope for the alpha card and live in the
  longer-term Settings drawer described in `screen-audit-admin-settings.md`.

## Review Workspace Layout

```text
+--------------------------------------------------------------------+
| Project / Document / Topic selector                                |
+----------------------+-----------------------+---------------------+
| Source preview       | Editable DITA topic   | Validation issues   |
| PDF/DOC/PPT view     | XML or structured UI  | Traceability        |
| Extracted Markdown   | Topic metadata        | Comments            |
+----------------------+-----------------------+---------------------+
| Job timeline, approval status, agent activity, export actions       |
+--------------------------------------------------------------------+
```

## Frontend Behavior Rules

- Users can see source evidence for every generated section.
- Low-confidence content is easy to find from the project dashboard.
- Regeneration is scoped and intentional.
- Validation issues link to the affected DITA element.
- Topic plan changes are possible before expensive LLM generation.
- Editors support structured editing and XML inspection for advanced users.
- Editors hide or disable blocked DITA elements, warn on pasted XML violations, and show approved substitutions from the active constraint profile.
- Export readiness is clear at project, document, map, and topic level.
- Agent suggestions show source artifacts, tool calls, confidence, cost estimate, required approvals, and reversible diff.
- Assistant entry points are contextual actions, not a general unrestricted chatbot.

## Public API Groups

Initial user-facing endpoints:

- `POST /auth/login`
- `POST /auth/logout`
- `POST /auth/refresh`
- `GET /auth/sessions`
- `DELETE /auth/sessions/{session_id}`
- `POST /auth/tokens`
- `GET /auth/tokens`
- `DELETE /auth/tokens/{token_id}`
- `GET /business-units`
- `POST /business-units`
- `GET /business-units/{business_unit_id}`
- `DELETE /business-units/{business_unit_id}`
- `GET /business-units/{business_unit_id}/projects`
- `POST /projects`
- `GET /projects`
- `GET /projects/{project_id}`
- `POST /projects/{project_id}/documents/uploads`
- `POST /uploads/{upload_id}/parts`
- `POST /uploads/{upload_id}/complete`
- `GET /documents/{document_id}`
- `DELETE /documents/{document_id}`
- `GET /documents/{document_id}/manifest`
- `GET /documents/{document_id}/artifacts`
- `GET /documents/{document_id}/blocks?cursor=...`
- `GET /documents/{document_id}/assets`
- `GET /documents/{document_id}/jobs`
- `GET /documents/{document_id}/source-quality`
- `GET /projects/{project_id}/topic-plan`
- `PATCH /projects/{project_id}/topic-plan`
- `POST /projects/{project_id}/topic-plan/approve`
- `POST /documents/{document_id}/topic-plan/recompute`
- `GET /topics/{topic_id}`
- `PATCH /topics/{topic_id}` — body `{xml: str}` preserved per ADR-006 contract; routed through review-service as a `RawXmlOverrideOp` (Phase 6.D). See ADR-014.
- `POST /topics/{topic_id}/ops` — body: an `EditOperation` (Merge / Split / Move / Retype / Rename / RawXmlOverride). Workbench's structural edit surface (Phase 6.B). See ADR-014.
- `GET /documents/{document_id}/ops` — ordered op log filtered to `edit.*` audit events (Phase 6.C).
- `POST /documents/{document_id}/ops/undo` — append inverse of chain head (Phase 6.C).
- `GET /documents/{document_id}/triage-queue` — blocks ordered ascending by min(confidence) with structured `review_flags` (Phase 5).
- `POST /topics/{topic_id}/assign-reviewer`
- `POST /topics/{topic_id}/approve`
- `POST /topics/{topic_id}/reject`
- `GET /topics/{topic_id}/validation-issues`
- `GET /topics/{topic_id}/traceability`

`POST /topics/{topic_id}/regenerate` and `regenerate-section` were retired in Phase 6.E as dead surface (the old implementations returned the unchanged topic). They will be reintroduced if and when review-service gains a real per-topic regeneration route backed by the LLM gateway.
- `GET /projects/{project_id}/terminology`
- `POST /projects/{project_id}/terminology/import`
- `GET /projects/{project_id}/templates`
- `POST /projects/{project_id}/conversion-profiles`
- `GET /projects/{project_id}/dita-constraint-profile`
- `GET /organizations/{organization_id}/dita-constraint-profiles`
- `POST /organizations/{organization_id}/dita-constraint-profiles`
- `GET /dita-constraint-profiles/{profile_id}/versions/{version}`
- `POST /dita-constraint-profiles/{profile_id}/versions/{version}/dry-run`
- `POST /dita-constraint-profiles/{profile_id}/versions/{version}/publish`
- `POST /dita/element-policy/resolve`
- `POST /dita/element-policy/validate-candidate`
- `GET /projects/{project_id}/activity`
- `GET /projects/{project_id}/quality-report`
- `GET /projects/{project_id}/evaluation-runs`
- `POST /projects/{project_id}/evaluation-runs`
- `GET /evaluation-runs/{evaluation_run_id}`
- `GET /projects/{project_id}/agents`
- `POST /agent-runs`
- `GET /agent-runs/{agent_run_id}`
- `GET /agent-runs/{agent_run_id}/trace`
- `POST /agent-runs/{agent_run_id}/approve-action`
- `POST /agent-runs/{agent_run_id}/cancel`
- `GET /projects/{project_id}/skills`
- `POST /projects/{project_id}/skills/{skill_id}/enable`
- `GET /projects/{project_id}/mcp-servers`
- `POST /projects/{project_id}/mcp-servers`
- `GET /mcp-servers/{server_id}/capabilities`
- `POST /mcp-servers/{server_id}/test-connection`
- `POST /mcp-servers/{server_id}/enable-capability`
- `POST /projects/{project_id}/exports`
- `GET /exports/{export_id}`
- `GET /exports/{export_id}/logs`
- `GET /notifications`
- `POST /notifications/{notification_id}/read`
- `GET /notification-preferences`
- `PATCH /notification-preferences`

## API Design Rules

- User-facing APIs return project-specific permissions when the frontend needs to decide enabled actions.
- Long-running actions return job IDs and publish status over WebSocket or Server-Sent Events.
- Public APIs are versioned under `/v1` for MVP; breaking changes require a new version and a published deprecation window.
- All long-running or mutating write APIs accept idempotency keys, not only LLM and agent endpoints.
- Generated content APIs include artifact version IDs to prevent stale edits.
- Document block APIs are cursor-paginated and may filter by page, slide, topic candidate, block type, or issue state.
- Agent run APIs also accept max budget, allowed tool scope, and input artifact version.
- Validation override APIs require a reason.
- DITA constraint profile APIs require profile version, rule IDs, severity, rationale, and dry-run results before publication.
- Agent action approval APIs require proposed diff, approval target, approver ID, and artifact version.
- MCP server registration APIs require admin permissions, transport type, trust level, allowed capabilities, allowed tools, and credential reference.

## Notification Behavior

- Users can choose channel, granularity, and digest preferences.
- Bulk operations suppress duplicate notifications and summarize repeated stage updates.
- Notification history is queryable and replayable from persisted notification records.
- MVP supports in-app notifications and WebSocket or SSE updates; email, Slack, and Teams are Phase 2+ unless required by a launch customer.

## Frontend Scale Strategy

- Virtualize long topic lists, source blocks, validation issues, activity logs, comments, and agent traces.
- Lazy-load source previews by page, slide, or topic.
- Do not load entire generated DITA packages into the browser.
- Edit one topic or bounded topic set at a time.
- Use streamed job progress.
- Use artifact version IDs to prevent stale edits.
