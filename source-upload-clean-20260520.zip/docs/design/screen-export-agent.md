# Export And Agent Activity Screen Spec

## Export Center

The Export Center is available only after project artifacts reach `Approved` or `Export Ready`, unless project policy allows warning overrides. It shows export package type, topic count, included artifact versions, validation summary, approval coverage, and most recent build state. The primary action is `Build DITA ZIP`; any future Git, CCMS, CMS, or localization handoff actions remain secondary until configured by an admin.

Export rows use `data-row` density and must include status, build time, actor, package size, and download or retry action. Failed exports use `status-danger` and include the failed stage or validator message. Successful exports use `status-success` and should preserve audit context without forcing the user into logs.

Recommended export layout:

```text
+--------------------------------------------------------------------------------+
| Export Header: Project | readiness | policy | Build DITA ZIP | integrations    |
+--------------------------------------+-----------------------------------------+
| Readiness Grid                       | Export Inspector                         |
| Approval coverage                    | selected export details                  |
| Validation blockers/warnings         | manifest / logs / download               |
| Topic/map/package counts             | included artifact versions               |
| Localization readiness               | audit and retention metadata             |
+--------------------------------------+-----------------------------------------+
| Export History: status | package | actor | build time | size | actions         |
+--------------------------------------------------------------------------------+
```

Locked export layout:

- **Project Context Bar:** 48px tall and shared with project-level screens.
- **Export Header:** 88px tall. It shows `Export Center`, readiness summary chips, integration state, and `Build DITA ZIP` as `button-primary` only when eligibility gates pass.
- **Main Content:** Two-column grid with 16px gap. Readiness grid owns 66.6% width. Export inspector uses `export-inspector`, 33.3% width, and stays sticky inside the content area.
- **Export History:** Full width below main content. Table headers are sticky when the history scrolls.

Readiness grid layout:

- Use a 4-column internal grid.
- Approval coverage card spans 2 columns.
- Validation summary card spans 2 columns.
- Conversion profile card spans 2 columns.
- Localization readiness card spans 2 columns.
- Each card uses `export-readiness-card`: `surface`, 24px padding, `rounded.lg`, and `shadows.card`.
- Card content uses title in `title-md`, primary metric in `heading-lg`, and a supporting list.

Export readiness uses `export-readiness-card` and must show:

- Approved topics, unapproved topics, warning overrides, and blocking validation issues.
- Included maps, topics, assets, images, conrefs/keyrefs when available, and locale/language coverage.
- Active conversion profile, DITA version, constraint profile, and export policy.
- Package manifest, artifact versions, content hashes, and build timestamp.

Export inspector:

- Appears when an export row is selected.
- Header shows status chip, package name, build timestamp, and actor.
- Manifest section lists artifact versions with hash prefixes and expandable details.
- Validation summary shows pass, warning, and failure counts at build time, with links to the full-screen triage view.
- Logs are behind a toggle, use `code-editor`, and scroll inside the inspector.
- Actions are download, retry, rebuild, and view full audit.

Export history table:

- Sticky headers.
- Columns are status, package name, actor, build time, size, and actions.
- Rows use `export-history-row`.
- Failed rows use a `status-danger` left edge; successful rows use `status-success`.
- Selecting a row populates the export inspector without navigating away.

Build actions:

- Build DITA ZIP is primary only when policy allows export.
- Retry failed export is primary inside a failed export detail state.
- Download is prominent only after a successful build.
- External publishing actions are hidden until the integration is configured and authorized.

## Agent And MCP Activity

Agent suggestions are contextual controls, not a general chatbot surface. Show source artifacts used, tool calls, confidence, estimated cost, required approval, and a reversible diff before applying any suggestion. MCP and skill controls are admin-facing and should use the same dense enterprise form patterns as project settings.

When an interaction panel is used, it is task-bound: Review Assistant, Validation Assistant, Topic Plan Assistant, Export Assistant, or Admin Setup Assistant. Responses may stream token-by-token, but the UI must buffer Markdown until block-level syntax is stable, especially code fences, lists, and DITA/XML snippets. During generation, show a visible stop button, a running-state label, and `aria-live="polite"` announcements for meaningful completion events rather than every token.

Agent citations are mandatory for claims about uploaded documents. Render numbered inline references that expand to source cards showing document name, source block ID, page or slide, freshness/version, confidence, and the exact excerpt used. Do not hide citations, uncertainty, or tool traces behind tooltips. Feedback controls attach to every agent proposal and include thumbs up/down, reason chips, and optional text only after the quick decision.

Agent proposal cards use `agent-proposal-card` and must include:

- Task type: review assist, validation fix, topic plan suggestion, terminology suggestion, export diagnosis, or admin setup.
- Inputs: document, topic, artifact version, allowed tool scope, and budget.
- Evidence: citations, source blocks, validation issues, tool calls, and confidence.
- Proposed change: readable summary plus reversible diff before apply.
- Approval: required approver, policy reason, accept/reject/cancel actions, and audit impact.
- Cost and latency: estimate before run where available and actual after completion.
- Tool budget at proposal time: tools and skills intended for use, maximum call count, and maximum estimated cost. The user authorizes the budget before the run. An actual cost or call count that exceeds the estimate by more than 25% generates an audit event and a banner inside the agent activity panel.
- Reversal window: applied agent proposals are reversible for 7 days within the artifact-version timeline. After 7 days, the version is still restorable manually, but the inline "undo this proposal" affordance is removed to prevent ambient back-out of decisions with downstream export implications.

MCP and skill controls:

- Admin-only setup uses settings forms, test connection actions, capability allowlists, and audit warnings.
- Runtime tool use appears in agent traces, not as ambient hidden automation.
- Agent runs inherit the user's narrowed project permissions and never broaden access.
- Cancel and stop controls remain visible during long-running agent work.
