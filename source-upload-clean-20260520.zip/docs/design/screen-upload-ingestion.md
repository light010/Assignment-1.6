# Document Upload And Ingestion Screen Spec

## As Implemented (Alpha) — Upload Hub

The upload surface is now the **primary** post-BU screen. Clicking a BU
card opens the Upload Hub directly; the previous Project Hub layer is
[retired](screen-project-hub.md). The Upload Hub combines the BU
context, a multi-file dropzone, the active upload queue, the document
list with stage steppers, and the document detail in a single scrollable
surface.

Source: `apps/web/src/App.tsx` (`UploadHub`, `MultiFileDropzone`,
`StageStepper`, `LocalUploadRow`, `DocumentStageRow`, `mapStatusToStage`)
and `apps/web/src/styles.css` (`.upload-hub`, `.dropzone-large`,
`.upload-list`, `.upload-row`, `.stage-stepper`, `.document-detail`).

The longer-form directional spec below remains for reference, but is no
longer authoritative for the shipped UI.

### Layout

```text
┌──────────────────────────────────────────────────────────────────────────┐
│ Top App Bar (full width, dark navy)                                      │
├────┬─────────────────────────────────────────────────────────────────────┤
│ ◇  │ ⌂ Business Units / Documentation Operations                         │
│ ▤  │                                                                     │
│ ⌇  │ Documentation Operations                                            │
│    │ Drop your source documents here. We will convert them into          │
│    │ reviewable DITA topics.                                             │
│    │ [role] [DITA 1.3] [storage] [N documents]                          │
│    │                                                                     │
│    │ ┌─────────────────────────────────────────────────────────────────┐ │
│    │ │  ⤴   Drag and drop documents                                    │ │
│    │ │      or click to browse · DOCX · PDF · TXT · MD · HTML · 250 MB │ │
│    │ └─────────────────────────────────────────────────────────────────┘ │
│    │                                                                     │
│ ⚙  │ In progress  [3]                                                    │
│ ?  │  ┌──────────────────────────────────────────────────────────────┐   │
│    │  │ 📄 user-guide.docx              2.3 MB              [Retry][✕]│   │
│    │  │ ●━━━━●━━━━○┄┄┄┄○┄┄┄┄○┄┄┄┄○                                    │   │
│    │  │ Upload  Extract Plan   Convert Review Export                  │   │
│    │  └──────────────────────────────────────────────────────────────┘   │
│    │                                                                     │
│    │ Documents  [12]                                                     │
│    │  ┌──────────────────────────────────────────────────────────────┐   │
│    │  │ 📄 ux-review.txt   Ready For Review · 1 topic       Open →   │   │
│    │  │ ●━━━━●━━━━●━━━━●━━━━●━━━━○                                    │   │
│    │  │ Upload  Extract Plan   Convert Review Export                  │   │
│    │  └──────────────────────────────────────────────────────────────┘   │
│    │                                                                     │
│    │ (after click) Document detail with tabs                             │
└────┴─────────────────────────────────────────────────────────────────────┘
```

The left column is the [icon-only App Nav](components-common.md#app-nav-icon-only-side-rail);
the **Documents** icon (FileText) is the active item when in a BU.

### Header

Source: `<header className="upload-hub-header">`.

- **Breadcrumb** (`<nav className="breadcrumb">`): same pattern as the
  retired Project Hub — `Home` icon button "Business Units" → separator
  → BU name. The back button calls
  `onBackToBusinessUnits` (`returnToBusinessUnits` in the App shell).
- **H1 row** (`.upload-hub-title-row`): BU name (e.g. "Documentation
  Operations") at 26px / 600, `letter-spacing: -0.02em`, followed by a
  small `(i)` button rendered by `<BUInfoPopover>`. The popover holds
  static workspace metadata (role, conversion target, storage used)
  per the
  [Header chips encode state, not config](../../DESIGN.md#1-chips-next-to-the-h1-encode-state-not-config)
  rule. See
  [Header Context Chips and (i) Popover](components-common.md#header-context-chips-and-i-popover)
  for the demotion table that retired the previous four pills.
- **Description**: literal copy "Convert source documents into
  reviewable DITA topics." at 13.5px / `var(--text-muted)`. Single
  line, ≤ 640 px wide.
- **One context pill** (`.context-meta` with a single
  `.context-pill`): just the document count
  (`{N} document(s)`). This is the only value here that satisfies the
  state / glanceable / non-duplicated test.

### Dropzone — multi-file with drag and drop

Source: `<MultiFileDropzone>` (component) and `.dropzone-large`
(selector). Implements the canonical
[Hero Dropzone pattern](components-common.md#hero-dropzone) in
`components-common.md`. The pattern is the visual hero of this screen
because uploading is the page's primary action — see
[Primary action is the visual hero](../../DESIGN.md#4-the-primary-action-is-the-visual-hero).

```text
┌──────────────────────────────────────────────────────────────────────┐
│  ⤴   Drag and drop documents                                         │
│      or click to browse · DOCX · PDF · TXT · MD · HTML · 250 MB · multi-file │
└──────────────────────────────────────────────────────────────────────┘
```

Geometry:

- Container: 1.5-px **dashed** `var(--border-strong)` border,
  `var(--r-lg)` radius, vertical gradient
  `linear-gradient(180deg, var(--surface-tint), var(--surface))`, padding
  `28px 28px 28px 24px`, cursor pointer.
- Two-column layout: leading 56-px circular icon zone (lucide `Upload`,
  24-px in an `accent-soft` circle), then a two-line text block.
- Hidden `<input type="file" multiple accept=".docx,.pdf,.txt,.md,.html,
  .htm">`.

States (verified in browser):

| State | Border | Background | Icon container | Text |
| --- | --- | --- | --- | --- |
| Default | dashed `var(--border-strong)` | gradient surface → tint | `accent-soft` w/ `accent` icon | "Drag and drop documents" |
| Hover | dashed `var(--accent)` | gradient `accent-soft` → surface | unchanged | unchanged |
| Drag-over (`.is-dragging`) | **solid** `var(--accent)` | flat `var(--accent-soft)` | `var(--accent)` w/ white icon, scale 1.05 | "Release to add to queue" |
| Disabled (`.is-disabled`) | unchanged | unchanged | unchanged | unchanged, `opacity: 0.6` |

Drag tracking uses a counter (`dragCounter`) so child elements firing
their own `dragenter`/`dragleave` do not flicker the dragging state. The
counter is reset to 0 on `drop`.

The dropzone accepts multiple files in a single drop. Each file is
either:

- Pushed to the local upload queue with state `"queued"` if it passes
  `validateUpload(file)` (extension allowed and ≤ 250 MB), **or**
- Pushed with state `"failed"` and the validation message captured as
  `error`. Failed items appear in the queue immediately so users see
  why a file did not start uploading.

### Local upload queue

Source: `useState<LocalUpload[]>([])` inside `UploadHub` and the queue
worker effect.

Each `LocalUpload`:

```ts
{
  localId: string;            // "up_{Date.now()}_{random}"
  file: File;
  state: "queued" | "uploading" | "done" | "failed";
  error?: string;
  documentId?: string;        // populated when state === "done"
}
```

Worker behavior:

- One upload runs at a time. The effect picks the next `"queued"` item
  and transitions it to `"uploading"` before calling
  `uploadDocument(project.project_id, file)`.
- On success: state becomes `"done"`, the returned `document_id` is
  stored, and `refreshProjects()` re-fetches so the document appears in
  the documents list.
- On failure: state becomes `"failed"`, the error message is captured
  for display, and the queue worker moves on to the next `"queued"`
  item.
- `"done"` items are filtered out of the rendered list (the document
  itself appears in the In-progress / Documents sections instead),
  while `"queued"`, `"uploading"`, and `"failed"` items stay visible.

Per-row controls:

- **Retry**: shown only when `state === "failed"`. Resets the row to
  `"queued"` and clears the error; the worker picks it up on the next
  tick.
- **Dismiss** (`<X>`): removes the row from the queue entirely. Allowed
  in any state.

### Doing vs Managing — section structure

Per the
[Doing vs Managing](../../DESIGN.md#2-doing-vs-managing--split-the-surface)
principle, the Upload Hub is a *doing* surface: time-ordered, focused
on the user's current task. It does **not** carry the full library
(that lives in the planned Documents page). On entry, the Hub
groups documents into two sections:

| Section | Selector | What goes in | Render mode |
| --- | --- | --- | --- |
| This session | `<section aria-label="This session">` | local in-flight uploads + any document touched in this browser session + any document still in a non-terminal pipeline state | full `<StageStepper>` per row |
| Earlier | `<section aria-label="Earlier documents">` | terminal-state documents that were not touched this session | compact rows with `.status-chip`, no stepper |

"This session" tracking is implemented by a `Set<string>` of document
IDs (`sessionDocIds`) stored in `UploadHub` state. IDs are added when:

- A local upload finishes and the server returns a document ID.
- The user clicks a row to open its detail (so the document is now
  on the user's working set even if it was Earlier before).

The Set is intentionally session-scoped — a hard reload empties it.
Persistent "recent activity" lives in the future Activity surface.

`isTerminalStatus(status)` returns true for `ready_for_review`,
`review_ready`, `approved`, `export_ready`, `rejected`, and any string
containing `"fail"`. Anything else is non-terminal and stays in
"This session" regardless of `sessionDocIds` membership.

### Local upload queue rendering

Inside the "This session" section, two subsequent row groups render in
order:

1. **Local uploads** (`<LocalUploadRow>`) — `queued` / `uploading` /
   `failed` local items in insertion order. Once a local upload
   completes and the server returns a document, the local row is
   removed and the corresponding document row appears below.
2. **Session documents** (`<DocumentStageRow variant="full">`) —
   server documents tagged for this session. The full stepper is
   forced regardless of terminal state because the user is actively
   working with them.

### Earlier toolbar — Search / Sort / Filter

Above the Earlier list, the screen renders the standard
[Index List + Search / Sort / Filter Toolbar](components-common.md#index-list--search--sort--filter-toolbar)
implemented as `.hub-toolbar`. Choices applied here:

- **Search input**: filters Earlier rows by `filename`
  (case-insensitive substring match).
- **Filter pills** (`.saved-filters`): `All`, `Review ready`,
  `Warnings`, `Failed`, `Approved`. Single-select.
- **Sort dropdown** (`.hub-sort select`): `Most recent` (default,
  newest `created_at` first), `Filename`, `Status`, `Quality`.

Earlier is capped at 8 rows in the preview. When `filteredEarlier`
exceeds 8, the section ends with a `.hub-view-all` button that
routes to the future Documents page (Phase 2). For the alpha that
button surfaces a placeholder message.

### Compact rows for Earlier

Earlier rows use `<DocumentStageRow variant="compact">`. Per the
[Show progress when informative](../../DESIGN.md#3-show-progress-affordances-when-theyre-informative-collapse-when-theyre-not)
rule, the stepper is hidden — its information is constant for a
terminal document. The row's meta line carries the equivalent
signal: a `.status-chip` ("Ready For Review", "Approved", etc.)
plus topic count, quality %, and a relative timestamp.

Hovering the row still reveals the destructive
[hover-revealed delete](components-common.md#hover-revealed-delete-button)
button, and clicking opens the Document Detail block below the list
(adding the document to `sessionDocIds`, so it moves into "This
session" if the user navigates back).

### Pipeline polling

Source: a `useEffect` inside `UploadHub` that runs while at least one
document has a non-terminal status.

- Sets a 3-second interval that calls `refreshProjects()` to re-fetch
  the project (and its documents) so the stage stepper advances as the
  backend pipeline progresses.
- Clears the interval as soon as all documents are in terminal states.

This is a polling implementation chosen for the alpha. When the API
gains streamed events / SSE for status changes, replace the interval
with a subscription; the consumer (`UploadHub`) is otherwise
status-agnostic.

### Stage stepper

Source: `<StageStepper status={…}>` and `.stage-stepper` selector.

A six-pill horizontal stepper rendered below the row's filename header:

```text
●━━━━●━━━━●━━━━●━━━━●━━━━○
Upload  Extract  Plan  Convert  Review  Export
```

Pill states:

| State | Dot fill | Connector | Label |
| --- | --- | --- | --- |
| `complete` | `var(--success)` | `var(--success)` | `var(--text)`, 500 |
| `active` | `var(--accent)`, 4-px halo `accent-soft`, pulse animation | (uses default `var(--border)` until next stage completes) | `var(--text)`, 600 |
| `warning` | `var(--warn-strong)` | `var(--warn-strong)` | `var(--warn-text)`, 600 |
| `failed` | `var(--danger)` | (default) | `var(--danger-text)`, 600 |
| `pending` | `var(--surface)` w/ `var(--border-strong)` ring | `var(--border)` | `var(--text-muted)`, 500 |

Pulse animation: `@keyframes stage-pulse` expands the
`var(--accent-soft)` halo from 4-px to 7-px and back over 1.6 s. Honors
the global `prefers-reduced-motion: reduce` override.

Below 720px the labels are hidden via `@media (max-width: 720px)`. A
`.stage-stepper.compact` modifier additionally hides labels on demand
for very dense lists.

### Status → stage mapping

Source: `mapStatusToStage(status)` in `App.tsx`.

The pipeline statuses defined in the root `DESIGN.md` map onto the six
stage indices as follows:

| API status | Stage index | State |
| --- | --- | --- |
| `queued`, `uploading` | 0 (Upload) | active |
| `upload_complete` | 1 (Extract) | active (label: "Starting extraction") |
| `extracting`, `extraction_in_progress` | 1 (Extract) | active |
| `extraction_complete`, `markdown_normalized` | 2 (Plan) | active (label: "Planning topics") |
| `topic_plan_ready` | 3 (Convert) | active (label: "Generating DITA") |
| `dita_generated` | 3 (Convert) | active (label: "Validating") |
| `validation_passed` | 4 (Review) | active (label: "Awaiting review") |
| `validation_warnings` | 4 (Review) | warning |
| `ready_for_review`, `review_ready` | 4 (Review) | active |
| `approved` | 5 (Export) | active (label: "Awaiting export") |
| `export_ready` | 5 (Export) | complete |
| anything containing `fail` | (last passed stage) | failed |
| anything else | 0 | active (label: humanized status) |

The function returns `{ index, state, label }`. The label is what
appears in the row's secondary text and as the stepper's `aria-label`.

### Local upload row vs. document stage row

Both rows share the same outer geometry (`.upload-row` — 1-px border,
`var(--r-lg)` radius, `var(--shadow-xs)`, status edge `::before`) but
diverge in content and behavior:

| | Local upload row | Document stage row |
| --- | --- | --- |
| Component | `<LocalUploadRow>` | `<DocumentStageRow>` |
| Source data | `LocalUpload` (in-browser state) | `DocumentRecord` (server) |
| Status | `queued` / `uploading` / `failed` mapped to a synthetic API status (`upload_failed` etc.) | actual `doc.status` |
| Cursor | default (not clickable) | `pointer` (opens detail) |
| Right-side affordance | Retry (failed only) + Dismiss | Hover-revealed delete + spinner (in-progress) |
| Edge color (default) | gray; **uploading** edge pulses accent gradient; **failed** danger | tone-driven by stage state |

Both rows render the same `<StageStepper>` so a file moves from the
"local upload" UI into the "server document" UI without the user seeing
a layout jump.

The **document stage row does not render a "Open →" CTA pill**. The
entire row is the affordance — `cursor: pointer`, hover lift, and a
keyboard-focusable container are sufficient. This matches the
[BU card rule](screen-bu-dashboard.md#removed-and-why) that an explicit
"Open" pill is redundant when clicking the card itself opens the
record. While a document is still processing (non-terminal status), a
small spinning `RefreshCw` indicator replaces the delete affordance to
communicate that work is in flight.

#### Document delete (hover-revealed)

Class `.upload-row-delete` — same pattern and palette as
[`.bu-card-delete`](components-common.md#hover-revealed-delete-button):

- Position: `top: 10px; right: 10px`, 26×26 button, `var(--r-sm)`
  radius.
- Default: `var(--danger)` icon on `var(--danger-bg)` with
  `var(--danger-border)`. Opacity 0, `translateY(-2px)`, pointer
  events disabled.
- Reveal: on `.upload-row:hover` or `:focus-within`, fades to opacity
  1 with `translateY(0)` and pointer events re-enabled.
- Hover: solid `var(--danger)` fill, white icon, controlled red
  shadow.
- Behavior: `event.stopPropagation()` (so the card's row-click does
  not fire) → `window.confirm` quoting the filename and explaining
  the consequence ("This will remove the document, its source blocks,
  generated topics, and artifacts. This cannot be undone.") → calls
  `deleteDocument(document_id)` from `api.ts`
  (`DELETE /v1/documents/{id}`). On success, the parent project is
  re-fetched. If the deleted document is currently selected, the
  detail view is closed.

The delete is rendered only when an `onDelete` prop is passed in by
the parent — the alpha unconditionally provides one, but the gating
prop preserves the option to hide the affordance for non-admin users
later without restyling.

### Document detail (after clicking a row)

Source: `<section className="document-detail">` rendered when
`activeDocument && project`.

- Header: filename (H2) + secondary line with status, topic count, and
  quality percentage. A small `<X>` close button on the right calls
  `setActiveDocumentId("")` to collapse the detail.
- Observability chips: Jobs and Artifacts sit above the lifecycle tabs
  because they are debug/support surfaces, not primary review stages.
- Tab strip: `<div className="tabs">` with the standard lifecycle tabs
  (Source / Workbench / Plan / Review / Export). Tab style
  is the underline pattern documented in
  [Tabs (underline)](components-common.md#tabs-underline).
- Body: `<PanelView>` switches between lifecycle panel components
  (`SourcePanel`, `WorkbenchPanel`, `TopicPlanPanel`, `ReviewPanel`,
  `ExportPanel`) while Jobs and Artifacts open from their chips.

The detail does **not** auto-open on entry. The page lands with the
dropzone visually dominant; the user must explicitly click a row to open
its detail. This is a deliberate change from the old Project Detail,
which auto-selected the first document.

### Empty / loading states

| State | Treatment |
| --- | --- |
| BU has no project yet | The dashboard's `refreshProjects` auto-creates a default `Documents` project before the Upload Hub renders. While that call is in flight, an `.empty-card` shows "Setting up your workspace…" |
| Project exists but no documents and no in-flight uploads | An `.empty-card` shows a `FileText` icon and copy "No documents yet. Drag files into the box above to get started." |
| Document list rendering with terminal-state items only | The "In progress" section is omitted; only the "Documents" section renders. |
| All documents in terminal state, no in-flight uploads | Same as above. The document detail collapses if its document is removed from the list. |

### Five-second scan test

A user landing on this screen should be able to answer, in five seconds:

1. Which BU am I working in? (breadcrumb + H1)
2. How do I add documents? (the dropzone is the largest interactive
   element on the page)
3. What's currently being processed? ("In progress" section with stage
   steppers)
4. Where is each document in the pipeline? (per-row stepper)
5. Which documents are ready for me to act on? ("Documents" section
   with terminal-state rows; "Open →" CTA on the right)

### Removed and why (relative to earlier directions)

- **Project Context Bar (separate row above the upload header).** The
  Upload Hub is the project; there is no project switcher because each
  BU has one default project and the user never sees a list.
- **Source tabs (Files / Folder / Remote URL / Connector / Recent /
  Failed).** Alpha supports a single file-picker / drag-drop source.
  The tabs return when remote and connector sources land.
- **Preflight panel as a separate surface.** Preflight is collapsed
  into the dropzone state machine and the per-file row error message.
  A real, multi-check preflight panel returns when we add duplicate
  detection, sensitivity classification, and language hinting.
- **Ingestion health rail (right side).** The current implementation
  pushes quota / cost / scan policy / OCR status into the future Settings
  surface. The Upload Hub focuses on the document pipeline itself.
- **Bulk action bar.** Multi-file upload is supported in alpha but
  bulk selection / actions on the resulting documents are not. The
  pattern returns when multi-select arrives.
- **Document Detail Drawer.** Detail expands inline below the list
  rather than as a side drawer. The inline expansion preserves scroll
  context and avoids a competing chrome layer.

### Auto-create idempotency

The `refreshProjects` function uses an in-component `useRef<Set<string>>`
(`autoCreatedFor`) to track which BUs it has already attempted to seed
with a default `Documents` project. This guards against three race
modes:

1. The BU-selection effect firing twice during a hot-reload cycle.
2. The user re-entering the same BU repeatedly within a session.
3. Two concurrent `refreshProjects` calls observing an empty list and
   both kicking off `createProject`.

The `Set.add()` happens before `await createProjectRequest(...)` so the
guard is in effect during the network round-trip, not just after it.
On failure the BU is removed from the set so a retry is possible.

After a successful auto-create, `refreshProjects` also calls
`refreshBusinessUnits(businessUnitId)` (best-effort) so the BU
dashboard's `project_count` is up to date the next time the user
returns, without requiring a manual refresh.

### Implementation references

| Concern | File | Symbol |
| --- | --- | --- |
| Component tree | `apps/web/src/App.tsx` | `UploadHub`, `MultiFileDropzone`, `StageStepper`, `LocalUploadRow`, `DocumentStageRow` |
| Status → stage logic | `apps/web/src/App.tsx` | `mapStatusToStage`, `stageIndexBeforeFailure`, `isTerminalStatus`, `STAGE_LABELS` |
| Auto-create default project | `apps/web/src/App.tsx#refreshProjects` | calls `createProjectRequest` when the BU has no projects, guarded by `autoCreatedFor` ref |
| Document delete | `apps/web/src/App.tsx#handleDeleteDocument` + `api.ts#deleteDocument` | `DELETE /v1/documents/{id}`, with `confirm()` dialog and parent-project refresh |
| Multi-file upload queue | `apps/web/src/App.tsx#UploadHub` (queue worker effect) | uses `uploadDocument(projectId, file)` from `api.ts` |
| Polling | `apps/web/src/App.tsx#UploadHub` (polling effect) | 3-s interval while any non-terminal document exists |
| Styles | `apps/web/src/styles.css` | `.upload-hub`, `.upload-hub-header`, `.dropzone-large`, `.upload-list`, `.upload-row`, `.upload-row-head`, `.upload-row-meta`, `.upload-row-actions`, `.upload-row-cta`, `.upload-row-pulse`, `.upload-row-retry`, `.upload-row-dismiss`, `.stage-stepper`, `.stage`, `.stage-dot`, `.stage-label`, `.document-detail`, `.document-detail-head`, `.document-detail-close`, `.hub-section`, `.hub-section-head`, `.hub-section-count`, `@keyframes stage-pulse` |

## Document Upload And Ingestion

The document upload screen is the default project screen when no document is active or the next required action is ingestion. It should feel like a modern enterprise ingestion command center: calm, fast, status-rich, and trustworthy. It is inspired by enterprise knowledge-ingestion products that separate source selection, metadata, async ingestion, chunk/extraction review, connector sync, and debugging into clear zones. DITAgen adapts that model to document conversion, where every uploaded file becomes source evidence for Markdown, topic planning, DITA generation, validation, review, and export.

The upload screen must answer four questions quickly: what can I upload, what is happening now, what failed or needs attention, and what is ready for review?

Recommended overall layout:

```text
+--------------------------------------------------------------------------------+
| Project Context Bar: BU / Project | profile | policy | language | permissions  |
+--------------------------------------------------------------------------------+
| Upload Header: Documents | Upload | Import URL | Connector | refresh | view     |
+--------------------------------------------------------------------------------+
| Source Tabs: Files | Folder | Remote URL | Connector | Recent | Failed         |
+--------------------------------------------------------------------------------+
| Upload Command Zone                         | Ingestion Health Rail             |
| +-----------------------------------------+ | Quota / storage / cost / policy    |
| | Drop files here                         | | Supported formats / limits         |
| | Select files | Select folder | URL      | | Security scan / retention note      |
| | DOCX PDF PPTX HTML MD TXT images        | | OCR / language / profile settings   |
| +-----------------------------------------+ +------------------------------------+
| Preflight Panel: duplicates, size, type, sensitivity, language, profile         |
+--------------------------------------------------------------------------------+
| Ingestion Queue                                                               |
| File row | status stepper | confidence | warnings | owner | actions           |
| File row | status stepper | confidence | warnings | owner | actions           |
+--------------------------------------------------------------------------------+
| Document Detail Drawer or Lower Inspector                                     |
| Preview | metadata | pipeline events | source quality | chunks/blocks | raw    |
+--------------------------------------------------------------------------------+
```

Layout zones:

- **Project Context Bar:** Keeps project name, BU, conversion profile, language policy, review policy, and current user permissions visible. Users must know which project will own the uploaded source.
- **Upload Header:** Provides upload/import actions, refresh state, and queue view toggle. `Upload` is primary only when no blocking preflight or quota issue exists.
- **Source Tabs:** Separate upload modes: Files, Folder, Remote URL, Connector, Recent, and Failed. MVP may support fewer modes, but the layout should reserve a clear place for future connectors.
- **Upload Command Zone:** Large `upload-dropzone` for drag-and-drop and file picker. It includes accepted file types, max file size, batch limits, security note, and privacy/retention copy. On drag hover, switch to `upload-dropzone-active`.
- **Ingestion Health Rail:** A compact right rail with upload quota, storage usage, monthly OCR/LLM cost if configured, allowed file types, malware scan policy, OCR availability, and connector sync status.
- **Preflight Panel:** Appears after files are selected and before upload begins. It checks duplicates, unsupported formats, password-protected files, oversize files, sensitivity classification, language hints, and profile compatibility.
- **Ingestion Queue:** The main operational surface after upload begins. Each document row shows filename, type, size, source hash, owner, current pipeline status, confidence, warning count, and next action.
- **Document Detail Inspector:** A right drawer or lower panel for the selected row. It shows preview, metadata, pipeline events, source quality, extracted source blocks/chunks, artifacts, and raw details behind a toggle.

Locked layout dimensions:

- **Project Context Bar:** 48px tall, `project-context-bar`, `primary-container` background, with BU/project breadcrumb, profile, policy, language, and permission summary.
- **Upload Header:** 88px tall. It contains the `Documents` `display/lg` title, view toggle, upload mode tabs, refresh state, and project-scoped upload actions.
- **Pre-upload Content:** Use a two-column flex layout with 16px gap. Upload command zone takes 60% width, `upload-dropzone`, and 320px minimum height. Health rail takes 40% width, `surface`, and 24px padding. Preflight panel is full width and appears only after files are selected, with 16px gap above it.
- **Post-upload Content:** Upload command zone collapses to 25% width and 120px height using `upload-dropzone-collapsed`, with copy changed to `Drop more here`. Health rail takes 25% width. Ingestion queue takes 50% width and becomes the dominant surface.
- **Post-upload Below 1280px:** The collapsed upload zone and health rail remain above; ingestion queue moves to full width below them.
- **Queue Header:** 40px sticky row using `ingestion-queue-header`, `surface-subtle`, and `label-md`.
- **Document Rows:** Use `document-row` with 52px minimum height to allow two-line content. Row gap is 0; use hairline outline dividers for continuous-list scanning.
- **Bulk Actions:** When rows are selected, a sticky `bulk-action-bar` appears at the top of the queue and pushes content down rather than overlaying rows.
- **Queue Empty State:** 240px tall, compact, with `No documents yet` and a short explanation.

Upload command zone internal layout:

- Use 40px padding from `spacing.4xl` with dense vertical spacing.
- Center an `upload-cloud` icon at `icon.size.xl` (32px) in `neutral-700`.
- Title is `Drop files here` in `title-md` with 16px above it.
- Subtitle is `or` in `body-sm` and `neutral-500` with 12px above it.
- Action row sits 16px below the subtitle and contains `Select files` as `button-primary`, plus `Select folder` and `Import URL` as `button-secondary`.
- File type hints sit 24px below actions in `body-sm` and `neutral-700`: `DOCX · PDF · PPTX · HTML · MD · TXT · PNG · JPG`.
- Limits sit 4px below hints in `body-sm` and `neutral-500`: `Up to 200MB per file · 50 files per batch`.

Drag-active behavior:

- Switch the command zone to `upload-dropzone-active`: `primary-container` background and 2px solid `colors.secondary` border.
- Subtitle changes to `Release to upload`.
- The panel scales to `1.01` over `motion.duration.fast` with `motion.easing.standard`. This is a tiny lift, not a bounce, and it reverts on dragleave.
- Drag-and-drop always has equivalent file-picker controls.

Document detail drawer:

- Triggered by clicking or keyboard-activating any document row.
- Uses `document-detail-drawer`, 480px wide, as a right-side drawer.
- Slides over the action rail; the rail remains visible behind a canvas-only scrim.
- Backdrop uses `opacity.drawer-scrim` (`0.32`) over the canvas only, not over the drawer.
- Drawer content scrolls vertically; the drawer header is sticky inside the drawer.

Upload modes:

- **Files:** Upload one or more local documents directly into the current project.
- **Folder:** Upload a local folder and preserve folder grouping as source set metadata.
- **Remote URL:** Import a source file by URL with title, description, and source metadata.
- **Connector:** Reserved for future SharePoint, Confluence, Google Drive, OneDrive, S3, ServiceNow, Git, CCMS, or CMS sources. Connector setup is not mixed into the upload dropzone; it opens a configuration drawer.
- **Recent:** Shows recently uploaded files and lets users retry failed files or reuse metadata.
- **Failed:** Focuses the queue on failed documents, failed stages, and retryable actions.

Preflight behavior:

- Run preflight before upload whenever possible: file type, size, duplicate hash, name collision, encryption/password protection, scan eligibility, known parser support, and project quota.
- Show preflight results as a compact checklist, not as modal errors unless upload is blocked.
- Allow users to fix metadata for multiple files at once: owner, language, source type, sensitivity, tags, document set, and conversion profile.
- If a duplicate is detected, offer Replace, Keep both, Skip, or Link to existing, depending on permissions.
- If the file can upload but extraction risk is high, allow upload with a warning and clearly mark the expected risk.

Ingestion queue row anatomy:

- **Identity:** Filename, extension, source type, size, source hash prefix, and optional document set/folder.
- **Status:** Exact pipeline label, stage icon, determinate progress only for upload transfer, and last event timestamp.
- **Quality:** Source confidence, OCR confidence, language detection, page/slide count, table/image detection, and warning badge.
- **Ownership:** Uploader, assigned reviewer, and current responsible role when a human action is needed.
- **Actions:** Open, inspect, retry failed stage, cancel if safe, remove if permitted, download original, view raw details.

Pipeline visualization:

- Use a compact stepper per document, not a generic spinner. The visible stages are `Queued`, `Uploading`, `Upload Complete`, `Extraction In Progress`, `Extraction Complete`, `Markdown Normalized`, `Topic Plan Ready`, `DITA Generated`, `Validation Passed` or `Validation Warnings`, `Review Ready`, `Approved`, `Export Ready`, and `Failed`.
- Completed stages collapse into small success checks. The active stage expands enough to show event text and elapsed time. Failed stages expand to show reason and next action.
- Batch-level progress summarizes counts by state, but every file keeps its own row. Do not hide individual failures behind a batch success message.
- Use streamed job progress when available; otherwise poll predictably and show last updated time.

Document detail inspector:

- **Preview:** First pages/slides or extracted text preview with parser warning if preview is partial.
- **Metadata:** Title, source type, tags, language, sensitivity, original filename, upload time, uploader, source hash, and retention policy.
- **Pipeline Events:** Chronological events with stage, timestamp, actor/service, and retry marker.
- **Source Quality:** OCR warnings, low-confidence blocks, missing images, table extraction risk, language mismatches, duplicate sections, and unsupported elements.
- **Chunks/Blocks:** DITAgen source blocks, page/slide location, confidence, and trace IDs; use "chunks" only as an analogy when discussing RAG-style ingestion.
- **Artifacts:** Original file, Markdown projection, source block JSON, assets, topic plan, generated topic JSON, DITA XML, validation reports, and export package references.
- **Raw Details:** JSON/log views are behind a toggle and use `code-editor`; normal users see readable summaries first.

Modern visual treatment:

- Keep the upload command zone large but restrained: solid surfaces, dashed border, icon, concise text, no gradient hero treatment.
- After files are selected, reduce the visual dominance of the dropzone and promote the queue and preflight panel.
- Use sticky queue headers and row-level status badges so long uploads stay scannable.
- Use inline progress and stage chips rather than modal progress dialogs.
- Use one primary action per state: Upload selected, Retry failed, Continue to topic plan, Open review, or Export ready.
- Make warnings actionable and local to the affected file or stage.

Permission and governance behavior:

- Users without upload permission see the queue and source evidence they can read, plus a clear reason upload is disabled.
- Sensitive or regulated projects show classification and retention copy in the health rail and metadata panel.
- Malware scanning, policy checks, and retention policy are visible as status items but do not expose security internals.
- Deleting a document requires explicit confirmation and must describe whether generated artifacts, reviews, and exports are affected.
- Connector credentials and OAuth flows are configured in secure drawers or admin settings, not in generic text fields on the upload page.

Adversarial review and countermeasures:

- **Failure mode: The upload page becomes a giant dropzone and hides the queue.** Countermeasure: after file selection or upload start, the queue becomes the dominant surface and the dropzone compresses.
- **Failure mode: Users see only "Processing" and cannot tell what is happening.** Countermeasure: every row shows the exact pipeline label, active stage, last event, and next action.
- **Failure mode: Batch upload hides individual failures.** Countermeasure: batch summaries never replace per-file rows; failed rows stay visible until resolved or dismissed.
- **Failure mode: Preflight blocks users with noisy errors.** Countermeasure: warnings are grouped into fixable checklist items; only unsupported, unsafe, or quota-blocked files stop upload.
- **Failure mode: The UI leaks sensitive filenames or document metadata.** Countermeasure: restricted users see safe project-level status only; filename, preview, source hash, and metadata require document read permission.
- **Failure mode: Retry creates duplicates or inconsistent artifacts.** Countermeasure: retry is stage-scoped and keeps artifact version history; duplicate hash handling is explicit.
- **Failure mode: Users remove documents without understanding downstream impact.** Countermeasure: destructive actions describe affected source blocks, topics, reviews, exports, and audit records before confirmation.
- **Failure mode: Raw JSON overwhelms non-technical users.** Countermeasure: readable cards are the default; raw views are opt-in and scoped to debug drawers.
- **Failure mode: Connector setup pollutes the upload path.** Countermeasure: upload modes are tabs; connector configuration opens a separate drawer with test connection, sync schedule, and permission mapping.
- **Failure mode: The page looks sleek but loses accessibility.** Countermeasure: drag-and-drop has equivalent file-picker controls, rows are keyboard reachable, progress updates use meaningful live-region announcements, and color is never the only status signal.

Five-second scan test:

- The user can identify accepted source types and limits.
- The user can identify which files are uploading, processing, failed, or ready.
- The user can identify whether the issue is quota, format, security, extraction, OCR, validation, or human review.
- The user can identify the next action for each file.
- The user can open source evidence or pipeline details without reading raw logs.

## Document Strip And Pipeline State

Document chips represent uploaded source artifacts. The chip should show filename, type, confidence, and processing or approval state when available. Confidence badges use success or warning containers; low confidence should link users to source quality details or affected blocks.

Processing banners use `status-info` with a spinner or timeline icon. Completed states use `status-success`. Validation, OCR, missing source, and export problems use `status-warning` or `status-danger` based on severity.

The document strip is not only navigation. It is a compact source-set control for moving between files in one project. Each document item must include filename, source type, current pipeline state, quality badge, topic count, and warning count. Long filenames truncate in the middle, not only at the end, so extensions and version numbers remain visible.

Use `document-row` for dense table/list views and `document-chip` for compact horizontal strips. Rows are preferred when more than six documents exist or when users must compare status, confidence, owner, and actions. Chips are acceptable inside review workspaces where the user needs quick document switching.

Document states:

- **Selected:** Uses `document-chip-active` or selected row treatment with a blue left edge or underline.
- **Review required:** Shows warning badge and links directly to source quality or validation details.
- **Blocked:** Uses danger treatment and exposes the failed stage without opening raw logs.
- **Ready:** Uses success treatment and includes the next action, such as Open topic plan, Review, Approve, or Export.
- **Restricted:** Shows safe metadata only and explains access limitation.

Do not use the document strip to show every artifact. Artifact registry, source blocks, Markdown, topic plan, validation, and exports each have their own panels.

## Pipeline Status

Pipeline status is a first-class design object. Use these exact user-facing labels:

- `Queued`: The document or job is accepted but not yet running.
- `Uploading`: File bytes are transferring or multipart upload is incomplete.
- `Upload Complete`: The source file is persisted and ready for extraction.
- `Extraction In Progress`: The extraction, OCR, or source-block generation stage is running.
- `Extraction Complete`: Source blocks and assets are available.
- `Markdown Normalized`: The reviewable Markdown projection is available.
- `Topic Plan Ready`: Topic boundaries, topic types, and confidence are ready for review.
- `DITA Generated`: Topic JSON and DITA XML have been generated.
- `Validation Passed`: Validation completed without blocking issues.
- `Validation Warnings`: Validation completed with warnings or review-required issues.
- `Review Ready`: A user can inspect, edit, comment, regenerate, approve, or reject topics.
- `Approved`: Required topics or project artifacts have been approved.
- `Export Ready`: The project meets export policy and can build a DITA package.
- `Failed`: A stage failed and the row must expose the failed stage, reason, retry action, and supportable next step.

Use `pipeline-state-color-map` from [`design-system.md`](design-system.md#pipeline-state-color-combinations) for exact label-to-color mapping. `Queued` uses `pipeline-step-neutral`; running and review-ready states use `pipeline-step-active`; completed states use `pipeline-step-success`; warning/review issues use `pipeline-step-warning`; failed states use `pipeline-step-danger`. A status row may include a progress bar only for determinate work such as upload transfer. Extraction, OCR, LLM generation, validation, and export should use stage indicators with timestamps and recent event text.

Pipeline display rules:

- Project-level status is an aggregate and must never hide per-document state.
- Document-level status uses a stepper or status row with stage, service, last event, elapsed time, and retry/cancel availability.
- Document-level status changes use `status-transition-contracts` so progress, failure, recovery, and stale-to-fresh changes animate consistently across queue rows and document chips.
- Topic-level status appears inside topic plan, review, validation, and export panels.
- A `Failed` state always includes failed stage, user-readable reason, retryability, affected artifacts, and support/audit ID.
- A warning state must distinguish "can continue with review" from "must fix before export".
- Stale status shows last refresh time and `status-warning`; do not imply a stage is still running if progress updates are unavailable.
