# DITAgen Design Documentation

Start with [`DESIGN.md`](../../DESIGN.md) for the compact design contract, then open only the focused file needed for the screen or system area you are changing.

## LLM Usage Rule

When modifying a screen, read `DESIGN.md` first, then read only the matching file below. Do not load every design file unless changing shared tokens, cross-screen behavior, accessibility, loading states, permission handling, or global design rules.

## Files

- [`design-system.md`](design-system.md): design tokens, core principles, colors, typography, layout primitives, elevation, and shapes.
- [`components-common.md`](components-common.md): app chrome, common panels, tabs, forms, tables, authentication, and responsive behavior.
- [`operational-systems.md`](operational-systems.md): accessibility, dark mode, motion, i18n/RTL, state taxonomy, notifications, shortcuts, command palette, forms/tables, diffs, versioning, comments, permission failure, audit, confidence, onboarding, concurrency, resilience, and search.
- [`screen-bu-dashboard.md`](screen-bu-dashboard.md): Business Unit dashboard portfolio command center.
- [`screen-project-hub.md`](screen-project-hub.md): Project Hub portfolio and project selection experience.
- [`screen-upload-ingestion.md`](screen-upload-ingestion.md): document upload, preflight, ingestion queue, pipeline status, and document strip.
- [`screen-review-workspace.md`](screen-review-workspace.md): review workspace, source evidence, topic plan, DITA editor, validation, and traceability.
- [`screen-export-agent.md`](screen-export-agent.md): export center plus bounded agent and MCP activity.
- [`screen-audit-admin-settings.md`](screen-audit-admin-settings.md): audit log, settings/admin shell, dangerous settings, and connector setup drawer.

## Preservation Note

This directory was split from the previous monolithic `DESIGN.md`. The detailed screen and component content was moved into focused files instead of being discarded.
