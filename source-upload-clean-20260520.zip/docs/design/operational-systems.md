# Operational Systems Spec

These rules define the product-level interaction systems that the screen specs rely on. They apply across the Business Unit Dashboard, Project Hub, Upload and Ingestion, Review Workspace, Export Center, and admin surfaces. They are part of the DITAgen design contract, not optional polish.

## Accessibility

DITAgen is used for compliance, technical publishing, and regulated content review. Accessibility is not a finishing pass; it is part of the contract a reviewer or approver depends on to do their job correctly. The product targets WCAG 2.2 AA and goes further on focus management, keyboard reachability, and announcement semantics because the workflows include legally meaningful approvals.

### Contrast

- All body text and interactive labels meet WCAG AA against their declared background. Small text minimum is 4.5:1; large text and badges minimum is 3:1.
- Tertiary red (`#C7392F`) on white is 4.51:1. It passes AA for body text but is marginal for sub-13px text, so do not place small monospace identifiers in tertiary red.
- Container fills such as `success-container`, `warning-container`, `danger-container`, and `info-container` are intentionally pale. Always use their matching on-container text colors. Do not place `neutral-700` body text on `warning-container`.
- Text colors must follow the approved `approved-color-pairings` matrix in [`design-system.md`](design-system.md#approved-on-x-pairings). A new foreground/background pair requires a contrast audit before use.
- Do not rely on color alone to communicate severity. Every badge and status row carries an icon and a textual label.
- Severity UI must use the full `severity-stack`: status rows get container fill, matching container text, a 4px solid severity edge, icon, and label; badges use container fill, matching text, and icon; solid actions use solid fill and solid text.

### Keyboard

- Every interactive element is reachable by `Tab` in DOM order. DOM order matches visual reading order: context, filters, primary content, inspector, actions.
- Roving focus is used inside grids such as the BU Bento grid, Project Bento grid, and document strip. One `Tab` enters the grid; arrow keys navigate within it. The grid still exposes logical reading order to assistive technology.
- Composite controls such as data tables, the DITA editor, and the diff viewer follow ARIA Authoring Practices for grid and treegrid. They announce row, column, and selected state.
- `Esc` dismisses overlays in this priority order: command palette, modal, drawer, popover, tooltip. Closing one layer must not close a deeper layer accidentally.
- A visible focus ring is required on every focusable element. Use `focus-ring` on light surfaces and `focus-ring-on-dark` on the navy app bar and `surface-inverse` rail.

### Touch And Pointer

- Minimum touch target is 44 x 44 CSS px on tablet and mobile. `icon-button` remains 36px visually, but it gets an invisible hit-area expansion to 44px on those breakpoints.
- Hover-only affordances are forbidden. Every action available on hover is also available on focus and on a row-level overflow control.

### Live Regions And Announcements

- Long-running pipeline progress uses a polite live region. Announce stage transitions such as `Extraction In Progress` to `Extraction Complete`, and final outcomes such as `Validation Passed` or `Failed`. Do not announce every progress percentage.
- Validation issue counts use a polite live region scoped to the validation panel, not the document. The reviewer is the audience; the announcement updates when filter results change.
- Agent generation announces start, stop, and meaningful completion. Token-by-token streaming is buffered until the next stable Markdown block. Streaming raw tokens to a screen reader is disorienting.
- Toasts use polite announcements for success and informational events. Save failures, network loss, and authorization expiry use assertive announcements.

### Motion And Reduced Motion

- Respect `prefers-reduced-motion: reduce`. The required override matrix lives in `reduced-motion-overrides` in [`design-system.md`](design-system.md). Reduced motion does not mean silent; functional changes still occur, but spatial and temporal animation is suppressed.
- Parallax, decorative entry animations, and spring-bounce transitions are not used.

### Authentication And Session

- Sign-in error messages are specific enough to help a real user but never reveal whether a user ID exists. Use the same response time and same error string for "no such user" and "wrong password."
- Session expiry warning is announced 60 seconds before sign-out, with a reauthenticate action in place that preserves the current screen, scroll position, and unsaved buffer.

### Permission Failure

- Disabled controls explain the missing permission inline. Tooltip on focus and click reveals the role required. Disabled controls do not silently swallow clicks.
- A user who cannot see a record sees a placeholder row with the access reason and a request-access action when policy allows it. They never see the record name, hash, or quality signals.

## Dark Mode Strategy

DITAgen is a long-session content review surface with frequent code and XML editing. Dark mode is part of the core product contract for that audience.

### Strategy

- Maintain one set of semantic tokens such as `surface`, `on-background`, `outline`, and `primary`. Provide two value sets: light values through `colors` and dark values through `dark` in `design-system.md`.
- Components reference semantic names only. They do not branch on theme and do not hardcode raw hex values.
- The auth shell, navy top app bar, and `surface-inverse` rail already act like dark surfaces in light mode. In dark mode, the app bar tone shifts lighter instead of staying at `primary-900`; otherwise the bar disappears into the canvas.

### Dark Theme Values

- The proposed dark theme values live in the `dark` token group in `design-system.md`.
- The light-to-dark mapping lives in `theme-parity`; implementation must use those values rather than algorithmic inversion.
- Pale containers in light mode become muted dark fills with desaturated foreground text. Do not invert by simply darkening the container; readability collapses.
- Shadows in dark mode are shallower and use a darker shadow color such as `rgba(0, 0, 0, 0.5)`. Keep elevation expressed primarily through tonal contrast and 1px borders.
- The deep navy `primary` becomes lighter in dark mode so it can carry foreground emphasis. The dark canvas becomes the institutional frame.

### Theme Switching

- The default theme follows the OS preference. Manual override is persisted per user and per device.
- Theme-dependent images such as logo marks and illustrations ship two variants. The DITAgen logo loses any subtle drop shadow in dark mode.
- Dark mode is never auto-applied during a single session if the user has not opted in. Sudden inversion during review is a cognitive disruption; respect the user setting.

## Motion And Animation

The product is operational, not promotional. Motion clarifies state transitions and preserves spatial continuity. It is never decorative.

Allowed motion:

- State transitions on buttons, tabs, badges, and panel collapses use `motion.duration.normal` with `motion.easing.standard`.
- Drawer and modal entrance uses `motion.presets.drawer`. A drawer slides from the side it is anchored to, not from below.
- Toast in and out uses `motion.presets.toast-in` and `motion.presets.toast-out`. Toasts stabilize in a corner and never fade in over content the user is reading.
- Skeleton shimmer uses `motion.presets.skeleton-shimmer` and is disabled on `prefers-reduced-motion`.
- Pipeline state change is a cross-fade between the previous and new badge over `motion.duration.fast`. The icon and label change simultaneously; do not animate them independently.
- Diff hunks use a 1-second highlight band when newly accepted, then fade. This is the only motion used to draw attention to a change after the fact.

### Per-Component Motion Contracts

Every animation references `motion` tokens and the structured `component-motion-contracts` map in [`design-system.md`](design-system.md). Do not invent one-off durations.

**Button**

- Background color transitions over `motion.duration.fast` with `motion.easing.standard` on hover and active.
- Click feedback uses a brief `transform: scale(0.985)` over `motion.duration.instant`, then returns to normal. Disable this feedback under reduced motion.
- No springiness and no ripple effect.

**Tab**

- The active 2px indicator animates position over `motion.duration.normal` with `motion.easing.standard`.
- Tab content swaps with a 120ms opacity cross-fade and no movement. Keep the outgoing content height fixed during the transition to prevent layout jump.
- If the user rapidly changes tabs, animate only the latest target and skip intermediate states.

**Drawer**

- Right-side drawers such as `detail-inspector`, notification center, settings drawer, connector drawer, and document detail drawer slide from `translateX(100%)` to `translateX(0)` over `motion.duration.slow` with `motion.easing.decelerate`.
- Drawer exit reverses the transform over `motion.duration.normal`, so closing feels slightly faster than opening.
- Backdrop opacity animates at the same time from `0` to `0.32`, or `0.48` for full-overlay drawers.
- A drawer never fades; it slides. Fading drawers feel weightless and weaken the spatial model.

**Modal**

- Backdrop fades in over 120ms.
- Container enters from 8px below final position and fades from 0 to 1 over `motion.duration.normal` with `motion.easing.decelerate`.
- Closing reverses slightly faster over `motion.duration.fast`.
- A modal never zooms or scales. Use subtle vertical motion only.

**Toast**

- Toasts enter bottom-right with `motion.presets.toast-in`: slide from 16px below plus fade.
- New toasts push existing toasts up over `motion.duration.normal` with `motion.easing.standard`.
- Dismissal uses `motion.presets.toast-out`: fade plus 8px slide right.
- Auto-dismiss timers pause on hover and focus.
- The `+N more` pill appears with the fourth toast and does not animate independently.

**Tooltip**

- Tooltip appears after a 400ms hover delay, with no delay when triggered by focus.
- It fades in over 120ms with no movement.
- It disappears immediately on mouse leave or blur, with no fade.
- Position is locked at trigger time; if the trigger moves, the tooltip moves instantly.

**Popover**

- Popover appears immediately on click.
- It fades in over `motion.duration.fast` with a 4px slide from the trigger direction.
- Click outside or `Esc` dismisses instantly. Popovers are UI panels, not floating decoration.

**Badge State Change**

- Severity changes such as `Validation Warnings` to `Validation Passed` cross-fade the entire badge over `motion.duration.fast`.
- Icon and label change together; do not animate them independently.
- Numeric badge counter changes may roll the digit over 200ms with a vertical slide only when the rest of the screen is calm. Otherwise use an instant swap.

**Dropdown And Select**

- Dropdowns open with `motion.duration.fast`, fading and sliding 4px down from the trigger.
- They close instantly on selection or `Esc`.

**Sidebar Item**

- Hover background color transitions over `motion.duration.fast`.
- Active 2px primary stripe animates position over `motion.duration.normal` when navigating between rail items.

**Resize Handle**

- Hover color transitions from `outline` to `outline-strong` over `motion.duration.fast`.
- During active drag, panels resize live without animation.
- On release, panels settle to the final size with a 60ms ease-out.

### Per-Screen Choreography

Screen choreography references `screen-motion-choreography` in [`design-system.md`](design-system.md). These rules are about preserving context during workflow changes, not adding decoration.

**Sign In**

- Card fades in from 8px below over `motion.duration.slow` with `motion.easing.decelerate` on initial load.
- Form field errors slide the helper-text container down 4px on validation failure with a 180ms height transition. On clear, the container slides back up.
- Primary action shows an inline spinner inside the button during sign-in attempt; button text remains visible.

**BU Dashboard And Project Hub**

- Page entrance: status strip and rails fade in immediately. Bento tiles stagger-fade over 120ms with a 32ms cascade.
- Cap the entrance cascade at 4 tiles; all remaining tiles fade in together so large grids do not feel slow or promotional.
- Filter changes: the grid does not recompose with decorative motion. Tiles that no longer match fade out over 120ms; remaining tiles reflow over `motion.duration.normal`; new tiles fade in last. The whole sequence must complete in under 320ms.
- Bento sizing changes, such as a tile moving from 4 columns to 6 columns due to a blocker, animate over `motion.duration.normal` with `motion.easing.standard`. Surrounding tiles flow into position at the same time.
- Refresh shows a brief spinner in the refresh icon, rotating over `motion.duration.deliberate`. Updated values cross-fade in their badges, and stale indicators fade out as values arrive.

**Document Upload**

- Drag-active state transitions over `motion.duration.fast`; background color, border style, and `scale(1.01)` animate together.
- File added to queue: row fades in from the right, `translateX(8px)` to `0`, over `motion.duration.normal`.
- Pipeline advancement: stage badge cross-fades and the stepper progress fill grows over 240ms with `motion.easing.decelerate`.
- Long-running stages without progress use a slow 1400ms indeterminate pulse on the active step only.
- File removal collapses row height to 0 over 200ms, then removes the row. Surrounding rows shift up smoothly.

**Topic Plan**

- Selecting a candidate cross-fades inspector content over `motion.duration.fast`; selected state on the candidate row applies instantly.
- Approving a candidate triggers a 300ms `success-container` flash on the row, then the row status badge updates with a cross-fade.
- If sort order is by status, approved rows may reorder over `motion.duration.normal`.
- Recompute keeps affected rows visible with a subtle skeleton overlay on top of existing content. Rows do not disappear. When new data arrives, the overlay fades out over 200ms.

**Review Workspace**

- Evidence-panel tab switching follows Tab component motion.
- Selecting an issue in the validation tab scrolls the editor to the affected element over 280ms with `motion.easing.decelerate`.
- The affected editor element receives a 1-second `warning-container` highlight band, then fades out over 600ms.
- Saving a draft shows an inline spinner in the save button. On success, the button flashes `success-container` for 200ms, returns to default, and a toast confirms.
- Approving a topic transitions the approve button to success solid for 300ms, then the panel moves to post-approval state. The Approve button cross-fades into Approved text with a check icon.
- Regeneration diff arrival slides the diff viewer in from the right as a 600px drawer over `motion.duration.slow`.

**Validation Triage**

- Filter changes: rows leaving the filter fade out over 120ms; remaining rows reflow over `motion.duration.normal`; new rows fade in last.
- Severity-group collapse shifts rows upward and rotates the group chevron 90 degrees over `motion.duration.fast`.
- Bulk action begins with selected rows fading to `surface-selected` for 200ms. On success, rows update or fade out depending on the action.

**Export Center**

- Build button click shows an inline progress bar inside the button background: a slim 2px bar at the bottom while the build runs.
- On success, the button briefly shows a check, then returns to default. The new export fades in at the top of history.
- Failed export rows appear with the `status-danger` left edge fading in over `motion.duration.fast`, and a toast announces the failure.

**Audit Log**

- New events at the top shift existing rows down over `motion.duration.normal`, then the new row fades in at the top.
- This animation runs only when the user is at the top of the table. If they have scrolled away, the new row appears silently and an `X new events` pill becomes available at the top to scroll back.

**Notification Center**

- Drawer slide-in uses Drawer component motion.
- Marking one notification as read fades the unread indicator out over 120ms; the row stays in place.
- Mark all as read fades visible indicators out in a 200ms cascade with a 32ms stagger capped at 4 indicators; the remaining indicators fade together.

**Command Palette**

- Opening fades the backdrop and moves the container from 8px above final position to final position while opacity moves from 0 to 1 over `motion.duration.fast`.
- Result list updates while typing swap instantly. Do not animate result reordering during typing because it is disorienting.
- Arrow-key selection movement changes the selected-row background instantly.

**Diff Viewer**

- Drawer entrance uses Drawer component motion.
- Hunk accept shows a 1-second `success-container` highlight band, then transforms to unchanged-context style over 300ms.
- Hunk reject shows a 600ms `danger-container` highlight, then collapses height to 0 over `motion.duration.normal`. Surrounding hunks shift up.
- Mode toggle between unified and side-by-side cross-fades over `motion.duration.fast`. Layout shift during the cross-fade is acceptable because both modes show the same content.

**Comments**

- New comment fades in at the bottom of the thread with a 4px slide up. Composer collapses to its default state.
- Resolution collapses the thread to a 32px row over `motion.duration.normal`, summarized as `Resolved by <user>`.
- Clicking a comment scrolls the editor to its anchor over `motion.duration.normal` with `motion.easing.decelerate`; the target element receives a 1-second highlight.

### Reduced Motion Override Matrix

Every animation above declares its reduced-motion behavior through `reduced-motion-overrides`. Reduced motion preserves feedback and state clarity while suppressing spatial and temporal movement.

| Pattern | Reduced motion override |
| --- | --- |
| Click scale feedback | Disabled; color and contrast feedback remain |
| Tab indicator slide | Instant position change |
| Tab content cross-fade | Instant swap |
| Drawer slide-in | Instant appearance plus 80ms backdrop fade |
| Modal slide-up | Instant appearance plus 80ms backdrop fade |
| Toast slide and fade | 80ms fade only, no slide |
| Tooltip fade | Instant |
| Popover fade and slide | 80ms fade only, no slide |
| Badge cross-fade | Instant swap |
| Counter rolling digit | Instant swap |
| Sidebar item indicator slide | Instant |
| Bento grid stagger entrance | All tiles fade in together over 120ms |
| Bento grid reflow | Instant rearrangement |
| Pipeline stepper fill | Instant fill change, no growth animation |
| Skeleton shimmer | Disabled; static skeleton |
| Spinner rotation | Disabled; replace with a non-rotating 12-frame static dot cycle over 800ms |
| Indeterminate progress ribbon | Disabled; replace with a single static loading label |
| Stage active dot pulse | Disabled; static dot |
| Issue scroll-to-element | Instant scroll, no smooth scrolling |
| Highlight band fade | Show for 1s, then clear instantly |
| Diff hunk accept highlight | Show for 600ms, then clear instantly |
| Diff hunk reject collapse | Instant collapse |
| Approve button success flash | Instant icon swap, no flash |

### Reduced Motion — Alpha implementation

Source: `apps/web/src/styles.css`.

The shipped CSS implements reduced motion as a single global override
that disables every transition and animation on every element when the
user has `prefers-reduced-motion: reduce` set:

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    transition: none !important;
    animation: none !important;
  }
}
```

This is a coarser implementation than the per-pattern matrix above
prescribes. It is correct for the alpha because:

- The shipped UI's only continuous animations are the BU card
  status-edge pulse for processing tone and the meta-dot pulse for the
  same. Both communicate "active" but neither encodes critical state —
  the meta text and status pill carry the truth. Killing the animation
  hides nothing.
- The shipped transitions are short (120 / 180 ms) and only animate
  hover, focus, and small lift effects. None of them encode required
  feedback that would be lost in a reduced-motion mode.

When the per-pattern overrides in the matrix above start to differ from
this blanket rule (e.g. a real diff hunk accept highlight, or a tab
content cross-fade), replace this global override with targeted rules
matching the matrix.

### Scrollbars (Alpha implementation)

Source: `apps/web/src/styles.css`.

```css
*::-webkit-scrollbar       { width: 10px; height: 10px; }
*::-webkit-scrollbar-track { background: transparent; }
*::-webkit-scrollbar-thumb {
  background: var(--border-strong);
  border: 2px solid var(--bg);
  border-radius: 999px;
}
*::-webkit-scrollbar-thumb:hover { background: var(--text-faint); }
```

Webkit-only (Chromium / Safari). Firefox uses its native scrollbar; we do
not currently override `scrollbar-width` or `scrollbar-color` because the
defaults are acceptable. The thumb uses `var(--border-strong)` so it
matches other hairline borders, with a 2-px transparent inset to make
the thumb feel slimmer than its container width.

Do not hide scrollbars on dense evidence, validation, queue, activity, or
editor panels. Users need to see that more content exists.

### Choreography Rules

- Stagger sparingly. Cascades over 4 elements look promotional; cap stagger to 4 elements at 32ms apart, and animate everything beyond the cap together.
- Motion direction follows attention. Drawers slide from the side where they live, toasts enter from the corner where they rest, and modals rise into focus.
- Layout-altering motion completes before content motion. When a drawer opens and reveals new content, the drawer reaches its final position before content inside starts animating.
- Status changes lead and decorations follow. When a row moves from warning to success, the badge changes first; decorative stripes and icon backgrounds follow within 80ms.
- Avoid simultaneous color and movement on the same element. A control changing color, scaling, and moving at once is too much; choose one primary cue per state.
- Continuous motion is forbidden in operational surfaces. The active pipeline-stage dot is the single approved exception, and it stops once the stage transitions.

Forbidden motion:

- Bounce springs on UI controls.
- Marquee or auto-scrolling content.
- Continuous loading spinners on stages that have a determinate progress signal.
- Parallax or depth-based motion.
- Avatar animation, typing cursors, or chat-style message reveals on agent traces. Use buffered Markdown.

## Internationalization And RTL

Localization managers are primary users. The product must not assume a single locale or left-to-right UI.

### Layout

- Horizontal layouts such as `workspace-header`, `filter-bar`, `top-app-bar`, and drawer anchor side flip in RTL locales. The rail moves to the right; the action rail moves to the left. Progressive disclosure direction flips accordingly.
- The DITA editor and any content showing XML, source IDs, or DITA paths stays LTR even in an RTL locale. Code is universal LTR. The surrounding UI chrome flips; code panels do not.
- Source previews of the original document do not flip. They show the original source orientation. Agent-generated text follows the project locale.

### Translation Expansion

- Plan layouts for a 30% translation expansion buffer for languages such as German, Russian, and Polish, and a 50% expansion buffer for compact labels such as chips, badges, and tabs.
- Long file names truncate in the middle so extension and version are preserved. Tab labels truncate at the end with a tooltip.
- Pipeline labels such as `Queued`, `Extraction In Progress`, and `Topic Plan Ready` are part of the product contract. They are translated, and the layout reserves the width of the longest translated form.

### Locale-Aware Formatting

- Dates use the user's locale. Active queues can show relative time such as "3 minutes ago"; hover and audit views include absolute UTC timestamps such as `2026-05-07 14:32 UTC`.
- Audit records always include the UTC absolute timestamp. Relative time is decorative.
- Numbers, currency, and file sizes are locale-formatted. File sizes use binary units such as `MiB` in source-quality and storage panels; user-facing copy can use SI units such as `MB` when the audience is non-technical.
- Document and topic identifiers are not translated. Source block IDs are immutable and rendered in `mono-sm` regardless of locale.

### Bidi Text In Mixed Content

- Source blocks may contain RTL text inside an LTR project, and vice versa. Use the Unicode bidi algorithm and add `dir="auto"` on extracted text containers.
- Do not force direction at the container level for source previews.

## Loading, Skeleton, And Empty/Error State Taxonomy

The product standardizes loading and state patterns so screens do not invent local behavior.

| State | When | Pattern |
| --- | --- | --- |
| Optimistic | User performed an action; backend will confirm in less than 300ms | Render the resulting state immediately; reconcile silently on confirm |
| Skeleton | Page or panel is loading first paint of structured data | Skeleton blocks preserve eventual layout geometry |
| Inline spinner | A specific control awaits server response for up to 2s | Spinner inside the control; control is disabled and announced as busy |
| Determinate progress | Upload transfer or operation with byte/percent truth | Progress bar with percent and elapsed time |
| Stage stepper | Async pipeline work without smooth percent, such as extraction or OCR | `pipeline-step-active` with last event text and elapsed time |
| Streamed | Agent generation | Buffered Markdown with stop control, stage label, and live-region updates |
| Stale | Last-known data is older than the panel freshness budget | Show last data with `status-warning` badge and refresh control |
| Degraded | One subsystem failed; rest of screen is functional | Affected panel shows degraded state; other panels stay live |
| Empty | No records yet | Compact empty state with reason and one next action |
| Restricted | User cannot read this record | Placeholder row with role reason and request-access action when policy allows |
| Error | Action failed | Inline error with cause, retryability, and audit ID where applicable |
| Offline | Network unreachable | Persistent banner; reads from safe local cache; writes are deferred |

Rules:

- The page never shows a single global spinner that blocks all panels. Each panel manages its own loading state so a slow panel never holds a fast one hostage.
- Skeletons preserve final geometry. A skeleton Bento tile is the same span as the eventual tile; a skeleton row is the same height as a real row. Layout shift on data arrival is a defect.
- Spinners do not appear inside skeletons. Pick one.
- Error states always include cause, suggested action, and, when relevant, an audit or correlation ID the user can quote to support. They never read only "An error occurred."

### Loading Motion Specs

Loading visuals use `loading-animation-contracts` in [`design-system.md`](design-system.md). They must communicate expected duration and available user action.

**Skeleton Shimmer**

- Skeletons use `surface-subtle` as the base.
- Shimmer is a horizontal gradient pass at 60% to 80% lightness.
- The shimmer animates from `-100%` to `200%` horizontal background position over `motion.presets.skeleton-shimmer` (`1400ms ease-in-out infinite alternate`).
- Shimmer angle is `0deg`. Do not use diagonal shimmer; diagonal shimmer reads as marketing polish rather than operational loading.
- On `prefers-reduced-motion: reduce`, shimmer stops and the skeleton remains at the static low-luminance state.

**Spinner**

- Default spinner is a 16px circle with 2px stroke and 25% of the circumference visible.
- Spinner rotates 360 degrees over 800ms linear, infinite.
- Sizes: `xs` is 12px with 1.5px stroke, `sm` is 16px with 2px stroke, `md` is 20px with 2.5px stroke, and `lg` is 24px with 3px stroke.
- Spinner color inherits `currentColor` from its container.
- Use spinner only for indeterminate operations under 4 seconds. Beyond 4 seconds, replace with a stage stepper or progress bar.
- Inline spinners inside buttons preserve button text. Never hide the label.

**Indeterminate Progress Bar**

- For long indeterminate work over 4 seconds where stage information is not available, show a 2px bar at the bottom of the active container.
- A 30%-wide ribbon translates from `-30%` to `130%` over 1200ms with `motion.easing.standard`, infinite.
- Use `secondary` against `surface`.

**Stage Stepper**

- The active stage shows an animated 4px dot on the leading edge of the step.
- The dot pulses scale `1` to `1.4` to `1` over 1200ms.
- Completed stages do not animate.
- Failed stages do not animate; they show a static danger icon.
- Reduced motion disables the pulse; the active dot is shown statically.

### Status Transitions

Status changes use `status-transition-contracts`. The transition tells users whether a record advanced, failed, recovered, or simply refreshed.

- Same-direction progress such as `Queued` to `Uploading` to `Upload Complete` to `Extraction Complete` cross-fades the badge over `motion.duration.fast`. The pipeline stepper fills the next stage with a 240ms color transition.
- Failure from any state to `Failed` cross-fades the badge to danger over `motion.duration.fast`, then animates the row left edge to a 4px danger stripe over the same duration. Do not use shake; shake is anxiety-inducing for serious failure modes. The color change is the announcement.
- Recovery from `Failed` to `Queued` after retry cross-fades the badge and fades the 4px danger edge back to neutral.
- Stale to fresh fades the stale badge out over 200ms while fresh values cross-fade in. This prevents the popping feel of synchronous state replacement.

### Empty-State Copy Patterns

Short, literal, action-led. Never marketing copy.

- BU dashboard with no accessible BUs: "You don't have access to a Business Unit yet. Request access or contact your tenant admin."
- Project with no documents: "No documents uploaded. Upload source files to start extraction and topic planning."
- Validation panel with no issues: "No validation issues. Re-run validation after editing."
- Topic plan empty: "Topic plan is not ready. It runs after Extraction Complete on at least one document."

## Notifications And Toasts

Notifications live in three surfaces, each with a different job.

1. **Transient toasts:** Confirm a just-performed action or surface a recoverable failure. Auto-dismiss in 4 to 6 seconds for success/info or stay until dismissed for warning/danger. Never carry primary content. Use `toast` and its variants. Toasts stack bottom-right; a maximum of three are visible; older toasts collapse into a "+N more" pill.
2. **Notification center:** A panel opened from the app bar bell icon. Persists until acknowledged. Holds assigned reviews, mentions, agent approval requests, export completion or failure, access request decisions, retention warnings, and policy alerts. Each notification deep-links to the relevant artifact with the right filter and panel pre-selected.
3. **In-page banners:** Project- or document-scoped persistent state. Used for stale metrics, degraded subsystems, policy override required, and "this artifact has unsaved changes from another tab." Banners are dismissible only when the underlying condition is resolved.

### Notification Center Layout

The notification center is anchored to the bell icon in the global app bar. The unread count overlays the bell with `badge-numeric`.

- Trigger: click the bell icon or activate it from keyboard focus.
- Surface: right-side `notification-drawer`, 420px wide, `z-index.drawer`, with vertical scrolling inside the drawer.
- Header: `notification-drawer-header`, 56px, sticky, with title, filter dropdown, and mark-all-read action.
- Tab strip: `notification-tab-strip`, 40px, with All, Unread, Mentions, Approvals, and System tabs.
- Row: `notification-row`, minimum 64px, `12px 16px` padding, 4px left category stripe, 40px top-aligned avatar for the actor or system source, title in `body-md` clamped to 1-2 lines and ellipsized at 3 lines, one-line context breadcrumb in `body-sm neutral-700`, right-aligned timestamp in `body-sm neutral-500`, unread indicator as a 4px top-right primary interaction dot, inline primary action, and overflow action.
- Empty state: `notification-empty-state`, 200px tall, centered copy "You're caught up." with a neutral icon.

Notification rows use the category stripe for quick scanning: info for assignment or mention, success for completed export or approval, warning for retention or policy attention, and danger for failed export, failed save, authorization expiry, or blocked workflow.

Rules:

- A toast confirming a destructive action includes a 6-second undo affordance when undo is supported. The undo button is always larger than the dismiss target.
- Toasts never duplicate validation issues. Validation issues live in the validation panel; toasts only confirm "validation re-run started" or "validation completed."
- Notification center items have read/unread state. Unread count uses `badge-numeric`.
- Selecting a notification deep-links to the relevant artifact with the appropriate panel and filter pre-selected. The notification stays in the drawer and is marked read.
- Read notification items remain visible for 30 days; older items move to an audit-style log reachable from the drawer footer.
- An assertive toast such as "Save failed - your changes are still local" never disappears on its own.

## Keyboard Shortcuts And Command Palette

Reviewers spend hours at the keyboard. Mouse-only affordances slow them down.

### Global Shortcuts

| Shortcut | Action |
| --- | --- |
| `Cmd/Ctrl + K` | Open command palette |
| `Cmd/Ctrl + /` | Open keyboard shortcut help |
| `Cmd/Ctrl + B` | Toggle navigation rail |
| `g` then `b` | Go to Business Unit dashboard |
| `g` then `p` | Go to Project Hub of current BU |
| `g` then `r` | Go to Review Workspace of current document |
| `g` then `e` | Go to Export Center of current project |
| `?` | Open contextual help for the current panel |

### Workspace Shortcuts (Review)

| Shortcut | Action |
| --- | --- |
| `Cmd/Ctrl + S` | Save draft |
| `Cmd/Ctrl + Enter` | Approve current topic when eligible |
| `Cmd/Ctrl + Shift + R` | Reject or request changes |
| `[` / `]` | Previous / next topic in the topic rail |
| `j` / `k` | Next / previous source block |
| `v` | Toggle XML / structured editor mode |
| `t` | Focus traceability panel |
| `c` | Focus comments panel |
| `Cmd/Ctrl + .` | Toggle agent activity drawer |
| `Esc` | Close active drawer, popover, or modal |

### Command Palette

The command palette is a unified command surface opened with `Cmd/Ctrl + K`. It exposes:

- **Navigation:** Any BU, project, document, topic, or readable artifact, fuzzy-matched on name, owner, hash prefix, and abbreviation.
- **Actions:** Approve, reject, regenerate, export, retry failed stage, request access, and open audit log. Each displayed command shows the role required when relevant; commands the user cannot execute are filtered out before display.
- **Recently opened:** Last 10 records across BUs.
- **Saved filters:** Any filter the user pinned in a portfolio screen.

### Command Palette Layout

The command palette uses `command-palette`, opens as a centered modal overlay over a 0.32 scrim, and anchors 20% from the viewport top so results appear close to the user's scanning path.

- Trigger: `Cmd/Ctrl + K` anywhere.
- Container: 560px wide, maximum 480px tall, `surface`, `rounded.lg`, `shadows.overlay`, `z-index.command-palette`.
- Header: `command-palette-header`, 60px, 16px padding, 20px search icon, borderless `body-lg` input, right-aligned Esc hint, and a 1px outline divider.
- Results: `command-palette-results`, scrollable, maximum 320px. Section headers use `command-palette-section-header` and group Recently opened, Navigation, Actions, and Saved filters.
- Result rows: `command-palette-result-row`, 48px, icon, primary text, breadcrumb in `body-sm neutral-700`, and shortcut hint at the right. Hover, focus, and selected states use `surface-selected`.
- Selected row: Up/Down moves the active result and Enter activates it. The active row remains visually distinct from passive hover so keyboard users can predict the command before committing.
- Footer: `command-palette-footer`, 44px, `surface-subtle`, with compact hints: Up/Down navigate, Enter select, `Cmd/Ctrl + K` close.
- Empty state: "No matches for '<query>'" with a neutral icon.

Palette behavior:

- The palette is always available from the global app bar. If the user is in an active search field, the first `Cmd/Ctrl + K` press escapes to the palette.
- The palette opens with the search field focused and shows recently opened records until the user types.
- Typing fuzzy-matches across all sources and re-ranks results as the query changes.
- The palette respects permission before rendering. A reviewer who cannot delete a topic does not see "Delete topic" as a result. Disabled action rows are not shown in the palette because a fast keyboard surface should not lead users into blocked commands.
- Each result includes a breadcrumb such as `BU > Project > Document > Topic` so the user can confirm the target before pressing Enter.

### Help Dialog

`Cmd/Ctrl + /` opens a modal listing all shortcuts grouped by scope. The dialog is also reachable from `?` when focus is not inside a text input, and from a Keyboard shortcuts link in the help menu.

## Form System

The form system standardizes state, validation timing, helper text, wizard behavior, and dangerous actions.

### Field States

Form controls use the full `interactive-state-chains.input-field` contract. Do not implement a focus ring without hover, disabled, invalid, and read-only states.

| State | Tokens |
| --- | --- |
| Default | `input-field`, border `1px solid {colors.outline}` |
| Hover | border `1px solid {colors.outline-strong}` |
| Focus | `focus-ring`, border `1px solid {colors.secondary}` |
| Filled | Same as default; helper text becomes optional |
| Invalid | border `1px solid {colors.danger}`, helper text uses `colors.on-danger-container` |
| Disabled | `disabled` token |
| Read-only | background `{colors.surface-muted}`, border `1px solid {colors.outline}`, no focus ring |

### Validation Timing

- Required-field validation runs on submit, never on focus. Focusing an empty required field and tabbing away does not trigger an error.
- Format validation for email, URL, and regex constraints runs on blur once the user has typed. It never runs on every keystroke.
- Server-side validation runs on submit. Server errors map to the same field-level invalid state with the server message.
- A form-level error summary appears at the top of the form on submit failure. It lists each invalid field with a clickable link that focuses the field. This is required for keyboard and screen-reader users.

### Helper Text, Label, And Tooltip

- The label always describes the field. It is never optional and is never replaced by a placeholder.
- Helper text appears below the field for permanent guidance such as "Project name must be unique within this BU."
- A tooltip info icon next to the label is reserved for explanations too long for helper text or tied to policy. Keep tooltip content under 280 characters.
- Required fields are indicated by an asterisk in the label and a `Required` indicator in any `aria-describedby` announcement. Optional is implicit, not labeled.

### Wizard Pattern

Multi-step flows such as project creation, connector setup, and export configuration use a stepper anchored at the top.

- The full set of steps is visible at once on desktop; mobile collapses to "Step 2 of 5."
- Step state is visible: completed uses success, active uses info, upcoming uses neutral, and error uses danger.
- Forward navigation is gated by step validity; backward navigation never destroys data already entered.
- Save-as-draft is available at any step. Drafts persist for 30 days.
- The final step shows a review summary of all entered data with an inline edit affordance per section before commit.

### Dangerous Actions

- A confirmation modal repeats the destructive verb in the primary button label, such as "Delete project," not "Confirm."
- The modal lists affected artifacts with counts, such as "This will remove 14 source documents, 47 generated topics, 3 export packages, and 2 active reviews."
- Highest-risk actions such as revoke access, delete project, or revoke export require typing the project name to enable the destructive button.
- After the action, a toast confirms with an undo affordance when undo is supported. Otherwise the toast confirms with the audit ID.

## Data Table System

Tables support dense operational work without hiding state or permissions.

### Row Selection

- Single-row selection uses a left-edge highlight with `surface-selected` and a 2px `colors.secondary` left border. No checkbox is needed for single-select grids.
- Multi-row selection uses a left-edge checkbox column. Selection state is announced to screen readers with the selected count.
- Range selection with `Shift + Click` is supported when the table is sorted by a stable column. Sort changes that would scramble the range cancel selection and announce that fact.

### Bulk Action Toolbar

- Appears as a sticky strip at the top of the table once one or more rows are selected.
- Pushes table content down rather than overlaying it.
- Includes selection count, Clear selection, and available bulk actions filtered by permission.
- If a bulk action would partially fail, the toolbar shows an estimate such as "12 of 15 will be approved; 3 require additional permission" before commit.

### Inline Editing

- Tables that allow inline edits, such as assignee, owner, and conversion profile in Project Hub, use a single click to enter edit mode for that cell only.
- `Tab` commits and moves to the next cell; `Esc` cancels.
- Edits trigger optimistic UI with a row-level success toast on confirm. On failure, the cell reverts and the row shows an inline error.

### Column Behavior

- Column resize is supported through a 6px hit area at the right edge of each header and persists per user per table.
- Column reorder is allowed through the column visibility menu, not by dragging the header itself.
- Frozen columns: the identifier column such as filename, project name, or BU name is always sticky-left in dense tables. Action columns are always sticky-right.

### Density Variants

- `data-row` at 40px is the default.
- `data-row-compact` at 32px is allowed for audit logs and validation triage where users scan long lists.
- `data-row-comfortable` at 52px is allowed for tables that display two lines of content per row, such as document name plus path.

### Absent, Zero, And Unknown

- Empty cell: a single em dash (`—`) styled in `colors.neutral-500`.
- Zero: numeric `0` in the same color as other numerics.
- Unknown or unresolved: italicized `unknown` in `colors.neutral-500`, with a tooltip explaining why.

These three values mean different things in audit and quality contexts and must read differently at a glance.

## Diff Viewer

Regeneration, agent proposals, topic recompute, and version compare all rely on a reversible diff before apply. The diff viewer is a first-class component used in three contexts: regeneration preview inside the review workspace, agent proposal inside the agent panel, and version compare from artifact history.

### Modes

- Unified diff is the default for narrow contexts such as drawers and inspectors.
- Side-by-side diff is used in full-width review when the change is non-trivial. The toggle is per-user, per-context, and sticky.
- Semantic diff for DITA and topic JSON is preferred over raw text diff. Element-level changes such as added, removed, modified, and moved are labeled. Attribute changes inside preserved elements appear as sub-rows.

### Layout Variants

- Inline diff uses `diff-viewer-inline`, 600px wide, one side wider than `detail-inspector`, and a single-pane unified diff. Use it for regeneration preview inside the review workspace, small agent proposals, and inspector-level comparisons.
- Full-screen diff uses `diff-viewer-overlay`, a modal-like overlay at 80% viewport width, maximum 1280px, with unified, side-by-side, and semantic mode options. Use it for version compare and large agent proposals.
- Header uses `diff-viewer-header`, 64px. Left side shows the diff title plus base and target version chips in `mono-sm`; right side shows mode toggle, accept all, reject all, and close.
- Body is a scrollable hunk list. Hunks have 8px vertical gaps so accept/reject controls do not visually merge across unrelated changes.
- Footer uses `diff-viewer-footer`, 56px, sticky bottom, with counts such as `X added`, `Y removed`, `Z modified`, plus Accept selected, Apply, and Cancel.

### Hunk Anatomy

- Hunk header uses `diff-hunk-header`, 32px, `surface-subtle`, element path, line range, and accept/reject icon buttons. Icon-only hunk actions still require `aria-label` and visible tooltips.
- Hunk body uses `diff-hunk-body` and code-editor typography.
- Removed lines use `diff-line-removed`: `danger-container`, `on-danger-container`, and 4px danger left border.
- Added lines use `diff-line-added`: `success-container`, `on-success-container`, and 4px success left border.
- Modified lines appear only in side-by-side mode, using `diff-line-modified-left` for the old side and `diff-line-modified-right` for the new side.
- Moved blocks use `diff-block-moved`: surface background, dashed accent outline, and a connecting curve indicator. Do not encode moves as warnings.
- Unchanged context uses `diff-context-line`: `code-surface` with `code` text.
- Inline annotations show agent rationale only when the diff originates from an agent proposal. Keep annotations to two `body-sm` lines before truncation.

### Acceptance Granularity

- Hunk-level accept/reject is required. Users do not have to accept the entire proposal.
- Each accepted hunk produces a discrete artifact-version event so partial acceptance is fully traceable.
- Reject with reason is allowed; the reason becomes part of the audit record.

### Visual Treatment

- Removed lines use `danger-container`, `on-danger-container`, and a `-` gutter prefix.
- Added lines use `success-container`, `on-success-container`, and a `+` gutter prefix.
- Modified lines appear side-by-side only: left side danger, right side success.
- Moved blocks use outline-only treatment with a connecting indicator. Do not use color fill; moves are common in topic restructuring and filled move blocks would saturate the view.
- Selection inside a diff uses `selection-code`.
- A 1-second `motion.duration.slow` highlight band confirms each accepted hunk and then fades.

### Performance

- Diffs over 500 lines render incrementally with the visible region first. The user can interact with the visible portion before the rest renders.
- Diffs over 5000 lines collapse unchanged regions by default with a "Show 247 unchanged lines" affordance per region.

## Versioning And Artifact History UI

Artifact versions are visible because approval, regeneration, override, and export all depend on them.

### Version Timeline

The version timeline is a right-side drawer opened from the editor header. Each version row shows:

- Version identifier such as `v3` and content hash prefix.
- Author or generator: user, agent, automated retry, or system.
- Timestamp: UTC absolute, with locale-relative display on hover.
- Change summary: hunk count or one-line agent summary.
- State at that version: draft, approved, rejected, or exported.
- Links: open as read-only, compare to current, compare to any other version, restore.

### Restore

- Restore creates a new version that copies the chosen version's content. It never rewrites history; the timeline always grows forward.
- Restoring requires the same role as the original edit.
- Restoring a previously approved version requires re-approval before export readiness returns.
- Approved versions are never silently overwritten. Editing an approved topic creates a new draft version for the next reviewer.

### Export Manifest References

The export package manifest references artifact versions by hash, not ordinal. The UI shows both the human ordinal such as `v3` and the hash prefix such as `a1f4...` so the user can confirm a manifest entry matches what they approved.

## Comments And Threaded Discussion

Comments are evidence-bound review records, not casual chat.

### Comment Composition

- Each comment row carries author, role, timestamp, body, anchor, resolution state, and reply count.
- Anchors reference a DITA path or source block ID. Anchored comments visually link to the relevant element with a left-edge marker that follows editor scroll.
- Selecting a comment scrolls the editor to its anchor without expanding unrelated panels.
- Mentions use `@username` and resolve to project members. A mentioned user receives a notification center item.
- Markdown is supported in comments: bold, italic, code, inline DITA paths, and source block ID references that auto-link.
- File or screenshot attachments are out of scope for alpha; reserve a clearly labeled placeholder.

### Comments Panel Layout

The Comments tab lives inside the review workspace evidence panel. It is a collaboration surface, so it gets a layout contract instead of inheriting generic list behavior.

- Filter strip: `comment-filter-strip`, 36px, sticky at the top of the tab, with All, Unresolved, Mentions, Mine, and Request changes filters.
- Thread list: vertical scroll between the filter strip and composer. Threads stack with 12px gaps.
- Thread container: `comment-thread`, surface background, 1px outline border, `rounded.md`, 12px padding, and stable spacing between header, body, footer, and replies.
- Anchor indicator: `comment-anchor-indicator`, 2px left edge. Use info for source block anchors, secondary for DITA element anchors, and neutral/accent treatment for document-level anchors. Do not use severity colors unless the comment is explicitly marked Request changes.
- Header: avatar, author, timestamp, and role chip in one row. The role chip uses existing badge/chip semantics and must not overpower the author name.
- Body: `body-md`; mentions render as `comment-anchor-chip` when resolved to a user. Markdown support is limited to bold, italic, inline code, linked DITA paths, and linked source block IDs.
- Footer: reply count, resolve, edit for own comments only, and overflow. Destructive or permission-sensitive actions stay in overflow.
- Replies: `comment-reply`, nested 24px to the right with 24px avatars and no extra bordered container. Indent, not cards, communicates nesting.
- Resolved threads: collapse into `comment-resolved-row`, 32px tall, showing `<n> resolved` with an expand affordance.

### Comment Composer

- Collapsed composer uses `comment-composer-collapsed`, 48px, with placeholder copy "Add a comment...".
- Expanded composer starts at 80px and can grow to 200px. It includes mention picker, attachment placeholder button, Cancel, and Comment.
- The attachment button is a reserved placeholder for alpha. It must not imply uploads are supported until attachment handling is implemented.
- When the composer is triggered from a selected DITA element or source block, the anchor is auto-set and displayed as `comment-anchor-chip` above the text area. Users can remove or change the anchor before posting.
- Composer submit is disabled until body text exists and the anchor rules for the current action are satisfied. Disabled state must explain the missing requirement on focus.

### Resolution

- Comments are resolved, not deleted. A resolved comment collapses but stays auditable. The resolver is recorded.
- Reopening a resolved comment is allowed by the original author or any reviewer until the topic is approved.
- Approved topics freeze comments. New discussion is filed as a new comment on the new draft after rejection or further-revision actions.

### Comment-Driven Workflow

- A comment with `Request changes` is a soft block. The reviewer marking the comment can prevent approval until they or an authorized override resolves it.
- Comments are filterable by my comments, mentions, unresolved, mine to resolve, and mentions of me.
- Comment filters integrate with validation and issue triage so unresolved comments appear alongside blocking validation issues.

## Permission Failure And Restricted-Access Patterns

Permission failures are predictable, safe, and explicit.

| Case | Pattern |
| --- | --- |
| Action you cannot perform | Button is disabled. Tooltip on focus reveals the role required and where to request it. |
| Record you cannot read | Placeholder row with name redacted, owner shown if policy allows, and Request access link. |
| Sub-panel you cannot access | Panel renders a quiet Restricted empty state explaining the permission and contact. |
| Action that requires step-up auth | Confirmation modal with reauth prompt; never silently fails. |

Rules:

- Permission failures never log out the user.
- Permission failures never produce a generic "403 Forbidden" in product UI.
- The UI never reveals a record's hash, ID, topic title, or quality signals to a user who cannot read it.
- The role catalog is centralized. The same role names appear in tooltips, settings, audit log, and notifications.
- Request-access flows route to the BU admin or project owner. The user sees pending request status in the notification center and can revoke a request.

## Audit Log UI

Audit is a visible surface at BU and project scope.

### Layout

Audit log uses a dense table with these columns:

- Timestamp: UTC absolute, with locale-relative display on hover.
- Actor: user, system, or agent. Agent rows are visually distinct.
- Action verb: lowercase and machine-stable, such as `topic.approved`, `export.built`, `member.role_changed`, or `agent.proposal.applied`.
- Target: resource path, clickable when the user has read permission.
- Outcome: success, failure, or partial. Failure rows expose the reason.
- Audit ID: copy affordance for support correspondence.

### Filters

- Time range with preset windows and custom range.
- Actor by user, role, agent, or system.
- Action category: auth, content, validation, export, agent, member, policy.
- Outcome.
- Target type and ID.

### Retention And Integrity

- The audit log is read-only in the UI.
- Export-to-CSV is allowed for authorized roles and is itself an audit event.
- Retention policy is shown at the top of the audit panel.
- An integrity warning banner appears if the backend reports any audit event that could not be persisted in the canonical store.

## Confidence Visualization Scale

Confidence is core to DITAgen and must read consistently across surfaces.

### Thresholds

| Confidence range | Token treatment | Label | Allowed actions |
| --- | --- | --- | --- |
| `>= 0.90` | `quality-badge-pass` | High | Auto-included in default review queue |
| `0.75 - 0.89` | `quality-badge-pass` | Acceptable | Auto-included; visible secondary badge |
| `0.50 - 0.74` | `quality-badge-warn` | Review needed | Always routed through review; cannot auto-export |
| `0.25 - 0.49` | `quality-badge-warn` plus warning icon | Low confidence | Blocks topic plan auto-approval; reviewer must act |
| `< 0.25` | `issue-row-warning` or `issue-row-blocking` based on stage | Unreliable | Warning at extraction; blocking at export |

### Visualization

- Numeric value is always shown alongside the badge or confidence bar. It is never replaced by stars, hearts, or game-like imagery.
- Confidence badge, bar fill, bar background, and numeric color follow `confidence-visualization-map` in [`design-system.md`](design-system.md#confidence-visualization-combinations).
- Confidence sources are stacked when multiple signals contribute, such as OCR, boundary, table, and language.
- The lowest individual signal drives the badge color; the rest are visible in the source-quality drawer.
- Confidence trends over re-extractions are graphed in the document detail inspector. A drop from 0.90 to 0.60 across re-runs is a warning even if both values were otherwise acceptable.

### Confidence Vs Validation

Confidence and validation are different signals. Confidence is about extraction quality; validation is about generated artifact correctness. A topic can be high confidence and still have blocking validation. Both badges may appear on the same row and never substitute for each other.

## Onboarding And In-Product Help

The product is dense. New users need on-ramps that do not bury the operational surface.

### First Run

- After first sign-in, the user lands on the BU Dashboard or the single BU's Project Hub.
- A dismissible banner offers a 60-second tour of the main panels of that screen. The tour is opt-in; closing it never blocks work.
- A welcome notification in the notification center links to short documentation pages: Source evidence and confidence, Topic plan, Validation, Export, Agent assistance, and Roles and permissions.
- No interstitial modals. No coachmarks that block the user's first click.

### Contextual Help

- Each major panel has an inline `?` icon in its header. It opens a short, panel-specific help popover.
- Help popover content is curated, not auto-generated, and always links to the relevant longer-form doc.
- The help icon never opens a chat widget. Help is documentation; agent assistance is task-bound and lives in the agent panel.
- Help content is versioned alongside the product. Users on an older deployment do not see help that references a feature they do not have.

### Empty State As Learning Surface

- Empty topic plan, validation panel, and export center states explain what the panel will show and which upstream stage produces its data.
- Empty states remain quiet and actionable, and they name the upstream pipeline stage.

## Concurrency, Conflict, And Multi-Tab Behavior

Multiple reviewers or one reviewer with multiple tabs are expected scenarios.

### Active-Editor Presence

- The editor header shows avatars of all users currently viewing the topic, with a small green dot for active editors.
- Presence refreshes on at least a 10-second cadence.
- Comments and selection cursors from other active editors appear in real time when supported. Otherwise, the panel announces "Updated by <user> 12s ago" with a refresh affordance.

### Conflict Resolution

- Saves are last-writer-wins only when there is no concurrent draft.
- If another draft was saved between this user's load and save, the save is held and a conflict modal opens.
- The conflict modal shows a three-way diff: base version, other user's draft, and this user's draft.
- The user can accept the other version, accept their own, or merge hunk-by-hunk using the diff viewer.
- Conflict resolution becomes a new artifact version with both contributors recorded.

### Multi-Tab Same User

- Same-user editing in two tabs is detected through a session identifier.
- The second tab shows a non-blocking banner: "You have this topic open in another tab; saving here will overwrite that draft."
- Both tabs share the same active draft.

### Optimistic Actions

- Quick actions such as approve, reject, retry stage, and dismiss notification are optimistic and reconcile silently.
- On failure, the row reverts and a toast announces the failure with a retry affordance.

## Session, Connection, And Offline Resilience

### Session Expiry

- A non-blocking warning appears 60 seconds before expiry with a reauthenticate affordance that preserves current screen and unsaved state.
- Sign-out due to expiry never destroys local unsaved drafts.
- After re-authentication, the draft is recovered if the backend accepts the same version.

### Network Loss

- A connection-status indicator in the app bar transitions to offline within 5 seconds of detecting loss.
- The UI does not pretend to save while offline.
- Reads continue from the last cached state with a banner: "Last updated 2 minutes ago. Some data may be stale."
- Writes are blocked while offline except editor drafts, which queue locally.
- On reconnection, queued drafts are submitted with a confirmation toast or surfaced as a conflict if the artifact moved during the offline period.

### Slow Network

- Operations exceeding a 4-second budget show a stage indicator with a "still working" announcement at 4s and again at 12s.
- After 12s, a cancel affordance becomes available when cancellation is safe.
- Streamed agent responses surface a stop control immediately and do not require a timeout to become cancellable.

## Search UX

Global search, command palette, and scoped search are related but distinct surfaces.

### Surfaces

- **Global search field in the app bar:** Searches across the entire scope the user can read: BUs, projects, documents, topics, source blocks, validation issues, exports, and audit events. It returns a results page on submit and offers inline suggestions while typing.
- **Command palette (`Cmd/Ctrl + K`):** Includes navigation results, actions, filters, and recent items. It is optimized for keyboard fast-paths.
- **Scoped panel search:** A search field local to a panel, such as validation issues in the current document or comments on the current topic. It filters within the panel and never escapes scope.

### Result Page Anatomy

- Search header uses `search-header`, 80px. It contains a search input at 60% width, a scope filter for BU, Project, or All, result count, and sort dropdown.
- Content uses a two-column flex layout with 16px gap: `search-facet-rail` at 240px and a flexible results column.
- Faceted filters appear down the left side: type, status, owner, time, severity, and confidence. Each facet is a collapsible group with a checkbox list.
- Result rows use `search-result-row`, minimum 96px, so title, breadcrumb, snippet, and metadata do not compete for space.
- The left side of a result row uses `search-result-type-icon`, with a 24px icon centered in a 44px icon-button target.
- The body shows title in `title-md`, breadcrumb in `body-sm neutral-700`, snippet in `body-sm`, and a metadata row with status chip, timestamp, and owner avatar.
- Matched terms in titles and snippets use `search-match-highlight` with `primary-100` highlight. Do not use warning yellow for search matches because it conflicts with validation severity.
- The right cluster shows confidence badge where applicable plus an open icon.
- Empty state uses `search-empty-state` with copy "No matches for '<query>'" and suggestions to broaden scope, remove filters, or check spelling. Keep it quiet; do not use marketing illustration.
- Result rows are dense and include breadcrumb, matched snippet, status badge, and date.
- Breadcrumbs use the pattern `BU > Project > Document > Topic`.
- Source block matches show matched text with surrounding context and deep-link to the document detail inspector with the block highlighted.
- Validation issue matches deep-link to the validation panel pre-filtered to that issue.

### Privacy

- Search results never reveal records the user lacks read permission for.
- A restricted match shows redacted name and an access-request affordance only if policy allows; otherwise it is omitted entirely.
- Search query strings are not logged with PII. They are logged for audit only with the searching user's ID and a hash of the query.

### Performance

- Inline suggestions return within 150ms or are not rendered.
- A late suggestion that arrives after the user has typed more is discarded silently.
- Full results return within 2 seconds; a slower query shows the result page in skeleton state with a stage indicator.

## Design Governance And Rollout Priority

The design system is operational infrastructure. Changes that affect accessibility, tokens, permission semantics, auditability, or status truth sources are higher priority than visual polish.

Priority order for implementation and review:

1. Token corrections and missing primitives: focus rings, source-attention variants, disabled states, placeholder, selection, scrollbars, and layout leakage fixes.
2. Accessibility: contrast, focus management, keyboard reachability, live-region semantics, touch targets, and reduced motion.
3. Loading, empty, error, restricted, stale, degraded, and offline taxonomy.
4. Permission failure and restricted-access patterns.
5. Notifications, toasts, command palette, and keyboard shortcuts.
6. Confidence visualization scale.
7. Diff viewer and artifact versioning UI.
8. Comments anatomy and audit log UI.
9. Concurrency, multi-tab behavior, session resilience, offline behavior, and search.
10. Motion, iconography, tooltip, popover, toast, and numeric badge polish.
11. Dark mode after semantic token stabilization.
12. Internationalization and RTL before pre-localization implementation begins.
13. Onboarding and in-product help after workspace screens stabilize.

## Open Product Decisions

These are product-owner decisions, not design-system defects. The UI contract can support each path, but the policy must be set before implementation ships.

- **Tenant theming:** Decide whether tenants can override `primary` and `tertiary`, or whether the navy/blue/red identity is fixed at the product level. If tenant theming is allowed, the contrast and semantic color audit runs per tenant.
- **Agent autonomy ceiling:** Define the maximum autonomous tool-call count before human approval is required. Proposal cards already expose tool budget, call count, cost ceiling, and approval state.
- **Audit retention:** Set retention policy values by tenant or regulatory class. The audit UI shows the policy, but empty or ambiguous retention values must not ship.
- **Comments across versions:** Confirm whether comments carry forward, fork, or stay attached to the rejected draft when a topic is rejected and a new draft is created. The current visual contract freezes comments on approval and starts new discussion on a new draft after rejection.
- **Presence transport:** Confirm the real-time presence mechanism and freshness budget. If the backend can only support 30-second polling, the presence indicator must not imply live editing; it should read as recently updated instead.
