---
version: alpha
name: DITAgen Evidence Console
description: Enterprise design system for the DITAgen web application in apps/web.
colors:
  primary: "#151D4A"
  on-primary: "#FFFFFF"
  primary-container: "#EEF1FF"
  on-primary-container: "#17214D"
  secondary: "#4E65C8"
  secondary-strong: "#344AA3"
  on-secondary: "#FFFFFF"
  secondary-container: "#EEF2FF"
  on-secondary-container: "#263B91"
  tertiary: "#C7392F"
  tertiary-strong: "#9F2B24"
  on-tertiary: "#FFFFFF"
  tertiary-container: "#FDEBE9"
  on-tertiary-container: "#7F211B"
  accent: "#141B3F"
  accent-container: "#F2F4F8"
  on-accent-container: "#1D284F"
  background: "#F4F2EE"
  background-alt: "#EEF2F6"
  on-background: "#242424"
  surface: "#FFFFFF"
  surface-subtle: "#FAF9F6"
  surface-muted: "#F0EFEB"
  surface-inverse: "#151D4A"
  inverse-on-surface: "#FFFFFF"
  surface-selected: "#F3F4F8"
  outline: "#DDDAD3"
  outline-strong: "#9C978F"
  focus: "#4E65C8"
  success: "#4F8F43"
  on-success: "#FFFFFF"
  success-container: "#EAF6E7"
  on-success-container: "#285A22"
  warning: "#9B6400"
  on-warning: "#FFFFFF"
  warning-container: "#FFF5D9"
  on-warning-container: "#6F4300"
  danger: "#C7392F"
  on-danger: "#FFFFFF"
  danger-container: "#FDEBE9"
  on-danger-container: "#7F211B"
  info: "#4E65C8"
  on-info: "#FFFFFF"
  info-container: "#EEF2FF"
  on-info-container: "#263B91"
  code: "#151D4A"
  code-surface: "#F7F7F4"
  neutral-50: "#FAF9F6"
  neutral-100: "#F4F2EE"
  neutral-200: "#EEF2F6"
  neutral-300: "#DDDAD3"
  neutral-500: "#9C978F"
  neutral-700: "#66615D"
  neutral-900: "#242424"
  neutral-950: "#151515"
  primary-50: "#F5F7FF"
  primary-100: "#EEF1FF"
  primary-300: "#AEBBF8"
  primary-500: "#4E65C8"
  primary-700: "#344AA3"
  primary-900: "#151D4A"
  primary-950: "#0D1232"
  semantic-success-50: "#F3FAF1"
  semantic-success-100: "#EAF6E7"
  semantic-success-500: "#4F8F43"
  semantic-success-700: "#36702E"
  semantic-success-900: "#285A22"
  semantic-warning-50: "#FFF9E8"
  semantic-warning-100: "#FFF5D9"
  semantic-warning-500: "#C78400"
  semantic-warning-700: "#9B6400"
  semantic-warning-900: "#6F4300"
  semantic-danger-50: "#FEF3F1"
  semantic-danger-100: "#FDEBE9"
  semantic-danger-500: "#C7392F"
  semantic-danger-700: "#9F2B24"
  semantic-danger-900: "#7F211B"
dark:
  background: "#0E1224"
  background-alt: "#13182E"
  surface: "#181D36"
  surface-subtle: "#1B2140"
  surface-muted: "#1F2549"
  surface-inverse: "#E8EAF2"
  inverse-on-surface: "#13182E"
  surface-selected: "#222A55"
  on-background: "#E5E7EE"
  outline: "#2A3168"
  outline-strong: "#3B4486"
  primary: "#AEBBF8"
  on-primary: "#0E1224"
  primary-container: "#1F2858"
  on-primary-container: "#D4DBFA"
  secondary: "#7E92E2"
  secondary-strong: "#A5B5EE"
  on-secondary: "#0E1224"
  tertiary: "#E5807A"
  on-tertiary: "#0E1224"
  success: "#7FBF73"
  on-success: "#0E1224"
  success-container: "#1F3A1A"
  on-success-container: "#BFE5B8"
  warning: "#E2B055"
  on-warning: "#0E1224"
  warning-container: "#3D2F12"
  on-warning-container: "#FFE0A3"
  danger: "#E5807A"
  on-danger: "#0E1224"
  danger-container: "#3D1B17"
  on-danger-container: "#FFC8C3"
  info: "#A5B5EE"
  on-info: "#0E1224"
  info-container: "#1F2858"
  on-info-container: "#D4DBFA"
  focus: "#A5B5EE"
  code: "#E5E7EE"
  code-surface: "#0F1424"
approved-color-pairings:
  surface-default:
    background: "{colors.surface}"
    foreground: "{colors.on-background}"
    useCase: "Default body text, inputs, panels"
  surface-secondary-metadata:
    background: "{colors.surface}"
    foreground: "{colors.neutral-700}"
    useCase: "Secondary metadata, helper text"
  surface-link:
    background: "{colors.surface}"
    foreground: "{colors.secondary}"
    useCase: "Links, active interaction labels"
  surface-critical-label:
    background: "{colors.surface}"
    foreground: "{colors.tertiary}"
    minTextSize: ">=14px"
    useCase: "Critical announcements, error labels"
  surface-subtle-body:
    background: "{colors.surface-subtle}"
    foreground: "{colors.on-background}"
    useCase: "Topic plan cards, code surface body"
  surface-muted-body:
    background: "{colors.surface-muted}"
    foreground: "{colors.on-background}"
    useCase: "Disabled fields, muted rows"
  surface-selected-active:
    background: "{colors.surface-selected}"
    foreground: "{colors.on-secondary-container}"
    useCase: "Active tab labels, selected list rows"
  surface-inverse-body:
    background: "{colors.surface-inverse}"
    foreground: "{colors.inverse-on-surface}"
    useCase: "Sidebar, dark surfaces"
  primary-body:
    background: "{colors.primary}"
    foreground: "{colors.on-primary}"
    useCase: "Top app bar, sidebar-active, dark CTAs"
  primary-container-body:
    background: "{colors.primary-container}"
    foreground: "{colors.on-primary-container}"
    useCase: "Sidebar-item label, info chips"
  secondary-solid:
    background: "{colors.secondary}"
    foreground: "{colors.on-secondary}"
    useCase: "Primary action button"
  secondary-container-body:
    background: "{colors.secondary-container}"
    foreground: "{colors.on-secondary-container}"
    useCase: "Active tab background, secondary chips"
  tertiary-solid:
    background: "{colors.tertiary}"
    foreground: "{colors.on-tertiary}"
    useCase: "Destructive button, numeric badge"
  tertiary-container-body:
    background: "{colors.tertiary-container}"
    foreground: "{colors.on-tertiary-container}"
    useCase: "Brand callouts, announcement banners"
  success-container-body:
    background: "{colors.success-container}"
    foreground: "{colors.on-success-container}"
    useCase: "Pass badges, success status rows"
  warning-container-body:
    background: "{colors.warning-container}"
    foreground: "{colors.on-warning-container}"
    useCase: "Warning badges, warning status rows"
  danger-container-body:
    background: "{colors.danger-container}"
    foreground: "{colors.on-danger-container}"
    useCase: "Blocking issue rows, danger status messages"
  info-container-body:
    background: "{colors.info-container}"
    foreground: "{colors.on-info-container}"
    useCase: "Active pipeline step, info banners"
  accent-container-body:
    background: "{colors.accent-container}"
    foreground: "{colors.on-accent-container}"
    useCase: "Editorial callouts"
  code-surface-body:
    background: "{colors.code-surface}"
    foreground: "{colors.code}"
    useCase: "XML editor text"
severity-stack:
  info:
    containerFill: "{colors.info-container}"
    containerText: "{colors.on-info-container}"
    solidFill: "{colors.info}"
    solidText: "{colors.on-info}"
    border: "{colors.info}"
    icon: info
  success:
    containerFill: "{colors.success-container}"
    containerText: "{colors.on-success-container}"
    solidFill: "{colors.success}"
    solidText: "{colors.on-success}"
    border: "{colors.success}"
    icon: check-circle
  warning:
    containerFill: "{colors.warning-container}"
    containerText: "{colors.on-warning-container}"
    solidFill: "{colors.warning}"
    solidText: "{colors.on-warning}"
    border: "{colors.warning}"
    icon: alert-triangle
  danger:
    containerFill: "{colors.danger-container}"
    containerText: "{colors.on-danger-container}"
    solidFill: "{colors.danger}"
    solidText: "{colors.on-danger}"
    border: "{colors.danger}"
    icon: x-octagon
  neutral:
    containerFill: "{colors.surface-muted}"
    containerText: "{colors.on-background}"
    solidFill: "{colors.neutral-700}"
    solidText: "{colors.surface}"
    border: "{colors.outline}"
    icon: info
pipeline-state-color-map:
  "Queued":
    token: pipeline-step-neutral
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    border: "1px solid {colors.outline}"
  "Uploading":
    token: pipeline-step-active
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  "Upload Complete":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Extraction In Progress":
    token: pipeline-step-active
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  "Extraction Complete":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Markdown Normalized":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Topic Plan Ready":
    token: pipeline-step-active
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  "DITA Generated":
    token: pipeline-step-active
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  "Validation Passed":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Validation Warnings":
    token: pipeline-step-warning
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    border: "1px solid {colors.warning}"
  "Review Ready":
    token: pipeline-step-active
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  "Approved":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Export Ready":
    token: pipeline-step-success
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  "Failed":
    token: pipeline-step-danger
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    border: "1px solid {colors.danger}"
confidence-visualization-map:
  high:
    range: ">= 0.90"
    badgeToken: quality-badge-pass
    barFill: "{colors.success}"
    barBackground: "{colors.success-container}"
    numericColor: "{colors.on-success-container}"
  acceptable:
    range: "0.75-0.89"
    badgeToken: quality-badge-pass
    barFill: "{colors.success}"
    barOpacity: 0.75
    barBackground: "{colors.success-container}"
    numericColor: "{colors.on-success-container}"
  review-needed:
    range: "0.50-0.74"
    badgeToken: quality-badge-warn
    barFill: "{colors.warning}"
    barBackground: "{colors.warning-container}"
    numericColor: "{colors.on-warning-container}"
  low-confidence:
    range: "0.25-0.49"
    badgeToken: quality-badge-warn
    icon: alert-triangle
    barFill: "{colors.warning}"
    barOpacity: 0.75
    barBackground: "{colors.warning-container}"
    numericColor: "{colors.on-warning-container}"
  unreliable:
    range: "< 0.25"
    badgeToken: "issue-row-warning or issue-row-blocking"
    barFill: "{colors.danger}"
    barBackground: "{colors.danger-container}"
    numericColor: "{colors.on-danger-container}"
diff-color-combinations:
  removed-line:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    borderLeft: "4px solid {colors.danger}"
  added-line:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    borderLeft: "4px solid {colors.success}"
  modified-line-left:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    borderLeft: "4px solid {colors.danger}"
  modified-line-right:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    borderLeft: "4px solid {colors.success}"
  moved-block:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    border: "1px dashed {colors.accent}"
  unchanged-context:
    backgroundColor: "{colors.code-surface}"
    textColor: "{colors.code}"
    border: none
  hunk-header:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.neutral-700}"
    borderBottom: "1px solid {colors.outline}"
  selection-in-diff:
    backgroundColor: "{components.selection-code.backgroundColor}"
    textColor: "{components.selection-code.textColor}"
    border: none
syntax-highlighting:
  element-name:
    lightColor: "{colors.primary-700}"
    darkColor: "{colors.primary-300}"
    fontWeight: 600
  attribute-name:
    lightColor: "{colors.secondary-strong}"
    darkColor: "{dark.secondary}"
  attribute-value:
    lightColor: "{colors.tertiary-strong}"
    darkColor: "{dark.tertiary}"
  comment:
    lightColor: "{colors.neutral-500}"
    darkColor: "{colors.neutral-500}"
    fontStyle: italic
  cdata-delimiter:
    lightColor: "{colors.accent}"
    darkColor: "{colors.primary-100}"
  plain-text-content:
    lightColor: "{colors.code}"
    darkColor: "{dark.code}"
  validation-underline-warning:
    textDecoration: "1.5px wavy {colors.warning}"
    darkTextDecoration: "1.5px wavy {dark.warning}"
  validation-underline-danger:
    textDecoration: "1.5px wavy {colors.danger}"
    darkTextDecoration: "1.5px wavy {dark.danger}"
  search-match-highlight:
    backgroundColor: "{colors.warning-container}"
    darkBackgroundColor: "{dark.warning-container}"
  active-line:
    backgroundColor: "{colors.surface-subtle}"
    darkBackgroundColor: "{dark.surface-muted}"
brand-combination-map:
  navy-frame-blue-interaction:
    use: "Top app bar, sidebar active state, and primary workflow actions"
    allowed: true
  navy-white:
    use: "Top app bar background and sidebar inverse surfaces"
    allowed: true
  blue-white:
    use: "Primary button on light surface"
    allowed: true
  blue-on-navy:
    use: "Active sidebar item indicator; use primary-100 for accessible focus"
    allowed: true
  red-white:
    use: "Numeric notification badge and critical announcement chip"
    allowed: true
  red-on-navy:
    use: "Forbidden; use red on white inside a navy header instead"
    allowed: false
  navy-warm-canvas:
    use: "Auth shell logo and dashboard heading anchors"
    allowed: true
  blue-warm-canvas:
    use: "Filter chip selected state and tab indicators"
    allowed: true
  red-warm-canvas:
    use: "Dangerous action confirmation banners"
    allowed: true
  teal-anywhere:
    use: "Logo only; never in chrome or interactive states"
    allowed: false
theme-parity:
  background:
    light: "#F4F2EE"
    dark: "#0E1224"
    contrastIntent: "Canvas at lowest layer"
  surface:
    light: "#FFFFFF"
    dark: "#181D36"
    contrastIntent: "Default panel"
  surface-subtle:
    light: "#FAF9F6"
    dark: "#1B2140"
    contrastIntent: "Repeated record group fill"
  surface-selected:
    light: "#F3F4F8"
    dark: "#222A55"
    contrastIntent: "Active row, active tab"
  outline:
    light: "#DDDAD3"
    dark: "#2A3168"
    contrastIntent: "Hairline borders"
  outline-strong:
    light: "#9C978F"
    dark: "#3B4486"
    contrastIntent: "Resize handles, scrollbar thumb"
  on-background:
    light: "#242424"
    dark: "#E5E7EE"
    contrastIntent: "Default body text"
  primary:
    light: "#151D4A"
    dark: "#AEBBF8"
    contrastIntent: "Foreground emphasis; inverted role in dark"
  secondary:
    light: "#4E65C8"
    dark: "#7E92E2"
    contrastIntent: "Interaction blue"
  tertiary:
    light: "#C7392F"
    dark: "#E5807A"
    contrastIntent: "Brand red"
  success-container:
    light: "#EAF6E7"
    dark: "#1F3A1A"
    contrastIntent: "Pale to muted dark, paired text desaturated"
  warning-container:
    light: "#FFF5D9"
    dark: "#3D2F12"
    contrastIntent: "Pale to muted dark"
  danger-container:
    light: "#FDEBE9"
    dark: "#3D1B17"
    contrastIntent: "Pale to muted dark"
interactive-state-chains:
  button-primary:
    default:
      backgroundColor: "{colors.secondary}"
      textColor: "{colors.on-secondary}"
      border: none
      shadow: none
    hover:
      backgroundColor: "{colors.secondary-strong}"
      textColor: "{colors.on-secondary}"
      border: none
      shadow: "{shadows.card-hover}"
    active:
      backgroundColor: "{colors.secondary-strong}"
      textColor: "{colors.on-secondary}"
      border: none
      shadow: none
    focus:
      backgroundColor: "{colors.secondary}"
      textColor: "{colors.on-secondary}"
      border: none
      focus: "{components.focus-ring}"
    disabled:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.neutral-500}"
      border: "1px solid {colors.outline}"
      shadow: none
  button-secondary:
    default:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline}"
    hover:
      backgroundColor: "{colors.secondary-container}"
      textColor: "{colors.on-secondary-container}"
      border: "1px solid {colors.secondary}"
    active:
      backgroundColor: "{colors.surface-selected}"
      textColor: "{colors.on-secondary-container}"
      border: "1px solid {colors.secondary}"
    focus:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline}"
      focus: "{components.focus-ring}"
    disabled:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.neutral-500}"
      border: "1px solid {colors.outline}"
  button-danger:
    default:
      backgroundColor: "{colors.tertiary}"
      textColor: "{colors.on-tertiary}"
      border: none
      shadow: none
    hover:
      backgroundColor: "{colors.tertiary-strong}"
      textColor: "{colors.on-tertiary}"
      border: none
      shadow: none
    active:
      backgroundColor: "{colors.tertiary-strong}"
      textColor: "{colors.on-tertiary}"
      border: none
      shadow: none
    focus:
      backgroundColor: "{colors.tertiary}"
      textColor: "{colors.on-tertiary}"
      border: none
      focus: "{components.focus-ring}"
    disabled:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.neutral-700}"
      border: "1px solid {colors.outline-strong}"
      shadow: none
  tab:
    default:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      indicator: none
    hover:
      backgroundColor: "{colors.surface-subtle}"
      textColor: "{colors.on-background}"
      indicator: none
    active:
      backgroundColor: "{colors.surface-selected}"
      textColor: "{colors.on-secondary-container}"
      indicator: "2px solid {colors.secondary}"
    focus:
      backgroundColor: current
      textColor: current
      indicator: current
      focus: "{components.focus-ring}"
    disabled:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.neutral-500}"
      indicator: none
      tooltip: "Required reason tooltip"
  input-field:
    default:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline}"
    hover:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline-strong}"
    focus:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.secondary}"
      focus: "{components.focus-ring}"
    filled:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline}"
    invalid:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.danger}"
    disabled:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.neutral-500}"
      border: "1px solid {colors.outline}"
    readOnly:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.on-background}"
      border: "1px solid {colors.outline}"
  data-row:
    default:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      indicator: none
    hover:
      backgroundColor: "{colors.surface-subtle}"
      textColor: "{colors.on-background}"
      indicator: none
    selected:
      backgroundColor: "{colors.surface-selected}"
      textColor: "{colors.on-secondary-container}"
      indicator: "2px solid {colors.secondary}"
    focus:
      backgroundColor: current
      textColor: current
      focus: "{components.focus-ring-inset}"
    restricted:
      backgroundColor: "{colors.surface-muted}"
      textColor: "{colors.neutral-500}"
      icon: lock
    stale:
      backgroundColor: "{colors.surface}"
      textColor: "{colors.on-background}"
      badge: "{components.status-warning}"
shadows:
  card: "0 2px 8px rgba(36, 36, 36, 0.12), 0 10px 24px rgba(36, 36, 36, 0.08)"
  card-hover: "0 4px 12px rgba(36, 36, 36, 0.14), 0 16px 32px rgba(36, 36, 36, 0.10)"
  auth-card: "0 2px 10px rgba(36, 36, 36, 0.14), 0 18px 44px rgba(36, 36, 36, 0.12)"
  overlay: "0 8px 28px rgba(21, 29, 74, 0.22)"
typography:
  heading-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: 700
    lineHeight: 1.18
    letterSpacing: 0em
  heading-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: 0em
  heading-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: 0em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: 0em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: 600
    lineHeight: 1.4
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.45
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: 0em
  mono-md:
    fontFamily: IBM Plex Mono
    fontSize: 13px
    fontWeight: 450
    lineHeight: 1.5
    letterSpacing: 0em
  mono-sm:
    fontFamily: IBM Plex Mono
    fontSize: 12px
    fontWeight: 450
    lineHeight: 1.45
    letterSpacing: 0em
  "display/xl":
    fontFamily: Inter
    fontSize: 32px
    fontWeight: 700
    lineHeight: 1.18
    letterSpacing: 0em
  "display/lg":
    fontFamily: Inter
    fontSize: 24px
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: 0em
  "body/md":
    fontFamily: Inter
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
  "body/sm":
    fontFamily: Inter
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.45
    letterSpacing: 0em
  "label/sm":
    fontFamily: Inter
    fontSize: 12px
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: 0em
  "code/md":
    fontFamily: IBM Plex Mono
    fontSize: 13px
    fontWeight: 450
    lineHeight: 1.5
    letterSpacing: 0em
rounded:
  none: 0px
  xs: 2px
  sm: 4px
  md: 6px
  lg: 8px
  full: 9999px
spacing:
  none: 0px
  xxs: 2px
  xs: 4px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 20px
  "2xl": 24px
  "3xl": 32px
  "4xl": 40px
  "5xl": 48px
  shell-padding: 24px
  panel-padding: 16px
  panel-gap: 14px
  rail-width: 280px
  row-height: 40px
  toolbar-height: 56px
  editor-min-height: 540px
motion:
  duration:
    instant: 80ms
    fast: 120ms
    normal: 180ms
    slow: 280ms
    deliberate: 420ms
  easing:
    standard: cubic-bezier(0.2, 0, 0, 1)
    decelerate: cubic-bezier(0, 0, 0, 1)
    accelerate: cubic-bezier(0.3, 0, 1, 1)
    emphasized: cubic-bezier(0.2, 0, 0, 1.2)
  presets:
    panel-collapse: "180ms cubic-bezier(0.2, 0, 0, 1)"
    drawer: "280ms cubic-bezier(0, 0, 0, 1)"
    toast-in: "180ms cubic-bezier(0, 0, 0, 1)"
    toast-out: "120ms cubic-bezier(0.3, 0, 1, 1)"
    skeleton-shimmer: "1400ms ease-in-out infinite alternate"
component-motion-contracts:
  button:
    hoverTransition: "{motion.duration.fast} {motion.easing.standard}"
    activeTransition: "{motion.duration.fast} {motion.easing.standard}"
    clickFeedback:
      transform: "scale(0.985)"
      duration: "{motion.duration.instant}"
      reducedMotion: disabled
    forbidden: "No springiness, no ripple effect"
  tab:
    indicatorTransition: "{motion.duration.normal} {motion.easing.standard}"
    contentSwap: "120ms opacity cross-fade"
    contentMotion: "No movement; height fixed during transition"
    rapidSwitching: "Animate latest target only; skip intermediate states"
    reducedMotionIndicator: "Instant position change"
    reducedMotionContent: "Instant content swap"
  drawer:
    enterTransform: "translateX(100%) to translateX(0)"
    enterDuration: "{motion.duration.slow}"
    enterEasing: "{motion.easing.decelerate}"
    exitTransform: "translateX(0) to translateX(100%)"
    exitDuration: "{motion.duration.normal}"
    exitEasing: "{motion.easing.decelerate}"
    backdropOpacity: "0 to 0.32 or 0.48 for full-overlay drawers"
    forbidden: "Drawer never fades; it slides"
    reducedMotion: "Instant drawer appearance plus 80ms backdrop fade"
  modal:
    backdropFadeIn: "120ms"
    enterTransform: "translateY(8px) to translateY(0)"
    enterOpacity: "0 to 1"
    enterDuration: "{motion.duration.normal}"
    enterEasing: "{motion.easing.decelerate}"
    exitDuration: "{motion.duration.fast}"
    forbidden: "Modal never zooms or scales"
    reducedMotion: "Instant modal appearance plus 80ms backdrop fade"
  toast:
    enter: "{motion.presets.toast-in}; slide from 16px below plus fade"
    pushExisting: "{motion.duration.normal} {motion.easing.standard}"
    exit: "{motion.presets.toast-out}; fade plus 8px slide right"
    pauseDismissalOn: "hover or focus"
    stackLimitPill: "Appears with the fourth toast; no independent animation"
    reducedMotion: "80ms fade only; no slide"
  tooltip:
    hoverDelay: 400ms
    focusDelay: 0ms
    enter: "120ms opacity fade, no movement"
    exit: instant
    position: "Locked at trigger time; moves instantly if trigger moves"
    reducedMotion: instant
  popover:
    enter: "{motion.duration.fast} fade plus 4px slide from trigger direction"
    exit: instant
    trigger: click
    reducedMotion: "80ms fade only; no slide"
  badge-state-change:
    severityChange: "{motion.duration.fast} cross-fade of full badge"
    iconAndLabel: "Change together"
    counterChange: "200ms vertical digit slide only on calm screens"
    reducedMotionSeverityChange: "Instant swap"
    reducedMotionCounterChange: "Instant swap"
  dropdown-select:
    enter: "{motion.duration.fast} fade plus 4px slide down"
    exit: instant
  sidebar-item:
    hoverTransition: "{motion.duration.fast} background-color"
    activeIndicatorTransition: "{motion.duration.normal} {motion.easing.standard}"
    reducedMotionActiveIndicator: instant
  resize-handle:
    hoverTransition: "{motion.duration.fast} outline to outline-strong"
    activeDrag: "Live resize without animation"
    releaseSettle: "60ms ease-out"
screen-motion-choreography:
  sign-in:
    initialLoad: "Card fades in from translateY(8px) over motion.duration.slow with motion.easing.decelerate"
    fieldError: "Helper-text container slides down 4px with a 180ms height transition; slides up when cleared"
    primaryAction: "Inline spinner appears inside the sign-in button while text remains visible"
  bu-dashboard-project-hub:
    pageEntrance: "Status strip and rails fade in immediately; bento tiles stagger-fade over 120ms with 32ms cascade"
    cascadeCap: "Cascade caps at 4 tiles; remaining tiles fade in together"
    filterChange: "Removed tiles fade out over 120ms; remaining tiles reflow over motion.duration.normal; new tiles fade in last; total under 320ms"
    bentoResize: "Tile span changes animate over motion.duration.normal with motion.easing.standard; surrounding tiles flow simultaneously"
    refresh: "Refresh icon spins over motion.duration.deliberate; updated badge values cross-fade; stale indicators fade out"
    reducedMotion: "All tiles fade in together over 120ms; bento reflow and sizing changes are instant"
  document-upload:
    dragActive: "Background, border, and scale(1.01) transition together over motion.duration.fast"
    fileAdded: "Queue row fades in from translateX(8px) over motion.duration.normal"
    pipelineAdvance: "Stage badge cross-fades; stepper progress fill grows over 240ms with motion.easing.decelerate"
    indeterminateStage: "Active step only uses a 1400ms slow pulse when no progress signal exists"
    fileRemoval: "Row collapses height to 0 over 200ms, then disappears; surrounding rows shift smoothly"
    reducedMotion: "Drag scale, row slide, fill growth, pulse, and removal collapse are disabled; badges still swap state"
  topic-plan:
    candidateSelection: "Inspector content cross-fades over motion.duration.fast; selected row state applies instantly"
    candidateApproval: "Row flashes success-container for 300ms, then status badge cross-fades"
    statusSortReorder: "Approved row may reorder over motion.duration.normal when sorted by status"
    recompute: "Affected rows keep existing content with a subtle skeleton overlay; overlay fades out over 200ms when data arrives"
  review-workspace:
    evidenceTabSwitch: "Uses tab component motion"
    issueSelection: "Editor scrolls to affected element over 280ms with motion.easing.decelerate"
    issueHighlight: "Target element gets warning-container highlight for 1 second, then fades over 600ms"
    saveDraft: "Save button shows inline spinner; success flashes success-container for 200ms, then returns to default; toast confirms"
    topicApproval: "Approve button transitions to success solid for 300ms, then cross-fades to Approved text with check icon"
    regenerationDiff: "Diff viewer slides in from the right as a 600px drawer over motion.duration.slow"
    reducedMotion: "Issue scroll is instant; highlight shows for 1 second then clears instantly; approval uses an instant icon swap"
  validation-triage:
    filterChange: "Rows leaving fade out over 120ms; remaining rows reflow over motion.duration.normal; new rows fade in last"
    severityGroupCollapse: "Rows shift up; group chevron rotates 90deg over motion.duration.fast"
    bulkAction: "Selected rows fade to surface-selected for 200ms; on success rows update or fade out based on action"
  export-center:
    buildClick: "Build button shows inline 2px bottom progress bar while build runs"
    buildSuccess: "Button briefly shows a check, then returns to default; new export fades in at top of history"
    failedExport: "History row status-danger left edge fades in over motion.duration.fast; toast announces failure"
  audit-log:
    newEventsAtTop: "When user is at top, rows shift down over motion.duration.normal and new row fades in"
    scrolledAway: "New row appears silently; X new events pill becomes available at top"
  notification-center:
    drawerEntrance: "Uses drawer component motion"
    markRead: "Unread indicator fades out over 120ms; row stays in place"
    markAllRead: "Visible indicators fade out in a 200ms cascade with 32ms stagger capped at 4; remaining indicators fade together"
  command-palette:
    open: "Backdrop fades; container slides 8px down from -8px to final and opacity 0 to 1 over motion.duration.fast"
    resultUpdates: "Results swap instantly while typing; no animated reordering"
    selectionMovement: "Selected row background changes instantly on arrow keys"
  diff-viewer:
    drawerEntrance: "Uses drawer component motion"
    hunkAccept: "Accepted hunk shows success-container highlight for 1 second, then becomes unchanged context over 300ms"
    hunkReject: "Rejected hunk shows danger-container highlight for 600ms, then collapses height to 0 over motion.duration.normal"
    modeToggle: "Unified and side-by-side modes cross-fade over motion.duration.fast"
    reducedMotion: "Accept highlight shows for 600ms then clears instantly; reject collapse is instant; mode toggle is instant"
  comments:
    newComment: "Comment fades in at thread bottom with 4px slide up; composer collapses"
    resolution: "Thread collapses to 32px row over motion.duration.normal with Resolved by user summary"
    anchorScroll: "Editor scrolls to anchor over motion.duration.normal with motion.easing.decelerate; target gets 1-second highlight"
loading-animation-contracts:
  skeleton-shimmer:
    baseBackground: "{colors.surface-subtle}"
    shimmer: "Horizontal gradient pass at 60% to 80% lightness"
    backgroundPosition: "-100% to 200% horizontal"
    angle: "0deg"
    duration: "{motion.presets.skeleton-shimmer}"
    reducedMotion: "Static low-luminance state"
    forbidden: "No diagonal shimmer"
  spinner:
    defaultSize: 16px
    defaultStrokeWidth: 2px
    visibleArc: "25%"
    rotation: "360deg over 800ms linear infinite"
    color: currentColor
    usageLimit: "Indeterminate operations under 4s only"
    preserveButtonLabel: true
    reducedMotion: "Rotation disabled; replace with a non-rotating 12-frame static dot cycle over 800ms"
    sizes:
      xs:
        size: 12px
        strokeWidth: 1.5px
      sm:
        size: 16px
        strokeWidth: 2px
      md:
        size: 20px
        strokeWidth: 2.5px
      lg:
        size: 24px
        strokeWidth: 3px
  indeterminate-progress-bar:
    height: 2px
    placement: "Bottom of active container"
    ribbonWidth: "30%"
    transform: "translateX(-30%) to translateX(130%)"
    duration: 1200ms
    easing: "{motion.easing.standard}"
    iteration: infinite
    color: "{colors.secondary}"
    track: "{colors.surface}"
    reducedMotion: "Ribbon disabled; replace with a single static loading label"
  stage-stepper:
    activeDotSize: 4px
    activeDotPulse: "scale(1) to scale(1.4) to scale(1)"
    activeDotDuration: 1200ms
    completedAnimation: none
    failedAnimation: none
    failedIcon: "{severity-stack.danger.icon}"
    reducedMotion: "Pulse disabled; dot remains static"
status-transition-contracts:
  same-direction:
    example: "Queued to Uploading to Upload Complete to Extraction Complete"
    badgeTransition: "{motion.duration.fast} cross-fade"
    stepperTransition: "Next stage fill uses 240ms color transition"
    reducedMotion: "Badge swaps instantly; stepper fill changes instantly"
  failure:
    example: "Any state to Failed"
    badgeTransition: "{motion.duration.fast} cross-fade to danger"
    rowEdgeTransition: "4px danger stripe over motion.duration.fast"
    forbidden: "No shake; failure color change is the announcement"
    reducedMotion: "Badge and row edge swap instantly"
  recovery:
    example: "Failed to Queued via retry"
    badgeTransition: "Cross-fade"
    rowEdgeTransition: "4px danger edge fades to neutral"
    reducedMotion: "Badge and row edge swap instantly"
  stale-to-fresh:
    badgeTransition: "Stale badge fades out over 200ms"
    valueTransition: "Fresh values cross-fade in at the same time"
    reducedMotion: "Stale badge clears instantly; values swap instantly"
reduced-motion-overrides:
  click-scale-feedback: "Disabled; color and contrast feedback remain"
  tab-indicator-slide: "Instant position change"
  tab-content-cross-fade: "Instant swap"
  drawer-slide-in: "Instant appearance plus 80ms backdrop fade"
  modal-slide-up: "Instant appearance plus 80ms backdrop fade"
  toast-slide-fade: "80ms fade only; no slide"
  tooltip-fade: instant
  popover-fade-slide: "80ms fade only; no slide"
  badge-cross-fade: "Instant swap"
  counter-rolling-digit: "Instant swap"
  sidebar-item-indicator-slide: instant
  bento-grid-stagger-entrance: "All tiles fade in together over 120ms"
  bento-grid-reflow: "Instant rearrangement"
  pipeline-stepper-fill: "Instant fill change; no growth animation"
  skeleton-shimmer: "Disabled; skeleton remains static"
  spinner-rotation: "Disabled; replaced with a non-rotating 12-frame static dot cycle over 800ms"
  indeterminate-progress-ribbon: "Disabled; replaced with a single static loading label"
  stage-active-dot-pulse: "Disabled; static dot"
  issue-scroll-to-element: "Instant scroll; no smooth scrolling"
  highlight-band-fade: "Show for 1s, then clear instantly"
  diff-hunk-accept-highlight: "Show for 600ms, then clear instantly"
  diff-hunk-reject-collapse: "Instant collapse"
  approve-button-success-flash: "Instant icon swap; no flash"
choreography-rules:
  stagger:
    rule: "Cascades over 4 elements look promotional"
    cap: 4
    interval: 32ms
    overflow: "Everything beyond the cap animates together"
  motion-direction: "Motion follows attention: drawers slide from their anchor side, toasts enter from their resting corner, and modals rise into focus"
  layout-before-content: "Layout-altering motion completes before child content motion begins"
  status-before-decoration: "Status changes lead; decorative stripe and icon-background changes follow within 80ms"
  single-primary-cue: "Avoid simultaneous color and movement on the same element; pick one primary cue per state"
  continuous-motion: "Forbidden in operational surfaces except the active pipeline-stage dot, which stops once the stage transitions"
z-index:
  base: 0
  raised: 1
  sticky-header: 10
  rail: 20
  app-bar: 30
  popover: 1000
  dropdown: 1100
  tooltip: 1200
  drawer: 1300
  modal: 1400
  toast: 1500
  command-palette: 1600
opacity:
  disabled: 0.45
  ghost: 0.6
  scrim: 0.48
  drawer-scrim: 0.32
  hover-overlay: 0.06
icon:
  size:
    xs: 12px
    sm: 16px
    md: 20px
    lg: 24px
    xl: 32px
  stroke-width:
    default: 1.75
    emphasis: 2
  color: currentColor
components:
  app-shell:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
  sidebar:
    backgroundColor: "{colors.surface-inverse}"
    textColor: "{colors.inverse-on-surface}"
    padding: "{spacing.xl}"
    width: "{spacing.rail-width}"
  sidebar-item:
    backgroundColor: "{colors.surface-inverse}"
    textColor: "{colors.primary-container}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    height: 52px
    padding: "0 12px"
  sidebar-item-active:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 52px
    padding: "0 12px"
  workspace-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-lg}"
    padding: "0 0 18px"
  panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.lg}"
    padding: "{spacing.panel-padding}"
    shadow: "{shadows.card}"
  panel-subtle:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.lg}"
    padding: "{spacing.panel-padding}"
  button-primary:
    backgroundColor: "{colors.secondary}"
    textColor: "{colors.on-secondary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
    border: none
    shadow: none
  button-primary-hover:
    backgroundColor: "{colors.secondary-strong}"
    textColor: "{colors.on-secondary}"
    border: none
    shadow: "{shadows.card-hover}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 12px"
    border: "1px solid {colors.outline}"
  button-secondary-hover:
    backgroundColor: "{colors.secondary-container}"
    textColor: "{colors.on-secondary-container}"
    border: "1px solid {colors.secondary}"
  button-tertiary:
    backgroundColor: "{colors.tertiary}"
    textColor: "{colors.on-tertiary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
  button-tertiary-hover:
    backgroundColor: "{colors.tertiary-strong}"
    textColor: "{colors.on-tertiary}"
  button-danger:
    backgroundColor: "{colors.tertiary}"
    textColor: "{colors.on-tertiary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
    border: none
    shadow: none
  button-danger-hover:
    backgroundColor: "{colors.tertiary-strong}"
    textColor: "{colors.on-tertiary}"
    border: none
    shadow: none
  icon-button:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.md}"
    size: 36px
  input-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    height: 38px
    padding: "0 10px"
    border: "1px solid {colors.outline}"
  disabled:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.neutral-500}"
    borderColor: "{colors.outline}"
    opacity: 1
    cursor: not-allowed
  disabled-strong:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.neutral-700}"
    borderColor: "{colors.outline-strong}"
    opacity: 1
    cursor: not-allowed
  placeholder:
    textColor: "{colors.neutral-500}"
    typography: "{typography.body-md}"
  selection:
    backgroundColor: "{colors.primary-100}"
    textColor: "{colors.on-primary-container}"
  selection-code:
    backgroundColor: "{colors.primary-300}"
    textColor: "{colors.primary-950}"
  scrollbar:
    thumbColor: "{colors.outline-strong}"
    thumbHoverColor: "{colors.neutral-700}"
    trackColor: transparent
    width: 10px
  tab:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 38px
    padding: "0 12px"
  tab-active:
    backgroundColor: "{colors.surface-selected}"
    textColor: "{colors.on-secondary-container}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 38px
    padding: "0 12px"
    indicator: "2px solid {colors.secondary}"
  document-chip:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    height: 38px
    padding: "0 10px"
  document-chip-active:
    backgroundColor: "{colors.surface-selected}"
    textColor: "{colors.on-secondary-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.md}"
    height: 38px
    padding: "0 10px"
  source-block-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
  topic-plan-card:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
  code-editor:
    backgroundColor: "{colors.code-surface}"
    textColor: "{colors.code}"
    typography: "{typography.mono-md}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
    syntax: "{syntax-highlighting}"
  code-editor-active-line:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.code}"
  code-editor-search-match:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
  code-editor-validation-warning:
    textDecoration: "1.5px wavy {colors.warning}"
  code-editor-validation-danger:
    textDecoration: "1.5px wavy {colors.danger}"
  trace-link:
    backgroundColor: "{colors.tertiary-container}"
    textColor: "{colors.on-tertiary-container}"
    typography: "{typography.mono-sm}"
    rounded: "{rounded.sm}"
    padding: "4px 6px"
  quality-badge-pass:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  quality-badge-warn:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  status-info:
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.info}"
  status-success:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.success}"
  status-warning:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.warning}"
  status-danger:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.danger}"
  status-neutral:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.outline}"
  accent-callout:
    backgroundColor: "{colors.accent-container}"
    textColor: "{colors.on-accent-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
  data-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
  data-row-hover:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
  data-row-selected:
    backgroundColor: "{colors.surface-selected}"
    textColor: "{colors.on-secondary-container}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
    borderLeft: "2px solid {colors.secondary}"
  data-row-muted:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
  data-row-restricted:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.neutral-500}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
    icon: lock
  data-row-stale:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: "{spacing.row-height}"
    padding: "0 12px"
    badge: "{components.status-warning}"
  data-row-compact:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 32px
    padding: "0 10px"
  data-row-comfortable:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 52px
    padding: "0 12px"
  primary-container-chip:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  source-attention-marker:
    backgroundColor: "{colors.accent}"
    textColor: "{colors.surface}"
    typography: "{typography.label-md}"
    rounded: "{rounded.sm}"
    size: 16px
  source-attention-marker-warn:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.sm}"
    size: 16px
  source-attention-marker-blocked:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.sm}"
    size: 16px
  success-action:
    backgroundColor: "{colors.success}"
    textColor: "{colors.on-success}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
  warning-action:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.on-warning}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
  info-action:
    backgroundColor: "{colors.info}"
    textColor: "{colors.on-info}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 14px"
  divider-line:
    backgroundColor: "{colors.outline}"
    textColor: "{colors.on-background}"
    height: 1px
  resize-handle:
    backgroundColor: "{colors.outline-strong}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.full}"
    width: 4px
  focus-ring:
    outlineColor: "{colors.focus}"
    outlineWidth: 2px
    outlineOffset: 2px
    outlineStyle: solid
    rounded: inherit
  focus-ring-inset:
    outlineColor: "{colors.focus}"
    outlineWidth: 2px
    outlineOffset: -2px
    outlineStyle: solid
    rounded: inherit
  focus-ring-on-dark:
    outlineColor: "{colors.primary-100}"
    outlineWidth: 2px
    outlineOffset: 2px
    outlineStyle: solid
  empty-state:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.3xl}"
  login-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    width: 440px
    minWidth: 360px
    maxWidth: 480px
    padding: "48px 40px"
    border: "1px solid {colors.outline}"
    shadow: "{shadows.auth-card}"
  auth-shell:
    backgroundColor: "{colors.background-alt}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    minHeight: 100vh
    display: flex
    alignItems: center
    justifyContent: center
    verticalAnchor: 45%
  auth-code-cell:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.mono-md}"
    rounded: "{rounded.md}"
    width: 40px
    height: 40px
    gap: 12px
    border: "1px solid {colors.outline}"
    focus: "{components.focus-ring}"
  top-app-bar:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    height: 64px
    zIndex: "{z-index.app-bar}"
  app-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    shadow: "{shadows.card}"
  business-unit-tile:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-lg}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    shadow: "{shadows.card}"
    minHeight: 168px
  business-unit-tile-priority:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-lg}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    shadow: "{shadows.card-hover}"
    minHeight: 220px
  project-tile:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{shadows.card}"
    minHeight: 136px
  breadcrumb:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 36px
    padding: "0 0"
  upload-dropzone:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.4xl}"
    border: "1px dashed {colors.outline-strong}"
    minHeight: 320px
  upload-dropzone-collapsed:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    border: "1px dashed {colors.outline}"
    height: 120px
    minHeight: 120px
  upload-dropzone-active:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    border: "2px solid {colors.secondary}"
    transform: "scale(1.01)"
    transition: "{motion.duration.fast} {motion.easing.standard}"
  pipeline-step:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    height: 44px
  pipeline-step-neutral:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    border: "1px solid {colors.outline}"
  pipeline-step-active:
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    border: "1px solid {colors.info}"
  pipeline-step-success:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    border: "1px solid {colors.success}"
  pipeline-step-warning:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    border: "1px solid {colors.warning}"
  pipeline-step-danger:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    border: "1px solid {colors.danger}"
  confidence-bar-high:
    fillColor: "{colors.success}"
    trackColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
  confidence-bar-acceptable:
    fillColor: "{colors.success}"
    opacity: 0.75
    trackColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
  confidence-bar-review-needed:
    fillColor: "{colors.warning}"
    trackColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
  confidence-bar-low:
    fillColor: "{colors.warning}"
    opacity: 0.75
    trackColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    icon: alert-triangle
  confidence-bar-unreliable:
    fillColor: "{colors.danger}"
    trackColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
  ingestion-status-badge:
    backgroundColor: "{colors.info-container}"
    textColor: "{colors.on-info-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  ingestion-status-badge-success:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  ingestion-status-badge-warning:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  ingestion-status-badge-danger:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  filter-bar:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "10px 12px"
    height: 52px
    minHeight: 52px
  status-strip:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    height: 72px
    minHeight: 72px
  bu-context-bar:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    typography: "{typography.body-sm}"
    height: 48px
    padding: "0 24px"
  project-context-bar:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    typography: "{typography.body-sm}"
    height: 48px
    padding: "0 24px"
  portfolio-rail:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    width: 220px
  action-rail:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    width: 260px
  pipeline-snapshot-bar:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    rounded: "{rounded.sm}"
    height: 40px
    width: 100%
  detail-inspector:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{shadows.overlay}"
    width: 420px
  document-detail-drawer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{shadows.overlay}"
    width: 480px
    backdropOpacity: "{opacity.drawer-scrim}"
  document-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    minHeight: 52px
  ingestion-queue-header:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 40px
    padding: "0 12px"
  topic-document-header:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-md}"
    height: 56px
    padding: "0 16px"
  topic-candidate-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 72px
    padding: "12px 16px"
  boundary-confidence-strip:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.on-warning}"
    width: 4px
  boundary-confidence-bar:
    backgroundColor: "{colors.success}"
    textColor: "{colors.on-success}"
    rounded: "{rounded.full}"
    width: 60px
    height: 4px
  topic-plan-detail-inspector:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.panel-padding}"
    width: 40%
  bulk-action-bar:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 48px
    padding: "0 12px"
    border: "1px solid {colors.outline}"
  review-workspace-grid:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    gap: "{spacing.panel-gap}"
    minHeight: "{spacing.editor-min-height}"
  review-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 80px
    padding: "0 24px"
  topic-source-rail:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    width: 280px
    minWidth: 240px
    maxWidth: 360px
  review-primary-panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.panel-padding}"
    minWidth: 520px
  editor-toolbar:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 40px
    borderBottom: "1px solid {colors.outline}"
  editor-info-bar:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.body-sm}"
    height: 28px
  evidence-validation-panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    width: 360px
    minWidth: 320px
    maxWidth: 520px
  evidence-validation-panel-expanded:
    width: 480px
  evidence-tab-strip:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 40px
    borderBottom: "1px solid {colors.outline}"
  review-bottom-activity-strip:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 48px
    padding: "0 16px"
  issue-row-blocking:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.danger}"
  issue-row-warning:
    backgroundColor: "{colors.warning-container}"
    textColor: "{colors.on-warning-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "10px 12px"
    borderLeft: "4px solid {colors.warning}"
  triage-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 80px
    padding: "0 24px"
  triage-group-header:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 48px
    padding: "0 12px"
  triage-issue-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    minHeight: 64px
    padding: "12px 16px"
  issue-detail-panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    width: 480px
  export-readiness-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{shadows.card}"
  export-inspector:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    width: 33.3%
  export-history-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    minHeight: "{spacing.row-height}"
    padding: "0 12px"
  audit-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 80px
    padding: "0 24px"
  audit-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 32px
    padding: "0 10px"
  audit-detail-drawer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{shadows.overlay}"
    width: 480px
  settings-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    height: 80px
    padding: "0 24px"
  settings-nav-rail:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    width: 220px
  settings-body:
    backgroundColor: transparent
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    maxWidth: 880px
  settings-section-block:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    border: "1px solid {colors.outline}"
  settings-save-bar:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 64px
    borderTop: "1px solid {colors.outline}"
  dangerous-settings-section:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    border: "1px solid {colors.danger}"
  connector-setup-drawer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
    shadow: "{shadows.overlay}"
    width: 560px
    backdropOpacity: "{opacity.scrim}"
  connector-drawer-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-md}"
    height: 64px
    borderBottom: "1px solid {colors.outline}"
  connector-drawer-footer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 64px
    borderTop: "1px solid {colors.outline}"
  connector-result-panel:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
    border: "1px solid {colors.outline}"
  notification-drawer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    shadow: "{shadows.overlay}"
    width: 420px
    zIndex: "{z-index.drawer}"
  notification-drawer-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-md}"
    height: 56px
    padding: "0 16px"
    borderBottom: "1px solid {colors.outline}"
  notification-tab-strip:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 40px
    borderBottom: "1px solid {colors.outline}"
  notification-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    minHeight: 64px
    padding: "12px 16px"
  notification-category-stripe:
    backgroundColor: "{colors.info}"
    textColor: "{colors.on-info}"
    width: 4px
  notification-avatar:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.full}"
    size: 40px
  notification-unread-indicator:
    backgroundColor: "{colors.secondary}"
    textColor: "{colors.on-secondary}"
    rounded: "{rounded.full}"
    size: 4px
  notification-empty-state:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.body-md}"
    height: 200px
  command-palette:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    shadow: "{shadows.overlay}"
    width: 560px
    maxHeight: 480px
    topAnchor: "20%"
    backdropOpacity: "{opacity.drawer-scrim}"
    zIndex: "{z-index.command-palette}"
  command-palette-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-lg}"
    height: 60px
    padding: "{spacing.panel-padding}"
    borderBottom: "1px solid {colors.outline}"
  command-palette-results:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    maxHeight: 320px
  command-palette-section-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.label-md}"
    height: 24px
    padding: "8px 12px 0"
  command-palette-result-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    height: 48px
    padding: "0 12px"
  command-palette-footer:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.body-sm}"
    height: 44px
    padding: "0 16px"
  diff-viewer-inline:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    shadow: "{shadows.overlay}"
    width: 600px
  diff-viewer-overlay:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    shadow: "{shadows.overlay}"
    width: 80vw
    maxWidth: 1280px
    maxHeight: 80vh
    backdropOpacity: "{opacity.scrim}"
    zIndex: "{z-index.modal}"
  diff-viewer-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.title-md}"
    height: 64px
    borderBottom: "1px solid {colors.outline}"
  diff-hunk-header:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.label-md}"
    height: 32px
    padding: "0 12px"
    borderBottom: "1px solid {colors.outline}"
  diff-hunk-body:
    backgroundColor: "{colors.code-surface}"
    textColor: "{colors.code}"
    typography: "{typography.mono-sm}"
  diff-line-removed:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    borderLeft: "4px solid {colors.danger}"
  diff-line-added:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    borderLeft: "4px solid {colors.success}"
  diff-line-modified-left:
    backgroundColor: "{colors.danger-container}"
    textColor: "{colors.on-danger-container}"
    borderLeft: "4px solid {colors.danger}"
  diff-line-modified-right:
    backgroundColor: "{colors.success-container}"
    textColor: "{colors.on-success-container}"
    borderLeft: "4px solid {colors.success}"
  diff-block-moved:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    border: "1px dashed {colors.accent}"
  diff-context-line:
    backgroundColor: "{colors.code-surface}"
    textColor: "{colors.code}"
  diff-viewer-footer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 56px
    borderTop: "1px solid {colors.outline}"
  agent-proposal-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    border: "1px solid {colors.outline}"
  comment-filter-strip:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.label-md}"
    height: 36px
    borderBottom: "1px solid {colors.outline}"
  comment-thread:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    rounded: "{rounded.md}"
    padding: "{spacing.md}"
    border: "1px solid {colors.outline}"
    gap: "{spacing.md}"
  comment-anchor-indicator:
    backgroundColor: "{colors.info}"
    textColor: "{colors.on-info}"
    width: 2px
  comment-reply:
    backgroundColor: transparent
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    indent: 24px
    avatarSize: 24px
  comment-composer-collapsed:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.body-md}"
    height: 48px
    border: "1px solid {colors.outline}"
    rounded: "{rounded.md}"
  comment-composer-expanded:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    minHeight: 80px
    maxHeight: 200px
    border: "1px solid {colors.focus}"
    rounded: "{rounded.md}"
  comment-anchor-chip:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "2px 8px"
  comment-resolved-row:
    backgroundColor: "{colors.surface-subtle}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.label-md}"
    height: 32px
    rounded: "{rounded.md}"
  search-header:
    backgroundColor: "{colors.background}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-md}"
    height: 80px
    padding: "0 24px"
  search-facet-rail:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    width: 240px
  search-result-row:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    typography: "{typography.body-sm}"
    minHeight: 96px
    padding: "16px 20px"
    borderBottom: "1px solid {colors.outline}"
  search-result-type-icon:
    backgroundColor: "{colors.surface-muted}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.md}"
    size: 44px
  search-match-highlight:
    backgroundColor: "{colors.primary-100}"
    textColor: "{colors.on-primary-container}"
    rounded: "{rounded.xs}"
  search-empty-state:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.neutral-700}"
    typography: "{typography.body-md}"
    rounded: "{rounded.lg}"
    padding: "{spacing.2xl}"
  skeleton-block:
    backgroundColor: "{colors.surface-subtle}"
    textColor: transparent
    animation: "{loading-animation-contracts.skeleton-shimmer.duration}"
  spinner-xs:
    size: 12px
    strokeWidth: 1.5px
    color: currentColor
  spinner-sm:
    size: 16px
    strokeWidth: 2px
    color: currentColor
  spinner-md:
    size: 20px
    strokeWidth: 2.5px
    color: currentColor
  spinner-lg:
    size: 24px
    strokeWidth: 3px
    color: currentColor
  indeterminate-progress-bar:
    backgroundColor: "{colors.surface}"
    fillColor: "{colors.secondary}"
    height: 2px
    ribbonWidth: "30%"
    animation: "1200ms {motion.easing.standard} infinite"
  stage-stepper-active-dot:
    backgroundColor: "{colors.info}"
    size: 4px
    animation: "1200ms scale pulse"
  stage-stepper-failed-icon:
    color: "{colors.danger}"
    icon: "{severity-stack.danger.icon}"
  tooltip:
    backgroundColor: "{colors.neutral-900}"
    textColor: "{colors.surface}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.sm}"
    padding: "6px 8px"
    maxWidth: 280px
    shadow: "{shadows.overlay}"
  popover:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-background}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
    border: "1px solid {colors.outline}"
    shadow: "{shadows.overlay}"
    minWidth: 240px
    maxWidth: 480px
  toast:
    backgroundColor: "{colors.surface-inverse}"
    textColor: "{colors.inverse-on-surface}"
    rounded: "{rounded.lg}"
    padding: "12px 14px"
    shadow: "{shadows.overlay}"
    minWidth: 320px
    maxWidth: 520px
  toast-success:
    backgroundColor: "{colors.success}"
    textColor: "{colors.on-success}"
  toast-warning:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.on-warning}"
  toast-danger:
    backgroundColor: "{colors.danger}"
    textColor: "{colors.on-danger}"
  badge-numeric:
    backgroundColor: "{colors.tertiary}"
    textColor: "{colors.on-tertiary}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    padding: "0 6px"
    minWidth: 18px
    height: 18px
---

# Design System


## Overview

DITAgen is an enterprise conversion workspace for turning messy source documents into reviewable DITA topics, maps, validation reports, and export packages. The interface must feel like a controlled operations console for technical writers, information architects, localization managers, reviewers, and content operations admins.

The design language is Evidence Console with an associate-portal discipline: calm, dense, legible, and explicit about provenance, using the stronger navigation, card, and table patterns shown in the ADP-inspired references. It favors structured panels, readable code surfaces, status-driven workflows, and visible traceability over promotional composition. The product should feel modern and premium, but never decorative. Users are making publishing and compliance decisions; every screen should help them compare evidence, assess confidence, edit safely, and approve intentionally.

## Implementation Bindings (Alpha)

The token contract described later in this document is the canonical
specification. The alpha frontend in `apps/web/src/styles.css` ships a
shorter, working set of CSS custom properties that map onto that contract.
This section is the source of truth for the variable names actually present
in the shipped CSS, so implementers and design reviewers can read code and
spec side-by-side without ambiguity.

If a value is in `styles.css`, it is in this table. If a token in the
canonical spec has no shipped equivalent yet, that is recorded too.

### Surfaces

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--bg` | `#fafbfc` | `background` | App canvas behind content |
| `--surface` | `#ffffff` | `surface` | Default panels, cards, inputs |
| `--surface-muted` | `#f6f7f9` | `surface-subtle` | Quiet rows, hover backgrounds, search input rest |
| `--surface-sunken` | `#f2f4f7` | `surface-muted` | Pipeline bar background, inactive avatar |
| `--surface-tint` | `#fbfcfd` | (alpha-only) | Bottom of card vertical gradient |

### Borders

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--border` | `#e6e8ec` | `outline` | Standard hairline borders |
| `--border-subtle` | `#eef0f3` | (alpha-only) | Inner dividers within a panel |
| `--border-strong` | `#d4d7de` | `outline-strong` | Default status edge, scrollbar thumb |

### Text

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--text` | `#0b1220` | `on-background` | Default body text |
| `--text-secondary` | `#2f384a` | `neutral-700` | Secondary copy |
| `--text-muted` | `#5b6472` | `neutral-700` | Helper, metadata |
| `--text-faint` | `#8a93a4` | `neutral-500` | Faint metadata, timestamps |

### Accent (action / link)

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--accent` | `#2952d4` | `secondary` / `primary-500` | Primary action, link, focus |
| `--accent-hover` | `#1f41b5` | `secondary-strong` | Primary action hover |
| `--accent-pressed` | `#1a348f` | `primary-700` | Primary action active |
| `--accent-soft` | `#eef2ff` | `secondary-container` | Selected pill, soft tint, info bg |
| `--accent-soft-border` | `#d8def5` | (alpha-only) | Border for soft accent surfaces |
| `--accent-on` | `#ffffff` | `on-secondary` | Foreground on accent fills |
| `--accent-light` | `#6f7df0` | `primary-300` | Avatar gradient highlight |

### Semantic — Success

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--success` | `#0f7d52` | `success` | Solid success fills, edges |
| `--success-bg` | `#ecf8f1` | `success-container` | Status badge surface |
| `--success-text` | `#0c4f36` | `on-success-container` | Status badge text |
| `--success-border` | `rgba(15, 125, 82, 0.22)` | (alpha-only) | Status badge / metric border |

### Semantic — Warning

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--warn` | `#a36a00` | `warning` | Warn solid fill |
| `--warn-strong` | `#d99421` | `semantic-warning-500` | Status edges, pipeline segments (more saturated than `--warn`) |
| `--warn-bg` | `#fff7e2` | `warning-container` | Warn surfaces |
| `--warn-text` | `#6a4500` | `on-warning-container` | Warn text |
| `--warn-border` | `rgba(163, 106, 0, 0.24)` | (alpha-only) | Warn surface border |

### Semantic — Danger

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--danger` | `#c4332a` | `danger` / `tertiary` | Solid danger fills, status edge, delete icon |
| `--danger-pressed` | `#a02b22` | `tertiary-strong` | Active state on destructive controls |
| `--danger-bg` | `#fdecea` | `danger-container` | Danger surface, delete-button rest |
| `--danger-text` | `#8a2520` | `on-danger-container` | Danger text |
| `--danger-border` | `rgba(196, 51, 42, 0.26)` | (alpha-only) | Danger surface border |

### Info

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--info-bg` | `#eef2ff` | `info-container` | Review-ready / info badges |
| `--info-text` | `#1f3aa6` | `on-info-container` | Review-ready / info text |

### Top app bar (dark)

| CSS variable | Value | Canonical token | Use |
| --- | --- | --- | --- |
| `--topbar-bg` | `#0f1830` | `primary` (dark) | Top of navy gradient |
| `--topbar-bg-2` | `#131e3d` | `primary-900` | Bottom of navy gradient |
| `--topbar-text` | `#e8ecf6` | `on-primary` | Primary on-dark text |
| `--topbar-muted` | `rgba(232, 236, 246, 0.62)` | (alpha-only) | Context label, tertiary text |
| `--topbar-border` | `rgba(255, 255, 255, 0.08)` | (alpha-only) | Topbar button hairline |

### Radii, shadows, motion

| CSS variable | Value |
| --- | --- |
| `--r-xs` | `4px` |
| `--r-sm` | `6px` |
| `--r-md` | `8px` |
| `--r-lg` | `10px` |
| `--r-xl` | `14px` |
| `--r-pill` | `999px` |
| `--shadow-xs` | `0 1px 1px rgba(15, 23, 42, 0.04)` |
| `--shadow-sm` | `0 1px 2px rgba(15, 23, 42, 0.05), 0 1px 1px rgba(15, 23, 42, 0.03)` |
| `--shadow-md` | `0 6px 18px rgba(15, 23, 42, 0.07), 0 2px 4px rgba(15, 23, 42, 0.03)` |
| `--shadow-lg` | `0 24px 56px rgba(15, 23, 42, 0.14), 0 8px 16px rgba(15, 23, 42, 0.05)` |
| `--focus-ring` | `0 0 0 3px rgba(41, 82, 212, 0.22)` |
| `--ease` | `cubic-bezier(0.2, 0.6, 0.2, 1)` |
| `--t-fast` | `120ms` |
| `--t-base` | `180ms` |

Typography in the alpha CSS is set on `:root`:

```css
font-family: "Inter", ui-sans-serif, system-ui, …;
font-feature-settings: "cv02", "cv03", "cv04", "cv11", "ss01";
```

Code and editor surfaces use `"JetBrains Mono", "SFMono-Regular",
"ui-monospace"`. The `cv*` features are Inter's stylistic alternates that
disambiguate `0/O`, `1/l`, `i/j`, etc. — important for IDs, hashes, and
artifact paths shown in the product.

### Color rules grounded in shipped CSS

These rules came out of the BU dashboard rebuild and apply to every screen
going forward:

1. **Use palette variables, never inline hex.** The four colors that were
   formerly inline (`#d99421`, `#a02b22`, `#fbfcfd`, `#6f7df0`) are now in
   the palette as `--warn-strong`, `--danger-pressed`, `--surface-tint`, and
   `--accent-light`. New surfaces follow the same rule. If a needed color
   does not exist in the palette, add it to the palette before using it
   anywhere.
2. **Tone the surface, not the icon, on container badges.** Pills and
   metric cards swap the surface tint and the border (e.g. swap to
   `--danger-bg` with `--danger-border` and `--danger-text`) — never just
   the text color on the default surface.
3. **Avoid inverted opacity for disabled states.** Disabled controls reduce
   opacity at most to `0.55`; below that, color contrast collapses for
   screen-magnifier users. The icon side-rail's "muted" placeholders use
   `opacity: 0.85` so the glyphs remain legible.
4. **Halos use the matching tone at low alpha.** Status dots use a 3-px
   `box-shadow` halo at the same hue (e.g. `rgba(15, 125, 82, 0.18)` for
   success, `rgba(196, 51, 42, 0.18)` for danger) so the dot has a soft
   bloom without inflating its hit area.
5. **Destructive elevation uses the danger color, not a generic shadow.**
   The delete button hover shadow is
   `0 4px 10px rgba(196, 51, 42, 0.24)` — a controlled red glow — not a
   neutral drop shadow. This keeps the visual weight on the action's
   meaning.

The ADP-inspired references set the visual bar:

- A deep navy top bar gives the app a stable enterprise frame.
- Side navigation uses compact rows, icons, clear selected state, and restrained gray text.
- Cards sit on an off-white or warm neutral canvas with soft, believable elevation.
- Blue is the main interaction color. Red is a brand accent and announcement color, not a general primary action.
- Screens are spacious but operational. They avoid hero marketing, decorative watermarks, fake 3D extrusion, and unnecessary visual noise.

The first screen after login is always the workspace, not a landing page. Use the product name, current project, active document, pipeline state, and next available action as the primary orientation cues.

## User Journey

The primary enterprise journey is:

```text
Sign In -> Business Unit Dashboard -> Project Hub -> Document Upload And Ingestion -> Review Workspace -> Export
```

Business Unit means the organization or team layer above projects. It maps to the tenant and organization model in the architecture, not to a separate chatbot workspace. A BU tile answers "where am I working?", a project tile answers "which conversion program am I running?", and the document upload screen answers "what source evidence is entering the DITA pipeline?"

The first authenticated screen is the Business Unit Dashboard when a user belongs to more than one BU. If the user has only one BU, route directly to that BU's Project Hub but keep a breadcrumb that names the BU. From a project, the default action is document upload or review of the next incomplete pipeline item. Do not route users into an unrestricted chat, a marketing dashboard, or a generic visual conversation builder.

The project journey remains evidence-led:

1. Select a Business Unit.
2. Select or create a Project.
3. Upload source documents.
4. Monitor ingestion and conversion status.
5. Review source evidence, Markdown projection, topic plan, generated DITA, validation, and traceability.
6. Use bounded agent assistance only where it can cite evidence and propose reversible changes.
7. Approve topics and export the DITA package.

## Cross-Screen Operating Model

Every screen follows the same enterprise operating model:

- **Context first:** Always show the current tenant, BU, project, active document, user role, and policy state when they affect available actions.
- **Next action visible:** Each screen exposes one dominant next action based on status and permissions. Secondary actions stay in toolbars, rails, or overflow menus.
- **Evidence before automation:** Generated plans, DITA, validation, exports, and agent proposals must show the source evidence, artifact version, confidence, and reviewer state behind them.
- **Provenance is per-claim, not per-screen:** Any value a user can act on, including a confidence score, validation message, export warning, or agent recommendation, carries an inline path back to its source. A panel cannot summarize evidence as a substitute for linking to it.
- **Triage before detail:** High-level screens prioritize blockers, assigned work, and ready-to-export items. Detail screens expose the full evidence, logs, and raw views only when needed.
- **Permission-aware UI:** Disabled controls must explain the required role or policy. Restricted records show safe metadata only.
- **State continuity:** Filters, selected document/topic, scroll position, and active panel should persist when switching between grid/table, queue/detail, and review/export surfaces.
- **No black boxes:** Long-running work shows stage, last event, elapsed time, retry/cancel state, and last refresh time.
- **Latency is communicated:** Operations under 100ms show no progress indication. Operations from 100ms to 1000ms may show an inline spinner. Operations over 1s show stage and last-event text. Operations over 4s expose a cancel control when cancellation is safe.
- **Telemetry follows policy:** Any analytics or telemetry collected from the workspace UI is documented in the user's settings page and is opt-out where regulation requires it.
- **Readable first, raw second:** Raw JSON, logs, XML payloads, and hashes are available, but readable enterprise records are the default.

## Colors

The palette is now navy-led, blue-forward, and warmed by neutral canvas colors. It should feel closer to an enterprise associate portal than a startup SaaS landing page. Large surfaces must not default to plain white. Use off-white, warm neutral, or blue-gray canvas colors behind white cards so depth and hierarchy are visible.

- **Primary (#151D4A):** Deep navy for top app bars, institutional framing, high-emphasis navigation, and dark surfaces.
- **Secondary (#4E65C8):** Enterprise blue for the single primary action in a local workflow, active tabs, focus emphasis, and important links.
- **Tertiary (#C7392F):** Controlled red for brand accents, announcements, and critical states. Do not use it as the default button color.
- **Accent (#141B3F):** Navy-black for editorial emphasis, quote marks, key dashboard values, and dense headers.
- **Background (#F4F2EE):** Warm neutral app canvas. It avoids a stark white page and gives cards visible separation.
- **Background Alt (#EEF2F6):** Blue-gray auth and utility canvas, used when the page needs a calmer, more premium background than pure white.
- **Surface (#FFFFFF):** Primary panel, card, form, table, and modal interior only. White surfaces should sit on a non-white canvas.
- **Semantic containers:** Use pale containers for status messaging and badges. Avoid filled red, amber, or green backgrounds except for destructive or final-confirmation actions.

The token contract includes both the current app-facing aliases and enterprise scale aliases:

- **Neutral scale:** `neutral-50` through `neutral-950` covers app canvas, alternate canvas, borders, muted text, body text, and near-black technical text.
- **Primary scale:** `primary-50` through `primary-950` covers navy framing, blue action states, focus rings, selected tabs, and high-emphasis links. `primary-900` is the deep enterprise frame; `primary-500` is the main action blue.
- **Semantic success:** `semantic-success-50` through `semantic-success-900` covers completed uploads, completed extraction, validation pass, approved topics, and export-ready states.
- **Semantic warning:** `semantic-warning-50` through `semantic-warning-900` covers OCR uncertainty, validation warnings, missing metadata, and review-required states.
- **Semantic danger:** `semantic-danger-50` through `semantic-danger-900` covers failed uploads, blocked validation, rejected topics, and destructive actions.

Color must carry meaning consistently. A confidence badge, validation issue, and export readiness message should not invent local colors. All normal text and interactive states must meet WCAG AA contrast; error and warning text should remain readable without relying on icon color alone.

### Approved On-X Pairings

Use only the approved foreground/background combinations in `approved-color-pairings` for text. Pairings outside this matrix are forbidden until a contrast audit adds them.

| Background | Approved foreground | Use case |
| --- | --- | --- |
| `surface` | `on-background` | Default body text, inputs, panels |
| `surface` | `neutral-700` | Secondary metadata, helper text |
| `surface` | `secondary` | Links, active interaction labels |
| `surface` | `tertiary` | Critical announcements and error labels at 14px or larger |
| `surface-subtle` | `on-background` | Topic plan cards, code surface body |
| `surface-muted` | `on-background` | Disabled fields, muted rows |
| `surface-selected` | `on-secondary-container` | Active tab labels, selected list rows |
| `surface-inverse` | `inverse-on-surface` | Sidebar and dark surfaces |
| `primary` | `on-primary` | Top app bar, sidebar-active, dark CTAs |
| `primary-container` | `on-primary-container` | Sidebar-item label, info chips |
| `secondary` | `on-secondary` | Primary action button |
| `secondary-container` | `on-secondary-container` | Active tab background, secondary chips |
| `tertiary` | `on-tertiary` | Destructive button, numeric badge |
| `tertiary-container` | `on-tertiary-container` | Brand callouts, announcement banners |
| `success-container` | `on-success-container` | Pass badges, success status rows |
| `warning-container` | `on-warning-container` | Warning badges, warning status rows |
| `danger-container` | `on-danger-container` | Blocking issue rows, danger status messages |
| `info-container` | `on-info-container` | Active pipeline step, info banners |
| `accent-container` | `on-accent-container` | Editorial callouts |
| `code-surface` | `code` | XML editor text |

Forbidden combinations:

- Do not use `neutral-700` on any `*-container` color; contrast collapses.
- Do not use `secondary` text on `surface-selected`; both are blue-ish and the link disappears.
- Do not use `tertiary` text below 14px on `surface`.
- Do not place any `on-*` token on a background that is not its declared partner.
- White text on `warning` is allowed for solid-fill buttons; white text on `warning-container` is forbidden.

### Severity Color Stack

Each severity uses the paired values in `severity-stack`. Implementers must reach for the whole stack rather than mixing individual colors.

| Severity | Container fill | Container text | Solid fill | Solid text | Border | Icon |
| --- | --- | --- | --- | --- | --- | --- |
| Info | `info-container` | `on-info-container` | `info` | `on-info` | `info` | `info` |
| Success | `success-container` | `on-success-container` | `success` | `on-success` | `success` | `check-circle` |
| Warning | `warning-container` | `on-warning-container` | `warning` | `on-warning` | `warning` | `alert-triangle` |
| Danger | `danger-container` | `on-danger-container` | `danger` | `on-danger` | `danger` | `x-octagon` |
| Neutral | `surface-muted` | `on-background` | `neutral-700` | `surface` | `outline` | `info` |

Status rows use container fill, container text, a 4px left edge in the solid fill color, icon, and textual label. Status badges use container fill, container text, and icon with no border. Solid-fill action buttons use solid fill, solid text, and icon with no border. Issue rows use the same container/text/left-edge pattern as status rows but are visually heavier than badges to communicate urgency at scan distance.

### DITA Editor Syntax Highlighting

XML/DITA editing uses `syntax-highlighting` on top of `code-editor`. The palette is intentionally minimal and uses only existing tokens so syntax color does not compete with validation and traceability states.

| Token type | Light theme | Dark theme |
| --- | --- | --- |
| Element name such as `<topic>` | `primary-700`; bold | `primary-300`; bold |
| Attribute name such as `id=` | `secondary-strong` | `secondary` |
| Attribute value string | `tertiary-strong` | `tertiary` |
| Comment | `neutral-500`; italic | `neutral-500`; italic |
| CDATA delimiter | `accent` | `primary-100` |
| Plain text content | `code` | `code` |
| Validation underline warning | 1.5px wavy `warning` | 1.5px wavy `warning` |
| Validation underline danger | 1.5px wavy `danger` | 1.5px wavy `danger` |
| Search match highlight | `warning-container` background | `warning-container` background |
| Active line | `surface-subtle` background | `surface-muted` background |

Plain text content uses dark `code` text in dark mode. Do not use `code-surface` as a foreground color; it is a background token and would make text disappear on the editor canvas. Bold is reserved for element names, italic is reserved for comments, and no other text decoration is used. Validation underlines never replace the issue badge in the gutter; both are shown.

### Brand And Identity Combinations

Brand combinations use `brand-combination-map`. Navy frames the product, blue carries interaction, and red is controlled announcement or destructive color.

| Pattern | Use |
| --- | --- |
| Navy frame + blue interaction | Top app bar, sidebar active state, primary workflow actions |
| Navy + white | Top app bar background, sidebar inverse surfaces |
| Blue + white | Primary button on light surface |
| Blue on navy | Active sidebar item indicator; use `primary-100` for accessible focus |
| Red on white | Numeric notification badge, critical announcement chip |
| Red on navy | Forbidden; use red on white inside a navy header instead |
| Navy on warm canvas | Auth shell logo, dashboard heading anchors |
| Blue + warm canvas | Filter chip selected state, tab indicators |
| Red + warm canvas | Dangerous action confirmation banners |
| Teal anywhere | Logo only; never in chrome, never in interactive states |

### Theme Parity Table

Theme values use `theme-parity`; dark mode is bespoke, not algorithmically inverted. Container colors are deliberately tuned because pale light fills inverted into dark theme become too saturated and fail the intended enterprise tone.

| Semantic | Light value | Dark value | Contrast intent |
| --- | --- | --- | --- |
| `background` | `#F4F2EE` | `#0E1224` | Canvas at lowest layer |
| `surface` | `#FFFFFF` | `#181D36` | Default panel |
| `surface-subtle` | `#FAF9F6` | `#1B2140` | Repeated record group fill |
| `surface-selected` | `#F3F4F8` | `#222A55` | Active row, active tab |
| `outline` | `#DDDAD3` | `#2A3168` | Hairline borders |
| `outline-strong` | `#9C978F` | `#3B4486` | Resize handles, scrollbar thumb |
| `on-background` | `#242424` | `#E5E7EE` | Default body text |
| `primary` | `#151D4A` | `#AEBBF8` | Foreground emphasis; inverted role in dark |
| `secondary` | `#4E65C8` | `#7E92E2` | Interaction blue |
| `tertiary` | `#C7392F` | `#E5807A` | Brand red |
| `success-container` | `#EAF6E7` | `#1F3A1A` | Pale to muted dark, paired text desaturated |
| `warning-container` | `#FFF5D9` | `#3D2F12` | Pale to muted dark |
| `danger-container` | `#FDEBE9` | `#3D1B17` | Pale to muted dark |

### Interactive State Chains

Interactive components must implement the full chain in `interactive-state-chains`: default, hover, active or selected where applicable, focus, and disabled/restricted states. Implementing only a hover state is a defect because keyboard, touch, disabled, and permission-gated states then drift from the design system.

Primary button (`button-primary`) states:

| State | Background | Text | Border | Shadow / focus |
| --- | --- | --- | --- | --- |
| Default | `secondary` | `on-secondary` | none | none |
| Hover | `secondary-strong` | `on-secondary` | none | `shadows.card-hover` |
| Active | `secondary-strong` | `on-secondary` | none | none |
| Focus | `secondary` | `on-secondary` | none | `focus-ring` |
| Disabled | `surface-muted` | `neutral-500` | `outline` | none |

Secondary button (`button-secondary`) states:

| State | Background | Text | Border / focus |
| --- | --- | --- | --- |
| Default | `surface` | `on-background` | `1px outline` |
| Hover | `secondary-container` | `on-secondary-container` | `1px secondary` |
| Active | `surface-selected` | `on-secondary-container` | `1px secondary` |
| Focus | `surface` | `on-background` | `1px outline` plus `focus-ring` |
| Disabled | `surface-muted` | `neutral-500` | `1px outline` |

Danger button (`button-danger`) states:

| State | Background | Text | Border / focus |
| --- | --- | --- | --- |
| Default | `tertiary` | `on-tertiary` | none |
| Hover | `tertiary-strong` | `on-tertiary` | none |
| Active | `tertiary-strong` | `on-tertiary` | none |
| Focus | `tertiary` | `on-tertiary` | `focus-ring` |
| Disabled | `surface-muted` | `neutral-700` | `outline-strong`; use `disabled-strong` |

Tab states:

| State | Background | Text | Indicator |
| --- | --- | --- | --- |
| Default | `surface` | `on-background` | none |
| Hover | `surface-subtle` | `on-background` | none |
| Active | `surface-selected` | `on-secondary-container` | 2px `secondary` bottom or left |
| Focus | current state | current state | current indicator plus `focus-ring` |
| Disabled | `surface` | `neutral-500` | none; show reason tooltip |

Input field states:

| State | Background | Text | Border |
| --- | --- | --- | --- |
| Default | `surface` | `on-background` | `1px outline` |
| Hover | `surface` | `on-background` | `1px outline-strong` |
| Focus | `surface` | `on-background` | `1px secondary` plus `focus-ring` |
| Filled | `surface` | `on-background` | `1px outline` |
| Invalid | `surface` | `on-background` | `1px danger` |
| Disabled | `surface-muted` | `neutral-500` | `1px outline` |
| Read-only | `surface-muted` | `on-background` | `1px outline` |

Data row states:

| State | Background | Text | Indicator |
| --- | --- | --- | --- |
| Default | `surface` | `on-background` | none |
| Hover | `surface-subtle` | `on-background` | none |
| Selected | `surface-selected` | `on-secondary-container` | 2px `secondary` left edge |
| Focus | current state | current state | `focus-ring-inset` |
| Restricted | `surface-muted` | `neutral-500` | lock icon prefix |
| Stale | `surface` | `on-background` | warning chip in row |

### Pipeline State Color Combinations

Pipeline labels map to `pipeline-state-color-map`. `Queued` uses the new `pipeline-step-neutral` token because it is accepted but not active, successful, warning, or failed.

| Pipeline label | Token | Background | Text | Border |
| --- | --- | --- | --- | --- |
| `Queued` | `pipeline-step-neutral` | `surface` | `neutral-700` | `outline` |
| `Uploading` | `pipeline-step-active` | `info-container` | `on-info-container` | `info` |
| `Upload Complete` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Extraction In Progress` | `pipeline-step-active` | `info-container` | `on-info-container` | `info` |
| `Extraction Complete` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Markdown Normalized` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Topic Plan Ready` | `pipeline-step-active` | `info-container` | `on-info-container` | `info` |
| `DITA Generated` | `pipeline-step-active` | `info-container` | `on-info-container` | `info` |
| `Validation Passed` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Validation Warnings` | `pipeline-step-warning` | `warning-container` | `on-warning-container` | `warning` |
| `Review Ready` | `pipeline-step-active` | `info-container` | `on-info-container` | `info` |
| `Approved` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Export Ready` | `pipeline-step-success` | `success-container` | `on-success-container` | `success` |
| `Failed` | `pipeline-step-danger` | `danger-container` | `on-danger-container` | `danger` |

### Confidence Visualization Combinations

Confidence bands use `confidence-visualization-map`. The numeric confidence value is always shown alongside the badge or bar and is never replaced by it.

| Band | Badge token | Bar fill | Bar background | Numeric color |
| --- | --- | --- | --- | --- |
| `>= 0.90` | `quality-badge-pass` | `success` | `success-container` | `on-success-container` |
| `0.75-0.89` | `quality-badge-pass` | `success` at 75% opacity | `success-container` | `on-success-container` |
| `0.50-0.74` | `quality-badge-warn` | `warning` | `warning-container` | `on-warning-container` |
| `0.25-0.49` | `quality-badge-warn` with warning icon | `warning` at 75% opacity | `warning-container` | `on-warning-container` |
| `< 0.25` | `issue-row-warning` or `issue-row-blocking` | `danger` | `danger-container` | `on-danger-container` |

### Diff Viewer Color Combinations

Diff elements use `diff-color-combinations` so regeneration previews, agent proposals, and version compare never drift visually.

| Element | Background | Text | Border / accent |
| --- | --- | --- | --- |
| Removed line | `danger-container` | `on-danger-container` | 4px left `danger` |
| Added line | `success-container` | `on-success-container` | 4px left `success` |
| Modified line left | `danger-container` | `on-danger-container` | 4px left `danger` |
| Modified line right | `success-container` | `on-success-container` | 4px left `success` |
| Moved block | `surface` | `on-background` | 1px dashed `accent` |
| Unchanged context | `code-surface` | `code` | none |
| Hunk header | `surface-subtle` | `neutral-700` | 1px bottom `outline` |
| Selection in diff | `selection-code` background | `selection-code` text | none |

Moved treatment is intentionally outline-only because moves are common in DITA topic restructuring. If moved blocks were color-filled, topic reordering would saturate the screen quickly.

Avoid teal as the dominant UI color. The generated DITAgen logo may retain teal, but app chrome, links, active tabs, and primary actions should use navy and blue. Teal can appear only as a small logo-derived accent or success-adjacent detail.

Dark mode uses the same semantic token names with the `dark` value set in the token contract. Component code must reference semantic names such as `surface`, `on-background`, `outline`, and `primary`; it must not branch on raw hex values. The top app bar shifts lighter in dark mode so it remains distinct from the workspace canvas. Pale light-mode containers become muted dark fills with explicit on-container text colors; never invert by darkening container fills alone.

Color system audit: every six months, run the contrast and semantic audit on the full token set. Validate that every `on-X` token meets AA against its `X` partner at the smallest typography in which that pair appears. Verify that no `container` color is used as a text color anywhere, and verify that no semantic color is invented locally. The audit is itself an artifact and is published with the design system release notes.

## Typography

Use **Inter** for all product UI and **IBM Plex Mono** for source block IDs, XML, DITA paths, artifact IDs, API-like values, and traceability references. The system is text-heavy, so type should be compact but not cramped.

> **Alpha drift (recorded for reconciliation):** the alpha frontend in
> `apps/web/index.html` currently loads **Inter** *and* **JetBrains Mono**
> from Google Fonts. This violates two rules of this section: (a) the
> mono family on the spec is IBM Plex Mono, and (b) the font-hosting
> policy below disallows Google Fonts in production. The alpha drift was
> taken deliberately for two reasons:
>
> - JetBrains Mono renders the disambiguating glyphs we need
>   (zero-with-slash, distinct `1`/`l`/`I`, monospaced underscore) at
>   smaller sizes than Plex Mono and feels closer to the rest of the
>   product's optical weight.
> - Self-hosting Inter Variable + JetBrains Mono with `font-display:
>   swap` is the eventual target; the alpha keeps the Google Fonts
>   loader so we are not blocked on infra while we iterate on type.
>
> Before promoting beyond alpha, either (i) self-host both families and
> remove the Google Fonts `<link>`s in `index.html`, or (ii) revise this
> section and the policy paragraph below to bless JetBrains Mono and the
> CDN. The drift must not be silent — leave this admonition in the doc
> until it is resolved.


- **Headings:** Use `heading-lg` or smaller inside the application shell. Reserve `heading-xl` for login and major empty states, not for routine panels.
- **Panel Titles:** Use `title-lg` or `title-md` with short, literal labels such as Source Blocks, Topic Plan, Review, Validation, Traceability, and Export Center.
- **Body Text:** Use `body-md` for most UI text and `body-sm` for secondary metadata, helper text, confidence explanations, and compact rows.
- **Labels:** Use `label-lg` for buttons, tabs, and high-emphasis controls. Use `label-md` for badges and compact status metadata.
- **Code:** Use `mono-md` in editors and previews; use `mono-sm` for inline identifiers and trace links.

Alias tokens are available for design handoff and implementation prompts: `display/xl` maps to major workspace and auth titles, `display/lg` maps to page-level section headers, `body/md` maps to default product copy and chat-like agent output, `body/sm` maps to supporting metadata, `label/sm` maps to compact labels and status chips, and `code/md` maps to XML, DITA paths, source IDs, and artifact references.

Canonical vs alias tokens: implementation uses the concrete tokens (`heading-xl`, `body-md`, `label-md`, `mono-md`) as canonical. Slash aliases (`display/xl`, `body/md`, `label/sm`, `code/md`) are design and Figma handoff aliases only. Do not create new implementation sizes from slash aliases. Do not introduce one-off typography sizes for local labels; use the closest canonical token. If none fits, propose a new canonical token through the design system PR process.

Inter weight policy: implementation uses Inter weights `400`, `600`, and `700` today. A `650` variable weight is allowed only after the app proves that Inter Variable is loaded from a single self-hosted font file with `font-display: swap`; do not rely on Google Fonts for production deployments because latency variance is operationally meaningful across geographies. Until that implementation gate lands, design tokens stay on `600` for title, label, and medium-heading emphasis. Existing frontend CSS may still contain nonstandard `650` or `750` weights; align those in a separate code-styling pass if implementation CSS is in scope.

Avoid oversized marketing typography. Do not use negative letter spacing. Do not use more than three visible font weights in one screen unless the editor content requires it.

## Layout

The application uses a persistent workspace layout: a deep navy top app bar, a left navigation rail when needed, a main work area, a document strip, panel tabs, and task-specific split views. The current alpha shell with a `280px` rail and panel-based workspace is the baseline, but future views should become more capable without changing the mental model.

- **Dashboard Tiles (Bento Grid):** Workspace selection screens use a Bento Grid layout. Tiles represent Business Units or Projects and are sized according to data priority, urgency, and recency. Do not use a uniform wall of equal cards when some workspaces have failed ingestion, pending review, export-ready packages, or high document volume.
- **Business Unit Dashboard:** Use a 12-column portal grid with 24px parent padding and 16px grid gaps. BU tiles span 4 columns by default; high-priority or recently active BUs may span 6 columns. Do not make every tile identical when status, volume, or urgency differs.
- **Project Hub:** Use the same 12-column grid, but project tiles are denser. Project tiles span 3 columns by default; priority projects with blockers or export readiness may span 4 to 6 columns. Tiles surface document count, review flags, most recent upload, and export readiness.
- **Top App Bar:** Desktop uses a deep navy top bar with brand, global search, help/task affordances, and user avatar or account control. Keep it compact and stable.
- **Shell:** Desktop may use a `280px` navigation rail and a flexible workspace. The rail contains brand, signed-in user, project creation, and project switching.
- **Workspace Header:** The header identifies the active project and exposes the primary next action. Keep secondary explanations short and place detailed guidance in contextual empty states or tooltips.
- **Document Strip:** Uploaded files behave like compact selectable records with filename, file type, source confidence, and processing state.
- **Review Grid:** Use a three-panel review layout when space allows: source or topic list, editable DITA topic, validation and traceability. On narrower screens, stack panels in task order.
- **Interaction Panel:** Bounded agent assistance appears as a project panel or drawer next to review, validation, topic planning, and export tasks. It is not a persistent general chatbot unless the active task needs agent evidence or a reversible proposal.
- **Density:** Use the `8px` rhythm for gaps and `4px` increments for micro-adjustments. Dense operational views are acceptable when row height, contrast, and alignment remain consistent. Density never compromises 44px touch targets on tablet and mobile breakpoints; dense rows expand their interactive area beyond their visible row height on touch devices.
- **Scrolling:** Long source blocks, topic lists, validation issues, comments, and agent traces should scroll inside their panel. The application shell should remain stable while users compare evidence.

Avoid nested cards. Page sections are workspace regions; cards are for repeated records such as source blocks, topic candidates, validation issues, exports, and audit events.

For auth and account entry screens, use a single centered card and a refined non-white canvas. Keep the page quiet: no dashboard previews, no marketing feature lists, no large watermarks, and no faux-3D tile. The sign-in form should look like a secure enterprise portal, not a landing page.

### Screen Layout Principles

Each screen uses a layout pattern matched to the decision the user is making. Do not reuse Bento tiles everywhere. Use Bento only when users are selecting among comparable workspaces or projects; use split workspaces, timelines, triage lists, or drawers when the user is comparing evidence or acting on a specific artifact.

The cross-screen rules that govern *what goes where on a page* —
header chips, doing vs managing, progressive disclosure of progress,
the primary action as the visual hero, and progressive disclosure of
static config — live in
[`DESIGN.md` › Information Architecture Principles](../../DESIGN.md#information-architecture-principles).
Treat that section as required reading before designing any new screen
or revising an existing one. The screen specs in this directory
implement those principles; this document captures the tokens those
implementations hang on.

- **Sign In (Focused Portal Card):** Use a single centered authentication card on `background-alt`. The only high-priority action is sign in. Secondary account help, legal links, and SSO options sit below the form and must not compete with the primary action.
- **Business Unit Dashboard (Bento Selection Grid):** Use the Bento Grid principle for workspace selection. Tile size reflects workload priority: failed ingestion, review backlog, export-ready packages, or recent activity can increase tile span. Idle BUs stay smaller and quieter.
- **Project Hub (Bento Project Grid):** Continue the Bento principle one level deeper. Project tiles are sized by data priority: active blockers and export-ready projects get larger spans; draft or idle projects stay compact. The grid must make the next project to inspect visually obvious without hiding lower-priority projects.
- **Document Upload And Ingestion (Command + Queue Layout):** Use a two-zone layout: a large upload command zone for the primary action and a right or lower ingestion queue for uploaded files, pipeline status, retry actions, and source-quality warnings. The upload target is visually dominant only until files exist; after upload, the queue and current blockers gain priority.
- **Pipeline Status (Step Timeline Layout):** Use a horizontal or vertical stepper depending on width. The current running stage, failed stage, or next required human action gets the strongest visual treatment. Completed steps are compact, not decorative.
- **Topic Plan (Decision List Layout):** Use a dense decision list grouped by document. Topic candidates are records with confidence, rationale, source coverage, and approval state. Keep the approve action close to the candidate set and avoid turning topic candidates into oversized cards.
- **Review Workspace (Evidence Split Grid):** Use a three-panel evidence grid: source evidence or topic list, DITA editor, and validation/traceability/agent activity. Width is assigned by task priority, not symmetry; the editor usually owns the largest column, while validation expands when blockers are present.
- **Validation And Traceability (Triage Layout):** Use issue severity and affected artifact count to prioritize records. Blocking validation issues appear first and may occupy wider rows; traceability references remain compact but visible next to the affected DITA path.
- **Agent Activity (Inspector Drawer Layout):** Use a right-side drawer or panel anchored to the current task. Tool calls, citations, confidence, cost, and proposed diffs are shown in a structured inspector layout rather than chat bubbles unless a conversational exchange is required.
- **Export Center (Readiness Grid):** Use a readiness summary plus export records. Export readiness, blockers, approval coverage, and package history are grouped so the user can decide whether to build, retry, or download without reading raw logs.

## Elevation & Depth

Depth is conveyed with tonal surfaces, borders, and a small number of believable shadows. The previous fake 3D tile direction is rejected. Do not use skewed side planes, extrusion blocks, heavy perspective transforms, cast side slabs, or button bases that look like physical plastic. This is an enterprise tool, so elevation should clarify hierarchy rather than create a glossy visual style.

- **Base Layer:** `background` fills the app canvas.
- **Primary Layer:** `surface` panels sit on the base with a 1px `outline` border and `rounded.lg`.
- **Subtle Layer:** `surface-subtle` groups repeated records inside panels without adding another card frame around the whole section.
- **Selected Layer:** `surface-selected` marks active document chips, tabs, and selected project-related controls.
- **Modal Layer:** Use `surface` with a slightly stronger border and a soft shadow only for dialogs that interrupt the workflow.
- **Auth Layer:** Use `auth-card` shadow on one centered white sign-in card over `background-alt`. The card should look lifted through shadow, border, and surrounding tone, not through fake 3D geometry.
- **Card Layer:** Use `shadows.card` for portal-style cards and data summary cards. Hover may use `shadows.card-hover`, but only if the card is actually interactive.

Default panels should not use heavy shadows. Prefer stable borders because users need crisp alignment for comparing source text, XML, and validation findings. Dashboard and portal-style cards can use soft shadows like the references, but the light source must remain consistent: shadow falls down and slightly right, never in multiple conflicting directions.

Never add large decorative watermarks behind cards or login forms. Watermarks reduce perceived quality, compete with the form, and are not part of the reference direction.

## Shapes

The shape language is precise and slightly softened. The system uses small radii to feel modern while preserving the engineered quality expected from a technical publishing workspace.

- **Panels and Cards:** Use `rounded.lg` (`8px`) for panels, login cards, empty states, and repeated record cards.
- **Controls:** Use `rounded.md` (`6px`) for buttons, inputs, tabs, document chips, and topic buttons.
- **Badges:** Use `rounded.full` only for compact confidence, status, and review assignment badges.
- **Code and Trace Tokens:** Use `rounded.sm` (`4px`) so inline identifiers remain compact.
- **Do not mix pill-shaped buttons with rectangular form fields** unless the pill is a true badge or avatar-like indicator.

Iconography should come from `lucide-react` when an icon exists. Use icons to identify upload, export, approval, warning, refresh, source, review, and sign-out actions. Icons support scanning; they do not replace accessible labels or titles.

## Interaction Primitives

Focus rings are outlines, not fills. Use `focus-ring` on normal surfaces, `focus-ring-inset` when scroll containers clip outlines, and `focus-ring-on-dark` on the navy top app bar or `surface-inverse` rail. Focus rings inherit the target control radius.

Disabled states use `disabled` or `disabled-strong`. Do not stack `opacity: 0.5` on top of disabled colors; it weakens contrast and makes controls harder for screen-magnifier users. If legacy opacity is unavoidable, use the opacity scale explicitly and treat it as a fallback.

Placeholder text uses `placeholder` and is never a substitute for a visible label. Text selection uses `selection`; editor and code surfaces use `selection-code` so selected XML remains readable on `code-surface`.

Scrollbars use the `scrollbar` token and stay subtle. Do not hide scrollbars on dense evidence, validation, queue, activity, or editor panels.

Motion uses the `motion` scale, `component-motion-contracts`, `screen-motion-choreography`, `loading-animation-contracts`, `status-transition-contracts`, `reduced-motion-overrides`, and `choreography-rules`. Hover, focus, tooltip, tab, drawer, modal, and toast transitions should use the named durations and easing. Reduced motion follows the explicit override matrix rather than a blanket duration collapse, so state changes stay perceivable without spatial animation.

Layering uses the `z-index` scale. Tooltips never sit above modals. Toasts sit above modals so save-failure or export-failure feedback remains visible when a confirmation dialog is open.

Tooltips, popovers, toasts, and numeric badges use their named component tokens. Numeric badges intentionally use `tertiary` for task-rail and inbox counts; it is a controlled announcement use of brand red, not a general action color.

Dense tables use `data-row` at 40px by default. `data-row-compact` at 32px is reserved for audit logs and validation triage; `data-row-comfortable` at 52px is reserved for two-line rows such as document name plus source path. Do not invent row heights per table.

Icon-only controls must have an `aria-label` and a visible tooltip on hover and focus with the same label. Icons inherit `currentColor`, use `icon.size.md` in toolbars/buttons by default, and use `icon.stroke-width.default` unless emphasis is required.

Pipeline icon mapping:

| Pipeline state | Lucide icon | Semantic token |
| --- | --- | --- |
| `Queued` | `clock` | neutral |
| `Uploading` | `upload-cloud` | info |
| `Upload Complete` | `check` | success |
| `Extraction In Progress` | `loader-2` with spin | info |
| `Extraction Complete` | `file-text` | success |
| `Markdown Normalized` | `file-code-2` | success |
| `Topic Plan Ready` | `list-tree` | info |
| `DITA Generated` | `code-xml` | info |
| `Validation Passed` | `shield-check` | success |
| `Validation Warnings` | `alert-triangle` | warning |
| `Review Ready` | `eye` | info |
| `Approved` | `badge-check` | success |
| `Export Ready` | `package-check` | success |
| `Failed` | `x-octagon` | danger |
