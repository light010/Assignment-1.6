# Review Workspace Screen Spec

## As Implemented (Alpha)

This section documents the review surface as it ships today in
`apps/web/src/App.tsx` (`WorkbenchPanel`, `ReviewPanel`, `TopicPlanPanel`,
`ArtifactRegistryPanel`, `JobTimelinePanel`, `ExportPanel`, `SourcePanel`,
`shortId`), `apps/web/src/SourceEvidenceViewer.tsx`,
`apps/web/src/workbenchModel.ts`, and `apps/web/src/workbenchSelectors.ts`.
Primary styling lives in
`apps/web/src/styles.css` (`.workbench-grid`, `.source-evidence-viewer`,
`.workbench-cockpit`, `.topic-filmstrip`, `.evidence-timeline`, `.attention-filter-row`, `.review-grid`, `.topic-list-panel`,
`.topic-button`, `.editor-panel`, `.review-side`, `.section-heading`,
`.badge-count`, `.trace`, `.ok`, `.issue`, `.tabs`). The directional spec
below — deeper structured editing, durable edit operations, bottom activity
strip, dedicated review header — is the longer-term direction. Where they
disagree, this section is the source of truth for what runs in production.

### Where it lives

The review workspace is rendered inside the Project Detail block of the
Project Hub, after a document is selected. Jobs and Artifacts are compact
observability chips above the lifecycle tabs. The lifecycle tabs are
Source / Workbench / Plan / Review / Export.

The **Workbench** tab is the default for terminal reviewable documents.
Source remains the default while extraction is still running. `ReviewPanel`
is still available when the **Review** tab is active, but the primary
human review surface is now the Workbench.

### Tabs

Source: `<div className="tabs">` and the `.tabs` selector.

```text
─────────────────────────────────────────────────────────────────
 Source   Workbench   Plan   Review   Export
                                          ━━━━━━              ← 2px accent rail
─────────────────────────────────────────────────────────────────
```

- Container: flex row with a 1-px bottom hairline (`var(--border)`).
- Each tab is a 38-px tall borderless button with 14-px horizontal
  padding, 13px / 500. Labels are short nouns: Source, Workbench, Plan,
  Review, Export.
- Active tab: `var(--text)` color, 2-px `var(--accent)` rail under the
  label drawn via `::after` (left:12 right:12 bottom:-1) so the rail does
  not touch the tab's edges. No background fill — the spec previously
  prescribed `surface-selected`; the alpha uses an underline-only style
  consistent with modern enterprise tools (Linear, Vercel, GitHub).
- Hover: `var(--text)` color, no background change.

The full tab pattern is documented in
[Tabs (underline)](components-common.md#tabs-underline).

### Workbench tab — original evidence + extracted topics

Source: `WorkbenchPanel`, `SourceEvidenceViewer`, `workbenchModel`, and
`workbenchSelectors`.

The Workbench fuses original source evidence and extracted-topic review
into one two-pane workspace:

```text
┌───────────────────────────────────┬───────────────────────────────────────┐
│ Original source viewer             │ Guided topic review cockpit           │
│ DOCX/PDF/TXT/MD/HTML rendered from │ Current topic, action, progress       │
│ the uploaded source file           │ Filmstrip + evidence timeline         │
│                                   │ Merge / Split / Move / Rename / Type  │
└───────────────────────────────────┴───────────────────────────────────────┘
```

Left pane rules:

- The left pane renders the original uploaded file, not a reconstruction
  from extracted `source_blocks`.
- PDF uses the existing PDF.js/react-pdf path. DOCX uses `docx-preview`
  and is lazy-loaded only when a DOCX is opened. TXT/MD render as read-only
  text. HTML renders in a sandboxed iframe.
- Extraction data is used only as an overlay/index for highlighting,
  source-to-unit selection, and connector geometry. Missing anchors are
  reported as unlocated; the UI never synthesizes missing source content.
- Rendered DOCX links are disabled inside the preview so uploaded content
  cannot navigate the app pane. The explicit `Open original` link is the
  only navigation affordance from the source viewer.

Right pane rules:

- There is no permanent triage rail and no topic-card grid. Clean documents
  are quiet and spacious.
- The right pane starts with a sticky cockpit for the current topic:
  title editing, type, position, confidence, draft/stale state, reviewed
  progress, previous/next navigation, next-attention navigation, and the
  next recommended action.
- A horizontal filmstrip provides topic navigation. Chips show a severity
  dot and reviewed checkmark; clean topics do not repeat a "Clean" badge.
- A compact sticky filter row provides All, Needs attention, Errors,
  Stale, and Review. The Workbench summary Attention count activates
  Needs attention.
- The selected topic's evidence timeline numbers extracted rows by original
  source-block order. The same numbers appear on the left source viewer so
  the relationship is visible without hunting through cards.
- The selected topic header shows inline issue messages, draft state, and
  validation staleness. Timeline rows show severity stripes/badges when
  their source blocks are involved in issues.
- Merge, split, move, rename, and type changes are interactive frontend
  edit operations stored in `sessionStorage` per document. They are
  undoable/redoable locally but are not persisted to the backend and do not
  regenerate DITA XML in this prototype.
- Keyboard affordance: `J/K` previous/next topic, `N` next attention topic,
  `M` merge, `S` split, `T` focus topic type, `R` rename, `Z` undo,
  `Shift+Z` redo, `?` shortcuts.

Current boundary notes:

- The deterministic planner fallback remains a product-fidelity ceiling;
  the Workbench makes cleanup faster but does not make weak topic planning
  correct.
- Source-file URLs currently embed an `access_token`, matching the existing
  app pattern. A future pass should move this to cookie/header auth or
  short-lived signed URLs.
- Backend edit-op persistence and DITA regeneration remain deferred.

### Review tab — three-panel grid

Source: `<div className="review-grid">` and `.review-grid`.

```text
┌────────────────┬───────────────────────────────────────┬────────────────┐
│ Topics    [N]  │ {topic.title}        [Save] [Approve] │ VALIDATION     │
│ ───────────────│ topic_type · status                   │ ◯ No validation│
│ ▎ Topic 1      │                                       │   issues       │
│   top_19…7833  │  <task>…</task>   (DITA editor)       │                │
│   Topic 2      │                                       │ TRACEABILITY   │
│   top_19…a8c1  │                                       │ /task/title    │
│                │                                       │   blk_001      │
│                │                                       │ /task/taskbody │
│                │                                       │   /steps blk_…2│
└────────────────┴───────────────────────────────────────┴────────────────┘
```

Grid: `220px minmax(420px, 1fr) 320px`, gap 14px, `min-height: 600px`.
Below 1180px the right panel spans both the editor and the topic list
columns; below 980px all three panels stack.

### Topic list panel (left)

Source: `<section className="panel topic-list-panel">` and the
`.topic-button` selector.

- Panel header (`.panel-toolbar`): H2 "Topics" plus a `.badge-count` chip
  showing the topic count (e.g. `1`). The badge uses 11.5px / 600
  tabular-nums on `var(--surface-muted)` with `var(--border)`.
- Topic items (`.topic-button`): one button per `document.topic_ids[i]`,
  full-width, left-aligned, `min-height: 52px`, `padding: 10px 12px`,
  1-px `var(--border-subtle)` border, `var(--r-md)` radius. Two-line
  content:
  - **Topic name** (`.topic-button-name`): "Topic {i+1}" at 13px / 600,
    `var(--text)`. Switches to `var(--info-text)` when the topic is the
    active one.
  - **Topic ID** (`.topic-button-id`): mono 11px / `var(--text-muted)`.
    The raw `topic_record_id` (often 30+ chars) is collapsed via
    `shortId(value)` — first 6 + ellipsis + last 4, e.g.
    `top_19…7833`. The full ID is preserved in the `title=` attribute for
    keyboard inspection and copy-paste.
- Active state: `var(--accent-soft)` background,
  `var(--accent-soft-border)` border, plus a 3-px `var(--accent)` left
  rail drawn via `.topic-button.active::before`. Same vertical inset as
  the BU card status edge so the visual language is consistent.

The previous treatment showed the raw ID as the only label. The current
"Topic N + truncated mono ID" pattern is the canonical pattern for any
list of opaque-ID records in this app — see
[Display helpers › `shortId`](components-common.md#display-helpers).

### Editor panel (center)

Source: `<section className="panel editor-panel">`.

Toolbar (`.panel-toolbar`):

- Left: a stacked block (`<div>` containing `<h2>` + `<small>`) with the
  topic title and a metadata line `"{topic_type} · {humanized status}"`.
  The title block uses the `.panel-toolbar > div:first-child:has(h2)`
  rule — vertical stack with 2-px gap so the title and meta read as one
  unit.
- Right: an action group (`<div>` containing two `<button>`s):
  - **Save** — secondary button (default neutral). Calls
    `PATCH /v1/topics/{id}` with the current XML and artifact version.
  - **Approve** — `.btn-primary` filled accent button with leading
    `CheckCircle2` icon. Calls `POST /v1/topics/{id}/approve` and refreshes
    the project list when the approval succeeds.

Editor body:

- A `<textarea>` styled by `.editor-panel textarea`: 100% width,
  `min-height: 540px`, 1-px `var(--border)`, `var(--r-md)` radius, 16-px
  padding, JetBrains Mono / 13px / line-height 1.6, `white-space:
  pre-wrap`, `resize: vertical`. Background `var(--surface-tint)` at rest;
  `var(--surface)` on focus.
- The textarea is the alpha placeholder for a real structured editor.
  Element-level highlighting, validation underlines, and reversible diffs
  remain on the longer-term direction (see below).

### Validation + Traceability panel (right)

Source: `<section className="panel review-side">`.

The right panel is now sectioned with uppercase metadata-style headings
rather than two side-by-side `<h2>`s. This was a deliberate change: the
previous structure's two H2s competed for visual weight against the
editor-panel H2 and the topic title.

Container: `.review-side` is a `display: grid` with `gap: 18px` and
`align-content: start` so sections sit at the top and don't stretch. Each
child is a `.review-side-section` (`display: grid; gap: 8px`).

Section heading (`.section-heading`): `<h3>` styled at 11.5px / 600,
uppercase, `letter-spacing: 0.06em`, color `var(--text-muted)`, no margin.
Used for "VALIDATION" and "TRACEABILITY" labels. The same primitive should
be reused anywhere in the app that needs a tertiary section header inside
a panel — see
[Section heading](components-common.md#section-heading).

#### Validation block

Two states:

- **No issues**: a `.ok` block — `var(--success-bg)` background, 1-px
  `var(--success-border)`, `var(--success-text)` text, with leading
  `CheckCircle2` (18px) and the literal text "No validation issues".
- **Has issues**: one `.issue` row per `topic.validation_issues[]`. Row:
  `var(--danger-bg)` background, 1-px `var(--danger-border)`,
  `var(--danger-text)` text, leading 16-px `AlertTriangle` icon.
  Issue body is two lines — `<strong>` issue code, then `<p>` issue
  message at 12.5px (color inherits danger-text at 0.85 opacity).

#### Traceability block

One `.trace` row per `topic.traceability[]` link. Row: 1-px
`var(--border-subtle)` on `var(--surface-muted)`, 10-px / 12-px padding,
two lines:

- `.trace-path` — JetBrains Mono 11.5px in `var(--text)`, with
  `word-break: break-all` so long DITA paths don't horizontally overflow.
  Examples: `/task/title`, `/task/taskbody/steps`.
- `.trace-blocks` — JetBrains Mono 11px in `var(--text-muted)`, comma-
  separated source block IDs.

These rows are read-only at alpha. The longer-term direction is to make
each row a deep-link to the corresponding source block in the Source tab.

### Empty state

When `topic === null` (no topic loaded yet, or no topics exist for the
document), the panel renders a single full-width
`<div className="empty-state compact">` with copy "No generated topics
are available for this document." The compact empty state is documented
in [Empty / error / banner patterns](components-common.md#empty-error-banner-patterns).

### Plan tab / Topic Plan panel (sibling)

Source: `TopicPlanPanel` and the `.topic-plan` selector.

Not part of the Review tab itself, but specified here because it shares
the same XML / topic data and is opened from the same flow.

- Toolbar: H2 "Topic Plan" + `<button>` "Approve Plan" with
  `CheckCircle2` icon. The Approve button uses the panel-toolbar's accent
  button style (which is the default for any `<button>` in
  `.panel-toolbar`).
- Per-document block (`.topic-plan`):
  - `<h3>` filename (14px / 600).
  - `<small>` status pill: `var(--accent-soft)` background, `var(--info-text)`
    text, `var(--r-pill)` radius. Either "approved" or "waiting for
    approval".
  - One `<article>` per topic candidate: `var(--surface-muted)` background,
    `var(--border-subtle)` border, padding 12px 14px. Content:
    - `<strong>` candidate title (13.5px / 600).
    - `<span>` candidate type (uppercase 11.5px / 500
      `var(--text-muted)`).
    - `<span>` boundary confidence as a percentage string.
    - `<p>` rationale text (12.5px / `var(--text-muted)`).

### Removed and why (for the alpha)

- **Resizable side rails with persisted widths.** The grid uses fixed
  `220px ... 320px`. Resize handles return when the editor moves to a
  real structured editor with side-by-side diff.
- **Bottom activity strip with job state / reviewer / export readiness.**
  The Activity panel in the project detail and the Jobs chip cover this
  data; a sticky bottom strip is unnecessary chrome at alpha scale.
- **Review header above the panels.** The Project Detail's existing
  workspace header (project name and meta) plus the topic title in the
  editor toolbar serve the same purpose. Adding another header row would
  triple the vertical chrome above the editor.
- **Two-column right panel with comments + agent activity.** Comments and
  agent activity are not implemented for alpha. The single sectioned
  right panel keeps the surface ready to receive them: a new
  `.review-side-section` block can be added without changing layout.

## Review Workspace

The Review Workspace must keep source evidence and generated output visible in the same decision context. Topic approval, rejection, regeneration, validation override, and export preparation are explicit workflow transitions, not passive save states. Every generated section should have a visible path back to source blocks, extraction confidence, and validation state.

Recommended review layout:

```text
+--------------------------------------------------------------------------------+
| Review Header: Project / Document / Topic | status | version | save | approve  |
+----------------------+--------------------------------+------------------------+
| Topic / Source Rail  | DITA Editor or Structured View | Validation / Evidence |
| - Topic list         | XML / semantic topic editor    | Issues                |
| - Source blocks      | selected element highlight     | Traceability          |
| - Assignments        | diff / regeneration preview    | Comments              |
|                      |                                | Agent proposals       |
+----------------------+--------------------------------+------------------------+
| Bottom Activity Strip: job state | reviewer state | export readiness | audit   |
+--------------------------------------------------------------------------------+
```

The center panel owns the largest width. The right evidence panel expands when blocking validation issues, unresolved comments, or agent approval requests exist. The left rail may switch between topic list, source blocks, and assignments, but it should not hide the active topic selection.

Review Workspace locked layout:

- **Project Context Bar:** 48px tall and shared with project-level screens.
- **Review Header:** 80px tall using `review-header`. Left side shows breadcrumb `Project > Document > Topic` and topic title in `title-lg`. Right side shows status chips for artifact version, save state, validation state, and approval state, followed by save, approve, reject, and overflow actions.
- **Three-Panel Grid:** Single-row flex layout using `review-workspace-grid`, filling remaining height minus the bottom activity strip.
- **Topic/Source Rail:** Uses `topic-source-rail`, 280px default width, resizable from 240px to 360px.
- **Editor Panel:** Uses `review-primary-panel`, flexes to fill remaining space, and never drops below 520px width.
- **Evidence/Validation Panel:** Uses `evidence-validation-panel`, 360px default width, resizable from 320px to 520px. It automatically expands to `evidence-validation-panel-expanded` at 480px when blocking issues exist.
- **Resize Handles:** 4px wide using `resize-handle`; they use `outline-strong` on hover and must remain keyboard reachable.
- **Bottom Activity Strip:** Uses `review-bottom-activity-strip`, 48px tall, `surface-subtle`, sticky bottom, and always visible. It shows job state, reviewer state, export readiness, and audit shortcut.

Resize and collapse behavior:

- Both side rails are resizable. User-set widths persist per project.
- The editor panel never goes below 520px.
- When the viewport cannot accommodate current widths, panels collapse in this order: right evidence panel becomes a drawer opened from an editor-toolbar icon; left rail becomes a drawer opened from the review header; editor remains full width.

Editor panel internal layout:

- Toolbar uses `editor-toolbar`, 40px tall, `surface-subtle`, and bottom border. It contains XML/Structured mode toggle, undo/redo, search, and regenerate.
- Content area scrolls independently. XML mode uses `code-editor`; Structured mode uses structured topic controls.
- Inline issue markers appear in the left gutter with severity color. Activating a marker opens issue detail in the evidence panel.
- Bottom info bar uses `editor-info-bar`, 28px tall, with cursor position, DITA element path, and character/word count.

Evidence/validation panel internal layout:

- Tab strip uses `evidence-tab-strip`, 40px tall, with tabs for Issues, Traceability, Comments, and Agent.
- Each tab owns its own scroll area; the panel height is fixed.
- Issues tab sorts blocking issues first with `issue-row-blocking`, then warnings with `issue-row-warning`. Selecting an issue scrolls the editor to the affected element.
- Traceability tab lists trace links with source block thumbnails.
- Comments tab uses the comments panel layout from [`operational-systems.md`](operational-systems.md#comments-and-threaded-discussion): sticky filter strip, threaded list, sticky composer, anchor indicators, nested replies, and collapsed resolved-thread rows.
- Agent tab shows proposal cards, citation count, cost, and latency indicators.

Vertical relationships:

- Editor and evidence panel scrolling is independent by default.
- A `follow selection` toggle in the editor toolbar can opt into scroll-linking between editor and evidence. Default is off because most reviewers prefer independent reading.
- Bottom activity strip is always visible and does not scroll.

Review actions:

- **Save:** Writes a draft and shows artifact version.
- **Approve:** Requires validation state, role permission, and no blocking self-approval rule violation.
- **Reject or Request Changes:** Requires a reason and optionally creates assignment/comment.
- **Regenerate:** Must be scoped to topic or section and show proposed diff before applying.
- **Override:** Requires validation issue, policy permission, and written reason.

Five-second scan test:

- The user can see the active topic and document.
- The user can see whether the topic is valid, assigned, edited, approved, or blocked.
- The user can see the source evidence for the selected content.
- The user can see the next allowed action and why any action is disabled.

## Source Evidence

Source block cards display block ID, block type, page or slide, confidence, language, and extracted text. Use `mono-sm` for IDs and `body-sm` for extracted text. Low-confidence or OCR-derived blocks should use warning badges and expose the reason without requiring users to inspect logs.

Source previews must support side-by-side comparison with generated DITA. Keep line wrapping readable and avoid text columns wider than comfortable reading length.

Source evidence is the credibility layer of DITAgen. Every source block card should show:

- Source block ID and stable trace ID.
- Document, page/slide/section, block type, language, and extraction method.
- Confidence signals: OCR, boundary, table/image handling, heading inference, and duplicate detection where available.
- Extracted text or structural summary, with a link to preview the original region.
- Related generated topic/DITA paths when traceability exists.
- Warning reason when confidence is low.

Use the document preview for visual inspection and the source block list for operational triage. If a source preview is unavailable, explain whether the missing preview is due to file type, permission, extraction failure, or not-yet-processed state.

## Topic Plan

Topic candidates are repeated records with title, topic type, boundary confidence, rationale, and source coverage. Emphasize topic title and confidence, not decorative card styling. Topic plan approval is a significant workflow transition; the approve action should be primary and visually stable.

The Topic Plan screen is a decision surface, not a static list. It should group candidates by document and show boundary confidence, topic type, source coverage, language, reuse opportunities, and expected review effort.

Topic Plan locked layout:

- **Project Context Bar:** 48px tall and shared with project-level screens.
- **Topic Plan Header:** 88px tall. Title is `Topic Plan` in `display/lg`. Right side shows confidence policy summary, recompute scope dropdown, and `Approve Plan` as `button-primary` only when eligible.
- **Filter Bar:** 52px tall and sticky. Filters include document, topic type, confidence threshold, language, coverage gaps, and override status.
- **Content:** Two-column flex layout with 16px gap. Topic candidate list owns the flexible primary column, typically 60-70% width. Detail inspector uses `topic-plan-detail-inspector`, 40% width, `surface`, and stays sticky inside the content area rather than page-level.

Topic candidate list layout:

- Candidates are grouped by document. Document headers are sticky within the candidate-list scroll area.
- Document headers use `topic-document-header`, 56px height, `surface-subtle`, document name in `title-md`, and a topic count badge.
- Candidate rows use `topic-candidate-row`, 72px height, and 12px 16px padding.
- Each row has a 4px left-edge `boundary-confidence-strip` that communicates boundary confidence while still showing numeric confidence.
- Row content runs left to right: topic title in `title-md`, topic type chip using `primary-container-chip`, source coverage summary in `body-sm`, boundary confidence as a 60px by 4px `boundary-confidence-bar` plus numeric value, and an action cluster for open evidence, split, merge, and overflow.

Topic candidate row anatomy:

- Candidate title, topic type, and proposed filename/key.
- Boundary confidence and rationale.
- Source coverage: count of source blocks, pages/slides, tables, images, and warnings.
- Policy fit: allowed topic type, constraint profile compatibility, terminology/language warnings.
- Actions: open evidence, split, merge, rename, change type, exclude, approve candidate, request recompute.

Selected candidate detail inspector:

- Header shows candidate title, type chip, and numeric confidence badge.
- Source coverage lists contributing source blocks with thumbnails and `mono-sm` IDs.
- Rationale is `body-sm`, cited, and clearly labeled as agent-generated boundary reasoning.
- Policy fit shows constraint profile match, terminology warnings, and language or reuse concerns.
- Reuse opportunities link to similar candidates across the project.
- Actions include rename, change type, exclude, recompute, and approve candidate.

Bulk actions:

- Selecting multiple candidates reveals a checkbox column on the left edge and a sticky `bulk-action-bar` at the top of the candidate list.
- Bulk operations are change topic type for all selected, exclude all, and request recompute for selected.
- Bulk actions are permission-filtered and must show partial-failure estimates before commit when some selected candidates are restricted or policy-blocked.

Approval rules:

- Approve Plan is primary only when candidates meet project confidence policy or the user can override warnings.
- Low-confidence candidates must remain visible after approval and route reviewers to affected source evidence.
- Recompute is scoped to document or candidate set; do not rerun the entire project unless explicitly requested.

## DITA Editor

The DITA editor is a work surface. Use `code-editor` styling with IBM Plex Mono, stable line height, and strong text contrast. XML editing controls should show artifact version, save state, approval state, and validation state. Disabled or blocked DITA elements should be communicated close to the editor action, not hidden in a generic alert.

The editor supports two modes:

- **Structured mode:** Preferred for editors and reviewers. It presents topic title, shortdesc, sections, steps, tables, notes, images, links, and metadata as structured controls.
- **XML mode:** Required for information architects and advanced users. It uses `code-editor`, `syntax-highlighting`, line numbers, validation highlights, search, and artifact version awareness.

Editor requirements:

- Show artifact version, save state, dirty state, validation state, reviewer assignment, and approval state in the header.
- Highlight the selected DITA element and synchronize it with traceability and validation panels.
- Warn on blocked DITA elements, invalid attributes, missing required structures, broken links, unresolved keyrefs, and unsupported pasted XML.
- Keep regeneration diffs separate from manual edits until accepted.
- Never autosave invalid destructive changes without clear save state and recoverability.

## Validation And Traceability

Validation issues should be scannable records with severity, code, affected DITA path, message, and suggested next action. Use red only for blocking or invalid output. Warnings use amber. Traceability tokens use blue containers and should look clickable when they can focus a source block or DITA element.

Validation and traceability share one evidence panel because users need to understand both "what is wrong" and "where it came from." Use `issue-row-blocking` for blockers and `issue-row-warning` for warnings.

Issue row anatomy:

- Severity, code, affected DITA path, topic, artifact version, and validator source.
- User-readable explanation and suggested next action.
- Links to focus DITA element, source block, topic candidate, and related comment.
- Override eligibility, override reason if present, and reviewer/approver identity.

Traceability rules:

- Trace links connect generated DITA paths to source block IDs, page/slide locations, and confidence.
- Missing traceability is itself a warning for generated content that claims source grounding.
- Traceability must work in both directions: source block to generated content and generated content to source block.
- Agent proposals cannot be accepted without traceability or explicit "no source available" rationale.

Triage behavior:

- Blocking issues sort first, then warnings, then informational notes.
- Filters include severity, validator, topic, document, assigned owner, override state, and source confidence.
- Selecting an issue focuses the editor and source evidence without changing the user's active topic unexpectedly.

Project-scoped full-screen triage layout:

The project-scoped Validation & Traceability screen is for content-ops leads clearing queues across many documents without entering each topic individually.

- **Project Context Bar:** 48px tall and shared with project-level screens.
- **Triage Header:** 80px tall using `triage-header`. It shows `Validation & Traceability` in `display/lg`, aggregate counts, and refresh.
- **Filter Bar:** 52px tall and sticky. Filters include severity, validator, document, topic, owner, override state, confidence, and search.
- **Content:** Two-column flex with 16px gap. Issue list owns the flexible primary column. Issue detail uses `issue-detail-panel`, 480px wide, and stays sticky inside the content area.

Full-screen issue list:

- Group by severity in order: Blocking, Warning, Info.
- Group headers use `triage-group-header`, 48px tall, with collapse toggle and count.
- Issue rows use `triage-issue-row`, variable height, and 64px minimum.
- Each issue row has a 4px left severity bar, validator code in `mono-sm`, DITA path in `mono-sm`, message in `body-md`, affected artifact, document chip, owner avatar, override status, and last action.
- Bulk selection is allowed for assign, override where permitted, and dismiss.

Full-screen issue detail:

- Header shows severity chip, validator code, topic, and artifact version.
- Body shows user-readable explanation, suggested fix, and source evidence link.
- Override section appears only when the user has override permission and requires a reason.
- Trace links list related source blocks and generated DITA paths.
- Actions are open in Review Workspace, assign, override, and mark verified.
