# Common Components And Interaction Patterns

## Components

### App Nav (Icon-Only Side Rail)

The shipped navigation is an icon-only side rail (`<aside class="app-nav">`,
component `AppNav` in `apps/web/src/App.tsx`). It supersedes the previous
"navigation rail" direction, which carried project rows inside the rail.
Project rows have moved to the Project Hub workspace; the rail is now a
durable, app-wide pivot for moving between top-level surfaces.

Geometry (from `apps/web/src/styles.css`):

- Width `64px` on desktop (≥ 980px), `56px` below that breakpoint.
- Sticky below the top app bar (`top: 56px`,
  `height: calc(100vh - 56px)`).
- Vertical layout: a primary group at the top, a footer group at the bottom,
  separated by `justify-content: space-between`.
- Background `var(--surface)`, right border `1px solid var(--border)`.
- z-index `10` (sits below the top app bar at `20`).

Each item (`.app-nav-item`) is a 40×40 button with `border-radius:
var(--r-md)`. States:

| State | Background | Color | Marker |
| --- | --- | --- | --- |
| Default | transparent | `var(--text-muted)` | none |
| Hover | `var(--surface-muted)` | `var(--text)` | 1px `var(--border-subtle)` border |
| Active (`.active`) | `var(--accent-soft)` | `var(--accent)` | 1px `var(--accent-soft-border)` border + 3px accent left rail (`::before`) at `left: -13px` |
| Muted (`.muted`) | transparent | `var(--text-muted)` at `0.85` opacity | reduced opacity hover |
| Focus | inherits + `var(--focus-ring)` | inherits | inherits |

Items currently shipped:

- **Primary group**: Home, Projects (LayoutGrid), Documents, Activity.
- **Footer group**: Settings, Help & Documentation.

Items that are not yet wired to a destination render with the `muted`
modifier and `disabled` attribute. They keep their tooltip
(`title="{label} — coming soon"`) so the role of each glyph is discoverable
even before the destination exists.

Active routing rules (see `App.tsx` shells):

- Business Unit dashboard ⇒ Home is active and disabled (you're already
  there).
- Project Hub ⇒ Projects is active; Home is enabled and routes back to the
  BU list via `returnToBusinessUnits`.

Accessibility:

- The aside has `aria-label="Primary navigation"`.
- Each button has `aria-label`, `title`, and `aria-current="page"` when active.
- Disabled placeholders are `disabled` so screen readers and keyboard users
  understand they are inert.

### Top App Bar

The top app bar is the primary enterprise frame, restored to dark navy after
a brief experiment with a translucent white bar. It anchors the product
identity, gives the page visual weight at the top, and stays out of the way
of content.

Geometry (from `.top-app-bar` and the topbar token block in
`apps/web/src/styles.css`):

- Height `56px`, full width, sticky at `top: 0` with z-index `20`.
- Background: `linear-gradient(180deg, var(--topbar-bg-2),
  var(--topbar-bg))`. Bottom border `1px solid rgba(0, 0, 0, 0.4)` plus
  a `1px inset` highlight via `box-shadow`.
- Three-column grid: brand | context label | actions.

Topbar tokens (defined under `:root` in `styles.css`):

- `--topbar-bg: #0f1830`, `--topbar-bg-2: #131e3d` — navy gradient.
- `--topbar-text: #e8ecf6` — primary on-dark text.
- `--topbar-muted: rgba(232, 236, 246, 0.62)` — secondary/context text.
- `--topbar-border: rgba(255, 255, 255, 0.08)` — hairline borders for
  topbar buttons.

Brand:

- 26-px logo + wordmark "DITAgen". Text is 15px / 600,
  `letter-spacing: -0.01em`, color `var(--topbar-text)`.

Context label (`.topbar-context`):

- Renders the current BU name (or `"Business Units"` on the dashboard).
- Padded left with a 1-px hairline divider via `::before`.
- Truncates with ellipsis on narrow viewports, hides entirely below 640px.

Account control (`.account-control`):

- Pill containing an 18-px avatar circle filled with
  `linear-gradient(135deg, var(--accent-light), var(--accent))` and the
  user's name. The avatar gradient uses palette tokens — no inline hex.

Sign-out icon (`.topbar-icon-button`):

- 32×32 button with translucent background and hover that lifts to
  `rgba(255, 255, 255, 0.10)`.

Future capacity:

- Global search and keyboard-shortcut hint (`Cmd/Ctrl + K`) are intended for
  this bar; they are not implemented yet. The bar reserves room for them
  between the context label and the actions.

### Status-Edged Card

Pattern used for repeated workspace selection cards (BU cards today; the
same pattern is applicable to project tiles when they need a more decisive
status presence).

A 4-px colored bar runs from `top: 0` to `bottom: 0` on the left of the
card, anchored to status. Implemented as a pseudo-element so the card itself
keeps its outer 1-px hairline border and rounded corners:

```css
.bu-card { padding-left: 24px; }
.bu-card::before {
  content: ""; position: absolute; top: 0; left: 0; bottom: 0;
  width: 4px; background: var(--border-strong);
}
.bu-card:hover::before { width: 5px; }
```

Tone classes drive the edge color via a single rule per tone:

```css
.bu-card.tone-danger::before     { background: var(--danger); }
.bu-card.tone-warning::before    { background: var(--warn-strong); }
.bu-card.tone-info::before       { background: var(--accent); }
.bu-card.tone-success::before    { background: var(--success); }
.bu-card.tone-processing::before { background: linear-gradient(180deg, var(--accent), var(--text-muted));
                                   animation: edgePulse 2.4s ease-in-out infinite; }
.bu-card.tone-neutral::before    { background: var(--border-strong); }
```

Rules:

- The status edge replaces oversized status pills as the primary at-a-glance
  cue. The pill stays in the card head row to label the state in words; the
  edge handles the 1-second triage scan.
- Tones are picked by a single function (`pickTone(status, summary)` for BU
  cards). Severity-first: danger > warning > info > success > processing >
  neutral.
- `processing` tones use a 2.4-s pulse on the edge and a 1.6-s pulse on the
  meta dot. No other tones animate. The pulse is gated by
  `prefers-reduced-motion: reduce` via the global override.
- Color must never be the only signal. The card's status pill, meta text,
  and avatar tint also encode the same state.

### Owner Avatar

Pattern used inside list/card rows to surface ownership at a glance without
fetching real avatar images. Implemented as `.bu-avatar`.

Anatomy:

- 34×34 circle (smaller variants 28×28 are allowed in dense lists).
- Two-letter initials derived from the owner team name via the `initials()`
  helper in `App.tsx` (first letter of the first two whitespace-separated
  tokens; falls back to `—`).
- Subtle inner highlight via
  `linear-gradient(135deg, rgba(255,255,255,0.55), transparent 60%)` layered
  over a tone-tinted background.
- Hover scales to `1.06×` when the parent card is hovered.

Tone tints (pair with `pickTone`):

| Tone | Background | Text | Border |
| --- | --- | --- | --- |
| danger | `var(--danger-bg)` | `var(--danger-text)` | `var(--danger-border)` |
| warning | `var(--warn-bg)` | `var(--warn-text)` | `var(--warn-border)` |
| info / processing | `var(--accent-soft)` | `var(--info-text)` | `var(--accent-soft-border)` |
| success | `var(--success-bg)` | `var(--success-text)` | `var(--success-border)` |
| neutral | `var(--surface-sunken)` | `var(--text-secondary)` | `var(--border)` |

Avatars are illustrative, not authoritative. Do not encode role or identity
in the avatar alone — always pair with the team name.

### Hover-Revealed Delete Button

Pattern used for destructive actions on a card or row. The full spec is the
delete button shipped on the BU card (`.bu-card-delete`), which can be
reused on any card-level destructive surface.

Visibility:

- `opacity: 0`, `transform: translateY(-2px)`, `pointer-events: none` by
  default — the icon is in the DOM but invisible.
- On `:hover` or `:focus-within` of the parent card, fades in to
  `opacity: 1` and `translateY(0)` and re-enables pointer events.
- On its own `:focus-visible` it also reveals — so keyboard users can always
  reach it.

Color (palette tokens only — no inline hex):

| State | Background | Border | Icon | Shadow |
| --- | --- | --- | --- | --- |
| Default | `var(--danger-bg)` | `var(--danger-border)` | `var(--danger)` | none |
| Hover | `var(--danger)` | `var(--danger)` | `var(--accent-on)` | `0 4px 10px rgba(196,51,42,.24)` |
| Active | `var(--danger-pressed)` | `var(--danger-pressed)` | `var(--accent-on)` | none |
| Focus | `var(--danger-bg)` | `var(--danger)` | `var(--danger)` | `0 0 0 3px rgba(196,51,42,.22)` |

Geometry: 28×28 button at `top: 10px; right: 10px`, `border-radius:
var(--r-sm)`, lucide `Trash2` at `size={14}`.

Behavior contract:

- `event.stopPropagation()` so the parent card click does not fire when the
  user actually wants to delete.
- A native `window.confirm` with a literal message that names the record and
  states the consequence: "This will remove its projects, documents, and
  history. This cannot be undone." This satisfies the design system rule
  that destructive and irreversible actions are visually distinct and
  confirmation-oriented.
- After the API call resolves, the parent list is re-fetched and any state
  pointing at the deleted record is cleared.
- The button is rendered only when the user has authority to delete the
  record (e.g. admin-only for BUs). Visibility is gated by an `onDelete`
  prop being passed in, never by CSS.

Do not show the delete affordance always-visible on cards. Always-visible
delete icons are a footgun on dense pages and dilute the safety of the
destructive action; the hover-reveal is intentional.

### Pipeline Mini-Bar

Pattern used to summarize multi-state pipeline counts inline on a card.
Implemented as `.bu-card-pipeline`.

Geometry: an 8-px tall horizontal bar with `border-radius: var(--r-pill)`,
1-px subtle border, `var(--surface-sunken)` background. Inside the bar,
each visible segment uses `flex-grow: count` so visual proportion equals
data proportion.

Segments:

| Segment | Token | Pipeline meaning |
| --- | --- | --- |
| `.pipeline-seg.failed` | `var(--danger)` | Failed jobs |
| `.pipeline-seg.warnings` | `var(--warn-strong)` | Validation warnings |
| `.pipeline-seg.review` | `var(--accent)` | Review-ready items |
| `.pipeline-seg.processing` | `var(--text-muted)` | In-flight processing |
| `.pipeline-seg.export` | `var(--success)` | Export-ready items |

Rules:

- Render the bar only when at least one segment count is > 0. Empty data ⇒
  no bar. Do not render an empty placeholder bar; the card has no obligation
  to fill space. (See the
  [progress-when-informative principle](../../DESIGN.md#3-show-progress-affordances-when-theyre-informative-collapse-when-theyre-not).)
- Each segment carries a `title="{Label}: {value}"` for screen readers and
  hover inspection.
- Hover brightens via `filter: brightness(1.1)`. No tooltip popovers in this
  release; the `title` is sufficient.
- The bar is decorative reinforcement — it must never be the only signal of
  pipeline state. The card's status pill and meta text are the textual
  source of truth.

### Stage Stepper

Pattern used to render a multi-stage pipeline as a row of pills with
connectors. The shipping example is the Upload Hub's
`<StageStepper status={...}>` rendered through `.stage-stepper` and
`.stage` selectors.

Six stages (`STAGE_LABELS`): Upload → Extract → Plan → Convert →
Review → Export. Each pill resolves to one of five states from
`mapStatusToStage(status)`:

| State | Dot fill | Connector | Label |
| --- | --- | --- | --- |
| `complete` | `var(--success)` | `var(--success)` | `var(--text)`, 500 |
| `active` | `var(--accent)`, 3-px halo `accent-soft`, pulse animation | (default) | `var(--text)`, 600 |
| `warning` | `var(--warn-strong)` | `var(--warn-strong)` | `var(--warn-text)`, 600 |
| `failed` | `var(--danger)` | (default) | `var(--danger-text)`, 600 |
| `pending` | `var(--surface)` w/ `var(--border-strong)` ring | `var(--border)` | `var(--text-muted)`, 500 |

#### Progressive disclosure rule

Per the
[Show progress when informative, collapse when not](../../DESIGN.md#3-show-progress-affordances-when-theyre-informative-collapse-when-theyre-not)
principle, the stepper has three render modes selected via the
component's `variant` prop:

| Variant | When to use | Behavior |
| --- | --- | --- |
| `full` | Caller forces the stepper (e.g. "This session" group) | Stepper always renders. |
| `compact` | Caller forces no stepper (e.g. dense Earlier list) | Stepper hidden; row shows only header + status chip. |
| `auto` (default) | Caller delegates the decision | Stepper renders only when status is non-terminal. Terminal documents collapse to a `.status-chip`. |

Terminal states (defined in `isTerminalStatus`):
`ready_for_review`, `review_ready`, `approved`, `export_ready`,
`rejected`, anything containing `fail`. Anything else is
non-terminal.

For a row in `compact` mode, the row's meta line is enriched with the
status chip + topic count + quality % + relative time so the user
still has the same answer ("is this ready for me to act on?")
without spending the vertical space on the stepper.

#### Anatomy and motion

- Six-column equal grid; pill stacked over label with a 6-px gap.
- Connector line runs from the right of dot N to the left of dot
  N+1. The connector AFTER a `complete` stage takes the success
  color; the connector BEFORE the active stage stays default.
- Active pill animates `@keyframes stage-pulse` — accent-soft halo
  expands from 3 px to 6 px and back over 1.6 s. Honors the global
  `prefers-reduced-motion: reduce` override.
- Below 720 px, labels hide via `@media (max-width: 720px)`. A
  `.stage-stepper.compact` class additionally hides labels for very
  dense lists.

#### Industry references

- **Vercel**: live deployments show full step-by-step progress;
  completed deployments collapse to a single "Ready" chip with a
  subtle deploy time. Same rule.
- **GitHub Actions**: in-progress workflow renders step-by-step;
  completed workflow shows a single check or X.
- **Linear**: cycles in progress render a progress bar; completed
  cycles collapse to a single line.

#### Don't

- Don't render the stepper inside a card whose status is already
  unambiguous from a single chip (e.g. an "Approved" history list).
  That violates the progressive-disclosure rule.
- Don't animate the stepper on completed states. The pulse is the
  signal of "movement"; once the work is done, it must stop.
- Don't make the connector the only signal of completion (it is too
  subtle on its own). Pair it with a filled dot.

### Hero Dropzone

Pattern used when a screen's primary action is "get a file in." The
shipping example is the Upload Hub's `<MultiFileDropzone>` rendered
through the `.dropzone-large` selector.

**Why hero-sized**: per the
[Primary action is the visual hero](../../DESIGN.md#4-the-primary-action-is-the-visual-hero)
principle, the dropzone is the largest interactive element on the
page. A small dropzone reads as chrome and gets ignored; a hero
dropzone announces intent and invites the action.

References (industry):

- **Loom / Notion / Figma** upload modals: dropzone fills the modal
  body, ~200 px+ height, prominent icon, friendly verb-led copy.
- **GitHub uploads**: a large dashed canvas takes the focal area of
  the New File / Add File flow.
- **Dropbox / Drive**: drag-over swaps the canvas to a tinted full-
  page drop affordance.

#### Geometry

- **Container** (`.dropzone-large`): `min-height: 200px`, full content
  width, `var(--r-xl)` (14 px) radius, vertical layout
  (`display: grid; justify-items: center; align-content: center`).
  Background: a radial accent-glow over a subtle vertical gradient
  (`linear-gradient(180deg, var(--surface-tint), var(--surface))`)
  with the glow growing on hover and growing further on drag-over.
  Border: 1.5 px **dashed** `var(--border-strong)` at rest.
- **Icon zone** (`.dropzone-icon`): 64 × 64 white circle on top of
  the radial glow, 1-px `var(--accent-soft-border)` border,
  `var(--shadow-sm)`, lucide `Upload` icon at 28 px in
  `var(--accent)`.
- **Text** (`.dropzone-text`): centered, max-width 520 px. Strong
  line at 19 px / 600 + small line at 13 px / muted. The strong line
  uses an action verb (e.g. *"Drop documents to convert"*).
- **Hidden file input** with `multiple` and the file-type `accept`
  pattern so a click anywhere on the label opens the system picker.

#### State machine

| State | Border | Background | Icon zone | Strong copy |
| --- | --- | --- | --- | --- |
| Default | dashed `var(--border-strong)` | gradient surface + soft glow | white w/ accent icon | "Drop documents to convert" |
| Hover | dashed `var(--accent)` | larger glow + tinted gradient | translateY(-2px) + bigger shadow | unchanged |
| Drag-over (`.is-dragging`) | **solid** `var(--accent)`, +4-px outer halo | flat `var(--accent-soft)` + giant glow | filled `var(--accent)` w/ white icon, scaled 1.1× | "Release to add to queue" |
| Disabled (`.is-disabled`) | unchanged | unchanged | unchanged | unchanged, opacity 0.6, cursor not-allowed |

The drag-over state should clearly *open up* — bigger, brighter,
filled. This is the moment of commitment for the user; the
visual feedback should match.

Drag tracking uses an internal counter so child elements firing their
own `dragenter` / `dragleave` events don't flicker the dragging state.
The counter resets to 0 on `drop`.

#### Drop behavior

- Multi-file drops are accepted in a single gesture. Each dropped
  file is validated independently via `validateUpload(file)` and
  pushed to the local queue with state `queued` (valid) or `failed`
  (invalid, with the error captured in the row).
- Failed files appear in the queue immediately so users see *why* a
  file did not start uploading, rather than the dropzone silently
  ignoring it.

#### When to use

Use the hero dropzone when the page's primary purpose is ingest —
Upload Hub today, future Import flows. Do **not** use it for
secondary attach actions (e.g. attaching a screenshot to a comment);
those should use a small `Upload` icon button next to the input
field. The hero treatment is reserved for screens where the user came
specifically to drop files.

### Metrics Strip

Pattern used for compact, full-width KPI strips above a list or grid. The BU
dashboard ships the canonical version (`.metrics-strip` containing
`.metric-card` items).

Geometry:

- Grid: `repeat(5, minmax(0, 1fr))` with 12-px gap. Drops to 3-col at
  `max-width: 1100px`, 2-col at `max-width: 640px`.
- Card: `var(--surface)` panel with 1-px `var(--border)`, 78-px min height,
  `var(--shadow-xs)`.
- Value: 24px / 600, `letter-spacing: -0.02em`, tabular-nums.
- Label: 11.5px uppercase 0.06em tracking, `var(--text-muted)`.

Tone:

- `tone="warning"` ⇒ border swaps to `var(--warn-border)` and the value
  color to `var(--warn-text)`.
- `tone="danger"` ⇒ border swaps to `var(--danger-border)` and the value
  color to `var(--danger-text)`.
- Tones apply only when the value is non-zero. A zero "Failed jobs" stays
  neutral; a non-zero one turns red. This keeps the strip quiet at idle and
  loud only when there is real signal.

Use this strip for portfolio aggregates above a card grid or list. Do not
mix marketing or vanity numbers with it.

### Header Context Chips and (i) Popover

Pattern used to surface workspace metadata next to the page H1 without
cluttering the chrome. The shipping example is the Upload Hub
(`apps/web/src/App.tsx#UploadHub` and `BUInfoPopover`) where the H1
"Documentation Operations" is followed by a small `(i)` button and a
single `N documents` chip.

**Promotion rule** (per
[`DESIGN.md` › Information Architecture Principles](../../DESIGN.md#1-chips-next-to-the-h1-encode-state-not-config)):
a chip qualifies for the H1 row when it is **stateful**, **glanceable
at task time**, and **not duplicated** elsewhere in the chrome. If a
value fails any of those tests it goes into the popover or into
Settings.

#### Demotion table

Captured during the Upload Hub redesign so similar decisions are
consistent on future screens.

| Value | Original location | Promoted (chip) or demoted? | Where it lives now |
| --- | --- | --- | --- |
| `org_admin` (user role) | H1 chip | Demoted | (i) popover (already implied by topbar avatar) |
| `DITA 1.3` (conversion target) | H1 chip | Demoted | (i) popover (static config; future Settings) |
| `12.5 KB storage` | H1 chip | Demoted | (i) popover (admin info; not actionable here) |
| `1 document` | H1 chip | **Promoted** (kept) | H1 row — count changes as users upload |
| Last activity time on a row | row meta | Promoted (kept on the row) | Row meta line, formatted via `relativeTime()` |

#### `(i)` popover anatomy

Implemented as `BUInfoPopover` with the `.info-popover`,
`.info-popover-trigger`, and `.info-popover-panel` selectors.

- **Trigger** (`.info-popover-trigger`): 26 × 26 circular button next
  to the H1, lucide `Info` at 14 px. Default neutral; turns to
  `var(--accent)` outline + `var(--accent-soft)` background when open.
- **Panel** (`.info-popover-panel`): 240-px min-width card,
  `var(--surface)` background, `var(--shadow-lg)`, anchored
  `top: calc(100% + 8px); left: 0` of the trigger.
- **Content**: `<dl>` with `dt` (uppercase 11 px label) /
  `dd` (13.5 px / 600 / tabular-nums value) pairs. Three or four
  rows max — anything longer goes to a Settings drawer instead.
- **Dismiss**: blurring the trigger closes the popover unless focus
  moves into the panel itself. Click-outside also closes.
- **Accessibility**: `aria-haspopup="dialog"`, `aria-expanded`,
  `role="dialog"` on the panel, `aria-label="Workspace details"`.

Do not nest interactive controls inside the popover unless they are
read-only links to a real Settings surface. The popover is for
*explanation*, not *configuration*.

### Index List + Search / Sort / Filter Toolbar

Pattern used at the top of any list (BU dashboard, Project Hub
projects, Upload Hub Earlier section, future Documents page) to
control what's visible. The shipping examples are
`.minimal-toolbar` (BU dashboard, Project Hub) and `.hub-toolbar`
(Upload Hub Earlier section).

Per the
[Doing vs Managing](../../DESIGN.md#2-doing-vs-managing--split-the-surface)
principle, lists in *managing* contexts must let the user
search, sort, and filter; lists in *doing* contexts may include a
trimmed version of the toolbar (search-only) but should not lead
with it.

#### Anatomy

```text
┌──────────────────────────────────────────────────────────────┐
│ ⌕ Search …            [All|Need attn|Ready|Failed] Sort ▾   │
└──────────────────────────────────────────────────────────────┘
```

- **Layout**: 2-column grid (`grid-template-columns: minmax(240px, 320px) 1fr`).
  Search input on the left; filter pills + sort dropdown clustered on
  the right (`justify-self: end`).
- **Search input**: 36-px tall pill (`.filter-search`) with leading
  lucide `Search` icon. Filters as the user types — no submit button.
  The input's parent picks up `:focus-within` so the entire pill
  takes the focus ring.
- **Saved filter pills** (`.saved-filters button`): 28-px tall pill
  cluster inside a 1-px bordered container. Active pill has white
  background + border + `var(--shadow-xs)`; inactive is transparent
  with muted text. 4–6 pills max; if you need more, the screen
  needs a real filter drawer instead.
- **Sort dropdown** (`.hub-sort select`): native `<select>` with a
  custom-painted caret. Inline label "Sort" left of the control;
  options are user-readable strings (`Most recent`, `Filename`,
  `Status`, `Quality`).

#### Composition

Every list using this toolbar must implement:

1. **Empty state for filtered-to-zero** — a small dashed
   `.empty-card` with copy "No documents match the current filters."
   plus an optional reset button. Never leave a pristine container
   that looks like the list never loaded.
2. **Default sort** that matches the screen's intent:
   - *Doing* surfaces: most recent first.
   - *Managing* surfaces: severity first, then last activity, then
     name (matches the existing BU dashboard sort order).
3. **Stable filter state** within the screen. Do not reset filters
   when the user opens a row, scrolls, or refreshes; only reset on
   navigation away from the surface or on explicit "Reset filters."

#### When to use what

- **Search alone** (search input only, no pills, no sort) — for
  short lists in *doing* contexts (≤ ~10 rows expected).
- **Search + filter pills** — most index lists. Pills are saved
  views, not raw column predicates.
- **Search + filter pills + sort** — managing surfaces with
  enough records that order genuinely matters (≥ ~20 rows).
- **Search + filter drawer** — when filter combinations exceed
  what 4–6 pills can express (date range × owner × type ×
  status). The drawer is Phase 2+ and lives off the same toolbar.

#### Industry references

- **Linear**: compact, keyboard-first toolbar; Cmd-K for search;
  filter pills above the list. The visual rhythm we follow.
- **Vercel deployments**: search left, status chips and sort
  right. Same model.
- **Stripe / Customers**: search left, advanced filter button on
  the right that opens a drawer when conditions are complex.
- **GitHub Issues**: filter pills as URL state — saved filters
  are durable links.

### Eyebrow Pill

Small pre-title pill with an optional status dot. Used at the top of page
headers to fix tenant context, role, environment, or build channel without
swelling the H1.

Implemented as `.eyebrow` (with optional `.eyebrow-dot` child).

- Pill: `var(--surface)` background, 1-px `var(--border)`, `var(--r-pill)`
  radius, `var(--shadow-xs)`. Padding 4px 10px (8px left when a dot is
  present).
- Text: 11px uppercase 0.04em tracking, `var(--text-muted)`.
- Status dot: 6×6 circle, `var(--success)` background, soft halo via
  `box-shadow: 0 0 0 3px rgba(15, 125, 82, 0.18)`. The dot color can be
  swapped to any palette tone if the eyebrow is communicating a different
  state.

The eyebrow does not replace the page H1 or the breadcrumb; it sits above
both and orients the user before they read the headline.

### Buttons (Alpha implementation)

The shipped button system maps to two visual variants: a default neutral
button and a primary accent variant via `.btn-primary`. There are no
classes for tertiary, ghost, or icon-only-stripped buttons in the alpha
CSS — the same default button is restyled inline (e.g. `.topbar-icon-button`)
when an icon-only square is needed.

#### Default `<button>`

Source: bare `button` selector in `apps/web/src/styles.css`.

| Property | Value |
| --- | --- |
| Display | `inline-flex; align-items: center; justify-content: center; gap: 8px` |
| Border | 1-px `var(--border)` |
| Background | `var(--surface)` |
| Text color | `var(--text-secondary)` |
| Min-height | 34px |
| Padding | 0 12px |
| Radius | `var(--r-sm)` (6px) |
| Font | 13px / 500 / `letter-spacing: -0.005em` |
| Cursor | `pointer` |
| Transition | `120ms cubic-bezier(0.2, 0.6, 0.2, 1)` on bg / border / color / shadow |

States:

- **Hover** (`:hover:not(:disabled)`): border `var(--border-strong)`,
  background `var(--surface-muted)`, color `var(--text)`.
- **Focus** (`:focus-visible`): border `var(--accent)` + `var(--focus-ring)`
  shadow.
- **Disabled**: `opacity: 0.55; cursor: not-allowed`. Background and border
  do not change — disabled buttons remain visually present but inactive.

#### `.btn-primary` (accent fill)

Source: `.btn-primary` selector. Apply this class to any `<button>` that
should read as the dominant action in its local surface.

| Property | Value |
| --- | --- |
| Background | `var(--accent)` |
| Border | `var(--accent)` |
| Text color | `var(--accent-on)` (white) |
| Font weight | 500 |

States:

- **Hover** (`:hover:not(:disabled)`): background and border switch to
  `var(--accent-hover)`. Color stays white.
- **Focus**: inherits the default `:focus-visible` (accent border +
  focus-ring). Because background is already accent, focus is signaled
  through the ring.
- **Active toggle** (`.btn-primary.active`): used when the same button
  flips to a "Cancel" affordance — background `var(--surface)`, border
  `var(--border-strong)`, color `var(--text)`. Used today on the BU
  dashboard "Add Business Unit ↔ Cancel" toggle.

#### Composition rules

- Use `.btn-primary` for the **single most important action** on the
  surface: Upload and process, Create business unit, Create project,
  Approve, Approve Plan, Build DITA ZIP. Anything else stays default.
- Avoid two `.btn-primary` buttons in the same row. If two actions are
  competing for primary status, one should become secondary (default)
  and the other should keep the accent.
- Destructive actions are documented separately under
  [Hover-Revealed Delete Button](#hover-revealed-delete-button).
  Do not invent a `.btn-danger` filled variant for delete/destructive —
  the destructive affordance lives in dedicated icon buttons or in
  `confirm()` dialogs, never as a default-state filled red button on a
  card.

#### Inline-icon buttons inside `.panel-toolbar`

The toolbar pattern overrides default styles for buttons that live in a
panel header so they act as the panel's primary action without needing
explicit class names:

```css
.panel-toolbar button,
.upload-button,
.primary-action {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--accent-on);
  font-weight: 500;
}
```

This keeps the markup clean (`<div class="panel-toolbar"><h2>…</h2><button>Approve Plan</button></div>`)
while still rendering an accent button. When the toolbar holds **two**
buttons (e.g. Save + Approve in the Review panel), the more important one
should explicitly add `.btn-primary` and the other should opt out via
markup refactor; the bare-`<button>`-in-toolbar default will give both an
accent fill, which is incorrect.

### Form Primitives (Alpha implementation)

Source: bare `input`, `textarea`, `select` selectors in
`apps/web/src/styles.css`.

| Property | Value |
| --- | --- |
| Border | 1-px `var(--border)` |
| Background | `var(--surface)` |
| Text color | `var(--text)` |
| Min-height | 36px (textareas grow naturally) |
| Padding | `0 12px` (12px all-around for `<textarea>`) |
| Radius | `var(--r-sm)` |
| Font | 13.5px (inherits Inter) |
| Transition | 120ms on border-color and box-shadow |

States:

- **Placeholder** (`::placeholder`): `var(--text-faint)` — distinct from
  `var(--text-muted)` so a real value reads stronger than a placeholder.
- **Focus** (`:focus`): border `var(--accent)` + `var(--focus-ring)` shadow.
  Outline is removed because the focus ring is the visible cue. Never
  remove both.

#### Code surfaces

- `<textarea>`s used for code (DITA editor) and `<pre>`s used for read-only
  code projection (Markdown projection) inherit JetBrains Mono via the
  global `code, pre, textarea` rule. Line-height 1.55–1.6, `white-space:
  pre-wrap` so long lines wrap inside the editor instead of forcing a
  horizontal scroll.

#### Filter search input

`.filter-search` (used in the BU dashboard and Project Hub toolbars) wraps
the bare `<input>` in a 36-px tall pill with a leading 36-px square that
holds the lucide `Search` icon. The pill's container picks up
`:focus-within` styling so the entire pill — not just the input — gains the
focus ring. This is the canonical pattern for any search input on a
filter row.

#### Inline create form fields

`.inline-create-fields` is a 3-column grid of `<label>` blocks. Each label
holds a 12-px `<span>` field name and a standard input. The labels are
left-aligned and never inside a placeholder; placeholders carry the
example value (e.g. `e.g. Customer Documentation`), not the label.

Per the form rules already in this document: required fields show
`required` near the label, validation lives near the control, and
dangerous changes confirm before submit.

### Tabs (underline)

Source: `.tabs` selector, used for the in-document lifecycle switcher
(Source / Workbench / Plan / Review / Export). Jobs and Artifacts are
observability chips above the lifecycle tabs, not lifecycle tabs.

The shipped tab style is **underline-only**, not a segmented control. This
supersedes the previous "active tab uses `surface-selected` + blue
underline + clear border" direction. Reasons:

1. The tab strip sits directly under the Documents row and above the
   panel content; a filled background on the active tab created a
   competing "card" feeling.
2. The underline is sufficient for active state and matches the rest of
   the app's lighter chrome (Linear, Vercel, GitHub style).

Geometry:

- Container: flex row, `border-bottom: 1px solid var(--border)`, no
  background.
- Each tab: 38-px tall, 13px / 500 / capitalize, `border: 0`,
  `background: transparent`, `padding: 0 14px`, `color: var(--text-muted)`.

States:

- **Hover**: `color: var(--text)`. No background change.
- **Active** (`.tabs button.active`): `color: var(--text)` and a 2-px
  `var(--accent)` rail rendered as `::after` with `left: 12px; right:
  12px; bottom: -1px; border-radius: 2px`. The rail's horizontal insets
  mean it doesn't touch the tab's edges, which keeps it visually
  separate from the strip border.

Composition rules:

- Tab labels are nouns or noun phrases ("Source", "Workbench", "Plan",
  "Review") — never verbs. Use an explicit label map when the route key
  and visible label differ, for example `topic-plan` routes rendering as
  "Plan".
- Disabled or condition-locked tabs are not in the alpha. When they
  arrive, they keep the underline pattern and gain a tooltip explaining
  the precondition (per the existing Tabs guidance below).

### Empty / Error / Banner Patterns

The shipped CSS provides three distinct affordances. Pick the one that
matches the situation; do not invent new variants per surface.

#### `.empty-card` — full-region empty state

Used when an entire region (the BU grid, the project list, etc.) has no
content under the current filter. Geometry:

- Dashed 1-px `var(--border)`, `var(--r-lg)` radius, `var(--surface)`
  background.
- `padding: 56px 24px`, centered grid (`place-items: center; align-content:
  center`), 10-px gap.
- Holds an optional lucide icon at 28px in `var(--text-faint)`, then a
  `<p>` explaining what is missing, and an optional reset / next-action
  button.

The dashed border + faint icon read as "scaffolding" — the user
understands the page is fine, the result set is just empty.

#### `.panel .empty` — empty state inside a panel

Used inside a panel toolbar where the panel itself is filled chrome but
its body has nothing to show. Geometry:

- Dashed 1-px `var(--border)`, `var(--r-md)` radius,
  `var(--surface-muted)` background.
- `padding: 16px`, text-align center, 13px `var(--text-muted)`.

This is intentionally lighter than `.empty-card` so it doesn't fight the
panel border around it. The shipped uses are the activity panel ("No
project activity yet."), the documents panel ("No documents uploaded
yet."), the artifact registry ("No artifact rows found."), and the export
panel ("No exports created in this session.").

#### `.empty-state.compact` — full-panel empty state

Used when the panel itself is empty (e.g. the Review panel before any
topic loads). Container is the panel surface — dashed
`var(--border)` border, `var(--surface)` background, `var(--r-lg)` radius,
`min-height: 200px` for the compact variant. Holds optional icon + `<p>`.

#### `.error-banner` — page-level error

Used at the top of a page region to surface an action error
(`setError(message)`). Geometry:

- 1-px `var(--danger-border)`, `var(--danger-bg)` background,
  `var(--danger-text)` text, `var(--r-md)` radius, `padding: 10px 14px`,
  13px / 500.

The error banner is non-dismissable in the alpha; subsequent actions clear
it. It must say what the user tried and why it failed, in plain language.

#### `.status-banner` — page-level non-error progress / info

Used to surface in-flight operations (the page-level "Processing" banner
shown during BU/document creation flows). Same geometry as
`.error-banner`, but `var(--accent-soft)` background, `var(--info-text)`
text, `var(--accent-soft-border)` border. Always rendered with a leading
`<svg>` icon + label.

### Inline Create Panel

Pattern used to surface short creation flows on the page that owns the
collection. It is a drop-down expansion of a header action button rather
than a separate route or modal — appropriate for forms with 1–4 fields
that can complete in a single submit.

Source: `.inline-create-panel`, `.inline-create-header`,
`.inline-create-fields`, `.inline-create-actions` in
`apps/web/src/styles.css`. Canonical implementation: the BU dashboard
"Add Business Unit" form.

Anatomy:

- Container: 1-px `var(--accent-soft-border)`, `var(--r-lg)` radius,
  `linear-gradient(180deg, var(--accent-soft), var(--surface))`,
  `var(--shadow-sm)`, padding 20px, gap 16px between rows.
- Header (`.inline-create-header`): H2 (16px) plus a 13-px description
  paragraph under it. Both left-aligned.
- Fields (`.inline-create-fields`): 3-column grid for short forms
  (Name / Owner / Region). Each field is `<label><span>Field name</span>
  <input></label>`. On viewports below 980px the grid collapses to a
  single column.
- Actions (`.inline-create-actions`): right-aligned. Cancel button
  (default styling), then primary submit using `.btn-primary` with the
  domain icon (e.g. `Building2` for BUs).

Open/close:

- The header action button toggles between `Plus` + label ("Add Business
  Unit") and `X` + "Cancel". When toggled to "Cancel", apply
  `.btn-primary.active` so the button reads as a secondary action while
  open.
- Use `aria-expanded` and `aria-controls` on the toggle button so screen
  readers announce the disclosure. The form has the matching `id`.

Do **not** use this pattern for:

- Forms longer than 4 fields → use a drawer or dedicated route.
- Forms that require multi-step validation → use a wizard.
- Destructive operations.

### Record Row Patterns

The shipped CSS contains three repeated record patterns. They share design
DNA (1-px subtle border, muted surface, monospace IDs) but each is
optimized for the data it carries.

#### `.activity-row`

Source: rendered inside `.activity-panel`. Used for compact event lists
where each row is one event.

- Container: 1-px `var(--border-subtle)`, `var(--r-md)`,
  `var(--surface-muted)` background, padding 10px / 12px.
- Two-line layout: `<strong>` action (13px / 600), then `<span>` resource
  type (12.5px `var(--text-muted)`).

#### `.document-row`

Source: rendered inside `.document-table`. Used for tabular records where
columns must align.

- 4-column grid (`minmax(180px, 1fr) 150px 100px 72px`).
- Hairline bottom border (`var(--border-subtle)`), 48-px min height,
  10-px / 12-px padding.
- Active row: `var(--accent-soft)` background + 3-px inset accent left
  rail. The active treatment matches the rest of the app's "selected
  list row" pattern.

The cells in order are filename + lucide icon, status (humanized),
topics count (with proper pluralization), and a quality badge. See the
upload spec for content rules.

#### `.artifact-table`

Source: `.artifact-table` containing `.artifact-header` and `.artifact-row`.
Used for wide read-only registries where horizontal scrolling is
acceptable.

- Container: 1-px `var(--border-subtle)`, `var(--r-md)`, `overflow:
  auto` so the rows can scroll horizontally inside the panel.
- Header row: 1-px bottom border, `var(--surface-muted)` background, 11px
  uppercase / 0.06em tracking labels.
- Data row: 6-column grid (`minmax(190px, 1.2fr) 160px 160px 90px 150px
  minmax(260px, 1fr)`), 44-px min height, 1-px bottom border. Hover:
  `var(--surface-muted)` background.
- Mono cells (artifact ID, hash, path) use ellipsis-truncation with
  `overflow: hidden; text-overflow: ellipsis; white-space: nowrap`.
- Width floor 1040px so the columns don't smush together; the panel
  scrolls horizontally below this width.

### Section heading

Source: `.section-heading` selector.

A small uppercase label used for tertiary section headings inside a
panel (e.g. "VALIDATION" and "TRACEABILITY" in the Review panel's right
column). 11.5px / 600, uppercase, `letter-spacing: 0.06em`,
`var(--text-muted)`. No margin.

Use this primitive whenever a panel needs to be split into two or more
labeled blocks but a full `<h2>` would compete with the panel's own
`<h2>` in the toolbar.

### Workspace Header And Actions

Each workspace view exposes one primary action. Use `button-primary` for the most important local action: Upload, Approve Plan, Save, Approve, or Build DITA ZIP. Use secondary buttons for reversible or navigational controls. Use danger buttons only for destructive actions such as rejecting content, removing uploads, or revoking access.

Buttons, tabs, inputs, and selectable rows must implement the complete `interactive-state-chains` contract from the design system. A component is not complete until default, hover, active or selected, focus, disabled or restricted, and stale/invalid states render consistently where applicable.

### Tabs And Segmented Views

Tabs are compact lifecycle controls for Source, Workbench, Plan, Review,
and Export. The shipped treatment is underline-only; active tabs use blue
text plus a blue underline. Labels should be nouns or noun phrases, not
instructions.

Default document tabs are Source, Workbench, Plan, Review, and Export.
Jobs and Artifacts are chips above the lifecycle tabs. Upload appears as a
command surface, not a passive tab, when the project has no documents or
the user has upload intent. Admin-only tabs such as Settings, Members,
MCP, Skills, Terminology, Templates, and Constraints are separated into a
settings area or secondary rail.

Tabs must preserve document/topic selection when switching views. If a tab is disabled by project status or role, show the condition: for example, "Topic Plan requires extracted source blocks" or "Export requires approved topics".

### Panels And Split Workspaces

Panels are the core building block. Each panel has a short title, optional toolbar, and a scrollable content area when needed. Source, Markdown, DITA editor, validation, traceability, agent activity, comments, and export records should remain visually distinct but aligned on the same spacing system.

Do not wrap an entire page section in a floating card and then place panels inside it. The workspace itself is the section.

Panel composition rules:

- Use `filter-bar` above dense lists, queues, and validation triage surfaces.
- Use `detail-inspector` for right-side drawers that inspect one selected document, topic, issue, export, or agent proposal.
- Use `status-strip` for compact aggregate metrics, never for marketing stats.
- Toolbars contain icon-first actions with accessible labels. Icon-only controls require an `aria-label` and a visible tooltip on hover and focus with the same label. Toolbars should not grow into multi-row button walls.
- Panels must declare their empty, loading, restricted, stale, and error states. Never leave an empty white panel without an explanation.

### Forms, Tables, And Empty States

Forms use left-aligned labels, compact inputs, visible validation, and short helper text. Tables use `data-row` density with clear row hover and selected states. Empty states should be quiet and actionable: show what is missing, why it matters, and the next command. Avoid illustration-heavy empty states.

Form rules:

- Label every field explicitly; placeholders are examples, not labels.
- Required fields show required state near the label and validation near the control.
- Long forms are split into sections or drawers with save/cancel anchored in the header or footer.
- Dangerous form changes require confirmation and explain downstream impact.
- Bulk actions show selected count and require clear undo/recovery where possible.

Table rules:

- Use sticky headers for long queues, validation lists, export history, audit events, and activity logs.
- Provide search, filter, sort, column visibility, and pagination or virtualization for large datasets.
- Row actions must be icon-first with accessible labels and overflow for low-frequency actions.
- Empty rows, loading rows, stale rows, and restricted rows have explicit states.

Empty-state rules:

- Explain what is missing, why it matters, and one next action.
- Do not use large illustrations, marketing copy, or decorative placeholders.
- If a user lacks permission, say which permission or role is needed.
- Empty cells, zero, and unknown read differently. An em dash means no value applies. A literal `0` means the count is zero. Italicized `unknown` means the system did not produce a value, and the reason is in the row tooltip. These three are not interchangeable.

### Authentication

Authentication follows the reference sign-in model: one centered card, clear logo, literal title, User ID, Password, Remember user ID, help link, and a primary sign-in action. Keep secondary links below a divider. The auth background uses `background-alt` or a soft branded panel, not plain white. The card is white with `shadows.auth-card`, but it must not include artificial 3D geometry, decorative side slabs, perspective transforms, or large watermark text.

The login card should be visually premium through spacing, typography, border quality, and shadow discipline. The DITAgen generated logo can be used, but if it appears too illustrative at small sizes, use a simplified mark or crop rather than enlarging the entire image.

#### As Implemented (Alpha)

Source: `LoginView` in `apps/web/src/App.tsx` and `.auth-shell`,
`.auth-topbar`, `.auth-main`, `.auth-card`, `.auth-input`, `.auth-submit`
in `apps/web/src/styles.css`.

Differences from the directional spec above (each is a deliberate alpha
choice; revise the directional copy when one of them is reverted):

- **Auth topbar shares the dark-navy bar with the rest of the app.** The
  shipped `.auth-topbar` reuses the same `linear-gradient(180deg,
  var(--topbar-bg-2), var(--topbar-bg))` and 56-px height as
  `.top-app-bar`. This gives the sign-in screen the same enterprise frame
  the user sees after login. The previous direction (translucent white
  bar over the canvas) was tried and rejected because it visually
  disconnected the auth screen from the rest of the product.
- **Auth shell layout is `grid-template-rows: 56px 1fr`.** The topbar
  occupies the first row; everything below is the auth-main region. The
  card centers vertically inside the second row via flexbox
  (`justify-content: center` and `height: 100%`). True vertical center,
  not a 45% anchor.
- **Backdrop is two soft radial gradients, scoped below the topbar.**
  `.auth-shell::before` covers `top: 56px` to the bottom of the viewport
  and layers two low-alpha radial gradients (accent at top-left,
  success at bottom-right). It is `pointer-events: none`. Result: a
  faint "office light" vignette that doesn't reach the topbar.
- **Card geometry**: 420-px width (capped to `100% - 32px`), 40 / 36 / 32
  padding (top / right / bottom — left mirrors right), 1-px
  `var(--border)`, `var(--r-xl)` (14px) radius, `var(--shadow-lg)`. No
  inline `border-color: #dddad3` — the value comes from the palette.
- **Lock chip** (`.auth-lock`): a small 32-px square in the top-right
  corner of the card with the lucide `Lock` icon. Background
  `var(--surface-muted)`, border `var(--border)`, color
  `var(--text-muted)`. It signals security context without crowding the
  title.
- **Logo image** uses the existing `ditagenLogo` asset at 56×56,
  `border-radius: 14px`, `var(--shadow-md)`. The logo is illustrative
  enough at this size; a simplified mark may replace it later.
- **Title** "Sign in to DITAgen" — 22px / 600, `letter-spacing: -0.02em`,
  centered. (The directional spec uses `heading-xl`; the shipped value is
  closer to `heading-lg`. Keeping the smaller size because the centered
  card already has visual weight from the lock chip and logo above.)
- **Field group** uses the standard `.auth-input` row — 38-px tall
  container with leading lucide icon (`Mail` / `Lock`), full-width
  input, and (for the password row) a trailing `.auth-eye` toggle that
  swaps `Eye`/`EyeOff`. Focus-within: border switches to
  `var(--accent)` and the container gains `var(--focus-ring)`.
- **Remember user ID** (`.auth-remember`): inline checkbox + label,
  `accent-color: var(--accent)`, `cursor: pointer`. 12.5px / 500.
- **Primary sign-in** (`.auth-submit`): full-width filled accent button,
  42-px height, `var(--r-md)` radius, `font-weight: 600`. Hover lifts
  `translateY(-0.5px)` and switches to `var(--accent-hover)`. Active
  drops to `var(--accent-pressed)`. Disabled: `opacity: 0.7; cursor:
  progress`. While submitting, the button shows a spinning `RefreshCw`
  icon plus the literal text "Signing in".
- **Divider + secondary links** sit below the form: a 1-px
  `var(--border-subtle)` divider, then a centered grid of help link and
  "New user? Get started" link. Both use `var(--accent)` for color and
  500 weight.
- **Footer**: a flex row with brand mark + version on the left and Privacy
  / Legal links on the right. Color `var(--text-faint)` at 12px.
- **Below 620px**: card padding tightens to 32px / 22px and the auth-main
  reduces to 24-px top padding so mobile keyboards don't push the form
  off-screen.

Authentication background rules:

- The shipped backdrop is a low-alpha radial gradient atmosphere on
  `var(--bg)`. Plain `background-alt` is no longer the default; the
  gradient gives the canvas enough tonal depth that a flat color reads as
  unfinished against the navy topbar.
- A subtle blue-gray top-lightening is folded into the radial; do not add
  a third layer.
- Do not add watermark logos, decorative shapes, marketing illustrations,
  or a promotional side panel.

Authentication responsive behavior:

- Below 480px viewport width, the card uses `calc(100% - 32px)` with 16px side margins and `40px 24px` padding.
- The card never goes edge-to-edge; the surrounding canvas is part of the secure enterprise portal identity.
- On viewports shorter than 700px, the card anchor shifts to 32% so mobile keyboards do not push the form off-screen.

Enterprise authentication states:

- SSO appears as a secondary enterprise option below the primary local sign-in control when enabled.
- MFA, expired password, locked account, session expired, and invite acceptance states reuse the same centered-card pattern.
- MFA challenge uses the same card with the title "Verify your sign-in." Code input uses 6 single-character `auth-code-cell` controls with auto-advance, `mono-md` typography, and 12px between cells.
- Account locked and expired password states keep the same card geometry, replace the form with `status-warning` or `status-danger`, and expose a single primary action such as Reset password or Contact admin.
- SSO-only tenant hides username and password fields entirely and shows a single "Sign in with <provider>" primary action.
- Error messages are specific but do not leak account enumeration details.
- Remembered user ID is opt-in and never stores passwords or tokens visibly.
- Post-login routing goes to the Business Unit Dashboard, Project Hub, or last safe context based on access and session state.
- Step-up authentication is required for sensitive actions such as export to an external connector, changing another user's role, or destructive bulk operations. The prompt opens in place, never as a redirect, and returns the user to the exact action they initiated. Failure shows a clear reason and never silently swallows the action.

### Responsive Behavior

Below tablet width, collapse the rail above the workspace or behind navigation, stack split panels in workflow order, and keep primary actions sticky within the relevant panel header when possible. Text must wrap without overlapping controls. Do not reduce critical code or validation text below `12px`.

Responsive specifics:

- Breakpoints are desktop at `>= 1280px`, tablet at `768-1279px`, and mobile below `768px`. Internal panels may define their own breakpoints; for example, the editor panel switches to single-pane below `720px`. Prefer container queries over viewport queries where supported.
- BU and Project Bento grids become prioritized lists on mobile; severity order is preserved.
- Upload command zone stacks above the health rail and queue; selected document inspector becomes a full-screen drawer.
- Review workspace stacks as topic/source selector, editor, validation/traceability, comments/agent activity.
- Dense tables switch to row cards only when columns would become unreadable; never squeeze identifiers below legibility.
- Sticky primary actions remain close to the active panel, not globally floating over content.
- Keyboard order follows DOM order and visual workflow order: context, filters, primary content, inspector, actions.
- Audit log, validation report, and topic content support a basic print stylesheet: monochrome, no app chrome, and page breaks between topics. DITA ZIP export remains the primary deliverable; print is for ad-hoc compliance review.

## Display Helpers

Small pure functions that turn raw API data into user-facing strings. They
live in `apps/web/src/App.tsx` today; if reuse grows, lift them into a
`format.ts` helper module. Every screen spec that surfaces a value through
one of these helpers links here so the formatting contract is a single
source of truth.

### `initials(name: string): string`

Source: `App.tsx`.

Returns up to two uppercase characters derived from `name`:

- Empty / falsy ⇒ `"—"`.
- One whitespace-separated token ⇒ first two characters of that token,
  uppercased (e.g. `"Compliance"` ⇒ `"CO"`).
- Two or more tokens ⇒ first letter of token 1 + first letter of token 2,
  uppercased (e.g. `"Content Operations"` ⇒ `"CO"`,
  `"Product Enablement"` ⇒ `"PE"`).

Used for owner avatars (`.bu-avatar`). The display contract is purely
illustrative; do not encode permissions or identity in initials alone.

### `relativeTime(value: string | null | undefined): string`

Source: `App.tsx`.

Returns a compact relative timestamp suitable for in-card metadata:

| Diff | Output |
| --- | --- |
| invalid / falsy | `""` (caller must handle empty) |
| < 0 (future) | `"just now"` |
| < 60 s | `"just now"` |
| < 60 min | `"{n}m ago"` |
| < 24 h | `"{n}h ago"` |
| < 30 d | `"{n}d ago"` |
| < 365 d | `"{n}mo ago"` |
| ≥ 365 d | `"{n}y ago"` |

Used for the BU card timestamp (`.bu-card-time`) and any other "last
activity" surface. The output is intentionally short — the precise
timestamp belongs in a tooltip when needed. Render in tabular-nums so
adjacent rows align.

### `humanizeStatus(status: string): string`

Source: `App.tsx`.

Replaces underscores with spaces and Title-cases each word. Used to
render snake_case API states as human-readable labels:

- `"ready_for_review"` ⇒ `"Ready For Review"`
- `"export_ready"` ⇒ `"Export Ready"`
- `"validation_warnings"` ⇒ `"Validation Warnings"`

Use this whenever you would otherwise render a raw API status string in
the UI. The `Required Pipeline Labels` list in the root `DESIGN.md`
remains authoritative for *what* the labels are; this helper governs
*how* they are spelled when the API hands us snake_case.

### `shortId(value: string): string`

Source: `App.tsx`.

Collapses long opaque identifiers (topic IDs, artifact versions) into a
six-character prefix + ellipsis + four-character suffix when they exceed
14 characters:

- `"top_19e058b8568_c4bc647833a8c1"` ⇒ `"top_19…a8c1"`
- `"av_19e058b8565_d04…"` ⇒ `"av_19e…"` (left as-is when ≤ 14)

Used for the topic list (`.topic-button-id`) and any other surface that
shows opaque identifiers in dense rows. Always preserve the full ID in a
`title=` attribute or a copy-affordance — the truncation is purely for
visual density.

### `formatBytes(size: number): string`

Source: `App.tsx`. Returns `"{n} B"`, `"{n.n} KB"`, or `"{n.n} MB"`.
Splits at 1024 boundaries.

Used in BU card storage (when wired), the BU hub context pill ("10.6 KB
storage"), the file summary in the upload dropzone, and the artifact
registry size column. There is no GB threshold yet; alpha datasets stay
below 1 GB.

### `formatConfidence(value: number | null): string`

Source: `App.tsx`. Returns `"unknown"` when the input is `null`,
otherwise `"{round(value * 100)}%"`.

Used for source quality / confidence wherever it is summarized as a
single number. The literal `"unknown"` (not "—" and not "0%") is the
correct empty representation per the global "empty cells, zero, and
unknown read differently" rule. Render in tabular-nums in tabular
contexts.

## Operational Systems

The detailed operating rules for accessibility, dark mode, motion, i18n/RTL, loading and error states, notifications, keyboard shortcuts, command palette, form validation, data tables, diffs, versioning, comments, permission failure, audit logs, confidence visualization, onboarding, concurrency, session resilience, offline behavior, and search live in [`operational-systems.md`](operational-systems.md). Treat that file as required context when changing shared interaction behavior or any component that crosses more than one screen.

## Do's and Don'ts

- Do make source evidence, confidence, validation, and approval state visible in the same workflow where decisions happen.
- Do make the Sign In -> Business Unit Dashboard -> Project Hub -> Document Upload And Ingestion -> Review Workspace -> Export journey explicit in navigation, breadcrumbs, and empty states.
- Do use the exact pipeline labels in this document so uploads, extraction, topic planning, DITA generation, validation, review, approval, and export have consistent language.
- Do use navy for the enterprise frame and blue for primary actions, active tabs, links, focus, and high-emphasis controls.
- Do use red only as a controlled brand accent, announcement color, or critical status, not as the default action color.
- Do place white cards on warm neutral or blue-gray backgrounds so the page does not feel empty or unfinished.
- Do use soft card shadows and clear borders for portal-style tiles, summary cards, and auth cards.
- Do keep panels aligned, dense, and readable with predictable gutters.
- Do use `lucide-react` icons for recognizable tool actions.
- Do pair icon-only controls with both `aria-label` and a visible tooltip on hover/focus.
- Do preserve accessible labels, focus rings, keyboard reachability, and WCAG AA contrast.
- Do make destructive and irreversible actions visually distinct and confirmation-oriented.
- Do publish design tokens as a versioned package consumed by both implementation and the Figma library. Drift between the two is a defect.
- Do treat every screen's loading, empty, restricted, stale, degraded, and error state as part of done. A panel is not implemented until all of these states render correctly.
- Do measure each screen against its five-second scan test in user testing, not just in design review.
- Don't create landing-page heroes, oversized marketing headings, decorative gradients, or ornamental background effects for the product workspace.
- Don't use fake 3D card extrusion, skewed side planes, plastic button bases, perspective gimmicks, or heavy cast slabs.
- Don't use large watermark text or logo ghosts behind auth cards or workspace cards.
- Don't use a plain white page background for auth or portal surfaces.
- Don't let teal dominate the app chrome; keep it limited to the logo or small supporting accents.
- Don't use nested cards or card-heavy layouts for whole page sections.
- Don't invent new semantic colors for local warnings, confidence, validation, or export states.
- Don't collapse document ingestion into a generic "Processing" state; expose the current pipeline stage and next available action.
- Don't introduce a generic visual conversation flow builder as a core DITAgen surface; agent assistance stays bounded to evidence, validation, topic planning, review, export, and admin setup tasks.
- Don't hide low-confidence content behind logs or generic banners.
- Don't use text-only rounded controls when a standard icon button with a tooltip is clearer.
- Don't let editor text, long filenames, topic IDs, or XML paths overflow their containers.
- Don't present agent output as authoritative; always show evidence, confidence, and approval affordances.
- Don't ship a feature without a permission check, keyboard path, empty state, error state, and at least one audit event for any state-changing action.
- Don't introduce a new icon family alongside `lucide-react`. If lucide lacks an exact icon, pick the closest existing icon and document the substitution.
- Don't allow two surfaces to disagree about a record's status. The audit log is the source of truth; dashboards, project hubs, and notification center items read from it.
