# Project Hub Screen Spec

## Status: Retired in Alpha

The Project Hub layer has been removed from the user-facing flow.
Clicking a BU card now opens the
[Upload Hub](screen-upload-ingestion.md) directly. The frontend does not
create, list, select, or name projects. Any hidden grouping required by
services is owned server-side and must not leak into UI copy or
navigation.

Reasons for retirement (recorded so this is not relitigated):

- The alpha needs only one project per BU; a separate selection layer
  added a click without adding clarity.
- Project-level concerns (conversion profile, review policy, quality
  metrics, member assignment) are out of scope for the alpha. When they
  return, they belong in a Settings drawer, not as a list page.
- The "next best action" for almost every BU is to upload more
  documents. Skipping straight to the Upload Hub matches that intent.

The directional content below is preserved only as historical reference.
It is not authoritative for the current alpha.

## As Implemented (Alpha) — preserved for reference

The implementation notes below describe an older shipped direction before
the Project Hub was retired. They should not be used as a target for new
work without first re-introducing a project layer into the product
architecture.

### Layout

```text
┌──────────────────────────────────────────────────────────────────────────┐
│ Top App Bar (full width, dark navy)                                      │
├────┬─────────────────────────────────────────────────────────────────────┤
│ ◇  │ Breadcrumb:  ⌂ Business Units / Documentation Operations           │
│ ▦  │                                                                     │
│ ▤  │ Page Header                                                         │
│ ⌇  │   h1 = BU name ("Documentation Operations")                         │
│    │   description                                                       │
│    │   [role pill] [DITA pill] [storage pill]                            │
│    │   right side: [new project name input + Create] [Refresh]          │
│    │                                                                     │
│    │ Toolbar: [search] ............................. [filter pills]     │
│    │                                                                     │
│    │ Quiet Metrics Strip (Draft / Review Ready / Warnings / Failed /     │
│    │   Export Ready) — borderless, vertically divided                    │
│    │                                                                     │
│    │ Project list surface (one row per project)                          │
│    │                                                                     │
│    │ (selected project) Project Detail panels render below this list     │
└────┴─────────────────────────────────────────────────────────────────────┘
```

The left column is the [icon-only App Nav](components-common.md#app-nav-icon-only-side-rail).
There is no separate "BU Context Bar" — the breadcrumb supplies that
context. There is no Project Rail or Task Rail; insights are inline.

### Breadcrumb

Source: `<nav className="breadcrumb">` in `App.tsx`, `.breadcrumb*`
selectors in `styles.css`.

- Container `.breadcrumb`: flex row, 13px / 500 weight, `var(--text-muted)`.
- **Back button** (`.breadcrumb-back`): inline-flex with leading 14-px
  `Home` icon and the literal text "Business Units". Calls
  `onBackToBusinessUnits` (which maps to `returnToBusinessUnits` in the App
  shell). Hover: `var(--surface-muted)` background + `var(--border-subtle)`
  border, color `var(--text)`.
- **Separator** (`.breadcrumb-sep`): a single literal `/` in
  `var(--text-faint)`, `user-select: none`.
- **Current** (`.breadcrumb-current`): the BU name in `var(--text)` weight
  500. Not interactive.

The breadcrumb is pure navigation. Metadata is no longer mixed in here; it
moved to context pills below the title.

### Page header

Source: `<section className="minimal-header project">`.

- **H1**: the BU name (e.g. "Documentation Operations"), 22–28px
  responsive, `letter-spacing: -0.02em`. The previous "Projects" generic
  title was removed because it created a redundancy with the page-already-
  about-projects context.
- **Description**: short prose under the title (e.g. "{BU name} workspaces,
  source documents, review readiness, and export state.").
- **Context meta** (`.context-meta` containing `.context-pill` chips): three
  short read-only chips below the description. The shipped trio:
  - User's BU role (`summary.current_user_role`, falls back to "restricted")
  - DITA target version (`policy.target_dita_version`)
  - Storage used (`formatBytes(summary.storage_bytes) + " storage"`)

  Pill styling: `var(--surface)` background, `var(--border)`, `var(--r-pill)`
  radius, `padding: 3px 10px`, 11.5px / 500, `letter-spacing: 0.005em`,
  `font-variant-numeric: tabular-nums`. Color `var(--text-secondary)`.

  These pills are read-only at-a-glance metadata. They are *not*
  interactive filters; the filter pills below the toolbar serve that role.

- **Right side actions** (`.minimal-actions`):
  - **Inline create** (`<form className="project-inline-create">`):
    a single text input + a `.btn-primary` Create button (with
    `FolderPlus` icon). Submit handler creates the project and routes the
    selection to it. The form is always visible — there is no separate
    "Create project" wizard for the alpha because creation only requires a
    name; description and conversion profile defaults are filled by the
    backend.
  - **Refresh**: secondary button with `RefreshCw` icon.

### Toolbar

Source: `<section className="minimal-toolbar" aria-label="Project filters">`.

Same primitive as the BU dashboard — a `.filter-search` input with leading
`Search` icon plus `.saved-filters` pill chips on the right. Saved filters
shipped: **All**, **Needs Attention**, **Review Ready**, **Failed**,
**Admin**.

Predicates implemented in `App.tsx`:

| Filter | Predicate |
| --- | --- |
| All | always true |
| Needs Attention | `severity >= 3` (i.e. Review Ready, Validation Warnings, or Failed) |
| Review Ready | `reviewReadyCount > 0` |
| Failed | `failedCount > 0` |
| Admin | `businessUnit.summary.current_user_role === "org_admin"` |

`Assigned To Me` and `Export Ready` are referenced in code paths but are
implemented as aliases of the same predicate set; they aren't visible in
the chip row.

### Quiet metrics strip

Source: `<section className="quiet-metrics">` and the `.quiet-metrics`
selector.

This is the alpha sibling of the BU dashboard's `.metrics-strip`, optimized
for an inline page strip rather than a full panel. Geometry:

- Five-column equal grid (`repeat(5, minmax(110px, 1fr))`).
- Top + bottom hairline (`var(--border)`), no card backgrounds. `padding:
  18px 0`. Each metric cell has 24px horizontal padding and a
  `var(--border-subtle)` right divider.
- Label: 12px uppercase 0.06em tracking, `var(--text-muted)`.
- Value: 22px / 600 / `letter-spacing: -0.02em`, `var(--text)`,
  tabular-nums.

The strip's five cells are computed from per-project rollups:

- **Draft**: count of projects whose status resolves to "Draft" (no docs).
- **Review ready**: sum of `reviewReadyCount` across projects.
- **Warnings**: sum of `validation_issue_count` across documents.
- **Failed**: count of projects with any failed documents.
- **Export ready**: count of projects whose status is `export_ready`.

These metrics do not use tone color — they're informational. Mistakes that
matter (failed, warnings) get the BU-card-style tone treatment in the
project list rows themselves, not in the strip.

### Project list surface

Source: `<section className="minimal-list-surface project-list-surface">`
and the `.minimal-list-row` selector.

A single column of dense rows, one row per project. Geometry:

- Container: 1-px `var(--border)`, `var(--r-lg)` radius, `var(--surface)`
  background, hidden overflow, `var(--shadow-xs)`.
- Header row (`.minimal-list-heading`): 42-px tall,
  `var(--surface-muted)` background, 11px uppercase 0.06em tracking,
  `var(--text-muted)`. Columns: Project / Status / Docs / Topics / Quality /
  (action). The header is hidden below 980px.
- Data rows (`.minimal-list-row`): 68-px min height, 14px / 18px padding,
  hairline top border. Hover background `var(--surface-muted)`. Active row
  has `var(--accent-soft)` background and an inset 3-px accent left rail.

Row content (in order):

1. `.minimal-entity` — leading status dot (`.status-dot.{statusKey}`) with
   tone halo, BU-card-style; project name (h2, 14px / 600); subtitle in
   `var(--text-muted)` 12.5px ("DITA {version} / {review_policy}").
2. `.minimal-status` — short status label ("Review Ready", "Failed",
   "Draft", etc.).
3. `<strong>` — `documentCount`.
4. `<strong>` — `topicCount`.
5. `<span>` — `formatConfidence(avgConfidence)` (e.g. "82%" or "unknown").
6. `.minimal-row-actions` — single button labeled with the project's next
   action (Open workspace / Review topics / Open failures / Open export /
   Upload source). Hover fills with `var(--accent)` and white text.

Status dot color follows the same tone logic as BU cards:
`.status-dot.review-ready`, `.needs-review`, `.validation-warnings` →
`var(--accent)`; `.failed` → `var(--danger)`; `.export-ready` →
`var(--success)`; default → `var(--text-faint)`.

### Project sort order (shipped)

Source: `summarizeProject` and the sort comparator in `ProjectHub`.

```text
severity DESC                          // failed > warnings > review > export > processing > draft
  → lastActivityAt DESC
  → name ASC
```

Severity scoring is fixed in code:

| Status resolves to | severity |
| --- | --- |
| Failed | 5 |
| Validation Warnings | 4 |
| Review Ready | 3 |
| Export Ready | 2 |
| Processing | 1 |
| Draft / Topic Plan Ready | 0 |

### Empty / loading states

Implemented in `ProjectHub` JSX, using `.minimal-empty`:

- **No projects in BU**: shows a `BriefcaseBusiness` icon and
  "Create a project in {BU name} to start upload and ingestion."
- **No projects match filter**: shows the same chrome but with copy
  "No projects match the current filters."

Both states render inside the `.minimal-list-surface` container so the page
doesn't reflow when the result set empties.

### Project Detail (after selecting a row)

When a row is active, the Project Detail block renders **below** the list
on the same scroll surface (no drawer, no navigation). It contains the
upload + activity grid, the document table, the panel tabs, and the active
panel content. The Detail block is documented separately in
[`screen-upload-ingestion.md`](screen-upload-ingestion.md) and
[`screen-review-workspace.md`](screen-review-workspace.md).

### Removed and why

- **BU Context Bar (separate 48-px row above the page header).** The
  breadcrumb already conveys the BU context; the dedicated bar inflated
  vertical chrome without adding scan value.
- **Bento priority project tiles (3/4/6-column spans).** Replaced by a
  single uniform list. Severity now lives in the row's status dot, status
  text, and the next-action button text. The tradeoff: less visual drama
  on small project sets; better legibility on large ones.
- **Project Rail and Task Rail** (left and right rails). Out of scope for
  alpha. Insights live inline in the metrics strip and per-row dot.
- **Pipeline snapshot bar inside the project row.** The shipped row uses
  the same data points as the BU card pipeline mini-bar but renders them as
  status text and counts; the bar can return for v2 once we have wider
  rows.
- **Default subtitle "1.3 profile / active".** Removed (was
  jargon-heavy). The conversion profile lives in the row subtitle as
  "DITA {version} / {review_policy}", which uses words instead of profile
  IDs.

## Project Hub

The Project Hub must answer three questions quickly: which project should I open, what state is it in, and what is the next useful action?

Recommended overall layout:

```text
+--------------------------------------------------------------------------------+
| Global App Bar: DITAgen | global search | tasks | help | notifications | user  |
+--------------------------------------------------------------------------------+
| BU Context Bar: Home / Business Unit | BU status | members | policy | settings |
+--------------------------------------------------------------------------------+
| Project Header: Projects | create project | import | date range | refresh | view |
+--------------------------------------------------------------------------------+
| Filter Bar: search project/document/topic | All | Favorites | Needs Review      |
|             status | owner | profile | language | sensitivity | sort | filters |
+----------------------+-----------------------------------------+----------------+
| Project Rail         | Project Portfolio Status Strip          | Task Rail      |
| - Favorite projects  | Draft | Processing | Review Ready       | My Reviews     |
| - Recently opened    | Warnings | Failed | Approved | Export   | Failed Jobs    |
| - Templates/profiles +-----------------------------------------+ Exports Ready  |
| - Archived projects  | Priority Project Lane                   | Agent Actions  |
|                      | [6-col blocked project] [3-col export]  | Access/Policy  |
|                      | [3-col review backlog]                  |                |
|                      +-----------------------------------------+                |
|                      | Bento Project Grid                      |                |
|                      | [4-col project] [4-col project] [4-col] |                |
|                      | [6-col project] [3-col] [3-col]         |                |
|                      | [4-col project] [4-col project] [4-col] |                |
|                      +-----------------------------------------+                |
|                      | Optional Project Table for large BUs     |                |
+----------------------+-----------------------------------------+----------------+
```

Layout zones:

- **BU Context Bar:** Keeps the selected BU visible and shows BU status, member count, user's BU role, active policy set, and settings access for authorized users. It includes the breadcrumb back to the BU dashboard.
- **Project Header:** Shows the project count, create/import actions, refresh state, date range, and grid/table toggle. `Create Project` is primary only when the BU has no urgent work; otherwise it becomes secondary.
- **Filter Bar:** Supports project name, document filename, topic title, owner, conversion profile, language, sensitivity, status, source type, and "needs attention" filters. Filters persist within the BU.
- **Project Rail:** Shows favorites, recently opened projects, templates/conversion profiles, archived projects, and quick links to BU-level settings. It is navigation, not a second metrics dashboard.
- **Project Portfolio Status Strip:** Shows counts for draft, processing, review ready, validation warnings, failed, approved, and export ready projects. Each status card acts as a filter shortcut.
- **Priority Project Lane:** Surfaces the top two or three projects needing action. This lane prevents urgent work from being buried inside a large grid.
- **Bento Project Grid:** The main project-selection surface. Tiles represent projects and are sized by operational priority.
- **Task Rail:** A user-specific queue for assigned reviews, failed project jobs, export-ready packages, agent approval requests, access/policy tasks, and recent project activity.
- **Project Table View:** Required once a BU has many projects or when users need bulk comparison. The table uses dense rows with sortable status, owner, last activity, document count, review count, and export state.

Locked layout dimensions:

- **Workspace grid:** Use the same 12-column grid as the BU Dashboard after subtracting 24px shell padding on each side. Column and row gutters are both 16px.
- **Global App Bar:** 64px tall, full width, `primary` background, fixed at top, and above rails with layout z-index 30.
- **BU Context Bar:** 48px tall, `bu-context-bar`, `primary-container` background, breadcrumb on the left, and BU policy chips on the right. It is the constant breadcrumb back to the BU Dashboard and should read as "inside a BU" without competing with the Project Header.
- **Project Header:** 88px tall, canvas background, and 24px top/bottom padding. It contains project count, create/import actions, date range, refresh control, and grid/table view toggle.
- **Filter Bar:** 52px tall, `surface`, 24px gap above and below, sticky after the Project Header scrolls away.
- **Content Area:** Three-column flex layout with 16px inter-column gaps: 220px Project Rail, flexible main column, and 260px Task Rail.
- **Status Strip:** 72px tall `status-strip` with equal-width status cards. Status cards act as filters and keep the same visual scale as the BU Dashboard.
- **Priority Project Lane:** Auto-height 12-column grid for two or three projects needing action. Priority projects span 6 columns with 220px minimum height.
- **Bento Project Grid:** 12-column grid. Default project tiles span 3 columns with 136px minimum height; active project tiles may span 4 columns; priority projects span 6 columns. Row and column gaps are 16px.

Sticky behavior:

- Global app bar is fixed at top with layout z-index 30.
- BU Context Bar scrolls normally with the page; it is persistent by repetition in breadcrumbs, not by stickiness.
- Filter bar becomes sticky after the user scrolls past the Project Header. When stuck, it gains a 1px bottom outline and a soft 4px shadow.
- Status strip is not sticky.
- Project Rail and Task Rail scroll with the page on normal desktop. On tall screens above 1080px, only the Task Rail becomes sticky.

Project tile sizing:

- **6-column priority tile:** Use for one or two projects with failed ingestion, blocking validation, high review backlog, export-ready packages, active customer deadline, quota/cost risk, or executive importance.
- **4-column active tile:** Use for active conversion projects with ongoing upload, extraction, review, or export work when the project needs more scan space than a default tile.
- **3-column standard tile:** Default tile size for draft, idle, low-volume, or stable projects.
- **2-column alert tile:** Use inside the task rail or status strip for narrow alerts, not as the main project representation.

Project tile anatomy:

- **Header:** Project name, favorite star, owner/team, current user role, and overflow menu.
- **Profile line:** Conversion profile, DITA version, language coverage, review policy, and sensitivity classification.
- **Dominant state:** One clear badge: draft, processing, review ready, validation warnings, failed, approved, export ready, or archived.
- **Pipeline snapshot:** Compact distribution of documents across `Queued`, `Extraction In Progress`, `Topic Plan Ready`, `Review Ready`, `Approved`, `Export Ready`, and `Failed`.
- **Work metrics:** Document count, generated topic count, review assignments, validation blockers, failed jobs, exports ready.
- **Quality metrics:** Average source confidence, low-confidence OCR blocks, validation warning count, approval rate, edit-distance signal when available.
- **Operational metrics:** Last upload, last activity, active reviewers, monthly LLM/OCR cost, storage usage, and scheduled retention date when available.
- **Primary action:** Opens the project to the next best screen: upload when empty, pipeline when processing, topic plan when ready, review when assigned, export when ready, or failure detail when blocked.
- **Secondary actions:** Create upload, view activity, manage members, settings, duplicate/archive. Keep these in an overflow menu unless they are the next required action.

Default 3-column project tile layout:

- Use 20px padding from `spacing.xl`.
- Header row contains project name in `title-md`, favorite icon, and overflow icon. Profile line appears below in `body-sm` with `neutral-700` and includes conversion profile, DITA version, and language.
- Status badge appears 12px below the header and uses `label-md`.
- Pipeline snapshot appears 8px below the badge as a full-width `pipeline-snapshot-bar`, 40px tall. It uses color-coded stacked segments by pipeline state; exact counts appear in tooltips instead of visible count badges.
- Bottom row appears 16px below the pipeline snapshot with a divider above. It contains the next best primary action on the left and a right-aligned timestamp in `body-sm`.

Pipeline snapshot rule:

- Use the stacked bar instead of individual numeric badges at 3-column width. Six or more numeric counts cannot fit legibly in a compact tile; the bar gives an immediate state ratio and exposes counts on hover/focus.

Project priority scoring:

- Failed stages and blocking validation outrank all other states.
- Assigned reviews and review-ready work outrank passive processing.
- Export-ready projects outrank idle approved projects.
- Customer deadlines and explicit pinning can raise priority within the same severity group.
- Recent activity can raise visibility but must not outrank a blocker.
- Favorites improve placement within a status group, not above operational risk.
- Archived projects are hidden by default unless the filter includes them.

Interactions:

- Clicking a project tile opens the next best project workspace, not a generic project overview if a more specific action is pending.
- `Enter` and `Space` activate the focused tile; overflow menu actions are separately reachable.
- Status strip cards filter the grid without resetting search.
- The grid/table toggle preserves filters, sort, scroll position where practical, and selected project context.
- Task rail items route to a project with the relevant panel and filter already applied.
- Create/import actions open a wizard or drawer; they must not navigate away and lose current filters.
- Pinned/favorite projects remain visible but do not hide urgent non-favorite work.

Search, filters, and sorting:

- Search matches project name, owner, document filename, topic title, artifact ID, source hash prefix, and known abbreviations.
- Saved filters include `All`, `Favorites`, `Needs Attention`, `Assigned To Me`, `Review Ready`, `Export Ready`, `Failed`, `Archived`, and `Admin`.
- Default sort is severity first, assigned-to-me, deadline, favorites, recent activity, then project name.
- Admins can switch to storage, cost, member count, policy, retention, or template/profile sorting.
- Empty filter results show why nothing matched and provide reset, broaden search, or include archived actions.

States:

- **Loading:** Use skeleton project tiles preserving the Bento geometry and status-strip placeholders.
- **Empty BU:** Show one focused `Create Project` action, recommended conversion profiles, and a brief explanation of what a project contains.
- **Draft project:** Surface setup progress: profile, languages, constraints, reviewers, first upload.
- **Restricted project:** Show project name, owner, role reason, and request-access action when policy allows it; do not leak document or topic details.
- **Degraded metrics:** Keep project tiles navigable when analytics fail; show `status-warning` for stale metrics and preserve last-known status.
- **Archived project:** Use muted treatment, remove from default grid, and expose restore only to authorized roles.

Adversarial review and countermeasures:

- **Failure mode: The Project Hub duplicates the BU Dashboard.** Countermeasure: BU Dashboard compares BUs; Project Hub compares projects inside one BU and exposes project-specific actions, profiles, documents, topics, review, export, and policy details.
- **Failure mode: Bento sizing becomes decorative and arbitrary.** Countermeasure: tile span must come from explicit priority scoring. If data cannot justify a larger span, use the standard 4-column tile.
- **Failure mode: Large BUs become unusable because cards do not scale.** Countermeasure: table view is mandatory for many projects, saved filters are required, and search must match project, document, topic, and artifact identifiers.
- **Failure mode: The primary action is ambiguous.** Countermeasure: every project tile computes one next best action from pipeline state and user role.
- **Failure mode: The hub leaks sensitive project metadata.** Countermeasure: restricted tiles show only safe metadata and access rationale; document names, topic titles, cost, and quality signals require read permission.
- **Failure mode: Users miss urgent work because favorites dominate.** Countermeasure: favorites only reorder within severity groups; blockers always outrank favorites.
- **Failure mode: Metrics look authoritative when they are stale.** Countermeasure: status strip and tiles show last refresh time, stale metric badges, and degraded state.
- **Failure mode: Admin controls crowd operational work.** Countermeasure: admin actions live in the rail, overflow, settings drawer, or admin views. The main grid stays focused on choosing and opening projects.
- **Failure mode: The layout collapses poorly on mobile.** Countermeasure: mobile becomes a prioritized list with the same severity order and next action; do not preserve the desktop grid at unreadable widths.
- **Failure mode: Agent actions look like autonomous execution.** Countermeasure: agent approval requests appear as tasks with evidence, cost, citations, and reversible diff; they do not mutate project artifacts directly.

Five-second scan test:

- The user can identify which projects need attention.
- The user can identify whether the work is upload, extraction, topic planning, review, validation, export, access, or policy.
- The user can identify their assigned reviews or approvals.
- The user can identify blocked projects and why they are blocked.
- The user can open the next best project action without interpreting raw logs.

Responsive behavior:

- 1600px and above: full desktop layout with 220px Project Rail, flexible main column, and 260px Task Rail.
- 1280-1599px: Task Rail collapses to 220px and project tiles compress proportionally.
- 1024-1279px: Project Rail collapses behind a hamburger toggle, and the main column expands.
- 768-1023px: Task Rail collapses behind an aside panel toggle in the Project Header.
- Below 768px: status strip becomes a 2-row, 3-column grid; project tiles become a single-column severity-ordered list; both rails collapse.
