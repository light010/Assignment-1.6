# Business Unit Dashboard Screen Spec

This spec describes the Business Unit (BU) dashboard as currently shipped in
`apps/web/src/App.tsx` (component `BusinessUnitDashboard`, card `BusinessUnitCard`)
and `apps/web/src/styles.css` (selectors `.bu-grid`, `.bu-card`, `.bu-card-delete`,
`.bu-card-pipeline`, `.metrics-strip`, `.metric-card`, `.minimal-toolbar`,
`.minimal-header`).

It supersedes the prior Bento priority-tile direction. The team explicitly
chose equal-sized cards over heuristic-sized Bento tiles, and a quiet single
column over a two-column layout with a right rail. The principles that survive
from the previous direction are restated here; the geometry has changed.

## Purpose

The BU dashboard is the first authenticated screen for users who can access
multiple business units. It is a portfolio entry point, not a marketing
landing. Users come here to:

- Pick a BU and open its document Upload Hub.
- Triage portfolio-wide signal counts (review ready, warnings, failed,
  export ready, storage).
- Filter to BUs that need attention.
- Create a new BU (admin only).
- Delete a BU they own (admin only).

The grid is the BU switcher. The global app bar does not duplicate BU
selection on this screen.

## Layout

```text
┌──────────────────────────────────────────────────────────────────────────┐
│ Top App Bar (full width, dark navy, sticky)                              │
├────┬─────────────────────────────────────────────────────────────────────┤
│    │ Page Header                                                         │
│ ◇  │   eyebrow pill • h1 "Business Units" • description                  │
│ ▦  │   right side: [+ Add Business Unit] (admin) [↻ Refresh]            │
│ ▤  │                                                                     │
│ ⌇  │ Metrics Strip (5 cards: Review ready / Warnings / Failed / Export   │
│    │   ready / Storage) — full width                                     │
│    │                                                                     │
│    │ Inline Create Panel (shown only when "Add Business Unit" is open)   │
│    │                                                                     │
│    │ Toolbar: [search] ............................. [filter pills]     │
│    │                                                                     │
│ ⚙  │ BU Grid                                                             │
│ ?  │   repeat(auto-fill, minmax(300px, 1fr)) with 14px gap              │
└────┴─────────────────────────────────────────────────────────────────────┘
```

The left column is the [icon-only App Nav](components-common.md#app-nav-icon-only-side-rail).
On viewports ≥ 980px it is 64px wide; below 980px it narrows to 56px.

The page content area is centered with `max-width: 1320px` and 32px horizontal
padding (28px on tablet, 20px on mobile). All content stacks vertically; there
is no right rail on this screen.

## Header

Source: `App.tsx` BusinessUnitDashboard JSX, `.minimal-header` in styles.css.

This page header carries no static-config chips per the
[chips encode state, not config](../../DESIGN.md#1-chips-next-to-the-h1-encode-state-not-config)
rule. The eyebrow ("DITAgen Local · Admin") qualifies because the
"Admin" segment changes per user; everything else (DITA target,
storage, retention) lives in Settings.

- **Eyebrow pill** (`.eyebrow`, `.eyebrow-dot`): a small pill with a green
  status dot showing tenant context and the user's role label, e.g.
  `● DITAgen Local · Admin`. Pill: `var(--surface)` background, `var(--border)`
  border, 11px uppercase 0.04em tracking, `var(--shadow-xs)`. The dot is 6px,
  `var(--success)` background, with a soft 3px halo via `box-shadow`.
- **Title**: H1 "Business Units" at 26–28px, `letter-spacing: -0.02em`,
  `font-weight: 600`. Color `var(--text)`.
- **Description**: secondary copy below the title in `var(--text-muted)` at
  13–14px. Live count: `{N} accessible portfolios for document conversion,
  review, and export.`

Right-side actions:

- **Add Business Unit** (admin only): primary indigo button with `Plus` icon
  in default state and `X` icon when toggled (label flips to "Cancel"). Class
  `.btn-primary`. Toggling reveals the inline create form below the metrics
  strip.
- **Refresh**: secondary button with `RefreshCw` icon. Spins while
  `loading === true`.

## Metrics Strip

Source: `<section className="metrics-strip">` and `.metric-card` selectors.

Five cards in a `repeat(5, minmax(0, 1fr))` grid with 12px gap. Cards are
`var(--surface)` with 1px `var(--border)`, `min-height: 78px`, `padding:
16px 18px`, `border-radius: var(--r-md)`, `box-shadow: var(--shadow-xs)`.

| Card | Source value | Tone |
| --- | --- | --- |
| Review ready | `Σ summary.review_ready_count` | neutral |
| Warnings | `Σ summary.validation_warning_count` | `warning` if > 0 |
| Failed jobs | `Σ summary.failed_job_count` | `danger` if > 0 |
| Export ready | `Σ summary.export_ready_count` | neutral |
| Storage | `formatBytes(Σ summary.storage_bytes)` | neutral |

Tone swaps the border to `var(--warn-border)` or `var(--danger-border)` and
the value color to `var(--warn-text)` or `var(--danger-text)`. Neutral cards
keep the standard border and text color.

**Responsive**: 5-col → 3-col at `max-width: 1100px` → 2-col at
`max-width: 640px`.

The metric values are tabular-nums (`font-variant-numeric: tabular-nums`) and
26px when neutral. Labels are 11.5px uppercase 0.06em tracking,
`var(--text-muted)`.

## Inline Create Panel

Source: `<form className="inline-create-panel">`. Only rendered when
`isAdmin && createOpen`.

- Container: 1px `var(--accent-soft-border)` border, `border-radius:
  var(--r-lg)`, soft gradient background
  `linear-gradient(180deg, var(--accent-soft), var(--surface))`,
  `box-shadow: var(--shadow-sm)`, padding 20px.
- Header: H2 "New business unit" with copy "Define ownership and region. You
  can configure conversion policy later."
- Fields: 3-column grid (Name / Owner team / Region), each with a 12px
  weight-500 label and a standard input. Name is `required`. Below 980px the
  fields stack to single column.
- Actions: right-aligned. Cancel (`<button>`), then Create business unit
  (primary indigo, with `Building2` icon).

## Toolbar

Source: `<section className="minimal-toolbar">`. Implements the
canonical
[Index List + Search / Sort / Filter Toolbar](components-common.md#index-list--search--sort--filter-toolbar)
pattern.

Two-column grid: search (left, fixed width range) and filter pills (right,
`flex-wrap`).

- **Search input** (`.filter-search`): 36-px tall pill with leading
  `Search` icon. Background `var(--surface-muted)` by default, switches to
  `var(--surface)` plus `var(--focus-ring)` on focus-within. Filters on BU
  name, owner team, region, description.
- **Saved filters** (`.saved-filters button`): pill chips for `All`,
  `Needs Attention`, `Review Ready`, `Failed`, `Admin`. Active chip:
  `var(--surface)` background, `var(--border)` border, `var(--shadow-xs)`.
  Inactive: transparent, `var(--text-muted)`.

Filter semantics (current implementation):

| Filter | Predicate |
| --- | --- |
| All | no filter |
| Needs Attention | `dominant_status_label ∈ {Failed, Validation Warnings, Needs Review}` |
| Review Ready | `summary.review_ready_count > 0` |
| Failed | `summary.failed_job_count > 0` |
| Admin | `summary.current_user_role === "org_admin"` |

Sort order is fixed: severity score (descending), then `document_count`
(descending), then `name` ascending. `businessUnitSeverity` returns 5 for
failed, 4 for warnings, 3 for review-ready, 2 for export-ready, 1 for
processing, 0 otherwise.

## BU Grid

Source: `<section className="bu-grid">`, `.bu-grid` and `.bu-card` selectors.

Grid: `display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 14px`.

Cards are equal-sized — there is no priority span. The data priority that
existed in the previous Bento-tile direction is now expressed entirely
through (a) sort order, (b) the 4-px colored status edge on the left of the
card, and (c) the meta text in the card footer.

### BU Card Anatomy

```text
┌───┬────────────────────────────────────────────────────────┐
│ ▎ │ [Avatar] Owner Team           [Status pill]      [🗑]  │
│ ▎ │          REGION                                        │
│ ▎ │                                                        │
│ ▎ │ Documentation Operations                               │
│ ▎ │ Primary documentation conversion portfolio.            │
│ ▎ │ ──────────────────────────────────────────────────────│
│ ▎ │ PROJECTS    DOCUMENTS    QUALITY                       │
│ ▎ │   1            1           82%                         │
│ ▎ │ ──────────────────────────────────────────────────────│
│ ▎ │ ████████████████████░░░░░░░░░░░░░░░░░░░░ pipeline bar  │
│ ▎ │                                                        │
│ ▎ │ ● 1 ready for review                       11h ago    │
└───┴────────────────────────────────────────────────────────┘
```

The thick left bar (`▎`) is the **status edge** — a 4-px colored bar from
`top: 0` to `bottom: 0` rendered via `.bu-card::before`. It widens to 5px on
hover.

**DOM and class structure** (from `App.tsx` BusinessUnitCard):

```html
<article class="bu-card tone-{tone}{is-empty?}" role="button" tabindex="0">
  <button class="bu-card-delete">🗑</button>      <!-- admin + onDelete only -->
  <header class="bu-card-head">
    <div class="bu-card-owner">
      <span class="bu-avatar tone-{tone}">CO</span>
      <div class="bu-card-owner-text">
        <span class="bu-card-owner-team">Content Operations</span>
        <span class="bu-card-owner-region">NORTH AMERICA</span>
      </div>
    </div>
    <span class="bu-card-status {statusKey}">Needs Review</span>
  </header>
  <h2 class="bu-card-name">Documentation Operations</h2>
  <p class="bu-card-description">…</p>           <!-- only if description -->
  <dl class="bu-card-stats">
    <div><dt>Documents</dt><dd>1</dd></div>
    <div><dt>Review</dt><dd>1</dd></div>
    <div><dt>Quality</dt><dd>82%</dd></div>
  </dl>
  <div class="bu-card-pipeline">…</div>          <!-- only if pipeline.total > 0 -->
  <footer class="bu-card-foot">
    <span class="bu-card-meta">1 ready for review</span>
    <span class="bu-card-time">11h ago</span>    <!-- only if last_activity_at -->
  </footer>
</article>
```

Notes:
- The card is an `<article role="button" tabindex="0">` rather than a
  `<button>` because it contains a nested delete `<button>` and nested
  interactive elements would be invalid HTML. Enter and Space are mapped to
  the click handler in `onKeyDown`.
- The delete button is rendered only when an `onDelete` prop is passed, which
  the dashboard provides only when `isAdmin === true`.

### Card geometry and rhythm

| Property | Value | Source |
| --- | --- | --- |
| Layout | `flex`, `flex-direction: column`, `gap: 14px` | `.bu-card` |
| Padding | `18px 20px 16px 24px` (extra left for status edge) | `.bu-card` |
| Min-height | `232px` | `.bu-card` |
| Border | `1px solid var(--border)` + 4-px colored edge | `.bu-card`, `.bu-card::before` |
| Radius | `var(--r-lg)` (10px) | `.bu-card` |
| Background | `linear-gradient(180deg, var(--surface), var(--surface-tint))` | `.bu-card` |
| Shadow (rest) | `var(--shadow-xs)` | `.bu-card` |
| Shadow (hover) | `var(--shadow-md)` | `.bu-card:hover` |
| Lift on hover | `translateY(-2px)` | `.bu-card:hover` |
| Edge widens to | `5px` on hover | `.bu-card:hover::before` |
| Glow on hover | radial accent-soft glow at top-right | `.bu-card::after` |
| Footer placement | `margin-top: auto` so footer always sits at the bottom | `.bu-card-foot` |

### Tone selection (`pickTone`)

Function: `pickTone(status, summary)` in `App.tsx`. Priority order:

1. `danger` if `status === "Failed"` or `summary.failed_job_count > 0`
2. `warning` if `status === "Validation Warnings"` or
   `summary.validation_warning_count > 0`
3. `info` if `status === "Review Ready"` / `"Needs Review"` or
   `summary.review_ready_count > 0`
4. `success` if `status === "Export Ready"` or
   `summary.export_ready_count > 0`
5. `processing` if `summary.processing_count > 0`
6. `neutral` otherwise

Tone drives the status-edge color, the avatar tint, and the meta dot color:

| Tone | Edge & meta dot | Avatar bg / border |
| --- | --- | --- |
| `danger` | `var(--danger)` | `var(--danger-bg)` / `var(--danger-border)` |
| `warning` | `var(--warn-strong)` | `var(--warn-bg)` / `var(--warn-border)` |
| `info` | `var(--accent)` | `var(--accent-soft)` / `var(--accent-soft-border)` |
| `success` | `var(--success)` | `var(--success-bg)` / `var(--success-border)` |
| `processing` | `var(--accent)` (linear gradient on edge; meta dot pulses) | `var(--accent-soft)` |
| `neutral` | `var(--border-strong)` | `var(--surface-sunken)` / `var(--border)` |

The processing tone animates the status edge and meta dot via `@keyframes
edgePulse` (2.4s for the edge, 1.6s for the dot).

### Owner cluster

- **Avatar** (`.bu-avatar`): 34×34 circle with team initials (first letter of
  the first two whitespace-separated tokens of `owner_team`, falling back to
  `—`). Background uses a tone-tinted color with a subtle inner highlight
  via `linear-gradient(135deg, rgba(255,255,255,0.55), transparent 60%)`.
  Border 1px in the matching tone color. Scales to `1.06×` on card hover.
- **Owner text** (`.bu-card-owner-text`): two-line block.
  - **Team** (`.bu-card-owner-team`): 12.5px / 600. Wraps to a maximum of
    2 lines via `-webkit-line-clamp: 2`. No truncation with ellipsis on this
    line; long team names wrap.
  - **Region** (`.bu-card-owner-region`): 10.5px / 500 uppercase 0.05em
    tracking, single line with ellipsis. Falls back to `Global`.

### Status pill

Class `.bu-card-status.{statusKey}` where `statusKey =
status.toLowerCase().replace(/\s+/g, "-")`. Pill: `min-height: 22px`,
`padding: 0 10px`, `var(--r-pill)` radius, leading 6-px colored dot.

| Status label | Class suffix | Pill colors |
| --- | --- | --- |
| Failed | `.failed` | `var(--danger-bg)` / `var(--danger-text)` / `var(--danger-border)` |
| Validation Warnings | `.validation-warnings` | `var(--warn-bg)` / `var(--warn-text)` / `var(--warn-border)` |
| Review Ready, Needs Review | `.review-ready`, `.needs-review` | `var(--info-bg)` / `var(--info-text)` / `var(--accent-soft-border)` |
| Export Ready | `.export-ready` | `var(--success-bg)` / `var(--success-text)` / `var(--success-border)` |
| Idle / other | (no extra class) | `var(--surface-muted)` / `var(--text-muted)` / `var(--border)` |

### BU name and description

- **Name** (`.bu-card-name`): 17px / 600, `letter-spacing: -0.015em`, max
  2 lines via `-webkit-line-clamp`.
- **Description** (`.bu-card-description`): 12.5px / muted color, max 2
  lines. Rendered only when `businessUnit.description` is truthy.

### Stats grid

`.bu-card-stats` is a `<dl>` with three `<div>` items: Documents, Review,
Quality. Layout: 3-col grid, top and bottom hairlines (`var(--border-subtle)`).

- `dt`: 10.5px uppercase 0.04em tracking, `var(--text-muted)`.
- `dd`: 19px / 600, `letter-spacing: -0.02em`, tabular-nums.
- Quality is rendered via `formatConfidence(summary.avg_source_confidence)`,
  which returns either `"unknown"` or `"{round(value*100)}%"`.

On card hover, each stat translates `translateY(-1px)` for a subtle parallax.

### Pipeline mini-bar

Function: `pipelineSegments(summary)` in `App.tsx`. The bar appears only when
the sum of pipeline counts is > 0. Empty BUs (zero data) skip the bar
entirely; this is the explicit replacement for the old "Get started" pseudo-
card and "Open →" CTA.

The bar (`.bu-card-pipeline`) is 8px tall with a 1-px subtle border and
`var(--surface-sunken)` background. It contains up to five segments shown only
when their count is > 0. Each segment uses `flex-grow: count` so the visual
proportion equals the data proportion. Segment classes and colors:

| Class | Source value | Color |
| --- | --- | --- |
| `.pipeline-seg.failed` | `summary.failed_job_count` | `var(--danger)` |
| `.pipeline-seg.warnings` | `summary.validation_warning_count` | `var(--warn-strong)` |
| `.pipeline-seg.review` | `summary.review_ready_count` | `var(--accent)` |
| `.pipeline-seg.processing` | `summary.processing_count` | `var(--text-muted)` |
| `.pipeline-seg.export` | `summary.export_ready_count` | `var(--success)` |

Each segment has a `title=` tooltip with `"{Label}: {value}"` for keyboard
and screen-reader inspection. On hover the segment brightens via
`filter: brightness(1.1)`.

### Footer

`.bu-card-foot` uses `margin-top: auto` so it sits at the bottom of the card
regardless of how much pipeline / description content is present.

Two children:

- **Meta** (`.bu-card-meta`): 12.5px / 500 with a leading 7-px tone-colored
  dot. The text is selected by priority (first match wins):
  1. `"{N} processing"` if `processing_count > 0`
  2. `"{N} ready for review"` if `review_ready_count > 0`
  3. `"{N} failed"` if `failed_job_count > 0`
  4. `"{N} export ready"` if `export_ready_count > 0`
  5. `"No documents yet"` if the BU is empty
  6. `"All quiet"` otherwise
- **Time** (`.bu-card-time`): relative timestamp such as `11h ago` produced
  by the `relativeTime(summary.last_activity_at)` helper. Rendered only when
  the value parses to a valid date. Uses tabular-nums and `var(--text-faint)`.

There is no "Open →" CTA. The card itself is the affordance: the entire
article is keyboard-focusable, `Enter` / `Space` activates it, and `cursor:
pointer` plus the hover lift signal interactivity. This is a deliberate
removal — see "Removed and why" below.

### Delete affordance

Class `.bu-card-delete`, lucide `Trash2` icon at `size={14}`. Source:
`BusinessUnitCard` JSX (only rendered when `onDelete` is passed) and
`App.tsx` `handleDeleteBusinessUnit`.

| Property | Default | Hover | Active | Focus |
| --- | --- | --- | --- | --- |
| Icon color | `var(--danger)` | `var(--accent-on)` | `var(--accent-on)` | `var(--danger)` |
| Background | `var(--danger-bg)` | `var(--danger)` | `var(--danger-pressed)` | `var(--danger-bg)` |
| Border | `var(--danger-border)` | `var(--danger)` | `var(--danger-pressed)` | `var(--danger)` |
| Shadow | none | `0 4px 10px rgba(196,51,42,.24)` | none | `0 0 0 3px rgba(196,51,42,.22)` |

Visibility:

- Default: `opacity: 0`, `transform: translateY(-2px)`, `pointer-events: none`.
- On `.bu-card:hover` or `.bu-card:focus-within`: `opacity: 1`,
  `translateY(0)`, `pointer-events: auto`.
- On its own `:focus-visible`: same — opacity 1 and pointer events on, so
  keyboard users always reach it.

Behavior:

- `onClick` calls `event.stopPropagation()` so the card click handler does
  not fire.
- The handler shows a `window.confirm` with the literal message:
  `Delete the business unit "{name}"? This will remove its documents and
  history. This cannot be undone.`
- On confirmation, calls `deleteBusinessUnit(business_unit_id)` from
  `api.ts` (HTTP `DELETE /v1/business-units/{id}`).
- If the deleted BU is the currently active one, the app routes back to the
  BU list via `returnToBusinessUnits()`.
- After the call resolves, `refreshBusinessUnits()` re-fetches the list.
- Errors surface in the page-level error banner via `setError`.

Position: `position: absolute; top: 10px; right: 10px; width: 28px;
height: 28px; z-index: 3`. It does not displace the status pill which sits
within the head row in normal flow.

This affordance is admin-only; non-admin users do not see the icon at all.

### Empty BU state

When `summary.document_count === 0`, the card gets the `is-empty` modifier
class. The current implementation:

- Hides the pipeline mini-bar (no data to summarize).
- Sets the meta text to `"No documents yet"`.
- Keeps the rest of the card identical so empty BUs are still browseable.

There is no separate inline CTA card-within-card. The card itself is the CTA;
clicking it opens the BU's Upload Hub where the user can upload the first
document.

## States

| Page state | Source | Treatment |
| --- | --- | --- |
| Loading | `loading === true` | `<div class="empty-card">Loading business units…</div>` |
| Empty (no filter match) | `filteredBusinessUnits.length === 0` | `.empty-card` with `Building2` icon, copy "No business units match the current filters.", and a `Reset filters` button that sets the filter to `All`. |
| Error | non-empty `error` | `.error-banner` rendered above the grid (`background: var(--danger-bg)`, text `var(--danger-text)`, border `var(--danger-border)`). |
| Busy (post-action) | `busy === true` | Page-level pending; affected actions (Add BU, Refresh) disable themselves. |
| Restricted | `current_user_role === null` | The BU still appears with its data, but the delete affordance is not rendered (admin-only). |

## Interactions

- **Open**: clicking a card or pressing Enter / Space on it calls
  `onSelectBusinessUnit(business_unit_id)`, which routes to the
  [Upload Hub](screen-upload-ingestion.md) for that BU. The previous
  Project Hub layer between the dashboard and the Upload Hub is retired
  in alpha.
- **Filter shortcuts**: status totals in the metrics strip do not currently
  filter the grid. Filter pills do.
- **Add BU**: opens the inline create panel below the metrics strip. The
  primary action button toggles label between "Add Business Unit" and
  "Cancel" with matching `Plus`/`X` icons.
- **Delete BU**: hover or focus-within reveals the trash button. Click ⇒
  confirm dialog ⇒ DELETE call ⇒ list refresh.
- **Refresh**: re-fetches the list. The icon spins while loading.

## Five-second scan test

A new user landing on this screen should be able to answer, in five seconds:

1. Which BUs do I have access to?
2. Which BU needs attention first? (look for danger / warning status pills,
   tone-colored edges, and the meta dot at the bottom of cards)
3. What kind of work is waiting? (review ready vs. warnings vs. failed,
   surfaced both in the metrics strip and per-card meta)
4. When did each BU last move? (relative timestamp in the card footer)
5. What is the next action? (open a card, or use the Add BU / Refresh
   actions in the header)

## Responsive behavior

| Breakpoint | Behavior |
| --- | --- |
| ≥ 1100px | 5-col metrics, 3+ column grid (auto-fill at 300px min) |
| 980–1099px | Metrics drop to 3-col, grid recomputes via auto-fill |
| 768–979px | Sidebar narrows to 56px, page padding tightens, header stacks |
| 640–767px | Metrics drop to 2-col, grid often single column |
| < 640px | Topbar context label hides, all metric cards 2-col, grid 1-col |

The `auto-fill` minmax pattern is preferred over fixed breakpoints for the
card grid because card width is dictated by available space, not by viewport
brackets.

## Removed and why

The current implementation deliberately omits patterns from earlier drafts.
For each, the reason is recorded so this is not relitigated:

- **Bento priority tiles (4/6/3 column spans).** The product team chose equal
  weighting because mixed-size tiles created scanning friction and made the
  grid feel "designed" rather than informative. Severity is now expressed via
  sort order, the tone-colored status edge, the meta dot, and the per-card
  status pill — not through tile size.
- **Right rail (Needs attention / Health snapshot / Quick actions).** Tried,
  rejected by the team. The page is a list-of-cards experience; insights are
  surfaced inline (metrics strip, per-card meta) rather than in a parallel
  rail.
- **"Open →" CTA pill in the card footer.** Removed: the entire card is
  already the affordance. Hover lift and `cursor: pointer` are sufficient
  signals; an explicit CTA was redundant.
- **"Get started" placeholder text on empty BUs.** Removed for the same
  reason: the card itself is the CTA. Empty BUs simply read
  "No documents yet" + the timestamp.
- **Decorative signal bars** (six fixed bars per card, scaled by counts).
  Replaced by the data-driven pipeline mini-bar that only renders when there
  is something to show, and uses real proportions.
- **Insight bar** ("N items need your attention" with click-through).
  Tried, rejected. The metrics strip already carries the same numbers.
- **Bento "Add BU" tile inside the grid.** Replaced by a header action that
  opens an inline create panel above the toolbar. This keeps the grid
  homogeneous (every tile is a real BU) and elevates the create flow.

## Implementation references

| Concern | File | Symbol |
| --- | --- | --- |
| Component tree | `apps/web/src/App.tsx` | `BusinessUnitDashboard`, `BusinessUnitCard`, `PortfolioMetric`, `pickTone`, `pipelineSegments`, `initials`, `relativeTime` |
| Delete handler | `apps/web/src/App.tsx` | `handleDeleteBusinessUnit` |
| API binding | `apps/web/src/api.ts` | `deleteBusinessUnit`, `BusinessUnit`, `BusinessUnitSummary` |
| Card styles | `apps/web/src/styles.css` | `.bu-grid`, `.bu-card`, `.bu-card::before`, `.bu-card::after`, `.bu-card-head`, `.bu-card-owner`, `.bu-avatar`, `.bu-card-status`, `.bu-card-name`, `.bu-card-description`, `.bu-card-stats`, `.bu-card-pipeline`, `.pipeline-seg.*`, `.bu-card-foot`, `.bu-card-meta`, `.bu-card-time`, `.bu-card-delete` |
| Header / strip / toolbar | `apps/web/src/styles.css` | `.minimal-header`, `.metrics-strip`, `.metric-card`, `.minimal-toolbar`, `.filter-search`, `.saved-filters`, `.eyebrow`, `.eyebrow-dot`, `.inline-create-panel` |
| Tone colors | `apps/web/src/styles.css` (token block) | `--accent`, `--success`, `--warn`, `--warn-strong`, `--danger`, `--danger-pressed`, `--accent-soft`, `--accent-soft-border`, `--surface-tint`, `--accent-light` |

Any change to card geometry, status logic, or the delete flow must update
both the component and this spec; the screen spec is the source of truth for
visual contract and interaction language.
