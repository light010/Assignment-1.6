# Audit, Settings, And Connector Admin Screen Spec

## Audit Log

The Audit Log is a read-only governance screen available at both BU and Project scope. It is the source of truth for state-changing actions and status history. Dashboards, project hubs, export history, and notification center items must not disagree with audit state.

Locked audit layout:

- **Context Bar:** 48px tall and scoped to either BU or Project. Use `bu-context-bar` for BU scope and `project-context-bar` for Project scope.
- **Audit Header:** 80px tall using `audit-header`. It shows `Audit Log` in `display/lg`, retention policy chip, and Export CSV action.
- **Filter Bar:** 52px tall and sticky. Filters are time range, actor, category, outcome, target type, and search.
- **Content:** Full-width table. No cards around the table.
- **Optional Row Detail:** Clicking or keyboard-activating a row opens a right-side `audit-detail-drawer`.

Audit table:

- Header is sticky.
- Density uses `data-row-compact` or `audit-row`, 32px height, because audit lists get long.
- Timestamp column is 180px and shows UTC absolute time; locale-relative time appears on hover.
- Actor column is 200px and shows avatar, name, role chip, and an `agent` prefix chip for agent rows.
- Action verb column is 220px and uses `mono-sm` for machine-stable identifiers such as `topic.approved` or `member.role_changed`.
- Target column is flexible. It links when readable and shows redacted text when the user lacks read permission.
- Outcome column is 120px and uses success, failure, or partial outcome chip.
- Audit ID column is 160px, uses `mono-sm`, and includes a copy affordance.
- Failed rows use a subtle 4px `danger-container` left edge.

Audit detail drawer:

- Uses `audit-detail-drawer`, 480px wide.
- Shows full event payload formatted as readable records first.
- Raw JSON is behind a toggle and uses `code-editor`.
- Related events list preceding and following events with the same actor or target.

Audit rules:

- Audit Log is read-only.
- CSV export is itself an audit event.
- The UI shows the retention policy; it does not hide missing or ambiguous retention configuration.
- Restricted audit targets never reveal names, hashes, topic titles, or quality signals the user cannot read.

## Settings And Admin Surfaces

BU settings, project settings, member management, conversion profiles, terminology, MCP configuration, skills, and policy editing all use the same shell. This is a pattern, not a single destination.

Locked settings layout:

- **Context Bar:** 48px tall and scoped to BU or Project.
- **Settings Header:** 80px tall using `settings-header`. It shows the settings area title and save/discard actions for dirty forms.
- **Content:** Two-column flex with 16px gap.
- **Settings Nav Rail:** Uses `settings-nav-rail`, 220px wide. Grouped sections are General, Members, Profiles, Policy, Terminology, MCP & Skills, Retention, and Audit.
- **Settings Body:** Uses `settings-body`, flexes to available space, and caps at 880px for readable forms. On very wide screens it is centered horizontally.

Settings body composition:

- Page title uses `title-lg` with 24px below.
- Section blocks use `settings-section-block`: `surface`, `rounded.lg`, 1px outline, 24px padding, and 24px gap between sections.
- Section header uses `title-md` plus helper text in `body-sm` and `neutral-700`.
- Section content stacks form fields with 16px between fields.
- Dirty forms show a sticky bottom `settings-save-bar`, 64px tall, `surface`, top border, and Discard plus Save changes actions. Save is primary and disabled until validation passes.

Dangerous sections:

- Dangerous actions such as delete BU, delete project, and revoke access are always the last section block on a settings page.
- Use `dangerous-settings-section`, `danger-container`, 1px danger border, and title in danger color.
- Destructive action button uses `button-danger` and requires typed confirmation.
- Admin actions never share a save bar with operational settings; they confirm individually.

## Connector Setup Drawer

Connector configuration opens as a separate surface, never inside the upload page. The upload page may link to connector setup, but it does not contain OAuth, credentials, scope mapping, or sync scheduling fields.

Connector drawer layout:

- Drawer uses `connector-setup-drawer`, right-side, 560px wide.
- Backdrop uses `opacity.scrim` (`0.48`) over the entire workspace.
- Header uses `connector-drawer-header`, 64px tall, sticky. It contains connector logo, connector name, close icon, and connection status chip: Connected, Disconnected, Error, or Syncing.
- Body scrolls vertically with 24px padding.
- Footer uses `connector-drawer-footer`, 64px tall, sticky bottom. It contains Cancel and Save & connect. Save & connect is primary and validation-gated.

Connector drawer body:

- **Auth section:** OAuth flow or credential form.
- **Permission scope:** Checkbox list of resource scopes.
- **Sync schedule:** Immediate, hourly, daily, or manual.
- **Source filtering:** Path patterns, file types, and max file size.
- **Permission mapping:** Who can access ingested documents; inherited or restricted.
- **Test connection:** Secondary button plus `connector-result-panel` for success, error, and diagnostic result.

Connector rules:

- Connector setup is admin-facing unless project policy explicitly delegates setup.
- Credentials and OAuth tokens are never displayed after save.
- Test connection results are readable summaries first; raw debug output is behind a toggle.
- Saving a connector, changing scopes, disabling sync, or changing permission mapping creates an audit event.
