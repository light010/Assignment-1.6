# PostgreSQL Service-Owned Schema

DITAgen now supports `DITAGEN_STORE_BACKEND=sql` with
`DITAGEN_DATABASE_URL=postgresql://...`. The compatibility SQL store
creates one schema per owning service and one JSONB-backed table per
state collection. This is the migration bridge from `JsonStore` to
typed repositories; route behavior stays stable while each service gets
its own PostgreSQL ownership boundary.

The explicit DDL lives at
`infrastructure/postgres/001_service_owned_state.sql`; services also run
equivalent `CREATE SCHEMA IF NOT EXISTS` / `CREATE TABLE IF NOT EXISTS`
statements on startup so local Compose can self-initialize.
The Alembic migration scaffold lives under
`infrastructure/postgres/alembic/` and carries the same table set for
managed environments that require migration history.

```mermaid
erDiagram
  api_gateway_users {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  api_gateway_sessions {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  api_gateway_revoked_tokens {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  business_unit_service_business_units {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  business_unit_service_projects {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  business_unit_service_project_memberships {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  upload_service_documents {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  upload_service_jobs {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  upload_service_artifact_registry {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  upload_service_upload_sessions {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  upload_service_exports {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  extraction_service_extractions {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  review_service_topics {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }
  audit_service_audit_events {
    text record_id PK
    jsonb payload
    timestamptz updated_at
  }

  business_unit_service_business_units ||--o{ business_unit_service_projects : owns
  business_unit_service_projects ||--o{ upload_service_documents : contains
  upload_service_documents ||--o{ upload_service_jobs : tracks
  upload_service_documents ||--o{ upload_service_artifact_registry : emits
  upload_service_documents ||--o{ extraction_service_extractions : extracted_as
  upload_service_documents ||--o{ review_service_topics : produces
  api_gateway_users ||--o{ api_gateway_sessions : signs_in
  api_gateway_users ||--o{ api_gateway_revoked_tokens : owns
  api_gateway_users ||--o{ audit_service_audit_events : acts
```

## Physical Table Names

PostgreSQL schemas are:

- `api_gateway`
- `business_unit_service`
- `upload_service`
- `extraction_service`
- `review_service`
- `analysis_service`
- `validation_service`
- `audit_service`
- `llm_gateway_service`

Each collection table has:

- `record_id text primary key`
- `payload jsonb not null`
- `updated_at timestamptz not null default now()`

This layout intentionally keeps JSON payloads during the first migration
so services can move off the shared JSON file without rewriting every
route. The next repository pass can normalize each payload into typed
columns behind the same service-owned schemas.
