# Deployment Notes

## Auth Secret

`DITAGEN_AUTH_SECRET` is required whenever `DITAGEN_ENV` is not
`development`. The runtime rejects missing secrets and known local
defaults so containers do not silently sign production tokens with a
demo key.

For Docker Compose, provide the secret from the shell or an environment
file before startup:

```bash
export DITAGEN_AUTH_SECRET="$(openssl rand -hex 32)"
docker compose up
```

Rotation procedure:

1. Set the new secret on every service at the same time.
2. Restart services together so token signing and verification agree.
3. Force users to log in again; previous access tokens and PATs become
   invalid because signatures no longer verify.
4. Record the rotation in the audit log.

## CORS

Production deployments should set explicit allowlists:

```bash
DITAGEN_CORS_ORIGINS=https://app.example.com
DITAGEN_CORS_METHODS=GET,POST,PUT,PATCH,DELETE,OPTIONS
DITAGEN_CORS_HEADERS=Authorization,Content-Type,X-Request-ID,X-Business-Unit-ID
```

Wildcard methods and headers are intentionally not used outside local
development.
