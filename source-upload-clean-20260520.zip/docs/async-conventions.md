# Async Route Conventions

Use `async def` for FastAPI routes that await service calls, file
operations, subprocesses, or other I/O. Gateway proxy routes and
service-to-service orchestration routes should be async because they
call `request_service`.

Use sync `def` for small pure-computation routes and simple state reads
that do not await I/O. FastAPI will run sync handlers in its threadpool.

Do not open direct `httpx.AsyncClient` instances inside services for
DITAgen service boundaries. Use `ditagen_common.service_clients` so
in-process tests, request headers, and service URLs stay consistent.
