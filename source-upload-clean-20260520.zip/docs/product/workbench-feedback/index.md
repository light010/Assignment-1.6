# Workbench Feedback Batch Index

Generated: `2026-05-11`

Scope: uploaded app documents in `Documentation Operations`, sourced from DOCX files under `DATA/dita_source_docs/DOC`. This index tracks visible Chromium line-by-line extraction review, not DITA topic-classification quality.

| Report | App status | Browser line review | Source blocks | Locator coverage | Visual mismatches | P0 count | P1 count | P2 count |
|---|---|---|---:|---:|---:|---:|---:|---:|
| [apple-ca-psc](apple-ca-psc.md) | ready_for_review | complete | 55 | 55/55 | 0 | 0 | 0 | 0 |
| [assigning-workers-compensation-classification-codes](assigning-workers-compensation-classification-codes.md) | ready_for_review | complete | 65 | 65/65 | 0 | 0 | 0 | 0 |
| [changing-a-business-number-for-single-tax-filing](changing-a-business-number-for-single-tax-filing.md) | ready_for_review | complete | 48 | 48/48 | 0 | 0 | 0 | 0 |
| [changing-payroll-frequency](changing-payroll-frequency.md) | ready_for_review | complete | 77 | 77/77 | 0 | 0 | 0 | 0 |
| [completing-a-letter-search-checklist](completing-a-letter-search-checklist.md) | ready_for_review | complete | 63 | 63/63 | 0 | 0 | 0 | 0 |
| [customer-change-requests](customer-change-requests.md) | ready_for_review | complete | 50 | 50/50 | 0 | 0 | 0 | 0 |
| [employment-tax-file-transmission-guidelines-and-troubleshooting](employment-tax-file-transmission-guidelines-and-troubleshooting.md) | ready_for_review | complete | 34 | 34/34 | 0 | 0 | 0 | 0 |
| [generating-a-globalview-gateway-g2-deletion-file-gv](generating-a-globalview-gateway-g2-deletion-file-gv.md) | ready_for_review | complete | 76 | 76/76 | 0 | 0 | 0 | 0 |
| [overview-of-job-change-actions](overview-of-job-change-actions.md) | ready_for_review | complete | 12 | 12/12 | 0 | 0 | 0 | 0 |
| [processing-an-on-cycle-payroll-with-bpms-us](processing-an-on-cycle-payroll-with-bpms-us.md) | failed_extraction | blocked_by_document_status | 0 | 0/0 | 0 | 0 | 0 | 0 |
| [reprocessing-funddirect-file-created-with-error](reprocessing-funddirect-file-created-with-error.md) | extraction_needs_review | blocked_by_document_status | 23 | 23/23 | 0 | 0 | 0 | 0 |
| [results-completing-a-letter-search-checklist-copy-copy](results-completing-a-letter-search-checklist-copy-copy.md) | ready_for_review | complete | 62 | 62/62 | 0 | 0 | 0 | 0 |
| [results-completing-a-letter-search-checklist-copy](results-completing-a-letter-search-checklist-copy.md) | ready_for_review | complete | 62 | 62/62 | 0 | 0 | 0 | 0 |
| [retroactivity-overview](retroactivity-overview.md) | ready_for_review | complete | 70 | 70/70 | 0 | 0 | 0 | 0 |
| [running-calabrio-reports](running-calabrio-reports.md) | ready_for_review | complete | 56 | 56/56 | 0 | 0 | 0 | 0 |
| [running-the-monthly-illinois-sui-report](running-the-monthly-illinois-sui-report.md) | ready_for_review | complete | 76 | 76/76 | 0 | 0 | 0 | 0 |
| [running-the-paycheck-protection-program-ppp-loan-forgiveness-application](running-the-paycheck-protection-program-ppp-loan-forgiveness-application.md) | ready_for_review | complete | 43 | 43/43 | 0 | 0 | 0 | 0 |
| [sap-garnishment-processing-overview](sap-garnishment-processing-overview.md) | ready_for_review | complete | 66 | 66/66 | 0 | 0 | 0 | 0 |
| [setting-up-a-garnishment](setting-up-a-garnishment.md) | ready_for_review | complete | 54 | 54/54 | 0 | 0 | 0 | 0 |
| [setting-up-an-excel-payroll-register-for-payatwork-clients](setting-up-an-excel-payroll-register-for-payatwork-clients.md) | ready_for_review | complete | 73 | 73/73 | 0 | 0 | 0 | 0 |
| [terminating-an-employee-and-generating-a-record-of-employment](terminating-an-employee-and-generating-a-record-of-employment.md) | ready_for_review | complete | 63 | 63/63 | 0 | 0 | 0 | 0 |
| [troubleshooting-candidate-issues-in-ziprecruiter](troubleshooting-candidate-issues-in-ziprecruiter.md) | ready_for_review | complete | 35 | 35/35 | 0 | 0 | 0 | 0 |
| [troubleshooting-log-on](troubleshooting-log-on.md) | ready_for_review | complete | 40 | 40/40 | 0 | 0 | 0 | 0 |
| [updating-a-sui-rate](updating-a-sui-rate.md) | ready_for_review | complete | 54 | 54/54 | 0 | 0 | 0 | 0 |
| [updating-the-kpi-month-to-date-metrics](updating-the-kpi-month-to-date-metrics.md) | ready_for_review | complete | 30 | 30/30 | 0 | 0 | 0 | 0 |
| [updating-the-payroll-schedule](updating-the-payroll-schedule.md) | ready_for_review | complete | 72 | 72/72 | 0 | 0 | 0 | 0 |
| [viewing-and-editing-state-tax-withholding-information-in-employee-access](viewing-and-editing-state-tax-withholding-information-in-employee-access.md) | extraction_needs_review | blocked_by_document_status | 45 | 45/45 | 0 | 0 | 0 | 0 |

## Top Repeated Issues

| Issue | Count | First affected docs | Priority | Fix scope |
|---|---:|---|---|---|
| No repeated P0/P1/P2 issue | 0 | - | - | - |
