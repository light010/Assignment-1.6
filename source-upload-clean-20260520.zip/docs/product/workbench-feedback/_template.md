# Workbench Extraction Feedback: <Document Name>

## Metadata

| Field | Value |
|---|---|
| Document | `<Document Name>` |
| Review date | `<YYYY-MM-DD>` |
| App URL | `http://127.0.0.1:5173/` |
| Reviewer | `Codex browser review` |
| Review scope | Extraction completeness, source mapping, and extraction-review UX |
| Out of scope | DITA topic classification, generated topic quality, classifier tuning |
| Baseline matched count | `<matched>/<total>` |
| Unlocated count | `<count>` |
| Notes | `<context>` |

## Executive Summary

| Category | Summary |
|---|---|
| Extraction correctness | `<summary>` |
| Source mapping | `<summary>` |
| Table/list/heading representation | `<summary>` |
| UI clutter/information economy | `<summary>` |
| Attention/review workflow | `<summary>` |
| Accessibility/keyboard review | `<summary>` |
| Highest-priority fixes | `<summary>` |

## Document-Specific Backlog

| ID | Area | Finding | Why it matters | Recommended fix | Fix scope | Priority | Status |
|---|---|---|---|---|---|---|---|
| `<DOC>-001` | `<area>` | `<finding>` | `<impact>` | `<fix>` | `<scope>` | `<P0-P3>` | `Open` |

## Line-by-Line Feedback

| Line | Extracted source block | Type | Locator | Parent path | Structure details | Why it is right | What is wrong | UX notes | Improvement | Fix scope | Priority | Acceptance test | Evidence |
|---:|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `<text>` | `<type>` | `<locator>` | `<path>` | `<details>` | `<why correct>` | `<issue or none>` | `<information economy, placement, representation, row label, selection, inspector, accessibility>` | `<improvement>` | `<scope>` | `<P0-P3>` | `<test>` | `<screenshot/path>` |

## Repeated Patterns

| Pattern | Examples | Impact | Recommended fix |
|---|---|---|---|
| `<pattern>` | `<lines>` | `<impact>` | `<fix>` |

## Implementation Summary

| Rank | Fix | Scope | Why now | Acceptance test |
|---:|---|---|---|---|
| 1 | `<fix>` | `<scope>` | `<reason>` | `<test>` |

## Final Notes

`<notes>`
