# DITAgen Alpha Backlog

## Active week plans

- **Week 3 — DOCX/PDF Extraction & Source Preview**:
  [`docs/product/wk3-extraction-and-source-preview.md`](wk3-extraction-and-source-preview.md).
  Library research (PyMuPDF + pdfplumber + python-docx + mdformat for
  the backend; Framer Motion + Shiki + react-markdown + TanStack
  Virtual for the front-end), service boundary contracts, motion
  choreography for the Source Preview surface, observability, and
  acceptance metrics.

## Next Engineering Slices

- Move project, upload, review, and export state from the JSON alpha store into service-owned PostgreSQL tables and Alembic migrations.
- Replace synchronous upload pipeline execution with RabbitMQ stage events and worker consumers.
- Add real MinIO object storage adapter behind the artifact interface.
- Add DITA-OT validation and smoke builds in the validation/export services.
- Add OCR fallback for scanned PDFs and image-only pages.
- Implement OIDC/Keycloak adapter behind the existing local auth boundary.
- Expand generated topic support for richer reference tables, troubleshooting structure, glossary topics, and asset/image placement.
- Add Playwright browser tests for the React happy path.
- Add OpenAPI contract export in CI from the running FastAPI gateway.
