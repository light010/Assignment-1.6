# Workbench UI/UX Enhancement Report

> Created 2026-05-11. Author: synthesis from code-level review of current frontend + cross-reference with the 27 per-document feedback reports (1 P0, 61 P1, 254 P2 across 1336 line-by-line entries) + the normative guidelines doc.

This report goes beyond "did the code match the design intent?" (the previous review) and asks the harder question: **for each visible element in the Workbench, did it earn its place on the screen, and is its current representation the best way to communicate that piece of information?**

It is organized by **17 UI/UX dimensions** and lists **25 improvement points**, each tagged with priority, affected file:line, the UX problem, and a concrete fix. The report is intentionally adversarial — it accepts that the recent refactor closed the P0 + the contract gaps + the architecture locks, and it now critiques the **visual and information-design layer** that sits on top.

---

## 0a. Full-Corpus Interactive-Review Baseline (2026-05-12)

Ran the new `recorded-interactive-review.mjs` harness against all 27 documents. **128 invariants asserted, 120 pass, 8 fail, 27 console errors auto-captured across 6 documents.** Wall-clock: 3 min 12 s.

**The 8 failures cluster into 3 patterns** (each confirms a previously-reported issue):

| Pattern | Failing docs | Total | Bug |
|---|---|---|---|
| **P-57** programmatic scrollTo silently overridden | apple-ca-psc, employment-tax-file-transmission, setting-up-an-excel-payroll-register, updating-a-sui-rate | **4 of 23 ready docs (17%)** | Selection-anchored snap-back — confirmed conditional reproduction |
| **P-46** Blocks pill shows 0 on docs with real blocks | reprocessing-funddirect, viewing-and-editing-state-tax-withholding | **2 of 2 blocked docs (100%)** | Universal failure on blocked state |
| **P-47** Skeleton placeholder rendered alongside error | reprocessing-funddirect, viewing-and-editing-state-tax-withholding | **2 of 2 blocked docs (100%)** | Universal failure on blocked state |

**New baseline insight on P-58** (console-error pattern across ready docs):

| Doc | Console errors | Notes |
|---|---:|---|
| retroactivity-overview | 8 | NEW — ready doc with 8 errors during normal interaction |
| setting-up-an-excel-payroll-register-for-payatwork-clients | 8 | NEW — also fails P-57 |
| changing-payroll-frequency | 4 | NEW |
| reprocessing-funddirect | 2 | expected (P-58 / blocked) |
| viewing-and-editing-state-tax-withholding | 2 | expected (P-58 / blocked) |
| processing-an-on-cycle-payroll-with-bpms-us | 3 | expected (failed_extraction) |

**P-58 widens**: 3 *ready* documents emit console errors during normal Workbench interaction (4–8 each). This wasn't visible in the 3-doc baseline. The current report's P-58 framing ("blocked docs emit 404s") is **too narrow** — the bug is broader.

### Healthy baselines

- **17 of 23 ready docs (74%) pass all 5 invariants and emit zero console errors.** The workbench is mostly healthy for the common case.
- **1 of 1 failed-extraction document** (`processing-an-on-cycle-payroll-with-bpms-us`) passes both invariants — `ExtractionFailedPanel` renders correctly, Workbench tab is disabled. The Phase D' panel-split work is genuinely shipping.

### CI integration

- **Workflow**: `.github/workflows/interactive-review.yml` runs on `workflow_dispatch`, nightly cron (06:00 UTC), and PRs labeled `interactive-review`.
- **Exit codes**: 0 = all 128 invariants pass; 1 = any failure; 2 = setup error.
- **Outputs**: `junit.xml` (parsed by `dorny/test-reporter@v1`), per-doc `findings.md` + screenshots + `console.json`, aggregate `index.md` + `summary.json`. All uploaded as GitHub Actions artifact (14-day retention).
- **Invocation**: `npm run test:interactive-review` (full) or `npm run test:interactive-review:quick` (3 docs).

### Artifacts on disk (this run)

- `/private/tmp/workbench-interactive-review-all-27/index.md` — aggregate findings table
- `/private/tmp/workbench-interactive-review-all-27/junit.xml` — CI-format report (8 failures)
- `/private/tmp/workbench-interactive-review-all-27/summary.json` — machine-readable
- 27 per-doc folders with screenshots + findings.md + console.json

---

## 0b. Remediation Status (2026-05-14)

Current implementation run: `npm run test:interactive-review` against the live local UI/API on `127.0.0.1:5174` / `127.0.0.1:8000`.

**Result:** 27 documents reviewed, **141 invariants, 141 pass, 0 fail, 0 console errors**. Artifacts: `/private/tmp/workbench-interactive-review-current/index.md`, `summary.json`, `junit.xml`, and per-document screenshots.

Additional gates:

- `npm --prefix apps/web run test -- --run`: **109 tests passed**.
- `npm --prefix apps/web run build`: **passed**.
- `PLAYWRIGHT_BASE_URL=http://127.0.0.1:5174 DITAGEN_API_BASE_URL=http://127.0.0.1:8000 npm --prefix apps/web run test:e2e`: **5 tests passed**, including the tablet-width stacked-pane regression.
- `docker-compose build extraction-service` via the Compose plugin: **passed** after bypassing the local Docker credential-helper hang with an empty Docker config.
- `docker run --rm ditagen-extraction-service:latest sh -lc 'pandoc --version ...'`: **Pandoc 3.1.11.1** and **mdformat-gfm 1.0.0** present on PATH.

| Area | Report Points | Status | Verification |
|---|---|---|---|
| Lifecycle/default routing | P-7, P-29, P-54 | **Fixed** | No `Source` lifecycle tab. Ready, gated, and failed documents land on `Workbench`. |
| Full filename display | P-55 | **Intentionally not implemented** | User preference overrides the report; H1 and breadcrumb preserve full filenames including `.docx`. |
| Ready pane foundation | P-35, P-39, P-56, P-57 | **Fixed** | Desktop and tablet e2e assert equal pane heights; full harness asserts source scroll does not snap back after selection or programmatic scroll. |
| Gated Workbench diagnostics | P-46, P-47, P-48, P-49, P-52, P-58 | **Fixed** | Gated docs show source-block counts, affected groups, selected evidence detail, remediation actions, and zero expected console noise. |
| Document-root chrome | P-26, P-27, P-28, P-31, P-32, P-33, P-34 | **Fixed** | Root inspector uses descendant counts, summary confidence labeling, collapsed passing checks, and no contradictory selected-row hint. |
| Extraction fidelity | P-36, P-37, P-38, P-45, P-50, P-51 | **Fixed** | Resource heuristic tightened, breadcrumbs dedupe and include procedural context, inline runs render, heading/list labels corrected, table debug prefixes removed. |
| Inspector and triage | P-1, P-2, P-3, P-8, P-10, P-11, P-12, P-13, P-16, P-17, P-23, P-24, P-25, P-40, P-41, P-42, P-43, P-44 | **Fixed** | Inspector has grouped Identity/Position/Trust sections, confidence breakdowns, severity-sorted signals, readable chips, source-state legend, locator action, and table grids. |
| Search/navigation | P-15, P-18 | **Fixed** | Search result count/reset is present; sticky H1/H2 section rail remains visible and highlights the active ancestor. |
| Header/artifacts/review polish | P-4, P-5, P-6, P-19, P-20, P-21, P-22, P-53 | **Fixed** | Header uses source-block count and threshold-relative gate copy, Jobs/Artifacts are demoted, XML editor has line/validation rails, status labels use shared helpers, dead UI removed. |
| Backend extraction dependency | P-58 adjacent operational blocker | **Fixed in image** | Shared Python service image installs Pandoc and mdformat-gfm; built extraction image verifies both binaries/plugins on PATH. |

---

## 0. Executive Summary

The Workbench is functionally correct: the P0 source-sync canary passes live, the review-flag contract is locked, the blocked-document UX is split into two clear states, and 18/18 vitest files and 4/4 Playwright tests are green. The residual gaps are not correctness gaps. They are **information-design gaps** — places where the right datum lives at the wrong level of the UI, where two representations compete for the same screen real estate, where a number is shown without the threshold that makes it actionable, or where structure is implied by indentation but not announced semantically.

The single biggest theme across the 25 points is **trust-by-disclosure**: the user must be able to see *why* the system claims a block is "low confidence", *why* a heading is "inferred", *which axis* of confidence triggered the flag, *which row* of a table is being inspected, and *what* the next action is. Today many of these answers exist in the data model but are summarized down to a single number, a single tag, or a single line that the reviewer must mentally decompose.

---

## 1. Methodology

Each point answers all four of these questions, not just the first:

1. **Is it correct?** (does the rendered value match the source?)
2. **Did it earn its place?** (would removing it cost the reviewer a decision?)
3. **Is this the best representation?** (text vs badge vs icon vs mini-bar vs progress vs sparkline vs cell vs breadcrumb vs disclosure)
4. **Is the nesting / placement right?** (row vs group header vs inspector vs toolbar vs drawer vs portal)

Dimensions applied (≥17):

| # | Dimension | Question |
|---|---|---|
| 1 | Comprehension speed | Can a reviewer grok the row in 2 seconds? |
| 2 | Information economy | Does every visible element help a decision *now*? |
| 3 | Placement | Is this datum at the right UI level? |
| 4 | Representation | Does the format match the information's shape? |
| 5 | Row label quality | Is the label structural, content, redundant, or misleading? |
| 6 | Visual hierarchy | Are document / section / table / row / cell levels visibly distinct? |
| 7 | Selection clarity | Are active / preview / focus / search / attention all distinct? |
| 8 | Reviewer action clarity | Does the UI tell the user what to do next? |
| 9 | Inspector usefulness | Does the inspector answer the reviewer's next question? |
| 10 | Terminology | Extraction-focused, or leaking classifier/topic language? |
| 11 | Noise balance | Enough info, no overload? |
| 12 | Scalability | Holds at 1000+ blocks, 50+ tables, 7-level lists? |
| 13 | Accessibility | Keyboard, ARIA, non-color state, contrast ≥ AA? |
| 14 | Trust signaling | Does the UI honestly say "we are uncertain"? |
| 15 | Failure surfacing | Are silent failures impossible? |
| 16 | Cognitive load | Mental work to reconstruct meaning? |
| 17 | Cross-document consistency | Same pattern across the 27 documents? |

---

## 2. Improvement Points

Each point lists: dimension(s) hit, current state (with file:line where applicable), the UX problem, the concrete fix, and priority.

### P-1. Confidence is shown as one number when three exist (Trust signaling • Information economy • Cognitive load)

- **Current**: `ExtractionExplorerPane.tsx:121` shows `{Math.round(node.confidence * 100)}%` — a single percentage derived from `extraction ?? block_type ?? heading` at `extractionExplorerModel.ts:524-526`. The reviewer sees "72%" but cannot tell *which axis* is below threshold, and the threshold itself (0.72 — `LOW_CONFIDENCE_THRESHOLD`) is not visible.
- **Problem**: The number does not earn its place because it conveys neither *which* axis is risky nor *how risky*. Two blocks at "72%" can mean radically different things — one is a heading whose style is ambiguous, one is a paragraph whose block-type classifier failed.
- **Fix**: In the inspector, replace the single `Confidence` row with a **3-axis micro-bar**: `Extraction ████░ 87% │ Type ██░░░ 55% (below 0.72) │ Heading n/a`. Color the axis red when below threshold, gray when N/A. Keep the badge collapsed to "55%" on the row itself, but expand to the breakdown in the inspector.
- **Priority**: **P1**

### P-2. Table row cells are flat spans with no separators or column awareness (Representation • Visual hierarchy • Cognitive load • Scalability)

- **Current**: `ExtractionExplorerPane.tsx:236-239` renders cells as `<span>` inside `extraction-row-cells` with no separators, no header-row detection, no colspan visual treatment, no rowspan handling. For a 6-column row the reviewer sees `Apple CA Pearl District … 503-555-1234 admin@acme.com` as run-together text.
- **Problem**: The cell boundaries are in the backend data (`block.cells[].text`) but lost in the rendered output. Reviewers must re-read the source pane to know where one cell ends and the next begins.
- **Fix**: Render cells as a **mini-grid with visible boundaries** — either a CSS grid with `grid-template-columns: repeat(N, minmax(0, 1fr))` and dotted vertical borders, or `<span>`s joined by `·` typographic separators (already used in `rowMeta`). Detect header rows (`row_index == 1`, parent table's metadata) and bold them. Add a `colspan > 1` indicator (e.g., span across 2 grid columns). Drop empty cells visibly (placeholder dash) rather than `" "`.
- **Priority**: **P1**

### P-3. Inspector shows one locator string, no "open in source" affordance (Reviewer action clarity • Inspector usefulness)

- **Current**: `ExtractionExplorerPane.tsx:142` renders `<dd>{node.locator}</dd>` as plain text (`docx:p:35`). The locator is informational, not actionable.
- **Problem**: Reviewers want to *jump to* the source position the locator points at. The action exists in code (selecting the row scrolls the source pane), but the locator itself is not visually a button.
- **Fix**: Turn the locator into a clickable affordance — `<button class="locator-chip"><code>docx:p:35</code> ↗</button>` — that scrolls the source pane and focuses the matching anchor. Same handler as row click, just with a visual hint that it is interactive.
- **Priority**: **P2**

### P-4. The "X% quality" in the header meta is a context-free number (Trust signaling • Information economy)

- **Current**: `DocumentDetail.tsx:80` shows `{Math.round(document.source_quality.overall_confidence * 100)}% quality` in the meta line alongside topic count and status.
- **Problem**: A bare number ("73% quality") tells a reviewer nothing — is 73% above the gate threshold? Below? Worse than yesterday? Better than the corpus average? Without an anchor, the number is decorative.
- **Fix**: Replace with a **threshold-relative phrase**: "Above gate" (green dot), "Below gate (−12 pts)" (amber), "Below gate by 32 pts" (red). Move the raw percentage to the inspector hover. The reviewer wants a decision cue, not a measurement.
- **Priority**: **P2**

### P-5. Topic count leaks into extraction-review header (Terminology • Information economy)

- **Current**: `DocumentDetail.tsx:75-77` shows `{document.topic_ids.length} topics` in the meta line of the *document detail header*, which sits above the Workbench (an *extraction* surface).
- **Problem**: The guidelines doc explicitly states "Terminology should match extraction review, not topic planning." Topic count is a classifier output — it leaks the downstream stage's vocabulary into the upstream stage's header. Reviewers fixing extraction issues see a topic count they cannot act on from this view.
- **Fix**: Replace topic count with **source-block count** ("50 source blocks") in the meta line. Move topic count behind the "Plan" tab where it belongs. Cross-tab counts (artifacts, topics) should each live in their owning tab's header, not in the document-wide meta.
- **Priority**: **P2**

### P-6. Jobs / Artifacts chips occupy the first viewport (Information economy • Placement)

- **Current**: `DocumentDetail.tsx:90-109` renders Jobs and Artifacts as primary chips in the document detail header. Comment on line 54-63 explicitly acknowledges they are "demoted observability surfaces" — yet they are visually promoted.
- **Problem**: Two debug/observability entry points sit in the highest-attention zone of the page (top-right of the document header), which a reviewer never needs for normal extraction review. They earn their place only for the maybe-1%-of-time when something has gone wrong.
- **Fix**: Move both behind a single "·· More" overflow control or a small kebab menu. Expose Jobs *only* when a job is in `running` or `failed` state (lift the chip into the header when there's a signal, hide it when quiet). Artifacts only matters for power users — hide entirely behind a developer toggle or keyboard shortcut.
- **Priority**: **P2**

### P-7. Lifecycle tab order does not reflect actual reviewer journey (Reviewer action clarity • Cross-document consistency)

- **Current**: `DocumentDetail.tsx:131-137` tab order is Source, Workbench, Plan, Review, Export.
- **Problem**: A first-time reviewer arrives at Source by default (correct), but the *next* tab they need is Workbench (extraction review) — except Workbench is disabled when extraction fails. The visual ordering doesn't encode the conditional flow. When Workbench is gated, the reviewer's eye still moves to it next and bounces off a tooltip.
- **Fix**: Add a leading **dot or numeric badge** on each tab indicating "your next step here" vs "complete" vs "blocked": e.g., `① Source ✓ │ ② Workbench (blocked: re-extract) │ ③ Plan │ ④ Review │ ⑤ Export`. Keep state lightweight (CSS + aria-current), but make the journey visible without relying on the disabled tooltip.
- **Priority**: **P2**

### P-8. Attention badge count loses severity grouping (Representation • Trust signaling)

- **Current**: `ExtractionExplorerPane.tsx:246` renders `<span class="attention">{node.attentionSignals.length}</span>` — a flat count of all signals regardless of severity. The `attention-block-count` header (line 57) shows the same flat sum.
- **Problem**: 3 errors and 0 warnings look identical to 0 errors and 3 warnings. The triage decision is materially different.
- **Fix**: Render the row badge as **`!3 ⚠2 ⓘ1`** (error / warning / info) — three small chips, color-coded, only the non-zero ones rendered. Same in the header. A user can then scan for "any row with `!`" without filter-toggling.
- **Priority**: **P1**

### P-9. SOURCE_HIGHLIGHT_UNMAPPED state lives only on the row, not on the document header (Failure surfacing • Visual hierarchy)

- **Current**: `extractionExplorerModel.ts:539-545` raises the unmapped signal per-block and the row class gets `.unlocated`. The header in `ExtractionExplorerPane.tsx:59` shows `X/Y located` but no top-of-page red alert when the failure count is non-zero.
- **Problem**: A document with 50 blocks and 1 unmapped block shows `49/50 located` — a 98% pass rate that visually reads as "fine". The 1 failure becomes a needle-in-haystack scrolling problem rather than a first-screen finding.
- **Fix**: When `matchFailureCount > 0`, add a **persistent red banner** at the top of the extraction pane: "1 source block could not be highlighted in source preview. [Show failures only]". The button toggles the existing `attentionOnly` filter to a stricter `unmappedOnly` mode.
- **Priority**: **P1**

### P-10. Inspector cell list is unstructured (Representation • Inspector usefulness)

- **Current**: `ExtractionExplorerPane.tsx:123-129` renders `<div class="extraction-cell-list">` with `<span>{cell.text}</span>` per cell. No `Row N of M`, no column headers, no cell index, no widths.
- **Problem**: When a reviewer selects a table row, the inspector should answer "where am I in this table, and what does each cell mean?" Today it shows the cells but not their position.
- **Fix**: Replace with `<table class="inspector-cell-grid">` showing: column index header row (`Col 1 │ Col 2 │ Col 3`), the cell content row, and a footer with `Row {row_index} of {parent_table.rows} · {columns} cols`. The inspector becomes a mini-spreadsheet for the selected row.
- **Priority**: **P1**

### P-11. UnlocatedChips show opaque block IDs (Representation • Cognitive load)

- **Current**: `ExtractionReviewBanner.tsx:217` renders `<code>{blockId}</code>` per chip. `block_id` is opaque (`blk_19e1840…`) and unreadable.
- **Problem**: Reviewers cannot map a `blk_*` ID back to source content without clicking each chip. The chips become decorative — they exist to be counted, not used.
- **Fix**: Render each chip as **"{first 30 chars of text} ↗"** with the block_id in title/hover. The user sees `"Click Verify and Sign On Quote… ↗"` instead of `blk_19e1840…`. Add an icon hinting "click to scroll to source". The block_id stays as the data attribute for the click handler.
- **Priority**: **P1**

### P-12. blocked_groups and review_flag_counts are rendered as two flat lists (Information economy • Visual hierarchy)

- **Current**: `ExtractionReviewBanner.tsx:165-180` renders `extraction-review-banner__groups` twice — once for `blocked_groups` (with severity classes) and once for `review_flag_counts` (without). They overlap conceptually.
- **Problem**: A reviewer reads two visually-similar rows of chips with no obvious distinction. The duplication wastes screen and creates the impression of more information than exists.
- **Fix**: Render **one combined section** showing `{label} ({count}) {severity-dot}` per group, sorted by severity (error → warning → info). Drop the second row. If `review_flag_counts` ever diverges from `blocked_groups` (it shouldn't post-summary-endpoint), surface that as a developer-only debug toggle.
- **Priority**: **P2**

### P-13. Heading provenance is dropped into rowMeta as informal phrase (Trust signaling • Terminology)

- **Current**: `ExtractionExplorerPane.tsx:320` shows `if (styleSource === "formatting") parts.push("inferred heading");` — the string "inferred heading" appended after dots.
- **Problem**: Reviewers cannot tell at a glance which headings are explicit vs inferred vs from numbering. The phrase appears mid-meta-string, easy to miss.
- **Fix**: Add a small **provenance chip** to the heading row: `[H1 STYLE]` (green) for explicit DOCX style, `[H1 INFERRED]` (amber) for formatting heuristic, `[H1 NUM]` (blue) for numbering. Visible immediately, color-coded by trust, no parsing required.
- **Priority**: **P2**

### P-14. Same icon for table and table_row blurs the hierarchy (Visual hierarchy • Representation)

- **Current**: `ExtractionExplorerPane.tsx:266-267` uses `<Table2 size={14}>` for `kind="table"` and `<Table2 size={13}>` for `kind="table_row"` — the same icon, 1px different.
- **Problem**: When a user scans the tree, table containers and their rows look almost identical. The depth indentation does most of the work, which fails when search filters collapse intermediate levels.
- **Fix**: Use **distinct glyphs**: `<Table2>` for table containers, `<TableRowsSplit>` (or a custom horizontal-line glyph) for `table_row`. The icon should encode kind, not just family.
- **Priority**: **P3**

### P-15. Search-filtered view has no result count (Information economy • Scalability)

- **Current**: `flattenVisibleExtractionNodes` in `extractionExplorerModel.ts:201-227` filters by `query`. The pane renders `<div class="extraction-empty">No extraction rows match the current search.</div>` (`ExtractionExplorerPane.tsx:72`) only when zero matches.
- **Problem**: When 7 of 50 rows match, the user has no immediate count — they have to scroll the filtered list and count manually. Reviewers want "7 matches" to decide whether the filter is selective enough.
- **Fix**: Add a `<small class="search-result-count">N of M shown</small>` to the header when a query is active. Also clear the query with a visible `×` button — today the query stays until manually emptied.
- **Priority**: **P2**

### P-16. Inspector confidence breakdown does not surface confidence_signals (Trust signaling • Inspector usefulness)

- **Current**: `extractionExplorerModel.ts:445` includes `style_source: stringSignal(block.confidence_signals?.style_source)` in metadata. Used by `rowMeta` for the "inferred heading" string. But `confidence_signals` carries much richer signal (font_size_zscore, bold_ratio, corpus_mean_size_pt, dominant_font_size_pt) that never reaches the UI.
- **Problem**: The data exists; it could explain *why* a heading was inferred ("font 18pt > corpus mean 12pt; bold ratio 1.0; ends without punctuation"). The reviewer would gain trust ("yes, that's clearly a heading") or lose it ("12pt non-bold? that's not a heading").
- **Fix**: Add an inspector disclosure section **"Why we think this is a heading"** (or whatever block_type) that lists the actual signal values. Hidden by default; one click to expand. Power-user feature that builds calibrated trust.
- **Priority**: **P2**

### P-17. Hover preview vs active selection are CSS-distinct but not legend-explained (Accessibility • Selection clarity)

- **Current**: `SourceEvidenceViewer.tsx:167-172` applies `source-viewer-active`, `source-viewer-selected`, `source-viewer-preview`, `source-viewer-spotlight`, `source-viewer-filter-match` classes — five visual states.
- **Problem**: A new reviewer has no legend. They learn the distinctions by accident. Color-blind reviewers may not distinguish the active/selected states if their CSS treatments rely on color alone (need to audit — likely partial).
- **Fix**: Add a small **state legend** to the source-pane toolbar — a row of swatches with labels (`Active`, `Hover`, `Match`, `Attention`). Always visible. Also use a non-color cue (border thickness, underline style, icon prefix) for each state.
- **Priority**: **P2**

### P-18. Long extraction trees lack section anchors (Scalability • Navigation)

- **Current**: A 70-block document (e.g., retroactivity-overview, 70 blocks) requires the reviewer to scroll the tree to find a heading. There is no per-heading "jump" affordance other than scrolling.
- **Problem**: Reviewers reading line-by-line need to navigate between sections. Today they scroll until they find the next heading visually. At 1000+ blocks this is untenable.
- **Fix**: Add a **collapsed section overview** on the tree header: a small list of all H1/H2 headings, click jumps to that subtree. Effectively a mini-TOC. Alternatively, sticky-heading behavior (current heading pins to top of viewport as you scroll past it).
- **Priority**: **P1**

### P-19. Topic Review pane uses raw textarea for DITA editing (Information economy • Trust signaling • Cognitive load)

- **Current**: `DocumentDetail.tsx:452-456` renders `<textarea value={topic.dita_xml}>` — a plain textarea for editing XML. No syntax highlighting, no validation feedback inline, no schema awareness.
- **Problem**: Editing DITA XML in a textarea encourages typos. The validation issues list (line 461-475) appears in a separate panel, decoupled from the location of the error in the textarea.
- **Fix**: Switch to a **lightweight code editor** (CodeMirror 6 or Monaco) with XML syntax highlighting and inline validation markers. When a validation issue exists for line N, scroll-link the issue row to line N. (Out of pure scope of extraction review but mentioned as a parallel cross-tab consistency point.)
- **Priority**: **P2** (out of extraction scope but listed for cross-tab consistency)

### P-20. Artifact registry shows truncated hash with no copy affordance (Reviewer action clarity • Representation)

- **Current**: `DocumentDetail.tsx:288` renders `<code>{artifact.hash.slice(0, 18)}...</code>`.
- **Problem**: Truncated hashes that can't be copied serve no purpose. The reviewer either trusts the system or needs the full hash for forensic work — neither case is helped by `b8e7…3f2a…`.
- **Fix**: Either show the full hash with a copy button, OR hide the hash entirely behind a details expander. Choose one — the current state is the worst of both.
- **Priority**: **P3**

### P-21. Review tab "status" string uses ad-hoc regex replace (Cross-document consistency)

- **Current**: `DocumentDetail.tsx:442` uses `topic.status.replace(/_/g, " ")` while `DocumentDetail.tsx:72` uses `humanizeStatus(document.status)`. Two different humanization paths.
- **Problem**: `extraction_needs_review` → "Extraction needs review" via `humanizeStatus`, but "extraction_needs_review" → "extraction needs review" via raw `.replace`. Capitalization differs between identical underlying statuses.
- **Fix**: Always use `humanizeStatus`. Remove the ad-hoc `.replace`.
- **Priority**: **P3**

### P-22. Dead branch in UnlocatedChips loop (Information economy • Code hygiene)

- **Current**: `ExtractionReviewBanner.tsx:218` contains `{index < shown.length - 1 ? null : null}` — both branches return null, the ternary is a no-op.
- **Problem**: Dead conditional code. Slows readers, suggests the author meant something else and forgot.
- **Fix**: Delete the line. (Per user's "report dead surfaces" rule, this is reported and should be removed.)
- **Priority**: **P3**

### P-23. ExtractionInspector signal list has no severity sort or grouping (Inspector usefulness • Information economy)

- **Current**: `ExtractionExplorerPane.tsx:130-138` maps `node.attentionSignals` directly — order is whatever the model produced (insertion order).
- **Problem**: When 4 signals exist (1 error, 2 warnings, 1 info), the reviewer should see the error first. Today they appear in code-insertion order, which mixes severities visually.
- **Fix**: Sort `node.attentionSignals` by severity descending (error → warning → info) before render. Optionally group: error block, warning block, info block, with subtle dividers.
- **Priority**: **P2**

### P-24. "Show N more" expansion in UnlocatedChips is one-way (Scalability • Reviewer action clarity)

- **Current**: `ExtractionReviewBanner.tsx:194-229` caps chips at 20, then "Show {remainder} more" expands. No way to collapse back.
- **Problem**: Once expanded, a long list of chips dominates the banner permanently. The user has to refresh to get the compact view back.
- **Fix**: When expanded, swap the button to "Show fewer". Same UX pattern as Stripe/Linear collapsible lists.
- **Priority**: **P3**

### P-25. Inspector "Marker" field is shown only when present, with no fallback context (Inspector usefulness • Comprehension speed)

- **Current**: `ExtractionExplorerPane.tsx:119` shows `Marker: {numberingLabel(node)}` only when a marker exists (line `&& numberingLabel(node)`).
- **Problem**: A reviewer comparing two consecutive list items sees one with "Marker: 2." and the next without (because the second's numbering was lost). They don't know whether the second item *has no marker* or *had a marker we couldn't extract*.
- **Fix**: Always show the Marker row when the parent is a list/procedure context, with explicit "—" or "(no marker found)" for missing values. Reveal absence; don't hide it.
- **Priority**: **P2**

### P-26. The same fact is repeated 4–6 times in the Workbench viewport (Information economy • Cognitive load • Cross-document consistency)

- **Current** (verified against live screenshot of `Updating the Payroll Schedule.docx`, ready_for_review, 72 blocks): "72 source blocks all located" appears in 5 places on one screen — `Evidence Workbench` card `SOURCE BLOCKS:72` + `LOCATED:72/72`, left-pane `72/72 matched` chip, right-pane `72 source blocks` heading, `72/72 located` pill, and the checklist `All blocks located ✓`. "Nothing needs review" appears in 4 places — `NEEDS REVIEW:0` card + `0 need review` pill + `0 signals` pill + `Review flags ✓` checklist chip. **The filename appears 4 times** — H1, `Evidence Workbench` subtitle, `Selected Block` inspector when document-root is selected, AND as the synthetic document-root tree row label (root cause: `extractionExplorerModel.ts:85-95` sets `label: documentLabel` on the synthetic `document` node, so wherever the node renders the filename gets re-stated). Empty draft state appears twice (`DRAFT OPS:0` + 3 disabled buttons).
- **Problem**: roughly **5–10% of pixels carry new information**. The reviewer's brain has to keep re-parsing the same facts. The one actual signal in this state — the amber `Lists nested ⚠` checklist chip — is *smaller* and *less weighted* than the redundant green checks around it.
- **Fix**: **Delete the entire `Evidence Workbench` stat card.** Move its only-non-redundant element (the Undo/Redo/Reset draft cluster) into a small toolbar above the tree when `DRAFT OPS > 0`; hide it entirely when zero. The right-pane header already carries `72 source blocks` and `72/72 located`. The left-pane already carries `72/72 matched`. Pick **one canonical place** per fact and remove all the others.
- **Priority**: **P1**

### P-27. The "0 need review" pill is amber when its count is zero (Selection clarity • Trust signaling — semantic error)

- **Current**: `ExtractionExplorerPane.tsx:57` renders `{model.attentionBlockCount} need review` in a chip that is styled amber/orange (the "attention" color). When `attentionBlockCount === 0` the chip is *still* amber.
- **Problem**: Amber means "attention required". A zero count needing attention is a **success state**, not a warning state. Conditioning reviewers to see amber-on-zero teaches them to *ignore* amber when it eventually means something real.
- **Fix**: Make the chip color **conditional on count**: 0 → green or neutral gray (`status-ok`); ≥1 → amber. Same rule for `0 signals`. Also: when both are zero, consider collapsing both pills into a single muted "All checks clear" chip rather than two zero pills.
- **Priority**: **P1**

### P-28. Checklist row dedicates ~85% of its pixels to "things that are fine" (Information economy • Visual hierarchy)

- **Current**: `ExtractionReviewChecklist` in `ExtractionExplorerPane.tsx:89-100` renders all 6 (or 8 with extensions) checklist items as same-size chips regardless of state. A typical ready_for_review document shows 7 green checks and 0–1 amber warnings.
- **Problem**: 7 chips that each say "this category is fine" cost ~600px of horizontal real estate and produce **zero actionable signal**. The 1 chip that *does* matter (e.g., `Lists nested ⚠`) is the same size and visual weight as the 7 noise chips.
- **Fix**: Adopt a **"green collapse, amber/red expand"** pattern. Default render:
  - When all pass: a single muted chip "All 8 checks passing ✓".
  - When some fail: render only the failing chips at full size + a small "(7 other checks passing)" link that expands the full list on click.
  
  Same data, 1/7th the screen, the signal-to-noise ratio inverts.
- **Priority**: **P1**

### P-29. "EVIDENCE WORKBENCH" and "EXTRACTION EXPLORER" labels re-state the section the user is already inside (Information economy • Terminology)

- **Current**: The active tab is "Workbench". Inside it, two all-caps labels — `EVIDENCE WORKBENCH` (left card label) and `EXTRACTION EXPLORER` (right pane label) — repeat names that are conceptually identical to the tab the user just clicked.
- **Problem**: Labeling a thing with its own name is the verbal-UI equivalent of writing "this is text" on a wall. Worse: "Evidence Workbench" and "Extraction Explorer" are two different proper nouns for *the same surface* — internal jargon noise that reviewers must mentally reconcile.
- **Fix**: Drop both labels. The tab name and the layout already say what these sections are. If a distinguishing label is needed for the right pane in mobile/narrow layouts, use a single short noun ("Blocks").
- **Priority**: **P2**

### P-30. "Original DOCX" chip implies tabs that don't exist (Reviewer action clarity • Information economy)

- **Current**: The left pane shows a blue active chip "Original DOCX" next to "72/72 matched" and "Open original". The chip styling reads as a tab.
- **Problem**: A tab with no siblings is theater — it implies the user could switch to "Markdown" or "PDF" but no such option exists. Worse, the chip carries no information the source preview itself doesn't already convey.
- **Fix**: Either (a) **add the real alternates** (Markdown projection from the Pandoc step, Plain text fallback) and let the chip become a real source-format switcher, OR (b) **delete the chip**. The middle state — a single-option tab — is the worst choice.
- **Priority**: **P2**

### P-31. "Located 72/1" on document-root inspector is a semantic display bug (Trust signaling • Failure surfacing — display)

- **Current** (visible in the selected-document-container state): the inspector strip reads `Type document · Blocks 1 · Located 72/1 · Confidence 90%`. The "72/1" is interpreted by reviewers as "72 located out of 1" — nonsensical.
- **Problem**: The numerator and denominator come from different sources — likely `model.locatedBlockCount` (72) over the document-root node's own `sourceBlockIds.length` (1, because the synthetic node carries only itself). This violates the "x/y" reading convention where x ≤ y. A reviewer who sees "72/1" cannot trust other counts in the same strip.
- **Fix**: For synthetic container nodes (document, table) the inspector should show **`Located: {locatedDescendantCount} of {totalDescendantCount}`** using descendant counts, not the synthetic node's own `sourceBlockIds` length. Better: hide the `Located` field entirely on synthetic nodes and use a separate `Children: 72 (all located)` line that doesn't pretend to be a ratio.
- **Priority**: **P0** (display correctness)

### P-32. "1 source blocks" — pluralization bug (Polish • Trust signaling)

- **Current**: the document-root tree row shows the meta line "1 source blocks" (singular subject, plural noun).
- **Problem**: Trivial but signals "the UI is not carefully proofread", which erodes trust in the data underneath. Same bug almost certainly affects "1 topics", "1 tables", "1 rows" wherever plural strings are built by string concatenation rather than a pluralization helper.
- **Fix**: Add a `plural(count, singular, plural?)` helper (or use `Intl.PluralRules`) and route every count-noun pair through it. Lock with a vitest case for each call site.
- **Priority**: **P3**

### P-33. "Confidence" displayed on synthetic container nodes is meaningless (Trust signaling • Information economy)

- **Current**: when the document-container node is selected, the inspector shows `Confidence 90%`. The same will be true for synthetic `table` container nodes. These nodes have no source text; "confidence" is computed by `rollUpSyntheticNodes` (`extractionExplorerModel.ts:564-583`) as the minimum confidence across children.
- **Problem**: A reviewer asks "90% confident that what?". For an extracted block the answer is "this block's type / extraction / heading". For a synthetic container the answer is "the worst confidence of any descendant" — useful as a *signal*, but not as a `Confidence: 90%` field that visually equates with per-block confidence.
- **Fix**: On synthetic nodes, replace the `Confidence` field with **`Lowest descendant confidence: 90%`** (one wraps the meaning into the label), or hide the field entirely on synthetic nodes and surface the same data only at block level. Don't render a number that the reviewer cannot map back to a source decision.
- **Priority**: **P2**

### P-39. Source-pane / Extraction-pane width imbalance (Visual hierarchy • Accessibility • Scalability — ROOT CAUSE of P-35)

- **Current** (visible across all screenshots): the dual-pane layout renders at roughly **20–25% left / 70–75% right** instead of a balanced 50/50 (or even 40/60). The left pane is so narrow it cannot display its own content — leading to the symptom captured as P-35 (left ~25–30 px clipped on every line).
- **Problem**: a dual-pane review tool is structured around the assumption that the two panes are *balanced partners* in the reviewer's eye-movement. When one pane is squeezed to a quarter of the screen, three things break: (a) the squeezed pane cannot render its native content (P-35 is the visible symptom), (b) the dominant pane fills its excess space with redundant chips and meta-strips that wouldn't otherwise fit (the P-26 viewport-duplication is partly *enabled* by the extra width), (c) the asymmetric layout subliminally signals "the right pane is more important than the source you're verifying against" — which is the inverse of the actual epistemic priority.
- **Root cause**: likely a CSS grid-template-columns or flex-basis distribution in `WorkbenchPanel.tsx` (the `.workbench-grid` container) where the right pane is allowed to grow without constraint while the left pane has no minimum width. Probably something like `grid-template-columns: 1fr 3fr` or unconstrained flex-grow on the right child.
- **Fix**: enforce **balanced split with a guaranteed minimum width on each pane**:
  - `grid-template-columns: minmax(min-content, 1fr) minmax(min-content, 1fr)` (50/50 with min-content fallback for both), OR
  - explicit `grid-template-columns: 480px 1fr` with a resizable splitter for ≥1280 px viewports, OR
  - a 40/60 split with `min-width: 480px` on the left and `min-width: 640px` on the right; force horizontal page scroll if the viewport is narrower than 1120 px combined.
  
  Whichever variant lands, **the left pane must never be allowed to render at less than its content-min-width** — that's the invariant. Add a Playwright test that asserts `sourcePane.getBoundingClientRect().width >= 480` at the default viewport.
- **Cascade**: shipping P-39 fixes P-35 (left clip) as a side effect AND reduces the available right-pane width, which makes the viewport-duplication cleanup of P-26 cheaper because there will simply be less room for redundant chips.
- **Priority**: **P0** (root cause of P-35 + enabler of P-26 chrome bloat)

### P-40. `Source block ID` (`blk_…hex…`) in the inspector earns no place in primary view (Information economy • Terminology)

- **Current** (every selected-block inspector view): the metadata strip shows `Source block ID  blk_49a3ebf6bc96` as a first-class chip with equal visual weight to Type, Marker, Locator, Confidence.
- **Problem**: this is an opaque internal identifier. Reviewers never need to type, copy, or reference it in normal review. They cannot decode it visually. It is **debug data** taking the same screen real estate as actionable metadata. Worse, on touch-narrow viewports it forces the metadata strip to wrap earlier, pushing actually-useful fields below the fold.
- **Fix**: remove the chip from the primary inspector view. Make it accessible via a "Copy block ID" overflow action or as a `title=` attribute on the locator chip (since both identify the block). Keep the data in the DOM for `data-source-block-id` selectors used by automation — don't render it as a visual field.
- **Priority**: **P2**

### P-41. Inspector metadata is a flat chip soup with no semantic grouping (Information economy • Visual hierarchy • Cognitive load)

- **Current**: the seven metadata chips render in a single inline strip separated by `·` — Type, Source block ID, Marker, List level, Numbering format, Locator, Confidence. All chips share identical visual weight, font size, and color. The strip wraps at an arbitrary point depending on viewport width.
- **Problem**: the seven chips fall into **three different semantic categories** that the layout doesn't acknowledge:
  - **Identity** (what this block is): Type, Source block ID
  - **Position** (where this block lives): Marker, List level, Numbering format, Locator
  - **Trust** (how confident we are): Confidence
  
  Showing them as a flat list forces the reviewer to mentally re-categorize on every selection. Worse, the wrap point is arbitrary — on some documents the position group wraps mid-strip, on others it stays inline. Reviewers cannot build a stable scanning pattern.
- **Fix**: render the inspector as a **3-column grouped layout**:
  ```
  IDENTITY              POSITION                   TRUST
  Type: step/list item  Marker: 17 · List level 1  Extraction: 87% ████░
  [hover for ID/copy]   Locator: docx:p:22 ↗      Type:       55% ██░░ (below)
                                                   Heading:    n/a
  ```
  Three small uppercase column headers, two-three values per column, consistent layout across all documents. Trust column uses the multi-axis bar from P-1. Identity column hides the opaque ID per P-40. Position column collapses Numbering format into the Marker chip ("17 · decimal" or just infer from glyph).
- **Priority**: **P2**

### P-42. Inspector Type field "step/list item" is a hybrid label (Terminology)

- **Current**: `displayKind` (`ExtractionExplorerPane.tsx:325`) maps `procedure_step` kind to the string `"step/list item"`.
- **Problem**: hybrid labels (`step/list item`, `concept/task`, etc.) are a sign the model can't commit to one type. A reviewer reading "Type: step/list item" cannot tell whether this is *definitely* a procedure step, *definitely* a list item, or *either could be*. The hybrid is honest about uncertainty but hides actionable specificity.
- **Fix**: drop the slash. The block already carries `block.block_type` (the canonical backend type — `procedure_step`, `ordered_list`, `unordered_list`, etc.) — render that directly. Use `"Step"` for `procedure_step` with numbered marker, `"List item"` for non-numbered or alphabetic-marker bullets. The kind-vs-block_type confusion in `nodeKindForBlock` already creates a layer of indirection; the display side shouldn't compound it.
- **Priority**: **P3**

### P-43. Marker chip shows "17." (trailing period as visual noise) (Polish • Information economy)

- **Current**: the Marker chip renders `17.` with the trailing period. The period comes from `fallbackNumberingLabel` (`extractionExplorerModel.ts:450-452`) which formats as `${marker}.`.
- **Problem**: the period is decoration, not information — it is the *separator* between the marker and the text in the source, not part of the marker itself. Showing it inside a chip context (where there is no following text on the same line) makes the chip read as "step 17.…" with an implied trailing ellipsis.
- **Fix**: strip the trailing period before display, OR omit the period from `fallbackNumberingLabel`'s template entirely (let the rendering side add typographic separators only when joining marker+text).
- **Priority**: **P3**

### P-44. `Numbering format: decimal` chip earns no place — debug data on primary surface (Information economy)

- **Current**: the inspector shows `Numbering format  decimal` (or `bullet`, `lowerLetter`, etc.) as a first-class chip.
- **Problem**: a reviewer can already read the marker glyph (`17.` vs `o` vs `a.`) and infer the format. The chip restates what the marker shape already says. It only earns its place when the marker is *missing* or *wrong* — at which point the chip should be amber/warning, not equal-weight neutral.
- **Fix**: drop the chip from the default inspector. Surface it only when there's a discrepancy (marker present but no `numbering` metadata, or `numbering.format !== "decimal"` and the marker fallback was used). Same data, surfaced only when it tells the reviewer something they don't already know from the visible marker.
- **Priority**: **P2**

### P-45. Breadcrumb duplicates identical consecutive headings and gives zero positional cue (Visual hierarchy • Inspector usefulness)

- **Current** (visible on every selected-block inspector for this document): the breadcrumb reads `Updating the Payroll Schedule / Updating the Payroll Schedule`. The first segment is the H1, the second is the H2 — which happens to have the same text in this DOCX. The breadcrumb is identical for *every* block under that H2: step 1, step 17, Period Ending, Last In, all 72 blocks share this breadcrumb.
- **Problem**: the breadcrumb's job is to tell the reviewer where they are in the document. When 72 different selections produce the same breadcrumb string, the breadcrumb is decorative — it occupies a row of pixels and conveys no positional information. The duplicate-heading visual amplifies the uselessness ("twice the redundancy for the same nothing").
- **Fix**: two complementary fixes:
  1. **De-duplicate consecutive identical ancestors** at render time. `extractionNodeBreadcrumb` (`extractionExplorerModel.ts:265-268`) should drop a segment if it equals its predecessor. Result: `Updating the Payroll Schedule` instead of `Updating the Payroll Schedule / Updating the Payroll Schedule`. Pure UI fix; backend already has the (duplicate) data.
  2. **Include the immediate procedural parent in the breadcrumb** (already P-37). With P-37 + the dedup, the breadcrumb for step 17 becomes `Updating the Payroll Schedule › Step 17` — which actually locates the user. For nested bullets like Period Ending, it becomes `Updating the Payroll Schedule › Step 5 › Period Ending`.
- **Priority**: **P1**

### P-57. Programmatic scroll on the source pane is silently overridden by snap-back (Failure surfacing • Cognitive load — extension of P-56)

- **Current** (reproduced by `recorded-interactive-review.mjs` harness against Apple CA, Run 2 result): a programmatic `element.scrollTo({top: 400, behavior: "instant"})` on `<div class="source-original-scroll">` (the actual scrollable container, scrollHeight=1965, clientHeight=580) is reverted to `scrollTop=0` within 800 ms. The reversion happens because the snap-back behavior described in P-56 fires not just for user wheel/touch scrolls but for **any** scroll that displaces the pane from the selected block's natural anchor position.
- **Problem**: this turns P-56 from "user can't scroll freely" into a broader API failure: any feature that programmatically scrolls the source pane (a "Jump to top" button, an "expand context" overlay, a screen-reader skip-link, a deep-link that opens the doc at a specific scroll position) is silently overridden. The bug is *imperative-scope*, not just *interaction-scope*.
- **Fix**: same architectural fix as P-56 (`revealOnNextSelection` flag + decouple selection state from scroll trigger). With that fix, programmatic scrolling becomes a sibling concept — once the "reveal one-shot" has fired, the pane stays where any subsequent caller puts it.
- **Lock**: extend the P-56 invariant test to also call `sourcePane.scrollTo(arbitrary_position)` and assert the position holds for ≥1 second.
- **Methodology note**: this finding was produced by the new `apps/web/scripts/recorded-interactive-review.mjs` harness on its first improved run, before any human noticed it. The harness is now a working tool for detecting interaction bugs that other test layers miss.
- **Priority**: **P0** (broader scope than P-56; same fix unblocks both)

### P-58. Blocked documents emit 3× 404 console errors during render (Failure surfacing — silent backend failures)

- **Current** (reproduced by harness on `Reprocessing FundDirect`): opening a blocked document logs three `Failed to load resource: the server responded with a status of 404 (Not Found)` errors. Ready documents emit zero. The 404s correlate with the user-visible "Could not load source preview: Not Found" red error box AND the contradictory skeleton placeholders behind it (P-47).
- **Problem**: 404s shouldn't appear in the console for *expected* application states. The frontend is requesting 3 separate resources (likely the source preview HTML, the source DOCX render, and possibly a thumbnail) that the backend doesn't serve for blocked documents. The right pattern is either (a) skip the requests entirely when `status !== "ready_for_review"`, or (b) surface a typed structured "resource unavailable" response from the backend that the frontend can render as an explicit empty state, no 404 needed.
- **Why this matters**: 404 spam in the console hides *real* errors. When something actually breaks, developers and CI scanners must wade through expected-but-not-handled 404s to find it. Production observability becomes noisier and more brittle.
- **Fix**: in `SourcePanel.tsx` (or wherever the source fetch fan-out happens), gate the requests on `summary.status === "ready_for_review"`. For other statuses, render the appropriate empty/blocked state without fetching. Add a Playwright invariant: opening a blocked document produces zero console errors.
- **Priority**: **P1**

### P-56. Paired-pane scroll trap — neither pane can be scrolled independently of selection (Reviewer action clarity • Cognitive load • Scalability — workflow-breaking)

- **Current** (verified by user interaction, not by static screenshot): selecting a block in the extraction tree (right pane) makes the source pane scroll to the corresponding anchor — correct. But after that, scrolling the source pane independently to read context above or below the selected block is **blocked** — the source pane immediately snaps back to the selected block. The same happens in reverse: clicking a source anchor scrolls the right-pane tree to it, but then scrolling the tree independently snaps it back. The two panes are bidirectionally bound to selection in a way that prevents either pane from being free-scrolled.
- **Root cause** (code-level hypothesis, requires interactive Playwright trace to confirm):
  - `SourceEvidenceViewer.tsx:190` registers a `useEffect` that fires `blockElementsRef.get(firstSelected).scrollIntoView({ block: "center", behavior: "smooth" })` whenever `selectedIdsKey` changes.
  - `ExtractionExplorerPane.tsx:165-173` registers a `useEffect` that fires `rowRefs.get(activeNodeId).scrollIntoView({ block: "nearest" })` whenever `activeNodeId` changes.
  - If hover preview, focus events, or any unrelated re-render causes either of these dependencies to change (e.g., array reference changes even when contents are stable, or hover-preview state leaks into the selection), the `scrollIntoView` re-fires, snapping the pane back to the selected block.
  - The app has **no concept of "the user is currently scrolling this pane, suspend auto-scroll"**. The selection-state and scroll-position are conflated.
- **Problem**: the dual-pane source-vs-extraction comparison workflow depends on the reviewer being able to (a) select a block, (b) read 3–5 lines above and below it in the source for context, (c) compare against the extracted text in the tree, (d) decide. Step (b) is currently impossible without losing the selection. This breaks the fundamental review loop on every block that needs context.
- **Fix** — implement the "reveal once, then release" pattern (industry convention used by VS Code split-edit, GitHub PR diff, Notion split view):
  1. **Drive auto-scroll from a one-shot signal, not from selection state.** Replace the `useEffect` watching `selectedIdsKey` with an explicit `revealOnNextSelection: boolean` flag that is set `true` only by an explicit user action (click on a row, keyboard Enter), and is reset to `false` immediately after the first scroll.
  2. **Decouple hover preview from scroll triggers.** Hover preview may produce a transient highlight in the paired pane but must *never* invoke `scrollIntoView`. Audit `onPreviewNode` and any other hover handlers to confirm they don't enter the selection-state path.
  3. **Add a "Sync scrolling" toggle** in the source-pane toolbar (small chain-link icon, default ON). When OFF, the paired-pane scroll trigger is suppressed entirely; both panes scroll independently.
  4. **Detect user-driven scroll and pause auto-scroll** — when the user scrolls a pane via wheel/touch/scrollbar, set a `userScrollingPane: "left" | "right" | null` flag with a short debounce (~1.5s). While set, auto-scroll for that pane is suppressed. This implements the "natural" behavior reviewers expect without requiring them to think about a toggle.
- **Lock**: add a Playwright regression test that (a) selects a row on the right, (b) confirms the source pane scrolls to it, (c) programmatically scrolls the source pane up 200 px via `page.mouse.wheel(0, -200)`, (d) waits 500 ms, (e) asserts the source pane's `scrollTop` is still ~200 px above the selected block (i.e., the snap-back did NOT happen).
- **Cross-reference**: this is the single most consequential workflow bug found in this session — together with **P-35** (source pane unreadable due to left-clip) and **P-39** (pane width imbalance), the three of these constitute *the foundational dual-pane review experience is currently broken at the interaction layer*. All three should ship in the layout/foundation pass (Pass 0a).
- **Methodology note**: this class of bug is invisible to (a) static code review — the individual `scrollIntoView` calls look reasonable in isolation, (b) static screenshot review — single-frame captures cannot show temporal scroll behavior, (c) the existing Playwright spec which tests *that* the highlight appears, not that subsequent free-scrolling works. Catching it requires either interactive use (which the user did) or a Playwright test that explicitly tries to scroll after selection.
- **Priority**: **P0** (workflow-breaking — the dual-pane review loop is fundamentally impaired)

### P-46. Blocked document shows `Blocks 0` pill while backend has 23 source blocks (Failure surfacing • Trust signaling)

- **Current** (`Reprocessing FundDirect File Created with Error.docx`, status `extraction_needs_review`): the Source-pane sub-tab strip renders `Blocks (0)` even though the feedback report and the extraction-quality artifact both show this document has 23 source blocks. The reviewer trying to triage which of the 23 blocks failed sees "0" and concludes "nothing to look at here".
- **Root cause** (likely): the Source-pane sub-tab count is derived from an endpoint that returns zero blocks when the document is in a gated state (probably the regular `/v1/documents/{id}/blocks` returns an empty list when `quality_gate.passed == false`), instead of using the count from the `extraction-review-summary` endpoint which includes the actual block_count regardless of gate status.
- **Fix**: drive the count from `summary.block_count` (or fall back to `summary.unlocated_source_block_ids.length + summary.located_block_count`). Add a Playwright invariant: for any blocked document with `unlocated_source_block_ids.length > 0`, the Blocks pill must show a non-zero count.
- **Priority**: **P0** (wrong number on screen)

### P-47. Blocked document renders "Not Found" error AND skeleton placeholders simultaneously (Failure surfacing • Cognitive load)

- **Current** (same document): below the gate banner, the source area shows a red error `Could not load source preview: Not Found` followed immediately by 4 gray skeleton-shimmer placeholder rows. The UI is communicating "this failed" and "this is still loading" at the same time.
- **Problem**: contradictory states are worse than either alone. The reviewer cannot tell whether they should wait, refresh, or accept that the source is unreachable.
- **Fix**: when the source-preview load fails, the skeleton placeholders should be **removed**, not left in place. Replace with a single explicit empty state: "Source preview unavailable for this document. [Re-fetch] [View raw upload]". If the failure is transient, the Re-fetch button gives an explicit recovery path.
- **Priority**: **P0** (display correctness — contradictory states on screen)

### P-48. "83% quality" displayed alongside "Extraction Needs Review" status (Trust signaling — semantic contradiction)

- **Current** (`Reprocessing FundDirect`): the meta line under the H1 reads `Extraction Needs Review · 0 topics · 83% quality`. A document gated by the quality gate cannot also be 83% "quality" — those facts are mutually exclusive in the reviewer's mental model.
- **Problem**: the percentage is computed from a different axis (overall extraction confidence) than the gate decision (specific blocking reasons). The two numbers come from different sources and they pass each other in the meta line creating a contradiction.
- **Fix**: when the gate has failed, suppress the bare quality percentage and replace with the gate's blocking reason summary: e.g., `Extraction Needs Review · 1 blocking reason · Re-extract or override required`. Move the underlying quality% behind a hover/details affordance for power users.
- **Priority**: **P1**

### P-49. Internal gate name `docx_source_fidelity_v1` exposed in user-facing banner (Terminology • Trust signaling)

- **Current**: the gate banner reads `docx_source_fidelity_v1 blocked analysis.` — the engineer-internal gate identifier is shown to reviewers.
- **Problem**: `docx_source_fidelity_v1` is a versioned internal gate name. Reviewers don't know what `_v1` means, what `source_fidelity` covers, or whether `_v2` exists. The string conveys precisely zero actionable information beyond "something engineer-named blocked this".
- **Fix**: render the gate's *display name* (the catalog already has labels for blocking reasons — extend it to gate names) e.g. `Source-fidelity quality gate blocked analysis`. The versioned ID stays in the audit log / debug surface but not the user-facing banner.
- **Priority**: **P1** (terminology)

### P-50. `List level: 1` rendered on heading blocks (Trust signaling — wrong data)

- **Current** (`Apple CA (PSC).docx`, "Apple CA One Pager" heading selected): the inspector strip shows `List level 1` as a chip. Headings do not have DOCX list levels — this is `inferred_level` (heading depth) being mislabeled, or a default `1` being rendered even when the block carries no numbering.
- **Problem**: a reviewer reading "Type heading · List level 1" parses this as "this heading is at list level 1", which is meaningless. The chip earns no place and conveys wrong information.
- **Fix**: gate the chip on `block_type === "procedure_step" || ordered_list || unordered_list`. For headings, replace with `Heading level: 2` using `inferred_level` (the actual heading depth). For paragraphs, hide entirely.
- **Priority**: **P1** (wrong data on screen, near P0 — only escapes P0 because reviewers eventually learn to ignore it)

### P-51. Table-row cells prefixed with `C1` / `C2` debug labels (Information economy • Visual hierarchy)

- **Current** (Apple CA table rows in tree): each cell rendered with a small `C1` / `C2` prefix before the cell content: `C1 Client Name` `C2 Apple CA`.
- **Problem**: column index is structural information conveyed by the cell's *position* in the row. Labeling it `C1`/`C2` is redundant with position. Worse, the labels add visual noise to every cell on every table row across every document.
- **Fix**: drop the `C1`/`C2` prefixes. The cell grid layout already encodes column position. Keep the header row (when detectable) with optional column labels at the *table* level, not the cell level.
- **Priority**: **P2**

### P-52. Empty/blank pill rendered between gate reasons and action buttons (Information economy — dead UI element)

- **Current** (`Reprocessing FundDirect` gate banner): between the `Structure tree has no hierarchy` chip and the `Re-extract` / `Override gate` action buttons, a small empty white-bordered pill is rendered with no content inside.
- **Problem**: a UI element that renders blank is a code-side bug (probably a conditional `{condition && <span>…</span>}` where `condition` is unexpectedly truthy but the content is empty string). It catches the reviewer's eye, slows the scan, and reduces trust in the rest of the layout.
- **Fix**: identify the conditional render. If empty content is a valid state, suppress the wrapping `<span>` / `<button>` entirely. Add a vitest assertion that no `extraction-review-banner__*` chip renders without text content.
- **Priority**: **P2**

### P-53. Text truncation cuts mid-word with ellipsis (Polish — readability)

- **Current** (`SAP Garnishment` tree, paragraph row): "SAP processes the following garnishment ty…" — the truncation cuts mid-word inside "types", producing "ty…".
- **Problem**: mid-word truncation produces a confusing readable fragment ("ty…" reads as a different word). Word-boundary truncation is the convention.
- **Fix**: use CSS `text-overflow: ellipsis; white-space: nowrap; overflow: hidden;` with `word-break: normal;` and explicit max-width; OR switch to JS truncation that respects word boundaries. Tailwind has `truncate` but it falls back to mid-character on narrow widths — for a row-title context, prefer `line-clamp-1` with `word-break: keep-all`.
- **Priority**: **P3**

### P-54. Source-pane sub-tabs (`Preview / Blocks / Markdown / Warnings / Assets`) collide visually with lifecycle tabs (Visual hierarchy • Cognitive load)

- **Current** (`Reprocessing FundDirect` Source tab): the page has TWO parallel tab systems — lifecycle tabs (Source/Workbench/Plan/Review/Export) at the top and source-pane sub-tabs (Preview/Blocks/Markdown/Warnings/Assets) on the right. Both look like tabs.
- **Problem**: reviewers must learn the mental model that source-pane sub-tabs are *views of one panel* while lifecycle tabs are *workflow stages*. Without strong visual differentiation they read as parallel choices.
- **Fix**: visually differentiate. Source-pane sub-tabs become a small segmented control with a distinct color/treatment that signals "view switcher within this panel", separate from the prominent lifecycle tab rail. Or move source-pane sub-tabs into a dropdown/menu attached to the panel header instead of horizontally adjacent to lifecycle tabs.
- **Priority**: **P2**

### P-55. `.docx` extension persists in H1 and breadcrumb (Polish • Information economy)

- **Current** (across all 5 documents): the page H1 and breadcrumb terminal segment show `Apple CA (PSC).docx`, `Reprocessing FundDirect File Created with Error.docx`, etc. The `.docx` extension is always present.
- **Problem**: the user just navigated here from a document list. They know it's a docx. The extension adds 5 characters of cognitive load per filename render (multiplied across H1, breadcrumb, Evidence Workbench subtitle, inspector for document-root) for no information gain. For documents named "X File.docx" the extension is also visually awkward.
- **Fix**: strip the extension at display time using a `displayFilename(filename)` helper (`filename.replace(/\.(docx?|pdf|xlsx?|pptx?)$/i, "")`). Keep the full filename as `title=` attribute for hover and in the underlying data. Add a vitest test for the helper.
- **Priority**: **P3**

### P-35. Source preview pane left-clips every line (~25–30 px) — content unreadable (Failure surfacing • Trust signaling — rendering correctness)

- **Current** (verified by screenshot of `Updating the Payroll Schedule.docx`, source-pane preview): every visible line in the rendered DOCX is missing its first ~25–30 px on the left. "Updating" → "ng", "Period Ending" → "eriod Ending", "Description" → "scription", "AutoPay" → "y", "Assign" → "ne", numbered list markers `1. 2. 3.` are entirely cut off.
- **Root cause** (likely): a CSS layout problem inside `SourceEvidenceViewer.tsx`. Candidate causes: (a) container has `overflow-x: hidden` while inner DOCX content carries a left margin/indent wider than the visible viewport-half allocated to the pane, (b) the `docx-preview` library renders with absolute positioning offset by a page-margin value that exceeds the pane's visible width, (c) the pane is being rendered at a width narrower than its content-min-width with no horizontal scroll fallback. The selection highlight bar (e.g., on "eriod Ending") extends to the left edge with no source line visible to its left — confirming horizontal overflow being clipped, not just compressed.
- **Problem**: this is *the worst possible state* for an extraction-review tool. The user's job is to compare extracted content to the source. If the source is unreadable, the workflow is broken. Selection sync, source highlighting, mapping verification — all the features we built — assume the user can read the source they're verifying against.
- **Fix**: depending on root cause — (a) replace `overflow-x: hidden` with `overflow-x: auto` so the user can scroll horizontally, OR (b) ensure the pane width has a guaranteed minimum (`min-width` matching the source content's natural width) before the parent grid distributes width, OR (c) reduce DOCX page-margin rendering to match the available pane width, OR (d) fall back to a markdown-projection view of the source when the DOCX cannot render within the available width. The simplest immediate fix: add `overflow-x: auto` and a small "← scroll to see line start" hint when the user is at non-zero `scrollLeft`. **Add a Playwright regression** that loads each fixture and asserts that the first character of the first heading is visible at `getBoundingClientRect().left >= pane.left`.
- **Priority**: **P0** (rendering correctness — the source pane is unreadable)

### P-36. `nodeKindForBlock` over-promotes ordinary bullets to "resource candidate" (Terminology • Trust signaling • Reviewer action clarity)

- **Current**: `extractionExplorerModel.ts:391-392` reads:
  ```ts
  if ((resourceSection || block.numbering?.format === "bullet") && text.length <= 80) return "resource";
  ```
  Any procedure_step block with `numbering.format === "bullet"` AND text ≤ 80 chars is promoted to kind `"resource"`. This produces a link-icon (`<Link2>` at `ExtractionExplorerPane.tsx:268`) and the row meta label "resource candidate" at `displayKind` (`ExtractionExplorerPane.tsx:326`).
- **Problem**: bullets are commonly used for *non-resource* content — field-name lists ("Period Ending / Last In / First Out / Paydate"), options to choose between, sub-procedure items, value enumerations. The current heuristic mis-classifies all of them as resources. Worse, the link icon implies the user can *click to navigate* — but there's no URL to navigate to, so the icon's affordance is a lie.
- **Fix**: tighten the heuristic to require ACTUAL resource signals, not just the bullet format. A conservative replacement:
  ```ts
  // Promote to resource only when text *looks* like a URL/file reference,
  // OR the parent heading literally names a resources/links section.
  if (/^(?:https?:\/\/|mailto:|[\w.-]+\.(?:docx?|pdf|xlsx?|pptx?))/i.test(text)) return "resource";
  if (resourceSection && text.length <= 80) return "resource";
  return "procedure_step";
  ```
  Drop the bullet-format clause. Bullets stay as `procedure_step` (or, if we want to distinguish, introduce a new kind `"list_item"` for non-procedural bullets and reserve `"procedure_step"` for numbered sequential steps).
- **Lock**: add a vitest test for this exact fixture: a `procedure_step` block with `numbering.format = "bullet"`, text "Period Ending", parent path "…Make the appropriate changes to the baseline date fields:" → kind must be `"procedure_step"` or `"list_item"`, NOT `"resource"`.
- **Priority**: **P1**

### P-37. Inspector breadcrumb omits procedure-step parent for nested list items (Visual hierarchy • Inspector usefulness)

- **Current** (verified): the inspector breadcrumb for "Period Ending" reads `Updating the Payroll Schedule / Updating the Payroll Schedule` — only the heading ancestors. The immediate parent ("Step 5: Make the appropriate changes to the baseline date fields:") is missing from the breadcrumb even though the sub-note "Nested under previous list item." confirms the model knows it's nested.
- **Root cause**: `parentForBlock` (`extractionExplorerModel.ts:375-382`) walks `block.heading_path_ids` only. It never traverses procedure_step parents:
  ```ts
  function parentForBlock(block, documentNode, headingNodesByBlockId) {
    const nearest = (block.heading_path_ids || []).slice().reverse()
      .map(id => headingNodesByBlockId.get(id)).find(Boolean);
    return nearest || documentNode;
  }
  ```
  `extractionNodeBreadcrumb` then renders `[...node.headingPath, ...].filter(Boolean).join(" / ")` — which means non-heading ancestors never appear in the breadcrumb path.
- **Problem**: reviewers triaging a sub-bullet need to know which step it belongs to. Telling them "you are under heading X" is true but useless when "step 5 of procedure Y" is the actually-relevant context. The current breadcrumb is also identical for *any* nested item under that heading — six different sub-bullets all show `Updating the Payroll Schedule / Updating the Payroll Schedule`, which is contextually no information.
- **Fix**: extend `parentForBlock` (and the headingPath rollup in `nodeFromBlock`) to include the immediate procedure_step ancestor for blocks whose `numbering.level > 0` or whose `block_type === "procedure_step"` and which are nested under another procedure_step. Render the procedural ancestor in the breadcrumb with a distinct treatment, e.g. `Updating the Payroll Schedule › ① Make the appropriate changes…` (heading → step). Backend already has the info via `parent_block_id`/`heading_path_ids` — frontend just isn't using it.
- **Priority**: **P1**

### P-38. Inline formatting (bold / italic / code / monospace) is dropped from extracted-row text (Trust signaling • Cognitive load • Information economy)

- **Current**: the source pane renders "the **Description** field, enter the details about the requested schedule" — "Description" appears in bold in the source DOCX. The extracted tree row at `ExtractionExplorerPane.tsx:234` shows the same text as a plain string: `<span class="extraction-row-title">{node.label}</span>`. Bold, italic, and code formatting from the original DOCX are not preserved in the rendered row text.
- **Backend has the data**: `SourceBlock.inline_runs[]` carries `start`, `end`, `text`, `marks` (per the schema `marks` includes `bold`, `italic`, `code`, etc.) plus a `semantic_hint` field. The information exists in the wire payload — the frontend's `labelForBlock` (`extractionExplorerModel.ts:423-426`) simply returns `block.text` (a flat string) and never consults `inline_runs`.
- **Problem**: bold in technical procedure documents is not decorative. It marks UI labels ("**Description** field", "**P,PSCH** screen"), code paths ("**Process > Payroll > Payroll Schedule Load**"), system codes ("**-CAN-SD-SMB-OTG**"). Dropping the formatting means the reviewer cannot, from the extracted view alone, distinguish narrative prose from UI/code references. They must cross-reference the source pane for *every single row*, which is exactly the workflow the workbench was built to eliminate. Same for `inline_runs.semantic_hint` (`uicontrol`, `cmdname`, `filepath`, `term`, `keyword`, `ph`) — those are *exactly* the semantic intents the eventual DITA output needs to preserve, and they're invisible in the review surface.
- **Fix**: render `node.block.inline_runs` as a `<RichText runs={inline_runs} text={block.text} />` component that walks the runs and wraps each in `<strong>` / `<em>` / `<code>` per `marks`, plus a small subscript tag for `semantic_hint` (e.g., a tiny `[ui]` after a `uicontrol` run on hover). Backend doesn't need to change. Add a vitest test using a synthetic block with mixed runs (bold + code + plain) and assert the rendered DOM contains `<strong>` and `<code>` elements where expected.
- **Cross-cutting note**: this fix also improves the SELECTED BLOCK inspector's content readability and the search-result rendering. One component change, multi-surface benefit.
- **Priority**: **P1**

### P-34. Document-root inspector contradicts itself: shows data AND tells the user to select a row (Reviewer action clarity • Selection clarity)

- **Current**: `ExtractionExplorerPane.tsx:150` renders `{isDocument && <p class="extraction-inspector-note">Select a row to inspect its source locator, structure, and review signals.</p>}` *in addition to* the meta strip (Type, Blocks, Located, Confidence). The result on screen: a populated metadata block followed by a note instructing the reviewer to select a row — even though a row (the document container) is, in fact, selected.
- **Problem**: The state communicates two contradictory things at once: "here is the selected node's data" and "no useful node is selected, please select one". The reviewer cannot tell whether the action they took (selecting the document row) succeeded.
- **Fix**: Two clean options — (a) **suppress the "select a row" note when the document-root is the active node** and add a separate, non-conflicting hint like "Document container is selected. Open a heading to start reviewing extracted blocks." or (b) **suppress the metadata strip on synthetic-document selection** so the inspector is *just* the "select a row" empty state, with the document container's children list immediately below. Either approach picks one truth.
- **Priority**: **P2**

---

## 3. Cross-cutting themes (meta-points)

Beyond the 25 specific issues, three patterns recur:

### T-A. The data model is richer than the UI exposes

Backend emits multi-axis confidence, full `confidence_signals`, `style_source`, `numbering` details, `inline_runs` with semantic hints. The frontend collapses most of these into one badge or one string. Recommendation: build a **progressive-disclosure inspector** where the standard view stays clean and a single "Show extraction signals" toggle exposes the full data — power users get the trust signal they need, casual reviewers don't get overwhelmed.

### T-B. Numbers without thresholds are decorative

"73% quality", "55% confidence", "X% boundary" — every percentage in the UI lacks the threshold that makes it actionable. Reviewers don't speak in numbers; they speak in "above/below the bar". Recommendation: a global **`<ThresholdBar value={x} threshold={y} />`** component used everywhere a single confidence/quality number is shown. The component shows the value, the threshold mark, and the gap.

### T-C. Source-pane state legend is implicit

Five visual states (active, selected, hover, attention, search-match) overlay on the source pane with no in-product legend. Recommendation: a single small swatches-row legend, always visible in the source-pane toolbar.

### T-D. Viewport-scale duplication is invisible to per-component review (added after live screenshot review)

The most consequential UI problem in the Workbench is **not** that any single component is poorly designed — it is that **three components each correctly render the same fact**, and together they paint the screen with redundancy. The `Evidence Workbench` summary card, the `ExtractionExplorerPane` header, and the source-pane top-strip each have a defensible reason in isolation for showing "block count + located count" — but on the rendered page they form a four- or five-way echo chamber. Per-component code review will never catch this; only a viewport-level "what is the information density of pixels on this screen?" audit will.

**Concrete duplications visible in a single 1440×1000 viewport on `Updating the Payroll Schedule.docx`:**

| Fact | Appearances |
|---|---|
| Block count | `SOURCE BLOCKS: 72`, `72 source blocks`, `72/72 matched`, `72/72 located`, `All blocks located ✓` = **5** |
| Nothing-needs-review state | `NEEDS REVIEW: 0`, `0 need review`, `0 signals`, `Review flags ✓`, `Warnings resolved ✓` = **5** |
| Filename | H1 + `Evidence Workbench` subtitle = **2** |
| Empty-draft state | `DRAFT OPS: 0` + 3 disabled buttons = **2** |

**Fix pattern**: every fact gets exactly ONE canonical location on screen. The right-pane Extraction Explorer header is the canonical place for block counts and review state. The source-pane top-strip is the canonical place for source-mapping state. The `Evidence Workbench` summary card duplicates both and should be deleted; the draft-ops cluster (its only unique element) moves into a small toolbar that hides when zero.

**Recommendation**: introduce a viewport-level review as a permanent step in the Definition of Done — alongside "does the test pass" and "does the lint pass", add **"on every change to a Workbench component, capture a screenshot and audit redundancy at the viewport level"**. Add a Playwright test that asserts the canonical-fact contract: e.g., on a ready document, the count of DOM elements containing the text `${block_count} source blocks` is exactly 1.

---

## 4. Priority Summary

| Priority | Count | Points |
|---|---:|---|
| **P0** (rendering / display correctness — broken or wrong on screen, OR workflow-breaking interaction) | 7 | **P-31** (Located 72/1), **P-35** (source-pane left-clip), **P-39** (pane width imbalance — root cause), **P-46** (Blocks 0 on doc with 23 blocks), **P-47** (Not Found + skeleton placeholders simultaneously), **P-56** (paired-pane scroll trap — user can't scroll independently of selection), **P-57** (programmatic scroll is also overridden by snap-back — broader scope than P-56) |
| **P1** (review-blocking or major trust issue) | 19 | P-1, P-2, P-8, P-9, P-10, P-11, P-18, **P-26**, **P-27**, **P-28**, **P-36**, **P-37**, **P-38**, **P-45**, **P-48** (83% quality vs gated contradiction), **P-49** (gate ID exposed), **P-50** (List level on heading), **P-58** (blocked docs emit 3× 404 console errors) |
| **P2** (slows reviewers or wastes screen) | 22 | P-3, P-4, P-5, P-6, P-7, P-12, P-13, P-15, P-16, P-17, P-23, P-25, **P-29**, **P-30**, **P-33**, **P-34**, **P-40**, **P-41**, **P-44**, **P-51** (cell C1/C2 prefixes), **P-52** (empty pill), **P-54** (sub-tabs collision) |
| **P3** (polish, hygiene) | 11 | P-14, P-19, P-20, P-21, P-22, P-24, **P-32**, **P-42**, **P-43**, **P-53** (mid-word truncation), **P-55** (.docx extension) |

**Total: 58 visual improvement points** (25 from component-level review + 30 from screenshot-level review + 1 from user interaction feedback + 2 from automated interactive harness — bolded). The points cluster as:
- **Viewport duplication cluster** (P-26 through P-30): same fact rendered 4–6 times across summary card + headers + pills + checklist.
- **Document-root inspector cluster** (P-31 through P-34): the synthetic `document` node is rendered as if it were a real extracted block, producing a wrong "Located 72/1" number, a confusing "Confidence 90%" on a synthetic container, a contradictory "select a row" note when a row IS selected, and yet another instance of the filename label.
- **Source-pane rendering cluster** (P-35): the left ~25–30 px of every source line is clipped, rendering the source preview unreadable. This is the single most consequential bug in the report — it breaks the verify-against-source workflow that every other Workbench feature is built around.
- **Extraction-fidelity cluster** (P-36, P-37, P-38): bullets over-promoted to "resource candidate" with a misleading link icon; procedure-step ancestors dropped from breadcrumbs; inline formatting (bold, italic, code, semantic-hint runs) silently discarded from extracted-row text. Each of these makes the reviewer do mental work the data could have done for them.
- **Layout-and-inspector cluster** (P-39, P-40, P-41, P-42, P-43, P-44, P-45): pane width imbalance (root cause of P-35); inspector metadata is a flat chip soup with debug data (block ID) at equal weight to actionable trust data; hybrid type labels; trailing-period markers; useless numbering-format chips; breadcrumb duplicates identical consecutive headings and gives zero positional cue across 72 distinct selections. These collectively make the inspector feel "full" while delivering only ~30% useful information at ~100% cognitive cost.
- **5-document audit cluster** (P-46 through P-55): a chip-by-chip audit of Apple CA, SAP Garnishment, Customer Change Requests, PPP Loan Forgiveness, and the gated Reprocessing FundDirect (captured at 1440×900 viewport via Playwright) surfaced 10 more bugs — most notably (a) the blocked-document Source pane shows `Blocks 0` when 23 blocks exist, AND a "Not Found" error coexists with skeleton placeholders, AND `83% quality` is displayed alongside "Extraction Needs Review" (three contradictions on one screen), (b) the internal gate name `docx_source_fidelity_v1` is leaked to user-facing copy, (c) heading blocks are rendered with `List level: 1` chips even though headings don't have list levels, (d) every table-row cell carries debug-label prefixes (`C1`, `C2`), and (e) the `.docx` extension persists in H1 and breadcrumbs across all 5 documents.

Together the screenshot-level findings would reduce ~80% of the chrome on a clean viewport, fix five P0 rendering/layout/data bugs, restore three layers of source fidelity that the backend already produces but the frontend currently throws away, re-balance the dual-pane layout so the source the reviewer is comparing against is actually readable, and eliminate the contradictory-states problem on blocked documents.

---

## 5. Recommended Implementation Order

A reasonable execution plan (each step is shippable on its own):

**0a. Foundational workflow hotfix (ship FIRST, blocks everything else)** — **P-39 (pane width imbalance) + P-35 (left-clip, symptom of P-39) + P-56 (paired-pane scroll trap)**. Together these three fix the foundational dual-pane review experience.
- **P-39**: enforce balanced pane widths with guaranteed min-widths so the left pane is never starved.
- **P-35**: resolves as a side effect of P-39 (the left pane will then have enough width to render its content).
- **P-56**: implement "reveal once, then release" pattern + add a "Sync scrolling" toggle so reviewers can read context around a selected block without snap-back.

Without this pass, every other UX improvement is built on a layout where (a) the reviewer cannot read the source they're verifying against, and (b) they cannot read context around a selected block without losing their selection. Two CSS/grid fixes on `WorkbenchPanel.tsx`'s grid container plus a state-decoupling refactor on the two `scrollIntoView` `useEffect` blocks, with Playwright invariant tests: (a) `sourcePane.width >= 480`, (b) `firstLineFirstChar.left >= sourcePane.left`, (c) after-select-and-scroll, `sourcePane.scrollTop` does not auto-revert.

0b. **Viewport deduplication + document-root sanity pass (highest leverage after 0a)** — P-26 (delete Evidence Workbench card, removes 1 of 4 filename instances + draft-ops echo + block-count echo + needs-review echo), P-27 (zero-state chip color), P-28 (collapse passing checks), P-29 (drop redundant section labels), P-30 (drop or expand the Original DOCX chip), **P-31 (fix the "Located 72/1" display bug — P0 correctness)**, **P-32 (pluralization helper)**, **P-33 (relabel synthetic-container confidence)**, **P-34 (resolve document-root inspector contradiction, drops the 3rd & 4th filename instances)**. This pass removes ~80% of the chrome on a clean-state viewport, fixes one P0 display bug, and is mostly *deletion or labeling* — minimal risk, highest signal-to-noise gain.

0c. **Extraction-fidelity restoration pass** — **P-36** (tighten resource-candidate heuristic), **P-37** (include procedure-step parents in breadcrumb), **P-38** (render `inline_runs` with `<strong>`/`<em>`/`<code>` + semantic-hint subscripts), **P-45** (dedup consecutive breadcrumb entries + use the P-37 procedural path). The backend already produces this data; the frontend simply has to consume it. Same conceptual surface (the extraction tree's row rendering + the inspector breadcrumb), one focused PR. Restores three layers of source fidelity that today live in the wire payload but never reach the reviewer's eye.

0d. **Inspector grouping pass** — **P-40** (remove block-ID chip from primary view), **P-41** (3-column Identity / Position / Trust layout for inspector metadata), **P-42** (drop "step/list item" hybrid label), **P-43** (strip trailing period from marker chip), **P-44** (hide numbering-format chip when it agrees with marker glyph). Five small fixes on the same component (`ExtractionInspector` in `ExtractionExplorerPane.tsx`), one focused PR. Restructures the inspector's information design from flat chip soup into purposeful 3-column groups.

1. **Trust pass** — P-1 (multi-axis confidence), P-13 (heading provenance chips), P-16 (confidence-signal disclosure). Same conceptual surface (the inspector), one focused PR.
2. **Table-row trust pass** — P-2 (cell grid with separators), P-10 (inspector cell grid with row/col headers), P-25 (always-show marker). One PR, hugely improves the 217 P2 table-row findings.
3. **Failure surfacing pass** — P-9 (page-level unmapped banner), P-11 (chip text content not block_id), P-12 (combine blocked_groups + review_flag_counts), P-24 (collapsible "show more"). One PR.
4. **Attention triage pass** — P-8 (severity-grouped badges), P-23 (severity-sorted signals), P-15 (search result count + clear).
5. **Header cleanup pass** — P-4 (threshold-relative quality), P-5 (drop topic count from extraction header), P-6 (demote Jobs/Artifacts to overflow), P-7 (numbered tab journey).
6. **Polish pass** — P-3 (locator chip click-through), P-14 (table-row icon), P-17 (state legend), P-20 (hash copy-or-hide), P-21 (consistent humanizeStatus), P-22 (delete dead branch).
7. **Scalability pass** — P-18 (TOC / sticky heading).
8. **Cross-tab consistency** — P-19 (CodeMirror in Review pane).

Each pass is a focused PR with vitest + Playwright + a screenshot regression test. The whole set is ~6–8 weeks of focused work, or ~3 weeks if a UI engineer focuses on it full-time.

---

## 6. Out of Scope (explicit)

- DITA topic classification, topic-type tuning (per guidelines doc).
- Plan / Review / Export tab UX beyond P-7's tab-numbering and P-19's editor swap.
- Full mobile/narrow-viewport pass (deferred; see plans/gentle-twirling-whisper.md §8).
- Backend extraction quality (the data is already richer than the UI uses — see T-A).

---

## 7. Verification Plan

Each point shipped should ship with:

- **Vitest**: at least one component test for the new visual state.
- **Playwright**: at least one E2E that exercises the new affordance (extend `e2e/workbench-extraction-explorer.spec.ts`).
- **Screenshot**: capture before/after in `apps/web/test-results/` to track visual regressions.
- **Cross-document smoke**: re-run `node apps/web/scripts/workbench-line-by-line-review.mjs` after each pass and confirm the relevant per-document feedback reports drop their associated findings.
- **Interactive-review harness** (new): re-run `npm run test:interactive-review` from `apps/web/` and confirm no new invariants fail. The harness walks every document, asserts P-46/47/56/57/58 + others, captures screenshots + console errors, and emits JUnit XML (`/private/tmp/workbench-interactive-review/junit.xml`). Wired as a GitHub Actions workflow at `.github/workflows/interactive-review.yml` — runs nightly, on manual dispatch, and on PRs labeled `interactive-review`.

## 7b. Three-layer regression discipline (now in place)

This session established three independent regression layers, each targeting a class of bug the others miss:

| Layer | Script | Bug class caught | Cadence |
|---|---|---|---|
| Standard 5-gate | `uv run ruff/mypy/pytest`, `npm test`, `tsc` | Lint, type, contract, model logic | Every commit |
| Chip-audit screenshots | `apps/web/scripts/chip-audit-capture.mjs` | Visual redundancy, layout imbalance, chip soup, wrong-data-on-screen | Per UI-touching PR |
| **Interactive-review harness** | **`apps/web/scripts/recorded-interactive-review.mjs`** | **Scroll snap-back (P-56/57), missing-count rendering (P-46), error+placeholder coexistence (P-47), console-error spam (P-58), and any future temporal-interaction bug** | **Nightly + manual + opt-in label** |

The harness is the answer to the methodology gap that surfaced repeatedly during this session: 20 of the 58 findings could only be discovered by interactive use, and ~5 of those by *multi-step* interactive use that single-shot tests don't cover. Wiring the harness into CI converts that discovery cost into a one-time investment.

---

## 8. Linkage

- **Plan that established the baseline**: `plans/gentle-twirling-whisper.md` (§0b ledger — all phases verified green).
- **Source feedback**: 27 reports in `docs/product/workbench-feedback/` (1336 line entries, 1 P0, 61 P1, 254 P2).
- **Normative review guidelines**: `docs/product/workbench-extraction-review-guidelines.md` (Reviewer Preflight, Review Contract, Review Flag Glossary, Definition Of Done, Out Of Scope).
- **Automation**: `apps/web/scripts/workbench-line-by-line-review.mjs` (regenerates per-doc reports; future runs should reflect the post-improvement state).
