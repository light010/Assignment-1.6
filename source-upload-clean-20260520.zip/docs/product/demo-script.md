# DITAgen Weekly Demo Script

## Week 1-2 Baseline

1. Run `docker compose up --build`.
2. Open `http://localhost:8000/docs` and show API Gateway health plus `/v1` endpoints.
3. Open `http://localhost:8011/docs`, `http://localhost:8012/docs`, and `http://localhost:8022/docs` to show project, upload, and audit service boundaries.
4. Open `http://localhost:5173` and sign in with `admin@ditagen.local` / `admin123`.
5. Select a Business Unit and confirm it opens the BU-scoped document Upload Hub.

## End-To-End Alpha Demo

1. Upload a DOCX, PDF, TXT, MD, or HTML document.
2. Show document metadata plus the Jobs and Artifacts chips.
3. Open Source and show stable source blocks plus Markdown projection.
4. Open Workbench and confirm the left pane renders the original uploaded source file. For DOCX, call out the `Original DOCX` status, matched/unlocated counts, and `Open original` link.
5. In Workbench, select an extracted topic and show source-to-unit highlighting plus connector lines.
6. Use inline attention filters on the right pane. Clean documents should show no separate triage rail.
7. Demonstrate local review edits: merge adjacent units, undo, redo, split a unit, retype a topic, and reset draft. Retype should show `Validation stale` until reset.
8. Open Plan and show topic candidates, topic type, confidence, and rationale.
9. Approve the topic plan.
10. Open Review, inspect generated DITA XML, validation issues, and traceability.
11. Edit XML if desired, save, then approve the topic.
12. Open Export and build the DITA ZIP.
13. Download the ZIP and inspect `ditagen.ditamap`, `topics/*.dita`, and reports.

## Known Alpha Limits

- The API Gateway executes the pipeline synchronously on upload to keep demos predictable.
- Project-service, upload-service, and audit-service containers own their Week 2 state transitions; projects are an internal alpha storage detail, while auth/session remains in the gateway.
- Postgres, Redis, RabbitMQ, and MinIO are available locally but the first state implementation is filesystem-backed.
- OCR, DITA-OT validation, durable queues, and OIDC are still backlog items.
