# Week 3 — DOCX/PDF Extraction & Source Preview

> **Status (2026-05-10)**: this doc is a planning-era artifact, kept for
> historical context. The work it describes shipped across Phases 1-10
> of `plans/logical-whistling-widget.md` and now has authoritative
> documentation elsewhere:
>
> - Extraction pipeline: ADR-003, ADR-013, `services/extraction-service/app/extractors.py`.
> - Block model + char-offset traceability: ADR-013 + `packages/python/ditagen_common/ditagen_common/models/block.py`.
> - Confidence + review_flags + triage queue: Phase 5 of the plan.
> - Edit-op surface (Merge/Split/Move/Retype/Rename/RawXmlOverride): ADR-014.
> - review-service migration: ADR-015.
> - LLM Gateway + Llama integration + CredentialProvider: ADR-005.
> - Apple CA invariant tests + golden topic plan: `tests/test_apple_ca_invariants.py`.
>
> The drift notes below capture the planning-era → reality gap at the
> time of Phase 1; they're preserved for the post-mortem record but
> are no longer load-bearing.

> **Refinement of the original Week 3 plan.** Keeps the original story
> structure and acceptance gates, adds: deep library research with
> rationale, contract-first service boundary, motion choreography for
> the Source Preview surface, observability + quality metrics from day
> one, and tightened acceptance criteria. The original "Out of scope"
> list is preserved verbatim.

> **Verified against code reality on 2026-05-09** as part of
> `plans/logical-whistling-widget.md` Phase 1. Two known drifts from
> what this doc describes:
> 1. The doc references "Golden DOCX in `tests/fixtures/docx/`" and
>    `pytest -k docx_golden` (Test plan, Story 2). Neither exists.
>    Tests use synthetic in-process fixtures built via `python-docx` in
>    `tests/test_week3_extraction.py` (`create_docx_fixture`,
>    `create_layered_docx_fixture`). Phase 9 added the real-world
>    Apple CA golden topic plan at `tests/golden/apple_ca_topic_plan.json`
>    locked by `tests/test_apple_ca_invariants.py`.
> 2. "No anonymous dicts crossing service boundaries" (principle #1) is
>    aspirational — block / topic / candidate models are still
>    `dict[str, Any]`. Phase 2 of the root-cause plan replaces them
>    with Pydantic models derived from
>    `contracts/artifacts/source-block.schema.json`. **Resolved as of
>    2026-05-10** — typed Block, Topic, EditOperation models are in
>    `packages/python/ditagen_common/ditagen_common/models/`.
>
> Body-order DOCX traversal (interleaved paragraphs and tables via
> `<w:p>`/`<w:tbl>` walker) is implemented at `_docx_body_items` and
> locked by `test_extraction_service_docx_layered_body_order`.

## Demo outcome

A user signs in, opens a Business Unit, drops a DOCX and a PDF into the
Upload Hub, and within seconds sees a **Source Preview** surface that
makes the extraction *visible* — not just "successful." They can:

- Watch the live pipeline advance through Upload → Extract → Plan →
  Convert → Review → Export with no UI jank.
- Open a document and switch between **Preview / Blocks / Markdown /
  Warnings / Assets** sub-tabs with shared-element transitions.
- Hover any block in the list and see its corresponding text highlight
  in the Markdown preview.
- Click an asset thumbnail and zoom into a lightbox.
- Inspect the artifact registry (versioned, hashed, sized, pathed)
  alongside a clean explanation of any extraction warning.

The screen reads like a Vercel deployment detail or a Stripe webhook
inspector: dense, calm, motion only where it conveys meaning.

## Engineering principles for the week

These come straight from
[`DESIGN.md` › Information Architecture Principles](../../DESIGN.md#information-architecture-principles)
and the
[Operational Systems › Motion contract](../design/operational-systems.md#motion-and-animation)
in `docs/design/`. They are not new for this week — they are the rules
we hold ourselves to.

1. **Contracts before code.** Every internal endpoint ships with an
   explicit request/response model committed to `contracts/openapi/`
   and a Pydantic v2 schema. No anonymous dicts crossing service
   boundaries.
2. **Determinism is a feature.** Same input bytes ⇒ same artifacts,
   same hashes, same Markdown ordering. Tests assert byte equality on
   golden artifacts.
3. **No black boxes.** Every artifact has version + hash + producer +
   created-at. Every job stage emits a structured event. The UI shows
   stage, last event, elapsed time, and the next required action.
4. **Progressive disclosure of progress.** Live pipeline shows the
   stepper; terminal documents collapse to a status chip. (Already
   shipped in Week 2 Upload Hub.)
5. **Motion only when it carries meaning.** Tab switches, block hover
   sync, asset reveals — yes. Decorative bounces, marquees, parallax —
   no. All animations honor `prefers-reduced-motion`.

## Library research and selection

Decisions below are informed by: license compatibility, maintenance
status (commits in the last 90 days), Python 3.12+ support, and
demonstrated production deployments. Each row records the chosen
library plus the next-best alternative and why we did not start there.

### License boundary pattern

Two of the strongest tools in this space — **PyMuPDF (AGPL)** and
**Pandoc (GPL-2+)** — carry copyleft licenses. We deliberately accept
both, applying the same architectural pattern in each case: the
copyleft tool runs in **`extraction-service`**, which is its own
deployable unit invoked over an HTTP / ASGI boundary, never linked
into customer binaries. Our code is not a derived work; the
subprocess output is the only thing that crosses the boundary. This
same pattern is widely used in production (e.g. n8n shipping LibreOffice
behind a microservice, Confluent shipping `kafkacat` in tooling
containers).

If our ship model ever changes from "DITAgen-as-a-service" to "ship a
binary on customer infra" we would re-evaluate; both tools have
commercial licensing that handles that case.

### PDF extraction

| Library | License | Strengths | Weaknesses | Verdict |
| --- | --- | --- | --- | --- |
| **PyMuPDF (`fitz`)** | AGPL or commercial | Fastest in class; rich block/line/span model with bbox + font + flags; embedded image extraction; layout heuristics; mature | License complexity for closed-source distribution; large native dep | **Primary**. We ship as a separate service which keeps the AGPL boundary clean (we do not link it into customer binaries). |
| pdfplumber | MIT | Best-in-class table detection via lattice/stream | Slower; weaker on image extraction; no font metadata depth | **Secondary**. Used as a table-fallback inside extraction-service when PyMuPDF's table heuristics return low confidence. |
| pdfminer.six | MIT | Pure Python; deterministic | Slow; no image extraction; weaker layout signal | Rejected as primary; kept available for forensic re-runs. |
| pypdfium2 | Apache-2.0 | PDFium-based; license-clean; image rasterization | Less rich text model than PyMuPDF; smaller community | Considered for future rasterization needs (page thumbnails, OCR feed). |
| unstructured.io | Apache-2.0 | High-level; batteries-included pipeline | Heavy deps (NLP models); opinionated chunking conflicts with our block contract | Rejected for primary path. |
| `marker-pdf` | GPL | Excellent transformer-based PDF→Markdown | GPL prevents shipping; GPU-hungry | Track for v2 high-fidelity export; not Week 3. |
| `docling` (IBM) | MIT | Modern document parser, strong tables, structured output | Newer, fewer field reports; heavier model deps | Track for v2; revisit at Week 6+. |

**Decision:** PyMuPDF as primary, pdfplumber as table fallback. The
extraction-service is its own deployable unit, which gives us a clean
copyleft boundary today and lets us swap engines later (`marker`,
`docling`) without touching the public API.

### DOCX extraction

| Library | License | Strengths | Weaknesses | Verdict |
| --- | --- | --- | --- | --- |
| **`python-docx`** | MIT | Reads ECMA-376 `wordprocessingml` directly; mature; full style/run/numbering access | Does not preserve every visual nuance (text frames, advanced fields) | **Primary**. We extend it with our own numbering walker for list-level inference. |
| `mammoth` | BSD-2 | Pragmatic DOCX→HTML; good for "import a styled doc" flows | Forces an HTML intermediate that loses our block model | Rejected — we project to Markdown ourselves. |
| `docx2txt` | MIT | Pure-Python, simple | No structure; only plain text | Rejected. |
| LibreOffice headless | MPL-2.0 | Full fidelity render | 200 MB+ runtime, slow startup | Rejected for Week 3; revisit if we ship a "render to PDF" feature. |

**Decision:** `python-docx` plus a small custom layer that extracts the
numbering hierarchy (a known weak spot in `python-docx`) and walks
`word/_rels/*.rels` to map image relationships to source paragraphs.

### Asset and image handling

| Library | License | Use |
| --- | --- | --- |
| **Pillow** | MIT-CMU | Image decode, dimensions, format normalization, optional resize to "preview" thumbnail. |
| **python-magic** | MIT | Reliable content-type detection from magic bytes (don't trust filename or `Content-Type` header). |
| filetype | MIT | Pure-Python alternative to python-magic if `libmagic` is unavailable in CI. |
| pyexiv2 / exiftool | varies | Out of scope this week; metadata mining can come with the future asset registry tab. |

**Decision:** Pillow + python-magic. python-magic in production; the
test container provides `libmagic1`. Fall back to `filetype` only if
the test environment ever drops the system library.

### Markdown projection

| Library | License | Strengths | Weaknesses | Verdict |
| --- | --- | --- | --- | --- |
| **Pandoc** (subprocess) | GPL-2+ | Universal AST. Best-in-class **DOCX→Markdown** fidelity: footnotes, math, captions, cross-references, glossaries, complex tables. Mature (since 2006), widely used in publishing pipelines. Filter API (Lua native, Python via panflute). | GPL — but the subprocess boundary handles that (see *License boundary pattern* above). System dep adds ~80 MB to the extraction-service container. PDF input is just a Poppler wrapper, **useless for our PDF needs.** No bbox / font / per-block layout metadata. Subprocess startup ~150 ms per call (mitigatable via `pandoc-server` in Pandoc 3.0+). | **Primary, for DOCX only**. Replaces the previous hand-rolled DOCX→Markdown writer. **Not used for PDF**, which stays on PyMuPDF. |
| **`panflute`** | BSD-3 | Python library for writing Pandoc AST filters. Lets us walk and mutate the JSON AST without leaving Python. | None for our scope. | **Adopted**. Used to rewrite image targets in the Pandoc output to our `asset:{asset_id}` URL scheme. |
| **`pypandoc`** | MIT | Ergonomic Python wrapper around the `pandoc` subprocess. Avoids a hand-rolled `subprocess.run` wrapper. | Adds an indirection over `subprocess`; for production we may want our own wrapper for finer error handling and tracing. | **Adopted for the first cut**; we may swap for a thin custom subprocess wrapper if we need finer-grained span attributes from inside Pandoc. |
| **`mdformat`** | MIT | Deterministic Markdown formatter with stable rules; we run it on the projected `content.md` so two equivalent block sequences produce byte-identical files. | None for our scope. | **Kept**. Pandoc itself is deterministic for the same input + flags, but its Markdown writer's whitespace choices have shifted across minor versions; `mdformat` pins our output regardless. |
| `markdown-it-py` | MIT | Pure-Python parser. | We don't need a parser in production. | **Test-only**. Used in unit tests to round-trip parse and assert structure of the projected Markdown. |
| Hand-rolled string concat | n/a | The previous approach. Easy determinism. | Loses everything Pandoc does well. | Retired for DOCX. **Kept for PDF** because Pandoc cannot help there. |

**Decision:** **Hybrid markdown projector**:

- **DOCX** → `pandoc --from docx --to gfm --extract-media=./assets
  --wrap=preserve` → panflute filter rewrites `image.url` to our
  `asset:{asset_id}` scheme → `mdformat` for byte-determinism.
- **PDF** → in-process projector reading our `source-blocks.jsonl` →
  template + token append → `mdformat`. (PyMuPDF gives us better
  per-page fidelity than Pandoc's PDF reader, so we don't pay the
  Pandoc tax on the PDF path.)

The two paths produce the same artifact name (`content.md`) so the UI
treats them identically. The pipelines just diverge on the producer
side.

### Frontend — Source Preview UI

| Concern | Library | License | Why |
| --- | --- | --- | --- |
| **Animation orchestration** | **Framer Motion** | MIT | The shared-layout transitions for the sub-tab swap (Preview ↔ Blocks ↔ Markdown ↔ Warnings ↔ Assets) need `AnimatePresence` and `LayoutGroup`. Framer Motion is the most ergonomic React option, has first-class `prefers-reduced-motion` support, and ships a small core when tree-shaken (~25 KB gz). |
| **Markdown render** | **react-markdown + remark-gfm + remark-html (sanitized)** | MIT | Composable, no `dangerouslySetInnerHTML`, GFM tables, autolinks. We pass a `components` map so `<code>` renders through Shiki and `<a>` opens in the asset lightbox. |
| **Code/XML highlighting** | **Shiki** | MIT | Uses VS Code's TextMate grammars, server-renderable, identical theme as our editor surface. Avoids the runtime cost of Prism for our small XML/Markdown surface. |
| **Virtualization for blocks** | **TanStack Virtual** | MIT | A 100-page PDF can have thousands of blocks. Virtualization keeps the blocks tab responsive without imposing a fixed-row pager UX. |
| **Tables** | **TanStack Table (headless)** | MIT | Already used elsewhere; headless API lets the blocks table inherit our row tokens. |
| **Image lightbox** | **`yet-another-react-lightbox`** | MIT | Tiny, accessible, keyboard support. We reuse our existing `<Trash2>` hover pattern for "delete this asset" later. |
| **PDF page preview (read-only)** | **`react-pdf`** | MIT | Wraps PDF.js; needed for the Preview sub-tab to show the original page next to the extracted blocks. Lazy-loaded chunk. |
| **Skeleton shimmer** | Built-in (CSS) | n/a | We already have a `@keyframes shimmer` and skeleton tokens; no new dep. |
| **Toast notifications** | **Sonner** | MIT | Tiny (~5 KB gz), no peer-dep on Radix. Used for "Markdown copied", "Asset downloaded", "Document deleted." |

**Note:** We deliberately do not bring in a heavyweight design-system
package (Material, Chakra, Mantine). Our token contract in
`apps/web/src/styles.css` is the source of truth; importing a UI kit
would force us into someone else's tokens.

### Observability stack

| Concern | Library | Use |
| --- | --- | --- |
| **Logging** | `structlog` + `python-json-logger` | Already in use. Add per-stage event emitter `extraction.event(stage, doc_id, …)`. |
| **Tracing** | `opentelemetry-sdk` + OTLP exporter | New for Week 3. Wrap each pipeline stage in a span; export to console in dev, to OTLP collector in staging. |
| **Metrics** | `prometheus_client` | Counters: `extraction_documents_total{outcome}`, `extraction_warnings_total{kind}`. Histograms: `extraction_stage_seconds{stage}`, `extraction_artifact_bytes`. |
| **Front-end RUM** | Stub a `window.__telemetry` shim only; no third-party until OTel JS lands. | |

## Architecture refinement

### Service boundary

```text
┌──────────────┐ HTTP   ┌────────────────────────┐
│ upload-svc   │──────▶ │ extraction-svc         │
│ (gateway     │ ASGI   │  POST /internal/       │
│  proxies)    │ in dev │     extractions        │
└──────────────┘        │  GET  /internal/       │
                        │     extractions/{id}   │
                        │     status             │
                        └────────────┬───────────┘
                                     │
                                     ▼
                        ┌────────────────────────┐
                        │ artifact registry      │
                        │ (filesystem adapter)   │
                        └────────────────────────┘
```

- `upload-service` accepts the upload, persists the original, then
  enqueues an extraction request.
- In dev / tests we use **`httpx.AsyncClient(transport=ASGITransport(app=...))`**
  so no separate process is required. The transport is selected at
  runtime by `EXTRACTION_TRANSPORT={"asgi","http"}`.
- The public gateway path is unchanged. Internal routes are bound to
  `/internal/*` and protected by the service's bearer token middleware
  (the same pattern auth uses today).

### Contracts

Both endpoints get explicit Pydantic models in
`services/extraction-service/contracts.py`, exported into the OpenAPI
schema, and mirrored in `apps/web/src/api.ts` for type parity.

```python
class ExtractionRequest(BaseModel):
    document_id: str
    project_id: str
    business_unit_id: str
    filename: str
    content_type: Literal["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
    artifact_path: str            # the upload-service-stored original
    request_id: str               # for trace correlation
    requested_by: str             # user id / api key id

class ExtractionStatus(BaseModel):
    document_id: str
    stage: Literal["uploaded", "extracting", "extraction_complete",
                   "markdown_projecting", "markdown_complete", "failed"]
    started_at: datetime | None
    finished_at: datetime | None
    error: ExtractionError | None
    artifacts: list[ArtifactRef]
    warnings: list[ExtractionWarning]
```

### Job stages and events

Every stage emits a structured event into `audit_log` AND a Prometheus
counter increment:

```
uploaded               (counted at upload-service)
extracting             ──► extraction.started
extraction_complete    ──► extraction.completed{block_count, asset_count}
markdown_projecting    ──► markdown.started
markdown_complete      ──► markdown.completed{bytes, hash}
failed                 ──► extraction.failed{stage, error_kind}
```

The `extraction.failed` event records the stage where it failed, so
the UI can render the stepper frozen at the right pill.

## Stories (refined)

### Story 1 — Extraction service boundary

Refinements over the original:

- Bind the internal API behind a service bearer token check — copy the
  pattern from `gateway-service/auth_middleware.py`.
- The `ExtractionRequest` payload includes `request_id` so we can
  correlate logs across upload → extraction → markdown spans.
- Status endpoint returns `ExtractionStatus` (typed) and is **idempotent**
  in the sense that polling does not advance the pipeline — it only
  reports.
- `EXTRACTION_TRANSPORT` env var selects ASGI vs HTTP. Local pytest
  defaults to ASGI; staging defaults to HTTP; CI runs both matrices.
- Upload-service publishes a `document.extraction_requested` audit
  event with the request id before calling the extraction service, so
  a failed network call still leaves a record.

**Acceptance**

- `pytest services/extraction-service` runs entirely in-process via
  ASGI transport.
- The OpenAPI export at `contracts/openapi/api-gateway.yaml` includes
  the public document routes; a separate
  `contracts/openapi/extraction-service.yaml` covers the internal API.
- Killing the extraction-service mid-upload leaves the document in
  `failed` state with a typed `ExtractionError` (kind: `service_unreachable`),
  not in a permanent "extracting" limbo.

### Story 2 — DOCX extraction upgrade

Original tasks preserved. Refinements:

- **Numbering walker.** `python-docx` exposes paragraph numbering ids
  but not the resolved level/format. Add a small `NumberingResolver`
  that reads `word/numbering.xml` once and resolves `(numId, level)`
  → list-style + indent so we can correctly bucket nested ordered/
  unordered lists.
- **Run-level metadata.** Bold / italic / underline are easy. Code-
  like text is detected by font name (`Consolas`, `Courier`, monospace
  family) AND by character style (`HTMLCode` / `Code`). We do not
  re-implement `tab` / kerning logic.
- **Table extraction** preserves merged cells via the cell's
  `gridSpan`/`vMerge` attrs. Each cell row is one block with
  `block_type: "table_row"` and a `table_id` that ties rows back
  together; the `cells` list carries `text`, `colspan`, `rowspan`.
- **Asset extraction.** Walk `word/_rels/document.xml.rels` to map
  every `r:embed` / `r:link` to its target. Embedded images live at
  `word/media/`. For each, compute SHA-256, content-type via
  python-magic, dimensions via Pillow, and the nearest paragraph
  caption candidate (the next paragraph whose style is `Caption`,
  fallback to the same-paragraph alt text).
- **Block ids** are deterministic:
  `blk_{sha1(filename + position + first 32 chars of text)[:12]}`.
  Same input → same id.

**Test plan**

- Golden DOCX in `tests/fixtures/docx/` covers: H1/H2/H3, body
  paragraphs, bullet list (3 levels), numbered list with restart,
  one table with merged cells, two embedded PNGs (one with caption,
  one without), one inline code run.
- `pytest -k docx_golden` asserts:
  - Block count and types match.
  - Table block exposes the correct cell shape.
  - Asset manifest has 2 entries with non-empty hashes.
  - Re-running on the same fixture produces byte-identical artifacts
    (determinism check).

### Story 3 — PDF extraction upgrade

Original tasks preserved. Refinements:

- **Block geometry.** PyMuPDF returns blocks with `bbox`, `lines`, and
  per-span fonts/sizes/flags. We persist:
  ```
  block.id, block.type, block.text,
  block.bbox = [x0, y0, x1, y1],
  block.page,
  block.order_in_page,
  block.font.size, block.font.family, block.font.weight ∈ {regular, bold},
  block.is_likely_heading (heuristic: top 1.5σ font size on the page AND ≤ 80 chars),
  block.confidence_signals
  ```
- **Heading inference.** Use a per-document Z-score over font size to
  pick H1/H2/H3. A page with only one font tier produces no heading
  blocks and a `low_heading_signal` warning.
- **Repeated header/footer detection.** For each page, compare the
  topmost and bottommost text spans across pages. A span repeated on
  ≥ 60% of pages with byte-equal text and bbox within 5 px tolerance
  is flagged as a header/footer and excluded from the main block
  stream (still emitted into `header-footer.jsonl` for forensics).
- **Scanned/empty PDF detection.** If `total text chars / total pages
  < 30` AND the document has at least one image-heavy page, emit
  `quality.scanned_or_image_only` warning. Still produce an artifact
  with what we have; do not fail the upload.
- **Tables.** PyMuPDF 1.23+ exposes `page.find_tables()`. For tables
  whose `accuracy` is below 0.8 we re-run pdfplumber on that page
  region and merge. Tables become block_type `"table"` with the same
  shape as DOCX.
- **Embedded images.** `page.get_images(full=True)` + `doc.extract_image(xref)`.
  Same hash/Pillow/python-magic pipeline as DOCX.

**Test plan**

- `tests/fixtures/pdf/multi_page_with_headers.pdf` — repeated header
  is filtered.
- `tests/fixtures/pdf/scanned.pdf` — emits the right warning, does
  not crash.
- `tests/fixtures/pdf/two_column.pdf` — block order respects reading
  order (this is a PyMuPDF default but we should assert it because
  we depend on it).

### Story 4 — Artifact model and registry hardening

Refinements:

- The `Artifact` model becomes:
  ```python
  class Artifact(BaseModel):
      id: str                     # opaque, server-generated
      document_id: str
      name: str                   # e.g. "source-blocks.jsonl"
      version: int                # monotonic per (document_id, name)
      content_type: str
      size_bytes: int
      sha256: str                 # hex
      path: str                   # storage adapter path
      producer: Literal["upload-service","extraction-service","markdown-service"]
      created_at: datetime
      created_by: str | None      # user/agent id
      previous_version_id: str | None
  ```
- **Versioning.** Re-extracting (e.g. user re-uploads or operator
  triggers a re-run) creates a new artifact with `version = prev + 1`
  and `previous_version_id` set. Old versions are not deleted.
- **Manifest pointer.** Each document has a `latest_artifacts: dict[name, artifact_id]`
  pointer, atomically updated when a new version lands. The UI reads
  through this pointer.
- **Garbage collection** is out of scope for Week 3, but the schema
  supports it (no orphan artifacts; `previous_version_id` is the
  retention chain).

### Story 5 — Markdown normalization

Refinements (updated for the Pandoc decision):

- Markdown projection moves into its own module
  `extraction-service/markdown_projector.py` exposing two strategies
  behind a common signature:
  `project(input_path, blocks, assets) -> tuple[content_md: bytes, warnings: list[Warning]]`.
  - `DocxPandocProjector` — wraps `pandoc` via `pypandoc`, post-
    processes the AST with `panflute`, then formats with `mdformat`.
  - `PdfNativeProjector` — composes Markdown directly from
    `source-blocks.jsonl` (PyMuPDF output), then formats with
    `mdformat`.
  The strategy is selected from the document's `content_type` so the
  upstream pipeline does not need to care which one runs.
- Both strategies preserve `<!-- source:blk_xxx -->` anchors so the
  Source Preview UI's hover-sync feature (block ↔ markdown highlight)
  works on output from either.
  - For Pandoc: a panflute filter rewrites the AST to insert HTML-
    comment anchors before each block-level node, keyed off the
    block-id we computed in Story 2.
  - For PDF: anchors are emitted from our token writer.
- Both strategies prepend an HTML-comment frontmatter line with the
  source artifact hashes so a consumer can verify the Markdown was
  generated from a known source-blocks artifact.
- **Tables**:
  - DOCX (Pandoc): native GFM tables with merged-cell handling done
    by Pandoc. Lossy-merge cases emit `warning.lossy_table_merge`
    when our panflute filter detects a flattened cell.
  - PDF: GFM tables; merged cells degrade to repeated text with a
    `<!-- table cell merged -->` note and the same warning.
- **Images**: rendered as `![alt](asset:{asset_id})` with our custom
  `asset:` scheme that the frontend resolves to the artifact CDN URL.
  - DOCX path: panflute filter walks `Image` nodes and rewrites
    `.url` from the Pandoc-extracted relative path to `asset:{id}`,
    using a lookup keyed on the file hash captured during Story 2's
    asset extraction.
  - PDF path: token writer emits the form directly.
- **Frontmatter**: an HTML-comment block at the top of `content.md`
  records `source_blocks_sha256`, `asset_manifest_sha256`,
  `pandoc_version` (DOCX path), and `extractor_version` so the
  Markdown is auditable.
- **Determinism**: after assembly, run the bytes through `mdformat`
  with a pinned config (`{wrap: keep, number: keep, code-block-style:
  fenced}`). The pinned Pandoc version + pinned mdformat config gives
  us byte-equal output for byte-equal input. Asserted in the
  determinism test suite.
- **Failure handling**: a non-zero `pandoc` exit emits
  `extraction.failed{stage="markdown_projecting",
  error_kind="pandoc_failure", stderr_tail=…}` and lands the document
  in `failed` with a typed `ExtractionError` so the UI shows the
  stepper frozen on Plan and a retry affordance.
- Emit `markdown.completed{bytes, hash, projector="docx_pandoc" |
  "pdf_native"}` and persist the artifact.

### Story 6 — Source Preview UI (modern enterprise treatment)

This is the most user-visible deliverable. The Source tab on the
document detail becomes a five-pane inspector with motion choreography
that conveys meaning, not decoration.

#### Layout

```text
┌───────────────────────────────────────────────────────────────┐
│ Document detail header (filename · status · meta · close)     │
├───────────────────────────────────────────────────────────────┤
│  [Preview]  [Blocks]  [Markdown]  [Warnings (2)]  [Assets (3)]│  ← sub-tab strip
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  ▼ active sub-tab content                                     │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

The five sub-tabs:

1. **Preview** — original document rendered as an image stream (PDF
   pages rendered via `react-pdf`; DOCX pages via a per-page rasterized
   thumbnail rendered server-side and served as a static asset).
   Hovering a block in the right rail highlights the corresponding
   bbox on the page. Default landing tab when the document is
   terminal; falls back to **Blocks** when the document is still
   extracting.
2. **Blocks** — TanStack-Table view, virtualized, columns: id, type,
   page, text preview, confidence, warnings. Row hover ⇒ row
   highlighted in the Markdown panel and (on Preview tab) bbox lit on
   the page.
3. **Markdown** — `react-markdown` rendering of `content.md` with
   Shiki-highlighted code blocks. Block anchors in the source
   (`<!-- source:blk_xxx -->`) are preserved as invisible
   anchor elements; hovering a block id elsewhere scrolls the
   Markdown panel to that anchor smoothly. A "Copy raw" button copies
   the unrendered Markdown to clipboard with a Sonner toast.
4. **Warnings** — list of `ExtractionWarning` items, grouped by
   severity. Each row uses our existing `.issue` / `.ok` /
   `status-chip` primitives from `components-common.md`. Empty state
   ("No extraction warnings") uses the standard `.empty-state` card.
5. **Assets** — grid of asset thumbnails. Each thumbnail shows the
   image, filename, size, and click→lightbox. Lightbox lazy-loads via
   `yet-another-react-lightbox`. Right-click on a thumbnail opens a
   small menu (Download original, Copy asset URL).

The five sub-tabs are state in the URL hash (`#preview`, `#blocks`,
…) so deep-linking and browser-back work.

#### Motion choreography

| Trigger | Effect | Tokens |
| --- | --- | --- |
| Sub-tab switch | Cross-fade between sub-tab bodies (200 ms, ease-out). The strip's underline rail uses Framer Motion's `layoutId="source-tab-rail"` for a magnetic slide. | `--t-base` (180 ms) |
| Block hover | Markdown panel scrolls to corresponding `<a name>` anchor with a 300 ms `easeInOutCubic` smooth-scroll, and the matching paragraph gains a 1.2 s `accent-soft` highlight band that fades out. | spec'd in `operational-systems.md` |
| Stage advances during extraction | Stage stepper's active dot animates `scale 1 → 1.06 → 1` once when the stage transitions; the previous stage's connector fills with success green over 250 ms. | matches the existing `@keyframes stage-pulse` |
| Asset thumbnail mount | Stagger reveal: 50 ms apart, capped at 4 items. Each thumbnail enters with `opacity 0 → 1` and `translateY(8px → 0)`. | `--t-fast` (120 ms) per item |
| Warning banner mount | Slides down 16 px with a soft spring (Framer Motion `type: "spring", stiffness: 320, damping: 28`). | one-off |
| Skeleton → content | Cross-fade 250 ms. Skeleton shape matches the final layout pixel-for-pixel (no layout jump). | shimmer keyframe |
| Toast | Sonner default (slide up + fade). Position bottom-right. | n/a |
| Lightbox open | `react-lightbox` default scale-in + backdrop fade (150 ms). | n/a |

All of the above respect `prefers-reduced-motion: reduce` via the
global override in `styles.css`. The block-hover scroll degrades to
`scrollIntoView({ behavior: "auto" })` when motion is reduced.

#### Empty / loading / error states (per sub-tab)

Per the design system rule that every panel must declare empty,
loading, restricted, stale, and error states.

| Sub-tab | Loading | Empty | Error |
| --- | --- | --- | --- |
| Preview | Page thumbnails as `.bu-skeleton-tile` placeholders | "Preview not available for this document type" + link to Blocks | "Could not render the original; the source artifact is preserved" + Download original link |
| Blocks | Skeleton table rows | "No blocks were extracted" + warning-callout if `quality.scanned_or_image_only` is set | Inline error banner above the table |
| Markdown | Skeleton lines (3 sizes, randomized) cross-fading shimmer | "No content was projected" + retry-extraction button | Same |
| Warnings | n/a (text only) | "No extraction warnings" `.ok` chip | Same |
| Assets | 6 skeleton thumbnails | "No assets were embedded in this document" | Same |

#### Accessibility

- Sub-tab strip is a real `<nav role="tablist">` with `aria-controls`
  pointing at panel IDs; each panel has `role="tabpanel"` and
  `tabindex={0}`. Arrow keys move focus across tabs.
- The Preview/Blocks sync uses ARIA live announcements: "Showing
  block 4 of 87 on page 2." Updates announce on hover/focus, not on
  every scroll tick (debounced to ≥ 200 ms).
- Lightbox traps focus, returns focus to the asset thumbnail on
  close.
- Markdown rendering uses semantic tags (`<h2>`, `<h3>`, `<table>`,
  `<figure>`) — no `<div>` soup.
- All interactive controls have a real focus ring (the existing
  `--focus-ring` token).

## Test plan (refined)

### Backend

- **Determinism suite**: each fixture is processed twice; artifact
  bytes (after `mdformat`) must be identical. Hashes compared.
- **Golden artifact suite**: `tests/golden/{fixture}/` contains
  expected `source-blocks.jsonl`, `content.md`, `asset-manifest.json`.
  `pytest -k golden` re-runs and diffs. Updates require an explicit
  `pytest --update-golden` flag.
- **Contract tests**: against the OpenAPI export, using `schemathesis`
  to randomized-fuzz the internal extraction endpoints with realistic
  payloads.
- **Property tests**: `hypothesis` strategies for block ordering and
  asset hash uniqueness.
- **Service-failure tests**: kill extraction-service mid-call, assert
  document lands in `failed` with the right `ExtractionError.kind`.
- **Performance tests** (smoke, not gating): a 50-page PDF must
  extract in ≤ 8 s on the CI runner; otherwise emit a warning in CI
  output (don't fail the build until we have an SLO).

### Frontend

- **Playwright e2e** (uses the existing `apps/web/playwright/` once we
  add it):
  - Upload a DOCX, watch the stage stepper advance, open Source tab,
    switch through all five sub-tabs.
  - Hover a block → assert the Markdown anchor receives the highlight
    class within 200 ms.
  - Open an asset → lightbox opens; press Escape → focus returns to
    the thumbnail.
- **React unit tests** (Vitest):
  - `<StageStepper>` for every status string in `mapStatusToStage`.
  - `<SourcePreview>` snapshot tests for each sub-tab in each state
    (loading / empty / populated / error).
- **Reduced-motion tests**: `vi.stubGlobal('matchMedia', …)` to assert
  the global motion override silences transitions and the block-hover
  scroll degrades to non-smooth.
- **Accessibility audit**: run `axe-core` against the document detail
  surface; fail the suite on any AA violation.

### Cross-service

- Gateway proxy tests (preserved from original plan):
  - `/v1/documents/{id}/blocks`
  - `/v1/documents/{id}/markdown`
  - `/v1/documents/{id}/assets`
  - `/v1/documents/{id}/source-quality`
  - `/v1/documents/{id}/artifacts`
- All five must return typed payloads, not raw dicts.

## Observability

### Metrics (Prometheus)

```
extraction_documents_total{outcome="success|failed",content_type=…}
extraction_warnings_total{kind=…}
extraction_stage_seconds{stage=…}             histogram
markdown_artifact_bytes                        histogram
extraction_service_up                          gauge
```

Dashboards (alpha — render with Grafana once the collector is in
staging):

- Extraction throughput (docs/min) by content type.
- p50 / p95 stage latency over time.
- Top warning kinds in the last hour.
- Failed-doc count and the last 10 failures with error kind.

### Tracing

Each `ExtractionRequest` opens a parent span; child spans for:
`docx_parse`, `pdf_parse`, `numbering_walk`, `header_footer_detect`,
`markdown_project`, `mdformat`, `artifact_persist`. Span attributes
include `document_id`, `block_count`, `asset_count`, and (for failures)
the truncated traceback.

### Alerting (Phase 2, not Week 3)

- Error budget per content type: > 2% failures over 30 minutes pages
  the on-call.
- p95 stage latency above 10× steady-state for any stage pages.

## Operational concerns

- **Disk usage.** Artifacts are versioned and never deleted in Week 3.
  Land a metric (`artifact_storage_bytes`) so we can see the curve and
  retire / GC in a later week.
- **Concurrency.** The extraction-service runs PyMuPDF in a thread
  pool with a worker count of `min(4, os.cpu_count())`. PDF extraction
  is I/O- and CPU-bound; threading is fine for the AGPL-clean variant
  we ship.
- **Memory ceiling.** A 250 MB PDF with image-heavy pages can produce
  500 MB+ of intermediate state. Add a soft RSS guard (psutil) that
  emits a `quality.memory_pressure` warning when the worker exceeds
  1 GB and aborts cleanly.
- **Pandoc subprocess startup.** Each DOCX extraction pays ~150 ms
  of `pandoc` startup. Acceptable for Week 3 scale (≤ a few docs per
  minute). The future optimization is **`pandoc-server`** (Pandoc 3.0+
  ships a JSON-over-HTTP server that eliminates per-call startup);
  the markdown_projector module is structured so swapping `pypandoc`
  for an HTTP client to a co-located `pandoc-server` is a contained
  change.
- **Pandoc version pinning.** The container Dockerfile installs a
  pinned major.minor version (e.g. `pandoc=3.1.x`). A boot check
  asserts `pandoc --version` matches the expected major; mismatch
  fails the readiness probe. This protects determinism — Pandoc's
  Markdown writer formatting has shifted across minor versions in
  the past.

## Out of scope (preserved)

- OCR beyond a warning/fallback marker.
- Perfect PDF table reconstruction.
- DITA XML generation changes.
- LLM topic planning improvements.
- Real RabbitMQ worker orchestration.
- Production MinIO migration if filesystem adapter is still the alpha
  storage layer.

## Final acceptance checklist (refined)

Week 3 is complete when:

- [ ] DOCX upload generates source blocks (incl. nested lists,
      merged-cell tables), assets with hashes, deterministic
      Markdown, and registry entries with version + hash + path.
- [ ] PDF upload generates page-aware source blocks with bbox and
      font signals, repeated header/footer detection, asset extraction
      where embedded, and a clear `quality.scanned_or_image_only`
      warning when relevant.
- [ ] Re-running extraction on the same input produces byte-identical
      artifacts (`pytest -k determinism` is green).
- [ ] Artifact registry surfaces version, hash, size, path, producer,
      created-at, and the previous-version-id chain. The latest pointer
      is atomic.
- [ ] The Source Preview UI ships all five sub-tabs (Preview, Blocks,
      Markdown, Warnings, Assets) with: shared-element tab rail,
      block ↔ markdown hover sync, asset lightbox, copy-to-clipboard
      for raw Markdown, and per-sub-tab loading/empty/error states.
- [ ] Motion choreography matches the table above. All animations
      degrade under `prefers-reduced-motion: reduce`.
- [ ] Live pipeline updates the stage stepper with no UI jank
      (verified by Playwright e2e; no layout shift > 0.05 CLS).
- [ ] Prometheus metrics + OTel traces emit for every extraction.
      Failed extractions land in `failed` state with a typed
      `ExtractionError` and a corresponding `extraction.failed` audit
      event.
- [ ] Existing Week 2 upload, BU dashboard, document delete, and
      review/export paths remain green (`uv run pytest && npm run build &&
      npm test`).
- [ ] OpenAPI exports for both `gateway` and `extraction-service`
      committed to `contracts/openapi/`.

## Engineering choreography for the week

(Not motion design — schedule.)

| Day | Focus |
| --- | --- |
| Mon | Story 1: service boundary, contracts, ASGI transport, audit events. Frontend: scaffold Source Preview shell with 5 placeholder sub-tabs. |
| Tue | Story 2: DOCX numbering walker, run metadata, table extraction, asset registry. Frontend: Blocks sub-tab + virtualized table. |
| Wed | Story 3: PDF block geometry, heading inference, header/footer detection. Frontend: Preview sub-tab + react-pdf integration + block hover sync. |
| Thu | Story 4: artifact versioning, manifest pointer, retention chain. Frontend: Warnings sub-tab + Assets grid + lightbox. |
| Fri | Story 5: Markdown projector + mdformat. Story 6 polish: motion choreography pass, accessibility audit, Playwright e2e. Determinism + golden suites green. |

If a story slips, the cuttable scope is: Preview sub-tab (drop to a
"Preview unavailable" empty state), the Sonner toast for copy
(silent copy still works), and the asset lightbox (clicking simply
opens in a new tab).

## References

- DESIGN.md › Information Architecture Principles —
  `/Users/.../DITAgen/DESIGN.md`
- `docs/design/components-common.md` — Stage Stepper, Hero Dropzone,
  Index List + Toolbar, status-chip, hover-revealed delete patterns.
- `docs/design/operational-systems.md` — motion contracts, reduced-
  motion override matrix, scrollbars, accessibility, command palette
  (future).
- ADR-006 — frontend & API workflow boundaries.
- ADR-003 — processing pipeline and DITA model.
- PyMuPDF docs — https://pymupdf.readthedocs.io/
- python-docx docs — https://python-docx.readthedocs.io/
- Pandoc User's Guide — https://pandoc.org/MANUAL.html
- Pandoc API and AST — https://pandoc.org/using-the-pandoc-api.html
- panflute (Python AST filters) — http://scorreia.com/software/panflute/
- pypandoc — https://github.com/JessicaTegner/pypandoc
- Framer Motion — https://www.framer.com/motion/
- Shiki — https://shiki.style/
- TanStack Table & Virtual — https://tanstack.com/
- mdformat — https://mdformat.readthedocs.io/
