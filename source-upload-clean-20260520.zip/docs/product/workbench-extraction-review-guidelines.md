# Workbench Extraction Review Guidelines

This is the normative guide for Workbench extraction review. It defines what the reviewer verifies, which UI states are authoritative, and how automated feedback reports must be shaped. The source document is the ground truth. DITA topic classification, topic-type tuning, and generated topic quality are out of scope for this review.

## Reviewer Preflight

Before opening any document, confirm the session is reproducible.

1. Record the app build (commit short SHA), the document index slug, and the review date (UTC) in the session log. These appear in every report's `## Metadata` table.
2. Verify the dev server is reachable and the document list loads. If the index returns an empty set or a network error, stop and report the blocker — do not synthesize an empty review.
3. Confirm the browser console is open with the `Preserve log` option enabled. Console output is part of the evidence for every finding.
4. If authenticated routes are required, load test credentials from the project's `.env.test` (or equivalent) — never hardcode them in a report.
5. Pin a single browser viewport per batch (the canonical default is visible Chromium at the project's standard width). Mobile and narrow viewports remain out of scope.

A preflight failure is itself reportable: capture the blocker in `## Final Notes` and exit the run instead of producing a partial backlog.

## Review Contract

Review every document in document order, including ready, gated, and failed extraction states.

1. Open the document in the app and inspect the Source and Workbench surfaces that are available for its status.
2. For ready documents, click every Extraction Explorer row and verify that the selected row, source highlight, and inspector all reference the same source block id.
3. For gated documents, review the extraction-needs-review panel before opening any downstream tab. Record every blocking reason, unlocated source block, and review flag group.
4. For failed documents, do not treat an empty block tree as evidence. Record the typed extraction failure reason, failed stage, and whether re-extraction is available.
5. Classify findings by root cause: frontend UX, frontend state, frontend model, frontend mapping, backend extraction, backend artifact semantics, or no issue.
6. Attach an acceptance test to every P0/P1/P2 finding.

## Source Mapping Rules

| Rule | Requirement |
|---|---|
| Source block id is canonical | Selection, hover preview, inspector content, and source highlight must derive from the same source block id. |
| DOCX locators are strict | A parsed `docx:*` locator must match the corresponding rendered DOCX candidate. Text fallback is allowed only when no parsed DOCX locator exists. |
| Mapping failures are surfaced | Any source block that cannot be highlighted in the source preview is an error-level extraction attention signal before the reviewer clicks it. |
| Active and preview are distinct | Hover preview must never overwrite selected source ids or make selected rows look unselected. |
| Locator details belong in the inspector | Row metadata should not repeat raw locators; selected-block details show the locator. |

## Finding Evidence Requirements

Every P0/P1/P2 finding in a generated report must be reproducible from the evidence attached to it. A finding without evidence is a hypothesis, not a defect.

| Evidence | When required | Form |
|---|---|---|
| Screenshot | Always for P0/P1; for P2 when the symptom is visual | PNG saved alongside the report; label `TC-<source-block-id>-before`/`-after` for fix verification |
| Source block id | Always | Quote the canonical `data-source-block-id` and the parsed `docx:*` locator |
| Console capture | Whenever the symptom touches state, selection, or fetch errors | Paste the relevant lines verbatim — do not summarize |
| Network trace | Whenever a gated/failed panel disagrees with backend state | Method, URL, status code, and the response payload's `block_count` / `failure_reason` / `failed_stage` fields |
| Acceptance test | Always for P0/P1/P2 (see Acceptance Test Patterns) | Cite the helper (Playwright/Vitest) and the exact selector or assertion |

"It looked wrong" is not evidence. If the source block id cannot be quoted, the finding belongs to the Unmapped Block Surfacing acceptance pattern, not the backlog.

## Review Flag Glossary

This table is generated from the backend review flag catalog and is locked by `tests/test_review_flag_glossary_doc.py`. Keep the code set identical to `source-block.schema.json#$defs.reviewFlag.properties.code.enum`.

| Code | Severity | Meaning | Reviewer action |
|---|---|---|---|
| `LOW_BLOCK_TYPE_CONFIDENCE` | warning | The classifier is not confident that the assigned source block type is correct. | Compare the row with the source and confirm the block type before approving. |
| `ORPHAN_TABLE_ROW` | warning | A table row appears without a first-row sibling in the same table, which can mean rows were dropped. | Inspect the source table and verify that all expected rows are represented. |
| `MIXED_HEADING_STYLE` | info | The paragraph style is used for both headings and non-heading content, so heading intent is ambiguous. | Check the source style and surrounding structure before relying on this heading. |
| `SUSPECTED_HEADING_FRAGMENT` | info | A heading ends with sentence punctuation, which can indicate a wrapped paragraph was promoted. | Confirm whether the row is truly a heading or should remain body content. |
| `HEADING_BY_FORMATTING` | info | The heading was inferred from formatting or numbering rather than an explicit heading style. | Verify the visual source heading before accepting the inferred hierarchy. |
| `HEADING_IN_CELL` | warning | A paragraph inside a table cell was promoted to a heading, which is usually a false positive. | Check the table cell and demote the block if it is regular cell content. |
| `SYNTHETIC_ROOT_HEADING` | warning | The structure tree created a root heading because body content had no real top-level heading. | Review the document opening and confirm the synthetic container is acceptable. |
| `ASSET_REF_UNRESOLVED` | error | A source block references an extracted asset that is missing from the asset manifest. | Open the source and asset list, then re-extract or repair the missing asset reference. |
| `NESTED_TABLE` | info | A table row contains one or more nested tables emitted as separate source blocks. | Verify the parent row and nested rows preserve the source table relationship. |
| `DEEP_NESTING_UNSUPPORTED` | error | A nested table contains another nested table beyond the extractor's supported depth. | Inspect the source table and manually account for content below the supported nesting level. |
| `FLOATING_TABLE` | warning | A floating or text-wrapped table may not appear in the same reading order as the source. | Compare the table position in the source with the extracted document order. |
| `POSSIBLY_CALLOUT` | info | A short formatted paragraph may be a callout or note instead of normal body text. | Check the source styling and decide whether the block needs note/callout treatment. |
| `SUBDOC_UNSUPPORTED` | error | The DOCX references a linked sub-document that this extractor does not follow. | Open the source package and process the linked sub-document separately if needed. |
| `MATH_CONTENT` | warning | The paragraph contains OOXML math and the extracted text may only be a placeholder. | Compare the equation in the source and capture or repair the math content. |
| `HAS_INSERTIONS` | warning | Tracked-change insertions are present in the source paragraph. | Review the source changes and confirm whether inserted text should be kept. |
| `HAS_DELETIONS` | warning | Tracked-change deletions are present; deleted text is not reflected as normal extracted content. | Review the source changes and confirm the surviving text is correct. |
| `SMARTART_DROPPED` | error | A SmartArt diagram was detected but not extracted. | Inspect the source diagram and capture the missing content manually or re-extract with support. |
| `HIDDEN_TEXT_DROPPED` | warning | Hidden text runs were filtered out of the extracted paragraph. | Open the source paragraph and confirm the hidden content was intentionally excluded. |
| `MULTI_COLUMN` | warning | The section uses multi-column layout that may be flattened in a different reading order. | Compare extracted order with the source columns before approving the section. |
| `NO_HEADINGS_FOUND` | warning | No high-confidence heading styles were found in the document body. | Review the structure tree and add or confirm section boundaries before downstream use. |

## Blocked Document Subprocess

### Failed Extraction

1. Read the `Extraction failed` panel.
2. Record the failure reason and failed stage.
3. Open the upload/source file when needed to determine whether the input is corrupted, encrypted, too large, empty, or blocked by an unavailable extractor dependency.
4. Use the admin re-extract action only after the input condition is understood.
5. Do not report missing Workbench rows for a failed document. The valid state is the explicit failed panel with `block_count: 0` and no fake quality gate.

### Extraction Needs Review

1. Read the `Extraction gated` panel before opening downstream tabs.
2. Record grouped blocking reasons, review flag counts, and unlocated source block ids from the extraction review summary.
3. Use unlocated-block chips or source links to inspect the affected blocks.
4. Resolve the underlying extraction or mapping issue before approving downstream analysis. Gate override is an audited admin action, not a review shortcut.
5. Report whether disabled-tab tooltips distinguish gated extraction from failed extraction.

## Acceptance Test Patterns

### Row Click Sync

Use the Workbench Playwright helper that opens a document, clicks `.extraction-row[data-source-block-id="<id>"]`, and asserts exactly one `.source-viewer-active[data-source-block-id="<id>"]` exists. The Customer Change Requests canary is `docx:p:35`.

### Actionable Review Flag

Use a Vitest model or inspector test with a source block carrying a catalog code. Assert that the rendered signal uses the catalog severity, label, explanation, and reviewer action. Do not accept regex-derived severity or humanized fallback text for known codes.

### Unmapped Block Surfacing

Use `matchBlocksToCandidates()` with a parsed `docx:*` locator that has no corresponding candidate. Assert that `sourceMatchFailureIds()` returns the block id and that the Extraction Explorer model emits `SOURCE_HIGHLIGHT_UNMAPPED` with error severity.

### Hover Preview Isolation

Use a Vitest model test that sets a selected source block id, then dispatches a hover event over a different row. Assert three invariants:

1. The previously selected `.extraction-row.active` element still carries the `active` class modifier — hover never strips it.
2. The `.source-viewer-active` highlight still resolves to the originally selected source block id.
3. The hover preview surfaces appear in DOM/state slots that are distinct from the selected-block inspector content (verify via separate model selectors or hook outputs, not shared state).

A hover that overwrites selection is a P0 (see Source Mapping Rules: "Active and preview are distinct").

### Gated Tab Affordance

Use a Playwright assertion against a gated document. Assert that downstream tabs (Plan/Review/Export) are disabled, that the disabled-tooltip text references the gated extraction state (not the failed state), and that `aria-disabled="true"` is present on each disabled tab trigger. Indistinguishable tooltips between gated and failed states are a P1.

## Automation Guardrail

`apps/web/scripts/workbench-line-by-line-review.mjs` is the only supported batch line-review automation.

Required output per document report (the order the script emits, top to bottom):

1. `## Metadata` — document id, slug, review date, app status, browser pass status, source-block totals, locator coverage, block histogram, visual mismatch count, evidence screenshot reference.
2. `## Executive Summary` — one-row-per-category table: extraction correctness, source mapping, table/list/heading representation, UI clutter, attention/review workflow, accessibility/keyboard review, and `P0=N; P1=N; P2=N.` for highest-priority fixes.
3. `## Document-Specific Backlog` — grouped P0/P1/P2 findings only. P3 findings are intentionally excluded from this table; if no blocking issue exists, the script emits a single `No blocking document-specific issue` row. The columns are `Area | Finding | Recommended fix | Fix scope | Priority`.
4. `## Visible Chromium Line-by-Line Verification` — one row per ready source block, with the 24-column schema the script emits (line index, source block, type, locator, parent path, structure details, visual status, source highlight, why-right, what-wrong, improvement, information economy, placement, representation, row-label quality, visual hierarchy, selection state, reviewer action clarity, inspector usefulness, terminology, accessibility, root cause, priority, acceptance test).
5. `## Final Notes` — restates that DITA topic classification is out of scope and captures any reviewer-specific caveats.

Invariants the script enforces:

- No `[object Object]` substring may appear anywhere in a generated report or the batch index.
- For any document whose `status !== "ready_for_review"`, the report body must contain the literal string `Line-by-line review blocked by status`. This sentinel is checked verbatim — paraphrases will fail the assertion.
- `docs/product/workbench-feedback/index.md` must include the batch table (one row per report, with `App status`, `Browser line review`, `Source blocks`, `Locator coverage`, `Visual mismatches`, and `P0 / P1 / P2` count columns) and a `## Top Repeated Issues` appendix. The appendix is capped at 12 rows, grouped by `priority::fix_scope::what_wrong`, listing at most 3 first-affected documents per row, sorted by descending count then alphabetic `what_wrong`. P3 issues are excluded from this rollup.

The automation script and this guideline must stay in lockstep. If the required output sections, the blocked-status sentinel, or the rollup invariants change, update both the script assertions and this document in the same change. The lock test is `tests/test_review_flag_glossary_doc.py` for the glossary table; section-shape lockstep currently relies on this guideline being treated as normative — any drift between this section and `assertReportContent`/`writeIndex` in the script is a P1 documentation finding.

## Severity And Fix Rubric

Severity answers *how bad is the problem?* Priority answers *when do we fix it?* This rubric assigns the two together because, for a reviewer-facing artifact, every blocking defect is also fix-worthy. If the two ever diverge for a specific finding (e.g., a true P0 with no fix path), record the severity here and document the deferred priority in the report's `## Final Notes`.

| Severity | Meaning | Example |
|---|---|---|
| P0 | Data loss, wrong source mapping, or a user could approve incorrect extraction. | Row highlights the wrong source block; extracted text omits table cells. |
| P1 | Review-blocking confusion or inconsistent state. | Review flag has no action; failed extraction looks like an empty Workbench. |
| P2 | Slows reviewers or creates avoidable doubt. | Table rows are accurate but lack row/table context. |
| P3 | Polish or readability improvement. | Heading provenance could be summarized better. |

P3 findings are **never** included in the Document-Specific Backlog or the Top Repeated Issues appendix. They live in the line-by-line table only and exist to document polish work the team may choose to bundle later.

| Fix scope | Use when |
|---|---|
| Frontend UX | Backend data is correct, but presentation is misleading or inefficient. |
| Frontend state | Selection, hover, focus, search, filters, or keyboard behavior diverges. |
| Frontend model | The right-pane tree, grouping, attention selector, or lookup maps need change. |
| Frontend mapping | Source anchors and extraction rows do not map or scroll correctly. |
| Backend extraction | Source text, block type, cells, list levels, locators, or metadata are wrong or missing. |
| Backend artifact semantics | Backend emits data that is technically valid but too ambiguous for reliable review. |
| No issue | Extraction and UX are acceptable for this row. |

## False Positives Not To Report

Reviewers regularly want to flag these states; none of them are defects in extraction review.

- A `warning`-severity review flag (e.g., `LOW_BLOCK_TYPE_CONFIDENCE`, `MIXED_HEADING_STYLE`) appearing on a block that *is* correct after manual inspection. The flag did its job by prompting the check.
- A gated panel that surfaces multiple blocking reasons. Multiple reasons are by design; only an inconsistent or empty panel is a finding.
- A `SYNTHETIC_ROOT_HEADING` on a document whose source opens with body content. The synthetic container is intentional and is acknowledged in the inspector.
- A failed-extraction document whose Workbench row tree is empty. The valid state is `block_count: 0` plus the explicit failure panel — there is no "missing data" to report.
- Differences in capitalization or whitespace between the source preview and the extracted text when the source DOCX itself contains the same difference. The source is ground truth.
- DITA topic classification or topic-type assignment in the downstream tabs. These are out of scope (see below).

## Definition Of Done

A document review is complete when all of the following hold. Sign the report's `## Final Notes` with the reviewer initials and date only after this checklist passes.

- Every ready source block has been clicked and verified per the Row Click Sync acceptance pattern.
- For gated documents: every blocking reason group and every unlocated source block id has been recorded in the backlog or marked as "no issue."
- For failed documents: the failure reason and failed stage are quoted verbatim; the re-extraction availability is recorded.
- Every P0/P1/P2 finding has a fix scope, a recommended fix, and an acceptance test pointer attached.
- Every P0/P1 finding has its evidence (screenshot, console capture, network trace as applicable) attached or referenced by stable label.
- The generated report passes the script's `assertReportContent` invariants (run the automation; do not hand-edit a report to bypass an assertion).
- The batch `index.md` has been regenerated so the document's counts roll up into the batch table and the Top Repeated Issues appendix.

If any item is incomplete, the report status remains in-progress regardless of how many findings were recorded.

## Out Of Scope

- DITA topic classification, topic-type tuning, and generated topic quality.
- Plan, Review, and Export tab UX beyond disabled-tab messaging.
- Mobile and narrow-viewport review.
- Full keyboard and screen-reader audit beyond the row-sync assertions above.
- Generated XML/DITA validity checks — handled by `validation-service` and surfaced through a separate review track.
- Backend extractor performance and latency. Capture latency observations in a separate operations report, not the extraction review.
