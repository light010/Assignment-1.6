# Contract Migration Playbook

Artifact contracts under `contracts/artifacts/` are versioned producer
interfaces.

- Additive optional fields do not require a schema version bump.
- New required fields require a version bump, a migration note, and a
  producer-output test.
- Removing or renaming fields requires a compatibility plan for existing
  artifacts.
- Every artifact schema must have at least one test that validates real
  producer output against the schema.

Migration files should be named with a sortable prefix, for example:

```text
0001-extraction-quality-v1.md
```
