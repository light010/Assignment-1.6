# OpenAPI Contracts

Each backend service exposes its OpenAPI spec at runtime under
`/openapi.json` (FastAPI default). The committed `.yaml` files in this
directory are point-in-time snapshots produced by
`scripts/regenerate_openapi_contracts.py`, which side-loads each
service's `app/main.py` and serializes `app.openapi()` to JSON.

The files have a `.yaml` extension but contain pretty-printed JSON
(valid YAML, no PyYAML dependency).

## Generated specs (Phase 11, 2026-05-10)

| File | Service | Owns |
|---|---|---|
| `api-gateway.yaml` | api-gateway | Public `/v1/*` routes; auth; proxy to backend services. |
| `extraction-service.yaml` | extraction-service | `/internal/extractions/*`, `/internal/documents/{id}/triage-queue`. |
| `analysis-service.yaml` | analysis-service | `/internal/analyses` orchestrator (Phase 8). |
| `review-service.yaml` | review-service | `/internal/topics/{id}/ops`, `/ops/undo`, approve/reject/assign (Phase 6). |
| `validation-service.yaml` | validation-service | `/internal/validation/dita-files`, `/internal/validation/topic` (Phase 7). |
| `llm-gateway-service.yaml` | llm-gateway-service | `/internal/llm/topic-plan`, `/internal/llm/generate-topic`, `/internal/llm/chat/completions`, `/internal/llm/providers` (Phase 4/8). |

## How to regenerate

```bash
uv run python scripts/regenerate_openapi_contracts.py
```

The script is deterministic (sorted keys, 2-space indent) so running
twice produces identical files. CI should regenerate after every
service-shape change and fail the diff if a route was added without
updating the spec.

## Frontend-consumed endpoints (verify on next export)

The alpha frontend (`apps/web/src/api.ts`) calls the endpoints below.
When the OpenAPI export task runs, confirm each is present and that its
contract matches the frontend type definitions in `api.ts`:

- Auth: `POST /v1/auth/login`, `POST /v1/auth/refresh`.
- Business units: `GET /v1/business-units`, `POST /v1/business-units`,
  `GET /v1/business-units/{id}`, `DELETE /v1/business-units/{id}`,
  `GET /v1/business-units/{id}/documents`,
  `POST /v1/business-units/{id}/documents/uploads`. The `DELETE` endpoint is the
  most recent addition (BU dashboard delete affordance — see ADR-006
  "Business Unit Layer"); confirm it is implemented server-side and
  that its response is `{ ok: true }` or a typed error per the
  application's standard envelope.
- Documents: `GET /v1/documents/{id}/blocks`,
  `GET /v1/documents/{id}/markdown`,
  `GET /v1/documents/{id}/artifacts`,
  `GET /v1/documents/{id}/jobs`,
  `GET /v1/documents/{id}/assets`,
  `GET /v1/documents/{id}/assets/{asset_id}`,
  `GET /v1/documents/{id}/source-file`,
  `GET /v1/documents/{id}/source-quality`,
  `GET /v1/documents/{id}/topic-plan`,
  `POST /v1/documents/{id}/topic-plan/approve`,
  `POST /v1/documents/{id}/exports`,
  `DELETE /v1/documents/{id}` (consumed by the Upload Hub's
  hover-revealed delete affordance — confirm the endpoint exists
  server-side and returns `{ ok: true }` on success).
- Topics: `GET /v1/topics/{id}`, `PATCH /v1/topics/{id}`,
  `POST /v1/topics/{id}/approve`.
- Exports: `GET /v1/exports/{id}/download` (token in query string for
  the download stream).

This list is informational and intended to make the next contract-export
task produce a complete schema. It is not a substitute for the canonical
OpenAPI document.
