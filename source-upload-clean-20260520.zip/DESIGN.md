# DITAgen Design Contract

This is the compact design contract for DITAgen. Use it first for every UI task, then open only the focused design file needed for the screen or system area you are changing.

## LLM Usage Rule

Read this file first. Then read exactly one focused file from `docs/design/` unless the task changes shared tokens, cross-screen behavior, accessibility, loading states, permission handling, or global design rules. Do not load all design docs for a single-screen change.

## Product Direction

DITAgen is an enterprise conversion workspace for turning messy source documents into reviewable DITA topics, maps, validation reports, and export packages. It is an evidence console, not a generic chatbot builder. The product should feel calm, dense, legible, role-aware, and explicit about provenance.

## Primary Journey

`Sign In -> Business Unit Dashboard -> Upload Hub -> Review Workspace -> Export`

Business Unit means the organization or team layer that scopes document
conversion work. The Upload Hub is the canonical post-BU surface — it
combines the BU context, the multi-file dropzone, the live pipeline view
per document, and the document detail in a single page. Projects are not
a user-facing navigation step in the alpha. Any internal grouping needed
by services must remain invisible to the UI and copy.

Uploaded documents become source evidence for Markdown, topic planning,
DITA generation, validation, review, and export.

## Core Principles

- Context first: show tenant, BU, document, role, policy, and artifact version when they affect actions.
- One next action: each screen exposes one dominant next action based on status and permissions.
- Evidence before automation: generated output and agent proposals show source evidence, confidence, citations, and reversible diffs.
- Triage before detail: high-level screens prioritize blockers, assigned work, and ready-to-export items.
- Permission-aware UI: restricted records show safe metadata only, and disabled controls explain the required role or policy.
- No black boxes: long-running work shows stage, last event, elapsed time, retry/cancel state, and last refresh time.
- Readable first, raw second: raw JSON, logs, XML payloads, and hashes are available behind explicit debug/details views.

## Design System Files

- [`docs/design/README.md`](docs/design/README.md): design documentation index and file-selection guide.
- [`docs/design/design-system.md`](docs/design/design-system.md): full token contract, colors, typography, layout primitives, elevation, and shapes.
- [`docs/design/components-common.md`](docs/design/components-common.md): app chrome, shared components, forms, tables, authentication, responsive behavior, and do/don't rules.
- [`docs/design/operational-systems.md`](docs/design/operational-systems.md): accessibility, dark mode, motion, i18n/RTL, state taxonomy, notifications, shortcuts, forms/tables, diffs, versioning, comments, permissions, audit, confidence, onboarding, concurrency, resilience, and search.

## Screen Specs

- [`docs/design/screen-bu-dashboard.md`](docs/design/screen-bu-dashboard.md): BU portfolio command center and Bento workspace selection.
- [`docs/design/screen-project-hub.md`](docs/design/screen-project-hub.md): retired historical Project Hub notes; not an active alpha screen.
- [`docs/design/screen-upload-ingestion.md`](docs/design/screen-upload-ingestion.md): upload command center, preflight, ingestion queue, document strip, and pipeline statuses.
- [`docs/design/screen-review-workspace.md`](docs/design/screen-review-workspace.md): review workspace, source evidence, topic plan, DITA editor, validation, and traceability.
- [`docs/design/screen-export-agent.md`](docs/design/screen-export-agent.md): export readiness, export history, agent proposal cards, MCP activity, and approval constraints.
- [`docs/design/screen-audit-admin-settings.md`](docs/design/screen-audit-admin-settings.md): audit log, settings/admin shell, dangerous settings, and connector setup drawer.

## Required Pipeline Labels

Use these exact user-facing labels: `Queued`, `Uploading`, `Upload Complete`, `Extraction In Progress`, `Extraction Complete`, `Markdown Normalized`, `Topic Plan Ready`, `DITA Generated`, `Validation Passed`, `Validation Warnings`, `Review Ready`, `Approved`, `Export Ready`, `Failed`.

## Global Visual Rules

- Use navy for enterprise framing and blue for primary actions, active tabs, links, focus, and high-emphasis controls.
- Use red only as a controlled brand accent, announcement color, or critical status.
- Use off-white or blue-gray app canvases behind white surfaces.
- Use equal-sized card grids (`repeat(auto-fill, minmax(...))`) for BU selection. Severity is communicated through sort order, a 4-px tone-colored status edge on the card, and a tone-colored meta dot — not through tile size. The previous Bento priority direction has been retired; see [`docs/design/screen-bu-dashboard.md`](docs/design/screen-bu-dashboard.md).
- Use queues, timelines, split workspaces, inspectors, and triage lists for artifact work; do not push selection cards into those surfaces.
- Use brand atmosphere, not ornamental noise: navy framing, restrained surfaces, and subtle tonal depth are welcome; avoid landing-page heroes, decorative gradients, fake 3D extrusion, watermarks, nested cards, and generic SaaS decoration.
- Keep all status indicators accessible: color is never the only signal.

## Information Architecture Principles

These principles are cross-cutting. They came out of UX reviews on the BU
dashboard rebuild and the Upload Hub redesign. They apply to every
screen.

### 1. Chips next to the H1 encode state, not config

A chip on a page header tells the user *the current state of this
surface*. Static configuration ("the conversion target is DITA 1.3",
"my role is org_admin") goes into a Settings drawer or behind an `(i)`
affordance. Mixing them inflates the chrome and dilutes the meaningful
chips.

Concretely, a chip qualifies for the page header when it satisfies all
three:

- **Stateful** — it changes during the user's normal work on that screen
  (a count that ticks up on upload, a status that flips on review).
- **Glanceable** — it answers a question the user has *while doing the
  task* on this screen.
- **Not duplicated** elsewhere in the chrome (top app bar avatar already
  carries identity; breadcrumb already carries location).

If a value is static (set once and persisted), admin-only, or already
elsewhere in chrome, it does *not* belong in the H1 row. Move it into a
`(i)` popover, a side rail, or the Settings surface.

References:

- **Stripe Dashboard / Customers**: just a title and a primary action.
  Org name and role live in the top bar. Filters use chips, but those
  are *applied filters*, not static config.
- **Linear / Issues**: title + count + actions. Tenant name lives in
  the workspace switcher; assignee/role live in row metadata.
- **Vercel / Project**: branch and environment chips that *change* are
  in the chrome; static config (framework, region, build settings) is
  one click away in Settings.

In DITAgen this rule retired three pills from the Upload Hub
(`org_admin`, `DITA 1.3`, `0 B storage`) into a small
[(i) info popover](docs/design/components-common.md#header-context-chips-and-i-popover)
and kept only `N documents` next to the title. Same rule applies to any
new screen.

### 2. Doing vs Managing — split the surface

Almost every enterprise product has at least two views over the same
data: a *doing* view (focused, time-ordered, action-oriented) and a
*managing* view (search, filter, sort, bulk actions). They are
intentionally different surfaces because the user's intent is
different.

| Product | Doing | Managing |
| --- | --- | --- |
| Stripe | "Recent payments" widget | full Payments page |
| Drive | "Recent" | "My Drive" (full library) |
| Linear | "Inbox" (changed for me) | "All Issues" |
| GitHub | dashboard "Recent activity" | full Issues / PRs lists |
| Notion | "Recently visited" | per-page navigation |

In DITAgen this maps to:

- **Upload Hub** = *doing*. Hero dropzone, current session's uploads
  with full progress, link to the full library when there are more
  documents than the Hub should show.
- **Documents** (planned) = *managing*. Searchable, sortable,
  filterable, paginated. Bulk actions. Side-drawer detail view.

When designing a new screen, pick which of these it is. Do not try to
build one screen that does both — it will be cluttered for the doer
and underpowered for the manager.

### 3. Show progress affordances when they're informative; collapse when they're not

A progress indicator (stepper, progress bar, status timeline) is
useful exactly when the underlying state is moving. Once the state
settles, the same indicator becomes decoration.

| State | What the user wants | What the indicator should show |
| --- | --- | --- |
| In flight | "Where is my file in the pipeline right now?" | Full stepper, active stage pulsing |
| Terminal | "Is this ready for me to act on?" | Compact status chip, *not* the full stepper |
| Failed | "What went wrong, and where?" | Stepper frozen at the failed stage, with a retry affordance |

References:

- **Vercel**: live deployments show full step-by-step progress;
  completed deployments collapse to a single "Ready" chip with a
  subtle deploy time.
- **GitHub Actions**: in-progress workflows render step-by-step;
  completed workflows show a single check or X.
- **Linear**: cycles in progress show a progress bar; completed
  cycles collapse to a single line.

In DITAgen this is implemented as the `<DocumentStageRow variant="auto">`
default — full
[Stage Stepper](docs/design/components-common.md#stage-stepper)
for in-progress documents, a compact row with a `.status-chip` for
terminal documents.

### 4. The primary action is the visual hero

Every screen has one thing the user came to do. That thing should be
the *largest, most visible interactive element on the page*. If the
user has to hunt for it, the chrome is too loud.

The Upload Hub's primary action is "get a document into the pipeline."
The dropzone therefore takes the focal area: ~200 px tall, full
content width, a 64-px circular icon, soft accent-glow, drag-over
animation that "opens up" the canvas.

References:

- **Loom / Notion / Figma upload modals**: dropzone is full-width with
  ~200 px+ height, prominent icon, friendly verb-led copy.
- **GitHub uploads**: a large dashed canvas takes the focal area.
- **Dropbox / Drive**: drag-over swaps the canvas to a tinted full-page
  drop affordance.

The same rule applies to the BU dashboard (the BU grid is the selection
action; the metrics strip is supporting), the Upload Hub (the dropzone is
the primary action), and the Review Workspace (the editor + Approve
action).

The
[Hero Dropzone pattern](docs/design/components-common.md#hero-dropzone)
is documented in `components-common.md` and is the canonical example.

### 5. Progressive disclosure beats permanent surfacing

Static, admin-only, or low-frequency information should be reachable
in one click but invisible by default. The
[(i) info popover](docs/design/components-common.md#header-context-chips-and-i-popover)
on the Upload Hub is the canonical example: role, conversion target,
and storage usage are all available, but they don't crowd the chrome.

Apply the same rule to:

- Per-record settings (open in a drawer, not in the row).
- Audit / history (link to a separate Activity surface, not inline).
- Power-user keyboard shortcuts (Cmd-K palette, not always-visible
  hint chips).

## UX Patterns Learned (BU Dashboard rebuild)

These patterns were validated during the BU dashboard rebuild and are now
canonical. Each is documented in detail in
[`docs/design/components-common.md`](docs/design/components-common.md) and,
where the BU screen is the canonical surface, in
[`docs/design/screen-bu-dashboard.md`](docs/design/screen-bu-dashboard.md).

- **The whole card is the affordance.** When a card opens a record, do not
  add a redundant "Open →" CTA pill. Hover lift, `cursor: pointer`, and a
  keyboard-focusable container are enough. Removing the CTA frees footer
  real estate for status meta and a relative timestamp instead.
- **Status edge over tile size.** A 4-px tone-colored left edge plus a
  tone-colored meta dot communicate severity faster than mixed-size tiles
  and keep the grid uniform.
- **Pipeline mini-bar only when there is data.** Empty BUs render no bar; do
  not show a placeholder. The card honestly says "No documents yet" in its
  meta line.
- **Hover-revealed destructive actions, palette-tinted at rest.** The delete
  icon is hidden until the user hovers/focuses the card. At rest it uses
  `--danger`/`--danger-bg`/`--danger-border`; on hover it fills with
  `--danger` and gains a controlled red shadow. A native `confirm` dialog
  with explicit consequences is required before the destructive call.
- **Owner avatars derive initials from `owner_team`.** Two-letter circles
  give ownership a face without external image fetches. Avatars are
  illustrative; pair with the team name in text.
- **No inline hex in component CSS.** All colors flow from `:root` palette
  tokens. New surfaces add palette variables (e.g. `--warn-strong`,
  `--danger-pressed`, `--surface-tint`, `--accent-light`) before they are
  used.
- **Compact metrics strip beats large KPI cards** when the metrics are
  one-glance counts. Use `repeat(5, minmax(0, 1fr))` of 78-px tall cards;
  drop to 3-col then 2-col responsively.
- **Eyebrow pill, not eyebrow text.** A pill with an optional status dot
  provides tenant/role context above the H1 without inflating the title.

## Frontend implementation reference

The shipped CSS variables and primitives live in `apps/web/src/styles.css`.
Their canonical-token mapping is documented in the "Implementation Bindings
(Alpha)" section of
[`docs/design/design-system.md`](docs/design/design-system.md). When code
and spec disagree, file an issue — do not let drift accumulate.
