"""review-service — owner of edit metadata + edit-op surface (Phase 6).

ADR-004 puts review state and edit metadata under this service. Phase 6
fills the prior 3-line skeleton with the typed edit-op API plus the
review-state routes migrated from upload-service.

Routes (Phase 6.B/C):
  POST   /internal/topics/{topic_id}/ops             — apply EditOperation
  GET    /internal/documents/{document_id}/ops       — ordered op log
  POST   /internal/documents/{document_id}/ops/undo  — append inverse op

Routes migrated in Phase 6.D/E (kept on upload-service as thin proxies
during transition):
  POST   /internal/topics/{topic_id}/assign-reviewer
  POST   /internal/topics/{topic_id}/approve
  POST   /internal/topics/{topic_id}/reject

Source of truth: per ADR-004 the audit event log IS the ledger. We do not
maintain a parallel op log — `_document_op_chain` reconstructs the chain
by scanning audit events for
`action == "edit.*"` and matching `extraction_snapshot_id`. The cost is
linear in the audit log size; an alpha-scale cost we accept.
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any

from ditagen_common.artifacts import read_artifact_text
from ditagen_common.auth import assert_role, context_headers, current_user
from ditagen_common.edits import ReplayError, SnapshotMismatchError, replay
from ditagen_common.ids import new_id
from ditagen_common.models import (
    Block,
    EditOperation,
    EditOperationAdapter,
    ExtractionSnapshot,
    Topic,
)
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import emit_audit_event, list_audit_events, request_service
from ditagen_common.store import utc_now
from ditagen_common.store_factory import create_store
from fastapi import Body, Depends, HTTPException, Request
from pydantic import BaseModel

VALIDATION_SERVICE_URL = os.getenv(
    "DITAGEN_VALIDATION_SERVICE_URL", "http://validation-service:8000"
)

app = create_service_app("review-service")
store = create_store("review-service")


class RejectRequest(BaseModel):
    reason: str


# ---------------------------------------------------------------------------
# Helpers — state shape adapters between dict-based JsonStore + typed models
# ---------------------------------------------------------------------------


def _require_topic_record(topic_id: str, user: dict[str, Any]) -> dict[str, Any]:
    state = store.read()
    topic = state.get("topics", {}).get(topic_id)
    if not topic or topic.get("tenant_id") != user["tenant_id"]:
        raise HTTPException(status_code=404, detail="Topic not found")
    return topic


def _topic_from_state_dict(topic_dict: dict[str, Any]) -> Topic:
    """Project a state dict into the typed Topic shape replay() expects.

    Replay correctness depends on reading the IMMUTABLE original fields,
    not the mutable projected ones. State dicts carry both:

      generated_topic.{title, topic_type, short_desc, source_block_ids,
                       dita_xml}   — set at creation, never mutated
      title / topic_type / dita_xml / source_block_ids (top-level)
                                   — projected mutable view written by
                                     `_project_topic_back` after every op

    `_topic_from_state_dict` reads from `generated_topic` first so the
    snapshot replay starts from is identical across runs regardless of
    how many ops have already mutated the top-level view. Fall back to
    top-level only when generated_topic is missing (legacy state).
    """
    generated = topic_dict.get("generated_topic") or {}
    title = generated.get("title") or topic_dict.get("title") or "Untitled"
    short_desc = generated.get("short_desc") or topic_dict.get("short_desc")
    topic_type = (
        generated.get("topic_type") or topic_dict.get("topic_type") or "concept"
    )
    source_block_ids = generated.get("source_block_ids") or topic_dict.get("source_block_ids", [])
    dita_xml = generated.get("dita_xml") or topic_dict.get("dita_xml")
    return Topic(
        topic_id=topic_dict.get("topic_record_id") or topic_dict["topic_id"],
        title=title,
        short_desc=short_desc,
        topic_type=topic_type,
        source_block_ids=list(source_block_ids),
        dita_xml=dita_xml,
    )


def _load_snapshot(document_id: str) -> ExtractionSnapshot:
    state = store.read()
    extraction = state.get("extractions", {}).get(document_id)
    if not extraction:
        raise HTTPException(
            status_code=404,
            detail=f"document {document_id!r} has no extraction record",
        )
    blocks_ref = next(
        (a for a in extraction.get("artifacts", []) if a.get("name") == "source-blocks.jsonl"),
        None,
    )
    if blocks_ref is None:
        raise HTTPException(
            status_code=404, detail="source-blocks.jsonl artifact missing"
        )
    raw_blocks = [
        json.loads(line)
        for line in read_artifact_text(blocks_ref).splitlines()
        if line.strip()
    ]
    blocks = [Block.model_validate(b) for b in raw_blocks]
    snapshot_id = blocks_ref["artifact_id"]
    topic_dicts = [
        t for t in state.get("topics", {}).values() if t.get("document_id") == document_id
    ]
    topics = [_topic_from_state_dict(t) for t in topic_dicts]
    return ExtractionSnapshot(
        snapshot_id=snapshot_id,
        document_id=document_id,
        blocks=blocks,
        topics=topics,
    )


def _ops_from_audit_events(events: list[dict[str, Any]], snapshot_id: str) -> list[EditOperation]:
    ops: list[EditOperation] = []
    for event in events:
        action = event.get("action") or ""
        if not action.startswith("edit."):
            continue
        meta = event.get("metadata") or {}
        op_payload = meta.get("op")
        if not op_payload:
            continue
        if op_payload.get("extraction_snapshot_id") != snapshot_id:
            continue
        ops.append(EditOperationAdapter.validate_python(op_payload))
    return ops


async def _document_op_chain_for_request(
    document_id: str,
    snapshot_id: str,
    *,
    headers: dict[str, str] | None = None,
) -> list[EditOperation]:
    """Reconstruct the ordered op chain by scanning audit-service events."""
    response = await list_audit_events(headers=headers, store=store)
    return _ops_from_audit_events(response.get("events", []), snapshot_id)


def _resolve_target_topic_id(op: EditOperation, default: str) -> str:
    """Op payloads target topics in two shapes: rename / retype /
    raw_xml_override / move-target carry `topic_id` (or
    `target_topic_id`); merge / split affect blocks within a topic, so
    we fall back to the route's path topic_id."""
    payload = op.payload
    target = getattr(payload, "topic_id", None) or getattr(payload, "target_topic_id", None)
    return target or default


def _topic_owning_op_blocks(op: EditOperation, snapshot: ExtractionSnapshot) -> str | None:
    """For block-targeting ops (Merge/Split), find the topic that owns
    the affected blocks in the snapshot. Used by undo when the op
    payload carries `block_ids` rather than `topic_id`."""
    payload = op.payload
    block_ids: set[str] = set()
    if hasattr(payload, "block_ids"):
        block_ids.update(payload.block_ids)
    elif hasattr(payload, "block_id"):
        block_ids.add(payload.block_id)
    if not block_ids:
        return None
    for topic in snapshot.topics:
        if any(b in topic.source_block_ids for b in block_ids):
            return topic.topic_id
    return None


def _project_topic_back(
    topic_record_id: str,
    projected: Topic,
    validation_issues: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Write replay's projected fields back to the state dict.

    Other fields on the dict (generated_topic, traceability, status,
    etc.) are preserved. Status flips to "edited" because every
    successful op is a state change. `validation_issues`, when supplied,
    overwrites the prior list — the post-replay validation call is the
    authoritative view of the projected topic's compliance.
    """
    def update(state: dict[str, Any]) -> dict[str, Any]:
        topic = state["topics"].get(topic_record_id)
        if topic is None:
            raise HTTPException(status_code=404, detail="Topic not found during projection")
        topic["title"] = projected.title
        topic["short_desc"] = projected.short_desc
        topic["topic_type"] = projected.topic_type
        topic["source_block_ids"] = list(projected.source_block_ids)
        if projected.dita_xml is not None:
            topic["dita_xml"] = projected.dita_xml
        if validation_issues is not None:
            topic["validation_issues"] = validation_issues
        topic["status"] = "edited"
        topic["artifact_version"] = new_id("av")
        return topic

    return store.mutate(update)


async def _validate_projected_topic(
    *,
    topic_id: str,
    dita_xml: str | None,
    business_unit_id: str | None,
    project_id: str | None,
    headers: dict[str, str],
) -> list[dict[str, Any]]:
    """Synchronously validate the projected topic via validation-service.

    Phase 7 — review-service no longer imports validate_dita_files;
    it goes through the canonical service. Returns the issues list (may
    be empty); raises HTTPException with the upstream status if
    validation-service is unreachable or returns a non-200.
    """
    if not dita_xml:
        return []
    response = await request_service(
        method="POST",
        base_url=VALIDATION_SERVICE_URL,
        path="/internal/validation/topic",
        headers=headers,
        json={
            "topic_id": topic_id,
            "dita_xml": dita_xml,
            "asset_manifest": {"assets": []},
            "business_unit_id": business_unit_id,
            "project_id": project_id,
        },
    )
    if response.status_code != 200:
        raise HTTPException(
            status_code=502,
            detail=f"validation-service returned {response.status_code}: {response.text}",
        )
    return response.json().get("validation_issues", [])


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@app.post("/internal/topics/{topic_id}/ops")
async def apply_edit_op(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
    body: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Apply an EditOperation to the topic's projected state.

    Body shape: any of the six `EditOperation` variants. Envelope fields
    (op_id, actor_id, created_at, parent_op_id, extraction_snapshot_id)
    are stamped server-side from the user / current snapshot / audit
    chain when omitted by the caller — clients with idempotency
    requirements can pre-set op_id.

    Status codes:
      200 — op accepted and projected
      400 — op failed validation or replay precondition
      404 — topic / extraction / snapshot artifact missing
      409 — op's snapshot_id does not match the document's current snapshot
    """
    topic_dict = _require_topic_record(topic_id, user)
    document_id = topic_dict["document_id"]
    snapshot = _load_snapshot(document_id)
    chain = await _document_op_chain_for_request(
        document_id,
        snapshot.snapshot_id,
        headers=context_headers(request, user),
    )

    body.setdefault("op_id", new_id("op"))
    body.setdefault("actor_id", user["user_id"])
    body.setdefault("created_at", utc_now())
    body.setdefault("extraction_snapshot_id", snapshot.snapshot_id)
    body.setdefault("parent_op_id", chain[-1].op_id if chain else None)

    try:
        op = EditOperationAdapter.validate_python(body)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid edit op: {exc}") from exc

    try:
        projected = replay(snapshot, [*chain, op])
    except SnapshotMismatchError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ReplayError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    op_dump = op.model_dump(mode="json")
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": f"edit.{op.op_type}",
            "resource_type": "topic",
            "resource_id": topic_id,
            "business_unit_id": topic_dict.get("business_unit_id"),
            "project_id": topic_dict.get("project_id"),
            "metadata": {"op": op_dump, "document_id": document_id},
        },
        headers=context_headers(request, user),
        store=store,
    )

    target_topic_id = _resolve_target_topic_id(op, default=topic_id)
    target_projected = next(
        (t for t in projected.topics if t.topic_id == target_topic_id),
        None,
    )
    if target_projected is None:
        target_projected = next(
            (t for t in projected.topics if t.topic_id == topic_id), None
        )
    if target_projected is not None:
        # Phase 7: validate the projected topic synchronously and stamp
        # the issues onto the state dict in the same mutation as the
        # other projected fields. Synchronous because the workbench
        # surfaces issues inline; latency target <200ms locked by
        # `test_validate_topic_latency_under_200ms`.
        validation_issues = await _validate_projected_topic(
            topic_id=target_topic_id,
            dita_xml=target_projected.dita_xml,
            business_unit_id=topic_dict.get("business_unit_id"),
            project_id=topic_dict.get("project_id"),
            headers=context_headers(request, user),
        )
        updated_topic = _project_topic_back(
            target_topic_id, target_projected, validation_issues=validation_issues
        )
    else:
        updated_topic = topic_dict

    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.edited",
            "resource_type": "topic",
            "resource_id": target_topic_id,
            "business_unit_id": topic_dict.get("business_unit_id"),
            "project_id": topic_dict.get("project_id"),
            "metadata": {
                "op_id": op.op_id,
                "op_type": op.op_type,
                "is_lossy": getattr(op, "is_lossy", False),
            },
        },
        headers=context_headers(request, user),
        store=store,
    )

    return {
        "op_id": op.op_id,
        "op_type": op.op_type,
        "topic_id": target_topic_id,
        "topic": updated_topic,
        "projected_state": projected.model_dump(mode="json"),
    }


@app.get("/internal/documents/{document_id}/ops")
async def list_document_ops(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Return the ordered op log for `document_id`.

    Filtered to `action.startswith("edit.")` events whose
    `metadata.op.extraction_snapshot_id` matches the document's current
    snapshot. Ordering is the audit log's insertion order — the same
    ordering replay() consumes.
    """
    snapshot = _load_snapshot(document_id)
    chain = await _document_op_chain_for_request(
        document_id,
        snapshot.snapshot_id,
        headers=context_headers(request, user),
    )
    return {
        "document_id": document_id,
        "snapshot_id": snapshot.snapshot_id,
        "ops": [op.model_dump(mode="json") for op in chain],
    }


def _invert_op(op: EditOperation, before: ExtractionSnapshot) -> dict[str, Any] | None:
    """Build the body of a new op that reverses `op`.

    Returns the body shape `apply_edit_op` expects (op_type + payload;
    envelope fields are stamped by the route). Returns None if the op
    cannot be inverted from the projected-state-before-op alone.

    The function intentionally returns plain dicts — Pydantic
    construction would force us to provide placeholder envelope strings
    that fail the min_length validators. Validation runs once, when
    `apply_edit_op` calls `EditOperationAdapter.validate_python(body)`.

    Inversion semantics:

      Merge of [a, b] -> derived d   inverse: Split derived at len(a) (Phase 6
                                              limitation: only 2-block merges
                                              produce a clean Split-inverse).
      Split of s @ off -> [a, b]     inverse: Merge [a, b].
      Move b -> T                    inverse: Move b -> original_topic.
      Retype t -> X                  inverse: Retype t -> previous_topic_type.
      Rename t {title, short_desc}   inverse: Rename t with previous values.
      RawXmlOverride t -> xml        inverse: RawXmlOverride t -> previous_xml
                                              (with is_lossy=True preserved).
    """
    from ditagen_common.models import (
        MergeOp,
        MoveOp,
        RawXmlOverrideOp,
        RenameOp,
        RetypeOp,
        SplitOp,
    )

    if isinstance(op, MergeOp):
        if len(op.payload.block_ids) != 2:
            return None
        first_block = next(
            (b for b in before.blocks if b.block_id == op.payload.block_ids[0]), None
        )
        if first_block is None:
            return None
        derived_id = f"blk_m_{hashlib.sha1(op.op_id.encode()).hexdigest()[:12]}"
        return {
            "op_type": "split",
            "payload": {"block_id": derived_id, "char_offset": len(first_block.text)},
        }
    if isinstance(op, SplitOp):
        seed = op.op_id.encode("utf-8")
        a_id = f"blk_s_{hashlib.sha1(seed + b':a').hexdigest()[:12]}"
        b_id = f"blk_s_{hashlib.sha1(seed + b':b').hexdigest()[:12]}"
        return {"op_type": "merge", "payload": {"block_ids": [a_id, b_id]}}
    if isinstance(op, MoveOp):
        source_topic = next(
            (t for t in before.topics if op.payload.block_id in t.source_block_ids), None
        )
        if source_topic is None:
            return None
        return {
            "op_type": "move",
            "payload": {
                "block_id": op.payload.block_id,
                "target_topic_id": source_topic.topic_id,
            },
        }
    if isinstance(op, RetypeOp):
        target = next((t for t in before.topics if t.topic_id == op.payload.topic_id), None)
        if target is None:
            return None
        return {
            "op_type": "retype",
            "payload": {"topic_id": op.payload.topic_id, "topic_type": target.topic_type},
        }
    if isinstance(op, RenameOp):
        target = next((t for t in before.topics if t.topic_id == op.payload.topic_id), None)
        if target is None:
            return None
        return {
            "op_type": "rename",
            "payload": {
                "topic_id": op.payload.topic_id,
                "title": target.title,
                "short_desc": target.short_desc,
            },
        }
    if isinstance(op, RawXmlOverrideOp):
        target = next((t for t in before.topics if t.topic_id == op.payload.topic_id), None)
        if target is None or target.dita_xml is None:
            return None
        return {
            "op_type": "raw_xml_override",
            "payload": {"topic_id": op.payload.topic_id, "xml": target.dita_xml},
            "is_lossy": True,
        }
    return None


@app.post("/internal/documents/{document_id}/ops/undo")
async def undo_last_op(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Append an inverse op for the chain's head.

    Inversion is computed against the projected state *before* the head
    op ran (so we can recover prior `topic_type`, `dita_xml`, etc.).
    Some ops are not invertible from snapshot alone — those return 422
    with a structured reason. The inverse op is appended via the same
    `apply_edit_op` path, so the audit log records BOTH the original op
    and its inverse — undo is itself an audited event.
    """
    from ditagen_common.edits import replay as _replay

    snapshot = _load_snapshot(document_id)
    chain = await _document_op_chain_for_request(
        document_id,
        snapshot.snapshot_id,
        headers=context_headers(request, user),
    )
    if not chain:
        raise HTTPException(status_code=400, detail="no ops to undo")
    head = chain[-1]
    state_before_head = _replay(snapshot, chain[:-1])
    snapshot_before_head = ExtractionSnapshot(
        snapshot_id=snapshot.snapshot_id,
        document_id=snapshot.document_id,
        blocks=state_before_head.blocks,
        topics=state_before_head.topics,
    )
    inverse_body = _invert_op(head, snapshot_before_head)
    if inverse_body is None:
        raise HTTPException(
            status_code=422,
            detail=f"op_type {head.op_type!r} (op_id={head.op_id!r}) cannot be inverted from snapshot",
        )
    target_topic_id = _resolve_target_topic_id(head, default="") or (
        _topic_owning_op_blocks(head, snapshot_before_head) or ""
    )
    if not target_topic_id:
        raise HTTPException(
            status_code=422,
            detail=f"cannot derive a target topic for undo of op {head.op_id!r}",
        )
    state = store.read()
    target_topic_dict = state.get("topics", {}).get(target_topic_id)
    if target_topic_dict is None or target_topic_dict.get("tenant_id") != user["tenant_id"]:
        raise HTTPException(status_code=404, detail="target topic for undo not found")
    return await apply_edit_op(
        topic_id=target_topic_id,
        request=request,
        user=user,
        body=inverse_body,
    )


# ---------------------------------------------------------------------------
# Review-state routes migrated from upload-service (Phase 6.E)
#
# Per ADR-004 these belong on review-service alongside the edit ops. The
# audit envelope shapes are preserved exactly so upstream consumers
# (activity feed, audit-service projection) see no change.
# ---------------------------------------------------------------------------


@app.post("/internal/topics/{topic_id}/assign-reviewer")
async def assign_reviewer(
    topic_id: str,
    request: Request,
    reviewer_id: str = Body(embed=True),
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    topic = _require_topic_record(topic_id, user)

    def update(state: dict[str, Any]) -> dict[str, Any]:
        state["topics"][topic_id]["reviewer_id"] = reviewer_id
        state["topics"][topic_id]["status"] = "in_review"
        return state["topics"][topic_id]

    result = store.mutate(update)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.review.requested",
            "resource_type": "topic",
            "resource_id": topic_id,
            "business_unit_id": topic.get("business_unit_id"),
            "project_id": topic.get("project_id"),
            "metadata": {"reviewer_id": reviewer_id},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return result


@app.post("/internal/topics/{topic_id}/approve")
async def approve_topic(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "reviewer"})
    topic = _require_topic_record(topic_id, user)

    def approve(state: dict[str, Any]) -> dict[str, Any]:
        state["topics"][topic_id]["status"] = "approved"
        return state["topics"][topic_id]

    result = store.mutate(approve)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.approved",
            "resource_type": "topic",
            "resource_id": topic_id,
            "business_unit_id": topic.get("business_unit_id"),
            "project_id": topic.get("project_id"),
        },
        headers=context_headers(request, user),
        store=store,
    )
    return result


@app.post("/internal/topics/{topic_id}/reject")
async def reject_topic(
    topic_id: str,
    request_body: RejectRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "reviewer"})
    topic = _require_topic_record(topic_id, user)

    def reject(state: dict[str, Any]) -> dict[str, Any]:
        state["topics"][topic_id]["status"] = "changes_requested"
        state["topics"][topic_id]["rejection_reason"] = request_body.reason
        return state["topics"][topic_id]

    result = store.mutate(reject)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.rejected",
            "resource_type": "topic",
            "resource_id": topic_id,
            "business_unit_id": topic.get("business_unit_id"),
            "project_id": topic.get("project_id"),
            "metadata": {"reason": request_body.reason},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return result
