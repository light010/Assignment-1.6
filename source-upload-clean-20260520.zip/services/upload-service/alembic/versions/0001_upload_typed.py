"""upload-service typed schema (Phase 4 D4)

Revision ID: 0001_upload_typed
Revises:
Create Date: 2026-05-12

Replaces the JsonStore-owned collections (documents, upload_sessions,
jobs, artifact_registry, exports) with typed tables owned by the
upload-service. See plans/architecture-hardening.md §D4 and
adr/016-service-owned-data-contracts.md.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001_upload_typed"
down_revision = None
branch_labels = None
depends_on = None


def _seq_pk_column(name: str = "seq") -> sa.Column:
    return sa.Column(
        name,
        sa.BigInteger().with_variant(sa.Integer(), "sqlite"),
        primary_key=True,
        autoincrement=True,
        nullable=False,
    )


def upgrade() -> None:
    op.create_table(
        "documents",
        _seq_pk_column(),
        sa.Column("document_id", sa.Text(), nullable=False, unique=True),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("filename", sa.Text(), nullable=False),
        sa.Column("content_type", sa.Text(), nullable=True),
        sa.Column("source_hash", sa.Text(), nullable=False),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("extraction_failure_reason", sa.Text(), nullable=True),
        sa.Column("job_ids", sa.JSON(), nullable=False),
        sa.Column("topic_ids", sa.JSON(), nullable=False),
        sa.Column("original_artifact", sa.JSON(), nullable=False),
        sa.Column("manifest", sa.JSON(), nullable=False),
        sa.Column("manifest_artifact", sa.JSON(), nullable=True),
        sa.Column("artifacts", sa.JSON(), nullable=False),
        sa.Column("latest_artifacts", sa.JSON(), nullable=False),
        sa.Column("source_quality", sa.JSON(), nullable=False),
        sa.Column("extraction", sa.JSON(), nullable=False),
        sa.Column("upload_id", sa.Text(), nullable=True),
        sa.Column("topic_plan_approved", sa.Boolean(), nullable=True),
        sa.Column("created_at", sa.Text(), nullable=False),
    )
    op.create_index("ix_documents_tenant_id", "documents", ["tenant_id"])
    op.create_index("ix_documents_project_id", "documents", ["project_id"])
    op.create_index(
        "ix_documents_business_unit_id", "documents", ["business_unit_id"]
    )
    op.create_index("ix_documents_status", "documents", ["status"])

    op.create_table(
        "upload_sessions",
        _seq_pk_column(),
        sa.Column("upload_id", sa.Text(), nullable=False, unique=True),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("organization_id", sa.Text(), nullable=False),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("filename", sa.Text(), nullable=False),
        sa.Column("content_type", sa.Text(), nullable=True),
        sa.Column("size_bytes", sa.BigInteger(), nullable=True),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("parts", sa.JSON(), nullable=False),
        sa.Column("received_bytes", sa.BigInteger(), nullable=False),
        sa.Column("document_id", sa.Text(), nullable=True),
        sa.Column("completed_at", sa.Text(), nullable=True),
        sa.Column("created_by", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
    )
    op.create_index(
        "ix_upload_sessions_tenant_id", "upload_sessions", ["tenant_id"]
    )
    op.create_index(
        "ix_upload_sessions_project_id", "upload_sessions", ["project_id"]
    )
    op.create_index("ix_upload_sessions_status", "upload_sessions", ["status"])

    op.create_table(
        "jobs",
        _seq_pk_column(),
        sa.Column("job_id", sa.Text(), nullable=False, unique=True),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("document_id", sa.Text(), nullable=False),
        sa.Column("stage", sa.Text(), nullable=False),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("events", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
    )
    op.create_index("ix_jobs_document_id", "jobs", ["document_id"])
    op.create_index("ix_jobs_project_id", "jobs", ["project_id"])
    op.create_index("ix_jobs_status", "jobs", ["status"])

    op.create_table(
        "artifact_registry",
        _seq_pk_column(),
        sa.Column("artifact_id", sa.Text(), nullable=False, unique=True),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("document_id", sa.Text(), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("artifact_version", sa.Integer(), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("content_type", sa.Text(), nullable=True),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("hash", sa.Text(), nullable=False),
        sa.Column("sha256", sa.Text(), nullable=False),
        sa.Column("path", sa.Text(), nullable=False),
        sa.Column("producer", sa.Text(), nullable=False),
        sa.Column("created_by", sa.Text(), nullable=True),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.Column("previous_version_id", sa.Text(), nullable=True),
    )
    op.create_index(
        "ix_artifact_registry_document_id",
        "artifact_registry",
        ["document_id"],
    )
    op.create_index(
        "ix_artifact_registry_project_id", "artifact_registry", ["project_id"]
    )
    op.create_index(
        "ix_artifact_registry_name", "artifact_registry", ["name"]
    )

    op.create_table(
        "exports",
        _seq_pk_column(),
        sa.Column("export_id", sa.Text(), nullable=False, unique=True),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("topic_count", sa.Integer(), nullable=False),
        sa.Column("artifact", sa.JSON(), nullable=False),
        sa.Column("logs", sa.JSON(), nullable=False),
    )
    op.create_index("ix_exports_project_id", "exports", ["project_id"])
    op.create_index(
        "ix_exports_business_unit_id", "exports", ["business_unit_id"]
    )


def downgrade() -> None:
    for index, table in [
        ("ix_exports_business_unit_id", "exports"),
        ("ix_exports_project_id", "exports"),
        ("ix_artifact_registry_name", "artifact_registry"),
        ("ix_artifact_registry_project_id", "artifact_registry"),
        ("ix_artifact_registry_document_id", "artifact_registry"),
        ("ix_jobs_status", "jobs"),
        ("ix_jobs_project_id", "jobs"),
        ("ix_jobs_document_id", "jobs"),
        ("ix_upload_sessions_status", "upload_sessions"),
        ("ix_upload_sessions_project_id", "upload_sessions"),
        ("ix_upload_sessions_tenant_id", "upload_sessions"),
        ("ix_documents_status", "documents"),
        ("ix_documents_business_unit_id", "documents"),
        ("ix_documents_project_id", "documents"),
        ("ix_documents_tenant_id", "documents"),
    ]:
        op.drop_index(index, table_name=table)
    for table in (
        "exports",
        "artifact_registry",
        "jobs",
        "upload_sessions",
        "documents",
    ):
        op.drop_table(table)
