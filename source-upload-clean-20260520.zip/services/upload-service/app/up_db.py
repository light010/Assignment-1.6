"""SQLAlchemy engine + typed models owned by upload-service.

Phase 4 D4 graduates upload-service from JsonStore to a service-owned
relational backend, per ADR-016. The model surface covers every
collection upload-service is the canonical owner of:

  - documents               (uploaded files + their pipeline state)
  - upload_sessions         (multipart upload session tracking)
  - jobs                    (per-document pipeline job tracking)
  - artifact_registry       (file-blob index — every produced artifact)
  - exports                 (export-bundle records)

Storage decisions (mirror D2.1 / D3.1 patterns):

  - **Per-service DB URL** via `DITAGEN_UPLOAD_DATABASE_URL`. Default
    falls back to a SQLite file under DITAGEN_DATA_DIR.
  - **`seq BIGINT` autoincrement PK** even though every row has a natural
    string key. Stable insertion order, robust to clock drift, same
    pattern as audit_events and the BU service models.
  - **Natural keys are `UNIQUE NOT NULL`** so the migration script can
    rely on `ON CONFLICT (id) DO NOTHING` semantics via repo upsert.
  - **Timestamps stored as `Text`** (ISO-8601 with trailing Z). The
    JsonStore wire shape is ISO-Z strings; storing as text avoids
    datetime ↔ ISO round-trip drift across SQLite and PostgreSQL.
    Strings are lexicographically sortable, so `ORDER BY created_at`
    works.
  - **JSON columns** for `artifacts`, `latest_artifacts`,
    `source_quality`, `manifest`, `extraction`, `parts`, `events`,
    `topic_ids`, `job_ids`, `logs`. SQLAlchemy's `JSON` maps to TEXT on
    SQLite and JSONB on PostgreSQL.

Phase 4 D4 is a **consumers-first lean cutover** (see plans/architecture-
hardening.md §D4 for the strategy). Cross-service readers (api-gateway,
BU service) migrate to `request_service` against upload-service's
existing HTTP endpoints BEFORE the JsonStore-to-SQL backend swap. No
dual-write swallow-and-log bridge — SQL is authoritative from day 1.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Column,
    Index,
    Integer,
    MetaData,
    Text,
    create_engine,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

_METADATA = MetaData()


class Base(DeclarativeBase):
    """SQLAlchemy 2.0 declarative base for upload-service tables."""

    metadata = _METADATA


def _seq_pk() -> Column[int]:
    """Per-row monotonic autoincrement PK.

    BigInteger on PostgreSQL (BIGSERIAL); INTEGER PRIMARY KEY on SQLite
    (rowid alias — without the variant SQLite refuses to autoincrement
    a BIGINT PK). Same pattern as audit-service and BU service `seq`."""
    return Column(
        BigInteger().with_variant(Integer, "sqlite"),
        primary_key=True,
        autoincrement=True,
        nullable=False,
    )


class Document(Base):
    """Uploaded document + its full pipeline state.

    The largest envelope in the upload-service surface — covers the
    upload event, extraction status, analysis output references, topic
    plan, and quality verdict in a single row. JSON columns hold the
    deeply-nested data; scalar columns hold what we need to index on
    (tenant_id for isolation, status for filtering, project_id for
    list-by-project queries)."""

    __tablename__ = "documents"

    seq = _seq_pk()
    document_id = Column(Text, nullable=False, unique=True)
    tenant_id = Column(Text, nullable=False)
    business_unit_id = Column(Text, nullable=False)
    project_id = Column(Text, nullable=False)
    filename = Column(Text, nullable=False)
    content_type = Column(Text, nullable=True)
    source_hash = Column(Text, nullable=False)
    status = Column(Text, nullable=False)
    extraction_failure_reason = Column(Text, nullable=True)
    job_ids = Column(JSON, nullable=False, default=list)
    topic_ids = Column(JSON, nullable=False, default=list)
    original_artifact = Column(JSON, nullable=False, default=dict)
    manifest = Column(JSON, nullable=False, default=dict)
    manifest_artifact = Column(JSON, nullable=True)
    artifacts = Column(JSON, nullable=False, default=dict)
    latest_artifacts = Column(JSON, nullable=False, default=dict)
    source_quality = Column(JSON, nullable=False, default=dict)
    extraction = Column(JSON, nullable=False, default=dict)
    upload_id = Column(Text, nullable=True)
    topic_plan_approved = Column(Boolean, nullable=True)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        Index("ix_documents_tenant_id", "tenant_id"),
        Index("ix_documents_project_id", "project_id"),
        Index("ix_documents_business_unit_id", "business_unit_id"),
        Index("ix_documents_status", "status"),
    )

    def to_envelope(self) -> dict[str, Any]:
        envelope: dict[str, Any] = {
            "document_id": self.document_id,
            "tenant_id": self.tenant_id,
            "business_unit_id": self.business_unit_id,
            "project_id": self.project_id,
            "filename": self.filename,
            "content_type": self.content_type,
            "source_hash": self.source_hash,
            "status": self.status,
            "job_ids": list(self.job_ids or []),
            "topic_ids": list(self.topic_ids or []),
            "original_artifact": dict(self.original_artifact or {}),
            "manifest": dict(self.manifest or {}),
            "manifest_artifact": self.manifest_artifact,
            "artifacts": dict(self.artifacts or {}),
            "latest_artifacts": dict(self.latest_artifacts or {}),
            "source_quality": dict(self.source_quality or {}),
            "extraction": dict(self.extraction or {}),
            "upload_id": self.upload_id,
            "created_at": self.created_at,
        }
        if self.extraction_failure_reason is not None:
            envelope["extraction_failure_reason"] = self.extraction_failure_reason
        if self.topic_plan_approved is not None:
            envelope["topic_plan_approved"] = self.topic_plan_approved
        return envelope


class UploadSession(Base):
    """Multipart upload session tracking.

    Sessions are created by `POST /internal/projects/{id}/uploads`,
    receive part data via `POST /internal/uploads/{upload_id}/parts`,
    and complete via `POST /internal/uploads/{upload_id}/complete`. The
    parts list grows on each PUT — `received_bytes` tracks cumulative
    size for the 250 MB cap."""

    __tablename__ = "upload_sessions"

    seq = _seq_pk()
    upload_id = Column(Text, nullable=False, unique=True)
    tenant_id = Column(Text, nullable=False)
    organization_id = Column(Text, nullable=False)
    business_unit_id = Column(Text, nullable=False)
    project_id = Column(Text, nullable=False)
    filename = Column(Text, nullable=False)
    content_type = Column(Text, nullable=True)
    size_bytes = Column(BigInteger, nullable=True)
    status = Column(Text, nullable=False)
    parts = Column(JSON, nullable=False, default=list)
    received_bytes = Column(BigInteger, nullable=False, default=0)
    document_id = Column(Text, nullable=True)
    completed_at = Column(Text, nullable=True)
    created_by = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        Index("ix_upload_sessions_tenant_id", "tenant_id"),
        Index("ix_upload_sessions_project_id", "project_id"),
        Index("ix_upload_sessions_status", "status"),
    )

    def to_envelope(self) -> dict[str, Any]:
        envelope: dict[str, Any] = {
            "upload_id": self.upload_id,
            "tenant_id": self.tenant_id,
            "organization_id": self.organization_id,
            "business_unit_id": self.business_unit_id,
            "project_id": self.project_id,
            "filename": self.filename,
            "content_type": self.content_type,
            "size_bytes": self.size_bytes,
            "status": self.status,
            "parts": list(self.parts or []),
            "received_bytes": self.received_bytes or 0,
            "created_by": self.created_by,
            "created_at": self.created_at,
        }
        if self.document_id is not None:
            envelope["document_id"] = self.document_id
        if self.completed_at is not None:
            envelope["completed_at"] = self.completed_at
        return envelope


class Job(Base):
    """Per-document pipeline job tracking.

    A Job captures the upload→extraction→analysis→review pipeline state
    for a single document. The `events` list grows as stages emit; the
    `status` flips at terminal stages (failed, completed)."""

    __tablename__ = "jobs"

    seq = _seq_pk()
    job_id = Column(Text, nullable=False, unique=True)
    business_unit_id = Column(Text, nullable=False)
    project_id = Column(Text, nullable=False)
    document_id = Column(Text, nullable=False)
    stage = Column(Text, nullable=False)
    status = Column(Text, nullable=False)
    events = Column(JSON, nullable=False, default=list)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        Index("ix_jobs_document_id", "document_id"),
        Index("ix_jobs_project_id", "project_id"),
        Index("ix_jobs_status", "status"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "business_unit_id": self.business_unit_id,
            "project_id": self.project_id,
            "document_id": self.document_id,
            "stage": self.stage,
            "status": self.status,
            "events": list(self.events or []),
            "created_at": self.created_at,
        }


class ArtifactRegistryEntry(Base):
    """File-blob index — every produced artifact across the pipeline.

    Written by `ditagen_common.artifacts.register_artifact`. The
    `producer` column tells which service emitted the artifact
    (upload-service, extraction-service, analysis-service, etc.) so
    downstream consumers can filter on origin.

    The natural key is `artifact_id`. The `name` field is the
    file-name-within-a-document (e.g. `source-blocks.jsonl`), not
    unique globally."""

    __tablename__ = "artifact_registry"

    seq = _seq_pk()
    artifact_id = Column(Text, nullable=False, unique=True)
    project_id = Column(Text, nullable=False)
    document_id = Column(Text, nullable=False)
    name = Column(Text, nullable=False)
    artifact_version = Column(Integer, nullable=False)
    version = Column(Integer, nullable=False)
    content_type = Column(Text, nullable=True)
    size_bytes = Column(BigInteger, nullable=False, default=0)
    hash = Column(Text, nullable=False)
    sha256 = Column(Text, nullable=False)
    path = Column(Text, nullable=False)
    producer = Column(Text, nullable=False)
    created_by = Column(Text, nullable=True)
    created_at = Column(Text, nullable=False)
    previous_version_id = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_artifact_registry_document_id", "document_id"),
        Index("ix_artifact_registry_project_id", "project_id"),
        Index("ix_artifact_registry_name", "name"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "artifact_id": self.artifact_id,
            # The JsonStore wire shape duplicates artifact_id as `id` —
            # preserved here for parity with existing consumers.
            "id": self.artifact_id,
            "project_id": self.project_id,
            "document_id": self.document_id,
            "name": self.name,
            "artifact_version": self.artifact_version,
            "version": self.version,
            "content_type": self.content_type,
            "size_bytes": self.size_bytes or 0,
            "hash": self.hash,
            "sha256": self.sha256,
            "path": self.path,
            "producer": self.producer,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "previous_version_id": self.previous_version_id,
        }


class Export(Base):
    """Export-bundle record — what `POST /internal/projects/{id}/exports`
    produces. Each row points to the zip artifact (in artifact_registry)
    and carries human-readable logs for the workbench UI."""

    __tablename__ = "exports"

    seq = _seq_pk()
    export_id = Column(Text, nullable=False, unique=True)
    business_unit_id = Column(Text, nullable=False)
    project_id = Column(Text, nullable=False)
    status = Column(Text, nullable=False)
    topic_count = Column(Integer, nullable=False, default=0)
    artifact = Column(JSON, nullable=False, default=dict)
    logs = Column(JSON, nullable=False, default=list)

    __table_args__ = (
        Index("ix_exports_project_id", "project_id"),
        Index("ix_exports_business_unit_id", "business_unit_id"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "export_id": self.export_id,
            "business_unit_id": self.business_unit_id,
            "project_id": self.project_id,
            "status": self.status,
            "topic_count": self.topic_count or 0,
            "artifact": dict(self.artifact or {}),
            "logs": list(self.logs or []),
        }


def database_url() -> str:
    """Resolve the upload-service DB URL.

    Production overrides via DITAGEN_UPLOAD_DATABASE_URL.
    Default is a hermetic SQLite file under DITAGEN_DATA_DIR."""
    url = os.getenv("DITAGEN_UPLOAD_DATABASE_URL")
    if url:
        return url
    data_dir = os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")
    return f"sqlite:///{data_dir}/upload-service.sqlite3"


_ENGINE_CACHE: dict[str, Engine] = {}
_SESSION_FACTORY_CACHE: dict[str, sessionmaker[Session]] = {}


def get_engine(url: str | None = None) -> Engine:
    """Return (and cache) a SQLAlchemy Engine for the upload-service DB.

    Cache keyed by URL so tests that switch DITAGEN_DATA_DIR get a
    fresh engine per per-test data dir. Same pattern as the BU service's
    `bu_db.get_engine`."""
    target = url or database_url()
    if target not in _ENGINE_CACHE:
        connect_args: dict[str, Any] = {}
        if target.startswith("sqlite"):
            connect_args["check_same_thread"] = False
            from pathlib import Path
            from urllib.parse import urlparse

            db_path = Path(urlparse(target).path.lstrip("/")).resolve()
            db_path.parent.mkdir(parents=True, exist_ok=True)
        engine = create_engine(target, future=True, connect_args=connect_args)
        Base.metadata.create_all(engine)
        _ENGINE_CACHE[target] = engine
        _SESSION_FACTORY_CACHE[target] = sessionmaker(
            bind=engine, expire_on_commit=False, future=True
        )
    return _ENGINE_CACHE[target]


@contextmanager
def session_scope(url: str | None = None) -> Iterator[Session]:
    """Open a SQLAlchemy session, commit on success, rollback on raise."""
    target = url or database_url()
    get_engine(target)
    factory = _SESSION_FACTORY_CACHE[target]
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def reset_engine_cache() -> None:
    """Drop the engine + session-factory caches. Tests-only."""
    for engine in _ENGINE_CACHE.values():
        engine.dispose()
    _ENGINE_CACHE.clear()
    _SESSION_FACTORY_CACHE.clear()
