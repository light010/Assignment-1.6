from __future__ import annotations

import base64
import json
import logging
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from ditagen_common.artifacts import (
    read_artifact_json,
    read_artifact_text,
    slugify,
    write_artifact,
)
from ditagen_common.auth import (
    assert_role,
    context_headers,
    current_user,
    require_business_unit,
)
from ditagen_common.ids import new_id
from ditagen_common.models import REVIEW_FLAG_CATALOG
from ditagen_common.pipeline import build_dita_files, build_export_zip
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import emit_audit_event, request_service
from ditagen_common.store import utc_now
from ditagen_common.store_factory import create_store
from fastapi import Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from up_repositories import DocumentRepository, UploadSessionRepository

app = create_service_app("upload-service")
store = create_store("upload-service")

ALLOWED_SUFFIXES = {".docx", ".pdf", ".txt", ".md", ".html", ".htm"}
MAX_UPLOAD_BYTES = 250 * 1024 * 1024

# Step G1: per-instance rate limit for `/reextract`. v1 limitation: this
# is in-memory, so two upload-service replicas don't share the throttle.
# Documented as such; durable enforcement is a future story (would need
# Redis or a JsonStore field). The 600s window is long enough that any
# legitimate "I made a content change, re-extract" gesture isn't blocked,
# but short enough that someone hammering the button doesn't DOS pandoc.
REEXTRACT_THROTTLE_WINDOW_S = 600
_reextract_last_attempt_at: dict[str, datetime] = {}
BUSINESS_UNIT_SERVICE_URL = os.getenv(
    "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
)
EXTRACTION_SERVICE_URL = os.getenv("DITAGEN_EXTRACTION_SERVICE_URL", "http://extraction-service:8000")
LLM_GATEWAY_SERVICE_URL = os.getenv(
    "DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000"
)
REVIEW_SERVICE_URL = os.getenv(
    "DITAGEN_REVIEW_SERVICE_URL", "http://review-service:8000"
)
VALIDATION_SERVICE_URL = os.getenv(
    "DITAGEN_VALIDATION_SERVICE_URL", "http://validation-service:8000"
)
ANALYSIS_SERVICE_URL = os.getenv(
    "DITAGEN_ANALYSIS_SERVICE_URL", "http://analysis-service:8000"
)
DEFAULT_MODEL_NAME = "fixture-deterministic"
DEFAULT_PROMPT_VERSION = "v0"

EXTRACTION_FAILURE_REASONS = {
    "pandoc_unavailable",
    "input_corrupted",
    "input_encrypted",
    "input_too_large",
    "empty_document",
    "unknown",
}


class UploadSessionCreate(BaseModel):
    filename: str = Field(min_length=1)
    content_type: str | None = None
    size_bytes: int | None = Field(default=None, ge=0)


class UploadPartRequest(BaseModel):
    content: str | None = None
    content_base64: str | None = None
    part_number: int = Field(default=1, ge=1)


class TopicPatchRequest(BaseModel):
    xml: str
    artifact_version: str | None = None


class RejectRequest(BaseModel):
    reason: str = Field(min_length=1)


class GateOverrideRequest(BaseModel):
    reason: str = Field(min_length=1)


class ExportCreateRequest(BaseModel):
    include_unapproved: bool = True


def validate_filename(filename: str) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_SUFFIXES:
        raise HTTPException(status_code=400, detail="Alpha upload supports DOCX, PDF, TXT, MD, and HTML")
    return suffix


def reject_oversized_content_length(request: Request) -> None:
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds alpha limit of 250 MB")


_bu_denorm_logger = logging.getLogger("upload-service.bu-denorm")


async def _require_project_via_bu_service(
    request: Request,
    project_id: str,
    user: dict[str, Any],
    *,
    include_deleted: bool = False,
) -> dict[str, Any]:
    """Phase 4 D3.5.c fallout: project lookup delegates to BU service.

    Pre-D3.5.c, upload-service called `require_project(state, ...)`
    against its own JsonStore. That worked only because D3.3's dual-
    write populated `state["projects"]` here as a side effect of every
    BU service write. D3.5.c retired the dual-write — BU service now
    writes only to its own SQL, so upload-service's JsonStore mirror
    of projects is stale or empty.

    This helper mirrors api-gateway's D3.6 `require_project` pattern
    and replaces all 9 `require_project(state, ...)` call sites in
    this module (plan §D3 finding #50).

    Semantic preservation: BU service's `GET /internal/projects/{id}`
    is hardcoded `include_deleted=True` (it has to be — there's no
    other way to fetch archived projects for the admin paths). To
    match `ditagen_common.auth.require_project`'s default-False
    behavior, we apply the archived filter client-side here."""
    # `include_documents=False` is the cycle-breaker. BU service's
    # `get_project` joins documents from upload-service when the flag
    # is true. If this access-check call requested documents, the join
    # would call back into upload-service which would call this helper
    # again → infinite recursion (D4.4.b finding #65).
    response = await request_service(
        method="GET",
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/projects/{project_id}",
        params={"include_documents": "false"},
        headers=context_headers(request, user),
    )
    if response.status_code == 404:
        raise HTTPException(status_code=404, detail="Project not found")
    if response.status_code == 403:
        raise HTTPException(status_code=403, detail="Project access denied")
    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="Project access error",
        )
    project = response.json()
    if not include_deleted and project.get("status") == "archived":
        raise HTTPException(status_code=404, detail="Project not found")
    return project


async def _append_document_to_project_via_bu_service(
    request: Request,
    project_id: str,
    document_id: str,
    user: dict[str, Any],
) -> dict[str, Any] | None:
    """Phase 4 D3.7.c: append a document_id to a project via BU service.

    Replaces the 3 in-mutate-callback
    `state["projects"][project_id]["document_ids"].append(document_id)`
    direct writes (the document_ids denorm boundary leak — plan §D3
    finding #2). Idempotent at the BU service end.

    **Best-effort by design** (finding #24): the document record itself
    carries `project_id` as the canonical "attached to" signal. The
    BU service's `document_ids` is a denormalized query-convenience
    index — drift here doesn't lose data, just slows the "list
    project documents" path until reconciliation. So if the BU service
    is unreachable, we LOG and return None rather than fail the upload
    (which would lose the document entirely). The success paths get a
    fresh project envelope back; the failure paths get None.

    Note this is categorically different from D3.3's dual-write
    swallow-and-log: that pattern is for keeping two backends of the
    SAME logical write in sync (JsonStore + SQL of the BU service);
    this pattern is for a cross-service denorm sync where the
    authoritative signal lives elsewhere (the document record)."""
    try:
        response = await request_service(
            method="POST",
            base_url=BUSINESS_UNIT_SERVICE_URL,
            path=f"/internal/projects/{project_id}/documents",
            headers=context_headers(request, user),
            json={"document_id": document_id},
        )
    except Exception as exc:  # noqa: BLE001 — see docstring; best-effort denorm
        _bu_denorm_logger.warning(
            "append document_id %s to project %s skipped: %s",
            document_id,
            project_id,
            exc,
        )
        return None
    if response.status_code != 200:
        _bu_denorm_logger.warning(
            "append document_id %s to project %s returned %s: %s",
            document_id,
            project_id,
            response.status_code,
            response.text[:200],
        )
        return None
    return response.json()


async def _remove_document_from_project_via_bu_service(
    request: Request,
    project_id: str,
    document_id: str,
    user: dict[str, Any],
) -> dict[str, Any] | None:
    """Phase 4 D3.7.c: symmetric remove via BU service. Best-effort,
    same rationale as the append helper above — if BU service is
    unreachable during delete_document, the document record is still
    removed from upload-service-owned state; the denorm just keeps a
    stale entry until reconciliation."""
    try:
        response = await request_service(
            method="DELETE",
            base_url=BUSINESS_UNIT_SERVICE_URL,
            path=f"/internal/projects/{project_id}/documents/{document_id}",
            headers=context_headers(request, user),
        )
    except Exception as exc:  # noqa: BLE001 — see docstring; best-effort denorm
        _bu_denorm_logger.warning(
            "remove document_id %s from project %s skipped: %s",
            document_id,
            project_id,
            exc,
        )
        return None
    if response.status_code != 200:
        _bu_denorm_logger.warning(
            "remove document_id %s from project %s returned %s: %s",
            document_id,
            project_id,
            response.status_code,
            response.text[:200],
        )
        return None
    return response.json()


async def _require_document_via_repo(
    request: Request, document_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    """Phase 4 D4.5.b: repo-backed replacement for the
    `ditagen_common.auth.require_document(state, ...)` helper.

    The deleted helper read `state["documents"]` (now empty post-D4.5.b)
    and chained into `require_project(state, ...)` — which has been
    silently broken since D3.5.c retired the BU service's JsonStore
    dual-write. Tests passed because every test seeded `state["projects"]`
    directly via `store.mutate`; production reads would 404 for any
    project created after D3.5.c. D4.5.b deletes both helpers from
    `ditagen_common.auth` and replaces the only caller (this module)
    with this async, repo-backed equivalent.

    Behaviour:
      - fetches the document from `DocumentRepository().get(...)`
      - 404s on missing or tenant mismatch (matching the JsonStore-era
        contract — leaks no information about cross-tenant existence)
      - delegates project access to BU service via
        `_require_project_via_bu_service(..., include_deleted=True)`.
        `include_deleted=True` matches the old `require_document`'s
        behaviour of resolving documents whose project has been
        archived — needed so cleanup paths (delete_document, etc.)
        can still operate on archived-project documents.
    """
    document = DocumentRepository().get(document_id)
    if not document or document.get("tenant_id") != user.get("tenant_id"):
        raise HTTPException(status_code=404, detail="Document not found")
    await _require_project_via_bu_service(
        request, document["project_id"], user, include_deleted=True
    )
    return document


async def ensure_document_workspace_project(
    request: Request,
    business_unit_id: str,
    user: dict[str, Any],
) -> dict[str, Any]:
    """Phase 4 D3.7.b: workspace-project provisioning delegated to BU
    service.

    Was a local `store.mutate`-based function that wrote
    `state["projects"]` + `state["project_memberships"]` directly — the
    cross-service boundary leak flagged in plan §D3 finding #1. Now
    POSTs to the BU service's auto-provision endpoint, which owns the
    project + membership lifecycle. Semantics preserved exactly:
    the BU service endpoint replicates the original find-or-create
    behavior (returns any user-accessible non-archived project first,
    only creates the system_managed workspace if none exists).

    Audit event `project.auto_provisioned` is now emitted by the BU
    service, not upload-service — moves the audit closer to the
    canonical writer."""
    response = await request_service(
        method="POST",
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}/auto-provision-workspace-project",
        headers=context_headers(request, user),
    )
    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail=f"Workspace project provisioning failed: {response.text[:200]}",
        )
    return response.json()


def read_jsonl(ref: dict[str, Any]) -> list[dict[str, Any]]:
    return [json.loads(line) for line in read_artifact_text(ref).splitlines() if line.strip()]


def artifact_key(name: str) -> str:
    return {
        "source-lines.jsonl": "source_lines",
        "source-blocks.jsonl": "source_blocks",
        "style-profile.json": "style_profile",
        "structure-tree.json": "structure_tree",
        "asset-manifest.json": "asset_manifest",
        "extraction-quality.json": "extraction_quality",
        "content.md": "markdown",
        "header-footer.jsonl": "header_footer",
    }.get(name, slugify(name).replace("-", "_").replace(".", "_"))


def refs_by_key(artifacts: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {artifact_key(artifact["name"]): artifact for artifact in artifacts}


def latest_artifact_pointers(**refs: dict[str, Any]) -> dict[str, str]:
    pointers: dict[str, str] = {}
    for ref in refs.values():
        artifact_id = ref.get("artifact_id") or ref.get("id")
        if artifact_id:
            pointers[ref["name"]] = artifact_id
    return pointers


async def run_extraction_request(
    *,
    project_id: str,
    business_unit_id: str,
    document_id: str,
    filename: str,
    content_type: str | None,
    original_ref: dict[str, Any],
    user: dict[str, Any],
    request: Request,
) -> dict[str, Any]:
    headers = context_headers(request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "document.extraction_requested",
            "resource_type": "document",
            "resource_id": document_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "metadata": {"filename": filename, "source_hash": original_ref["hash"]},
        },
        headers=headers,
        store=store,
    )
    payload = {
        "document_id": document_id,
        "project_id": project_id,
        "business_unit_id": business_unit_id,
        "filename": filename,
        "content_type": content_type or "application/octet-stream",
        "artifact_path": original_ref["path"],
        "request_id": headers["X-Request-ID"],
        "requested_by": user["user_id"],
    }
    try:
        response = await request_service(
            method="POST",
            base_url=EXTRACTION_SERVICE_URL,
            path="/internal/extractions",
            headers=headers,
            json=payload,
            timeout=120.0,
        )
        response.raise_for_status()
        return response.json()
    except Exception as exc:
        return {
            "extraction_id": document_id,
            "document_id": document_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "stage": "failed",
            "error": {
                "kind": "service_unreachable",
                "message": str(exc),
                "stage": "extracting",
                "retryable": True,
                "metadata": {},
            },
            "artifacts": [],
            "warnings": [],
            "events": ["extraction.failed"],
            "block_count": 0,
            "asset_count": 0,
        }


def legacy_quality_gate() -> dict[str, Any]:
    return {
        "name": "legacy_pre_gate",
        "passed": True,
        "severity": "info",
        "blocking_reasons": [],
        "warnings": [],
        "override": None,
        "override_history": [],
    }


def legacy_quality_artifact(document_id: str) -> dict[str, Any]:
    """Step G3: schema-valid synthesized payload for legacy documents.

    Pre-gate documents (uploaded before the gate existed, or migrated in
    without an `extraction_quality` artifact) need a response that
    validates against `extraction-quality.schema.json`. Previously
    `GET /artifacts/extraction-quality.json` returned just
    `{document_id, gate}`, which is missing the schema's required
    `schema_version`, `metrics`, and `runtime` fields. Strict client-side
    validators would reject it.

    The minimal-empty `metrics`/`runtime` shapes here mirror what an
    extraction-service emit would produce when no work was done. Any
    field with a `null` accepted by the schema gets `null`; numeric
    fields default to 0; lists default to empty.
    """
    return {
        "schema_version": 1,
        "document_id": document_id,
        "gate": legacy_quality_gate(),
        "metrics": {
            "total_source_blocks": 0,
            "located_source_blocks": 0,
            "unlocated_source_block_ids": [],
            "block_type_histogram": {},
            "structure_confidence": None,
            "repaired_level_count": 0,
            "review_flag_counts": {},
            "asset_resolution_rate": 1.0,
        },
        "runtime": {
            "extractor_version": "legacy",
            "pandoc_version": None,
            "mdformat_version": None,
            "duration_ms": 0,
            "pandoc_warnings": [],
        },
    }


def synthetic_failed_quality_gate(*, reasons: list[str], warnings: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    return {
        "name": "docx_source_fidelity_v1",
        "passed": False,
        "severity": "blocking",
        "blocking_reasons": sorted(set(reasons)),
        "warnings": warnings or [],
        "override": None,
        "override_history": [],
    }


def extraction_failure_reason(error: dict[str, Any] | None) -> str:
    kind = str((error or {}).get("kind") or "").lower()
    detail = " ".join(
        str((error or {}).get(key) or "").lower()
        for key in ("kind", "message", "stage")
    )
    for reason in ("pandoc_unavailable", "input_corrupted", "input_encrypted", "input_too_large", "empty_document"):
        if reason in kind or reason in detail:
            return reason
    if "encrypted" in detail:
        return "input_encrypted"
    if "corrupt" in detail:
        return "input_corrupted"
    if "too large" in detail or "size" in detail:
        return "input_too_large"
    if "empty" in detail or "no readable" in detail:
        return "empty_document"
    return "unknown"


def review_flag_catalog_response() -> dict[str, dict[str, str]]:
    return {
        code: {
            "label": entry["label"],
            "severity": entry["severity"],
            "explanation": entry["explanation"],
            "action": entry["action"],
        }
        for code, entry in REVIEW_FLAG_CATALOG.items()
    }


def humanize_code(code: str) -> str:
    return code.replace("_", " ").replace("-", " ").title()


def safe_document_blocks(document: dict[str, Any]) -> list[dict[str, Any]]:
    ref = (document.get("artifacts") or {}).get("source_blocks")
    if not ref:
        return []
    return read_jsonl(ref)


def get_quality_artifact_for_document(document: dict[str, Any]) -> dict[str, Any]:
    ref = (document.get("artifacts") or {}).get("extraction_quality")
    if ref is None:
        return legacy_quality_artifact(document["document_id"])
    return read_artifact_json(ref)


def extraction_review_summary(document: dict[str, Any]) -> dict[str, Any]:
    status = document.get("status") or "unknown"
    blocks = safe_document_blocks(document)
    quality = get_quality_artifact_for_document(document)
    gate = None if status == "failed_extraction" else quality.get("gate")
    metrics = quality.get("metrics") or {}
    review_flag_counts: dict[str, int] = {}
    sample_ids_by_code: dict[str, list[str]] = {}
    located_block_count = int(metrics.get("located_source_blocks") or 0)
    unlocated_source_block_ids = list(metrics.get("unlocated_source_block_ids") or [])

    if blocks:
        located_block_count = len(
            [
                block
                for block in blocks
                if (block.get("source_location") or {}).get("section")
                or (block.get("source_location") or {}).get("bbox")
            ]
        )
        for block in blocks:
            block_id = str(block.get("block_id") or "")
            for flag in block.get("review_flags") or []:
                if not isinstance(flag, dict):
                    continue
                code = str(flag.get("code") or "")
                if not code:
                    continue
                review_flag_counts[code] = review_flag_counts.get(code, 0) + 1
                samples = sample_ids_by_code.setdefault(code, [])
                if block_id and len(samples) < 5:
                    samples.append(block_id)
    elif isinstance(metrics.get("review_flag_counts"), dict):
        review_flag_counts = {
            str(code): int(count)
            for code, count in metrics["review_flag_counts"].items()
            if isinstance(count, int | float)
        }

    blocked_groups: list[dict[str, Any]] = []
    for code, count in sorted(review_flag_counts.items()):
        catalog = REVIEW_FLAG_CATALOG.get(code)  # type: ignore[call-overload]
        blocked_groups.append(
            {
                "code": code,
                "label": catalog["label"] if catalog else humanize_code(code),
                "severity": catalog["severity"] if catalog else "warning",
                "count": count,
                "sample_block_ids": sample_ids_by_code.get(code, []),
            }
        )

    if isinstance(gate, dict) and gate.get("passed") is False:
        warning_samples: dict[str, list[str]] = {}
        for warning in gate.get("warnings") or []:
            if not isinstance(warning, dict):
                continue
            kind = str(warning.get("kind") or "")
            ids = [str(item) for item in warning.get("source_block_ids") or [] if item]
            if kind and ids:
                warning_samples.setdefault(kind, []).extend(ids[:5])
        for reason in gate.get("blocking_reasons") or []:
            code = str(reason)
            blocked_groups.append(
                {
                    "code": code,
                    "label": humanize_code(code),
                    "severity": "error",
                    "count": 1,
                    "sample_block_ids": warning_samples.get(code, [])[:5],
                }
            )

    failure_reason = document.get("extraction_failure_reason")
    if status == "failed_extraction" and failure_reason not in EXTRACTION_FAILURE_REASONS:
        failure_reason = extraction_failure_reason(
            ((document.get("source_quality") or {}).get("extraction_error"))
            or ((document.get("extraction") or {}).get("error"))
        )

    return {
        "status": status,
        "extraction_failure_reason": failure_reason if status == "failed_extraction" else None,
        "block_count": len(blocks),
        "located_block_count": located_block_count if blocks else 0,
        "unlocated_source_block_ids": unlocated_source_block_ids,
        "review_flag_counts": review_flag_counts,
        "blocked_groups": blocked_groups,
        "gate": gate,
        "catalog": review_flag_catalog_response(),
    }


# Phase 8 — `write_analysis_artifacts` retired. Analysis pipeline lives
# on analysis-service per ADR-004; upload-service now calls
# `POST /internal/analyses` and consumes the returned refs + topic_ids.


async def persist_document_upload(
    *,
    project_id: str,
    filename: str,
    content_type: str | None,
    data: bytes,
    user: dict[str, Any],
    request: Request,
    upload_id: str | None = None,
) -> dict[str, Any]:
    validate_filename(filename)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds alpha limit of 250 MB")
    project = await _require_project_via_bu_service(request, project_id, user)
    business_unit_id = project["business_unit_id"]

    document_id = new_id("doc")
    job_id = new_id("job")
    original_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name=f"original/{filename}",
        content=data,
        content_type=content_type or "application/octet-stream",
        store=store,
        created_by=user["user_id"],
        producer="upload-service",
    )
    extraction = await run_extraction_request(
        project_id=project_id,
        business_unit_id=business_unit_id,
        document_id=document_id,
        filename=filename,
        content_type=content_type,
        original_ref=original_ref,
        user=user,
        request=request,
    )
    extraction_refs = refs_by_key(extraction.get("artifacts", []))

    if extraction.get("stage") == "failed":
        error = extraction.get("error") or {
            "kind": "unknown_extraction_failure",
            "message": "Extraction failed without a typed error.",
            "stage": "extracting",
            "retryable": False,
        }
        failure_reason = extraction_failure_reason(error)
        document = {
            "document_id": document_id,
            "tenant_id": user["tenant_id"],
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "filename": filename,
            "content_type": content_type,
            "source_hash": original_ref["hash"],
            "status": "failed_extraction",
            "extraction_failure_reason": failure_reason,
            "job_ids": [job_id],
            "topic_ids": [],
            "original_artifact": original_ref,
            "manifest": {},
            "manifest_artifact": None,
            "artifacts": {"original": original_ref},
            "latest_artifacts": latest_artifact_pointers(original=original_ref),
            "source_quality": {
                "overall_confidence": 0,
                "review_required": True,
                "validation_issue_count": 0,
                "warnings": extraction.get("warnings", []),
                "extraction_error": error,
            },
            "created_at": utc_now(),
            "upload_id": upload_id,
            "extraction": extraction,
        }
        job = {
            "job_id": job_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "stage": "extract",
            "status": "failed",
            "events": ["document.uploaded", "document.extraction_requested", "extraction.failed"],
            "created_at": utc_now(),
        }

        # Cross-backend operation order (finding #73): SQL document
        # upsert FIRST (load-bearing — the visible UI entity), JsonStore
        # job write SECOND. Failure between them leaves a document with
        # `job_ids` referencing a missing job — the job listing returns
        # empty (recoverable on retry / manual re-emit), rather than an
        # orphan job pointing at a nonexistent document.
        DocumentRepository().upsert(document)

        def save_failed_job(state: dict[str, Any]) -> dict[str, Any]:
            state["jobs"][job_id] = job
            return job

        store.mutate(save_failed_job)
        created_failed: dict[str, Any] = {"document": document, "job": job}
        if upload_id:
            UploadSessionRepository().mark_terminal(
                upload_id,
                status="failed",
                document_id=document_id,
                completed_at=utc_now(),
            )
        created_failed["project"] = await _append_document_to_project_via_bu_service(
            request, project_id, document_id, user
        )
        await emit_audit_event(
            {
                "actor_id": user["user_id"],
                "action": "extraction.failed",
                "resource_type": "document",
                "resource_id": document_id,
                "business_unit_id": business_unit_id,
                "project_id": project_id,
                "metadata": {"filename": filename, "error": error},
            },
            headers=context_headers(request, user),
            store=store,
        )
        return created_failed

    required_artifacts = {"source_blocks", "structure_tree", "asset_manifest", "markdown", "extraction_quality"}
    missing_artifacts = sorted(required_artifacts - extraction_refs.keys())
    # Step G4: use the dedicated `missing_required_artifacts` blocking
    # reason for the incomplete-artifact-set case. Previously this path
    # used `asset_unresolved`, which is the schema's reason for asset
    # manifest reference failures — a different failure mode that the
    # triage queue routes to a different workflow.
    extraction_quality = (
        read_artifact_json(extraction_refs["extraction_quality"])
        if "extraction_quality" in extraction_refs
        else {
            "gate": synthetic_failed_quality_gate(
                reasons=["missing_required_artifacts"],
                warnings=[
                    {
                        "kind": "missing_artifacts",
                        "message": f"Extraction service returned an incomplete artifact set: {', '.join(missing_artifacts)}",
                    }
                ],
            ),
            "metrics": {},
            "runtime": {},
        }
    )
    quality_gate = extraction.get("quality_gate") or extraction_quality.get("gate") or legacy_quality_gate()
    if missing_artifacts:
        quality_gate = synthetic_failed_quality_gate(
            reasons=["missing_required_artifacts"],
            warnings=[
                {
                    "kind": "missing_artifacts",
                    "message": f"Extraction service returned an incomplete artifact set: {', '.join(missing_artifacts)}",
                }
            ],
        )
    if quality_gate.get("passed") is False:
        refs = dict(extraction_refs)
        suffix = Path(filename).suffix.lower()
        manifest = {
            "document_id": document_id,
            "source_filename": filename,
            "source_hash": original_ref["hash"],
            "file_type": suffix.lstrip(".") or "text",
            "artifact_version": next(iter(refs.values()), original_ref).get("artifact_version", 1),
            "created_artifacts": list(refs.keys()),
            "extractor_version": extraction.get("extractor_version"),
            "extraction_id": extraction.get("extraction_id"),
            "quality_gate": quality_gate,
        }
        manifest_ref = write_artifact(
            project_id=project_id,
            document_id=document_id,
            name="document-manifest.json",
            content=manifest,
            store=store,
            created_by=user["user_id"],
            producer="upload-service",
        )
        refs["document_manifest"] = manifest_ref
        latest_refs = {"original": original_ref, **refs}
        source_quality = {
            "overall_confidence": (
                extraction_quality.get("metrics", {}).get("structure_confidence")
                if isinstance(extraction_quality, dict)
                else None
            )
            or 0,
            "review_required": True,
            "validation_issue_count": 0,
            "warnings": extraction.get("warnings", []),
            "block_count": extraction.get("block_count", 0),
            "asset_count": extraction.get("asset_count", 0),
            "quality_gate": quality_gate,
        }
        document = {
            "document_id": document_id,
            "tenant_id": user["tenant_id"],
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "filename": filename,
            "content_type": content_type,
            "source_hash": original_ref["hash"],
            "status": "extraction_needs_review",
            "job_ids": [job_id],
            "topic_ids": [],
            "original_artifact": original_ref,
            "manifest": manifest,
            "manifest_artifact": manifest_ref,
            "artifacts": refs,
            "latest_artifacts": latest_artifact_pointers(**latest_refs),
            "source_quality": source_quality,
            "created_at": utc_now(),
            "upload_id": upload_id,
            "extraction": extraction,
        }
        job = {
            "job_id": job_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "stage": "extract",
            "status": "blocked",
            "events": [
                "document.uploaded",
                "document.extraction_requested",
                "extraction.started",
                "extraction.completed",
                "extraction.gate.blocked_analysis",
            ],
            "created_at": utc_now(),
        }

        # Operation ordering: see save_failed above (finding #73).
        DocumentRepository().upsert(document)

        def save_blocked_job(state: dict[str, Any]) -> dict[str, Any]:
            state["jobs"][job_id] = job
            return job

        store.mutate(save_blocked_job)
        created_blocked: dict[str, Any] = {"document": document, "job": job}
        if upload_id:
            UploadSessionRepository().mark_terminal(
                upload_id,
                status="needs_review",
                document_id=document_id,
                completed_at=utc_now(),
            )
        created_blocked["project"] = await _append_document_to_project_via_bu_service(
            request, project_id, document_id, user
        )
        await emit_audit_event(
            {
                "actor_id": user["user_id"],
                "action": "extraction.gate.blocked_analysis",
                "resource_type": "document",
                "resource_id": document_id,
                "business_unit_id": business_unit_id,
                "project_id": project_id,
                "metadata": {
                    "filename": filename,
                    "blocking_reasons": quality_gate.get("blocking_reasons", []),
                },
            },
            headers=context_headers(request, user),
            store=store,
        )
        return created_blocked

    # Phase 8 — analysis pipeline now lives on analysis-service. Pass the
    # extraction artifact refs through; analysis-service reads them,
    # runs topic-plan → generate-topic → dita → validation, persists
    # topics + analysis artifacts, and returns the refs + topic_ids
    # this route needs to build the document record.
    analysis_response = await request_service(
        method="POST",
        base_url=ANALYSIS_SERVICE_URL,
        path="/internal/analyses",
        headers=context_headers(request, user),
        json={
            "document_id": document_id,
            "project_id": project_id,
            "business_unit_id": business_unit_id,
            "tenant_id": user["tenant_id"],
            "actor_id": user["user_id"],
            "source_blocks_artifact": extraction_refs["source_blocks"],
            "structure_tree_artifact": extraction_refs["structure_tree"],
            "asset_manifest_artifact": extraction_refs["asset_manifest"],
            "markdown_artifact": extraction_refs["markdown"],
            "model_name": DEFAULT_MODEL_NAME,
            "prompt_version": DEFAULT_PROMPT_VERSION,
        },
    )
    if analysis_response.status_code != 200:
        raise HTTPException(
            status_code=analysis_response.status_code,
            detail=f"analysis-service failed: {analysis_response.text}",
        )
    analysis = analysis_response.json()
    refs = {**extraction_refs, **analysis["analysis_refs"]}
    topic_ids = list(analysis["topic_ids"])
    review_required = bool(analysis.get("review_required", False))
    validation_issue_count = int(analysis.get("validation_issue_count", 0))
    analysis_block_count = int(analysis.get("block_count", extraction.get("block_count", 0)))
    analysis_asset_count = int(analysis.get("asset_count", extraction.get("asset_count", 0)))
    overall_confidence = analysis.get("overall_confidence")

    suffix = Path(filename).suffix.lower()
    manifest = {
        "document_id": document_id,
        "source_filename": filename,
        "source_hash": original_ref["hash"],
        "file_type": suffix.lstrip(".") or "text",
        "artifact_version": refs["source_blocks"]["artifact_version"],
        "created_artifacts": list(refs.keys()),
        "extractor_version": extraction.get("extractor_version"),
        "extraction_id": extraction.get("extraction_id"),
        "quality_gate": quality_gate,
    }
    manifest_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="document-manifest.json",
        content=manifest,
        store=store,
        created_by=user["user_id"],
        producer="upload-service",
    )
    refs["document_manifest"] = manifest_ref
    latest_refs = {"original": original_ref, **refs}
    document = {
        "document_id": document_id,
        "tenant_id": user["tenant_id"],
        "business_unit_id": business_unit_id,
        "project_id": project_id,
        "filename": filename,
        "content_type": content_type,
        "source_hash": original_ref["hash"],
        "status": "ready_for_review",
        "job_ids": [job_id],
        "topic_ids": topic_ids,
        "original_artifact": original_ref,
        "manifest": manifest,
        "manifest_artifact": manifest_ref,
        "artifacts": refs,
        "latest_artifacts": latest_artifact_pointers(**latest_refs),
        "source_quality": {
            # Phase 8 — analysis-service is the canonical source for
            # post-pipeline metrics. block_count/asset_count come from
            # extraction (the canonical source); fallback to analysis
            # if extraction stripped them.
            "overall_confidence": overall_confidence,
            "review_required": review_required,
            "validation_issue_count": validation_issue_count,
            "warnings": extraction.get("warnings", []),
            "block_count": extraction.get("block_count", analysis_block_count),
            "asset_count": extraction.get("asset_count", analysis_asset_count),
            "quality_gate": quality_gate,
        },
        "created_at": utc_now(),
        "upload_id": upload_id,
        "extraction": extraction,
    }
    job = {
        "job_id": job_id,
        "business_unit_id": business_unit_id,
        "project_id": project_id,
        "document_id": document_id,
        "stage": "pipeline",
        "status": "completed",
        "events": [
            "document.uploaded",
            "document.extraction_requested",
            "extraction.started",
            "extraction.completed",
            "markdown.started",
            "markdown.completed",
            "document.analysis.completed",
            "topic.plan.created",
            "dita.generation.completed",
            "dita.validation.completed",
        ],
        "created_at": utc_now(),
    }

    # Operation ordering: see save_failed above (finding #73).
    DocumentRepository().upsert(document)

    def save_job(state: dict[str, Any]) -> dict[str, Any]:
        state["jobs"][job_id] = job
        return job

    store.mutate(save_job)
    created: dict[str, Any] = {"document": document, "job": job}
    if upload_id:
        UploadSessionRepository().mark_terminal(
            upload_id,
            status="completed",
            document_id=document_id,
            completed_at=utc_now(),
        )
    created["project"] = await _append_document_to_project_via_bu_service(
        request, project_id, document_id, user
    )
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "document.uploaded",
            "resource_type": "document",
            "resource_id": document_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "metadata": {"filename": filename, "topic_count": len(topic_ids)},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


@app.post("/internal/projects/{project_id}/documents/uploads")
async def create_upload_or_document(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    reject_oversized_content_length(request)
    project = await _require_project_via_bu_service(request, project_id, user)

    content_type = request.headers.get("content-type", "")
    if content_type.startswith("multipart/form-data"):
        form = await request.form()
        file = form.get("file")
        if file is None or not hasattr(file, "filename") or not hasattr(file, "read"):
            raise HTTPException(status_code=400, detail="Missing multipart file field")
        filename = file.filename or "upload.txt"
        validate_filename(filename)
        data = await file.read()
        return await persist_document_upload(
            project_id=project_id,
            filename=filename,
            content_type=getattr(file, "content_type", None),
            data=data,
            user=user,
            request=request,
        )

    payload = UploadSessionCreate.model_validate(await request.json())
    validate_filename(payload.filename)
    if payload.size_bytes is not None and payload.size_bytes > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds alpha limit of 250 MB")
    upload_id = new_id("upl")
    session = {
        "upload_id": upload_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "business_unit_id": project["business_unit_id"],
        "project_id": project_id,
        "filename": payload.filename,
        "content_type": payload.content_type,
        "size_bytes": payload.size_bytes,
        "status": "created",
        "parts": [],
        "received_bytes": 0,
        "created_by": user["user_id"],
        "created_at": utc_now(),
    }

    created = UploadSessionRepository().upsert(session)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "upload.session.created",
            "resource_type": "upload_session",
            "resource_id": upload_id,
            "business_unit_id": project["business_unit_id"],
            "project_id": project_id,
            "metadata": {"filename": payload.filename},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


@app.get("/internal/business-units/{business_unit_id}/documents")
def list_business_unit_documents(
    business_unit_id: str,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # `require_business_unit(state, ...)` still reads BU-service-owned
    # `state["business_units"]` — the finding #67 boundary leak that
    # stays in JsonStore until D5/D7 cleanup. Out of D4.5.b scope.
    require_business_unit(store.read(), business_unit_id, user)
    return {
        "business_unit_id": business_unit_id,
        "documents": DocumentRepository().list_for_business_unit(business_unit_id),
    }


@app.get("/internal/projects/{project_id}/documents")
async def list_project_documents(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D4.4.a — project-scoped documents listing.

    Filters by `document.project_id` (canonical signal) rather than by
    the BU service's `project.document_ids` denorm — see finding #24
    (denorm drift is best-effort; the document record is authoritative).
    Project access is verified via BU service before the documents are
    returned, so tenant isolation is preserved across the cross-service
    boundary."""
    await _require_project_via_bu_service(request, project_id, user)
    return {
        "project_id": project_id,
        "documents": DocumentRepository().list_for_project(project_id),
    }


@app.get("/internal/projects/{project_id}/storage-summary")
async def project_storage_summary(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D4.4.a — upload-side aggregation for a project.

    Returns the upload-service-owned counters that BU service's
    `project_status_summary` needs. Reading these here (where the data
    lives) avoids N×3 cross-service round-trips (documents + jobs +
    artifact_registry) per project on BU service summary pages.

    Topic-related fields (`approved_topics`, `topic_count`,
    `export_ready_count`) and project-metadata fields
    (`last_activity_at`) are owned elsewhere and stay in BU service."""
    await _require_project_via_bu_service(request, project_id, user)
    documents = DocumentRepository().list_for_project(project_id)
    # Jobs + artifact_registry are still JsonStore-backed (D4.5.c / D4.5.d
    # will migrate them). The single store.read() here is the only
    # JsonStore touch in this route after D4.5.b.
    state = store.read()
    document_ids = {document["document_id"] for document in documents}
    jobs = [
        job
        for job in state["jobs"].values()
        if job.get("document_id") in document_ids
    ]
    storage_bytes = sum(
        artifact.get("size_bytes", 0)
        for artifact in state.get("artifact_registry", {}).values()
        if artifact.get("project_id") == project_id
    )
    confidence_values = [
        document.get("source_quality", {}).get("overall_confidence")
        for document in documents
        if document.get("source_quality", {}).get("overall_confidence") is not None
    ]

    return {
        "project_id": project_id,
        "document_count": len(documents),
        "processing_count": sum(
            1 for job in jobs if job.get("status") in {"queued", "running", "processing"}
        ),
        "review_ready_count": sum(
            1 for document in documents if document.get("status") == "ready_for_review"
        ),
        "validation_warning_count": sum(
            document.get("source_quality", {}).get("validation_issue_count", 0)
            for document in documents
        ),
        "failed_job_count": sum(1 for job in jobs if job.get("status") == "failed"),
        "storage_bytes": storage_bytes,
        "confidence_values": confidence_values,
        "topic_id_count": sum(len(document.get("topic_ids", [])) for document in documents),
    }


@app.post("/internal/business-units/{business_unit_id}/documents/uploads")
async def create_business_unit_upload_or_document(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    reject_oversized_content_length(request)
    project = await ensure_document_workspace_project(request, business_unit_id, user)
    project_id = project["project_id"]

    content_type = request.headers.get("content-type", "")
    if content_type.startswith("multipart/form-data"):
        form = await request.form()
        file = form.get("file")
        if file is None or not hasattr(file, "filename") or not hasattr(file, "read"):
            raise HTTPException(status_code=400, detail="Missing multipart file field")
        filename = file.filename or "upload.txt"
        validate_filename(filename)
        data = await file.read()
        created = await persist_document_upload(
            project_id=project_id,
            filename=filename,
            content_type=getattr(file, "content_type", None),
            data=data,
            user=user,
            request=request,
        )
        return {key: value for key, value in created.items() if key != "project"}

    payload = UploadSessionCreate.model_validate(await request.json())
    validate_filename(payload.filename)
    if payload.size_bytes is not None and payload.size_bytes > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds alpha limit of 250 MB")
    upload_id = new_id("upl")
    session = {
        "upload_id": upload_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "business_unit_id": business_unit_id,
        "project_id": project_id,
        "filename": payload.filename,
        "content_type": payload.content_type,
        "size_bytes": payload.size_bytes,
        "status": "created",
        "parts": [],
        "received_bytes": 0,
        "created_by": user["user_id"],
        "created_at": utc_now(),
    }

    created = UploadSessionRepository().upsert(session)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "upload.session.created",
            "resource_type": "upload_session",
            "resource_id": upload_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "metadata": {"filename": payload.filename},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


async def require_upload_session(
    request: Request, upload_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    session = UploadSessionRepository().get(upload_id)
    if not session or session.get("tenant_id") != user["tenant_id"]:
        raise HTTPException(status_code=404, detail="Upload session not found")
    await _require_project_via_bu_service(request, session["project_id"], user)
    return session


async def require_topic_record(
    request: Request, topic_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    state = store.read()
    topic = state["topics"].get(topic_id)
    if not topic or topic.get("tenant_id") != user["tenant_id"]:
        raise HTTPException(status_code=404, detail="Topic not found")
    await _require_project_via_bu_service(
        request, topic["project_id"], user, include_deleted=True
    )
    return topic


async def require_export_record(
    request: Request, export_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    state = store.read()
    record = state["exports"].get(export_id)
    if not record:
        raise HTTPException(status_code=404, detail="Export not found")
    await _require_project_via_bu_service(
        request, record["project_id"], user, include_deleted=True
    )
    return record


@app.post("/internal/uploads/{upload_id}/parts")
async def upload_part(
    upload_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    reject_oversized_content_length(request)
    session = await require_upload_session(request, upload_id, user)
    content_type = request.headers.get("content-type", "")
    filename = session["filename"]
    part_number = 1
    if content_type.startswith("multipart/form-data"):
        form = await request.form()
        file = form.get("file")
        if file is None or not hasattr(file, "read"):
            raise HTTPException(status_code=400, detail="Missing multipart file field")
        uploaded_filename = getattr(file, "filename", None)
        if uploaded_filename:
            filename = uploaded_filename
        data = await file.read()
    else:
        payload = UploadPartRequest.model_validate(await request.json())
        if payload.content_base64:
            data = base64.b64decode(payload.content_base64)
        else:
            data = (payload.content or "").encode("utf-8")
        part_number = payload.part_number
    if session.get("received_bytes", 0) + len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds alpha limit of 250 MB")

    encoded = base64.b64encode(data).decode("ascii")
    updated = UploadSessionRepository().append_part(
        upload_id,
        filename=filename,
        part_number=part_number,
        data_base64=encoded,
        size_bytes=len(data),
        received_at=utc_now(),
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="Upload session not found")
    return updated


@app.post("/internal/uploads/{upload_id}/complete")
async def complete_upload(
    upload_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    session = await require_upload_session(request, upload_id, user)
    if not session.get("parts"):
        raise HTTPException(status_code=400, detail="Upload session has no parts")
    data = b"".join(base64.b64decode(part["data_base64"]) for part in session["parts"])
    return await persist_document_upload(
        project_id=session["project_id"],
        filename=session["filename"],
        content_type=session.get("content_type"),
        data=data,
        user=user,
        request=request,
        upload_id=upload_id,
    )


@app.get("/internal/documents/{document_id}")
async def get_document(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    return await _require_document_via_repo(request, document_id, user)


@app.get("/internal/documents/{document_id}/manifest")
async def get_manifest(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return document["manifest"]


@app.get("/internal/documents/{document_id}/artifacts")
async def get_artifacts(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    state = store.read()
    registry = [
        entry
        for entry in state["artifact_registry"].values()
        if entry["document_id"] == document_id
    ]
    registry.sort(key=lambda entry: (entry["name"], entry["artifact_version"]))
    return {"document_id": document_id, "artifacts": document["artifacts"], "registry": registry}


@app.get("/internal/documents/{document_id}/artifacts/extraction-quality.json")
async def get_extraction_quality_artifact(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return get_quality_artifact_for_document(document)


@app.get("/internal/documents/{document_id}/extraction-review-summary")
async def get_extraction_review_summary(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return extraction_review_summary(document)


@app.get("/internal/documents/{document_id}/blocks")
async def get_blocks(
    document_id: str,
    request: Request,
    cursor: int = 0,
    limit: int = 100,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    blocks = safe_document_blocks(document)
    page = blocks[cursor : cursor + limit]
    next_cursor = cursor + limit if cursor + limit < len(blocks) else None
    return {"items": page, "next_cursor": next_cursor}


@app.get("/internal/documents/{document_id}/assets")
async def get_assets(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return read_artifact_json(document["artifacts"]["asset_manifest"])


@app.get("/internal/documents/{document_id}/assets/{asset_id}")
async def get_asset_content(
    document_id: str,
    asset_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> FileResponse:
    document = await _require_document_via_repo(request, document_id, user)
    state = store.read()
    manifest = read_artifact_json(document["artifacts"]["asset_manifest"])
    asset = next((item for item in manifest.get("assets", []) if item["asset_id"] == asset_id), None)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    artifact_id = document.get("latest_artifacts", {}).get(asset["dita_href"])
    registry_entry = state["artifact_registry"].get(artifact_id) if artifact_id else None
    if not registry_entry:
        raise HTTPException(status_code=404, detail="Asset artifact not found")
    return FileResponse(
        registry_entry["path"],
        media_type=registry_entry["content_type"],
        filename=asset["filename"],
    )


@app.get("/internal/documents/{document_id}/source-file")
async def get_source_file(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> FileResponse:
    document = await _require_document_via_repo(request, document_id, user)
    original = document["original_artifact"]
    return FileResponse(
        original["path"],
        media_type=original["content_type"],
        filename=document["filename"],
    )


@app.get("/internal/documents/{document_id}/jobs")
async def get_document_jobs(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    state = store.read()
    return {"jobs": [state["jobs"][job_id] for job_id in document.get("job_ids", [])]}


@app.get("/internal/documents/{document_id}/source-quality")
async def get_source_quality(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return document["source_quality"]


@app.post("/internal/documents/{document_id}/override-gate")
async def override_document_quality_gate(
    document_id: str,
    payload: GateOverrideRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin"})
    document = await _require_document_via_repo(request, document_id, user)
    now = utc_now()

    def mutator(envelope: dict[str, Any]) -> None:
        source_quality = envelope["source_quality"]
        gate = source_quality.get("quality_gate") or legacy_quality_gate()
        history = list(gate.get("override_history") or [])
        # Step G2: capture the gate's PRE-override evidence as
        # `override.prior_gate` AT THE MOMENT THE OVERRIDE IS APPLIED.
        # The snapshot moves with the override into history when a
        # later override displaces it. Capturing here (and not at the
        # push-to-history moment) is correct: at push-to-history time,
        # the gate has already been transformed by the prior override,
        # so the original blocking_reasons would be unrecoverable.
        prior_gate_snapshot = {
            "passed": gate.get("passed"),
            "severity": gate.get("severity"),
            "blocking_reasons": list(gate.get("blocking_reasons") or []),
            "warnings": list(gate.get("warnings") or []),
        }
        override = {
            "by": user["user_id"],
            "at": now,
            "reason": payload.reason,
            "prior_gate": prior_gate_snapshot,
        }
        if gate.get("override"):
            # Move the previous active override (with its already-attached
            # prior_gate) into history. Don't recompute prior_gate — the
            # value on the existing override is the correct one.
            history.append(gate["override"])
        gate = {
            **gate,
            "passed": True,
            "severity": "info",
            "blocking_reasons": [],
            "override": override,
            "override_history": history,
        }
        source_quality["quality_gate"] = gate
        source_quality["review_required"] = True
        envelope["status"] = "ready_for_review"
        # Step G6: `gate_overridden_at`/`gate_overridden_by` removed.
        # They were write-only duplicates of `gate.override.at`/`.by`
        # (no consumer read them in Python, TypeScript, or tests). The
        # canonical source is now `quality_gate.override`.

    updated = DocumentRepository().with_atomic_update(document_id, mutator)
    if updated is None:
        # Document deleted between auth check and update — race-condition
        # 404 rather than the old JsonStore KeyError. See finding #73 on
        # cross-backend atomicity loss.
        raise HTTPException(status_code=404, detail="Document not found")
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "document.gate_overridden",
            "resource_type": "document",
            "resource_id": document_id,
            "business_unit_id": document["business_unit_id"],
            "project_id": document["project_id"],
            "metadata": {"reason": payload.reason},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return updated


@app.post("/internal/documents/{document_id}/reextract")
async def reextract_document(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin"})
    document = await _require_document_via_repo(request, document_id, user)
    # Step G1: rate-limit. Reject inside the throttle window with HTTP 429
    # and an audit event so operators can spot abuse from logs. The
    # window is REEXTRACT_THROTTLE_WINDOW_S (600s = 10min) — long enough
    # that nobody hits it from normal use, short enough to throttle a
    # tight loop. v1 limitation: in-memory per instance.
    now_dt = datetime.now(UTC)
    last_attempt = _reextract_last_attempt_at.get(document_id)
    if last_attempt is not None and now_dt - last_attempt < timedelta(
        seconds=REEXTRACT_THROTTLE_WINDOW_S
    ):
        retry_after_s = int(
            REEXTRACT_THROTTLE_WINDOW_S - (now_dt - last_attempt).total_seconds()
        )
        await emit_audit_event(
            {
                "actor_id": user["user_id"],
                "action": "extraction.reextract.throttled",
                "resource_type": "document",
                "resource_id": document_id,
                "business_unit_id": document["business_unit_id"],
                "project_id": document["project_id"],
                "metadata": {
                    "retry_after_s": retry_after_s,
                    "window_s": REEXTRACT_THROTTLE_WINDOW_S,
                },
            },
            headers=context_headers(request, user),
            store=store,
        )
        raise HTTPException(
            status_code=429,
            detail=(
                f"Re-extraction is throttled per document; retry in "
                f"{retry_after_s}s."
            ),
            headers={"Retry-After": str(retry_after_s)},
        )
    _reextract_last_attempt_at[document_id] = now_dt
    original = document["original_artifact"]
    extraction = await run_extraction_request(
        project_id=document["project_id"],
        business_unit_id=document["business_unit_id"],
        document_id=document_id,
        filename=document["filename"],
        content_type=document.get("content_type"),
        original_ref=original,
        user=user,
        request=request,
    )
    refs = refs_by_key(extraction.get("artifacts", []))
    quality_gate = extraction.get("quality_gate") or legacy_quality_gate()

    def mutator(envelope: dict[str, Any]) -> None:
        # Note: the JsonStore-era code also wrote a `last_reextract_at`
        # decoration; that field has zero readers across services,
        # packages, tests, and apps, so D4.5.b drops the write (the
        # column doesn't exist on the Document model, and the D4.3
        # migration script would have dropped the legacy values anyway).
        if extraction.get("stage") == "failed":
            error = extraction.get("error") or {
                "kind": "unknown_extraction_failure",
                "message": "Extraction failed without a typed error.",
                "stage": "extracting",
                "retryable": False,
            }
            envelope["extraction"] = extraction
            envelope["status"] = "failed_extraction"
            envelope["extraction_failure_reason"] = extraction_failure_reason(error)
            envelope["source_quality"]["review_required"] = True
            envelope["source_quality"]["extraction_error"] = error
            envelope["source_quality"]["warnings"] = extraction.get("warnings", [])
            envelope["source_quality"]["block_count"] = 0
            envelope["source_quality"]["asset_count"] = 0
            return
        if refs:
            envelope["artifacts"].update(refs)
            envelope["latest_artifacts"].update(latest_artifact_pointers(**refs))
        envelope["extraction"] = extraction
        # Clearing nullable columns: set to None rather than `pop`. The
        # `with_atomic_update` setattr loop iterates `envelope.items()`,
        # so a popped key would leave the row column untouched (an old
        # `extraction_failure_reason` would persist). `to_envelope`
        # filters None out at read time, so the wire shape is preserved.
        envelope["extraction_failure_reason"] = None
        envelope["source_quality"].pop("extraction_error", None)
        envelope["source_quality"]["quality_gate"] = quality_gate
        envelope["source_quality"]["warnings"] = extraction.get("warnings", [])
        envelope["source_quality"]["block_count"] = extraction.get("block_count", 0)
        envelope["source_quality"]["asset_count"] = extraction.get("asset_count", 0)
        envelope["status"] = (
            "ready_for_review" if quality_gate.get("passed") else "extraction_needs_review"
        )

    updated = DocumentRepository().with_atomic_update(document_id, mutator)
    if updated is None:
        raise HTTPException(status_code=404, detail="Document not found")
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "extraction.reextract.requested",
            "resource_type": "document",
            "resource_id": document_id,
            "business_unit_id": document["business_unit_id"],
            "project_id": document["project_id"],
            "metadata": {"passed": quality_gate.get("passed")},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return updated


@app.get("/internal/documents/{document_id}/markdown")
async def get_markdown(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return {"document_id": document_id, "markdown": read_artifact_text(document["artifacts"]["markdown"])}


@app.delete("/internal/documents/{document_id}")
async def delete_document(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, bool]:
    """Phase 4 D3.7.c: project.document_ids removal delegated to BU service.

    Was sync + did the document_ids comprehension inside `state.mutate`.
    Now async: BU service removes the document_id from its project
    record first (idempotent — no-op if already absent), then this
    route's local mutate drops the upload-service-owned records
    (document, topics, jobs, artifacts)."""
    assert_role(user, {"org_admin", "project_admin", "editor"})
    document = await _require_document_via_repo(request, document_id, user)
    project_id = document["project_id"]

    await _remove_document_from_project_via_bu_service(
        request, project_id, document_id, user
    )

    # Cross-backend delete ordering: JsonStore cascade FIRST (topics +
    # jobs + artifact_registry), SQL document delete LAST. Rationale —
    # the document is the visible UI entity; until SQL deletes it, the
    # row remains and a retry of the route is straightforward (the
    # document envelope is still resolvable for re-running the cascade).
    # Reversing the order would leave orphan rows in the JsonStore-side
    # tables pointing at a vanished document — recoverable only by an
    # explicit sweep keyed on `document_id`.
    def delete_cascade(state: dict[str, Any]) -> None:
        for topic_id in list(document.get("topic_ids", [])):
            state["topics"].pop(topic_id, None)
        for job_id in list(document.get("job_ids", [])):
            state["jobs"].pop(job_id, None)
        for artifact_id, artifact in list(state["artifact_registry"].items()):
            if artifact.get("document_id") == document_id:
                state["artifact_registry"].pop(artifact_id, None)
        return None

    store.mutate(delete_cascade)
    DocumentRepository().delete(document_id)
    return {"ok": True}


@app.get("/internal/documents/{document_id}/topic-plan")
async def get_document_topic_plan(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return {
        "document_id": document_id,
        "filename": document["filename"],
        "topic_plan": read_artifact_json(document["artifacts"]["topic_plan"]),
        "approved": document.get("topic_plan_approved", False),
    }


@app.post("/internal/documents/{document_id}/topic-plan/approve")
async def approve_document_topic_plan(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "information_architect"})
    document = await _require_document_via_repo(request, document_id, user)

    if DocumentRepository().mark_topic_plan_approved(document_id) is None:
        # Race with delete between auth check and flip.
        raise HTTPException(status_code=404, detail="Document not found")
    result = {"document_id": document_id, "approved": True}
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.plan.approved",
            "resource_type": "document",
            "resource_id": document_id,
            "business_unit_id": document["business_unit_id"],
            "project_id": document["project_id"],
        },
        headers=context_headers(request, user),
        store=store,
    )
    return result


@app.get("/internal/projects/{project_id}/topic-plan")
async def get_topic_plan(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    project = await _require_project_via_bu_service(request, project_id, user)
    # Iterate the BU service's `document_ids` denorm to preserve insertion
    # order (no `created_at desc` reshuffling). Look up envelopes via the
    # repo's project-scoped query — one DB hit, then in-memory join keyed
    # by document_id.
    by_id = {
        document["document_id"]: document
        for document in DocumentRepository().list_for_project(project_id)
    }
    plans = [
        {
            "document_id": document_id,
            "filename": document["filename"],
            "topic_plan": read_artifact_json(document["artifacts"]["topic_plan"]),
            "approved": document.get("topic_plan_approved", False),
        }
        for document_id in project.get("document_ids", [])
        if (document := by_id.get(document_id)) is not None
    ]
    return {"project_id": project_id, "documents": plans}


@app.patch("/internal/projects/{project_id}/topic-plan")
async def patch_topic_plan(
    project_id: str,
    patch: dict[str, Any],
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "information_architect"})
    await _require_project_via_bu_service(request, project_id, user)
    return {"project_id": project_id, "status": "accepted_for_alpha", "patch": patch}


@app.post("/internal/projects/{project_id}/topic-plan/approve")
async def approve_topic_plan(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "information_architect"})
    project = await _require_project_via_bu_service(request, project_id, user)

    # Atomic batch flip: one SQL statement, all-or-nothing — replaces the
    # JsonStore mutate-callback loop. The rowcount is intentionally
    # ignored; the wire shape returns the same fixed `approved=True`
    # the JsonStore version did, regardless of how many docs existed.
    DocumentRepository().mark_topic_plan_approved_for(project.get("document_ids", []))
    result = {"project_id": project_id, "approved": True}
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "topic.plan.approved",
            "resource_type": "project",
            "resource_id": project_id,
            "business_unit_id": project["business_unit_id"],
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return result


@app.post("/internal/documents/{document_id}/topic-plan/recompute")
async def recompute_topic_plan(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    document = await _require_document_via_repo(request, document_id, user)
    return {
        "document_id": document_id,
        "status": "already_computed_alpha",
        "topic_plan": read_artifact_json(document["artifacts"]["topic_plan"]),
    }


@app.get("/internal/topics/{topic_id}")
async def get_topic(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    return await require_topic_record(request, topic_id, user)


@app.patch("/internal/topics/{topic_id}")
async def patch_topic(
    topic_id: str,
    request_body: TopicPatchRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """ADR-006 PATCH /v1/topics back-compat.

    The legacy `{xml: str}` body shape is preserved (Phase 6), but the
    actual edit flows through review-service as a RawXmlOverrideOp so
    it lands in the same audit log as structural ops and replays
    consistently. The topic.edited event AND the post-edit DITA
    validation are owned by review-service (Phase 7) — this route is a
    pure delegating proxy.
    """
    assert_role(user, {"org_admin", "project_admin", "editor"})
    await require_topic_record(request, topic_id, user)
    response = await request_service(
        method="POST",
        base_url=REVIEW_SERVICE_URL,
        path=f"/internal/topics/{topic_id}/ops",
        headers=context_headers(request, user),
        json={
            "op_type": "raw_xml_override",
            "payload": {"topic_id": topic_id, "xml": request_body.xml},
            "is_lossy": True,
        },
    )
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    return store.read()["topics"][topic_id]


@app.get("/internal/topics/{topic_id}/validation-issues")
async def get_validation_issues(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    topic = await require_topic_record(request, topic_id, user)
    return {"topic_id": topic_id, "issues": topic.get("validation_issues", [])}


@app.get("/internal/topics/{topic_id}/traceability")
async def get_traceability(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    topic = await require_topic_record(request, topic_id, user)
    return {"topic_id": topic_id, "traceability": topic.get("traceability", [])}


@app.post("/internal/projects/{project_id}/exports")
async def create_export(
    project_id: str,
    request_body: ExportCreateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "reviewer"})
    project = await _require_project_via_bu_service(request, project_id, user)
    state = store.read()
    topics = [
        topic
        for topic in state["topics"].values()
        if topic["project_id"] == project_id
        and (request_body.include_unapproved or topic["status"] == "approved")
    ]
    if not topics:
        raise HTTPException(status_code=400, detail="No topics are available to export")
    generated_topics = [topic["generated_topic"] for topic in topics]
    dita_files = {f"topics/{topic['topic_id']}.dita": topic["dita_xml"] for topic in topics}
    dita_files["ditagen.ditamap"] = build_dita_files(generated_topics)["ditagen.ditamap"]
    validation_issues = [issue for topic in topics for issue in topic.get("validation_issues", [])]
    zip_bytes = build_export_zip(
        document_id=project_id,
        topic_plan={"project_id": project_id, "document_ids": project.get("document_ids", [])},
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        markdown="",
    )
    export_id = new_id("exp")
    export_ref = write_artifact(
        project_id=project_id,
        document_id="project-export",
        name=f"{slugify(project['name'])}-{export_id}.zip",
        content=zip_bytes,
        content_type="application/zip",
        store=store,
        created_by=user["user_id"],
    )
    record = {
        "export_id": export_id,
        "business_unit_id": project["business_unit_id"],
        "project_id": project_id,
        "status": "completed",
        "topic_count": len(topics),
        "artifact": export_ref,
        "logs": [
            f"Packaged {len(topics)} topic(s)",
            f"Included {len(validation_issues)} validation issue(s) in report",
        ],
    }

    def save(state: dict[str, Any]) -> dict[str, Any]:
        state["exports"][export_id] = record
        return record

    saved = store.mutate(save)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "export.completed",
            "resource_type": "export",
            "resource_id": export_id,
            "business_unit_id": project["business_unit_id"],
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return saved


@app.post("/internal/documents/{document_id}/exports")
async def create_document_export(
    document_id: str,
    request_body: ExportCreateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor", "reviewer"})
    document = await _require_document_via_repo(request, document_id, user)
    state = store.read()
    topics = [
        topic
        for topic in state["topics"].values()
        if topic["document_id"] == document_id
        and (request_body.include_unapproved or topic["status"] == "approved")
    ]
    if not topics:
        raise HTTPException(status_code=400, detail="No topics are available to export")
    generated_topics = [topic["generated_topic"] for topic in topics]
    dita_files = {f"topics/{topic['topic_id']}.dita": topic["dita_xml"] for topic in topics}
    dita_files["ditagen.ditamap"] = build_dita_files(generated_topics)["ditagen.ditamap"]
    validation_issues = [issue for topic in topics for issue in topic.get("validation_issues", [])]
    zip_bytes = build_export_zip(
        document_id=document_id,
        topic_plan=read_artifact_json(document["artifacts"]["topic_plan"]),
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        markdown=read_artifact_text(document["artifacts"]["markdown"]),
    )
    export_id = new_id("exp")
    export_ref = write_artifact(
        project_id=document["project_id"],
        document_id=document_id,
        name=f"{slugify(Path(document['filename']).stem)}-{export_id}.zip",
        content=zip_bytes,
        content_type="application/zip",
        store=store,
        created_by=user["user_id"],
    )
    record = {
        "export_id": export_id,
        "business_unit_id": document["business_unit_id"],
        "project_id": document["project_id"],
        "document_id": document_id,
        "status": "completed",
        "topic_count": len(topics),
        "artifact": export_ref,
        "logs": [
            f"Packaged {len(topics)} topic(s)",
            f"Included {len(validation_issues)} validation issue(s) in report",
        ],
    }

    def save(state: dict[str, Any]) -> dict[str, Any]:
        state["exports"][export_id] = record
        return record

    saved = store.mutate(save)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "export.completed",
            "resource_type": "export",
            "resource_id": export_id,
            "business_unit_id": document["business_unit_id"],
            "project_id": document["project_id"],
            "metadata": {"document_id": document_id},
        },
        headers=context_headers(request, user),
        store=store,
    )
    return saved


@app.get("/internal/exports/{export_id}")
async def get_export(
    export_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    return await require_export_record(request, export_id, user)


@app.get("/internal/exports/{export_id}/logs")
async def get_export_logs(
    export_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    record = await require_export_record(request, export_id, user)
    return {"export_id": export_id, "logs": record.get("logs", [])}


@app.get("/internal/exports/{export_id}/download")
async def download_export(
    export_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> FileResponse:
    record = await require_export_record(request, export_id, user)
    return FileResponse(
        record["artifact"]["path"],
        media_type="application/zip",
        filename=Path(record["artifact"]["path"]).name,
    )
