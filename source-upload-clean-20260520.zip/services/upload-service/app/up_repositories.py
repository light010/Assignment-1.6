"""Upload-service repositories — Phase 4 D4.

Each collection that upload-service owns has its own repository class
exposing the primitives the routes (D4.5 cutover) and the migration
script (D4.3) need. Wire-shape envelopes are produced by
`to_envelope()` on the ORM model — preserving the contract while the
storage backend changes under the hood.

Idempotency rule (applies to every `upsert` method): the natural key
(document_id, upload_id, job_id, artifact_id, export_id) is the dedup
key. A second call with the same natural key updates the row in place
rather than inserting a duplicate. Required for the migration script
(D4.3) to be safely re-runnable.

Design notes:

  - Short-lived session per method (mirrors D3.2 / D2 patterns). No
    long-lived sessions; upload-service is stateless HTTP.
  - Returns are envelope dicts, never ORM objects.
  - Tenant/visibility filtering stays at the ROUTE layer (it depends
    on `current_user`, an HTTP concept). Repos are tenant-agnostic.
  - **JSON-dict mutation pattern**: methods that need to mutate a
    JSON column field (e.g. `latest_artifacts`) RE-ASSIGN the column
    rather than mutating the dict in place. SQLAlchemy does not
    track in-place mutations of JSON columns; re-assignment is the
    documented pattern.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from sqlalchemy import select, update
from up_db import (
    ArtifactRegistryEntry,
    Document,
    Export,
    Job,
    UploadSession,
    session_scope,
)


class DocumentRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        """Insert or update a document by `document_id`. Idempotent."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == envelope["document_id"])
            )
            if row is None:
                row = Document(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, document_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == document_id)
            )
            return row.to_envelope() if row else None

    def list_for_project(self, project_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(Document)
                .where(Document.project_id == project_id)
                .order_by(Document.created_at.desc())
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_business_unit(self, business_unit_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(Document)
                .where(Document.business_unit_id == business_unit_id)
                .order_by(Document.created_at.desc())
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_tenant(self, tenant_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(Document)
                .where(Document.tenant_id == tenant_id)
                .order_by(Document.created_at.desc())
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def set_latest_artifact(
        self, document_id: str, name: str, artifact_id: str
    ) -> dict[str, Any] | None:
        """Update `document.latest_artifacts[name] = artifact_id`.

        Called from `register_artifact` (`ditagen_common.artifacts`) to
        maintain the cross-collection denorm between artifact_registry
        and documents. Re-assigns the JSON column (SQLAlchemy doesn't
        track in-place dict mutations on JSON columns)."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == document_id)
            )
            if row is None:
                return None
            current = dict(row.latest_artifacts or {})
            current[name] = artifact_id
            row.latest_artifacts = current  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()

    def delete(self, document_id: str) -> bool:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == document_id)
            )
            if row is None:
                return False
            session.delete(row)
            return True

    def mark_topic_plan_approved(self, document_id: str) -> dict[str, Any] | None:
        """Flip `document.topic_plan_approved = True` atomically.

        Idempotent + skip-on-missing — returns None if the document does
        not exist, matching the JsonStore-era
        `if document_id in state["documents"]` guard used by the
        project-wide approve route. Mirrors the D4.5.a `mark_terminal`
        style: single-statement domain method, atomic at the SQL txn
        level, rather than a read-modify-write that would race against
        concurrent overrides."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == document_id)
            )
            if row is None:
                return None
            row.topic_plan_approved = True  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()

    def mark_topic_plan_approved_for(self, document_ids: list[str]) -> int:
        """Flip `topic_plan_approved=True` on every existing document in
        the list — single SQL statement, atomic.

        Replaces the project-wide approve loop that previously ran inside
        a JsonStore mutate callback (all-or-nothing via the single-file
        commit). With per-document upserts a mid-loop process kill would
        leave the project half-approved; `UPDATE … WHERE id IN (…)` is
        the SQL equivalent of the JsonStore all-or-nothing semantics.

        Returns the count of rows actually flipped. Missing ids are
        silently skipped (matches the `if document_id in state["documents"]`
        guard in the JsonStore-era callback)."""
        if not document_ids:
            return 0
        with session_scope(self._database_url) as session:
            result = session.execute(
                update(Document)
                .where(Document.document_id.in_(document_ids))
                .values(topic_plan_approved=True)
            )
            # SQLAlchemy 2.0 types `session.execute(update())` as the
            # generic `Result[Any]`; the runtime object is a
            # `CursorResult` which carries `rowcount`. Same kind of
            # stub-vs-runtime mismatch finding #76 documented for JSON
            # column assignments.
            return int(result.rowcount or 0)  # type: ignore[attr-defined]

    def with_atomic_update(
        self,
        document_id: str,
        mutator: Callable[[dict[str, Any]], None],
    ) -> dict[str, Any] | None:
        """Apply mutator to the document envelope in a single SQL txn.

        Preserves the JsonStore mutate-callback atomicity for the
        multi-field structural updates (override-gate, reextract) where
        adding a specific domain method per field would proliferate the
        repo surface (finding #59). The mutator receives the current
        envelope dict and mutates it in place; the method writes the
        post-mutation envelope back to the row in the same session.

        Returns None if the document does not exist; returns the
        post-mutation envelope otherwise."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Document).where(Document.document_id == document_id)
            )
            if row is None:
                return None
            envelope = row.to_envelope()
            mutator(envelope)
            for field, value in envelope.items():
                setattr(row, field, value)
            session.flush()
            return row.to_envelope()


class UploadSessionRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(UploadSession).where(
                    UploadSession.upload_id == envelope["upload_id"]
                )
            )
            if row is None:
                row = UploadSession(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, upload_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(UploadSession).where(UploadSession.upload_id == upload_id)
            )
            return row.to_envelope() if row else None

    def append_part(
        self,
        upload_id: str,
        *,
        filename: str,
        part_number: int,
        data_base64: str,
        size_bytes: int,
        received_at: str,
    ) -> dict[str, Any] | None:
        """Atomic read-modify-write to append/replace one part on a session.

        Replaces any existing part with the same `part_number`, keeps the
        parts list sorted, recomputes `received_bytes`, sets `status` to
        `"receiving"`, and refreshes `filename` (multipart callers can
        change the filename across parts).

        Single-session_scope semantics preserve the JsonStore-mutate
        atomicity guarantee for this collection. Re-assigns the JSON
        column (SQLAlchemy doesn't track in-place mutations of JSON)."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(UploadSession).where(UploadSession.upload_id == upload_id)
            )
            if row is None:
                return None
            current_parts = list(row.parts or [])
            existing = [
                part
                for part in current_parts
                if part["part_number"] != part_number
            ]
            existing.append(
                {
                    "part_number": part_number,
                    "data_base64": data_base64,
                    "size_bytes": size_bytes,
                    "received_at": received_at,
                }
            )
            existing.sort(key=lambda item: item["part_number"])
            row.filename = filename  # type: ignore[assignment]
            row.status = "receiving"  # type: ignore[assignment]
            row.parts = existing  # type: ignore[assignment]
            row.received_bytes = sum(part["size_bytes"] for part in existing)
            session.flush()
            return row.to_envelope()

    def mark_terminal(
        self,
        upload_id: str,
        *,
        status: str,
        document_id: str | None,
        completed_at: str,
    ) -> dict[str, Any] | None:
        """Flip an upload session to a terminal status.

        Idempotent + skip-on-missing: returns None if the upload_id
        doesn't exist, mirroring the JsonStore-era
        `if upload_id and upload_id in state["upload_sessions"]` guard.
        Called from the three `process_upload` paths (save/save_failed/
        save_blocked) after the documents+jobs JsonStore commit lands —
        see D4.5.a for the operation-ordering rationale."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(UploadSession).where(UploadSession.upload_id == upload_id)
            )
            if row is None:
                return None
            row.status = status  # type: ignore[assignment]
            if document_id is not None:
                row.document_id = document_id  # type: ignore[assignment]
            row.completed_at = completed_at  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()


class JobRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Job).where(Job.job_id == envelope["job_id"])
            )
            if row is None:
                row = Job(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, job_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(select(Job).where(Job.job_id == job_id))
            return row.to_envelope() if row else None

    def list_for_document(self, document_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(Job)
                .where(Job.document_id == document_id)
                .order_by(Job.seq)
            )
            return [row.to_envelope() for row in session.scalars(stmt)]


class ArtifactRegistryRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        """Insert or update an artifact-registry entry by `artifact_id`.

        Accepts the JsonStore wire shape which duplicates `id` =
        `artifact_id`. The duplicate `id` field is dropped on write
        because it's not a column on the typed model — `to_envelope`
        reconstructs it from the canonical artifact_id at read time."""
        payload = {k: v for k, v in envelope.items() if k != "id"}
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(ArtifactRegistryEntry).where(
                    ArtifactRegistryEntry.artifact_id == payload["artifact_id"]
                )
            )
            if row is None:
                row = ArtifactRegistryEntry(**payload)
                session.add(row)
            else:
                for field, value in payload.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, artifact_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(ArtifactRegistryEntry).where(
                    ArtifactRegistryEntry.artifact_id == artifact_id
                )
            )
            return row.to_envelope() if row else None

    def list_for_document(self, document_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(ArtifactRegistryEntry)
                .where(ArtifactRegistryEntry.document_id == document_id)
                .order_by(ArtifactRegistryEntry.seq)
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_project(self, project_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = (
                select(ArtifactRegistryEntry)
                .where(ArtifactRegistryEntry.project_id == project_id)
                .order_by(ArtifactRegistryEntry.seq)
            )
            return [row.to_envelope() for row in session.scalars(stmt)]


class ExportRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Export).where(Export.export_id == envelope["export_id"])
            )
            if row is None:
                row = Export(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, export_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Export).where(Export.export_id == export_id)
            )
            return row.to_envelope() if row else None
