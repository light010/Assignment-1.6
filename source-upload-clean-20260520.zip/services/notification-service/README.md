# notification-service

**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation).

ADR-004 designs this service as the user notification fanout —
delivers in-app, email, and webhook notifications subscribed to
events from `audit-service`'s event bus. Today the `/v1/notifications`
routes in `api-gateway` return empty lists; nothing is actually fanned
out.

## What this service will own

- `GET /internal/notifications` — user inbox.
- `POST /internal/notifications/{id}/read` — mark as read.
- `GET /internal/notification-preferences` — per-user delivery prefs.
- Event-bus subscriber that filters audit events to per-user inboxes
  per `notification_preferences.granularity` (stage / topic / project).
- Email + webhook adapters.

## Why deferred

Notification fanout is a polish feature. The alpha's audit_events list
in JsonStore is already the event log; this service is a read-side
projection that the frontend will eventually consume. The skeleton
stays so other services can `emit_audit_event` (Phase 4+) without
needing to know whether anyone is listening.
