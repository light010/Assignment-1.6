"""Alembic environment for the audit-service relational schema.

Phase 4 D2 — per-service Alembic per ADR-016. The global
`infrastructure/postgres/alembic` still manages the JsonStore
compatibility tables for un-migrated services; audit-service has
graduated to its own typed schema and owns this Alembic instance
end-to-end."""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

# Make `db` importable when alembic runs from the repo root. Matches
# the top-level-module convention service main.py files use (no
# implicit packages — see services/extraction-service/app/main.py).
REPO_ROOT = Path(__file__).resolve().parents[3]
SERVICE_APP_DIR = REPO_ROOT / "services" / "audit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))

from db import Base, database_url  # noqa: E402

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def _url() -> str:
    return os.getenv("DITAGEN_AUDIT_DATABASE_URL") or database_url()


def run_migrations_offline() -> None:
    context.configure(
        url=_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    section = config.get_section(config.config_ini_section, {})
    section["sqlalchemy.url"] = _url()
    connectable = engine_from_config(
        section,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
