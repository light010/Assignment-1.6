"""audit_events typed schema (Phase 4 D2)

Revision ID: 0001_audit_events_typed
Revises:
Create Date: 2026-05-11

Replaces the JsonStore `audit_events` list and the Phase 1 S6 JSONL
bridge with a typed table owned by audit-service. See
plans/architecture-hardening.md §D2 and adr/016-service-owned-data-contracts.md.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001_audit_events_typed"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "audit_events",
        sa.Column(
            "seq",
            sa.BigInteger().with_variant(sa.Integer(), "sqlite"),
            primary_key=True,
            autoincrement=True,
            nullable=False,
        ),
        sa.Column("event_id", sa.Text(), nullable=False, unique=True),
        sa.Column("occurred_at", sa.DateTime(timezone=False), nullable=False),
        sa.Column("actor_id", sa.Text(), nullable=False),
        sa.Column("action", sa.Text(), nullable=False),
        sa.Column("resource_type", sa.Text(), nullable=False),
        sa.Column("resource_id", sa.Text(), nullable=False),
        sa.Column("business_unit_id", sa.Text(), nullable=True),
        sa.Column("project_id", sa.Text(), nullable=True),
        sa.Column("metadata", sa.JSON(), nullable=False),
    )
    op.create_index("ix_audit_events_seq", "audit_events", ["seq"])
    op.create_index(
        "ix_audit_events_business_unit_id", "audit_events", ["business_unit_id"]
    )
    op.create_index("ix_audit_events_project_id", "audit_events", ["project_id"])
    op.create_index("ix_audit_events_occurred_at", "audit_events", ["occurred_at"])


def downgrade() -> None:
    op.drop_index("ix_audit_events_occurred_at", table_name="audit_events")
    op.drop_index("ix_audit_events_project_id", table_name="audit_events")
    op.drop_index("ix_audit_events_business_unit_id", table_name="audit_events")
    op.drop_index("ix_audit_events_seq", table_name="audit_events")
    op.drop_table("audit_events")
