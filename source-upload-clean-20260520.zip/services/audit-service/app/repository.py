"""Audit-event repository — the only typed entry point to the audit DB.

Phase 4 D2 contract:

  - `append_event(...)` returns the persisted envelope (the JSON shape
    consumers see on the wire). Idempotent on `event_id`: a second
    append with the same event_id is a no-op and returns the existing
    envelope. This is required for D2.4's migration script and for any
    upstream retry that lands twice.
  - `list_events(*, business_unit_id=None, project_id=None)` returns
    every event filtered server-side. Used by the legacy `GET
    /internal/audit-events` route.
  - `walk_since_seq(*, seq, limit)` returns the cursor-paginated window
    `WHERE seq > :seq ORDER BY seq LIMIT :limit`. This is the
    load-bearing query — `tests/test_event_replay.py` pins the
    no-duplicates / no-gaps invariant on top.
  - `resolve_seq_for_event_id(event_id)` returns the seq for an
    event_id, or `None` if unknown. The replay endpoint maps an
    event_id cursor to a seq cursor before walking. Unknown event_id
    cursors return None (the route surfaces this as "caller is caught
    up" — see D1's bugfix in audit-service main.py).

Design notes:

  - The repository takes a *factory* of sessions, not a session. Each
    method opens its own short-lived session via `session_scope`. The
    audit-service is a stateless web service — long-lived sessions
    would pin connections and confuse error recovery.
  - All filtering is in the database, not Python. The previous JSONL
    pattern read everything then filtered in-process, which would have
    eventually run out of memory in production. SQL filter pushdown
    fixes the underlying memory profile, not just the API."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from db import AuditEvent, session_scope
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError


def _parse_iso_z(value: str | None) -> datetime:
    """Parse an ISO-Z timestamp into a naive UTC datetime.

    The persisted column is timezone-naive (UTC by convention) because
    SQLite stores timestamps as text and the timezone bit is unreliable
    across SQLAlchemy + SQLite + Postgres roundtrips. Storing naive UTC
    and rendering with a Z suffix on read keeps the wire contract
    stable."""
    if not value:
        return datetime.now(UTC).replace(tzinfo=None)
    text = value.replace("Z", "+00:00") if value.endswith("Z") else value
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return datetime.now(UTC).replace(tzinfo=None)
    if dt.tzinfo is not None:
        dt = dt.astimezone(UTC).replace(tzinfo=None)
    return dt


class AuditEventRepository:
    """SQL-backed implementation of the audit-event contract."""

    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def append_event(
        self,
        *,
        event_id: str,
        actor_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        business_unit_id: str | None,
        project_id: str | None,
        metadata: dict[str, Any] | None,
        occurred_at: str | None,
    ) -> dict[str, Any]:
        """Insert a new event; return its on-the-wire envelope.

        Idempotent: if `event_id` is already persisted, returns the
        existing envelope without inserting. This is the property the
        migration script (D2.4) relies on."""
        with session_scope(self._database_url) as session:
            existing = session.scalar(
                select(AuditEvent).where(AuditEvent.event_id == event_id)
            )
            if existing is not None:
                return existing.to_envelope()
            row = AuditEvent(
                event_id=event_id,
                occurred_at=_parse_iso_z(occurred_at),
                actor_id=actor_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                business_unit_id=business_unit_id,
                project_id=project_id,
                event_metadata=metadata or {},
            )
            session.add(row)
            try:
                session.flush()
            except IntegrityError:
                # Concurrent writer raced us on the same event_id.
                # Re-read the persisted row; idempotency holds.
                session.rollback()
                with session_scope(self._database_url) as retry:
                    persisted = retry.scalar(
                        select(AuditEvent).where(AuditEvent.event_id == event_id)
                    )
                    if persisted is None:
                        raise
                    return persisted.to_envelope()
            return row.to_envelope()

    def list_events(
        self,
        *,
        business_unit_id: str | None = None,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Every event matching the optional filters, in seq order."""
        with session_scope(self._database_url) as session:
            stmt = select(AuditEvent).order_by(AuditEvent.seq)
            if business_unit_id is not None:
                stmt = stmt.where(AuditEvent.business_unit_id == business_unit_id)
            if project_id is not None:
                stmt = stmt.where(AuditEvent.project_id == project_id)
            return [row.to_envelope() for row in session.scalars(stmt)]

    def walk_since_seq(
        self,
        *,
        seq: int,
        limit: int,
        business_unit_id: str | None = None,
        project_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Return the cursor window `WHERE seq > :seq` and the seq of
        the last row returned (or `:seq` if the window is empty).

        The returned cursor is monotonic: the second element is `>= seq`
        always, so a consumer that uses it as their next cursor never
        regresses — the D1 invariant locked in
        `tests/test_event_replay.py` is preserved structurally."""
        with session_scope(self._database_url) as session:
            stmt = (
                select(AuditEvent)
                .where(AuditEvent.seq > seq)
                .order_by(AuditEvent.seq)
                .limit(limit)
            )
            if business_unit_id is not None:
                stmt = stmt.where(AuditEvent.business_unit_id == business_unit_id)
            if project_id is not None:
                stmt = stmt.where(AuditEvent.project_id == project_id)
            rows = list(session.scalars(stmt))
            # Cast through int() — at instance level row.seq is int, but
            # the class-attribute is typed as Column[int] for query
            # construction. mypy can't bridge the two without help.
            if rows:
                next_seq = max(int(row.seq) for row in rows)
            else:
                next_seq = seq
            return [row.to_envelope() for row in rows], next_seq

    def resolve_seq_for_event_id(self, event_id: str) -> int | None:
        """Return the seq for an event_id, or None if it isn't in the
        DB. The route uses None to mean 'caller's cursor is unknown —
        treat as caught up' (see audit-service main.py for the rationale
        and the D1 bug it prevents)."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(AuditEvent).where(AuditEvent.event_id == event_id)
            )
            return int(row.seq) if row is not None else None

    def max_seq(self) -> int:
        """Return the largest seq in the table, or 0 if empty.

        The replay endpoint uses this to clamp past-end integer cursors
        — keeping `next_cursor >= requested_cursor` (the other D1
        invariant)."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(AuditEvent.seq).order_by(AuditEvent.seq.desc()).limit(1)
            )
            return int(row) if row is not None else 0
