"""audit-service entrypoint.

Phase 4 D2 architecture (post-D2.7, fully migrated):

  - audit_events live in a service-owned SQL table (see `db.py`,
    `repository.py`, and the per-service Alembic under
    `services/audit-service/alembic/`).
  - audit-service NO LONGER reads `JsonStore` — tenant-isolation
    lookups (BU/project) go to business-unit-service via `request_service`.
    The `test_jsonstore_key_ownership.py` lock pins the
    no-state-key-access invariant at `frozenset()` for this service.
  - The Phase 1 S6 JSONL bridge has been retired; SQL is the only
    write target (D2.7).

The replay endpoint contract (D1, locked by `tests/test_event_replay.py`):

  - cursor "0" returns all events from the start
  - cursor "N" returns events where seq > N
  - cursor "<event_id>" resolves to that event's seq, then walks seq >
  - unknown event_id → caller is caught up; preserve cursor (no rewalk)
  - no-duplicates, no-gaps, no-regression on past-end cursors
"""

from __future__ import annotations

import os
from typing import Any

from ditagen_common.auth import context_headers, current_user
from ditagen_common.ids import new_id
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import request_service
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from repository import AuditEventRepository

app = create_service_app("audit-service")
audit_repository = AuditEventRepository()

# Cursor walk window. Plan §D2 calls for LIMIT 100. The D1 invariants
# don't depend on the specific window, but the same number keeps the
# test suite's safety bound (1000-hop loop) comfortable.
_REPLAY_WINDOW = 100


def _business_unit_service_url() -> str:
    """Return the business-unit-service base URL.

    Fails loud if the env var is missing — audit-service can't enforce
    tenant isolation without it. Per the CLAUDE.md "missing required
    input → STOP" rule."""
    url = os.getenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL")
    if not url:
        raise RuntimeError(
            "DITAGEN_BUSINESS_UNIT_SERVICE_URL must be set — audit-service "
            "needs it to verify BU/project visibility for tenant "
            "isolation. See ADR-016."
        )
    return url


class AuditEventCreate(BaseModel):
    actor_id: str | None = None
    action: str = Field(min_length=1)
    resource_type: str = Field(min_length=1)
    resource_id: str = Field(min_length=1)
    business_unit_id: str | None = None
    project_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


async def _can_see_business_unit(
    bu_id: str,
    *,
    request: Request,
    user: dict[str, Any],
    cache: dict[str, bool],
) -> bool:
    """Return True iff `user` can see business_unit `bu_id`.

    Resolved by asking business-unit-service — its `require_business_unit`
    gate is the canonical authorization check. We treat HTTP 200 as
    visible and any 4xx as invisible. 5xx propagates as an HTTPException
    so we never silently classify a business-unit-service outage as a tenant
    boundary violation."""
    if bu_id in cache:
        return cache[bu_id]
    response = await request_service(
        method="GET",
        base_url=_business_unit_service_url(),
        path=f"/internal/business-units/{bu_id}",
        headers=context_headers(request, user),
    )
    if response.status_code == 200:
        cache[bu_id] = True
        return True
    if 400 <= response.status_code < 500:
        cache[bu_id] = False
        return False
    raise HTTPException(
        status_code=502,
        detail=f"business-unit-service returned {response.status_code} resolving business_unit",
    )


async def _can_see_project(
    project_id: str,
    *,
    request: Request,
    user: dict[str, Any],
    cache: dict[str, bool],
) -> bool:
    """Return True iff `user` can see project `project_id`."""
    if project_id in cache:
        return cache[project_id]
    response = await request_service(
        method="GET",
        base_url=_business_unit_service_url(),
        path=f"/internal/projects/{project_id}",
        headers=context_headers(request, user),
    )
    if response.status_code == 200:
        cache[project_id] = True
        return True
    if 400 <= response.status_code < 500:
        cache[project_id] = False
        return False
    raise HTTPException(
        status_code=502,
        detail=f"business-unit-service returned {response.status_code} resolving project",
    )


async def _filter_visible(
    events: list[dict[str, Any]],
    *,
    request: Request,
    user: dict[str, Any],
) -> list[dict[str, Any]]:
    """Drop events whose BU/project the user cannot see.

    Memoizes BU/project visibility within a single call — the typical
    100-event window touches at most a handful of distinct ids, so the
    cache keeps round trips small."""
    bu_cache: dict[str, bool] = {}
    project_cache: dict[str, bool] = {}
    visible: list[dict[str, Any]] = []
    for event in events:
        bu_id = event.get("business_unit_id")
        if bu_id:
            if not await _can_see_business_unit(
                bu_id, request=request, user=user, cache=bu_cache
            ):
                continue
        elif event.get("project_id"):
            if not await _can_see_project(
                event["project_id"], request=request, user=user, cache=project_cache
            ):
                continue
        visible.append(event)
    return visible


async def _gate_query_filter(
    *,
    business_unit_id: str | None,
    project_id: str | None,
    request: Request,
    user: dict[str, Any],
) -> None:
    """If a query filter is supplied, verify the user can see it.

    The previous implementation called `require_business_unit(state, ...)`
    which raised 403 directly. The equivalent post-D2.6 is: ask
    business-unit-service for the same resource; propagate its 4xx so the
    caller still sees a clear error instead of a silent empty
    response."""
    if business_unit_id:
        response = await request_service(
            method="GET",
            base_url=_business_unit_service_url(),
            path=f"/internal/business-units/{business_unit_id}",
            headers=context_headers(request, user),
        )
        if response.status_code >= 400:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.json().get("detail", "business_unit not visible"),
            )
    if project_id:
        response = await request_service(
            method="GET",
            base_url=_business_unit_service_url(),
            path=f"/internal/projects/{project_id}",
            headers=context_headers(request, user),
        )
        if response.status_code >= 400:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.json().get("detail", "project not visible"),
            )


@app.post("/internal/audit-events")
def create_audit_event(
    request: AuditEventCreate,
    http_request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    metadata = dict(request.metadata)
    if http_request.headers.get("x-request-id"):
        metadata["request_id"] = http_request.headers["x-request-id"]
    if http_request.headers.get("x-actor-id"):
        metadata["context_actor_id"] = http_request.headers["x-actor-id"]
    # Phase 4 D2.7c — SQL is the single source of truth. The Phase 1 S6
    # JSONL bridge has been retired now that audit-service owns its
    # database and the only readers (audit-service GET endpoints,
    # review-service `_document_op_chain_for_request`) go through SQL.
    return audit_repository.append_event(
        event_id=new_id("aud"),
        actor_id=request.actor_id or user["user_id"],
        action=request.action,
        resource_type=request.resource_type,
        resource_id=request.resource_id,
        business_unit_id=request.business_unit_id,
        project_id=request.project_id,
        metadata=metadata,
        occurred_at=None,
    )


@app.get("/internal/audit-events")
async def list_audit_events(
    http_request: Request,
    business_unit_id: str | None = None,
    project_id: str | None = None,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await _gate_query_filter(
        business_unit_id=business_unit_id,
        project_id=project_id,
        request=http_request,
        user=user,
    )
    repo_events = audit_repository.list_events(
        business_unit_id=business_unit_id,
        project_id=project_id,
    )
    visible = await _filter_visible(repo_events, request=http_request, user=user)
    return {"events": visible}


@app.get("/internal/events/since/{cursor}")
async def replay_audit_events(
    cursor: str,
    http_request: Request,
    business_unit_id: str | None = None,
    project_id: str | None = None,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Cursor-paginated event replay backed by SQL."""
    await _gate_query_filter(
        business_unit_id=business_unit_id,
        project_id=project_id,
        request=http_request,
        user=user,
    )

    if cursor.isdigit():
        requested_int: int | None = int(cursor)
        seq_cursor: int = requested_int
    else:
        resolved = audit_repository.resolve_seq_for_event_id(cursor)
        if resolved is None:
            return {
                "events": [],
                "cursor": cursor,
                "next_cursor": cursor,
                "event_count": 0,
            }
        seq_cursor = resolved
        requested_int = None

    raw_events, next_seq = audit_repository.walk_since_seq(
        seq=seq_cursor,
        limit=_REPLAY_WINDOW,
        business_unit_id=business_unit_id,
        project_id=project_id,
    )
    visible = await _filter_visible(raw_events, request=http_request, user=user)

    if requested_int is not None and next_seq < requested_int:
        next_cursor_value = str(requested_int)
    else:
        next_cursor_value = str(next_seq)

    return {
        "events": visible,
        "cursor": cursor,
        "next_cursor": next_cursor_value,
        "event_count": len(visible),
    }
