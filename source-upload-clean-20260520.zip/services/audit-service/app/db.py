"""SQLAlchemy engine + AuditEvent model owned by audit-service.

Phase 4 D2 of `plans/architecture-hardening.md` graduates audit-service
from the JSONL bridge (Phase 1 S6) to a service-owned relational store.
ADR-016 mandates per-service ownership; this module is the audit-service
half of that contract.

Key design choices:

  - **Per-service DB URL** (`DITAGEN_AUDIT_DATABASE_URL`), not the shared
    `DITAGEN_DATABASE_URL` used by the `SqlStateStore` compatibility
    wrapper. Mixing them would violate the ownership invariant — one
    service, one database (logically). For SQLite hermetic tests, each
    service's URL points at its own file.
  - **`seq BIGINT` autoincrement** as the cursor primitive. Event IDs
    are `aud_<millis_hex>_<rand>` which sort lexicographically *within*
    a single writer process, but multiple audit-service processes can
    emit same-millis events whose random suffixes break lexicographic
    monotonicity. `seq` is a per-DB autoincrement — robust to any
    writer concurrency the DB itself serializes through INSERT.
  - **`event_id` UNIQUE** so the migration script (D2.4) can replay
    JSONL/state.json events with ON CONFLICT semantics without
    duplicating.
  - **`metadata` is JSON text on SQLite**, JSONB on PostgreSQL. The
    `JSON` type variant from SQLAlchemy handles both.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Column,
    DateTime,
    Index,
    Integer,
    MetaData,
    Text,
    create_engine,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

_METADATA = MetaData()


class Base(DeclarativeBase):
    """SQLAlchemy 2.0 declarative base for audit-service tables."""

    metadata = _METADATA


class AuditEvent(Base):
    """Append-only audit-event row.

    `seq` is the cursor primitive (autoincrement). `event_id` is the
    consumer-facing identifier (stable across migrations) and is unique.
    """

    __tablename__ = "audit_events"

    # BigInteger PK gives PostgreSQL BIGSERIAL semantics. SQLite only
    # rowid-aliases an `INTEGER PRIMARY KEY`, so without the variant the
    # column needs an explicit value on insert — silently breaks autoincr.
    seq = Column(
        BigInteger().with_variant(Integer, "sqlite"),
        primary_key=True,
        autoincrement=True,
    )
    event_id = Column(Text, nullable=False, unique=True)
    occurred_at = Column(DateTime(timezone=False), nullable=False)
    actor_id = Column(Text, nullable=False)
    action = Column(Text, nullable=False)
    resource_type = Column(Text, nullable=False)
    resource_id = Column(Text, nullable=False)
    business_unit_id = Column(Text, nullable=True)
    project_id = Column(Text, nullable=True)
    event_metadata = Column("metadata", JSON, nullable=False, default=dict)

    __table_args__ = (
        Index("ix_audit_events_seq", "seq"),
        Index("ix_audit_events_business_unit_id", "business_unit_id"),
        Index("ix_audit_events_project_id", "project_id"),
        Index("ix_audit_events_occurred_at", "occurred_at"),
    )

    def to_envelope(self) -> dict[str, Any]:
        """Serialize to the JSON shape consumers expect on the wire.

        This is the contract pinned by `tests/test_event_replay.py` and
        `tests/test_audit_service.py`: occurred_at as ISO-Z, metadata as
        a dict (never null), and the same field names the JSONL bridge
        used. The `seq` column is internal and not exposed."""
        occurred_at = self.occurred_at
        return {
            "event_id": self.event_id,
            "actor_id": self.actor_id,
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "business_unit_id": self.business_unit_id,
            "project_id": self.project_id,
            "metadata": self.event_metadata or {},
            "occurred_at": _isoformat_z(occurred_at),
        }


def _isoformat_z(value: Any) -> str:
    """Render datetime as ISO-8601 with a trailing 'Z' (UTC).

    The JSONL bridge stored timestamps as strings already in this shape;
    preserving it keeps the wire contract byte-identical."""
    if value is None:
        return ""
    if hasattr(value, "isoformat"):
        text = value.isoformat()
        if text.endswith("+00:00"):
            text = text[:-6] + "Z"
        elif "+" not in text and not text.endswith("Z"):
            text = text + "Z"
        return text
    return str(value)


def database_url() -> str:
    """Resolve the audit-service DB URL.

    Default is a local SQLite file under DITAGEN_DATA_DIR. Production
    overrides via DITAGEN_AUDIT_DATABASE_URL. The fallback is hermetic
    for tests (file path is per-DATA_DIR) and explicit for ops."""
    url = os.getenv("DITAGEN_AUDIT_DATABASE_URL")
    if url:
        return url
    data_dir = os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")
    return f"sqlite:///{data_dir}/audit-service.sqlite3"


_ENGINE_CACHE: dict[str, Engine] = {}
_SESSION_FACTORY_CACHE: dict[str, sessionmaker[Session]] = {}


def get_engine(url: str | None = None) -> Engine:
    """Return (and cache) a SQLAlchemy Engine for the audit-service DB.

    Caches by URL string so the test suite — which spawns one
    `AuditEvent` schema per `DITAGEN_DATA_DIR` (per-test tmp_path) —
    doesn't leak connections across tests. The cache key IS the URL,
    not "service name", because each test gets a fresh URL."""
    target = url or database_url()
    if target not in _ENGINE_CACHE:
        connect_args: dict[str, Any] = {}
        if target.startswith("sqlite"):
            # Without check_same_thread=False, FastAPI's threadpool
            # routes (sync def handlers) raise on cross-thread reuse of
            # the connection — the same hazard pip-installed SQLite has
            # always had. We hold no long-lived connection state in a
            # session beyond a single request, so this is safe.
            connect_args["check_same_thread"] = False
            from pathlib import Path
            from urllib.parse import urlparse

            db_path = Path(urlparse(target).path.lstrip("/")).resolve()
            db_path.parent.mkdir(parents=True, exist_ok=True)
        engine = create_engine(target, future=True, connect_args=connect_args)
        Base.metadata.create_all(engine)
        _ENGINE_CACHE[target] = engine
        _SESSION_FACTORY_CACHE[target] = sessionmaker(
            bind=engine, expire_on_commit=False, future=True
        )
    return _ENGINE_CACHE[target]


@contextmanager
def session_scope(url: str | None = None) -> Iterator[Session]:
    """Open a SQLAlchemy session, commit on success, rollback on raise.

    Callers MUST NOT pass the session beyond the `with` block — the
    connection returns to the pool on exit."""
    target = url or database_url()
    get_engine(target)
    factory = _SESSION_FACTORY_CACHE[target]
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def reset_engine_cache() -> None:
    """Drop the engine + session-factory caches.

    Tests that switch `DITAGEN_AUDIT_DATABASE_URL` between phases of the
    same process need this to avoid talking to a stale engine. Calling
    it from production code is a bug."""
    for engine in _ENGINE_CACHE.values():
        engine.dispose()
    _ENGINE_CACHE.clear()
    _SESSION_FACTORY_CACHE.clear()
