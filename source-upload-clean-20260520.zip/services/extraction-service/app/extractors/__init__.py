from __future__ import annotations

from pathlib import Path

from .common import (
    _HEADING_TERMINAL_PUNCTUATION,
    EXTRACTOR_VERSION,
    ExtractedAsset,
    ExtractionOutput,
)
from .docx import _extract_docx
from .docx_helpers import _docx_is_formatting_heading
from .heading_classifier import _compute_review_signals
from .pdf import _extract_pdf
from .textual import _extract_textual, _html_to_text, _looks_like_heading


def extract_document(*, document_id: str, filename: str, content_type: str, data: bytes) -> ExtractionOutput:
    suffix = Path(filename).suffix.lower()
    if suffix == ".docx":
        return _extract_docx(document_id=document_id, filename=filename, data=data)
    if suffix == ".pdf":
        return _extract_pdf(document_id=document_id, filename=filename, data=data)
    if suffix in {".html", ".htm"}:
        return _extract_textual(
            document_id=document_id,
            filename=filename,
            data=_html_to_text(data).encode("utf-8"),
            source_kind="html",
        )
    return _extract_textual(document_id=document_id, filename=filename, data=data, source_kind="text")


__all__ = [
    "EXTRACTOR_VERSION",
    "ExtractedAsset",
    "ExtractionOutput",
    "_HEADING_TERMINAL_PUNCTUATION",
    "_compute_review_signals",
    "_docx_is_formatting_heading",
    "_looks_like_heading",
    "extract_document",
]
