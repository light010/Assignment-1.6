from __future__ import annotations

import re
from typing import Any

from ditagen_common.models import ReviewFlagCode, review_flag_payload

_BLOCK_TYPE_REVIEW_THRESHOLD = 0.7

def _make_review_flag(
    code: ReviewFlagCode,
    *,
    message: str | None = None,
    extra_context: str | None = None,
) -> dict[str, str]:
    return review_flag_payload(code, message=message, extra_context=extra_context)


def _compute_review_signals(blocks: list[dict[str, Any]]) -> None:
    if not blocks:
        return

    nonzero_sizes: list[float] = []
    for block in blocks:
        size = ((block.get("style_summary") or {}).get("dominant_font_size_pt")) or 0.0
        if size > 0:
            nonzero_sizes.append(float(size))
    mean_size = sum(nonzero_sizes) / len(nonzero_sizes) if nonzero_sizes else 0.0
    if len(nonzero_sizes) >= 2:
        variance = sum((s - mean_size) ** 2 for s in nonzero_sizes) / len(nonzero_sizes)
        stdev = variance**0.5
    else:
        stdev = 0.0

    style_roles: dict[str, set[str]] = {}
    for block in blocks:
        style_name = ((block.get("style_summary") or {}).get("source_style_name") or "").strip()
        if style_name:
            style_roles.setdefault(style_name, set()).add(block["block_type"])

    rows_by_table: dict[str, set[int]] = {}
    for block in blocks:
        if block["block_type"] == "table_row":
            tid = block.get("table_id")
            ridx = block.get("row_index")
            if tid and isinstance(ridx, int):
                rows_by_table.setdefault(tid, set()).add(ridx)

    for block in blocks:
        block_type = block["block_type"]
        text = block.get("text") or ""
        style_name = ((block.get("style_summary") or {}).get("source_style_name") or "").strip()
        font_size = float((block.get("style_summary") or {}).get("dominant_font_size_pt") or 0.0)

        bt_conf = _block_type_posterior(
            block_type=block_type,
            style_name=style_name,
            text=text,
            numbering=block.get("numbering"),
        )
        heading_conf = _heading_posterior(
            block_type=block_type,
            text=text,
            style_name=style_name,
            font_size=font_size,
            corpus_mean_size=mean_size,
            corpus_stdev=stdev,
        )
        ext_conf = _extraction_posterior(text)
        si_conf = _semantic_inline_posterior(block.get("inline_runs") or [])

        block["confidence"] = {
            "extraction": round(ext_conf, 3),
            "block_type": round(bt_conf, 3),
            "heading": round(heading_conf, 3) if heading_conf is not None else None,
            "semantic_inline": round(si_conf, 3),
        }

        signals = block.get("confidence_signals") or {}
        if not isinstance(signals, dict):
            signals = {}
        signals.update(
            {
                "style": style_name or None,
                "font_size": round(font_size, 2) if font_size else None,
                "font_size_zscore": round((font_size - mean_size) / stdev, 3)
                if stdev > 0 and font_size > 0
                else None,
                "corpus_mean_size_pt": round(mean_size, 2),
                "corpus_stdev_size_pt": round(stdev, 3),
                "text_len": len(text),
            }
        )
        block["confidence_signals"] = signals

        flags: list[dict[str, Any]] = [
            flag for flag in block.get("review_flags", []) if isinstance(flag, dict)
        ]
        if bt_conf < _BLOCK_TYPE_REVIEW_THRESHOLD:
            flags.append(
                _make_review_flag(
                    "LOW_BLOCK_TYPE_CONFIDENCE",
                    message=(
                        f"block_type={block_type!r} classifier confidence "
                        f"{bt_conf:.2f} < {_BLOCK_TYPE_REVIEW_THRESHOLD}"
                    ),
                )
            )
        if block_type == "table_row":
            tid = block.get("table_id")
            ridx = block.get("row_index")
            if tid and isinstance(ridx, int) and ridx > 1 and 1 not in rows_by_table.get(tid, set()):
                flags.append(
                    _make_review_flag(
                        "ORPHAN_TABLE_ROW",
                        message=(
                            f"table_row #{ridx} of {tid} has no row #1 sibling "
                            "(extraction may have lost the header row)"
                        ),
                    )
                )
        if block_type == "heading" and style_name:
            other_roles = style_roles.get(style_name, set()) - {"heading"}
            if other_roles:
                flags.append(
                    _make_review_flag(
                        "MIXED_HEADING_STYLE",
                        message=(
                            f"style {style_name!r} is used as heading and "
                            f"{sorted(other_roles)!r}"
                        ),
                    )
                )
        if block_type == "heading" and text and text.rstrip()[-1:] in {".", ",", ";", ":"}:
            flags.append(
                _make_review_flag(
                    "SUSPECTED_HEADING_FRAGMENT",
                    message=(
                        f"heading ends with sentence-terminal {text.rstrip()[-1]!r}; "
                        "may be a wrapped paragraph misclassified"
                    ),
                )
            )
        block["review_flags"] = flags
        block["is_likely_heading"] = block_type == "heading" and (heading_conf or 0.0) >= 0.6


def _extraction_posterior(text: str) -> float:
    score = 0.9
    if len(text) < 3:
        score -= 0.2
    if "�" in text:
        score -= 0.4
    if any(token in text for token in ("â€™", "â€œ", "â€\x9d", "Ã©", "Ã¨")):
        score -= 0.3
    return max(0.05, min(0.99, score))


def _block_type_posterior(
    *,
    block_type: str,
    style_name: str,
    text: str,
    numbering: dict[str, Any] | None,
) -> float:
    if block_type == "heading":
        if re.match(r"Heading\s+\d", style_name or "", flags=re.I):
            return 0.95
        words = text.split()
        if words:
            title_score = sum(1 for w in words if w[:1].isupper())
            short_titlecase = (
                1 <= len(words) <= 8
                and title_score >= max(1, len(words) // 2)
                and not text.rstrip().endswith((".", ","))
            )
            if short_titlecase:
                return 0.78
        return 0.55
    if block_type == "procedure_step":
        if numbering:
            return 0.9
        if re.match(
            r"^(click|select|press|open|choose|install|run|enter|verify)\b",
            text,
            flags=re.I,
        ):
            return 0.65
        return 0.55
    if block_type == "table_row":
        return 0.95
    if block_type == "warning":
        return 0.85 if re.search(r"\b(warning|caution)\b", text, flags=re.I) else 0.55
    if block_type == "note":
        return 0.85 if re.search(r"\b(note|tip)\b", text, flags=re.I) else 0.55
    # paragraph / unknown — discriminate by word-count and sentence shape so
    # short fragments ("N/A", "Status:") and long-but-unterminated lines
    # (e.g. "Apple CA SAP User Creation is completed by 5012") surface as
    # low-confidence rather than land at a flat 0.72 that never fires
    # LOW_BLOCK_TYPE_CONFIDENCE.
    words = text.split()
    if not words:
        return 0.4
    if len(words) <= 2:
        return 0.55
    ends_with_terminator = text.rstrip().endswith((".", "!", "?"))
    if len(words) >= 6 and ends_with_terminator:
        return 0.88
    if not ends_with_terminator:
        # No sentence-terminator on a multi-word paragraph: the rule
        # classifier didn't promote this to heading, but the shape
        # doesn't close as a sentence either. Real content is genuinely
        # ambiguous — surface it for triage.
        return 0.65
    return 0.72


def _heading_posterior(
    *,
    block_type: str,
    text: str,
    style_name: str,
    font_size: float,
    corpus_mean_size: float,
    corpus_stdev: float,
) -> float | None:
    if block_type != "heading":
        return None
    if re.match(r"Heading\s+\d", style_name or "", flags=re.I):
        score = 0.95
    elif corpus_stdev > 0 and font_size > 0:
        z = (font_size - corpus_mean_size) / corpus_stdev
        if z >= 1.0:
            score = 0.9
        elif z >= 0.5:
            score = 0.75
        else:
            score = 0.55
    else:
        score = 0.6
    if text.rstrip().endswith((".", ",", ";", ":")):
        score -= 0.2
    return max(0.05, min(0.99, score))


def _semantic_inline_posterior(inline_runs: list[dict[str, Any]]) -> float:
    """Average per-run `semantic_confidence` when present, else heuristic.

    Phase 5 producers do not yet populate per-run `semantic_confidence`
    (the field exists in the schema for Phase 6+ DITA-tagging work). Until
    then we use a two-bucket fallback: 0.7 if the run carries any inline
    marks (bold / italic / monospace / etc — there is *some* inline
    structure to project onto DITA), 0.55 otherwise (pure prose, nothing
    to verify).
    """
    if not inline_runs:
        return 0.55
    confidences: list[float] = []
    has_marks = False
    for run in inline_runs:
        sc = run.get("semantic_confidence")
        if isinstance(sc, int | float):
            confidences.append(float(sc))
        if run.get("marks"):
            has_marks = True
    if confidences:
        return sum(confidences) / len(confidences)
    return 0.7 if has_marks else 0.55
