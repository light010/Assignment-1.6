from __future__ import annotations

import hashlib
import io
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from ditagen_common.locator import (
    format_docx_footer_locator,
    format_docx_header_locator,
)

from .common import (
    _HEADING_TERMINAL_PUNCTUATION,
    ExtractedAsset,
    _block_id,
    _content_type_for_extension,
    _image_dimensions,
    _inline_run,
    _source_block,
    _source_line,
)
from .textual import _looks_like_heading, _textual_block_type

_DRAWINGML_MAIN_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
_OFFICE_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_WML_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

def _docx_paragraph_image_asset_ids(paragraph: Any, document: Any) -> list[str]:
    """Resolve the asset_ids of every image embedded in `paragraph`.

    Walks <a:blip r:embed="rIdN"/> elements under the paragraph and looks
    up each relationship target in `document.part.related_parts`, then
    hashes the image bytes to produce the same asset_id `_asset_manifest`
    will mint. Keeps the order in which drawings appear so callers can
    correlate to inline runs if needed.
    """
    asset_ids: list[str] = []
    seen: set[str] = set()
    for blip in paragraph._element.findall(f".//{{{_DRAWINGML_MAIN_NS}}}blip"):
        rid = blip.get(f"{{{_OFFICE_REL_NS}}}embed")
        if not rid:
            continue
        try:
            image_part = document.part.related_parts[rid]
        except (KeyError, AttributeError):
            continue
        blob = getattr(image_part, "blob", None)
        if not blob:
            continue
        asset_id = f"asset_{hashlib.sha1(blob).hexdigest()[:12]}"
        if asset_id in seen:
            continue
        seen.add(asset_id)
        asset_ids.append(asset_id)
    return asset_ids


def _docx_body_items(document: Any) -> list[tuple[str, Any]]:
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    items: list[tuple[str, Any]] = []
    for child in document.element.body.iterchildren():
        if child.tag.endswith("}p"):
            items.append(("paragraph", Paragraph(child, document)))
        elif child.tag.endswith("}tbl"):
            items.append(("table", Table(child, document)))
    return items


def _docx_block_type(
    paragraph: Any,
    text: str,
    index: int,
    *,
    formatting_threshold: float | None,
) -> tuple[str, int | None, str, float | None]:
    style_name = paragraph.style.name if paragraph.style is not None else ""
    heading = re.match(r"Heading\s+(\d+)", style_name or "", flags=re.I)
    if heading:
        return "heading", int(heading.group(1)), "style_name", 0.95
    if style_name.lower() == "title":
        return "heading", 1, "style_name", 0.95
    if style_name.lower() == "subtitle":
        return "heading", 2, "style_name", 0.85
    numbering = _docx_numbering(paragraph)
    if numbering:
        # `numbering["level"]` always exists (set in `_docx_numbering`)
        # and is an `int`; the previous double `.get()` was defending
        # against an impossible state and tripped mypy's Any-narrowing.
        numbering_level = numbering.get("level")
        level_value = int(numbering_level) if isinstance(numbering_level, int | float) else 0
        return "procedure_step", level_value + 1, "numbering", None
    dotted_heading = re.match(r"^(\d+(?:\.\d+)*)\s+\S", text)
    if dotted_heading and not text.rstrip().endswith(_HEADING_TERMINAL_PUNCTUATION):
        return "heading", min(6, dotted_heading.group(1).count(".") + 1), "numbering", 0.55
    if _docx_is_formatting_heading(paragraph, text, formatting_threshold):
        return "heading", _docx_formatting_heading_level(paragraph, formatting_threshold), "formatting", 0.6
    block_type = _textual_block_type(text, index)
    return block_type, 1 if _looks_like_heading(text, index) else None, "none", None


def _docx_formatting_heading_threshold(document: Any) -> float | None:
    sizes = sorted(
        size
        for kind, paragraph in _docx_body_items(document)
        if kind == "paragraph"
        if paragraph.text.strip()
        for size in [_docx_paragraph_font_size(paragraph)]
        if size is not None
    )
    if not sizes:
        return None
    index = min(len(sizes) - 1, max(0, int(round((len(sizes) - 1) * 0.9))))
    return sizes[index]


def _docx_paragraph_font_size(paragraph: Any) -> float | None:
    sizes: list[float] = []
    for run in paragraph.runs:
        size = getattr(getattr(run, "font", None), "size", None)
        if size is not None and getattr(size, "pt", None) is not None:
            sizes.append(float(size.pt))
    if sizes:
        return max(sizes)
    style = paragraph.style if paragraph.style is not None else None
    style_size = getattr(getattr(style, "font", None), "size", None)
    if style_size is not None and getattr(style_size, "pt", None) is not None:
        return float(style_size.pt)
    return None


def _docx_is_formatting_heading(
    paragraph: Any,
    text: str,
    formatting_threshold: float | None,
    *,
    in_table_cell: bool = False,
) -> bool:
    """Detect whether `paragraph` looks like a heading by formatting alone.

    Step D1 adds the `in_table_cell` defensive guard: when True, this
    function **always returns False** because formatting-detected headings
    inside cells should NOT be promoted to top-level headings — they would
    pollute the structure tree. The caller is responsible for emitting
    `HEADING_IN_CELL` review_flag if it observed the underlying signal
    (the paragraph WOULD have matched but was suppressed because of the
    cell context).

    This guard is defensive today (the producer currently aggregates cell
    paragraphs via `_docx_cell_shape` rather than classifying them), but
    Step E's nested-table walk will start classifying inner-cell paragraphs
    individually. The parameter exists now so that the API doesn't change
    underneath callers added in Step E.

    The terminal-punctuation set is sourced from
    `_HEADING_TERMINAL_PUNCTUATION` (shared with `_looks_like_heading` and
    the DOCX dotted-heading layer) so the three classifier paths cannot
    drift independently.
    """
    if in_table_cell:
        return False
    if formatting_threshold is None:
        return False
    if len(text) > 120 or text.rstrip().endswith(_HEADING_TERMINAL_PUNCTUATION):
        return False
    size = _docx_paragraph_font_size(paragraph)
    if size is None or size < formatting_threshold:
        return False
    visible_runs = [run for run in paragraph.runs if run.text.strip()]
    all_bold = bool(visible_runs) and all(bool(run.bold) for run in visible_runs)
    alignment = getattr(paragraph, "alignment", None)
    centered = getattr(alignment, "name", "") == "CENTER" or alignment == 1
    caps_ratio = _caps_ratio(text)
    return all_bold or centered or (caps_ratio >= 0.8 and len(text) <= 80)


def _docx_formatting_heading_level(paragraph: Any, formatting_threshold: float | None) -> int:
    size = _docx_paragraph_font_size(paragraph)
    if formatting_threshold is None or size is None:
        return 3
    if size >= formatting_threshold * 1.25:
        return 1
    if size >= formatting_threshold * 1.1:
        return 2
    return 3


def _caps_ratio(text: str) -> float:
    letters = [char for char in text if char.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for char in letters if char.isupper()) / len(letters)


def _docx_numbering(paragraph: Any) -> dict[str, Any] | None:
    ppr = paragraph._p.pPr  # noqa: SLF001 - python-docx exposes numbering through the XML object.
    if ppr is None or ppr.numPr is None:
        return None
    raw_num_id = ppr.numPr.numId.val if ppr.numPr.numId is not None else None
    raw_level = ppr.numPr.ilvl.val if ppr.numPr.ilvl is not None else 0
    # Pass the typed locals to `_docx_numbering_definition` rather than
    # re-reading from `normalized` — the dict's value type is `Any`,
    # which loses the str-or-None / int narrowing mypy needs for the
    # downstream signature.
    num_id: str | None = str(raw_num_id) if raw_num_id is not None else None
    level: int = int(raw_level or 0)
    normalized: dict[str, Any] = {"num_id": num_id, "level": level}
    fmt, level_text = _docx_numbering_definition(paragraph, num_id, level)
    if fmt:
        normalized["format"] = fmt
    if level_text:
        normalized["level_text"] = level_text
    return normalized


def _docx_numbering_definition(paragraph: Any, num_id: str | None, level: int) -> tuple[str | None, str | None]:
    if not num_id:
        return None, None
    numbering_part = getattr(getattr(paragraph, "part", None), "numbering_part", None)
    root = getattr(numbering_part, "element", None)
    if root is None:
        return None, None
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    abstract_id: str | None = None
    for num in root.findall(f"{ns}num"):
        if num.get(f"{ns}numId") != num_id:
            continue
        abstract = num.find(f"{ns}abstractNumId")
        abstract_id = abstract.get(f"{ns}val") if abstract is not None else None
        break
    if abstract_id is None:
        return None, None
    for abstract in root.findall(f"{ns}abstractNum"):
        if abstract.get(f"{ns}abstractNumId") != abstract_id:
            continue
        for lvl in abstract.findall(f"{ns}lvl"):
            if lvl.get(f"{ns}ilvl") != str(level):
                continue
            fmt = lvl.find(f"{ns}numFmt")
            text = lvl.find(f"{ns}lvlText")
            return (
                fmt.get(f"{ns}val") if fmt is not None else None,
                text.get(f"{ns}val") if text is not None else None,
            )
    return None, None


def _docx_numbering_with_label(numbering: dict[str, Any], state: dict[str, list[int]]) -> dict[str, Any]:
    num_id = numbering.get("num_id") or "__default__"
    level = int(numbering.get("level") or 0)
    counters = state.setdefault(str(num_id), [])
    while len(counters) <= level:
        counters.append(0)
    counters[level] += 1
    del counters[level + 1 :]
    fmt = str(numbering.get("format") or "decimal")
    marker = _format_numbering_counter(counters[level], fmt)
    level_text = str(numbering.get("level_text") or "")
    label = level_text.replace(f"%{level + 1}", marker) if level_text else f"{marker}."
    return {**numbering, "label": label}


def _format_numbering_counter(value: int, fmt: str) -> str:
    if fmt == "bullet":
        return "•"
    if fmt == "lowerLetter":
        return _alpha_counter(value).lower()
    if fmt == "upperLetter":
        return _alpha_counter(value).upper()
    if fmt == "lowerRoman":
        return _roman_counter(value).lower()
    if fmt == "upperRoman":
        return _roman_counter(value).upper()
    return str(value)


def _alpha_counter(value: int) -> str:
    chars: list[str] = []
    current = max(1, value)
    while current:
        current -= 1
        chars.append(chr(ord("A") + (current % 26)))
        current //= 26
    return "".join(reversed(chars))


def _roman_counter(value: int) -> str:
    current = max(1, value)
    numerals = [
        (1000, "M"),
        (900, "CM"),
        (500, "D"),
        (400, "CD"),
        (100, "C"),
        (90, "XC"),
        (50, "L"),
        (40, "XL"),
        (10, "X"),
        (9, "IX"),
        (5, "V"),
        (4, "IV"),
        (1, "I"),
    ]
    result: list[str] = []
    for number, label in numerals:
        while current >= number:
            result.append(label)
            current -= number
    return "".join(result)


def _docx_run_is_hidden(run: Any) -> bool:
    """Return True iff `run` has explicit `<w:vanish/>` (run.font.hidden).

    Step D2: python-docx's `run.font.hidden` is tri-state — True (explicit
    `<w:vanish/>`), False (explicit `<w:vanish w:val="0"/>`), or None
    (inherit from style). We only treat the True case as hidden because
    inherited hidden via paragraph/character style is rare in practice
    and would require a full style-chain walk; the explicit run-level
    flag covers Word's built-in "Hidden" character format which is what
    99% of documents use.
    """
    try:
        return run.font.hidden is True
    except AttributeError:
        return False


def _docx_visible_text(paragraph: Any) -> tuple[str, bool]:
    """Concatenate non-hidden run text from a paragraph.

    Returns `(visible_text, has_hidden_runs)`:
    - `visible_text`: paragraph text with `<w:vanish/>` runs filtered out.
    - `has_hidden_runs`: True iff at least one run with visible text was filtered.

    **Fast path** (the overwhelmingly common case): if no `<w:vanish/>`
    element exists anywhere in the paragraph's XML subtree, returns
    `paragraph.text` verbatim. This matches python-docx's full text
    aggregation — which crucially **includes hyperlink content** via
    its XML walk over both direct `<w:r>` children AND `<w:r>` runs
    nested inside `<w:hyperlink>`. Iterating `paragraph.runs` alone
    misses hyperlink runs (verified empirically against Apple CA's
    Portal Links section, where the "Apple CA Blueprint" and "Apple CA
    PPM" paragraphs are pure hyperlinks).

    **Slow path** (only when `<w:vanish/>` is present): walks the XML
    subtree to identify every `<w:r>` descendant — direct children of
    `<w:p>` AND children of `<w:hyperlink>` — and excludes those whose
    `<w:rPr>` contains an active `<w:vanish/>` element. The slow path
    preserves text, `<w:tab/>` content, and so on for non-hidden runs.

    The caller is responsible for emitting `HIDDEN_TEXT_DROPPED`
    review_flag when `has_hidden_runs` is True so triage reviewers can
    confirm the drop was intentional.
    """
    p_element = paragraph._p  # noqa: SLF001 - python-docx exposes XML through _p.

    # Fast path: detect whether any <w:vanish/> exists in the subtree.
    has_any_vanish = False
    for vanish in p_element.iter(f"{_WML_NS}vanish"):
        val = vanish.get(f"{_WML_NS}val")
        if val in (None, "", "1", "true"):
            has_any_vanish = True
            break
    if not has_any_vanish:
        return paragraph.text, False

    # Slow path: walk every <w:r> descendant (including hyperlink children)
    # and filter the hidden ones. Skip <w:r> inside <w:del> too — those
    # are deleted-revision runs that should never appear in the visible
    # text regardless of <w:vanish/>.
    parts: list[str] = []
    has_hidden_with_text = False
    for r in p_element.iter(f"{_WML_NS}r"):
        # Determine if this <w:r> is hidden via direct rPr.
        is_hidden = False
        rpr = r.find(f"{_WML_NS}rPr")
        if rpr is not None:
            v = rpr.find(f"{_WML_NS}vanish")
            if v is not None:
                val = v.get(f"{_WML_NS}val")
                if val in (None, "", "1", "true"):
                    is_hidden = True
        if is_hidden:
            for t in r.iter(f"{_WML_NS}t"):
                if t.text:
                    has_hidden_with_text = True
                    break
            continue
        for child in r.iter():
            tag = child.tag
            if tag == f"{_WML_NS}t" and child.text:
                parts.append(child.text)
            elif tag == f"{_WML_NS}tab":
                parts.append("\t")
    return "".join(parts), has_hidden_with_text


def _docx_run_marks(run: Any) -> list[str]:
    """Inline-mark list (bold/italic/underline/monospace) for a python-docx Run."""
    marks: list[str] = []
    if run.bold:
        marks.append("bold")
    if run.italic:
        marks.append("italic")
    if run.underline:
        marks.append("underline")
    font_name = run.font.name or ""
    style_name = run.style.name if run.style is not None else ""
    if re.search(r"(consolas|courier|mono|code)", f"{font_name} {style_name}", flags=re.I):
        marks.append("monospace")
    return marks


def _docx_hyperlink_target(hyperlink_element: Any, paragraph: Any) -> str | None:
    """Resolve a `<w:hyperlink>` element to its target URL.

    External links carry `r:id` resolved via the paragraph's part
    relationships. Internal links use `w:anchor` (a bookmark name); we
    return `#<anchor>` so consumers can distinguish without losing the
    anchor. Returns None when neither attribute is present (malformed).
    """
    r_id = hyperlink_element.get(f"{{{_OFFICE_REL_NS}}}id")
    if r_id:
        try:
            return paragraph.part.rels[r_id].target_ref
        except (KeyError, AttributeError):
            return None
    anchor = hyperlink_element.get(f"{_WML_NS}anchor")
    if anchor:
        return f"#{anchor}"
    return None


def _docx_runs(paragraph: Any, fallback_text: str) -> list[dict[str, Any]]:
    """Build inline_runs by walking the paragraph's direct XML children in
    document order.

    Step D3: this replaces the prior implementation that iterated
    `paragraph.runs`, which (in python-docx 1.x) excludes runs nested
    inside `<w:hyperlink>`. The block's `text` field — sourced from
    `_docx_visible_text` / `paragraph.text` — DOES include hyperlink
    content; iterating `paragraph.runs` alone left `inline_runs` missing
    the hyperlink ranges, breaking the offset alignment invariant.

    Walking direct children of `<w:p>` covers both shapes:
      - `<w:r>`: a direct run; emit one InlineRun.
      - `<w:hyperlink>`: resolve `r:id` → URL via paragraph.part.rels,
        emit one InlineRun **per nested `<w:r>`** with the same `href`
        and a `"link"` mark.

    Hidden runs (`<w:vanish/>`) are filtered identically to
    `_docx_visible_text` so block text and inline_run offsets stay
    aligned. The cursor advances over the visible text contributed by
    each emitted run.
    """
    from docx.text.run import Run

    runs: list[dict[str, Any]] = []
    cursor = 0

    def emit_run_element(r_element: Any, href: str | None) -> None:
        nonlocal cursor
        run = Run(r_element, paragraph)
        if _docx_run_is_hidden(run):
            return
        text = run.text
        if not text:
            return
        marks = _docx_run_marks(run)
        if href is not None:
            marks.append("link")
        runs.append(_inline_run(text, cursor, cursor + len(text), marks, href=href))
        cursor += len(text)

    for child in paragraph._p:  # noqa: SLF001 - paragraph._p is the lxml element.
        tag = child.tag
        if tag == f"{_WML_NS}r":
            emit_run_element(child, href=None)
        elif tag == f"{_WML_NS}hyperlink":
            href = _docx_hyperlink_target(child, paragraph)
            for r_element in child.iter(f"{_WML_NS}r"):
                emit_run_element(r_element, href=href)

    return runs or [_inline_run(fallback_text, 0, len(fallback_text), [])]


def _docx_cell_shape(cell: Any) -> dict[str, Any]:
    text = cell.text.strip().replace("\n", " ")
    tc_pr = cell._tc.tcPr  # noqa: SLF001 - python-docx exposes merged-cell attrs through XML.
    colspan = 1
    rowspan = 1
    if tc_pr is not None and tc_pr.gridSpan is not None:
        colspan = int(tc_pr.gridSpan.val or 1)
    if tc_pr is not None and tc_pr.vMerge is not None:
        rowspan = 0 if tc_pr.vMerge.val == "continue" else 1
    return {"text": text, "colspan": colspan, "rowspan": rowspan}


def _docx_caption_candidates(document: Any) -> dict[int, str]:
    captions: dict[int, str] = {}
    for index, paragraph in enumerate(document.paragraphs, start=1):
        style_name = paragraph.style.name if paragraph.style is not None else ""
        if style_name.lower() == "caption" and paragraph.text.strip():
            captions[index] = paragraph.text.strip()
    return captions


@dataclass(frozen=True)
class _DocxNote:
    """A single footnote or endnote extracted from the DOCX's notes stream."""

    kind: str  # "footnote" or "endnote"
    note_id: int
    text: str


def _extract_docx_notes(data: bytes) -> list[_DocxNote]:
    """Walk `word/footnotes.xml` and `word/endnotes.xml` from the DOCX zip.

    Step D4 — footnote/endnote streams ship to the producer as separate
    `block_type="note"` source blocks (locator `docx:footnote:{id}` or
    `docx:endnote:{id}`). They are not part of the body iteration and do
    not consume body_index slots.

    Word emits two reserved IDs in these streams that must be skipped:
      - `-1` (separator: the horizontal rule above footnotes)
      - `0`  (continuation separator)
    Anything else is real footnote content authored by the user. Empty
    notes (text.strip() == "") are also skipped — Word sometimes leaves
    placeholder entries behind during edits.
    """
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    notes: list[_DocxNote] = []
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return notes
    with archive:
        for entry, kind in (("word/footnotes.xml", "footnote"), ("word/endnotes.xml", "endnote")):
            try:
                xml_bytes = archive.read(entry)
            except KeyError:
                continue
            try:
                root = ET.fromstring(xml_bytes)
            except ET.ParseError:
                continue
            for note_elem in root.findall(f"{ns}{kind}"):
                raw_id = note_elem.get(f"{ns}id")
                if raw_id is None:
                    continue
                try:
                    note_id = int(raw_id)
                except ValueError:
                    continue
                if note_id < 1:  # Skip reserved separators (-1, 0).
                    continue
                text_parts: list[str] = []
                for t in note_elem.iter(f"{ns}t"):
                    if t.text:
                        text_parts.append(t.text)
                text = "".join(text_parts).strip()
                if not text:
                    continue
                notes.append(_DocxNote(kind=kind, note_id=note_id, text=text))
    return notes


def _emit_docx_header_footer_blocks(
    *,
    document: Any,
    document_id: str,
    filename: str,
    position: int,
    blocks: list[dict[str, Any]],
    source_lines: list[dict[str, Any]],
) -> int:
    """Append `running_header`/`running_footer` blocks for every section.

    Walks `document.sections`. For each section index ``i``:
      - emits one block per non-empty paragraph in `section.header`, locator
        ``docx:hdr:section-{i}:p:{j}``,
      - then the same for `section.footer`, locator
        ``docx:ftr:section-{i}:p:{j}``.

    The section-id charset (``[A-Za-z0-9_.-]+``) is enforced by
    `format_docx_header_locator`/`format_docx_footer_locator` — ``section-{i}``
    is a valid token.

    v1 only walks the *primary* header/footer surface; Word's first-page
    and even-page variants are intentionally out of scope. Empty paragraphs
    (text.strip() == "") are skipped — Word leaves placeholder ``<w:p/>``
    elements behind in header parts even when the author cleared them.
    """
    sections = getattr(document, "sections", None) or []
    for section_idx, section in enumerate(sections):
        section_id = f"section-{section_idx}"
        for kind, surface, formatter, role in (
            ("running_header", getattr(section, "header", None), format_docx_header_locator, "header"),
            ("running_footer", getattr(section, "footer", None), format_docx_footer_locator, "footer"),
        ):
            if surface is None:
                continue
            paragraphs = getattr(surface, "paragraphs", None) or []
            for para_idx, paragraph in enumerate(paragraphs):
                text = (paragraph.text or "").strip()
                if not text:
                    continue
                position += 1
                section_locator = formatter(section_id, para_idx)
                hf_block_id = _block_id(filename, position, f"{role}:{section_id}:p:{para_idx}:{text}")
                hf_line = _source_line(
                    document_id=document_id,
                    line_number=position,
                    page=None,
                    section=section_locator,
                    text=text,
                    font_size=11,
                    bold=False,
                    style_name=role.capitalize(),
                    block_id=hf_block_id,
                )
                source_lines.append(hf_line)
                blocks.append(
                    _source_block(
                        document_id=document_id,
                        block_id=hf_block_id,
                        line_id=hf_line["line_id"],
                        block_type=kind,
                        text=text,
                        page=None,
                        section=section_locator,
                        order=position,
                        heading_path_ids=[],
                        inferred_level=None,
                        font_size=11,
                        font_family=None,
                        bold=False,
                        style_name=role.capitalize(),
                        inline_runs=[_inline_run(text, 0, len(text), [])],
                        extra={
                            "char_start": 0,
                            "char_end": len(text),
                            "confidence_signals": {
                                "style_source": "style_name",
                                "source_kind": role,
                            },
                        },
                    )
                )
    return position


def _extract_docx_assets(data: bytes) -> list[ExtractedAsset]:
    assets: list[ExtractedAsset] = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for name in sorted(archive.namelist()):
            if not name.startswith("word/media/"):
                continue
            content = archive.read(name)
            width, height = _image_dimensions(content)
            assets.append(
                ExtractedAsset(
                    name=Path(name).name,
                    content=content,
                    content_type=_content_type_for_extension(Path(name).suffix),
                    width=width,
                    height=height,
                )
            )
    return assets
