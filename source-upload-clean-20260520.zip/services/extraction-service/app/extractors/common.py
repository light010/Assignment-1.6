from __future__ import annotations

import hashlib
import io
import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from ditagen_common.artifacts import sha256_bytes, sha256_text, slugify
from ditagen_common.models import (
    Block,
    Confidence,
    ConfidenceSignals,
    Font,
    InlineRun,
    Numbering,
    SourceLocation,
    StyleSummary,
    TableCell,
)
from ditagen_common.pipeline import build_structure_tree

from .heading_classifier import _compute_review_signals

try:
    from pandoc_projector import PandocProjectorError, project_docx_to_markdown
except ModuleNotFoundError:  # package import path
    import importlib.util
    import sys

    _projector_path = Path(__file__).resolve().parents[1] / "pandoc_projector.py"
    _projector_spec = importlib.util.spec_from_file_location("extraction_service_pandoc_projector", _projector_path)
    if _projector_spec is None or _projector_spec.loader is None:
        raise
    _projector_module = importlib.util.module_from_spec(_projector_spec)
    sys.modules.setdefault("extraction_service_pandoc_projector", _projector_module)
    _projector_spec.loader.exec_module(_projector_module)
    globals()["PandocProjectorError"] = _projector_module.PandocProjectorError
    globals()["project_docx_to_markdown"] = _projector_module.project_docx_to_markdown

try:
    from contracts import ExtractionWarning
except ModuleNotFoundError:  # direct package-file test loader
    import importlib.util
    import sys

    _contracts_path = Path(__file__).resolve().parents[1] / "contracts.py"
    _contracts_spec = importlib.util.spec_from_file_location("extraction_service_contracts", _contracts_path)
    if _contracts_spec is None or _contracts_spec.loader is None:
        raise
    _contracts_module = importlib.util.module_from_spec(_contracts_spec)
    sys.modules.setdefault("extraction_service_contracts", _contracts_module)
    _contracts_spec.loader.exec_module(_contracts_module)
    globals()["ExtractionWarning"] = _contracts_module.ExtractionWarning

EXTRACTOR_VERSION = "week3-alpha.1"
_PLACEHOLDER_CONFIDENCE = 0.5
_HEADING_TERMINAL_PUNCTUATION = (".", "!", "?", ";", ":", ",")

@dataclass(frozen=True)
class ExtractedAsset:
    name: str
    content: bytes
    content_type: str
    width: int | None = None
    height: int | None = None
    caption: str | None = None
    source_block_id: str | None = None


@dataclass(frozen=True)
class ExtractionOutput:
    source_lines: list[dict[str, Any]]
    source_blocks: list[dict[str, Any]]
    style_profile: dict[str, Any]
    structure_tree: dict[str, Any]
    asset_manifest: dict[str, Any]
    markdown: str
    extraction_quality: dict[str, Any]
    warnings: list[ExtractionWarning] = field(default_factory=list)
    assets: list[ExtractedAsset] = field(default_factory=list)
    header_footer: list[dict[str, Any]] = field(default_factory=list)


def _assemble_output(
    *,
    document_id: str,
    filename: str,
    blocks: list[dict[str, Any]],
    source_lines: list[dict[str, Any]],
    warnings: list[ExtractionWarning],
    assets: list[ExtractedAsset],
    header_footer: list[dict[str, Any]] | None = None,
    source_kind: str,
    source_bytes: bytes | None = None,
) -> ExtractionOutput:
    # Phase 5: every extractor path lands here, so this is the single
    # canonical site that runs the corpus-aware confidence + review-flag
    # computation. An architecture invariant
    # (`confidence_post_processor_runs`) asserts that the four extractors
    # do not bypass `_assemble_output` to ship raw blocks.
    # Step G5: measure real `duration_ms` for the structure-tree +
    # projection phases. The per-extractor body iteration is excluded
    # because it varies per source_kind; the gate's `runtime.duration_ms`
    # is meant to track the post-processing pipeline that's identical
    # across DOCX/PDF/text/HTML.
    started_at_s = time.perf_counter()
    _compute_review_signals(blocks)
    asset_manifest = _asset_manifest(document_id=document_id, assets=assets)
    structure_tree = build_structure_tree(document_id=document_id, source_blocks=blocks)
    style_profile = _style_profile(document_id=document_id, blocks=blocks)
    markdown, projection_runtime, projection_reason = _project_markdown(
        filename=filename,
        source_kind=source_kind,
        source_bytes=source_bytes,
        blocks=blocks,
        asset_manifest=asset_manifest,
        warnings=warnings,
    )
    elapsed_ms = max(1, int((time.perf_counter() - started_at_s) * 1000))
    projection_runtime["duration_ms"] = elapsed_ms
    extraction_quality = _extraction_quality(
        document_id=document_id,
        source_kind=source_kind,
        blocks=blocks,
        structure_tree=structure_tree,
        asset_manifest=asset_manifest,
        warnings=warnings,
        projection_reason=projection_reason,
        projection_runtime=projection_runtime,
    )
    return ExtractionOutput(
        source_lines=source_lines,
        source_blocks=blocks,
        style_profile=style_profile,
        structure_tree=structure_tree,
        asset_manifest=asset_manifest,
        markdown=markdown,
        extraction_quality=extraction_quality,
        warnings=warnings,
        assets=assets,
        header_footer=header_footer or [],
    )


def _project_markdown(
    *,
    filename: str,
    source_kind: str,
    source_bytes: bytes | None,
    blocks: list[dict[str, Any]],
    asset_manifest: dict[str, Any],
    warnings: list[ExtractionWarning],
) -> tuple[str, dict[str, Any], str | None]:
    runtime: dict[str, Any] = {"pandoc_version": None, "mdformat_version": None, "pandoc_warnings": []}
    if source_kind != "docx":
        return _markdown(filename=filename, blocks=blocks, asset_manifest=asset_manifest), runtime, None

    if os.getenv("EXTRACTION_PROJECTOR") == "python_v1":
        warnings.append(
            _warning(
                "extraction.projector.rollback_engaged",
                "DOCX markdown used the operator-selected python_v1 rollback projector.",
            )
        )
        return _markdown(filename=filename, blocks=blocks, asset_manifest=asset_manifest), runtime, None

    try:
        projection = project_docx_to_markdown(docx_bytes=source_bytes or b"", source_blocks=blocks)
    except PandocProjectorError as exc:
        # Step F: pass the projector's reason through verbatim instead of
        # collapsing every non-pandoc_unavailable failure to "pandoc_failed".
        # The schema accepts pandoc_unavailable, pandoc_failed, pandoc_reordered,
        # mdformat_unavailable, mdformat_plugin_missing — the projector raises
        # with the right one; we just plumb it through to the gate.
        reason = exc.reason
        warnings.append(_warning(f"dependency.{reason}", str(exc)))
        return _markdown(filename=filename, blocks=blocks, asset_manifest=asset_manifest), runtime, reason

    runtime = {
        "pandoc_version": projection.pandoc_version,
        "mdformat_version": projection.mdformat_version,
        "pandoc_warnings": projection.warnings,
    }
    return projection.markdown, runtime, None


def _extraction_quality(
    *,
    document_id: str,
    source_kind: str,
    blocks: list[dict[str, Any]],
    structure_tree: dict[str, Any],
    asset_manifest: dict[str, Any],
    warnings: list[ExtractionWarning],
    projection_reason: str | None,
    projection_runtime: dict[str, Any],
) -> dict[str, Any]:
    locators = [
        (block.get("source_location") or {}).get("section")
        for block in blocks
        if block.get("block_type") not in {"running_header", "running_footer"}
    ]
    missing_locator_ids = [
        block["block_id"]
        for block in blocks
        if block.get("block_type") not in {"running_header", "running_footer"}
        and not (block.get("source_location") or {}).get("section")
    ]
    duplicate_locators = sorted({item for item in locators if item and locators.count(item) > 1})
    review_flag_counts: dict[str, int] = {}
    for block in blocks:
        for flag in block.get("review_flags") or []:
            if isinstance(flag, dict) and flag.get("code"):
                review_flag_counts[flag["code"]] = review_flag_counts.get(flag["code"], 0) + 1
    histogram: dict[str, int] = {}
    for block in blocks:
        histogram[block["block_type"]] = histogram.get(block["block_type"], 0) + 1

    blocking_reasons: list[str] = []
    if source_kind == "docx":
        if missing_locator_ids:
            blocking_reasons.append("locator_missing")
        if duplicate_locators:
            blocking_reasons.append("locator_duplicate")
        if projection_reason:
            blocking_reasons.append(projection_reason)
        if len(structure_tree.get("nodes", [])) > 1 and not any(
            node.get("child_node_ids") for node in structure_tree.get("nodes", [])
        ):
            blocking_reasons.append("structure_tree_flat")
        if structure_tree.get("quality", {}).get("review_required"):
            blocking_reasons.append("structure_tree_review_required")
    if any(warning.severity == "error" for warning in warnings):
        blocking_reasons.append("review_flag_threshold_exceeded")

    total_assets = len(asset_manifest.get("assets", []))
    resolved_assets = sum(1 for asset in asset_manifest.get("assets", []) if asset.get("asset_id"))
    asset_resolution_rate = resolved_assets / total_assets if total_assets else 1.0

    blocking_reasons = sorted(set(blocking_reasons))
    return {
        "schema_version": 1,
        "document_id": document_id,
        "gate": {
            "name": "docx_source_fidelity_v1",
            "passed": not blocking_reasons,
            "severity": "blocking" if blocking_reasons else "info",
            "blocking_reasons": blocking_reasons,
            "warnings": [
                {
                    "kind": warning.kind,
                    "message": warning.message,
                    "source_block_ids": warning.source_block_ids,
                }
                for warning in warnings
            ],
            "override": None,
            "override_history": [],
        },
        "metrics": {
            "total_source_blocks": len(blocks),
            "located_source_blocks": len(blocks) - len(missing_locator_ids),
            "unlocated_source_block_ids": missing_locator_ids,
            "block_type_histogram": histogram,
            "structure_confidence": structure_tree.get("quality", {}).get("overall_confidence"),
            "repaired_level_count": int(structure_tree.get("quality", {}).get("repaired_level_count") or 0),
            "review_flag_counts": review_flag_counts,
            "asset_resolution_rate": round(asset_resolution_rate, 3),
        },
        "runtime": {
            "extractor_version": EXTRACTOR_VERSION,
            "pandoc_version": projection_runtime.get("pandoc_version"),
            "mdformat_version": projection_runtime.get("mdformat_version"),
            # Step G5: real measurement from `_assemble_output`. Falls
            # back to 0 only if the caller bypassed the timing wrap.
            "duration_ms": int(projection_runtime.get("duration_ms") or 0),
            "pandoc_warnings": projection_runtime.get("pandoc_warnings", []),
        },
    }


def _style_profile(*, document_id: str, blocks: list[dict[str, Any]]) -> dict[str, Any]:
    clusters: dict[int, int] = {}
    for block in blocks:
        size = int(round(block["style_summary"]["dominant_font_size_pt"]))
        clusters[size] = clusters.get(size, 0) + 1
    ordered = sorted(clusters.items(), key=lambda item: item[0], reverse=True)
    return {
        "document_id": document_id,
        "font_size_clusters": [
            {
                "rank": index,
                "font_size_pt": size,
                "block_count": count,
                "likely_role": "heading" if index == 1 else "body",
            }
            for index, (size, count) in enumerate(ordered, start=1)
        ],
        "heading_rules": {
            "accept_threshold": 0.78,
            "review_threshold": 0.55,
            "signals": [
                "source_style_name",
                "font_size_rank",
                "numbering_pattern",
                "short_line",
            ],
        },
    }


def _asset_manifest(*, document_id: str, assets: list[ExtractedAsset]) -> dict[str, Any]:
    manifest_assets = []
    for asset in assets:
        digest = sha256_bytes(asset.content)
        ext = Path(asset.name).suffix.lower() or ".bin"
        asset_id = f"asset_{hashlib.sha1(asset.content).hexdigest()[:12]}"
        manifest_assets.append(
            {
                "asset_id": asset_id,
                "document_id": document_id,
                "filename": asset.name,
                "content_type": asset.content_type,
                "size_bytes": len(asset.content),
                "hash": digest,
                "sha256": digest,
                "width": asset.width,
                "height": asset.height,
                "caption": asset.caption,
                "source_block_id": asset.source_block_id,
                "dita_href": f"assets/{asset_id}{ext}",
                "preview_url": f"asset:{asset_id}",
            }
        )
    return {
        "document_id": document_id,
        "assets": manifest_assets,
    }


def _markdown(*, filename: str, blocks: list[dict[str, Any]], asset_manifest: dict[str, Any]) -> str:
    source_blocks_hash = sha256_text("\n".join(json.dumps(block, sort_keys=True) for block in blocks) + "\n")
    asset_manifest_hash = sha256_text(json.dumps(asset_manifest, sort_keys=True))
    lines = [
        (
            "<!-- "
            f"source_blocks_sha256={source_blocks_hash} "
            f"asset_manifest_sha256={asset_manifest_hash} "
            f"extractor_version={EXTRACTOR_VERSION} "
            f"source_filename={Path(filename).name}"
            " -->"
        ),
        "",
    ]
    # Step D5: figure blocks render inline at their body-index position
    # using the first `asset_ref`. The trailing asset list (kept for
    # orphan images that no figure block claimed) is deduped against
    # the set of inline-rendered asset_ids to avoid emitting the same
    # image twice in `content.md`.
    asset_by_id = {a["asset_id"]: a for a in asset_manifest.get("assets", []) if a.get("asset_id")}
    referenced_asset_ids: set[str] = set()
    for block in blocks:
        block_type = block["block_type"]
        # Step E: running_header/running_footer blocks are emitted into
        # `source_blocks.jsonl` so the workbench can show them, but they
        # do NOT belong in the main content stream of `content.md`. The
        # PDF code path treats them the same way (see the quality-gate
        # locator-counting at extractors.py:828 which already excludes
        # both types).
        if block_type in {"running_header", "running_footer"}:
            continue
        text = block["text"].strip()
        if block_type == "figure":
            asset_refs = block.get("asset_refs") or []
            if not asset_refs:
                continue
            asset = asset_by_id.get(asset_refs[0])
            href = asset["dita_href"] if asset else f"asset:{asset_refs[0]}"
            alt = (asset.get("caption") or asset.get("filename")) if asset else "image"
            lines.append(f"<!-- source:{block['block_id']} -->")
            lines.append(f"![{alt}]({href})")
            lines.append("")
            for aid in asset_refs:
                referenced_asset_ids.add(aid)
            continue
        if not text:
            continue
        lines.append(f"<!-- source:{block['block_id']} -->")
        if block_type == "heading":
            level = max(1, min(int(block.get("inferred_level") or 1), 3))
            lines.append(f"{'#' * level} {text}")
        elif block_type == "procedure_step":
            lines.append(f"1. {text}")
        elif block_type == "table_row" and block.get("cells"):
            lines.append("| " + " | ".join(cell["text"] for cell in block["cells"]) + " |")
        else:
            lines.append(text)
        lines.append("")
    for asset in asset_manifest.get("assets", []):
        if asset.get("asset_id") in referenced_asset_ids:
            continue
        alt = asset.get("caption") or asset.get("filename")
        lines.extend([f"![{alt}](asset:{asset['asset_id']})", ""])
    return "\n".join(lines).strip() + "\n"


def _source_line(
    *,
    document_id: str,
    line_number: int,
    page: int | None,
    section: str | None = None,
    text: str,
    font_size: float,
    bold: bool,
    style_name: str | None,
    block_id: str,
) -> dict[str, Any]:
    line_id = f"line_{line_number:04d}"
    # Step I3: `source_location` is bounded by `source-line.schema.json`
    # to `{page, slide, section, bbox}` (additionalProperties: false). The
    # historical emit included `source_location.block_id`, which made
    # every `source-lines.jsonl` schema-INVALID against strict
    # validators. Plan I3 claimed `block_id` was "already carried at the
    # top level" — that was inaccurate; no consumer reads it from
    # source-lines at all. The link source-line → block is established
    # by callers passing `line_id` into `_source_block.line_ids` (the
    # block points at its lines, not the other way around).
    # `block_id` param is kept for caller ergonomics but no longer
    # emitted onto the source-line dict.
    _ = block_id  # intentionally unused — see comment above
    return {
        "line_id": line_id,
        "document_id": document_id,
        "page_or_slide": page,
        "text": text,
        "source_location": {"page": page, "section": section},
        "style": {
            "font_family": None,
            "font_size_pt": round(float(font_size), 2),
            "bold": bool(bold),
            "italic": None,
            "monospace": "`" in text,
            "alignment": "left",
            "source_style_name": style_name,
        },
        "text_runs": [{"text": text, "start": 0, "end": len(text), "marks": _source_marks(text), "style": {}}],
    }


def _source_block(
    *,
    document_id: str,
    block_id: str,
    line_id: str,
    block_type: str,
    text: str,
    page: int | None,
    section: str | None = None,
    order: int,
    heading_path_ids: list[str],
    inferred_level: int | None,
    font_size: float,
    font_family: str | None,
    bold: bool,
    style_name: str | None,
    inline_runs: list[dict[str, Any]],
    asset_refs: list[str] | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Construct a typed `Block` (Phase 2b) and serialize to a JSON-safe dict.

    The transitional dict-aliases (`id`, `type`, `page`, top-level `bbox`)
    are gone — the frontend uses canonical fields plus a defensive
    `source_location.bbox || bbox` fallback that survives the change.

    Per-format extras flow in via the `extra` dict and get mapped to typed
    fields on the model. Any unknown key in `extra` is dropped (the model
    is strict, `extra="forbid"`); known keys are:
      bbox, table_id, row_index, cells, numbering, caption_candidate,
      char_start, char_end, is_likely_heading, confidence_signals,
      review_flags.
    """
    extra = extra or {}

    bbox = extra.get("bbox")
    table_id = extra.get("table_id")
    row_index = extra.get("row_index")
    raw_cells = extra.get("cells", [])
    numbering = extra.get("numbering")
    caption_candidate = extra.get("caption_candidate")
    char_start = extra.get("char_start")
    char_end = extra.get("char_end")
    is_likely_heading = extra.get("is_likely_heading", block_type == "heading")
    confidence_signals_raw = extra.get(
        "confidence_signals",
        {"style": style_name, "font_size": round(float(font_size), 2)},
    )
    review_flags = extra.get("review_flags", [])

    # Placeholder confidence values. The Phase 5 post-processor
    # `_compute_review_signals` (called from each `_extract_*` function
    # before `_assemble_output`) overwrites these with corpus-aware
    # signals. The placeholder is deliberately mid-range so any block
    # whose post-processor was skipped surfaces as "needs review" rather
    # than fake-high.
    block_model = Block(
        block_id=block_id,
        document_id=document_id,
        block_type=cast(Any, block_type),
        text=text,
        source_location=SourceLocation(page=page, section=section, bbox=list(bbox) if bbox else None),
        heading_path_ids=list(heading_path_ids),
        inline_runs=[InlineRun(**run) for run in inline_runs],
        confidence=Confidence(
            extraction=_PLACEHOLDER_CONFIDENCE,
            block_type=_PLACEHOLDER_CONFIDENCE,
            heading=_PLACEHOLDER_CONFIDENCE if block_type == "heading" else None,
            semantic_inline=_PLACEHOLDER_CONFIDENCE,
        ),
        source_line_ids=[line_id],
        inferred_level=inferred_level,
        style_summary=StyleSummary(
            dominant_font_size_pt=round(float(font_size), 2),
            font_size_rank=1 if block_type == "heading" else 2,
            bold_ratio=1 if bold else 0,
            italic_ratio=0,
            monospace_ratio=1 if "`" in text else 0,
            source_style_name=style_name,
        ),
        asset_refs=list(asset_refs or []),
        language="en-US",
        content_hash=sha256_text(text),
        review_flags=review_flags,
        warnings=[],
        font=Font(
            size=round(float(font_size), 2),
            family=font_family,
            weight="bold" if bold else "regular",
        ),
        order_in_page=order,
        is_likely_heading=is_likely_heading,
        confidence_signals=ConfidenceSignals(**confidence_signals_raw),
        table_id=table_id,
        row_index=row_index,
        cells=[TableCell(**cell) for cell in raw_cells],
        numbering=Numbering(**numbering) if numbering else None,
        caption_candidate=caption_candidate,
        char_start=char_start,
        char_end=char_end,
    )
    return block_model.model_dump(mode="json")


def _inline_run(
    text: str,
    start: int,
    end: int,
    marks: list[str],
    *,
    href: str | None = None,
) -> dict[str, Any]:
    run: dict[str, Any] = {
        "start": start,
        "end": end,
        "text": text,
        "marks": marks,
        "semantic_hint": "codeph" if "monospace" in marks or "`" in text else None,
    }
    # Step D3: only attach `href` when present so existing (non-hyperlink)
    # inline_run dicts stay byte-identical with prior output.
    if href is not None:
        run["href"] = href
    return run


def _source_marks(text: str) -> list[str]:
    return ["monospace"] if "`" in text else []


def _strip_list_marker(text: str) -> str:
    return re.sub(r"^\s*(\d+[\.)]|[-*])\s+", "", text).strip()


def _block_id(filename: str, position: int, text: str) -> str:
    seed = f"{Path(filename).name}:{position}:{text[:32]}".encode()
    return f"blk_{hashlib.sha1(seed).hexdigest()[:12]}"


def _warning(kind: str, message: str, *, source_block_ids: list[str] | None = None) -> ExtractionWarning:
    warning_id = f"warn_{slugify(kind)}_{hashlib.sha1(message.encode('utf-8')).hexdigest()[:8]}"
    return ExtractionWarning(
        warning_id=warning_id,
        kind=kind,
        severity="warning" if not kind.endswith("empty_docx") else "error",
        message=message,
        source_block_ids=source_block_ids or [],
    )


def _with_extra_warning(output: ExtractionOutput, warning: ExtractionWarning) -> ExtractionOutput:
    return ExtractionOutput(
        source_lines=output.source_lines,
        source_blocks=output.source_blocks,
        style_profile=output.style_profile,
        structure_tree=output.structure_tree,
        asset_manifest=output.asset_manifest,
        markdown=output.markdown,
        extraction_quality=output.extraction_quality,
        warnings=[*output.warnings, warning],
        assets=output.assets,
        header_footer=output.header_footer,
    )


def _content_type_for_extension(extension: str) -> str:
    mapping = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".svg": "image/svg+xml",
        ".bmp": "image/bmp",
        ".tif": "image/tiff",
        ".tiff": "image/tiff",
    }
    return mapping.get(extension.lower(), "application/octet-stream")


def _image_dimensions(data: bytes) -> tuple[int | None, int | None]:
    """Return (width, height) for an image asset, or (None, None) on failure.

    We delegate to Pillow rather than parsing PNG/JPEG headers by hand.
    The previous hand-rolled parser was a license-clean shortcut from
    the alpha — it covered just two formats and trusted untrusted bytes
    to be well-formed (a malformed JPEG could spin the marker scan).
    Pillow's `Image.open()` handles PNG/JPEG/GIF/BMP/TIFF/WebP safely,
    raises on bad input instead of looping, and never decodes pixels
    here because we only read `.size` (header-only).
    """
    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError:
        # Pillow ships in our pyproject.toml, but stay graceful: missing
        # dimensions degrade the asset card, they don't break extraction.
        return None, None
    try:
        with Image.open(io.BytesIO(data)) as image:
            width, height = image.size
            return int(width), int(height)
    except (UnidentifiedImageError, OSError, ValueError):
        return None, None


def _heading_font_threshold(font_sizes: list[float]) -> float | None:
    if len(set(round(size, 1) for size in font_sizes)) <= 1:
        return None
    mean = sum(font_sizes) / len(font_sizes)
    variance = sum((size - mean) ** 2 for size in font_sizes) / len(font_sizes)
    stdev = variance**0.5
    return mean + (0.75 * stdev)
