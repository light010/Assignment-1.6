from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .common import (
    _HEADING_TERMINAL_PUNCTUATION,
    ExtractionOutput,
    ExtractionWarning,
    _assemble_output,
    _block_id,
    _inline_run,
    _source_block,
    _source_line,
    _strip_list_marker,
    _warning,
)


def _extract_textual(
    *,
    document_id: str,
    filename: str,
    data: bytes,
    source_kind: str,
    warnings: list[ExtractionWarning] | None = None,
) -> ExtractionOutput:
    text = data.decode("utf-8", errors="ignore")
    if not text.strip():
        text = data.decode("latin-1", errors="ignore")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        lines = [Path(filename).stem or "Untitled document"]
    source_lines: list[dict[str, Any]] = []
    source_blocks: list[dict[str, Any]] = []
    heading_path: list[str] = []
    for index, line_text in enumerate(lines, start=1):
        block_type = _textual_block_type(line_text, index)
        block_id = _block_id(filename, index, line_text)
        source_line = _source_line(
            document_id=document_id,
            line_number=index,
            page=1,
            text=line_text,
            font_size=18 if block_type == "heading" else 11,
            bold=block_type == "heading",
            style_name=source_kind,
            block_id=block_id,
        )
        source_lines.append(source_line)
        if block_type == "heading":
            heading_path = [block_id]
        source_blocks.append(
            _source_block(
                document_id=document_id,
                block_id=block_id,
                line_id=source_line["line_id"],
                block_type=block_type,
                text=_strip_list_marker(line_text),
                page=1,
                order=index,
                heading_path_ids=heading_path if block_type != "heading" else [],
                inferred_level=1 if block_type == "heading" else None,
                font_size=18 if block_type == "heading" else 11,
                font_family=None,
                bold=block_type == "heading",
                style_name=source_kind,
                inline_runs=[_inline_run(_strip_list_marker(line_text), 0, len(_strip_list_marker(line_text)), [])],
            )
        )
    current_warnings = list(warnings or [])
    if not any(block["block_type"] == "heading" for block in source_blocks):
        current_warnings.append(_warning("quality.low_heading_signal", "No high-confidence heading was found."))
    return _assemble_output(
        document_id=document_id,
        filename=filename,
        blocks=source_blocks,
        source_lines=source_lines,
        warnings=current_warnings,
        assets=[],
        source_kind=source_kind,
    )


def _textual_block_type(text: str, index: int) -> str:
    if _looks_like_heading(text, index):
        return "heading"
    if re.match(r"^\s*(\d+[\.)]|[-*])\s+", text) or re.match(
        r"^(click|select|press|open|choose|install|run|enter|verify)\b",
        text,
        flags=re.I,
    ):
        return "procedure_step"
    if "|" in text:
        return "table_row"
    if re.search(r"\b(warning|caution)\b", text, flags=re.I):
        return "warning"
    if re.search(r"\b(note|tip)\b", text, flags=re.I):
        return "note"
    return "paragraph"


def _looks_like_heading(text: str, index: int) -> bool:
    """Heuristic: does `text` at position `index` look like a heading?

    Step D1 fix (folds Finding A.1 from Step A): the prior implementation
    short-circuited to `True` for ANY short text at `index == 1`, even when
    that text ended in terminal punctuation (`.`, `:`, `;`, `,`). That
    misclassified a normal opening sentence like "This is a sentence." as
    a heading whenever it happened to land at position 1. The terminal-
    punctuation guard now runs FIRST so position-1 doesn't override it.

    Also: the prior `endswith` tuple was `(".", ":", ";", ",")` while the
    DOCX layered classifier's dotted-heading check used the wider
    `(".", "!", "?", ";", ":", ",")` set. Step D1 unifies both via the
    `_HEADING_TERMINAL_PUNCTUATION` module-level constant so the three
    classifier paths can't drift.
    """
    stripped = text.strip().strip("#")
    if len(stripped) > 90 or stripped.endswith(_HEADING_TERMINAL_PUNCTUATION):
        return False
    if index == 1 and len(stripped) >= 1:
        return True
    if re.match(r"^\d+(\.\d+)*\s+[A-Z]", stripped):
        return True
    words = stripped.split()
    return 1 <= len(words) <= 8 and sum(word[:1].isupper() for word in words) >= max(1, len(words) // 2)


def _html_to_text(data: bytes) -> str:
    text = data.decode("utf-8", errors="ignore")
    text = re.sub(r"<(h[1-6]|p|li|tr|br)\b[^>]*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return "\n".join(line.strip() for line in text.splitlines() if line.strip())
