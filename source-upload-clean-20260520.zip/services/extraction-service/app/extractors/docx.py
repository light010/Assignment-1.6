from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from ditagen_common.locator import (
    format_docx_endnote_locator,
    format_docx_footnote_locator,
    format_docx_nested_table_row_locator,
    format_docx_paragraph_locator,
    format_docx_table_row_locator,
)

from .common import (
    ExtractionOutput,
    ExtractionWarning,
    _assemble_output,
    _block_id,
    _inline_run,
    _source_block,
    _source_line,
    _strip_list_marker,
    _warning,
    _with_extra_warning,
)
from .docx_helpers import (
    _docx_block_type,
    _docx_body_items,
    _docx_caption_candidates,
    _docx_cell_shape,
    _docx_formatting_heading_threshold,
    _docx_numbering,
    _docx_numbering_with_label,
    _docx_paragraph_image_asset_ids,
    _docx_runs,
    _docx_visible_text,
    _emit_docx_header_footer_blocks,
    _extract_docx_assets,
    _extract_docx_notes,
)
from .heading_classifier import _make_review_flag
from .textual import _extract_textual


def _extract_docx(*, document_id: str, filename: str, data: bytes) -> ExtractionOutput:
    try:
        from docx import Document
    except Exception as exc:  # pragma: no cover - dependency is declared, this guards broken envs.
        warning = _warning(
            "dependency.python_docx_unavailable",
            f"python-docx is unavailable, falling back to plain text extraction: {exc}",
        )
        fallback = _extract_textual(document_id=document_id, filename=filename, data=data, source_kind="docx")
        return _with_extra_warning(fallback, warning)

    with tempfile.TemporaryDirectory(prefix="ditagen-docx-") as tmp_dir:
        tmp = Path(tmp_dir) / "input.docx"
        tmp.write_bytes(data)
        document = Document(str(tmp))
        blocks: list[dict[str, Any]] = []
        source_lines: list[dict[str, Any]] = []
        warnings: list[ExtractionWarning] = []
        heading_path: list[str] = []
        captions_by_position = _docx_caption_candidates(document)
        position = 0

        paragraph_index = 0
        table_index = 0
        body_index = 0
        numbering_state: dict[str, list[int]] = {}
        formatting_threshold = _docx_formatting_heading_threshold(document)
        for kind, item in _docx_body_items(document):
            if kind == "paragraph":
                paragraph = item
                # Step D2: filter `<w:vanish/>` runs out of the visible text
                # before applying the canonical empty rule. The visibility
                # decision lives in `_docx_visible_text` and is mirrored in
                # `_docx_runs` so block-level `text` and `inline_runs` agree
                # on which run offsets are visible. If we observed any
                # filtered runs, emit `HIDDEN_TEXT_DROPPED` review_flag
                # below so triage can confirm the dropped content was
                # intentional rather than a producer bug.
                visible_text_raw, has_hidden_runs = _docx_visible_text(paragraph)
                text = visible_text_raw.strip()
                # Canonical empty rule: a paragraph is a body-index slot if it
                # carries text OR references image assets. Frontend
                # `collectDocxCandidates` must apply the same predicate; any
                # divergence shifts the locator index from that point forward.
                image_asset_ids = _docx_paragraph_image_asset_ids(paragraph, document)
                if not text and not image_asset_ids:
                    continue
                section = format_docx_paragraph_locator(body_index)
                body_index += 1
                paragraph_index += 1
                position += 1
                style_name = paragraph.style.name if paragraph.style is not None else None
                is_image_only = not text and bool(image_asset_ids)
                if is_image_only:
                    block_type = "figure"
                    level = None
                    style_source = "figure"
                    initial_heading_confidence = None
                else:
                    block_type, level, style_source, initial_heading_confidence = _docx_block_type(
                        paragraph,
                        text,
                        position,
                        formatting_threshold=formatting_threshold,
                    )
                block_text = "" if is_image_only else _strip_list_marker(text)
                block_id = _block_id(filename, position, text or f"figure:{image_asset_ids[0]}")
                line = _source_line(
                    document_id=document_id,
                    line_number=position,
                    page=None,
                    section=section,
                    text=text if not is_image_only else "",
                    font_size=18 if block_type == "heading" else 11,
                    bold=block_type == "heading",
                    style_name=style_name,
                    block_id=block_id,
                )
                source_lines.append(line)
                review_flags: list[dict[str, Any]] = []
                if block_type == "heading" and style_source in {"formatting", "numbering"}:
                    review_flags.append(
                        _make_review_flag(
                            "HEADING_BY_FORMATTING",
                            message=f"Heading inferred from {style_source} signals rather than explicit Heading style.",
                        )
                    )
                if has_hidden_runs:
                    # Step D2: one or more <w:vanish/> runs were filtered
                    # from this paragraph's text. The dropped content may
                    # be intentional (Word's built-in "Hidden" character
                    # format) or a producer bug — triage reviewers must
                    # confirm by inspecting the source.
                    review_flags.append(
                        _make_review_flag(
                            "HIDDEN_TEXT_DROPPED",
                            message=(
                                "One or more <w:vanish/> runs were filtered from this paragraph. "
                                "Open the source file to confirm the dropped content was intentional."
                            ),
                        )
                    )
                inline_runs = [] if is_image_only else _docx_runs(paragraph, block_text)
                bold_flag = (
                    False
                    if is_image_only
                    else (block_type == "heading" or any(run.bold for run in paragraph.runs))
                )
                numbering = _docx_numbering(paragraph)
                if numbering:
                    numbering = _docx_numbering_with_label(numbering, numbering_state)
                blocks.append(
                    _source_block(
                        document_id=document_id,
                        block_id=block_id,
                        line_id=line["line_id"],
                        block_type=block_type,
                        text=block_text,
                        page=None,
                        section=section,
                        order=position,
                        heading_path_ids=heading_path if block_type != "heading" else [],
                        inferred_level=level,
                        font_size=18 if block_type == "heading" else 11,
                        font_family=None,
                        bold=bold_flag,
                        style_name=style_name,
                        inline_runs=inline_runs,
                        asset_refs=image_asset_ids,
                        extra={
                            "numbering": numbering,
                            "caption_candidate": captions_by_position.get(paragraph_index),
                            "char_start": 0,
                            "char_end": len(block_text),
                            "review_flags": review_flags,
                            "confidence_signals": {
                                "style_source": style_source,
                                "initial_heading_confidence": initial_heading_confidence,
                            },
                        },
                    )
                )
                if block_type == "heading":
                    heading_path = [block_id]
                continue

            table = item
            non_empty_rows = [
                (row_index, row, [_docx_cell_shape(cell) for cell in row.cells])
                for row_index, row in enumerate(table.rows, start=1)
            ]
            non_empty_rows = [
                (row_index, row, cells)
                for row_index, row, cells in non_empty_rows
                if any(cell["text"] for cell in cells)
            ]
            if not non_empty_rows:
                continue
            table_body_index = body_index
            body_index += 1
            table_index += 1
            table_id = f"tbl_{table_index:03d}"
            # Step E: capture pending nested-table emissions per outer row so
            # we can interleave them right after the owning outer row block.
            # Inner tables are numbered cumulatively across all cells of the
            # outer row (the locator grammar has no cell axis), matching what
            # the rendered docx-preview HTML produces.
            for row_index, row, cells in non_empty_rows:
                position += 1
                text = " | ".join(cell["text"] for cell in cells)
                section = format_docx_table_row_locator(table_body_index, row_index)
                block_id = _block_id(filename, position, text)
                line = _source_line(
                    document_id=document_id,
                    line_number=position,
                    page=None,
                    section=section,
                    text=text,
                    font_size=11,
                    bold=False,
                    style_name="Table",
                    block_id=block_id,
                )
                source_lines.append(line)
                outer_review_flags: list[dict[str, Any]] = []
                row_inner_tables = [
                    (cell_idx, inner_table)
                    for cell_idx, cell in enumerate(row.cells)
                    for inner_table in cell.tables
                ]
                if row_inner_tables:
                    outer_review_flags.append(
                        _make_review_flag(
                            "NESTED_TABLE",
                            message=(
                                f"Outer row contains {len(row_inner_tables)} nested table(s). "
                                "Inner rows are emitted as separate blocks with "
                                "`docx:tbl:{outer}:r:{row}:tbl:{N}:r:{M}` locators."
                            ),
                        )
                    )
                blocks.append(
                    _source_block(
                        document_id=document_id,
                        block_id=block_id,
                        line_id=line["line_id"],
                        block_type="table_row",
                        text=text,
                        page=None,
                        section=section,
                        order=position,
                        heading_path_ids=heading_path,
                        inferred_level=None,
                        font_size=11,
                        font_family=None,
                        bold=False,
                        style_name="Table",
                        inline_runs=[_inline_run(text, 0, len(text), [])],
                        extra={
                            "table_id": table_id,
                            "row_index": row_index,
                            "cells": cells,
                            "char_start": 0,
                            "char_end": len(text),
                            "review_flags": outer_review_flags,
                        },
                    )
                )
                # Step E: emit inner table rows directly after the owning
                # outer row. Each inner table gets its own `table_id` slot so
                # ORPHAN_TABLE_ROW logic and structure_tree consumers can
                # reason about inner-row sibling counts without confusing
                # them with outer rows. Deep nesting (3+ levels) is bounded:
                # we DO NOT descend into doubly-nested tables, but we emit a
                # DEEP_NESTING_UNSUPPORTED flag on the inner row so triage
                # knows content was dropped.
                for inner_seq, (_cell_idx, inner_table) in enumerate(row_inner_tables):
                    inner_non_empty = [
                        (inner_row_index, inner_row, [_docx_cell_shape(c) for c in inner_row.cells])
                        for inner_row_index, inner_row in enumerate(inner_table.rows, start=1)
                    ]
                    inner_non_empty = [
                        (idx, ir, cs) for idx, ir, cs in inner_non_empty if any(c["text"] for c in cs)
                    ]
                    if not inner_non_empty:
                        continue
                    table_index += 1
                    inner_table_id = f"tbl_{table_index:03d}"
                    for inner_row_index, inner_row, inner_cells in inner_non_empty:
                        position += 1
                        inner_text = " | ".join(c["text"] for c in inner_cells)
                        inner_section = format_docx_nested_table_row_locator(
                            table_body_index, row_index, inner_seq, inner_row_index
                        )
                        inner_block_id = _block_id(filename, position, inner_text)
                        inner_line = _source_line(
                            document_id=document_id,
                            line_number=position,
                            page=None,
                            section=inner_section,
                            text=inner_text,
                            font_size=11,
                            bold=False,
                            style_name="Table",
                            block_id=inner_block_id,
                        )
                        source_lines.append(inner_line)
                        inner_flags: list[dict[str, Any]] = []
                        if any(c.tables for c in inner_row.cells):
                            inner_flags.append(
                                _make_review_flag(
                                    "DEEP_NESTING_UNSUPPORTED",
                                    message=(
                                        "This nested-table row contains a further-nested table. "
                                        "v1 emits at most one level of nesting; the deeper table's "
                                        "content was not extracted."
                                    ),
                                )
                            )
                        blocks.append(
                            _source_block(
                                document_id=document_id,
                                block_id=inner_block_id,
                                line_id=inner_line["line_id"],
                                block_type="table_row",
                                text=inner_text,
                                page=None,
                                section=inner_section,
                                order=position,
                                heading_path_ids=heading_path,
                                inferred_level=None,
                                font_size=11,
                                font_family=None,
                                bold=False,
                                style_name="Table",
                                inline_runs=[_inline_run(inner_text, 0, len(inner_text), [])],
                                extra={
                                    "table_id": inner_table_id,
                                    "row_index": inner_row_index,
                                    "cells": inner_cells,
                                    "char_start": 0,
                                    "char_end": len(inner_text),
                                    "review_flags": inner_flags,
                                },
                            )
                        )

        assets = _extract_docx_assets(data)
        if not blocks:
            warnings.append(_warning("quality.empty_docx", "No readable DOCX paragraphs were found."))
            return _extract_textual(document_id=document_id, filename=filename, data=data, source_kind="docx", warnings=warnings)
        if not any(block["block_type"] == "heading" for block in blocks):
            warnings.append(_warning("quality.low_heading_signal", "No high-confidence heading styles were found."))

        # Step D4: footnote/endnote streams ship as separate `block_type="note"`
        # source blocks. They live outside the body iteration (no body_index
        # slot, no heading_path) and use their own locator namespace
        # (`docx:footnote:N` / `docx:endnote:N`). Append after the body
        # blocks so source-block order is "body, then notes" — consumers
        # that walk source_blocks linearly get a stable position for note
        # content.
        for note in _extract_docx_notes(data):
            position += 1
            note_section = (
                format_docx_footnote_locator(note.note_id)
                if note.kind == "footnote"
                else format_docx_endnote_locator(note.note_id)
            )
            note_block_id = _block_id(filename, position, f"{note.kind}:{note.note_id}:{note.text}")
            note_line = _source_line(
                document_id=document_id,
                line_number=position,
                page=None,
                section=note_section,
                text=note.text,
                font_size=11,
                bold=False,
                style_name=f"{note.kind.capitalize()}Text",
                block_id=note_block_id,
            )
            source_lines.append(note_line)
            blocks.append(
                _source_block(
                    document_id=document_id,
                    block_id=note_block_id,
                    line_id=note_line["line_id"],
                    block_type="note",
                    text=note.text,
                    page=None,
                    section=note_section,
                    order=position,
                    heading_path_ids=[],
                    inferred_level=None,
                    font_size=11,
                    font_family=None,
                    bold=False,
                    style_name=f"{note.kind.capitalize()}Text",
                    inline_runs=[_inline_run(note.text, 0, len(note.text), [])],
                    extra={
                        "char_start": 0,
                        "char_end": len(note.text),
                        "confidence_signals": {
                            "style_source": "style_name",
                            "source_kind": note.kind,
                        },
                    },
                )
            )

        # Step E: walk every section's primary header + footer. These
        # paragraphs live outside the body stream (no body_index slot, no
        # heading_path) and ship with their own locator namespace
        # (`docx:hdr:section-N:p:M` / `docx:ftr:section-N:p:M`). Block type
        # is `running_header` / `running_footer` so the schema's
        # `BlockType` enum, the workbench triage queue, and the structure-
        # tree consumer all recognize them as orthogonal to the body. v1
        # only walks the primary header/footer (Word also supports first-
        # page and even-page variants; tracked as a known gap rather than
        # silent best-effort).
        position = _emit_docx_header_footer_blocks(
            document=document,
            document_id=document_id,
            filename=filename,
            position=position,
            blocks=blocks,
            source_lines=source_lines,
        )
        return _assemble_output(
            document_id=document_id,
            filename=filename,
            blocks=blocks,
            source_lines=source_lines,
            warnings=warnings,
            assets=assets,
            source_kind="docx",
            source_bytes=data,
        )
