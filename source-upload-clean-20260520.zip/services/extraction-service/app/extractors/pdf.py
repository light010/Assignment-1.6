from __future__ import annotations

import re
from typing import Any

from ditagen_common.artifacts import sha256_bytes

from .common import (
    ExtractedAsset,
    ExtractionOutput,
    ExtractionWarning,
    _assemble_output,
    _block_id,
    _content_type_for_extension,
    _heading_font_threshold,
    _inline_run,
    _source_block,
    _source_line,
    _strip_list_marker,
    _warning,
    _with_extra_warning,
)
from .textual import _extract_textual, _textual_block_type


def _extract_pdf(*, document_id: str, filename: str, data: bytes) -> ExtractionOutput:
    try:
        import fitz
    except Exception as exc:  # pragma: no cover - dependency is declared, this guards broken envs.
        warning = _warning("dependency.pymupdf_unavailable", f"PyMuPDF is unavailable: {exc}")
        fallback = _extract_textual(document_id=document_id, filename=filename, data=data, source_kind="pdf")
        return _with_extra_warning(fallback, warning)

    doc = fitz.open(stream=data, filetype="pdf")
    raw_blocks: list[dict[str, Any]] = []
    header_footer: list[dict[str, Any]] = []
    warnings: list[ExtractionWarning] = []
    assets: list[ExtractedAsset] = []
    seen_asset_hashes: set[str] = set()
    total_chars = 0
    image_page_count = 0

    for page_index, page in enumerate(doc, start=1):
        page_dict = page.get_text("dict")
        page_width = float(page.rect.width)
        page_height = float(page.rect.height)
        page_images = page.get_images(full=True)
        if page_images:
            image_page_count += 1
        for image in page_images:
            xref = image[0]
            extracted = doc.extract_image(xref)
            content = extracted.get("image") or b""
            if not content:
                continue
            digest = sha256_bytes(content)
            if digest in seen_asset_hashes:
                continue
            seen_asset_hashes.add(digest)
            ext = extracted.get("ext") or "bin"
            width = extracted.get("width")
            height = extracted.get("height")
            assets.append(
                ExtractedAsset(
                    name=f"pdf-image-{page_index}-{xref}.{ext}",
                    content=content,
                    content_type=_content_type_for_extension(f".{ext}"),
                    width=int(width) if width else None,
                    height=int(height) if height else None,
                )
            )
        order = 0
        for block in page_dict.get("blocks", []):
            if block.get("type") != 0:
                continue
            lines = block.get("lines", [])
            text = "\n".join(
                "".join(span.get("text", "") for span in line.get("spans", [])).strip()
                for line in lines
            ).strip()
            if not text:
                continue
            spans = [span for line in lines for span in line.get("spans", [])]
            sizes = [float(span.get("size") or 0) for span in spans if span.get("size")]
            first_span = spans[0] if spans else {}
            bbox = [round(float(value), 2) for value in block.get("bbox", [0, 0, 0, 0])]
            order += 1
            total_chars += len(text)
            raw_blocks.append(
                {
                    "text": text,
                    "page": page_index,
                    "order": order,
                    "bbox": bbox,
                    "page_width": page_width,
                    "page_height": page_height,
                    "font_size": sum(sizes) / len(sizes) if sizes else 11,
                    "font_family": first_span.get("font"),
                    "bold": bool(int(first_span.get("flags") or 0) & 2)
                    or "bold" in str(first_span.get("font") or "").lower(),
                }
            )

    repeated = _pdf_repeated_running_content(raw_blocks, max(1, len(doc)))
    source_lines: list[dict[str, Any]] = []
    source_blocks: list[dict[str, Any]] = []
    heading_path: list[str] = []
    font_sizes = [block["font_size"] for block in raw_blocks if block["text"] not in repeated]
    threshold = _heading_font_threshold(font_sizes)
    content_position = 0
    for raw in raw_blocks:
        if raw["text"] in repeated:
            header_footer.append(raw)
            continue
        content_position += 1
        is_heading = threshold is not None and raw["font_size"] >= threshold and len(raw["text"]) <= 80
        block_type = "heading" if is_heading else _textual_block_type(raw["text"], content_position)
        block_id = _block_id(filename, content_position, raw["text"])
        line = _source_line(
            document_id=document_id,
            line_number=content_position,
            page=raw["page"],
            text=raw["text"],
            font_size=raw["font_size"],
            bold=raw["bold"],
            style_name=None,
            block_id=block_id,
        )
        source_lines.append(line)
        if block_type == "heading":
            heading_path = [block_id]
        source_blocks.append(
            _source_block(
                document_id=document_id,
                block_id=block_id,
                line_id=line["line_id"],
                block_type=block_type,
                text=_strip_list_marker(raw["text"]),
                page=raw["page"],
                order=raw["order"],
                heading_path_ids=heading_path if block_type != "heading" else [],
                inferred_level=1 if block_type == "heading" else None,
                font_size=raw["font_size"],
                font_family=raw["font_family"],
                bold=raw["bold"],
                style_name=None,
                inline_runs=[_inline_run(_strip_list_marker(raw["text"]), 0, len(_strip_list_marker(raw["text"])), [])],
                extra={
                    "bbox": raw["bbox"],
                    "is_likely_heading": is_heading,
                    "confidence_signals": {
                        "font_size_zscore": round(raw["font_size"] - (threshold or raw["font_size"]), 3),
                        "header_footer_filtered": False,
                    },
                },
            )
        )

    if total_chars / max(1, len(doc)) < 30 and image_page_count:
        warnings.append(
            _warning(
                "quality.scanned_or_image_only",
                "The PDF appears to be scanned or image-heavy; OCR is not enabled in Week 3.",
            )
        )
    if threshold is None:
        warnings.append(_warning("quality.low_heading_signal", "PDF font signals did not identify stable headings."))
    if not source_blocks:
        fallback = _extract_textual(document_id=document_id, filename=filename, data=data, source_kind="pdf", warnings=warnings)
        return fallback
    return _assemble_output(
        document_id=document_id,
        filename=filename,
        blocks=source_blocks,
        source_lines=source_lines,
        warnings=warnings,
        assets=assets,
        header_footer=header_footer,
        source_kind="pdf",
    )


def _pdf_repeated_running_content(raw_blocks: list[dict[str, Any]], page_count: int) -> set[str]:
    by_text: dict[str, set[int]] = {}
    top_or_bottom: dict[str, bool] = {}
    for block in raw_blocks:
        text = re.sub(r"\s+", " ", block["text"]).strip()
        if len(text) > 120:
            continue
        y0, y1 = block["bbox"][1], block["bbox"][3]
        page_height = block["page_height"]
        in_running_band = y0 < page_height * 0.12 or y1 > page_height * 0.88
        if not in_running_band:
            continue
        by_text.setdefault(text, set()).add(int(block["page"]))
        top_or_bottom[text] = True
    return {
        text
        for text, pages in by_text.items()
        if top_or_bottom.get(text) and len(pages) / max(1, page_count) >= 0.6 and page_count > 1
    }
