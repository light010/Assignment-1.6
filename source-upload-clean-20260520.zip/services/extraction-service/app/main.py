from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, TypedDict

from ditagen_common.artifacts import read_artifact_text, write_artifact
from ditagen_common.auth import context_headers, current_user
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import request_service
from ditagen_common.store import utc_now
from ditagen_common.store_factory import create_store
from extractors import EXTRACTOR_VERSION, ExtractedAsset, extract_document
from fastapi import Depends, HTTPException, Request

from contracts import (
    ArtifactRef,
    ExtractionError,
    ExtractionRequest,
    ExtractionStatus,
    TriageEntry,
    TriageQueueResponse,
)

BUSINESS_UNIT_SERVICE_URL = os.getenv(
    "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
)

app = create_service_app("extraction-service")
store = create_store("extraction-service")

class Metrics(TypedDict):
    success: int
    failed: int
    warnings: dict[str, int]
    artifact_bytes: int


METRICS: Metrics = {
    "success": 0,
    "failed": 0,
    "warnings": {},
    "artifact_bytes": 0,
}


def extraction_metrics() -> str:
    lines = [
        f'extraction_documents_total{{outcome="{outcome}"}} {count}'
        for outcome, count in (("success", METRICS["success"]), ("failed", METRICS["failed"]))
    ]
    for kind, count in sorted(METRICS["warnings"].items()):
        lines.append(f'extraction_warnings_total{{kind="{kind}"}} {count}')
    lines.append(f"markdown_artifact_bytes {METRICS['artifact_bytes']}")
    lines.append("extraction_service_up 1")
    return "\n".join(lines) + "\n"


app.state.metrics_provider = extraction_metrics


def event(action: str, **metadata: Any) -> dict[str, Any]:
    return {"action": action, "occurred_at": utc_now(), "metadata": metadata}


def status_from_record(record: dict[str, Any]) -> ExtractionStatus:
    return ExtractionStatus.model_validate(record)


def save_status(record: dict[str, Any]) -> ExtractionStatus:
    def save(state: dict[str, Any]) -> dict[str, Any]:
        state["extractions"][record["extraction_id"]] = record
        return record

    return status_from_record(store.mutate(save))


def update_status(extraction_id: str, patch: dict[str, Any]) -> ExtractionStatus:
    def update(state: dict[str, Any]) -> dict[str, Any]:
        record = state["extractions"][extraction_id]
        record.update(patch)
        return record

    return status_from_record(store.mutate(update))


def artifact_ref(entry: dict[str, Any]) -> ArtifactRef:
    return ArtifactRef.model_validate(entry)


def write_jsonl(
    *,
    project_id: str,
    document_id: str,
    name: str,
    rows: list[dict[str, Any]],
    created_by: str,
) -> dict[str, Any]:
    content = "\n".join(json.dumps(row, sort_keys=True) for row in rows)
    if content:
        content += "\n"
    return write_artifact(
        project_id=project_id,
        document_id=document_id,
        name=name,
        content=content,
        content_type="application/x-jsonlines",
        store=store,
        created_by=created_by,
        producer="extraction-service",
    )


def write_asset_artifacts(
    *,
    project_id: str,
    document_id: str,
    assets: list[ExtractedAsset],
    manifest: dict[str, Any],
    created_by: str,
) -> list[dict[str, Any]]:
    refs: list[dict[str, Any]] = []
    by_name = {asset.name: asset for asset in assets}
    for manifest_asset in manifest.get("assets", []):
        asset = by_name.get(manifest_asset["filename"])
        if asset is None:
            continue
        refs.append(
            write_artifact(
                project_id=project_id,
                document_id=document_id,
                name=manifest_asset["dita_href"],
                content=asset.content,
                content_type=asset.content_type,
                store=store,
                created_by=created_by,
                producer="extraction-service",
            )
        )
    return refs


@app.post("/internal/extractions", response_model=ExtractionStatus)
def create_extraction(
    payload: ExtractionRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> ExtractionStatus:
    if payload.requested_by != user["user_id"] and "org_admin" not in user.get("roles", []):
        raise HTTPException(status_code=403, detail="Extraction requester does not match bearer token")
    original_path = Path(payload.artifact_path)
    extraction_id = payload.document_id
    started_at = utc_now()
    base_record = {
        "extraction_id": extraction_id,
        "document_id": payload.document_id,
        "business_unit_id": payload.business_unit_id,
        "project_id": payload.project_id,
        "stage": "extracting",
        "started_at": started_at,
        "finished_at": None,
        "error": None,
        "artifacts": [],
        "warnings": [],
        "quality_gate": None,
        "events": [
            event(
                "extraction.started",
                request_id=payload.request_id,
                filename=payload.filename,
                content_type=payload.content_type,
            )
        ],
        "block_count": 0,
        "asset_count": 0,
    }
    save_status(base_record)
    if not original_path.exists():
        return fail_extraction(
            extraction_id=extraction_id,
            stage="extracting",
            kind="source_artifact_missing",
            message=f"Source artifact does not exist: {payload.artifact_path}",
            retryable=False,
        )

    try:
        data = original_path.read_bytes()
        output = extract_document(
            document_id=payload.document_id,
            filename=payload.filename,
            content_type=payload.content_type,
            data=data,
        )
        refs = [
            write_jsonl(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="source-lines.jsonl",
                rows=output.source_lines,
                created_by=payload.requested_by,
            ),
            write_jsonl(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="source-blocks.jsonl",
                rows=output.source_blocks,
                created_by=payload.requested_by,
            ),
            write_artifact(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="style-profile.json",
                content=output.style_profile,
                store=store,
                created_by=payload.requested_by,
                producer="extraction-service",
            ),
            write_artifact(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="structure-tree.json",
                content=output.structure_tree,
                store=store,
                created_by=payload.requested_by,
                producer="extraction-service",
            ),
            write_artifact(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="asset-manifest.json",
                content=output.asset_manifest,
                store=store,
                created_by=payload.requested_by,
                producer="extraction-service",
            ),
            write_artifact(
                project_id=payload.project_id,
                document_id=payload.document_id,
                name="extraction-quality.json",
                content=output.extraction_quality,
                store=store,
                created_by=payload.requested_by,
                producer="extraction-service",
            ),
        ]
        if output.header_footer:
            refs.append(
                write_jsonl(
                    project_id=payload.project_id,
                    document_id=payload.document_id,
                    name="header-footer.jsonl",
                    rows=output.header_footer,
                    created_by=payload.requested_by,
                )
            )
        refs.extend(
            write_asset_artifacts(
                project_id=payload.project_id,
                document_id=payload.document_id,
                assets=output.assets,
                manifest=output.asset_manifest,
                created_by=payload.requested_by,
            )
        )
        update_status(
            extraction_id,
            {
                "stage": "markdown_projecting",
                "events": [
                    *store.read()["extractions"][extraction_id]["events"],
                    event("extraction.completed", block_count=len(output.source_blocks), asset_count=len(output.assets)),
                    event("markdown.started", extractor_version=EXTRACTOR_VERSION),
                ],
                "block_count": len(output.source_blocks),
                "asset_count": len(output.assets),
            },
        )
        markdown_ref = write_artifact(
            project_id=payload.project_id,
            document_id=payload.document_id,
            name="content.md",
            content=output.markdown,
            content_type="text/markdown",
            store=store,
            created_by=payload.requested_by,
            producer="markdown-service",
        )
        refs.append(markdown_ref)
        artifact_refs = [artifact_ref(ref).model_dump(mode="json") for ref in refs]
        warning_payloads = [warning.model_dump(mode="json") for warning in output.warnings]
        for warning in output.warnings:
            METRICS["warnings"][warning.kind] = METRICS["warnings"].get(warning.kind, 0) + 1
        METRICS["success"] += 1
        METRICS["artifact_bytes"] += markdown_ref["size_bytes"]
        current = store.read()["extractions"][extraction_id]
        return update_status(
            extraction_id,
            {
                "stage": "markdown_complete",
                "finished_at": utc_now(),
                "artifacts": artifact_refs,
                "warnings": warning_payloads,
                "quality_gate": output.extraction_quality["gate"],
                "events": [
                    *current["events"],
                    event(
                        "markdown.completed",
                        bytes=markdown_ref["size_bytes"],
                        hash=markdown_ref["hash"],
                    ),
                    event(
                        "extraction.gate.evaluated",
                        gate_name=output.extraction_quality["gate"]["name"],
                        passed=output.extraction_quality["gate"]["passed"],
                        severity=output.extraction_quality["gate"]["severity"],
                        blocking_reasons=output.extraction_quality["gate"]["blocking_reasons"],
                        located_pct=(
                            output.extraction_quality["metrics"]["located_source_blocks"]
                            / max(1, output.extraction_quality["metrics"]["total_source_blocks"])
                        ),
                        structure_confidence=output.extraction_quality["metrics"]["structure_confidence"],
                        duration_ms=output.extraction_quality["runtime"]["duration_ms"],
                    ),
                    # Step I4: pandoc telemetry. The pandoc invocation
                    # always runs inside `_assemble_output` regardless of
                    # whether the gate passed; emit a separate event so
                    # operators can correlate gate outcomes with pandoc
                    # health. The success vs failure branch is decided
                    # by whether `projection_reason` was None in the
                    # producer (translated into `pandoc_version` being
                    # populated on success).
                    *_pandoc_telemetry_events(output.extraction_quality),
                ],
            },
        )
    except Exception as exc:
        return fail_extraction(
            extraction_id=extraction_id,
            stage="extracting",
            kind=exc.__class__.__name__,
            message=str(exc),
            retryable=False,
        )


def _pandoc_telemetry_events(extraction_quality: dict[str, Any]) -> list[dict[str, Any]]:
    """Step I4: emit `extraction.pandoc.invoked` on success, or
    `extraction.pandoc.failed` on failure, so operators can monitor
    pandoc health independently of the gate outcome.

    Failure is detected by the presence of one of the projector reasons
    in the gate's `blocking_reasons` list: pandoc_unavailable,
    pandoc_failed, pandoc_reordered, mdformat_unavailable,
    mdformat_plugin_missing. This mirrors what `PandocProjectorError`
    raises (locked by `test_pandoc_projector.py:test_projector_error_reasons_are_in_schema_enum`).
    """
    runtime = extraction_quality.get("runtime", {}) or {}
    blocking = extraction_quality.get("gate", {}).get("blocking_reasons") or []
    projector_failure_reasons = {
        "pandoc_unavailable",
        "pandoc_failed",
        "pandoc_reordered",
        "mdformat_unavailable",
        "mdformat_plugin_missing",
    }
    matched_failures = [r for r in blocking if r in projector_failure_reasons]
    if matched_failures:
        return [
            event(
                "extraction.pandoc.failed",
                reasons=matched_failures,
                pandoc_version=runtime.get("pandoc_version"),
                mdformat_version=runtime.get("mdformat_version"),
                stderr_warning_count=len(runtime.get("pandoc_warnings") or []),
            )
        ]
    return [
        event(
            "extraction.pandoc.invoked",
            pandoc_version=runtime.get("pandoc_version"),
            mdformat_version=runtime.get("mdformat_version"),
            duration_ms=runtime.get("duration_ms", 0),
            stderr_warning_count=len(runtime.get("pandoc_warnings") or []),
        )
    ]


def fail_extraction(
    *,
    extraction_id: str,
    stage: str,
    kind: str,
    message: str,
    retryable: bool,
) -> ExtractionStatus:
    METRICS["failed"] += 1
    state = store.read()
    current = state["extractions"].get(extraction_id)
    if not current:
        raise HTTPException(status_code=404, detail="Extraction not found")
    error = ExtractionError(kind=kind, message=message, stage="failed", retryable=retryable)
    return update_status(
        extraction_id,
        {
            "stage": "failed",
            "finished_at": utc_now(),
            "error": error.model_dump(mode="json"),
            "events": [
                *current.get("events", []),
                event("extraction.failed", stage=stage, error_kind=kind),
            ],
        },
    )


@app.get("/internal/extractions/{extraction_id}/status", response_model=ExtractionStatus)
async def get_extraction_status(
    extraction_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> ExtractionStatus:
    """Phase 4 D3.5.c.0: BU membership check via BU service.

    Was reading `state["business_unit_memberships"]` directly — a real
    cross-service boundary leak (plan §D3 finding #37). Now delegates
    to BU service's `GET /internal/business-units/{id}` which performs
    the same membership-based access check authoritatively. Same
    pattern as audit-service D2.6."""
    record = store.read()["extractions"].get(extraction_id)
    if not record:
        raise HTTPException(status_code=404, detail="Extraction not found")
    if "org_admin" not in user.get("roles", []):
        bu_id = record.get("business_unit_id")
        bu_response = await request_service(
            method="GET",
            base_url=BUSINESS_UNIT_SERVICE_URL,
            path=f"/internal/business-units/{bu_id}",
            headers=context_headers(request, user),
        )
        if bu_response.status_code != 200:
            raise HTTPException(status_code=404, detail="Extraction not found")
    return status_from_record(record)


def _min_confidence(confidence: dict[str, Any]) -> float:
    """Smallest non-null axis. Defaults to 1.0 if all axes are missing
    (which would be a producer bug — Phase 5's post-processor always
    sets `extraction` and `block_type`)."""
    values = [
        float(value)
        for value in confidence.values()
        if isinstance(value, int | float)
    ]
    return min(values) if values else 1.0


async def _ensure_extraction_visible(
    request: Request, extraction_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    """Phase 4 D3.5.c.0: BU access check via BU service.

    Was reading `state["business_unit_memberships"]` directly. Now
    delegates the membership check to BU service via `request_service`
    — the same access semantics, sourced from the authoritative
    BU-owned data."""
    record = store.read()["extractions"].get(extraction_id)
    if not record:
        raise HTTPException(status_code=404, detail="Extraction not found")
    if "org_admin" in user.get("roles", []):
        return record
    bu_id = record.get("business_unit_id")
    bu_response = await request_service(
        method="GET",
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/business-units/{bu_id}",
        headers=context_headers(request, user),
    )
    if bu_response.status_code != 200:
        raise HTTPException(status_code=404, detail="Extraction not found")
    return record


@app.get("/internal/documents/{document_id}/triage-queue", response_model=TriageQueueResponse)
async def get_triage_queue(
    document_id: str,
    request: Request,
    limit: int = 50,
    user: dict[str, Any] = Depends(current_user),
) -> TriageQueueResponse:
    """Return blocks ordered ascending by min(confidence) (Phase 5).

    Only blocks worth looking at land in `entries`: those with at least
    one `review_flag` OR a `min_confidence` below 0.7. Every-block-in-the-
    document is not what a reviewer wants — that's just the regular
    blocks endpoint.
    """
    record = await _ensure_extraction_visible(request, document_id, user)
    artifacts = record.get("artifacts", [])
    blocks_ref = next(
        (artifact for artifact in artifacts if artifact.get("name") == "source-blocks.jsonl"),
        None,
    )
    if blocks_ref is None:
        raise HTTPException(status_code=404, detail="source-blocks.jsonl artifact missing")
    blocks_text = read_artifact_text(blocks_ref)
    blocks = [
        json.loads(line) for line in blocks_text.splitlines() if line.strip()
    ]

    entries: list[TriageEntry] = []
    for block in blocks:
        confidence = block.get("confidence") or {}
        min_conf = _min_confidence(confidence)
        flags = block.get("review_flags") or []
        if not flags and min_conf >= 0.7:
            continue
        entries.append(
            TriageEntry(
                block_id=block["block_id"],
                document_id=block["document_id"],
                block_type=block["block_type"],
                text=(block.get("text") or "")[:280],
                page=(block.get("source_location") or {}).get("page"),
                order_in_page=block.get("order_in_page"),
                confidence={
                    axis: (float(value) if isinstance(value, int | float) else None)
                    for axis, value in confidence.items()
                },
                min_confidence=round(min_conf, 3),
                review_flags=flags,
            )
        )
    entries.sort(key=lambda entry: entry.min_confidence)
    return TriageQueueResponse(
        document_id=document_id,
        extractor_version=EXTRACTOR_VERSION,
        total_blocks=len(blocks),
        flagged_blocks=len(entries),
        entries=entries[: max(0, limit)],
    )
