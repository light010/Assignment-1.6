from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

ExtractionStage = Literal[
    "uploaded",
    "extracting",
    "extraction_complete",
    "markdown_projecting",
    "markdown_complete",
    "failed",
]

Producer = Literal["upload-service", "extraction-service", "markdown-service"]


class ExtractionRequest(BaseModel):
    document_id: str = Field(min_length=1)
    project_id: str = Field(min_length=1)
    business_unit_id: str = Field(min_length=1)
    filename: str = Field(min_length=1)
    content_type: str
    artifact_path: str = Field(min_length=1)
    request_id: str = Field(min_length=1)
    requested_by: str = Field(min_length=1)


class ArtifactRef(BaseModel):
    artifact_id: str
    document_id: str
    name: str
    artifact_version: int | str
    version: int | str
    content_type: str
    size_bytes: int
    hash: str
    sha256: str
    path: str
    producer: Producer
    created_at: str | None = None
    created_by: str | None = None
    previous_version_id: str | None = None


class ExtractionWarning(BaseModel):
    warning_id: str
    kind: str
    severity: Literal["info", "warning", "error"] = "warning"
    message: str
    source_block_ids: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExtractionError(BaseModel):
    kind: str
    message: str
    stage: ExtractionStage
    retryable: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExtractionStatus(BaseModel):
    extraction_id: str
    document_id: str
    business_unit_id: str
    project_id: str
    stage: ExtractionStage
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error: ExtractionError | None = None
    artifacts: list[ArtifactRef] = Field(default_factory=list)
    warnings: list[ExtractionWarning] = Field(default_factory=list)
    quality_gate: dict[str, Any] | None = None
    events: list[dict[str, Any]] = Field(default_factory=list)
    block_count: int = 0
    asset_count: int = 0


class TriageEntry(BaseModel):
    """A single block in the triage queue (Phase 5).

    Holds just enough payload for a workbench reviewer to spot the block:
    its identity, location, type, leading text, computed confidences, the
    derived `min_confidence` used for sorting, and the structured
    review-flag list. Full block details (inline_runs, cells, etc.) come
    from the regular block lookup once a block is selected.
    """

    block_id: str
    document_id: str
    block_type: str
    text: str
    page: int | None = None
    order_in_page: int | None = None
    confidence: dict[str, float | None]
    min_confidence: float = Field(ge=0.0, le=1.0)
    review_flags: list[dict[str, Any]] = Field(default_factory=list)


class TriageQueueResponse(BaseModel):
    document_id: str
    extractor_version: str
    total_blocks: int
    flagged_blocks: int
    entries: list[TriageEntry] = Field(default_factory=list)
