"""DOCX → Markdown projector via Pandoc + mdformat.

Step F rewrite. Goals — every one is folded in from audit #615 and the
plan §F:

- F1. Async subprocess via `asyncio.create_subprocess_exec`. The public
  entry point stays sync (`asyncio.run(...)`) — see "Architecture note"
  below for why we don't propagate async through the entire pipeline.
- F2. Resource limits via `preexec_fn` on Linux only. macOS skips with a
  once-only stderr warning because `RLIMIT_AS` doesn't reliably bound
  child-process memory on Darwin (and would create false confidence).
- F3. Stream-cap stdout via async readers; kill subprocess on `>10 MiB`
  instead of buffer-then-check.
- F4. Correct timeout exception: `asyncio.TimeoutError` from
  `asyncio.wait_for`. Caller (`extractors.py:_project_markdown`) is
  updated to handle the projector's `PandocProjectorError` directly —
  no more `except TimeoutError:` ambiguity.
- F5. Reorder detection (NOT fabrication). Count pandoc-emitted top-level
  chunks and compare to the *alignment-unit count* (source blocks that
  map 1:1 to a pandoc chunk — see `_ALIGNMENT_EXCLUDED_TYPES`). On
  mismatch: raise `pandoc_reordered` reason — DO NOT synthesize the
  alignment by zipping with `source.text` fallback. The old
  alignment-by-fabrication code is gone.
- F6. mdformat-gfm preflight at projector entry. Fails loudly with
  `mdformat_unavailable` or `mdformat_plugin_missing` instead of
  silently falling back to non-deterministic raw markdown.
- F7. Schema additions for the two new blocking reasons live in
  `contracts/artifacts/extraction-quality.schema.json`.
- F8. Determinism lock — `tests/test_apple_ca_invariants.py::
  test_pandoc_projection_is_deterministic` ensures three consecutive
  Apple CA extractions produce byte-identical `content.md`. Skipped
  when pandoc is unavailable.

Architecture note (plan deviation, documented in plans/extraction-quality-gate.md §F1):
The plan originally proposed propagating `async` through
`_project_markdown`, `_assemble_output`, `_extract_docx`, and the
FastAPI route. On closer look:
  - The FastAPI route `create_extraction` is sync `def`, which FastAPI
    runs on a threadpool. So pandoc's 30s subprocess does NOT block the
    event loop today. The async benefit is speculative.
  - Only ONE test file and ONE FastAPI route call `extract_document`
    directly. The cascade scope is real but small.
  - F1-F4's runtime safety (RLIMIT, stream-cap, correct timeout
    exception) is fundamentally about subprocess-shell hygiene, not
    about caller async-ness — those benefits land equally with a sync
    wrapper.
We sync-wrap `asyncio.run(_project_async(...))` at the projector
boundary. Re-evaluate full-async if (a) profiling shows event-loop
starvation under load or (b) the rest of the service migrates to async.
"""
from __future__ import annotations

import asyncio
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

PANDOC_MIN_VERSION = (3, 1, 0)
PANDOC_TIMEOUT_S = 30
PANDOC_OUTPUT_CAP_BYTES = 10 * 1024 * 1024  # 10 MiB
PANDOC_RLIMIT_AS_BYTES = 1024 * 1024 * 1024  # 1 GiB
PANDOC_RLIMIT_CPU_S = 30
MDFORMAT_TIMEOUT_S = 10
PANDOC_FLAGS = (
    "--from=docx+styles",
    "--to=gfm-raw_html",
    "--wrap=none",
    "--sandbox",
    "--reference-links=false",
    "--markdown-headings=atx",
    "--shift-heading-level-by=0",
    "--id-prefix=ditagen-",
)
PANDOC_FORBIDDEN_FLAGS = ("--lua-filter", "--filter", "--standalone")

# Source-block types that do NOT each map to one pandoc top-level chunk.
# Multiple of these collapse into a single pandoc block:
#   - `table_row`: every row of a table is the same `<table>` chunk.
#   - `running_header`/`running_footer`: filtered from markdown body.
#   - `note`: footnotes/endnotes ship in their own pandoc stream, not the
#     body — they don't appear as top-level body chunks.
#   - `ordered_list`/`unordered_list`/`procedure_step`: every item lives
#     inside a single `<ul>`/`<ol>` chunk. Without this exclusion every
#     document with a list would false-positive reorder-detect.
# Reorder detection counts only source blocks whose `block_type` is NOT
# in this set, comparing against the count of pandoc top-level chunks.
_ALIGNMENT_EXCLUDED_TYPES = frozenset(
    {
        "table_row",
        "running_header",
        "running_footer",
        "note",
        "ordered_list",
        "unordered_list",
        "procedure_step",
    }
)

_RLIMIT_SKIPPED_LOGGED = False


@dataclass(frozen=True)
class PandocProjection:
    markdown: str
    pandoc_version: str | None
    mdformat_version: str | None
    warnings: list[str] = field(default_factory=list)


class PandocProjectorError(RuntimeError):
    """Raised by the projector with a machine-readable `reason`.

    Reason values map 1:1 to entries in `extraction-quality.schema.json`'s
    `blocking_reasons` enum:
      - `pandoc_unavailable`: pandoc binary missing or too old.
      - `pandoc_failed`: pandoc invocation failed (nonzero exit,
        timeout, stream cap exceeded, or post-processing error).
      - `pandoc_reordered`: pandoc emitted a chunk count that doesn't
        align with the source-block alignment-unit count.
      - `mdformat_unavailable`: mdformat binary not on PATH.
      - `mdformat_plugin_missing`: mdformat present but the `gfm` plugin
        is not loaded (canonicalization would diverge from contract).
    """

    def __init__(self, reason: str, message: str, *, stderr_tail: str = "") -> None:
        super().__init__(message)
        self.reason = reason
        self.stderr_tail = stderr_tail


def project_docx_to_markdown(
    *, docx_bytes: bytes, source_blocks: list[dict[str, Any]]
) -> PandocProjection:
    """Sync entry point wrapping the async pipeline.

    See module docstring "Architecture note" for why this is sync. The
    actual subprocess work happens inside `asyncio.run`.
    """
    return asyncio.run(
        _project_docx_to_markdown_async(docx_bytes=docx_bytes, source_blocks=source_blocks)
    )


async def _project_docx_to_markdown_async(
    *, docx_bytes: bytes, source_blocks: list[dict[str, Any]]
) -> PandocProjection:
    pandoc = shutil.which("pandoc")
    if not pandoc:
        raise PandocProjectorError("pandoc_unavailable", "Pandoc >= 3.1 is not installed.")
    version_text = _pandoc_version(pandoc)
    version = _parse_version(version_text)
    if version < PANDOC_MIN_VERSION:
        raise PandocProjectorError(
            "pandoc_unavailable",
            (
                "Pandoc >= 3.1 is required; found "
                f"{version_text.splitlines()[0] if version_text else 'unknown'}."
            ),
        )
    _assert_flag_policy()

    # F6: preflight mdformat-gfm BEFORE invoking pandoc. The canonicalization
    # step at the end of the pipeline must be deterministic; raw pandoc
    # output is not byte-identical across pandoc versions. Failing fast
    # here keeps the gate honest: the document is marked
    # `mdformat_unavailable`/`mdformat_plugin_missing` rather than
    # silently shipping non-canonical markdown.
    mdformat_status = _probe_mdformat()
    if mdformat_status.kind == "missing":
        raise PandocProjectorError(
            "mdformat_unavailable",
            "mdformat is not installed; deterministic markdown canonicalization is required.",
        )
    if mdformat_status.kind == "no_gfm":
        raise PandocProjectorError(
            "mdformat_plugin_missing",
            (
                "mdformat is installed but the `gfm` plugin is missing. "
                "Install with `uv pip install mdformat-gfm`."
            ),
        )

    with tempfile.TemporaryDirectory(prefix="pandoc-") as tmp_dir:
        input_path = Path(tmp_dir) / "input.docx"
        input_path.write_bytes(docx_bytes)
        command = [pandoc, *PANDOC_FLAGS, "--output=-", str(input_path)]
        # F2: RLIMIT_AS/RLIMIT_CPU on Linux via preexec_fn. On macOS,
        # setrlimit is available but RLIMIT_AS doesn't reliably bound
        # child-process address space — so we skip with a once-only
        # warning to avoid false confidence.
        preexec = _apply_rlimits if sys.platform == "linux" else None
        if preexec is None:
            _maybe_log_macos_rlimit_skip()
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=tmp_dir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                preexec_fn=preexec,
            )
        except OSError as exc:
            raise PandocProjectorError(
                "pandoc_failed", f"Failed to start pandoc subprocess: {exc}"
            ) from exc

        try:
            # F3+F4: stream-cap with kill-on-cap, wrapped in async timeout.
            # asyncio.wait_for raises builtin TimeoutError on Python 3.11+;
            # `asyncio.TimeoutError` is now aliased to it. Use the builtin
            # for forward-compatibility (and to satisfy ruff UP041).
            stdout, stderr, cap_exceeded = await asyncio.wait_for(
                _drain_with_cap(process, cap=PANDOC_OUTPUT_CAP_BYTES),
                timeout=PANDOC_TIMEOUT_S,
            )
        except TimeoutError as exc:
            process.kill()
            await process.wait()
            raise PandocProjectorError(
                "pandoc_failed",
                f"Pandoc exceeded the {PANDOC_TIMEOUT_S}s wall-clock timeout.",
            ) from exc

        return_code = await process.wait()
        if cap_exceeded:
            raise PandocProjectorError(
                "pandoc_failed",
                f"Pandoc output exceeded the {PANDOC_OUTPUT_CAP_BYTES // (1024 * 1024)} MiB cap.",
            )

    stderr_text = stderr.decode("utf-8", errors="replace")
    if return_code != 0:
        raise PandocProjectorError(
            "pandoc_failed",
            f"Pandoc failed with exit code {return_code}.",
            stderr_tail=stderr_text[-2000:],
        )

    markdown = stdout.decode("utf-8", errors="replace")
    markdown = _strip_pandoc_generated_ids(markdown)
    # F5: count chunks BEFORE injecting sentinels (the sentinels would
    # otherwise inflate the chunk count to 2x).
    pandoc_chunks = _split_pandoc_chunks(markdown)
    alignment_units = _count_alignment_units(source_blocks)
    if len(pandoc_chunks) != alignment_units:
        raise PandocProjectorError(
            "pandoc_reordered",
            (
                "Pandoc emitted "
                f"{len(pandoc_chunks)} top-level chunks but the alignment-unit "
                f"count is {alignment_units}. Refusing to fabricate alignment."
            ),
        )
    markdown = _inject_source_sentinels(pandoc_chunks, source_blocks)
    markdown = _canonicalize_markdown(markdown)
    return PandocProjection(
        markdown=markdown,
        pandoc_version=version_text.splitlines()[0] if version_text else None,
        mdformat_version=mdformat_status.version,
        warnings=[line for line in stderr_text.splitlines() if line.strip()],
    )


async def _drain_with_cap(
    process: asyncio.subprocess.Process, *, cap: int
) -> tuple[bytes, bytes, bool]:
    """Drain stdout + stderr concurrently. Kill if stdout exceeds `cap`.

    Returns `(stdout, stderr, cap_exceeded)`. When `cap_exceeded` is True,
    the process has already been killed and the returned stdout is
    truncated at the cap. Caller must still `await process.wait()` to
    reap.
    """
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    cap_exceeded = False

    async def read_stdout() -> None:
        nonlocal cap_exceeded
        assert process.stdout is not None
        size = 0
        while True:
            chunk = await process.stdout.read(65536)
            if not chunk:
                return
            size += len(chunk)
            if size > cap:
                cap_exceeded = True
                process.kill()
                return
            stdout_chunks.append(chunk)

    async def read_stderr() -> None:
        assert process.stderr is not None
        while True:
            chunk = await process.stderr.read(65536)
            if not chunk:
                return
            stderr_chunks.append(chunk)

    await asyncio.gather(read_stdout(), read_stderr())
    return b"".join(stdout_chunks), b"".join(stderr_chunks), cap_exceeded


def _apply_rlimits() -> None:  # pragma: no cover - runs in child process
    """preexec_fn applied in the child process before exec.

    Linux only. macOS callers pass `preexec_fn=None` and log a one-shot
    warning. This function deliberately imports `resource` lazily so
    the module imports cleanly on Windows (where `resource` is absent).
    """
    import resource

    resource.setrlimit(
        resource.RLIMIT_AS, (PANDOC_RLIMIT_AS_BYTES, PANDOC_RLIMIT_AS_BYTES)
    )
    resource.setrlimit(
        resource.RLIMIT_CPU, (PANDOC_RLIMIT_CPU_S, PANDOC_RLIMIT_CPU_S)
    )


def _maybe_log_macos_rlimit_skip() -> None:
    global _RLIMIT_SKIPPED_LOGGED
    if _RLIMIT_SKIPPED_LOGGED:
        return
    _RLIMIT_SKIPPED_LOGGED = True
    sys.stderr.write(
        "[pandoc_projector] macOS detected: RLIMIT_AS/RLIMIT_CPU skipped "
        "(setrlimit is unreliable for child-process address space on Darwin). "
        f"The {PANDOC_TIMEOUT_S}s wall-clock timeout still applies.\n"
    )


def _pandoc_version(pandoc: str) -> str:
    completed = subprocess.run(
        [pandoc, "--version"],
        capture_output=True,
        check=False,
        timeout=5,
    )
    if completed.returncode != 0:
        raise PandocProjectorError("pandoc_unavailable", "Unable to read pandoc --version.")
    return completed.stdout.decode("utf-8", errors="replace")


def _parse_version(version_text: str) -> tuple[int, int, int]:
    match = re.search(r"pandoc\s+(\d+)\.(\d+)(?:\.(\d+))?", version_text, flags=re.I)
    if not match:
        return (0, 0, 0)
    return (int(match.group(1)), int(match.group(2)), int(match.group(3) or 0))


def _assert_flag_policy() -> None:
    flags = set(PANDOC_FLAGS)
    forbidden = flags.intersection(PANDOC_FORBIDDEN_FLAGS)
    if forbidden:
        raise PandocProjectorError(
            "pandoc_failed", f"Forbidden Pandoc flags configured: {sorted(forbidden)}"
        )


@dataclass(frozen=True)
class _MdformatStatus:
    """Result of preflight probe."""

    kind: str  # "missing" | "no_gfm" | "ok"
    version: str | None


def _probe_mdformat() -> _MdformatStatus:
    """F6: preflight check that mdformat-gfm is actually invokable.

    Returns:
      - `_MdformatStatus(kind="missing", version=None)` if the binary is
        not on PATH.
      - `_MdformatStatus(kind="no_gfm", version=...)` if mdformat is
        installed but the gfm plugin is not loaded.
      - `_MdformatStatus(kind="ok", version=...)` otherwise.

    Detection of the gfm plugin: we run `mdformat --help` and look for
    a line that names `gfm` (the loaded-plugins section). This is a
    cheap, deterministic check that doesn't require touching files.
    """
    mdformat = shutil.which("mdformat")
    if not mdformat:
        return _MdformatStatus(kind="missing", version=None)
    version_text = _mdformat_version_text(mdformat)
    help_text = _mdformat_help_text(mdformat)
    if "gfm" not in help_text.lower():
        return _MdformatStatus(kind="no_gfm", version=version_text)
    return _MdformatStatus(kind="ok", version=version_text)


def _mdformat_version_text(mdformat: str) -> str | None:
    completed = subprocess.run(
        [mdformat, "--version"], capture_output=True, check=False, timeout=5
    )
    if completed.returncode != 0:
        return None
    return completed.stdout.decode("utf-8", errors="replace").strip()


def _mdformat_help_text(mdformat: str) -> str:
    completed = subprocess.run(
        [mdformat, "--help"], capture_output=True, check=False, timeout=5
    )
    if completed.returncode != 0:
        return ""
    return completed.stdout.decode("utf-8", errors="replace")


def _strip_pandoc_generated_ids(markdown: str) -> str:
    return re.sub(r"\s*\{#ditagen-[^}]+}", "", markdown)


def _split_pandoc_chunks(markdown: str) -> list[str]:
    """Split pandoc output into top-level chunks.

    Pandoc separates top-level blocks (paragraphs, headings, lists,
    tables, blockquotes, code blocks) with one blank line. The
    `--wrap=none` flag ensures no spurious wrapping inside a chunk. So
    `\\n{2,}` is a sound separator.

    Empty leading/trailing entries are stripped.
    """
    return [chunk for chunk in re.split(r"\n{2,}", markdown.strip()) if chunk.strip()]


def _count_alignment_units(source_blocks: list[dict[str, Any]]) -> int:
    """F5 alignment-unit count.

    Excludes the block_types in `_ALIGNMENT_EXCLUDED_TYPES` (table rows,
    list items, running headers/footers, notes). The remaining blocks
    are the ones that pandoc's chunked output should align to 1:1.
    """
    return sum(
        1
        for block in source_blocks
        if block.get("block_type") not in _ALIGNMENT_EXCLUDED_TYPES
    )


def _inject_source_sentinels(
    chunks: list[str], source_blocks: list[dict[str, Any]]
) -> str:
    """F5: emit `<!-- source:{block_id} -->` before each alignment-unit chunk.

    Precondition (enforced by caller): `len(chunks) == _count_alignment_units(source_blocks)`.
    This means there is exactly one pandoc chunk per non-excluded source
    block, in matching order. No fabrication, no fallback.
    """
    lines: list[str] = []
    chunk_iter = iter(chunks)
    for source_block in source_blocks:
        if source_block.get("block_type") in _ALIGNMENT_EXCLUDED_TYPES:
            continue
        try:
            chunk = next(chunk_iter)
        except StopIteration as exc:  # pragma: no cover - guarded by caller
            raise PandocProjectorError(
                "pandoc_reordered",
                "Alignment-unit / chunk count drifted after preflight; refusing to fabricate.",
            ) from exc
        lines.append(f"<!-- source:{source_block['block_id']} -->")
        lines.append(chunk)
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def _canonicalize_markdown(markdown: str) -> str:
    """Run mdformat with gfm to canonicalize. F6 preflight already verified
    mdformat-gfm is available, so any failure here is a true error — we
    raise `pandoc_failed` rather than silently returning raw markdown.
    """
    mdformat = shutil.which("mdformat")
    assert mdformat is not None, "F6 preflight should have caught this"
    completed = subprocess.run(
        [mdformat, "--wrap=keep", "-"],
        input=markdown.encode("utf-8"),
        capture_output=True,
        check=False,
        timeout=MDFORMAT_TIMEOUT_S,
    )
    if completed.returncode != 0:
        stderr_tail = completed.stderr.decode("utf-8", errors="replace")[-1000:]
        raise PandocProjectorError(
            "pandoc_failed",
            f"mdformat returned exit code {completed.returncode} during canonicalization.",
            stderr_tail=stderr_tail,
        )
    return completed.stdout.decode("utf-8", errors="replace").strip() + "\n"
