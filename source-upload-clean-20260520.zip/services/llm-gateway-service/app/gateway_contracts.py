"""Request/response Pydantic models for the LLM Gateway.

Phase 4 of `plans/logical-whistling-widget.md`. Per ADR-005:32, every
LLM call goes through this gateway — the request/response shapes are
the contract that lets Phase 8 drop in a real provider without the
caller side changing.

Per ADR-005:20 every gateway response carries `GatewayCallMetadata`:
the model, the provider, the prompt version, content hashes of input
and output, and (when known) token counts and cost estimate.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal

from ditagen_common.models import Block
from pydantic import BaseModel, ConfigDict, Field


class _StrictBase(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ---------------------------------------------------------------------------
# Provider capability declarations
# ---------------------------------------------------------------------------


class ProviderCapabilities(_StrictBase):
    """Declares what a provider implements. Gateway routes consult this
    to return 501 Not Implemented for unsupported requests rather than
    forwarding to a provider that would raise."""

    supports_chat_completions: bool = False
    supports_topic_plan: bool = False
    supports_generate_topic: bool = False
    supports_streaming: bool = False
    supports_structured_output: bool = False
    deterministic: bool = False
    """If True, same (request, prompt_version) pair always produces the
    same output. The fixture-deterministic provider sets this; real
    providers typically set False."""


# ---------------------------------------------------------------------------
# GatewayCallMetadata — the per-response audit envelope (ADR-005:20)
# ---------------------------------------------------------------------------


class GatewayCallMetadata(_StrictBase):
    model: str = Field(min_length=1)
    provider: str = Field(min_length=1)
    prompt_version: str = Field(min_length=1)
    input_hash: str = Field(min_length=1)
    output_hash: str = Field(min_length=1)
    tokens_in: int | None = None
    tokens_out: int | None = None
    cost_usd_estimate: float | None = None


def canonical_hash(payload: Any) -> str:
    """SHA-256 over the canonical JSON of `payload`. Deterministic for the
    same logical content regardless of dict key order."""
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


# ---------------------------------------------------------------------------
# Topic-plan request/response
# ---------------------------------------------------------------------------


class TopicPlanRequest(_StrictBase):
    document_id: str = Field(min_length=1)
    source_blocks: list[Block] = Field(min_length=1)
    structure_tree: dict[str, Any] = Field(default_factory=dict)
    model_name: str = Field(default="fixture-deterministic", min_length=1)
    prompt_version: str = Field(default="v0", min_length=1)


class TopicPlanResponse(_StrictBase):
    topic_plan: dict[str, Any]
    """Validates against `contracts/llm/topic-plan.schema.json`. Kept as
    `dict[str, Any]` here because Phase 4 still consumes the legacy
    pipeline output; Phase 6 may tighten this to a typed `TopicPlan`
    model."""

    llm_metadata: GatewayCallMetadata


# ---------------------------------------------------------------------------
# Generate-topic request/response
# ---------------------------------------------------------------------------


class GenerateTopicRequest(_StrictBase):
    candidate: dict[str, Any]
    """A topicCandidate-shaped dict (see contracts/llm/topic-plan.schema.json
    #topicCandidate). Phase 6 typed this when the Topic model
    extends to cover generated-topic shape."""

    source_blocks: list[Block] = Field(min_length=1)
    model_name: str = Field(default="fixture-deterministic", min_length=1)
    prompt_version: str = Field(default="v0", min_length=1)


class GenerateTopicResponse(_StrictBase):
    generated_topic: dict[str, Any]
    """Validates against `contracts/llm/generated-topic.schema.json`."""

    llm_metadata: GatewayCallMetadata


# ---------------------------------------------------------------------------
# Chat-completions (OpenAI-compatible shape, ADR-005:13)
# ---------------------------------------------------------------------------


class ChatMessage(_StrictBase):
    role: Literal["system", "user", "assistant"]
    content: str


class ChatCompletionsRequest(_StrictBase):
    model: str = Field(min_length=1)
    messages: list[ChatMessage] = Field(min_length=1)
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, ge=1)
    response_format: dict[str, Any] | None = None


class ChatCompletionChoice(_StrictBase):
    index: int = Field(ge=0)
    message: ChatMessage
    finish_reason: Literal["stop", "length", "content_filter", "tool_calls"] = "stop"


class ChatCompletionsResponse(_StrictBase):
    id: str = Field(min_length=1)
    object: Literal["chat.completion"] = "chat.completion"
    model: str = Field(min_length=1)
    choices: list[ChatCompletionChoice] = Field(min_length=1)
    usage: dict[str, int] = Field(default_factory=dict)
    llm_metadata: GatewayCallMetadata


# ---------------------------------------------------------------------------
# Provider listing
# ---------------------------------------------------------------------------


class ProviderInfo(_StrictBase):
    name: str = Field(min_length=1)
    capabilities: ProviderCapabilities


class ProvidersResponse(_StrictBase):
    providers: list[ProviderInfo]
