"""LLM Gateway service — FastAPI surface.

Phase 4 of `plans/logical-whistling-widget.md`. Per ADR-005:32 every
LLM call goes through this gateway. Phase 4 ships the contract surface
plus a single registered `fixture-deterministic` provider that wraps
the existing rule-based pipeline. Phase 8 plugs in a real provider
without changing this file.
"""

from __future__ import annotations

from ditagen_common.service_app import create_service_app
from fastapi import HTTPException
from gateway_contracts import (
    ChatCompletionsRequest,
    ChatCompletionsResponse,
    GenerateTopicRequest,
    GenerateTopicResponse,
    ProvidersResponse,
    TopicPlanRequest,
    TopicPlanResponse,
)
from gateway_providers import Provider, ProviderCapabilityError
from gateway_registry import Registry, UnknownModelError, default_registry

app = create_service_app("llm-gateway-service")
_registry: Registry = default_registry()


def _resolve_model(model_name: str) -> Provider:
    try:
        return _registry.get(model_name)
    except UnknownModelError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/internal/llm/providers", response_model=ProvidersResponse)
def list_providers() -> ProvidersResponse:
    return ProvidersResponse(providers=_registry.list_providers())


@app.post("/internal/llm/topic-plan", response_model=TopicPlanResponse)
def topic_plan(req: TopicPlanRequest) -> TopicPlanResponse:
    provider = _resolve_model(req.model_name)
    if not provider.capabilities().supports_topic_plan:
        raise HTTPException(
            status_code=501,
            detail=f"provider for model {req.model_name!r} does not support topic_plan",
        )
    try:
        return provider.topic_plan(req)
    except ProviderCapabilityError as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc


@app.post("/internal/llm/generate-topic", response_model=GenerateTopicResponse)
def generate_topic(req: GenerateTopicRequest) -> GenerateTopicResponse:
    provider = _resolve_model(req.model_name)
    if not provider.capabilities().supports_generate_topic:
        raise HTTPException(
            status_code=501,
            detail=f"provider for model {req.model_name!r} does not support generate_topic",
        )
    try:
        return provider.generate_topic(req)
    except ProviderCapabilityError as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc


@app.post("/internal/llm/chat/completions", response_model=ChatCompletionsResponse)
def chat_completions(req: ChatCompletionsRequest) -> ChatCompletionsResponse:
    provider = _resolve_model(req.model)
    if not provider.capabilities().supports_chat_completions:
        raise HTTPException(
            status_code=501,
            detail=(
                f"provider for model {req.model!r} does not support "
                f"chat_completions; Phase 8 lands a real provider"
            ),
        )
    try:
        return provider.chat_completions(req)
    except ProviderCapabilityError as exc:
        raise HTTPException(status_code=501, detail=str(exc)) from exc
