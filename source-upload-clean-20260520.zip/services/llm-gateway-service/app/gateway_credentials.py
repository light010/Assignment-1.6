"""Credential providers for the LLM Gateway.

Phase 8 followup. The original LlamaProvider supported only a static
API key (`DITAGEN_LLAMA_API_KEY`). Enterprise deployments routinely
authenticate via a `(tenant_id, app_id, secret)` triple — either passed
through as headers to an already-authenticated gateway, or exchanged
for a short-lived bearer at an OAuth2 token endpoint.

This module isolates "what headers do I attach to my LLM request" from
the provider call logic. Adding a new credential pattern (mTLS,
SigV4-style HMAC, etc.) is a new `CredentialProvider` subclass — no
changes to LlamaProvider.

Modes ranked from least → most ceremony:

  NoAuthCredentialProvider:
      No `Authorization`/identity headers. Used when DITAgen talks to
      a local Ollama on `http://localhost:11434` (the default for dev).

  StaticBearerCredentialProvider:
      `Authorization: Bearer <api_key>`. Used when the LLM endpoint
      takes a long-lived bearer token (most hosted endpoints).

  HeaderBundleCredentialProvider:
      `X-Tenant-Id: <tenant>` + `X-App-Id: <app>` +
      `Authorization: Bearer <secret>`. Used when the LLM endpoint
      lives behind an enterprise gateway that already terminates auth
      and just needs the tenancy bundle stamped on the request.

  OAuth2ClientCredentialsProvider:
      POSTs `(tenant_id, app_id, secret)` to a token endpoint, gets
      back `{access_token, expires_in}`, caches with TTL, refreshes on
      401 or near-expiry. Used when the auth service issues
      short-lived bearers (Azure-style).

Every provider implements the same surface: `headers_for_request()`
returns a fresh header dict for each call. Providers that cache
internally (OAuth2) keep that state private so callers don't have to
manage token lifetimes.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Protocol

import httpx


class CredentialError(RuntimeError):
    """Raised when a credential provider cannot produce headers — e.g.
    the OAuth2 token endpoint is unreachable or the auth service
    rejected the credentials. The LlamaProvider surfaces these as
    HTTPException(503) so analysis-service falls back to fixture."""


class CredentialProvider(Protocol):
    """A credential provider returns the headers to attach to each LLM
    request. Implementations may cache internally; callers must not.

    `headers_for_request()` is called before every HTTP call (or every
    retry attempt). Providers that maintain a token cache check
    expiry there.

    `invalidate()` is called when the LLM endpoint returns 401, giving
    the provider a chance to drop its cached token and refresh on the
    next call. Providers without cached state can no-op.
    """

    name: str

    def headers_for_request(self) -> dict[str, str]:
        ...

    def invalidate(self) -> None:
        ...


class NoAuthCredentialProvider:
    """No identity headers. Local Ollama, dev fixtures."""

    name = "no-auth"

    def headers_for_request(self) -> dict[str, str]:
        return {}

    def invalidate(self) -> None:
        return None


class StaticBearerCredentialProvider:
    """`Authorization: Bearer <api_key>` — long-lived token."""

    name = "static-bearer"

    def __init__(self, *, api_key: str) -> None:
        if not api_key:
            raise CredentialError("static-bearer requires non-empty api_key")
        self._api_key = api_key

    def headers_for_request(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key}"}

    def invalidate(self) -> None:
        # Static bearer can't refresh; a 401 here means the key is
        # bad and the only fix is to rotate it in env.
        return None


class HeaderBundleCredentialProvider:
    """`X-Tenant-Id` + `X-App-Id` + `Authorization: Bearer <secret>`.

    For enterprise LLM gateways that already authenticate at the edge
    and just need the tenancy bundle stamped on each request. No token
    exchange — the secret IS the bearer.
    """

    name = "header-bundle"

    def __init__(self, *, tenant_id: str, app_id: str, secret: str) -> None:
        if not (tenant_id and app_id and secret):
            raise CredentialError(
                "header-bundle requires non-empty tenant_id, app_id, and secret"
            )
        self._tenant_id = tenant_id
        self._app_id = app_id
        self._secret = secret

    def headers_for_request(self) -> dict[str, str]:
        return {
            "X-Tenant-Id": self._tenant_id,
            "X-App-Id": self._app_id,
            "Authorization": f"Bearer {self._secret}",
        }

    def invalidate(self) -> None:
        # The secret can't auto-rotate; if it's wrong the deployment
        # needs new env vars. Same as static-bearer.
        return None


class OAuth2ClientCredentialsProvider:
    """Exchange (tenant_id, app_id, secret) for a short-lived bearer.

    POST `<token_endpoint>` with `grant_type=client_credentials`,
    `client_id=<app_id>`, `client_secret=<secret>` and (optionally)
    `tenant_id=<tenant>`. Expect a JSON response with `access_token`
    and `expires_in` (seconds).

    The bearer is cached in memory with a `_safety_margin` (60s)
    subtracted from `expires_in` so we refresh before the upstream
    expiry. A 401 from the LLM endpoint triggers `invalidate()`, which
    drops the cache and forces a fresh exchange on the next request.

    Thread-safe — the refresh path holds a lock so concurrent callers
    don't stampede the token endpoint.

    Scope is optional. Tenant placement is configurable:
      - tenant_in_body=True (default): include `tenant_id` in the form
        body alongside grant_type/client_id/client_secret.
      - tenant_in_path=True: substitute `{tenant_id}` in token_endpoint
        (Azure-style).
      - tenant_in_header=True: send `X-Tenant-Id: <tenant>` on the
        token-exchange request (some custom gateways).

    Only one placement is active at a time; if multiple are set the
    constructor raises.
    """

    name = "oauth2-client-credentials"

    def __init__(
        self,
        *,
        tenant_id: str,
        app_id: str,
        secret: str,
        token_endpoint: str,
        scope: str | None = None,
        tenant_in_body: bool = True,
        tenant_in_path: bool = False,
        tenant_in_header: bool = False,
        request_timeout_seconds: float = 10.0,
        safety_margin_seconds: float = 60.0,
    ) -> None:
        if not (tenant_id and app_id and secret and token_endpoint):
            raise CredentialError(
                "oauth2-client-credentials requires tenant_id, app_id, secret, token_endpoint"
            )
        if sum([tenant_in_body, tenant_in_path, tenant_in_header]) != 1:
            raise CredentialError(
                "exactly one of tenant_in_body / tenant_in_path / tenant_in_header must be true"
            )
        self._tenant_id = tenant_id
        self._app_id = app_id
        self._secret = secret
        self._token_endpoint = token_endpoint
        self._scope = scope
        self._tenant_in_body = tenant_in_body
        self._tenant_in_path = tenant_in_path
        self._tenant_in_header = tenant_in_header
        self._request_timeout_seconds = request_timeout_seconds
        self._safety_margin_seconds = safety_margin_seconds
        self._cached_token: str | None = None
        self._cached_expiry: float = 0.0
        self._lock = threading.Lock()
        # Test seam — injectable httpx client for the token endpoint.
        self._token_client: httpx.Client | None = None

    def headers_for_request(self) -> dict[str, str]:
        token = self._token_or_refresh()
        return {"Authorization": f"Bearer {token}"}

    def invalidate(self) -> None:
        with self._lock:
            self._cached_token = None
            self._cached_expiry = 0.0

    # ---- internals ----------------------------------------------------

    def _token_or_refresh(self) -> str:
        with self._lock:
            now = time.monotonic()
            if self._cached_token and now < self._cached_expiry:
                return self._cached_token
            token, expires_in = self._exchange()
            self._cached_token = token
            self._cached_expiry = now + max(0.0, expires_in - self._safety_margin_seconds)
            return token

    def _exchange(self) -> tuple[str, float]:
        endpoint = self._token_endpoint
        body: dict[str, str] = {
            "grant_type": "client_credentials",
            "client_id": self._app_id,
            "client_secret": self._secret,
        }
        headers: dict[str, str] = {"Content-Type": "application/x-www-form-urlencoded"}
        if self._tenant_in_path:
            endpoint = endpoint.replace("{tenant_id}", self._tenant_id)
        if self._tenant_in_body:
            body["tenant_id"] = self._tenant_id
        if self._tenant_in_header:
            headers["X-Tenant-Id"] = self._tenant_id
        if self._scope:
            body["scope"] = self._scope

        client = self._token_client or httpx.Client(timeout=self._request_timeout_seconds)
        try:
            response = client.post(endpoint, data=body, headers=headers)
        except httpx.HTTPError as exc:
            raise CredentialError(
                f"oauth2 token endpoint unreachable: {exc}"
            ) from exc
        finally:
            if self._token_client is None:
                client.close()
        if response.status_code != 200:
            raise CredentialError(
                f"oauth2 token endpoint returned {response.status_code}: "
                f"{response.text[:200]}"
            )
        payload: dict[str, Any] = response.json()
        token = payload.get("access_token")
        if not token:
            raise CredentialError(
                f"oauth2 response missing access_token: keys={sorted(payload)}"
            )
        expires_in = float(payload.get("expires_in", 3600))
        return token, expires_in


def build_credential_provider(
    *,
    api_key: str | None,
    tenant_id: str | None,
    app_id: str | None,
    secret: str | None,
    token_endpoint: str | None,
    scope: str | None = None,
    tenant_in_body: bool = True,
    tenant_in_path: bool = False,
    tenant_in_header: bool = False,
) -> CredentialProvider:
    """Factory — picks the credential mode based on what's set.

    Precedence (most specific first):
      1. tenant_id + app_id + secret + token_endpoint → OAuth2.
      2. tenant_id + app_id + secret (no endpoint)    → HeaderBundle.
      3. api_key                                       → StaticBearer.
      4. (nothing)                                     → NoAuth.

    Mixing api_key with tenant/app/secret raises — the operator should
    pick one credential model explicitly.
    """
    have_triple = bool(tenant_id and app_id and secret)
    have_api_key = bool(api_key)
    if have_triple and have_api_key:
        raise CredentialError(
            "set EITHER DITAGEN_LLAMA_API_KEY OR the (tenant_id, app_id, secret) "
            "bundle — not both. Pick one credential model."
        )
    if have_triple and token_endpoint:
        return OAuth2ClientCredentialsProvider(
            tenant_id=tenant_id or "",
            app_id=app_id or "",
            secret=secret or "",
            token_endpoint=token_endpoint,
            scope=scope,
            tenant_in_body=tenant_in_body,
            tenant_in_path=tenant_in_path,
            tenant_in_header=tenant_in_header,
        )
    if have_triple:
        return HeaderBundleCredentialProvider(
            tenant_id=tenant_id or "",
            app_id=app_id or "",
            secret=secret or "",
        )
    if have_api_key:
        return StaticBearerCredentialProvider(api_key=api_key or "")
    return NoAuthCredentialProvider()
