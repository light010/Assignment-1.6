"""Prompt-injection denylist + length cap.

Phase 8 of `plans/logical-whistling-widget.md`. Per ADR-005:48 every
real-provider call passes user-supplied content through a safety check
before the prompt template is rendered. The check has two layers:

  1. Length cap — content longer than the per-provider limit is
     rejected without scanning. Defense in depth: extreme volumes are
     prima-facie suspicious AND they blow past context windows.
  2. Regex denylist — well-known prompt-injection idioms ("ignore
     previous instructions", "you are now …", "system:", etc.). The
     list is small and conservative; false positives are preferable to
     false negatives for the alpha. Future versions will use a
     model-based detector.

A blocked call surfaces as `ProviderSafetyError`, which the gateway
maps to HTTP 400 (the user's content, not a server failure). The
analysis-service fallback chain treats safety errors as fatal — there
is no point retrying on the fixture provider with the same content.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# Patterns are case-insensitive. Each one is well-documented in the
# prompt-injection literature; new entries require a referenced
# example before being added.
_DENYLIST_PATTERNS: tuple[re.Pattern[str], ...] = (
    # `(?:<qualifier>\s+)*` allows chained qualifiers like
    # "ignore the prior instructions" or "disregard all previous prior".
    re.compile(
        r"\bignore\s+(?:(?:all|the|any|previous|prior|above)\s+)*instructions?\b", re.I
    ),
    re.compile(
        r"\bdisregard\s+(?:(?:the|all|any|previous|prior|above)\s+)*instructions?\b", re.I
    ),
    re.compile(r"\byou\s+are\s+now\s+(?:a|an)\s+", re.I),
    re.compile(r"\bsystem\s*:\s*you\s+are\b", re.I),
    re.compile(r"\bprint\s+your\s+(?:system\s+)?prompt\b", re.I),
    re.compile(r"\breveal\s+(?:your|the)\s+(?:system\s+)?prompt\b", re.I),
    # Markdown image data-URL exfil — rare in user-pasted docs but a
    # known vector for data smuggling.
    re.compile(r"!\[\]\(\s*data:", re.I),
)


class ProviderSafetyError(ValueError):
    """Raised when user-supplied content trips a safety check.

    Carries `reason` (a short machine-readable code) and `match` (the
    matched fragment or length descriptor) so the gateway can surface a
    structured 400 response.
    """

    def __init__(self, *, reason: str, match: str) -> None:
        self.reason = reason
        self.match = match
        super().__init__(f"{reason}: {match[:120]}")


@dataclass(frozen=True)
class SafetyCheckResult:
    ok: bool
    reason: str | None = None
    match: str | None = None


def check_user_content(content: str, *, max_chars: int) -> SafetyCheckResult:
    """Apply length cap + denylist to `content`. Pure function."""
    if len(content) > max_chars:
        return SafetyCheckResult(
            ok=False,
            reason="content_exceeds_length_cap",
            match=f"{len(content)} chars > {max_chars}",
        )
    for pattern in _DENYLIST_PATTERNS:
        match = pattern.search(content)
        if match:
            return SafetyCheckResult(
                ok=False,
                reason="prompt_injection_pattern",
                match=match.group(0),
            )
    return SafetyCheckResult(ok=True)


def assert_user_content_safe(content: str, *, max_chars: int) -> None:
    """Raise ProviderSafetyError if `content` fails the safety check."""
    result = check_user_content(content, max_chars=max_chars)
    if not result.ok:
        assert result.reason is not None  # ok=False guarantees this
        assert result.match is not None
        raise ProviderSafetyError(reason=result.reason, match=result.match)
