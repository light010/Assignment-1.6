"""Typed settings for the LLM Gateway.

Phase 8 of `plans/logical-whistling-widget.md`. Per ADR-005:34 every
provider reads its credentials and endpoint from a typed settings model
— never hardcoded. Env vars are read once at module import time so the
gateway boots with a frozen view of its configuration; reload requires
a service restart.

Llama is wired through the OpenAI-compatible endpoint Ollama exposes
(default `http://localhost:11434/v1`). The model name is configurable
so operators can swap in `llama3.1:8b`, `llama3.2`, `qwen2.5`, etc.
without touching code.

URL normalization: operators commonly paste Ollama's native URL
(`http://localhost:11434`) into `DITAGEN_LLAMA_BASE_URL`, but the
OpenAI-compatible routes live under `/v1`. `effective_base_url`
auto-appends `/v1` when the URL has no path beyond `/`, so both forms
work. Operators who deploy behind a reverse proxy can set a custom
path explicitly and the normalization leaves it alone.
"""

from __future__ import annotations

import os
from urllib.parse import urlparse

from gateway_credentials import CredentialProvider, build_credential_provider
from pydantic import BaseModel, ConfigDict, Field


class _StrictBase(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LlamaSettings(_StrictBase):
    """Llama provider configuration.

    Read from env at startup; missing required fields make
    `is_configured` return False, in which case the registry skips
    registration and the gateway falls back to fixture-deterministic.
    """

    base_url: str = Field(
        default="",
        description="OpenAI-compatible base URL. Ollama default: http://localhost:11434/v1",
    )
    model_name: str = Field(
        default="",
        description="Model to use for topic_plan / generate_topic / chat. e.g. 'llama3.1:8b'",
    )
    request_timeout_seconds: float = Field(default=60.0, gt=0.0)
    max_retries: int = Field(default=3, ge=1, le=10)
    initial_backoff_seconds: float = Field(default=0.5, gt=0.0)
    max_backoff_seconds: float = Field(default=8.0, gt=0.0)
    cost_usd_per_1k_input_tokens: float = Field(default=0.0, ge=0.0)
    cost_usd_per_1k_output_tokens: float = Field(default=0.0, ge=0.0)
    """Local Llama is free; set non-zero for hosted Llama deployments."""

    api_key: str | None = Field(
        default=None,
        description="Bearer token for authenticated Llama endpoints. None for local Ollama. "
        "Mutually exclusive with the (tenant_id, app_id, secret) bundle.",
    )
    # Phase 8 followup — tenant/app/secret credential model. When set,
    # routes through HeaderBundleCredentialProvider (default) or
    # OAuth2ClientCredentialsProvider (if token_endpoint is also set).
    tenant_id: str | None = Field(default=None)
    app_id: str | None = Field(default=None)
    secret: str | None = Field(default=None)
    token_endpoint: str | None = Field(
        default=None,
        description="Optional OAuth2 token endpoint. When set with tenant/app/secret, "
        "the provider exchanges credentials for a short-lived bearer and caches it.",
    )
    oauth2_scope: str | None = Field(
        default=None,
        description="Optional `scope` parameter for the OAuth2 client-credentials grant.",
    )
    oauth2_tenant_placement: str = Field(
        default="body",
        description="Where to put tenant_id in the OAuth2 exchange: 'body' (form field, default), "
        "'path' (substitute {tenant_id} in endpoint URL, Azure-style), or 'header' (X-Tenant-Id).",
    )
    max_user_content_chars: int = Field(default=120_000, ge=1)
    """Hard length cap on user content fed to the model — first line of
    defense against prompt-injection-via-volume per ADR-005:48."""

    @property
    def is_configured(self) -> bool:
        """True iff both base_url and model_name are non-empty."""
        return bool(self.base_url) and bool(self.model_name)

    @property
    def effective_base_url(self) -> str:
        """`base_url` normalized so OpenAI-compatible routes resolve.

        If the URL has no path (or only `/`), append `/v1` — operators
        often paste Ollama's bare host URL `http://localhost:11434`.
        If a non-root path is already set (`https://proxy/llm`,
        `https://api.example.com/v2`, etc.), leave it alone — they
        chose that path deliberately.
        """
        if not self.base_url:
            return self.base_url
        url = self.base_url.rstrip("/")
        parsed = urlparse(url)
        if not parsed.path:
            return f"{url}/v1"
        return url

    def credential_provider(self) -> CredentialProvider:
        """Build the credential provider implied by the configured env.

        Precedence (most specific first):
          1. tenant+app+secret+token_endpoint → OAuth2ClientCredentials.
          2. tenant+app+secret (no endpoint)  → HeaderBundle.
          3. api_key                          → StaticBearer.
          4. (nothing)                        → NoAuth (local Ollama).

        Mixing api_key with the tenant/app/secret bundle raises — the
        operator should pick one credential model explicitly so it's
        unambiguous in audit logs and incident postmortems.
        """
        placement = self.oauth2_tenant_placement.lower()
        return build_credential_provider(
            api_key=self.api_key,
            tenant_id=self.tenant_id,
            app_id=self.app_id,
            secret=self.secret,
            token_endpoint=self.token_endpoint,
            scope=self.oauth2_scope,
            tenant_in_body=placement == "body",
            tenant_in_path=placement == "path",
            tenant_in_header=placement == "header",
        )


def load_llama_settings() -> LlamaSettings:
    """Read Llama settings from env. Called once at registry build time."""
    return LlamaSettings(
        base_url=os.getenv("DITAGEN_LLAMA_BASE_URL", ""),
        model_name=os.getenv("DITAGEN_LLAMA_MODEL", ""),
        request_timeout_seconds=float(
            os.getenv("DITAGEN_LLAMA_TIMEOUT_SECONDS", "60.0")
        ),
        max_retries=int(os.getenv("DITAGEN_LLAMA_MAX_RETRIES", "3")),
        initial_backoff_seconds=float(
            os.getenv("DITAGEN_LLAMA_INITIAL_BACKOFF_SECONDS", "0.5")
        ),
        max_backoff_seconds=float(
            os.getenv("DITAGEN_LLAMA_MAX_BACKOFF_SECONDS", "8.0")
        ),
        cost_usd_per_1k_input_tokens=float(
            os.getenv("DITAGEN_LLAMA_COST_USD_PER_1K_INPUT", "0.0")
        ),
        cost_usd_per_1k_output_tokens=float(
            os.getenv("DITAGEN_LLAMA_COST_USD_PER_1K_OUTPUT", "0.0")
        ),
        api_key=os.getenv("DITAGEN_LLAMA_API_KEY"),
        tenant_id=os.getenv("DITAGEN_LLAMA_TENANT_ID"),
        app_id=os.getenv("DITAGEN_LLAMA_APP_ID"),
        secret=os.getenv("DITAGEN_LLAMA_SECRET"),
        token_endpoint=os.getenv("DITAGEN_LLAMA_TOKEN_ENDPOINT"),
        oauth2_scope=os.getenv("DITAGEN_LLAMA_OAUTH2_SCOPE"),
        oauth2_tenant_placement=os.getenv("DITAGEN_LLAMA_OAUTH2_TENANT_PLACEMENT", "body"),
        max_user_content_chars=int(
            os.getenv("DITAGEN_LLAMA_MAX_USER_CONTENT_CHARS", "120000")
        ),
    )
