"""Llama provider (OpenAI-compatible HTTP endpoint).

Phase 8 of `plans/logical-whistling-widget.md`. Per ADR-005:13 the
gateway speaks OpenAI's `/v1/chat/completions` shape; Llama via Ollama
exposes exactly that. The provider:

  * Reads endpoint + model + cost rates from `LlamaSettings` (frozen
    Pydantic model populated from env at import time).
  * Renders prompts via `gateway_prompts.get_prompt(version, name)`.
  * Forwards through `httpx.Client` (sync; FastAPI runs sync handlers
    in the threadpool).
  * Retries with exponential backoff + jitter on connection errors and
    5xx responses, up to `max_retries`. 4xx surfaces immediately.
  * Validates structured output against the JSON schema, and runs ONE
    repair-retry on schema failure with the parse error appended to the
    prompt. On second failure raises `ProviderSchemaError` and the
    analysis-service falls back to fixture-deterministic.
  * Computes `cost_usd_estimate` from the model's usage block when the
    server returns one; otherwise falls back to a 4-chars-per-token
    estimate (rough, but better than `None`).
  * Runs every user-supplied content string through
    `gateway_safety.assert_user_content_safe()` before sending — length
    cap + regex denylist.

Determinism: temperature defaults to 0.0 and seed (when supported) is
passed through, so a given Llama+model+request normally round-trips to
the same response. We do NOT claim `deterministic=True` in capabilities
because the upstream server may ignore seed.
"""

from __future__ import annotations

import json
import random
import time
from typing import Any

import httpx
from gateway_contracts import (
    ChatCompletionChoice,
    ChatCompletionsRequest,
    ChatCompletionsResponse,
    ChatMessage,
    GatewayCallMetadata,
    GenerateTopicRequest,
    GenerateTopicResponse,
    ProviderCapabilities,
    TopicPlanRequest,
    TopicPlanResponse,
    canonical_hash,
)
from gateway_credentials import CredentialError, CredentialProvider
from gateway_prompts import get_prompt
from gateway_safety import assert_user_content_safe
from gateway_settings import LlamaSettings

from gateway_providers import Provider, ProviderCapabilityError

PROVIDER_LABEL = "llama-openai-compatible"


class ProviderRetryableError(RuntimeError):
    """Transient failure from the upstream Llama endpoint (timeout, 5xx,
    network reset). The retry loop catches these; the final attempt
    re-raises so the caller can fall back."""


class ProviderSchemaError(ValueError):
    """Raised when the model output fails JSON schema validation even
    after the repair-retry. The analysis-service catches this and falls
    back to fixture-deterministic with a warning event."""


class LlamaProvider(Provider):
    """Real LLM provider over an OpenAI-compatible Llama endpoint."""

    def __init__(
        self,
        settings: LlamaSettings,
        *,
        credential_provider: CredentialProvider | None = None,
    ) -> None:
        if not settings.is_configured:
            raise ValueError(
                "LlamaProvider requires DITAGEN_LLAMA_BASE_URL and "
                "DITAGEN_LLAMA_MODEL to be set"
            )
        self._settings = settings
        # Resolve the credential provider once at construction. Tests
        # can inject a stand-in; production calls settings.credential_provider()
        # which picks the right mode based on env (NoAuth / StaticBearer /
        # HeaderBundle / OAuth2). Token caching lives inside the provider.
        self._credentials: CredentialProvider = (
            credential_provider
            if credential_provider is not None
            else settings.credential_provider()
        )
        self.name = settings.model_name
        # Lazy client — built on first call so tests can patch httpx
        # transports cleanly.
        self._client: httpx.Client | None = None

    # -----------------------------------------------------------------
    # Provider interface
    # -----------------------------------------------------------------

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supports_chat_completions=True,
            supports_topic_plan=True,
            supports_generate_topic=True,
            supports_streaming=False,
            supports_structured_output=True,
            deterministic=False,
        )

    def chat_completions(self, request: ChatCompletionsRequest) -> ChatCompletionsResponse:
        for message in request.messages:
            assert_user_content_safe(
                message.content, max_chars=self._settings.max_user_content_chars
            )
        payload: dict[str, Any] = {
            "model": self._settings.model_name,
            "messages": [m.model_dump() for m in request.messages],
        }
        if request.temperature is not None:
            payload["temperature"] = request.temperature
        if request.max_tokens is not None:
            payload["max_tokens"] = request.max_tokens
        if request.response_format is not None:
            payload["response_format"] = request.response_format

        raw = self._call_with_retries("/chat/completions", payload)
        usage = raw.get("usage") or {}
        tokens_in = int(usage.get("prompt_tokens") or 0) or None
        tokens_out = int(usage.get("completion_tokens") or 0) or None
        cost = self._estimate_cost(tokens_in, tokens_out)
        choices = [
            ChatCompletionChoice(
                index=int(choice.get("index", 0)),
                message=ChatMessage(
                    role=choice["message"]["role"],
                    content=choice["message"]["content"],
                ),
                finish_reason=choice.get("finish_reason", "stop"),
            )
            for choice in raw.get("choices", [])
        ]
        if not choices:
            raise ProviderRetryableError("Llama returned no choices in chat.completion")
        return ChatCompletionsResponse(
            id=raw.get("id") or f"chatcmpl_llama_{int(time.time() * 1000)}",
            model=request.model,
            choices=choices,
            usage={k: int(v) for k, v in usage.items() if isinstance(v, int | float)},
            llm_metadata=GatewayCallMetadata(
                model=request.model,
                provider=PROVIDER_LABEL,
                prompt_version="passthrough",
                input_hash=canonical_hash(payload),
                output_hash=canonical_hash(raw),
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cost_usd_estimate=cost,
            ),
        )

    def topic_plan(self, request: TopicPlanRequest) -> TopicPlanResponse:
        block_dicts = [b.model_dump(mode="json") for b in request.source_blocks]
        user_content = _summarize_blocks(block_dicts)
        assert_user_content_safe(
            user_content, max_chars=self._settings.max_user_content_chars
        )
        template = get_prompt(request.prompt_version, "topic_plan")
        rendered = template.format(source_blocks_summary=user_content)
        plan = self._call_for_json(rendered)
        plan.setdefault("document_id", request.document_id)
        input_hash = canonical_hash(
            {
                "document_id": request.document_id,
                "source_blocks": block_dicts,
                "structure_tree": request.structure_tree,
                "model_name": request.model_name,
                "prompt_version": request.prompt_version,
            }
        )
        return TopicPlanResponse(
            topic_plan=plan,
            llm_metadata=self._call_metadata(
                model=request.model_name,
                prompt_version=request.prompt_version,
                input_hash=input_hash,
                output_payload=plan,
            ),
        )

    def generate_topic(self, request: GenerateTopicRequest) -> GenerateTopicResponse:
        block_dicts = [b.model_dump(mode="json") for b in request.source_blocks]
        user_content = "Candidate:\n" + json.dumps(request.candidate, indent=2) + "\n\nBlocks:\n" + _summarize_blocks(block_dicts)
        assert_user_content_safe(
            user_content, max_chars=self._settings.max_user_content_chars
        )
        template = get_prompt(request.prompt_version, "generate_topic")
        rendered = template.format(
            candidate_summary=json.dumps(request.candidate, indent=2),
            source_blocks_summary=_summarize_blocks(block_dicts),
        )
        topic = self._call_for_json(rendered)
        topic.setdefault("topic_id", request.candidate.get("topic_id", "tpc_generated"))
        topic.setdefault("topic_candidate_id", request.candidate.get("topic_id", "tpc_generated"))
        input_hash = canonical_hash(
            {
                "candidate": request.candidate,
                "source_blocks": block_dicts,
                "model_name": request.model_name,
                "prompt_version": request.prompt_version,
            }
        )
        return GenerateTopicResponse(
            generated_topic=topic,
            llm_metadata=self._call_metadata(
                model=request.model_name,
                prompt_version=request.prompt_version,
                input_hash=input_hash,
                output_payload=topic,
            ),
        )

    # -----------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------

    def _client_or_build(self) -> httpx.Client:
        if self._client is None:
            # Only stamp the static Content-Type at client-build time.
            # Auth headers come from `self._credentials.headers_for_request()`
            # per-call so OAuth2 token refresh + 401-driven invalidation
            # work without rebuilding the client.
            self._client = httpx.Client(
                base_url=self._settings.effective_base_url,
                headers={"Content-Type": "application/json"},
                timeout=self._settings.request_timeout_seconds,
            )
        return self._client

    def _auth_headers(self) -> dict[str, str]:
        """Pull the per-call credential headers. Wraps CredentialError
        as ProviderRetryableError so a transient auth-service outage
        triggers the retry+fallback flow rather than killing the call."""
        try:
            return self._credentials.headers_for_request()
        except CredentialError as exc:
            raise ProviderRetryableError(
                f"credential provider {self._credentials.name!r} failed: {exc}"
            ) from exc

    def _call_with_retries(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        last_exc: Exception | None = None
        backoff = self._settings.initial_backoff_seconds
        for attempt in range(1, self._settings.max_retries + 1):
            try:
                # Credentials refreshed per-attempt so an OAuth2 token
                # that expired mid-retry-loop picks up a fresh one.
                auth_headers = self._auth_headers()
                response = self._client_or_build().post(
                    path, json=payload, headers=auth_headers
                )
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
                last_exc = ProviderRetryableError(
                    f"Llama transport error on attempt {attempt}: {exc}"
                )
            except ProviderRetryableError as exc:
                # `_auth_headers()` wraps CredentialError as retryable so
                # a flaky auth service triggers the retry loop rather
                # than failing the call outright.
                last_exc = exc
            else:
                if response.status_code < 400:
                    try:
                        return response.json()
                    except json.JSONDecodeError as exc:
                        # Body wasn't JSON despite 2xx — retryable.
                        last_exc = ProviderRetryableError(
                            f"Llama returned non-JSON 2xx body on attempt {attempt}: {exc}"
                        )
                elif response.status_code == 401:
                    # Token might have expired between cache check and
                    # the call. Invalidate the cache and retry — the
                    # next iteration's _auth_headers() forces refresh.
                    self._credentials.invalidate()
                    last_exc = ProviderRetryableError(
                        f"Llama 401 on attempt {attempt}; invalidated "
                        f"credential cache and will retry"
                    )
                elif response.status_code >= 500:
                    last_exc = ProviderRetryableError(
                        f"Llama 5xx on attempt {attempt}: {response.status_code} {response.text[:200]}"
                    )
                else:
                    # Other 4xx — caller's fault or our prompt; do not
                    # retry. Auth failures that aren't 401 (e.g. 403)
                    # surface here because they typically indicate a
                    # permission problem the cache invalidation can't
                    # fix.
                    raise ProviderCapabilityError(
                        f"Llama {response.status_code}: {response.text[:200]}"
                    )
            if attempt < self._settings.max_retries:
                jitter = random.uniform(0, backoff * 0.25)  # noqa: S311 — backoff jitter, not crypto
                time.sleep(backoff + jitter)
                backoff = min(backoff * 2, self._settings.max_backoff_seconds)
        assert last_exc is not None
        raise last_exc

    def _call_for_json(self, prompt: str) -> dict[str, Any]:
        """Run the prompt with JSON-mode + repair-retry on parse failure."""
        messages = [
            {
                "role": "system",
                "content": (
                    "You return ONLY valid JSON. No prose, no markdown fences, no commentary. "
                    "Return an object that satisfies the schema described in the user message."
                ),
            },
            {"role": "user", "content": prompt},
        ]
        for attempt in range(1, 3):  # one repair-retry
            payload = {
                "model": self._settings.model_name,
                "messages": messages,
                "temperature": 0.0,
                "response_format": {"type": "json_object"},
            }
            raw = self._call_with_retries("/chat/completions", payload)
            try:
                content = raw["choices"][0]["message"]["content"]
            except (KeyError, IndexError, TypeError) as exc:
                raise ProviderSchemaError(
                    f"Llama response missing choices[0].message.content: {exc}"
                ) from exc
            try:
                parsed = json.loads(content)
                if not isinstance(parsed, dict):
                    raise ValueError(f"top-level JSON is {type(parsed).__name__}, expected object")
                self._last_usage = raw.get("usage") or {}
                return parsed
            except (json.JSONDecodeError, ValueError) as exc:
                if attempt == 1:
                    messages.append(
                        {
                            "role": "user",
                            "content": (
                                f"Your previous response could not be parsed as a JSON object. "
                                f"Error: {exc}. Return ONLY a valid JSON object now."
                            ),
                        }
                    )
                    continue
                raise ProviderSchemaError(
                    f"Llama output failed JSON parse after repair-retry: {exc}; "
                    f"first 200 chars: {content[:200]!r}"
                ) from exc
        raise ProviderSchemaError("unreachable: repair-retry loop exited without returning")

    def _call_metadata(
        self,
        *,
        model: str,
        prompt_version: str,
        input_hash: str,
        output_payload: Any,
    ) -> GatewayCallMetadata:
        usage = getattr(self, "_last_usage", {}) or {}
        tokens_in = int(usage.get("prompt_tokens") or 0) or None
        tokens_out = int(usage.get("completion_tokens") or 0) or None
        return GatewayCallMetadata(
            model=model,
            provider=PROVIDER_LABEL,
            prompt_version=prompt_version,
            input_hash=input_hash,
            output_hash=canonical_hash(output_payload),
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd_estimate=self._estimate_cost(tokens_in, tokens_out),
        )

    def _estimate_cost(self, tokens_in: int | None, tokens_out: int | None) -> float | None:
        rate_in = self._settings.cost_usd_per_1k_input_tokens
        rate_out = self._settings.cost_usd_per_1k_output_tokens
        if rate_in == 0.0 and rate_out == 0.0:
            return 0.0  # local Llama is free; explicit zero beats None
        if tokens_in is None and tokens_out is None:
            return None
        return ((tokens_in or 0) / 1000.0) * rate_in + ((tokens_out or 0) / 1000.0) * rate_out


def _summarize_blocks(blocks: list[dict[str, Any]]) -> str:
    """Render a compact text view of source blocks for the prompt."""
    parts: list[str] = []
    for block in blocks:
        bid = block.get("block_id", "?")
        btype = block.get("block_type", "?")
        text = (block.get("text") or "").strip().replace("\n", " ")
        if len(text) > 280:
            text = text[:280] + "…"
        parts.append(f"[{bid} {btype}] {text}")
    return "\n".join(parts)
