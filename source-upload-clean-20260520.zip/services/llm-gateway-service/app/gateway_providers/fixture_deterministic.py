"""Fixture-deterministic provider — wraps the legacy rule-based pipeline.

Phase 4 of `plans/logical-whistling-widget.md`. This provider delegates
to `ditagen_common.pipeline.build_topic_plan` and `build_generated_topic`
without changing their behavior. Its purpose is to make the gateway the
single seam for topic planning and topic generation, so Phase 8 can drop
in a real LLM provider without callers changing.

Determinism: the underlying pipeline functions are pure (no IO, no
random, no wall-clock). Same input -> byte-identical output. Locked by
`tests/test_llm_gateway.py::test_fixture_provider_is_deterministic`.

Phase 11 retires `ditagen_common.pipeline.build_topic_plan` /
`build_generated_topic` once Phase 8's real provider is in place.
Until then this file is the only allowed importer of those functions
outside the legacy alpha helper at `pipeline.py:run_document_pipeline`
(locked by `tests/test_architecture.py::test_pipeline_topic_functions
_only_imported_by_gateway`).
"""

from __future__ import annotations

from ditagen_common.pipeline import (
    build_generated_topic as _legacy_build_generated_topic,
)
from ditagen_common.pipeline import (
    build_topic_plan as _legacy_build_topic_plan,
)
from gateway_contracts import (
    GatewayCallMetadata,
    GenerateTopicRequest,
    GenerateTopicResponse,
    ProviderCapabilities,
    TopicPlanRequest,
    TopicPlanResponse,
    canonical_hash,
)

from gateway_providers import Provider

PROVIDER_LABEL = "local-rule-based"


class FixtureDeterministicProvider(Provider):
    """Pure-Python rule-based provider. No LLM calls."""

    name = "fixture-deterministic"

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supports_chat_completions=False,
            supports_topic_plan=True,
            supports_generate_topic=True,
            supports_streaming=False,
            supports_structured_output=True,
            deterministic=True,
        )

    def topic_plan(self, request: TopicPlanRequest) -> TopicPlanResponse:
        # The legacy pipeline expects dict-shaped blocks; round-trip
        # through Pydantic so the gateway boundary is typed but the
        # downstream contract stays unchanged. This is a temporary
        # shim — Phase 6 may tighten when the typed Topic model
        # extends to cover the topic_plan output shape.
        block_dicts = [b.model_dump(mode="json") for b in request.source_blocks]
        plan = _legacy_build_topic_plan(
            document_id=request.document_id,
            source_blocks=block_dicts,
            structure_tree=request.structure_tree,
            model_name=request.model_name,
        )
        input_hash = canonical_hash(
            {
                "document_id": request.document_id,
                "source_blocks": block_dicts,
                "structure_tree": request.structure_tree,
                "model_name": request.model_name,
                "prompt_version": request.prompt_version,
            }
        )
        return TopicPlanResponse(
            topic_plan=plan,
            llm_metadata=GatewayCallMetadata(
                model=request.model_name,
                provider=PROVIDER_LABEL,
                prompt_version=request.prompt_version,
                input_hash=input_hash,
                output_hash=canonical_hash(plan),
            ),
        )

    def generate_topic(self, request: GenerateTopicRequest) -> GenerateTopicResponse:
        block_dicts = [b.model_dump(mode="json") for b in request.source_blocks]
        topic = _legacy_build_generated_topic(
            candidate=request.candidate,
            source_blocks=block_dicts,
            model_name=request.model_name,
        )
        input_hash = canonical_hash(
            {
                "candidate": request.candidate,
                "source_blocks": block_dicts,
                "model_name": request.model_name,
                "prompt_version": request.prompt_version,
            }
        )
        return GenerateTopicResponse(
            generated_topic=topic,
            llm_metadata=GatewayCallMetadata(
                model=request.model_name,
                provider=PROVIDER_LABEL,
                prompt_version=request.prompt_version,
                input_hash=input_hash,
                output_hash=canonical_hash(topic),
            ),
        )
