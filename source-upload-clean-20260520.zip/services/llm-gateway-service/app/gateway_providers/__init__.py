"""Provider abstraction for the LLM Gateway.

Phase 4 of `plans/logical-whistling-widget.md`. Per ADR-005:42, every
provider call goes through a typed interface. The gateway accepts a
request, dispatches to the registered provider for that model_name, and
returns a typed response with `GatewayCallMetadata` (ADR-005:20).

A `Provider` declares its capabilities up-front. Methods that the
provider does not support raise `ProviderCapabilityError`; the gateway
route checks capabilities before dispatching and returns 501 Not
Implemented for unsupported pairs.
"""

from __future__ import annotations

from gateway_contracts import (
    ChatCompletionsRequest,
    ChatCompletionsResponse,
    GenerateTopicRequest,
    GenerateTopicResponse,
    ProviderCapabilities,
    TopicPlanRequest,
    TopicPlanResponse,
)


class ProviderCapabilityError(NotImplementedError):
    """Raised by a Provider method when its capabilities don't include
    that operation. Distinct from generic NotImplementedError so
    callers can branch on it without false positives."""


class Provider:
    """Abstract base for every gateway-registered provider.

    Subclasses must override `name` and `capabilities()`, plus the
    methods their capabilities advertise as supported. Other methods
    keep the base default of raising ProviderCapabilityError.

    All methods are synchronous in Phase 4 because the only registered
    provider (fixture-deterministic) wraps pure-Python rule code.
    Phase 8 introduces async wrappers when real LLM calls land.
    """

    name: str = ""

    def capabilities(self) -> ProviderCapabilities:
        raise NotImplementedError(f"{type(self).__name__} must override capabilities()")

    def topic_plan(self, request: TopicPlanRequest) -> TopicPlanResponse:
        raise ProviderCapabilityError(
            f"provider {self.name!r} does not support topic_plan"
        )

    def generate_topic(self, request: GenerateTopicRequest) -> GenerateTopicResponse:
        raise ProviderCapabilityError(
            f"provider {self.name!r} does not support generate_topic"
        )

    def chat_completions(self, request: ChatCompletionsRequest) -> ChatCompletionsResponse:
        raise ProviderCapabilityError(
            f"provider {self.name!r} does not support chat_completions"
        )
