"""Versioned prompt templates.

Phase 4 ships v0 templates as placeholders — the
fixture-deterministic provider doesn't use prompts, so v0 strings are
documentation-only. The mechanism is real so Phase 8 can plug in real
prompt templates without changing the gateway request shape (the
caller still passes `prompt_version` through).

Per ADR-005:19 every prompt template must be versioned. The version
flows into `GatewayCallMetadata.prompt_version` so eval and
regeneration can trace the exact template in use.
"""

from __future__ import annotations

V0_TOPIC_PLAN_TEMPLATE = """\
You are a technical writer.

Given the following source blocks extracted from a document, group them
into topic candidates. Each topic candidate should:
- Cover a coherent subject area.
- Be one of: concept, task, reference, troubleshooting, glossary.
- Reference its source block IDs explicitly.

Source blocks:
{source_blocks_summary}

Return JSON validating against contracts/llm/topic-plan.schema.json.
"""

V0_GENERATE_TOPIC_TEMPLATE = """\
You are a technical writer.

Given the following topic candidate and the source blocks it references,
generate a DITA-ready topic body for the requested topic_type.

Candidate:
{candidate_summary}

Source blocks:
{source_blocks_summary}

Return JSON validating against contracts/llm/generated-topic.schema.json.
"""

V1_TOPIC_PLAN_TEMPLATE = """\
You are a senior technical writer. Group source blocks into topic candidates
for a DITA documentation set.

Return ONLY a single JSON object validating against
contracts/llm/topic-plan.schema.json. Required top-level keys:
  document_id, topic_candidates (array, min 1), map_outline (array),
  confidence (object with overall_confidence in [0,1]), llm_metadata
  (object with model, provider, prompt_version, input_artifact_hashes).

Each topic_candidate must have:
  topic_id (string, prefix tpc_), title (string), topic_type
  (one of: concept, task, reference, troubleshooting, glossary),
  source_block_ids (array of block ids from the input).

Source blocks:
{source_blocks_summary}
"""

V1_GENERATE_TOPIC_TEMPLATE = """\
You are a senior technical writer. Generate a DITA-ready topic body for a
single candidate, returning ONLY a JSON object validating against
contracts/llm/generated-topic.schema.json.

Required keys: topic_id, topic_candidate_id, topic_type, title,
source_block_ids, body (DITA-flavored XML-like structure as a string),
traceability (array mapping body sections back to source_block_ids),
confidence (object), llm_metadata (object).

Candidate:
{candidate_summary}

Source blocks:
{source_blocks_summary}
"""

PROMPT_TEMPLATES: dict[str, dict[str, str]] = {
    "v0": {
        "topic_plan": V0_TOPIC_PLAN_TEMPLATE,
        "generate_topic": V0_GENERATE_TOPIC_TEMPLATE,
    },
    "v1": {
        "topic_plan": V1_TOPIC_PLAN_TEMPLATE,
        "generate_topic": V1_GENERATE_TOPIC_TEMPLATE,
    },
}


class UnknownPromptError(KeyError):
    """Raised when a prompt name or version isn't registered."""


def get_prompt(version: str, name: str) -> str:
    if version not in PROMPT_TEMPLATES:
        raise UnknownPromptError(
            f"unknown prompt version {version!r}; known: {sorted(PROMPT_TEMPLATES)}"
        )
    if name not in PROMPT_TEMPLATES[version]:
        raise UnknownPromptError(
            f"unknown prompt {name!r} in version {version!r}; "
            f"known: {sorted(PROMPT_TEMPLATES[version])}"
        )
    return PROMPT_TEMPLATES[version][name]
