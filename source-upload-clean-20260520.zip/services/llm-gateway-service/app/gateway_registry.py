"""Provider registry.

Maps `model_name` -> `Provider`. Phase 4 shipped a single registered
provider (fixture-deterministic). Phase 8 adds LlamaProvider whose
registration is conditional on `DITAGEN_LLAMA_BASE_URL` +
`DITAGEN_LLAMA_MODEL` being set — without those, Llama is absent from
the registry and the gateway falls back to fixture-deterministic only.

The Phase 8 plan calls for a fallback chain (real → fixture on error).
That fallback lives in analysis-service, not in the registry: the
registry knows what's registered, not how to recover when a provider
fails mid-call.
"""

from __future__ import annotations

from gateway_contracts import ProviderInfo
from gateway_providers import Provider
from gateway_providers.fixture_deterministic import FixtureDeterministicProvider
from gateway_providers.llama import LlamaProvider
from gateway_settings import LlamaSettings, load_llama_settings


class UnknownModelError(KeyError):
    """Raised when a request targets a model_name that has no registered provider."""


class Registry:
    def __init__(self) -> None:
        self._providers: dict[str, Provider] = {}

    def register(self, model_name: str, provider: Provider) -> None:
        if not model_name:
            raise ValueError("model_name must be non-empty")
        self._providers[model_name] = provider

    def get(self, model_name: str) -> Provider:
        if model_name not in self._providers:
            raise UnknownModelError(
                f"no provider registered for model_name {model_name!r}; "
                f"known: {sorted(self._providers)}"
            )
        return self._providers[model_name]

    def list_providers(self) -> list[ProviderInfo]:
        return [
            ProviderInfo(name=name, capabilities=provider.capabilities())
            for name, provider in sorted(self._providers.items())
        ]


def default_registry(*, llama_settings: LlamaSettings | None = None) -> Registry:
    """Build the default registry with every provider this service ships.

    Llama registration is opt-in via env: only registered when both
    `DITAGEN_LLAMA_BASE_URL` and `DITAGEN_LLAMA_MODEL` are non-empty.
    Passing `llama_settings` explicitly is for tests.
    """
    registry = Registry()
    registry.register("fixture-deterministic", FixtureDeterministicProvider())
    settings = llama_settings if llama_settings is not None else load_llama_settings()
    if settings.is_configured:
        registry.register(settings.model_name, LlamaProvider(settings))
    return registry
