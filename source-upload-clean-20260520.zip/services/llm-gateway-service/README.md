# llm-gateway-service

ADR-005:32 — the single seam every LLM call goes through. Phase 4
shipped the gateway with `fixture-deterministic` only (rule-based, no
LLM). Phase 8 added `LlamaProvider` (OpenAI-compatible HTTP endpoint —
Ollama, llama.cpp, vLLM, hosted Llama).

## Provider registration

`fixture-deterministic` is always registered. `LlamaProvider` is
registered IFF the env below is configured at startup. Without it the
gateway still works — it just doesn't expose any real LLM.

## Env vars — connection

| Var | Default | Notes |
|---|---|---|
| `DITAGEN_LLAMA_BASE_URL` | `""` | OpenAI-compatible base URL. Ollama: `http://localhost:11434` (the `/v1` suffix is auto-appended when missing). Hosted: `https://api.your-llama-host.com/v1`. |
| `DITAGEN_LLAMA_MODEL` | `""` | Model identifier sent to the upstream server. e.g. `llama3.1:8b`, `llama3.2`, `qwen2.5`. This is also the `model_name` callers must use in `TopicPlanRequest`/`GenerateTopicRequest` to route to Llama. |
| `DITAGEN_LLAMA_TIMEOUT_SECONDS` | `60.0` | Per-request timeout. |
| `DITAGEN_LLAMA_MAX_RETRIES` | `3` | Retries on transport errors, 5xx, and 401 (cache invalidation). 4xx other than 401 fail-fast. |
| `DITAGEN_LLAMA_INITIAL_BACKOFF_SECONDS` | `0.5` | Backoff base for jittered exponential retry. |
| `DITAGEN_LLAMA_MAX_BACKOFF_SECONDS` | `8.0` | Backoff ceiling. |
| `DITAGEN_LLAMA_COST_USD_PER_1K_INPUT` | `0.0` | Local Llama is free; set for hosted. |
| `DITAGEN_LLAMA_COST_USD_PER_1K_OUTPUT` | `0.0` | Same. |
| `DITAGEN_LLAMA_MAX_USER_CONTENT_CHARS` | `120000` | Length-cap (defense-in-depth against prompt-injection-via-volume). |

## Env vars — credentials

Four credential modes; the factory picks the most specific one whose env
vars are set. Set EITHER `DITAGEN_LLAMA_API_KEY` OR the tenant/app/secret
triple — mixing both raises at startup so the credential model is always
unambiguous in audit logs.

| Var | Default | Notes |
|---|---|---|
| `DITAGEN_LLAMA_API_KEY` | unset | **StaticBearer mode** — `Authorization: Bearer <api_key>` on every request. |
| `DITAGEN_LLAMA_TENANT_ID` | unset | Tenancy identifier in the (tenant, app, secret) auth triple. |
| `DITAGEN_LLAMA_APP_ID` | unset | Application/client identifier. |
| `DITAGEN_LLAMA_SECRET` | unset | Client secret. |
| `DITAGEN_LLAMA_TOKEN_ENDPOINT` | unset | When set with the triple, switches to **OAuth2 client-credentials mode** — POST `(tenant, app, secret)` to this endpoint, get a bearer back, cache with TTL. |
| `DITAGEN_LLAMA_OAUTH2_SCOPE` | unset | Optional `scope` parameter for the OAuth2 exchange. |
| `DITAGEN_LLAMA_OAUTH2_TENANT_PLACEMENT` | `body` | Where to put `tenant_id` in the OAuth2 exchange: `body` (form field, default), `path` (substitute `{tenant_id}` in endpoint URL — Azure-style), or `header` (`X-Tenant-Id`). |

### Mode 1 — Local Ollama (no auth)

```bash
export DITAGEN_LLAMA_BASE_URL=http://localhost:11434
export DITAGEN_LLAMA_MODEL=llama3.2
```

### Mode 2 — Static bearer (long-lived API key)

```bash
export DITAGEN_LLAMA_BASE_URL=https://api.your-host.com/v1
export DITAGEN_LLAMA_MODEL=llama3.1:70b
export DITAGEN_LLAMA_API_KEY=sk-your-key-here
```

### Mode 3 — Enterprise header-bundle (tenant + app + secret pass-through)

When your LLM lives behind an enterprise gateway that authenticates at
the edge and just needs the tenancy bundle stamped on each request:

```bash
export DITAGEN_LLAMA_BASE_URL=https://llm-gw.internal/v1
export DITAGEN_LLAMA_MODEL=llama3.2
export DITAGEN_LLAMA_TENANT_ID=ten_acme_corp
export DITAGEN_LLAMA_APP_ID=app_ditagen_prod
export DITAGEN_LLAMA_SECRET=svc_secret_value
# (no token endpoint → header-bundle mode)
```

Headers attached to every Llama request:

```
X-Tenant-Id: ten_acme_corp
X-App-Id: app_ditagen_prod
Authorization: Bearer svc_secret_value
```

### Mode 4 — OAuth2 client-credentials (short-lived bearer)

When the auth service issues short-lived bearers (Azure, Okta-style,
custom enterprise IDP):

```bash
export DITAGEN_LLAMA_BASE_URL=https://api.llm-host.com/v1
export DITAGEN_LLAMA_MODEL=llama3.2
export DITAGEN_LLAMA_TENANT_ID=ten_acme_corp
export DITAGEN_LLAMA_APP_ID=app_ditagen_prod
export DITAGEN_LLAMA_SECRET=svc_secret_value
export DITAGEN_LLAMA_TOKEN_ENDPOINT=https://auth.internal/oauth2/token
# Optional:
export DITAGEN_LLAMA_OAUTH2_SCOPE=llm:invoke
export DITAGEN_LLAMA_OAUTH2_TENANT_PLACEMENT=body  # or 'path' or 'header'
```

Behavior:
- POSTs `grant_type=client_credentials&client_id=<app_id>&client_secret=<secret>&tenant_id=<tenant>` to the token endpoint.
- Caches the returned `access_token` until `expires_in − 60s` (refresh-ahead safety margin).
- On 401 from the LLM endpoint, invalidates the cache and re-exchanges on the next call.
- The token cache is thread-safe.

Azure-style endpoint template (`{tenant_id}` in URL path):

```bash
export DITAGEN_LLAMA_TOKEN_ENDPOINT="https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
export DITAGEN_LLAMA_OAUTH2_TENANT_PLACEMENT=path
```

## Safety

Every user-content string is passed through
`gateway_safety.assert_user_content_safe()` before the prompt is
rendered. Two layers:

1. Length cap (`DITAGEN_LLAMA_MAX_USER_CONTENT_CHARS`).
2. Regex denylist for known prompt-injection idioms ("ignore previous
   instructions", "you are now …", "system: you are …", "print your
   system prompt", "reveal your prompt", markdown image data-URLs).

A blocked call raises `ProviderSafetyError`. Analysis-service's
fallback chain does NOT fall back on safety errors — the fixture
provider sees the same content and the safety concern doesn't change.

## Determinism

Llama defaults to `temperature=0.0` for topic-plan / generate-topic.
Determinism is best-effort because the upstream server may not honor
seed. `capabilities().deterministic` returns `False` — the gateway
contract advertises non-determinism so eval pipelines treat
Llama-vs-fixture diffs as quality signals, not regressions.

## Repair-retry

LLM JSON output frequently fails to parse on first try (truncated, trailing
commas, etc.). The provider does ONE repair-retry: on JSON parse failure
it appends a system message describing the error and re-prompts. If the
second attempt also fails, `ProviderSchemaError` propagates so
analysis-service can fall back to fixture-deterministic.

## Cost accounting

`GatewayCallMetadata.cost_usd_estimate` is filled when the upstream
server returns a `usage` block (most OpenAI-compatible endpoints do)
AND the per-1k-token rates are configured. Local Llama returns `0.0`
(free) regardless of token counts.
