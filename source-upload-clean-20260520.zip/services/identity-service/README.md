# identity-service

**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation).

ADR-004 designs this service as the identity provider for users,
sessions, tokens, and role assertions. Today the equivalent functions
are in `ditagen_common.auth` + `ditagen_common.security` (issue_token,
verify_token, verify_password, current_user dependency), called
directly from every service.

## What this service will own

- `POST /internal/auth/login` (currently in api-gateway).
- `POST /internal/auth/refresh` (currently in api-gateway).
- `POST /internal/auth/logout` (currently in api-gateway).
- `POST /internal/auth/tokens` — personal access tokens.
- `GET /internal/users/{id}` + user CRUD.
- Role + permission policy resolution.

Auth-helper functions (issue_token, verify_token, current_user) stay
in `ditagen_common` even after this service stands up — they're the
typed contract identity-service implements, and other services need
them to verify tokens client-side without a round-trip.

## Why deferred

The alpha treats authentication as a library concern (`ditagen_common.auth`)
because the user model is single-tenant for the demo. Splitting it
into a separate service is a future-proofing move that the alpha
doesn't need. The skeleton stays so the `service_clients` registry
keeps the route reserved for when this service comes online.
