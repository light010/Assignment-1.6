from __future__ import annotations

import json
import os
from typing import Any

import httpx
from ditagen_common.auth import context_headers, current_user_from_token, public_user
from ditagen_common.ids import new_id
from ditagen_common.observability import install_observability
from ditagen_common.security import (
    issue_token,
    validate_auth_secret_config,
    verify_password,
    verify_token,
)
from ditagen_common.service_clients import emit_audit_event, request_service
from ditagen_common.store_factory import create_store
from fastapi import Body, Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, StreamingResponse
from pydantic import BaseModel

validate_auth_secret_config()


def _csv_env(name: str, default: str) -> list[str]:
    return [item.strip() for item in os.getenv(name, default).split(",") if item.strip()]


_DEFAULT_CORS_ORIGINS = ",".join(
    f"http://{host}:{port}"
    for host in ("localhost", "127.0.0.1")
    for port in (5173, 5174, 5175)
)

app = FastAPI(title="DITAgen API Gateway", version="0.1.0")
gateway_metrics = install_observability(app, "api-gateway")
app.add_middleware(
    CORSMiddleware,
    # Default to a small range of Vite dev ports because Vite auto-
    # bumps to 5174/5175 when 5173 is occupied — silently breaking the
    # local CORS preflight is a worse failure mode than allowing two
    # extra dev ports. Production deployments override via the
    # DITAGEN_CORS_ORIGINS env var with explicit canonical origins.
    allow_origins=_csv_env("DITAGEN_CORS_ORIGINS", _DEFAULT_CORS_ORIGINS),
    allow_credentials=True,
    allow_methods=_csv_env("DITAGEN_CORS_METHODS", "GET,POST,PUT,PATCH,DELETE,OPTIONS"),
    allow_headers=_csv_env(
        "DITAGEN_CORS_HEADERS",
        "Authorization,Content-Type,X-Request-ID,X-Business-Unit-ID",
    ),
)
store = create_store("api-gateway")
BUSINESS_UNIT_SERVICE_URL = os.getenv(
    "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
)
UPLOAD_SERVICE_URL = os.getenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
EXTRACTION_SERVICE_URL = os.getenv("DITAGEN_EXTRACTION_SERVICE_URL", "http://extraction-service:8000")
REVIEW_SERVICE_URL = os.getenv("DITAGEN_REVIEW_SERVICE_URL", "http://review-service:8000")
LLM_GATEWAY_SERVICE_URL = os.getenv(
    "DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000"
)

_DOCUMENT_ROUTE_MIRRORS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("/v1/documents/{document_id}", ("GET", "DELETE")),
    ("/v1/documents/{document_id}/manifest", ("GET",)),
    ("/v1/documents/{document_id}/artifacts", ("GET",)),
    ("/v1/documents/{document_id}/artifacts/extraction-quality.json", ("GET",)),
    ("/v1/documents/{document_id}/extraction-review-summary", ("GET",)),
    ("/v1/documents/{document_id}/blocks", ("GET",)),
    ("/v1/documents/{document_id}/assets", ("GET",)),
    ("/v1/documents/{document_id}/jobs", ("GET",)),
    ("/v1/documents/{document_id}/source-quality", ("GET",)),
    ("/v1/documents/{document_id}/markdown", ("GET",)),
    ("/v1/documents/{document_id}/source-file", ("GET",)),
    ("/v1/documents/{document_id}/reextract", ("POST",)),
    ("/v1/documents/{document_id}/override-gate", ("POST",)),
)


class LoginRequest(BaseModel):
    email: str
    password: str


def current_user(
    authorization: str | None = Header(default=None),
    access_token: str | None = None,
) -> dict[str, Any]:
    return current_user_from_token(authorization, access_token=access_token, store=store)


async def require_project(
    request: Request, project_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    """Phase 4 D3.6: project authorization delegates to business-unit-service.

    Was a direct JsonStore subscript on `state["projects"]` — the single
    BU-owned state-dict access in api-gateway flagged in plan §D3
    finding #6. Now goes through the BU service's
    `GET /internal/projects/{id}` over the same `request_service`
    transport other cross-service calls use.

    Async because `request_service` is async-only — the
    `test_async_route_conventions.py` architecture lock forbids
    bridging sync→async via `asyncio.run` inside FastAPI handlers
    (known event-loop-collision footgun). The 14 sync routes that
    call this helper were promoted to async at the same time."""
    response = await request_service(
        method="GET",
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/projects/{project_id}",
        headers=context_headers(request, user),
    )
    if response.status_code == 404:
        raise HTTPException(status_code=404, detail="Project not found")
    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="Project access error",
        )
    return response.json()


def require_topic(topic_id: str, user: dict[str, Any]) -> dict[str, Any]:
    state = store.read()
    topic = state["topics"].get(topic_id)
    if not topic or topic["tenant_id"] != user["tenant_id"]:
        raise HTTPException(status_code=404, detail="Topic not found")
    return topic


@app.get("/health/live")
def live() -> dict[str, str]:
    return {"service": "api-gateway", "status": "live"}


@app.get("/health/ready")
def ready() -> dict[str, str]:
    return {"service": "api-gateway", "status": "ready"}


@app.get("/metrics", response_class=PlainTextResponse)
def metrics() -> str:
    return gateway_metrics.render()


@app.post("/v1/auth/login")
async def login(request: LoginRequest) -> dict[str, Any]:
    state = store.read()
    user = next((item for item in state["users"] if item["email"].lower() == request.email.lower()), None)
    if not user or not verify_password(request.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    session_id = new_id("sess")
    access_token = issue_token(
        {
            "sub": user["user_id"],
            "tenant_id": user["tenant_id"],
            "org_id": user["organization_id"],
            "roles": user["roles"],
            "session_id": session_id,
        },
        expires_in_seconds=3600,
    )
    refresh_token = issue_token(
        {"sub": user["user_id"], "session_id": session_id, "type": "refresh"},
        expires_in_seconds=60 * 60 * 24 * 7,
    )

    def save_session(state: dict[str, Any]) -> dict[str, Any]:
        state["sessions"][session_id] = {
            "session_id": session_id,
            "user_id": user["user_id"],
            "refresh_token": refresh_token,
        }
        return state["sessions"][session_id]

    store.mutate(save_session)
    # Phase 4 D2.7b — audit events go through audit-service (the SQL
    # source of truth). On login there is no inbound Authorization
    # header yet, so we use the just-issued access_token to authenticate
    # the audit emission.
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "auth.login.succeeded",
            "resource_type": "session",
            "resource_id": session_id,
        },
        headers={
            "Authorization": f"Bearer {access_token}",
            "X-Request-ID": new_id("req"),
            "X-Actor-ID": user["user_id"],
            "X-Tenant-ID": user["tenant_id"],
            "X-Organization-ID": user["organization_id"],
        },
        store=store,
    )
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": public_user(user),
    }


@app.post("/v1/auth/logout")
async def logout(
    http_request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, str]:
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "auth.logout",
            "resource_type": "user",
            "resource_id": user["user_id"],
        },
        headers=context_headers(http_request, user),
        store=store,
    )
    return {"status": "ok"}


@app.post("/v1/auth/refresh")
def refresh(refresh_token: str = Body(embed=True)) -> dict[str, Any]:
    try:
        claims = verify_token(refresh_token)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    if claims.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Not a refresh token")
    state = store.read()
    user = next((item for item in state["users"] if item["user_id"] == claims["sub"]), None)
    if not user:
        raise HTTPException(status_code=401, detail="Unknown user")
    return {
        "access_token": issue_token(
            {
                "sub": user["user_id"],
                "tenant_id": user["tenant_id"],
                "org_id": user["organization_id"],
                "roles": user["roles"],
                "session_id": claims["session_id"],
            }
        ),
        "token_type": "bearer",
        "user": public_user(user),
    }


@app.get("/v1/auth/sessions")
def sessions(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    state = store.read()
    return {
        "sessions": [
            {"session_id": item["session_id"], "user_id": item["user_id"]}
            for item in state["sessions"].values()
            if item["user_id"] == user["user_id"]
        ]
    }


@app.post("/v1/auth/tokens")
def create_token(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    token_id = new_id("pat")
    token = issue_token(
        {"sub": user["user_id"], "type": "personal_access_token", "jti": token_id},
        expires_in_seconds=86400,
    )

    def save_token(state: dict[str, Any]) -> dict[str, Any]:
        claims = verify_token(token)
        state["revoked_tokens"][token_id] = {
            "token_id": token_id,
            "user_id": user["user_id"],
            "name": "Personal access token",
            "issued_at": claims["iat"],
            "expires_at": claims["exp"],
            "revoked_at": None,
        }
        return state["revoked_tokens"][token_id]

    store.mutate(save_token)
    return {"token_id": token_id, "token": token}


@app.get("/v1/auth/tokens")
def list_tokens(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    state = store.read()
    tokens = [
        item
        for item in state.get("revoked_tokens", {}).values()
        if item.get("user_id") == user["user_id"]
    ]
    tokens.sort(key=lambda item: item.get("issued_at", 0), reverse=True)
    return {"tokens": tokens, "user_id": user["user_id"]}


@app.delete("/v1/auth/tokens/{token_id}")
def delete_token(token_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    def revoke_token(state: dict[str, Any]) -> dict[str, Any]:
        token_record = state.get("revoked_tokens", {}).get(token_id)
        if not token_record or token_record.get("user_id") != user["user_id"]:
            raise HTTPException(status_code=404, detail="Personal access token not found")
        if not token_record.get("revoked_at"):
            from ditagen_common.store import utc_now

            token_record["revoked_at"] = utc_now()
        return token_record

    store.mutate(revoke_token)
    return {"token_id": token_id, "status": "revoked", "user_id": user["user_id"]}


def downstream_response(response: httpx.Response) -> Response:
    headers = {}
    for header_name in ("content-type", "content-disposition"):
        if response.headers.get(header_name):
            headers[header_name] = response.headers[header_name]
    return Response(content=response.content, status_code=response.status_code, headers=headers)


async def proxy_to_service(
    *,
    request: Request,
    user: dict[str, Any],
    base_url: str,
    path: str,
) -> Response:
    body = await request.body()
    business_unit_id = (
        request.path_params.get("business_unit_id")
        or request.query_params.get("business_unit_id")
        or request.headers.get("x-business-unit-id")
    )
    if not business_unit_id and body and request.headers.get("content-type", "").startswith("application/json"):
        try:
            parsed = json.loads(body)
        except json.JSONDecodeError:
            parsed = {}
        if isinstance(parsed, dict):
            business_unit_id = parsed.get("business_unit_id")
    headers = context_headers(request, user)
    if business_unit_id:
        headers["X-Business-Unit-ID"] = business_unit_id
    for header_name in ("content-type", "accept"):
        if request.headers.get(header_name):
            headers[header_name] = request.headers[header_name]
    response = await request_service(
        method=request.method,
        base_url=base_url,
        path=path,
        headers=headers,
        params=request.query_params.multi_items(),
        content=body or None,
    )
    return downstream_response(response)


@app.get("/v1/business-units")
@app.post("/v1/business-units")
async def proxy_business_units(request: Request, user: dict[str, Any] = Depends(current_user)) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path="/internal/business-units",
    )


@app.get("/v1/business-units/{business_unit_id}")
@app.patch("/v1/business-units/{business_unit_id}")
@app.delete("/v1/business-units/{business_unit_id}")
async def proxy_business_unit(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}",
    )


@app.get("/v1/business-units/{business_unit_id}/projects")
async def proxy_business_unit_projects(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}/projects",
    )


@app.get("/v1/business-units/{business_unit_id}/activity")
async def proxy_business_unit_activity(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}/activity",
    )


@app.get("/v1/business-units/{business_unit_id}/documents")
async def proxy_business_unit_documents(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}/documents",
    )


@app.post("/v1/business-units/{business_unit_id}/documents/uploads")
async def proxy_business_unit_upload_document(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/business-units/{business_unit_id}/documents/uploads",
    )


@app.post("/v1/projects")
@app.get("/v1/projects")
async def proxy_projects(request: Request, user: dict[str, Any] = Depends(current_user)) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path="/internal/projects",
    )


@app.get("/v1/projects/{project_id}")
@app.patch("/v1/projects/{project_id}")
@app.delete("/v1/projects/{project_id}")
async def proxy_project(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/projects/{project_id}",
    )


@app.get("/v1/projects/{project_id}/activity")
async def proxy_project_activity(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=BUSINESS_UNIT_SERVICE_URL,
        path=f"/internal/projects/{project_id}/activity",
    )


@app.post("/v1/projects/{project_id}/documents/uploads")
async def proxy_upload_document(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/projects/{project_id}/documents/uploads",
    )


@app.post("/v1/uploads/{upload_id}/parts")
@app.post("/v1/uploads/{upload_id}/complete")
async def proxy_upload_session(
    upload_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    suffix = request.url.path.split(f"/v1/uploads/{upload_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/uploads/{upload_id}{suffix}",
    )


async def proxy_document_route(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    # Step H0: extraction-quality.json, reextract, and override-gate are
    # all proxied to upload-service via the same passthrough. Before
    # Step H these were unreachable from the UI — the upload-service
    # routes existed but the gateway didn't expose them, so any browser
    # request returned HTTP 404. This was a dead-service-surface bug
    # closed during Step H implementation.
    suffix = request.url.path.split(f"/v1/documents/{document_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/documents/{document_id}{suffix}",
    )


for _document_route_path, _document_route_methods in _DOCUMENT_ROUTE_MIRRORS:
    app.add_api_route(
        _document_route_path,
        proxy_document_route,
        methods=list(_document_route_methods),
    )


@app.get("/v1/documents/{document_id}/triage-queue")
async def proxy_document_triage_queue(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    """Proxy to extraction-service (Phase 5). The triage queue is a read
    over extraction artifacts, so it lives on the extraction service per
    ADR-004's "extraction owns its artifacts" rule — putting it on
    upload-service would be one more boundary leak."""
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=EXTRACTION_SERVICE_URL,
        path=f"/internal/documents/{document_id}/triage-queue",
    )


@app.get("/v1/documents/{document_id}/assets/{asset_id}")
async def proxy_document_asset_content(
    document_id: str,
    asset_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/documents/{document_id}/assets/{asset_id}",
    )


@app.get("/v1/documents/{document_id}/topic-plan")
@app.post("/v1/documents/{document_id}/topic-plan/approve")
async def proxy_document_topic_plan_route(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    suffix = request.url.path.split(f"/v1/documents/{document_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/documents/{document_id}{suffix}",
    )


@app.get("/v1/projects/{project_id}/topic-plan")
@app.patch("/v1/projects/{project_id}/topic-plan")
@app.post("/v1/projects/{project_id}/topic-plan/approve")
async def proxy_project_topic_plan(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    suffix = request.url.path.split(f"/v1/projects/{project_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/projects/{project_id}{suffix}",
    )


@app.post("/v1/documents/{document_id}/topic-plan/recompute")
async def proxy_document_topic_plan(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/documents/{document_id}/topic-plan/recompute",
    )


@app.post("/v1/documents/{document_id}/exports")
async def proxy_create_document_export(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/documents/{document_id}/exports",
    )


@app.get("/v1/topics/{topic_id}")
@app.get("/v1/topics/{topic_id}/validation-issues")
@app.get("/v1/topics/{topic_id}/traceability")
async def proxy_topic_read(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    """Read-side topic lookups stay on upload-service (Phase 6 keeps the
    document/topic registry there; Phase 10 demotes upload further)."""
    suffix = request.url.path.split(f"/v1/topics/{topic_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/topics/{topic_id}{suffix}",
    )


@app.patch("/v1/topics/{topic_id}")
async def proxy_topic_patch(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    """ADR-006 PATCH /v1/topics — body shape `{xml: str}` preserved.
    upload-service still owns the route; it delegates to review-service
    via a `RawXmlOverrideOp` (Phase 6.D)."""
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/topics/{topic_id}",
    )


@app.post("/v1/topics/{topic_id}/assign-reviewer")
@app.post("/v1/topics/{topic_id}/approve")
@app.post("/v1/topics/{topic_id}/reject")
@app.post("/v1/topics/{topic_id}/ops")
async def proxy_topic_review_state(
    topic_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    """Review-state mutations + the new edit-op surface (Phase 6.E).
    Routed directly to review-service per ADR-004's edit-metadata
    ownership split."""
    suffix = request.url.path.split(f"/v1/topics/{topic_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=REVIEW_SERVICE_URL,
        path=f"/internal/topics/{topic_id}{suffix}",
    )


@app.get("/v1/documents/{document_id}/ops")
@app.post("/v1/documents/{document_id}/ops/undo")
async def proxy_document_ops(
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    """Phase 6.C — op log + undo, both on review-service."""
    suffix = request.url.path.split(f"/v1/documents/{document_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=REVIEW_SERVICE_URL,
        path=f"/internal/documents/{document_id}{suffix}",
    )


@app.get("/v1/projects/{project_id}/terminology")
async def terminology(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"project_id": project_id, "terms": []}


@app.post("/v1/projects/{project_id}/terminology/import")
async def import_terminology(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"project_id": project_id, "status": "deferred_alpha"}


@app.get("/v1/projects/{project_id}/templates")
async def templates(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"project_id": project_id, "templates": [{"template_id": "default_dita13", "name": "Default DITA 1.3"}]}


@app.post("/v1/projects/{project_id}/conversion-profiles")
async def conversion_profile(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"project_id": project_id, "status": "default_profile_active"}


@app.get("/v1/projects/{project_id}/dita-constraint-profile")
async def dita_constraint_profile(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {
        "profile_id": "default_dita13",
        "version": "1.0.0",
        "target_dita_version": "1.3",
        "mode": "denylist_with_defaults",
        "rules": [],
    }


@app.get("/v1/projects/{project_id}/quality-report")
async def quality_report(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D4.4.d: project quality counters come from upload-service.

    The 3 fields (document_count, topic_count, validation_issue_count)
    map 1:1 onto upload-service's `/storage-summary` response:
    `document_count`, `topic_id_count`, `validation_warning_count`.
    The api-gateway wire shape is preserved by re-keying on the way
    out.

    Project access is still verified via `require_project` (BU
    service) so 404/403 semantics are unchanged."""
    await require_project(request, project_id, user)
    response = await request_service(
        method="GET",
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/projects/{project_id}/storage-summary",
        headers=context_headers(request, user),
    )
    if response.status_code != 200:
        raise HTTPException(
            status_code=response.status_code,
            detail="Failed to fetch project quality counters",
        )
    summary = response.json()
    return {
        "project_id": project_id,
        "document_count": summary["document_count"],
        "topic_count": summary["topic_id_count"],
        "validation_issue_count": summary["validation_warning_count"],
    }


@app.get("/v1/projects/{project_id}/evaluation-runs")
async def evaluation_runs(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"evaluation_runs": []}


@app.post("/v1/projects/{project_id}/evaluation-runs")
async def create_evaluation_run(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"evaluation_run_id": new_id("eval"), "status": "deferred_alpha"}


@app.get("/v1/evaluation-runs/{evaluation_run_id}")
def get_evaluation_run(evaluation_run_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"evaluation_run_id": evaluation_run_id, "status": "deferred_alpha", "user_id": user["user_id"]}


@app.get("/v1/projects/{project_id}/agents")
async def agents(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"agents": ["topic-planning-agent", "dita-refactoring-agent", "validation-explanation-agent"]}


@app.post("/v1/agent-runs")
def create_agent_run(payload: dict[str, Any] = Body(default={}), user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"agent_run_id": new_id("agr"), "status": "completed_alpha", "payload": payload, "actor_id": user["user_id"]}


@app.get("/v1/agent-runs/{agent_run_id}")
def get_agent_run(agent_run_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"agent_run_id": agent_run_id, "status": "completed_alpha", "actor_id": user["user_id"]}


@app.get("/v1/agent-runs/{agent_run_id}/trace")
def get_agent_trace(agent_run_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"agent_run_id": agent_run_id, "trace": [], "actor_id": user["user_id"]}


@app.post("/v1/agent-runs/{agent_run_id}/approve-action")
def approve_agent_action(agent_run_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"agent_run_id": agent_run_id, "status": "approved_alpha", "actor_id": user["user_id"]}


@app.post("/v1/agent-runs/{agent_run_id}/cancel")
def cancel_agent_run(agent_run_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"agent_run_id": agent_run_id, "status": "cancelled_alpha", "actor_id": user["user_id"]}


@app.get("/v1/projects/{project_id}/skills")
async def skills(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"skills": ["docx-extraction", "topic-planning", "dita-task-generation", "dita-validation-fix"]}


@app.post("/v1/projects/{project_id}/skills/{skill_id}/enable")
async def enable_skill(
    project_id: str,
    skill_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"project_id": project_id, "skill_id": skill_id, "status": "enabled_alpha"}


@app.get("/v1/projects/{project_id}/mcp-servers")
async def mcp_servers(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"mcp_servers": []}


@app.post("/v1/projects/{project_id}/mcp-servers")
async def register_mcp_server(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    await require_project(request, project_id, user)
    return {"server_id": new_id("mcp"), "status": "registered_disabled_alpha"}


@app.get("/v1/mcp-servers/{server_id}/capabilities")
def mcp_capabilities(server_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"server_id": server_id, "capabilities": [], "actor_id": user["user_id"]}


@app.post("/v1/mcp-servers/{server_id}/test-connection")
def test_mcp_connection(server_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"server_id": server_id, "status": "not_configured_alpha", "actor_id": user["user_id"]}


@app.post("/v1/mcp-servers/{server_id}/enable-capability")
def enable_mcp_capability(server_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"server_id": server_id, "status": "deferred_alpha", "actor_id": user["user_id"]}


@app.post("/v1/projects/{project_id}/exports")
async def proxy_create_export(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/projects/{project_id}/exports",
    )


@app.get("/v1/exports/{export_id}")
@app.get("/v1/exports/{export_id}/logs")
@app.get("/v1/exports/{export_id}/download")
async def proxy_export_route(
    export_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> Response:
    suffix = request.url.path.split(f"/v1/exports/{export_id}", 1)[1]
    return await proxy_to_service(
        request=request,
        user=user,
        base_url=UPLOAD_SERVICE_URL,
        path=f"/internal/exports/{export_id}{suffix}",
    )


@app.get("/v1/notifications")
def notifications(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"notifications": [], "user_id": user["user_id"]}


@app.post("/v1/notifications/{notification_id}/read")
def read_notification(notification_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"notification_id": notification_id, "status": "read", "user_id": user["user_id"]}


@app.get("/v1/notification-preferences")
def notification_preferences(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"user_id": user["user_id"], "channel": "in_app", "granularity": "stage"}


@app.patch("/v1/notification-preferences")
def patch_notification_preferences(
    patch: dict[str, Any] = Body(default={}), user: dict[str, Any] = Depends(current_user)
) -> dict[str, Any]:
    return {"user_id": user["user_id"], "preferences": patch}


@app.get("/v1/projects/{project_id}/events")
async def project_events(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> StreamingResponse:
    await require_project(request, project_id, user)

    def stream():
        yield "event: connected\n"
        yield f"data: {json.dumps({'project_id': project_id, 'status': 'connected'})}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")


@app.post("/v1/llm/chat/completions")
async def llm_chat_completion(
    request: Request,
    user: dict[str, Any] = Depends(current_user),
    payload: dict[str, Any] = Body(default={}),
) -> Response:
    response = await request_service(
        method="POST",
        base_url=LLM_GATEWAY_SERVICE_URL,
        path="/internal/llm/chat/completions",
        headers=context_headers(request, user),
        json=payload,
    )
    return downstream_response(response)
