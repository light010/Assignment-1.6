"""validation-service — DITA file/topic validator (Phase 7).

ADR-004 puts DITA validation under this service. Phase 7 fills the
prior 3-line skeleton with two routes:

  POST  /internal/validation/dita-files  — validate a full set of
                                           {path: xml} entries plus
                                           an asset_manifest. Used by
                                           analysis-service and the
                                           export pipeline.
  POST  /internal/validation/topic       — validate a single topic;
                                           latency target <200ms so
                                           review-service can call it
                                           synchronously after every
                                           edit-op replay.

Both routes delegate to `ditagen_common.pipeline.validate_dita_files`,
the existing rule-based validator. Centralizing the call here is what
lets the `validate_dita_files_centralized` arch invariant lock the
boundary: any other service mentioning the function fails the gate.

The single-topic route emits a `dita.validation.completed` audit event
per ADR-004:80 so the review activity feed and dashboards see every
validation run.
"""

from __future__ import annotations

from typing import Any

from ditagen_common.auth import context_headers, current_user
from ditagen_common.pipeline import validate_dita_files
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import emit_audit_event
from ditagen_common.store_factory import create_store
from fastapi import Depends, Request
from pydantic import BaseModel, Field

app = create_service_app("validation-service")
store = create_store("validation-service")


class DitaFilesValidationRequest(BaseModel):
    dita_files: dict[str, str] = Field(
        description="Map of file path (e.g. 'topics/tpc_x.dita') to its DITA XML."
    )
    asset_manifest: dict[str, Any] = Field(
        default_factory=dict,
        description="Asset manifest for cross-reference checks; missing assets surface as warnings.",
    )


class TopicValidationRequest(BaseModel):
    topic_id: str = Field(min_length=1)
    dita_xml: str = Field(min_length=1)
    asset_manifest: dict[str, Any] = Field(default_factory=dict)
    business_unit_id: str | None = None
    project_id: str | None = None


class ValidationIssuesResponse(BaseModel):
    validation_issues: list[dict[str, Any]]
    error_count: int
    warning_count: int


def _summarize(issues: list[dict[str, Any]]) -> tuple[int, int]:
    error_count = sum(1 for issue in issues if issue.get("severity") == "error")
    warning_count = sum(1 for issue in issues if issue.get("severity") == "warning")
    return error_count, warning_count


@app.post("/internal/validation/dita-files", response_model=ValidationIssuesResponse)
def validate_dita_file_set(
    payload: DitaFilesValidationRequest,
) -> ValidationIssuesResponse:
    """Validate a full set of dita files (used by analysis-service /
    upload-service's analysis pipeline). Treated as service-to-service
    per the LLM-gateway pattern — no `current_user` dependency. The
    single-topic route still requires auth because review-service
    forwards the calling user's context for audit attribution.
    """
    issues = validate_dita_files(
        dita_files=payload.dita_files, asset_manifest=payload.asset_manifest
    )
    errors, warnings = _summarize(issues)
    return ValidationIssuesResponse(
        validation_issues=issues,
        error_count=errors,
        warning_count=warnings,
    )


@app.post("/internal/validation/topic", response_model=ValidationIssuesResponse)
async def validate_single_topic(
    payload: TopicValidationRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> ValidationIssuesResponse:
    """Validate one topic. Synchronous; review-service calls this after
    every edit-op replay so the projected topic surfaces issues inline.

    Emits `dita.validation.completed` per ADR-004:80 with the issue
    counts so the activity feed has a paper trail of every check.
    """
    issues = validate_dita_files(
        dita_files={f"topics/{payload.topic_id}.dita": payload.dita_xml},
        asset_manifest=payload.asset_manifest,
    )
    errors, warnings = _summarize(issues)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "dita.validation.completed",
            "resource_type": "topic",
            "resource_id": payload.topic_id,
            "business_unit_id": payload.business_unit_id,
            "project_id": payload.project_id,
            "metadata": {
                "error_count": errors,
                "warning_count": warnings,
            },
        },
        headers=context_headers(request, user),
        store=store,
    )
    return ValidationIssuesResponse(
        validation_issues=issues,
        error_count=errors,
        warning_count=warnings,
    )


__all__ = [
    "DitaFilesValidationRequest",
    "TopicValidationRequest",
    "ValidationIssuesResponse",
]
