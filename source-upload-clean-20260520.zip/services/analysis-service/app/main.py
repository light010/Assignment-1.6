"""analysis-service — orchestrates topic-plan → generate-topic → DITA → validation.

Phase 8 of `plans/logical-whistling-widget.md`. ADR-004 puts the analysis
pipeline under this service. Before Phase 8 the same code lived inside
`upload-service.write_analysis_artifacts`; Phase 8 moves it here and
adds a real-LLM fallback chain (real provider → fixture-deterministic
on transient or schema failures).

Route:
  POST /internal/analyses — body shape `AnalysisRequest`. Reads back
                            source-blocks / structure-tree / asset-
                            manifest / markdown via the artifact refs
                            the caller (upload-service) already wrote,
                            runs the pipeline, writes the analysis
                            artifacts, persists topics to state, and
                            emits `document.analysis.completed`.

Fallback chain (per ADR-005:62):
  - Network or schema failure on the real provider triggers ONE retry
    against `fixture-deterministic`. A `document.analysis.fallback_triggered`
    event records the original failure for ops.
  - A safety failure (prompt-injection denylist or length cap) is NOT
    retried — fixture sees the same content and the safety concern
    doesn't change. The route surfaces a structured 422.
"""

from __future__ import annotations

import os
from typing import Any

import httpx
from ditagen_common.artifacts import (
    read_artifact_json,
    read_artifact_text,
    write_artifact,
)
from ditagen_common.auth import context_headers, current_user
from ditagen_common.ids import new_id
from ditagen_common.pipeline import build_dita_files, build_export_zip
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import emit_audit_event, request_service
from ditagen_common.store_factory import create_store
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field

app = create_service_app("analysis-service")
store = create_store("analysis-service")

LLM_GATEWAY_SERVICE_URL = os.getenv(
    "DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000"
)
VALIDATION_SERVICE_URL = os.getenv(
    "DITAGEN_VALIDATION_SERVICE_URL", "http://validation-service:8000"
)
FALLBACK_MODEL = "fixture-deterministic"
DEFAULT_PROMPT_VERSION = "v0"


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class ArtifactRefIn(BaseModel):
    """Subset of the artifact registry fields analysis-service needs.

    Matches the shape `extraction-service` produces — we read `path`
    via `read_artifact_text`/`json` and pass `artifact_version` through
    when stamping derivative artifacts.
    """

    artifact_id: str
    name: str
    path: str
    content_type: str
    size_bytes: int
    hash: str
    artifact_version: int | str | None = None
    version: int | str | None = None
    sha256: str | None = None
    producer: str | None = None


class AnalysisRequest(BaseModel):
    document_id: str = Field(min_length=1)
    project_id: str = Field(min_length=1)
    business_unit_id: str = Field(min_length=1)
    tenant_id: str = Field(min_length=1)
    actor_id: str = Field(min_length=1)
    source_blocks_artifact: ArtifactRefIn
    structure_tree_artifact: ArtifactRefIn
    asset_manifest_artifact: ArtifactRefIn
    markdown_artifact: ArtifactRefIn
    model_name: str = Field(default=FALLBACK_MODEL, min_length=1)
    prompt_version: str = Field(default=DEFAULT_PROMPT_VERSION, min_length=1)


class AnalysisResponse(BaseModel):
    document_id: str
    analysis_refs: dict[str, dict[str, Any]]
    topic_ids: list[str]
    review_required: bool
    validation_issue_count: int
    block_count: int
    asset_count: int
    overall_confidence: float | None
    model_requested: str
    model_used: str
    fell_back_to_fixture: bool
    fallback_reason: str | None = None


# ---------------------------------------------------------------------------
# Pipeline helpers
# ---------------------------------------------------------------------------


def _ref_to_dict(ref: ArtifactRefIn) -> dict[str, Any]:
    return ref.model_dump(mode="json")


async def _call_gateway_topic_plan(
    *,
    document_id: str,
    source_blocks: list[dict[str, Any]],
    structure_tree: dict[str, Any],
    model_name: str,
    prompt_version: str,
    headers: dict[str, str],
) -> dict[str, Any]:
    response = await request_service(
        method="POST",
        base_url=LLM_GATEWAY_SERVICE_URL,
        path="/internal/llm/topic-plan",
        headers=headers,
        json={
            "document_id": document_id,
            "source_blocks": source_blocks,
            "structure_tree": structure_tree,
            "model_name": model_name,
            "prompt_version": prompt_version,
        },
    )
    response.raise_for_status()
    return response.json()["topic_plan"]


async def _call_gateway_generate_topic(
    *,
    candidate: dict[str, Any],
    source_blocks: list[dict[str, Any]],
    model_name: str,
    prompt_version: str,
    headers: dict[str, str],
) -> dict[str, Any]:
    response = await request_service(
        method="POST",
        base_url=LLM_GATEWAY_SERVICE_URL,
        path="/internal/llm/generate-topic",
        headers=headers,
        json={
            "candidate": candidate,
            "source_blocks": source_blocks,
            "model_name": model_name,
            "prompt_version": prompt_version,
        },
    )
    response.raise_for_status()
    return response.json()["generated_topic"]


async def _call_validation(
    *,
    dita_files: dict[str, str],
    asset_manifest: dict[str, Any],
) -> list[dict[str, Any]]:
    response = await request_service(
        method="POST",
        base_url=VALIDATION_SERVICE_URL,
        path="/internal/validation/dita-files",
        json={"dita_files": dita_files, "asset_manifest": asset_manifest},
    )
    response.raise_for_status()
    return response.json()["validation_issues"]


def _classify_gateway_error(response: httpx.Response) -> tuple[str, bool]:
    """Map a gateway error response to (reason, fallback_eligible).

    Safety errors (422 with 'safety' marker) are NOT fallback-eligible
    — the fixture provider sees the same content. Schema errors and
    5xx are fallback-eligible because the rule-based fixture is
    independent of the LLM's output quality.
    """
    body = response.text or ""
    if response.status_code == 422 and "safety" in body.lower():
        return ("safety_violation", False)
    if response.status_code >= 500:
        return (f"gateway_5xx_{response.status_code}", True)
    if response.status_code == 502 or response.status_code == 504:
        return (f"gateway_{response.status_code}", True)
    if "schema" in body.lower() or "json" in body.lower():
        return (f"schema_error_{response.status_code}", True)
    return (f"gateway_{response.status_code}", True)


async def _run_pipeline(
    *,
    document_id: str,
    source_blocks: list[dict[str, Any]],
    structure_tree: dict[str, Any],
    asset_manifest: dict[str, Any],
    model_name: str,
    prompt_version: str,
    headers: dict[str, str],
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, str], list[dict[str, Any]]]:
    """Run topic-plan → generate-topic → dita-files → validation.

    Raises HTTPException on gateway failure so the caller can decide
    whether to fall back.
    """
    topic_plan = await _call_gateway_topic_plan(
        document_id=document_id,
        source_blocks=source_blocks,
        structure_tree=structure_tree,
        model_name=model_name,
        prompt_version=prompt_version,
        headers=headers,
    )
    generated_topics: list[dict[str, Any]] = []
    for candidate in topic_plan["topic_candidates"]:
        topic = await _call_gateway_generate_topic(
            candidate=candidate,
            source_blocks=source_blocks,
            model_name=model_name,
            prompt_version=prompt_version,
            headers=headers,
        )
        generated_topics.append(topic)
    dita_files = build_dita_files(generated_topics)
    validation_issues = await _call_validation(
        dita_files=dita_files, asset_manifest=asset_manifest
    )
    return topic_plan, generated_topics, dita_files, validation_issues


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@app.post("/internal/analyses", response_model=AnalysisResponse)
async def create_analysis(
    payload: AnalysisRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> AnalysisResponse:
    """Run the full analysis pipeline and persist artifacts + topics.

    Status codes:
      200 — analysis succeeded (possibly via fallback to fixture)
      422 — user content tripped the safety check; no fallback applied
      502 — both primary AND fixture providers failed
    """
    headers = context_headers(request, user)

    source_blocks = [
        __import_jsonl_line(line)
        for line in read_artifact_text(_ref_to_dict(payload.source_blocks_artifact)).splitlines()
        if line.strip()
    ]
    structure_tree = read_artifact_json(_ref_to_dict(payload.structure_tree_artifact))
    asset_manifest = read_artifact_json(_ref_to_dict(payload.asset_manifest_artifact))
    markdown = read_artifact_text(_ref_to_dict(payload.markdown_artifact))

    model_used = payload.model_name
    fell_back = False
    fallback_reason: str | None = None
    try:
        topic_plan, generated_topics, dita_files, validation_issues = await _run_pipeline(
            document_id=payload.document_id,
            source_blocks=source_blocks,
            structure_tree=structure_tree,
            asset_manifest=asset_manifest,
            model_name=payload.model_name,
            prompt_version=payload.prompt_version,
            headers=headers,
        )
    except httpx.HTTPStatusError as exc:
        reason, fallback_eligible = _classify_gateway_error(exc.response)
        if not fallback_eligible:
            raise HTTPException(status_code=422, detail=f"analysis aborted: {reason}") from exc
        if payload.model_name == FALLBACK_MODEL:
            # Fixture itself failed — nothing left to try.
            raise HTTPException(
                status_code=502,
                detail=f"analysis failed on fixture provider: {reason}",
            ) from exc
        # Fall back.
        model_used = FALLBACK_MODEL
        fell_back = True
        fallback_reason = reason
        await emit_audit_event(
            {
                "actor_id": payload.actor_id,
                "action": "document.analysis.fallback_triggered",
                "resource_type": "document",
                "resource_id": payload.document_id,
                "business_unit_id": payload.business_unit_id,
                "project_id": payload.project_id,
                "metadata": {
                    "primary_model": payload.model_name,
                    "fallback_model": FALLBACK_MODEL,
                    "reason": reason,
                },
            },
            headers=headers,
            store=store,
        )
        topic_plan, generated_topics, dita_files, validation_issues = await _run_pipeline(
            document_id=payload.document_id,
            source_blocks=source_blocks,
            structure_tree=structure_tree,
            asset_manifest=asset_manifest,
            model_name=FALLBACK_MODEL,
            prompt_version=payload.prompt_version,
            headers=headers,
        )

    export_zip = build_export_zip(
        document_id=payload.document_id,
        topic_plan=topic_plan,
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        markdown=markdown,
    )
    artifact_args = {
        "project_id": payload.project_id,
        "document_id": payload.document_id,
        "store": store,
        "created_by": payload.actor_id,
    }
    analysis_refs = {
        "topic_plan": write_artifact(
            **artifact_args,
            name="topic-plan.json",
            content=topic_plan,
            producer="analysis-service",
        ),
        "generated_topics": write_artifact(
            **artifact_args,
            name="generated-topics.json",
            content=generated_topics,
            producer="analysis-service",
        ),
        "dita_files": write_artifact(
            **artifact_args,
            name="dita-files.json",
            content=dita_files,
            producer="analysis-service",
        ),
        "validation_report": write_artifact(
            **artifact_args,
            name="validation-report.json",
            content={"issues": validation_issues},
            producer="analysis-service",
        ),
        "export_zip": write_artifact(
            **artifact_args,
            name="document-export.zip",
            content=export_zip,
            content_type="application/zip",
            producer="analysis-service",
        ),
    }

    topic_ids = _persist_topics(
        generated_topics=generated_topics,
        dita_files=dita_files,
        validation_issues=validation_issues,
        document_id=payload.document_id,
        project_id=payload.project_id,
        business_unit_id=payload.business_unit_id,
        tenant_id=payload.tenant_id,
        generated_topics_ref=analysis_refs["generated_topics"],
    )

    await emit_audit_event(
        {
            "actor_id": payload.actor_id,
            "action": "document.analysis.completed",
            "resource_type": "document",
            "resource_id": payload.document_id,
            "business_unit_id": payload.business_unit_id,
            "project_id": payload.project_id,
            "metadata": {
                "model_used": model_used,
                "fell_back_to_fixture": fell_back,
                "topic_count": len(generated_topics),
                "validation_issue_count": len(validation_issues),
            },
        },
        headers=headers,
        store=store,
    )

    quality = structure_tree.get("quality") or {}
    overall_confidence = quality.get("overall_confidence")
    if overall_confidence is not None:
        overall_confidence = float(overall_confidence)
    return AnalysisResponse(
        document_id=payload.document_id,
        analysis_refs={k: v for k, v in analysis_refs.items()},
        topic_ids=topic_ids,
        review_required=bool(topic_plan.get("review_required", False)),
        validation_issue_count=len(validation_issues),
        block_count=len(source_blocks),
        asset_count=len(asset_manifest.get("assets", [])),
        overall_confidence=overall_confidence,
        model_requested=payload.model_name,
        model_used=model_used,
        fell_back_to_fixture=fell_back,
        fallback_reason=fallback_reason,
    )


def _persist_topics(
    *,
    generated_topics: list[dict[str, Any]],
    dita_files: dict[str, str],
    validation_issues: list[dict[str, Any]],
    document_id: str,
    project_id: str,
    business_unit_id: str,
    tenant_id: str,
    generated_topics_ref: dict[str, Any],
) -> list[str]:
    topic_ids: list[str] = []
    for topic in generated_topics:
        rid = new_id("top")
        topic_ids.append(rid)
        topic_xml = dita_files[f"topics/{topic['topic_id']}.dita"]

        def add(
            state: dict[str, Any],
            topic_dict: dict[str, Any] = topic,
            record_id: str = rid,
            xml: str = topic_xml,
        ) -> dict[str, Any]:
            # Mirrors the shape upload-service used to write. Phase 6's
            # snapshot/projection split requires both `generated_topic`
            # (immutable original incl. dita_xml for replay) and the
            # top-level mutable view.
            state["topics"][record_id] = {
                "topic_record_id": record_id,
                "topic_id": topic_dict["topic_id"],
                "tenant_id": tenant_id,
                "business_unit_id": business_unit_id,
                "project_id": project_id,
                "document_id": document_id,
                "status": "generated",
                "title": topic_dict.get("title", "Untitled"),
                "short_desc": topic_dict.get("short_desc"),
                "topic_type": topic_dict.get("topic_type", "concept"),
                "source_block_ids": list(topic_dict.get("source_block_ids", [])),
                "dita_xml": xml,
                "generated_topic": {**topic_dict, "dita_xml": xml},
                "validation_issues": validation_issues,
                "traceability": topic_dict.get("traceability", []),
                "artifact_version": generated_topics_ref["artifact_version"],
            }
            return state["topics"][record_id]

        store.mutate(add)
    return topic_ids


def __import_jsonl_line(line: str) -> dict[str, Any]:
    """Small wrapper over json.loads to keep _run_pipeline tidy."""
    import json

    return json.loads(line)
