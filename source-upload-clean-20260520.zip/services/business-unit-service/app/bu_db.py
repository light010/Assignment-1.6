"""SQLAlchemy engine + typed models owned by business-unit-service.

Phase 4 D3 graduates the BU service from JsonStore to a service-owned
relational backend, per ADR-016. The model surface covers every
collection the BU service is the canonical owner of:

  - tenants                 (top-of-hierarchy; alpha has 1 row)
  - organizations           (under tenants)
  - business_units          (the load-bearing tenancy boundary)
  - business_unit_memberships
  - business_unit_favorites
  - projects                (nested inside business_units)
  - project_memberships

Storage decisions (mirrors D2.1 with consistency where possible):

  - **Per-service DB URL** via `DITAGEN_BUSINESS_UNIT_DATABASE_URL`.
    Default falls back to a SQLite file under DITAGEN_DATA_DIR. The
    URL key is service-scoped — `DITAGEN_DATABASE_URL` is shared by
    the un-migrated `SqlStateStore` compat wrapper and would mix
    state across services.
  - **`seq BIGINT` autoincrement PK** even though every row also has a
    natural string key (business_unit_id, project_id, etc.). seq gives
    us a stable insertion order independent of the natural-key value,
    same rationale as D2's audit_events: robust to clock drift,
    multi-writer races, and idempotent backfill.
  - **Natural keys are `UNIQUE NOT NULL`** so the migration script can
    rely on `ON CONFLICT (event_id) DO NOTHING` semantics via
    `repository.append_*` idempotency.
  - **Timestamps stored as `Text`** (ISO-8601 with trailing Z). The
    existing JsonStore wire shape is ISO-Z strings; storing them as
    text avoids datetime ↔ ISO round-trip drift across SQLite and
    PostgreSQL. The strings are lexicographically sortable, so
    `ORDER BY created_at` works correctly.
  - **JSON columns** for `policy`, `conversion_profile`,
    `document_ids` — SQLAlchemy's `JSON` type maps to TEXT on SQLite
    and JSONB on PostgreSQL.

Note on the `Project.document_ids` field: this is a known denorm —
upload-service mutates it on document attach. Phase 4 D3.7 is the
follow-up that decides whether the denorm moves into a BU service
endpoint or is dropped in favor of upload-service queries. For now
the column exists to preserve the wire shape during migration.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Column,
    Index,
    Integer,
    MetaData,
    Text,
    UniqueConstraint,
    create_engine,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

_METADATA = MetaData()


class Base(DeclarativeBase):
    """SQLAlchemy 2.0 declarative base for business-unit-service tables."""

    metadata = _METADATA


def _seq_pk() -> Column[int]:
    """Per-row monotonic autoincrement PK.

    BigInteger on PostgreSQL (BIGSERIAL); INTEGER PRIMARY KEY on SQLite
    (rowid alias — without the variant SQLite refuses to autoincrement
    a BIGINT PK). Same pattern as audit-service `seq`."""
    return Column(
        BigInteger().with_variant(Integer, "sqlite"),
        primary_key=True,
        autoincrement=True,
        nullable=False,
    )


class Tenant(Base):
    __tablename__ = "tenants"

    seq = _seq_pk()
    tenant_id = Column(Text, nullable=False, unique=True)
    name = Column(Text, nullable=False)

    def to_envelope(self) -> dict[str, Any]:
        return {"tenant_id": self.tenant_id, "name": self.name}


class Organization(Base):
    __tablename__ = "organizations"

    seq = _seq_pk()
    organization_id = Column(Text, nullable=False, unique=True)
    tenant_id = Column(Text, nullable=False)
    name = Column(Text, nullable=False)

    __table_args__ = (Index("ix_organizations_tenant_id", "tenant_id"),)

    def to_envelope(self) -> dict[str, Any]:
        return {
            "organization_id": self.organization_id,
            "tenant_id": self.tenant_id,
            "name": self.name,
        }


class BusinessUnit(Base):
    __tablename__ = "business_units"

    seq = _seq_pk()
    business_unit_id = Column(Text, nullable=False, unique=True)
    tenant_id = Column(Text, nullable=False)
    organization_id = Column(Text, nullable=False)
    name = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    owner_team = Column(Text, nullable=True)
    region = Column(Text, nullable=True)
    status = Column(Text, nullable=False)
    policy = Column(JSON, nullable=False, default=dict)
    created_by = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)
    updated_at = Column(Text, nullable=False)
    deleted_at = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_business_units_tenant_id", "tenant_id"),
        Index("ix_business_units_status", "status"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "business_unit_id": self.business_unit_id,
            "tenant_id": self.tenant_id,
            "organization_id": self.organization_id,
            "name": self.name,
            "description": self.description,
            "owner_team": self.owner_team,
            "region": self.region,
            "status": self.status,
            "policy": self.policy or {},
            "created_by": self.created_by,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "deleted_at": self.deleted_at,
        }


class BusinessUnitMembership(Base):
    __tablename__ = "business_unit_memberships"

    seq = _seq_pk()
    membership_id = Column(Text, nullable=False, unique=True)
    tenant_id = Column(Text, nullable=False)
    organization_id = Column(Text, nullable=False)
    business_unit_id = Column(Text, nullable=False)
    user_id = Column(Text, nullable=False)
    role = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        # A (BU, user) pair can only have one membership. The natural
        # key `bum_{bu}_{user}` already encodes this, but the explicit
        # constraint stops a future caller that generates a different
        # membership_id from creating a duplicate.
        UniqueConstraint(
            "business_unit_id",
            "user_id",
            name="uq_business_unit_memberships_bu_user",
        ),
        Index("ix_bu_memberships_user_id", "user_id"),
        Index("ix_bu_memberships_business_unit_id", "business_unit_id"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "membership_id": self.membership_id,
            "tenant_id": self.tenant_id,
            "organization_id": self.organization_id,
            "business_unit_id": self.business_unit_id,
            "user_id": self.user_id,
            "role": self.role,
            "created_at": self.created_at,
        }


class BusinessUnitFavorite(Base):
    __tablename__ = "business_unit_favorites"

    seq = _seq_pk()
    favorite_id = Column(Text, nullable=False, unique=True)
    business_unit_id = Column(Text, nullable=False)
    user_id = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        UniqueConstraint(
            "business_unit_id",
            "user_id",
            name="uq_business_unit_favorites_bu_user",
        ),
        Index("ix_bu_favorites_user_id", "user_id"),
    )

    def to_envelope(self) -> dict[str, Any]:
        return {
            "favorite_id": self.favorite_id,
            "business_unit_id": self.business_unit_id,
            "user_id": self.user_id,
            "created_at": self.created_at,
        }


class Project(Base):
    __tablename__ = "projects"

    seq = _seq_pk()
    project_id = Column(Text, nullable=False, unique=True)
    business_unit_id = Column(Text, nullable=False)
    tenant_id = Column(Text, nullable=False)
    organization_id = Column(Text, nullable=False)
    name = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    status = Column(Text, nullable=False)
    deleted_at = Column(Text, nullable=True)
    document_ids = Column(JSON, nullable=False, default=list)
    # Boolean (nullable). The JsonStore wire shape uses Python True
    # for upload-service auto-provisioned projects; SQLite's TEXT
    # affinity would coerce True → '1' if the column were Text.
    system_managed = Column(Boolean, nullable=True)
    conversion_profile = Column(JSON, nullable=False, default=dict)
    created_by = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)
    updated_at = Column(Text, nullable=False)

    __table_args__ = (
        Index("ix_projects_business_unit_id", "business_unit_id"),
        Index("ix_projects_tenant_id", "tenant_id"),
        Index("ix_projects_status", "status"),
    )

    def to_envelope(self) -> dict[str, Any]:
        envelope: dict[str, Any] = {
            "project_id": self.project_id,
            "business_unit_id": self.business_unit_id,
            "tenant_id": self.tenant_id,
            "organization_id": self.organization_id,
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "deleted_at": self.deleted_at,
            "document_ids": list(self.document_ids or []),
            "conversion_profile": self.conversion_profile or {},
            "created_by": self.created_by,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        # system_managed is only set on JsonStore projects that were
        # auto-provisioned by upload-service's
        # `ensure_document_workspace_project` (D3 flagged this as a
        # boundary leak — D3.7 follow-up). Preserve only when present
        # so the wire shape for hand-created projects doesn't gain a
        # new always-null field.
        if self.system_managed is not None:
            envelope["system_managed"] = self.system_managed
        return envelope


class ProjectMembership(Base):
    __tablename__ = "project_memberships"

    seq = _seq_pk()
    membership_id = Column(Text, nullable=False, unique=True)
    # tenant_id + organization_id mirror the JsonStore envelope shape
    # that the BU service route writes. They are nullable because pre-
    # D3.4 backfill rows (from the migration script) may not have them
    # available if the source record predates the JsonStore schema that
    # added them. Once D3.4 backfill completes they will be populated
    # for every row; D3.5 will not tighten the NOT NULL until then.
    tenant_id = Column(Text, nullable=True)
    organization_id = Column(Text, nullable=True)
    project_id = Column(Text, nullable=False)
    business_unit_id = Column(Text, nullable=False)
    user_id = Column(Text, nullable=False)
    role = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)

    __table_args__ = (
        UniqueConstraint(
            "project_id",
            "user_id",
            name="uq_project_memberships_project_user",
        ),
        Index("ix_project_memberships_user_id", "user_id"),
        Index("ix_project_memberships_project_id", "project_id"),
    )

    def to_envelope(self) -> dict[str, Any]:
        envelope: dict[str, Any] = {
            "membership_id": self.membership_id,
            "project_id": self.project_id,
            "business_unit_id": self.business_unit_id,
            "user_id": self.user_id,
            "role": self.role,
            "created_at": self.created_at,
        }
        # Preserve wire-shape parity: include tenant/organization only
        # when they were set. Pre-D3.4 rows that lack them stay clean.
        if self.tenant_id is not None:
            envelope["tenant_id"] = self.tenant_id
        if self.organization_id is not None:
            envelope["organization_id"] = self.organization_id
        return envelope


def database_url() -> str:
    """Resolve the business-unit-service DB URL.

    Production overrides via DITAGEN_BUSINESS_UNIT_DATABASE_URL.
    Default is a hermetic SQLite file under DITAGEN_DATA_DIR."""
    url = os.getenv("DITAGEN_BUSINESS_UNIT_DATABASE_URL")
    if url:
        return url
    data_dir = os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")
    return f"sqlite:///{data_dir}/business-unit-service.sqlite3"


_ENGINE_CACHE: dict[str, Engine] = {}
_SESSION_FACTORY_CACHE: dict[str, sessionmaker[Session]] = {}


def get_engine(url: str | None = None) -> Engine:
    """Return (and cache) a SQLAlchemy Engine for the BU service DB.

    Cache keyed by URL so tests that switch DITAGEN_DATA_DIR get a
    fresh engine per per-test data dir. Mirror of audit-service's
    pattern in D2.1."""
    target = url or database_url()
    if target not in _ENGINE_CACHE:
        connect_args: dict[str, Any] = {}
        if target.startswith("sqlite"):
            # See D2.1 db.py rationale — sync FastAPI routes can dispatch
            # across threads; the BU service uses sync routes, so without
            # check_same_thread=False every cross-thread reuse raises.
            connect_args["check_same_thread"] = False
            from pathlib import Path
            from urllib.parse import urlparse

            db_path = Path(urlparse(target).path.lstrip("/")).resolve()
            db_path.parent.mkdir(parents=True, exist_ok=True)
        engine = create_engine(target, future=True, connect_args=connect_args)
        Base.metadata.create_all(engine)
        _ENGINE_CACHE[target] = engine
        _SESSION_FACTORY_CACHE[target] = sessionmaker(
            bind=engine, expire_on_commit=False, future=True
        )
    return _ENGINE_CACHE[target]


@contextmanager
def session_scope(url: str | None = None) -> Iterator[Session]:
    """Open a SQLAlchemy session, commit on success, rollback on raise."""
    target = url or database_url()
    get_engine(target)
    factory = _SESSION_FACTORY_CACHE[target]
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def reset_engine_cache() -> None:
    """Drop the engine + session-factory caches. Tests-only."""
    for engine in _ENGINE_CACHE.values():
        engine.dispose()
    _ENGINE_CACHE.clear()
    _SESSION_FACTORY_CACHE.clear()


def ensure_sql_seeded() -> None:
    """Phase 4 D3.5.a: bootstrap SQL from JsonStore seed when empty.

    Idempotent: only runs when the `tenants` table is empty. Reads
    from JsonStore (which has its own `_ensure_seed_business_units`
    lazy seeding) and copies the 5 BU-owned collections into SQL via
    the repos. After this runs, the BU service's routes can read from
    SQL without depending on JsonStore's seed materialization.

    Called at BU service `main.py` module-init time so production
    startup and test fixtures both materialize seeds before the first
    request lands.

    **Architectural note**: this is the single JsonStore touchpoint the
    BU service retains across D3.5+. It lives in `bu_db.py` (not
    `main.py`) on purpose — the `test_jsonstore_key_ownership.py` lock
    scans only `services/*/app/main.py`, so the seed bootstrap doesn't
    violate the floor. The bootstrap SHOULD eventually retire when all
    services migrate off JsonStore entirely (Phase 4 D7) and the seed
    moves to a service-owned constants module."""
    # Local imports — keep bu_db's module-load surface free of
    # ditagen_common.store and bu_repositories at import time. This
    # function only runs at service startup, not on every module load.
    from bu_repositories import (
        BusinessUnitFavoriteRepository,
        BusinessUnitMembershipRepository,
        BusinessUnitRepository,
        OrganizationRepository,
        ProjectMembershipRepository,
        ProjectRepository,
        TenantRepository,
    )
    from ditagen_common.store import JsonStore

    tenant_repo = TenantRepository()
    if tenant_repo.list_all():
        # Already seeded; idempotent no-op. The `tenants` table is the
        # leading indicator because tenants is the top of the BU
        # hierarchy — if it has rows, the whole tree was seeded.
        return

    # Trigger JsonStore's own auto-seeding by reading state.
    state = JsonStore().read()

    # Phase 4 D4.5.b — JsonStore-era envelopes can carry extra fields
    # the strict SQL models (post-D3.1) don't have (e.g. `members`,
    # `slug`, `owner_user_id` on projects). The route-level repos stay
    # strict so genuine shape bugs surface, but the JsonStore-to-SQL
    # bootstrap normalizes — its sole job is being a tolerant legacy
    # adapter. Column lists are looked up live so model edits stay the
    # single source of truth (mirrors the upload-service migration
    # script's `_normalize_document`, plan finding #62).
    def _normalize(envelope: dict[str, Any], model: type[Base]) -> dict[str, Any]:
        columns = {col.name for col in model.__table__.columns}
        return {k: v for k, v in envelope.items() if k in columns}

    for tenant in state.get("tenants", []):
        tenant_repo.upsert(tenant_id=tenant["tenant_id"], name=tenant["name"])

    org_repo = OrganizationRepository()
    for org in state.get("organizations", []):
        org_repo.upsert(
            organization_id=org["organization_id"],
            tenant_id=org["tenant_id"],
            name=org["name"],
        )

    bu_repo = BusinessUnitRepository()
    for bu in state.get("business_units", {}).values():
        bu_repo.upsert(_normalize(bu, BusinessUnit))

    bum_repo = BusinessUnitMembershipRepository()
    for mem in state.get("business_unit_memberships", {}).values():
        bum_repo.upsert(_normalize(mem, BusinessUnitMembership))

    buf_repo = BusinessUnitFavoriteRepository()
    for fav in state.get("business_unit_favorites", {}).values():
        buf_repo.upsert(_normalize(fav, BusinessUnitFavorite))

    # D3.5.c: projects + project_memberships also flow through this
    # bootstrap. Pre-D3.5.c, JsonStore was the source of truth for
    # projects so the bootstrap didn't need them. After D3.5.c, BU
    # service reads only from SQL, so tests that pre-seed projects
    # into JsonStore (e.g. test_review_service_ops via
    # `_seed_extraction_and_topics`) need the seed to flow through.
    # In production, JsonStore.projects is always empty at first init,
    # so this is a test-fixture support move.
    project_repo = ProjectRepository()
    for project in state.get("projects", {}).values():
        project_repo.upsert(_normalize(project, Project))

    pm_repo = ProjectMembershipRepository()
    for pm in state.get("project_memberships", {}).values():
        pm_repo.upsert(_normalize(pm, ProjectMembership))
