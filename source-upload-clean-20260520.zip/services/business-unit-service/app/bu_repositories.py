"""Business-unit-service repositories — Phase 4 D3.

Each collection that the BU service owns has its own repository class
exposing the primitives the routes (D3.3) and the migration script
(D3.4) need. Wire-shape envelopes are produced by `to_envelope()` on
the ORM model so route consumers see the JsonStore-compatible record
shape — preserving the contract while the storage backend changes
under the hood.

Idempotency rule (applies to every `upsert` / `add_*` method): the
natural key (business_unit_id, project_id, membership_id, …) is the
dedup key. A second call with the same natural key updates the row
in place rather than inserting a duplicate. This is required for the
migration script (D3.4) to be safely re-runnable.

Design notes:

  - Each repo opens a short-lived session per method (mirrors the D2
    AuditEventRepository pattern). No long-lived sessions; the BU
    service is stateless HTTP.
  - Returns are envelope dicts, never ORM objects. ORM rows escaping
    the repo would tie callers to the storage shape.
  - Tenant/visibility filtering stays at the ROUTE level (it depends
    on `current_user`, an HTTP concept). Repos are tenant-agnostic;
    they take the filter as an argument when the route asks them to.
"""

from __future__ import annotations

from typing import Any

from bu_db import (
    BusinessUnit,
    BusinessUnitFavorite,
    BusinessUnitMembership,
    Organization,
    Project,
    ProjectMembership,
    Tenant,
    session_scope,
)
from sqlalchemy import select


class TenantRepository:
    """Tenants are seeded once; queried often, rarely mutated."""

    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, *, tenant_id: str, name: str) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(select(Tenant).where(Tenant.tenant_id == tenant_id))
            if row is None:
                row = Tenant(tenant_id=tenant_id, name=name)
                session.add(row)
            else:
                # The Column[str] vs str mypy mismatch is the same
                # SQLAlchemy class-vs-instance attribute tension D2
                # navigated with `int(row.seq)` casts on reads. For
                # writes, type: ignore is the cleanest expression of
                # "this is a SQLAlchemy descriptor, instance-level
                # assignment is fine."
                row.name = name  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()

    def get(self, tenant_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(select(Tenant).where(Tenant.tenant_id == tenant_id))
            return row.to_envelope() if row else None

    def list_all(self) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            return [row.to_envelope() for row in session.scalars(select(Tenant).order_by(Tenant.seq))]


class OrganizationRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(
        self, *, organization_id: str, tenant_id: str, name: str
    ) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Organization).where(Organization.organization_id == organization_id)
            )
            if row is None:
                row = Organization(
                    organization_id=organization_id, tenant_id=tenant_id, name=name
                )
                session.add(row)
            else:
                row.tenant_id = tenant_id  # type: ignore[assignment]
                row.name = name  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()

    def get(self, organization_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Organization).where(Organization.organization_id == organization_id)
            )
            return row.to_envelope() if row else None

    def list_for_tenant(self, tenant_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(Organization).where(Organization.tenant_id == tenant_id).order_by(Organization.seq)
            return [row.to_envelope() for row in session.scalars(stmt)]


class BusinessUnitRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        """Insert or update a business unit by `business_unit_id`."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(BusinessUnit).where(
                    BusinessUnit.business_unit_id == envelope["business_unit_id"]
                )
            )
            if row is None:
                row = BusinessUnit(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, business_unit_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(BusinessUnit).where(BusinessUnit.business_unit_id == business_unit_id)
            )
            return row.to_envelope() if row else None

    def list_for_tenant(
        self, tenant_id: str, *, include_archived: bool = False
    ) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(BusinessUnit).where(BusinessUnit.tenant_id == tenant_id)
            if not include_archived:
                stmt = stmt.where(BusinessUnit.status != "archived")
            stmt = stmt.order_by(BusinessUnit.name)
            return [row.to_envelope() for row in session.scalars(stmt)]


class BusinessUnitMembershipRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            # The (business_unit_id, user_id) UNIQUE constraint is the
            # authoritative dedup — even if the natural-key envelope's
            # `membership_id` differs (a future caller generating a
            # different id format), the (bu, user) tuple wins. So we
            # query by that tuple first, fall back to membership_id.
            row = session.scalar(
                select(BusinessUnitMembership).where(
                    BusinessUnitMembership.business_unit_id == envelope["business_unit_id"],
                    BusinessUnitMembership.user_id == envelope["user_id"],
                )
            )
            if row is None:
                row = BusinessUnitMembership(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def list_for_business_unit(self, business_unit_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(BusinessUnitMembership).where(
                BusinessUnitMembership.business_unit_id == business_unit_id
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_user(self, user_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(BusinessUnitMembership).where(
                BusinessUnitMembership.user_id == user_id
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def get_role(self, business_unit_id: str, user_id: str) -> str | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(BusinessUnitMembership).where(
                    BusinessUnitMembership.business_unit_id == business_unit_id,
                    BusinessUnitMembership.user_id == user_id,
                )
            )
            return str(row.role) if row is not None else None


class BusinessUnitFavoriteRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(BusinessUnitFavorite).where(
                    BusinessUnitFavorite.business_unit_id == envelope["business_unit_id"],
                    BusinessUnitFavorite.user_id == envelope["user_id"],
                )
            )
            if row is None:
                row = BusinessUnitFavorite(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def remove(self, *, business_unit_id: str, user_id: str) -> bool:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(BusinessUnitFavorite).where(
                    BusinessUnitFavorite.business_unit_id == business_unit_id,
                    BusinessUnitFavorite.user_id == user_id,
                )
            )
            if row is None:
                return False
            session.delete(row)
            return True

    def list_for_user(self, user_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(BusinessUnitFavorite).where(
                BusinessUnitFavorite.user_id == user_id
            )
            return [row.to_envelope() for row in session.scalars(stmt)]


class ProjectRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        """Insert or update a project by `project_id`.

        Accepts `system_managed` optionally (some JsonStore-era
        projects carry it; hand-created ones don't). The repo
        defaults it to None when absent so the schema's nullable
        column behaves consistently."""
        payload = dict(envelope)
        payload.setdefault("system_managed", None)
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Project).where(Project.project_id == payload["project_id"])
            )
            if row is None:
                row = Project(**payload)
                session.add(row)
            else:
                for field, value in payload.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def get(self, project_id: str) -> dict[str, Any] | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Project).where(Project.project_id == project_id)
            )
            return row.to_envelope() if row else None

    def list_for_business_unit(
        self, business_unit_id: str, *, include_archived: bool = False
    ) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(Project).where(Project.business_unit_id == business_unit_id)
            if not include_archived:
                stmt = stmt.where(Project.status != "archived")
            stmt = stmt.order_by(Project.created_at)
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_tenant(
        self, tenant_id: str, *, include_archived: bool = False
    ) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(Project).where(Project.tenant_id == tenant_id)
            if not include_archived:
                stmt = stmt.where(Project.status != "archived")
            stmt = stmt.order_by(Project.created_at)
            return [row.to_envelope() for row in session.scalars(stmt)]

    def append_document_id(
        self, project_id: str, document_id: str
    ) -> dict[str, Any] | None:
        """Append document_id to `project.document_ids` if not already
        present. Idempotent on document_id; returns None if project
        doesn't exist.

        Paired with `remove_document_id`. These two methods are the
        BU service's controlled write surface for the document_ids
        denorm — Phase 4 D3.7 migrates upload-service off direct
        JsonStore mutation onto the BU service endpoints that wrap
        these methods."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Project).where(Project.project_id == project_id)
            )
            if row is None:
                return None
            current = list(row.document_ids or [])
            if document_id not in current:
                current.append(document_id)
                row.document_ids = current  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()

    def remove_document_id(
        self, project_id: str, document_id: str
    ) -> dict[str, Any] | None:
        """Remove document_id from `project.document_ids` if present.
        Idempotent (no-op if absent); returns None if project doesn't
        exist. Symmetric with `append_document_id`."""
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(Project).where(Project.project_id == project_id)
            )
            if row is None:
                return None
            current = list(row.document_ids or [])
            if document_id in current:
                current.remove(document_id)
                row.document_ids = current  # type: ignore[assignment]
            session.flush()
            return row.to_envelope()


class ProjectMembershipRepository:
    def __init__(self, *, database_url: str | None = None) -> None:
        self._database_url = database_url

    def upsert(self, envelope: dict[str, Any]) -> dict[str, Any]:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(ProjectMembership).where(
                    ProjectMembership.project_id == envelope["project_id"],
                    ProjectMembership.user_id == envelope["user_id"],
                )
            )
            if row is None:
                row = ProjectMembership(**envelope)
                session.add(row)
            else:
                for field, value in envelope.items():
                    setattr(row, field, value)
            session.flush()
            return row.to_envelope()

    def list_for_project(self, project_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(ProjectMembership).where(
                ProjectMembership.project_id == project_id
            )
            return [row.to_envelope() for row in session.scalars(stmt)]

    def list_for_user(self, user_id: str) -> list[dict[str, Any]]:
        with session_scope(self._database_url) as session:
            stmt = select(ProjectMembership).where(ProjectMembership.user_id == user_id)
            return [row.to_envelope() for row in session.scalars(stmt)]

    def get_role(self, project_id: str, user_id: str) -> str | None:
        with session_scope(self._database_url) as session:
            row = session.scalar(
                select(ProjectMembership).where(
                    ProjectMembership.project_id == project_id,
                    ProjectMembership.user_id == user_id,
                )
            )
            return str(row.role) if row is not None else None
