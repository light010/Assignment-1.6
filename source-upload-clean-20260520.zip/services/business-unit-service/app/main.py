from __future__ import annotations

import os
from typing import Any

from bu_db import ensure_sql_seeded
from bu_repositories import (
    BusinessUnitFavoriteRepository,
    BusinessUnitMembershipRepository,
    BusinessUnitRepository,
    ProjectMembershipRepository,
    ProjectRepository,
)
from ditagen_common.auth import (
    assert_role,
    context_headers,
    current_user,
)
from ditagen_common.ids import new_id
from ditagen_common.service_app import create_service_app
from ditagen_common.service_clients import (
    emit_audit_event,
    list_audit_events,
    request_service,
)
from ditagen_common.store import utc_now
from ditagen_common.store_factory import create_store
from fastapi import Body, Depends, HTTPException, Request
from pydantic import BaseModel, Field

app = create_service_app("business-unit-service")
store = create_store("business-unit-service")

UPLOAD_SERVICE_URL = os.getenv(
    "DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000"
)

# Phase 4 D3.5.a — bootstrap SQL from JsonStore seed on startup.
# Idempotent: runs only when SQL `tenants` table is empty. After this,
# the BU service's reads can graduate to SQL without depending on
# JsonStore's lazy `_ensure_seed_business_units` materialization.
# See bu_db.ensure_sql_seeded() for the architectural rationale.
ensure_sql_seeded()

# Phase 4 D3.5.c — SQL is authoritative.
#
# These repos are the canonical write target for the BU service's owned
# collections (business_units, bu_memberships, projects,
# project_memberships, bu_favorites). The dual-write bridge from D3.3
# is retired: routes call repo.upsert() directly and any failure
# surfaces as a 500 to the caller. JsonStore is still consulted for
# foreign reads (documents, jobs, topics, artifact_registry — owned by
# other services and tracked in test_jsonstore_key_ownership.py).
business_unit_repo = BusinessUnitRepository()
bu_membership_repo = BusinessUnitMembershipRepository()
bu_favorite_repo = BusinessUnitFavoriteRepository()
project_repo = ProjectRepository()
project_membership_repo = ProjectMembershipRepository()


# Phase 4 D3.5.b — repo-based authorization helpers.
#
# These mirror the semantics of the four `ditagen_common.auth` state-
# dict helpers (require_business_unit, require_project,
# can_access_business_unit, can_access_project) but resolve the entity
# and the membership via the BU service's own repositories instead of
# subscripting a JsonStore-shaped state dict. D3.5.b/c routes adopt
# these one-by-one; the shared `ditagen_common.auth.*` helpers stay
# available for upload-service until that boundary leak (D3.7) is
# fully closed and they can retire.
#
# Why two near-duplicate helper families exist in the codebase today:
# the upload-service still imports the state-dict shape from
# ditagen_common. Refactoring those helpers in place would ripple
# into upload-service, which has its own migration path. Local repo-
# based helpers here let BU service complete its migration without
# blocking on upload-service's.


def _membership_role_via_repo(
    business_unit_id: str, user_id: str
) -> str | None:
    """Repo-backed equivalent of `ditagen_common.auth.business_unit_membership(...)`.

    Returns the membership role string for (business_unit_id, user_id)
    or None if no membership exists."""
    return bu_membership_repo.get_role(business_unit_id, user_id)


def _can_access_business_unit_via_repo(
    business_unit: dict[str, Any],
    user: dict[str, Any],
    *,
    required_membership_roles: set[str] | None = None,
) -> bool:
    """Mirror of `ditagen_common.auth.can_access_business_unit`.

    Same logic, but reads the membership via the repo instead of
    iterating `state["business_unit_memberships"].values()`."""
    if business_unit.get("tenant_id") != user.get("tenant_id"):
        return False
    if set(user.get("roles", [])) & {"org_admin"}:
        return True
    role = _membership_role_via_repo(
        business_unit["business_unit_id"], user["user_id"]
    )
    if role is None:
        return False
    return required_membership_roles is None or role in required_membership_roles


def _require_business_unit_via_repo(
    business_unit_id: str,
    user: dict[str, Any],
    *,
    include_deleted: bool = False,
    required_membership_roles: set[str] | None = None,
) -> dict[str, Any]:
    """Mirror of `ditagen_common.auth.require_business_unit`.

    Resolves the BU via `business_unit_repo.get(...)` and the access
    check via the repo. Raises HTTPException(404) on missing/archived,
    (403) on access denial — same status codes as the shared helper
    so the response contract is preserved exactly."""
    business_unit = business_unit_repo.get(business_unit_id)
    if (
        not business_unit
        or business_unit.get("tenant_id") != user.get("tenant_id")
        or (not include_deleted and business_unit.get("status") == "archived")
    ):
        raise HTTPException(status_code=404, detail="Business unit not found")
    if not _can_access_business_unit_via_repo(
        business_unit,
        user,
        required_membership_roles=required_membership_roles,
    ):
        raise HTTPException(status_code=403, detail="Business unit access denied")
    return business_unit


def _can_access_project_via_repo(
    project: dict[str, Any],
    user: dict[str, Any],
    *,
    required_membership_roles: set[str] | None = None,
) -> bool:
    """Mirror of `ditagen_common.auth.can_access_project`.

    Includes the BU-membership cascade (`bu_admin` can act as
    `project_admin`) — the same precedence the shared helper has."""
    if project.get("tenant_id") != user.get("tenant_id"):
        return False
    business_unit_id = project.get("business_unit_id")
    if not business_unit_id:
        return False
    if set(user.get("roles", [])) & {"org_admin"}:
        return True
    project_role = project_membership_repo.get_role(
        project["project_id"], user["user_id"]
    )
    if project_role and (
        required_membership_roles is None
        or project_role in required_membership_roles
    ):
        return True
    bu_role = _membership_role_via_repo(business_unit_id, user["user_id"])
    if bu_role is None:
        return False
    if required_membership_roles is None:
        return True
    return "project_admin" in required_membership_roles and bu_role == "bu_admin"


def _require_project_via_repo(
    project_id: str,
    user: dict[str, Any],
    *,
    include_deleted: bool = False,
    required_membership_roles: set[str] | None = None,
) -> dict[str, Any]:
    """Mirror of `ditagen_common.auth.require_project`."""
    project = project_repo.get(project_id)
    if (
        not project
        or project.get("tenant_id") != user.get("tenant_id")
        or (not include_deleted and project.get("status") == "archived")
    ):
        raise HTTPException(status_code=404, detail="Project not found")
    if not _can_access_project_via_repo(
        project,
        user,
        required_membership_roles=required_membership_roles,
    ):
        raise HTTPException(status_code=403, detail="Project access denied")
    return project


class ProjectCreateRequest(BaseModel):
    business_unit_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    description: str | None = None


class ProjectUpdateRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1)
    description: str | None = None


class BusinessUnitCreateRequest(BaseModel):
    name: str = Field(min_length=1)
    description: str | None = None
    owner_team: str | None = None
    region: str | None = None


class BusinessUnitUpdateRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1)
    description: str | None = None
    owner_team: str | None = None
    region: str | None = None


class ProjectAppendDocumentRequest(BaseModel):
    document_id: str = Field(min_length=1)


def default_conversion_profile() -> dict[str, Any]:
    return {
        "target_dita_version": "1.3",
        "allowed_topic_types": ["concept", "task", "reference", "troubleshooting", "glossary"],
        "review_policy": "allow_alpha_export_with_warnings",
    }


def default_business_unit_policy() -> dict[str, Any]:
    return {
        "target_dita_version": "1.3",
        "allowed_upload_extensions": [".docx", ".pdf", ".txt", ".md", ".html", ".htm"],
        "max_upload_bytes": 250 * 1024 * 1024,
        "review_policy": "manual_approval",
    }


async def _fetch_project_documents_via_upload_service(
    request: Request, project_id: str, user: dict[str, Any]
) -> list[dict[str, Any]]:
    """Phase 4 D4.4.b: documents joined into project responses come from
    upload-service (the owner). Replaces the JsonStore subscript
    `state["documents"][doc_id]` that filtered by the BU service's
    `project.document_ids` denorm.

    Returns an empty list if upload-service is unreachable or the
    project has no documents — never raises. The project envelope's
    `documents` field is a denorm convenience for the workbench UI;
    failing the parent project read because of a documents-fetch hiccup
    would be worse than degrading the response. Categorically the
    same best-effort pattern as upload-service's `_append_document_to_
    project_via_bu_service` (finding #24)."""
    try:
        response = await request_service(
            method="GET",
            base_url=UPLOAD_SERVICE_URL,
            path=f"/internal/projects/{project_id}/documents",
            headers=context_headers(request, user),
        )
    except Exception:  # noqa: BLE001 — see docstring; best-effort denorm
        return []
    if response.status_code != 200:
        return []
    return list(response.json().get("documents", []))


async def project_with_documents(
    project: dict[str, Any], request: Request, user: dict[str, Any]
) -> dict[str, Any]:
    """Phase 4 D4.4.b: filters by `document.project_id` (canonical),
    not `project.document_ids` (denorm). Documents fetched from
    upload-service via the project-scoped endpoint."""
    documents = await _fetch_project_documents_via_upload_service(
        request, project["project_id"], user
    )
    return {**project, "documents": documents}


async def _fetch_project_storage_summary_via_upload_service(
    request: Request, project_id: str, user: dict[str, Any]
) -> dict[str, Any]:
    """Phase 4 D4.4.c: upload-side KPI counters come from upload-service.

    Returns the 8-field upload-side aggregation (document_count,
    processing_count, review_ready_count, validation_warning_count,
    failed_job_count, storage_bytes, confidence_values,
    topic_id_count). Best-effort — degrades to zeros if upload-service
    is unreachable, mirroring the documents-fetch pattern (the
    summary is a UI rollup, not load-bearing data)."""
    fallback = {
        "document_count": 0,
        "processing_count": 0,
        "review_ready_count": 0,
        "validation_warning_count": 0,
        "failed_job_count": 0,
        "storage_bytes": 0,
        "confidence_values": [],
        "topic_id_count": 0,
    }
    try:
        response = await request_service(
            method="GET",
            base_url=UPLOAD_SERVICE_URL,
            path=f"/internal/projects/{project_id}/storage-summary",
            headers=context_headers(request, user),
        )
    except Exception:  # noqa: BLE001 — best-effort summary
        return fallback
    if response.status_code != 200:
        return fallback
    payload = response.json()
    return {key: payload.get(key, value) for key, value in fallback.items()}


async def project_status_summary(
    project: dict[str, Any],
    state: dict[str, Any],
    request: Request,
    user: dict[str, Any],
) -> dict[str, Any]:
    """Phase 4 D4.4.c: upload-side KPI fields delegated to upload-service.

    Topic-status fields (`approved_topics`, `export_ready_count`)
    remain JsonStore reads against `state["topics"]` because review-
    service hasn't migrated yet — review-service-owned migration is
    D5 work. Per the no-backcompat invariant, when D5 lands these
    reads switch to review-service via `request_service` in one step;
    no transitional shim here."""
    upload_summary = await _fetch_project_storage_summary_via_upload_service(
        request, project["project_id"], user
    )
    approved_topics = sum(
        1
        for topic in state.get("topics", {}).values()
        if topic.get("project_id") == project["project_id"]
        and topic.get("status") == "approved"
    )
    topic_id_count = upload_summary["topic_id_count"]
    export_ready = (
        1 if topic_id_count > 0 and approved_topics == topic_id_count else 0
    )
    return {
        "document_count": upload_summary["document_count"],
        "processing_count": upload_summary["processing_count"],
        "review_ready_count": upload_summary["review_ready_count"],
        "validation_warning_count": upload_summary["validation_warning_count"],
        "failed_job_count": upload_summary["failed_job_count"],
        "export_ready_count": export_ready,
        "storage_bytes": upload_summary["storage_bytes"],
        "confidence_values": list(upload_summary["confidence_values"]),
        "last_activity_at": project.get("updated_at") or project.get("created_at"),
    }


def dominant_status(summary: dict[str, Any]) -> str:
    if summary["failed_job_count"]:
        return "Failed"
    if summary["validation_warning_count"]:
        return "Validation Warnings"
    if summary["review_ready_count"]:
        return "Needs Review"
    if summary["processing_count"]:
        return "Processing"
    if summary["export_ready_count"]:
        return "Export Ready"
    return "Idle"


async def business_unit_summary(
    business_unit: dict[str, Any],
    state: dict[str, Any],
    request: Request,
    user: dict[str, Any],
) -> dict[str, Any]:
    """Phase 4 D3.5.b.3: owned reads via repos, foreign reads via state.

    - `projects` for this BU: `project_repo.list_for_business_unit`
      (owned). Access filter: `_can_access_project_via_repo`.
    - `current_user_role`: `bu_membership_repo.get_role` (owned).
    - `is_favorite`: `bu_favorite_repo.list_for_user` (owned).
    - `project_status_summary` and document/job/topic/artifact joins
      still take `state` because those collections are foreign-owned
      (upload-service / review-service). Their migration happens in
      later D-steps when those services own typed backends."""
    projects = [
        project
        for project in project_repo.list_for_business_unit(
            business_unit["business_unit_id"]
        )
        if _can_access_project_via_repo(project, user)
    ]
    project_summaries = [
        await project_status_summary(project, state, request, user)
        for project in projects
    ]
    confidence_values = [
        value
        for summary in project_summaries
        for value in summary["confidence_values"]
        if value is not None
    ]
    last_activity_candidates = [
        value for summary in project_summaries if (value := summary.get("last_activity_at"))
    ] + [business_unit.get("updated_at") or business_unit.get("created_at")]
    summary = {
        "project_count": len(projects),
        "document_count": sum(item["document_count"] for item in project_summaries),
        "processing_count": sum(item["processing_count"] for item in project_summaries),
        "review_ready_count": sum(item["review_ready_count"] for item in project_summaries),
        "validation_warning_count": sum(item["validation_warning_count"] for item in project_summaries),
        "failed_job_count": sum(item["failed_job_count"] for item in project_summaries),
        "export_ready_count": sum(item["export_ready_count"] for item in project_summaries),
        "avg_source_confidence": (
            sum(confidence_values) / len(confidence_values) if confidence_values else None
        ),
        "storage_bytes": sum(item["storage_bytes"] for item in project_summaries),
        "last_activity_at": max(last_activity_candidates) if last_activity_candidates else None,
        "current_user_role": (
            "org_admin"
            if "org_admin" in user.get("roles", [])
            else _membership_role_via_repo(
                business_unit["business_unit_id"], user["user_id"]
            )
        ),
        "is_favorite": any(
            favorite.get("business_unit_id") == business_unit["business_unit_id"]
            for favorite in bu_favorite_repo.list_for_user(user["user_id"])
        ),
    }
    return {
        **business_unit,
        "summary": {**summary, "dominant_status_label": dominant_status(summary)},
    }


@app.get("/internal/business-units")
async def list_business_units(
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # Phase 4 D3.5.b.2: owned-collection read via repo.
    candidate_bus = business_unit_repo.list_for_tenant(user["tenant_id"])
    # `state.read()` stays for `topics` (review-service-owned, D5).
    # Upload-side KPI fields now come from upload-service via
    # request_service (D4.4.c).
    state = store.read()
    accessible_bus = [
        bu for bu in candidate_bus if _can_access_business_unit_via_repo(bu, user)
    ]
    business_units = [
        await business_unit_summary(bu, state, request, user) for bu in accessible_bus
    ]
    business_units.sort(key=lambda item: item["name"].lower())
    return {"business_units": business_units}


@app.post("/internal/business-units")
async def create_business_unit(
    request_body: BusinessUnitCreateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin"})
    business_unit_id = new_id("bu")
    membership_id = f"bum_{business_unit_id}_{user['user_id']}"
    now = utc_now()
    business_unit = {
        "business_unit_id": business_unit_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "name": request_body.name,
        "description": request_body.description,
        "owner_team": request_body.owner_team or "Unassigned",
        "region": request_body.region or "Global",
        "status": "active",
        "policy": default_business_unit_policy(),
        "created_by": user["user_id"],
        "created_at": now,
        "updated_at": now,
        "deleted_at": None,
    }
    membership = {
        "membership_id": membership_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "business_unit_id": business_unit_id,
        "user_id": user["user_id"],
        "role": "bu_admin",
        "created_at": now,
    }

    # Phase 4 D3.5.c: SQL is now the authoritative write target. The
    # repo upserts are no longer "mirrors" of a JsonStore write —
    # they ARE the write. Failures propagate as the user-visible 500.
    business_unit_repo.upsert(business_unit)
    bu_membership_repo.upsert(membership)
    state = store.read()
    created = await business_unit_summary(business_unit, state, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "business_unit.created",
            "resource_type": "business_unit",
            "resource_id": business_unit_id,
            "business_unit_id": business_unit_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


@app.get("/internal/business-units/{business_unit_id}")
async def get_business_unit(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # Phase 4 D3.5.b.2 + D4.4.c: auth via repo; upload-side KPIs via
    # upload-service; `topics` (review-service-owned) still reads
    # state until D5.
    business_unit = _require_business_unit_via_repo(
        business_unit_id, user, include_deleted=True
    )
    state = store.read()
    return await business_unit_summary(business_unit, state, request, user)


@app.patch("/internal/business-units/{business_unit_id}")
async def update_business_unit(
    business_unit_id: str,
    request_body: BusinessUnitUpdateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    business_unit = _require_business_unit_via_repo(
        business_unit_id,
        user,
        required_membership_roles={"bu_admin"},
    )
    if request_body.name is not None:
        business_unit["name"] = request_body.name
    for field in ("description", "owner_team", "region"):
        if field in request_body.model_fields_set:
            business_unit[field] = getattr(request_body, field)
    business_unit["updated_at"] = utc_now()
    business_unit_repo.upsert(business_unit)
    state = store.read()
    updated = await business_unit_summary(business_unit, state, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "business_unit.updated",
            "resource_type": "business_unit",
            "resource_id": business_unit_id,
            "business_unit_id": business_unit_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return updated


@app.delete("/internal/business-units/{business_unit_id}")
async def archive_business_unit(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    business_unit = _require_business_unit_via_repo(
        business_unit_id,
        user,
        required_membership_roles={"bu_admin"},
    )
    now = utc_now()
    business_unit["status"] = "archived"
    business_unit["deleted_at"] = now
    business_unit["updated_at"] = now
    business_unit_repo.upsert(business_unit)
    state = store.read()
    archived = await business_unit_summary(business_unit, state, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "business_unit.deleted",
            "resource_type": "business_unit",
            "resource_id": business_unit_id,
            "business_unit_id": business_unit_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return archived


@app.get("/internal/business-units/{business_unit_id}/projects")
async def list_business_unit_projects(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_business_unit_via_repo(business_unit_id, user)
    candidate_projects = project_repo.list_for_business_unit(business_unit_id)
    accessible_projects = [
        project
        for project in candidate_projects
        if _can_access_project_via_repo(project, user)
    ]
    projects = [
        await project_with_documents(project, request, user)
        for project in accessible_projects
    ]
    projects.sort(key=lambda item: item["name"].lower())
    return {"projects": projects}


@app.get("/internal/business-units/{business_unit_id}/activity")
async def business_unit_activity(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # Phase 4 D3.5.b.2: pure auth-check route; `state.read()` dropped
    # entirely (audit events are served by audit-service, not state).
    _require_business_unit_via_repo(business_unit_id, user, include_deleted=True)
    return await list_audit_events(
        headers=context_headers(request, user),
        business_unit_id=business_unit_id,
        store=store,
    )


@app.post("/internal/projects")
async def create_project(
    request_body: ProjectCreateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    _require_business_unit_via_repo(
        request_body.business_unit_id,
        user,
        required_membership_roles={"bu_admin", "editor"},
    )
    project_id = new_id("prj")
    membership_id = f"mem_{project_id}_{user['user_id']}"
    project = {
        "project_id": project_id,
        "business_unit_id": request_body.business_unit_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "name": request_body.name,
        "description": request_body.description,
        "created_by": user["user_id"],
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "status": "active",
        "deleted_at": None,
        "conversion_profile": default_conversion_profile(),
        "document_ids": [],
    }
    membership = {
        "membership_id": membership_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        # business_unit_id is denormed onto the membership so the SQL
        # backend can answer `list_for_business_unit` without a join.
        # The JsonStore-era envelope omitted it (callers joined through
        # state["projects"]); D3.3 makes it part of the wire shape so
        # both backends store the same record.
        "business_unit_id": request_body.business_unit_id,
        "project_id": project_id,
        "user_id": user["user_id"],
        "role": "project_admin",
        "created_at": utc_now(),
    }

    project_repo.upsert(project)
    project_membership_repo.upsert(membership)
    created = await project_with_documents(project, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "project.created",
            "resource_type": "project",
            "resource_id": project_id,
            "business_unit_id": request_body.business_unit_id,
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


@app.get("/internal/projects")
async def list_projects(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    _require_business_unit_via_repo(business_unit_id, user)
    candidate_projects = project_repo.list_for_business_unit(business_unit_id)
    accessible_projects = [
        project
        for project in candidate_projects
        if _can_access_project_via_repo(project, user)
    ]
    projects = [
        await project_with_documents(project, request, user)
        for project in accessible_projects
    ]
    return {"projects": projects}


@app.get("/internal/projects/{project_id}")
async def get_project(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
    include_documents: bool = True,
) -> dict[str, Any]:
    """Returns the project envelope.

    `include_documents=False` is the join-free path used by
    upload-service's `_require_project_via_bu_service` for access
    checks — without it, BU's documents-join → upload-service →
    BU.get_project → documents-join would recurse infinitely
    (D4.4.b finding: the documents-join is a cross-service
    boundary, and the access-check path must not traverse it)."""
    project = _require_project_via_repo(project_id, user, include_deleted=True)
    if not include_documents:
        return project
    return await project_with_documents(project, request, user)


@app.patch("/internal/projects/{project_id}")
async def update_project(
    project_id: str,
    request_body: ProjectUpdateRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin", "editor"})
    project = _require_project_via_repo(
        project_id,
        user,
        required_membership_roles={"project_admin"},
    )
    if request_body.name is not None:
        project["name"] = request_body.name
    if "description" in request_body.model_fields_set:
        project["description"] = request_body.description
    project["updated_at"] = utc_now()
    project_repo.upsert(project)
    updated = await project_with_documents(project, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "project.updated",
            "resource_type": "project",
            "resource_id": project_id,
            "business_unit_id": updated["business_unit_id"],
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return updated


@app.delete("/internal/projects/{project_id}")
async def archive_project(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    assert_role(user, {"org_admin", "project_admin"})
    project = _require_project_via_repo(
        project_id,
        user,
        required_membership_roles={"project_admin"},
    )
    now = utc_now()
    project["status"] = "archived"
    project["deleted_at"] = now
    project["updated_at"] = now
    project_repo.upsert(project)
    archived = await project_with_documents(project, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "project.deleted",
            "resource_type": "project",
            "resource_id": project_id,
            "business_unit_id": archived["business_unit_id"],
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return archived


@app.post("/internal/projects/{project_id}/authorize")
def authorize_project(
    project_id: str,
    payload: dict[str, Any] = Body(default={}),
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # Phase 4 D3.5.b.2: pure auth-check + return; `state.read()` dropped.
    project = _require_project_via_repo(project_id, user, include_deleted=True)
    action = payload.get("action", "read")
    return {"project_id": project["project_id"], "action": action, "allowed": True}


@app.post("/internal/business-units/{business_unit_id}/auto-provision-workspace-project")
async def auto_provision_workspace_project(
    business_unit_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D3.7: BU-owned auto-provision endpoint.

    Replaces upload-service's `ensure_document_workspace_project` direct
    JsonStore write (the §D3 finding #1 boundary leak). Preserves the
    existing semantics:

      1. If the caller already has access to *any* non-archived project
         in this BU, return it as the workspace target (matches
         pre-D3.7 behavior where a hand-created project would also
         serve as upload destination).
      2. Otherwise create a new `system_managed=True` project named
         "Documents" + a project_admin membership for the caller.

    Idempotent: a second call from the same actor after step 2 will
    take branch 1 (the just-created project is accessible). A second
    call after a crash mid-create is safe — the new_id() collision is
    astronomically improbable, and even if it occurred, the BU service
    would return the *first* matching project."""
    assert_role(user, {"org_admin", "project_admin", "editor"})
    business_unit = _require_business_unit_via_repo(business_unit_id, user)

    # Phase 4 D3.5.b.3: existence check via repo (already archived-filtered).
    # D4.4.b — `project_with_documents` is async + delegates to
    # upload-service. The eager disk-read optimization from the
    # JsonStore era is gone; the documents fetch now lives at the
    # boundary of the route.
    for existing in project_repo.list_for_business_unit(business_unit_id):
        if _can_access_project_via_repo(existing, user):
            return await project_with_documents(existing, request, user)

    project_id = new_id("prj")
    membership_id = f"mem_{project_id}_{user['user_id']}"
    now = utc_now()
    project = {
        "project_id": project_id,
        "business_unit_id": business_unit_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "name": "Documents",
        "description": "System document workspace",
        "status": "active",
        "deleted_at": None,
        "document_ids": [],
        "system_managed": True,
        "conversion_profile": {
            "target_dita_version": business_unit["policy"]["target_dita_version"],
            "allowed_topic_types": ["concept", "task", "reference"],
            "review_policy": business_unit["policy"]["review_policy"],
        },
        "created_by": user["user_id"],
        "created_at": now,
        "updated_at": now,
    }
    membership = {
        "membership_id": membership_id,
        "tenant_id": user["tenant_id"],
        "organization_id": user["organization_id"],
        "business_unit_id": business_unit_id,
        "project_id": project_id,
        "user_id": user["user_id"],
        "role": "project_admin",
        "created_at": now,
    }

    project_repo.upsert(project)
    project_membership_repo.upsert(membership)
    created = await project_with_documents(project, request, user)
    await emit_audit_event(
        {
            "actor_id": user["user_id"],
            "action": "project.auto_provisioned",
            "resource_type": "project",
            "resource_id": project_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
        },
        headers=context_headers(request, user),
        store=store,
    )
    return created


@app.post("/internal/projects/{project_id}/documents")
async def append_project_document(
    project_id: str,
    request_body: ProjectAppendDocumentRequest,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D3.7: controlled write surface for the document_ids
    denorm append. Replaces upload-service's direct
    `state["projects"][...]["document_ids"].append(...)` at 3 sites.

    Idempotent on document_id — second append of the same id is a
    no-op (no schema duplicate, no `updated_at` bump)."""
    _require_project_via_repo(project_id, user)
    document_id = request_body.document_id
    project = project_repo.append_document_id(project_id, document_id)
    if project is None:
        # `_require_project_via_repo` already raised on missing project,
        # so this branch is structurally unreachable. The check exists to
        # narrow the type for project_with_documents below.
        raise HTTPException(status_code=404, detail="Project not found")
    return await project_with_documents(project, request, user)


@app.delete("/internal/projects/{project_id}/documents/{document_id}")
async def remove_project_document(
    project_id: str,
    document_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    """Phase 4 D3.7: controlled write surface for the document_ids
    denorm remove. Replaces upload-service's direct comprehension at
    `delete_document` (1 site).

    Idempotent — removing a document_id not in the list is a no-op
    (no `updated_at` bump)."""
    _require_project_via_repo(project_id, user)
    project = project_repo.remove_document_id(project_id, document_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return await project_with_documents(project, request, user)


@app.get("/internal/projects/{project_id}/activity")
async def project_activity(
    project_id: str,
    request: Request,
    user: dict[str, Any] = Depends(current_user),
) -> dict[str, Any]:
    # Phase 4 D3.5.b.2: pure auth-check route; `state.read()` dropped.
    _require_project_via_repo(project_id, user, include_deleted=True)
    return await list_audit_events(
        headers=context_headers(request, user),
        project_id=project_id,
        store=store,
    )
