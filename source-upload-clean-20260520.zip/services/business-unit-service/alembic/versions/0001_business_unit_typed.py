"""business-unit-service typed schema (Phase 4 D3)

Revision ID: 0001_business_unit_typed
Revises:
Create Date: 2026-05-11

Replaces the JsonStore-owned collections (tenants, organizations,
business_units, business_unit_memberships, business_unit_favorites,
projects, project_memberships) with typed tables owned by the
business-unit-service. See plans/architecture-hardening.md §D3 and
adr/016-service-owned-data-contracts.md.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001_business_unit_typed"
down_revision = None
branch_labels = None
depends_on = None


def _seq_pk_column(name: str = "seq") -> sa.Column:
    return sa.Column(
        name,
        sa.BigInteger().with_variant(sa.Integer(), "sqlite"),
        primary_key=True,
        autoincrement=True,
        nullable=False,
    )


def upgrade() -> None:
    op.create_table(
        "tenants",
        _seq_pk_column(),
        sa.Column("tenant_id", sa.Text(), nullable=False, unique=True),
        sa.Column("name", sa.Text(), nullable=False),
    )

    op.create_table(
        "organizations",
        _seq_pk_column(),
        sa.Column("organization_id", sa.Text(), nullable=False, unique=True),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
    )
    op.create_index("ix_organizations_tenant_id", "organizations", ["tenant_id"])

    op.create_table(
        "business_units",
        _seq_pk_column(),
        sa.Column("business_unit_id", sa.Text(), nullable=False, unique=True),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("organization_id", sa.Text(), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("owner_team", sa.Text(), nullable=True),
        sa.Column("region", sa.Text(), nullable=True),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("policy", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.Column("updated_at", sa.Text(), nullable=False),
        sa.Column("deleted_at", sa.Text(), nullable=True),
    )
    op.create_index("ix_business_units_tenant_id", "business_units", ["tenant_id"])
    op.create_index("ix_business_units_status", "business_units", ["status"])

    op.create_table(
        "business_unit_memberships",
        _seq_pk_column(),
        sa.Column("membership_id", sa.Text(), nullable=False, unique=True),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("organization_id", sa.Text(), nullable=False),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("user_id", sa.Text(), nullable=False),
        sa.Column("role", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.UniqueConstraint(
            "business_unit_id",
            "user_id",
            name="uq_business_unit_memberships_bu_user",
        ),
    )
    op.create_index(
        "ix_bu_memberships_user_id", "business_unit_memberships", ["user_id"]
    )
    op.create_index(
        "ix_bu_memberships_business_unit_id",
        "business_unit_memberships",
        ["business_unit_id"],
    )

    op.create_table(
        "business_unit_favorites",
        _seq_pk_column(),
        sa.Column("favorite_id", sa.Text(), nullable=False, unique=True),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("user_id", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.UniqueConstraint(
            "business_unit_id",
            "user_id",
            name="uq_business_unit_favorites_bu_user",
        ),
    )
    op.create_index("ix_bu_favorites_user_id", "business_unit_favorites", ["user_id"])

    op.create_table(
        "projects",
        _seq_pk_column(),
        sa.Column("project_id", sa.Text(), nullable=False, unique=True),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("tenant_id", sa.Text(), nullable=False),
        sa.Column("organization_id", sa.Text(), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("status", sa.Text(), nullable=False),
        sa.Column("deleted_at", sa.Text(), nullable=True),
        sa.Column("document_ids", sa.JSON(), nullable=False),
        sa.Column("system_managed", sa.Boolean(), nullable=True),
        sa.Column("conversion_profile", sa.JSON(), nullable=False),
        sa.Column("created_by", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.Column("updated_at", sa.Text(), nullable=False),
    )
    op.create_index("ix_projects_business_unit_id", "projects", ["business_unit_id"])
    op.create_index("ix_projects_tenant_id", "projects", ["tenant_id"])
    op.create_index("ix_projects_status", "projects", ["status"])

    op.create_table(
        "project_memberships",
        _seq_pk_column(),
        sa.Column("membership_id", sa.Text(), nullable=False, unique=True),
        # tenant_id/organization_id are nullable to match BU service
        # JsonStore-envelope wire shape (Phase 4 D3.3 finding — the
        # original 0001 dropped them). Nullable because D3.4 backfill
        # may encounter pre-schema rows; D3.5+ may tighten to NOT NULL
        # once all rows are populated.
        sa.Column("tenant_id", sa.Text(), nullable=True),
        sa.Column("organization_id", sa.Text(), nullable=True),
        sa.Column("project_id", sa.Text(), nullable=False),
        sa.Column("business_unit_id", sa.Text(), nullable=False),
        sa.Column("user_id", sa.Text(), nullable=False),
        sa.Column("role", sa.Text(), nullable=False),
        sa.Column("created_at", sa.Text(), nullable=False),
        sa.UniqueConstraint(
            "project_id", "user_id", name="uq_project_memberships_project_user"
        ),
    )
    op.create_index(
        "ix_project_memberships_user_id", "project_memberships", ["user_id"]
    )
    op.create_index(
        "ix_project_memberships_project_id", "project_memberships", ["project_id"]
    )


def downgrade() -> None:
    for index, table in [
        ("ix_project_memberships_project_id", "project_memberships"),
        ("ix_project_memberships_user_id", "project_memberships"),
        ("ix_projects_status", "projects"),
        ("ix_projects_tenant_id", "projects"),
        ("ix_projects_business_unit_id", "projects"),
        ("ix_bu_favorites_user_id", "business_unit_favorites"),
        ("ix_bu_memberships_business_unit_id", "business_unit_memberships"),
        ("ix_bu_memberships_user_id", "business_unit_memberships"),
        ("ix_business_units_status", "business_units"),
        ("ix_business_units_tenant_id", "business_units"),
        ("ix_organizations_tenant_id", "organizations"),
    ]:
        op.drop_index(index, table_name=table)
    for table in (
        "project_memberships",
        "projects",
        "business_unit_favorites",
        "business_unit_memberships",
        "business_units",
        "organizations",
        "tenants",
    ):
        op.drop_table(table)
