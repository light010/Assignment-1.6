# export-service

**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation).

ADR-004 puts export bundle creation (the "download all topics as a
DITA-formatted ZIP") under this service. Today the equivalent routes
live on `upload-service` at `/v1/projects/{id}/exports` and
`/v1/documents/{id}/exports`, using `ditagen_common.pipeline.build_export_zip`.

## What this service will own

- `POST /internal/exports` — project and per-document export creation.
- `GET /internal/exports/{id}` — status + log polling.
- `GET /internal/exports/{id}/download` — streamed ZIP delivery.
- Export retention policy (currently artifacts live forever via
  `JsonStore`).

## Why deferred

Export creation is a low-volume, low-frequency operation in alpha.
Leaving it on `upload-service` until `dita-service` lands keeps the
deletion surface smaller for Phase 10. When `dita-service` exists,
this service can compose dita-service.build-export-zip with a
streamed-download endpoint without touching upload-service's other
routes.
