# dita-service

**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation).

ADR-013 designs this service as the deterministic DITA XML producer —
the layer that takes structured `generated_topic` JSON and emits
schema-valid DITA topic files. ADR-013:12-29 specifies that ONLY
deterministic code emits final DITA XML; LLMs produce intermediate
JSON, never raw XML.

Today the equivalent work is done by `ditagen_common.pipeline.build_dita_files`
called from `analysis-service` and `upload-service` (for exports). The
3-line skeleton here is a placeholder.

## What this service will own

- `POST /internal/dita/build-files` — wraps `build_dita_files`.
- `POST /internal/dita/build-export-zip` — wraps `build_export_zip`.
- DITA constraint profile selection per project.
- Eventually: bookmap / ditamap composition logic that's currently
  inline in `build_dita_files`.

## Why deferred

Phase 8's analysis-service moved `build_dita_files` use into a single
caller. Standing up this service is a mechanical extraction once the
caller surface is stable. Phase 10 keeps `analysis-service` and
`upload-service` (export routes) as the only callers, with an
architecture invariant ready to activate when this service lands.
