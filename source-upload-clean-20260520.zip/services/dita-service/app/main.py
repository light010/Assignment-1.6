from ditagen_common.service_app import create_service_app

app = create_service_app("dita-service")
