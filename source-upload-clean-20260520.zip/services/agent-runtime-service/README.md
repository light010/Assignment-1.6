# agent-runtime-service

**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation).

ADR-005 designs this service as the multi-step LLM agent orchestrator
(plan → tool-call → observe → repeat) for review workflows like
"explain this validation issue" and "draft a topic from these blocks."
The current skeleton is a 3-line FastAPI app that exposes only
`/health/live` and `/health/ready` so docker-compose health checks pass.

## What this service will own (per ADR-005)

- Agent run lifecycle: create, observe, approve-action, cancel.
- Tool registration + MCP server adapter integration.
- Per-run trace persistence + replay.
- Budget enforcement at the agent-run level (separate from per-call
  gateway budgets).

## Why deferred

Phase 0 of the backend root-cause plan (`plans/logical-whistling-widget.md`)
prioritized the analysis + review + validation pipeline. Agent runtime
is out of scope until those land. The alpha `/v1/agent-runs/*` routes
in `api-gateway` return synthetic `status=completed_alpha` responses
to keep the frontend contract stable while this service waits.

## Activation criteria

Phase 8 retired `regenerate_topic` as dead surface; reviving it
requires this service to be real OR `analysis-service` to gain a
single-topic regeneration route. Whichever lands first will be the
trigger to stand up agent-runtime.
