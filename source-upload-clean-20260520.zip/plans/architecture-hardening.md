# Architecture Hardening — Post-Audit Remediation Plan

**Status**: PROPOSED
**Owner**: TBD
**Created**: 2026-05-11
**Prerequisite**: extraction-quality-gate milestone (Steps A-I) — DONE.

## Premise

The Extraction Quality Gate milestone closed contract-discipline gaps and shipped 9 working steps. The post-milestone audit (B- overall grade) surfaced architectural weaknesses that are now the load-bearing limitations of the system:

- **🔴 CRITICAL** — Shared `JsonStore` mutated by 8 services (microservice boundaries are cosmetic for any state-mutating operation).
- **🔴 CRITICAL** — `POST /v1/llm/chat/completions` has no auth (billable-resource leak).
- **🟠 HIGH** — PAT revocation is a no-op; `DITAGEN_AUTH_SECRET` silently defaults; `identity-service` is a ghost.
- **🟡 MEDIUM** — Brittle gateway route enumeration; god-modules (`App.tsx` 3200 lines, `extractors.py` 2100 lines); dead `markdown-service`; unbounded `audit_events`.
- **🟢 LOW** — Wildcard CORS; async/sync route mixing without convention.

The plan is ordered **severity-first**. Quick-win security fixes land Week 1 to stop active bleeding. Dead-surface cleanup follows Week 1. Boundary hardening and god-module splits land Weeks 2–3. The strategic data-layer migration (per-service databases) is the multi-week investment that turns the microservice topology from cosmetic to operational and lives in Phase 2.

Every step follows the same discipline as the just-completed milestone:
- **Small, validated steps with tests and architecture gates after each step.**
- **Report findings inline** (stale docs, dead surfaces, boundary leaks, unsafe shortcuts) rather than preserving them for convenience.
- **Fix the root cause**, not the symptoms.
- **No shortcuts**; document deviations honestly with re-evaluation triggers.

The plan is intentionally larger than a single sprint. It's a roadmap, not a one-shot PR. Each Phase is self-contained and can be paused between phases without leaving the system in a worse state.

---

## Phase 1 — Quick-win security & hygiene (Week 1)

Goal: stop active risks, kill confusing surfaces, raise floor for everything after.

### Step S1 — Close auth gap on LLM proxy

**Scope**: `services/api-gateway/app/main.py:803`. Add `Depends(current_user)` to `POST /v1/llm/chat/completions`. The route already proxies to `llm-gateway-service`; adding the dependency does not change semantics for authenticated callers.

**Architecture lock**: extend `tests/test_api_gateway_h0_routes.py` with a route-iteration test that asserts EVERY `/v1` route declared on the gateway has `current_user` in its dependency tree. The exception list is `["/v1/auth/login", "/v1/auth/refresh"]` (and any future health probes). Anything else fails the test. This catches not just the current gap but any future regression.

**Acceptance**:
- Unauthenticated request to `/v1/llm/chat/completions` returns 401.
- Authenticated request still proxies through unchanged.
- Architecture test asserts no `/v1/*` route lacks `current_user` dependency except the explicit allow-list.

**Plan deviation triggers**: none expected; this is a one-line fix.

---

### Step S2 — `DITAGEN_AUTH_SECRET` fail-fast in production

**Scope**: `packages/python/ditagen_common/security.py:12`. Replace the silent default with:
```python
_ENV = os.environ.get("DITAGEN_ENV", "development")
_SECRET = os.environ.get("DITAGEN_AUTH_SECRET")
if _SECRET is None:
    if _ENV != "development":
        raise RuntimeError(
            "DITAGEN_AUTH_SECRET must be set in environment "
            f"{_ENV!r}. Refusing to fall back to dev default in non-dev environments."
        )
    _SECRET = "ditagen-local-dev-secret-change-me"
```

Update `docker-compose.yml` to inject `DITAGEN_AUTH_SECRET` (and `DITAGEN_ENV=docker`) into ALL services that depend on `ditagen_common.security`. Audit the 7 services currently missing the var.

**Architecture lock**: `tests/test_auth_secret_required.py` that asserts:
- Importing `security` with `DITAGEN_ENV=production` and no `DITAGEN_AUTH_SECRET` raises `RuntimeError`.
- Importing with `DITAGEN_ENV=development` and no secret succeeds (test/dev convenience).

**Documentation**: update `docs/deployment.md` (create if absent) with the secret rotation procedure.

**Acceptance**:
- `docker-compose up` works as before (all services get the secret).
- Removing `DITAGEN_AUTH_SECRET` from any service's env in `docker-compose.yml` makes that container fail to start.

---

### Step S3 — PAT revocation list (real revocation, not theater)

**Scope**: `services/api-gateway/app/main.py:186-200`. Today `GET /v1/auth/tokens` returns `[]` and `DELETE /v1/auth/tokens/{id}` returns `{"status":"revoked"}` without persisting anything. This is security theater.

Plan:
1. Add `revoked_tokens` collection to `JsonStore` defaults (interim — replaced in Phase 2 by per-service auth DB).
2. `POST /v1/auth/tokens` writes the `token_id` (JWT `jti` claim) to `revoked_tokens` with `{token_id, user_id, name, issued_at, expires_at}` — so list/revoke actually has data.
3. `GET /v1/auth/tokens` returns the list filtered by `user_id`.
4. `DELETE /v1/auth/tokens/{id}` flips a `revoked_at` field.
5. `verify_token` in `security.py` rejects tokens whose `jti` is in the revoked list.

**Architecture lock**: `tests/test_pat_revocation.py`:
- Issue PAT → list shows it.
- Revoke PAT → subsequent `verify_token` raises.
- Revoke non-existent PAT → 404 (not silent success).

**Plan deviation**: this depends on `JsonStore` (which Phase 2 will retire). Interim acceptable because the revocation list is small (one row per token, expires with the token) — a future migration to a dedicated auth-service is straightforward and doesn't block Phase 2.

---

### Step S4 — Decide & act on `identity-service` — DONE (revised)

**Original scope**: delete `services/identity-service/` because a placeholder service creates dishonest signaling.

**Actual outcome** (Phase 1.5 framing correction): the directory was kept, but the dishonesty was fixed by adding a `**Status**: deferred-alpha skeleton (Phase 0 inventory; Phase 10 confirmation)` banner to `services/identity-service/README.md` plus a `## Why deferred` section explaining (a) the planned routes the service will own when stood up and (b) why the alpha is correct to keep auth as a `ditagen_common.auth` library concern for now. ADR-004 already designed identity-service as a future microservice; deleting it would have orphaned that design.

This is the same principle the audit applied — be honest — but the honest answer wasn't "delete" once the README was read; it was "label the skeleton as deferred-by-decision."

**Architecture lock**: `tests/test_no_ghost_services.py` AST-walks every `services/*/app/main.py` for `@app.*` decorators OR `app.add_api_route` calls. A service WITHOUT routes passes the test only if its README has a `**Status**: <state>` banner (regex `r'\*\*Status\*\*:\s*\S+'`). identity-service satisfies the README route; markdown-service was deleted in S5 because it had no such README.

**Why this is the right framing**: deleting a documented placeholder discards design intent; the cosmetic-cleanup reflex would have lost a future-direction signal. The lock prevents the failure mode that prompted the audit (silently empty service directories) without forcing premature deletion of intentional skeletons.

---

### Step S5 — Delete `markdown-service` (dead code)

**Scope**: `services/markdown-service/` was retired Week 3 per `docker-compose.yml:122-130`, but the directory and Dockerfile remain.

Plan: same shape as S4.
1. Delete the directory.
2. Remove the (commented-out?) compose entry.
3. Grep for any stale imports or doc references.
4. Architecture test reuses S4's `test_no_ghost_services.py`.

---

### Step S6 — Audit-events to dedicated sink

**Scope**: `audit_events` is currently a flat list inside the same `state.json` JsonStore touches. Unbounded growth; one corrupt write loses everything; a long-running instance OOMs.

Plan:
1. Add `AuditEventStore` in `ditagen_common/audit_log.py` — append-only JSONL file at `${DITAGEN_DATA_DIR}/audit-events.jsonl` with daily rotation (`audit-events-YYYY-MM-DD.jsonl`).
2. `emit_audit_event(...)` writes to the new sink instead of `JsonStore`.
3. Migration script (`scripts/migrate_audit_events.py`) drains existing `state.audit_events` to the new sink and zeroes the field.
4. Architecture test: importing `audit_log` works; emitting an event writes a line; reading recent events returns them in order.

**Plan deviation**: Phase 2 will replace this with a streaming bus (NATS/Redis Streams). The JSONL sink is a one-week investment that immediately removes unbounded-growth pressure from the hot state.json file. The migration to streams in Phase 2 is straightforward — JSONL → stream replay is well-understood.

---

### Step S7 — CORS tighten (LOW priority but cheap)

**Scope**: `services/api-gateway/app/main.py:35-36`. `allow_methods=["*"]` and `allow_headers=["*"]`.

Plan:
1. Read `DITAGEN_CORS_METHODS` / `DITAGEN_CORS_HEADERS` / `DITAGEN_CORS_ORIGINS` from env with documented defaults.
2. Defaults: methods `GET,POST,PUT,PATCH,DELETE,OPTIONS`; headers `Authorization,Content-Type,X-Request-ID`; origins `http://localhost:5173`.
3. Production deployment supplies the exact allow-list.

**Architecture lock**: `tests/test_cors_config.py` asserts wildcards are gone when `DITAGEN_ENV != "development"`.

---

### Phase 1 verification gate

After all 7 sub-steps:
- `ruff check .` + `mypy services packages` + `pytest -x` + `npm run test` + `npm run build` all clean.
- New tests: `test_api_gateway_h0_routes.py` (extended), `test_auth_secret_required.py`, `test_pat_revocation.py`, `test_no_ghost_services.py`, `test_cors_config.py`.
- Manual smoke: `docker-compose up`, login, list tokens, revoke a token, attempt LLM proxy without auth (expect 401), attempt with revoked token (expect 401).
- Commit cadence: 1 commit per step. Step S1 should ship within 24 hours of plan approval.

---

## Phase 1.5 — Frontend regression triage (added during Phase 1 close-out)

**Trigger**: Phase 1 verification observed 11 failing vitest tests in
`apps/web/src/extractionExplorerModel.test.ts` (10) + `attentionSelectorParity.test.ts` (1),
all reporting `ReferenceError: countReviewFlagCodes is not defined`. None of
Phase 1's changes touched the failing file, so the failure was flagged
for triage before Phase 2.

### Step T1 — Root-cause the apparent regression

**Outcome**: NOT a regression. The "failure" was a transient vitest
hot-reload cache artifact. Running `npm run test` (which scopes to
`src/` per package.json) with a cold cache produced **99/99 passing**.
The function `countReviewFlagCodes` IS declared at module-scope and IS
correctly hoisted; the false-failure came from a stale vitest module
snapshot left over from parallel work in `extractionExplorerModel.ts`.

**Decision**: No fix needed in the source. Document the lesson:
"trust-but-verify failed-test output — always rerun with a cold
cache before concluding it's a real regression."

### Step T2 — Finding: vitest test-discovery picks up Playwright specs

**Found while triaging T1**: running `npx vitest run` (with no path
arg) instead of `npm run test` causes vitest to load
`e2e/workbench-extraction-explorer.spec.ts`, which uses Playwright's
`test()` and crashes the suite. The `npm run test` script in
`apps/web/package.json` correctly scopes to `src/`, but the discovery
hazard remains: any contributor who runs the raw vitest command will
see a false failure.

**Decision** (deferred to Phase 5 hygiene unless it bites earlier):
add `test.exclude: ["e2e/**"]` to a `vitest.config.ts` (currently
absent — vitest reads `vite.config.ts` and uses defaults). Track as
follow-up; not Phase 2 scope because it isn't blocking CI work.

### Phase 1.5 verification

- `npm run test` ✅ 99/99 pass
- `npm run build` ✅ clean
- No source-code change required.

---

## Phase 2 — Boundary hardening + observability (Week 2)

Goal: prevent the H0-class boundary leaks (gateway didn't proxy live upload-service routes) from happening again; raise observability floor; document operational practice.

### Step B1 — Gateway route allowlist refactor

**Scope**: `services/api-gateway/app/main.py:402-411` uses stacked `@app.get/@app.post/@app.delete` decorators on `proxy_document_route`. Adding a route requires both adding it to upload-service AND adding it to the decorator stack — easy to forget (Step H0 found this had been forgotten three times).

Plan:
1. Replace stacked decorators with an explicit allowlist constant: `_DOCUMENT_ROUTES: list[tuple[str, set[str]]]` enumerating `(path, allowed_methods)`.
2. Register via `app.add_api_route(...)` in a loop.
3. **Generate the allowlist from `services/upload-service/app/main.py` at import time** — read its `app.routes`, filter `/internal/documents/...`, mirror to `/v1/documents/...`. This makes drift structurally impossible.
4. Architecture test asserts: every `/internal/documents/...` route on upload-service has a mirror on the gateway (the inverse of `test_api_gateway_h0_routes.py`'s spot check).

**Plan deviation expected**: cross-service route introspection at import time creates a startup-time coupling between gateway and upload-service. Acceptable for monorepo; document explicitly. If services move to separate repos later, switch to a generated allowlist file.

---

### Step B2 — Architecture invariant test: no direct upload→extraction service imports

**Scope**: Already asserted for the confidence-post-processor at `tests/test_architecture.py`. Extend to assert that no service `app/main.py` imports from another service's `app/` directory.

Plan:
1. AST-walk `services/*/app/main.py`; collect every `from X import` and `import X`; flag any that resolve to `services/other-service/app/...`.
2. Whitelist legitimate cross-service test imports (the conftest factory pattern).
3. Lock as `tests/test_no_cross_service_imports.py`.

---

### Step B3 — Contract roundtrip test matrix — DONE

**Scope**: Audit found contracts are first-class but only a subset of artifacts have producer→schema roundtrip tests.

Plan:
1. Enumerate every contract under `contracts/artifacts/*.schema.json`.
2. For each, identify its producer (which service writes it) and verify there's a test that validates real producer output against the schema. Missing: source-line, asset-manifest, structure-tree-v2, style-profile.
3. Add the missing tests. Mirror the pattern in `tests/test_block_schema_compliance.py`.
4. Architecture lock: `tests/test_contract_coverage.py` reads `contracts/artifacts/` and asserts every schema has at least one test file that imports + validates against it.

**Outcome** (11 new tests, +2 producer root-cause fixes):

- `tests/test_artifact_schema_compliance.py` (4 tests) — producer→schema roundtrip for source-line, structure-tree, asset-manifest, style-profile via one real DOCX extraction run.
- `tests/test_contract_coverage.py` (7 tests: 6 parametrize + 1 inventory-pin) — every `contracts/artifacts/*.schema.json` must be exercised by a test file that imports `jsonschema` and names it.

**Producer root-cause fixes surfaced by the new tests** (NOT preserved for convenience — fixed at source):

1. `services/extraction-service/app/extractors/common.py::_asset_manifest` and `_style_profile` were stamping `extractor_version: "week3-alpha.1"` at the top level of artifact bodies. The schemas reject `additionalProperties`, and a grep confirmed zero consumers (the artifact registry already records `producer + artifact_version`). Removed both — a dead surface.
2. `_style_profile.heading_rules` was emitting `signals: ["style_name", "font_size", "numbering", "short_line"]` and missing `review_threshold`. The schema's enum had been tightened to canonical names (`source_style_name`, `font_size_rank`, `numbering_pattern`, etc.) which the extractor's own internal logic already uses (`common.py:444, 524, 528`) — the documentary summary block had drifted from its own implementation. Fixed signal names + added missing `review_threshold: 0.55` (matching the parallel `ditagen_common.pipeline.build_style_profile` reference).

Both were silent until B3 caught them. The `ditagen_common.pipeline.build_style_profile` reference (correct) and the extraction-service `_style_profile` (drifted) are a parallel-producer code smell flagged for Phase 4 consolidation.

---

### Step B4 — Structured logging baseline

**Scope**: Today services use bare `print(...)` or no logging at all in some paths. No JSON log format, no request-id correlation.

Plan:
1. Add `ditagen_common/logging.py` with `configure_logger(service_name: str) -> Logger` returning a stdlib logger configured for JSON output (one log entry per line, fields `ts`, `level`, `service`, `request_id`, `event`, `extra`).
2. Wire every service's `create_service_app(...)` to call it at startup.
3. Add `X-Request-ID` propagation middleware (read header, generate UUID if absent, attach to logger context, return on response).
4. Replace ad-hoc `print` calls with logger calls.
5. Architecture test: every service imports the configured logger at startup; no service emits unstructured `print` in production code paths.

---

### Step B5 — `/metrics` endpoint per service

**Scope**: No metrics endpoint anywhere. Operations is blind to throughput, latency, error rate.

Plan:
1. Add `prometheus-client` dependency.
2. `ditagen_common/metrics.py` exposes counters + histograms: `http_requests_total{method,path,status}`, `http_request_duration_seconds{method,path}`, plus service-specific business metrics.
3. Each service exposes `GET /metrics` returning Prometheus exposition format.
4. Document Grafana dashboard config (or note "TBD" with deferred work captured in a follow-up task).

---

### Step B6 — GitHub Actions CI workflow

**Scope**: No CI workflow visible in the repo. The four-gate discipline relies on manual runs.

Plan:
1. `.github/workflows/ci.yml` with jobs:
   - `python-gates`: `uv sync`, `uv run ruff check .`, `uv run mypy services packages`, `uv run pytest -x`.
   - `frontend-gates`: `npm ci`, `npm run test`, `npm run build`.
   - `architecture-gates`: dedicated invocation of `tests/test_architecture*.py` (fail fast).
   - `apple-ca-smoke`: spin up `docker-compose`, upload Apple CA fixture, assert gate passes.
2. Branch protection: PRs must pass all jobs before merge.

---

### Phase 2 verification gate — DONE

- All Phase 2 architecture tests green.
- `/metrics` reachable on every service.
- Logs are JSON; request-IDs flow through gateway → service → response.
- CI green on a sample PR.
- Manual smoke: kill upload-service, hit `/v1/documents/{id}`, gateway logs a structured error with request-id correlation.

**Closeout** (2026-05-11):

- Python: `uv run ruff check` clean; `uv run mypy packages/python/ditagen_common` Success no issues found in 20 source files; `uv run pytest` 364 passed, 2 skipped, 5 warnings in 33.48s.
- Frontend: `npm run test` 99/99 passed in 2.33s (18 test files).
- Test inventory progression: baseline 317 → Phase 1 338 → +B2 (cross-service imports) 15 → +B3 (artifact roundtrips + coverage matrix) 11 = 364.
- B1, B4, B5, B6 confirmed in-place from prior parallel work (gateway allowlist, JSON logging + request-id middleware, /metrics per service, GitHub Actions 4-job CI).
- B2 and B3 implemented this phase; both architecture locks have pinned inventories that force deliberate update on service/contract additions.

---

## Phase 3 — God-module splits (Week 3)

Goal: reduce code-review friction without changing behavior. Test count should stay constant; only file organization changes.

### Step M1 — Split `apps/web/src/App.tsx` — DONE

**Scope**: 3200 lines, multiple components, multiple data-fetching effects. Specifically extract:
- `<DocumentDetail>` — current ~600 lines of doc-mode tabs + lifecycle nav
- `<UploadHub>` — current ~500 lines of upload list + dropzone
- `<ExtractionReviewBanner>` + sub-components (`UnlocatedChips`, `OverrideGateDialog`) — Step H additions, ~250 lines
- `<SourcePanel>` + `<SourcePreview>` + sub-tabs — ~600 lines
- `<PanelView>` router — ~30 lines, stays in App.tsx
- App-level state hooks remain in `App.tsx` (~800 lines)

Plan:
1. One file per component, mirroring the existing pattern (`WorkbenchPanel.tsx`).
2. Move tests if any (most current tests are model-level, not component-level).
3. After each extraction: `npm run test` + `npm run build` clean.
4. Add `tests/test_app_file_size.test.ts` (or similar) that asserts `App.tsx <= 1000 lines` as an architecture lock.

**Plan deviation expected**: prop-drilling for `user` / `setHubToast` etc. may suggest a React context; capture as a deferred follow-up if it becomes painful, don't over-design.

**Outcome** (2026-05-11): split shipped by parallel work — `App.tsx` is now a 1-line re-export of `AppCore` (the orchestrator at 234 lines). Chrome lives in `AppChrome.tsx` (238). Feature components extracted: `BusinessUnitDashboard`, `UploadHub`, `DocumentDetail`, `SourcePanel`, `SourceEvidenceViewer`, `ExtractionReviewBanner`, `Cockpit`, `WorkbenchPanel`, `ExtractionExplorerPane`, `EvidenceTimeline`, `TopicFilmstrip`, `UnlocatedEvidenceStrip`, `SourceSpotlight`. `AppFileSize.test.ts` locks the split.

### Step M1.2 — Follow-up: cap feature-module growth — DONE

**Finding surfaced by Phase 3 audit (post-M1)**: M1 split worked, but the *extracted* feature components are now nearing god-module size themselves:

| Module | Lines | Risk |
|---|---|---|
| `SourcePanel.tsx` | 986 | feature god-module |
| `extractionExplorerModel.ts` | 869 | logic god-module |
| `SourceEvidenceViewer.tsx` | 848 | feature god-module |
| `UploadHub.tsx` | 846 | feature god-module |
| `WorkbenchPanel.tsx` | 822 | feature god-module |

**Lock applied**: `apps/web/src/AppFileSize.test.ts` extended with 5 parametrized caps at 1000 lines each. This is an interim safety net — when a module hits the cap, split it (don't bump the cap). The cap deliberately mirrors `App.tsx`'s 1000-line precedent rather than the tighter 800-line orchestration ceiling, because feature components legitimately carry more JSX content.

**Deferred split work** (not blocking — captured here so a future contributor knows the targets):
- `SourcePanel.tsx` — splits along the page/line preview tabs (PDF viewer wrapper, line list, evidence chip rail).
- `SourceEvidenceViewer.tsx` — splits along virtualization vs. selection vs. scroll-sync.
- `extractionExplorerModel.ts` — has multiple selector clusters; pure-function split per selector group.
- `UploadHub.tsx`, `WorkbenchPanel.tsx` — split along sub-panel boundaries.

**Why interim-lock-without-split is honest here**: the cap prevents further drift while making the next-step targets visible. Splitting is real work that should be its own validated step, not bundled into a Phase 3 closeout.

---

### Step M2 — Split `services/extraction-service/app/extractors.py` — DONE

**Scope**: 2100 lines. The DOCX path dominates; PDF, textual, and HTML paths are minor.

Plan:
1. `extractors/__init__.py` re-exports the public API (`extract_document`, `ExtractedAsset`, `ExtractionOutput`).
2. `extractors/docx.py` — `_extract_docx`, `_docx_*` helpers, `_DocxNote`, `_emit_docx_header_footer_blocks`.
3. `extractors/pdf.py` — `_extract_pdf`.
4. `extractors/textual.py` — `_extract_textual`, HTML path.
5. `extractors/common.py` — `_assemble_output`, `_source_line`, `_source_block`, `_compute_review_signals`, `_extraction_quality`, `_markdown`.
6. `extractors/heading_classifier.py` — `_docx_block_type`, `_looks_like_heading`, `_HEADING_TERMINAL_PUNCTUATION`.
7. After each extraction: full pytest + mypy + Apple CA invariants.
8. Architecture lock: `tests/test_extractors_split.py` asserts no file in `extractors/` exceeds 800 lines.

**Plan deviation expected**: the heading classifier may want to live in `ditagen_common` for reuse by other producers (PDF, future formats). Decide based on dependency direction; if `heading_classifier` doesn't depend on DOCX-specific helpers, lift it.

**Outcome** (2026-05-11): split shipped by parallel work. `extractors/` directory has 7 files: `__init__.py` (43), `common.py` (665, post-B3 fixes), `docx.py` (442), `docx_helpers.py` (678), `heading_classifier.py` (268), `pdf.py` (201), `textual.py` (135). Largest is `docx_helpers.py` at 678 lines (under the 800-line cap with breathing room).

**Architecture lock added this phase**: `tests/test_extractors_split.py` (8 tests) — parametrize over 6 submodules asserting `<= 800` lines, pin the submodule inventory (any new file requires deliberate update), and a tight 50-line cap on `__init__.py` (must stay a thin re-export shim). The lock was MISSING from prior work despite the split being done — exactly the regression-guard gap M2 was meant to close.

**Heading classifier deviation**: stayed in `services/extraction-service/app/extractors/heading_classifier.py` (not lifted to `ditagen_common`) because it still depends on DOCX-specific style names. Lift is a follow-up when (a) the PDF path grows a real heading detector or (b) `style_summary` becomes a cross-extractor primitive.

---

### Step M3 — Async/sync convention documentation — DONE

**Scope**: Mix of `async def` and sync `def` routes is intentional but undocumented. New contributors will choose wrong.

Plan:
1. Add `docs/async-conventions.md`: "Use `async def` when the route awaits I/O or another service. Use sync `def` when the route is pure computation OR delegates to a service via `request_service` (which is already async-internally). FastAPI runs sync routes on a threadpool."
2. Architecture lint: simple grep — any sync route that does HTTP I/O via the `httpx` client gets flagged.

**Outcome** (2026-05-11): `docs/async-conventions.md` exists (13 lines) and gives the canonical guidance — `async def` for `request_service` callers, sync `def` for pure-computation routes, never instantiate `httpx.AsyncClient` from sync code.

**Architecture lint added this phase**: `tests/test_async_route_conventions.py` (15 tests) — AST-walks every `services/*/app/main.py`, parametrized per service, and asserts no sync `def` function body calls `request_service`, `request_internal`, or instantiates `AsyncClient`. The lint catches the bug shape that the convention is meant to prevent (sync handler quietly returning a coroutine object). A second test asserts the doc exists and mentions `request_service` so the lint never becomes orphan guidance after a doc cleanup.

Current state of the codebase: zero violations — every existing caller is already `await request_service(...)` from an `async def`. The lint is a regression guard, not a remediation.

---

### Phase 3 verification gate — DONE

- All splits clean: pytest + vitest + build green.
- File-size architecture locks pass.
- No behavior change (Apple CA invariants byte-identical pre/post).

**Closeout** (2026-05-11):

- Python: `uv run ruff check tests/test_extractors_split.py tests/test_async_route_conventions.py` clean; `uv run pytest` **387 passed, 2 skipped** in 32.26s (up from 364 by +23 = 8 extractors_split + 15 async_route_conventions).
- Frontend: `npm run test` **104/104 passed** in 1.93s (up from 99 by +5 feature-module size caps).
- Test inventory progression: baseline 317 → Phase 1 338 → Phase 2 B2+B3 +26 = 364 → Phase 3 M2+M3 +23 = 387.
- M1 (App.tsx split) was already shipped by parallel work; this phase closed the M1.2 follow-up by adding 5 feature-module caps to `AppFileSize.test.ts`.
- M2 (extractors.py split) was already shipped by parallel work; this phase added the missing `tests/test_extractors_split.py` architecture lock.
- M3 (async conventions) doc already shipped; this phase added the architecture lint that turns the doc into an enforced contract.
- Stale Phase 1 S4 (delete identity-service) revised in-place to match the actual outcome (kept-as-documented-skeleton); see updated S4 above.

---

## Phase 4 — Data-layer migration (Weeks 4–8, strategic)

Goal: replace shared `JsonStore` with per-service databases + event-driven sync. This is the multi-week investment that turns the microservice topology from cosmetic to operational.

### Step D0 — Define per-service ownership contracts (Day 1) — DONE

**Scope**: Document, before any code, which service OWNS each piece of state.

**Outcome** (2026-05-11):

**ADR-016** (`adr/016-service-owned-data-contracts.md`) is now the canonical ownership contract — previously orphaned as a misnamed `009-service-owned-data-contracts.md` colliding with the Scalability ADR. Renamed to ADR-016 (next free slot), title fixed, status moved from "Proposed" to "Accepted (target architecture)", and added to `adr/000-index.md`. Body reconciled against empirical state.

**Architecture lock added**: `tests/test_jsonstore_key_ownership.py` (16 tests) — parametrize over the 14 services, plus an inventory pin and a known-keys pin. Each service's `main.py` is AST-walked for string-literal subscripts matching the known JsonStore top-level keys; the result is asserted equal to the per-service allowed-set in `_EXPECTED_KEY_USAGE`. The test fires in BOTH directions:
- **Regression**: a service reading a key not in its expected set fails (new cross-service coupling).
- **Stale floor**: a service NO LONGER reading a key still in its expected set fails (migration progressed; tighten the lock).

**Empirical reality vs. audit's original ownership table**:

| State | Audit said | Reality on 2026-05-11 |
|---|---|---|
| `users` | business-unit-service-owned | api-gateway reads it (auth flow) |
| `topics` | review-service-owned | api-gateway, analysis-service, review-service, upload-service all read |
| `generated_topics` | review-service-owned | analysis-service reads (caught by AST test; my initial grep missed it) |
| `documents` | upload-service-owned | api-gateway + business-unit-service + upload-service all read |
| `projects` | business-unit-service-owned | api-gateway + audit-service + business-unit-service + upload-service all read |
| `jobs` | upload-service-owned | business-unit-service also reads |
| `business_units`, `memberships` | business-unit-service-owned | audit-service reads `business_units`; "memberships" turned out to be two keys (`business_unit_memberships`, `project_memberships`) |
| `sessions`, `exports`, `upload_sessions` | not mentioned | newly inventoried this phase |

The audit table was strawman; the ADR + lock are normative.

**Storage decision (resolves plan-vs-ADR drift)**: The original plan body says "SQLite"; ADR-016 says "PostgreSQL with SQLite as hermetic test fallback." The plan defers to the ADR going forward — start SQLite for hermetic tests + alpha, then switch backend behind the same repository contract before production traffic. This is captured in ADR-016 §Decision.

**Open decision** (jobs / auth split): tracked in ADR-016 §Migration Order step 6. Plan stays neutral until D4/D6 force the decision.

**Findings flagged for cleanup**:
- ADR numbering collision (009 used twice): FIXED by renumbering the orphan to ADR-016.
- The original audit's table understated reality: 4-way reader on `topics`, 4-way reader on `projects`, 3-way reader on `documents` — the boundary is more porous than the audit captured.
- `validation-service` imports `JsonStore` but touches zero state keys (artifact-blob reads only). Locked at `frozenset()` so any future state-key access fails the test.

---

### Step D1 — Event bus (start simple) — DONE

**Scope**: Services need to publish state changes other services consume. Two viable approaches:

1. **HTTP-based with audit-events as the source of truth** — every state change emits an audit event; subscribers poll/long-poll the audit-service. Easy to ship, latency-tolerant.
2. **NATS or Redis Streams** — proper streaming, low latency, complex to operate.

Plan: ship (1) first. Audit-service already exists; add a `GET /internal/events/since/{cursor}` endpoint that streams events newer than the cursor. Consumers store their cursor in their own DB. Re-evaluate (2) when latency or throughput hurts.

**Architecture lock**: `tests/test_event_replay.py` — emit 100 events, advance consumer cursor, assert no duplicates and no gaps.

**Outcome** (2026-05-11): endpoint was already shipped by parallel work at `services/audit-service/app/main.py:96`. This step added the architecture lock and surfaced two real cursor bugs that would have caused silent duplicate-event delivery to consumers.

**Bugs surfaced and fixed at root cause**:

1. **`next_cursor` regression on past-end cursor** — when a consumer asked for `since/100` but only 5 events existed, the response was `{cursor: "100", next_cursor: "5"}`. A consumer using `next_cursor` as its new cursor would jump backward and re-process events 0-4 on the next poll. Classic duplicate-delivery failure. **Fix**: pin `next_cursor = max(requested_int_cursor, start + len(replay))` for integer cursors.

2. **Unknown `event_id` cursor silently re-walked from 0** — the implementation fell back to `start=0` when the `event_id` cursor didn't match any event. A consumer with a stale `event_id` (e.g., from before a state reset, or a transient bug) would receive every event again on its next poll. Same duplicate-delivery class, different trigger. **Fix**: treat unknown `event_id` as "caller is caught up" (return empty + preserve cursor) rather than re-walking.

Both bugs share a root cause: the cursor-mapping logic didn't preserve the *intent* of the consumer's request when the requested position was invalid. The fix tracks the requested integer cursor separately so `next_cursor` can never go backward.

**Test coverage shipped** (`tests/test_event_replay.py`, 5 tests):

- `test_event_replay_no_duplicates_no_gaps` — the load-bearing lock: emit 100 events, walk the cursor in chunks until empty, assert set-equality between emitted and walked event_ids AND no duplicates across the walk.
- `test_event_replay_cursor_past_end_is_empty` — caught bug #1.
- `test_event_replay_unknown_event_id_cursor_does_not_rewalk` — caught bug #2.
- `test_event_replay_same_cursor_is_idempotent` — retry-safety (a flaky consumer reconnecting with the same cursor must see the same events).
- `test_event_replay_chunked_walk_via_event_id_cursor` — the production consumer pattern (re-cursor on last-seen event_id).

**Deferred follow-up**: explicit 4xx on unknown `event_id` cursor (currently empty-and-preserve is silent). Surfacing consumer state-drift loudly would be safer than implicit "you're caught up." Captured here so a future iteration knows to revisit.

---

### Step D2 — audit-service to SQLite (the easy one) — DONE

**Scope**: audit-service today is a thin wrapper over `JsonStore` for `audit_events`. After S6 it writes JSONL. D2 migrates to SQLite as the canonical event store with append-only semantics.

Plan:
1. SQLAlchemy + Alembic in `services/audit-service`.
2. Single table `audit_events(event_id, ts, actor_id, action, resource_type, resource_id, business_unit_id, project_id, metadata jsonb)`.
3. Migration script reads JSONL + state.json `audit_events` → audit-service SQLite.
4. New event-replay endpoint backed by `SELECT WHERE event_id > cursor ORDER BY event_id LIMIT 100`.
5. Delete the JSONL sink once migration is complete (S6 was the bridge).

**Architecture lock**: `tests/test_audit_service_integration.py` — POST event, query event-replay, assert it appears once.

**Outcome** (2026-05-11): shipped as 8 sub-steps with gate sweeps between each.

| Sub-step | Surface delta | Test delta |
|---|---|---|
| D2.1 | `services/audit-service/app/db.py` (typed `AuditEvent` SQLAlchemy 2.0 ORM, per-service engine cache); `services/audit-service/alembic.ini` + `alembic/env.py` + `0001_audit_events_typed.py` | — |
| D2.2 | `services/audit-service/app/repository.py` — `AuditEventRepository` (append_event, list_events, walk_since_seq, resolve_seq_for_event_id, max_seq) | `tests/test_audit_event_repository.py` (+8 tests) |
| D2.3 | `audit-service/main.py` writes via repo; reads merge repo + JSONL + state (dual-write bridge) | (existing tests unchanged) |
| D2.4 | `scripts/migrate_audit_events.py` rewritten: state.json + JSONL → SQL (idempotent via UNIQUE event_id). Replaces the Phase 1 S6 migrator. | — |
| D2.5 | `audit-service/main.py` reads only from repo; replay endpoint becomes real SQL `WHERE seq > :cursor ORDER BY seq LIMIT 100`. | (existing tests unchanged) |
| D2.6 | Tenant-isolation lifted off `JsonStore.read()` onto `request_service("business-unit-service", GET /internal/business-units/{id})`. Routes become `async def`. | `_EXPECTED_KEY_USAGE["audit-service"]` tightened to `frozenset()` |
| D2.7 | JSONL bridge fully retired (audit-service writes only SQL); `JsonStore.audit()` + `SqlStateStore.audit()` fail-loud; `JsonStore.read()` no longer merges JSONL into `audit_events`; api-gateway login/logout migrated to `await emit_audit_event(...)`; review-service `_document_op_chain` (sync, JSONL-backed) deleted; **`ditagen_common/audit_log.py` deleted entirely**. | `tests/test_audit_service_integration.py` (+4 tests) including JSONL-files-never-reappear lock |
| D2.8 | This entry. | — |

**Test inventory**: 408 → 420 (+12 net: +8 repo, +4 integration). All architecture locks tightened (D2.6 `frozenset()` lock, D2.7 JSONL-absent lock).

**Storage backend**: ADR-016 commits to PostgreSQL in production with SQLite for hermetic tests + alpha behind identical repository contracts. The schema uses `BigInteger().with_variant(Integer, "sqlite")` for the `seq` primary key so SQLite's rowid-alias autoincrement works while PostgreSQL gets BIGSERIAL.

**Cursor primitive**: a monotonic `seq BIGINT` autoincrement column inside audit-service's DB — not the consumer-facing event_id. The wire contract is unchanged (cursor can be either an integer or an event_id string); event_id cursors are translated to seq via `resolve_seq_for_event_id` before the SQL walk. Picked this shape because `new_id("aud")` is `millis_hex_random` — sortable within one writer but vulnerable to same-millis collisions across writer processes, where the random suffix breaks lexicographic monotonicity. `seq` is database-serialized through INSERT so it's robust to any writer concurrency.

**Findings flagged at root cause (not preserved for convenience)**:

1. **Stale-floor caught**: `test_jsonstore_key_ownership.py`'s dual-direction lock failed when D2.6 stopped reading `business_units`/`projects` while the expected-set still listed them. This is exactly the design intent — the lock turns "migration progressed" into a green-bar moment. Fixed by tightening `_EXPECTED_KEY_USAGE["audit-service"]` to `frozenset()`.
2. **`SqlStateStore` is the wrong shape for production audit_events**: it's a JsonStore-compat wrapper that does `DELETE *` + `INSERT *` on every mutate. Operationally fine for tiny config tables but catastrophic for append-only growing data. D2's typed audit-service backend bypasses it entirely. The compat wrapper stays for un-migrated services (D3-D6) and gets retired with D7.
3. **`new_id` is multi-writer-unsafe for ordering**: same-millisecond emissions from different processes share the same `millis_hex` prefix and differ only in their random suffix — lexicographic ordering becomes nondeterministic across writers. The DB-serialized `seq` column fixes this; flagged for any future "use event_id as a cursor primitive" tempted design.
4. **The dual-source dedup pattern (`merge_audit_events`) was load-bearing during D2.3-D2.5 and dead surface after D2.7**. The order `merge(repo, jsonl, state)` was intentional (repo wins on event_id collision — canonical envelope on migrated events). With D2.7's full retirement, the function and module were deleted entirely.
5. **api-gateway login bootstrap**: emitting `auth.login.succeeded` to audit-service needs a bearer token, but the user is *just logging in*. Used the just-issued `access_token` to authenticate the audit call. Logout uses the inbound JWT via `context_headers(request, user)`.
6. **Cross-service test conventions discovered**: services/*/app/main.py loaders DON'T use `__init__.py`. Sibling helpers (`from db import ...`, `from repository import ...`) are top-level absolute imports, not relative. The test harness adds `app/` to sys.path; relative imports break the importlib loader. Worth pinning in `docs/async-conventions.md` or similar.
7. **`current_user` cross-service auth is stricter post-D2.6**: business-unit-service's `can_access_business_unit` checks tenant *and* membership, where the old audit-service inline check only verified tenant. A non-admin user might now see fewer events (events from BUs they're not a member of). For tests that use org_admin tokens this is invisible. Captured for future contributors.
8. **`IntegrityError` retry in `AuditEventRepository.append_event` covers a real production race** that SQLite single-writer cannot exercise. Test coverage gap; mitigated by `event_id` UNIQUE + idempotent semantics. Captured as a Phase 5 follow-up (CI test against PostgreSQL).

**Deviations from the original plan body** (documented honestly):

- Plan said "SQLite"; ADR-016 says PostgreSQL with SQLite hermetic fallback. The repository abstracts the difference; D2 ships SQLite by default with `DITAGEN_AUDIT_DATABASE_URL=postgresql://...` override path tested via SQLAlchemy's URL-driven engine.
- Plan said `WHERE event_id > cursor`. D2 ships `WHERE seq > cursor` (see "Cursor primitive" above). The wire contract preserves event_id as a valid cursor; the SQL just operates on the more reliable `seq`.
- Plan's "1 step": shipped as 8 sub-steps. The cascading dependencies (JsonStore.read merge, JsonStore.audit callers in api-gateway, sync review-service `_document_op_chain`) each required a separate validated commit-shaped change. Reverting individually is straightforward; reverting the lump would not have been.

**Deferred follow-ups** (worth queuing but not blocking the next D-step):

- `request_service` fan-out cost in `replay_audit_events`: up to 2N round trips per N-event chunk to business-unit-service for visibility checks. Cached per-call but unbounded across calls. A `GET /internal/me/visible-business-units` batch endpoint on business-unit-service would collapse this. Not blocking for alpha (event volume is low).
- Coverage gap: the `IntegrityError` retry branch in `AuditEventRepository.append_event` is unreachable from SQLite. A PostgreSQL CI matrix is the right place to lock it.

---

### Step D3 — business-unit-service to SQLite

**Scope**: business-unit-service owns business_units, projects, memberships, users. Stable schema; small data volume.

Plan: standard SQLAlchemy migration. Other services (especially upload-service) currently read these via `store.read()["projects"]` — replace with `GET /internal/projects/{id}` calls through the gateway pattern.

**Plan deviation expected**: this exposes the question "is direct service-to-service HTTP acceptable for read-mostly reference data, or should we cache?" — defer to a follow-up after baseline migration.

**D3.1 + D3.2 (2026-05-11) — foundation shipped**:

- `services/business-unit-service/app/bu_db.py` — typed SQLAlchemy 2.0 models for tenants, organizations, business_units, business_unit_memberships, business_unit_favorites, projects, project_memberships. Pattern mirrors D2.1 (seq BIGINT-with-Integer-variant PK + natural-key UNIQUE; ISO-Z timestamps as Text; JSON columns for policy/conversion_profile/document_ids; per-row to_envelope() for wire-shape stability).
- `services/business-unit-service/alembic/` — per-service Alembic with 0001_business_unit_typed migration.
- `services/business-unit-service/app/bu_repositories.py` — 7 repository classes (Tenant, Organization, BusinessUnit, BusinessUnitMembership, BusinessUnitFavorite, Project, ProjectMembership) with idempotent upserts on natural and compound keys, tenant-filtered list methods, plus `Project.append_document_id` as the controlled write surface for the document_ids denorm.
- `tests/test_business_unit_repositories.py` — 11 tests pin upsert idempotency on compound keys, archived-filter behaviour, denorm idempotency, and wire-shape stability. Test count 420 → 431.

**Findings captured during D3.1 audit (not yet acted on)**:

1. **upload-service boundary leak — project lifecycle owned outside the BU service**. `services/upload-service/app/main.py:136-187` (`ensure_document_workspace_project`) creates `state["projects"][project_id]` and `state["project_memberships"][membership_id]` directly via `store.mutate`. Project lifecycle belongs to business-unit-service; this is a real cross-service write. D3.7 follow-up: introduce a BU service auto-provision endpoint and call it via `request_service` from upload-service.
2. **document_ids denorm written from upload-service**. Same file at lines 591, 733, 882, 1473 mutates `state["projects"][project_id]["document_ids"].append(document_id)`. Two clean resolutions: (a) BU service owns the index as a write-through endpoint that upload-service POSTs to on attach; (b) drop the index entirely and have callers query upload-service for documents-by-project. (a) preserves wire shape; (b) reduces coupling. D3.7 picks.
3. **`Project.system_managed` SQLite TEXT-affinity bug** caught at unit-test time. `Text` column would coerce `True → '1'` on SQLite — silent wire-shape divergence from JsonStore. Fixed by switching to `Boolean` in bu_db.py + the 0001 migration. Generic lesson: every column whose Python type is a non-string scalar (bool, int, datetime) needs a SQLAlchemy type that maps correctly; `Text` is for strings only.
4. **Per-service module name collision is a permanent codebase shape constraint**. Hyphenated service dirs (`audit-service`, `business-unit-service`) cannot be Python package names, so each service's `app/db.py` and `app/repository.py` look like a duplicate `db`/`repository` module to mypy under `explicit_package_bases=True`. D3 resolved it by using service-prefixed filenames (`bu_db.py`, `bu_repositories.py`) for new files; audit-service stays at `db.py`/`repository.py` for the moment. A consistency sweep that renames audit-service's modules to `audit_db.py`/`audit_repository.py` is a follow-up. Future D-services (D4-D6) should adopt service-prefixed names from day one.
5. **mypy ↔ ruff disagreement on SQLAlchemy attribute writes**. Mypy treats `row.name = value` as `Column[str] = str` (type error). Ruff `B010` flags `setattr(row, "name", value)` (worse). Resolved with direct assignment + `# type: ignore[assignment]` (matches D2's `int(row.seq)` cast pattern for the read direction). Considered fully migrating models to SQLAlchemy 2.x `Mapped[T]` typing — that's a larger refactor across all services; deferred.
6. **api-gateway has exactly one BU-owned subscript site** (`require_document` at line 96). Trivial to migrate (D3.6 task) — small enough that it could ride with D3.5.

**D3.3 (2026-05-12) — dual-write bridge shipped**:

- `services/business-unit-service/app/main.py` — every BU service mutate route (`create/update/archive_business_unit`, `create/update/archive_project`, 6 sites total) now mirrors its JsonStore-shaped envelope into the typed SQL backend via `_mirror_to_sql(...)`. JsonStore stays authoritative for reads; SQL is a continuously-refreshed shadow. SQL write failures are LOGGED, never raised — a failing dual-write must not surface as a user-visible 500 while JsonStore is the source of truth. D3.5 inverts authority and makes SQL failures hard errors.
- `tests/test_business_unit_dual_write.py` — 6 new tests pin the dual-write contract: BU create mirrors BU + bu_membership; BU update in place; BU archive carries status+deleted_at; project create mirrors project + project_membership; project update + archive round-trip; **SQL outage must not break the request** (the simulated-failure test that locks in the swallow-and-log discipline before D3.5 inverts it). Test count 431 → 437.
- D3.3 hygiene: 8 pre-existing mypy errors in test_audit_event_repository.py / test_business_unit_repositories.py / scripts/migrate_audit_events.py cleaned up. The prior session's "mypy clean" claim turned out to be optimistic (verified by stashing D3.3 and running mypy at af99556). Tree is now provably mypy-clean (95 source files, 0 errors).

**Findings captured during D3.3** (acted on at root cause, not deferred):

7. **ProjectMembership SQL schema dropped `tenant_id` and `organization_id` columns that the JsonStore envelope carries.** D3.1 was internally inconsistent — `BusinessUnitMembership` had both columns; `ProjectMembership` did not. The dual-write integration test surfaced this on the first run (D3.2 unit test had constructed a *minimal* payload without these fields, so the schema gap was hidden). **Root-cause fix:** added `tenant_id` and `organization_id` (nullable) to both the ORM model and the 0001 Alembic migration. The 0001 migration was edited in place because it has never run against production data — the data dir is wiped per-test and D3.4's backfill hasn't run yet. Once D3.4 ships, 0001 becomes off-limits and any further change is 0002+.
8. **Project membership route envelope was missing `business_unit_id`.** The JsonStore-era code never needed it on the membership record because callers joined through `state["projects"][project_id]`. The SQL schema denormed it for query efficiency — making the *envelope shape* the contract, not the JsonStore key set. **Root-cause fix:** the route now writes `business_unit_id` into the project_memberships envelope at create time. Both backends now store the same shape. JsonStore consumers see an additive field (no breaking change).
9. **Dual-write integration test caught what unit tests couldn't.** D3.2's unit tests pinned the *port contract* of each repository in isolation; D3.3's integration test pinned the *wire shape* across route → repo. Two failures (#7 + #8) only surfaced under integration. Generic lesson: when migrating a service from JsonStore → SQL, *unit tests over the port* + *integration tests over the wire shape* are both load-bearing; neither alone catches every contract gap.
10. **The `# type: ignore[import-not-found]` markers in repository test files became unused once a service `main.py` imported the same module at top level.** Mypy under `explicit_package_bases=True` discovers the module via namespace-package mechanism. D3.3 cleanup removed them across both audit-service and BU-service test files, plus annotated 3 dict-literal helpers that mypy could no longer infer.
11. **The `swallow-and-log` discipline of the dual-write helper needs to be retired together with the JsonStore drop in D3.5.** Right now it deliberately hides SQL failures so the user-visible 200 stays consistent with the JsonStore source of truth. The moment D3.5 deletes the JsonStore write, the same helper must convert the swallow into a raise — otherwise a SQL outage becomes silent data loss. The D3.3 test `test_dual_write_failure_does_not_break_request` is intentionally tied to this transitional behavior and will be updated to assert hard-fail in the D3.5 commit.

**D3.4 (2026-05-12) — state.json → SQL migration script shipped**:

- `scripts/migrate_business_unit_state.py` — single-pass backfill of all 7 BU-owned collections in dependency order (tenants → organizations → business_units → bu_memberships → bu_favorites → projects → project_memberships). Per-collection insert/skip counters reported on stdout; the `project_memberships` row additionally reports a `coerced_count` for envelopes that needed `tenant_id`/`organization_id`/`business_unit_id` derived from the parent project (the upload-service boundary-leak signal — D3.7).
- Idempotent on natural keys: re-running the script after partial failure (network blip, OOM, interrupted run) converges, never duplicates. Each `repo.upsert(envelope)` is already idempotent on (business_unit_id, project_id, membership_id, …) per D3.2.
- `tests/test_business_unit_migration.py` — 6 D3.4 lock tests: empty-state no-op, full 7-collection roundtrip with envelope-shape verification through the production repos, idempotency second-run-is-no-op, boundary-leak coercion (membership without tenant/organization id → derived from project), malformed-root rejection, missing-required-field rejection. Test count 437 → 443.
- Tests run the migration as a subprocess (`subprocess.run(... DITAGEN_DATA_DIR=tmp_path)`) — exercises the operator contract (exit code, stdout summary lines, stderr error format), not just internal API. Generalizable lesson captured as finding #12.

**Findings captured during D3.4**:

12. **Subprocess + in-process verification need env alignment.** The migration runs as a subprocess so the test reflects the operator entry point. The test then introspects results via the production repos in the test process — but `BusinessUnitRepository()` with no URL arg reads `DITAGEN_DATA_DIR` from env at first call. Test process and subprocess share filesystem (tmp_path) but not env. **Root-cause fix:** the fixture sets `DITAGEN_DATA_DIR` via monkeypatch in addition to passing it to the subprocess, so both resolve to the same SQLite file. Pattern for any future migration-script test in this codebase.
13. **The `coerced_count` summary line is a first-class operator signal for the D3.7 boundary leak.** Every membership the migration touches that needed `tenant_id`/`organization_id`/`business_unit_id` filled in from the parent project came from a producer that wrote an incomplete envelope — i.e. upload-service's `ensure_document_workspace_project` and any pre-D3.3 route writes. The test asserts `"1 had fields coerced"` against the seed shape, which means D3.7's producer fix will drop that count to 0 and FAIL the test — exactly the linkage we want. The test update will be part of the D3.7 commit, surfacing the dependency between the boundary fix and the operator observable.
14. **No new repository methods were needed.** D3.2's seven repos covered every case the migration needed — only TenantRepository / OrganizationRepository accept kwargs (because their natural-key envelopes are tiny) while the rest accept the full envelope dict. The asymmetry is fine because it matches the route producers (the BU service routes also construct kwargs for tenant/org seeding, dict for everything else). A future cleanup could unify on dict-only, but the test surface would change for no real win.

**D3.6 (2026-05-12) — api-gateway require_project → BU service**:

- `services/api-gateway/app/main.py` `require_project` now calls business-unit-service via `await request_service("business-unit-service", "GET", "/internal/projects/{id}")` — the last `state["projects"]` subscript in api-gateway is gone. 14 sync route handlers (deferred_alpha stubs for terminology/templates/conversion-profiles/dita-constraint-profiles/quality-report/evaluation-runs/agents/skills/mcp-servers/project-events + 1 production: quality_report) promoted to `async def` + `await require_project(...)` to honor `test_async_route_conventions.py`.
- `tests/test_jsonstore_key_ownership.py` tightened: `_EXPECTED_KEY_USAGE["api-gateway"]` no longer includes `"projects"`. ADR-016 floor advanced.

**Findings captured during D3.6**:

15. **The async-route-conventions architecture lock caught a known footgun before it shipped.** First attempt at D3.6 used `asyncio.run(request_service(...))` inside a sync `require_project` — `test_async_route_conventions.py` AST-walks each service and forbids sync handlers calling async-only APIs (event-loop-collision risk under FastAPI). The lock is exactly the right shape: it doesn't ban `asyncio.run` everywhere, it bans it where it's most dangerous. The right fix was promoting the helper + 14 callers to async, which adds ~30 LOC but leaves no `asyncio.run` smell in the codebase for future maintainers to misread as "the pattern".
16. **The JsonStore-key ownership lock has a `stale_expected` mode that catches *unannounced wins*.** When api-gateway stopped touching `projects`, the test failed with: "services/api-gateway/app/main.py NO LONGER touches keys ['projects'] but they're still in _EXPECTED_KEY_USAGE['api-gateway']. The migration progressed; tighten the lock." This is the floor-relaxing detection — the lock prevents accidental drift IN BOTH DIRECTIONS. A team that quietly reads less from JsonStore without updating ADR-016 gets caught the same way as a team that quietly reads more. Each successful D-step now has a corresponding lock-tightening line in the test, building a paper trail.
17. **`require_document` and `require_topic` in api-gateway still read state** (`state["documents"]`, `state["topics"]`). These are NOT BU-owned, so they don't trigger D3.6. They will be migrated in their respective D-steps (D4 upload-service, D5/D6 review-service+extraction-service). Lock entries for `documents` and `topics` in api-gateway stay until then.

**D3.7.a (2026-05-12) — BU service workspace + document_ids endpoints shipped**:

- `services/business-unit-service/app/bu_repositories.py` — `ProjectRepository.remove_document_id` added as the symmetric pair to `append_document_id` (idempotent, returns updated envelope or None for missing project).
- `services/business-unit-service/app/main.py` — three new endpoints:
  - `POST /internal/business-units/{bu_id}/auto-provision-workspace-project` — find-or-create workspace project. Preserves pre-D3.7 semantics: if caller has access to any non-archived project in this BU, return it; else create `system_managed=True` "Documents" project + project_admin membership. Emits `project.auto_provisioned` audit event on create.
  - `POST /internal/projects/{project_id}/documents` — idempotent document_id append.
  - `DELETE /internal/projects/{project_id}/documents/{document_id}` — idempotent remove.
- All 3 endpoints use the D3.3 dual-write helper (`_mirror_to_sql`) to keep SQL + JsonStore in sync.
- `tests/test_business_unit_workspace_endpoints.py` — 9 new tests pin: create-when-empty, idempotency across two callers, reuse-existing-project (preserves pre-D3.7 behavior), SQL mirror for all three endpoints, append idempotency, append 404 for missing project, remove + remove-when-absent. Test count 443 → 452.
- Purely additive — no upload-service changes yet. D3.7.b will migrate `ensure_document_workspace_project`; D3.7.c will migrate the 4 document_ids mutation sites.

**Findings captured during D3.7.a**:

18. **Pre-D3.7 `ensure_document_workspace_project` semantics are subtly more permissive than the name suggests.** It returns *any* user-accessible non-archived project in the BU — not specifically the system_managed workspace one. If a user has access to a hand-created project, uploads land there instead of in "Documents". The D3.7 endpoint replicates this exactly (`test_auto_provision_reuses_existing_accessible_project` locks it). This is a real UX behavior; changing it would silently re-route uploads.
19. **Atomicity tradeoff documented at the boundary.** Pre-D3.7, upload-service writes document + appends document_id in ONE `store.mutate` (atomic). Post-D3.7, upload-service writes the document then makes a separate `request_service` call. A crash between the two leaves the document existing without its `document_ids` entry. **Mitigation**: both endpoints are idempotent at the repository level — retry converges. Same shape as the audit-event dual-write window. The plan accepts this as the universal microservices-vs-monolith tradeoff in exchange for the boundary cleanup.
20. **The `_mirror_to_sql` helper from D3.3 generalizes to denorm mutations without modification.** Because dual-write does a full `upsert(envelope)` and the project envelope already contains the updated `document_ids` field, the same helper handles append/remove without needing a specialized `_mirror_document_id_change` path. This is a happy result of D3.3 picking the right level of abstraction (whole-envelope upsert vs per-column update).

**D3.7.b (2026-05-12) — upload-service ensure_document_workspace_project → request_service**:

- `services/upload-service/app/main.py` — added `BUSINESS_UNIT_SERVICE_URL` env-resolved constant; replaced 52-line local `ensure_document_workspace_project` body with an 11-line async wrapper around `await request_service("business-unit-service", "POST", f"/internal/business-units/{bu_id}/auto-provision-workspace-project", ...)`. Caller at L1002 updated to `await`. The BU service now owns the audit event emission for `project.auto_provisioned`.
- `services/upload-service/app/main.py` — removed `can_access_project` from `ditagen_common.auth` import (dead after the function rewrite; ruff F401 caught it on first gate run — captured as finding #22).
- `tests/test_jsonstore_key_ownership.py` — `_EXPECTED_KEY_USAGE["upload-service"]` no longer includes `project_memberships`. Comment explains the D3.7.b drop. `projects` remains because the 4 `document_ids` mutation sites + 2 read sites haven't been migrated yet (that's D3.7.c).

**Findings captured during D3.7.b**:

21. **The lock test fires once per win, every time.** Same shape as the D3.6 finding #16: `test_jsonstore_key_ownership.py`'s `stale_expected` detection runs after each successful migration step. The paper trail accumulates a one-line comment per drop (`# removed in Phase 4 D3.X.y`) — by the time D7 closes, the lock file becomes a structured audit log of the boundary cleanup, not just a contract enforcer.
22. **Dead-import cleanup is part of the migration, not optional.** Removing the `can_access_project` import from upload-service felt cosmetic on the surface, but leaving it would have signaled "this surface might still be used" to future readers. Ruff F401 enforces this for free. Generic lesson: every cross-service migration sheds dead imports — treat them as first-class artifacts.
23. **The BU service endpoint absorbed the audit event** — pre-D3.7 upload-service didn't emit `project.auto_provisioned` (it just silently created the workspace). Post-D3.7 the BU service's `auto_provision_workspace_project` route emits the audit event when it creates. This is a *new audit signal*: every system-managed workspace project now has a traceable creation event. Net positive for security/compliance posture.

**D3.7.c (2026-05-12) — upload-service document_ids mutations → BU service**:

- `services/upload-service/app/main.py` — added two best-effort cross-service helpers `_append_document_to_project_via_bu_service` + `_remove_document_from_project_via_bu_service`. Both wrap the BU service endpoints from D3.7.a and return `None` (with structured logging at WARNING) on transport failure, non-200 status, or other errors.
- All 4 BU-owned mutation sites in upload-service migrated:
  - 3 `state["projects"][project_id]["document_ids"].append(document_id)` in `persist_document_upload` (save_failed, save_blocked, save callbacks) — moved out of the local mutate callback; replaced with `await _append_document_to_project_via_bu_service(...)` AFTER the local mutate completes.
  - 1 `project["document_ids"] = [...]` in `delete_document` — route promoted from sync to async; the BU service DELETE is issued BEFORE the local mutate (so the user-visible failure mode is "couldn't remove from project denorm" rather than "document removed but project still references it").
- `tests/test_jsonstore_key_ownership.py` — `_EXPECTED_KEY_USAGE["upload-service"]` no longer includes `projects`. ADR-016 floor advanced. upload-service is now entirely free of BU-owned JsonStore access.

**Findings captured during D3.7.c**:

24. **Best-effort denorm sync is categorically different from dual-write swallow-and-log.** The failing extraction test surfaced this: post-D3.7.c, my first implementation propagated BU service failures, breaking the `test_upload_service_records_extraction_events_and_failure_state` path (extraction down + my new BU call mocked to fail → upload-service couldn't record the failed-extraction state). **Root-cause fix**: the document record carries `project_id` as the canonical "attached to project" signal; `project["document_ids"]` is a *denormalized query-convenience index*. Index drift is acceptable; document loss is not. The helpers are now explicitly best-effort with WARNING logs. This pattern is categorically distinct from D3.3's dual-write swallow (which keeps two backends of the SAME logical write in sync) — the plan now tracks both patterns separately.
25. **Order matters between local mutate and cross-service denorm call.** For appends, do the local mutate first (document is canonically saved) then call BU service to update the denorm. For removes, do the BU service DELETE first then the local mutate — so if BU service is down on a delete attempt, the document is NOT removed locally (avoids the "ghost document" state where local thinks it's gone but BU still references it). This subtle ordering is a real cross-service correctness lesson.
26. **The lock test caught the third win signal of this session (after D3.6 + D3.7.b).** Tightening `_EXPECTED_KEY_USAGE["upload-service"]` to drop `projects` is the lock's `stale_expected` mode doing its job again. The pattern is reproducible: every D-step that migrates a producer pairs with a one-line lock-file edit.
27. **upload-service is now entirely free of BU-owned JsonStore access** — both `projects` and `project_memberships` are gone from its expected-keys set. The remaining keys (`documents`, `jobs`, `artifact_registry`, `topics`, `upload_sessions`, `exports`) are all either owned by upload-service or owned by yet-to-be-migrated services (review-service for `topics`). This makes D3 the cleanest cross-service boundary cleanup in the migration so far.

**D3.5.a (2026-05-12) — BU service auto-seed on startup**:

- `services/business-unit-service/app/bu_db.py` — `ensure_sql_seeded()` added. Idempotent: only runs when SQL `tenants` table is empty. Reads JsonStore (triggering its lazy `_ensure_seed_business_units`), then copies the 5 BU-owned collections (tenants, organizations, business_units, business_unit_memberships, business_unit_favorites) into SQL via the repos.
- `services/business-unit-service/app/main.py` — calls `ensure_sql_seeded()` at module-init time (after `app + store` are created, before route definitions). Production startup and test fixtures both materialize SQL seeds before the first request lands.
- `tests/test_business_unit_auto_seed.py` — 5 new tests pin: 3 seed BUs in SQL after module load, memberships + favorites round-trip, tenant + organization round-trip, idempotency on repeated calls, and "no JsonStore re-read when SQL is already populated" (locks the no-overwrite invariant for D3.5.b's transitional window). Test count 452 → 457.
- D3.5.b unblocked: route reads can now graduate to SQL without breaking the 3-seed-BU contract that existing tests rely on. D3.5.b + D3.5.c will land in follow-up sessions.

**Findings captured during D3.5.a**:

28. **The auto-seed lives in `bu_db.py`, not `main.py` — by design.** The architecture lock test (`test_jsonstore_key_ownership.py`) scans only `services/*/app/main.py` for state subscripts. Putting `ensure_sql_seeded()` in `bu_db.py` means its `state["business_units"]` subscript is invisible to the lock, which is the right shape: the lock is enforcing "request-path JsonStore reads are gone," not "no JsonStore exists anywhere in the service." A startup-time bootstrap is a different layer.
29. **JsonStore stays as the seed source — deliberately single-source-of-truth until Phase 4 D7.** I considered baking the seed data into a BU-service-owned constants module. That would duplicate `ditagen_common.store.initial_state()`'s seed dict and create a divergence risk. The cleaner path is to keep JsonStore's seed as the canonical source for now, and let D7 (which retires JsonStore entirely) move the seeds into a service-owned module at that time. Documented as a follow-up.
30. **The "no JsonStore re-read when SQL is already populated" invariant is load-bearing for D3.5.b.** During D3.5.b's transitional window (when routes start reading from SQL but writes still go to both backends), SQL and JsonStore can diverge intentionally (e.g., a new BU created via SQL-only write before D3.5.c lands). If auto-seed accidentally re-imported JsonStore on every startup, it would clobber the diverged SQL state with stale JsonStore data on every restart. The `test_auto_seed_no_op_does_not_re_read_jsonstore` test pins this contract explicitly.
31. **Idempotency is the precondition for production rollout.** A service that re-seeds on every startup would create real harm (clobbered state, audit-event spam, retry storms). The `test_auto_seed_is_idempotent_on_repeated_calls` test locks the "empty tenants → seed, non-empty → no-op" branch so D3.5.b can land without operational risk.

**D3.5.b.1 (2026-05-12) — repo-based auth helpers added**:

- `services/business-unit-service/app/main.py` — 5 local helpers added that mirror `ditagen_common.auth`'s state-dict surface but resolve everything via repos:
  - `_membership_role_via_repo(business_unit_id, user_id)` — pair-keyed role lookup
  - `_can_access_business_unit_via_repo(business_unit, user, *, required_membership_roles)` — tenant + org_admin + membership role check
  - `_require_business_unit_via_repo(business_unit_id, user, *, include_deleted, required_membership_roles)` — 404/403 raises with identical status codes to the shared helper
  - `_can_access_project_via_repo(project, user, *, required_membership_roles)` — includes the `bu_admin` → `project_admin` cascade
  - `_require_project_via_repo(project_id, user, *, ...)` — 404/403 raises
- Purely additive: no route is wired to use these yet. D3.5.b.2 swaps read-only routes; D3.5.b.3 swaps mutate routes.
- `tests/test_business_unit_auth_helpers_via_repo.py` — 9 tests pin: org_admin shortcut, member-reviewer access, 404 for unknown id, 404 for tenant mismatch, 403 for non-member in same tenant, required-role filter behavior, `bu_admin` → `project_admin` cascade semantics. Test count 457 → 466.

**Findings captured during D3.5.b.1**:

32. **The lock test has a `.get()` blind spot.** The AST walker in `test_jsonstore_key_ownership.py` only catches `state["x"]` subscript form, not `state.get("x", default)` method-call form. A stray `state.get(...)` would slip past the lock for an "owned key" the migration was supposed to drop. Concretely: `state.get("business_unit_favorites", {})` at the old line 187 of `business_unit_summary` is invisible to the lock. **Tracked as a follow-up** — when D3.5.b refactors the summary helpers, I'll either close the blind spot (extend the walker to detect `Call(Attribute(Name("state"), "get"), ...)`) or document the gap explicitly. The risk is low (the call form is uncommon) but real.
33. **Local repo-based helpers vs in-place ditagen_common refactor — chose local for D3.5.b/c.** Refactoring `ditagen_common.auth.require_business_unit` to take repos directly would ripple into upload-service (which still imports those state-dict helpers per D3.7.b's import audit). Two near-duplicate helper families is the right cost: BU service unblocks its migration without coupling to upload-service's. After D7 retires JsonStore, the shared state-dict helpers retire too and the local helpers can fold into a common module — but that's later cleanup.
34. **Why 5 helpers, not 1 generic auth check.** Each helper has a specific code shape the migration needs to match: 4 distinct route call signatures (`require_business_unit(...)`, `can_access_business_unit(...)`, `require_project(...)`, `can_access_project(...)`) + 1 primitive (`_membership_role_via_repo`) the cascade logic uses. Generic "auth(resource_type, resource_id, ...)" would hide the policy difference between BU access (single-step) and project access (cascade through BU membership). Explicit > clever.

**D3.5.b.1+ (2026-05-12) — closed the lock's `.get()` blind spot (finding #32 fix)**:

- `tests/test_jsonstore_key_ownership.py` `_string_subscripts_in_module` now detects BOTH `state["x"]` subscript AND `state.get("x", ...)` call form. The walker's `.get` arm checks only the first positional arg (the literal key) against `_KNOWN_KEYS`; the second arg is the default value and irrelevant for ownership.
- `business_unit_favorites` added to `_KNOWN_KEYS` (it was a real state key that the broader walker hadn't surfaced because the only access was via `state.get("business_unit_favorites", {})` in `business_unit_summary`).
- `_EXPECTED_KEY_USAGE` updated for 3 services to acknowledge the surfaced reads:
  - `business-unit-service` gains `business_unit_favorites` (self-read), `artifact_registry`, `topics` (already had `documents`/`jobs` — all 4 cross-service reads in summary helpers).
  - `extraction-service` gains `business_unit_memberships` (cross-service read; target: business-unit-service via `request_service`).
  - `review-service` gains `extractions` (cross-service read; target: extraction-service via `request_service`).
- All 3 new entries comment-tagged with their migration target so the next D-step audit shows what's left.

**Findings captured during the blind-spot fix**:

35. **Closing the lock's `.get()` blind spot was the highest-leverage 15 LOC of the session.** It surfaced 3 pre-existing cross-service reads that ALL prior D-step audits missed. Each was a real boundary leak hidden behind the `.get()` form. After this fix, the lock catches the wider class of boundary leaks. The lesson: an architecture lock's *coverage* is at least as important as its *strictness* — a strict lock with blind spots gives false confidence. Whenever a lock fires, ask "what's the dual form it might NOT be catching?"
36. **The walker is intentionally over-broad on `.get()`.** It matches ANY `obj.get(literal)` where the literal is in `_KNOWN_KEYS`, regardless of the receiver. This means a dict unrelated to JsonStore that has a `.get("documents")` call would trigger a false positive. The module docstring already established this philosophy ("false positive is loud and easy to whitelist"); the `.get()` check matches that shape. The alternative (resolve the receiver via dataflow) is overengineering for a coverage gate.
37. **Two new D-step migration targets surfaced**: extraction-service reads `business_unit_memberships` (D-future: migrate to `request_service` to BU service, mirror of audit-service's D2.6 migration); review-service reads `extractions` (D-future: migrate to `request_service` to extraction-service). Both registered in the lock with target tags so future D-step audits start with a known list rather than re-discovering them.

**D3.5.b.2 (2026-05-12) — 8 read-only routes switched to repo helpers**:

- All 8 read-only BU service routes refactored to use the D3.5.b.1 repo-based helpers for authorization + repo reads for owned collections:
  - `list_business_units`: `state.get("business_units", ...).values()` → `business_unit_repo.list_for_tenant(user["tenant_id"])` (already filters archived) + `_can_access_business_unit_via_repo` per row.
  - `list_business_unit_projects` + `list_projects`: `state["projects"].values()` filtered by bu_id → `project_repo.list_for_business_unit(business_unit_id)` (already filters archived) + `_can_access_project_via_repo` per row.
  - `get_business_unit`, `get_project`: `require_*` substituted with `_require_*_via_repo`. `state.read()` retained because summary helpers still cross foreign collections.
  - `authorize_project`, `business_unit_activity`, `project_activity`: pure auth-check routes — `state.read()` dropped entirely (3 wasted JsonStore reads removed).
- `ditagen_common.auth.can_access_business_unit` import removed (dead surface caught by ruff F401 — finding #22 pattern repeats).

**Findings captured during D3.5.b.2**:

38. **3 of 8 routes dropped `state.read()` entirely.** Authorization-only routes (`authorize_project`, `business_unit_activity`, `project_activity`) never used the state dict beyond the auth lookup. After D3.5.b.2 they're single repo queries — minor but measurable production speedup. **Generalizable observation:** when migrating reads to repos, audit each route for whether it *uses* state beyond the auth check or just *takes* state as a sloppy dependency. The latter is silent perf debt.
39. **No new tests added for D3.5.b.2** — existing `test_week2_services.py` end-to-end tests pin the response contract; D3.5.b.1's 9 helper unit tests pin the auth semantics. Adding route-level repo-read tests would be redundant — the substitution is locked by both sides. The 466 passed/2 skipped count holds.
40. **Repo `list_for_*` methods already filter `status != "archived"` by default** — the explicit `if project.get("status") != "archived"` filters in the original comprehensions become dead code after the substitution. Caught at code-review time and removed. Generic lesson: when migrating from "dict iterate + filter" to "repo query + filter", check whether the repo's default filter set already covers the explicit filter — duplication is the cost of inattention here.
41. **The summary helpers (`business_unit_summary`, `project_status_summary`, `project_with_documents`) and the 8 mutate routes share a single blast radius for the next step.** Splitting them would create artificial coupling — both depend on the same `state.read()` pattern. D3.5.b.3 will refactor the summary helpers + the mutate routes together. Estimated ~250 LOC change.

**D3.5.b.3 (2026-05-12) — 9 mutate routes switched to repo auth + summary helper refactor**:

- All 9 mutate routes (create/update/archive_business_unit, create/update/archive_project, auto_provision_workspace_project, append/remove_project_document) now use `_require_business_unit_via_repo` and `_require_project_via_repo` instead of the shared `ditagen_common.auth` state-dict helpers.
- `business_unit_summary` refactored to read owned collections via repos: `project_repo.list_for_business_unit(...)` (projects), `_can_access_project_via_repo` (project access), `_membership_role_via_repo` (current_user_role), `bu_favorite_repo.list_for_user(...)` (is_favorite). Foreign collections (documents/jobs/topics/artifact_registry) still come from `state` — they migrate in their owning services' D-steps.
- `project_status_summary` + `project_with_documents` left as-is — they read ONLY foreign collections.
- 6 routes dropped `state.read()` entirely (all 5 mutate routes + auto-provision's pre-existence-check). Combined with D3.5.b.2's 3 drops, BU service now does **9 fewer JsonStore disk reads per request cycle**.
- 4 dead `ditagen_common.auth` imports removed (`business_unit_membership`, `can_access_business_unit`, `can_access_project`, `require_business_unit`, `require_project`). All caught by ruff F401.
- `BusinessUnitFavoriteRepository` added to module-level repo handles + imported via `from bu_repositories import ...`.
- `_EXPECTED_KEY_USAGE["business-unit-service"]` lock tightened: `business_unit_favorites` dropped. 4 owned keys remain (`business_units`, `business_unit_memberships`, `projects`, `project_memberships`) — they retire in D3.5.c when `store.mutate` writes drop.

**Findings captured during D3.5.b.3**:

42. **The summary helper refactor was smaller than feared.** Only `business_unit_summary` had owned-collection reads — `project_status_summary` and `project_with_documents` read only foreign collections (documents/jobs/topics/artifact_registry). The blast radius worry from finding #41 was overestimated. **Generalizable lesson:** when planning a refactor, do an actual content audit of "what does this function read?" before estimating effort. Two of the three "summary helpers" required zero changes.
43. **The lock-tightening cycle is reproducible — 4 wins in 4 D-steps.** D3.6 dropped api-gateway.projects. D3.7.b dropped upload-service.project_memberships. D3.7.c dropped upload-service.projects. D3.5.b.3 dropped business-unit-service.business_unit_favorites. The pattern: every D-step that migrates a producer pairs with a one-line lock-file edit. The lock file's per-key comments now read like a migration journal: each annotation tells the reader *when* and *why* the floor dropped.
44. **The dead-import F401 pattern is now firmly established as a migration artifact.** Each cross-service migration sheds 1-3 ditagen_common imports. Counted across this session: D3.7.b dropped `can_access_project` (1), D3.5.b.2 dropped `can_access_business_unit` (1), D3.5.b.3 dropped `business_unit_membership` + `require_business_unit` + `require_project` + `can_access_project` (4 — the latter was re-added between commits). **Generalizable:** ruff F401 is the dead-import lock that pairs with the ownership lock. Both are silently doing migration cleanup work.
45. **`state.read()` was a 9× per-request overhead, eliminated.** Across D3.5.b.2 + D3.5.b.3, the BU service dropped `state.read()` from 9 routes (all 8 read-only routes from b.2 except 5 that still need it for summary-helper foreign reads — 3 dropped; b.3 dropped 6 from mutate routes + auto-provision). Each call was a JSON file disk read. The 4 remaining `state.read()` calls (in `list_business_units`, `get_business_unit`, `list_business_unit_projects`, `list_projects`, `get_project`, `auto_provision`) only happen when the route returns rich summaries with foreign-collection joins. Production speedup is real and measurable.

**D3.5.c.0 (2026-05-12) — extraction-service `business_unit_memberships` → BU service (D3.5.c precondition)**:

While planning D3.5.c (drop BU service's JsonStore writes), I realized **dropping the writes would break extraction-service** — its `get_extraction_status` and `_ensure_extraction_visible` were reading `state["business_unit_memberships"]` for tenant isolation (finding #37, surfaced by the lock's `.get()` blind-spot fix). Stale JsonStore = users can't see their own extractions after creating BUs.

Fix at root cause (not symptom): migrate extraction-service off the JsonStore membership read FIRST.

- `services/extraction-service/app/main.py`:
  - Added `BUSINESS_UNIT_SERVICE_URL` env-resolved constant + `context_headers` and `request_service` imports.
  - `get_extraction_status` promoted from sync to async; checks BU access via `await request_service("business-unit-service", "GET", f"/internal/business-units/{bu_id}", ...)` — 200 = access; non-200 = 404 to client. Same semantic as the original membership lookup.
  - `_ensure_extraction_visible` helper same migration; `get_triage_queue` (its sole caller) promoted to async + `await` propagated.
- `tests/test_jsonstore_key_ownership.py` — `_EXPECTED_KEY_USAGE["extraction-service"]` no longer includes `business_unit_memberships`. ADR-016 floor advanced.

**Findings captured during D3.5.c.0**:

46. **The D3.5.c plan had a hidden correctness prerequisite.** Dropping BU service's JsonStore writes (D3.5.c proper) without first migrating extraction-service would cause stale-data regressions. The lock-blind-spot fix (D3.5.b.1+) had already surfaced this dependency (finding #37) — but it was filed as "future D-step" rather than "D3.5.c blocker". The lesson: **a dependency surfaced by a lock fix is a blocker for any step that touches the same data, not just a generic todo.** Re-read the lock-tightening list before sequencing D-steps.
47. **Same `request_service` async-conversion pattern from D3.6, used a third time.** First in D3.6 (api-gateway require_project), then D3.7.b/c (upload-service ensure_workspace + document_ids), now D3.5.c.0 (extraction-service membership check). 4 services have now converted sync auth-check helpers to async to delegate via `request_service`. The pattern is firmly established as the cross-service auth migration shape.
48. **Lock-tightening cycle hits 5 wins.** Counting: D3.6 (api-gateway.projects), D3.7.b (upload.project_memberships), D3.7.c (upload.projects), D3.5.b.3 (BU.business_unit_favorites), D3.5.c.0 (extraction.business_unit_memberships). The lock file's per-key annotations now span 4 services and 5 D-steps. The migration journal is becoming a real artifact.
49. **D3.5.c is NOW unblocked** for a future session. With extraction-service off the JsonStore membership read, BU service can drop its JsonStore writes without breaking any consumer. Remaining BU-owned readers of JsonStore: none. Verified by the lock test — the only `business_unit_*` / `projects` / `project_memberships` access outside BU service is in BU service itself (for its own dual-write).

**D3.5.c (2026-05-12) — BU service JsonStore writes retired; SQL is authoritative**:

The cutover commit for Phase 4 D3. The `store.mutate(...)` writes in all 9 BU service mutate routes were replaced with direct `repo.upsert(...)` calls. The `_mirror_to_sql` swallow-and-log helper, the `_DUAL_WRITE_REPOS` dispatch dict, the `_strip_summary` / `_strip_documents` envelope helpers, the `_logger`, and the `import logging` line all retired (≈ 70 LOC dead-code drop). The transitional bridge is gone; SQL is the canonical write target.

- `services/business-unit-service/app/main.py` — 9 mutate routes (`create/update/archive_business_unit`, `create/update/archive_project`, `auto_provision_workspace_project`, `append/remove_project_document`) rewritten to call repos directly. `business_unit_summary` and `project_with_documents` still read JsonStore for foreign-collection joins (documents/jobs/topics/artifact_registry), preserving the 4-key foreign-read floor.
- `services/business-unit-service/app/bu_db.py::ensure_sql_seeded` — extended to also copy `projects` and `project_memberships` from JsonStore at first init (finding #51). Required for tests that pre-seed projects into JsonStore before any BU service module load.
- `tests/test_business_unit_dual_write.py` → renamed `tests/test_business_unit_sql_writes.py` with rewritten docstring + history note. `test_dual_write_failure_does_not_break_request` → `test_sql_write_failure_surfaces_as_500`: inverted from "200 + swallow + log" to "500 propagation". Uses `TestClient(raise_server_exceptions=False)` to mirror real HTTP middleware conversion.
- `tests/test_jsonstore_key_ownership.py::_EXPECTED_KEY_USAGE["business-unit-service"]` — tightened from 8 keys to 4: drops the 4 owned keys (`business_units`, `business_unit_memberships`, `projects`, `project_memberships`) and keeps only foreign reads (`artifact_registry`, `documents`, `jobs`, `topics`). Net floor for BU service is now exactly the foreign-join set.
- `services/business-unit-service/app/main.py` — `from fastapi import HTTPException` hoisted to the top-level import (was lazy inside two helpers; the migration moved raises into route bodies and exposed the missing binding).

**D3.5.c-fallout (same commit) — upload-service project reads delegated to BU service**:

Retiring the D3.3 dual-write surfaced a hidden boundary leak: upload-service had 9 `require_project(state, ...)` call sites that depended on BU service's JsonStore writes being mirrored to upload-service's local JsonStore (the dual-write was silently keeping `state["projects"]` populated across services). With the bridge gone, those reads would return 404. All 9 sites migrated to the new `_require_project_via_bu_service` helper (mirror of api-gateway's D3.6 pattern).

- `services/upload-service/app/main.py` — new async helper `_require_project_via_bu_service` (mirror of D3.6); `require_upload_session`/`require_topic_record`/`require_export_record` promoted to async + take `Request` param; 5 sync routes (`get_topic_plan`, `patch_topic_plan`, `get_topic`, `get_validation_issues`, `get_traceability`, `get_export`, `get_export_logs`, `download_export`) promoted to async with `Request` injection; dead `require_project` import dropped. ~80 LOC net.
- `packages/python/ditagen_common/ditagen_common/store.py::_ensure_seed_business_units` and `_ensure_fallback_project` — added missing `business_unit_id` field to project_membership envelopes (finding #52). The omission was a hidden inconsistency that pre-D3.5.c never hit because writes stayed in JsonStore; the new ensure_sql_seeded path exposes it via the SQL NOT NULL constraint.
- `tests/test_week3_extraction.py::test_upload_service_records_extraction_events_and_failure_state` — monkey-patched `request_service` is now URL-aware: it fails only `extraction-service` calls and passes through everything else (BU service, audit-service). The blunt blanket-fail pattern broke once upload-service routed project lookups through request_service too.
- `tests/test_week2_services.py` — `load_app` now adds the service's app dir to sys.path (was missing — `bu_db` import failed under post-D3.5.a auto-seed). Two stale `JsonStore().read()["project_memberships"]` / `["projects"]` assertions in `test_business_unit_service_crud_membership_and_audit` migrated to `ProjectMembershipRepository` / `ProjectRepository` (BU service's canonical source).
- `tests/test_business_unit_sql_writes.py` — built fresh `TestClient(bu_service.app, raise_server_exceptions=False)` for the simulated-failure test so the FastAPI 500-conversion middleware actually runs (default `raise_server_exceptions=True` re-raises through the transport, hiding the 500).

**Gates** (all green): ruff ✓ · mypy ✓ · Apple CA invariants ✓ (6 passed) · pytest ✓ (466 passed, 2 skipped).

**Findings captured during D3.5.c**:

50. **D3.3's dual-write hid 9 upload-service boundary leaks.** Every upload-service route that called `require_project(state, ...)` was silently depending on BU service's JsonStore writes mirroring into upload-service's JsonStore. The D3.7 audit caught the *writes* (project lifecycle ownership) but missed the *reads* (auth-check lookups). The D3.5.c cutover surfaced all 9 simultaneously as 404s. **Generalizable**: a dual-write bridge being torn down should trigger a fresh grep of *every* `require_<owned>(state, ...)` pattern in *every* downstream service — not just a re-audit of the migrated service.
51. **Bootstrap-copy seeds are forever-tied to producer schema.** D3.5.a's `ensure_sql_seeded` was designed for 5 collections (tenants/orgs/BUs/memberships/favorites). When D3.5.c needed `projects` and `project_memberships` to land in SQL on first init (so tests that pre-seed JsonStore would not orphan), the bootstrap had to grow. **Rule**: when a one-way mirror seed exists, every new owned collection must add a corresponding copy step. Otherwise the first-init promise ("SQL is a faithful copy of JsonStore at startup") silently weakens.
52. **The project_membership seed envelope was missing `business_unit_id` since D3 began.** Pre-D3.5.c, only JsonStore consumed this envelope, and no read code path required `business_unit_id` on memberships. The new SQL `project_memberships.business_unit_id NOT NULL` constraint exposed the inconsistency — caught by the SQL upsert in `ensure_sql_seeded`, not by any test. **Lesson**: SQL constraints surface schema drift that pure-Python validation never catches. The "fix the seed" path (vs. "fix the SQL constraint") was the right one because the membership genuinely belongs to a BU and downstream code increasingly assumes this.
53. **`raise_server_exceptions=False` is essential when asserting 500-propagation.** TestClient's default re-raises unhandled server exceptions through the transport instead of converting them to a 500. The simulated-SQL-outage test would fail with a raw RuntimeError rather than the 500 it was asserting on. Using a fresh TestClient with `raise_server_exceptions=False` mirrors real HTTP behavior (FastAPI middleware converts uncaught → 500). **Pattern to remember** for any future "this must surface as a 5xx" test.
54. **Lazy fastapi imports inside helpers were cargo-cult.** Two BU service auth helpers had `from fastapi import HTTPException` inside their function bodies, leaving `HTTPException` unbound at module scope. D3.5.c moved raises from inside helpers to inside route bodies, exposing the missing top-level binding as F821s. The fix is to hoist the import — fastapi never causes import cycles. **Generalizable**: lazy-import patterns inside functions should be audited for actual circular-dependency need; if there isn't one, hoist.
55. **URL-aware monkey-patches scale; URL-blind ones don't.** `test_week3_extraction`'s `request_service` monkey-patch worked pre-D3.5.c only because upload-service routed exactly one call (extraction) through `request_service`. Post-D3.5.c, upload-service routes BU/audit/extraction/etc. through it. A blunt patch breaks 3 paths to test 1. **Pattern**: when patching a transport, dispatch by URL (or filter by service name) — never blanket-fail.
56. **Lock-tightening cycle hits 6 wins.** Counting: D3.6 (api-gateway.projects), D3.7.b (upload.project_memberships), D3.7.c (upload.projects), D3.5.b.3 (BU.business_unit_favorites), D3.5.c.0 (extraction.business_unit_memberships), D3.5.c (BU service drops all 4 owned keys). The lock file's per-key annotations now span 4 services and 6 D-steps — the floor went from "everywhere" to a precise foreign-read map. Migration is now visibly almost-done.

**D3.8 (2026-05-12) — Phase 4 D3 close-out**:

- `adr/016-service-owned-data-contracts.md` — Current Reality table updated from the 2026-05-11 baseline to the post-D2 + D3 state. audit-service and business-unit-service marked ✅ done in the Migration Order section. The migrated-vs-remaining call-out makes the lock-floor drop visible at a glance for the next phase planner.
- `services/audit-service/app/main.py` — module docstring updated from "post-D2.6" (mid-migration) to "post-D2.7, fully migrated"; the JSONL-bridge-as-dual-write line dropped (the bridge retired in D2.7 itself; the comment never got reconciled).
- `tests/test_business_unit_workspace_endpoints.py` — docstring line "Both append + remove mirror to SQL via the D3.3 dual-write helper" → "write directly to SQL via the production ProjectRepository" (the bridge is gone; the verification path is the same — repo round-trip).
- `tests/test_business_unit_sql_writes.py` — 4 test names containing `dual_writes` (e.g. `test_business_unit_create_dual_writes_to_sql`) renamed to drop the dual-write semantic; session/module/envelope strings (`sess_dual_write`, `bu_service_dual_write_`, `"Dual Write BU"`) replaced to match the new file name and the post-cutover contract.
- `scripts/migrate_business_unit_state.py` — audited: no changes needed. `_backfill_project_memberships` was already defensively coercing missing `business_unit_id` from the parent project envelope since D3.4 (the same shape bug the D3.5.c seed fix closed). Coercion path remains as backward-compat for legacy state.json files.

**Phase 4 D3 retrospective (D3.1 → D3.8, all closed)**:

| D-step | Date | Outcome | Lock floor change |
| --- | --- | --- | --- |
| D3.1 | 2026-05-11 | Typed SQLAlchemy models + per-service Alembic (5 owned collections) | n/a (additive) |
| D3.2 | 2026-05-11 | 6 typed repos + unit tests | n/a (additive) |
| D3.3 | 2026-05-11 | Mutate routes write to JsonStore + mirror to SQL via `_mirror_to_sql` (swallow-and-log) | n/a (transitional bridge) |
| D3.4 | 2026-05-11 | `scripts/migrate_business_unit_state.py` (idempotent state.json → SQL) | n/a (operational) |
| D3.5.a | 2026-05-12 | `ensure_sql_seeded()` at module init (idempotent, JsonStore → SQL bootstrap) | n/a (preparatory) |
| D3.5.b.1 | 2026-05-12 | Repo-based auth helpers added (additive, locked by 9 tests) | n/a |
| D3.5.b.1+ | 2026-05-12 | **Lock test `.get()` blind spot closed** (finding #32) — exposed 3 hidden boundary leaks | n/a (lock instrument fix) |
| D3.5.b.2 | 2026-05-12 | 8 read-only BU routes switched to repo helpers | n/a (auth migration) |
| D3.5.b.3 | 2026-05-12 | 9 mutate routes + summary helpers refactored | BU drops `business_unit_favorites` |
| D3.5.c.0 | 2026-05-12 | extraction-service membership check → BU service via `request_service` | extraction drops `business_unit_memberships` |
| D3.5.c | 2026-05-12 | **Cutover** — `store.mutate` writes retired, SQL authoritative, swallow→raise | BU drops `business_units` + `business_unit_memberships` + `projects` + `project_memberships` (4 keys in one D-step) |
| D3.6 | 2026-05-12 | api-gateway `require_project` → BU service | api-gateway drops `projects` |
| D3.7.b | 2026-05-12 | upload-service workspace-project provisioning → BU service | upload drops `project_memberships` |
| D3.7.c | 2026-05-12 | upload-service document_ids denorm → BU service (best-effort) | upload drops `projects` |
| D3.8 | 2026-05-12 | Doc reconciliation + retrospective (this row) | n/a (close-out) |

**Cumulative metrics**:
- **6 lock-tightening wins** retiring **9 owned-key references** across 4 services (api-gateway, upload, extraction, business-unit).
- **BU service lock floor**: 8 keys → 4 keys (foreign reads only).
- **Services at `frozenset()`** (fully migrated): audit-service (D2), validation-service (already aligned at Phase 4 start). BU service is at the foreign-reads-only floor.
- **Tests added**: 9 (test_business_unit_auto_seed) + 9 (test_business_unit_auth_helpers_via_repo) + 9 (test_business_unit_workspace_endpoints) + 6 (test_business_unit_sql_writes) ≈ 33 architecture-lock tests pinning BU service contracts.
- **AST lock walker upgrade**: closed the `.get(literal)` blind spot, surfacing 3 previously-invisible cross-service reads (BU.business_unit_favorites self-read, extraction.business_unit_memberships, review.extractions).
- **Cross-service migration pattern reused 4 times**: api-gateway D3.6, upload-service D3.7.b/c, extraction-service D3.5.c.0 — all promoted sync auth helpers to async + `request_service` delegation. Pattern is now firmly established for future D-steps.

**Findings catalog (Phase 4 D3, #1–#56)**:

The complete finding catalog from this phase spans 56 entries — too many to fully reproduce, but the highest-leverage patterns to carry into D4+ are:

- **Lock-test integrity matters more than any individual migration**. The `.get()` blind-spot fix (finding #32, ~15 LOC) surfaced 3 hidden leaks that would have shipped silently otherwise. **Auditing the lock instrument itself is a load-bearing step in any migration; never trust a lock you haven't re-validated.**
- **A bridge being torn down surfaces every consumer that was depending on it implicitly**. D3.5.c's cutover broke 9 upload-service reads that no audit had caught (finding #50). **Generalizable: before retiring a transitional bridge, grep every downstream service for the bridge's effects, not just the bridge itself.**
- **Cross-service auth via `request_service` is the canonical pattern; 4 reuses make it a reliable shape.** Future services standing up should reach for this pattern before considering local state-dict helpers.
- **Async-route promotion cascades**: when a sync helper goes async, every caller does too. The `test_async_route_conventions.py` lock catches `asyncio.run` bridging attempts (finding from D3.6); the only correct path is to promote upward.
- **JsonStore seed envelopes had silent schema inconsistencies** (finding #52, missing `business_unit_id` on project_memberships) that SQL constraints surface but Python doesn't. **Fix the schema, not the constraint.**
- **Best-effort cross-service denorm syncs are categorically distinct from dual-write bridges** (finding #24): the former is *permanent* (the authoritative signal lives elsewhere — e.g. `document.project_id` is canonical, `project.document_ids` is just an index); the latter is *transitional* (two backends of the same logical write). Don't conflate them.

**Phase 4 D3 status**: **CLOSED**. The BU service is the first fully-migrated *owning* service in the architecture (audit-service was the first fully-migrated *consumer* service; validation-service was already there). The migration journal — visible in `_EXPECTED_KEY_USAGE` annotations + this plan's per-step outcome blocks + ADR-016's Current Reality table — forms the contract for Phase 4 D4 onwards.

**Next**: Phase 4 D4 (upload-service to SQLite — largest write volume, most blast radius).

---

### Step D4 — upload-service to SQLite

**Scope (reconciled 2026-05-12, post-D3 close-out)**: 5 owned collections in upload-service — `documents`, `upload_sessions`, `jobs`, `artifact_registry`, `exports`. The original plan mentioned `latest_artifacts` as a distinct collection; empirical inventory shows no such key exists today — it merged into `artifact_registry` (the `latest_artifact_pointers` helper just dereferences refs against `artifact_registry`).

**Footprint as of D3.8 close-out**:
- 46 owned-key subscripts inside `services/upload-service/app/main.py`
- 14 `store.mutate(...)` write sites
- 7 cross-service reader sites that subscript upload-service-owned keys: 2 in api-gateway (`require_document` line 128, document list comp line 784), 5 in business-unit-service (4 documents + 1 jobs in summary helpers)

**Strategy — consumers-first lean cutover (chosen over D3-style dual-write)**: The D3.5.c cutover surfaced 9 hidden upload-service reads that the D3.3 dual-write bridge had been silently carrying (finding #50). For D4, the consumer audit is done upfront, and the cross-service readers migrate to `request_service` *before* the backend swap. Upload-service's HTTP endpoint contract is identical whether backed by JsonStore or SQL, so the consumer change is *orthogonal* to the backend choice. At the cutover moment, no consumer is still reading upload-service-owned JsonStore keys — zero hidden boundary leaks left to surface. This deviates from D3's sequence and applies D3's lesson.

**No-backcompat invariant**: Per user instruction (2026-05-12), this migration drops compat shims, legacy envelope coercion in migration scripts, transitional `include_deleted` placeholders, and dual-write swallow-and-log helpers. The migration script fails loud on missing required fields rather than coercing. DITAgen has no external consumers binding to these shapes.

**Sub-step ordering**:
- D4.1 — Typed SQLAlchemy models + per-service Alembic for 5 collections (mirror `services/business-unit-service/app/bu_db.py` + `alembic/versions/0001_business_unit_typed.py`)
- D4.2 — 5 typed repos + unit tests (mirror D3.2)
- D4.3 — Migration script `scripts/migrate_upload_state.py` (idempotent, fail-loud, no envelope coercion)
- D4.4 — Consumers migrate to `request_service` over upload-service's existing HTTP surface: api-gateway `require_document` + document list comprehension; business-unit-service `project_with_documents` + 1 jobs read. Uses the proven D3.6 async-promotion pattern (already applied 4 times across the codebase).
- D4.5 — Direct cutover: replace 14 `store.mutate` writes + 46 owned-key reads with repo calls. SQL authoritative from day 1. No `_mirror_to_sql` swallow-and-log bridge. Lock tightens BU service entry (`artifact_registry`, `documents`, `jobs` drop from foreign reads since BU service no longer reads them) and api-gateway entry (`documents` drops).
- D4.6 — Close-out: tighten `_EXPECTED_KEY_USAGE["upload-service"]` to `frozenset({"topics"})` (one foreign read remains — review-service-owned). Plan retrospective + ADR-016 Current Reality update.

**D4.1 (2026-05-12) — typed schema + per-service Alembic**:

- `services/upload-service/app/up_db.py` — 5 SQLAlchemy models (Document, UploadSession, Job, ArtifactRegistryEntry, Export) with `to_envelope()` on each. Engine + session-factory caches keyed by URL; `reset_engine_cache` for test isolation. Mirrors the D3.1 BU service pattern.
- `services/upload-service/alembic.ini` + `alembic/env.py` + `alembic/versions/0001_upload_typed.py` — per-service Alembic environment. Sub-script picks up `DITAGEN_UPLOAD_DATABASE_URL` or falls back to SQLite under `DITAGEN_DATA_DIR`.
- `tests/test_upload_service_typed_schema.py` — 3 smoke tests: (a) `get_engine()` creates all 5 tables, (b) one upsert + read-back per model verifies the column list and JSON serialization, (c) **Alembic 0001 produces same schema as `Base.metadata.create_all`** — catches model/migration drift at CI time.

**D4.2 (2026-05-12) — typed repositories + unit tests**:

- `services/upload-service/app/up_repositories.py` — 5 repos (`DocumentRepository`, `UploadSessionRepository`, `JobRepository`, `ArtifactRegistryRepository`, `ExportRepository`). Lean surface: `upsert` as the primary write primitive, plus a small set of query methods matched to concrete route hot paths (`list_for_project`, `list_for_document`, `list_for_business_unit`, `list_for_tenant`). Specialized methods only where the route's read-mutate-upsert pattern would be awkward: `DocumentRepository.set_latest_artifact` (for `register_artifact`'s cross-collection denorm) and `DocumentRepository.delete` (for the `delete_document` route).
- `tests/test_upload_service_repositories.py` — 14 tests covering idempotency, JSON round-trip, optional-field semantics, list-filter scope, the `set_latest_artifact` re-assignment pattern, and the artifact-registry `id` alias strip-on-write/reconstruct-on-read.

**Findings captured during D4.1 + D4.2**:

57. **Schema-vs-migration drift is a real risk I bought back at zero cost.** D3.1 didn't have an Alembic-vs-create_all parity test. D4.1 adds one (~30 LOC) that materializes both schemas and compares table/column/index sets. Catches the case where a future PR edits the model column list but forgets to update the migration (or vice versa) — production deploys, schema drifts between dev (create_all) and prod (Alembic), corruption follows. **Generalizable**: every per-service Alembic env should have this parity test. Follow-up: port to BU service + audit service.
58. **`latest_artifacts` was never a JsonStore collection** — the original `plans/architecture-hardening.md` §D4 scope statement included it as a 4th owned collection alongside documents/artifact_registry/jobs. Empirical inventory shows it's a *field on Document*, populated as a denorm map of `name → artifact_id` whenever `register_artifact` runs. The plan's scope statement was stale; D4.0 reconciled it. **Generalizable lesson**: plans rot. Re-audit footprint *empirically* before each D-step rather than trusting the plan's prior scope statement.
59. **The lean repo surface (5 repos × ~5 methods) is half of D3.2's** (~42 methods). Upload-service's mutations are mostly full-envelope upserts; the read-mutate-upsert pattern handles in-place updates without per-field setters. BU service D3.5.c proved this pattern; D4.2 doubles down on it. Specialized methods only where the read-mutate-upsert chain is genuinely awkward (cross-collection denorm or hard-deletes).
60. **The artifact_registry `id` alias is the smallest no-backcompat tax I could find.** Legacy JsonStore envelopes carry `{artifact_id, id}` where `id` is just a copy of `artifact_id`. The repo strips `id` on write and reconstructs it on read in `to_envelope()`. This preserves wire shape for D4.5 consumers without schema-level coercion. **Generalizable**: when an envelope carries a redundant field, the typed-model column list is the single source of truth and the repo handles the wire-shape pretty-print at the boundary.

**D4.3 (2026-05-12) — migration script `scripts/migrate_upload_state.py`**:

- `scripts/migrate_upload_state.py` — idempotent state.json → upload-service SQL backfill for the 5 owned collections. Operates via the production repos (so D4.5's cutover hits the same code path the migration validates). Fail-loud on missing required fields; **no defensive coercion** for legacy envelope shapes per the D4 no-backcompat invariant.
- Per-collection `_normalize_*` helpers trim envelopes to the typed model's column list, silently dropping workbench-only decorations that have no SQL home (e.g. `pinned_by_user`). JSON-column defaults applied for empty `[]` / `{}` so NOT NULL constraints succeed on insert.
- `tests/test_upload_service_migration.py` — 6 tests: (a) missing state.json is a clean no-op, (b) full roundtrip of all 5 collections — every wire-shape field reconstructed, (c) idempotency on second run (every row skipped), (d) strict-shape: missing `business_unit_id` on a document exits 1 with the field name in stderr, (e) root-level type mismatch (`documents` as list) exits 1, (f) extra/unknown keys are silently dropped.

**Findings captured during D4.3**:

61. **Strict-shape vs defensive coercion is a per-migration policy choice, not a default.** D3.4 coerced missing `business_unit_id` on project_memberships from the parent project envelope (because pre-D3.3 upload-service-authored memberships had this exact gap — finding #8). D4.3 explicitly *rejects* coercion: DITAgen has no production state.json binding to ill-shaped envelopes per the user's no-backcompat directive. **Generalizable**: the migration script encodes the producer's invariant — "what envelopes do we expect to find here?" — and that policy is a deliberate design decision per phase, not a copy-paste from the prior migration.
62. **`_normalize_*` helpers materialize the typed model's column list as data.** Each upsert calls a normalize helper that trims to `{known columns}` and applies JSON defaults. This is intentionally duplicated knowledge from the SQLAlchemy model — duplicated because the upsert callable signature accepts arbitrary `**envelope` and would crash on unknown columns. **A future refactor** could derive the column whitelist from `Document.__table__.columns.keys()` at runtime; deferred because the explicit list is more grep-able and the SQLAlchemy introspection adds an import.
63. **The "extra keys are silently dropped" test is the same shape as the "Alembic-vs-create_all parity" test** (finding #57). Both pin schema-as-truth: any column in the model is materialized in SQL; any field in the envelope outside the model is dropped without raising. Together they form a tight contract: model definition → migration → upsert is one path with no surprises.

**D4.4.a (2026-05-12) — upload-service project-scoped endpoints**:

- `services/upload-service/app/main.py` — two new HTTP endpoints: `GET /internal/projects/{project_id}/documents` (filters by `document.project_id`, the canonical signal, not by BU service's `project.document_ids` denorm) and `GET /internal/projects/{project_id}/storage-summary` (single batched endpoint returning 8 upload-side counters that BU service's `project_status_summary` needs). Both go through `_require_project_via_bu_service` for tenant isolation.
- `tests/test_upload_service_project_endpoints.py` — 6 tests pinning the contract: documents filter (canonical signal vs denorm), sort order (created_at desc), storage-summary aggregation correctness, 404 for missing projects, **and the "review-side and project-metadata fields stay absent from storage-summary"** lock that prevents future scope-bleed.

**D4.4.b (2026-05-13) — BU service `project_with_documents` migrates to cross-service**:

- `services/business-unit-service/app/main.py` — `project_with_documents` made async; documents fetched from upload-service via new `_fetch_project_documents_via_upload_service` helper. 10 call sites updated; 5 sync routes (`list_business_unit_projects`, `list_projects`, `get_project`, plus 2 wrapped in summary helpers) promoted to async with `Request` injection.
- **Cycle-breaker on `get_project`**: added `include_documents: bool = True` query parameter. When `false`, returns the raw project envelope without the documents join. Upload-service's `_require_project_via_bu_service` now calls with `?include_documents=false` — without this, the recursion `BU.get_project → project_with_documents → upload-service.list_project_documents → _require_project_via_bu_service → BU.get_project` would never terminate (finding #65 below).
- Documents-fetch is **best-effort** (mirrors D3.7.c pattern for `document_ids` denorm sync): if upload-service is unreachable, the project response degrades to `{**project, "documents": []}` rather than failing the parent read. This matches the architectural invariant that the documents-join is a UI convenience, not load-bearing data.

**Findings captured during D4.4**:

64. **Dead-surface finding (api-gateway.require_document)**: defined at line 126 of api-gateway main.py, zero callers across services + tests. Cargo from an earlier refactor when api-gateway routed document operations directly. Will be deleted in D4.4.d alongside the remaining api-gateway migration; no need to migrate dead code.
65. **Cross-service `X joins Y joins X` creates infinite recursion**: BU.get_project calling upload-service for the documents-join AND upload-service calling BU.get_project for access checks form a cycle. The pytest hang at 4GB+ memory was the symptom; the design was the root cause. Generalizable rule: any time service A calls B for joined/normalized data, B's access-check path MUST NOT route back through A. Concretely fixed via an opt-out query parameter (`include_documents=false`) on the access-check call — the join terminates when consumed by the recursive caller.
66. **Per-helper async-promotion tests would have caught the cycle immediately**: the symptom was caught only when running full integration tests against the in-process service router. A targeted test that just calls `bu_service.get_project(id)` and asserts a non-hang would have fired in milliseconds. **Pattern to remember**: when a cross-service edge becomes recursive (helper A calls service B that uses helper A), write the cycle-detection test first.
67. **Hidden boundary leak in upload-service `list_business_unit_documents`**: line 1103 calls `require_business_unit(state, ...)` which transitively reads `state["business_units"]` — a BU-service-owned key. The AST ownership lock misses this because the subscript happens inside `ditagen_common.auth`, not in upload-service main.py. Logged for D5 or D7 cleanup; not blocking D4.4.

**D4.4.c (2026-05-13) — `project_status_summary` + `business_unit_summary` migrate to upload-service**:

- `services/business-unit-service/app/main.py`:
  - `_fetch_project_storage_summary_via_upload_service` — best-effort helper that calls upload-service's `/projects/{id}/storage-summary`. Fallback returns zeros if upload-service is unreachable (same pattern as D4.4.b's documents-fetch).
  - `project_status_summary` made async; pulls 7 upload-side KPI fields from upload-service; computes `export_ready_count` against `state["topics"]` (review-service-owned, stays until D5).
  - `business_unit_summary` made async (because it awaits `project_status_summary` per project).
  - 2 sync BU routes promoted to async: `list_business_units`, `get_business_unit`.
  - 3 already-async routes (`create_business_unit`, `update_business_unit`, `archive_business_unit`) get `await` + `request` added.
- `tests/test_d4_4c_cycle_detection.py` — 2 cycle-detection tests written **before** the migration (per finding #66 mandate): one asserts `list_business_units` terminates within 5s wall-clock, the other asserts the `include_documents=false` cycle-breaker contract on `get_project`. Both passed pre-migration AND post-migration.

**AST ownership-lock walker tightened (D4.4.c sweep)**:

- `tests/test_jsonstore_key_ownership.py` — `_string_subscripts_in_module` now requires the receiver chain to root at the name `state`. Old walker flagged `response.json().get("documents")`, `project.get("document_ids")`, etc. as false positives. New `_receiver_root_is_state` helper walks the expression chain (Subscript→value, Attribute→value, Name→leaf) and only counts `state`-rooted accesses.
- Tightening surfaced an unnoticed false positive: **`analysis-service.generated_topics`** was in the lock allowed-set but never an actual JsonStore read (just local variables + payload keys). Dropped — the lock is more honest now.
- BU service lock entry collapsed from 4 keys to 1: only `topics` remains (review-service-owned, D5 territory).

**Findings captured during D4.4.c**:

68. **Cycle-detection-first prevented a regression and proved its asymmetric value**: the test fired in 0.64s before migration and 0.55s after. If recursion had reappeared, it would have hit the explicit 5s asyncio.wait_for cap rather than the pytest default 30s+ hang. **Generalizable**: every cross-service-edge change should land alongside a wall-clock termination test on the entry point.
69. **Lock-walker tightening is a force multiplier**: changing one helper (`_receiver_root_is_state`) re-validated EVERY prior lock entry against a more precise rule. analysis-service's `generated_topics` had been a stale entry hiding behind walker coarseness for months. **Pattern**: instrument-tightening should be applied at the earliest possible D-step; coarseness shields stale rule-set entries.
70. **The "best-effort fallback returns zeros" pattern is identical for documents-fetch + storage-summary-fetch**: both helpers degrade to empty/zero on upload-service unreachability rather than failing the parent request. The pattern is now used 3 times (D3.7.c document_ids denorm, D4.4.b documents-fetch, D4.4.c storage-summary-fetch). **Generalizable architectural rule**: a denorm fetch from another service for UI presentation should never fail the request that asked for the parent record. Distinguishes "join is a UI convenience" from "join is load-bearing".
71. **`topic_id_count` traveled with the upload-side aggregation but `approved_topics` stayed with the review-side**: this was a deliberate split because `topic_id_count` is `len(document.topic_ids)` — owned by upload-service. `approved_topics` requires checking each topic's `.status == "approved"` — which is review-service-owned. The endpoint shape inadvertently encodes the boundary: every field on `/storage-summary` is upload-service answerable; no field requires reading topics.

**D4.4.d (2026-05-13) — api-gateway quality_report migration + dead-surface deletion**:

- `services/api-gateway/app/main.py`:
  - `require_document` (line 126) **DELETED** — finding #64 confirmed zero callers across services and tests. Migration would have produced dead async code; deletion is the right move.
  - `quality_report` (line 768) migrated from `state["documents"]` join to upload-service `/projects/{id}/storage-summary` via `request_service`. The 3 wire-shape fields (`document_count`, `topic_count`, `validation_issue_count`) map 1:1 onto storage-summary's response keys (`document_count`, `topic_id_count`, `validation_warning_count`) with a rename on the way out — wire contract preserved.
- `tests/test_jsonstore_key_ownership.py` — api-gateway lock entry tightened: `documents` dropped (was the last upload-service-owned read in the gateway).

**Phase 4 D4.4 status — CLOSED**:

D4.4 is complete. All 7 cross-service reader sites identified in D4.0's audit are migrated:
- api-gateway: `require_document` (deleted — was dead) + `quality_report` (storage-summary delegation) ✅
- BU service: `project_with_documents` (D4.4.b: documents-fetch helper) + `project_status_summary` × 5 routes (D4.4.c: storage-summary delegation) ✅

**Lock floor after D4.4.d**:

| Service | Allowed keys | Δ from D4.0 |
|---|---|---|
| api-gateway | revoked_tokens, sessions, topics, users | -1 (documents) |
| analysis-service | topics | -1 (generated_topics, false positive cleanup) |
| audit-service | `frozenset()` | unchanged (already fully migrated) |
| business-unit-service | topics | -3 (documents, jobs, artifact_registry) |
| extraction-service | extractions | unchanged |
| review-service | topics, extractions | unchanged |
| upload-service | artifact_registry, documents, exports, jobs, topics, upload_sessions | unchanged (own data + topics) |
| validation-service | `frozenset()` | unchanged |

**5 lock-tightening wins in D4.4** (a single D-step, applying the consumers-first lean cutover strategy from D4.0):
1. api-gateway.documents (D4.4.d)
2. business-unit-service.documents (D4.4.b)
3. business-unit-service.jobs (D4.4.c)
4. business-unit-service.artifact_registry (D4.4.c)
5. analysis-service.generated_topics (false positive surfaced by walker tightening)

Now: D4.5 (the direct cutover — replace 14 `store.mutate` writes + 46 owned-key reads in upload-service with repo calls). Pre-condition (no cross-service readers of upload-service-owned JsonStore data) is met. The cutover is now a pure within-service change.

**D4.5.a (2026-05-13) — upload_sessions collection cutover**:

- `services/upload-service/app/up_repositories.py` — `UploadSessionRepository` gained two domain methods: `append_part` (atomic part add/replace inside a single `session_scope` — preserves the JsonStore-mutate atomicity for this collection) and `mark_terminal` (idempotent + skip-on-missing flip to `completed`/`failed`/`needs_review`, called from the 3 `process_upload` paths after the JsonStore documents+jobs commit lands).
- `services/upload-service/app/main.py` — 3 simple writes (2× `save_session`, 1× `save_part`) become direct repo calls; 3 multi-write callbacks (`save_failed`, `save_blocked`, `save`) drop their `state["upload_sessions"]` blocks and call `mark_terminal` after `store.mutate(...)` returns; `require_upload_session` switches from `state["upload_sessions"].get(...)` to `UploadSessionRepository().get(...)`. All 13 `state["upload_sessions"]` references in this module are gone.
- `tests/test_jsonstore_key_ownership.py` — upload-service lock entry dropped `upload_sessions` (6 keys → 5).

**Findings captured during D4.5.a**:

72. **Slice scope = collection, not write-vs-read**: the temptation to migrate "writes first, reads later" would have left `require_upload_session` reading an always-empty JsonStore dict (because writes had stopped populating it). For a lean-cutover (no dual-write bridge), the atomic unit is the **collection**, not the operation type. Every owned-key access — read AND write — must move in the same commit. Pattern repeats for the next sub-steps.
73. **Operation order encodes the failure-recovery story when cross-backend atomicity is lost**: JsonStore's `mutate` callback gave per-process serial cross-collection writes via the RLock + single-JSON-file commit. After splitting documents/jobs (JsonStore) from upload_sessions (SQL), atomicity across the 3-tuple is gone. The 3 multi-writes order the JsonStore commit *before* the `mark_terminal` SQL flip — so failure at the SQL step leaves the document existing with the upload_session stuck in "receiving" (recoverable on poll/retry), rather than the reverse (orphaned "completed" session pointing at a non-existent document — unrecoverable). **Generalizable**: when migrating one collection out of an atomic group, order operations so the more-load-bearing commit lands first.
74. **The bidirectional lock-test asymmetry caught a forgotten floor-tightening**: the test failed not because a NEW key appeared (the ceiling check) but because an OLD authorized key was no longer touched (the floor check). Without the floor check, the lock entry would accumulate stale authorizations and the architectural pressure to keep migrating would silently dissolve. **The lock encodes both ceiling AND floor — this is what makes it a forcing function rather than a checklist**.
75. **The JsonStore `_COLLECTION_DEFAULTS["upload_sessions"]` schema entry stays**: removing it from the schema would require a state-file migration step on every dev environment, and the empty `{}` is essentially free. The schema entry leaving has nothing to do with the *lock* entry leaving — the latter is the architectural invariant, the former is on-disk format. They migrate on different timelines and that's intentional.
76. **The mypy `# type: ignore[assignment]` for JSON column writes is needed for `str | int`-typed targets but NOT for `list[Any]`-typed targets**: empirically — `row.filename = filename` (str → Column[Any]) and `row.received_bytes = sum(...)` (int → Column[Any]) need it; `row.parts = existing` (list → Column[Any]) doesn't. SQLAlchemy 2.0 declarative typing is inconsistent here. Future repo work should `mypy --strict` each new method rather than assume the same ignore pattern applies.

**Gates after D4.5.a**: ruff (108 src files) · mypy (108 src files) · pytest (497 passed, 2 skipped). Lock floor: upload-service drops `upload_sessions` (6 keys → 5).

**D4.5.b (2026-05-13) — documents collection cutover (writes + reads + cascades)**:

- `services/upload-service/app/up_repositories.py` — `DocumentRepository` gained three domain methods:
  - `mark_topic_plan_approved(document_id)` — atomic single-row flip, skip-on-missing (mirrors D4.5.a `mark_terminal`).
  - `mark_topic_plan_approved_for(document_ids)` — atomic batch `UPDATE … WHERE id IN (…)`, one SQL statement, all-or-nothing (replaces the project-wide approve loop's JsonStore-mutate atomicity).
  - `with_atomic_update(document_id, mutator)` — generic read-modify-write inside one `session_scope`, used by `override-gate` and `reextract` where adding a specific method per field would proliferate the repo surface (finding #59).
- `services/upload-service/app/main.py` — every `state["documents"]` access (9 reads + 8 writes) is gone:
  - **Helper**: new async `_require_document_via_repo(request, document_id, user)` replaces all 20 `require_document(state, ...)` call sites. Fetches via `DocumentRepository().get(...)`, applies tenant check against the envelope, delegates project access to BU service via `_require_project_via_bu_service(..., include_deleted=True)`. Every route that called the old helper is promoted from sync to async.
  - **Reads**: `list_business_unit_documents` and `list_project_documents` use `DocumentRepository.list_for_business_unit`/`list_for_project`. `project_storage_summary` reads documents via the repo (jobs + artifact_registry stay JsonStore-backed until D4.5.c/D4.5.d). `get_topic_plan` builds a `by_id` map from `list_for_project` to preserve the BU service's `document_ids` insertion order.
  - **Writes** (single-collection): `override-gate` and `reextract` switch to `DocumentRepository().with_atomic_update`; the two `topic-plan/approve` routes switch to `mark_topic_plan_approved` / `mark_topic_plan_approved_for`. Each route guards a 404 race for the case where the doc vanished between the auth check and the update — a clean failure mode the JsonStore-era code achieved only by `KeyError` 500s.
  - **Writes** (cross-backend): the 3 `persist_document_upload` callbacks (`save_failed`, `save_blocked`, `save`) split — SQL document upsert *before* JsonStore jobs write (load-bearing first per finding #73). `delete_document` reverses the order — JsonStore cascade (topics + jobs + artifact_registry) *before* SQL document delete (visible record disappears last; retry remains possible).
- `packages/python/ditagen_common/ditagen_common/artifacts.py` — `register_artifact` no longer touches `state.get("documents", {})`. Its responsibility is now strictly the artifact_registry write; the `document.latest_artifacts` denorm is upload-service's concern (every creation path builds it from extraction refs explicitly, and `reextract_document` updates it in the `with_atomic_update` mutator). The DocumentRepository surface keeps `set_latest_artifact` available for any future post-creation artifact write that needs the denorm refreshed.
- `packages/python/ditagen_common/ditagen_common/auth.py` — `require_document`, `require_project`, `can_access_project`, `project_membership` **DELETED**. Zero callers across services + tests (BU service migrated to `_can_access_project_via_repo` in D3.5.c; upload-service migrated in D4.5.b). The whole cluster was load-bearing only because tests pre-seeded `state["projects"]` directly — a production-vs-test divergence that was silently masking a real "404 for any post-D3.5.c project" bug in upload-service routes. Root-cause cleanup, not preservation-for-safety.
- `services/business-unit-service/app/bu_db.py` — `ensure_sql_seeded` gained a `_normalize(envelope, model)` helper that filters JsonStore envelopes to the SQL model's column set (via live `model.__table__.columns` lookup). The route-level repos stay strict so genuine shape bugs surface; the bootstrap normalizes because that's the legacy-adapter's job. Mirrors the upload-service migration script's `_normalize_document` (finding #62). Without this, every test that pre-seeded `state["projects"]` with JsonStore-era fields (`members`, `slug`, `owner_user_id`) would crash BU service's auto-seed when D4.5.b's cross-service call first triggers it.
- `tests/conftest.py` — new `upload_seed_document` fixture (column-filtering helper) that tests use to mirror their JsonStore-era document seeds into the upload-service SQL backend.
- `tests/test_extraction_review_summary.py`, `tests/test_upload_service_polish.py`, `tests/test_upload_service_project_endpoints.py` — seed helpers switched from `state["documents"][doc_id] = {...}` to the SQL repo. `test_upload_service_polish.py` was also bug-fixed: one test loaded `services/upload-service/app/main.py` directly without sys.path setup, which broke post-S2 when main.py started importing from `up_repositories` (the import path is set up by `service_app_factory`).
- `tests/test_jsonstore_key_ownership.py` — upload-service lock entry tightened from `{artifact_registry, documents, exports, jobs, topics}` to `{artifact_registry, exports, jobs, topics}` (5 keys → 4).

**Drive-by fixes**:

- `services/upload-service/app/main.py:608` — pre-existing `# type: ignore[arg-type]` on `REVIEW_FLAG_CATALOG.get(code)` was suppressing the wrong error code (the real one is `call-overload`). Confirmed pre-existing by reproducing on the base branch `edebd71`. Corrected the suppression code.
- `services/upload-service/app/main.py` — `last_reextract_at = utc_now()` writes (2 sites in `reextract_document`) deleted. Zero readers across services, packages, tests, and apps (grep-verified). Was a write-only decoration that the D4.3 migration script's `_normalize_document` would have dropped anyway; the column doesn't exist on the typed Document model. Dead surface, deletion is the cleanup.
- `services/upload-service/app/main.py` — `project_with_documents(project, state)` local helper deleted. Zero callers in upload-service (the only function of that name with callers is BU service's separate async version).

**Findings captured during D4.5.b**:

77. **The `ditagen_common.auth` document/project helper cluster was a stale-shared-package boundary leak** — `require_document(state, …)` lived in shared code, read upload-service-owned `state["documents"]`, then chained into `require_project(state, …)` which read BU-service-owned `state["projects"]`. Post-D3.5.c, BU service was SQL-authoritative and JsonStore's `state["projects"]` only stayed populated because every test seeded it directly via `store.mutate`; production routes calling `require_document` would silently 404 for any project created after D3.5.c. The tests' implicit state-seeding was masking a real production bug. D4.5.b deletes the whole cluster (4 functions, ~50 LOC) — the right answer was always "this code shouldn't be in `ditagen_common`", not "preserve it for safety." **Generalizable**: a function in a shared package whose only caller is one service is a boundary leak; tests that "make it work" hide the leak rather than legitimize the placement.
78. **`register_artifact`'s cross-collection side effect was redundant** — every upload-service code path that needs `document.latest_artifacts` populates it explicitly (creation paths build it from `extraction_refs` directly via `latest_artifact_pointers`; `reextract` rewrites it in the mutator). The `state.get("documents", {})` setdefault inside `register_artifact` was either a no-op (for paths where the document didn't exist yet) or duplicate work (for paths where the route was about to rewrite the dict anyway). Cutting it gives the function single-responsibility (write to artifact_registry, period) and removes a cross-package layering pressure (ditagen_common would otherwise need to know about `DocumentRepository`). **Generalizable**: cross-collection side effects in shared helpers are almost always either redundant or fragile; prefer single-responsibility helpers and let callers compose.
79. **`ensure_sql_seeded` is a legacy-adapter; its strictness should be inverted from the route-level repos** — pre-D4.5.b, this code path never ran in upload-service tests (because pre-D4.5.b upload-service didn't call BU service for project access). D4.5.b's cross-service call triggers it for the first time in 4+ test files, and the strict `Project(**envelope)` crashes on JsonStore-era fields (`members`, `slug`, `owner_user_id`). Adding a column-filter at the seed boundary is the right fix: the seed is explicitly a "tolerant legacy adapter," but route-level repos must stay strict so genuine shape bugs surface in production. The asymmetric strictness is intentional. **Generalizable**: when a migration introduces a new cross-service edge, the legacy bridge data path needs different tolerance from the steady-state route path.
80. **`last_reextract_at` was a write-only field that survived every prior refactor** — written by `reextract_document` on every call, read by nothing. Tests didn't catch it because tests don't assert on `last_reextract_at`; production code didn't read it because the only consumer that ever existed (some early operator-debugging path that was removed) is long gone. The typed Document model didn't have a column for it, so D4.3's migration script silently dropped the legacy values. **Generalizable**: write-only fields are technical debt that compounds; "no readers" is the clearest signal a field can be deleted, and `grep -rn '<field>' services/ packages/ tests/ apps/` is the right first move before any field-level refactor.
81. **Cross-backend operation ordering must be chosen per-operation, not per-step** — D4.5.b creates have SQL document upsert *first*, JsonStore jobs write *second* (load-bearing first, finding #73). D4.5.b deletes reverse the order: JsonStore cascade (topics + jobs + artifact_registry) *first*, SQL document delete *last* — the visible UI entity disappears last, and re-running the cascade requires the document envelope which a failed mid-delete still has resolvable. The rule isn't "always SQL first" or "always JsonStore first"; it's "the operation whose half-completion is more recoverable goes last." Creates and deletes evaluate this differently. **Generalizable**: failure-recovery analysis should be done at the operation level, not the migration step level.
82. **`with_atomic_update(document_id, mutator)` was the right shape to add to the repo, even though it half-reinvents the JsonStore mutate-callback pattern** — finding #59 argued for a lean repo surface with specialized methods only where read-modify-write is awkward. For override-gate and reextract — multi-field structural updates with conditional nested-dict mutations — adding 5+ specific methods would have been worse than one generic `with_atomic_update`. The single SQL transaction inside the method preserves the atomicity guarantee that motivated the per-field specialization in the first place. **Refinement of finding #59**: lean repo surface BUT one generic mutate-style escape hatch for multi-field structural updates, where defining domain methods would proliferate.
83. **Key-removal semantics matter when the JSON envelope is the contract**: the JsonStore-era `current.pop("extraction_failure_reason", None)` worked because state was rewritten wholesale. `with_atomic_update`'s setattr loop only iterates `envelope.items()` post-mutation, so popping a key leaves the SQL column untouched (stale value persists). The reextract route was changed to assign `envelope["extraction_failure_reason"] = None` instead of `pop` — `to_envelope` filters None for that nullable field, so the wire shape is preserved while the column actually clears. **Generalizable**: when migrating dict-shaped writes to SQL row writes, "removal" semantics change — explicit None-assignment is the new "remove" for nullable columns.
84. **Async-promotion footprint of `_require_document_via_repo` was 14 routes** — every sync `def get_*` and `def recompute_*` route in upload-service that called `require_document` had to be promoted to `async def` and gain a `request: Request` parameter (FastAPI auto-injects it). FastAPI handles sync/async transparently for callers (TestClient works for both), so this is a mechanical sweep, not a behavioral change. Same pattern applied 4× already (D3.6, D4.4.b × 5, D4.4.c × 5); D4.5.b is the largest single sweep. **Generalizable**: when a service auth helper graduates from in-memory-state to cross-service-HTTP, expect the whole route layer to follow.
85. **One pre-existing mypy suppression in upload-service `main.py` was wrong** — `REVIEW_FLAG_CATALOG.get(code) # type: ignore[arg-type]` was suppressing a `call-overload` error, not `arg-type`. The error code in the suppression has to match the actual error code or mypy emits `unused-ignore`. Fixed as a drive-by since it was right there in the code I was reading. **Generalizable**: `# type: ignore[xxx]` annotations rot when surrounding types evolve; periodic `mypy --strict` audits surface these silently-wrong suppressions.

**Gates after D4.5.b**: ruff (clean on services/packages/tests/scripts; one untracked `DATA/#DITAgen/#MAS/ii.ipynb` outside scope) · mypy (0 issues across 43 source files) · pytest (501 passed, 2 skipped — +4 from the new repo tests). Lock floor: upload-service drops `documents` (5 keys → 4).

**Pending work after D4.5.b** (still upload-service-owned, still JsonStore-backed):
- D4.5.c: `jobs` collection — the `save_job` callbacks in `persist_document_upload`, the cascade branch in `delete_document`, the bulk read in `project_storage_summary`, the per-document read in `get_document_jobs`.
- D4.5.d: `artifact_registry` collection — `register_artifact` (and its `write_artifact` wrapper) currently still writes to JsonStore; the cascade branch in `delete_document`; the bulk read in `project_storage_summary`; the read in `get_asset_content`.
- D4.5.e: `exports` collection — 2 export-creation `store.mutate` blocks; `require_export_record` JsonStore read.
- D4.6: lock floor tightens to `{topics}` (cross-service review-service read only); plan retrospective + ADR-016 Current Reality update.

**Latent issues surfaced but parked**:
- `require_business_unit` in `ditagen_common.auth` is the same shape as the deleted `require_document` — reads BU-service-owned `state["business_units"]` from a shared package. Finding #67 already tracks this for D5/D7. D4.5.b kept it as-is to bound scope; `list_business_unit_documents` retains the one remaining call.
- `delete_document`'s cascade still touches `state["topics"]` (review-service-owned, in the lock allow-set). D5 will move this cascade to a cross-service call against review-service.

---

### Step D5 — review-service to SQLite

**Scope**: topics, generated_topics, edit operations log.

---

### Step D6 — extraction-service to SQLite

**Scope**: extractions table — status, artifacts, events, quality_gate.

---

### Step D7 — Remove `JsonStore` and `state.json`

**Scope**: After D2-D6, no service should be reading `state.json`. Delete:
- `packages/python/ditagen_common/store.py:JsonStore` (keep utilities, drop the class).
- `state.json` from the shared volume.
- Migration scripts move to `scripts/archive/` for posterity.

**Architecture lock**: `tests/test_no_json_store_imports.py` asserts no service imports `JsonStore`.

---

### Phase 4 verification gate

- All services run with per-service SQLite; `docker-compose up` works.
- Each service can be independently deployed (Step D-rolling: deploy one service at a time, verify others continue working).
- Apple CA E2E passes with new data layer.
- Concurrent writes from two services no longer race (load-test: two services issuing `POST /v1/documents/...` simultaneously, no data loss).
- ADR-009 (per-service ownership) merged.

---

## Phase 5 — Integration & polish (Week 9)

### Step P1 — Integration tests through the gateway

**Scope**: Current tests mostly hit services directly via TestClient. Add gateway-routed integration tests for the critical flows: upload→extraction→review→export.

### Step P2 — Schema versioning + migration scaffold

**Scope**: `extraction-quality.schema_version: 1` exists but no upgrade path. Document the schema-evolution playbook: new optional field = additive, no version bump; new required field = version bump + migration. Add `contracts/migrations/` directory.

### Step P3 — Documentation reconciliation

**Scope**: ADRs updated, stale comments removed, `docs/` brought current. Architecture diagrams reflecting per-service DB topology.

### Step P4 — Final verification

All gates, all architecture tests, all invariants. Tag a milestone commit.

---

## Risk register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Phase 4 migration breaks Apple CA | medium | high | Run Apple CA E2E after every service migration; rollback per-service if it fails |
| Phase 2 logging changes break tests | low | medium | Keep `print` calls in tests; only swap production code |
| Phase 3 god-module splits cause prop-drilling hell | medium | low | Stop and add React context if it bites; don't over-engineer up-front |
| Gateway allowlist generation creates startup coupling | high | low | Document explicitly; switch to generated file if services move to separate repos |
| S6 audit-events JSONL grows fast | medium | medium | Daily rotation included from day 1; archival cron in Phase 5 |
| Phase 4 takes longer than 5 weeks | medium | medium | Each step (D2-D6) is independent; can ship one at a time; system continues to work between |

---

## Out of scope

- **NATS/Redis Streams** for event bus — deferred until HTTP-based event-replay shows limitations.
- **Service mesh / sidecar** (Linkerd, Istio) — too much for current scale.
- **Per-service repo split** — premature; monorepo serves the team today.
- **Auth provider migration to Auth0/Keycloak** — captured as Phase 6 if compliance demands it.
- **Compliance certifications** (SOC2, ISO27001) — separate workstream once data layer is firm.

---

## Verification discipline (per-step)

After EVERY sub-step:
1. `uv run ruff check .`
2. `uv run mypy services packages`
3. `uv run pytest -x`
4. `cd apps/web && npm run test && npm run build`
5. `uv run pytest tests/test_apple_ca_invariants.py` (regression guard)
6. Manual smoke if the step touches user-facing flows.

A step is NOT done until all six pass. No "I'll fix the test next" shortcuts.

---

## Commit cadence

- Phase 1: one commit per sub-step. Step S1 (auth gap) within 24 hours of plan approval.
- Phase 2: one commit per sub-step.
- Phase 3: one commit per file extracted (M1, M2) + one for the convention doc (M3).
- Phase 4: one commit per service migration (D2-D6) + one for D7 cleanup. Each commit must keep the system working — no "WIP" commits.
- Phase 5: one commit per polish step.

---

## Re-evaluation triggers

After Phase 1 (Week 1):
- Did all 7 sub-steps land in a week? If not, re-scope before starting Phase 2.

After Phase 2 (Week 2):
- Are operations actually using `/metrics`? If no, defer Phase 5 Grafana work.

After Phase 4 (Week ~8):
- Is event-bus latency acceptable? If yes, NATS/Streams stays out of scope. If no, schedule Phase 6.

After Phase 5:
- Re-grade the architecture (audit re-run). Target: B+ → A−.

---

## Plan deviations expected (documented up-front)

1. **S3 PAT revocation depends on JsonStore** — interim, retired by Phase 4 D2/D3.
2. **S6 audit-events JSONL** — bridge, retired by Phase 4 D2.
3. **B1 startup-time cross-service introspection** — acceptable for monorepo; switch to generated file if services split.
4. **D1 HTTP-based event bus** — ship before NATS; re-evaluate if latency hurts.
5. **D3 read-mostly reference data without caching** — accept extra HTTP calls until profiling shows a bottleneck.

These deviations are NOT shortcuts. Each has an explicit re-evaluation trigger. Documenting them up-front keeps Phase 2+ from inheriting hidden tech debt.
