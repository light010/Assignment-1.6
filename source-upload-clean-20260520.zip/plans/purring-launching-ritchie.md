# DOCX Extraction Quality Gate — Implementation Plan

## Context

The next milestone is a **DOCX extraction quality gate** with Apple CA as the strict acceptance fixture. Topic classification is intentionally deferred until this gate passes, because tuning it now would tune around unstable inputs.

Current state (from a read-only exploration of the repo):

- `services/extraction-service/app/extractors.py` emits **55 source blocks** for Apple CA but assigns every block `source_location = {"page": 1}` — there is no real DOCX locator. The viewer is forced to match by text alone.
- `packages/python/ditagen_common/ditagen_common/pipeline.py:259-309` builds a **flat** structure tree: every heading is a root, `child_node_ids: []` for all. `quality.overall_confidence` is the constant `0.82 if nodes else 0.65`, and `repaired_level_count` is hardcoded `0`.
- `apps/web/src/sourceViewerModel.ts:60-116` matches via exact-string then contains-substring (≥24 chars). Normalization strips `|•·` and smart quotes but **does not** handle NBSP, zero-width chars, or wrap-induced whitespace anomalies. Result: **44/55** matched on Apple CA.
- `services/upload-service/app/main.py:267-533` (`persist_document_upload`) calls analysis-service **unconditionally** when extraction returns four artifacts and `stage != "failed"`. No quality gate exists.
- Only two document statuses are ever written: `"failed_extraction"` and `"ready_for_review"`. The frontend `mapStatusToStage` claims to handle ten more — all phantom.
- No Pandoc, panflute, mdformat, or `pypandoc` anywhere. Markdown is produced by a pure-Python string-builder (`extractors.py:537-569`).

The intended outcome of this plan:

1. Apple CA reaches **55/55 matched, 0 unlocated** in the rendered DOCX source viewer.
2. DOCX extraction emits reliable source-block locators, real heading hierarchy, deterministic Pandoc-projected Markdown.
3. Analysis is **blocked** when the extraction quality gate fails; documents land in a new `extraction_needs_review` status with Source still inspectable but Plan/Review/Export disabled.
4. No topic-classifier tuning. Any topic-plan shifts come naturally from better extraction input.

## Non-Negotiables (carry forward as gates after every phase)

- `uv run ruff check .` clean
- `uv run mypy .` clean
- `uv run pytest -x` green
- `npm --prefix apps/web run lint` clean (where applicable)
- `npm --prefix apps/web run test` green (where applicable)
- Re-running extraction on Apple CA produces **byte-identical** `source-blocks.jsonl`, `structure-tree.json`, `content.md`, `extraction-quality.json` (determinism invariant).
- No silent fallbacks. Missing Pandoc → typed `dependency.pandoc_unavailable` error. Gate failure → no analysis call. Partial artifacts → document persisted with `extraction_needs_review`, never lost.

## Stale Docs / Dead Surfaces / Boundary Leaks To Fix (Not Preserve)

The user explicitly asked me to surface and fix these rather than work around them:

1. `apps/web/src/UnlocatedEvidenceStrip.tsx` — exported, never imported. **Delete in Phase 6.**
2. `apps/web/src/SourceEvidenceViewer.tsx:543` `HtmlOriginalViewer` always emits unmatched. **Out of scope for this milestone but documented with a TODO in Phase 8.**
3. `packages/python/ditagen_common/ditagen_common/pipeline.py` `repaired_level_count: 0` is dead metadata. **Made real in Phase 2.**
4. `apps/web/src/App.tsx:827-862` `mapStatusToStage` handles ~10 statuses no service writes. **Pruned to live set + new `extraction_needs_review` in Phase 7.**
5. `apps/web/src/App.tsx:1530-1532` `defaultPanelForDocument` jumps to Workbench for `failed_extraction` because `isTerminalStatus` matches `"fail"`. **Fixed in Phase 7.**
6. `services/upload-service/app/main.py:308` checks `extraction.get("stage") == "failed"` as a magic string — `ExtractionStage` enum at `services/extraction-service/app/contracts.py:8-15` is never imported. **Fixed in Phase 5 (boundary leak).**
7. `services/upload-service/app/main.py:383-389` partial-artifact path raises 502 with **no document record persisted** — upload state silently lost. **Fixed in Phase 5.**
8. `services/extraction-service/app/main.py:314` `ExtractionError.stage = "failed"` regardless of which stage actually failed. **Fixed in Phase 3 (typed code enum).**
9. `ExtractionError.kind` is a free string with no enum. **Tightened to a `Literal[...]` union in Phase 3.**

## Critical Files (high-frequency touch list)

Backend:
- `services/extraction-service/app/extractors.py` — DOCX source-block emitter, Markdown projector, `_assemble_output` convergence.
- `services/extraction-service/app/contracts.py` — `ExtractionError`, `ExtractionStage`. Tightened.
- `services/extraction-service/app/main.py` — HTTP routes; gate artifact + `extraction-quality.json` write.
- `services/extraction-service/app/pandoc.py` — NEW. Subprocess wrapper + version probe.
- `packages/python/ditagen_common/ditagen_common/pipeline.py` — `build_structure_tree`. Level-aware.
- `services/upload-service/app/main.py` — `persist_document_upload`. Gate enforcement.
- `contracts/artifacts/source-block.schema.json` — `source_location.section` carries DOCX locator; no new top-level fields.
- `contracts/artifacts/structure-tree.schema.json` — `quality_gate` block.
- `contracts/artifacts/extraction-quality.schema.json` — NEW.
- `contracts/openapi/extraction-service.yaml`, `analysis-service.yaml`, `api-gateway.yaml` — schemas + new status.
- `pyproject.toml` (root) — add `panflute`, `mdformat`.

Frontend:
- `apps/web/src/sourceViewerModel.ts` — normalization + locator pre-pass.
- `apps/web/src/SourceEvidenceViewer.tsx` — candidate collection + table-row handling.
- `apps/web/src/api.ts` — `DocumentRecord.status` enum + `quality_gate` types.
- `apps/web/src/App.tsx` — tab gating + default-panel + status labels + dead-branch removal.
- `apps/web/src/UnlocatedEvidenceStrip.tsx` — DELETE.

Tests:
- `tests/test_apple_ca_invariants.py` — extended with locator + structure + gate assertions.
- `tests/golden/apple_ca_topic_plan.json` — may legitimately shift after Pandoc lands; regenerated **once**, with diff reviewed in Phase 9.
- `apps/web/src/sourceViewerModel.test.ts` — table-row + NBSP + locator pre-pass cases.
- `apps/web/e2e/` — Apple CA 55/55 + blocked-extraction.

---

## Phase 0 — Baseline And Diagnostic

**Goal:** Lock the failure mode before touching code. Prove the 11 unlocated blocks are real and identify *which* blocks they are.

1. Run all four gates on `main`, capture pass/fail and timings into `plans/_baseline.txt` (gitignored).
2. Write a throwaway diagnostic script `scripts/diagnose_apple_ca_unlocated.py` that:
   - Loads `tests/golden/apple_ca_topic_plan.json` (or re-runs extraction).
   - Lists exactly which 11 block IDs the current Playwright fixture would mark unlocated, with their `block_type`, `text[:80]`, and any existing `confidence_signals`.
   - This is **read-only diagnostic**. Output is committed to `plans/_apple_ca_unlocated_baseline.json` for evidence.
3. **Gate:** the 11 IDs are recorded. Plan execution proceeds **only if** the IDs match the user's screenshot evidence (44/55).
4. **Tests added:** none yet — this phase is observation.
5. **Architecture gate:** none — diagnostic only.

**Stop here for review before Phase 1.** If the 11 are not what we expect (e.g., the fixture has drifted), revisit scope.

---

## Phase 1 — DOCX Source-Block Locators

**Goal:** Give every DOCX block a stable, schema-compatible locator in `source_location.section`. Reuse the schema; **add no new top-level source-block fields.**

1. Extend `_extract_docx` in `services/extraction-service/app/extractors.py:79-199`:
   - Paragraphs: write `source_location.section = f"docx:p:{paragraph_index}"`.
   - Table rows: write `source_location.section = f"docx:tbl:{table_index}:r:{row_index}"`. The table cell text shape continues to live in the existing `cells` field; do not duplicate.
   - Preserve `page: 1` (no page-break tracking in this milestone; flagged for follow-up).
2. Confirm `contracts/artifacts/source-block.schema.json` already permits `section: string|null` (the exploration verified it does — lines 62-93 of the schema). No schema bump.
3. Keep `_block_id` deterministic per `(filename, position, text[:32])`. The locator is **additive** — it does not change block IDs.
4. Move `confidence_signals` writes to a helper `_docx_confidence_signals(...)` so the diagnostic surfaces (style, font-size, normalized-text length, NBSP count, etc.) are colocated. NBSP count surfaces into the frontend matcher via Phase 6.

**Tests:**
- Extend `tests/test_apple_ca_invariants.py` with `test_apple_ca_every_block_has_unique_docx_locator` — asserts `source_location.section` is non-null, unique, and matches `^docx:(p:\d+|tbl:\d+:r:\d+)$` for every block.
- `test_apple_ca_locator_is_monotonic` — locators sorted by emission order match document order.
- Determinism: existing `test_apple_ca_extraction_is_deterministic` continues to pass (locator is derived from indices, no randomness).

**Architecture gates after this phase:** ruff, mypy, pytest, plus a fresh `extraction-service` integration run on Apple CA showing all 55 blocks have locators.

---

## Phase 2 — Heading-Stack Structure Repair

**Goal:** Make `structure-tree.json` reflect real H1/H2/H3 hierarchy. Replace the flat list. Make `quality.overall_confidence` and `repaired_level_count` real values.

1. Rewrite `build_structure_tree` in `packages/python/ditagen_common/ditagen_common/pipeline.py:259-309`:
   - Maintain a level-aware stack: H1 starts a root branch; H2/H3 attach under nearest valid parent.
   - For non-heading blocks (paragraphs, table rows, procedure steps, notes), inherit `heading_path_ids` from the active stack — they do not become tree nodes themselves, but the **schema currently stores them as part of heading nodes' descendants via `child_node_ids`** when they belong to a section. Verify schema requirements before deciding shape; do not invent a representation. Likely outcome: `child_node_ids` lists heading children only, with non-heading blocks referenced separately on each heading node via an existing `source_block_ids` field if present, or kept on the source-block side via `heading_path_ids` (already in source-block schema).
   - Skipped-level repair: if a heading jumps H1 → H3, attach under nearest valid parent and increment `repaired_level_count`.
2. Compute `quality.overall_confidence` from real signals:
   - Penalize per repaired level.
   - Penalize per source block carrying a review flag.
   - Penalize per orphan table row.
   - Floor at 0.0, cap at 1.0.
   - This formula is colocated in a new `pipeline.compute_structure_confidence(...)` so the gate logic in Phase 3 can call it.
3. Table row groups: surface `table_id` already in source-block metadata; preserve row order and `heading_path_ids` inheritance. No tree-shape change — tables remain at source-block level, indexed by section.

**Tests:**
- `test_apple_ca_structure_tree_is_nested` — root_nodes contains only H1 ids; H2 nodes appear under their H1 parent's `child_node_ids`.
- `test_apple_ca_portal_links_under_correct_heading` — the "Apple CA Portal Links" H2 is under its parent H1 (named after the document section).
- `test_apple_ca_additional_resources_section_exists` — structural presence only; no classifier coupling.
- `test_skipped_level_repair_increments_count` — synthetic H1→H3 document, asserts `repaired_level_count == 1`.
- `test_overall_confidence_drops_with_warnings` — synthetic blocks with `MIXED_HEADING_STYLE`, asserts confidence < 0.82.

**Architecture gates:** the four standard + `test_apple_ca_extraction_is_deterministic` still passing (this is the most likely regression risk — verify byte-equality).

---

## Phase 3 — Typed Error Codes And Gate Artifact Producer

**Goal:** Tighten `ExtractionError.kind`/`stage` to enums, and emit a new `extraction-quality.json` artifact.

1. In `services/extraction-service/app/contracts.py`:
   - Replace `kind: str` on `ExtractionError` with `kind: Literal[...]` enumerating known codes. Initial set: `dependency.pandoc_unavailable` (new, lands in Phase 4), `dependency.python_docx_unavailable`, `dependency.pymupdf_unavailable`, `quality.empty_docx`, `quality.low_heading_signal`, `quality.scanned_or_image_only`, `service_unreachable`. Exhaustive switch in upload-service.
   - Make `stage` a real enum, not a hardcoded `"failed"` (fixes `main.py:314`).
2. Add `contracts/artifacts/extraction-quality.schema.json` with:
   ```json
   {
     "gate_name": "docx_source_fidelity_v1",
     "passed": true,
     "severity": "blocking",
     "total_source_blocks": 55,
     "located_source_blocks": 55,
     "unlocated_source_block_ids": [],
     "structure_confidence": 0.9,
     "blocking_reasons": []
   }
   ```
3. In `_assemble_output`, compute the gate object and write `extraction-quality.json` next to the existing artifacts. Reuse `write_artifact` from `ditagen_common.artifacts` — do not invent a new writer.
4. Gate-pass formula for DOCX:
   - Every source block has a non-null `source_location.section`.
   - Structure tree has at least one root and at least one valid parent/child relationship if more than one heading exists.
   - No `severity == "blocking"` warnings in the extraction warnings list.
   - `quality.overall_confidence ≥ 0.6` (threshold; configurable later, not in this milestone).
   - **Note:** Pandoc projection success becomes a precondition in Phase 4.
5. The route `POST /internal/extractions` in `services/extraction-service/app/main.py` returns the gate object in its response payload (`quality_gate: {...}`), in addition to writing the artifact.

**Tests:**
- `test_apple_ca_quality_gate_passes_on_baseline_extractor` — asserts the gate artifact emits with `passed: true`, `total == located == 55`. This is the milestone success criterion at the backend layer.
- `test_quality_gate_fails_on_orphan_table_rows` — synthetic fixture, asserts `blocking_reasons` is non-empty.
- `test_extraction_error_kind_is_enum` — Pydantic validation rejects unknown kinds.
- `test_extraction_quality_artifact_schema` — JSON Schema validation passes.

**Architecture gates:** four standard, plus a `contracts/artifacts/*.schema.json` lint pass.

---

## Phase 4 — Pandoc-Backed Markdown Projection

**Goal:** Replace the native Markdown projector **for DOCX only** with a Pandoc subprocess. Preserve `<!-- source:blk_xxx -->` anchors via AST post-processing. PDF / HTML / text stay on the native projector.

This is the highest-risk phase. Land it behind a Pandoc-availability check and preserve byte-determinism.

1. **Dependencies** — add to root `pyproject.toml` only (no service-level pyproject.toml exists today; the exploration confirmed):
   - `panflute>=2.3.0`
   - `mdformat>=0.7.17`
   - Do **not** add `pypandoc`. Subprocess only.
2. **New module** `services/extraction-service/app/pandoc.py`:
   - `PandocRuntime.detect()` → uses `shutil.which("pandoc")`. Returns `(path, version)` or raises `PandocUnavailableError`.
   - `PandocRuntime.convert_docx_to_ast(docx_path: Path) -> dict` — runs `pandoc -f docx -t json` in a `tempfile.TemporaryDirectory()`, captures stderr into a `dependency.pandoc_unavailable`-shaped error on failure.
   - `PandocRuntime.ast_to_markdown(ast: dict) -> str` — runs `pandoc -f json -t gfm-raw_html` (or `commonmark` per testing — choose the variant that round-trips Apple CA cleanest; **test before committing the flag**).
3. **Anchor preservation strategy** (the architectural risk):
   - After `convert_docx_to_ast`, walk the AST with `panflute`.
   - For each top-level block element (Para, Header, Table, BulletList, OrderedList, BlockQuote), match against the next source-block in document order by **comparing the locator key** computed from the AST position to the source-block's `source_location.section` written in Phase 1. If matching by locator is too brittle for tables (Pandoc may emit a single Table block where extractor emits N table rows), fall back to a **text-prefix match** within the active section scope.
   - Insert a `panflute.RawBlock("html", f"<!-- source:{block_id} -->")` immediately before each matched block.
   - Write the modified AST to JSON, re-pipe through `pandoc -f json -t gfm`, then run `mdformat` for deterministic whitespace.
4. **Routing** in `_assemble_output` (`extractors.py:436-455`):
   - If extension is `.docx` AND `PandocRuntime.detect()` succeeds: project via Pandoc.
   - If extension is `.docx` AND Pandoc unavailable: **fail extraction** with `ExtractionError(kind="dependency.pandoc_unavailable", ...)`. Do not fall back to native. Quality gate is set `passed: false` with `blocking_reasons: ["pandoc_unavailable"]`.
   - PDF / HTML / text: native projector unchanged.
5. **`content.md` artifact name preserved.** Only the producer changes.

**Tests:**
- `test_pandoc_runtime_detects_or_skips` — at session-scope, mark Pandoc tests `pytest.skip("pandoc binary not available")` when absent so CI without Pandoc still passes other phases. CI image MUST install Pandoc; documented in Phase 8.
- `test_apple_ca_content_md_anchors_one_per_block` — every backend `block_id` appears exactly once as `<!-- source:blk_xxx -->` in `content.md`. Anchor order matches document order.
- `test_apple_ca_content_md_is_byte_deterministic_across_two_runs` — re-extract twice in a temp dir, SHA256-compare `content.md`.
- `test_missing_pandoc_fails_with_typed_error` — patch `shutil.which` to return `None`, assert `ExtractionError(kind="dependency.pandoc_unavailable")`.
- Determinism gate: `tests/test_apple_ca_invariants.py::test_apple_ca_extraction_is_deterministic` is now stronger — `content.md` byte-equality across runs.
- `tests/golden/apple_ca_content_md.md` — NEW golden file, regenerated **once**, diff reviewed by hand. Subsequent changes require an explicit `--update-golden` flag.

**Architecture gates:** four standard + Pandoc-required CI check (skip locally with warning if unavailable; fail in CI image).

---

## Phase 5 — Upload-Service Gate Enforcement And Status Wiring

**Goal:** Block analysis-service when the gate fails. Introduce `extraction_needs_review`. Fix the boundary leak and the silent partial-artifact failure.

1. **Boundary fix:** import `ExtractionStage` and the new error-code `Literal` from `services.extraction_service.app.contracts` into `services.upload_service.app.main` (already cross-imported via internal package structure — check Python path; if the import is awkward, lift the enums to `packages/python/ditagen_common/ditagen_common/extraction_contracts.py` and import there).
2. **Gate enforcement** at `services/upload-service/app/main.py:308-413`:
   - After `run_extraction_request`, read `extraction["quality_gate"]` (added in Phase 3).
   - If `extraction["stage"] == ExtractionStage.FAILED`: persist a document record with `status = "failed_extraction"` (existing behavior).
   - If `extraction["quality_gate"]["passed"] is False` and `extraction["stage"] != FAILED`: persist a document with **new** status `"extraction_needs_review"`, copy `quality_gate` into `source_quality.quality_gate`, and **do not call analysis-service**.
   - Else: proceed to analysis (existing behavior).
3. **Silent-failure fix** at lines 383-389: if `missing_artifacts` is non-empty after successful extraction, treat as gate failure — persist with `extraction_needs_review` and record the missing artifacts as `blocking_reasons`. Do not raise 502 with no document persisted.
4. **`source_quality` extension** in the document record:
   ```python
   "source_quality": {
       ...existing fields,
       "quality_gate": extraction["quality_gate"],
   }
   ```
   Update the `GET /v1/documents/{id}/source-quality` route to expose this.
5. **Source-only document availability:** for `extraction_needs_review` and `failed_extraction`, ensure `GET /v1/documents/{id}/blocks`, `/markdown`, `/assets` either return empty payloads or 404 with a structured error — **never KeyError**. Add a `_safe_artifact_lookup` helper.

**Tests:**
- `test_gate_failure_blocks_analysis_call` — mock extraction to return `quality_gate.passed: False`, assert analysis-service is **not** called, assert document status is `extraction_needs_review`.
- `test_partial_artifacts_persists_document` — mock extraction to return three of four artifacts, assert document persists with `extraction_needs_review` and `blocking_reasons` includes the missing artifact names.
- `test_blocks_endpoint_safe_on_failed_extraction` — 404 or empty, never 500.
- `test_apple_ca_e2e_pipeline_passes_gate_calls_analysis` — happy path regression.

**Architecture gates:** four standard. Add an import-linter rule (or simple AST test) that asserts `upload-service` imports `ExtractionStage` only from the canonical contracts module — preventing future boundary leaks.

---

## Phase 6 — Frontend Source Viewer To 55/55

**Goal:** Take Apple CA from 44/55 to 55/55 by adding NBSP/zero-width normalization, a locator-based pre-pass, and a table-row matching path that uses backend `cells`.

1. **Normalization extension** in `apps/web/src/sourceViewerModel.ts:45-53`:
   - Add ` ` → space substitution before the whitespace-collapse step.
   - Add zero-width char stripping: `​‌‍﻿` → empty.
   - Normalize soft hyphens (`­`) → empty.
   - Normalize wrapped URLs/emails by removing internal whitespace between `://` and the next whitespace boundary. Bounded; do not over-normalize.
2. **Locator pre-pass** in `matchBlocksToCandidates`:
   - Before exact/contains text matching, parse the block's `source_location.section`. If it matches `^docx:p:(\d+)$`, look up the Nth eligible candidate by docx-preview document order. If it matches `^docx:tbl:(\d+):r:(\d+)$`, find the Nth `<tr>` inside the Mth `<table>`.
   - Locator match is **authoritative** when the rendered candidate's normalized text shares ≥ 50% token overlap with the block's normalized text (a sanity check — protects against locator drift if docx-preview changes structure across versions).
   - Locator match advances the monotonic cursor like a text match.
3. **Table-row path** for blocks with `cells`:
   - Compute two normalized candidate forms for each `<tr>`: (a) `innerText` of the row, (b) `cells.map(td => td.innerText).join(" ")`. Backend already strips `|` — match against either form, prefer (a) if both succeed.
   - For short cells (< 24 chars), bypass the contains-threshold and allow exact match on either form.
4. **Delete** `apps/web/src/UnlocatedEvidenceStrip.tsx` (dead code per exploration). Remove from `App.tsx` if any stale import exists (exploration says none).
5. **Update the matchmaker stats surface** in `SourceEvidenceViewer.tsx:226` to display the matched count out of total (`44/55` → `55/55` UX), not just the unmatched count.

**Tests** in `apps/web/src/sourceViewerModel.test.ts`:
- `matches NBSP-bearing block text`
- `matches zero-width-bearing block text`
- `matches wrapped URL block`
- `matches table-row block via cells path`
- `matches by locator when text is ambiguous`
- `locator with mismatched text falls through to text-match`
- Update the existing duplicate-heading test to assert the locator pre-pass picks the correct heading even when the cursor would have gotten it right by accident.

**Architecture gates:** lint, vitest, plus a new Playwright unit-level smoke that runs `matchBlocksToCandidates` against the Apple CA fixture (loaded from `tests/golden/apple_ca_source_blocks_subset.json` — a thin slice of real source blocks) and asserts `matched.length === 55, unmatched.length === 0`.

---

## Phase 7 — Frontend Status Gating And Dead-Branch Cleanup

**Goal:** Wire `extraction_needs_review` end-to-end, disable Plan/Review/Export when the gate fails, fix the wrong default panel, and remove phantom status branches.

1. **Status enum** in `apps/web/src/api.ts:62`:
   - Promote `DocumentRecord.status: string` to a `Literal` union: `"failed_extraction" | "extraction_needs_review" | "ready_for_review" | "approved" | "export_ready"`. Drop the phantom ones.
   - Add type guards `isExtractionBlocked(status)`, `isInProgress(status)`.
2. **Tab gating** in `apps/web/src/App.tsx:1470-1499`:
   - Add `disabled` attribute to Plan, Review, Export tab buttons: `disabled={isExtractionBlocked(document.status)}`.
   - Source and Workbench stay enabled; Workbench shows an empty state with the gate reasons surfaced from `source_quality.quality_gate` when the doc is blocked.
   - **Architecture: do not auto-redirect** — if the user clicks a disabled tab, keep them on the current panel.
3. **Default panel fix** in `defaultPanelForDocument` at `App.tsx:1530-1532`:
   - `failed_extraction` and `extraction_needs_review` → default to `"source"`, not `"workbench"`.
   - Update `isTerminalStatus` to drop the `"fail"` substring check; use the explicit set instead.
4. **Status label**: add `"extraction_needs_review" → "Extraction Review Required"` to `mapStatusToStage` and any label tables. Remove the phantom branches (`"extracting"`, `"markdown_normalized"`, etc.) — keep only labels for statuses that are actually written.
5. **Gate-reasons surface** in the Source / Warnings sub-tab: when `source_quality.quality_gate.passed === false`, render a banner above the warnings list with `gate_name`, `severity`, and `blocking_reasons[]`. Reuses the existing Warnings tab — no new component.

**Tests** in `apps/web/src/` Vitest + jsdom:
- `Plan/Review/Export tabs are disabled when status is extraction_needs_review`
- `defaultPanelForDocument returns "source" for extraction_needs_review`
- `gate banner renders blocking reasons`
- Snapshot test for the trimmed `mapStatusToStage` set.

**Architecture gates:** lint, vitest. Add a unit assertion that the `DocumentRecord.status` Literal union is **exhaustively covered** by `mapStatusToStage` (TS exhaustiveness via `assertNever`).

---

## Phase 8 — End-to-End Tests And Runtime Docs

**Goal:** Cover the happy path and the blocked path in real browser tests. Document Pandoc as a runtime requirement.

1. **Playwright tests** in `apps/web/e2e/`:
   - `apple-ca-source-viewer-55-of-55.spec.ts` — login → Documentation Operations → Apple CA → assert toolbar reads `55/55 matched`, no unlocated chip; click a source block → assert chunk row activates; click a chunk row → assert source anchor highlights; keyboard nav (`j`/`k` or arrow keys) still works.
   - `blocked-extraction-document.spec.ts` — seed a document with `extraction_needs_review` (via a test-only API helper or fixture file) → assert Source tab is available, Plan/Review/Export are disabled, no topic plan rendered, gate banner visible.
2. **Pandoc runtime documentation:**
   - Add a `## Runtime requirements` section to `README.md` (or `docs/setup.md`, whichever the project uses) explaining Pandoc must be installed:
     - macOS: `brew install pandoc`
     - Linux/CI: distribution package or `pandoc` binary in the base Docker image.
   - Update `infrastructure/docker/*.Dockerfile` for the extraction-service image to install Pandoc.
   - Add an **extraction-service startup diagnostic**: at process boot, call `PandocRuntime.detect()` and log the version. If unavailable, log a `WARN` with the exact `brew install pandoc` hint. Do not fail boot — fail per-extraction.
3. **Stale doc reconciliation** (the user asked me to surface these):
   - ADR-005 (LLM provider) and ADR-014/015 mention extraction outputs — verify no claims contradict the new gate. Update wording if any.
   - `contracts/openapi/extraction-service.yaml` — add `quality_gate` to the response schema.
   - `contracts/openapi/api-gateway.yaml` — add `extraction_needs_review` to status enum; add `source_quality.quality_gate` to document response.
   - `docs/architecture.md` (if it exists) — note the gate boundary between extraction-service and analysis-service.
   - Any `docs/product/*.md` claiming extraction is "lossless" or "complete" needs a hedge.

**Tests:**
- The two Playwright specs above. Run headed for first verification.
- A docs lint that fails CI when `extraction_needs_review` is referenced in code but absent from the OpenAPI status enum (simple grep-based check).

**Architecture gates:** four backend + frontend, plus `npm --prefix apps/web run test:e2e` and a headed Playwright run for final visual QA.

---

## Phase 9 — Final Verification And Golden Reconciliation

**Goal:** Lock the new state. Acknowledge and reconcile any natural shifts in downstream goldens caused by better extraction.

1. **Re-run determinism**: extract Apple CA twice in two fresh temp directories, SHA256-compare `source-blocks.jsonl`, `structure-tree.json`, `content.md`, `extraction-quality.json`. **All four must match.**
2. **Topic-plan golden** at `tests/golden/apple_ca_topic_plan.json`:
   - Re-run end-to-end (upload → extraction → analysis) on Apple CA.
   - If the topic plan changed: this is acceptable per the user's feedback ("naturally caused by better extraction input"). Regenerate the golden **once**, with the diff inspected by hand and noted in the commit message. Do not regenerate iteratively.
3. **Run all gates:**
   - `uv run ruff check --fix .`
   - `uv run mypy .`
   - `uv run pytest -x`
   - `npm --prefix apps/web run lint`
   - `npm --prefix apps/web run test`
   - `npm --prefix apps/web run build`
   - `npm --prefix apps/web run test:e2e`
4. **Manual visual QA**: open the app, navigate Apple CA, confirm 55/55 matched, click round-trip works, open a synthetic blocked document, confirm Plan/Review/Export disabled.
5. **Final commit log**: one commit per phase. Use the existing Apple CA invariant test file as the proof-of-life for backend changes; use Playwright specs for frontend.

**Architecture gates:** all four standard, plus the determinism invariant, plus a manual sign-off on the topic-plan golden diff.

---

## Verification (End-To-End)

After all phases land, validate manually with this sequence:

1. `uv run ruff check . && uv run mypy . && uv run pytest -x` — all green.
2. `npm --prefix apps/web run lint && npm --prefix apps/web run test && npm --prefix apps/web run build` — all green.
3. `npm --prefix apps/web run test:e2e` — both `apple-ca-source-viewer-55-of-55.spec.ts` and `blocked-extraction-document.spec.ts` pass.
4. Headed Playwright run for visual confirmation.
5. Two-run determinism check via the diagnostic script from Phase 0 (now repurposed as a CI smoke).

## Open Questions Not Answered By The Feedback Doc

These are decisions I made by reading the feedback and the code. Flag if any is wrong:

1. **Anchor preservation via AST round-trip with `panflute`**, not via post-process character-offset patching. AST is more robust; this is the intent behind `panflute` being in the feedback's dependency list.
2. **Locator format** is exactly `docx:p:{N}` and `docx:tbl:{N}:r:{M}` per the feedback example. Stored on `source_location.section` (existing schema field, nullable string — no schema bump).
3. **Pandoc-availability is per-extraction, not per-boot.** Boot logs a warning; per-extraction fails with the typed error. This matches the feedback's "Add a startup or extraction-time diagnostic that reports missing Pandoc clearly."
4. **`extraction_needs_review` is a distinct status from `failed_extraction`.** Failed = extraction crashed. Needs-review = extraction completed but the gate did not pass. Both block analysis; both keep Source inspectable; only Failed is terminal in the UI.
5. **Topic-plan golden may shift once** when Pandoc lands. Acceptable per feedback. Diff reviewed by hand, regenerated once with `--update-golden`.

If any of these is wrong, fix the plan before Phase 1.
