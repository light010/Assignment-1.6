# Backend Root-Cause Plan: Topic-Planning, Edit Algebra, and Service Boundaries

## Context

The user's previous critique reframed the workbench redesign around four backend root causes:
1. The "topic-planning model" (`fixture-deterministic`) is a deterministic Python stub, not a real LLM.
2. The edit API supports only raw-XML topic PATCH — there is no block-level merge/split/move/retype/rename.
3. Traceability decays after the first edit because there is no typed edit-op log to replay.
4. Live DITA validation, confidence-driven triage, and Apple CA invariant tests are missing.

Investigation surfaced a deeper issue under all four: **the architecture has drifted away from its own ADRs**. `review-service`, `analysis-service`, `llm-gateway-service`, and `validation-service` are all 3-line empty FastAPI skeletons (only `/health/live`, `/health/ready`, `/metrics`). Their responsibilities are absorbed into `upload-service`. Fixing this drift is the actual root-cause backend repair — it's the precondition that makes every item above implementable correctly. The user has approved full ADR-aligned migration.

One assertion in the original plan critique is wrong and must be retired: DOCX body-order traversal is **already implemented** at `extractors.py:503` (`_docx_body_items` walks `document.element.body.iterchildren()`) and is locked by `test_week3_extraction.py:161`. We will NOT "fix" this — we will instead extend the test to lock the invariant under more documents.

### Scope (locked with user)

In scope:
- LLM gateway: contract + dispatch surface (Phase 4) **and** real provider integration (Phase 8).
- Edit-op algebra + Pydantic block model + character-offset traceability (Phases 2–3, 6).
- Confidence-driven triage + live DITA validation + Apple CA invariant tests (Phases 5, 7, 9).
- Full ADR-004 migration: stand up `analysis-service`, `review-service`, `validation-service`; demote `upload-service` to upload-only.

Not in scope (explicitly deferred):
- Frontend Workbench panel work (untracked `apps/web/src/WorkbenchPanel.tsx` continues independently; backend lands contracts-first so it doesn't drift).
- Replacing JsonStore with PostgreSQL/S3 (ADR-004 long-term goal). The plan rides on existing `JsonStore` and `write_artifact` primitives.
- MCP gateway / Agent Runtime work (separate ADR-005 surface).

---

## Reality reconciliation — claims vs. code

| Claim in prior plans / critique | Code reality | Action |
|---|---|---|
| "DOCX tables append after paragraphs (extractors.py:82)" | False. `_docx_body_items` (extractors.py:498) walks `body.iterchildren()` correctly; tested at `test_week3_extraction.py:161-168` | **Drop the fix; harden the test instead** |
| "fixture-deterministic is a stub" | True. Zero LLM SDK imports anywhere; `model_name` is echoed into `llm_metadata.model` only (`pipeline.py:445-452, 580-586`) | Phase 4 + 8 |
| "Edit API is read-heavy / XML-only PATCH" | True. `upload-service/main.py:1077` (`patch_topic`) accepts `TopicPatchRequest{xml: str}` — no structural ops | Phase 6 |
| "review_flags exist on every block" | True but always `[]` (extractors.py:634) — dead surface | Phase 5 |
| "Confidence carries real signal" | False. Hardcoded `0.9`/`0.82` constants (extractors.py:595) | Phase 5 |
| "LLM Gateway exists" | False. `llm-gateway-service` is an empty stub | Phase 4 + 8 |
| "Review-service owns edit metadata" (ADR-004:241) | False. Owned accidentally by upload-service | Phase 6 |
| "Validation surfaces in workflow" | Partially. `validate_dita_files` runs once inline at `patch_topic` (upload-service:1086) | Phase 7 |
| "Apple CA fixture is in tests" | False. File exists at `DATA/dita_source_docs/DOC/Apple CA (PSC).docx` but is unreferenced | Phase 9 |

---

## Inventory: stale docs, dead surfaces, boundary leaks, unsafe shortcuts

These are tracked here so they get explicitly addressed (not silently preserved).

### Stale docs (modified in working tree, must be reconciled)
- `architecture.md` — root index, modified
- `DESIGN.md` — frontend design contract, modified
- `adr/006-frontend-api-and-user-workflows.md` — modified, must align with edit-op API
- `docs/product/wk3-extraction-and-source-preview.md` — untracked, asserts claims about extraction we will need to retest
- `contracts/openapi/README.md` — modified; OpenAPI is "machine-generated" but we will hand-edit; reconcile in Phase 11
- `services/markdown-service/README.md` — untracked

### Dead / zombie surfaces
- `services/review-service/app/main.py` — 3-line skeleton (Phase 6 owns)
- `services/analysis-service/app/main.py` — 3-line skeleton (Phase 8 owns)
- `services/llm-gateway-service/app/main.py` — 3-line skeleton (Phase 4 owns)
- `services/validation-service/app/main.py` — 3-line skeleton (Phase 7 owns)
- `services/audit-service/app/main.py` — confirm in Phase 0; either wire or delete
- `services/dita-service/app/main.py` — confirm in Phase 0
- `services/export-service/app/main.py` — confirm in Phase 0
- `services/identity-service/app/main.py` — confirm in Phase 0
- `services/notification-service/app/main.py` — confirm in Phase 0
- `services/api-gateway/app/main.py` (modified) — verify routing for new services
- `regenerate_topic` (upload-service:1114) — returns unchanged topic; will move to llm-gateway in Phase 8 or be deleted as never-implemented
- `regenerate_section` (upload-service:1121) — delegates to regenerate_topic; same fate
- `block.review_flags: []` — populate or remove (Phase 5)
- `block.confidence` constants `0.9`/`0.82` — replace or remove (Phase 5)

### Boundary leaks
- `write_analysis_artifacts` (upload-service:249) does topic-planning, generation, validation, and export-zip building — all of which belong in analysis/dita/validation/export services. The string `"fixture-deterministic"` is hardcoded twice inside it (lines 263, 266). Phase 8 owns.
- `patch_topic` (upload-service:1077) calls `validate_dita_files` directly. Should call validation-service. Phase 7 owns.
- `extractors.py:71` writes a temp file to `/tmp` instead of `$TMPDIR` — sandbox-fragile. Phase 1 fixes.
- `service_clients.SERVICE_APP_PATHS` (line 14) does not list `llm-gateway-service` or any of the new services. Each phase that stands a service up must extend this.

### Unsafe shortcuts to refuse
- ❌ Bypassing the LLM Gateway by calling provider SDKs from any service other than `llm-gateway-service` (would violate ADR-005:34).
- ❌ Letting any model write production DITA XML directly (violates ADR-013:12-29 — "deterministic code from schema-valid generated-topic.json").
- ❌ Mutating extraction snapshot artifacts in place when applying edit ops (violates the snapshot+replay invariant Phase 3 establishes).
- ❌ `--no-verify` on commits, mocking the database in integration tests, deleting tests we don't understand.
- ❌ Adding fields to block dicts via `block.update(extra)` after the Pydantic model lands (Phase 2) — must go through typed setter or model copy.

---

## ADR alignment — design constraints

| ADR | Constraint applied to plan |
|---|---|
| ADR-004 | PostgreSQL + S3 + event bus are long-term targets. We ride existing `JsonStore` + `write_artifact` for now but emit the canonical event-types listed in ADR-004:60 (`topic.review.requested`, `topic.approved`, etc.). Phase 6 adds `topic.edited` to that catalog. |
| ADR-005 | All LLM calls go through `llm-gateway-service`. Provider interface is OpenAI-compatible, typed, with structured-output support. Prompts are versioned. Every call records model + provider + prompt-version + input-hash + output-hash. Phase 4 + 8 implement this. |
| ADR-006 | `PATCH /v1/topics/{topic_id}` stays the public edit endpoint, but its body becomes a tagged-union `EditOperation` instead of `{xml: str}`. Phase 6 + 11 reconcile. |
| ADR-013 | Deterministic extraction → LLM topic-planning → review → LLM refactor → deterministic XML build. The plan keeps deterministic code as the only producer of final DITA XML. |
| ADR-000 | `architecture.md` is a navigation index; ADRs are source of truth. Phase 11 keeps it that way (only updates index entries, no architecture content). |

---

## Critical files (the plan touches these)

Read-mostly map (file → role):
- `services/extraction-service/app/extractors.py` — `_source_block` (580), `_docx_body_items` (503), `_extract_docx_assets` (709). Phase 1 (temp dir), Phase 2 (Pydantic), Phase 5 (confidence/review_flags).
- `services/extraction-service/app/contracts.py` — `ExtractionRequest`/`ExtractionStatus`. Phase 2 imports new shared types.
- `services/upload-service/app/main.py` — `write_analysis_artifacts` (249), `patch_topic` (1077), `regenerate_topic` (1114). Phases 6–8 demolish and migrate.
- `services/review-service/app/main.py` — empty. Phase 6 fills.
- `services/analysis-service/app/main.py` — empty. Phase 8 fills.
- `services/validation-service/app/main.py` — empty. Phase 7 fills.
- `services/llm-gateway-service/app/main.py` — empty. Phases 4 + 8 fill.
- `packages/python/ditagen_common/ditagen_common/pipeline.py` — `build_topic_plan` (335), `build_generated_topic` (456), `validate_dita_files` (604). Phases 4, 7, 8 refactor callers to go via gateway.
- `packages/python/ditagen_common/ditagen_common/store.py` — `JsonStore.audit` (524). Phase 6 rides edit-ops on this.
- `packages/python/ditagen_common/ditagen_common/artifacts.py` — `write_artifact` (versioning + content-hash). Phases 3, 6, 8 use this for ops + snapshots.
- `packages/python/ditagen_common/ditagen_common/service_clients.py` — `SERVICE_APP_PATHS` (14). Every phase that stands up a service extends this.
- `services/api-gateway/app/main.py` — gateway routing; Phase 11 reconciles `/v1/*` paths.
- `contracts/artifacts/source-block.schema.json` — authoritative block schema; Phase 2 derives Pydantic from this.
- `contracts/llm/{topic-plan,generated-topic}.schema.json` — gateway request-output contracts; Phase 4 derives Pydantic.
- `contracts/openapi/api-gateway.yaml` + per-service YAMLs — Phase 11 regenerates.
- `tests/test_week3_extraction.py` (lines 132–174) — extend in Phases 1, 5, 9.
- `tests/test_pipeline.py`, `tests/test_api_gateway.py` — extend in Phase 9.

New files the plan creates:
- `packages/python/ditagen_common/ditagen_common/models/{block,topic,edit_op}.py` — Pydantic models (Phase 2, 3).
- `contracts/edits/edit-operation.schema.json` — JSON schema (Phase 3).
- `services/llm-gateway-service/app/{providers,prompts,registry}.py` — gateway internals (Phase 4, 8).
- `services/review-service/app/{routes,replay,model.py}` — edit-op surface (Phase 6).
- `services/validation-service/app/main.py` — DITA validator (Phase 7).
- `services/analysis-service/app/main.py` — topic-planning runner (Phase 8).
- `tests/conftest.py` — currently absent; created in Phase 0 with shared fixtures (Apple CA loader, fake gateway, JsonStore tmp dir).
- `tests/test_apple_ca_invariants.py` — Phase 9.

---

## Cross-cutting gates (run after every phase)

Locked sequence — no phase declares "done" until all four pass:

```bash
uv run ruff check --fix .
uv run mypy packages/python/ditagen_common services
uv run pytest -x
uv run python scripts/check_architecture_invariants.py   # created in Phase 0
```

The architecture-invariants script (Phase 0) enforces:
1. No service imports another service's `app.*` modules (only `ditagen_common` is shared).
2. `llm-gateway-service` is the only service that imports any LLM SDK (`openai`, `anthropic`, `litellm`, `langchain_*`).
3. `validate_dita_files` is called only from `validation-service` (after Phase 7).
4. `JsonStore.mutate` calls in production code carry an `audit_*` keyword or a corresponding `audit()` call (after Phase 6).
5. New code uses typed Pydantic models, not `dict[str, Any]`, on the block/topic/edit-op surface (after Phase 2/3/6).

If a gate fails, the phase rolls back to the last green commit. No `--no-verify`, no skipped checks. If pytest hangs, that's a real failure, not "the test is flaky" — diagnose.

---

## Phased plan — small steps, gated independently

Each phase ends with the four gates above plus phase-specific verification. Each phase is its own commit (multiple commits allowed within a phase if mid-phase commits are individually green).

### Phase 0 — Baseline and instrumentation (1 day)

**Goal:** establish a known-green baseline; create the architecture-invariant runner; document the existing-but-empty service skeletons.

Steps:
1. Run all four gates on `main` and capture the output as the baseline. Anything red here is pre-existing and gets a tracking note (NOT silently fixed alongside other work).
2. Create `scripts/check_architecture_invariants.py`. Phase 0 ships it with only the first invariant active (no service imports another service); subsequent phases activate the rest.
3. Inventory every empty `services/*/app/main.py` (the audit/dita/export/identity/notification suspects flagged above) — for each, check `service_clients.SERVICE_APP_PATHS` and decide *now* whether each service is in scope (this plan touches review/analysis/validation/llm-gateway only; the rest get a `STATUS: deferred-skeleton` README entry).
4. Create `tests/conftest.py` with three fixtures: `apple_ca_docx_bytes` (loads `DATA/dita_source_docs/DOC/Apple CA (PSC).docx` — fail loudly if missing), `tmp_jsonstore` (per-test isolated state), `service_app_factory` (in-process service loader).

**Verification:** all four gates green; running `pytest tests/conftest.py` discovers fixtures; `Apple CA (PSC).docx` opens successfully via the new fixture.

**Rollback risk:** none. Phase 0 only adds files.

---

### Phase 1 — Lock current correct behavior + clean up boundary leaks (1 day)

**Goal:** turn the prior plan's "fix DOCX body order" item into "lock body-order under more inputs", and fix the `/tmp` boundary leak before any larger refactor lands.

Steps:
1. Move `_extract_docx`'s temp-file write from `/tmp` to `tempfile.TemporaryDirectory()` honoring `$TMPDIR`. Same for any sibling extractors found via `grep -n "/tmp" services/`.
2. Extend `tests/test_week3_extraction.py`'s body-order assertion: instead of one synthetic 2-row table, parametrize over (a) the existing synthetic fixture and (b) a new mid-sized synthetic doc with 3 tables interleaved with paragraphs and a heading inside a table cell.
3. Add an architecture test asserting that `extractors.py` does NOT call `document.paragraphs` for block extraction (only for caption candidates). This is a regression-prevention test — keeps a future refactor from breaking what already works.
4. Reconcile `docs/product/wk3-extraction-and-source-preview.md` claims against code reality. If any sentence claims "paragraphs-then-tables", rewrite it. Mark the doc with current date as last-verified.

**Verification:** all four gates green; the parametrized body-order test is part of the passing set; `grep -rn "/tmp/" services/ | grep -v node_modules` returns only intentional results (e.g., test artifacts).

**Rollback risk:** very low — `tempfile.TemporaryDirectory` is the standard idiom; fixture changes are additive.

---

### Phase 2 — Pydantic block model + character-offset traceability (2 days)

**Goal:** replace the `dict[str, Any]` block model with a Pydantic `Block` derived from `contracts/artifacts/source-block.schema.json`; add precise character-offset fields for highlight-mapping.

Steps:
1. Generate (by hand, reviewed against schema) `packages/python/ditagen_common/ditagen_common/models/block.py`:
   - Mirror every field in `source-block.schema.json` strictly (`additionalProperties: false`).
   - Add new optional fields: `char_start: int | None`, `char_end: int | None`, `parent_block_id: str | None` (for nested table-row→table relationships), `lineage: list[str]` (source block IDs this derived from — empty for original extraction; populated by edit-ops in Phase 6).
   - Update `contracts/artifacts/source-block.schema.json` in lockstep so the schema is canonical (the Python model is derived, not the source of truth).
2. Refactor `_source_block` (extractors.py:580) to construct `Block(...)` and `.model_dump(mode="json")` only at write time. Remove the `block["source_location"]["bbox"] = extra["bbox"]` mutation pattern (line 640) — go through the typed model.
3. For DOCX paragraphs, populate `char_start`/`char_end` as offsets within the paragraph's accumulated text. For PDF, leave them None and lean on existing bbox. (Mammoth-HTML mapping is a frontend-only concern; the backend just provides the offsets.)
4. Add JSON-schema validation test: every block produced by the extraction pipeline validates against `source-block.schema.json`.
5. Wire architecture invariant: `services/extraction-service/app/extractors.py` must not declare new functions returning `dict[str, Any]` for block-shaped data — they return `Block`.

**Verification:** existing extraction tests still pass; schema-validation test passes for synthetic + Apple CA fixtures; `mypy` is strict on the new model module (`disallow_untyped_defs = True` for `ditagen_common.models`).

**Rollback risk:** medium. `block.update(extra)` patterns in extractors must be reviewed individually. Mitigation: ship in two sub-commits — (a) define model + add schema test that current dicts pass, (b) flip producer to model.

---

### Phase 3 — Edit-operation algebra (snapshot + replay model) (2 days)

**Goal:** define typed `EditOperation` (Merge / Split / Move / Retype / Rename) and the snapshot+replay semantics, before any service exposes them. This is the data spine the user's critique asked for.

Steps:
1. Author `contracts/edits/edit-operation.schema.json` — strict JSON schema, oneOf the five op types. Each op carries: `op_id` (ULID), `op_type`, `target_*` (block_id or topic_id), `payload` (op-specific), `actor_id`, `created_at`, `parent_op_id` (for ordered replay), `extraction_snapshot_id` (the immutable artifact_version it was taken against).
2. Author `packages/python/ditagen_common/ditagen_common/models/edit_op.py` — Pydantic discriminated-union mirroring the schema. `Merge.payload`: `block_ids: list[str]`. `Split.payload`: `block_id: str, char_offset: int` (uses Phase 2's char offsets). `Move.payload`: `block_id: str, target_topic_id: str`. `Retype.payload`: `topic_id: str, topic_type: Literal["concept","task","reference","troubleshooting","glossary"]`. `Rename.payload`: `topic_id: str, title: str | None, short_desc: str | None`.
3. Author `packages/python/ditagen_common/ditagen_common/edits/replay.py`: pure function `replay(snapshot: ExtractionSnapshot, ops: list[EditOperation]) -> ProjectedState`. ProjectedState is `(blocks, topics, traceability)` — all Pydantic. Replay is deterministic, total (every op type exhaustively handled — `assert_never`), and never mutates the snapshot. Lineage is computed: a Merge produces a new block whose `lineage = [a, b, c]`.
4. Architecture invariant: snapshot artifacts written by `extraction-service` are never re-written; edits become new artifacts via `write_artifact` with `previous_version_id` pointing at the snapshot. `replay.py` accepts only the read-side artifact loader.
5. Tests:
   - Per-op replay unit tests (apply each op to a tiny synthetic snapshot, assert projected state).
   - Property test: applying then reverse-applying ops in order returns the original snapshot for the subset of ops that are reversible (Merge/Split are inverses; Retype/Rename are not — assert this distinction is documented).
   - Determinism test: same `(snapshot, ops)` pair → byte-identical projected state.

**Verification:** all four gates green; new `tests/test_edit_op_replay.py` passes; schema validates against `contracts/edits/edit-operation.schema.json` examples.

**Rollback risk:** low. Phase 3 is pure additive: no service routes are exposed yet. Only new modules and tests.

---

### Phase 4 — Stand up `llm-gateway-service` with the contract surface (2 days)

**Goal:** stand up the gateway with a typed OpenAI-compatible request/response surface. `fixture-deterministic` becomes a registered "provider" that delegates to the existing rule-based pipeline. No real provider yet (Phase 8). This is the seam — every other service that wants topic-planning or generation goes through it.

Steps:
1. Implement `services/llm-gateway-service/app/main.py` with these routes (per ADR-005:32 + ADR-006):
   - `POST /internal/llm/chat/completions` — OpenAI-compatible body shape.
   - `POST /internal/llm/topic-plan` — typed: input is `{document_id, source_blocks: list[Block], structure_tree, model_name, prompt_version}`; output validates `contracts/llm/topic-plan.schema.json`.
   - `POST /internal/llm/generate-topic` — input `{candidate, source_blocks, model_name, prompt_version}`; output validates `contracts/llm/generated-topic.schema.json`.
   - `GET /internal/llm/providers` — list registered providers and capabilities.
2. Implement `app/providers/__init__.py` with a `Provider` Protocol: `complete_chat(req) -> resp`, `topic_plan(req) -> plan`, `generate_topic(req) -> topic`, `capabilities() -> ProviderCapabilities`.
3. Implement `app/providers/fixture_deterministic.py` — wraps `ditagen_common.pipeline.build_topic_plan` and `build_generated_topic` (no behavior change). Records `model="fixture-deterministic"`, `provider="local-rule-based"`, `prompt_version="v0"`, `input_hash`, `output_hash` per ADR-005:20.
4. Implement `app/registry.py` — `Registry.get(model_name) -> Provider`. Single registered entry: `fixture-deterministic`.
5. Implement `app/prompts.py` — versioned prompt templates. v0 prompts are no-ops (the fixture provider doesn't use them) but the registry mechanism is real.
6. Add to `service_clients.SERVICE_APP_PATHS`.
7. Migrate one caller (smallest one) onto the gateway: change `write_analysis_artifacts` (upload-service:249) to call `llm-gateway-service` for `topic_plan` instead of importing `build_topic_plan` directly. Use `request_service` (the existing async httpx wrapper) — exact pattern.
8. Update OpenAPI spec for the gateway (machine-generate or hand-edit per Phase 11).
9. Activate architecture invariant #2 (only `llm-gateway-service` imports LLM SDKs — currently a no-op since none are imported anywhere; locks the future).
10. Tests:
    - `tests/test_llm_gateway.py`: posts to each route, asserts response validates against the JSON schema.
    - Determinism test: same input → same output (fixture provider is deterministic).
    - Architecture test: grep that `build_topic_plan` and `build_generated_topic` are imported only by `llm-gateway-service` and tests.

**Verification:** all four gates green; new gateway tests pass; existing `test_pipeline.py` still produces the same topic plan (compare hashes).

**Rollback risk:** medium. Migrating the upload-service caller can produce subtle JSON shape diffs. Mitigation: contract test asserts byte-identical artifact output before/after migration on the synthetic fixture and the Apple CA fixture.

---

### Phase 5 — Confidence-driven triage (`review_flags` + computed confidence) (2 days)

**Goal:** make `review_flags: []` and the constant `0.9`/`0.82` confidences carry real signal, then expose a triage queue.

Steps:
1. In `extractors.py:_source_block` (580), replace the constant confidences with computed signals:
   - `extraction.confidence`: based on font-size deviation from page mode, character-count z-score, presence of decoded-as-mojibake characters.
   - `block_type.confidence`: posterior of the rule-based classifier (e.g., heading detector returns probability, not boolean).
   - `heading.confidence`: only set for `block_type == "heading"`; based on style-name match, font weight, font-size rank.
   - `semantic_inline.confidence`: keep for now; document the formula.
2. Populate `review_flags` with structured codes:
   - `LOW_BLOCK_TYPE_CONFIDENCE` — `block_type.confidence < 0.7`.
   - `ORPHAN_TABLE_ROW` — table_row block whose `parent_block_id` table is missing from the same page.
   - `MIXED_HEADING_STYLE` — heading whose style name is one used elsewhere as body.
   - `SUSPECTED_HEADING_FRAGMENT` — short text in heading style that doesn't match heading-shape regex.
   - Document the full enum in `contracts/artifacts/source-block.schema.json` under `review_flags.items.enum`.
3. Add `GET /internal/documents/{id}/triage-queue` to `extraction-service`: returns blocks sorted ascending by min(confidence) with their flags. Returns `Block` shape from Phase 2.
4. Move the corresponding `/v1/documents/{id}/triage-queue` route to `api-gateway` (proxy).
5. Tests:
   - Each flag has a synthetic-block test that asserts it fires.
   - Apple CA fixture test: at least one `LOW_BLOCK_TYPE_CONFIDENCE` flag exists somewhere (not zero); the contacts table has zero `ORPHAN_TABLE_ROW` flags.
   - Snapshot test for the triage queue's top 5 blocks on Apple CA — locks the heuristic.

**Verification:** all four gates green; triage queue returns non-empty for Apple CA; `review_flags: []` no longer hardcoded anywhere (grep proves it).

**Rollback risk:** low-medium. Computed confidences may shift existing test snapshots — must update them as part of this phase.

---

### Phase 6 — Stand up `review-service` with edit-op surface (3 days)

**Goal:** ADR-004 says `review-service` owns review state, edit metadata. Stand it up. Move all topic-edit routes off `upload-service`. Edit-ops persist via `JsonStore.audit()` (existing primitive, no parallel log).

Steps:
1. Implement `services/review-service/app/main.py` with edit routes per `EditOperation` types from Phase 3:
   - `POST /internal/topics/{topic_id}/ops` — body: `EditOperation`. Validates → appends to `state["audit_events"]` via `JsonStore.audit(action=f"edit.{op_type}", resource_type="topic", resource_id=topic_id, metadata={"op": op.model_dump()})` → triggers replay → returns `ProjectedTopic`.
   - `GET /internal/documents/{id}/ops` — returns ordered op log filtered to `action LIKE 'edit.%'` for that document.
   - `POST /internal/documents/{id}/ops/undo` — appends an inverse op when the head op is reversible (Merge/Split). Retype/Rename undo is a new op with previous values, fetched from the audit log.
2. Replace `patch_topic` (upload-service:1077). Two options, decide on day 1:
   - (a) Delete the route entirely and bump API to v2 (cleaner, breaks contract).
   - (b) Keep `PATCH /v1/topics/{topic_id}` but route to `review-service`, transforming `{xml: str}` into a structural op when possible, else a `RawXmlOverride` op (a sixth op type marked `is_lossy: true` so the workbench can warn). **(b) is the recommended path** — keeps ADR-006 intact while making the structural ops first-class. Add `RawXmlOverride` to the `EditOperation` discriminated union in Phase 3 retroactively (or here as a Phase 6 amendment — note in plan).
3. Move `regenerate_topic` (upload-service:1114) and `regenerate_section` (upload-service:1121) to `review-service` and have them call the LLM gateway (`POST /internal/llm/generate-topic`) — they stop being stubs. If we choose not to make them real here, **delete them** rather than leaving the stub.
4. Move `assign_reviewer`, `approve_topic`, `reject_topic` (upload-service:1126, 1143, 1172) to `review-service` — they fit ADR-004's review-state ownership. Update `api-gateway` proxying.
5. Add `topic.edited` event to ADR-004's catalog (line 60–107) — currently missing. Emit it from `review-service` after every successful op.
6. Activate architecture invariant #4 (every `JsonStore.mutate` for topic state has a paired `audit()` call).
7. Activate architecture invariant: `services/upload-service` no longer contains routes matching `/topics/`. Test enforces this via FastAPI route inspection.
8. Tests:
   - End-to-end edit-op test: extract Apple CA → apply Merge of two contacts-table rows → assert lineage on the merged block → undo → assert original blocks restored.
   - Replay determinism: given the same op log, two cold-starts of the service produce byte-identical projected state.
   - Audit-log immutability: every op produces exactly one audit_events entry with the canonical envelope (ADR-004:109 — event_id, event_type, event_version, occurred_at, etc.).

**Verification:** all four gates green; old `upload-service` topic routes return 404 or are removed; Apple CA edit-op smoke test passes via `api-gateway`.

**Rollback risk:** high — this phase moves routes between services. Mitigation: ship the move and the api-gateway proxy update in the same commit; add a contract test that calls every public `/v1/topics/*` endpoint and asserts 200/expected-shape both before and after.

---

### Phase 7 — Stand up `validation-service` + live per-topic validation (1.5 days)

**Goal:** make validation a first-class workflow citizen. After every edit-op replay, the projected topic is validated; results surface inline.

Steps:
1. Implement `services/validation-service/app/main.py`:
   - `POST /internal/validation/dita-files` — body: `{dita_files: dict[str,str], asset_manifest: dict}`; returns `validation_issues: list[ValidationIssue]`. Internally calls `ditagen_common.pipeline.validate_dita_files` (line 604).
   - `POST /internal/validation/topic` — body: `{topic_id, dita_xml, asset_manifest}`; returns issues for the single topic, runs in <100ms target.
2. Refactor `validate_dita_files` calls:
   - `upload-service.write_analysis_artifacts:270` → moves to `analysis-service` in Phase 8 and calls `validation-service` from there.
   - `upload-service.patch_topic:1086` (already gone in Phase 6 — instead, `review-service`'s op handler calls `validation-service` after replay).
3. Add an `events.published` integration: `dita.validation.completed` event (already in ADR-004:80) emits with `topic_id` and counts of error/warning issues.
4. Activate architecture invariant #3 (`validate_dita_files` callable only from `validation-service`).
5. Tests:
   - Validation roundtrip: malformed DITA → expected issue codes; valid DITA → empty issues.
   - Latency test: single-topic validation completes in under 200 ms on the Apple CA topic set (locks the synchronous-after-edit guarantee).
   - Architecture test asserting no other service imports `validate_dita_files`.

**Verification:** all four gates green; review-service edit-op response now includes `validation_issues` for the affected topic; latency test passes.

**Rollback risk:** medium. Mitigation: keep `validate_dita_files` callable inside `pipeline.py` for transition; only the architecture invariant gates direct imports outside `validation-service`.

---

### Phase 8 — Stand up `analysis-service` + real LLM provider (3–4 days)

**Goal:** move analysis pipeline out of `upload-service` per ADR-004. Wire one real LLM provider through the gateway, keeping `fixture-deterministic` as default and fallback. Confirms ADR-005 end-to-end.

Steps:
1. Implement `services/analysis-service/app/main.py`:
   - `POST /internal/analyses` — body: `{document_id, project_id, source_blocks_artifact_id, structure_tree_artifact_id, model_name}`; orchestrates: call gateway `/topic-plan` → for each candidate call `/generate-topic` → call dita-service (or its skeleton — Phase 8.5 stands it up if needed) for `build_dita_files` → call validation-service → write all artifacts via `write_artifact`.
   - This service replaces `write_analysis_artifacts` in upload-service line 249 entirely. Delete `write_analysis_artifacts` after migration.
2. Add a real provider in `llm-gateway-service`:
   - Pick OpenAI or Anthropic (decide at phase start; OpenAI-compatible per ADR-005:13). Add `app/providers/openai_compat.py` (or anthropic.py).
   - Provider reads credentials from `os.environ` via a typed `Settings` model — never hardcoded. Document the required env var in `services/llm-gateway-service/README.md`.
   - Implement: prompt templating (versioned), structured-output via JSON Schema, retry-with-jitter (3 attempts), per-call cost accounting (`tokens_in`, `tokens_out`, `cost_usd_estimate`).
   - Per ADR-005:24, add a budget gate: per-project monthly token budget read from project state; over-budget calls return `429 over-budget` and emit `agent.guardrail.triggered`.
   - Per ADR-005:48: prompt-injection check on source content before each call. MVP check: regex denylist for known injection patterns + length cap. Document in ADR amendment.
3. Update `analysis-service` to default `model_name="fixture-deterministic"`, but accept `gpt-4o-mini` (or chosen model) as an alternative. Provider fallback configured per ADR-005:62 — if the real provider fails, fall back to fixture and emit a warning.
4. Add `document.analysis.completed` event (already in ADR-004:72) with the analysis result.
5. Tests:
   - Real-provider test gated by `OPENAI_API_KEY` env var (skip cleanly if absent — `pytest.mark.skipif`).
   - Provider-fallback test: real provider stubbed to fail → fixture provider runs → analysis succeeds.
   - Cost accounting: every gateway response includes `cost_usd_estimate`.
   - Output validation: real-provider response that fails schema → repair-retry per ADR-005:59 → if still fails, emit issue.
   - Eval regression: golden Apple CA topic plan from fixture provider → real provider → diff edit-distance recorded as quality signal (ADR-005:79).

**Verification:** all four gates green; analysis pipeline runs end-to-end on Apple CA via `analysis-service`; with `OPENAI_API_KEY` set, the real provider produces a valid topic plan; without it, fixture provider runs.

**Rollback risk:** high — this is the biggest delta. Mitigation: ship in three sub-commits — (a) stand up analysis-service with fixture provider only (no behavior change), (b) add real-provider adapter behind a flag, (c) flip default fallback chain. Each sub-commit must be independently green.

---

### Phase 9 — Apple CA invariant tests + golden fixtures (1.5 days)

**Goal:** lock document-shape invariants that survive model changes. Replaces brittle "15 topics" assertions.

Steps:
1. Author `tests/test_apple_ca_invariants.py` with these invariants:
   - **CONTACTS_TABLE_IS_ONE_BLOCK**: the contacts/client-summary table is exactly one logical table (one `table_id`); all its rows share that id.
   - **GARNISHMENT_HAS_OWN_TOPIC**: a topic candidate exists whose source includes the "Garnishment" heading and its descendants.
   - **NO_TOPIC_CROSSES_H1**: for every generated topic, all source blocks are descendants of a single H1 in the structure tree.
   - **EVERY_BLOCK_REFERENCED_ONCE**: every non-asset source block appears in exactly one topic's `source_block_ids`.
   - **EXTRACTION_IS_DETERMINISTIC**: extracting Apple CA twice produces byte-identical artifacts.
   - **EDIT_REPLAY_IS_DETERMINISTIC**: applying a fixed sequence of 5 edit ops (Merge two contact rows, Split a long paragraph, Retype a section to "task", Rename a topic, Move a block to another topic) produces a byte-identical projected state across two runs.
2. Author a smoke test for the full pipeline through `api-gateway`: upload Apple CA → poll until extraction + analysis complete → fetch triage queue → apply one Merge op → fetch validation issues → assert the topic has zero new validation issues.
3. Lock the model-output golden file: run the fixture provider on Apple CA, write `tests/golden/apple_ca_topic_plan.json`. Diff this on every CI run. Updates require a deliberate `--update-golden` flag.

**Verification:** all four gates green; new test file passes; golden file is committed.

**Rollback risk:** low — purely additive tests. The risk is them being too strict and blocking unrelated PRs; mitigation is the `--update-golden` escape hatch with mandatory PR description for changes.

---

### Phase 10 — Demote upload-service + mop up dead surfaces (1 day)

**Goal:** upload-service should only own ingestion (per its name and ADR-004). Confirm it now does, and clean up.

Steps:
1. Confirm `upload-service`'s remaining routes are: upload, document metadata read, job status, source artifacts read, asset retrieval. Anything else either was migrated or gets a tracking issue.
2. Delete (don't comment-out) every route migrated in Phases 6–8.
3. Delete `write_analysis_artifacts` and its imports.
4. Delete `regenerate_topic` and `regenerate_section` if they were not made real in Phase 6.
5. Audit the other empty service skeletons declared "deferred" in Phase 0 — for each, write a one-paragraph README under `services/<name>/README.md` explaining current scope.
6. Remove `architecture_test`-flagged invariants that are now enforced by code (no more belt-and-suspenders).

**Verification:** all four gates green; upload-service line count materially smaller; grep proves no orphan references to deleted symbols.

**Rollback risk:** low. Caught by gate #1 (no service imports another's app modules).

---

### Phase 11 — Documentation, ADR, and OpenAPI reconciliation (1.5 days)

**Goal:** make the docs honest. Address every "stale doc" item from the inventory.

Steps:
1. Regenerate `contracts/openapi/api-gateway.yaml`, `extraction-service.yaml`, plus new specs for review-service, analysis-service, validation-service, llm-gateway-service. Either restore the "machine-generated from FastAPI" note (ADR-006 implies this exists) or commit to hand-authored specs and update the README.
2. Update `architecture.md` index entries (only — keep it a navigation file per ADR-000:10).
3. Update `DESIGN.md` to reference the workbench panel as the design home; reconcile with the in-flight `apps/web/src/WorkbenchPanel.tsx`.
4. Update `adr/006-frontend-api-and-user-workflows.md` to reflect the `EditOperation` PATCH body shape.
5. Author **ADR-014: Edit-Operation Algebra and Snapshot+Replay** documenting Phase 3's design.
6. Author **ADR-015: review-service as edit-metadata owner** documenting the Phase 6 migration.
7. Update ADR-004 to add `topic.edited` and `edit.{op_type}` events to the catalog (lines 60–107 area).
8. Update ADR-005 with the LiteLLM adoption decision (or whatever provider the team picked) — currently it says "MVP should evaluate LiteLLM Proxy" (line 38), reify or rule out.
9. Update or delete `docs/product/wk3-extraction-and-source-preview.md`. If it's a planning document the work superseded, archive it.
10. Last-verified-date stamps on every doc that survives.

**Verification:** `grep -rn "fixture-deterministic"` shows it only inside `llm-gateway-service/app/providers/`; no docs claim DOCX is paragraphs-then-tables; ADR-014 and ADR-015 exist and are linked from `adr/000-index.md`.

**Rollback risk:** none — pure docs.

---

## End-to-end verification (post-Phase 11 acceptance)

The plan is "done" when, in a clean environment:

1. `uv run pytest -x` — all tests green, including `tests/test_apple_ca_invariants.py`.
2. `uv run ruff check .` and `uv run mypy packages services` — clean.
3. `uv run python scripts/check_architecture_invariants.py` — green with all five invariants active.
4. With services running locally (`docker-compose up`), the following sequence succeeds via the API gateway:
   - Upload `Apple CA (PSC).docx`.
   - Poll `GET /v1/documents/{id}/status` until `analysis_complete`.
   - `GET /v1/documents/{id}/triage-queue` returns blocks ordered by ascending min(confidence) with non-empty `review_flags` for at least one block.
   - `POST /v1/topics/{topic_id}/ops` with a `Merge` op succeeds, returns updated projected topic with lineage and zero new validation issues.
   - `POST /v1/documents/{id}/ops/undo` reverses the merge.
   - `GET /v1/documents/{id}/ops` shows both ops in order with full audit envelopes.
   - With `OPENAI_API_KEY` set, re-running analysis with `model_name="gpt-4o-mini"` produces a valid topic plan; without it, the gateway falls back to fixture-deterministic with a warning event.
5. The frontend (`http://127.0.0.1:5173`) loads the workbench panel and renders the new triage queue + edit-op surface (assumes Workbench frontend work landed independently — backend doesn't block on it).

---

## Open questions and risks

1. **Phase 8 provider choice** — OpenAI-compatible (gpt-4o-mini) vs. Anthropic (claude-haiku) vs. local (Ollama)? ADR-005:13 says OpenAI-compatible first. Decide at Phase 8 kickoff. Default recommendation: OpenAI gpt-4o-mini for the contract, with provider abstraction so swap is ~1 day.
2. **Phase 6 path-(a) vs (b)** — break ADR-006's PATCH contract and bump to v2, or keep PATCH and add `RawXmlOverride` as a sixth op? Recommend (b) for compatibility; revisit after the workbench is the dominant client.
3. **JsonStore vs Postgres** — the plan rides on JsonStore. ADR-004 wants Postgres. The audit-events collection grows unbounded under the edit-op pattern. Mitigation note: Phase 9's golden tests pin the JSON shape; a future Postgres migration becomes a mechanical port.
4. **`_extract_docx_assets` uses `zipfile` directly instead of python-docx** — extractors.py:709 unzips `word/media/`. This works but bypasses python-docx's image API. Out of scope for this plan; flag for follow-up.
5. **The other empty service skeletons** (audit, dita, export, identity, notification) — Phase 0 explicitly defers. They will need their own plans; the architecture-invariant runner will warn when a route accidentally lands in upload-service that should have been theirs.
6. **Eval regression on real provider (Phase 8)** — without a labeled gold-standard topic plan for Apple CA, "edit distance" is comparison to the fixture, not to ground truth. Document this as a known limitation; gold-standard labeling is a separate effort.

---

## Time estimate

Conservative total: **~20 working days** (4 weeks for one engineer).
- Phase 0: 1d
- Phase 1: 1d
- Phase 2: 2d
- Phase 3: 2d
- Phase 4: 2d
- Phase 5: 2d
- Phase 6: 3d
- Phase 7: 1.5d
- Phase 8: 3.5d
- Phase 9: 1.5d
- Phase 10: 1d
- Phase 11: 1.5d

Phases 1–3 must happen in order. Phases 4 and 5 can run in parallel after Phase 3. Phase 6 needs 3 + 4. Phase 7 needs 6. Phase 8 needs 4 + 7. Phase 9 needs 6 + 7 + 8. Phase 10 + 11 need everything.

If only one engineer is on this, the sequential path is the listed order. If two engineers can split, Engineer A owns Phases 0/1/2/3/6/9/10 (data spine and review-service) and Engineer B owns Phases 4/5/7/8 (gateway, triage, validation, analysis) — with Phase 3 as a synchronization point.
