# Workbench Extraction Review — Enhanced Implementation Plan

> Generated 2026-05-11. Supersedes the ad-hoc TODO list in chat. Anchored to actual code paths and the 27 feedback reports in `docs/product/workbench-feedback/`. **Status: closed.** All phases verified — see §0b ledger.

---

## 0b. Final Verification Ledger (2026-05-11, post-execution)

Every phase is closed with evidence. The only mutation this session made was deleting the stale `workbench_feedback.md` redirect stub and renaming the Playwright spec to match the current `ExtractionExplorerPane` surface.

| Phase | State | Evidence |
|---|---|---|
| 0 baseline gates | ✅ green | `ruff` all checks; `mypy` 0/76 files; `pytest` 357 passed 2 skipped (2 intentional skips: `test_pandoc_projection_is_deterministic`, `test_llama_real_endpoint_round_trips_topic_plan` — both environment-gated); `vitest` 98/98; `tsc -p apps/web/tsconfig.json` exit=0 |
| A1 schema enrichment | ✅ pre-existing | `source-block.schema.json` `$defs.reviewFlag.x-catalog` covers all 20 codes |
| A2 Python catalog | ✅ pre-existing | `ditagen_common/models/block.py:123` `REVIEW_FLAG_CATALOG`; helper `review_flag_payload` line 247 |
| A3 emission wiring | ✅ pre-existing | `_make_review_flag` in `extractors/heading_classifier.py:10`; 7 emission sites |
| A4 failure reason | ✅ pre-existing | `upload-service/app/main.py:352,475-484` `EXTRACTION_FAILURE_REASONS` enum |
| A5 summary endpoint | ✅ pre-existing | `upload-service/app/main.py:1202` internal route; api-gateway `/v1` proxy line 68 |
| B' frontend residuals | ✅ pre-existing | `labelForBlock` returns `Row N` at line 424; document-root inspector note at line 150; no frontend HEADING_BY_FORMATTING synthesis; `rowMeta` no longer appends locator |
| **C P0 source-sync** | ✅ **live-verified** | Playwright `Customer Change Requests docx:p:35 maps to source highlight` PASSED (3.0s) — real browser, real backend, real document |
| D' banner split | ✅ pre-existing + live-verified | `ExtractionFailedPanel` + `ExtractionNeedsReviewPanel` exported; Playwright `blocked document shows extraction-needs-review panel and disables Workbench` PASSED |
| E' lock tests | ✅ verified | 18 vitest files / 98 tests passed; `attentionSelectorParity.test.ts`, `extractionInspector.test.tsx`, `extractionReviewPanels.test.tsx`, `sourceEvidenceViewerSelection.test.tsx`, `reviewFlagLabels.test.ts` all green |
| F normative guidelines | ✅ verified | All section headings F1–F5 present at `docs/product/workbench-extraction-review-guidelines.md` (Reviewer Preflight, Review Contract, Source Mapping Rules, Finding Evidence Requirements, Review Flag Glossary, Blocked Document Subprocess, Acceptance Test Patterns, Automation Guardrail, Severity And Fix Rubric, False Positives Not To Report, Definition Of Done, Out Of Scope); `tests/test_review_flag_glossary_doc.py` 2/2 pass — schema↔doc parity enforced |
| G automation script | ✅ end-to-end verified | `assertReportContent` at `workbench-line-by-line-review.mjs:661-680` enforces no `[object Object]`, required sections, blocked-status disclosure; `topRepeatedIssues` rollup at line 636; `REPORT_ONLY=1 ONLY_DOC=apple-ca node ...` exit=0 |
| Dead-surface cleanup | ✅ done this session | `workbench_feedback.md` (25-line redirect stub) deleted; glossary lock test still passes post-deletion → confirms zero dependency on the stub |
| Spec rename for surface accuracy | ✅ done this session | `git mv apps/web/e2e/workbench-chunk-explorer.spec.ts workbench-extraction-explorer.spec.ts`; 2 doc references updated (`plans/architecture-hardening.md:191`, this file); Playwright 4/4 pass on renamed spec |

**Playwright spec results** (full E2E against running stack, post-rename):

```
✓ Apple CA Workbench extraction explorer syncs source blocks, source anchors, and keyboard navigation (5.6s)
✓ Customer Change Requests docx:p:35 maps to source highlight (3.0s)        ← P0 canary
✓ ready document does not show match-failure banner (3.8s)
✓ blocked document shows extraction-needs-review panel and disables Workbench (934ms)
4 passed (14.9s)
```

**No remaining open work in this plan scope.** Open follow-ups in the broader task list (#357, #446, #454–469, #482–492, #541, #641–644) belong to unrelated projects or are a separate next-step initiative (the new workbench re-review tasks #641–644 cover regenerating per-doc reports and authoring a Workbench-wide UI/UX enhancement report — see §Next-step pointers).

---

## 0. Reality Reconciliation (added post-approval)

After plan approval, file-level verification revealed that commit `78401dd "Refactor Workbench extraction review flow"` (the most recent commit at planning time) **already shipped substantial portions of Phases A, B, D, and E**. The original Explore-agent map referenced `services/extraction-service/app/extractors.py` as a single file; the codebase has since been refactored into an `extractors/` package (`docx.py`, `pdf.py`, `textual.py`, `common.py`, `heading_classifier.py`, `docx_helpers.py`). The feedback reports dated 2026-05-11 capture the **residual** gaps in an already-modernized codebase, not a from-scratch rebuild.

The plan body §2–§7 originally narrated the design as if every phase still needed building; once the §0b ledger above accumulated the evidence, those sections became redundant and were pruned. Design rationale is preserved in git history (file at commit before the Step "Prune plan body" edit).

---

## 1. Context

The 27 per-document feedback reports captured by `workbench-line-by-line-review.mjs` (one P0, 61 P1, 254 P2 across 1336 line reviews) described an extraction-review UI whose backend data is largely correct but whose presentation, terminology, mapping resilience, and blocked-document handling needed to clear reviewer trust thresholds. The five concrete trust-breakers the plan addressed:

1. The **P0 source-highlight failure** on `Customer Change Requests.docx` block `docx:p:35` — a class of silent mapping failure that must become a first-class, surfaced state rather than a row that "looks fine" until you click it.
2. **Review flags lack a label/severity/explanation/action contract** between backend and frontend (severity was a regex heuristic on the flag code; messages were a `humanize_code` fallback).
3. **Labels and inspector binding** — `labelForBlock()` flattened table cells into the row title (drove 217 findings) and the document-root row's inspector did not bind to its first concrete block.
4. **Blocked-document UX collapsed two distinct states** (`failed_extraction` with zero blocks vs `extraction_needs_review` with gate failures) into one banner.
5. **The guidelines doc** was principles-only and not tied to the automation that produces reports.

Outcome (now realized): a Workbench where a reviewer can validate any document — ready, gated, or failed — in document order, with every visible element earning its place, every review flag carrying an explanation and a next action, and every mapping failure surfacing before the reviewer has to discover it by clicking.

---

## 8. Out of Scope (explicit)

- DITA topic classification, topic-type tuning, generated topic quality.
- Plan / Review / Export tab UX beyond the tab-disablement tooltip.
- Backend extractor logic that already produces correct data (cells, locators, confidence axes, heading provenance).
- Mobile/narrow-viewport pass (deferred — listed in original TODO P3).
- Full keyboard accessibility audit beyond the Phase C Playwright assertions (deferred — listed in original TODO P3).

These remain valid follow-ups but are not part of this plan.

---

## Next-step pointers (not part of this plan)

Tasks #641–#644 in the project tracker (added after this plan was completed) describe a fresh end-to-end workbench review pass that would regenerate the 27 per-document feedback reports against the current code and author a Workbench-wide UI/UX enhancement report. That work uses this plan's artifacts (the automation script, the guidelines doc, the architecture lock tests) as inputs; it is not a re-opening of any phase here.
