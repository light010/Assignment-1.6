# Phase 0 Baseline — captured 2026-05-09

This file documents the gate state at the start of the backend root-cause plan
(`plans/logical-whistling-widget.md`). Each subsequent phase's "gates green"
check measures against this baseline, not zero-failures-from-scratch.

## Gate state on entry

| Gate | Status | Notes |
|---|---|---|
| `uv run ruff check .` | ✅ clean | "All checks passed!" |
| `uv run mypy packages/python/ditagen_common` | ✅ clean | Added in Phase 0. Service-side mypy deferred: each service's `app/main.py` collides on the module name `main` under whole-program scan. Per-service mypy is a Phase-2 add (when typed `ditagen_common.models` exists and is worth gating). |
| `uv run pytest -x` | ❌ **1 known failure** | `tests/test_week2_services.py::test_business_unit_seed_membership_and_crud`. See "Known baseline failure" below. |
| `scripts/check_architecture_invariants.py` | n/a | Created in Phase 0. |

## Known baseline failure

**Test:** `tests/test_week2_services.py::test_business_unit_seed_membership_and_crud`

**Failure:** test expects reviewer-scoped business-unit list `['bu_docs_ops']`,
actual is `['bu_compliance', 'bu_docs_ops', 'bu_product_content']`.

**Root cause:** `services/business-unit-service/app/main.py` is `HEAD`-committed as a
3-line skeleton but is **modified in the working tree to 599 lines** of
in-progress code. The expanded service seeds business units with a permission
scope that conflicts with this test's reviewer-isolation assertion. The test
file itself is unmodified (`git diff HEAD tests/test_week2_services.py` is
empty).

**Decision:** this regression was introduced by uncommitted in-flight work that
predates this plan. It is **not** part of this plan's scope. We do not silently
fix it under the cover of this plan. Two acceptable resolutions, neither of
which is this plan's responsibility:
1. The owner of the uncommitted `business-unit-service` work commits the fix
   (likely: tighten the seeded business-unit visibility for `usr_reviewer`).
2. The owner reverts the working-tree changes to `business-unit-service` until they
   are ready to land cleanly.

**Tracking:** every Phase 1+ pytest gate check must show:
- 1 failed: `test_business_unit_seed_membership_and_crud`
- 0 errors
- All other tests passing

If a phase shows ≠ 1 failure, that phase introduced a new break and must roll
back. If a phase shows 0 failures, somebody resolved the in-flight regression
out-of-band — verify and update this document.

## Service inventory — confirmed empty skeletons

| Service | LOC | Status |
|---|---|---|
| `agent-runtime-service/app/main.py` | 3 | empty skeleton — deferred (out of plan scope) |
| `analysis-service/app/main.py` | 3 | empty skeleton — Phase 8 fills |
| `dita-service/app/main.py` | 3 | empty skeleton — deferred |
| `export-service/app/main.py` | 3 | empty skeleton — deferred |
| `identity-service/app/main.py` | 3 | empty skeleton — deferred |
| `llm-gateway-service/app/main.py` | 3 | empty skeleton — Phases 4 + 8 fill |
| `notification-service/app/main.py` | 3 | empty skeleton — deferred |
| `review-service/app/main.py` | 3 | empty skeleton — Phase 6 fills |
| `validation-service/app/main.py` | 3 | empty skeleton — Phase 7 fills |

| Service | LOC | Status |
|---|---|---|
| `markdown-service/app/main.py` | 14 | thin — out of plan scope |
| `audit-service/app/main.py` | 73 | thin — emits/reads audit events; in-scope as a consumer of Phase 6 events |
| `extraction-service/app/main.py` | 334 | active — Phases 1, 2, 5 modify |
| `business-unit-service/app/main.py` | 599 | active (uncommitted) — see baseline failure |
| `api-gateway/app/main.py` | 750 | active — Phases 5, 6, 11 modify |
| `upload-service/app/main.py` | 1388 | **bloated — boundary leak** — Phases 6, 7, 8, 10 demolish and migrate |

Total active+thin LOC: 3185. After Phase 10 (upload-service demotion),
`upload-service` should drop materially and the analysis/review/validation
services should carry their proper share.
