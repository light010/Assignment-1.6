# Extraction & Structure Quality Gate — Augmented Plan

**Status**: Step A complete on `main` working tree (uncommitted). Steps B–I pending.

**Acceptance**: Apple CA 55/55 located, deterministic artifacts, gate strict on every DOCX in production (not just Apple CA). No DITA topic classifier tuning.

**Persistence rule** (from `~/.claude/.../memory/feedback_findings_must_be_actioned.md`): every Insight/Finding emitted during implementation must be either fixed in-step, folded into this plan, or filed as a task — never left as floating chat history.

---

## Step A — Empty-paragraph rule canonicalization ✅ DONE

### Changes shipped
- `services/extraction-service/app/extractors.py`: added `_DRAWINGML_MAIN_NS`, `_OFFICE_REL_NS`, `_docx_paragraph_image_asset_ids(paragraph, document)`; replaced text-only empty check with `text OR image_asset_ids`; emit `block_type="figure"` for image-only paragraphs; threaded `asset_refs` through `_source_block`.
- `apps/web/src/SourceEvidenceViewer.tsx:collectDocxCandidates`: mirrored canonical rule (`hasText || hasMedia` over `img/svg/object/picture/canvas` descendants).
- `tests/test_extraction_edge_cases.py` (new): 3 tests pin the canonical rule and the figure↔asset-manifest cross-link.

### Gate output
- ruff ✅, mypy on changed surfaces ✅, pytest 178/179 ✅, Apple CA 6/6 ✅, vitest 53/53 ✅, vite build ✅

### Findings discovered while implementing — actioned below
| # | Finding | Persistence target |
|---|---|---|
| A.1 | `_looks_like_heading(text, index)` at `extractors.py:1399-1403` returns True for ANY short text at `index==1`, overriding terminal-punctuation check | → Step D1 (heading inference layer cleanup) |
| A.2 | No downstream consumer renders `block_type="figure"` — markdown projector, topic plan, DITA emitter ignore it | → Step D5 (NEW — see below) |
| A.3 | Test helper `_build_image_only_paragraph_docx` pattern should be shared across D1-D4 edge fixtures | → Step D0 (NEW — see below) |

---

## Step B — Remove broken `table_id` fallback in frontend matcher

### Scope
- `apps/web/src/sourceViewerModel.ts:108-115`: delete the `block.table_id`/`row_index` fallback that does `Number("tbl_001") = 1` and looks up `candidatesByDocxTableRow.get("1:1")` — wrong axis (table-sequence vs body-index).
- Locator-first match remains; text-cursor fallback for legacy/PDF unchanged.

### Acceptance
- Multi-table DOCX fixture: two tables at different body indices match the correct `<tr>` candidates by locator only.
- No regression on Apple CA (single-table happy path).
- `matchType="table-row"` becomes unreachable (the only path that set it); decide whether to keep the enum value or drop it.

### Findings folded in from audit (#617)
- B.1 — **(critical)** `tbl_NNN` → `Number(N)` parse mismatch with body-index. Primary fix scope.
- B.2 — `matchType` enum value `"table-row"` may become dead after fix. Decide: keep for future use OR delete with the fallback.

### Tests to add
- New vitest case: two `<table>` elements at body-index 4 and 9, each with one row; backend blocks with `section: "docx:tbl:4:r:1"` and `"docx:tbl:9:r:1"` map to the right `<tr>` candidates. Same text in both rows to disprove text-cursor matching.

### Adversarial risk
- PDF table rows have `table_id` but no DOCX locator — fallback was only reached via DOCX path so deletion is safe; verify by reading `PdfOriginalViewer` candidate collection.

---

## Step C — Structure-tree parametrize coverage + dead-branch cleanup

### Scope
- `tests/test_structure_tree_repair.py`: add parametrize cases `[1,3,2]`, `[2,3]`, `[1,1,2,1]`, `[3,2,1]`. Pin orphan-H3 `repaired_level_count == 2` (synthesize + skipped-level both count).
- `packages/python/ditagen_common/ditagen_common/pipeline.py`: remove dead `0.62 if synthetic else 0.78` branch in `make_node` (synthetic_block always has `confidence: {"heading": 0.5}` so the fallback never executes).
- **Decision** (from earlier discussion): NOT adding orphan non-heading content to `root_nodes`. Document in pipeline.py why.

### Acceptance
- 8 plan parametrize sequences all green.
- Orphan-H3 test pins exact integer (no `>=`).
- `make_node` has no dead branch.
- Comment on `pipeline.py:302-305` documents the "orphan content stays out of root_nodes" decision with the schema-vs-consumer rationale.

### Findings folded in from audit (#614)
- C.1 — Orphan-H3 test asserts `>= 1` permissively; actual is 2. Pin exactly.
- C.2 — `make_node`'s synthetic-confidence fallback is dead code.
- C.3 — Plan §6 said "orphan content → root_nodes"; reconciled DOWNWARD: schema permits but consumers don't expect; document.
- C.4 — Hardcoded `font_size_rank=1, bold=True, not_repeated_header_footer=True` in `make_node` (`pipeline.py:285-291`) — looks-real-but-isn't. **Decide**: derive from block evidence OR set nullable. Note: schema allows null for these fields.

---

## Step D — Producer edge-case detectors (sub-PRs D0–D5)

### D0 — Shared edge-case fixture toolkit (NEW; folds A.3 + Step C discovery)

**Split into D0a (toolkit creation) and D0b (migrate tests) to keep each PR atomic.**

#### D0a — Create the toolkit
- Move `_build_image_only_paragraph_docx` and `_TINY_PNG` from `tests/test_extraction_edge_cases.py` into `tests/_docx_fixtures.py`.
- Stub DOCX builders (filled in as D1-D4 need them, not all at once): `build_image_only_paragraph_docx` ships in D0a; the rest land in their respective steps' fixture commits.
- Add `build_block_payload(*, block_id, text, block_type, **block_kwargs)` that goes **through Pydantic `Block(...)` → `.model_dump(mode="json")`**, so drift between helper and producer is impossible: the helper IS the model.
- Add `tests/test_docx_fixtures.py`: asserts the helper produces a Block-valid payload for every `block_type` Literal value, and that `Block.model_validate(payload)` round-trips.
- Update `tests/test_extraction_edge_cases.py` to import the moved helpers.

#### D0b — Migrate existing tests
- `tests/test_llm_gateway.py:_block_payload` → call `build_block_payload`.
- `tests/test_validation_service.py:249` → use `build_block_payload`.
- `tests/test_phase5_triage.py:_block` → refactor to use `build_block_payload`.
- `tests/test_analysis_service.py:51` → use `build_block_payload`.
- Acceptance: no test hand-builds a Block dict outside `_docx_fixtures.py`. Grep should return zero hits for `"block_type": "heading"` outside the toolkit + production code.

#### Why the split
- D0a is a non-invasive add (new file + add import in one existing file). Zero risk to other tests.
- D0b is the riskier migration. Splitting gives a green checkpoint between "toolkit exists" and "tests use it" so any migration regression has a clean rollback point.

### D1 — Heading-in-cell rule (folds A.1, D-audit-issue #3-4)
- `_docx_is_formatting_heading`: add `in_table_cell` argument; if True, return False AND emit `HEADING_IN_CELL` review_flag.
- Threading: producer must mark cell paragraphs as `in_table_cell=True` when walking `cell.paragraphs`.
- **Fold A.1**: also fix `_looks_like_heading(text, index)` to respect terminal punctuation at `index==1` — currently `if index == 1 and len(stripped) <= 90: return True` ignores `.`/`?`/`:`/`;`/`,`. Acceptance: a single-paragraph DOCX ending in period is classified as `paragraph`, not `heading`.
- Acceptance: bold-large paragraph inside `<td>` produces `table_row` block (not heading) with `HEADING_IN_CELL` flag.

### D2 — Hidden text (`<w:vanish>`)
- New `_docx_visible_text(paragraph)` filters runs where `run.font.hidden` is True OR `<w:vanish>` exists in run's `<w:rPr>`.
- If filtered_text != paragraph.text: emit `HIDDEN_TEXT_DROPPED` review_flag on the block.
- Acceptance: DOCX with one `<w:vanish>` run produces a block whose `text` excludes the hidden content; `HIDDEN_TEXT_DROPPED` present.

### D3 — Hyperlinks & inline URLs
- Walk `<w:hyperlink>` children of paragraphs; resolve `r:id` → `relationship.target_ref`.
- For each hyperlink, emit an `InlineRun` with `href` populated; preserve display text.
- Acceptance: DOCX with one external `<w:hyperlink>` produces a block whose `inline_runs[]` has at least one entry with `href` matching the relationship target.

### D4 — Footnotes / endnotes streams
- Walk `word/footnotes.xml` and `word/endnotes.xml` via `document.part.related_parts`.
- Emit `block_type="note"`, `lineage="footnote"` or `"endnote"`, locator `docx:footnote:{id}` or `docx:endnote:{id}`.
- Acceptance: DOCX with one footnote produces an additional `note` block with valid locator; the locator parses via `parse_locator`.

### D5 — Downstream consumers for `block_type="figure"` (NEW; folds A.2)
- `pipeline.build_markdown`: render `figure` blocks as `![](asset_path)` using `asset_refs[0]` and the manifest's `dita_href`.
- `pipeline.build_topic_plan`: include figure blocks in `source_block_ids`; do not exclude them.
- `pipeline._topic_to_xml`: figure blocks should produce `<image>` elements in DITA output (reference body, not heading).
- Acceptance: synthetic DOCX with one image-only paragraph round-trips through to a DITA `<image>` element with the correct asset href; export-zip contains the image bytes under `assets/`.

### Findings folded in from audit (#613, #617)
- D-audit-1 — `format_docx_nested_table_row_locator` defined but dead → owned by Step E.
- D-audit-2 — `format_docx_header_locator`/`footer_locator` defined but dead → owned by Step E (header/footer locator emission).
- D-audit-3 — `MULTI_COLUMN`, `SUBDOC_UNSUPPORTED`, `SMARTART_DROPPED`, `MATH_CONTENT`, `OLE_DROPPED` enums dead → emit detection in D2-D4 sweep when relevant XML elements are found.
- D-audit-4 — `HEADING_BY_FORMATTING` review flag emitted for both `formatting` AND `numbering` style sources (extractors.py:140-145); plan §5 wanted only `formatting`. Either split into `HEADING_BY_NUMBERING` or restrict. **Decision**: restrict to `formatting` only; numbered-heading source already encoded in `style_source` confidence_signals.
- D-audit-5 — Layer order inversion vs plan §5: code runs numbered-text (0.55) BEFORE formatting heuristic (0.60) at `extractors.py:_docx_block_type`. Reorder so higher-confidence layer wins.
- D-audit-6 — DOCX outline-level (`pPr/outlineLvl`) not detected. Plan §5 Layer 2 missing. Add `_docx_outline_level(paragraph)` helper.
- D-audit-7 — Producer iterates `_docx_body_items` twice (threshold + extraction). Cache the iteration; pass through.
- D-audit-8 — `cast(Any, block_type)` at `extractors.py:862` escapes type checker. Root-cause: producer threads `str` not `BlockType` literal. Fix at call sites.
- D-audit-9 — `_looks_like_heading` position-1 short-circuit (also A.1) — fixed in D1.

---

## Step E — Nested-table walk

### Scope
- `services/extraction-service/app/extractors.py`: extend table iteration to recurse into `cell.tables`; emit locator `docx:tbl:{outer}:r:{row}:tbl:{inner}:r:{row}`; emit `NESTED_TABLE` review_flag.
- Bound to ONE level; deeper nesting emits new `DEEP_NESTING_UNSUPPORTED` enum value.
- `contracts/artifacts/source-block.schema.json` + `packages/python/ditagen_common/.../models/block.py`: add `DEEP_NESTING_UNSUPPORTED` to `ReviewFlagCode` enum and Literal.
- `apps/web/src/sourceViewerModel.ts`: route `docx_nested_table_row` locator kind to inner-table candidates.
- `apps/web/src/SourceEvidenceViewer.tsx:collectDocxCandidates`: assign nested-table indices on inner `<table>` elements; ensure they're NOT also picked up as body-level tables.

### Acceptance
- Synthetic DOCX with outer 2×2 + inner 2×1 in cell (0,1) produces 4 outer-row + 1 inner-row blocks with valid locators.
- `parseLocator("docx:tbl:3:r:1:tbl:0:r:0")` resolves to inner `<tr>` in jsdom test.
- Header/footer locators (`format_docx_header_locator`/`footer_locator`) emitted for actual header/footer paragraphs — closes D-audit-2.

### Findings folded in
- E.1 — D-audit-1: nested-table locator dead → primary scope.
- E.2 — D-audit-2: header/footer locators dead → also closed here since both involve walking python-docx's section/header machinery.

---

## Step F — Pandoc projector rewrite

### Scope (full rewrite of `services/extraction-service/app/pandoc_projector.py`)

#### F1. Async subprocess
- Replace `subprocess.run` with `asyncio.create_subprocess_exec`.
- ~~Propagate async to `_project_markdown` and `_assemble_output` (refactor required).~~
- ~~Callers (`extractors.py:_extract_docx` etc.) become async.~~
- **Deviation (Step F implementation):** Sync-wrap `asyncio.run(_run_async(...))` at the projector public boundary instead of propagating async. Rationale: (1) FastAPI route `create_extraction` is sync `def` → already runs on threadpool, so pandoc's 30s subprocess never blocks the event loop. (2) Direct caller surface for `extract_document` is 1 FastAPI route + 1 test file — the async cascade has high test-churn cost and zero runtime benefit. (3) The actual safety items (F2 RLIMIT, F3 stream-cap, F4 correct timeout exception) live in the subprocess shell, not in the async-ness of callers. Re-evaluate full-async propagation when (a) profiling shows event-loop starvation under real load, or (b) other parts of the service migrate to async.

#### F2. Resource limits
- `preexec_fn` applies `RLIMIT_AS=1 GiB`, `RLIMIT_CPU=30 s` on Linux; skipped on macOS with a once-only warning log.

#### F3. Stream-cap output
- Read stdout via async reader; kill subprocess on `>10 MiB` instead of buffer-then-check.

#### F4. Correct timeout exception
- `asyncio.TimeoutError`; caller (`extractors.py:_project_markdown`) updated to catch the right exception class.

#### F5. Reorder detection (NOT fabrication)
- Count Pandoc-emitted top-level chunks. Tables emit one chunk regardless of row count, so the alignment unit is non-table-row source blocks.
- If chunk count != non-table-row source blocks: emit `blocking_reasons=["pandoc_reordered"]`. Do NOT synthesize alignment.
- Delete the current "alignment-by-fabrication" fallback at `pandoc_projector.py:126`.
- **Finding folded in (Step F implementation):** lists have the same N-source-blocks→1-pandoc-chunk problem as tables. The exclusion set must cover `{table_row, running_header, running_footer, note, ordered_list, unordered_list, procedure_step}` — not just `table_row`. Otherwise every document with a numbered/bulleted list would false-positive reorder-detect. Captured as `_ALIGNMENT_EXCLUDED_TYPES` constant in the new projector.

#### F6. mdformat-gfm pinning
- Startup check: `mdformat --help` must mention `gfm`. Else gate fails with new blocking reason `mdformat_plugin_missing`.
- If `mdformat` missing entirely: gate fails with new blocking reason `mdformat_unavailable`. No silent fallback.

#### F7. Add new blocking reasons to schema
- `contracts/artifacts/extraction-quality.schema.json`: add `mdformat_unavailable`, `mdformat_plugin_missing` to `gate.blocking_reasons` enum.

#### F8. Determinism lock
- New test: 3 consecutive Apple CA extractions produce byte-identical `content.md` (excluding `duration_ms`).
- Lock as `test_apple_ca_invariants.py::test_pandoc_projection_is_deterministic`.

### Findings folded in from audit (#615)
- F-audit-all: sync subprocess, no rlimits, post-hoc size check, wrong timeout exception class, silent mdformat fallback, alignment-by-fabrication. All resolved by F1-F8 above.

---

## Step G — Service polish

### G1 — Rate-limit `/reextract` (folds audit #616 gap)
- `services/upload-service/app/main.py:reextract_document`: in-memory `dict[document_id, datetime]`.
- Reject with HTTP 429 + emit `extraction.reextract.throttled` audit event if < 600s since last attempt.
- Document v1 limitation: per-instance only.

### G2 — Preserve original gate failure on override
- `override_document_quality_gate`: when override is applied, push the PRE-OVERRIDE gate object (full snapshot, including `blocking_reasons` and `metrics`) into `override_history[]`, not just `{by, at, reason}`.
- Schema: extend `gateOverride.$def` with optional `prior_gate` field. Additive; no `extraction-quality.schema_version` bump.

### G3 — Schema-valid legacy response
- `get_extraction_quality_artifact` for legacy docs without `extraction-quality.json`: return full artifact shape (`schema_version: 1`, `document_id`, `gate: legacy_pre_gate`, `metrics: {minimal-empty}`, `runtime: {minimal-empty}`).
- New helper `legacy_quality_artifact(document_id: str)`.
- **Finding folded in (Step G implementation):** `gate.name` in the schema was a `const: "docx_source_fidelity_v1"` — meaning the existing `legacy_pre_gate` synthesized gate has been schema-INVALID since it was introduced. Strict client-side validators (including the test-suite's jsonschema check) would have rejected the legacy response. Schema extended to `enum: ["docx_source_fidelity_v1", "legacy_pre_gate"]` so both real and legacy gates round-trip validation. Captured by `test_legacy_quality_artifact_validates_against_schema`.

### G4 — Missing-artifacts blocking reason
- Audit finding: `upload-service/main.py` uses `"asset_unresolved"` as a blocking reason when extraction-quality.json is missing. Misclassification.
- Add new enum value `missing_required_artifacts` to schema; use it in the missing-artifacts synthesis path.

### G5 — `duration_ms` real measurement (folds audit producer #15)
- Wrap `_assemble_output` (or just the Pandoc + structure-tree phases) with `time.perf_counter()`; populate `runtime.duration_ms` in `_extraction_quality`.
- Lock with a test asserting `duration_ms > 0`.

### G6 — Stale `gate_overridden` events bookkeeping
- Audit found `gate_overridden_at` and `gate_overridden_by` set on the document but never read by any consumer (`upload-service/main.py:1095-1096`). Either wire to UI surface OR remove. Decide before close.
- **Decision (Step G implementation):** REMOVED. They were write-only duplicates of `quality_gate.override.at` / `.by` — fields the frontend already reads. Two redundant stores of the same fact always drift, and there was no consumer to wire them to. Architecture-locked by `test_gate_overridden_dead_state_is_no_longer_written` (AST grep guard).

### G2 implementation note
- The plan called for snapshotting prior gate into `override_history[]` only. Implementation extended this: the active `gate.override` ALSO carries its `prior_gate` snapshot, captured AT THE MOMENT THE OVERRIDE IS APPLIED. When a later override displaces it, the entry moves into history with its prior_gate intact. Capturing at push-to-history time would be wrong: the gate has already been transformed by the prior override, so the original blocking_reasons would be unrecoverable. Schema marks `prior_gate` optional so legacy entries (without it) still validate.

---

## Step H — Frontend UI controls

### H0 — API gateway proxy routes (found during Step H implementation)
- **Finding folded in:** `services/api-gateway/app/main.py` does NOT proxy `POST /v1/documents/{id}/reextract`, `POST /v1/documents/{id}/override-gate`, or `GET /v1/documents/{id}/artifacts/extraction-quality.json` — but the corresponding `/internal/...` routes exist in upload-service. H1/H2/H3 are unreachable from the UI until the gateway exposes them. This is a dead-surface issue: the upload-service routes have been shipped but the gateway never grew the proxy hooks, so they've been HTTP-404 to any browser since they were added.
- Fix: extend `proxy_document_route` with the missing POST + the new GET. Reuse the existing `proxy_to_service(...)` pattern.
- Lock with a gateway test that hits each new route and asserts a non-404.

### H1 — Re-extract button
- In `ExtractionReviewBanner`, shown only when `document.user.role ∈ {org_admin, project_admin}`.
- POST to `/internal/documents/{id}/reextract`; handle 429 with toast + `extraction.reextract.throttled` indication.
- Spinner while in-flight; disable after click.

### H2 — Override-gate dialog
- Modal with required `reason` textarea (minLength 5).
- Disable submit until reason valid; prevent double-submit.
- Show confirmation toast on success.

### H3 — Unlocated chips
- Lazy-fetch `/internal/documents/{id}/artifacts/extraction-quality.json` on banner mount.
- Render `metrics.unlocated_source_block_ids` as numbered chips, capped at 20 + "show N more" affordance.

### H4 — Panel-redirect toast
- When `activeTabEnablement[panel]` is false and panel was set explicitly: show toast `"Extraction needs review — resolve before opening {panel}."`
- Closes audit #617 finding: "No toast on panel redirect (silent UX change)."

### Findings folded in from audit (#617)
- H-audit-1 — Defensive ligature replace after NFKC is redundant (`sourceViewerModel.ts:60-63`). Either delete OR add comment "defense-in-depth post-NFKC." Pick one.
- H-audit-2 — `humanizeStatus(reason)` may not handle snake_case blocking_reason codes. Add `blockingReasonLabel(code)` mapper.
- H-audit-3 — `QualityGate` wire type lacks `metrics`/`runtime`. Split into `QualityGateSummary` (current) + `ExtractionQualityArtifact` (full).
- H-audit-4 — `computeTabEnablement` recomputed every render. `useMemo`.
- H-audit-5 — Locator-mismatch dev console.warn when locator matches but candidate text disagrees (debug aid).

---

## Step I — Hygiene & documentation backfill

### I1 — `reviewFlag.code` description backfill
- `source-block.schema.json:426`: add one-line semantic rule for each of the 15 new codes added in this milestone (`HEADING_BY_FORMATTING`, `HEADING_IN_CELL`, `SYNTHETIC_ROOT_HEADING`, `ASSET_REF_UNRESOLVED`, `NESTED_TABLE`, `FLOATING_TABLE`, `POSSIBLY_CALLOUT`, `SUBDOC_UNSUPPORTED`, `MATH_CONTENT`, `HAS_INSERTIONS`, `HAS_DELETIONS`, `SMARTART_DROPPED`, `HIDDEN_TEXT_DROPPED`, `MULTI_COLUMN`, `NO_HEADINGS_FOUND`, plus `DEEP_NESTING_UNSUPPORTED` from Step E).

### I2 — Unify locator regex
- Export `LOCATOR_PATTERN_STRING` from `packages/python/ditagen_common/.../locator.py` as a public constant.
- Add `tests/test_locator_pattern_unified.py` asserting:
  - Python `LOCATOR_PATTERN.pattern == LOCATOR_PATTERN_STRING`
  - TypeScript regex source equals the string (via a runtime read of `apps/web/src/locator.ts`)
  - JSON Schema `source-block.schema.json#section.pattern` equals the same string (modulo escaping).
- Pin PDF page constraint to `[1-9]\d*` everywhere — fix the Python regex currently allowing `pdf:p:0` to match.
- Closes audit #611 (TS formatter incomplete) and #612 (regex drift across 4 sources).

### I3 — `source-line.schema.json` reconciliation
- **Decision**: REMOVE `block_id` from `_source_line`'s `source_location` dict (`extractors.py:790`); `block_id` is already carried at the top level of the source-line.
- Verify `source-line.schema.json` validation against current emit; lock with a test.
- Closes A.3 finding.

### I4 — Pandoc telemetry events
- `extraction-service/main.py`: emit `extraction.pandoc.invoked` on success with `duration_ms` and `stderr_warning_count`.
- Emit `extraction.pandoc.failed` on the failure path with `exit_code` and `stderr_tail`.

### I5 — TS formatter surface completion
- `apps/web/src/locator.ts`: add the 6 missing formatters (`formatDocxNestedTableRowLocator`, `formatDocxHeaderLocator`, `formatDocxFooterLocator`, `formatDocxFootnoteLocator`, `formatDocxEndnoteLocator`, `formatPdfBboxLocator`).
- Locator round-trip test extended to verify all 8 TS formatters match their Python counterparts.

### Findings folded in from audit (#611, #612)
- I-audit-1 — TS formatters incomplete → I5.
- I-audit-2 — Regex drift 4 sources → I2.
- I-audit-3 — PDF page=0 inconsistency → I2.
- I-audit-4 — `:g` float formatting can produce scientific notation rejected by schema → I2 (fix Python format to never produce scientific notation; bound floats to fixed-point).
- I-audit-5 — Section ID validation in `_validate_section_id` is undocumented in regex pattern → I2 (document chosen `[A-Za-z0-9_.-]+` charset).

---

## Risk Register (rolled forward)

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Apple CA invariants regress after Step D | medium | high | Apple CA is text-only — no figures, no hidden text, no tracked changes — Step D detectors are exercised by synthetic fixtures only; Apple CA invariants stay green throughout |
| Pandoc rewrite (F) breaks determinism | medium | high | Lock pre-rewrite `content.md` as golden BEFORE starting F; assert byte-identical for Apple CA in 3 consecutive runs after rewrite |
| docx-preview ↔ python-docx body-paragraph divergence | medium | high | jsdom test after Step A and after Step E: assert backend body-count == frontend bodyIndex count per fixture |
| `make_node` evidence hardcoding (C.4) silently hides regression | low | medium | Step C decision: derive from block.style_summary OR set null; lock with test that nulls match emit |
| Multi-instance reextract rate-limit lost on restart | low | low | Documented v1 limitation in G1; tracked as future Redis-backed throttle |
| Schema cross-field invariants not enforced (#612) | low | medium | Add validation test asserting `passed===true ↔ blocking_reasons==[]`, `located+unlocated==total`, etc. — add to Step I as I6 if discovered |

---

## Out of Scope (Reaffirmed)

- DITA topic classifier tuning (locked golden at `tests/golden/apple_ca_topic_plan.json`).
- PDF locator parity beyond regression coverage (separate milestone `pdf_source_fidelity_v1`).
- HTML locator support (grammar reserves `html_locator` slot).
- pandoc-server persistent daemon.
- LLM-based heading inference.
- Cross-instance rate-limit (single-instance only for v1).
- Idempotency keys on `/reextract` (G1 uses rate-limit; full idempotency deferred).

---

## Verification Discipline (Per-Step)

```
UV_CACHE_DIR=$PWD/.uv-cache uv run ruff check .
UV_CACHE_DIR=$PWD/.uv-cache uv run mypy services/extraction-service/app services/upload-service/app packages/python/ditagen_common
UV_CACHE_DIR=$PWD/.uv-cache uv run pytest tests/test_apple_ca_invariants.py -v
UV_CACHE_DIR=$PWD/.uv-cache uv run pytest tests/test_locator_grammar.py tests/test_structure_tree_repair.py tests/test_extraction_edge_cases.py -v
UV_CACHE_DIR=$PWD/.uv-cache uv run pytest -x
npm --prefix apps/web run test
npm --prefix apps/web run build
```

Each step's report-out must include:
- **Findings actioned** section: every Insight/Finding emitted during the step has a destination (✅ fixed in step / → task #N / → plan §X.Y updated).
- Gate output for each command above.
- Apple CA invariant count (must stay 6/6).

---

## Commit Cadence

- One commit per step (D split into D0-D5; H into H1-H4 as one bundle).
- Commit message format: `Step X: <one-line summary>. Apple CA invariants: 6/6.`
- No commit without explicit user sign-off.
