# DITAgen Alpha

DITAgen converts messy source documents into reviewable DITA topics, maps, validation reports, and export ZIPs. This repository now contains the first runnable alpha scaffold from the architecture plan.

## What Runs Today

- Full local microservice boundary layout in `docker-compose.yml`.
- API Gateway under `/v1` with seeded local auth, service-bound BU/document/artifact routes, topic planning, generated topic JSON, deterministic DITA XML, validation, review actions, and export.
- Project, upload, extraction, analysis, LLM gateway, validation, review, and audit services expose internal APIs behind the gateway while the alpha migrates off the shared JSON metadata store.
- Deferred skeleton services such as identity, notification, export, DITA, and agent runtime remain documented but are not exposed in Compose until they have real non-health APIs.
- React workspace for login, Business Unit Dashboard, BU-scoped document upload, document/job records, artifact registry, source artifacts, topic plans, review/edit/approval, and export.
- Local JSON state and filesystem artifact storage for the alpha; Postgres, Redis, RabbitMQ, and MinIO are wired in Compose for the production path.

## Local Demo

```bash
cp .env.example .env
export DITAGEN_AUTH_SECRET="$(openssl rand -hex 32)"
docker compose up --build
```

Open `http://localhost:5173`.

Seeded users:

- `admin@ditagen.local` / `admin123`
- `reviewer@ditagen.local` / `reviewer123`

API Gateway docs are available at `http://localhost:8000/docs`.

## Test

```bash
uv run pytest
```

## Alpha Scope

The current alpha prioritizes a runnable vertical slice over production completeness. DOCX and PDF extraction use best-effort library paths with text fallback, public LLM calls route through the LLM gateway, and local auth is HMAC-token based while the OIDC adapter remains a later implementation task.
