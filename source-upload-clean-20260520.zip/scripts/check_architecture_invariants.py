"""Architecture invariant checker for the DITAgen backend.

Runs a list of registered invariants over the source tree. Each invariant is
a pure function that takes a repo root and returns a list of violations
(empty list = passing). The runner exits non-zero on any violation.

Phases of the backend root-cause plan
(`plans/logical-whistling-widget.md`) progressively activate invariants.
Phase 0 ships invariant #1 only; phases 4, 6, 7 activate the rest. Each
invariant is registered in INVARIANTS with its phase-of-activation, so
running this script at the end of any phase reports which invariants are
expected to be live.

Usage:
    uv run python scripts/check_architecture_invariants.py
    uv run python scripts/check_architecture_invariants.py --phase 6
"""

from __future__ import annotations

import argparse
import ast
import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SERVICES_DIR = REPO_ROOT / "services"
PACKAGES_DIR = REPO_ROOT / "packages"


@dataclass(frozen=True)
class Violation:
    invariant: str
    file: Path
    line: int
    message: str

    def render(self) -> str:
        rel = self.file.relative_to(REPO_ROOT)
        return f"  {rel}:{self.line}  [{self.invariant}] {self.message}"


@dataclass(frozen=True)
class Invariant:
    name: str
    activates_in_phase: int
    description: str
    check: Callable[[Path], list[Violation]]


def _iter_service_python_files(root: Path) -> Iterable[tuple[str, Path]]:
    """Yield (service_name, file_path) for every .py under services/<name>/."""
    if not (root / "services").is_dir():
        return
    for service_dir in sorted((root / "services").iterdir()):
        if not service_dir.is_dir():
            continue
        for py_file in service_dir.rglob("*.py"):
            yield service_dir.name, py_file


def _parse_imports(file_path: Path) -> list[tuple[int, str]]:
    """Return (line, dotted_name) for every Import / ImportFrom in the file."""
    try:
        tree = ast.parse(file_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return []
    out: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                out.append((node.lineno, alias.name))
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                out.append((node.lineno, node.module))
    return out


# Invariant 1 — Phase 0: services do not import each other's app.* modules.
def _no_cross_service_app_imports(root: Path) -> list[Violation]:
    violations: list[Violation] = []
    service_names = {
        d.name for d in (root / "services").iterdir() if d.is_dir()
    }
    for service_name, py_file in _iter_service_python_files(root):
        for line, module in _parse_imports(py_file):
            for other in service_names:
                if other == service_name:
                    continue
                # An import like `services.upload-service.app.main` would
                # not be a real Python import (hyphens), but if anyone ever
                # uses an underscore-aliased path or an `app` import, catch
                # it. Concretely the leak shape we care about is `from app
                # import X` from another service's vantage point — which
                # would only happen via sys.path hacks. Phase 0 just flags
                # any direct `services.<other>` import.
                if module.startswith(f"services.{other}") or module == other:
                    violations.append(Violation(
                        invariant="no_cross_service_app_imports",
                        file=py_file,
                        line=line,
                        message=(
                            f"{service_name!r} imports {module!r} from another "
                            f"service. Only ditagen_common is shared."
                        ),
                    ))
    return violations


# Invariant 2 — Phase 4: only llm-gateway-service imports LLM SDKs.
def _llm_sdks_only_in_gateway(root: Path) -> list[Violation]:
    sdk_prefixes = ("openai", "anthropic", "litellm", "langchain", "langgraph")
    allowed_service = "llm-gateway-service"
    violations: list[Violation] = []
    for service_name, py_file in _iter_service_python_files(root):
        if service_name == allowed_service:
            continue
        for line, module in _parse_imports(py_file):
            head = module.split(".", 1)[0]
            if head in sdk_prefixes:
                violations.append(Violation(
                    invariant="llm_sdks_only_in_gateway",
                    file=py_file,
                    line=line,
                    message=(
                        f"service {service_name!r} imports LLM SDK {module!r}. "
                        f"All LLM calls must go through {allowed_service!r} per ADR-005."
                    ),
                ))
    return violations


# Invariant 3 — Phase 7: validate_dita_files callable only from validation-service.
# Strengthened in Phase 7 to AST-walk imports + call sites + alias-attribute
# access (mirrors the Phase 4 build_topic_plan invariant). Docstrings and
# comments mentioning the name are NOT violations — only real code paths.
def _validate_dita_files_centralized(root: Path) -> list[Violation]:
    target_symbol = "validate_dita_files"
    pipeline_module_names = {
        "ditagen_common.pipeline",
        "ditagen_common",  # `import ditagen_common; ditagen_common.pipeline.validate_dita_files(...)`
    }
    allowed_service = "validation-service"
    violations: list[Violation] = []
    for service_name, py_file in _iter_service_python_files(root):
        if service_name == allowed_service:
            continue
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue

        pipeline_aliases: set[str] = set()
        for node in ast.walk(tree):
            # 1. Direct symbol import: `from ditagen_common.pipeline import validate_dita_files`
            if isinstance(node, ast.ImportFrom):
                if any(alias.name == target_symbol for alias in node.names):
                    violations.append(
                        Violation(
                            invariant="validate_dita_files_centralized",
                            file=py_file,
                            line=node.lineno,
                            message=(
                                f"{service_name!r} imports {target_symbol!r} from "
                                f"{node.module!r}. Phase 7 reserves it for "
                                f"{allowed_service!r}."
                            ),
                        )
                    )
            # 2. Module import that binds an alias for later attribute access.
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name in pipeline_module_names:
                        bound = alias.asname or alias.name.split(".", 1)[0]
                        pipeline_aliases.add(bound)

        # 3. Attribute access through any pipeline alias:
        #    `pipeline.validate_dita_files(...)` or
        #    `ditagen_common.pipeline.validate_dita_files(...)`.
        if pipeline_aliases:
            for node in ast.walk(tree):
                if not isinstance(node, ast.Attribute):
                    continue
                if node.attr != target_symbol:
                    continue
                receiver = node.value
                while isinstance(receiver, ast.Attribute):
                    receiver = receiver.value
                if isinstance(receiver, ast.Name) and receiver.id in pipeline_aliases:
                    violations.append(
                        Violation(
                            invariant="validate_dita_files_centralized",
                            file=py_file,
                            line=node.lineno,
                            message=(
                                f"{service_name!r} accesses "
                                f"{receiver.id}.…{target_symbol!r}. "
                                f"Phase 7 reserves it for {allowed_service!r}."
                            ),
                        )
                    )

        # 4. getattr-style escape — literal-string form only.
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if not (isinstance(node.func, ast.Name) and node.func.id == "getattr"):
                continue
            if len(node.args) < 2:
                continue
            second = node.args[1]
            if isinstance(second, ast.Constant) and second.value == target_symbol:
                violations.append(
                    Violation(
                        invariant="validate_dita_files_centralized",
                        file=py_file,
                        line=node.lineno,
                        message=(
                            f"{service_name!r} reaches {target_symbol!r} via getattr. "
                            f"Phase 7 reserves it for {allowed_service!r}."
                        ),
                    )
                )
    return violations


# Invariant 4 — Phase 6: every JsonStore.mutate of `topics` has a paired audit().
# Static analysis at this fidelity is best-effort; the deterministic check is
# "any file that contains `state[\"topics\"]` mutation also contains an
# `audit(`/`emit_audit_event(` call". Refined when Phase 6 lands.
def _topic_mutations_are_audited(root: Path) -> list[Violation]:
    violations: list[Violation] = []
    for service_name, py_file in _iter_service_python_files(root):
        try:
            text = py_file.read_text(encoding="utf-8")
        except OSError:
            continue
        mutates_topics = (
            "state[\"topics\"]" in text
            and ".mutate(" in text
        )
        has_audit = (
            ".audit(" in text
            or "emit_audit_event(" in text
        )
        if mutates_topics and not has_audit:
            violations.append(Violation(
                invariant="topic_mutations_are_audited",
                file=py_file,
                line=1,
                message=(
                    f"service {service_name!r} mutates topics state without an "
                    f"audit() / emit_audit_event() call. Phase 6 invariant."
                ),
            ))
    return violations


# Invariant 7 — Phase 4 follow-up: no two services have the same local
# module name (other than main.py / __init__.py). The in-process loader
# pattern adds every service's `app/` to sys.path, so collisions cause
# cross-service module aliasing under pytest. This invariant prevents the
# class of bug the gateway hit during Phase 4.
def _no_duplicate_service_local_module_names(root: Path) -> list[Violation]:
    services_dir = root / "services"
    if not services_dir.is_dir():
        return []

    SHARED_FILE_NAMES = {"main.py", "__init__.py", "conftest.py"}
    # Map module-name -> list of (service_name, file_path) it appears in.
    name_to_services: dict[str, list[tuple[str, Path]]] = {}

    for service_dir in sorted(services_dir.iterdir()):
        if not service_dir.is_dir():
            continue
        app_dir = service_dir / "app"
        if not app_dir.is_dir():
            continue
        for entry in app_dir.iterdir():
            if entry.is_file() and entry.suffix == ".py":
                if entry.name in SHARED_FILE_NAMES:
                    continue
                module_name = entry.stem
            elif entry.is_dir() and (entry / "__init__.py").is_file():
                module_name = entry.name
            else:
                continue
            name_to_services.setdefault(module_name, []).append(
                (service_dir.name, entry)
            )

    violations: list[Violation] = []
    for module_name, owners in name_to_services.items():
        if len(owners) <= 1:
            continue
        services = ", ".join(sorted({s for s, _ in owners}))
        for _, entry in owners:
            violations.append(Violation(
                invariant="no_duplicate_service_local_module_names",
                file=entry,
                line=1,
                message=(
                    f"local module {module_name!r} appears in {services}. "
                    f"Pytest's in-process loader puts every service's app/ on "
                    f"sys.path simultaneously; same-named modules silently "
                    f"alias. Rename one with a service-specific prefix "
                    f"(e.g. gateway_{module_name}, extraction_{module_name})."
                ),
            ))
    return violations


# Invariant 6 — Phase 3: ditagen_common.edits.replay is pure (no IO, no
# FastAPI, no JsonStore). Snapshot artifacts written by extraction-service
# are immutable; replay() returns a new ProjectedState rather than mutating.
def _replay_is_pure(root: Path) -> list[Violation]:
    edits_dir = root / "packages" / "python" / "ditagen_common" / "ditagen_common" / "edits"
    if not edits_dir.is_dir():
        return []  # Phase 3 hasn't run yet — skip silently.
    forbidden_imports = (
        "fastapi",
        "httpx",
        "ditagen_common.store",
        "ditagen_common.artifacts",
        "ditagen_common.service_clients",
    )
    violations: list[Violation] = []
    for py_file in edits_dir.rglob("*.py"):
        for line, module in _parse_imports(py_file):
            for forbidden in forbidden_imports:
                if module == forbidden or module.startswith(forbidden + "."):
                    violations.append(Violation(
                        invariant="replay_is_pure",
                        file=py_file,
                        line=line,
                        message=(
                            f"forbidden import {module!r} in ditagen_common.edits — "
                            f"replay() must be pure (no IO, no FastAPI, no JsonStore). "
                            f"Phase 3 invariant: snapshot+replay is a pure function."
                        ),
                    ))
    return violations


# Invariant 9 — Phase 6: upload-service no longer owns POST /internal/topics/
# routes. Per ADR-004 the topic-mutation surface lives on review-service;
# upload only retains GET reads + the legacy PATCH delegating proxy.
def _upload_service_owns_no_topic_post_routes(root: Path) -> list[Violation]:
    upload_main = root / "services" / "upload-service" / "app" / "main.py"
    if not upload_main.is_file():
        return []
    try:
        tree = ast.parse(upload_main.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return []

    violations: list[Violation] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            continue
        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue
            method = getattr(decorator.func, "attr", None)
            if method != "post":
                continue
            if not decorator.args:
                continue
            path_node = decorator.args[0]
            if not isinstance(path_node, ast.Constant) or not isinstance(path_node.value, str):
                continue
            path = path_node.value
            # Allow non-topic POST routes; block any /internal/topics/<id>/...
            if path.startswith("/internal/topics/{"):
                violations.append(
                    Violation(
                        invariant="upload_service_owns_no_topic_post_routes",
                        file=upload_main,
                        line=decorator.lineno,
                        message=(
                            f"upload-service exposes POST {path!r} on function "
                            f"{node.name!r}. Phase 6 moved topic-mutation routes to "
                            f"review-service per ADR-004. Move this route or delete "
                            f"if it is dead surface."
                        ),
                    )
                )
    return violations


def _api_gateway_llm_calls_proxy_only(root: Path) -> list[Violation]:
    gateway_main = root / "services" / "api-gateway" / "app" / "main.py"
    if not gateway_main.is_file():
        return []
    text = gateway_main.read_text(encoding="utf-8")
    forbidden_markers = ("OPENAI_API_KEY", "OPENAI_BASE_URL", "api.openai.com")
    violations = [
        Violation(
            invariant="api_gateway_llm_calls_proxy_only",
            file=gateway_main,
            line=1,
            message=(
                "api-gateway contains direct provider configuration. "
                "Public /v1/llm routes must proxy to llm-gateway-service."
            ),
        )
        for marker in forbidden_markers
        if marker in text
    ]
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return violations
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr == "AsyncClient":
            receiver = func.value
            if isinstance(receiver, ast.Name) and receiver.id == "httpx":
                violations.append(
                    Violation(
                        invariant="api_gateway_llm_calls_proxy_only",
                        file=gateway_main,
                        line=node.lineno,
                        message=(
                            "api-gateway opens an httpx.AsyncClient directly. "
                            "Use ditagen_common.service_clients.request_service "
                            "for service boundaries."
                        ),
                    )
                )
    return violations


def _compose_has_no_runtime_skeleton_services(root: Path) -> list[Violation]:
    compose_path = root / "docker-compose.yml"
    if not compose_path.is_file():
        return []
    text = compose_path.read_text(encoding="utf-8")
    skeletons = {
        "identity-service",
        "notification-service",
        "export-service",
        "dita-service",
        "agent-runtime-service",
    }
    violations: list[Violation] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if stripped.endswith(":") and stripped[:-1] in skeletons:
            violations.append(
                Violation(
                    invariant="compose_has_no_runtime_skeleton_services",
                    file=compose_path,
                    line=line_number,
                    message=(
                        f"{stripped[:-1]!r} is exposed in docker-compose.yml "
                        "but has no production API surface. Keep deferred "
                        "skeletons documented, not running."
                    ),
                )
            )
    return violations


def _no_unstructured_prints_in_production_code(root: Path) -> list[Violation]:
    violations: list[Violation] = []
    for base in (root / "services", root / "packages"):
        if not base.is_dir():
            continue
        for py_file in base.rglob("*.py"):
            try:
                tree = ast.parse(py_file.read_text(encoding="utf-8"))
            except (OSError, SyntaxError):
                continue
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                if isinstance(node.func, ast.Name) and node.func.id == "print":
                    violations.append(
                        Violation(
                            invariant="no_unstructured_prints_in_production_code",
                            file=py_file,
                            line=node.lineno,
                            message=(
                                "production code uses print(); use the configured "
                                "JSON logger instead."
                            ),
                        )
                    )
    return violations


def _services_use_store_factory(root: Path) -> list[Violation]:
    violations: list[Violation] = []
    for service_name, py_file in _iter_service_python_files(root):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == "ditagen_common.store":
                names = {alias.name for alias in node.names}
                if "JsonStore" in names:
                    violations.append(
                        Violation(
                            invariant="services_use_store_factory",
                            file=py_file,
                            line=node.lineno,
                            message=(
                                f"{service_name!r} imports JsonStore directly. "
                                "Services must use create_store(service_name) so "
                                "PostgreSQL-backed storage is selected in deployment."
                            ),
                        )
                    )
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id == "JsonStore":
                    violations.append(
                        Violation(
                            invariant="services_use_store_factory",
                            file=py_file,
                            line=node.lineno,
                            message=(
                                f"{service_name!r} constructs JsonStore directly. "
                                "Use create_store(service_name)."
                            ),
                        )
                    )
    return violations


# Invariant 8 — Phase 5: extractors.common._assemble_output must call
# _compute_review_signals so every extracted block carries computed
# confidence + review_flags. If the call ever vanishes, every block ships
# with the 0.5 placeholder, the triage queue collapses to garbage, and
# the workbench loses its triage signal silently. Better to fail the gate.
def _confidence_post_processor_runs(root: Path) -> list[Violation]:
    extractors_path = (
        root / "services" / "extraction-service" / "app" / "extractors" / "common.py"
    )
    if not extractors_path.is_file():
        return []
    try:
        tree = ast.parse(extractors_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return []

    target_callee = "_compute_review_signals"
    target_caller = "_assemble_output"
    found_call_inside_caller = False
    caller_node: ast.FunctionDef | ast.AsyncFunctionDef | None = None

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            if node.name == target_caller:
                caller_node = node
                break

    if caller_node is None:
        return [
            Violation(
                invariant="confidence_post_processor_runs",
                file=extractors_path,
                line=1,
                message=(
                    f"function {target_caller!r} not found in extractors/common.py — "
                    f"Phase 5 invariant assumes the canonical assembly seam."
                ),
            )
        ]

    for node in ast.walk(caller_node):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id == target_callee:
                found_call_inside_caller = True
                break

    if not found_call_inside_caller:
        return [
            Violation(
                invariant="confidence_post_processor_runs",
                file=extractors_path,
                line=caller_node.lineno,
                message=(
                    f"{target_caller!r} no longer calls {target_callee!r}. "
                    f"Without it every block ships with placeholder 0.5 "
                    f"confidence and review_flags=[]; triage collapses."
                ),
            )
        ]
    return []


def _extractor_modules_are_split(root: Path) -> list[Violation]:
    extractors_dir = root / "services" / "extraction-service" / "app" / "extractors"
    if not extractors_dir.is_dir():
        return []
    violations: list[Violation] = []
    legacy_path = extractors_dir / "_legacy.py"
    if legacy_path.exists():
        violations.append(
            Violation(
                invariant="extractor_modules_are_split",
                file=legacy_path,
                line=1,
                message="legacy monolithic extractor file still exists.",
            )
        )
    for py_file in extractors_dir.glob("*.py"):
        if py_file.name == "__init__.py":
            continue
        line_count = len(py_file.read_text(encoding="utf-8").splitlines())
        if line_count > 800:
            violations.append(
                Violation(
                    invariant="extractor_modules_are_split",
                    file=py_file,
                    line=1,
                    message=f"extractor module has {line_count} lines; keep modules <= 800.",
                )
            )
    return violations


def _sync_routes_do_not_block(root: Path) -> list[Violation]:
    route_methods = {"get", "post", "put", "patch", "delete"}
    blocking_names = {"request_service", "run", "Popen", "check_call", "check_output"}
    blocking_modules = {"httpx", "requests", "subprocess"}
    violations: list[Violation] = []
    for _service_name, py_file in _iter_service_python_files(root):
        if py_file.name != "main.py":
            continue
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        imported_blocking: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split(".", 1)[0] in blocking_modules:
                        imported_blocking.add(alias.asname or alias.name.split(".", 1)[0])
            elif isinstance(node, ast.ImportFrom):
                module = (node.module or "").split(".", 1)[0]
                if module in blocking_modules:
                    imported_blocking.update(alias.asname or alias.name for alias in node.names)

        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue
            is_route = False
            for decorator in node.decorator_list:
                call = decorator if isinstance(decorator, ast.Call) else None
                func = call.func if call else decorator
                if isinstance(func, ast.Attribute) and func.attr in route_methods:
                    is_route = True
                    break
            if not is_route:
                continue
            for child in ast.walk(node):
                if not isinstance(child, ast.Call):
                    continue
                func = child.func
                name = ""
                module_name = ""
                if isinstance(func, ast.Name):
                    name = func.id
                    module_name = func.id
                elif isinstance(func, ast.Attribute):
                    name = func.attr
                    value = func.value
                    if isinstance(value, ast.Name):
                        module_name = value.id
                if (
                    name in blocking_names
                    or module_name in imported_blocking
                    or module_name in blocking_modules
                ):
                    violations.append(
                        Violation(
                            invariant="sync_routes_do_not_block",
                            file=py_file,
                            line=child.lineno,
                            message=(
                                f"sync route {node.name!r} calls blocking IO helper "
                                f"{name or module_name!r}; make the route async or move "
                                "blocking work out of the request path."
                            ),
                        )
                    )
                    break
    return violations


# Invariant 5 — Phase 2/3/6: ditagen_common.models functions don't return
# `dict[str, Any]` for block/topic/edit-op shapes.
def _models_module_uses_typed_returns(root: Path) -> list[Violation]:
    models_dir = root / "packages" / "python" / "ditagen_common" / "ditagen_common" / "models"
    if not models_dir.is_dir():
        return []  # Phase 2 hasn't run yet — skip silently.
    violations: list[Violation] = []
    for py_file in models_dir.rglob("*.py"):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                returns = node.returns
                if returns is None:
                    continue
                source = ast.unparse(returns)
                if "dict[str, Any]" in source or "Dict[str, Any]" in source:
                    violations.append(Violation(
                        invariant="models_module_uses_typed_returns",
                        file=py_file,
                        line=node.lineno,
                        message=(
                            f"function {node.name!r} returns dict[str, Any]. "
                            f"ditagen_common.models must use Pydantic models."
                        ),
                    ))
    return violations


INVARIANTS: list[Invariant] = [
    Invariant(
        name="no_cross_service_app_imports",
        activates_in_phase=0,
        description="No service imports another service's app.* modules; only ditagen_common is shared.",
        check=_no_cross_service_app_imports,
    ),
    Invariant(
        name="llm_sdks_only_in_gateway",
        activates_in_phase=4,
        description="Only llm-gateway-service imports LLM SDKs (openai/anthropic/litellm/langchain).",
        check=_llm_sdks_only_in_gateway,
    ),
    Invariant(
        name="validate_dita_files_centralized",
        activates_in_phase=7,
        description="validate_dita_files is referenced only by validation-service.",
        check=_validate_dita_files_centralized,
    ),
    Invariant(
        name="topic_mutations_are_audited",
        activates_in_phase=6,
        description="Any topic-state mutation has a paired audit()/emit_audit_event() call.",
        check=_topic_mutations_are_audited,
    ),
    Invariant(
        name="models_module_uses_typed_returns",
        activates_in_phase=2,
        description="ditagen_common.models functions don't return dict[str, Any] for block/topic shapes.",
        check=_models_module_uses_typed_returns,
    ),
    Invariant(
        name="replay_is_pure",
        activates_in_phase=3,
        description="ditagen_common.edits.replay imports no IO/HTTP/store modules — pure replay function.",
        check=_replay_is_pure,
    ),
    Invariant(
        name="no_duplicate_service_local_module_names",
        activates_in_phase=4,
        description="No two services have a same-named local module under app/ — sys.path collision prevention.",
        check=_no_duplicate_service_local_module_names,
    ),
    Invariant(
        name="confidence_post_processor_runs",
        activates_in_phase=5,
        description="extractors._assemble_output calls _compute_review_signals so every block carries computed confidence + review_flags.",
        check=_confidence_post_processor_runs,
    ),
    Invariant(
        name="extractor_modules_are_split",
        activates_in_phase=0,
        description="extraction-service extractor modules are split and each implementation file stays <= 800 lines.",
        check=_extractor_modules_are_split,
    ),
    Invariant(
        name="sync_routes_do_not_block",
        activates_in_phase=0,
        description="sync FastAPI routes do not call blocking HTTP/subprocess helpers.",
        check=_sync_routes_do_not_block,
    ),
    Invariant(
        name="upload_service_owns_no_topic_post_routes",
        activates_in_phase=6,
        description="upload-service has no POST /internal/topics/{...} routes — review-service owns topic mutations per ADR-004.",
        check=_upload_service_owns_no_topic_post_routes,
    ),
    Invariant(
        name="api_gateway_llm_calls_proxy_only",
        activates_in_phase=0,
        description="api-gateway does not call LLM providers directly; it proxies to llm-gateway-service.",
        check=_api_gateway_llm_calls_proxy_only,
    ),
    Invariant(
        name="compose_has_no_runtime_skeleton_services",
        activates_in_phase=0,
        description="docker-compose does not expose route-less deferred skeleton services.",
        check=_compose_has_no_runtime_skeleton_services,
    ),
    Invariant(
        name="no_unstructured_prints_in_production_code",
        activates_in_phase=0,
        description="services/packages production code uses structured logging instead of print().",
        check=_no_unstructured_prints_in_production_code,
    ),
    Invariant(
        name="services_use_store_factory",
        activates_in_phase=0,
        description="Services use create_store(...) rather than constructing JsonStore directly.",
        check=_services_use_store_factory,
    ),
]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase",
        type=int,
        default=0,
        help=(
            "Phase number. Invariants whose activates_in_phase <= this number "
            "are enforced; later ones are skipped with a notice."
        ),
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run every registered invariant regardless of phase.",
    )
    args = parser.parse_args()

    active: list[Invariant] = []
    deferred: list[Invariant] = []
    for inv in INVARIANTS:
        if args.all or inv.activates_in_phase <= args.phase:
            active.append(inv)
        else:
            deferred.append(inv)

    print(f"Architecture invariant check (phase={args.phase}, all={args.all})")
    print(f"  active:   {len(active)}")
    print(f"  deferred: {len(deferred)}")
    print()

    all_violations: list[Violation] = []
    for inv in active:
        violations = inv.check(REPO_ROOT)
        status = "OK" if not violations else f"FAIL ({len(violations)})"
        print(f"  [{status}] {inv.name} (phase {inv.activates_in_phase}) — {inv.description}")
        all_violations.extend(violations)

    if deferred:
        print()
        print("Deferred invariants (will activate in later phases):")
        for inv in deferred:
            print(f"  [skip] {inv.name} (activates phase {inv.activates_in_phase})")

    if all_violations:
        print()
        print(f"VIOLATIONS ({len(all_violations)}):")
        for v in all_violations:
            print(v.render())
        return 1

    print()
    print("All active invariants pass.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
