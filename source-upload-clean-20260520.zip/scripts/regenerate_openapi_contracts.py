"""Regenerate per-service OpenAPI specs from the live FastAPI apps.

The OpenAPI spec for each service is just `app.openapi()` serialized
to JSON. The committed contract files at `contracts/openapi/*.yaml` are
JSON-formatted (with a `.yaml` extension — valid YAML, no PyYAML
dependency).

Usage:
    uv run python scripts/regenerate_openapi_contracts.py

The script loads each service's `app/main.py` in-process (same loader
pattern used by tests), reads `app.openapi()`, and writes the result
to `contracts/openapi/<service>.yaml`. The order is alphabetical and
deterministic — running twice in a row produces identical files.

Phase 11 (`plans/logical-whistling-widget.md`) made this the canonical
mechanism. Before Phase 11 the contracts were hand-curated and drifted
from the FastAPI routes; Phase 11 closes that gap by making the live
app the source of truth.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = REPO_ROOT / "contracts" / "openapi"

SERVICES = [
    "analysis-service",
    "api-gateway",
    "extraction-service",
    "llm-gateway-service",
    "review-service",
    "validation-service",
]


def _setup_env() -> None:
    """Mirror the test-env env-vars so service-app imports succeed.

    Also injects `packages/python/ditagen_common` onto sys.path so the
    services' `from ditagen_common...` imports resolve without the
    operator setting PYTHONPATH.
    """
    common_pkg = REPO_ROOT / "packages" / "python" / "ditagen_common"
    if str(common_pkg) not in sys.path:
        sys.path.insert(0, str(common_pkg))
    os.environ.setdefault("DITAGEN_DATA_DIR", str(REPO_ROOT / ".ditagen" / "data"))
    os.environ.setdefault("DITAGEN_INPROCESS_SERVICES", "1")
    for service in SERVICES:
        var = f"DITAGEN_{service.replace('-', '_').upper()}_URL"
        os.environ.setdefault(var, f"http://{service}:8000")


def _load_service_app(service: str) -> Any:
    main_path = REPO_ROOT / "services" / service / "app" / "main.py"
    if not main_path.is_file():
        raise FileNotFoundError(f"service main.py not found: {main_path}")
    app_dir = str(main_path.parent)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    module_name = f"openapi_regen_{service.replace('-', '_')}"
    spec = importlib.util.spec_from_file_location(module_name, main_path)
    if not spec or not spec.loader:
        raise RuntimeError(f"could not load {service}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.app


def _write_spec(service: str, app: Any) -> Path:
    schema = app.openapi()
    # Stable ordering for diff-friendly output.
    text = json.dumps(schema, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    output = OUTPUT_DIR / f"{service}.yaml"
    output.write_text(text, encoding="utf-8")
    return output


def main() -> int:
    _setup_env()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    results: list[tuple[str, Path, int]] = []
    for service in SERVICES:
        app = _load_service_app(service)
        path = _write_spec(service, app)
        results.append((service, path, path.stat().st_size))
    print(f"Wrote {len(results)} OpenAPI specs to {OUTPUT_DIR.relative_to(REPO_ROOT)}/")
    for service, path, size in results:
        print(f"  {service:<24} {size:>8} bytes  {path.relative_to(REPO_ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
