"""Backfill audit_events from JSONL + JsonStore → audit-service SQLite.

Phase 4 D2 of `plans/architecture-hardening.md`. After this script runs,
audit-service can drop its JSONL/state.json read paths (Step D2.5) and
eventually delete the JSONL sink entirely (Step D2.7).

This replaces the Phase 1 S6 version of the same script (which moved
state.json events into JSONL). That stop-gap is now part of the migration
path: state.json AND any pre-existing JSONL events are pulled forward
into the typed SQL table in a single pass. Re-running is safe — the
repository is idempotent on `event_id`.

Data sources, in priority order:

  1. `${DITAGEN_DATA_DIR}/audit-events-YYYY-MM-DD.jsonl` (Phase 1 S6 sink)
  2. `${DITAGEN_DATA_DIR}/state.json` → `audit_events[]` (pre-S6 home)

A missing event_id in a legacy record is treated as a hard error — we
never invent ids, since that breaks downstream dedup on a re-run.

Usage:

  uv run python scripts/migrate_audit_events.py            # default DATA_DIR
  DITAGEN_DATA_DIR=/srv/data uv run python scripts/migrate_audit_events.py
  DITAGEN_AUDIT_DATABASE_URL=postgresql://... uv run python scripts/migrate_audit_events.py

Exit codes:
  0 — backfill complete (counts printed)
  1 — input source unreadable or missing required fields
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "audit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


def _data_dir() -> Path:
    return Path(os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")).resolve()


def _load_jsonl_events(directory: Path) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for path in sorted(directory.glob("audit-events-*.jsonl")):
        text = path.read_text(encoding="utf-8")
        for line_no, line in enumerate(text.splitlines(), start=1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                print(
                    f"ERROR: malformed JSONL at {path}:{line_no}: {exc}",
                    file=sys.stderr,
                )
                sys.exit(1)
            events.append(event)
    return events


def _load_state_events(directory: Path) -> list[dict[str, Any]]:
    state_path = directory / "state.json"
    if not state_path.is_file():
        return []
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: state.json is unreadable: {exc}", file=sys.stderr)
        sys.exit(1)
    raw = state.get("audit_events", [])
    return list(raw) if isinstance(raw, list) else []


def _backfill(events: list[dict[str, Any]]) -> tuple[int, int]:
    """Return (inserted, skipped_dup) counts. Idempotent."""
    from repository import AuditEventRepository

    repo = AuditEventRepository()
    inserted = 0
    skipped = 0
    for event in events:
        event_id = event.get("event_id")
        if not event_id:
            print(
                f"ERROR: legacy event missing event_id: {json.dumps(event)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.resolve_seq_for_event_id(event_id)
        repo.append_event(
            event_id=event_id,
            actor_id=event.get("actor_id") or "",
            action=event.get("action") or "",
            resource_type=event.get("resource_type") or "",
            resource_id=event.get("resource_id") or "",
            business_unit_id=event.get("business_unit_id"),
            project_id=event.get("project_id"),
            metadata=event.get("metadata") or {},
            occurred_at=event.get("occurred_at"),
        )
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def main() -> int:
    directory = _data_dir()
    if not directory.is_dir():
        print(f"DITAGEN_DATA_DIR ({directory}) does not exist — nothing to migrate.")
        return 0

    jsonl_events = _load_jsonl_events(directory)
    state_events = _load_state_events(directory)
    print(
        f"Found {len(jsonl_events)} JSONL events + {len(state_events)} "
        f"state.json events in {directory}"
    )

    # State events come first so JSONL (newer) wins on any same-event_id
    # collision through the repo's idempotent append. Belt + braces: the
    # repo dedupes either way, but this preserves the right "latest
    # write" body if metadata fields differ.
    combined = state_events + jsonl_events
    inserted, skipped = _backfill(combined)
    print(f"Inserted {inserted} new rows; skipped {skipped} duplicates (already migrated).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
