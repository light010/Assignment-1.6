"""Backfill upload-service state from JsonStore state.json → SQL.

Phase 4 D4.3 of `plans/architecture-hardening.md`. After this script
runs, upload-service has a complete SQL copy of state.json's 5
upload-service-owned collections. D4.5 then drops JsonStore reads/
writes from upload-service. The repos' upsert methods are idempotent
on natural keys, so this script is safely re-runnable on a partial
run (network hiccup, OOM, etc.).

Data source: `${DITAGEN_DATA_DIR}/state.json`. Collections:

  1. documents{}            — dict[document_id, envelope]
  2. upload_sessions{}      — dict[upload_id, envelope]
  3. jobs{}                 — dict[job_id, envelope]
  4. artifact_registry{}    — dict[artifact_id, envelope]
  5. exports{}              — dict[export_id, envelope]

**Strict-shape policy (no backwards-compatibility coercion)** —
per the D4 no-backcompat invariant, every envelope's required
fields are validated up front and the script fails loud on missing
fields. The earlier D3.4 migration's defensive coercion (e.g.
filling business_unit_id from the parent project) is intentionally
not replicated; DITAgen has no production state.json files binding
to ill-shaped envelopes.

The migration touches upload-service SQL only. The BU service's
`projects` table is *not* a foreign key from `documents.project_id`
(different databases). Upload-service migration is independent of
BU service's D3 migration order.

Usage:

  uv run python scripts/migrate_upload_state.py
  DITAGEN_DATA_DIR=/srv/data uv run python scripts/migrate_upload_state.py
  DITAGEN_UPLOAD_DATABASE_URL=postgresql://... uv run python scripts/migrate_upload_state.py

Exit codes:
  0 — backfill complete (counts printed)
  1 — input source unreadable, malformed, or missing required fields
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "upload-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


_DOCUMENT_REQUIRED = {
    "document_id",
    "tenant_id",
    "business_unit_id",
    "project_id",
    "filename",
    "source_hash",
    "status",
    "created_at",
}
_UPLOAD_SESSION_REQUIRED = {
    "upload_id",
    "tenant_id",
    "organization_id",
    "business_unit_id",
    "project_id",
    "filename",
    "status",
    "created_by",
    "created_at",
}
_JOB_REQUIRED = {
    "job_id",
    "business_unit_id",
    "project_id",
    "document_id",
    "stage",
    "status",
    "created_at",
}
_ARTIFACT_REQUIRED = {
    "artifact_id",
    "project_id",
    "document_id",
    "name",
    "artifact_version",
    "hash",
    "path",
    "producer",
    "created_at",
}
_EXPORT_REQUIRED = {
    "export_id",
    "business_unit_id",
    "project_id",
    "status",
}


def _data_dir() -> Path:
    return Path(os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")).resolve()


def _load_state(directory: Path) -> dict[str, Any]:
    state_path = directory / "state.json"
    if not state_path.is_file():
        print(
            f"state.json not found in {directory} — nothing to migrate.",
            file=sys.stderr,
        )
        return {}
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: state.json is unreadable: {exc}", file=sys.stderr)
        sys.exit(1)
    if not isinstance(state, dict):
        print("ERROR: state.json root must be an object.", file=sys.stderr)
        sys.exit(1)
    return state


def _validate_required(
    *, kind: str, envelope: dict[str, Any], required: set[str]
) -> None:
    """Fail loud on missing required fields. No coercion.

    Per the D4 no-backcompat invariant: legacy envelopes that lack
    required fields are not silently filled in. The operator must fix
    the source state.json before re-running."""
    missing = required - set(envelope.keys())
    if missing:
        print(
            f"ERROR: {kind} envelope missing required fields {sorted(missing)}: "
            f"{json.dumps(envelope)[:200]}",
            file=sys.stderr,
        )
        sys.exit(1)


def _backfill_documents(rows: dict[str, Any]) -> tuple[int, int]:
    from up_repositories import DocumentRepository

    repo = DocumentRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        _validate_required(
            kind="document", envelope=envelope, required=_DOCUMENT_REQUIRED
        )
        before = repo.get(envelope["document_id"])
        repo.upsert(_normalize_document(envelope))
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _normalize_document(envelope: dict[str, Any]) -> dict[str, Any]:
    """Trim the envelope to the columns the typed Document model has.

    JsonStore envelopes may carry extra keys (e.g. workbench-only
    decorations). The typed model is the schema source of truth; any
    column not in the model has no home and must be dropped explicitly.
    """
    columns = {
        "document_id",
        "tenant_id",
        "business_unit_id",
        "project_id",
        "filename",
        "content_type",
        "source_hash",
        "status",
        "extraction_failure_reason",
        "job_ids",
        "topic_ids",
        "original_artifact",
        "manifest",
        "manifest_artifact",
        "artifacts",
        "latest_artifacts",
        "source_quality",
        "extraction",
        "upload_id",
        "topic_plan_approved",
        "created_at",
    }
    normalized = {k: v for k, v in envelope.items() if k in columns}
    # Apply JSON-column defaults so SQLAlchemy's NOT NULL columns get
    # the right empty type rather than raising on insert.
    for json_field in (
        "job_ids",
        "topic_ids",
        "original_artifact",
        "manifest",
        "artifacts",
        "latest_artifacts",
        "source_quality",
        "extraction",
    ):
        if json_field not in normalized:
            normalized[json_field] = [] if json_field.endswith("_ids") else {}
    return normalized


def _backfill_upload_sessions(rows: dict[str, Any]) -> tuple[int, int]:
    from up_repositories import UploadSessionRepository

    repo = UploadSessionRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        _validate_required(
            kind="upload_session", envelope=envelope, required=_UPLOAD_SESSION_REQUIRED
        )
        before = repo.get(envelope["upload_id"])
        repo.upsert(_normalize_upload_session(envelope))
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _normalize_upload_session(envelope: dict[str, Any]) -> dict[str, Any]:
    columns = {
        "upload_id",
        "tenant_id",
        "organization_id",
        "business_unit_id",
        "project_id",
        "filename",
        "content_type",
        "size_bytes",
        "status",
        "parts",
        "received_bytes",
        "document_id",
        "completed_at",
        "created_by",
        "created_at",
    }
    normalized = {k: v for k, v in envelope.items() if k in columns}
    normalized.setdefault("parts", [])
    normalized.setdefault("received_bytes", 0)
    return normalized


def _backfill_jobs(rows: dict[str, Any]) -> tuple[int, int]:
    from up_repositories import JobRepository

    repo = JobRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        _validate_required(kind="job", envelope=envelope, required=_JOB_REQUIRED)
        before = repo.get(envelope["job_id"])
        repo.upsert(_normalize_job(envelope))
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _normalize_job(envelope: dict[str, Any]) -> dict[str, Any]:
    columns = {
        "job_id",
        "business_unit_id",
        "project_id",
        "document_id",
        "stage",
        "status",
        "events",
        "created_at",
    }
    normalized = {k: v for k, v in envelope.items() if k in columns}
    normalized.setdefault("events", [])
    return normalized


def _backfill_artifact_registry(rows: dict[str, Any]) -> tuple[int, int]:
    from up_repositories import ArtifactRegistryRepository

    repo = ArtifactRegistryRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        _validate_required(
            kind="artifact_registry", envelope=envelope, required=_ARTIFACT_REQUIRED
        )
        before = repo.get(envelope["artifact_id"])
        repo.upsert(_normalize_artifact(envelope))
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _normalize_artifact(envelope: dict[str, Any]) -> dict[str, Any]:
    columns = {
        "artifact_id",
        "project_id",
        "document_id",
        "name",
        "artifact_version",
        "version",
        "content_type",
        "size_bytes",
        "hash",
        "sha256",
        "path",
        "producer",
        "created_by",
        "created_at",
        "previous_version_id",
    }
    normalized = {k: v for k, v in envelope.items() if k in columns}
    # `version` defaults to artifact_version; `sha256` defaults to hash;
    # `size_bytes` defaults to 0. These mirror the JsonStore wire
    # shape's tolerance for older artifact rows that only set the
    # primary field — they are reconstruction defaults, not back-
    # compat coercion (the JsonStore writer in ditagen_common.artifacts
    # has always written both keys; this only protects against pre-
    # writer-fix artifacts in legacy state.json files).
    normalized.setdefault("version", normalized["artifact_version"])
    normalized.setdefault("sha256", normalized["hash"])
    normalized.setdefault("size_bytes", 0)
    return normalized


def _backfill_exports(rows: dict[str, Any]) -> tuple[int, int]:
    from up_repositories import ExportRepository

    repo = ExportRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        _validate_required(
            kind="export", envelope=envelope, required=_EXPORT_REQUIRED
        )
        before = repo.get(envelope["export_id"])
        repo.upsert(_normalize_export(envelope))
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _normalize_export(envelope: dict[str, Any]) -> dict[str, Any]:
    columns = {
        "export_id",
        "business_unit_id",
        "project_id",
        "status",
        "topic_count",
        "artifact",
        "logs",
    }
    normalized = {k: v for k, v in envelope.items() if k in columns}
    normalized.setdefault("topic_count", 0)
    normalized.setdefault("artifact", {})
    normalized.setdefault("logs", [])
    return normalized


def main() -> int:
    directory = _data_dir()
    state = _load_state(directory)
    if not state:
        return 0

    documents = state.get("documents", {})
    upload_sessions = state.get("upload_sessions", {})
    jobs = state.get("jobs", {})
    artifacts = state.get("artifact_registry", {})
    exports = state.get("exports", {})

    for kind, rows in (
        ("documents", documents),
        ("upload_sessions", upload_sessions),
        ("jobs", jobs),
        ("artifact_registry", artifacts),
        ("exports", exports),
    ):
        if not isinstance(rows, dict):
            print(
                f"ERROR: state[{kind}] must be a dict; got {type(rows).__name__}.",
                file=sys.stderr,
            )
            return 1

    print(
        f"backfilling upload-service SQL from {directory}/state.json "
        f"({len(documents)} documents, "
        f"{len(upload_sessions)} upload_sessions, "
        f"{len(jobs)} jobs, "
        f"{len(artifacts)} artifact_registry entries, "
        f"{len(exports)} exports)"
    )

    doc_ins, doc_skip = _backfill_documents(documents)
    upl_ins, upl_skip = _backfill_upload_sessions(upload_sessions)
    job_ins, job_skip = _backfill_jobs(jobs)
    art_ins, art_skip = _backfill_artifact_registry(artifacts)
    exp_ins, exp_skip = _backfill_exports(exports)

    print("backfill complete:")
    print(f"  documents:           {doc_ins} inserted, {doc_skip} skipped")
    print(f"  upload_sessions:     {upl_ins} inserted, {upl_skip} skipped")
    print(f"  jobs:                {job_ins} inserted, {job_skip} skipped")
    print(f"  artifact_registry:   {art_ins} inserted, {art_skip} skipped")
    print(f"  exports:             {exp_ins} inserted, {exp_skip} skipped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
