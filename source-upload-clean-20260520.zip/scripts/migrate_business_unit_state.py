"""Backfill business-unit-service state from JsonStore state.json → SQL.

Phase 4 D3.4 of `plans/architecture-hardening.md`. After this script
runs, business-unit-service has a complete SQL copy of state.json's 7
BU-owned collections. D3.5 then drops JsonStore reads/writes from the
BU service. The repos' upsert methods are idempotent on natural keys,
so this script is safely re-runnable on a partial run (network hiccup,
OOM, etc.).

Data source: `${DITAGEN_DATA_DIR}/state.json`. Collections, in
dependency order:

  1. tenants[]                       — list of {tenant_id, name}
  2. organizations[]                 — list of {organization_id, tenant_id, name}
  3. business_units{}                — dict[business_unit_id, envelope]
  4. business_unit_memberships{}     — dict[membership_id, envelope]
  5. business_unit_favorites{}       — dict[favorite_id, envelope]
  6. projects{}                      — dict[project_id, envelope]
  7. project_memberships{}           — dict[membership_id, envelope]

Defensive shape coercion (mirrors Phase 4 D3.3 findings #7 + #8):

  - Pre-D3.3 / upload-service-authored project_membership envelopes
    are missing tenant_id, organization_id, or business_unit_id. The
    SQL columns are nullable, but for D3.5+ consistency we derive the
    missing values from `state["projects"][project_id]` whenever
    possible. If derivation fails (orphan membership pointing at a
    deleted project), we log and write the row with NULLs — never
    invent ids or refuse to migrate.
  - Pre-D3.3 project envelopes may omit `system_managed`; the repo's
    `upsert` defaults the field to None on insert.

Usage:

  uv run python scripts/migrate_business_unit_state.py
  DITAGEN_DATA_DIR=/srv/data uv run python scripts/migrate_business_unit_state.py
  DITAGEN_BUSINESS_UNIT_DATABASE_URL=postgresql://... uv run python scripts/migrate_business_unit_state.py

Exit codes:
  0 — backfill complete (counts printed)
  1 — input source unreadable, malformed, or missing required fields
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


def _data_dir() -> Path:
    return Path(os.getenv("DITAGEN_DATA_DIR", ".ditagen/data")).resolve()


def _load_state(directory: Path) -> dict[str, Any]:
    state_path = directory / "state.json"
    if not state_path.is_file():
        print(
            f"state.json not found in {directory} — nothing to migrate.",
            file=sys.stderr,
        )
        return {}
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: state.json is unreadable: {exc}", file=sys.stderr)
        sys.exit(1)
    if not isinstance(state, dict):
        print("ERROR: state.json root must be an object.", file=sys.stderr)
        sys.exit(1)
    return state


def _backfill_tenants(rows: list[dict[str, Any]]) -> tuple[int, int]:
    from bu_repositories import TenantRepository

    repo = TenantRepository()
    inserted = skipped = 0
    for row in rows:
        tenant_id = row.get("tenant_id")
        name = row.get("name")
        if not tenant_id or not name:
            print(
                f"ERROR: tenant row missing tenant_id or name: {json.dumps(row)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.get(tenant_id)
        repo.upsert(tenant_id=tenant_id, name=name)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _backfill_organizations(rows: list[dict[str, Any]]) -> tuple[int, int]:
    from bu_repositories import OrganizationRepository

    repo = OrganizationRepository()
    inserted = skipped = 0
    for row in rows:
        organization_id = row.get("organization_id")
        tenant_id = row.get("tenant_id")
        name = row.get("name")
        if not organization_id or not tenant_id or not name:
            print(
                f"ERROR: organization row missing required fields: {json.dumps(row)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.get(organization_id)
        repo.upsert(organization_id=organization_id, tenant_id=tenant_id, name=name)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _backfill_business_units(rows: dict[str, Any]) -> tuple[int, int]:
    from bu_repositories import BusinessUnitRepository

    repo = BusinessUnitRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        business_unit_id = envelope.get("business_unit_id")
        if not business_unit_id:
            print(
                f"ERROR: business_unit envelope missing business_unit_id: {json.dumps(envelope)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.get(business_unit_id)
        repo.upsert(envelope)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _backfill_bu_memberships(rows: dict[str, Any]) -> tuple[int, int]:
    from bu_repositories import BusinessUnitMembershipRepository

    repo = BusinessUnitMembershipRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        business_unit_id = envelope.get("business_unit_id")
        user_id = envelope.get("user_id")
        if not business_unit_id or not user_id:
            print(
                f"ERROR: bu_membership envelope missing required fields: {json.dumps(envelope)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.get_role(business_unit_id, user_id)
        repo.upsert(envelope)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _backfill_bu_favorites(rows: dict[str, Any]) -> tuple[int, int]:
    from bu_repositories import BusinessUnitFavoriteRepository

    repo = BusinessUnitFavoriteRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        business_unit_id = envelope.get("business_unit_id")
        user_id = envelope.get("user_id")
        if not business_unit_id or not user_id:
            print(
                f"ERROR: bu_favorite envelope missing required fields: {json.dumps(envelope)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        # No direct "exists?" probe on favorites — check via list_for_user.
        existing = {
            (fav["business_unit_id"], fav["user_id"])
            for fav in repo.list_for_user(user_id)
        }
        repo.upsert(envelope)
        if (business_unit_id, user_id) in existing:
            skipped += 1
        else:
            inserted += 1
    return inserted, skipped


def _backfill_projects(rows: dict[str, Any]) -> tuple[int, int]:
    from bu_repositories import ProjectRepository

    repo = ProjectRepository()
    inserted = skipped = 0
    for envelope in rows.values():
        project_id = envelope.get("project_id")
        if not project_id:
            print(
                f"ERROR: project envelope missing project_id: {json.dumps(envelope)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        before = repo.get(project_id)
        repo.upsert(envelope)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped


def _backfill_project_memberships(
    rows: dict[str, Any], projects: dict[str, Any]
) -> tuple[int, int, int]:
    """Return (inserted, skipped_dup, coerced_count).

    `coerced_count` reports rows where we filled in business_unit_id,
    tenant_id, or organization_id from the project envelope — useful
    signal for spotting upload-service authored memberships (Phase 4
    D3.7 boundary leak)."""
    from bu_repositories import ProjectMembershipRepository

    repo = ProjectMembershipRepository()
    inserted = skipped = coerced = 0
    for envelope in rows.values():
        project_id = envelope.get("project_id")
        user_id = envelope.get("user_id")
        if not project_id or not user_id:
            print(
                f"ERROR: project_membership envelope missing required fields: "
                f"{json.dumps(envelope)[:200]}",
                file=sys.stderr,
            )
            sys.exit(1)
        # Defensive coercion. We mutate a *copy* so we never modify the
        # source state dict in memory.
        envelope_copy = dict(envelope)
        project = projects.get(project_id) or {}
        was_coerced = False
        for field in ("business_unit_id", "tenant_id", "organization_id"):
            if envelope_copy.get(field) is None and project.get(field) is not None:
                envelope_copy[field] = project[field]
                was_coerced = True
        if was_coerced:
            coerced += 1
        before = repo.get_role(project_id, user_id)
        repo.upsert(envelope_copy)
        if before is None:
            inserted += 1
        else:
            skipped += 1
    return inserted, skipped, coerced


def main() -> int:
    directory = _data_dir()
    if not directory.is_dir():
        print(f"DITAGEN_DATA_DIR ({directory}) does not exist — nothing to migrate.")
        return 0
    state = _load_state(directory)
    if not state:
        return 0

    tenants = state.get("tenants", [])
    organizations = state.get("organizations", [])
    business_units = state.get("business_units", {})
    bu_memberships = state.get("business_unit_memberships", {})
    bu_favorites = state.get("business_unit_favorites", {})
    projects = state.get("projects", {})
    project_memberships = state.get("project_memberships", {})

    if not isinstance(tenants, list) or not isinstance(organizations, list):
        print(
            "ERROR: state.tenants and state.organizations must be arrays.",
            file=sys.stderr,
        )
        sys.exit(1)
    for name, value in (
        ("business_units", business_units),
        ("business_unit_memberships", bu_memberships),
        ("business_unit_favorites", bu_favorites),
        ("projects", projects),
        ("project_memberships", project_memberships),
    ):
        if not isinstance(value, dict):
            print(f"ERROR: state.{name} must be an object.", file=sys.stderr)
            sys.exit(1)

    print(
        f"Backfilling BU service SQL from {directory}/state.json:\n"
        f"  {len(tenants)} tenants, {len(organizations)} organizations,\n"
        f"  {len(business_units)} business_units, "
        f"{len(bu_memberships)} bu_memberships, "
        f"{len(bu_favorites)} bu_favorites,\n"
        f"  {len(projects)} projects, "
        f"{len(project_memberships)} project_memberships"
    )

    t_ins, t_skip = _backfill_tenants(tenants)
    o_ins, o_skip = _backfill_organizations(organizations)
    bu_ins, bu_skip = _backfill_business_units(business_units)
    bum_ins, bum_skip = _backfill_bu_memberships(bu_memberships)
    buf_ins, buf_skip = _backfill_bu_favorites(bu_favorites)
    p_ins, p_skip = _backfill_projects(projects)
    pm_ins, pm_skip, pm_coerced = _backfill_project_memberships(
        project_memberships, projects
    )

    print("Backfill complete:")
    print(f"  tenants:                    {t_ins} inserted, {t_skip} skipped")
    print(f"  organizations:              {o_ins} inserted, {o_skip} skipped")
    print(f"  business_units:             {bu_ins} inserted, {bu_skip} skipped")
    print(f"  business_unit_memberships:  {bum_ins} inserted, {bum_skip} skipped")
    print(f"  business_unit_favorites:    {buf_ins} inserted, {buf_skip} skipped")
    print(f"  projects:                   {p_ins} inserted, {p_skip} skipped")
    print(
        f"  project_memberships:        {pm_ins} inserted, {pm_skip} skipped"
        f" ({pm_coerced} had fields coerced from project envelope)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
