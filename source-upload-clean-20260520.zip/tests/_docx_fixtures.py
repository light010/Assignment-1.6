"""Shared DOCX and Block-payload fixture helpers for the test suite.

This module is the **single canonical source** for two kinds of test
artifacts:

1. **Synthetic DOCX bytes** for edge-case extraction tests. Each builder
   returns a `bytes` object that `extract_document(...)` can consume.
   Per Step D0 of `plans/extraction-quality-gate.md`, every new edge-case
   fixture (image-only paragraph, hidden text, hyperlinks, nested tables,
   footnotes, etc.) lands here so tests don't reinvent DOCX construction.

2. **Block-shaped dicts in production shape.** `build_block_payload(...)`
   constructs the dict by **going through the Pydantic `Block` model**,
   so drift between hand-built test fixtures and producer output is
   structurally impossible. The helper IS the model, not a separate
   shape that could drift.

Background: Step C discovered that `test_llm_gateway.py:_block_payload`
hand-built heading blocks without `confidence.heading`, while the
producer at `extractors.py:_source_block:866-872` always populates that
field for headings. When `pipeline.make_node` started reading
`confidence.heading` strictly, the test broke. The root cause was
fixture drift — multiple tests invented their own block shape with no
shared source of truth.

Conventions:
- Test files import from this module instead of hand-rolling block dicts
  or DOCX byte streams.
- New block_type fields, new locator kinds, etc., are added here first
  with a unit test in `tests/test_docx_fixtures.py`; only then do
  consumer tests use them.
- `_TINY_PNG` is the canonical 1×1 transparent PNG for inline image
  fixtures. CRC-verified byte-for-byte; tested via python-docx's
  Pillow-free image reader.
"""

from __future__ import annotations

import base64
import io
from typing import Any

from ditagen_common.models import (
    Block,
    Confidence,
    InlineRun,
    SourceLocation,
)

# CRC-verified 1×1 transparent PNG. Decodes through python-docx's
# Pillow-free PNG reader; the alternate hand-coded byte string at the
# start of Step A failed CRC validation, so this base64 form is the
# canonical fixture for inline-image tests.
_TINY_PNG: bytes = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


def build_image_only_paragraph_docx() -> bytes:
    """3-paragraph DOCX: text → image-only paragraph → text.

    The middle paragraph carries an embedded picture and no text — used
    to exercise the canonical empty-paragraph rule (text OR asset_refs).
    Step A's regression suite asserts the producer emits 3 blocks for
    this input with monotonic body indices.
    """
    from docx import Document
    from docx.shared import Inches

    document = Document()
    document.add_paragraph("Before image")
    image_paragraph = document.add_paragraph()
    image_paragraph.add_run().add_picture(io.BytesIO(_TINY_PNG), width=Inches(0.5))
    document.add_paragraph("After image")
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def build_hyperlink_paragraph_docx(*, url: str = "https://example.com/help") -> bytes:
    """Single-paragraph DOCX with one external hyperlink.

    Paragraph reads visibly as `"Visit example for more info."` where
    `example` is an `<w:hyperlink>` element whose `r:id` resolves to
    `url`. Step D3's regression suite asserts the producer emits at
    least one `inline_runs` entry with `href == url` and a `"link"` mark.
    """
    from docx import Document
    from docx.oxml.ns import qn
    from docx.oxml.shared import OxmlElement

    document = Document()
    paragraph = document.add_paragraph("Visit ")
    rel_id = paragraph.part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)
    new_run = OxmlElement("w:r")
    rpr = OxmlElement("w:rPr")
    new_run.append(rpr)
    new_run_text = OxmlElement("w:t")
    new_run_text.text = "example"
    new_run.append(new_run_text)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)
    paragraph.add_run(" for more info.")
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def build_footnote_docx(*, footnote_text: str = "This is the footnote body.") -> bytes:
    """DOCX with one paragraph that has a footnote reference + a populated
    `word/footnotes.xml` part.

    python-docx 1.2.0 has no public footnote API, so we build a baseline
    DOCX with python-docx, then inject:
      - `word/footnotes.xml` with one `<w:footnote w:id="1">`
      - relationship in `word/_rels/document.xml.rels` pointing to it
      - `<Override>` in `[Content_Types].xml` for the footnotes part
      - `<w:footnoteReference w:id="1"/>` inside the body paragraph

    Step D4's regression suite asserts the producer emits a
    `block_type="note"` block with locator `docx:footnote:1` and text
    equal to `footnote_text`.
    """
    import zipfile as _zipfile

    from docx import Document

    document = Document()
    document.add_paragraph("Body text with footnote.")
    base_buffer = io.BytesIO()
    document.save(base_buffer)
    base_bytes = base_buffer.getvalue()

    footnotes_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<w:footnotes xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n'
        '  <w:footnote w:type="separator" w:id="-1"><w:p><w:r><w:separator/></w:r></w:p></w:footnote>\n'
        '  <w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>\n'
        f'  <w:footnote w:id="1"><w:p><w:r><w:t>{footnote_text}</w:t></w:r></w:p></w:footnote>\n'
        "</w:footnotes>\n"
    )
    fn_content_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"
    fn_rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes"

    # Re-build the zip with footnotes injected. We rewrite [Content_Types].xml,
    # word/_rels/document.xml.rels, and word/document.xml; copy everything else.
    src_zip = _zipfile.ZipFile(io.BytesIO(base_bytes))
    dst_buffer = io.BytesIO()
    dst_zip = _zipfile.ZipFile(dst_buffer, mode="w", compression=_zipfile.ZIP_DEFLATED)
    try:
        for item in src_zip.namelist():
            data = src_zip.read(item)
            if item == "[Content_Types].xml":
                # Inject Override before </Types>.
                xml = data.decode("utf-8")
                override = (
                    f'<Override PartName="/word/footnotes.xml" ContentType="{fn_content_type}"/>'
                )
                xml = xml.replace("</Types>", f"{override}</Types>")
                data = xml.encode("utf-8")
            elif item == "word/_rels/document.xml.rels":
                xml = data.decode("utf-8")
                relationship = (
                    '<Relationship Id="rIdFnFix" '
                    f'Type="{fn_rel_type}" Target="footnotes.xml"/>'
                )
                xml = xml.replace("</Relationships>", f"{relationship}</Relationships>")
                data = xml.encode("utf-8")
            elif item == "word/document.xml":
                xml = data.decode("utf-8")
                # Insert <w:r><w:footnoteReference w:id="1"/></w:r> before the closing
                # </w:p> of the first paragraph so the body actually references the
                # injected footnote stream.
                fn_ref_run = (
                    '<w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr>'
                    '<w:footnoteReference w:id="1"/></w:r>'
                )
                xml = xml.replace("</w:p>", f"{fn_ref_run}</w:p>", 1)
                data = xml.encode("utf-8")
            dst_zip.writestr(item, data)
        dst_zip.writestr("word/footnotes.xml", footnotes_xml)
    finally:
        dst_zip.close()
        src_zip.close()
    return dst_buffer.getvalue()


def build_nested_table_docx() -> bytes:
    """2x2 outer table with a 2-row inner table inside cell (0, 1).

    Layout::

        +-----------+---------------------------+
        | outer A   | inner_r1                  |
        |           | inner_r2                  |
        +-----------+---------------------------+
        | outer C   | outer D                   |
        +-----------+---------------------------+

    Step E's regression suite asserts the producer:
      - emits 2 outer-row blocks (one per outer table row),
      - emits 2 inner-row blocks with locator
        ``docx:tbl:{outer}:r:1:tbl:0:r:1`` and ``...:r:2``,
      - tags the outer row at row_index=1 with the ``NESTED_TABLE`` flag.
    """
    from docx import Document

    document = Document()
    outer = document.add_table(rows=2, cols=2)
    outer.rows[0].cells[0].text = "outer A"
    outer.rows[1].cells[0].text = "outer C"
    outer.rows[1].cells[1].text = "outer D"
    host_cell = outer.rows[0].cells[1]
    # python-docx leaves a default empty paragraph in each cell; clear it
    # so the inner table doesn't trail an empty <w:p> that would also
    # render in docx-preview and shift our row counts.
    host_cell.text = ""
    inner = host_cell.add_table(rows=2, cols=1)
    inner.rows[0].cells[0].text = "inner_r1"
    inner.rows[1].cells[0].text = "inner_r2"
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def build_header_footer_docx() -> bytes:
    """DOCX with one section whose primary header + footer carry text.

    Header reads ``"Confidential — Draft"`` and footer reads ``"Page 1 of N"``;
    body has a single paragraph so the producer can't be confused into
    treating header/footer paragraphs as body content. Step E's regression
    suite asserts the producer emits two blocks with locators
    ``docx:hdr:section-0:p:0`` and ``docx:ftr:section-0:p:0``, and
    block_type ``"running_header"`` / ``"running_footer"`` respectively.
    """
    from docx import Document

    document = Document()
    document.add_paragraph("Body paragraph.")
    section = document.sections[0]
    section.header.paragraphs[0].text = "Confidential — Draft"
    section.footer.paragraphs[0].text = "Page 1 of N"
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def build_hidden_text_paragraph_docx() -> bytes:
    """1-paragraph DOCX with a mix of visible and `<w:vanish/>` runs.

    The paragraph reads visibly as `"Visible suffix"` after Word filters
    the hidden middle run. Step D2's regression suite asserts the
    producer:
      - emits a block whose `text` is the visible-only concatenation,
      - emits `HIDDEN_TEXT_DROPPED` review_flag with severity=warning.
    """
    from docx import Document

    document = Document()
    paragraph = document.add_paragraph()
    paragraph.add_run("Visible ")
    hidden = paragraph.add_run("secret-internal-note ")
    hidden.font.hidden = True
    paragraph.add_run("suffix")
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def build_block_payload(
    *,
    block_id: str,
    text: str = "",
    block_type: str = "paragraph",
    document_id: str = "doc_test",
    section: str | None = None,
    page: int | None = None,
    confidence: dict[str, float] | None = None,
    **block_kwargs: Any,
) -> dict[str, Any]:
    """Construct a Block-shaped dict in production shape.

    Goes through `ditagen_common.models.Block(...).model_dump(mode="json")`
    so the returned dict mirrors exactly what `extractors.py:_source_block`
    emits. Drift between hand-built fixtures and producer output is
    impossible by construction: this helper IS the Block model.

    Args:
        block_id: Required. The block's stable identifier.
        text: Block text. Defaults to "" so figure blocks work out of the box.
        block_type: One of the `BlockType` Literal values. When `"heading"`,
            `confidence.heading` is populated automatically (matching
            `extractors.py:_source_block:866-872`).
        document_id: Defaults to `"doc_test"`.
        section: Optional locator string. Must parse via `parse_locator` if
            provided — Pydantic's `SourceLocation.validate_section_locator`
            enforces this.
        page: Optional page number. `None` for DOCX (per Step A canonical
            rule); set to `1` for PDF tests.
        confidence: Override default confidence values. Keys: `extraction`,
            `block_type`, `semantic_inline`, `heading`. Defaults are
            placeholder mid-range values that `_compute_review_signals`
            would overwrite in production.
        **block_kwargs: Pass-through for any optional Block field
            (`inferred_level`, `style_summary`, `asset_refs`,
            `review_flags`, `table_id`, `row_index`, `cells`, etc.).
            Validation happens via Pydantic; bad fields raise.

    Returns:
        A JSON-serialisable dict equivalent to what the producer emits.
    """
    confidence_dict: dict[str, float] = {
        "extraction": 0.85,
        "block_type": 0.85,
        "semantic_inline": 0.75,
    }
    if block_type == "heading":
        confidence_dict["heading"] = 0.85
    if confidence:
        confidence_dict.update(confidence)

    init_kwargs: dict[str, Any] = {
        "block_id": block_id,
        "document_id": document_id,
        "block_type": block_type,
        "text": text,
        "source_location": SourceLocation(page=page, section=section),
        "confidence": Confidence(**confidence_dict),
    }

    # Default inline_runs to a single run spanning the text. Callers can
    # override via `block_kwargs` if they need richer run structure.
    if "inline_runs" not in block_kwargs and text:
        init_kwargs["inline_runs"] = [InlineRun(start=0, end=len(text), text=text, marks=[])]

    init_kwargs.update(block_kwargs)

    block = Block(**init_kwargs)
    return block.model_dump(mode="json")
