from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def load(path: str):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def test_existing_topic_json_examples_match_contracts() -> None:
    Draft202012Validator(load("contracts/llm/topic-plan.schema.json")).validate(
        load("examples/topic-json/topic-plan.json")
    )
    Draft202012Validator(load("contracts/llm/generated-topic.schema.json")).validate(
        load("examples/topic-json/generated-topic.json")
    )


def test_existing_source_block_example_matches_contract() -> None:
    validator = Draft202012Validator(load("contracts/artifacts/source-block.schema.json"))
    for block in load("examples/topic-json/dirty-source-blocks.json"):
        validator.validate(block)
