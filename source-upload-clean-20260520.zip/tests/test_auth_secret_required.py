from __future__ import annotations

import pytest
from ditagen_common.security import DEFAULT_SECRET, validate_auth_secret_config


def test_auth_secret_required_outside_development(monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_ENV", "production")
    monkeypatch.delenv("DITAGEN_AUTH_SECRET", raising=False)

    with pytest.raises(RuntimeError, match="DITAGEN_AUTH_SECRET"):
        validate_auth_secret_config()


def test_auth_secret_rejects_known_default_outside_development(monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_ENV", "production")
    monkeypatch.setenv("DITAGEN_AUTH_SECRET", DEFAULT_SECRET)

    with pytest.raises(RuntimeError, match="known insecure default"):
        validate_auth_secret_config()


def test_auth_secret_allows_local_development_default(monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_ENV", "development")
    monkeypatch.delenv("DITAGEN_AUTH_SECRET", raising=False)

    assert validate_auth_secret_config() == DEFAULT_SECRET
