"""Unit tests for the shared test toolkit at `tests/_docx_fixtures.py`.

The toolkit's value is **guaranteed shape parity** between hand-built test
fixtures and the producer's output. These tests lock that guarantee.
"""

from __future__ import annotations

import io
from typing import get_args

import pytest
from _docx_fixtures import (
    _TINY_PNG,
    build_block_payload,
    build_header_footer_docx,
    build_image_only_paragraph_docx,
    build_nested_table_docx,
)
from ditagen_common.models import Block
from ditagen_common.models.block import BlockType
from pydantic import ValidationError


@pytest.mark.parametrize("block_type", list(get_args(BlockType)))
def test_build_block_payload_round_trips_through_block_model(block_type: str) -> None:
    """Every BlockType Literal value must produce a payload that
    re-validates against Block. If a future BlockType is added without
    updating the helper, this test fails — making fixture drift loud.
    """
    payload = build_block_payload(
        block_id=f"blk_{block_type}",
        text="Sample text",
        block_type=block_type,
    )
    # Round-trip: dict → Block → dict. Must equal the original.
    revalidated = Block.model_validate(payload).model_dump(mode="json")
    assert revalidated == payload, (
        f"Block round-trip diverged for block_type={block_type!r}; "
        "the helper's output is not in canonical Block shape."
    )


def test_build_block_payload_populates_heading_confidence_only_for_headings() -> None:
    """Mirrors `extractors.py:_source_block:866-872`: heading blocks carry
    `confidence.heading`; non-heading blocks do not.

    This is the exact contract that Step C tightened — `pipeline.make_node`
    now reads `confidence.heading` strictly, so this invariant must hold
    for every test fixture in the suite.
    """
    heading = build_block_payload(block_id="blk_h", text="H", block_type="heading")
    paragraph = build_block_payload(block_id="blk_p", text="P", block_type="paragraph")
    assert heading["confidence"]["heading"] is not None
    assert paragraph["confidence"]["heading"] is None


def test_build_block_payload_accepts_optional_block_fields() -> None:
    """Optional fields like `inferred_level`, `asset_refs`, `table_id`,
    `style_summary` can be passed through. Pydantic validates them; bad
    values raise."""
    payload = build_block_payload(
        block_id="blk_t1_r1",
        text="Field | Value",
        block_type="table_row",
        table_id="tbl_001",
        row_index=1,
        cells=[
            {"text": "Field", "colspan": 1, "rowspan": 1},
            {"text": "Value", "colspan": 1, "rowspan": 1},
        ],
    )
    assert payload["table_id"] == "tbl_001"
    assert payload["row_index"] == 1
    assert len(payload["cells"]) == 2
    # Confirm Pydantic actually validated by re-loading.
    block = Block.model_validate(payload)
    assert block.table_id == "tbl_001"


def test_build_block_payload_rejects_unknown_fields() -> None:
    """The Block model is `extra="forbid"`. Tests that pass typos slip
    through unnoticed today — the helper makes them fail loudly."""
    with pytest.raises(ValidationError):
        build_block_payload(
            block_id="blk_typo",
            text="x",
            block_type="paragraph",
            # NB: deliberate typo. Should raise.
            unknown_field="oops",
        )


def test_build_block_payload_locator_validates() -> None:
    """`source_location.section` must parse via `parse_locator`. Invalid
    locators should raise at construction time, not silently slip into
    the wire."""
    # Valid locator: should construct cleanly.
    payload = build_block_payload(
        block_id="blk_loc",
        text="Hello",
        section="docx:p:0",
    )
    assert payload["source_location"]["section"] == "docx:p:0"
    # Invalid locator: should raise.
    with pytest.raises(ValidationError):
        build_block_payload(
            block_id="blk_bad_loc",
            text="x",
            section="not-a-locator",
        )


def test_tiny_png_is_parseable_by_python_docx() -> None:
    """python-docx parses PNG with a Pillow-free reader that validates
    CRC chunks. An invalid PNG (like the hand-coded bytes in Step A's
    first attempt) crashes the test fixture builder loudly.
    """
    from docx import Document
    from docx.shared import Inches

    document = Document()
    document.add_paragraph().add_run().add_picture(io.BytesIO(_TINY_PNG), width=Inches(0.5))
    buffer = io.BytesIO()
    document.save(buffer)
    # Round-trip: if the embedded PNG were malformed, save+reload would fail.
    Document(io.BytesIO(buffer.getvalue()))


def test_build_image_only_paragraph_docx_yields_three_paragraphs() -> None:
    """The canonical image-only DOCX fixture must remain stable across
    test runs — three paragraphs, middle one image-only. Step A's
    extraction tests depend on this exact shape."""
    from docx import Document

    document = Document(io.BytesIO(build_image_only_paragraph_docx()))
    paragraphs = list(document.paragraphs)
    assert len(paragraphs) == 3
    assert paragraphs[0].text == "Before image"
    assert paragraphs[1].text == ""  # image-only
    assert paragraphs[2].text == "After image"


def test_build_nested_table_docx_has_outer_2x2_with_inner_2x1() -> None:
    """The nested-table fixture must remain stable: outer 2x2 with a
    2-row inner table living in cell (0, 1). Step E's regression suite
    depends on this exact shape so locator indices stay deterministic."""
    from docx import Document

    document = Document(io.BytesIO(build_nested_table_docx()))
    assert len(document.tables) == 1, "Only one body-level table"
    outer = document.tables[0]
    assert len(outer.rows) == 2
    assert len(outer.rows[0].cells) == 2

    host_cell = outer.rows[0].cells[1]
    assert len(host_cell.tables) == 1, "Cell (0, 1) must contain exactly one nested table"
    inner = host_cell.tables[0]
    assert len(inner.rows) == 2
    assert inner.rows[0].cells[0].text == "inner_r1"
    assert inner.rows[1].cells[0].text == "inner_r2"

    # Cells without nested tables should be free of them — guard against a
    # fixture regression that accidentally seeds nested tables everywhere.
    assert not outer.rows[0].cells[0].tables
    assert not outer.rows[1].cells[0].tables
    assert not outer.rows[1].cells[1].tables


def test_build_header_footer_docx_populates_primary_surfaces() -> None:
    """The header/footer fixture must produce a section whose primary
    header and footer carry the expected text, with a single body
    paragraph. Step E's regression suite asserts the producer's
    `running_header`/`running_footer` blocks pick up these strings."""
    from docx import Document

    document = Document(io.BytesIO(build_header_footer_docx()))
    body_paragraphs = list(document.paragraphs)
    assert len(body_paragraphs) == 1
    assert body_paragraphs[0].text == "Body paragraph."

    section = document.sections[0]
    header_text = " ".join(p.text for p in section.header.paragraphs).strip()
    footer_text = " ".join(p.text for p in section.footer.paragraphs).strip()
    assert "Confidential" in header_text
    assert "Page 1 of N" in footer_text
