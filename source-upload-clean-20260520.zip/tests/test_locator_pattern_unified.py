"""Step I2 — architecture lock: locator regex pattern is unified across
all three sources of truth.

Sources compared:
  1. `LOCATOR_PATTERN_STRING` in `packages/python/ditagen_common/locator.py`
  2. `source-block.schema.json#section.pattern`
  3. `source-line.schema.json#section.pattern`

Drift between these three has caused real bugs in this milestone
(audit I-audit-3: PDF `pdf:p:0` accepted by Python regex, rejected by
schema; audit I-audit-4: `:g` float formatting emits scientific
notation that the schema then rejects). This test asserts:
  - The Python pattern string matches the compiled regex's pattern.
  - Both schemas accept the SAME set of valid locator strings.
  - Both schemas reject the SAME set of invalid locator strings.
  - The unified pattern rejects `pdf:p:0` (audit I-audit-3 fix).
  - The bbox formatter produces strings that the unified pattern matches
    for tiny floats (audit I-audit-4 scientific-notation fix).

The TS side of the unification (`apps/web/src/locator.ts`) is checked
by a parallel vitest in `apps/web/src/locator.test.ts`.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest
from ditagen_common.locator import (
    LOCATOR_PATTERN,
    LOCATOR_PATTERN_STRING,
    format_pdf_bbox_locator,
    validate_locator,
)

ROOT = Path(__file__).resolve().parents[1]


def _schema_section_pattern(schema_relpath: str) -> str:
    schema = json.loads((ROOT / schema_relpath).read_text())
    if schema_relpath.endswith("source-block.schema.json"):
        return schema["properties"]["source_location"]["properties"]["section"]["pattern"]
    return schema["properties"]["source_location"]["properties"]["section"]["pattern"]


def test_python_pattern_string_matches_compiled_regex() -> None:
    assert LOCATOR_PATTERN.pattern == LOCATOR_PATTERN_STRING


_VALID_LOCATORS = [
    "docx:p:0",
    "docx:p:42",
    "docx:tbl:3:r:1",
    "docx:tbl:0:r:1:tbl:0:r:1",
    "docx:hdr:section-0:p:0",
    "docx:ftr:section_a.1:p:7",
    "docx:footnote:1",
    "docx:endnote:1",
    "pdf:p:1:bbox:0:0:0:0",
    "pdf:p:42:bbox:12.5:340.25:200:600",
    "pdf:p:1:bbox:-5:-10:100:200",
]

_INVALID_LOCATORS = [
    "",
    "docx:p:",
    "docx:p:-1",
    "docx:tbl:1",
    "docx:tbl:1:r:",
    "docx:hdr::p:0",
    # Audit I-audit-3: pdf:p:0 must be rejected.
    "pdf:p:0:bbox:0:0:0:0",
    # Scientific notation should not parse.
    "pdf:p:1:bbox:1e-06:0:0:0",
    # Random gibberish.
    "not-a-locator",
    "docx:tbl:1:r:1:extra",
]


@pytest.mark.parametrize("schema_relpath", [
    "contracts/artifacts/source-block.schema.json",
    "contracts/artifacts/source-line.schema.json",
])
@pytest.mark.parametrize("locator", _VALID_LOCATORS)
def test_valid_locators_match_python_and_schema(schema_relpath: str, locator: str) -> None:
    """Every valid locator the producer might emit must match BOTH the
    Python compiled regex AND each JSON Schema pattern."""
    schema_pattern = re.compile(_schema_section_pattern(schema_relpath))
    assert validate_locator(locator), f"Python rejected valid locator {locator!r}"
    assert schema_pattern.fullmatch(locator) is not None, (
        f"Schema {schema_relpath} rejected valid locator {locator!r}"
    )


@pytest.mark.parametrize("schema_relpath", [
    "contracts/artifacts/source-block.schema.json",
    "contracts/artifacts/source-line.schema.json",
])
@pytest.mark.parametrize("locator", _INVALID_LOCATORS)
def test_invalid_locators_rejected_by_python_and_schema(
    schema_relpath: str, locator: str
) -> None:
    """Every invalid locator must be rejected by BOTH the Python regex
    AND each JSON Schema pattern. Drift = real bugs."""
    schema_pattern = re.compile(_schema_section_pattern(schema_relpath))
    assert not validate_locator(locator), (
        f"Python accepted invalid locator {locator!r}"
    )
    assert schema_pattern.fullmatch(locator) is None, (
        f"Schema {schema_relpath} accepted invalid locator {locator!r}"
    )


def test_pdf_page_zero_is_rejected_now() -> None:
    """Audit I-audit-3 lock: `pdf:p:0` matched the Python regex pre-Step-I
    but failed `format_pdf_bbox_locator`'s `page < 1` guard, so the
    formatter and the validator disagreed. Fixed by tightening the regex
    to `[1-9]\\d*`.
    """
    assert not validate_locator("pdf:p:0:bbox:0:0:0:0")
    with pytest.raises(ValueError):
        format_pdf_bbox_locator(0, 0, 0, 0, 0)


@pytest.mark.parametrize("value", [
    0.0,
    -0.0,
    1.0,
    12.5,
    1e-6,  # would render as `1e-06` under :g, audit I-audit-4
    1e-12,  # extreme small
    1234567.89,
    -12.5,
])
def test_bbox_formatter_emits_locator_pattern_matching_strings(value: float) -> None:
    """Audit I-audit-4 lock: the bbox formatter must NEVER produce a
    component that the locator regex rejects. The previous `f"{v:g}"`
    formatter produced `1e-06` for tiny magnitudes — schema-invalid.
    """
    locator = format_pdf_bbox_locator(1, value, 0, 0, 0)
    assert validate_locator(locator), (
        f"format_pdf_bbox_locator produced a locator the regex rejects "
        f"for value={value!r}: {locator!r}"
    )
    # Spot-check: no scientific notation in the output.
    assert "e" not in locator.lower(), (
        f"Locator contains scientific-notation marker 'e' for value={value!r}: {locator!r}"
    )
