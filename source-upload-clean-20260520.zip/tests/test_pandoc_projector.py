"""Step F unit tests for the rewritten pandoc projector.

These tests deliberately avoid spawning pandoc/mdformat — they exercise:
  - The preflight checks (`shutil.which` mocked) for `pandoc_unavailable`,
    `mdformat_unavailable`, `mdformat_plugin_missing`.
  - The reorder-detection logic (`_count_alignment_units`,
    `_split_pandoc_chunks`, `_inject_source_sentinels`).
  - The exclusion set `_ALIGNMENT_EXCLUDED_TYPES` is exhaustive against
    the list-like block types that collapse to one pandoc chunk.

When pandoc + mdformat are installed (CI), the determinism lock in
`tests/test_apple_ca_invariants.py::test_pandoc_projection_is_deterministic`
runs a real end-to-end determinism check. Locally we skip-if-no-pandoc
to keep the suite fast and stable.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(
    0, str(Path(__file__).resolve().parents[1] / "services" / "extraction-service" / "app")
)

from pandoc_projector import (  # noqa: E402
    _ALIGNMENT_EXCLUDED_TYPES,
    PandocProjectorError,
    _count_alignment_units,
    _inject_source_sentinels,
    _split_pandoc_chunks,
    project_docx_to_markdown,
)


def test_alignment_excluded_types_covers_list_like_and_metadata_block_types() -> None:
    """The set must include every block_type that collapses to one (or
    zero) pandoc top-level chunks. The plan only called out `table_row`
    but lists have the same problem: N source_blocks of type
    `procedure_step` collapse to a single `<ol>` chunk.
    """
    expected = {
        "table_row",
        "running_header",
        "running_footer",
        "note",
        "ordered_list",
        "unordered_list",
        "procedure_step",
    }
    assert _ALIGNMENT_EXCLUDED_TYPES == frozenset(expected), (
        "If you change the alignment exclusion set, this test exists as "
        "the source of truth that pairs with the docstring in "
        "pandoc_projector.py — update both together."
    )


def test_count_alignment_units_excludes_table_rows_and_lists() -> None:
    source_blocks = [
        {"block_type": "heading"},
        {"block_type": "paragraph"},
        {"block_type": "table_row"},
        {"block_type": "table_row"},
        {"block_type": "table_row"},
        {"block_type": "procedure_step"},
        {"block_type": "procedure_step"},
        {"block_type": "paragraph"},
        {"block_type": "running_header"},
        {"block_type": "running_footer"},
        {"block_type": "note"},
    ]
    # Only heading + paragraph + paragraph = 3 alignment units.
    assert _count_alignment_units(source_blocks) == 3


def test_split_pandoc_chunks_handles_blank_line_separators() -> None:
    markdown = (
        "# Heading\n\nParagraph one with `code`.\n\nParagraph two.\n\n"
        "| col1 | col2 |\n| --- | --- |\n| a | b |\n"
    )
    chunks = _split_pandoc_chunks(markdown)
    assert len(chunks) == 4
    assert chunks[0] == "# Heading"
    assert chunks[1].startswith("Paragraph one")
    assert chunks[3].startswith("| col1")


def test_inject_source_sentinels_emits_one_sentinel_per_alignment_unit() -> None:
    chunks = ["# H1", "Body para.", "More body."]
    source_blocks = [
        {"block_id": "blk_h", "block_type": "heading"},
        {"block_id": "blk_tr", "block_type": "table_row"},  # excluded
        {"block_id": "blk_p1", "block_type": "paragraph"},
        {"block_id": "blk_hdr", "block_type": "running_header"},  # excluded
        {"block_id": "blk_p2", "block_type": "paragraph"},
    ]
    out = _inject_source_sentinels(chunks, source_blocks)
    assert out.count("<!-- source:blk_h -->") == 1
    assert out.count("<!-- source:blk_tr -->") == 0  # excluded
    assert out.count("<!-- source:blk_p1 -->") == 1
    assert out.count("<!-- source:blk_hdr -->") == 0  # excluded
    assert out.count("<!-- source:blk_p2 -->") == 1
    # Sentinels appear immediately before their owning chunk:
    assert "<!-- source:blk_h -->\n# H1" in out
    assert "<!-- source:blk_p1 -->\nBody para." in out
    assert "<!-- source:blk_p2 -->\nMore body." in out


def test_pandoc_unavailable_raises_with_correct_reason(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("pandoc_projector.shutil.which", lambda _name: None)
    with pytest.raises(PandocProjectorError) as exc_info:
        project_docx_to_markdown(docx_bytes=b"", source_blocks=[])
    assert exc_info.value.reason == "pandoc_unavailable"


def test_mdformat_unavailable_raises_with_correct_reason(monkeypatch: pytest.MonkeyPatch) -> None:
    """When pandoc is present but mdformat is missing, the projector must
    fail fast with `mdformat_unavailable` BEFORE invoking pandoc — the
    canonicalization step at the end of the pipeline is required for
    deterministic output, so silently falling back to raw pandoc markdown
    (the pre-Step-F behavior) is incorrect."""
    import pandoc_projector

    def fake_which(name: str) -> str | None:
        return "/usr/local/bin/pandoc" if name == "pandoc" else None

    def fake_pandoc_version(_path: str) -> str:
        return "pandoc 3.1.9\n"

    monkeypatch.setattr(pandoc_projector.shutil, "which", fake_which)
    monkeypatch.setattr(pandoc_projector, "_pandoc_version", fake_pandoc_version)
    with pytest.raises(PandocProjectorError) as exc_info:
        project_docx_to_markdown(docx_bytes=b"", source_blocks=[])
    assert exc_info.value.reason == "mdformat_unavailable"


def test_mdformat_plugin_missing_raises_with_correct_reason(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When mdformat is present but `--help` doesn't mention gfm, the
    projector must fail with `mdformat_plugin_missing`. Without the gfm
    plugin, canonicalization diverges from contract (no autolinks, no
    tables, etc.) — silently using non-gfm output is a contract bug.
    """
    import pandoc_projector

    def fake_which(name: str) -> str | None:
        if name == "pandoc":
            return "/usr/local/bin/pandoc"
        if name == "mdformat":
            return "/usr/local/bin/mdformat"
        return None

    monkeypatch.setattr(pandoc_projector.shutil, "which", fake_which)
    monkeypatch.setattr(pandoc_projector, "_pandoc_version", lambda _p: "pandoc 3.1.9\n")
    monkeypatch.setattr(
        pandoc_projector, "_mdformat_help_text", lambda _p: "usage: mdformat [...]"
    )
    monkeypatch.setattr(
        pandoc_projector, "_mdformat_version_text", lambda _p: "mdformat 0.7.17"
    )
    with pytest.raises(PandocProjectorError) as exc_info:
        project_docx_to_markdown(docx_bytes=b"", source_blocks=[])
    assert exc_info.value.reason == "mdformat_plugin_missing"


def test_projector_error_reasons_are_in_schema_enum() -> None:
    """Architecture lock: every `PandocProjectorError.reason` the projector
    can raise must appear in the `extraction-quality.schema.json`
    `blocking_reasons` enum. Without this lock a code-only addition (new
    reason in the projector) would silently produce gates the schema
    can't validate.
    """
    import json

    schema_path = (
        Path(__file__).resolve().parents[1]
        / "contracts"
        / "artifacts"
        / "extraction-quality.schema.json"
    )
    schema = json.loads(schema_path.read_text())
    enum_values = set(
        schema["properties"]["gate"]["properties"]["blocking_reasons"]["items"]["enum"]
    )

    # The reasons the projector raises. Keep this set in sync with the
    # PandocProjectorError docstring in pandoc_projector.py.
    projector_reasons = {
        "pandoc_unavailable",
        "pandoc_failed",
        "pandoc_reordered",
        "mdformat_unavailable",
        "mdformat_plugin_missing",
    }
    missing = projector_reasons - enum_values
    assert not missing, (
        f"Projector raises reason(s) not present in extraction-quality schema: {missing}"
    )
