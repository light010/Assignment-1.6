from __future__ import annotations

import json

from ditagen_common.store import JsonStore


def test_store_migrates_legacy_alpha_state(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    state_file = tmp_path / "state.json"
    state_file.write_text(
        json.dumps(
            {
                "tenants": [{"tenant_id": "ten_local", "name": "Local Tenant"}],
                "organizations": [
                    {
                        "organization_id": "org_local",
                        "tenant_id": "ten_local",
                        "name": "DITAgen Local",
                    }
                ],
                "users": [
                    {
                        "user_id": "usr_admin",
                        "tenant_id": "ten_local",
                        "organization_id": "org_local",
                        "email": "admin@ditagen.local",
                        "name": "Local Admin",
                        "password_hash": "unused",
                        "roles": ["org_admin", "project_admin", "editor", "reviewer"],
                    }
                ],
                "sessions": {},
                "projects": {
                    "prj_old": {
                        "project_id": "prj_old",
                        "tenant_id": "ten_local",
                        "organization_id": "org_local",
                        "name": "Old Project",
                        "created_by": "usr_admin",
                        "created_at": "2026-01-01T00:00:00Z",
                    }
                },
                "documents": {
                    "doc_old": {
                        "document_id": "doc_old",
                        "tenant_id": "ten_local",
                        "project_id": "prj_old",
                        "filename": "old.txt",
                        "status": "ready_for_review",
                        "job_ids": ["job_old"],
                        "topic_ids": ["top_old"],
                        "source_hash": "abc",
                        "source_quality": {
                            "overall_confidence": 0.9,
                            "review_required": False,
                            "validation_issue_count": 0,
                        },
                        "created_at": "2026-01-01T00:00:00Z",
                    }
                },
                "topics": {
                    "top_old": {
                        "topic_record_id": "top_old",
                        "tenant_id": "ten_local",
                        "project_id": "prj_old",
                        "document_id": "doc_old",
                        "status": "generated",
                        "generated_topic": {},
                        "dita_xml": "",
                        "validation_issues": [],
                        "traceability": [],
                        "artifact_version": "1",
                    }
                },
                "jobs": {
                    "job_old": {
                        "job_id": "job_old",
                        "project_id": "prj_old",
                        "document_id": "doc_old",
                        "stage": "pipeline",
                        "status": "completed",
                        "events": [],
                        "created_at": "2026-01-01T00:00:00Z",
                    }
                },
                "exports": {},
                "audit_events": [],
            }
        ),
        encoding="utf-8",
    )

    state = JsonStore(path=state_file).read()

    assert "bu_docs_ops" in state["business_units"]
    assert state["projects"]["prj_old"]["business_unit_id"] == "bu_docs_ops"
    assert state["projects"]["prj_old"]["status"] == "active"
    assert state["projects"]["prj_old"]["deleted_at"] is None
    assert state["documents"]["doc_old"]["business_unit_id"] == "bu_docs_ops"
    assert state["documents"]["doc_old"]["latest_artifacts"] == {}
    assert state["topics"]["top_old"]["business_unit_id"] == "bu_docs_ops"
    assert state["jobs"]["job_old"]["business_unit_id"] == "bu_docs_ops"
