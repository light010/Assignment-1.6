"""Tests for the EditOperation algebra + replay() function (Phase 3).

Coverage:

- Per-op replay unit tests (Merge / Split / Move / Retype / Rename).
- Replay determinism: same (snapshot, ops) -> byte-identical
  ProjectedState dump.
- Snapshot immutability: replay never mutates the input.
- Chain validation: snapshot mismatch + out-of-order parent_op_id
  raise.
- Merge ↔ Split inverse property: merging then splitting produces a
  block whose text matches the merged input.
- Schema compliance: every constructed op validates against
  contracts/edits/edit-operation.schema.json.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import jsonschema
import pytest
from ditagen_common.edits import ReplayError, SnapshotMismatchError, replay
from ditagen_common.models import (
    Block,
    Confidence,
    EditOperationAdapter,
    ExtractionSnapshot,
    MergeOp,
    MergePayload,
    MoveOp,
    MovePayload,
    RawXmlOverrideOp,
    RawXmlOverridePayload,
    RenameOp,
    RenamePayload,
    RetypeOp,
    RetypePayload,
    SourceLocation,
    SplitOp,
    SplitPayload,
    Topic,
)
from pydantic import ValidationError

REPO_ROOT = Path(__file__).resolve().parents[1]
EDIT_OP_SCHEMA_PATH = REPO_ROOT / "contracts" / "edits" / "edit-operation.schema.json"


def _load_schema() -> dict:
    return json.loads(EDIT_OP_SCHEMA_PATH.read_text(encoding="utf-8"))


def _block(*, block_id: str, text: str, page: int = 1) -> Block:
    return Block(
        block_id=block_id,
        document_id="doc_test",
        block_type="paragraph",
        text=text,
        source_location=SourceLocation(page=page),
        confidence=Confidence(extraction=0.9),
        char_start=0,
        char_end=len(text),
    )


def _topic(*, topic_id: str, source_block_ids: list[str], title: str = "Test Topic") -> Topic:
    return Topic(
        topic_id=topic_id,
        title=title,
        topic_type="concept",
        source_block_ids=list(source_block_ids),
    )


def _snapshot() -> ExtractionSnapshot:
    return ExtractionSnapshot(
        snapshot_id="av_snap_001",
        document_id="doc_test",
        blocks=[
            _block(block_id="blk_a", text="Alpha sentence."),
            _block(block_id="blk_b", text="Bravo sentence."),
            _block(block_id="blk_c", text="Charlie sentence."),
        ],
        topics=[
            _topic(
                topic_id="tpc_one",
                source_block_ids=["blk_a", "blk_b"],
                title="One",
            ),
            _topic(
                topic_id="tpc_two",
                source_block_ids=["blk_c"],
                title="Two",
            ),
        ],
    )


def _envelope(op_id: str, snapshot_id: str = "av_snap_001", parent: str | None = None) -> dict:
    return {
        "op_id": op_id,
        "actor_id": "usr_test",
        "created_at": "2026-05-09T12:00:00Z",
        "parent_op_id": parent,
        "extraction_snapshot_id": snapshot_id,
    }


# ---------------------------------------------------------------------------
# Per-op replay tests
# ---------------------------------------------------------------------------


def test_replay_merge_combines_blocks_and_updates_lineage() -> None:
    snap = _snapshot()
    op = MergeOp(
        **_envelope("op_merge_1"),
        payload=MergePayload(block_ids=["blk_a", "blk_b"]),
    )
    state = replay(snap, [op])

    # Two original blocks replaced by one derived block; blk_c untouched.
    assert [b.block_id for b in state.blocks][1:] == ["blk_c"]
    derived = state.blocks[0]
    assert derived.block_id.startswith("blk_m_")
    assert derived.text == "Alpha sentence. Bravo sentence."
    assert derived.lineage == ["blk_a", "blk_b"]
    assert derived.char_start == 0
    assert derived.char_end == len(derived.text)

    # Traceability updated: derived -> originals; blk_a/blk_b dropped.
    assert state.traceability[derived.block_id] == ["blk_a", "blk_b"]
    assert "blk_a" not in state.traceability
    assert "blk_b" not in state.traceability
    assert state.traceability["blk_c"] == ["blk_c"]

    # Topic that referenced [blk_a, blk_b] now references [derived].
    tpc_one = next(t for t in state.topics if t.topic_id == "tpc_one")
    assert tpc_one.source_block_ids == [derived.block_id]


def test_replay_split_divides_block_at_offset_and_records_lineage() -> None:
    snap = _snapshot()
    op = SplitOp(
        **_envelope("op_split_1"),
        payload=SplitPayload(block_id="blk_a", char_offset=6),
    )
    state = replay(snap, [op])

    # blk_a replaced by two new blocks; relative position preserved.
    block_ids = [b.block_id for b in state.blocks]
    assert "blk_a" not in block_ids
    a_id, b_id = block_ids[0], block_ids[1]
    assert a_id.startswith("blk_s_") and b_id.startswith("blk_s_")
    assert a_id != b_id
    assert block_ids[2:] == ["blk_b", "blk_c"]

    # Text split at offset 6: "Alpha " | "sentence."
    a_block = state.blocks[0]
    b_block = state.blocks[1]
    assert a_block.text == "Alpha "
    assert b_block.text == "sentence."
    assert a_block.lineage == ["blk_a"]
    assert b_block.lineage == ["blk_a"]
    assert a_block.char_start == 0 and a_block.char_end == 6
    assert b_block.char_start == 6 and b_block.char_end == 15

    # Topic ref blk_a was replaced by [a_id, b_id].
    tpc_one = next(t for t in state.topics if t.topic_id == "tpc_one")
    assert tpc_one.source_block_ids == [a_id, b_id, "blk_b"]


def test_replay_move_reassigns_block_to_target_topic() -> None:
    snap = _snapshot()
    op = MoveOp(
        **_envelope("op_move_1"),
        payload=MovePayload(block_id="blk_a", target_topic_id="tpc_two"),
    )
    state = replay(snap, [op])

    tpc_one = next(t for t in state.topics if t.topic_id == "tpc_one")
    tpc_two = next(t for t in state.topics if t.topic_id == "tpc_two")
    assert tpc_one.source_block_ids == ["blk_b"]
    assert tpc_two.source_block_ids == ["blk_c", "blk_a"]


def test_replay_retype_changes_topic_type_and_leaves_others_alone() -> None:
    snap = _snapshot()
    op = RetypeOp(
        **_envelope("op_retype_1"),
        payload=RetypePayload(topic_id="tpc_one", topic_type="task"),
    )
    state = replay(snap, [op])

    tpc_one = next(t for t in state.topics if t.topic_id == "tpc_one")
    tpc_two = next(t for t in state.topics if t.topic_id == "tpc_two")
    assert tpc_one.topic_type == "task"
    assert tpc_two.topic_type == "concept"


def test_replay_rename_updates_title_and_or_short_desc() -> None:
    snap = _snapshot()
    op_title_only = RenameOp(
        **_envelope("op_rename_1"),
        payload=RenamePayload(topic_id="tpc_one", title="Renamed One"),
    )
    op_both = RenameOp(
        **_envelope("op_rename_2", parent="op_rename_1"),
        payload=RenamePayload(
            topic_id="tpc_two",
            title="Renamed Two",
            short_desc="A short description.",
        ),
    )
    state = replay(snap, [op_title_only, op_both])

    tpc_one = next(t for t in state.topics if t.topic_id == "tpc_one")
    tpc_two = next(t for t in state.topics if t.topic_id == "tpc_two")
    assert tpc_one.title == "Renamed One"
    assert tpc_one.short_desc is None
    assert tpc_two.title == "Renamed Two"
    assert tpc_two.short_desc == "A short description."


# ---------------------------------------------------------------------------
# Cross-cutting properties
# ---------------------------------------------------------------------------


def test_replay_does_not_mutate_input_snapshot() -> None:
    snap = _snapshot()
    snap_before = copy.deepcopy(snap.model_dump(mode="json"))
    op = RetypeOp(
        **_envelope("op_imm_1"),
        payload=RetypePayload(topic_id="tpc_one", topic_type="reference"),
    )
    replay(snap, [op])
    snap_after = snap.model_dump(mode="json")
    assert snap_before == snap_after, "replay() mutated the input snapshot"


def test_replay_is_deterministic() -> None:
    snap = _snapshot()
    ops: list[MergeOp | SplitOp | MoveOp | RetypeOp | RenameOp | RawXmlOverrideOp] = [
        MergeOp(
            **_envelope("op_det_merge"),
            payload=MergePayload(block_ids=["blk_a", "blk_b"]),
        ),
        SplitOp(
            **_envelope("op_det_split", parent="op_det_merge"),
            payload=SplitPayload(block_id="blk_c", char_offset=8),
        ),
        RetypeOp(
            **_envelope("op_det_retype", parent="op_det_split"),
            payload=RetypePayload(topic_id="tpc_one", topic_type="task"),
        ),
    ]
    first = replay(snap, ops)
    second = replay(snap, ops)
    assert first.model_dump(mode="json") == second.model_dump(mode="json")


def test_replay_merge_then_split_yields_text_equal_to_merged() -> None:
    """Merge ⊕ Split is a partial inverse: the joined text round-trips.

    Splitting the merged block at the boundary of the first input's text
    produces two parts whose concatenation equals the merged text. This
    is a weak inverse — block_ids change because Merge/Split mint new
    derived ids — but the *text content* trip is byte-perfect.
    """
    snap = _snapshot()
    merge_op = MergeOp(
        **_envelope("op_inv_merge"),
        payload=MergePayload(block_ids=["blk_a", "blk_b"]),
    )
    state_after_merge = replay(snap, [merge_op])
    derived = state_after_merge.blocks[0]
    # Split at the boundary that sits between original "blk_a" and "blk_b".
    boundary = len("Alpha sentence. ")
    split_op = SplitOp(
        **_envelope("op_inv_split", parent="op_inv_merge"),
        payload=SplitPayload(block_id=derived.block_id, char_offset=boundary),
    )
    state_after_both = replay(snap, [merge_op, split_op])
    a_text = state_after_both.blocks[0].text
    b_text = state_after_both.blocks[1].text
    assert a_text + b_text == "Alpha sentence. Bravo sentence."


# ---------------------------------------------------------------------------
# Validation / error paths
# ---------------------------------------------------------------------------


def test_replay_rejects_op_targeting_wrong_snapshot() -> None:
    snap = _snapshot()
    op = RetypeOp(
        **_envelope("op_bad_snap", snapshot_id="av_snap_OTHER"),
        payload=RetypePayload(topic_id="tpc_one", topic_type="task"),
    )
    with pytest.raises(SnapshotMismatchError):
        replay(snap, [op])


def test_replay_rejects_out_of_order_chain() -> None:
    snap = _snapshot()
    a = RetypeOp(
        **_envelope("op_chain_a"),
        payload=RetypePayload(topic_id="tpc_one", topic_type="task"),
    )
    # Wrong parent_op_id — claims to follow op_does_not_exist.
    b = RenameOp(
        **_envelope("op_chain_b", parent="op_does_not_exist"),
        payload=RenamePayload(topic_id="tpc_one", title="X"),
    )
    with pytest.raises(ReplayError, match="chain integrity"):
        replay(snap, [a, b])


def test_replay_rejects_split_at_invalid_offset() -> None:
    snap = _snapshot()
    op = SplitOp(
        **_envelope("op_split_invalid"),
        payload=SplitPayload(block_id="blk_a", char_offset=99),
    )
    with pytest.raises(ReplayError, match="out of"):
        replay(snap, [op])


def test_replay_rejects_op_referencing_missing_block() -> None:
    snap = _snapshot()
    op = MergeOp(
        **_envelope("op_missing_block"),
        payload=MergePayload(block_ids=["blk_a", "blk_does_not_exist"]),
    )
    with pytest.raises(ReplayError, match="not found"):
        replay(snap, [op])


def test_replay_raw_xml_override_sets_topic_dita_xml() -> None:
    snap = _snapshot()
    new_xml = "<concept id='tpc_one'><title>One</title></concept>"
    op = RawXmlOverrideOp(
        **_envelope("op_xml_1"),
        payload=RawXmlOverridePayload(topic_id="tpc_one", xml=new_xml),
    )
    state = replay(snap, [op])
    by_id = {t.topic_id: t for t in state.topics}
    assert by_id["tpc_one"].dita_xml == new_xml
    assert by_id["tpc_two"].dita_xml is None
    assert state.ops_applied == ["op_xml_1"]


def test_replay_raw_xml_override_rejects_unknown_topic() -> None:
    snap = _snapshot()
    op = RawXmlOverrideOp(
        **_envelope("op_xml_2"),
        payload=RawXmlOverridePayload(topic_id="tpc_missing", xml="<x/>"),
    )
    with pytest.raises(ReplayError, match="raw_xml_override"):
        replay(snap, [op])


def test_raw_xml_override_op_pins_is_lossy_true() -> None:
    """The discriminated-union variant carries `is_lossy: Literal[True]`
    so any caller (or future serialization round-trip) that omits or
    falsifies the flag fails Pydantic validation. Workbench warning UI
    keys off this field."""
    op = RawXmlOverrideOp(
        **_envelope("op_xml_lossy"),
        payload=RawXmlOverridePayload(topic_id="tpc_one", xml="<x/>"),
    )
    assert op.is_lossy is True
    with pytest.raises(ValidationError):
        RawXmlOverrideOp(
            **_envelope("op_xml_lossy_bad"),
            payload=RawXmlOverridePayload(topic_id="tpc_one", xml="<x/>"),
            is_lossy=False,  # type: ignore[arg-type]
        )


def test_merge_payload_requires_at_least_two_blocks() -> None:
    with pytest.raises(ValidationError):
        MergePayload(block_ids=["blk_a"])


def test_split_payload_requires_positive_offset() -> None:
    with pytest.raises(ValidationError):
        SplitPayload(block_id="blk_a", char_offset=0)


# ---------------------------------------------------------------------------
# Schema compliance — every constructed op validates against the JSON schema
# ---------------------------------------------------------------------------


def test_every_op_variant_validates_against_schema() -> None:
    schema = _load_schema()
    validator = jsonschema.Draft202012Validator(schema)
    samples: list[MergeOp | SplitOp | MoveOp | RetypeOp | RenameOp | RawXmlOverrideOp] = [
        MergeOp(
            **_envelope("op_s_merge"),
            payload=MergePayload(block_ids=["blk_a", "blk_b"]),
        ),
        SplitOp(
            **_envelope("op_s_split"),
            payload=SplitPayload(block_id="blk_a", char_offset=3),
        ),
        MoveOp(
            **_envelope("op_s_move"),
            payload=MovePayload(block_id="blk_a", target_topic_id="tpc_two"),
        ),
        RetypeOp(
            **_envelope("op_s_retype"),
            payload=RetypePayload(topic_id="tpc_one", topic_type="reference"),
        ),
        RenameOp(
            **_envelope("op_s_rename"),
            payload=RenamePayload(topic_id="tpc_one", title="X", short_desc="Y"),
        ),
        RawXmlOverrideOp(
            **_envelope("op_s_xml"),
            payload=RawXmlOverridePayload(topic_id="tpc_one", xml="<concept/>"),
        ),
    ]
    failures: list[str] = []
    for op in samples:
        dumped = op.model_dump(mode="json")
        errors = list(validator.iter_errors(dumped))
        if errors:
            failures.append(
                f"{op.op_type}: "
                + "; ".join(f"{list(e.absolute_path)}: {e.message}" for e in errors)
            )
    assert not failures, "schema violations:\n" + "\n".join(failures)


def test_adapter_routes_dict_to_correct_variant() -> None:
    """The discriminated union picks the right class based on op_type."""
    payload_dict = {
        **_envelope("op_adp"),
        "op_type": "rename",
        "payload": {
            "topic_id": "tpc_one",
            "title": "From dict",
            "short_desc": None,
        },
    }
    parsed = EditOperationAdapter.validate_python(payload_dict)
    assert isinstance(parsed, RenameOp)
    assert parsed.payload.title == "From dict"


def test_adapter_rejects_unknown_op_type() -> None:
    payload_dict = {
        **_envelope("op_unknown"),
        "op_type": "annihilate",  # not in the enum
        "payload": {},
    }
    with pytest.raises(ValidationError):
        EditOperationAdapter.validate_python(payload_dict)
