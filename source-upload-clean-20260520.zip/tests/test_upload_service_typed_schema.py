"""Phase 4 D4.1 — upload-service typed schema smoke test.

These tests pin the foundation D4.2 (repos) builds on:

  1. `up_db.get_engine()` creates a SQLite file with all 5 owned
     tables and the indexes declared on the SQLAlchemy models.
  2. Each model's `to_envelope()` round-trips through a raw upsert
     using SQLAlchemy's session API (sanity check that the column
     list and JSON serialization are consistent).
  3. The Alembic 0001 migration produces the same schema as
     `Base.metadata.create_all`. This catches drift between the
     model definitions and the migration script — a real risk because
     both live in lockstep and a future column edit to one without
     the other ships a broken migration.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest
from sqlalchemy import create_engine, inspect

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "upload-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


@pytest.fixture
def fresh_db(tmp_path, monkeypatch):
    """Return a clean upload-service SQLite engine + reset cache."""
    from up_db import reset_engine_cache

    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    reset_engine_cache()
    yield tmp_path
    reset_engine_cache()


def test_engine_creates_all_five_owned_tables(fresh_db) -> None:
    from up_db import get_engine

    engine = get_engine()
    table_names = set(inspect(engine).get_table_names())
    expected = {
        "documents",
        "upload_sessions",
        "jobs",
        "artifact_registry",
        "exports",
    }
    assert expected.issubset(table_names), (
        f"missing tables: {expected - table_names}"
    )


def test_models_round_trip_through_session(fresh_db) -> None:
    """One upsert + read-back per table. Catches column/JSON drift."""
    from up_db import (
        ArtifactRegistryEntry,
        Document,
        Export,
        Job,
        UploadSession,
        get_engine,
        session_scope,
    )

    get_engine()
    now = "2026-05-12T00:00:00Z"

    document_row = Document(
        document_id="doc_smoke",
        tenant_id="ten_local",
        business_unit_id="bu_docs_ops",
        project_id="prj_smoke",
        filename="smoke.txt",
        content_type="text/plain",
        source_hash="hash_smoke",
        status="ready_for_review",
        job_ids=["job_smoke"],
        topic_ids=[],
        original_artifact={"artifact_id": "art_orig"},
        manifest={"document_id": "doc_smoke"},
        manifest_artifact=None,
        artifacts={"original": {"artifact_id": "art_orig"}},
        latest_artifacts={"source-blocks.jsonl": "art_blocks"},
        source_quality={"overall_confidence": 95},
        extraction={"stage": "markdown_complete"},
        upload_id=None,
        created_at=now,
    )
    upload_row = UploadSession(
        upload_id="upl_smoke",
        tenant_id="ten_local",
        organization_id="org_local",
        business_unit_id="bu_docs_ops",
        project_id="prj_smoke",
        filename="smoke.txt",
        content_type="text/plain",
        size_bytes=12,
        status="created",
        parts=[],
        received_bytes=0,
        created_by="usr_admin",
        created_at=now,
    )
    job_row = Job(
        job_id="job_smoke",
        business_unit_id="bu_docs_ops",
        project_id="prj_smoke",
        document_id="doc_smoke",
        stage="pipeline",
        status="completed",
        events=["document.uploaded"],
        created_at=now,
    )
    artifact_row = ArtifactRegistryEntry(
        artifact_id="art_smoke",
        project_id="prj_smoke",
        document_id="doc_smoke",
        name="source-blocks.jsonl",
        artifact_version=1,
        version=1,
        content_type="application/x-jsonlines",
        size_bytes=120,
        hash="h_smoke",
        sha256="h_smoke",
        path="/tmp/h_smoke",
        producer="extraction-service",
        created_by="usr_admin",
        created_at=now,
        previous_version_id=None,
    )
    export_row = Export(
        export_id="exp_smoke",
        business_unit_id="bu_docs_ops",
        project_id="prj_smoke",
        status="completed",
        topic_count=3,
        artifact={"artifact_id": "art_smoke_zip"},
        logs=["Packaged 3 topic(s)"],
    )

    with session_scope() as session:
        session.add_all([document_row, upload_row, job_row, artifact_row, export_row])

    with session_scope() as session:
        from sqlalchemy import select

        doc = session.scalars(select(Document)).one()
        assert doc.to_envelope()["document_id"] == "doc_smoke"
        assert doc.to_envelope()["latest_artifacts"] == {
            "source-blocks.jsonl": "art_blocks"
        }

        upl = session.scalars(select(UploadSession)).one()
        assert upl.to_envelope()["upload_id"] == "upl_smoke"
        assert upl.to_envelope()["received_bytes"] == 0

        job = session.scalars(select(Job)).one()
        assert job.to_envelope()["events"] == ["document.uploaded"]

        art = session.scalars(select(ArtifactRegistryEntry)).one()
        env = art.to_envelope()
        # JsonStore wire shape duplicates artifact_id as `id` — preserved.
        assert env["artifact_id"] == env["id"] == "art_smoke"

        exp = session.scalars(select(Export)).one()
        assert exp.to_envelope()["topic_count"] == 3


def test_alembic_migration_matches_create_all_schema(tmp_path) -> None:
    """The Alembic 0001 migration MUST produce the same schema as
    Base.metadata.create_all. If a future PR edits the model but
    forgets the migration (or vice versa), this test fails — catching
    schema drift at CI time instead of in production rollout."""
    import importlib.util

    from up_db import Base

    # Apply create_all to engine A.
    engine_a = create_engine(f"sqlite:///{tmp_path}/from_create_all.sqlite3")
    Base.metadata.create_all(engine_a)
    create_all_tables = _capture_schema(engine_a)

    # Apply Alembic 0001 to engine B.
    migration_path = (
        REPO_ROOT
        / "services"
        / "upload-service"
        / "alembic"
        / "versions"
        / "0001_upload_typed.py"
    )
    spec = importlib.util.spec_from_file_location("alembic_0001", migration_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    engine_b = create_engine(f"sqlite:///{tmp_path}/from_alembic.sqlite3")
    with engine_b.begin() as conn:
        # Alembic's op.* helpers route through the active context's
        # connection. Bind the migration module to engine_b for upgrade.
        from alembic.migration import MigrationContext
        from alembic.operations import Operations

        ctx = MigrationContext.configure(conn)
        ops = Operations(ctx)
        # Swap the global op binding only for this call window.
        module.op = ops  # type: ignore[attr-defined]
        module.upgrade()

    alembic_tables = _capture_schema(engine_b)

    assert alembic_tables == create_all_tables, (
        "Alembic migration produces different schema than "
        "Base.metadata.create_all. Update one to match the other."
    )


def _capture_schema(engine: Any) -> dict[str, dict[str, set[str]]]:
    """Per-table {'columns': set(), 'indexes': set()} snapshot."""
    insp = inspect(engine)
    out: dict[str, dict[str, set[str]]] = {}
    for table in sorted(insp.get_table_names()):
        cols = {col["name"] for col in insp.get_columns(table)}
        idx = {idx["name"] for idx in insp.get_indexes(table) if idx.get("name")}
        out[table] = {"columns": cols, "indexes": idx}
    return out
