"""Architecture lock — Phase 2 B3 of plans/architecture-hardening.md.

Every artifact contract under `contracts/artifacts/*.schema.json` MUST
have at least one test that validates real producer output against it.

The B3 audit found that contracts were "first-class but only a subset of
artifacts had producer→schema roundtrip tests." Without a coverage
matrix, a new contract can be added (or an old one ignored) and the
gates silently leave that artifact unvalidated until a production
incident reveals the schema drift.

This test:

  (1) Walks `contracts/artifacts/` and finds every `*.schema.json`.
  (2) For each, asserts at least one test file in `tests/` contains the
      schema's basename as a literal string AND imports `jsonschema`
      (the canonical validator used in this repo).
  (3) Pins the schema inventory in a separate test so adding a new
      contract requires a deliberate update — not a silent slip-through.

Two intentional weaknesses of the heuristic and why they're acceptable:

  - A test could mention a schema by name without actually validating
    (e.g., a doc-style test). Catching that requires AST analysis of
    every jsonschema.validate call site — over-engineered for a coverage
    gate. In practice, mentioning a schema by name AND importing
    jsonschema is a strong signal of intent.
  - A test could validate against a schema via a programmatically
    constructed path (`SCHEMA_DIR / f"{name}.schema.json"`). This test
    matches the basename anywhere in the file, so the string `"source-
    block.schema.json"` in a comment counts. That's by design — comments
    are written by humans claiming coverage, and the architecture lock
    holds them to it.

The companion file `tests/test_artifact_schema_compliance.py` provides
the producer-roundtrip validation for the four artifacts that had no
coverage before B3.
"""

from __future__ import annotations

from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = ROOT / "contracts" / "artifacts"
TESTS_DIR = ROOT / "tests"


def _artifact_schemas() -> list[Path]:
    return sorted(SCHEMA_DIR.glob("*.schema.json"))


def _validating_test_files() -> list[tuple[Path, str]]:
    """Return (test_path, contents) for every test file that imports
    `jsonschema` — the canonical validator. Reading once amortizes the
    file-system traversal across the parametrize."""
    pairs: list[tuple[Path, str]] = []
    for test_path in sorted(TESTS_DIR.rglob("test_*.py")):
        try:
            text = test_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if "jsonschema" not in text:
            continue
        pairs.append((test_path, text))
    return pairs


@pytest.mark.parametrize(
    "schema_path",
    _artifact_schemas(),
    ids=lambda p: p.name if isinstance(p, Path) else str(p),
)
def test_artifact_schema_has_validating_test(schema_path: Path) -> None:
    """Every contract under `contracts/artifacts/` is exercised by a test
    that imports `jsonschema` and names the schema file.

    Failure mode: a new schema was added without a producer test, OR an
    existing schema lost its test (renamed file, deleted test, etc.).
    Either case is a real coverage gap.
    """
    if not isinstance(schema_path, Path):
        return
    name = schema_path.name
    matches = [
        test_path
        for test_path, text in _validating_test_files()
        if name in text
    ]
    assert matches, (
        f"contract {name} is not validated by any test in tests/. "
        f"Every schema under contracts/artifacts/ must have at least one "
        f"test that (a) imports jsonschema and (b) names the schema file. "
        f"Add a producer-roundtrip test mirroring "
        f"tests/test_artifact_schema_compliance.py — do not delete this "
        f"architecture lock to bypass."
    )


def test_artifact_schema_inventory_pinned() -> None:
    """Pin the set of artifact schemas so a silent addition can't slip
    past the coverage check. When a new contract is added under
    `contracts/artifacts/`, append it here in the same commit AND add
    its producer-roundtrip test."""
    actual = {path.name for path in _artifact_schemas()}
    expected = {
        "asset-manifest.schema.json",
        "extraction-quality.schema.json",
        "source-block.schema.json",
        "source-line.schema.json",
        "structure-tree.schema.json",
        "style-profile.schema.json",
    }
    assert actual == expected, (
        f"Artifact schema inventory drift. Expected {sorted(expected)}, "
        f"got {sorted(actual)}. Update this test deliberately when adding "
        f"or removing a contract — and make sure a producer-roundtrip "
        f"test exists for any new schema."
    )
