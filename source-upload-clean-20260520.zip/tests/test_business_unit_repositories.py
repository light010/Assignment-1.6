"""Repository contract tests for business-unit-service — Phase 4 D3.2.

These exercise the SQL-backed BU repositories directly (no FastAPI,
no service-app fixture). Endpoint-level tests live in
`test_week2_services.py` and continue to exercise the production wire
contract once D3.3 swaps the storage backend.

Invariants pinned:

  1. upsert is idempotent on the natural key (business_unit_id,
     project_id, membership_id, etc.) — a second upsert of the same
     id updates in place, never duplicates.
  2. Membership/favorite upserts are idempotent on the COMPOUND key
     (business_unit_id, user_id) / (project_id, user_id) even if the
     `membership_id`/`favorite_id` field differs — UNIQUE constraint
     enforces it.
  3. List filters honour tenant/business-unit scope and the
     include_archived flag.
  4. Project.append_document_id is idempotent on the document_id and
     order-preserving (the denorm shape upload-service relies on).
  5. Wire shape (`to_envelope()`) matches the JsonStore record shape,
     so the route layer can swap storage backends transparently.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


@pytest.fixture
def repos(tmp_path, monkeypatch):
    """Fresh SQLite-backed BU repositories per test.

    The engine cache is keyed by URL, and tmp_path makes the URL
    unique per test — so each test sees a clean schema without an
    explicit teardown. `reset_engine_cache` is called for predictable
    behavior across re-runs in the same Python process."""
    from bu_db import reset_engine_cache
    from bu_repositories import (
        BusinessUnitFavoriteRepository,
        BusinessUnitMembershipRepository,
        BusinessUnitRepository,
        OrganizationRepository,
        ProjectMembershipRepository,
        ProjectRepository,
        TenantRepository,
    )

    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    reset_engine_cache()
    url = f"sqlite:///{tmp_path}/business-unit-service.sqlite3"
    return {
        "tenant": TenantRepository(database_url=url),
        "organization": OrganizationRepository(database_url=url),
        "business_unit": BusinessUnitRepository(database_url=url),
        "bu_membership": BusinessUnitMembershipRepository(database_url=url),
        "bu_favorite": BusinessUnitFavoriteRepository(database_url=url),
        "project": ProjectRepository(database_url=url),
        "project_membership": ProjectMembershipRepository(database_url=url),
    }


def _bu_payload(business_unit_id: str = "bu_test", **overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "business_unit_id": business_unit_id,
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "name": "Test BU",
        "description": "test description",
        "owner_team": "team-x",
        "region": "Global",
        "status": "active",
        "policy": {"target_dita_version": "1.3"},
        "created_by": "usr_admin",
        "created_at": "2026-05-11T00:00:00Z",
        "updated_at": "2026-05-11T00:00:00Z",
        "deleted_at": None,
    }
    base.update(overrides)
    return base


def _project_payload(project_id: str = "prj_test", **overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "project_id": project_id,
        "business_unit_id": "bu_test",
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "name": "Test Project",
        "description": None,
        "status": "active",
        "deleted_at": None,
        "document_ids": [],
        "conversion_profile": {"target_dita_version": "1.3"},
        "created_by": "usr_admin",
        "created_at": "2026-05-11T00:00:00Z",
        "updated_at": "2026-05-11T00:00:00Z",
    }
    base.update(overrides)
    return base


def test_business_unit_upsert_is_idempotent_on_natural_key(repos) -> None:
    repos["business_unit"].upsert(_bu_payload(name="Original"))
    repos["business_unit"].upsert(_bu_payload(name="Renamed"))
    units = repos["business_unit"].list_for_tenant("ten_local")
    assert len(units) == 1
    assert units[0]["name"] == "Renamed"


def test_business_unit_list_for_tenant_excludes_archived_by_default(repos) -> None:
    repos["business_unit"].upsert(_bu_payload("bu_active", status="active"))
    repos["business_unit"].upsert(_bu_payload("bu_archived", status="archived"))
    visible = repos["business_unit"].list_for_tenant("ten_local")
    with_archived = repos["business_unit"].list_for_tenant(
        "ten_local", include_archived=True
    )
    assert {u["business_unit_id"] for u in visible} == {"bu_active"}
    assert {u["business_unit_id"] for u in with_archived} == {"bu_active", "bu_archived"}


def test_bu_membership_upsert_idempotent_on_compound_key(repos) -> None:
    """Second upsert with same (bu, user) but DIFFERENT membership_id
    must not duplicate. This is the UNIQUE constraint doing its job."""
    repos["bu_membership"].upsert({
        "membership_id": "mbm_legacy_format",
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": "bu_test",
        "user_id": "usr_admin",
        "role": "bu_admin",
        "created_at": "2026-05-11T00:00:00Z",
    })
    # Same (bu, user) but different membership_id — repo dedups on the
    # compound key, so the new role replaces the old in place.
    repos["bu_membership"].upsert({
        "membership_id": "bum_bu_test_usr_admin",
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": "bu_test",
        "user_id": "usr_admin",
        "role": "reviewer",
        "created_at": "2026-05-12T00:00:00Z",
    })
    rows = repos["bu_membership"].list_for_business_unit("bu_test")
    assert len(rows) == 1
    assert rows[0]["role"] == "reviewer"


def test_bu_membership_get_role_returns_none_for_unknown(repos) -> None:
    repos["bu_membership"].upsert({
        "membership_id": "bum_bu_test_usr_admin",
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": "bu_test",
        "user_id": "usr_admin",
        "role": "bu_admin",
        "created_at": "2026-05-11T00:00:00Z",
    })
    assert repos["bu_membership"].get_role("bu_test", "usr_admin") == "bu_admin"
    assert repos["bu_membership"].get_role("bu_test", "usr_other") is None
    assert repos["bu_membership"].get_role("bu_other", "usr_admin") is None


def test_bu_favorite_remove_returns_false_when_absent(repos) -> None:
    payload = {
        "favorite_id": "buf_bu_test_usr_admin",
        "business_unit_id": "bu_test",
        "user_id": "usr_admin",
        "created_at": "2026-05-11T00:00:00Z",
    }
    repos["bu_favorite"].upsert(payload)
    assert repos["bu_favorite"].remove(business_unit_id="bu_test", user_id="usr_admin")
    # Second remove is a no-op signal, not an error.
    assert not repos["bu_favorite"].remove(business_unit_id="bu_test", user_id="usr_admin")


def test_project_upsert_preserves_system_managed_when_present(repos) -> None:
    repos["project"].upsert(_project_payload("prj_system", system_managed=True))
    repos["project"].upsert(_project_payload("prj_hand"))
    rows = repos["project"].list_for_business_unit("bu_test")
    rows_by_id = {p["project_id"]: p for p in rows}
    assert rows_by_id["prj_system"].get("system_managed") is True
    # Hand-created projects don't carry the field — wire shape stays
    # clean, no always-null leakage.
    assert "system_managed" not in rows_by_id["prj_hand"]


def test_project_append_document_id_is_idempotent(repos) -> None:
    repos["project"].upsert(_project_payload("prj_doc_index"))
    repos["project"].append_document_id("prj_doc_index", "doc_a")
    repos["project"].append_document_id("prj_doc_index", "doc_a")  # duplicate
    repos["project"].append_document_id("prj_doc_index", "doc_b")
    project = repos["project"].get("prj_doc_index")
    assert project is not None
    assert project["document_ids"] == ["doc_a", "doc_b"]


def test_project_append_document_id_unknown_project_returns_none(repos) -> None:
    assert repos["project"].append_document_id("prj_does_not_exist", "doc_x") is None


def test_project_list_for_business_unit_excludes_archived_by_default(repos) -> None:
    repos["project"].upsert(_project_payload("prj_active", status="active"))
    repos["project"].upsert(_project_payload("prj_archived", status="archived"))
    visible = repos["project"].list_for_business_unit("bu_test")
    with_archived = repos["project"].list_for_business_unit(
        "bu_test", include_archived=True
    )
    assert {p["project_id"] for p in visible} == {"prj_active"}
    assert {p["project_id"] for p in with_archived} == {"prj_active", "prj_archived"}


def test_project_membership_upsert_idempotent_on_compound_key(repos) -> None:
    payload = {
        "membership_id": "mem_prj_test_usr_admin",
        "project_id": "prj_test",
        "business_unit_id": "bu_test",
        "user_id": "usr_admin",
        "role": "project_admin",
        "created_at": "2026-05-11T00:00:00Z",
    }
    repos["project_membership"].upsert(payload)
    repos["project_membership"].upsert({**payload, "role": "editor"})
    rows = repos["project_membership"].list_for_project("prj_test")
    assert len(rows) == 1
    assert rows[0]["role"] == "editor"


def test_tenant_repository_seed_roundtrip(repos) -> None:
    repos["tenant"].upsert(tenant_id="ten_local", name="Local Tenant")
    repos["organization"].upsert(
        organization_id="org_local", tenant_id="ten_local", name="DITAgen Local"
    )
    assert repos["tenant"].get("ten_local") == {
        "tenant_id": "ten_local",
        "name": "Local Tenant",
    }
    assert repos["tenant"].list_all() == [
        {"tenant_id": "ten_local", "name": "Local Tenant"}
    ]
    orgs = repos["organization"].list_for_tenant("ten_local")
    assert orgs == [
        {
            "organization_id": "org_local",
            "tenant_id": "ten_local",
            "name": "DITAgen Local",
        }
    ]
