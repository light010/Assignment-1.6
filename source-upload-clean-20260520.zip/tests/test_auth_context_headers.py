from __future__ import annotations

from starlette.requests import Request

from ditagen_common.auth import context_headers


USER = {
    "user_id": "usr_admin",
    "tenant_id": "ten_local",
    "organization_id": "org_local",
}


def _request(path: str, headers: list[tuple[bytes, bytes]] | None = None) -> Request:
    return Request(
        {
            "type": "http",
            "method": "GET",
            "path": path.split("?", 1)[0],
            "query_string": path.split("?", 1)[1].encode("utf-8") if "?" in path else b"",
            "headers": headers or [],
            "path_params": {},
        }
    )


def test_context_headers_forwards_access_token_query_as_bearer() -> None:
    headers = context_headers(_request("/v1/documents/doc/source-file?access_token=query-token"), USER)

    assert headers["Authorization"] == "Bearer query-token"


def test_context_headers_prefers_authorization_header_over_query_token() -> None:
    request = _request(
        "/v1/documents/doc/source-file?access_token=query-token",
        headers=[(b"authorization", b"Bearer header-token")],
    )

    headers = context_headers(request, USER)

    assert headers["Authorization"] == "Bearer header-token"
