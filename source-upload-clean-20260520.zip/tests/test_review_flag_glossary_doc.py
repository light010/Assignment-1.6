from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "contracts/artifacts/source-block.schema.json"
GUIDELINES_PATH = ROOT / "docs/product/workbench-extraction-review-guidelines.md"


def test_review_flag_glossary_matches_schema_enum() -> None:
    schema = json.loads(SCHEMA_PATH.read_text())
    schema_codes = set(schema["$defs"]["reviewFlag"]["properties"]["code"]["enum"])
    content = GUIDELINES_PATH.read_text()
    section = content.split("## Review Flag Glossary", 1)[1].split("\n## ", 1)[0]
    doc_codes = re.findall(r"^\|\s*`([A-Z0-9_]+)`\s*\|", section, flags=re.MULTILINE)

    assert len(doc_codes) == len(set(doc_codes))
    assert set(doc_codes) == schema_codes


def test_review_flag_glossary_rows_have_actions() -> None:
    content = GUIDELINES_PATH.read_text()
    section = content.split("## Review Flag Glossary", 1)[1].split("\n## ", 1)[0]
    rows = [
        line
        for line in section.splitlines()
        if line.startswith("| `")
    ]

    assert rows
    for row in rows:
        cells = [cell.strip() for cell in row.strip("|").split("|")]
        assert len(cells) == 4
        assert cells[1] in {"info", "warning", "error"}
        assert cells[2]
        assert cells[3]
