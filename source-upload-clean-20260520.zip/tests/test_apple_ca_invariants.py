"""Apple CA invariant tests + golden fixture (Phase 9).

Locks document-shape invariants that survive model changes:
  - CONTACTS_TABLE_IS_ONE_BLOCK: the client-contacts table extracts as a
    single table_id with all rows sharing it.
  - GARNISHMENT_HAS_OWN_TOPIC: the "Apple CA Running Garnishment" L2
    heading produces its own topic candidate.
  - EVERY_BLOCK_REFERENCED_ONCE: every non-running-content block appears
    in exactly one topic candidate's source_block_ids (no orphans, no
    duplicates).
  - NO_TOPIC_CROSSES_H1: every topic candidate's source blocks share the
    same H1 ancestor in the structure tree (or live above the first H1).
  - EXTRACTION_IS_DETERMINISTIC: extracting Apple CA twice produces
    block-identical output (deterministic per-block ids derived from
    filename+position+text prefix).
  - APPLE_CA_TOPIC_PLAN_GOLDEN: the fixture-deterministic topic plan
    matches a committed golden file. Updates require explicit
    `--update-apple-ca-golden` flag.

The pipeline runs end-to-end against the real extraction service +
fixture-deterministic LLM gateway provider, so these tests catch real
regressions in extraction OR analysis without testing the LLM itself.
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
GOLDEN_DIR = REPO_ROOT / "tests" / "golden"
GOLDEN_TOPIC_PLAN = GOLDEN_DIR / "apple_ca_topic_plan.json"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
# The `--update-apple-ca-golden` CLI flag is registered in tests/conftest.py
# (pytest only loads addoption hooks from conftest, not test files).


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_phase9"}


def _extract_apple_ca(service_app_factory, apple_ca_docx_bytes: bytes) -> dict[str, Any]:
    """Run extraction-service against Apple CA. Returns the status dict
    (with artifact refs) so callers can pull source-blocks etc."""
    from ditagen_common.artifacts import write_artifact
    from ditagen_common.store import JsonStore

    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "phase9_extract_apple_ca"
    )
    client = TestClient(app)

    project_id = "prj_p9"
    business_unit_id = "bu_docs_ops"
    document_id = "doc_p9_apple_ca"
    original_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name=f"original/{document_id}.docx",
        content=apple_ca_docx_bytes,
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        store=JsonStore(),
        created_by="usr_admin",
        producer="upload-service",
    )
    response = client.post(
        "/internal/extractions",
        headers=_auth_headers(),
        json={
            "document_id": document_id,
            "project_id": project_id,
            "business_unit_id": business_unit_id,
            "filename": f"{document_id}.docx",
            "content_type": original_ref["content_type"],
            "artifact_path": original_ref["path"],
            "request_id": "req_p9_apple_ca",
            "requested_by": "usr_admin",
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def _read_jsonl(ref: dict[str, Any]) -> list[dict[str, Any]]:
    from ditagen_common.artifacts import read_artifact_text

    return [
        json.loads(line)
        for line in read_artifact_text(ref).splitlines()
        if line.strip()
    ]


@pytest.fixture
def apple_ca_pipeline(
    apple_ca_docx_bytes: bytes, service_app_factory, tmp_jsonstore
) -> dict[str, Any]:
    """One pipeline run shared across structural invariant tests.

    Returns:
        source_blocks: list of block dicts.
        structure_tree: dict from the extractor.
        topic_plan: fixture-deterministic build_topic_plan output.
        h1_block_ids: ordered list of H1 block_ids (for ancestry tests).
    """
    from ditagen_common.artifacts import read_artifact_json
    from ditagen_common.pipeline import build_topic_plan

    status = _extract_apple_ca(service_app_factory, apple_ca_docx_bytes)
    by_name = {ref["name"]: ref for ref in status["artifacts"]}
    source_blocks = _read_jsonl(by_name["source-blocks.jsonl"])
    structure_tree = read_artifact_json(by_name["structure-tree.json"])
    topic_plan = build_topic_plan(
        document_id=status["document_id"],
        source_blocks=source_blocks,
        structure_tree=structure_tree,
        model_name="fixture-deterministic",
    )
    h1_block_ids = [
        b["block_id"]
        for b in source_blocks
        if b["block_type"] == "heading" and b.get("inferred_level") == 1
    ]
    return {
        "status": status,
        "source_blocks": source_blocks,
        "structure_tree": structure_tree,
        "topic_plan": topic_plan,
        "h1_block_ids": h1_block_ids,
    }


# ---------------------------------------------------------------------------
# Structural invariants
# ---------------------------------------------------------------------------


def test_contacts_table_is_one_block(apple_ca_pipeline) -> None:
    """Apple CA's client-contacts table extracts as a single table_id
    with all rows sharing it. A regression here would mean python-docx
    or our body-walker split a real table into multiple — exactly the
    failure ORPHAN_TABLE_ROW (Phase 5 flag) was designed to catch."""
    table_rows = [
        b for b in apple_ca_pipeline["source_blocks"]
        if b["block_type"] == "table_row"
    ]
    by_table: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in table_rows:
        tid = row.get("table_id")
        assert tid, f"table_row {row['block_id']!r} missing table_id"
        by_table[tid].append(row)

    # The client-contacts table has cells like 'Name | Client Contact'
    # in its header row.
    contacts_table = next(
        (
            (tid, rows)
            for tid, rows in by_table.items()
            if any("Client Contact" in r["text"] for r in rows)
        ),
        None,
    )
    assert contacts_table is not None, (
        "Apple CA must contain a contacts table whose header row mentions "
        "'Client Contact'"
    )
    tid, rows = contacts_table
    # All rows share the same table_id (the invariant).
    assert all(r["table_id"] == tid for r in rows)
    # Row indices form a contiguous 1..N sequence (no missing rows).
    indices = sorted(r["row_index"] for r in rows if r.get("row_index"))
    assert indices == list(range(1, len(indices) + 1))


def test_garnishment_has_own_topic(apple_ca_pipeline) -> None:
    """The 'Apple CA Running Garnishment' L2 heading produces its own
    topic candidate. If a future heading-detection change groups it
    under a parent topic by accident, this test fails loudly."""
    blocks = apple_ca_pipeline["source_blocks"]
    garnishment_heading = next(
        (
            b for b in blocks
            if b["block_type"] == "heading"
            and "garnishment" in b["text"].lower()
        ),
        None,
    )
    assert garnishment_heading is not None, (
        "Apple CA must have a heading mentioning 'Garnishment'"
    )
    plan = apple_ca_pipeline["topic_plan"]
    garnishment_topic = next(
        (
            tc for tc in plan["topic_candidates"]
            if garnishment_heading["block_id"] in tc["source_block_ids"]
        ),
        None,
    )
    assert garnishment_topic is not None, (
        f"no topic candidate references the Garnishment heading "
        f"{garnishment_heading['block_id']!r}; candidates: "
        f"{[(tc['title'], tc['source_block_ids'][:3]) for tc in plan['topic_candidates']]}"
    )
    # The topic title should be derived from the heading.
    assert "garnishment" in garnishment_topic["title"].lower()


def test_every_block_referenced_exactly_once(apple_ca_pipeline) -> None:
    """The union of every topic candidate's source_block_ids must cover
    every non-running-content source block, and each block must appear
    exactly once. No orphans (would be lost in DITA output), no
    duplicates (would be exported twice)."""
    blocks = apple_ca_pipeline["source_blocks"]
    eligible_block_ids = {
        b["block_id"] for b in blocks
        if b["block_type"] not in {"running_header", "running_footer"}
    }
    referenced: list[str] = []
    for tc in apple_ca_pipeline["topic_plan"]["topic_candidates"]:
        referenced.extend(tc["source_block_ids"])
    referenced_counts = Counter(referenced)
    duplicates = {bid: n for bid, n in referenced_counts.items() if n > 1}
    assert not duplicates, f"blocks referenced more than once: {duplicates}"
    referenced_set = set(referenced_counts)
    orphans = eligible_block_ids - referenced_set
    assert not orphans, (
        f"{len(orphans)} eligible block(s) referenced by NO topic — they "
        f"would be lost in DITA export: {sorted(orphans)[:5]}"
    )


def test_no_topic_crosses_h1(apple_ca_pipeline) -> None:
    """Every topic candidate's source blocks share the same H1 ancestor
    (or all live above the first H1). A topic that spans two H1s is
    semantically wrong — H1 is the doc's top-level section boundary."""
    blocks = apple_ca_pipeline["source_blocks"]
    block_order = {b["block_id"]: i for i, b in enumerate(blocks)}
    h1_positions = sorted(
        (block_order[b["block_id"]], b["block_id"])
        for b in blocks
        if b["block_type"] == "heading" and b.get("inferred_level") == 1
    )

    def h1_for_position(pos: int) -> str:
        last = None
        for h1_pos, h1_id in h1_positions:
            if h1_pos <= pos:
                last = h1_id
            else:
                break
        return last or "before_first_h1"

    plan = apple_ca_pipeline["topic_plan"]
    for tc in plan["topic_candidates"]:
        ancestors = {
            h1_for_position(block_order[bid])
            for bid in tc["source_block_ids"]
            if bid in block_order
        }
        assert len(ancestors) <= 1, (
            f"topic candidate {tc['topic_candidate_id']!r} "
            f"({tc['title']!r}) spans multiple H1 ancestors: {ancestors}"
        )


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------


def test_pandoc_projection_is_deterministic(
    apple_ca_docx_bytes, service_app_factory, tmp_jsonstore
) -> None:
    """Step F8 — determinism lock for the pandoc projector.

    Three consecutive Apple CA extractions must produce a byte-identical
    `content.md` artifact. A regression here means the projector is
    leaking non-determinism — examples include:
      - mdformat-gfm not pinned (different pandoc/mdformat versions
        across runs produce different output).
      - Wall-clock or random in the sentinel injection.
      - Order-sensitive iteration over a non-deterministic source.

    Skipped when pandoc OR mdformat is missing — locally the projector
    falls back to `_markdown(...)` via `pandoc_unavailable`, which IS
    deterministic but isn't what this test covers.
    """
    import shutil

    if not shutil.which("pandoc"):
        pytest.skip("pandoc not installed; projector determinism cannot be exercised")
    if not shutil.which("mdformat"):
        pytest.skip("mdformat not installed; projector determinism cannot be exercised")

    hashes: set[str] = set()
    for _ in range(3):
        status = _extract_apple_ca(service_app_factory, apple_ca_docx_bytes)
        content_ref = next(
            a for a in status["artifacts"] if a["name"] == "content.md"
        )
        hashes.add(content_ref["hash"])
    assert len(hashes) == 1, (
        "content.md drifted across 3 consecutive Apple CA extractions; "
        f"saw {len(hashes)} distinct hashes: {hashes}. Pandoc projector "
        "determinism is broken — investigate mdformat-gfm pinning, "
        "version drift, or non-deterministic ordering in source-block "
        "iteration."
    )


def test_apple_ca_extraction_is_deterministic(
    apple_ca_docx_bytes, service_app_factory, tmp_jsonstore
) -> None:
    """Extract Apple CA twice; assert source-blocks.jsonl content is
    byte-identical (block_ids are deterministic functions of
    filename+position+text per `_block_id`). A regression here would
    mean someone introduced wall-clock or random into the extractor."""
    first = _extract_apple_ca(service_app_factory, apple_ca_docx_bytes)
    first_blocks_ref = next(
        a for a in first["artifacts"] if a["name"] == "source-blocks.jsonl"
    )
    second = _extract_apple_ca(service_app_factory, apple_ca_docx_bytes)
    second_blocks_ref = next(
        a for a in second["artifacts"] if a["name"] == "source-blocks.jsonl"
    )
    # write_artifact dedupes content-identical writes (the second call
    # returns the same artifact_id with previous_version_id pointing at
    # the first). That's itself evidence of byte-identical content.
    assert first_blocks_ref["hash"] == second_blocks_ref["hash"], (
        f"source-blocks.jsonl hash drift: "
        f"{first_blocks_ref['hash']} vs {second_blocks_ref['hash']}"
    )


# ---------------------------------------------------------------------------
# Golden topic plan
# ---------------------------------------------------------------------------


def _normalize_topic_plan_for_golden(plan: dict[str, Any]) -> dict[str, Any]:
    """Drop fields that vary between runs (timestamps, artifact_version,
    input_artifact_hashes that depend on snapshot ids) so the golden
    locks the structural shape, not the run metadata."""
    normalized = json.loads(json.dumps(plan))  # deep copy via JSON
    llm_meta = normalized.get("llm_metadata")
    if isinstance(llm_meta, dict):
        llm_meta.pop("input_artifact_hashes", None)
    normalized.pop("artifact_version", None)
    return normalized


def test_apple_ca_topic_plan_matches_golden(
    apple_ca_pipeline, request: pytest.FixtureRequest
) -> None:
    """The fixture-deterministic topic plan for Apple CA matches the
    committed golden file. The golden locks the heading-based grouping
    behavior — any change to `build_topic_plan` that affects topic
    boundaries, titles, or types will fail this test. Use
    `pytest --update-apple-ca-golden` to deliberately update."""
    actual = _normalize_topic_plan_for_golden(apple_ca_pipeline["topic_plan"])

    if request.config.getoption("--update-apple-ca-golden"):
        GOLDEN_DIR.mkdir(exist_ok=True)
        GOLDEN_TOPIC_PLAN.write_text(
            json.dumps(actual, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        pytest.skip("golden updated")

    if not GOLDEN_TOPIC_PLAN.is_file():
        pytest.fail(
            f"Golden file missing at {GOLDEN_TOPIC_PLAN}. Run with "
            f"`--update-apple-ca-golden` to create it."
        )

    expected = json.loads(GOLDEN_TOPIC_PLAN.read_text(encoding="utf-8"))
    if actual != expected:
        # Produce a focused diff: titles + source_block_ids per candidate.
        actual_summary = [
            (tc["topic_candidate_id"], tc["title"], len(tc["source_block_ids"]))
            for tc in actual.get("topic_candidates", [])
        ]
        expected_summary = [
            (tc["topic_candidate_id"], tc["title"], len(tc["source_block_ids"]))
            for tc in expected.get("topic_candidates", [])
        ]
        pytest.fail(
            "Apple CA topic plan drifted from golden. Run with "
            "`--update-apple-ca-golden` if the change is deliberate.\n"
            f"actual    ({len(actual_summary)}): {actual_summary[:5]}\n"
            f"expected  ({len(expected_summary)}): {expected_summary[:5]}\n"
        )
