"""Shared pytest fixtures for the DITAgen test suite.

Phase 0 of the backend root-cause plan
(`plans/logical-whistling-widget.md`) introduces three fixtures:

- `apple_ca_docx_bytes`: loads the Apple CA fixture from
  `DATA/dita_source_docs/DOC/Apple CA (PSC).docx`. Fails loudly if missing
  rather than silently skipping — Apple CA invariant tests in Phase 9 must
  not silently no-op.
- `tmp_jsonstore`: a per-test isolated `JsonStore` rooted at `tmp_path`.
  Replaces ad-hoc `monkeypatch.setenv("DITAGEN_DATA_DIR", ...)` patterns.
- `service_app_factory`: generalizes the `configure` + `load_app` helpers
  duplicated in `test_week2_services.py` and `test_week3_extraction.py`.
  Existing tests keep their local helpers; new tests should use this one.
"""

from __future__ import annotations

import importlib.util
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
APPLE_CA_PATH = REPO_ROOT / "DATA" / "dita_source_docs" / "DOC" / "Apple CA (PSC).docx"


def pytest_addoption(parser: pytest.Parser) -> None:
    """Phase 9 — `--update-apple-ca-golden` rewrites the committed
    golden topic plan. Without the flag the golden test diffs actual
    against committed and fails on drift."""
    parser.addoption(
        "--update-apple-ca-golden",
        action="store_true",
        default=False,
        help="Rewrite tests/golden/apple_ca_topic_plan.json with the fresh "
        "fixture-deterministic topic plan. Use only when the change is "
        "deliberate and the PR description explains why.",
    )


@pytest.fixture
def apple_ca_docx_bytes() -> bytes:
    """Read the Apple CA DOCX fixture into memory.

    Fails the test loudly if the file is absent — invariant tests must not
    silently skip on a missing fixture.
    """
    if not APPLE_CA_PATH.is_file():
        pytest.fail(
            f"Apple CA fixture not found at {APPLE_CA_PATH}. "
            "Phase 9 invariant tests require this file to be present."
        )
    return APPLE_CA_PATH.read_bytes()


@pytest.fixture
def tmp_jsonstore(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """A JsonStore rooted at tmp_path with default in-process service routing.

    Sets the env vars expected by ditagen_common services so any module
    loaded after this fixture is active picks up the isolated state.
    """
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    # Default in-process URLs — services consult these during request_service
    # but stay in-process when DITAGEN_INPROCESS_SERVICES=1.
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    monkeypatch.setenv("DITAGEN_EXTRACTION_SERVICE_URL", "http://extraction-service:8000")
    monkeypatch.setenv("DITAGEN_REVIEW_SERVICE_URL", "http://review-service:8000")
    monkeypatch.setenv("DITAGEN_VALIDATION_SERVICE_URL", "http://validation-service:8000")
    monkeypatch.setenv("DITAGEN_ANALYSIS_SERVICE_URL", "http://analysis-service:8000")
    monkeypatch.setenv("DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000")

    from ditagen_common.store import JsonStore

    return JsonStore()


@pytest.fixture
def service_app_factory(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Callable[[str, str], tuple[Any, Any]]:
    """Returns a callable that loads a service `app/main.py` in-process.

    Usage:
        def test_extraction(service_app_factory):
            app, module = service_app_factory(
                "services/extraction-service/app/main.py",
                "extraction_test",
            )
            client = TestClient(app)
            ...
    """
    # Reuse tmp_jsonstore's env setup without the JsonStore object — keeps
    # the env-prep concentrated in one place.
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    monkeypatch.setenv("DITAGEN_EXTRACTION_SERVICE_URL", "http://extraction-service:8000")
    monkeypatch.setenv("DITAGEN_REVIEW_SERVICE_URL", "http://review-service:8000")
    monkeypatch.setenv("DITAGEN_VALIDATION_SERVICE_URL", "http://validation-service:8000")
    monkeypatch.setenv("DITAGEN_ANALYSIS_SERVICE_URL", "http://analysis-service:8000")
    monkeypatch.setenv("DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000")

    def _load(relative: str, module_name: str) -> tuple[Any, Any]:
        module_path = REPO_ROOT / relative
        if not module_path.is_file():
            pytest.fail(f"Service module not found at {module_path}")
        full_module_name = f"{module_name}_{abs(hash(str(tmp_path)))}"
        app_dir = str(module_path.parent)
        if app_dir not in sys.path:
            sys.path.insert(0, app_dir)
        spec = importlib.util.spec_from_file_location(full_module_name, module_path)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        sys.modules[full_module_name] = module
        spec.loader.exec_module(module)
        return module.app, module

    return _load


_UPLOAD_DOCUMENT_COLUMNS = frozenset(
    {
        "document_id",
        "tenant_id",
        "business_unit_id",
        "project_id",
        "filename",
        "content_type",
        "source_hash",
        "status",
        "extraction_failure_reason",
        "job_ids",
        "topic_ids",
        "original_artifact",
        "manifest",
        "manifest_artifact",
        "artifacts",
        "latest_artifacts",
        "source_quality",
        "extraction",
        "upload_id",
        "topic_plan_approved",
        "created_at",
    }
)


def _upload_seed_document_impl(module: Any, envelope: dict[str, Any]) -> dict[str, Any]:
    """Phase 4 D4.5.b — mirror a test's JsonStore-era document seed
    into the upload-service SQL backend.

    The repo's `upsert(envelope)` calls `Document(**envelope)` directly
    (finding #59 — strict typed surface), so extra keys must be filtered
    out and the `created_at` NOT NULL column must be present. Tests
    that previously did `state["documents"][doc_id] = {...}` via a
    `store.mutate` callback now call this helper *in addition* — the
    state-side seed stays for fields that still live in JsonStore
    (projects, jobs, artifact_registry, topics until later D4.5/D5
    steps); the SQL-side seed is what the route handlers actually
    read after D4.5.b.

    Takes the host service module (so the DocumentRepository instance
    binds to the same upload-service.sqlite3 file the route handlers
    see) and the full JsonStore-style envelope. Returns the persisted
    envelope (post-`to_envelope`).
    """
    payload = {
        key: value for key, value in envelope.items() if key in _UPLOAD_DOCUMENT_COLUMNS
    }
    payload.setdefault("created_at", "2026-05-11T00:00:00Z")
    for json_field in (
        "job_ids",
        "topic_ids",
        "original_artifact",
        "manifest",
        "artifacts",
        "latest_artifacts",
        "source_quality",
        "extraction",
    ):
        if json_field not in payload:
            payload[json_field] = [] if json_field.endswith("_ids") else {}
    return module.DocumentRepository().upsert(payload)


@pytest.fixture
def upload_seed_document() -> Callable[[Any, dict[str, Any]], dict[str, Any]]:
    """Returns the `_upload_seed_document_impl` callable as a fixture so
    tests can request it via dependency injection. See the impl docstring
    for the why."""
    return _upload_seed_document_impl


@pytest.fixture
def audit_events_via_service():
    """Query audit-service for the canonical event list.

    Phase 4 D2.7c — `state["audit_events"]` is no longer a thing.
    Tests that need to assert on emitted audit events must read from
    the audit-service the same way production code does. This helper
    wraps the async list_audit_events for sync tests. The fixture
    relies on `DITAGEN_INPROCESS_SERVICES=1` + `DITAGEN_AUDIT_SERVICE_URL`
    being set (both via `service_app_factory` or `tmp_jsonstore`)."""

    import asyncio

    def _events(headers: dict[str, str]) -> list[dict[str, Any]]:
        from ditagen_common.service_clients import list_audit_events

        response = asyncio.run(list_audit_events(headers=headers))
        return response["events"]

    return _events
