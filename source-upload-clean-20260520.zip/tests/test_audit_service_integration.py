"""Phase 4 D2 architecture lock — `plans/architecture-hardening.md` §D2.

The plan's stated invariant:

  > Architecture lock: tests/test_audit_service_integration.py —
  > POST event, query event-replay, assert it appears once.

Why this is the *closing* lock for the JSONL retirement:

  - The repo unit tests (`test_audit_event_repository.py`) cover the
    SQL primitive in isolation.
  - The replay invariants (`test_event_replay.py`) cover the cursor
    contract under bulk emission.
  - The legacy happy-path (`test_audit_service.py`) covers the
    endpoint shape on a 2-event sequence.

This file adds the *end-to-end* lock: a POST through the public
endpoint must land in the SQL DB, must be visible to the same-tenant
caller via BOTH list and replay endpoints, and must appear *exactly
once*. If the JSONL bridge were ever reintroduced (or a future
backwards-compat shim merged events from two backends), the
once-exactly assertion would break loudly.

The dual-source duplicate hazard is real: pre-D2.5 the audit-service
read merged JSONL + state + repo and de-duped on event_id. That was
intentional during the bridge phase. Post-D2.7 there is one source
and de-dup is no longer load-bearing — but if a future change
reintroduces the merge without restoring the de-dup, this lock
catches it before it ships.
"""

from __future__ import annotations

from typing import Any

from ditagen_common.security import issue_token
from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_d2_lock"}


def _post_event(client: TestClient, action: str) -> dict[str, Any]:
    response = client.post(
        "/internal/audit-events",
        json={
            "action": action,
            "resource_type": "test",
            "resource_id": f"res_{action}",
            "business_unit_id": "bu_docs_ops",
        },
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    return response.json()


def test_d2_post_event_appears_exactly_once_in_list(service_app_factory) -> None:
    """POST one event, GET the list endpoint, assert exactly one match.

    Catches: a dual-write that re-emerges into the list response (the
    JSONL bridge regression class).
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "d2_integration_list_once",
    )
    client = TestClient(app)

    posted = _post_event(client, "d2.lock.list_once")

    response = client.get("/internal/audit-events", headers=_auth_headers())
    assert response.status_code == 200, response.text
    matches = [e for e in response.json()["events"] if e["event_id"] == posted["event_id"]]
    assert len(matches) == 1, (
        f"expected exactly 1 list-endpoint match for event_id={posted['event_id']!r}, "
        f"got {len(matches)}: {matches}"
    )


def test_d2_post_event_appears_exactly_once_in_replay(service_app_factory) -> None:
    """POST one event, walk the replay cursor from 0, assert exactly
    one match. Replay is the consumer-facing API; the duplicate hazard
    there has the worst blast radius (silent double processing)."""
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "d2_integration_replay_once",
    )
    client = TestClient(app)

    posted = _post_event(client, "d2.lock.replay_once")

    response = client.get(
        "/internal/events/since/0", headers=_auth_headers()
    )
    assert response.status_code == 200, response.text
    matches = [e for e in response.json()["events"] if e["event_id"] == posted["event_id"]]
    assert len(matches) == 1, (
        f"expected exactly 1 replay match for event_id={posted['event_id']!r}, "
        f"got {len(matches)}: {matches}"
    )


def test_d2_envelope_shape_is_preserved_across_write_and_read(
    service_app_factory,
) -> None:
    """The on-the-wire envelope must round-trip byte-identically. If a
    future change writes a richer shape and reads it back with a
    flattener, this catches the asymmetry."""
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "d2_integration_envelope",
    )
    client = TestClient(app)

    posted = _post_event(client, "d2.lock.envelope")

    response = client.get("/internal/audit-events", headers=_auth_headers())
    [match] = [
        event for event in response.json()["events"]
        if event["event_id"] == posted["event_id"]
    ]
    for key in (
        "event_id",
        "actor_id",
        "action",
        "resource_type",
        "resource_id",
        "business_unit_id",
        "project_id",
        "metadata",
        "occurred_at",
    ):
        assert match[key] == posted[key], (
            f"envelope mismatch on key={key!r}: "
            f"posted={posted[key]!r}, read-back={match[key]!r}"
        )


def test_d2_jsonl_files_are_no_longer_written(
    service_app_factory, tmp_path
) -> None:
    """POST several events; assert NO `audit-events-*.jsonl` file ever
    appears in DITAGEN_DATA_DIR.

    This is the closing lock that proves the S6 JSONL bridge is gone.
    A regression that reintroduces JSONL writes (even silent fallback)
    fails this test immediately."""
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "d2_integration_no_jsonl",
    )
    client = TestClient(app)

    for i in range(5):
        _post_event(client, f"d2.lock.no_jsonl.{i}")

    jsonl_files = list(tmp_path.glob("audit-events-*.jsonl"))
    assert jsonl_files == [], (
        f"audit-events JSONL files reappeared after D2.7 retirement: "
        f"{[p.name for p in jsonl_files]}. The S6 bridge is supposed to be "
        f"deleted; a writer is reintroducing it. Root-cause the writer."
    )
