from __future__ import annotations

import json
from pathlib import Path

import pytest
from ditagen_common.locator import (
    format_docx_endnote_locator,
    format_docx_footer_locator,
    format_docx_footnote_locator,
    format_docx_header_locator,
    format_docx_nested_table_row_locator,
    format_docx_paragraph_locator,
    format_docx_table_row_locator,
    format_pdf_bbox_locator,
    parse_locator,
    validate_locator,
)

ROOT = Path(__file__).resolve().parents[1]


def locator_cases() -> list[dict]:
    return json.loads((ROOT / "tests/golden/locator-cases.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", locator_cases())
def test_locator_grammar_roundtrip(case: dict) -> None:
    parsed = parse_locator(case["locator"])
    assert parsed.kind == case["kind"]
    assert list(parsed.values) == case["values"]
    assert validate_locator(case["locator"])


@pytest.mark.parametrize("value", ["docx:p:-1", "docx:tbl:1", "pdf:p:0", "docx:hdr:bad section:p:0"])
def test_locator_grammar_rejects_malformed_values(value: str) -> None:
    assert not validate_locator(value)
    with pytest.raises(ValueError):
        parse_locator(value)


def test_locator_formatters() -> None:
    assert format_docx_paragraph_locator(0) == "docx:p:0"
    assert format_docx_table_row_locator(3, 1) == "docx:tbl:3:r:1"
    assert format_docx_nested_table_row_locator(3, 1, 0, 2) == "docx:tbl:3:r:1:tbl:0:r:2"
    assert format_docx_header_locator("section-1", 0) == "docx:hdr:section-1:p:0"
    assert format_docx_footer_locator("section_2", 4) == "docx:ftr:section_2:p:4"
    assert format_docx_footnote_locator(9) == "docx:footnote:9"
    assert format_docx_endnote_locator(10) == "docx:endnote:10"
    assert format_pdf_bbox_locator(2, 10.5, 20, 300, 40.25) == "pdf:p:2:bbox:10.5:20:300:40.25"
