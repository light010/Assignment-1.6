"""Phase 4 D3.4 — state.json → BU service SQL migration lock.

These tests pin the migration script's contract that D3.5 will rely on
when it drops JsonStore reads from the BU service:

  1. Empty / missing state.json must not crash (idempotency edge case).
  2. Full roundtrip: every row written to state.json appears in SQL,
     queryable by the production repos with the matching envelope.
  3. Idempotency: running the migration twice is a no-op on the second
     run — every row is skipped, never duplicated.
  4. Defensive coercion: project_membership envelopes missing
     `business_unit_id`, `tenant_id`, or `organization_id` (Phase 4
     D3.3 finding #8; upload-service boundary leak D3.7) are filled in
     from the matching project envelope.
  5. The script exits non-zero on malformed input (root-level type
     mismatch, missing required natural-key fields) — never silently
     migrates bad data.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))

SCRIPT_PATH = REPO_ROOT / "scripts" / "migrate_business_unit_state.py"


def _run_migration(data_dir: Path) -> subprocess.CompletedProcess[str]:
    """Run the migration as a subprocess so the test exercises the same
    entry point an operator would use — including the env-var
    resolution and the sys.path mutation that the script does at
    import time."""
    return subprocess.run(
        [sys.executable, str(SCRIPT_PATH)],
        env={
            "DITAGEN_DATA_DIR": str(data_dir),
            "PATH": "/usr/bin:/bin",
        },
        capture_output=True,
        text=True,
        check=False,
    )


def _write_state(directory: Path, state: dict[str, Any]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "state.json").write_text(json.dumps(state), encoding="utf-8")


def _seed_state() -> dict[str, Any]:
    """A representative state.json shape covering all 7 collections.

    Includes one project_membership that lacks tenant_id /
    organization_id — the upload-service boundary-leak shape — so the
    coercion path is exercised."""
    return {
        "tenants": [{"tenant_id": "ten_a", "name": "Tenant A"}],
        "organizations": [
            {"organization_id": "org_a", "tenant_id": "ten_a", "name": "Org A"}
        ],
        "business_units": {
            "bu_a": {
                "business_unit_id": "bu_a",
                "tenant_id": "ten_a",
                "organization_id": "org_a",
                "name": "BU A",
                "description": None,
                "owner_team": "Platform",
                "region": "Global",
                "status": "active",
                "policy": {"target_dita_version": "1.3"},
                "created_by": "usr_admin",
                "created_at": "2026-05-01T00:00:00Z",
                "updated_at": "2026-05-01T00:00:00Z",
                "deleted_at": None,
            },
        },
        "business_unit_memberships": {
            "bum_bu_a_usr_admin": {
                "membership_id": "bum_bu_a_usr_admin",
                "tenant_id": "ten_a",
                "organization_id": "org_a",
                "business_unit_id": "bu_a",
                "user_id": "usr_admin",
                "role": "bu_admin",
                "created_at": "2026-05-01T00:00:00Z",
            },
        },
        "business_unit_favorites": {
            "buf_bu_a_usr_admin": {
                "favorite_id": "buf_bu_a_usr_admin",
                "business_unit_id": "bu_a",
                "user_id": "usr_admin",
                "created_at": "2026-05-01T00:00:00Z",
            },
        },
        "projects": {
            "prj_a": {
                "project_id": "prj_a",
                "business_unit_id": "bu_a",
                "tenant_id": "ten_a",
                "organization_id": "org_a",
                "name": "Project A",
                "description": None,
                "status": "active",
                "deleted_at": None,
                "document_ids": ["doc_a", "doc_b"],
                "conversion_profile": {"target_dita_version": "1.3"},
                "created_by": "usr_admin",
                "created_at": "2026-05-01T00:00:00Z",
                "updated_at": "2026-05-01T00:00:00Z",
            },
        },
        "project_memberships": {
            # Upload-service authored shape: missing tenant_id +
            # organization_id (D3.3 finding #7 + D3.7 boundary leak).
            "mem_prj_a_usr_admin": {
                "membership_id": "mem_prj_a_usr_admin",
                "project_id": "prj_a",
                "business_unit_id": "bu_a",
                "user_id": "usr_admin",
                "role": "project_admin",
                "created_at": "2026-05-01T00:00:00Z",
            },
        },
    }


@pytest.fixture
def fresh_state_dir(tmp_path, monkeypatch):
    """A scratch DITAGEN_DATA_DIR. Each test gets its own — the BU
    service engine cache is URL-keyed, so a fresh tmp_path is a fresh
    SQLite file.

    DITAGEN_DATA_DIR is set in the *test* process too (not just the
    subprocess) so that production repos instantiated post-migration
    in the test resolve to the same SQLite file the script wrote.
    `reset_engine_cache()` runs before each test to clear leftover
    Engine handles bound to a prior tmp_path."""
    from bu_db import reset_engine_cache

    reset_engine_cache()
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    return tmp_path


def test_missing_state_json_is_a_noop(fresh_state_dir) -> None:
    result = _run_migration(fresh_state_dir)
    assert result.returncode == 0, result.stderr
    assert "nothing to migrate" in (result.stdout + result.stderr).lower()


def test_full_roundtrip_loads_every_collection(fresh_state_dir) -> None:
    _write_state(fresh_state_dir, _seed_state())
    result = _run_migration(fresh_state_dir)
    assert result.returncode == 0, result.stderr

    # Re-read via the production repos — verifies the wire shape SQL
    # serves matches the JsonStore shape consumers expect.
    from bu_repositories import (
        BusinessUnitFavoriteRepository,
        BusinessUnitMembershipRepository,
        BusinessUnitRepository,
        OrganizationRepository,
        ProjectMembershipRepository,
        ProjectRepository,
        TenantRepository,
    )

    assert TenantRepository().get("ten_a") == {
        "tenant_id": "ten_a",
        "name": "Tenant A",
    }
    assert OrganizationRepository().list_for_tenant("ten_a") == [
        {"organization_id": "org_a", "tenant_id": "ten_a", "name": "Org A"}
    ]
    bu = BusinessUnitRepository().get("bu_a")
    assert bu is not None
    assert bu["name"] == "BU A"
    assert bu["status"] == "active"
    assert bu["policy"] == {"target_dita_version": "1.3"}
    assert BusinessUnitMembershipRepository().get_role("bu_a", "usr_admin") == "bu_admin"
    favorites = BusinessUnitFavoriteRepository().list_for_user("usr_admin")
    assert len(favorites) == 1
    assert favorites[0]["business_unit_id"] == "bu_a"
    project = ProjectRepository().get("prj_a")
    assert project is not None
    assert project["document_ids"] == ["doc_a", "doc_b"]
    assert ProjectMembershipRepository().get_role("prj_a", "usr_admin") == "project_admin"


def test_idempotency_second_run_inserts_nothing(fresh_state_dir) -> None:
    _write_state(fresh_state_dir, _seed_state())
    first = _run_migration(fresh_state_dir)
    assert first.returncode == 0, first.stderr
    second = _run_migration(fresh_state_dir)
    assert second.returncode == 0, second.stderr

    # Every collection in the second run must report 0 inserted.
    # Parse the structured summary block — the script's output format
    # is part of the operator contract this test pins.
    for line in second.stdout.splitlines():
        line_stripped = line.strip()
        if "inserted" in line_stripped:
            # Lines look like "  tenants: 0 inserted, 1 skipped" or
            # "  project_memberships: 0 inserted, 1 skipped (1 had …)".
            assert "0 inserted" in line_stripped, (
                f"Second migration run should insert 0 rows but got: {line_stripped}"
            )


def test_project_membership_coercion_for_legacy_shape(fresh_state_dir) -> None:
    _write_state(fresh_state_dir, _seed_state())
    result = _run_migration(fresh_state_dir)
    assert result.returncode == 0, result.stderr
    assert "1 had fields coerced" in result.stdout, (
        "Should detect and report the upload-service-shape membership "
        "(missing tenant_id + organization_id, coerced from project)."
    )

    # The migrated row must carry the derived fields in the wire shape
    # so D3.5 readers can rely on them.
    from bu_repositories import ProjectMembershipRepository

    rows = ProjectMembershipRepository().list_for_project("prj_a")
    assert len(rows) == 1
    row = rows[0]
    assert row["tenant_id"] == "ten_a"
    assert row["organization_id"] == "org_a"
    assert row["business_unit_id"] == "bu_a"


def test_malformed_state_root_exits_nonzero(fresh_state_dir) -> None:
    (fresh_state_dir).mkdir(parents=True, exist_ok=True)
    # Root-level type mismatch — should refuse to migrate.
    (fresh_state_dir / "state.json").write_text('"not an object"', encoding="utf-8")
    result = _run_migration(fresh_state_dir)
    assert result.returncode == 1
    assert "root must be an object" in result.stderr


def test_tenant_missing_required_field_exits_nonzero(fresh_state_dir) -> None:
    bad = _seed_state()
    bad["tenants"] = [{"tenant_id": "ten_a"}]  # missing name
    _write_state(fresh_state_dir, bad)
    result = _run_migration(fresh_state_dir)
    assert result.returncode == 1
    assert "tenant row missing" in result.stderr
