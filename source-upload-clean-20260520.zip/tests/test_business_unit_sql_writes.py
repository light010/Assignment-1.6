"""Phase 4 D3.5.c — SQL-authoritative write invariant lock.

History note: this file was `test_business_unit_sql_writes.py` during
D3.3, where it pinned the bridge contract (JsonStore authoritative,
SQL mirrored, failures swallowed and logged). D3.5.c inverted that
authority — mutate routes now write only to SQL via the repos, and
SQL failures propagate as 500. The file was renamed to match the new
contract; the test inversions are tracked in plan augmentation §D3.

These tests pin the post-cutover write contract for the BU service's
five owned collections:

  1. Every mutate route writes the entity to its owning repo.
  2. The route-level computed `summary` (BU) and `documents`
     (project) join keys never bleed into the SQL row — those are
     built fresh from the SQL state each read.
  3. Update + archive routes overwrite in place; no duplicate rows.
  4. A SQL write failure surfaces as a 500 to the caller. This is the
     anti-D3.3 invariant — silent swallowing is dead.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any

import pytest
from ditagen_common.security import issue_token
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


def _auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_sql_writes",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_d3_3"}


@pytest.fixture
def bu_service(tmp_path, monkeypatch):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv(
        "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
    )
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")

    from bu_db import reset_engine_cache
    reset_engine_cache()

    module_path = REPO_ROOT / "services" / "business-unit-service" / "app" / "main.py"
    full_module_name = f"bu_service_sql_writes_{abs(hash(str(tmp_path)))}"
    spec = importlib.util.spec_from_file_location(full_module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[full_module_name] = module
    spec.loader.exec_module(module)
    return TestClient(module.app)


def _sql_business_unit(business_unit_id: str) -> dict[str, Any] | None:
    from bu_repositories import BusinessUnitRepository
    return BusinessUnitRepository().get(business_unit_id)


def _sql_project(project_id: str) -> dict[str, Any] | None:
    from bu_repositories import ProjectRepository
    return ProjectRepository().get(project_id)


def _sql_bu_membership_role(business_unit_id: str, user_id: str) -> str | None:
    from bu_repositories import (
        BusinessUnitMembershipRepository,
    )

    return BusinessUnitMembershipRepository().get_role(business_unit_id, user_id)


def _sql_project_membership_role(project_id: str, user_id: str) -> str | None:
    from bu_repositories import (
        ProjectMembershipRepository,
    )

    return ProjectMembershipRepository().get_role(project_id, user_id)


def test_business_unit_create_writes_to_sql(bu_service) -> None:
    response = bu_service.post(
        "/internal/business-units",
        json={"name": "SQL Write BU", "owner_team": "Platform", "region": "NA"},
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    business_unit_id = response.json()["business_unit_id"]

    row = _sql_business_unit(business_unit_id)
    assert row is not None, "create must mirror BU envelope into SQL"
    assert row["name"] == "SQL Write BU"
    assert row["owner_team"] == "Platform"
    assert row["region"] == "NA"
    assert row["status"] == "active"
    # Route-level computed `summary` must NOT bleed into the SQL row.
    assert "summary" not in row

    # The bu_admin membership must also land in SQL.
    role = _sql_bu_membership_role(business_unit_id, "usr_admin")
    assert role == "bu_admin"


def test_business_unit_update_writes_in_place(bu_service) -> None:
    created = bu_service.post(
        "/internal/business-units",
        json={"name": "Original"},
        headers=_auth_headers(),
    )
    business_unit_id = created.json()["business_unit_id"]

    bu_service.patch(
        f"/internal/business-units/{business_unit_id}",
        json={"description": "Updated copy", "region": "EMEA"},
        headers=_auth_headers(),
    )

    row = _sql_business_unit(business_unit_id)
    assert row is not None
    assert row["description"] == "Updated copy"
    assert row["region"] == "EMEA"
    assert row["name"] == "Original"  # untouched fields preserved


def test_business_unit_archive_writes_status_and_timestamp(bu_service) -> None:
    created = bu_service.post(
        "/internal/business-units",
        json={"name": "To Archive"},
        headers=_auth_headers(),
    )
    business_unit_id = created.json()["business_unit_id"]

    bu_service.delete(
        f"/internal/business-units/{business_unit_id}", headers=_auth_headers()
    )

    row = _sql_business_unit(business_unit_id)
    assert row is not None
    assert row["status"] == "archived"
    assert row["deleted_at"] is not None


def test_project_create_writes_project_and_membership(bu_service) -> None:
    # `bu_docs_ops` comes from auto-seed (ensure_sql_seeded copied it
    # from JsonStore into SQL at module init). The new project below
    # exercises the create-route SQL write under test.
    response = bu_service.post(
        "/internal/projects",
        json={"business_unit_id": "bu_docs_ops", "name": "SQL Write Project"},
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    project_id = response.json()["project_id"]

    row = _sql_project(project_id)
    assert row is not None
    assert row["business_unit_id"] == "bu_docs_ops"
    assert row["name"] == "SQL Write Project"
    assert row["status"] == "active"
    assert row["document_ids"] == []
    # Route-level `documents` join must NOT bleed into the SQL row.
    assert "documents" not in row

    role = _sql_project_membership_role(project_id, "usr_admin")
    assert role == "project_admin"


def test_project_update_then_archive_round_trip(bu_service) -> None:
    created = bu_service.post(
        "/internal/projects",
        json={"business_unit_id": "bu_docs_ops", "name": "Renamed Soon"},
        headers=_auth_headers(),
    )
    project_id = created.json()["project_id"]

    bu_service.patch(
        f"/internal/projects/{project_id}",
        json={"name": "Renamed Now", "description": "Now with description"},
        headers=_auth_headers(),
    )
    row = _sql_project(project_id)
    assert row is not None
    assert row["name"] == "Renamed Now"
    assert row["description"] == "Now with description"

    bu_service.delete(f"/internal/projects/{project_id}", headers=_auth_headers())
    archived = _sql_project(project_id)
    assert archived is not None
    assert archived["status"] == "archived"
    assert archived["deleted_at"] is not None


def test_sql_write_failure_surfaces_as_500(bu_service, monkeypatch) -> None:
    """D3.5.c invariant (inverted from D3.3): SQL is the authoritative
    write target. A repo upsert raising means the entity does NOT
    exist in the system of record, and the route MUST surface that as
    a 500 — not silently log and return 200. This locks the cutover:
    if a future regression reintroduces swallow-and-log, this test
    fails.

    Note: a fresh TestClient is built with raise_server_exceptions=False
    because the default re-raises unhandled exceptions through the
    transport instead of converting them to a 500 response. In real
    HTTP, FastAPI's middleware converts to 500 — this matches that."""
    import bu_repositories

    def _boom(self, envelope):  # noqa: ARG001
        raise RuntimeError("simulated SQL outage")

    monkeypatch.setattr(bu_repositories.BusinessUnitRepository, "upsert", _boom)

    real_http_like_client = TestClient(bu_service.app, raise_server_exceptions=False)
    response = real_http_like_client.post(
        "/internal/business-units",
        json={"name": "Should not survive SQL outage"},
        headers=_auth_headers(),
    )

    assert response.status_code == 500, (
        "Post-D3.5.c, SQL write failure must propagate as 500. If this "
        "fires with status 200, a swallow-and-log regression slipped "
        "back in. See plan §D3.5.c."
    )
