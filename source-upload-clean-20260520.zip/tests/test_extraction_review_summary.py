from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_review_summary",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_review_summary"}


def _load_upload_app(service_app_factory) -> tuple[Any, Any]:
    return service_app_factory("services/upload-service/app/main.py", "review_summary_upload")


def _seed_document(
    module: Any,
    upload_seed_document: Callable[[Any, dict[str, Any]], dict[str, Any]],
    *,
    document_id: str,
    status: str,
    blocks: list[dict[str, Any]] | None = None,
    gate: dict[str, Any] | None = None,
    failure_error: dict[str, Any] | None = None,
) -> None:
    project_id = f"prj_{document_id}"
    blocks = blocks or []
    bu_id_holder: list[str] = []

    source_blocks_ref = None
    if blocks:
        source_blocks_ref = module.write_artifact(
            project_id=project_id,
            document_id=document_id,
            name="source-blocks.jsonl",
            content="\n".join(module.json.dumps(block) for block in blocks) + "\n",
            content_type="application/jsonl",
            store=module.store,
            created_by="usr_admin",
            producer="test",
        )

    quality = module.legacy_quality_artifact(document_id)
    quality["gate"] = gate if gate is not None else module.legacy_quality_gate()
    quality["metrics"]["total_source_blocks"] = len(blocks)
    quality["metrics"]["located_source_blocks"] = len(blocks)
    quality["metrics"]["review_flag_counts"] = {}
    for block in blocks:
        for flag in block.get("review_flags") or []:
            code = flag["code"]
            quality["metrics"]["review_flag_counts"][code] = quality["metrics"]["review_flag_counts"].get(code, 0) + 1
    quality_ref = None
    if status != "failed_extraction":
        quality_ref = module.write_artifact(
            project_id=project_id,
            document_id=document_id,
            name="extraction-quality.json",
            content=quality,
            store=module.store,
            created_by="usr_admin",
            producer="test",
        )

    def seed(state: dict[str, Any]) -> dict[str, Any]:
        bu_id_holder.append(next(iter(state["business_units"])))
        bu_id = bu_id_holder[-1]
        state["projects"][project_id] = {
            "project_id": project_id,
            "tenant_id": "ten_local",
            "business_unit_id": bu_id,
            "name": "Review Summary Test Project",
            "slug": "review-summary",
            "document_ids": [document_id],
            "owner_user_id": "usr_admin",
            "members": ["usr_admin"],
            "status": "active",
            "deleted_at": None,
            "created_at": "2026-05-11T00:00:00Z",
            "updated_at": "2026-05-11T00:00:00Z",
        }
        artifacts: dict[str, Any] = {}
        if source_blocks_ref:
            artifacts["source_blocks"] = source_blocks_ref
        if quality_ref:
            artifacts["extraction_quality"] = quality_ref
        return state

    module.store.mutate(seed)
    # Phase 4 D4.5.b — the upload-service routes now read documents from
    # SQL; the historical state["documents"] seed only kept BU+project
    # context alive. Mirror the document envelope into the upload-service
    # SQL repo so `_require_document_via_repo` resolves it.
    bu_id = bu_id_holder[-1]
    artifacts: dict[str, Any] = {}
    if source_blocks_ref:
        artifacts["source_blocks"] = source_blocks_ref
    if quality_ref:
        artifacts["extraction_quality"] = quality_ref
    upload_seed_document(
        module,
        {
            "document_id": document_id,
            "tenant_id": "ten_local",
            "business_unit_id": bu_id,
            "project_id": project_id,
            "filename": f"{document_id}.docx",
            "content_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "source_hash": "sha256:test",
            "status": status,
            "extraction_failure_reason": module.extraction_failure_reason(failure_error) if failure_error else None,
            "artifacts": artifacts,
            "latest_artifacts": {},
            "original_artifact": {
                "artifact_id": f"art_original_{document_id}",
                "path": "/dev/null",
                "content_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "hash": "seed-hash",
                "size_bytes": 0,
                "artifact_version": 1,
            },
            "source_quality": {
                "overall_confidence": 0.9,
                "review_required": status != "ready_for_review",
                "validation_issue_count": 0,
                "quality_gate": gate,
                "warnings": [],
                "block_count": len(blocks),
                "asset_count": 0,
                "extraction_error": failure_error,
            },
            "topic_ids": [],
            "job_ids": [],
            "extraction": {"stage": "failed", "error": failure_error} if failure_error else {"stage": "completed"},
        },
    )


def _block(module: Any, block_id: str, *, flag_code: str | None = None) -> dict[str, Any]:
    from ditagen_common.models import ReviewFlagCode, review_flag_payload

    flags = [review_flag_payload(cast(ReviewFlagCode, flag_code))] if flag_code else []
    return {
        "block_id": block_id,
        "document_id": "doc",
        "block_type": "paragraph",
        "text": f"Block {block_id}",
        "source_location": {"page": None, "section": f"docx:p:{block_id}", "bbox": None},
        "confidence": {"extraction": 0.9, "block_type": 0.9, "heading": None, "semantic_inline": 0.9},
        "review_flags": flags,
    }


def test_ready_document_review_summary_has_catalog_and_counts(
    service_app_factory, upload_seed_document
) -> None:
    app, module = _load_upload_app(service_app_factory)
    client = TestClient(app)
    _seed_document(
        module,
        upload_seed_document,
        document_id="doc_ready",
        status="ready_for_review",
        blocks=[_block(module, "1"), _block(module, "2")],
    )

    response = client.get("/internal/documents/doc_ready/extraction-review-summary", headers=_auth_headers())
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["status"] == "ready_for_review"
    assert payload["block_count"] == 2
    assert payload["located_block_count"] == 2
    assert payload["gate"]["passed"] is True
    assert "LOW_BLOCK_TYPE_CONFIDENCE" in payload["catalog"]


def test_ready_with_findings_groups_review_flags(
    service_app_factory, upload_seed_document
) -> None:
    app, module = _load_upload_app(service_app_factory)
    client = TestClient(app)
    _seed_document(
        module,
        upload_seed_document,
        document_id="doc_findings",
        status="ready_for_review",
        blocks=[_block(module, "1", flag_code="LOW_BLOCK_TYPE_CONFIDENCE")],
    )

    payload = client.get("/internal/documents/doc_findings/extraction-review-summary", headers=_auth_headers()).json()
    assert payload["review_flag_counts"] == {"LOW_BLOCK_TYPE_CONFIDENCE": 1}
    assert payload["blocked_groups"][0]["label"] == "Low block type confidence"
    assert payload["blocked_groups"][0]["sample_block_ids"] == ["1"]


def test_needs_review_summary_includes_gate_blocking_groups(
    service_app_factory, upload_seed_document
) -> None:
    app, module = _load_upload_app(service_app_factory)
    client = TestClient(app)
    gate = module.synthetic_failed_quality_gate(reasons=["structure_tree_review_required"])
    _seed_document(
        module,
        upload_seed_document,
        document_id="doc_needs_review",
        status="extraction_needs_review",
        blocks=[_block(module, "1")],
        gate=gate,
    )

    payload = client.get("/internal/documents/doc_needs_review/extraction-review-summary", headers=_auth_headers()).json()
    assert payload["status"] == "extraction_needs_review"
    assert payload["gate"]["passed"] is False
    assert any(group["code"] == "structure_tree_review_required" for group in payload["blocked_groups"])


def test_failed_extraction_summary_has_no_fake_gate(
    service_app_factory, upload_seed_document
) -> None:
    app, module = _load_upload_app(service_app_factory)
    client = TestClient(app)
    error = {"kind": "input_encrypted", "message": "Encrypted file", "stage": "extracting", "retryable": False}
    _seed_document(
        module,
        upload_seed_document,
        document_id="doc_failed",
        status="failed_extraction",
        failure_error=error,
    )

    payload = client.get("/internal/documents/doc_failed/extraction-review-summary", headers=_auth_headers()).json()
    assert payload["status"] == "failed_extraction"
    assert payload["extraction_failure_reason"] == "input_encrypted"
    assert payload["block_count"] == 0
    assert payload["gate"] is None
