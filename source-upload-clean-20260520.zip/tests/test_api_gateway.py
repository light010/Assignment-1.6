from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]


def load_gateway_app(tmp_path, monkeypatch):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    monkeypatch.setenv("DITAGEN_LLM_GATEWAY_SERVICE_URL", "http://llm-gateway-service:8000")
    module_path = ROOT / "services/api-gateway/app/main.py"
    module_name = "ditagen_api_gateway_test"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.app


def test_gateway_upload_review_and_export_flow(tmp_path, monkeypatch) -> None:
    app = load_gateway_app(tmp_path, monkeypatch)
    client = TestClient(app)

    login = client.post(
        "/v1/auth/login",
        json={"email": "admin@ditagen.local", "password": "admin123"},
    )
    assert login.status_code == 200
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    business_units = client.get("/v1/business-units", headers=headers)
    assert business_units.status_code == 200
    business_unit_id = business_units.json()["business_units"][0]["business_unit_id"]

    upload = client.post(
        f"/v1/business-units/{business_unit_id}/documents/uploads",
        files={
            "file": (
                "sample.txt",
                b"Install the Connector\nClick Save to apply DEFAULT_PROFILE.\n",
                "text/plain",
            )
        },
        headers=headers,
    )
    assert upload.status_code == 200
    document = upload.json()["document"]
    assert document["status"] == "ready_for_review"
    assert len(document["topic_ids"]) == 1

    topic_id = document["topic_ids"][0]
    topic = client.get(f"/v1/topics/{topic_id}", headers=headers)
    assert topic.status_code == 200
    assert topic.json()["generated_topic"]["topic_type"] == "task"

    edit = client.post(
        f"/v1/topics/{topic_id}/ops",
        json={
            "op_type": "rename",
            "payload": {
                "topic_id": topic_id,
                "title": "Gateway E2E Rename",
                "short_desc": None,
            },
        },
        headers=headers,
    )
    assert edit.status_code == 200, edit.text
    assert edit.json()["topic"]["title"] == "Gateway E2E Rename"

    undo = client.post(f"/v1/documents/{document['document_id']}/ops/undo", headers=headers)
    assert undo.status_code == 200, undo.text
    assert undo.json()["topic"]["title"] != "Gateway E2E Rename"

    approved = client.post(f"/v1/topics/{topic_id}/approve", headers=headers)
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"

    export = client.post(
        f"/v1/documents/{document['document_id']}/exports",
        json={"include_unapproved": False},
        headers=headers,
    )
    assert export.status_code == 200
    assert export.json()["status"] == "completed"


def _login_headers(client: TestClient) -> dict[str, str]:
    login = client.post(
        "/v1/auth/login",
        json={"email": "admin@ditagen.local", "password": "admin123"},
    )
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


def test_personal_access_tokens_are_listed_and_revoked(tmp_path, monkeypatch) -> None:
    app = load_gateway_app(tmp_path, monkeypatch)
    client = TestClient(app)
    headers = _login_headers(client)

    created = client.post("/v1/auth/tokens", headers=headers)
    assert created.status_code == 200, created.text
    token_id = created.json()["token_id"]
    pat_headers = {"Authorization": f"Bearer {created.json()['token']}"}

    listed = client.get("/v1/auth/tokens", headers=headers)
    assert listed.status_code == 200
    assert any(item["token_id"] == token_id for item in listed.json()["tokens"])

    usable = client.get("/v1/auth/sessions", headers=pat_headers)
    assert usable.status_code == 200

    revoked = client.delete(f"/v1/auth/tokens/{token_id}", headers=headers)
    assert revoked.status_code == 200

    blocked = client.get("/v1/auth/sessions", headers=pat_headers)
    assert blocked.status_code == 401
    assert "revoked" in blocked.json()["detail"].lower()


def test_revoking_unknown_personal_access_token_returns_404(tmp_path, monkeypatch) -> None:
    app = load_gateway_app(tmp_path, monkeypatch)
    client = TestClient(app)
    response = client.delete("/v1/auth/tokens/pat_missing", headers=_login_headers(client))
    assert response.status_code == 404


def test_llm_chat_completion_requires_auth_and_proxies_to_llm_gateway(
    tmp_path, monkeypatch
) -> None:
    app = load_gateway_app(tmp_path, monkeypatch)
    client = TestClient(app)

    unauthenticated = client.post(
        "/v1/llm/chat/completions",
        json={"model": "fixture-deterministic", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert unauthenticated.status_code == 401

    authenticated = client.post(
        "/v1/llm/chat/completions",
        headers=_login_headers(client),
        json={"model": "fixture-deterministic", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert authenticated.status_code == 501
    assert "chat_completions" in authenticated.json()["detail"]


def test_cors_rejects_methods_outside_configured_allowlist(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_ENV", "production")
    monkeypatch.setenv("DITAGEN_AUTH_SECRET", "test-production-secret")
    monkeypatch.setenv("DITAGEN_CORS_ORIGINS", "https://app.example.test")
    monkeypatch.setenv("DITAGEN_CORS_METHODS", "GET,POST")
    app = load_gateway_app(tmp_path, monkeypatch)
    client = TestClient(app)

    rejected = client.options(
        "/v1/auth/login",
        headers={
            "Origin": "https://app.example.test",
            "Access-Control-Request-Method": "PUT",
        },
    )
    assert rejected.status_code == 400

    accepted = client.options(
        "/v1/auth/login",
        headers={
            "Origin": "https://app.example.test",
            "Access-Control-Request-Method": "POST",
        },
    )
    assert accepted.status_code == 200
