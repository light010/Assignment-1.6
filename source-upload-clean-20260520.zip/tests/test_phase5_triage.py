"""Phase 5 — confidence-driven triage tests.

Covers:
  1. Per-flag synthetic tests for the four canonical review-flag codes
     (`LOW_BLOCK_TYPE_CONFIDENCE`, `ORPHAN_TABLE_ROW`,
     `MIXED_HEADING_STYLE`, `SUSPECTED_HEADING_FRAGMENT`).
  2. "No more constants" tests — extracts a real DOCX and asserts the
     `0.9` / `0.82` flat-confidence pattern is gone (computed signals
     produce variability).
  3. The `GET /v1/documents/{id}/triage-queue` route returns flagged
     blocks ordered ascending by min(confidence) with the right shape.
  4. Apple CA fixture invariants: at least one
     `LOW_BLOCK_TYPE_CONFIDENCE` somewhere; the contacts/client-summary
     tables produce zero `ORPHAN_TABLE_ROW` flags.

The unit tests import `_compute_review_signals` and helpers directly to
avoid spinning up the full FastAPI app for what is a pure-function
pipeline. The integration tests use `service_app_factory` from
`tests/conftest.py`.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

import pytest
from _docx_fixtures import build_block_payload
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]


def _load_extractors_module() -> Any:
    """Load `extractors` from extraction-service for direct function access."""
    app_path = REPO_ROOT / "services" / "extraction-service" / "app"
    sys.path.insert(0, str(app_path))
    return importlib.import_module("extractors")


def _make_block(
    *,
    block_id: str,
    block_type: str,
    text: str,
    style_name: str | None = None,
    font_size: float = 11.0,
    table_id: str | None = None,
    row_index: int | None = None,
    inline_runs: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a block dict with the same shape `_source_block` produces.

    Step D0b: delegates to `tests/_docx_fixtures.py:build_block_payload`
    so any future shape change to `Block` flows automatically through to
    the fixtures here. Confidence is set to placeholder (0.5) so the
    `_compute_review_signals` post-processor's per-flag thresholds
    surface as the triage tests below expect.
    """
    is_heading = block_type == "heading"
    style_summary = {
        "dominant_font_size_pt": font_size,
        "font_size_rank": 1 if is_heading else 2,
        "bold_ratio": 1 if is_heading else 0,
        "italic_ratio": 0,
        "monospace_ratio": 0,
        "source_style_name": style_name,
    }
    extras: dict[str, Any] = {
        "source_line_ids": ["line_0001"],
        "style_summary": style_summary,
        "content_hash": "0" * 64,
        "font": {"size": font_size, "family": None, "weight": "regular"},
        "order_in_page": 1,
        "is_likely_heading": is_heading,
        "char_start": 0,
        "char_end": len(text),
    }
    if is_heading:
        extras["inferred_level"] = 1
    if table_id is not None:
        extras["table_id"] = table_id
    if row_index is not None:
        extras["row_index"] = row_index
    if inline_runs is not None:
        extras["inline_runs"] = inline_runs
    return build_block_payload(
        block_id=block_id,
        text=text,
        block_type=block_type,
        document_id="doc_test",
        page=1,
        confidence={
            "extraction": 0.5,
            "block_type": 0.5,
            "heading": 0.5,
            "semantic_inline": 0.5,
        },
        **extras,
    )


def _assert_flag_contract(flag: dict[str, Any]) -> None:
    from ditagen_common.models import REVIEW_FLAG_CATALOG

    catalog = REVIEW_FLAG_CATALOG[flag["code"]]
    assert flag["severity"] == catalog["severity"]
    assert flag["message"]
    assert flag["action"] == catalog["action"]


@pytest.fixture
def extractors():
    return _load_extractors_module()


# ---------------------------------------------------------------------------
# Unit: per-flag synthetic
# ---------------------------------------------------------------------------


def test_low_block_type_confidence_fires_for_weak_paragraph_heading(extractors) -> None:
    """A heading with no Heading-N style and no title-case shape lands
    below the 0.7 block_type-confidence threshold and gets flagged."""
    blocks = [
        _make_block(
            block_id="blk_1",
            block_type="heading",
            text="this is not a real heading.",
            style_name=None,
            font_size=12.0,
        ),
    ]
    extractors._compute_review_signals(blocks)

    codes = [flag["code"] for flag in blocks[0]["review_flags"]]
    assert "LOW_BLOCK_TYPE_CONFIDENCE" in codes
    _assert_flag_contract(next(flag for flag in blocks[0]["review_flags"] if flag["code"] == "LOW_BLOCK_TYPE_CONFIDENCE"))
    assert blocks[0]["confidence"]["block_type"] < 0.7


def test_orphan_table_row_fires_when_row_one_is_missing(extractors) -> None:
    blocks = [
        _make_block(
            block_id="blk_orphan",
            block_type="table_row",
            text="Cell A | Cell B",
            table_id="tbl_001",
            row_index=2,
            style_name="Table",
        ),
    ]
    extractors._compute_review_signals(blocks)

    codes = [flag["code"] for flag in blocks[0]["review_flags"]]
    assert "ORPHAN_TABLE_ROW" in codes
    _assert_flag_contract(next(flag for flag in blocks[0]["review_flags"] if flag["code"] == "ORPHAN_TABLE_ROW"))


def test_orphan_flag_does_not_fire_when_row_one_present(extractors) -> None:
    blocks = [
        _make_block(
            block_id="blk_r1",
            block_type="table_row",
            text="Header A | Header B",
            table_id="tbl_001",
            row_index=1,
            style_name="Table",
        ),
        _make_block(
            block_id="blk_r2",
            block_type="table_row",
            text="Body A | Body B",
            table_id="tbl_001",
            row_index=2,
            style_name="Table",
        ),
    ]
    extractors._compute_review_signals(blocks)

    for block in blocks:
        codes = [flag["code"] for flag in block["review_flags"]]
        assert "ORPHAN_TABLE_ROW" not in codes


def test_mixed_heading_style_fires_when_style_is_dual_role(extractors) -> None:
    blocks = [
        _make_block(
            block_id="blk_h",
            block_type="heading",
            text="Section",
            style_name="BodyText",
            font_size=18.0,
        ),
        _make_block(
            block_id="blk_p",
            block_type="paragraph",
            text="A regular paragraph.",
            style_name="BodyText",
            font_size=11.0,
        ),
    ]
    extractors._compute_review_signals(blocks)

    heading_codes = [flag["code"] for flag in blocks[0]["review_flags"]]
    assert "MIXED_HEADING_STYLE" in heading_codes
    _assert_flag_contract(next(flag for flag in blocks[0]["review_flags"] if flag["code"] == "MIXED_HEADING_STYLE"))


def test_suspected_heading_fragment_fires_on_period_terminus(extractors) -> None:
    blocks = [
        _make_block(
            block_id="blk_h",
            block_type="heading",
            text="This heading ends in a period.",
            style_name="Heading 1",
            font_size=18.0,
        ),
    ]
    extractors._compute_review_signals(blocks)

    codes = [flag["code"] for flag in blocks[0]["review_flags"]]
    assert "SUSPECTED_HEADING_FRAGMENT" in codes
    _assert_flag_contract(next(flag for flag in blocks[0]["review_flags"] if flag["code"] == "SUSPECTED_HEADING_FRAGMENT"))


def test_no_flags_for_clean_heading_and_paragraph(extractors) -> None:
    blocks = [
        _make_block(
            block_id="blk_h",
            block_type="heading",
            text="Payroll Setup",
            style_name="Heading 1",
            font_size=18.0,
        ),
        _make_block(
            block_id="blk_p",
            block_type="paragraph",
            text="Install the connector.",
            style_name="Normal",
            font_size=11.0,
            inline_runs=[
                {
                    "start": 0,
                    "end": 23,
                    "text": "Install the connector.",
                    "marks": [],
                }
            ],
        ),
    ]
    extractors._compute_review_signals(blocks)

    for block in blocks:
        assert block["review_flags"] == []


# ---------------------------------------------------------------------------
# Unit: constants gone — placeholder must be overwritten everywhere
# ---------------------------------------------------------------------------


def test_no_block_carries_placeholder_after_post_processor(extractors) -> None:
    """If anyone forgot to call `_compute_review_signals`, the placeholder
    `0.5` would leak into output. This test catches that regression by
    asserting *post-processed* blocks never carry the placeholder."""
    blocks = [
        _make_block(
            block_id="blk_h",
            block_type="heading",
            text="Section",
            style_name="Heading 1",
            font_size=18.0,
        ),
        _make_block(
            block_id="blk_p",
            block_type="paragraph",
            text="A regular paragraph.",
            style_name="Normal",
            font_size=11.0,
        ),
        _make_block(
            block_id="blk_t",
            block_type="table_row",
            text="A | B",
            table_id="tbl_1",
            row_index=1,
            style_name="Table",
        ),
    ]
    extractors._compute_review_signals(blocks)

    for block in blocks:
        confidence = block["confidence"]
        # The placeholder is exactly 0.5; no real formula lands there.
        assert confidence["extraction"] != 0.5
        assert confidence["block_type"] != 0.5


def test_block_type_confidence_varies_across_block_types(extractors) -> None:
    """Phase 5 specifically replaces the constant 0.9/0.82 pair: across a
    mixed-type corpus the resulting `block_type` confidences must take
    more than two distinct values (the constants gave us exactly two)."""
    blocks = [
        _make_block(
            block_id=f"blk_{n}",
            block_type=block_type,
            text=text,
            style_name=style,
            font_size=size,
        )
        for n, (block_type, text, style, size) in enumerate(
            [
                ("heading", "Section A", "Heading 1", 20.0),
                ("heading", "weak heading.", None, 12.0),
                ("paragraph", "Body text here.", "Normal", 11.0),
                ("procedure_step", "Click Save.", None, 11.0),
                ("table_row", "A | B", "Table", 11.0),
                ("warning", "Warning: hot surface.", None, 11.0),
                ("note", "Note: see appendix.", None, 11.0),
            ]
        )
    ]
    extractors._compute_review_signals(blocks)

    distinct_block_type_confidences = {
        round(b["confidence"]["block_type"], 3) for b in blocks
    }
    assert len(distinct_block_type_confidences) > 2


# ---------------------------------------------------------------------------
# Integration: triage-queue route through extraction-service
# ---------------------------------------------------------------------------


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_phase5"}


def _build_layered_docx(tmp_path: Path) -> bytes:
    """A small DOCX with a heading-fragment, a real heading, an orphan
    table row, and a paragraph using the same style as a heading. Hits
    every flag in one fixture."""
    from docx import Document

    document = Document()
    document.add_heading("Section A", level=1)
    document.add_paragraph("Install the connector.")
    p = document.add_paragraph("This pretends to be a heading.")
    p.style = document.styles["Heading 2"]
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Field"
    table.cell(0, 1).text = "Value"
    table.cell(1, 0).text = "Mode"
    table.cell(1, 1).text = "Automatic"
    path = tmp_path / "phase5_layered.docx"
    document.save(str(path))
    return path.read_bytes()


def _post_extraction(client: TestClient, *, document_id: str, content: bytes, tmp_path: Path) -> dict[str, Any]:
    from ditagen_common.artifacts import write_artifact
    from ditagen_common.store import JsonStore

    original = write_artifact(
        project_id="prj_phase5",
        document_id=document_id,
        name=f"original/{document_id}.docx",
        content=content,
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        store=JsonStore(),
        created_by="usr_admin",
        producer="upload-service",
    )
    payload = {
        "document_id": document_id,
        "project_id": "prj_phase5",
        "business_unit_id": "bu_docs_ops",
        "filename": f"{document_id}.docx",
        "content_type": original["content_type"],
        "artifact_path": original["path"],
        "request_id": "req_phase5",
        "requested_by": "usr_admin",
    }
    response = client.post("/internal/extractions", json=payload, headers=_auth_headers())
    assert response.status_code == 200, response.text
    return response.json()


def test_triage_queue_route_returns_flagged_blocks_sorted_by_confidence(
    service_app_factory, tmp_path
) -> None:
    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "phase5_extraction_service"
    )
    client = TestClient(app)
    docx_bytes = _build_layered_docx(tmp_path)
    _post_extraction(client, document_id="doc_phase5_layered", content=docx_bytes, tmp_path=tmp_path)

    triage = client.get(
        "/internal/documents/doc_phase5_layered/triage-queue",
        headers=_auth_headers(),
    )
    assert triage.status_code == 200, triage.text
    body = triage.json()
    assert body["document_id"] == "doc_phase5_layered"
    assert body["total_blocks"] >= 4

    entries = body["entries"]
    assert entries, "expected at least one flagged block"
    confidences = [entry["min_confidence"] for entry in entries]
    assert confidences == sorted(confidences), "entries must be ordered ascending by min_confidence"

    all_codes = {flag["code"] for entry in entries for flag in entry["review_flags"]}
    assert all_codes & {
        "LOW_BLOCK_TYPE_CONFIDENCE",
        "MIXED_HEADING_STYLE",
        "SUSPECTED_HEADING_FRAGMENT",
    }, f"expected at least one structural flag among entries; got {all_codes}"


def test_triage_queue_extraction_blocks_are_schema_valid(
    service_app_factory, tmp_path
) -> None:
    """Phase 2's schema regression test asserted blocks validated against
    `source-block.schema.json`. Phase 5 mutates `confidence`,
    `confidence_signals`, and `review_flags` after the model dump — this
    test re-validates against the schema to catch any mutation that
    breaks the contract."""
    import jsonschema
    from ditagen_common.artifacts import read_artifact_text

    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "phase5_extraction_schema"
    )
    client = TestClient(app)
    docx_bytes = _build_layered_docx(tmp_path)
    status = _post_extraction(
        client, document_id="doc_phase5_schema", content=docx_bytes, tmp_path=tmp_path
    )
    blocks_ref = next(a for a in status["artifacts"] if a["name"] == "source-blocks.jsonl")
    blocks_text = read_artifact_text(blocks_ref)
    blocks = [json.loads(line) for line in blocks_text.splitlines() if line.strip()]
    assert blocks

    schema = json.loads(
        (REPO_ROOT / "contracts" / "artifacts" / "source-block.schema.json").read_text(
            encoding="utf-8"
        )
    )
    for block in blocks:
        jsonschema.validate(instance=block, schema=schema)


# ---------------------------------------------------------------------------
# Integration: Apple CA invariants
# ---------------------------------------------------------------------------


def test_apple_ca_extraction_yields_at_least_one_low_confidence_flag(
    service_app_factory, apple_ca_docx_bytes
) -> None:
    """The plan locks: 'at least one LOW_BLOCK_TYPE_CONFIDENCE flag exists
    somewhere' on the Apple CA fixture. This is a real-world doc with
    mixed-style headings and ambiguous block types — if the heuristic
    were too lax, no block would ever be flagged and the triage queue
    would be useless."""
    from ditagen_common.artifacts import read_artifact_text

    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "phase5_apple_ca"
    )
    client = TestClient(app)
    status = _post_extraction(
        client, document_id="doc_phase5_apple_ca", content=apple_ca_docx_bytes, tmp_path=Path("/tmp")
    )
    blocks_ref = next(a for a in status["artifacts"] if a["name"] == "source-blocks.jsonl")
    blocks = [
        json.loads(line)
        for line in read_artifact_text(blocks_ref).splitlines()
        if line.strip()
    ]

    flagged_codes = {
        flag["code"]
        for block in blocks
        for flag in block.get("review_flags") or []
    }
    assert "LOW_BLOCK_TYPE_CONFIDENCE" in flagged_codes, (
        "Apple CA must surface at least one low-block-type-confidence flag — "
        f"got {flagged_codes}"
    )


def test_apple_ca_table_rows_are_not_orphans(
    service_app_factory, apple_ca_docx_bytes
) -> None:
    """ORPHAN_TABLE_ROW signals broken extraction (a row_index>1 with no
    row_index=1 sibling). Apple CA's tables should extract cleanly under
    the Phase 1 body-walker, so zero ORPHAN_TABLE_ROW flags is the
    correct happy-path."""
    from ditagen_common.artifacts import read_artifact_text

    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "phase5_apple_ca_orphan"
    )
    client = TestClient(app)
    status = _post_extraction(
        client,
        document_id="doc_phase5_apple_ca_orphan",
        content=apple_ca_docx_bytes,
        tmp_path=Path("/tmp"),
    )
    blocks_ref = next(a for a in status["artifacts"] if a["name"] == "source-blocks.jsonl")
    blocks = [
        json.loads(line)
        for line in read_artifact_text(blocks_ref).splitlines()
        if line.strip()
    ]

    orphans = [
        block
        for block in blocks
        if any(flag["code"] == "ORPHAN_TABLE_ROW" for flag in block.get("review_flags") or [])
    ]
    assert orphans == [], (
        "Apple CA tables should not produce ORPHAN_TABLE_ROW flags. "
        f"Found {len(orphans)} orphan row(s): "
        f"{[(b['block_id'], b.get('table_id'), b.get('row_index')) for b in orphans]}"
    )
