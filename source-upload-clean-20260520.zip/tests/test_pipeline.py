from __future__ import annotations

import json
import zipfile
from io import BytesIO
from pathlib import Path

from ditagen_common.pipeline import run_document_pipeline
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def schema(path: str) -> dict:
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def test_alpha_pipeline_produces_contract_valid_topic_artifacts() -> None:
    sample = b"""Install the Connector
Click Save to apply DEFAULT_PROFILE.
Verify the connector starts.
"""
    result = run_document_pipeline(document_id="doc_test", filename="sample.txt", data=sample)

    assert result.source_blocks[0]["block_type"] == "heading"
    assert result.topic_plan["topic_candidates"][0]["topic_type"] == "task"
    assert result.generated_topics[0]["topic_type"] == "task"
    assert "DEFAULT_PROFILE" in result.dita_files["topics/install_the_connector.dita"]
    assert result.validation_issues == []

    Draft202012Validator(schema("contracts/llm/topic-plan.schema.json")).validate(result.topic_plan)
    Draft202012Validator(schema("contracts/llm/generated-topic.schema.json")).validate(
        result.generated_topics[0]
    )
    source_block_validator = Draft202012Validator(schema("contracts/artifacts/source-block.schema.json"))
    for block in result.source_blocks:
        source_block_validator.validate(block)


def test_alpha_export_contains_dita_map_topics_and_reports() -> None:
    result = run_document_pipeline(
        document_id="doc_export",
        filename="sample.txt",
        data=b"Install the Connector\nClick Save to apply DEFAULT_PROFILE.\n",
    )

    with zipfile.ZipFile(BytesIO(result.export_zip)) as archive:
        names = set(archive.namelist())

    assert "ditagen.ditamap" in names
    assert "topics/install_the_connector.dita" in names
    assert "reports/topic-plan.json" in names
    assert "reports/validation-report.json" in names
    assert "source/content.md" in names
