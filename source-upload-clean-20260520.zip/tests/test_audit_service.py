from __future__ import annotations

from ditagen_common.security import issue_token
from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    token = issue_token({"sub": "usr_admin", "roles": ["org_admin"]})
    return {"Authorization": f"Bearer {token}"}


def test_audit_replay_endpoint_returns_cursor_ordered_events(service_app_factory) -> None:
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "audit_replay_service",
    )
    client = TestClient(app)
    headers = _auth_headers()

    first = client.post(
        "/internal/audit-events",
        json={
            "action": "project.created",
            "resource_type": "project",
            "resource_id": "prj_audit_1",
            "business_unit_id": "bu_docs_ops",
        },
        headers=headers,
    )
    second = client.post(
        "/internal/audit-events",
        json={
            "action": "document.uploaded",
            "resource_type": "document",
            "resource_id": "doc_audit_1",
            "business_unit_id": "bu_docs_ops",
        },
        headers=headers,
    )
    assert first.status_code == 200
    assert second.status_code == 200

    initial = client.get("/internal/events/since/0", headers=headers)
    assert initial.status_code == 200
    body = initial.json()
    assert [event["action"] for event in body["events"]] == [
        "project.created",
        "document.uploaded",
    ]
    assert body["next_cursor"] == "2"

    offset = client.get("/internal/events/since/1", headers=headers)
    assert offset.status_code == 200
    assert [event["action"] for event in offset.json()["events"]] == ["document.uploaded"]

    by_event_id = client.get(
        f"/internal/events/since/{first.json()['event_id']}",
        headers=headers,
    )
    assert by_event_id.status_code == 200
    assert [event["action"] for event in by_event_id.json()["events"]] == ["document.uploaded"]
