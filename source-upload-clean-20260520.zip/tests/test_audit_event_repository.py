"""Repository contract tests for AuditEventRepository — Phase 4 D2.

These exercise the SQL-backed audit-event store directly (no FastAPI,
no service-app fixture). The endpoint-level locks live in
`test_audit_service.py` and `test_event_replay.py`; this file pins the
primitives those tests rest on.

Invariants asserted here (one assertion per test):

  1. append+list roundtrip — what goes in comes out, ordered by seq.
  2. event_id is the idempotency key — second append is a no-op.
  3. seq is monotonic across appends (no reordering across writers).
  4. walk_since_seq honours the LIMIT and returns a monotonic cursor.
  5. walk_since_seq returns the requested seq when no rows match
     (cursor preservation — the D1 contract).
  6. resolve_seq_for_event_id returns None for unknown ids.
  7. business_unit_id / project_id filters push down to SQL.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "audit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


@pytest.fixture
def repo(tmp_path, monkeypatch):
    """A fresh SQLite-backed repository per test.

    The engine cache in `db` is keyed by URL — each tmp_path produces a
    unique URL, so tests are hermetic without an explicit reset between
    every test. We still call `reset_engine_cache()` to make the
    test-suite-wide cache predictable on rerun. Imports mirror the
    production pattern (top-level `from db import ...` — see
    `services/extraction-service/app/main.py` for the convention)."""
    from db import reset_engine_cache
    from repository import AuditEventRepository

    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    reset_engine_cache()
    url = f"sqlite:///{tmp_path}/audit-service.sqlite3"
    return AuditEventRepository(database_url=url)


def _evt(event_id: str, **kwargs: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "event_id": event_id,
        "actor_id": "usr_test",
        "action": "test.event",
        "resource_type": "test",
        "resource_id": "res_0",
        "business_unit_id": None,
        "project_id": None,
        "metadata": {},
        "occurred_at": None,
    }
    base.update(kwargs)
    return base


def test_append_list_roundtrip_preserves_seq_order(repo) -> None:
    for i in range(5):
        repo.append_event(**_evt(f"aud_{i:04d}"))
    events = repo.list_events()
    assert [e["event_id"] for e in events] == [f"aud_{i:04d}" for i in range(5)]


def test_append_is_idempotent_on_event_id(repo) -> None:
    first = repo.append_event(**_evt("aud_dup"))
    second = repo.append_event(**_evt("aud_dup", action="other.event"))
    # Idempotency: the second call returns the FIRST persisted shape.
    # The mutation attempt in the second call is silently dropped — the
    # event_id is the canonical key, the rest of the payload follows
    # the persisted row.
    assert first["event_id"] == second["event_id"]
    assert first["action"] == second["action"] == "test.event"
    assert len(repo.list_events()) == 1


def test_walk_since_seq_returns_monotonic_cursor(repo) -> None:
    for i in range(10):
        repo.append_event(**_evt(f"aud_{i:04d}"))
    events, next_seq = repo.walk_since_seq(seq=3, limit=4)
    assert [e["event_id"] for e in events] == [
        "aud_0003",
        "aud_0004",
        "aud_0005",
        "aud_0006",
    ]
    assert next_seq == 7


def test_walk_since_seq_empty_window_preserves_cursor(repo) -> None:
    for i in range(3):
        repo.append_event(**_evt(f"aud_{i:04d}"))
    events, next_seq = repo.walk_since_seq(seq=100, limit=10)
    assert events == []
    # Cursor preservation: D1 locked this contract — no regression
    # allowed when the consumer's cursor is past the end.
    assert next_seq == 100


def test_resolve_seq_for_event_id_returns_none_for_unknown(repo) -> None:
    repo.append_event(**_evt("aud_known"))
    assert repo.resolve_seq_for_event_id("aud_known") is not None
    assert repo.resolve_seq_for_event_id("aud_does_not_exist") is None


def test_list_events_filters_business_unit(repo) -> None:
    repo.append_event(**_evt("aud_a", business_unit_id="bu_x"))
    repo.append_event(**_evt("aud_b", business_unit_id="bu_y"))
    repo.append_event(**_evt("aud_c", business_unit_id="bu_x"))
    filtered = repo.list_events(business_unit_id="bu_x")
    assert {e["event_id"] for e in filtered} == {"aud_a", "aud_c"}


def test_list_events_filters_project(repo) -> None:
    repo.append_event(**_evt("aud_a", project_id="prj_x"))
    repo.append_event(**_evt("aud_b", project_id="prj_y"))
    filtered = repo.list_events(project_id="prj_y")
    assert [e["event_id"] for e in filtered] == ["aud_b"]


def test_max_seq_returns_zero_on_empty_table(repo) -> None:
    assert repo.max_seq() == 0
    repo.append_event(**_evt("aud_first"))
    assert repo.max_seq() >= 1
