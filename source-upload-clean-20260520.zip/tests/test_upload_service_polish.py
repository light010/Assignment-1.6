"""Step G regression tests for upload-service polish.

Covers:
  - G1: `/reextract` rate-limit (in-memory, per-document, 600s window).
  - G2: gate override populates `prior_gate` snapshot in `override_history`.
  - G3: legacy documents (no extraction_quality artifact) get a
    schema-valid response from GET `.../extraction-quality.json`.
  - G4: missing-artifacts synthesized gate uses
    `missing_required_artifacts` not the misclassified `asset_unresolved`.
  - G5: real `duration_ms > 0` lands in the gate's `runtime`.
  - G6: dead `gate_overridden_at`/`gate_overridden_by` fields are no
    longer written by `override_document_quality_gate`.

The G3 and G4 tests exercise the helpers directly (cheap and
deterministic). G1/G2/G6 spin up the upload-service app via
`service_app_factory` because the route-level state machine is what we
need to verify. G5 measures a real extraction's runtime payload.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_g_polish"}


def _load_upload_app(service_app_factory) -> tuple[Any, Any]:
    return service_app_factory("services/upload-service/app/main.py", "g_polish_upload")


def _seed_project_and_document(
    module: Any,
    upload_seed_document: Callable[[Any, dict[str, Any]], dict[str, Any]],
    *,
    document_id: str,
    quality_gate: dict[str, Any] | None = None,
) -> None:
    """Mutate the store to insert one project + mirror one document into
    the upload-service SQL backend.

    The bootstrap creates business_units but not projects, so we have to
    fabricate the project envelope in JsonStore (BU service's
    `ensure_sql_seeded` picks it up on first cross-service call). The
    document goes through the `upload_seed_document` fixture to land in
    the upload-service SQL backend (post-D4.5.b documents are no longer
    JsonStore-backed).
    """
    bu_id_holder: list[str] = []
    project_id = f"prj_g_polish_{document_id}"

    def seed(state: dict[str, Any]) -> dict[str, Any]:
        bu_id_holder.append(next(iter(state["business_units"])))
        bu_id = bu_id_holder[-1]
        state["projects"][project_id] = {
            "project_id": project_id,
            "business_unit_id": bu_id,
            "tenant_id": "ten_local",
            "name": "G-Polish Test Project",
            "document_ids": [document_id],
            "status": "active",
            "deleted_at": None,
            "created_at": "2026-05-11T00:00:00Z",
            "updated_at": "2026-05-11T00:00:00Z",
        }
        return state

    module.store.mutate(seed)
    bu_id = bu_id_holder[-1]
    upload_seed_document(
        module,
        {
            "document_id": document_id,
            "tenant_id": "ten_local",
            "business_unit_id": bu_id,
            "project_id": project_id,
            "filename": f"{document_id}.docx",
            "content_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "source_hash": "seed-hash",
            "status": "extraction_needs_review",
            "artifacts": {},
            "latest_artifacts": {},
            "original_artifact": {
                "artifact_id": f"art_seed_{document_id}",
                "path": "/dev/null",
                "content_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "hash": "seed-hash",
                "size_bytes": 0,
                "artifact_version": 1,
            },
            "source_quality": {
                "quality_gate": quality_gate or module.legacy_quality_gate(),
                "review_required": quality_gate is not None,
                "warnings": [],
                "block_count": 0,
                "asset_count": 0,
            },
            "topic_ids": [],
            "job_ids": [],
        },
    )


# ---------------------------------------------------------------------- #
# G3 — legacy_quality_artifact is schema-valid
# ---------------------------------------------------------------------- #


def test_legacy_quality_artifact_validates_against_schema(service_app_factory) -> None:
    """Loads the upload-service module via the shared factory (so the
    `up_repositories` import path is set up correctly post-D4.5.b) to
    call the helper."""
    _, module = _load_upload_app(service_app_factory)

    payload = module.legacy_quality_artifact("doc_legacy")

    schema_path = ROOT / "contracts/artifacts/extraction-quality.schema.json"
    schema = json.loads(schema_path.read_text())
    import jsonschema  # locally — keep top-level imports light

    # jsonschema raises on invalid; passing means the payload conforms.
    jsonschema.validate(instance=payload, schema=schema)
    assert payload["document_id"] == "doc_legacy"
    assert payload["gate"]["name"] == "legacy_pre_gate"
    assert payload["runtime"]["extractor_version"] == "legacy"
    assert payload["runtime"]["duration_ms"] == 0


# ---------------------------------------------------------------------- #
# G4 — missing_required_artifacts enum is wired correctly
# ---------------------------------------------------------------------- #


def test_missing_required_artifacts_is_in_schema_enum() -> None:
    """Architecture lock: the new enum value must be present in the
    schema's `blocking_reasons` enum or every consumer would refuse to
    accept gates that synthesize it."""
    schema_path = ROOT / "contracts/artifacts/extraction-quality.schema.json"
    schema = json.loads(schema_path.read_text())
    enum_values = schema["properties"]["gate"]["properties"]["blocking_reasons"]["items"]["enum"]
    assert "missing_required_artifacts" in enum_values, (
        "Step G4 introduced `missing_required_artifacts`; it must appear in the "
        "schema enum or the produced gate would fail validation."
    )


def test_upload_service_no_longer_uses_asset_unresolved_for_missing_artifacts() -> None:
    """Grep guard against future regressions. The `asset_unresolved` enum
    value still exists in the schema (it's for asset-manifest reference
    failures — a real, semantically different signal). What we removed is
    its misuse as the reason for "extraction service returned an
    incomplete artifact set" — that path now emits
    `missing_required_artifacts`.

    The check walks the AST so a passing mention in a comment doesn't
    trip the guard. We're after live `reasons=["asset_unresolved"]`
    string-literal calls, not historical context in code comments.
    """
    import ast

    upload_main_path = ROOT / "services/upload-service/app/main.py"
    upload_main = upload_main_path.read_text()
    tree = ast.parse(upload_main)
    string_literals: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            string_literals.append(node.value)

    assert upload_main.count("missing_required_artifacts") >= 2, (
        "Both incomplete-artifact-set call sites should use the new reason."
    )
    assert "asset_unresolved" not in string_literals, (
        "asset_unresolved appeared as a live string literal in upload-service "
        "main.py — the missing-artifacts path should use missing_required_artifacts."
    )


# ---------------------------------------------------------------------- #
# G1, G2, G6 — route-level behavior (rate-limit, prior_gate, no
# gate_overridden_at/by)
# ---------------------------------------------------------------------- #


def test_override_populates_prior_gate_and_omits_dead_fields(
    service_app_factory, upload_seed_document
) -> None:
    app, module = _load_upload_app(service_app_factory)
    document_id = "doc_g_polish_override"
    failing_gate = {
        "name": "docx_source_fidelity_v1",
        "passed": False,
        "severity": "blocking",
        "blocking_reasons": ["locator_missing"],
        "warnings": [
            {
                "kind": "quality.missing_locator",
                "message": "Pre-override gate had this warning.",
            }
        ],
        "override": None,
        "override_history": [],
    }
    _seed_project_and_document(
        module, upload_seed_document, document_id=document_id, quality_gate=failing_gate
    )

    client = TestClient(app)
    # First override.
    response = client.post(
        f"/internal/documents/{document_id}/override-gate",
        headers=_auth_headers(),
        json={"reason": "Reviewed and approved despite locator gap."},
    )
    assert response.status_code == 200, response.text
    after_first = response.json()
    gate1 = after_first["source_quality"]["quality_gate"]
    assert gate1["override"]["reason"] == "Reviewed and approved despite locator gap."
    assert gate1["override_history"] == []
    # G6: dead duplicate fields are no longer written.
    assert "gate_overridden_at" not in after_first, (
        "Step G6 removed gate_overridden_at; it's a write-only duplicate of "
        "gate.override.at."
    )
    assert "gate_overridden_by" not in after_first

    # Second override — should snapshot the first one's PRIOR gate state.
    response2 = client.post(
        f"/internal/documents/{document_id}/override-gate",
        headers=_auth_headers(),
        json={"reason": "Second override after re-review."},
    )
    assert response2.status_code == 200, response2.text
    gate2 = response2.json()["source_quality"]["quality_gate"]
    assert gate2["override"]["reason"] == "Second override after re-review."
    assert len(gate2["override_history"]) == 1
    historical = gate2["override_history"][0]
    # G2: the snapshot must carry the prior gate's evidence — not just
    # {by, at, reason}. Reviewers need to see WHY the gate was overridden.
    assert "prior_gate" in historical
    assert historical["prior_gate"]["passed"] is False
    assert historical["prior_gate"]["blocking_reasons"] == ["locator_missing"]
    assert (
        historical["prior_gate"]["warnings"][0]["message"]
        == "Pre-override gate had this warning."
    )


def test_reextract_throttles_within_window(
    service_app_factory, monkeypatch, upload_seed_document
) -> None:
    """G1: two re-extracts within 600s → second one 429s. We don't run
    the full extraction (it's irrelevant — the throttle gate runs FIRST
    in the route), we stub out the extraction call.
    """
    app, module = _load_upload_app(service_app_factory)

    # Clear in-memory throttle so prior tests don't bleed in.
    module._reextract_last_attempt_at.clear()

    document_id = "doc_throttle"
    _seed_project_and_document(module, upload_seed_document, document_id=document_id)

    # Stub `run_extraction_request` to a trivial success so the route
    # doesn't actually spawn pandoc/extractor work.
    async def fake_run_extraction_request(**_kwargs: Any) -> dict[str, Any]:
        return {
            "extraction_id": "ex_stub",
            "stage": "completed",
            "artifacts": [],
            "warnings": [],
            "block_count": 0,
            "asset_count": 0,
            "quality_gate": module.legacy_quality_gate(),
        }

    monkeypatch.setattr(module, "run_extraction_request", fake_run_extraction_request)

    client = TestClient(app)
    first = client.post(
        f"/internal/documents/{document_id}/reextract",
        headers=_auth_headers(),
    )
    assert first.status_code == 200, first.text

    # Immediate second attempt should 429.
    second = client.post(
        f"/internal/documents/{document_id}/reextract",
        headers=_auth_headers(),
    )
    assert second.status_code == 429, second.text
    assert "Retry-After" in second.headers
    retry_after = int(second.headers["Retry-After"])
    assert 0 < retry_after <= module.REEXTRACT_THROTTLE_WINDOW_S


# ---------------------------------------------------------------------- #
# G5 — duration_ms > 0 in real extractions
# ---------------------------------------------------------------------- #


def test_duration_ms_is_positive_in_apple_ca_extraction(
    apple_ca_docx_bytes, service_app_factory
) -> None:
    """G5 — wall-clock measurement is real, not the stale 0 the producer
    used to ship. Apple CA's structure-tree + projection phases take more
    than 1ms even on fast hardware (the `max(1, ...)` floor in
    `_assemble_output` guarantees this is meaningful, not a tautology).
    """
    from ditagen_common.artifacts import read_artifact_json, write_artifact
    from ditagen_common.store import JsonStore

    app, _module = service_app_factory(
        "services/extraction-service/app/main.py", "g_polish_extract"
    )
    client = TestClient(app)

    project_id = "prj_g"
    business_unit_id = "bu_docs_ops"
    document_id = "doc_g_duration"
    original_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name=f"original/{document_id}.docx",
        content=apple_ca_docx_bytes,
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        store=JsonStore(),
        created_by="usr_admin",
        producer="upload-service",
    )
    response = client.post(
        "/internal/extractions",
        headers=_auth_headers(),
        json={
            "document_id": document_id,
            "project_id": project_id,
            "business_unit_id": business_unit_id,
            "filename": f"{document_id}.docx",
            "content_type": original_ref["content_type"],
            "artifact_path": original_ref["path"],
            "request_id": "req_g_duration",
            "requested_by": "usr_admin",
        },
    )
    assert response.status_code == 200, response.text
    status = response.json()
    quality_ref = next(a for a in status["artifacts"] if a["name"] == "extraction-quality.json")
    payload = read_artifact_json(quality_ref)
    assert payload["runtime"]["duration_ms"] >= 1, (
        f"Step G5 expected duration_ms >= 1ms after `_assemble_output`'s "
        f"perf_counter wrap; got {payload['runtime']['duration_ms']!r}. "
        "If this is 0, the wrap was bypassed."
    )


# ---------------------------------------------------------------------- #
# G6 — extra grep guard
# ---------------------------------------------------------------------- #


def test_gate_overridden_dead_state_is_no_longer_written() -> None:
    """G6 — grep guard: the upload-service no longer writes the
    duplicate `gate_overridden_at` / `gate_overridden_by` state. They
    were never read (audit found zero consumers in Python, TypeScript,
    or tests), and duplicate state always drifts. If a future change
    reintroduces them, this test fails loudly.
    """
    upload_main = (ROOT / "services/upload-service/app/main.py").read_text()
    assert "current[\"gate_overridden_at\"]" not in upload_main, (
        "gate_overridden_at write reintroduced. Either delete the write or "
        "wire a consumer (UI / event payload / audit metadata). Two "
        "redundant stores of override.at WILL drift."
    )
    assert "current[\"gate_overridden_by\"]" not in upload_main


# Avoid an unused-fixture lint by referencing `pytest` for IDE clarity.
_ = pytest
