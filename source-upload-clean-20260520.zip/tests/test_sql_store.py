from __future__ import annotations

from ditagen_common.sql_store import COLLECTION_OWNERS, SqlStateStore


def test_sql_store_creates_service_owned_tables_and_persists_state(tmp_path) -> None:
    database_url = f"sqlite:///{tmp_path / 'ditagen.db'}"
    store = SqlStateStore(database_url, service_name="business-unit-service")

    state = store.read()
    assert state["users"]
    assert "business_units" in state

    def add_project(state):
        state["projects"]["prj_sql"] = {
            "project_id": "prj_sql",
            "business_unit_id": "bu_docs_ops",
            "tenant_id": "ten_local",
            "organization_id": "org_local",
            "name": "SQL Project",
            "description": None,
            "created_by": "usr_admin",
            "created_at": "2026-05-11T00:00:00Z",
            "updated_at": "2026-05-11T00:00:00Z",
            "status": "active",
            "deleted_at": None,
            "conversion_profile": {
                "target_dita_version": "1.3",
                "allowed_topic_types": ["concept"],
                "review_policy": "manual_approval",
            },
            "document_ids": [],
        }
        return state["projects"]["prj_sql"]

    created = store.mutate(add_project)
    assert created["project_id"] == "prj_sql"

    reloaded = SqlStateStore(database_url, service_name="business-unit-service").read()
    assert reloaded["projects"]["prj_sql"]["name"] == "SQL Project"


def test_collection_owners_are_service_schemas() -> None:
    assert COLLECTION_OWNERS["projects"] == "business_unit_service"
    assert COLLECTION_OWNERS["documents"] == "upload_service"
    assert COLLECTION_OWNERS["topics"] == "review_service"
    assert COLLECTION_OWNERS["extractions"] == "extraction_service"
    assert COLLECTION_OWNERS["audit_events"] == "audit_service"
    assert COLLECTION_OWNERS["revoked_tokens"] == "api_gateway"
