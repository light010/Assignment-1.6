"""Architecture lock — Phase 2 B3 of plans/architecture-hardening.md.

Producer→schema roundtrip coverage for the four artifacts that previously
had no real-extraction validation:

  - `source-lines.jsonl` → `source-line.schema.json`
  - `structure-tree.json` → `structure-tree.schema.json`
  - `asset-manifest.json` → `asset-manifest.schema.json`
  - `style-profile.json` → `style-profile.schema.json`

The B3 audit found these contracts were "first-class but only a subset of
artifacts had producer→schema roundtrip tests." `source-block` and
`extraction-quality` were already covered (`test_block_schema_compliance.py`,
`test_upload_service_polish.py`). Without producer-roundtrip coverage on
the other four, a producer change can silently violate the contract — the
schema becomes documentation, not a gate.

This file runs the real extraction-service pipeline once against a DOCX
fixture, then validates every artifact it emits against its schema. A
failure here means EITHER:

  (a) the producer emitted a field shape the schema rejects (real
      regression — fix the producer), OR
  (b) the schema is wrong (rare — adjust deliberately).

Validation uses `jsonschema.Draft202012Validator.iter_errors` so a single
broken field surfaces every violation at once, not just the first.
"""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
from ditagen_common.artifacts import read_artifact_text
from fastapi.testclient import TestClient

# tests/ isn't a Python package; pytest places it on sys.path via
# `testpaths`, so a bare module import works.
from test_week3_extraction import (  # noqa: E402
    auth_headers,
    create_layered_docx_fixture,
    extraction_payload,
    load_app,
    refs_by_name,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = REPO_ROOT / "contracts" / "artifacts"


def _load_schema(name: str) -> dict:
    return json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))


def _run_extraction_once(tmp_path, monkeypatch) -> dict[str, dict]:
    """Run the extractor against the layered DOCX fixture once. Returns
    `refs_by_name`. The layered fixture exercises both prose and table
    blocks plus an embedded image — covering source-lines + asset
    entries + heading/paragraph structure nodes in one run."""
    app, _module = load_app(
        "services/extraction-service/app/main.py",
        "extraction_artifact_schema_compliance",
        tmp_path,
        monkeypatch,
    )
    payload = extraction_payload(
        document_id="doc_artifact_schema_compliance",
        filename="layered.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        content=create_layered_docx_fixture(tmp_path),
    )
    response = TestClient(app).post(
        "/internal/extractions", json=payload, headers=auth_headers()
    )
    assert response.status_code == 200, response.text
    return refs_by_name(response.json())


def _format_errors(label: str, errors: list[jsonschema.ValidationError]) -> str:
    return f"{label}: " + "; ".join(
        f"{list(e.absolute_path)}: {e.message}" for e in errors
    )


def test_source_lines_jsonl_validates_against_schema(tmp_path, monkeypatch) -> None:
    """Every source-line emitted by the extractor validates.

    `source-lines.jsonl` is JSONL — each line is an independent record
    that must validate against `source-line.schema.json`. A single
    schema-invalid line breaks the line-locator round trip the frontend
    uses for evidence highlighting.
    """
    refs = _run_extraction_once(tmp_path, monkeypatch)
    assert "source-lines.jsonl" in refs, (
        "extraction did not emit source-lines.jsonl — producer regression"
    )
    text = read_artifact_text(refs["source-lines.jsonl"])
    lines = [json.loads(line) for line in text.splitlines() if line.strip()]
    assert lines, "source-lines.jsonl is empty — fixture produced no lines"

    validator = jsonschema.Draft202012Validator(_load_schema("source-line.schema.json"))
    failures: list[str] = []
    for line in lines:
        errors = list(validator.iter_errors(line))
        if errors:
            failures.append(_format_errors(f"line {line.get('line_id')!r}", errors))
    assert not failures, "source-line schema violations:\n" + "\n".join(failures)


def test_structure_tree_validates_against_schema(tmp_path, monkeypatch) -> None:
    """The single structure-tree.json document validates as a whole.

    `structure-tree.schema.json` is `schema_version: 2` with required
    fields `nodes`, `root_nodes`, `quality`. Any producer change to the
    tree shape (new node kind, missing quality envelope, etc.) breaks
    this test before it reaches the frontend's tree-walker.
    """
    refs = _run_extraction_once(tmp_path, monkeypatch)
    assert "structure-tree.json" in refs, (
        "extraction did not emit structure-tree.json — producer regression"
    )
    tree = json.loads(read_artifact_text(refs["structure-tree.json"]))
    schema = _load_schema("structure-tree.schema.json")
    validator = jsonschema.Draft202012Validator(schema)
    errors = list(validator.iter_errors(tree))
    assert not errors, _format_errors("structure-tree", errors)


def test_asset_manifest_validates_against_schema(tmp_path, monkeypatch) -> None:
    """The asset manifest validates, even when assets list is empty.

    The layered DOCX fixture includes one inline image, so the manifest's
    `assets` array has at least one entry. The empty-assets path is
    covered by the schema's `default: []` — checked structurally by the
    Draft 2020-12 validator.
    """
    refs = _run_extraction_once(tmp_path, monkeypatch)
    assert "asset-manifest.json" in refs, (
        "extraction did not emit asset-manifest.json — producer regression"
    )
    manifest = json.loads(read_artifact_text(refs["asset-manifest.json"]))
    schema = _load_schema("asset-manifest.schema.json")
    validator = jsonschema.Draft202012Validator(schema)
    errors = list(validator.iter_errors(manifest))
    assert not errors, _format_errors("asset-manifest", errors)


def test_style_profile_validates_against_schema(tmp_path, monkeypatch) -> None:
    """The style-profile validates against its schema.

    `style-profile.schema.json` requires `font_size_clusters` and
    `heading_rules` — both derived from the source document's typography.
    A producer change that emits an unmapped cluster shape (e.g., a new
    cluster type without updating the schema's discriminator) will fail
    here.
    """
    refs = _run_extraction_once(tmp_path, monkeypatch)
    assert "style-profile.json" in refs, (
        "extraction did not emit style-profile.json — producer regression"
    )
    profile = json.loads(read_artifact_text(refs["style-profile.json"]))
    schema = _load_schema("style-profile.schema.json")
    validator = jsonschema.Draft202012Validator(schema)
    errors = list(validator.iter_errors(profile))
    assert not errors, _format_errors("style-profile", errors)
