"""Phase 4 D4.4.a — upload-service project-scoped endpoint contracts.

Pins the two new endpoints D4.4.b-d will call to remove cross-service
JsonStore subscripts:

  - GET /internal/projects/{project_id}/documents
  - GET /internal/projects/{project_id}/storage-summary

Invariants pinned:

  1. Documents endpoint filters by `document.project_id` (canonical
     signal), not by `project.document_ids` denorm. A document whose
     project_id matches but isn't listed in the BU service denorm
     still appears in the response.
  2. Documents endpoint sorts by `created_at` descending.
  3. Storage-summary aggregates only upload-service-owned data:
     document_count, processing_count, review_ready_count,
     validation_warning_count, failed_job_count, storage_bytes,
     confidence_values, topic_id_count. Topic-status and project-
     metadata fields (review-service-owned + BU-service-owned) are
     intentionally absent.
  4. Both endpoints require project access via BU service; a project
     that doesn't exist or the caller can't see returns 404.
"""

from __future__ import annotations

from typing import Any

import pytest
from ditagen_common.security import issue_token
from ditagen_common.store import JsonStore
from fastapi.testclient import TestClient


def _auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_d4_4a",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_d4_4a"}


@pytest.fixture
def upload_client(service_app_factory):
    """Load BU service first (so request_service can dispatch to it
    in-process for the project access check), then upload-service."""
    service_app_factory(
        "services/business-unit-service/app/main.py", "bu_for_d4_4a"
    )
    app, _module = service_app_factory(
        "services/upload-service/app/main.py", "upload_for_d4_4a"
    )
    return TestClient(app)


def _seed_project_with_documents(
    project_id: str = "prj_seed",
    business_unit_id: str = "bu_docs_ops",
) -> str:
    """Seed a project + 3 documents + matching jobs and artifacts.

    Phase 4 D3.5.c — projects: BU service is SQL-authoritative, so the
    project envelope goes through `ProjectRepository.upsert(...)`.
    Phase 4 D4.5.b — documents: upload-service is SQL-authoritative,
    so document envelopes go through `DocumentRepository.upsert(...)`.
    Jobs + artifact_registry are still JsonStore-backed (D4.5.c /
    D4.5.d will migrate them); those stay in the `store.mutate(add)`
    block below."""
    import sys
    from pathlib import Path

    repo_root = Path(__file__).resolve().parents[1]
    bu_app_dir = repo_root / "services" / "business-unit-service" / "app"
    upload_app_dir = repo_root / "services" / "upload-service" / "app"
    for app_dir in (bu_app_dir, upload_app_dir):
        if str(app_dir) not in sys.path:
            sys.path.insert(0, str(app_dir))
    from bu_repositories import ProjectRepository
    from up_repositories import DocumentRepository

    project_envelope: dict[str, Any] = {
        "project_id": project_id,
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": business_unit_id,
        "name": "D4.4a Test Project",
        "description": None,
        "status": "active",
        "deleted_at": None,
        "document_ids": ["doc_ready", "doc_processing"],
        "conversion_profile": {},
        "created_by": "usr_admin",
        "created_at": "2026-05-12T00:00:00Z",
        "updated_at": "2026-05-12T00:00:00Z",
    }
    ProjectRepository().upsert(project_envelope)

    documents = DocumentRepository()
    _document_defaults: dict[str, Any] = {
        "tenant_id": "ten_local",
        "business_unit_id": business_unit_id,
        "content_type": "text/plain",
        "job_ids": [],
        "topic_ids": [],
        "original_artifact": {},
        "manifest": {},
        "artifacts": {},
        "latest_artifacts": {},
        "extraction": {},
    }
    documents.upsert(
        {
            **_document_defaults,
            "document_id": "doc_ready",
            "project_id": project_id,
            "filename": "ready.txt",
            "source_hash": "h_ready",
            "status": "ready_for_review",
            "job_ids": ["job_ready"],
            "topic_ids": ["t_a", "t_b"],
            "source_quality": {"overall_confidence": 92, "validation_issue_count": 1},
            "created_at": "2026-05-12T00:00:01Z",
        }
    )
    documents.upsert(
        {
            **_document_defaults,
            "document_id": "doc_processing",
            "project_id": project_id,
            "filename": "processing.txt",
            "source_hash": "h_proc",
            "status": "extracting",
            "job_ids": ["job_processing"],
            "source_quality": {"overall_confidence": None, "validation_issue_count": 0},
            "created_at": "2026-05-12T00:00:02Z",
        }
    )
    # A document whose project_id matches but is NOT in the BU service's
    # `project.document_ids` denorm. Pins finding #24: canonical signal
    # is document.project_id, not the denorm.
    documents.upsert(
        {
            **_document_defaults,
            "document_id": "doc_drifted",
            "project_id": project_id,
            "filename": "drifted.txt",
            "source_hash": "h_drift",
            "status": "ready_for_review",
            "source_quality": {"overall_confidence": 70, "validation_issue_count": 0},
            "created_at": "2026-05-12T00:00:03Z",
        }
    )
    # Document in a different project — must not bleed into results.
    documents.upsert(
        {
            **_document_defaults,
            "document_id": "doc_other_project",
            "project_id": "prj_other",
            "filename": "other.txt",
            "source_hash": "h_other",
            "status": "ready_for_review",
            "source_quality": {},
            "created_at": "2026-05-12T00:00:04Z",
        }
    )

    store = JsonStore()

    def add(state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("projects", {})[project_id] = {
            "project_id": project_id,
            "tenant_id": "ten_local",
            "organization_id": "org_local",
            "business_unit_id": business_unit_id,
            "name": "D4.4a Test Project",
            "description": None,
            "status": "active",
            "deleted_at": None,
            "document_ids": ["doc_ready", "doc_processing"],
            "conversion_profile": {},
            "created_by": "usr_admin",
            "created_at": "2026-05-12T00:00:00Z",
            "updated_at": "2026-05-12T00:00:00Z",
        }
        state["jobs"]["job_ready"] = {
            "job_id": "job_ready",
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": "doc_ready",
            "stage": "pipeline",
            "status": "completed",
            "events": [],
            "created_at": "2026-05-12T00:00:01Z",
        }
        state["jobs"]["job_processing"] = {
            "job_id": "job_processing",
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": "doc_processing",
            "stage": "extract",
            "status": "running",
            "events": [],
            "created_at": "2026-05-12T00:00:02Z",
        }
        artifact_defaults = {
            "artifact_version": 1,
            "version": 1,
            "content_type": "application/octet-stream",
            "hash": "h",
            "sha256": "h",
            "path": "/tmp/x",
            "producer": "extraction-service",
            "created_at": "2026-05-12T00:00:00Z",
        }
        state.setdefault("artifact_registry", {})["art_a"] = {
            **artifact_defaults,
            "artifact_id": "art_a",
            "project_id": project_id,
            "document_id": "doc_ready",
            "name": "source-blocks.jsonl",
            "size_bytes": 1024,
        }
        state["artifact_registry"]["art_b"] = {
            **artifact_defaults,
            "artifact_id": "art_b",
            "project_id": project_id,
            "document_id": "doc_drifted",
            "name": "content.md",
            "size_bytes": 256,
        }
        # Artifact in a different project — must not contribute to
        # this project's storage_bytes.
        state["artifact_registry"]["art_other"] = {
            **artifact_defaults,
            "artifact_id": "art_other",
            "project_id": "prj_other",
            "document_id": "doc_other_project",
            "name": "source-blocks.jsonl",
            "size_bytes": 99999,
        }
        return state

    store.mutate(add)
    return project_id


def test_list_project_documents_filters_by_document_project_id(upload_client) -> None:
    """The canonical signal is `document.project_id`, not the BU
    service's `project.document_ids` denorm. A document whose
    project_id matches but isn't in the denorm still appears."""
    project_id = _seed_project_with_documents()
    response = upload_client.get(
        f"/internal/projects/{project_id}/documents",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text

    body = response.json()
    assert body["project_id"] == project_id
    returned_ids = {doc["document_id"] for doc in body["documents"]}
    # doc_drifted is in this project (project_id matches) but absent
    # from `project.document_ids`. It MUST appear.
    assert returned_ids == {"doc_ready", "doc_processing", "doc_drifted"}
    # doc_other_project is in a different project — MUST NOT appear.
    assert "doc_other_project" not in returned_ids


def test_list_project_documents_sorts_by_created_at_descending(upload_client) -> None:
    project_id = _seed_project_with_documents()
    response = upload_client.get(
        f"/internal/projects/{project_id}/documents",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    ordered = [doc["document_id"] for doc in response.json()["documents"]]
    # created_at descending: doc_drifted (00:03) > doc_processing (00:02) > doc_ready (00:01)
    assert ordered == ["doc_drifted", "doc_processing", "doc_ready"]


def test_list_project_documents_unknown_project_returns_404(upload_client) -> None:
    response = upload_client.get(
        "/internal/projects/prj_does_not_exist/documents",
        headers=_auth_headers(),
    )
    assert response.status_code == 404


def test_storage_summary_aggregates_upload_side_counters(upload_client) -> None:
    project_id = _seed_project_with_documents()
    response = upload_client.get(
        f"/internal/projects/{project_id}/storage-summary",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text

    body = response.json()
    assert body["project_id"] == project_id
    # 3 documents in project: doc_ready, doc_processing, doc_drifted.
    assert body["document_count"] == 3
    # 1 job with status "running" → processing_count
    assert body["processing_count"] == 1
    # 2 documents with status "ready_for_review": doc_ready + doc_drifted
    assert body["review_ready_count"] == 2
    # 1 validation issue on doc_ready, 0 elsewhere → 1 total
    assert body["validation_warning_count"] == 1
    # No failed jobs
    assert body["failed_job_count"] == 0
    # art_a (1024) + art_b (256) = 1280; art_other doesn't count
    assert body["storage_bytes"] == 1280
    # Only 2 documents have non-None overall_confidence (92 + 70)
    assert sorted(body["confidence_values"]) == [70, 92]
    # 2 topic_ids on doc_ready, 0 on others
    assert body["topic_id_count"] == 2


def test_storage_summary_unknown_project_returns_404(upload_client) -> None:
    response = upload_client.get(
        "/internal/projects/prj_does_not_exist/storage-summary",
        headers=_auth_headers(),
    )
    assert response.status_code == 404


def test_storage_summary_excludes_review_and_project_metadata_fields(
    upload_client,
) -> None:
    """The storage-summary endpoint MUST NOT include review-service-
    owned fields (approved_topics, export_ready_count) or project-
    metadata fields (last_activity_at). Those belong in BU service's
    aggregation layer."""
    project_id = _seed_project_with_documents()
    response = upload_client.get(
        f"/internal/projects/{project_id}/storage-summary",
        headers=_auth_headers(),
    )
    body = response.json()
    for forbidden in (
        "approved_topics",
        "export_ready_count",
        "last_activity_at",
        "topic_count",  # review-service derives this from canonical topics
    ):
        assert forbidden not in body, f"{forbidden} leaked into storage-summary"
