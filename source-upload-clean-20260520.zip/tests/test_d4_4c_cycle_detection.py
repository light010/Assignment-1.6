"""Phase 4 D4.4.c — cycle-detection lock for the
`business_unit_summary → project_status_summary → upload-service`
chain.

Finding #66 (D4.4.b retrospective): when a cross-service edge becomes
recursive, write the cycle-detection test FIRST. The D4.4.b hang
cost ~30 min of debugging; a test like this would have fired in ms.

The chain we're about to introduce in D4.4.c:

  BU.list_business_units
    → business_unit_summary(bu, state, user)             (async)
      → project_status_summary(project, request, user)   (async)
        → GET /internal/projects/{id}/storage-summary    (upload-service)
          → _require_project_via_bu_service(project_id)  (in upload-service)
            → GET /internal/projects/{id}?include_documents=false  (BU)
              → returns raw project (no further calls — cycle terminates)

If any future change to either of these helpers re-introduces a path
that calls back into the entry point, the test below times out
within a few seconds rather than hanging. The cycle-breaker is the
`include_documents=false` opt-out added in D4.4.b.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest
from ditagen_common.security import issue_token
from ditagen_common.store import JsonStore
from fastapi.testclient import TestClient


def _auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_d4_4c_cycle",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_d4_4c"}


@pytest.fixture
def bu_client_with_upload(service_app_factory):
    """Load upload-service first so request_service can dispatch to
    it in-process, then BU service for the entry point."""
    service_app_factory(
        "services/upload-service/app/main.py", "upload_d4_4c_cycle"
    )
    app, _module = service_app_factory(
        "services/business-unit-service/app/main.py", "bu_d4_4c_cycle"
    )
    return TestClient(app)


def _seed_minimal_state() -> None:
    """Seed one BU + one project + one document so list_business_units
    has something to summarize. Minimal — enough to trigger the
    chain, not enough to slow the test."""
    import sys
    from pathlib import Path

    bu_app_dir = (
        Path(__file__).resolve().parents[1]
        / "services"
        / "business-unit-service"
        / "app"
    )
    if str(bu_app_dir) not in sys.path:
        sys.path.insert(0, str(bu_app_dir))
    from bu_repositories import ProjectRepository

    project_envelope: dict[str, Any] = {
        "project_id": "prj_cycle_test",
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": "bu_docs_ops",
        "name": "Cycle Detection",
        "description": None,
        "status": "active",
        "deleted_at": None,
        "document_ids": ["doc_cycle"],
        "conversion_profile": {},
        "created_by": "usr_admin",
        "created_at": "2026-05-13T00:00:00Z",
        "updated_at": "2026-05-13T00:00:00Z",
    }
    ProjectRepository().upsert(project_envelope)

    store = JsonStore()

    def add(state: dict[str, Any]) -> dict[str, Any]:
        state["documents"]["doc_cycle"] = {
            "document_id": "doc_cycle",
            "tenant_id": "ten_local",
            "business_unit_id": "bu_docs_ops",
            "project_id": "prj_cycle_test",
            "filename": "cycle.txt",
            "source_hash": "h_cycle",
            "status": "ready_for_review",
            "job_ids": [],
            "topic_ids": [],
            "source_quality": {"overall_confidence": 80, "validation_issue_count": 0},
            "latest_artifacts": {},
            "created_at": "2026-05-13T00:00:01Z",
        }
        return state

    store.mutate(add)


def test_list_business_units_terminates_quickly(bu_client_with_upload) -> None:
    """The BU service summary chain must terminate without recursion.

    A 5-second wall-clock cap is plenty — the in-process round-trip
    is milliseconds. If this fires the test framework's per-test
    timeout (pytest-anyio default ~30s), the cycle-breaker
    (`include_documents=false`) has been removed or bypassed.
    """
    _seed_minimal_state()

    async def call_with_timeout() -> Any:
        return await asyncio.wait_for(
            asyncio.to_thread(
                bu_client_with_upload.get,
                "/internal/business-units",
                headers=_auth_headers(),
            ),
            timeout=5.0,
        )

    response = asyncio.run(call_with_timeout())
    assert response.status_code == 200, response.text
    body = response.json()
    # Sanity: the chain produced the seeded BU with non-zero data.
    bus = body["business_units"]
    assert any(item["business_unit_id"] == "bu_docs_ops" for item in bus)


def test_get_project_with_include_documents_false_does_not_join(
    bu_client_with_upload,
) -> None:
    """The cycle-breaker contract: `?include_documents=false` MUST
    return a project envelope WITHOUT a `documents` key. Without
    this, upload-service's access check would still trigger the
    documents-join which calls back into upload-service and
    recurses."""
    _seed_minimal_state()
    response = bu_client_with_upload.get(
        "/internal/projects/prj_cycle_test?include_documents=false",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["project_id"] == "prj_cycle_test"
    assert "documents" not in body, (
        "include_documents=false MUST omit the documents join — "
        "without this the upload-service access-check would recurse "
        "(D4.4.b finding #65)."
    )

    # Sanity: default (include_documents=true) returns documents.
    with_docs = bu_client_with_upload.get(
        "/internal/projects/prj_cycle_test",
        headers=_auth_headers(),
    )
    assert with_docs.status_code == 200
    assert "documents" in with_docs.json()
