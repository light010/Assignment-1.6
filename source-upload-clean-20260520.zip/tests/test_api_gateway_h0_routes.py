"""Step H0 — api-gateway proxy routes for reextract / override-gate /
extraction-quality.json.

Lock the gateway routing surface so a future refactor can't quietly
remove these proxies and re-create the dead-surface bug that blocked
Step H from working at all (UI calls 404 on every reextract/override).
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import cast

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]


def _load_gateway(tmp_path, monkeypatch):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    module_path = ROOT / "services/api-gateway/app/main.py"
    spec = importlib.util.spec_from_file_location("h0_gateway", module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules["h0_gateway"] = module
    spec.loader.exec_module(module)
    return module.app


def _load_upload_service(tmp_path, monkeypatch):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    module_path = ROOT / "services/upload-service/app/main.py"
    module_name = "h0_upload_service"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.app


def _routes(app) -> set[tuple[str, str]]:
    """Return (method, path) tuples for declared routes."""
    found: set[tuple[str, str]] = set()
    for route in app.routes:
        path = getattr(route, "path", None)
        methods = getattr(route, "methods", None) or set()
        for method in methods:
            if path:
                found.add((method, path))
    return found


def _has_dependency(route, dependency) -> bool:
    dependant = getattr(route, "dependant", None)
    if dependant is None:
        return False
    stack = list(getattr(dependant, "dependencies", []))
    while stack:
        current = stack.pop()
        if getattr(current, "call", None) is dependency:
            return True
        stack.extend(getattr(current, "dependencies", []))
    return False


def test_all_v1_gateway_routes_require_auth_except_explicit_public_routes(
    tmp_path, monkeypatch
) -> None:
    app = _load_gateway(tmp_path, monkeypatch)
    module = sys.modules["h0_gateway"]
    public_routes = {("/v1/auth/login", "POST"), ("/v1/auth/refresh", "POST")}
    violations: list[str] = []
    for route in app.routes:
        path = getattr(route, "path", "")
        methods = cast(set[str], getattr(route, "methods", set()) or set())
        if not path.startswith("/v1/"):
            continue
        for method in methods:
            if method in {"HEAD", "OPTIONS"} or (path, method) in public_routes:
                continue
            if not _has_dependency(route, module.current_user):
                violations.append(f"{method} {path}")

    assert not violations, "Gateway /v1 routes missing current_user dependency: " + ", ".join(
        sorted(violations)
    )


def test_gateway_exposes_reextract_route(tmp_path, monkeypatch) -> None:
    app = _load_gateway(tmp_path, monkeypatch)
    routes = _routes(app)
    assert ("POST", "/v1/documents/{document_id}/reextract") in routes, (
        "Step H0 finding regression: api-gateway must proxy "
        "POST /v1/documents/{id}/reextract to upload-service. Without it "
        "the UI re-extract button returns HTTP 404."
    )


def test_gateway_exposes_override_gate_route(tmp_path, monkeypatch) -> None:
    app = _load_gateway(tmp_path, monkeypatch)
    routes = _routes(app)
    assert ("POST", "/v1/documents/{document_id}/override-gate") in routes, (
        "Step H0 finding regression: api-gateway must proxy "
        "POST /v1/documents/{id}/override-gate to upload-service."
    )


def test_gateway_exposes_extraction_quality_artifact_route(tmp_path, monkeypatch) -> None:
    app = _load_gateway(tmp_path, monkeypatch)
    routes = _routes(app)
    assert (
        "GET",
        "/v1/documents/{document_id}/artifacts/extraction-quality.json",
    ) in routes, (
        "Step H0 finding regression: api-gateway must proxy "
        "GET /v1/documents/{id}/artifacts/extraction-quality.json so the "
        "H3 unlocated-chip lazy fetch can reach the artifact."
    )


def test_gateway_document_routes_mirror_upload_service_document_routes(
    tmp_path, monkeypatch
) -> None:
    gateway_routes = _routes(_load_gateway(tmp_path, monkeypatch))
    upload_routes = _routes(_load_upload_service(tmp_path, monkeypatch))

    expected = {
        (method, path.replace("/internal/", "/v1/", 1))
        for method, path in upload_routes
        if path.startswith("/internal/documents/")
        and method in {"GET", "POST", "PATCH", "DELETE", "PUT"}
    }
    missing = sorted(expected - gateway_routes)
    assert not missing, "Gateway is missing upload-service document mirrors: " + ", ".join(
        f"{method} {path}" for method, path in missing
    )


def test_gateway_reextract_proxies_to_upload_service(tmp_path, monkeypatch) -> None:
    """End-to-end smoke: hit the gateway route and assert it dispatches to
    upload-service (we expect 401/403 here since we don't set auth — the
    point is that it reaches the proxy, not 404)."""
    app = _load_gateway(tmp_path, monkeypatch)
    client = TestClient(app)
    response = client.post("/v1/documents/doc_anything/reextract")
    assert response.status_code != 404, (
        f"Gateway returned 404 for /reextract — route is not wired. "
        f"Body: {response.text[:200]}"
    )
