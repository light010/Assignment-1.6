from __future__ import annotations

import asyncio
import importlib.util
import sys
from pathlib import Path
from typing import Any

from ditagen_common.security import issue_token
from ditagen_common.service_clients import list_audit_events
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]


def configure_services(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")


def load_app(relative: str, module_name: str, tmp_path, monkeypatch):
    configure_services(tmp_path, monkeypatch)
    module_path = ROOT / relative
    full_module_name = f"{module_name}_{abs(hash(str(tmp_path)))}"
    app_dir = str(module_path.parent)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    spec = importlib.util.spec_from_file_location(full_module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[full_module_name] = module
    spec.loader.exec_module(module)
    return module.app


def auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_test_week2"}


def first_business_unit_id() -> str:
    return "bu_docs_ops"


def _audit_events_via_service() -> list[dict[str, Any]]:
    """Phase 4 D2.7c — read events from audit-service (canonical source),
    not from `JsonStore().read()["audit_events"]` which no longer exists."""
    response = asyncio.run(list_audit_events(headers=auth_headers()))
    return response["events"]


def create_project(client: TestClient) -> dict[str, Any]:
    response = client.post(
        "/internal/projects",
        json={
            "business_unit_id": first_business_unit_id(),
            "name": "Week 2 Project",
            "description": "Service-owned",
        },
        headers=auth_headers(),
    )
    assert response.status_code == 200
    return response.json()


def test_business_unit_seed_membership_and_crud(tmp_path, monkeypatch) -> None:
    app = load_app("services/business-unit-service/app/main.py", "business_unit_service_bu_test", tmp_path, monkeypatch)
    client = TestClient(app)

    seeded = client.get("/internal/business-units", headers=auth_headers())
    assert seeded.status_code == 200
    business_units = seeded.json()["business_units"]
    assert {item["business_unit_id"] for item in business_units} == {
        "bu_docs_ops",
        "bu_product_content",
        "bu_compliance",
    }
    assert all(item["summary"]["current_user_role"] == "org_admin" for item in business_units)

    reviewer_units = client.get("/internal/business-units", headers=auth_headers("usr_reviewer"))
    assert reviewer_units.status_code == 200
    assert [item["business_unit_id"] for item in reviewer_units.json()["business_units"]] == [
        "bu_docs_ops"
    ]

    reviewer_create = client.post(
        "/internal/business-units",
        json={"name": "Denied BU"},
        headers=auth_headers("usr_reviewer"),
    )
    assert reviewer_create.status_code == 403

    created = client.post(
        "/internal/business-units",
        json={"name": "Learning Content", "owner_team": "Education", "region": "EMEA"},
        headers=auth_headers(),
    )
    assert created.status_code == 200
    business_unit_id = created.json()["business_unit_id"]
    assert created.json()["summary"]["project_count"] == 0

    updated = client.patch(
        f"/internal/business-units/{business_unit_id}",
        json={"description": "Updated portfolio"},
        headers=auth_headers(),
    )
    assert updated.status_code == 200
    assert updated.json()["description"] == "Updated portfolio"

    archived = client.delete(f"/internal/business-units/{business_unit_id}", headers=auth_headers())
    assert archived.status_code == 200
    assert archived.json()["status"] == "archived"

    actions = [event["action"] for event in _audit_events_via_service()]
    assert {"business_unit.created", "business_unit.updated", "business_unit.deleted"} <= set(actions)


def test_business_unit_service_crud_membership_and_audit(tmp_path, monkeypatch) -> None:
    app = load_app("services/business-unit-service/app/main.py", "business_unit_service_test", tmp_path, monkeypatch)
    client = TestClient(app)

    reviewer_create = client.post(
        "/internal/projects",
        json={"business_unit_id": first_business_unit_id(), "name": "Denied"},
        headers=auth_headers("usr_reviewer"),
    )
    assert reviewer_create.status_code == 403

    missing_business_unit = client.post(
        "/internal/projects",
        json={"name": "Missing BU"},
        headers=auth_headers(),
    )
    assert missing_business_unit.status_code == 422

    project = create_project(client)
    project_id = project["project_id"]
    assert project["business_unit_id"] == first_business_unit_id()
    assert project["conversion_profile"]["target_dita_version"] == "1.3"

    # Phase 4 D3.5.c: project_memberships moved off JsonStore. Read
    # from BU service's SQL via the repo (the canonical source).
    from bu_repositories import ProjectMembershipRepository
    memberships = ProjectMembershipRepository().list_for_user("usr_admin")
    assert any(item["project_id"] == project_id for item in memberships)

    listed = client.get(
        "/internal/projects",
        params={"business_unit_id": first_business_unit_id()},
        headers=auth_headers(),
    )
    assert listed.status_code == 200
    assert [item["project_id"] for item in listed.json()["projects"]] == [project_id]

    updated = client.patch(
        f"/internal/projects/{project_id}",
        json={"name": "Updated Week 2"},
        headers=auth_headers(),
    )
    assert updated.status_code == 200
    assert updated.json()["name"] == "Updated Week 2"

    reviewer_update = client.patch(
        f"/internal/projects/{project_id}",
        json={"name": "Denied"},
        headers=auth_headers("usr_reviewer"),
    )
    assert reviewer_update.status_code == 403

    archived = client.delete(f"/internal/projects/{project_id}", headers=auth_headers())
    assert archived.status_code == 200
    assert archived.json()["status"] == "archived"

    listed_after_archive = client.get(
        "/internal/projects",
        params={"business_unit_id": first_business_unit_id()},
        headers=auth_headers(),
    )
    assert listed_after_archive.status_code == 200
    assert listed_after_archive.json()["projects"] == []

    direct_get = client.get(f"/internal/projects/{project_id}", headers=auth_headers())
    assert direct_get.status_code == 200
    assert direct_get.json()["status"] == "archived"

    actions = [event["action"] for event in _audit_events_via_service()]
    assert {"project.created", "project.updated", "project.deleted"} <= set(actions)
    # Phase 4 D3.5.c: projects live in BU service SQL. The invariant
    # being asserted is "every project has a non-empty business_unit_id"
    # — read from the canonical repo.
    from bu_repositories import ProjectRepository
    all_projects = ProjectRepository().list_for_tenant("ten_local", include_archived=True)
    assert all(project["business_unit_id"] for project in all_projects)


def test_upload_service_direct_and_session_uploads(tmp_path, monkeypatch) -> None:
    project_app = load_app("services/business-unit-service/app/main.py", "business_unit_service_upload_test", tmp_path, monkeypatch)
    project = create_project(TestClient(project_app))

    upload_app = load_app("services/upload-service/app/main.py", "upload_service_test", tmp_path, monkeypatch)
    client = TestClient(upload_app)
    project_id = project["project_id"]

    unsupported = client.post(
        f"/internal/projects/{project_id}/documents/uploads",
        files={"file": ("sample.exe", b"nope", "application/octet-stream")},
        headers=auth_headers(),
    )
    assert unsupported.status_code == 400

    oversized = client.post(
        f"/internal/projects/{project_id}/documents/uploads",
        json={"filename": "large.pdf", "size_bytes": 250 * 1024 * 1024 + 1},
        headers=auth_headers(),
    )
    assert oversized.status_code == 413

    direct = client.post(
        f"/internal/projects/{project_id}/documents/uploads",
        files={
            "file": (
                "sample.txt",
                b"Install the Connector\nClick Save to apply DEFAULT_PROFILE.\n",
                "text/plain",
            )
        },
        headers=auth_headers(),
    )
    assert direct.status_code == 200
    document = direct.json()["document"]
    assert document["status"] == "ready_for_review"

    bu_upload = client.post(
        f"/internal/business-units/{first_business_unit_id()}/documents/uploads",
        files={"file": ("bu-sample.txt", b"Business unit upload\n", "text/plain")},
        headers=auth_headers(),
    )
    assert bu_upload.status_code == 200
    assert "project" not in bu_upload.json()

    bu_documents = client.get(
        f"/internal/business-units/{first_business_unit_id()}/documents",
        headers=auth_headers(),
    )
    assert bu_documents.status_code == 200
    assert any(item["filename"] == "bu-sample.txt" for item in bu_documents.json()["documents"])

    artifacts = client.get(f"/internal/documents/{document['document_id']}/artifacts", headers=auth_headers())
    assert artifacts.status_code == 200
    registry_names = {item["name"] for item in artifacts.json()["registry"]}
    assert "source-blocks.jsonl" in registry_names
    assert "document-manifest.json" in registry_names
    assert "original/sample.txt" in registry_names

    jobs = client.get(f"/internal/documents/{document['document_id']}/jobs", headers=auth_headers())
    assert jobs.status_code == 200
    assert jobs.json()["jobs"][0]["events"][0] == "document.uploaded"

    markdown = client.get(f"/internal/documents/{document['document_id']}/markdown", headers=auth_headers())
    assert markdown.status_code == 200
    assert "Install the Connector" in markdown.json()["markdown"]

    session = client.post(
        f"/internal/projects/{project_id}/documents/uploads",
        json={"filename": "session.txt", "content_type": "text/plain", "size_bytes": 18},
        headers=auth_headers(),
    )
    assert session.status_code == 200
    upload_id = session.json()["upload_id"]

    part = client.post(
        f"/internal/uploads/{upload_id}/parts",
        json={"content": "Session upload body", "part_number": 1},
        headers=auth_headers(),
    )
    assert part.status_code == 200
    assert part.json()["status"] == "receiving"

    completed = client.post(f"/internal/uploads/{upload_id}/complete", headers=auth_headers())
    assert completed.status_code == 200
    assert completed.json()["document"]["upload_id"] == upload_id

    actions = [event["action"] for event in _audit_events_via_service()]
    assert "upload.session.created" in actions
    assert "document.uploaded" in actions
    uploaded_events = [
        event for event in _audit_events_via_service() if event["action"] == "document.uploaded"
    ]
    assert uploaded_events
    assert all(event["business_unit_id"] == first_business_unit_id() for event in uploaded_events)


def test_gateway_proxies_week2_routes_and_context(tmp_path, monkeypatch) -> None:
    app = load_app("services/api-gateway/app/main.py", "gateway_week2_test", tmp_path, monkeypatch)
    client = TestClient(app)

    login = client.post(
        "/v1/auth/login",
        json={"email": "admin@ditagen.local", "password": "admin123"},
    )
    assert login.status_code == 200
    headers = {
        "Authorization": f"Bearer {login.json()['access_token']}",
        "X-Request-ID": "req_gateway_proxy",
    }

    business_units = client.get("/v1/business-units", headers=headers)
    assert business_units.status_code == 200
    business_unit_id = business_units.json()["business_units"][0]["business_unit_id"]

    project_without_bu = client.post("/v1/projects", json={"name": "Missing BU"}, headers=headers)
    assert project_without_bu.status_code == 422

    project = client.post(
        "/v1/projects",
        json={"business_unit_id": business_unit_id, "name": "Gateway Proxy"},
        headers=headers,
    )
    assert project.status_code == 200
    project_id = project.json()["project_id"]
    assert project.json()["business_unit_id"] == business_unit_id

    activity = client.get(f"/v1/projects/{project_id}/activity", headers=headers)
    assert activity.status_code == 200
    created_event = next(event for event in activity.json()["events"] if event["action"] == "project.created")
    assert created_event["metadata"]["request_id"] == "req_gateway_proxy"
    assert created_event["metadata"]["context_actor_id"] == "usr_admin"
    assert created_event["business_unit_id"] == business_unit_id

    business_unit_activity = client.get(
        f"/v1/business-units/{business_unit_id}/activity",
        headers=headers,
    )
    assert business_unit_activity.status_code == 200
    assert any(
        event["action"] == "project.created"
        for event in business_unit_activity.json()["events"]
    )

    bad_upload = client.post(
        f"/v1/business-units/{business_unit_id}/documents/uploads",
        files={"file": ("sample.exe", b"nope", "application/octet-stream")},
        headers=headers,
    )
    assert bad_upload.status_code == 400
    assert "Alpha upload supports" in bad_upload.text

    upload = client.post(
        f"/v1/business-units/{business_unit_id}/documents/uploads",
        files={"file": ("sample.txt", b"Gateway upload\n", "text/plain")},
        headers=headers,
    )
    assert upload.status_code == 200
    document_id = upload.json()["document"]["document_id"]

    documents = client.get(f"/v1/business-units/{business_unit_id}/documents", headers=headers)
    assert documents.status_code == 200
    assert any(item["document_id"] == document_id for item in documents.json()["documents"])

    artifacts = client.get(f"/v1/documents/{document_id}/artifacts", headers=headers)
    assert artifacts.status_code == 200
    assert artifacts.json()["registry"]
    assert all("producer" in item for item in artifacts.json()["registry"])

    source_quality = client.get(f"/v1/documents/{document_id}/source-quality", headers=headers)
    assert source_quality.status_code == 200
    assert "warnings" in source_quality.json()

    blocks = client.get(f"/v1/documents/{document_id}/blocks", headers=headers)
    assert blocks.status_code == 200
    assert blocks.json()["items"]

    assets = client.get(f"/v1/documents/{document_id}/assets", headers=headers)
    assert assets.status_code == 200
    assert "assets" in assets.json()

    jobs = client.get(f"/v1/documents/{document_id}/jobs", headers=headers)
    assert jobs.status_code == 200
    assert jobs.json()["jobs"][0]["status"] == "completed"


def test_gateway_project_and_business_unit_routes_do_not_use_store_directly() -> None:
    source = (ROOT / "services/api-gateway/app/main.py").read_text(encoding="utf-8")
    forbidden = ("store.read()", "store.mutate(")
    route_names = ("proxy_business_units", "proxy_business_unit", "proxy_projects", "proxy_project")
    for route_name in route_names:
        start = source.index(f"async def {route_name}")
        end = source.find("\n\n@app.", start)
        body = source[start:end if end != -1 else len(source)]
        assert not any(item in body for item in forbidden), route_name
