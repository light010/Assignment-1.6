"""validation-service tests (Phase 7).

Covers:
  - Roundtrip: malformed DITA produces expected codes; valid DITA
    returns no issues.
  - Latency: single-topic validation completes well under 200ms on
    representative payloads (locks the synchronous-after-edit
    guarantee that review-service depends on).
  - Audit envelope: every single-topic validation emits exactly one
    `dita.validation.completed` event with error/warning counts.
  - End-to-end: review-service apply_edit_op writes
    `validation_issues` onto the projected topic.
"""

from __future__ import annotations

import time
from typing import Any

import pytest
from _docx_fixtures import build_block_payload
from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_phase7"}


def _audit_events_via_service() -> list[dict[str, Any]]:
    """Phase 4 D2.7c — events live in audit-service, not state.audit_events."""
    import asyncio

    from ditagen_common.service_clients import list_audit_events

    response = asyncio.run(list_audit_events(headers=_auth_headers()))
    return response["events"]


@pytest.fixture
def validation_app(service_app_factory, tmp_jsonstore):
    app, module = service_app_factory(
        "services/validation-service/app/main.py", "phase7_validation_service"
    )
    return app, module


# ---------------------------------------------------------------------------
# Roundtrip: malformed + valid + missing-asset
# ---------------------------------------------------------------------------


def test_validate_topic_returns_empty_for_well_formed_dita(validation_app) -> None:
    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/topic",
        headers=_auth_headers(),
        json={
            "topic_id": "tpc_one",
            "dita_xml": "<concept id='tpc_one'><title>Topic One</title></concept>",
            "asset_manifest": {"assets": []},
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["validation_issues"] == []
    assert body["error_count"] == 0
    assert body["warning_count"] == 0


def test_validate_topic_flags_xml_not_well_formed(validation_app) -> None:
    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/topic",
        headers=_auth_headers(),
        json={
            "topic_id": "tpc_bad",
            "dita_xml": "<concept><title>Unclosed</title>",  # missing </concept>
            "asset_manifest": {"assets": []},
        },
    )
    assert response.status_code == 200
    body = response.json()
    codes = [issue["code"] for issue in body["validation_issues"]]
    assert "xml_not_well_formed" in codes
    assert body["error_count"] >= 1


def test_validate_topic_flags_missing_title(validation_app) -> None:
    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/topic",
        headers=_auth_headers(),
        json={
            "topic_id": "tpc_no_title",
            "dita_xml": "<concept id='x'><body><p>No title.</p></body></concept>",
            "asset_manifest": {"assets": []},
        },
    )
    assert response.status_code == 200
    body = response.json()
    codes = [issue["code"] for issue in body["validation_issues"]]
    assert "missing_title" in codes


def test_validate_topic_flags_unsupported_root(validation_app) -> None:
    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/topic",
        headers=_auth_headers(),
        json={
            "topic_id": "tpc_weird",
            "dita_xml": "<bookmap><title>Wrong root</title></bookmap>",
            "asset_manifest": {"assets": []},
        },
    )
    assert response.status_code == 200
    body = response.json()
    codes = [issue["code"] for issue in body["validation_issues"]]
    assert "unsupported_topic_root" in codes


def test_validate_dita_files_set_returns_per_file_issues(validation_app) -> None:
    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/dita-files",
        headers=_auth_headers(),
        json={
            "dita_files": {
                "topics/good.dita": "<concept id='g'><title>Good</title></concept>",
                "topics/bad.dita": "<concept><title>Unclosed",
            },
            "asset_manifest": {"assets": []},
        },
    )
    assert response.status_code == 200
    body = response.json()
    by_path = {issue["path"]: issue["code"] for issue in body["validation_issues"]}
    assert by_path.get("topics/bad.dita") == "xml_not_well_formed"
    assert "topics/good.dita" not in by_path
    assert body["error_count"] >= 1


# ---------------------------------------------------------------------------
# Latency: single-topic validation under 200ms
# ---------------------------------------------------------------------------


def test_validate_topic_latency_well_under_200ms(validation_app) -> None:
    """Lock the contract that review-service can call validation
    synchronously after every edit-op without making the workbench
    feel laggy. Hard limit is 200ms; in practice a rule-based
    validator on a single topic runs in single-digit ms — but even a
    slow CI environment must stay well under 200ms."""
    app, _module = validation_app
    client = TestClient(app)
    payload = {
        "topic_id": "tpc_latency",
        "dita_xml": (
            "<concept id='latency'>"
            "<title>Latency target</title>"
            "<body><p>" + ("Sample paragraph. " * 200) + "</p></body>"
            "</concept>"
        ),
        "asset_manifest": {"assets": []},
    }
    # Warm up the client + import paths.
    client.post("/internal/validation/topic", headers=_auth_headers(), json=payload)
    elapsed_samples: list[float] = []
    for _ in range(5):
        start = time.perf_counter()
        response = client.post(
            "/internal/validation/topic", headers=_auth_headers(), json=payload
        )
        elapsed_samples.append(time.perf_counter() - start)
        assert response.status_code == 200
    median_ms = sorted(elapsed_samples)[len(elapsed_samples) // 2] * 1000
    assert median_ms < 200, (
        f"single-topic validation median latency {median_ms:.2f}ms exceeds 200ms; "
        "review-service synchronous-after-edit guarantee at risk"
    )


# ---------------------------------------------------------------------------
# Audit envelope
# ---------------------------------------------------------------------------


def test_validate_topic_emits_dita_validation_completed_event(validation_app) -> None:

    app, _module = validation_app
    client = TestClient(app)
    response = client.post(
        "/internal/validation/topic",
        headers=_auth_headers(),
        json={
            "topic_id": "tpc_event",
            "dita_xml": "<concept id='e'><title>Event</title></concept>",
            "asset_manifest": {"assets": []},
            "business_unit_id": "bu_docs_ops",
            "project_id": "prj_phase7",
        },
    )
    assert response.status_code == 200
    audit = _audit_events_via_service()
    events = [e for e in audit if e.get("action") == "dita.validation.completed"]
    assert len(events) == 1
    event = events[0]
    assert event["resource_type"] == "topic"
    assert event["resource_id"] == "tpc_event"
    assert event["business_unit_id"] == "bu_docs_ops"
    assert event["project_id"] == "prj_phase7"
    assert "error_count" in event["metadata"]
    assert "warning_count" in event["metadata"]


# ---------------------------------------------------------------------------
# End-to-end: review-service writes validation_issues onto projected topic
# ---------------------------------------------------------------------------


def _seed_minimal_topic(document_id: str) -> tuple[str, str]:
    """Reuse the helper pattern from test_review_service_ops without the
    full block setup — these tests don't replay block-touching ops."""
    import json

    from ditagen_common.artifacts import write_artifact
    from ditagen_common.ids import new_id
    from ditagen_common.store import JsonStore

    store = JsonStore()
    project_id = "prj_phase7"
    business_unit_id = "bu_docs_ops"
    tenant_id = "ten_local"

    # Step D0b migration: hand-built 30-line dict → shared helper that
    # goes through the Block model. Drift between this test's input shape
    # and the producer's `_source_block` output shape is now structurally
    # impossible (the helper IS the model).
    block = build_block_payload(
        block_id="blk_a",
        text="Alpha.",
        block_type="paragraph",
        document_id=document_id,
        page=1,
        confidence={"extraction": 0.9, "block_type": 0.85, "semantic_inline": 0.7},
        source_line_ids=["line_a"],
        order_in_page=1,
        char_start=0,
        char_end=6,
    )
    blocks_jsonl = json.dumps(block, sort_keys=True) + "\n"
    blocks_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="source-blocks.jsonl",
        content=blocks_jsonl,
        content_type="application/x-jsonlines",
        store=store,
        created_by="usr_admin",
        producer="extraction-service",
    )
    rid = new_id("trc")

    def add(state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("projects", {})[project_id] = {
            "project_id": project_id,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "name": "Phase 7 Test",
            "status": "active",
            "document_ids": [document_id],
            "deleted_at": None,
        }
        state["extractions"][document_id] = {
            "extraction_id": document_id,
            "document_id": document_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "stage": "markdown_complete",
            "started_at": "2026-05-09T00:00:00Z",
            "finished_at": "2026-05-09T00:00:01Z",
            "error": None,
            "artifacts": [blocks_ref],
            "warnings": [],
            "events": [],
            "block_count": 1,
            "asset_count": 0,
        }
        state["topics"][rid] = {
            "topic_record_id": rid,
            "topic_id": rid,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "status": "generated",
            "title": "Topic One",
            "short_desc": None,
            "topic_type": "concept",
            "source_block_ids": ["blk_a"],
            "dita_xml": "<concept id='tpc_one'><title>Topic One</title></concept>",
            "generated_topic": {
                "topic_id": rid,
                "title": "Topic One",
                "short_desc": None,
                "topic_type": "concept",
                "source_block_ids": ["blk_a"],
                "dita_xml": "<concept id='tpc_one'><title>Topic One</title></concept>",
            },
            "validation_issues": [],
            "traceability": [],
            "artifact_version": new_id("av"),
        }
        return state

    store.mutate(add)
    return rid, document_id


def test_review_service_writes_validation_issues_onto_projected_topic(
    service_app_factory, tmp_jsonstore
) -> None:
    """End-to-end Phase 7 contract: applying an op via review-service
    triggers a validation-service call AND writes the resulting
    validation_issues onto the projected topic dict in the same
    mutation. A reviewer that reads the topic immediately after editing
    sees the issues without a second roundtrip."""
    review_app, _r = service_app_factory(
        "services/review-service/app/main.py", "phase7_review_for_validation"
    )
    rid, _ = _seed_minimal_topic(document_id="doc_p7_e2e")

    client = TestClient(review_app)
    # Apply a RawXmlOverride that produces an invalid topic (no title).
    response = client.post(
        f"/internal/topics/{rid}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "raw_xml_override",
            "payload": {
                "topic_id": rid,
                "xml": "<concept id='broken'><body><p>Missing title.</p></body></concept>",
            },
            "is_lossy": True,
        },
    )
    assert response.status_code == 200, response.text
    topic = response.json()["topic"]
    codes = [issue["code"] for issue in topic.get("validation_issues", [])]
    assert "missing_title" in codes, (
        f"expected missing_title in topic.validation_issues; got {codes}"
    )


def test_review_service_clears_issues_on_subsequent_valid_edit(
    service_app_factory, tmp_jsonstore
) -> None:
    """Apply a broken xml then a fixed xml — validation_issues on the
    second projection must be empty. Locks the 'overwrite, don't
    accumulate' contract on Phase 7's stamping."""
    review_app, _r = service_app_factory(
        "services/review-service/app/main.py", "phase7_review_clears"
    )
    rid, _ = _seed_minimal_topic(document_id="doc_p7_clears")
    client = TestClient(review_app)
    client.post(
        f"/internal/topics/{rid}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "raw_xml_override",
            "payload": {
                "topic_id": rid,
                "xml": "<concept id='broken'><body><p>Missing title.</p></body></concept>",
            },
            "is_lossy": True,
        },
    )
    fix = client.post(
        f"/internal/topics/{rid}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "raw_xml_override",
            "payload": {
                "topic_id": rid,
                "xml": "<concept id='fixed'><title>Fixed</title></concept>",
            },
            "is_lossy": True,
        },
    )
    assert fix.status_code == 200
    assert fix.json()["topic"]["validation_issues"] == []
