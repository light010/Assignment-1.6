"""CredentialProvider tests (Phase 8 followup).

Locks the four credential modes the LLM gateway supports and the
401-driven cache-invalidation flow:

  - NoAuth: no Authorization header attached (local Ollama).
  - StaticBearer: Authorization: Bearer <api_key>.
  - HeaderBundle: X-Tenant-Id + X-App-Id + Authorization: Bearer <secret>.
  - OAuth2ClientCredentials: token-exchange + TTL caching + invalidate()
    drops the cache and forces a re-exchange on the next call.
  - Factory precedence: triple+endpoint → OAuth2; triple → HeaderBundle;
    api_key → StaticBearer; nothing → NoAuth; api_key+triple → raises.

LlamaProvider integration tests:
  - Header-bundle headers attach to every request.
  - OAuth2 token cached across calls; 401 from LLM endpoint invalidates
    the cache and the next attempt fetches a fresh token.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any

import httpx
import pytest


def _gateway_path() -> Path:
    return Path(__file__).resolve().parents[1] / "services" / "llm-gateway-service" / "app"


# Side-load the gateway app dir so the bare `gateway_*` imports resolve.
sys.path.insert(0, str(_gateway_path()))
CREDS = importlib.import_module("gateway_credentials")
SETTINGS_MOD = importlib.import_module("gateway_settings")
CONTRACTS = importlib.import_module("gateway_contracts")
LLAMA = importlib.import_module("gateway_providers.llama")


# ---------------------------------------------------------------------------
# Unit: per-mode header shapes
# ---------------------------------------------------------------------------


def test_no_auth_provider_returns_empty_headers() -> None:
    provider = CREDS.NoAuthCredentialProvider()
    assert provider.headers_for_request() == {}
    provider.invalidate()  # no-op
    assert provider.name == "no-auth"


def test_static_bearer_provider_attaches_bearer_header() -> None:
    provider = CREDS.StaticBearerCredentialProvider(api_key="sk-test-12345")
    headers = provider.headers_for_request()
    assert headers == {"Authorization": "Bearer sk-test-12345"}


def test_static_bearer_rejects_empty_key() -> None:
    with pytest.raises(CREDS.CredentialError):
        CREDS.StaticBearerCredentialProvider(api_key="")


def test_header_bundle_provider_attaches_tenant_app_secret() -> None:
    provider = CREDS.HeaderBundleCredentialProvider(
        tenant_id="ten_abc", app_id="app_def", secret="s3cr3t"
    )
    headers = provider.headers_for_request()
    assert headers == {
        "X-Tenant-Id": "ten_abc",
        "X-App-Id": "app_def",
        "Authorization": "Bearer s3cr3t",
    }


def test_header_bundle_rejects_partial_triple() -> None:
    for tenant, app, secret in [
        ("", "app", "s"),
        ("t", "", "s"),
        ("t", "app", ""),
    ]:
        with pytest.raises(CREDS.CredentialError):
            CREDS.HeaderBundleCredentialProvider(
                tenant_id=tenant, app_id=app, secret=secret
            )


# ---------------------------------------------------------------------------
# OAuth2 token exchange — happy path, cache, invalidate, error
# ---------------------------------------------------------------------------


def _oauth2_provider(
    handler, *, scope: str | None = None, **kwargs: Any
) -> Any:
    transport = httpx.MockTransport(handler)
    provider = CREDS.OAuth2ClientCredentialsProvider(
        tenant_id="ten_abc",
        app_id="app_def",
        secret="s3cr3t",
        token_endpoint="https://auth.example/oauth2/token",
        scope=scope,
        request_timeout_seconds=2.0,
        safety_margin_seconds=1.0,
        **kwargs,
    )
    provider._token_client = httpx.Client(transport=transport, timeout=2.0)
    return provider


def test_oauth2_exchange_returns_bearer_token() -> None:
    exchange_calls: list[dict[str, Any]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = dict(item.split("=", 1) for item in request.content.decode().split("&"))
        exchange_calls.append(body)
        return httpx.Response(
            200,
            json={"access_token": "fresh-bearer-1", "expires_in": 3600},
        )

    provider = _oauth2_provider(handler)
    headers = provider.headers_for_request()
    assert headers == {"Authorization": "Bearer fresh-bearer-1"}
    assert len(exchange_calls) == 1
    assert exchange_calls[0]["grant_type"] == "client_credentials"
    assert exchange_calls[0]["client_id"] == "app_def"
    assert exchange_calls[0]["client_secret"] == "s3cr3t"
    assert exchange_calls[0]["tenant_id"] == "ten_abc"  # default placement is body


def test_oauth2_caches_token_across_calls() -> None:
    exchange_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal exchange_count
        exchange_count += 1
        return httpx.Response(200, json={"access_token": "cached-bearer", "expires_in": 3600})

    provider = _oauth2_provider(handler)
    h1 = provider.headers_for_request()
    h2 = provider.headers_for_request()
    h3 = provider.headers_for_request()
    assert h1 == h2 == h3
    assert exchange_count == 1, "token should be cached; expected one exchange"


def test_oauth2_invalidate_forces_re_exchange() -> None:
    issued: list[str] = []
    counter = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal counter
        counter += 1
        token = f"bearer-{counter}"
        issued.append(token)
        return httpx.Response(200, json={"access_token": token, "expires_in": 3600})

    provider = _oauth2_provider(handler)
    first = provider.headers_for_request()
    provider.invalidate()
    second = provider.headers_for_request()
    assert first != second
    assert issued == ["bearer-1", "bearer-2"]


def test_oauth2_tenant_in_path_substitutes_template() -> None:
    captured_url: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured_url.append(str(request.url))
        return httpx.Response(200, json={"access_token": "az-bearer", "expires_in": 3600})

    transport = httpx.MockTransport(handler)
    provider = CREDS.OAuth2ClientCredentialsProvider(
        tenant_id="ten_abc",
        app_id="app_def",
        secret="s3cr3t",
        token_endpoint="https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
        tenant_in_body=False,
        tenant_in_path=True,
        request_timeout_seconds=2.0,
    )
    provider._token_client = httpx.Client(transport=transport, timeout=2.0)
    provider.headers_for_request()
    assert "ten_abc" in captured_url[0]
    assert "{tenant_id}" not in captured_url[0]


def test_oauth2_tenant_in_header_sends_x_tenant_id() -> None:
    captured_headers: list[dict[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured_headers.append(dict(request.headers))
        return httpx.Response(200, json={"access_token": "hdr-bearer", "expires_in": 3600})

    transport = httpx.MockTransport(handler)
    provider = CREDS.OAuth2ClientCredentialsProvider(
        tenant_id="ten_abc",
        app_id="app_def",
        secret="s3cr3t",
        token_endpoint="https://auth.example/oauth2/token",
        tenant_in_body=False,
        tenant_in_header=True,
        request_timeout_seconds=2.0,
    )
    provider._token_client = httpx.Client(transport=transport, timeout=2.0)
    provider.headers_for_request()
    # Note httpx normalizes header keys to lowercase.
    assert captured_headers[0].get("x-tenant-id") == "ten_abc"


def test_oauth2_requires_exactly_one_tenant_placement() -> None:
    with pytest.raises(CREDS.CredentialError):
        CREDS.OAuth2ClientCredentialsProvider(
            tenant_id="t",
            app_id="a",
            secret="s",
            token_endpoint="https://x/y",
            tenant_in_body=True,
            tenant_in_path=True,  # both → invalid
        )


def test_oauth2_raises_on_token_endpoint_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="auth-service down")

    provider = _oauth2_provider(handler)
    with pytest.raises(CREDS.CredentialError, match="500"):
        provider.headers_for_request()


def test_oauth2_raises_when_access_token_missing() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"oops": "no token"})

    provider = _oauth2_provider(handler)
    with pytest.raises(CREDS.CredentialError, match="access_token"):
        provider.headers_for_request()


# ---------------------------------------------------------------------------
# Factory precedence
# ---------------------------------------------------------------------------


def test_factory_picks_noauth_when_nothing_set() -> None:
    p = CREDS.build_credential_provider(
        api_key=None, tenant_id=None, app_id=None, secret=None, token_endpoint=None
    )
    assert isinstance(p, CREDS.NoAuthCredentialProvider)


def test_factory_picks_static_bearer_with_api_key_only() -> None:
    p = CREDS.build_credential_provider(
        api_key="sk-1", tenant_id=None, app_id=None, secret=None, token_endpoint=None
    )
    assert isinstance(p, CREDS.StaticBearerCredentialProvider)


def test_factory_picks_header_bundle_with_triple_no_endpoint() -> None:
    p = CREDS.build_credential_provider(
        api_key=None,
        tenant_id="t",
        app_id="a",
        secret="s",
        token_endpoint=None,
    )
    assert isinstance(p, CREDS.HeaderBundleCredentialProvider)


def test_factory_picks_oauth2_with_triple_and_endpoint() -> None:
    p = CREDS.build_credential_provider(
        api_key=None,
        tenant_id="t",
        app_id="a",
        secret="s",
        token_endpoint="https://x/y",
    )
    assert isinstance(p, CREDS.OAuth2ClientCredentialsProvider)


def test_factory_rejects_mixed_api_key_and_triple() -> None:
    with pytest.raises(CREDS.CredentialError, match="EITHER"):
        CREDS.build_credential_provider(
            api_key="sk-1",
            tenant_id="t",
            app_id="a",
            secret="s",
            token_endpoint=None,
        )


# ---------------------------------------------------------------------------
# Settings → credential_provider() integration
# ---------------------------------------------------------------------------


def test_settings_credential_provider_picks_header_bundle_from_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DITAGEN_LLAMA_BASE_URL", "https://llm.example.com/v1")
    monkeypatch.setenv("DITAGEN_LLAMA_MODEL", "llama3.2")
    monkeypatch.setenv("DITAGEN_LLAMA_TENANT_ID", "ten_xyz")
    monkeypatch.setenv("DITAGEN_LLAMA_APP_ID", "app_xyz")
    monkeypatch.setenv("DITAGEN_LLAMA_SECRET", "s3cr3t-xyz")
    monkeypatch.delenv("DITAGEN_LLAMA_API_KEY", raising=False)
    monkeypatch.delenv("DITAGEN_LLAMA_TOKEN_ENDPOINT", raising=False)
    settings = SETTINGS_MOD.load_llama_settings()
    provider = settings.credential_provider()
    assert isinstance(provider, CREDS.HeaderBundleCredentialProvider)
    headers = provider.headers_for_request()
    assert headers["X-Tenant-Id"] == "ten_xyz"
    assert headers["X-App-Id"] == "app_xyz"
    assert headers["Authorization"] == "Bearer s3cr3t-xyz"


def test_settings_credential_provider_picks_oauth2_when_endpoint_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DITAGEN_LLAMA_BASE_URL", "https://llm.example.com/v1")
    monkeypatch.setenv("DITAGEN_LLAMA_MODEL", "llama3.2")
    monkeypatch.setenv("DITAGEN_LLAMA_TENANT_ID", "ten_xyz")
    monkeypatch.setenv("DITAGEN_LLAMA_APP_ID", "app_xyz")
    monkeypatch.setenv("DITAGEN_LLAMA_SECRET", "s3cr3t-xyz")
    monkeypatch.setenv("DITAGEN_LLAMA_TOKEN_ENDPOINT", "https://auth.example/token")
    monkeypatch.delenv("DITAGEN_LLAMA_API_KEY", raising=False)
    settings = SETTINGS_MOD.load_llama_settings()
    provider = settings.credential_provider()
    assert isinstance(provider, CREDS.OAuth2ClientCredentialsProvider)


# ---------------------------------------------------------------------------
# LlamaProvider integration with credential providers
# ---------------------------------------------------------------------------


def _llama_settings(**overrides: Any) -> Any:
    defaults: dict[str, Any] = {
        "base_url": "http://test-llama/v1",
        "model_name": "llama3.1:8b",
        "request_timeout_seconds": 2.0,
        "max_retries": 3,
        "initial_backoff_seconds": 0.001,
        "max_backoff_seconds": 0.01,
    }
    defaults.update(overrides)
    return SETTINGS_MOD.LlamaSettings(**defaults)


def test_llama_provider_attaches_header_bundle_on_every_request() -> None:
    """The HeaderBundle credentials show up on every Llama HTTP call —
    not just at client-build time. Regression-prevents a future change
    that stamps auth into the client headers (would break OAuth2
    refresh)."""
    captured: list[dict[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(dict(request.headers))
        return httpx.Response(
            200,
            json={
                "id": "x",
                "model": "llama3.1:8b",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": '{"document_id":"d","topic_candidates":[{"topic_id":"t","title":"T","topic_type":"concept","source_block_ids":["b"]}]}',
                        },
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            },
        )

    transport = httpx.MockTransport(handler)
    settings = _llama_settings(
        tenant_id="ten_x", app_id="app_x", secret="s3cr3t-x"
    )
    provider = LLAMA.LlamaProvider(settings)
    provider._client = httpx.Client(
        base_url="http://test-llama/v1", transport=transport, timeout=2.0
    )

    from ditagen_common.models import Block, Confidence, SourceLocation

    block = Block(
        block_id="b",
        document_id="d",
        block_type="paragraph",
        text="hello",
        source_location=SourceLocation(page=1),
        confidence=Confidence(extraction=0.9),
        char_start=0,
        char_end=5,
    )
    provider.topic_plan(
        CONTRACTS.TopicPlanRequest(
            document_id="d",
            source_blocks=[block],
            structure_tree={},
            model_name="llama3.1:8b",
            prompt_version="v1",
        )
    )
    assert captured, "expected at least one Llama call"
    # httpx normalizes header names to lowercase.
    last = captured[-1]
    assert last.get("x-tenant-id") == "ten_x"
    assert last.get("x-app-id") == "app_x"
    assert last.get("authorization") == "Bearer s3cr3t-x"


def test_llama_provider_invalidates_credentials_on_401_and_retries() -> None:
    """When the Llama endpoint returns 401, the provider invalidates
    the credential cache and retries. This is the production scenario
    where an OAuth2 token expired between cache-check and call."""
    invalidate_calls: list[int] = []

    class CountingCreds:
        name = "counting-test"
        token_seq = 0

        def headers_for_request(self) -> dict[str, str]:
            self.token_seq += 1
            return {"Authorization": f"Bearer token-{self.token_seq}"}

        def invalidate(self) -> None:
            invalidate_calls.append(1)

    call_log: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        auth = request.headers.get("authorization", "")
        call_log.append(auth)
        if len(call_log) == 1:
            return httpx.Response(401, text="token expired")
        return httpx.Response(
            200,
            json={
                "id": "x",
                "model": "llama3.1:8b",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": '{"document_id":"d","topic_candidates":[{"topic_id":"t","title":"T","topic_type":"concept","source_block_ids":["b"]}]}',
                        },
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            },
        )

    transport = httpx.MockTransport(handler)
    settings = _llama_settings()
    provider = LLAMA.LlamaProvider(settings, credential_provider=CountingCreds())
    provider._client = httpx.Client(
        base_url="http://test-llama/v1", transport=transport, timeout=2.0
    )
    from ditagen_common.models import Block, Confidence, SourceLocation

    block = Block(
        block_id="b",
        document_id="d",
        block_type="paragraph",
        text="hello",
        source_location=SourceLocation(page=1),
        confidence=Confidence(extraction=0.9),
        char_start=0,
        char_end=5,
    )
    provider.topic_plan(
        CONTRACTS.TopicPlanRequest(
            document_id="d",
            source_blocks=[block],
            structure_tree={},
            model_name="llama3.1:8b",
            prompt_version="v1",
        )
    )
    assert invalidate_calls == [1], "expected exactly one invalidate() on 401"
    assert call_log[0] == "Bearer token-1"
    assert call_log[1] == "Bearer token-2", "retry must use a fresh token"
