"""Step S7 — CORS config is env-driven, not wildcard.

Pre-Step-S7 the gateway used `allow_methods=["*"]` and
`allow_headers=["*"]` — fine for alpha but a production deployment
should never ship wildcards. Step S7 made the three CORS dimensions
(origins, methods, headers) env-driven via `_csv_env` with explicit
defaults that exclude `*`.

This test locks two things:

  (1) The current configuration does NOT contain `*` for methods or
      headers (audit S7 finding regression guard).
  (2) Overriding `DITAGEN_CORS_*` env vars changes the corresponding
      middleware config — proving the env wiring works.

The origins default is intentionally a small range of Vite dev ports
(localhost:5173/5174/5175 + 127.0.0.1 variants) — see the comment in
gateway main.py for why. A wildcard origin would be unsafe with
`allow_credentials=True`.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_gateway_with_env(tmp_path, monkeypatch, env_overrides: dict[str, str] | None = None):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    if env_overrides:
        for key, value in env_overrides.items():
            monkeypatch.setenv(key, value)
    module_path = ROOT / "services/api-gateway/app/main.py"
    spec = importlib.util.spec_from_file_location(
        f"cors_gateway_{abs(hash(tuple((env_overrides or {}).items())))}", module_path
    )
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.app


def _cors_middleware(app):
    """Locate the CORSMiddleware kwargs on the FastAPI app's middleware stack."""
    from fastapi.middleware.cors import CORSMiddleware

    for middleware in app.user_middleware:
        if middleware.cls is CORSMiddleware:
            return middleware
    raise AssertionError(
        "CORSMiddleware not found on FastAPI app — Step S7 regression. "
        "The gateway must add CORSMiddleware via app.add_middleware."
    )


def test_cors_defaults_do_not_use_wildcards(tmp_path, monkeypatch) -> None:
    """No env overrides — defaults should be a closed allow-list, not `*`."""
    app = _load_gateway_with_env(tmp_path, monkeypatch)
    middleware = _cors_middleware(app)

    methods = middleware.kwargs.get("allow_methods", [])
    headers = middleware.kwargs.get("allow_headers", [])
    origins = middleware.kwargs.get("allow_origins", [])

    assert "*" not in methods, (
        f"CORS methods default contains wildcard — Step S7 regression: {methods}"
    )
    assert "*" not in headers, (
        f"CORS headers default contains wildcard — Step S7 regression: {headers}"
    )
    assert "*" not in origins, (
        f"CORS origins default contains wildcard — wildcard origins are unsafe "
        f"with allow_credentials=True: {origins}"
    )
    # Sanity: defaults must include at least the canonical methods.
    assert set(methods) >= {"GET", "POST", "OPTIONS"}, (
        f"CORS default methods missing canonical entries: {methods}"
    )


def test_cors_env_overrides_take_effect(tmp_path, monkeypatch) -> None:
    """`DITAGEN_CORS_*` env vars must override the defaults. This is the
    deployment-config hook: production sets these to its canonical
    origin list.
    """
    app = _load_gateway_with_env(
        tmp_path,
        monkeypatch,
        {
            "DITAGEN_CORS_ORIGINS": "https://canonical.example.com",
            "DITAGEN_CORS_METHODS": "GET,POST",
            "DITAGEN_CORS_HEADERS": "Authorization",
        },
    )
    middleware = _cors_middleware(app)

    assert middleware.kwargs["allow_origins"] == ["https://canonical.example.com"]
    assert middleware.kwargs["allow_methods"] == ["GET", "POST"]
    assert middleware.kwargs["allow_headers"] == ["Authorization"]


def test_cors_csv_parser_strips_whitespace(tmp_path, monkeypatch) -> None:
    """Operator-supplied env values often have trailing spaces or stray
    empties (`"GET, POST, "`). The `_csv_env` helper must normalize, so
    a typo in compose doesn't silently include "" as an allowed origin.
    """
    app = _load_gateway_with_env(
        tmp_path,
        monkeypatch,
        {"DITAGEN_CORS_ORIGINS": "https://a.example.com , https://b.example.com,"},
    )
    middleware = _cors_middleware(app)
    assert middleware.kwargs["allow_origins"] == [
        "https://a.example.com",
        "https://b.example.com",
    ]
    assert "" not in middleware.kwargs["allow_origins"]
