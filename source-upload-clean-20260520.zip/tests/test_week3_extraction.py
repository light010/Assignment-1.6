from __future__ import annotations

import base64
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

from ditagen_common.artifacts import read_artifact_text, write_artifact
from ditagen_common.security import issue_token
from ditagen_common.store import JsonStore
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p94AAAAASUVORK5CYII="
)


def configure(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    monkeypatch.setenv("DITAGEN_EXTRACTION_SERVICE_URL", "http://extraction-service:8000")


def load_app(relative: str, module_name: str, tmp_path, monkeypatch):
    configure(tmp_path, monkeypatch)
    module_path = ROOT / relative
    full_module_name = f"{module_name}_{abs(hash(str(tmp_path)))}"
    app_dir = str(module_path.parent)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    spec = importlib.util.spec_from_file_location(full_module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[full_module_name] = module
    spec.loader.exec_module(module)
    return module.app, module


def auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_week3"}


def create_docx_fixture(tmp_path: Path) -> bytes:
    from docx import Document

    image_path = tmp_path / "one.png"
    image_path.write_bytes(PNG_1X1)
    document = Document()
    document.add_heading("Payroll Setup", level=1)
    document.add_paragraph("Install the Connector")
    document.add_paragraph("Click Save to apply DEFAULT_PROFILE.")
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Field"
    table.cell(0, 1).text = "Value"
    table.cell(1, 0).text = "Mode"
    table.cell(1, 1).text = "Automatic"
    document.add_picture(str(image_path))
    document.add_paragraph("Figure 1. Connector state").style = "Caption"
    path = tmp_path / "fixture.docx"
    document.save(str(path))
    return path.read_bytes()


def create_pdf_fixture() -> bytes:
    import fitz

    doc = fitz.open()
    for page_no in range(2):
        page = doc.new_page()
        page.insert_text((72, 24), "DITAgen Header", fontsize=8)
        page.insert_text((72, 90), "Payroll Setup" if page_no == 0 else "Click Save", fontsize=18)
        page.insert_text((72, 130), "Install the Connector", fontsize=11)
    return doc.tobytes()


def create_scanned_pdf_fixture() -> bytes:
    import fitz

    doc = fitz.open()
    page = doc.new_page()
    page.insert_image(fitz.Rect(72, 72, 220, 220), stream=PNG_1X1)
    return doc.tobytes()


def extraction_payload(
    *,
    document_id: str,
    filename: str,
    content_type: str,
    content: bytes,
) -> dict[str, Any]:
    original = write_artifact(
        project_id="prj_week3",
        document_id=document_id,
        name=f"original/{filename}",
        content=content,
        content_type=content_type,
        store=JsonStore(),
        created_by="usr_admin",
        producer="upload-service",
    )
    return {
        "document_id": document_id,
        "project_id": "prj_week3",
        "business_unit_id": "bu_docs_ops",
        "filename": filename,
        "content_type": content_type,
        "artifact_path": original["path"],
        "request_id": "req_week3",
        "requested_by": "usr_admin",
    }


def refs_by_name(status: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {artifact["name"]: artifact for artifact in status["artifacts"]}


def test_extraction_service_docx_contract_assets_and_determinism(tmp_path, monkeypatch) -> None:
    app, _module = load_app("services/extraction-service/app/main.py", "extraction_service_docx", tmp_path, monkeypatch)
    client = TestClient(app)
    docx_bytes = create_docx_fixture(tmp_path)
    payload = extraction_payload(
        document_id="doc_week3_docx",
        filename="fixture.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        content=docx_bytes,
    )

    first = client.post("/internal/extractions", json=payload, headers=auth_headers())
    assert first.status_code == 200
    first_status = first.json()
    assert first_status["stage"] == "markdown_complete"
    first_refs = refs_by_name(first_status)
    assert {"source-blocks.jsonl", "content.md", "asset-manifest.json"} <= set(first_refs)
    assert first_status["asset_count"] == 1
    assert all("producer" in artifact for artifact in first_status["artifacts"])

    first_markdown = read_artifact_text(first_refs["content.md"])
    assert "<!-- source:" in first_markdown
    assert "Payroll Setup" in first_markdown
    source_blocks = [
        json.loads(line)
        for line in read_artifact_text(first_refs["source-blocks.jsonl"]).splitlines()
        if line.strip()
    ]
    block_texts = [block["text"] for block in source_blocks]
    assert block_texts.index("Field | Value") < block_texts.index("Figure 1. Connector state")
    table_rows = [block for block in source_blocks if block["block_type"] == "table_row"]
    assert [row["row_index"] for row in table_rows] == [1, 2]
    assert all(row["table_id"] == "tbl_001" for row in table_rows)
    assert table_rows[0]["cells"] == [
        {"text": "Field", "colspan": 1, "rowspan": 1},
        {"text": "Value", "colspan": 1, "rowspan": 1},
    ]

    second = client.post("/internal/extractions", json=payload, headers=auth_headers())
    assert second.status_code == 200
    second_markdown = read_artifact_text(refs_by_name(second.json())["content.md"])
    assert second_markdown == first_markdown
    assert refs_by_name(second.json())["content.md"]["previous_version_id"] == first_refs["content.md"]["artifact_id"]


def test_extraction_service_pdf_geometry_header_filter_and_scanned_warning(tmp_path, monkeypatch) -> None:
    app, _module = load_app("services/extraction-service/app/main.py", "extraction_service_pdf", tmp_path, monkeypatch)
    client = TestClient(app)

    pdf = client.post(
        "/internal/extractions",
        json=extraction_payload(
            document_id="doc_week3_pdf",
            filename="source.pdf",
            content_type="application/pdf",
            content=create_pdf_fixture(),
        ),
        headers=auth_headers(),
    )
    assert pdf.status_code == 200
    status = pdf.json()
    assert status["stage"] == "markdown_complete"
    source_blocks = read_artifact_text(refs_by_name(status)["source-blocks.jsonl"])
    assert "DITAgen Header" not in source_blocks
    assert '"bbox"' in source_blocks

    scanned = client.post(
        "/internal/extractions",
        json=extraction_payload(
            document_id="doc_week3_scanned",
            filename="scanned.pdf",
            content_type="application/pdf",
            content=create_scanned_pdf_fixture(),
        ),
        headers=auth_headers(),
    )
    assert scanned.status_code == 200
    assert any(
        warning["kind"] == "quality.scanned_or_image_only"
        for warning in scanned.json()["warnings"]
    )


def test_upload_service_records_extraction_events_and_failure_state(tmp_path, monkeypatch) -> None:
    project_app, _project_module = load_app("services/business-unit-service/app/main.py", "project_week3", tmp_path, monkeypatch)
    project_client = TestClient(project_app)
    project = project_client.post(
        "/internal/projects",
        json={"business_unit_id": "bu_docs_ops", "name": "Week 3"},
        headers=auth_headers(),
    ).json()

    upload_app, upload_module = load_app("services/upload-service/app/main.py", "upload_week3", tmp_path, monkeypatch)
    upload_client = TestClient(upload_app)
    uploaded = upload_client.post(
        f"/internal/projects/{project['project_id']}/documents/uploads",
        files={"file": ("source.txt", b"Payroll Setup\nClick Save\n", "text/plain")},
        headers=auth_headers(),
    )
    assert uploaded.status_code == 200
    document = uploaded.json()["document"]
    assert document["status"] == "ready_for_review"
    assert document["extraction"]["stage"] == "markdown_complete"
    assert "document.extraction_requested" in uploaded.json()["job"]["events"]
    registry = JsonStore().read()["artifact_registry"].values()
    assert any(item["producer"] == "extraction-service" for item in registry)
    assert any(item["producer"] == "markdown-service" and item["name"] == "content.md" for item in registry)

    # Phase 4 D3.5.c-fallout: upload-service now calls BU service via
    # `request_service` for project lookup (was: local JsonStore). A
    # blanket monkey-patch that fails every request_service call would
    # break the project-lookup path BEFORE the extraction call ever
    # runs — that's not what this test asserts. Fail only calls to
    # extraction-service; pass through everything else to the real one.
    real_request_service = upload_module.request_service

    async def selective_request_service(**kwargs):
        base_url = kwargs.get("base_url", "")
        if "extraction-service" in base_url:
            raise RuntimeError("extraction service down")
        return await real_request_service(**kwargs)

    upload_module.request_service = selective_request_service
    failed = upload_client.post(
        f"/internal/projects/{project['project_id']}/documents/uploads",
        files={"file": ("down.txt", b"Will fail\n", "text/plain")},
        headers=auth_headers(),
    )
    assert failed.status_code == 200
    failed_document = failed.json()["document"]
    assert failed_document["status"] == "failed_extraction"
    assert failed_document["source_quality"]["extraction_error"]["kind"] == "service_unreachable"


def create_layered_docx_fixture(tmp_path: Path) -> bytes:
    """Build a richer DOCX with 3 tables interleaved with paragraphs and headings.

    Body order under DOCX is `<w:p>` and `<w:tbl>` interleaved at the body
    level. The single-table synthetic fixture only exercises one table.
    This fixture covers: heading → paragraph → table → paragraph →
    sub-heading → paragraph → table → paragraph → heading → paragraph →
    table. It also places a Heading-styled paragraph *inside* a table cell
    to verify the body walker doesn't promote it to a top-level heading
    block.
    """
    from docx import Document

    document = Document()
    document.add_heading("Section A", level=1)
    document.add_paragraph("Body before the first table.")
    table_a = document.add_table(rows=2, cols=2)
    table_a.cell(0, 0).text = "A1c1"
    table_a.cell(0, 1).text = "A1c2"
    table_a.cell(1, 0).text = "A2c1"
    table_a.cell(1, 1).text = "A2c2"
    document.add_paragraph("Body after the first table.")
    document.add_heading("Sub-section A.1", level=2)
    document.add_paragraph("Body before the second table.")
    table_b = document.add_table(rows=3, cols=2)
    table_b.cell(0, 0).text = "B1c1"
    table_b.cell(0, 1).text = "B1c2"
    table_b.cell(1, 0).text = "B2c1"
    table_b.cell(1, 1).text = "B2c2"
    cell_paragraph = table_b.cell(2, 0).paragraphs[0]
    cell_paragraph.text = "B3c1-styled"
    cell_paragraph.style = document.styles["Heading 3"]
    table_b.cell(2, 1).text = "B3c2"
    document.add_paragraph("Body after the second table.")
    document.add_heading("Section B", level=1)
    document.add_paragraph("Body before the third table.")
    table_c = document.add_table(rows=2, cols=3)
    table_c.cell(0, 0).text = "C1c1"
    table_c.cell(0, 1).text = "C1c2"
    table_c.cell(0, 2).text = "C1c3"
    table_c.cell(1, 0).text = "C2c1"
    table_c.cell(1, 1).text = "C2c2"
    table_c.cell(1, 2).text = "C2c3"
    document.add_paragraph("Trailing body paragraph.")
    path = tmp_path / "layered.docx"
    document.save(str(path))
    return path.read_bytes()


def test_extraction_service_docx_layered_body_order(tmp_path, monkeypatch) -> None:
    """Body-order under interleaved paragraphs, tables, and styled cells."""
    app, _module = load_app(
        "services/extraction-service/app/main.py",
        "extraction_service_layered_docx",
        tmp_path,
        monkeypatch,
    )
    client = TestClient(app)
    docx_bytes = create_layered_docx_fixture(tmp_path)
    payload = extraction_payload(
        document_id="doc_layered_docx",
        filename="layered.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        content=docx_bytes,
    )
    response = client.post("/internal/extractions", json=payload, headers=auth_headers())
    assert response.status_code == 200
    refs = refs_by_name(response.json())
    source_blocks = [
        json.loads(line)
        for line in read_artifact_text(refs["source-blocks.jsonl"]).splitlines()
        if line.strip()
    ]

    heading_texts = [b["text"] for b in source_blocks if b["block_type"] == "heading"]
    assert heading_texts == ["Section A", "Sub-section A.1", "Section B"]

    table_ids = sorted({b["table_id"] for b in source_blocks if b["block_type"] == "table_row"})
    assert table_ids == ["tbl_001", "tbl_002", "tbl_003"]

    block_texts = [b["text"] for b in source_blocks]
    section_a_idx = block_texts.index("Section A")
    body_before_t1_idx = block_texts.index("Body before the first table.")
    table_a_first_row_idx = block_texts.index("A1c1 | A1c2")
    body_after_t1_idx = block_texts.index("Body after the first table.")
    sub_a1_idx = block_texts.index("Sub-section A.1")
    table_b_first_row_idx = block_texts.index("B1c1 | B1c2")
    section_b_idx = block_texts.index("Section B")
    table_c_first_row_idx = block_texts.index("C1c1 | C1c2 | C1c3")
    trailing_idx = block_texts.index("Trailing body paragraph.")
    assert (
        section_a_idx
        < body_before_t1_idx
        < table_a_first_row_idx
        < body_after_t1_idx
        < sub_a1_idx
        < table_b_first_row_idx
        < section_b_idx
        < table_c_first_row_idx
        < trailing_idx
    )

    assert "B3c1-styled" not in heading_texts
    table_b_third_row = next(
        b for b in source_blocks
        if b["block_type"] == "table_row"
        and b["table_id"] == "tbl_002"
        and b["row_index"] == 3
    )
    assert "B3c1-styled" in table_b_third_row["text"]
