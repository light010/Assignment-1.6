"""Architecture lock — Step S4 of plans/architecture-hardening.md.

Every service directory under `services/` must be either:

  (a) a "real" service — its `app/main.py` declares at least one
      FastAPI route (anything with an `@app.*` decorator that the
      compiled FastAPI app surface lists), OR

  (b) a documented placeholder — its `app/main.py` may be empty
      (just `create_service_app(...)`), but the directory MUST
      contain a `README.md` whose body opens with a `**Status**:`
      banner explaining the deferred state. The banner exists so
      reviewers reading the repo cannot mistake the directory for
      live code.

Any service directory that satisfies NEITHER condition is a "ghost
service" — dead surface that pretends the architecture covers a
concern it doesn't. The audit caught one such case (markdown-service)
and proposed deletion (Step S5). This test prevents the pattern from
returning: a future contributor who creates an empty `services/foo/`
will see this test fail until they either implement routes or write
the placeholder README explaining why the skeleton exists.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SERVICES_DIR = ROOT / "services"

# Services whose intentional purpose is "library / package — no FastAPI
# app at all". These are extremely rare; we keep this set empty today
# and document the entry shape so future additions are deliberate.
_LIBRARY_ONLY_SERVICES: frozenset[str] = frozenset()


def _service_directories() -> list[Path]:
    return sorted(p for p in SERVICES_DIR.iterdir() if p.is_dir())


def _has_fastapi_routes(main_py: Path) -> bool:
    """Walk the AST of `app/main.py` and return True if any `@app.<method>`
    decorator is present. This is more reliable than importing the
    module (avoids ENV+sys.path setup just to count routes) and catches
    the case where routes are declared but never registered."""
    try:
        tree = ast.parse(main_py.read_text())
    except (OSError, SyntaxError):
        return False
    fastapi_methods = {"get", "post", "put", "patch", "delete", "head", "options", "api_route"}
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            for decorator in node.decorator_list:
                # Match `@app.get(...)`, `@app.post(...)`, etc.
                if (
                    isinstance(decorator, ast.Call)
                    and isinstance(decorator.func, ast.Attribute)
                    and isinstance(decorator.func.value, ast.Name)
                    and decorator.func.value.id == "app"
                    and decorator.func.attr in fastapi_methods
                ):
                    return True
        # Also catch `app.add_api_route(...)` style registration.
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "add_api_route"
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "app"
        ):
            return True
    return False


_STATUS_BANNER_RE = re.compile(r"\*\*Status\*\*:\s*\S+", re.MULTILINE)


def _has_status_banner(readme: Path) -> bool:
    try:
        body = readme.read_text()
    except OSError:
        return False
    return bool(_STATUS_BANNER_RE.search(body))


@pytest.mark.parametrize("service_dir", _service_directories(), ids=lambda p: p.name)
def test_service_is_either_real_or_documented_placeholder(service_dir: Path) -> None:
    """Each `services/<name>/` must have routes OR a Status-banner README.

    A service with neither is a ghost — it gives readers the false
    impression that the architecture covers a concern that has no
    implementation AND no commitment. The audit found one
    (`markdown-service`) which Step S5 deletes; this test prevents the
    pattern from returning.
    """
    if service_dir.name in _LIBRARY_ONLY_SERVICES:
        pytest.skip(f"{service_dir.name} is declared as library-only")

    main_py = service_dir / "app" / "main.py"
    readme = service_dir / "README.md"

    has_routes = main_py.exists() and _has_fastapi_routes(main_py)
    has_status_banner = readme.exists() and _has_status_banner(readme)

    assert has_routes or has_status_banner, (
        f"services/{service_dir.name}/ is a ghost service — no FastAPI "
        f"routes in app/main.py AND no README.md with a `**Status**:` "
        f"banner. Either implement routes OR add a README documenting "
        f"the placeholder status (see services/identity-service/README.md "
        f"for the template)."
    )


def test_service_directory_set_is_listed_below() -> None:
    """Pin the set of service directories so a silent addition can't slip
    by. When a new service legitimately joins, update this list AND the
    `_LIBRARY_ONLY_SERVICES` set above if applicable."""
    actual = {p.name for p in _service_directories()}
    # Step S5 (2026-05-11): markdown-service deleted as a ghost
    # directory. The producer string "markdown-service" remains
    # intentional in extraction-service for artifact-row backward
    # compatibility (see docker-compose.yml comment + the Producer
    # Literal in extraction-service/app/contracts.py). The DIRECTORY
    # was the ghost; the IDENTIFIER stays.
    expected = {
        "agent-runtime-service",
        "analysis-service",
        "api-gateway",
        "audit-service",
        "business-unit-service",
        "dita-service",
        "export-service",
        "extraction-service",
        "identity-service",
        "llm-gateway-service",
        "notification-service",
        "review-service",
        "upload-service",
        "validation-service",
    }
    extras = actual - expected
    missing = expected - actual
    assert not extras, (
        f"New service(s) found in services/ that aren't pinned in this "
        f"test: {sorted(extras)}. Add them to the expected set "
        f"deliberately."
    )
    assert not missing, (
        f"Expected service(s) missing from services/: {sorted(missing)}. "
        f"If you deleted one, also update this test."
    )
