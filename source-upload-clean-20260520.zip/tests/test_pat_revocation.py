"""Step S3 — PAT revocation must actually revoke.

Pre-Step-S3 the gateway returned `{"status": "revoked"}` on
`DELETE /v1/auth/tokens/{id}` but stored nothing — a leaked PAT was
valid until its 24-hour expiry no matter what the API said. Step S3
wired the gateway to a `revoked_tokens` collection in JsonStore and
made `verify_token` consult it.

This test locks the round-trip end-to-end:

1. Issue a PAT (POST `/v1/auth/tokens`).
2. The token MUST appear in `GET /v1/auth/tokens` for the same user.
3. Use it on a protected route — succeeds.
4. Revoke it (`DELETE /v1/auth/tokens/{id}`).
5. Re-use the same token — MUST fail with 401.

The architecture lock is the regression guard: if a future change
removes the revocation check or stops persisting tokens, this test
breaks loudly. Without it, the security theater pattern is one
refactor away from returning.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]


def _load_gateway(tmp_path, monkeypatch) -> Any:
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv("DITAGEN_UPLOAD_SERVICE_URL", "http://upload-service:8000")
    # Phase 4 D2.7b — api-gateway login/logout audit-emits via
    # audit-service. Without this URL set, emit_audit_event falls back
    # to JsonStore.audit() which is now fail-loud.
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")
    monkeypatch.setenv("DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000")
    module_path = ROOT / "services/api-gateway/app/main.py"
    spec = importlib.util.spec_from_file_location("pat_rev_gateway", module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules["pat_rev_gateway"] = module
    spec.loader.exec_module(module)
    return module


def _login(client: TestClient) -> str:
    response = client.post(
        "/v1/auth/login",
        json={"email": "admin@ditagen.local", "password": "admin123"},
    )
    assert response.status_code == 200, response.text
    return response.json()["access_token"]


def test_pat_lifecycle_issue_list_use_revoke_reject(tmp_path, monkeypatch) -> None:
    """The 5-step round-trip — issue → list → use → revoke → reject.

    Step S3's guarantee is that the revoked state is REAL, not a
    cosmetic API response. A revoked token must stop authenticating
    immediately.
    """
    gateway = _load_gateway(tmp_path, monkeypatch)
    client = TestClient(gateway.app)
    access_token = _login(client)
    bearer = {"Authorization": f"Bearer {access_token}"}

    # Step 1 — issue a PAT
    issue_resp = client.post("/v1/auth/tokens", headers=bearer)
    assert issue_resp.status_code == 200, issue_resp.text
    pat_id = issue_resp.json()["token_id"]
    pat_value = issue_resp.json()["token"]
    assert pat_id and pat_value

    # Step 2 — list shows it
    list_resp = client.get("/v1/auth/tokens", headers=bearer)
    assert list_resp.status_code == 200, list_resp.text
    tokens = list_resp.json()["tokens"]
    assert any(item["token_id"] == pat_id for item in tokens), (
        f"Issued PAT not visible in /v1/auth/tokens list: {tokens}"
    )

    # Step 3 — use it on a protected route (the list endpoint is itself
    # protected; calling it via PAT confirms the PAT is currently valid)
    use_resp = client.get("/v1/auth/tokens", headers={"Authorization": f"Bearer {pat_value}"})
    assert use_resp.status_code == 200, (
        f"Freshly-issued PAT should authenticate; got {use_resp.status_code}: {use_resp.text}"
    )

    # Step 4 — revoke
    revoke_resp = client.delete(f"/v1/auth/tokens/{pat_id}", headers=bearer)
    assert revoke_resp.status_code == 200, revoke_resp.text
    assert revoke_resp.json()["status"] == "revoked"

    # Step 5 — revoked PAT MUST be rejected
    rejected_resp = client.get(
        "/v1/auth/tokens", headers={"Authorization": f"Bearer {pat_value}"}
    )
    assert rejected_resp.status_code == 401, (
        f"Revoked PAT was still accepted — Step S3 security theater "
        f"regression. Got {rejected_resp.status_code}: {rejected_resp.text}"
    )


def test_revoking_nonexistent_pat_returns_404(tmp_path, monkeypatch) -> None:
    """A revoke on an unknown token_id must 404, not silent-succeed.

    Silent success on bad input is a class of bug — the operator gets a
    success response and assumes the token is gone, but no record
    existed so nothing changed. We explicitly require a 404.
    """
    gateway = _load_gateway(tmp_path, monkeypatch)
    client = TestClient(gateway.app)
    access_token = _login(client)
    bearer = {"Authorization": f"Bearer {access_token}"}

    response = client.delete("/v1/auth/tokens/pat_does_not_exist", headers=bearer)
    assert response.status_code == 404, response.text


def test_user_cannot_revoke_another_users_pat(tmp_path, monkeypatch) -> None:
    """Authorization check: a user attempting to revoke another user's
    PAT must get 404 (not 200). The store filters by user_id; this test
    catches the case where a future refactor accidentally drops the
    filter and lets one user invalidate another's tokens.

    Skipped if the local dev bootstrap doesn't provide a second user.
    """
    gateway = _load_gateway(tmp_path, monkeypatch)
    client = TestClient(gateway.app)
    access_token = _login(client)
    bearer = {"Authorization": f"Bearer {access_token}"}

    # Issue admin's PAT
    issue_resp = client.post("/v1/auth/tokens", headers=bearer)
    admin_pat_id = issue_resp.json()["token_id"]

    # Find a second user in the bootstrap state.
    state = gateway.store.read()
    other_user = next(
        (u for u in state["users"] if u["email"].lower() != "admin@ditagen.local"),
        None,
    )
    if other_user is None:
        pytest.skip("No second bootstrap user available to exercise cross-user revoke")

    # Mint a token directly for the other user (skips login flow).
    other_token = gateway.issue_token(
        {
            "sub": other_user["user_id"],
            "tenant_id": other_user["tenant_id"],
            "org_id": other_user["organization_id"],
            "roles": other_user["roles"],
            "session_id": "sess_test_other",
        }
    )
    response = client.delete(
        f"/v1/auth/tokens/{admin_pat_id}",
        headers={"Authorization": f"Bearer {other_token}"},
    )
    assert response.status_code == 404, (
        f"Other user was able to revoke admin's PAT — authorization "
        f"regression. Got {response.status_code}: {response.text}"
    )
