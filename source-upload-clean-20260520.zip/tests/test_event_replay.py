"""Architecture lock — Phase 4 Step D1 of plans/architecture-hardening.md.

audit-service exposes `GET /internal/events/since/{cursor}` as the
transitional event bus per ADR-016. Consumers walk the cursor in
chunks. The two failure modes that destroy this contract:

  - **Duplicates**: the same `event_id` returned on two distinct
    cursor-walk responses. A consumer that double-processes an event
    sends two emails, charges twice, etc. Silent and catastrophic.
  - **Gaps**: an `event_id` that was emitted but never appears in any
    cursor-walk response. The consumer's downstream state diverges
    from the source-of-truth audit log without any signal.

The 2-event happy-path test (`test_audit_service.py`) verifies the
endpoint shape, not these invariants at scale.

This file asserts:

  1. Emit N events. Walk the cursor from "0" in chunks until empty.
     The union of seen `event_id`s equals the emitted set (no gaps).
  2. No event_id appears twice across the walk (no duplicates).
  3. `next_cursor` advances monotonically when the walk returns events.
  4. Cursor past the end returns empty + a cursor that doesn't go
     backward (no-op convergence).
  5. Same cursor called twice returns identical event sets (idempotent
     reads — a flaky consumer that retries the same cursor doesn't
     skip events).

N is set to 100 per the plan's explicit "emit 100 events" criterion.
Smaller values can hide off-by-one bugs at chunk boundaries.
"""

from __future__ import annotations

from typing import Any

import pytest
from ditagen_common.security import issue_token
from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    token = issue_token({"sub": "usr_admin", "roles": ["org_admin"]})
    return {"Authorization": f"Bearer {token}"}


def _emit_event(client: TestClient, headers: dict[str, str], i: int) -> dict[str, Any]:
    response = client.post(
        "/internal/audit-events",
        json={
            "action": "test.event",
            "resource_type": "test",
            "resource_id": f"res_{i:04d}",
            "business_unit_id": "bu_docs_ops",
        },
        headers=headers,
    )
    assert response.status_code == 200, response.text
    return response.json()


def _walk_cursor(
    client: TestClient,
    headers: dict[str, str],
    *,
    start: str = "0",
    chunk_advance_safety_limit: int = 1000,
) -> list[dict[str, Any]]:
    """Walk the cursor from `start` until the server returns zero events.

    Returns the full ordered list of events seen across all hops. Raises
    if the walk doesn't terminate within `chunk_advance_safety_limit`
    hops — that's an infinite-loop cursor bug.
    """
    seen: list[dict[str, Any]] = []
    cursor = start
    for _ in range(chunk_advance_safety_limit):
        response = client.get(f"/internal/events/since/{cursor}", headers=headers)
        assert response.status_code == 200, response.text
        body = response.json()
        chunk = body["events"]
        if not chunk:
            break
        seen.extend(chunk)
        next_cursor = body["next_cursor"]
        assert next_cursor != cursor, (
            f"cursor did not advance after returning {len(chunk)} events "
            f"(cursor={cursor!r}, next_cursor={next_cursor!r}) — infinite-loop bug"
        )
        cursor = next_cursor
    else:
        pytest.fail(
            f"event replay walk did not terminate within "
            f"{chunk_advance_safety_limit} hops"
        )
    return seen


def test_event_replay_no_duplicates_no_gaps(service_app_factory) -> None:
    """The load-bearing event-bus invariant: emit N events; the full
    cursor walk yields exactly those N events, each exactly once.

    Plan §D1: "emit 100 events, advance consumer cursor, assert no
    duplicates and no gaps."
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "event_replay_no_dups_no_gaps",
    )
    client = TestClient(app)
    headers = _auth_headers()

    emitted_ids: list[str] = []
    for i in range(100):
        emitted = _emit_event(client, headers, i)
        emitted_ids.append(emitted["event_id"])

    walked = _walk_cursor(client, headers)
    walked_ids = [event["event_id"] for event in walked]

    assert len(walked_ids) == len(set(walked_ids)), (
        f"duplicates detected: walk returned {len(walked_ids)} events "
        f"but only {len(set(walked_ids))} unique event_ids"
    )
    assert set(walked_ids) == set(emitted_ids), (
        f"gap detected: emitted {len(emitted_ids)} events, walked "
        f"{len(walked_ids)}; missing="
        f"{sorted(set(emitted_ids) - set(walked_ids))[:5]}..."
    )


def test_event_replay_cursor_past_end_is_empty(service_app_factory) -> None:
    """A cursor past the last emitted event must return empty events,
    not stale data and not an error. The next_cursor must NOT decrease.
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "event_replay_past_end",
    )
    client = TestClient(app)
    headers = _auth_headers()

    for i in range(5):
        _emit_event(client, headers, i)

    past_end = client.get("/internal/events/since/100", headers=headers)
    assert past_end.status_code == 200, past_end.text
    body = past_end.json()
    assert body["events"] == [], f"past-end cursor returned events: {body['events']}"
    assert int(body["next_cursor"]) >= int(body["cursor"]), (
        f"next_cursor regressed: cursor={body['cursor']}, next_cursor="
        f"{body['next_cursor']}"
    )


def test_event_replay_same_cursor_is_idempotent(service_app_factory) -> None:
    """Calling `since/{cursor}` twice with no intervening writes returns
    the same event set. A consumer that retries (network flake, restart)
    must not miss or double-count events because of the retry.
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "event_replay_idempotent",
    )
    client = TestClient(app)
    headers = _auth_headers()

    for i in range(10):
        _emit_event(client, headers, i)

    first = client.get("/internal/events/since/3", headers=headers)
    second = client.get("/internal/events/since/3", headers=headers)
    assert first.status_code == 200 and second.status_code == 200
    first_ids = [event["event_id"] for event in first.json()["events"]]
    second_ids = [event["event_id"] for event in second.json()["events"]]
    assert first_ids == second_ids, (
        f"non-idempotent replay: first call returned {first_ids}, second "
        f"call returned {second_ids}"
    )
    assert first.json()["next_cursor"] == second.json()["next_cursor"]


def test_event_replay_unknown_event_id_cursor_does_not_rewalk(
    service_app_factory,
) -> None:
    """An unknown event_id cursor (e.g., a stale cursor from before a
    consumer restart, or a typo) must NOT silently re-walk from event 0.

    The pre-fix behavior fell back to `start=0` on unknown event_id,
    which would deliver every event to a consumer who thought they were
    caught up — a duplicate-delivery failure mode that's silent and
    catastrophic. The fix treats unknown event_id as "caller is caught
    up": empty events + cursor preserved.

    A future iteration could return 4xx for unknown cursors to surface
    consumer state-drift explicitly; deferred to keep this step
    surgical.
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "event_replay_unknown_eid",
    )
    client = TestClient(app)
    headers = _auth_headers()

    for i in range(10):
        _emit_event(client, headers, i)

    unknown = client.get(
        "/internal/events/since/evt_does_not_exist_xyz", headers=headers
    )
    assert unknown.status_code == 200, unknown.text
    body = unknown.json()
    assert body["events"] == [], (
        f"unknown event_id cursor returned {len(body['events'])} events — "
        f"duplicate-delivery risk. Empty response is the safe behavior."
    )


def test_event_replay_chunked_walk_via_event_id_cursor(service_app_factory) -> None:
    """The cursor supports BOTH integer offsets AND event_id strings.
    The event_id form is what consumers naturally use ("I last
    processed event X; give me everything after"). A bug in the
    event_id-to-offset translation (off-by-one, missing event) would
    leak through the integer-cursor test.

    Emit N events; chunk-walk using event_id cursors (re-cursor on
    last-seen event_id). Assert union equals emitted set, no dupes.
    """
    app, _module = service_app_factory(
        "services/audit-service/app/main.py",
        "event_replay_eid_cursor",
    )
    client = TestClient(app)
    headers = _auth_headers()

    emitted_ids: list[str] = []
    for i in range(50):
        emitted = _emit_event(client, headers, i)
        emitted_ids.append(emitted["event_id"])

    seen: list[str] = []
    cursor = "0"
    for _ in range(60):  # safety bound: should converge in ≤50 hops
        response = client.get(f"/internal/events/since/{cursor}", headers=headers)
        body = response.json()
        chunk = body["events"]
        if not chunk:
            break
        # Switch from integer cursor to event_id cursor after the first
        # hop — the production consumer pattern.
        seen.extend(event["event_id"] for event in chunk)
        cursor = chunk[-1]["event_id"]
    else:
        pytest.fail("event_id cursor walk did not terminate")

    assert len(seen) == len(set(seen)), f"duplicates via event_id cursor: {seen}"
    assert set(seen) == set(emitted_ids), (
        f"gap via event_id cursor: missing="
        f"{sorted(set(emitted_ids) - set(seen))[:5]}"
    )
