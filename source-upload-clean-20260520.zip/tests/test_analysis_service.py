"""analysis-service tests (Phase 8.B/C).

Covers:
  - Happy path with fixture-deterministic: extract → analyze → topics
    persisted with the expected snapshot+projection split.
  - Fallback chain: unknown model_name → gateway 404 → analysis falls
    back to fixture-deterministic and emits document.analysis.fallback_triggered.
  - Audit envelope: document.analysis.completed event records model_used.

Step D0b migration note: the block payload below now goes through the
shared `tests/_docx_fixtures.py:build_block_payload` helper so the test
input mirrors what the producer's `_source_block` emits, exactly. The
prior hand-built 30-line dict had to enumerate every Block field by hand,
including all the `None` defaults — one easy place for fixture drift.
"""

from __future__ import annotations

import json
from typing import Any

import pytest
from _docx_fixtures import build_block_payload
from fastapi.testclient import TestClient


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_phase8"}


def _audit_events_via_service() -> list[dict[str, Any]]:
    """Phase 4 D2.7c — events live in audit-service, not state.audit_events."""
    import asyncio

    from ditagen_common.service_clients import list_audit_events

    response = asyncio.run(list_audit_events(headers=_auth_headers()))
    return response["events"]


def _seed_extraction_for_analysis(document_id: str) -> dict[str, Any]:
    """Drop a minimal source-blocks + structure-tree + asset-manifest +
    markdown set into the artifact registry so analysis-service can read
    them through its artifact-ref input shape."""
    from ditagen_common.artifacts import write_artifact
    from ditagen_common.ids import new_id
    from ditagen_common.store import JsonStore

    project_id = "prj_p8"
    business_unit_id = "bu_docs_ops"
    tenant_id = "ten_local"
    store = JsonStore()

    block = build_block_payload(
        block_id="blk_a",
        text="Payroll Setup",
        block_type="heading",
        document_id=document_id,
        page=1,
        confidence={"extraction": 0.92, "block_type": 0.95, "heading": 0.93, "semantic_inline": 0.7},
        source_line_ids=["line_a"],
        inferred_level=1,
        is_likely_heading=True,
        order_in_page=1,
        char_start=0,
        char_end=13,
    )
    blocks_jsonl = json.dumps(block, sort_keys=True) + "\n"
    blocks_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="source-blocks.jsonl",
        content=blocks_jsonl,
        content_type="application/x-jsonlines",
        store=store,
        created_by="usr_admin",
        producer="extraction-service",
    )
    structure_tree = {
        "document_id": document_id,
        "nodes": [{"block_id": "blk_a", "level": 1}],
        "quality": {"overall_confidence": 0.91},
    }
    structure_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="structure-tree.json",
        content=structure_tree,
        store=store,
        created_by="usr_admin",
        producer="extraction-service",
    )
    asset_manifest = {"document_id": document_id, "assets": []}
    asset_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="asset-manifest.json",
        content=asset_manifest,
        store=store,
        created_by="usr_admin",
        producer="extraction-service",
    )
    markdown_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="content.md",
        content="# Payroll Setup\n",
        content_type="text/markdown",
        store=store,
        created_by="usr_admin",
        producer="markdown-service",
    )

    def add(state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("projects", {})[project_id] = {
            "project_id": project_id,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "name": "Phase 8 Test",
            "status": "active",
            "document_ids": [document_id],
            "deleted_at": None,
        }
        return state

    store.mutate(add)

    return {
        "source_blocks": blocks_ref,
        "structure_tree": structure_ref,
        "asset_manifest": asset_ref,
        "markdown": markdown_ref,
        "project_id": project_id,
        "business_unit_id": business_unit_id,
        "tenant_id": tenant_id,
        "new_id_fn": new_id,
    }


def _analysis_payload(document_id: str, model_name: str = "fixture-deterministic") -> dict[str, Any]:
    seeds = _seed_extraction_for_analysis(document_id)
    return {
        "document_id": document_id,
        "project_id": seeds["project_id"],
        "business_unit_id": seeds["business_unit_id"],
        "tenant_id": seeds["tenant_id"],
        "actor_id": "usr_admin",
        "source_blocks_artifact": seeds["source_blocks"],
        "structure_tree_artifact": seeds["structure_tree"],
        "asset_manifest_artifact": seeds["asset_manifest"],
        "markdown_artifact": seeds["markdown"],
        "model_name": model_name,
        "prompt_version": "v0",
    }


def test_analysis_happy_path_writes_artifacts_and_persists_topics(
    service_app_factory, tmp_jsonstore
) -> None:
    """Phase 8.B end-to-end: POST /internal/analyses runs the full
    pipeline against fixture-deterministic and lands all 5 analysis
    artifacts plus N topics in state[topics]."""
    from ditagen_common.store import JsonStore

    app, _module = service_app_factory(
        "services/analysis-service/app/main.py", "phase8_analysis_happy"
    )
    client = TestClient(app)
    response = client.post(
        "/internal/analyses",
        headers=_auth_headers(),
        json=_analysis_payload("doc_p8_happy"),
    )
    assert response.status_code == 200, response.text
    body = response.json()

    expected_refs = {"topic_plan", "generated_topics", "dita_files", "validation_report", "export_zip"}
    assert expected_refs <= body["analysis_refs"].keys()
    assert body["model_requested"] == "fixture-deterministic"
    assert body["model_used"] == "fixture-deterministic"
    assert body["fell_back_to_fixture"] is False
    assert body["fallback_reason"] is None
    assert len(body["topic_ids"]) >= 1
    assert body["overall_confidence"] == pytest.approx(0.91)

    persisted_topics = JsonStore().read()["topics"]
    for topic_id in body["topic_ids"]:
        topic = persisted_topics[topic_id]
        assert topic["document_id"] == "doc_p8_happy"
        # Phase 6's snapshot/projection split — generated_topic carries
        # the immutable original incl. dita_xml; top-level is the
        # mutable projection.
        assert topic["generated_topic"]["dita_xml"]
        assert topic["dita_xml"]
        assert topic["status"] == "generated"


def test_analysis_emits_completed_audit_event(
    service_app_factory, tmp_jsonstore
) -> None:

    app, _module = service_app_factory(
        "services/analysis-service/app/main.py", "phase8_analysis_audit"
    )
    client = TestClient(app)
    response = client.post(
        "/internal/analyses",
        headers=_auth_headers(),
        json=_analysis_payload("doc_p8_audit"),
    )
    assert response.status_code == 200, response.text
    audit = _audit_events_via_service()
    events = [e for e in audit if e.get("action") == "document.analysis.completed"]
    assert len(events) == 1
    event = events[0]
    assert event["resource_id"] == "doc_p8_audit"
    assert event["metadata"]["model_used"] == "fixture-deterministic"
    assert event["metadata"]["fell_back_to_fixture"] is False
    assert event["metadata"]["topic_count"] >= 1


def test_analysis_falls_back_to_fixture_on_unknown_model(
    service_app_factory, tmp_jsonstore
) -> None:
    """Phase 8.C — unknown `model_name` makes the gateway return 404.
    analysis-service should classify that as fallback-eligible and
    retry the whole pipeline against fixture-deterministic, then emit
    a `document.analysis.fallback_triggered` audit event."""

    app, _module = service_app_factory(
        "services/analysis-service/app/main.py", "phase8_analysis_fallback"
    )
    client = TestClient(app)
    payload = _analysis_payload(
        "doc_p8_fallback", model_name="this-model-is-definitely-not-registered"
    )
    response = client.post("/internal/analyses", headers=_auth_headers(), json=payload)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["model_requested"] == "this-model-is-definitely-not-registered"
    assert body["model_used"] == "fixture-deterministic"
    assert body["fell_back_to_fixture"] is True
    assert body["fallback_reason"] is not None
    # Both events should land in the audit log.
    audit = _audit_events_via_service()
    assert any(
        e.get("action") == "document.analysis.fallback_triggered" for e in audit
    )
    assert any(e.get("action") == "document.analysis.completed" for e in audit)


def test_analysis_fixture_self_failure_returns_502(
    service_app_factory, tmp_jsonstore, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If the fixture provider itself fails (no fallback left), the
    route returns 502 — no infinite recursion, no silent success."""

    app, module = service_app_factory(
        "services/analysis-service/app/main.py", "phase8_analysis_terminal"
    )

    # Patch _call_gateway_topic_plan to always raise httpx.HTTPStatusError
    # with a 500 — this is what would happen if the gateway were down.
    import httpx

    async def boom(**kwargs: Any) -> dict[str, Any]:
        request = httpx.Request("POST", "http://test/internal/llm/topic-plan")
        response = httpx.Response(500, request=request, text="gateway down")
        raise httpx.HTTPStatusError(
            "500 Server Error", request=request, response=response
        )

    monkeypatch.setattr(module, "_call_gateway_topic_plan", boom)

    client = TestClient(app)
    payload = _analysis_payload("doc_p8_terminal", model_name="fixture-deterministic")
    response = client.post("/internal/analyses", headers=_auth_headers(), json=payload)
    assert response.status_code == 502, response.text
    assert "fixture" in response.text.lower()
    # No completed event should have landed — only the fallback chain
    # itself, but since we started AT fixture, no fallback is recorded
    # because the fallback path is only taken when model != fixture.
    audit = _audit_events_via_service()
    assert not any(
        e.get("action") == "document.analysis.completed"
        and e.get("resource_id") == "doc_p8_terminal"
        for e in audit
    )
