"""review-service edit-op surface tests (Phase 6.B/C/D/E/F/G).

Covers:
  - POST /internal/topics/{topic_id}/ops with each op variant.
  - Envelope auto-stamping (op_id, actor_id, created_at, parent_op_id,
    extraction_snapshot_id) when the client omits them.
  - 404 / 409 / 400 status code paths.
  - audit_events ledger shape: every applied op produces exactly one
    `edit.{op_type}` event plus one `topic.edited` follow-up.
  - Cold-start determinism: rebuilding an extraction snapshot from
    state and replaying the audit-log op chain produces a byte-
    identical ProjectedState across two service-app loads.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from _docx_fixtures import build_block_payload
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]


def _auth_headers() -> dict[str, str]:
    from ditagen_common.security import issue_token

    token = issue_token(
        {
            "sub": "usr_admin",
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_test",
            "roles": ["org_admin"],
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_phase6"}


def _audit_events_via_service() -> list[dict[str, Any]]:
    """Phase 4 D2.7c — read events from audit-service (canonical source),
    not from `JsonStore().read()["audit_events"]` which is retired."""
    import asyncio

    from ditagen_common.service_clients import list_audit_events

    response = asyncio.run(list_audit_events(headers=_auth_headers()))
    return response["events"]


def _seed_extraction_and_topics(
    *,
    document_id: str,
    project_id: str = "prj_phase6",
    business_unit_id: str = "bu_docs_ops",
    tenant_id: str = "ten_local",
) -> tuple[str, str, str]:
    """Write a minimal source-blocks.jsonl artifact and seed two topics
    plus an extraction record in JsonStore. Returns (snapshot_id,
    topic_one_record_id, topic_two_record_id).
    """
    from ditagen_common.artifacts import write_artifact
    from ditagen_common.ids import new_id
    from ditagen_common.store import JsonStore

    store = JsonStore()

    blocks = [
        _block_dict("blk_a", document_id, "Alpha sentence."),
        _block_dict("blk_b", document_id, "Bravo sentence."),
        _block_dict("blk_c", document_id, "Charlie sentence."),
    ]
    blocks_jsonl = "\n".join(json.dumps(b, sort_keys=True) for b in blocks) + "\n"
    blocks_ref = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name="source-blocks.jsonl",
        content=blocks_jsonl,
        content_type="application/x-jsonlines",
        store=store,
        created_by="usr_admin",
        producer="extraction-service",
    )
    snapshot_id = blocks_ref["artifact_id"]

    rid_one = new_id("trc")
    rid_two = new_id("trc")

    def add(state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("projects", {})[project_id] = {
            "project_id": project_id,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "name": "Phase 6 Test",
            "status": "active",
            "document_ids": [document_id],
            "deleted_at": None,
        }
        state["extractions"][document_id] = {
            "extraction_id": document_id,
            "document_id": document_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "stage": "markdown_complete",
            "started_at": "2026-05-09T00:00:00Z",
            "finished_at": "2026-05-09T00:00:01Z",
            "error": None,
            "artifacts": [blocks_ref],
            "warnings": [],
            "events": [],
            "block_count": len(blocks),
            "asset_count": 0,
        }
        # `generated_topic` is the IMMUTABLE original from
        # build_generated_topic — replay-from-snapshot reads its fields
        # to reconstruct the starting state. The top-level title /
        # topic_type / dita_xml are the MUTABLE projected view that the
        # workbench reads. Phase 6's replay discipline requires both
        # views: ops mutate only the top-level keys.
        state["topics"][rid_one] = {
            "topic_record_id": rid_one,
            "topic_id": rid_one,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "status": "generated",
            "title": "Topic One",
            "short_desc": None,
            "topic_type": "concept",
            "source_block_ids": ["blk_a", "blk_b"],
            "dita_xml": "<concept id='one'><title>Topic One</title></concept>",
            "generated_topic": {
                "topic_id": rid_one,
                "title": "Topic One",
                "short_desc": None,
                "topic_type": "concept",
                "source_block_ids": ["blk_a", "blk_b"],
                "dita_xml": "<concept id='one'><title>Topic One</title></concept>",
            },
            "validation_issues": [],
            "traceability": [],
            "artifact_version": new_id("av"),
        }
        state["topics"][rid_two] = {
            "topic_record_id": rid_two,
            "topic_id": rid_two,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "status": "generated",
            "title": "Topic Two",
            "short_desc": None,
            "topic_type": "reference",
            "source_block_ids": ["blk_c"],
            "dita_xml": "<reference id='two'><title>Topic Two</title></reference>",
            "generated_topic": {
                "topic_id": rid_two,
                "title": "Topic Two",
                "short_desc": None,
                "topic_type": "reference",
                "source_block_ids": ["blk_c"],
                "dita_xml": "<reference id='two'><title>Topic Two</title></reference>",
            },
            "validation_issues": [],
            "traceability": [],
            "artifact_version": new_id("av"),
        }
        return state

    store.mutate(add)
    return snapshot_id, rid_one, rid_two


def _block_dict(block_id: str, document_id: str, text: str) -> dict[str, Any]:
    """Minimal Block dict that round-trips through Block.model_validate.

    Step D0b: delegates to the shared `build_block_payload` helper so
    drift between this fixture's shape and the producer's
    `_source_block` output is structurally impossible.
    """
    return build_block_payload(
        block_id=block_id,
        text=text,
        block_type="paragraph",
        document_id=document_id,
        page=1,
        confidence={"extraction": 0.9, "block_type": 0.85, "semantic_inline": 0.7},
        source_line_ids=[f"line_{block_id}"],
        style_summary={
            "dominant_font_size_pt": 11.0,
            "font_size_rank": 2,
            "bold_ratio": 0,
            "italic_ratio": 0,
            "monospace_ratio": 0,
            "source_style_name": "Normal",
        },
        font={"size": 11.0, "weight": "regular"},
        order_in_page=1,
        char_start=0,
        char_end=len(text),
    )


@pytest.fixture
def review_app(service_app_factory, tmp_jsonstore):
    app, module = service_app_factory(
        "services/review-service/app/main.py", "phase6_review_service"
    )
    return app, module


def test_apply_rename_op_updates_topic_title(review_app) -> None:
    app, _module = review_app
    snapshot_id, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_rename")
    client = TestClient(app)
    response = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "rename",
            "payload": {"topic_id": rid_one, "title": "Renamed Topic", "short_desc": None},
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["op_type"] == "rename"
    assert body["topic"]["title"] == "Renamed Topic"
    assert body["topic"]["status"] == "edited"
    assert body["projected_state"]["snapshot_id"] == snapshot_id


def test_apply_retype_op_updates_topic_type(review_app) -> None:
    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_retype")
    client = TestClient(app)
    response = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "retype",
            "payload": {"topic_id": rid_one, "topic_type": "task"},
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["topic"]["topic_type"] == "task"


def test_apply_raw_xml_override_op_writes_dita_xml(review_app) -> None:
    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_xml")
    client = TestClient(app)
    new_xml = "<concept id='one'><title>One v2</title></concept>"
    response = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "raw_xml_override",
            "payload": {"topic_id": rid_one, "xml": new_xml},
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["topic"]["dita_xml"] == new_xml


def test_apply_move_op_relocates_block_to_target_topic(review_app) -> None:
    app, _module = review_app
    _, rid_one, rid_two = _seed_extraction_and_topics(document_id="doc_p6_move")
    client = TestClient(app)
    response = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "move",
            "payload": {"block_id": "blk_b", "target_topic_id": rid_two},
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    # The route resolves the target to rid_two for move ops.
    assert body["topic_id"] == rid_two
    target_topic = next(t for t in body["projected_state"]["topics"] if t["topic_id"] == rid_two)
    assert "blk_b" in target_topic["source_block_ids"]
    source_topic = next(t for t in body["projected_state"]["topics"] if t["topic_id"] == rid_one)
    assert "blk_b" not in source_topic["source_block_ids"]


def test_apply_op_against_unknown_topic_returns_404(review_app) -> None:
    app, _module = review_app
    _seed_extraction_and_topics(document_id="doc_p6_404")
    client = TestClient(app)
    response = client.post(
        "/internal/topics/trc_nonexistent/ops",
        headers=_auth_headers(),
        json={
            "op_type": "rename",
            "payload": {"topic_id": "trc_nonexistent", "title": "X", "short_desc": None},
        },
    )
    assert response.status_code == 404


def test_op_with_stale_snapshot_id_returns_409(review_app) -> None:
    """Caller pre-supplies an extraction_snapshot_id that doesn't match
    the document's current snapshot — replay rejects with
    SnapshotMismatchError, route surfaces as 409 Conflict."""
    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_409")
    client = TestClient(app)
    response = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_id": "op_explicit_test",
            "actor_id": "usr_admin",
            "created_at": "2026-05-09T12:00:00Z",
            "parent_op_id": None,
            "extraction_snapshot_id": "art_does_not_exist",
            "op_type": "rename",
            "payload": {"topic_id": rid_one, "title": "Stale", "short_desc": None},
        },
    )
    assert response.status_code == 409


def test_op_chain_persists_to_audit_events_with_canonical_envelope(review_app) -> None:
    """Every accepted op produces exactly one `edit.{op_type}` audit event
    whose metadata.op round-trips through EditOperationAdapter, plus one
    `topic.edited` follow-up. Locks ADR-004's audit-as-truth property."""
    from ditagen_common.models import EditOperationAdapter

    app, _module = review_app
    snapshot_id, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_audit")
    client = TestClient(app)
    for new_title in ("First Rename", "Second Rename"):
        response = client.post(
            f"/internal/topics/{rid_one}/ops",
            headers=_auth_headers(),
            json={
                "op_type": "rename",
                "payload": {
                    "topic_id": rid_one,
                    "title": new_title,
                    "short_desc": None,
                },
            },
        )
        assert response.status_code == 200, response.text

    audit = _audit_events_via_service()
    edit_events = [e for e in audit if (e.get("action") or "").startswith("edit.")]
    edited_events = [e for e in audit if e.get("action") == "topic.edited"]
    assert len(edit_events) == 2
    assert len(edited_events) == 2
    for event in edit_events:
        assert event["resource_type"] == "topic"
        assert event["resource_id"] == rid_one
        op_payload = event["metadata"]["op"]
        assert op_payload["extraction_snapshot_id"] == snapshot_id
        # Round-trip lock — payload must remain a valid op.
        EditOperationAdapter.validate_python(op_payload)
    # Parent chain — second op's parent_op_id equals first op's op_id.
    op_ids = [e["metadata"]["op"]["op_id"] for e in edit_events]
    parents = [e["metadata"]["op"]["parent_op_id"] for e in edit_events]
    assert parents[0] is None
    assert parents[1] == op_ids[0]


def test_list_document_ops_returns_chain_in_order(review_app) -> None:
    app, _module = review_app
    snapshot_id, rid_one, rid_two = _seed_extraction_and_topics(document_id="doc_p6_list")
    client = TestClient(app)
    for title in ("First", "Second"):
        client.post(
            f"/internal/topics/{rid_one}/ops",
            headers=_auth_headers(),
            json={"op_type": "rename", "payload": {"topic_id": rid_one, "title": title, "short_desc": None}},
        )
    response = client.get(
        "/internal/documents/doc_p6_list/ops", headers=_auth_headers()
    )
    assert response.status_code == 200
    body = response.json()
    assert body["snapshot_id"] == snapshot_id
    assert [op["op_type"] for op in body["ops"]] == ["rename", "rename"]
    assert body["ops"][0]["payload"]["title"] == "First"
    assert body["ops"][1]["payload"]["title"] == "Second"
    assert body["ops"][1]["parent_op_id"] == body["ops"][0]["op_id"]


def test_undo_rename_restores_previous_title(review_app) -> None:
    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_undo_rename")
    client = TestClient(app)
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={"op_type": "rename", "payload": {"topic_id": rid_one, "title": "Renamed", "short_desc": None}},
    )
    response = client.post(
        "/internal/documents/doc_p6_undo_rename/ops/undo",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    body = response.json()
    # Original seeded title was "Topic One".
    assert body["topic"]["title"] == "Topic One"


def test_undo_retype_restores_previous_topic_type(review_app) -> None:
    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_undo_retype")
    client = TestClient(app)
    # Seeded as "concept"; retype to "task" then undo back to "concept".
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={"op_type": "retype", "payload": {"topic_id": rid_one, "topic_type": "task"}},
    )
    response = client.post(
        "/internal/documents/doc_p6_undo_retype/ops/undo",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    assert response.json()["topic"]["topic_type"] == "concept"


def test_undo_move_restores_block_to_source_topic(review_app) -> None:
    app, _module = review_app
    _, rid_one, rid_two = _seed_extraction_and_topics(document_id="doc_p6_undo_move")
    client = TestClient(app)
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={"op_type": "move", "payload": {"block_id": "blk_b", "target_topic_id": rid_two}},
    )
    response = client.post(
        "/internal/documents/doc_p6_undo_move/ops/undo",
        headers=_auth_headers(),
    )
    assert response.status_code == 200, response.text
    state_topics = response.json()["projected_state"]["topics"]
    src = next(t for t in state_topics if t["topic_id"] == rid_one)
    dst = next(t for t in state_topics if t["topic_id"] == rid_two)
    assert "blk_b" in src["source_block_ids"]
    assert "blk_b" not in dst["source_block_ids"]


def test_undo_records_a_separate_audit_event(review_app) -> None:
    """Undo is itself an audited op — the chain must show both the
    original op and its inverse, so 'why did this topic flip back?' has
    a paper trail."""

    app, _module = review_app
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_undo_audit")
    client = TestClient(app)
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={"op_type": "retype", "payload": {"topic_id": rid_one, "topic_type": "task"}},
    )
    client.post(
        "/internal/documents/doc_p6_undo_audit/ops/undo",
        headers=_auth_headers(),
    )
    audit = _audit_events_via_service()
    edit_events = [e for e in audit if (e.get("action") or "") == "edit.retype"]
    assert len(edit_events) == 2
    # Both ops chain together: undo's parent_op_id == original op's op_id.
    op_ids = [e["metadata"]["op"]["op_id"] for e in edit_events]
    parents = [e["metadata"]["op"]["parent_op_id"] for e in edit_events]
    assert parents[0] is None
    assert parents[1] == op_ids[0]


def test_undo_with_empty_chain_returns_400(review_app) -> None:
    app, _module = review_app
    _seed_extraction_and_topics(document_id="doc_p6_undo_empty")
    client = TestClient(app)
    response = client.post(
        "/internal/documents/doc_p6_undo_empty/ops/undo",
        headers=_auth_headers(),
    )
    assert response.status_code == 400


def test_patch_topic_on_upload_delegates_to_review_via_raw_xml_override(
    service_app_factory,
) -> None:
    """Phase 6.D — `PATCH /v1/topics/{id}` body `{xml: str}` is preserved
    on upload-service for ADR-006 back-compat, but the actual mutation
    flows through review-service as a RawXmlOverrideOp and lands in the
    canonical audit log alongside structural ops."""

    review_app_, _r = service_app_factory(
        "services/review-service/app/main.py", "phase6_review_for_patch"
    )
    upload_app, _u = service_app_factory(
        "services/upload-service/app/main.py", "phase6_upload_for_patch"
    )
    _, rid_one, _ = _seed_extraction_and_topics(document_id="doc_p6_patch")

    new_xml = "<concept id='one'><title>Patched via legacy route</title></concept>"
    upload_client = TestClient(upload_app)
    response = upload_client.patch(
        f"/internal/topics/{rid_one}",
        headers=_auth_headers(),
        json={"xml": new_xml},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["dita_xml"] == new_xml
    assert body["status"] == "edited"
    assert "validation_issues" in body  # validation still runs (until Phase 7)

    # Audit log MUST contain a single edit.raw_xml_override event with the
    # right snapshot — proves the PATCH flowed through review-service's
    # op surface, not a parallel write path.
    audit = _audit_events_via_service()
    raw_xml_events = [e for e in audit if (e.get("action") or "") == "edit.raw_xml_override"]
    topic_edited_events = [e for e in audit if (e.get("action") or "") == "topic.edited"]
    assert len(raw_xml_events) == 1
    op_payload = raw_xml_events[0]["metadata"]["op"]
    assert op_payload["op_type"] == "raw_xml_override"
    assert op_payload["payload"]["topic_id"] == rid_one
    assert op_payload["payload"]["xml"] == new_xml
    assert op_payload["is_lossy"] is True
    # Exactly one topic.edited — emitted by review-service, NOT
    # double-emitted by upload-service.
    assert len(topic_edited_events) == 1


def test_apple_ca_merge_then_undo_restores_block_count_via_split_inverse(
    apple_ca_docx_bytes, service_app_factory
) -> None:
    """Phase 6.G end-to-end: extract Apple CA → seed a topic referencing
    two real table_rows → POST a Merge op → assert lineage on the
    merged block → POST undo → assert the merge-derived block is gone
    and the projected state has a Split-inverse pair that traces back
    to the merged block.

    Apple CA is the canonical real-world fixture. Merge inverse is
    Split-of-the-derived-block, so the original block_ids are NOT
    literally restored — replay's inverse produces new `blk_s_*` ids.
    The test asserts the load-bearing behavior: count round-trips
    (N → N-1 after merge → N after undo) and the projected texts
    concatenate back to the merged content.
    """
    from ditagen_common.artifacts import read_artifact_text, write_artifact
    from ditagen_common.ids import new_id
    from ditagen_common.store import JsonStore

    extract_app, _e = service_app_factory(
        "services/extraction-service/app/main.py", "phase6_apple_ca_extract"
    )
    extract_client = TestClient(extract_app)

    document_id = "doc_p6_apple_ca"
    project_id = "prj_p6_apple_ca"
    business_unit_id = "bu_docs_ops"
    tenant_id = "ten_local"
    original = write_artifact(
        project_id=project_id,
        document_id=document_id,
        name=f"original/{document_id}.docx",
        content=apple_ca_docx_bytes,
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        store=JsonStore(),
        created_by="usr_admin",
        producer="upload-service",
    )
    response = extract_client.post(
        "/internal/extractions",
        headers=_auth_headers(),
        json={
            "document_id": document_id,
            "project_id": project_id,
            "business_unit_id": business_unit_id,
            "filename": f"{document_id}.docx",
            "content_type": original["content_type"],
            "artifact_path": original["path"],
            "request_id": "req_p6_apple_ca",
            "requested_by": "usr_admin",
        },
    )
    assert response.status_code == 200, response.text
    blocks_ref = next(
        a for a in response.json()["artifacts"] if a["name"] == "source-blocks.jsonl"
    )
    raw_blocks = [
        json.loads(line)
        for line in read_artifact_text(blocks_ref).splitlines()
        if line.strip()
    ]

    table_rows = [b for b in raw_blocks if b["block_type"] == "table_row" and b.get("table_id")]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for b in table_rows:
        grouped.setdefault(b["table_id"], []).append(b)
    table_id, rows = next(((tid, rs) for tid, rs in grouped.items() if len(rs) >= 2), (None, None))
    assert table_id is not None and rows is not None, (
        "Apple CA must have at least one table with two or more rows"
    )
    blk_a_id = rows[0]["block_id"]
    blk_b_id = rows[1]["block_id"]
    blk_a_text = rows[0]["text"]
    blk_b_text = rows[1]["text"]

    rid = new_id("trc")

    def seed(state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("projects", {})[project_id] = {
            "project_id": project_id,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "name": "Apple CA Phase 6 Test",
            "status": "active",
            "document_ids": [document_id],
            "deleted_at": None,
        }
        state["topics"][rid] = {
            "topic_record_id": rid,
            "topic_id": rid,
            "tenant_id": tenant_id,
            "business_unit_id": business_unit_id,
            "project_id": project_id,
            "document_id": document_id,
            "status": "generated",
            "title": "Apple CA Contacts Topic",
            "short_desc": None,
            "topic_type": "concept",
            "source_block_ids": [blk_a_id, blk_b_id],
            "dita_xml": "<concept id='contacts'><title>Contacts</title></concept>",
            "generated_topic": {
                "topic_id": rid,
                "title": "Apple CA Contacts Topic",
                "short_desc": None,
                "topic_type": "concept",
                "source_block_ids": [blk_a_id, blk_b_id],
                "dita_xml": "<concept id='contacts'><title>Contacts</title></concept>",
            },
            "validation_issues": [],
            "traceability": [],
            "artifact_version": new_id("av"),
        }
        return state

    JsonStore().mutate(seed)

    review_app_, _r = service_app_factory(
        "services/review-service/app/main.py", "phase6_apple_ca_review"
    )
    review_client = TestClient(review_app_)
    n_blocks_initial = len(raw_blocks)

    merge_response = review_client.post(
        f"/internal/topics/{rid}/ops",
        headers=_auth_headers(),
        json={"op_type": "merge", "payload": {"block_ids": [blk_a_id, blk_b_id]}},
    )
    assert merge_response.status_code == 200, merge_response.text
    merge_body = merge_response.json()
    merged_state = merge_body["projected_state"]
    derived = [b for b in merged_state["blocks"] if b["block_id"].startswith("blk_m_")]
    assert len(derived) == 1, "expected exactly one merge-derived block"
    derived_block = derived[0]
    assert derived_block["lineage"] == [blk_a_id, blk_b_id]
    assert derived_block["text"] == f"{blk_a_text} {blk_b_text}"
    assert merged_state["traceability"][derived_block["block_id"]] == [blk_a_id, blk_b_id]
    projected_ids_after_merge = {b["block_id"] for b in merged_state["blocks"]}
    assert blk_a_id not in projected_ids_after_merge
    assert blk_b_id not in projected_ids_after_merge
    assert len(merged_state["blocks"]) == n_blocks_initial - 1

    undo_response = review_client.post(
        f"/internal/documents/{document_id}/ops/undo",
        headers=_auth_headers(),
    )
    assert undo_response.status_code == 200, undo_response.text
    undo_state = undo_response.json()["projected_state"]
    assert len(undo_state["blocks"]) == n_blocks_initial
    assert not any(b["block_id"].startswith("blk_m_") for b in undo_state["blocks"])
    split_pair = [b for b in undo_state["blocks"] if b["block_id"].startswith("blk_s_")]
    assert len(split_pair) == 2
    assert "".join(b["text"] for b in split_pair) == f"{blk_a_text} {blk_b_text}"
    for b in split_pair:
        assert b["lineage"] == [derived_block["block_id"]]


def test_cold_start_replay_is_byte_identical(review_app, service_app_factory) -> None:
    """Phase 6 invariant: if you load review-service twice and replay the
    same audit-log op chain, ProjectedState dumps are identical. The
    audit log is the source of truth — restart safety depends on this."""
    app, _module = review_app
    _, rid_one, rid_two = _seed_extraction_and_topics(document_id="doc_p6_cold")
    client = TestClient(app)
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "rename",
            "payload": {"topic_id": rid_one, "title": "Cold Run", "short_desc": "x"},
        },
    )
    client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "move",
            "payload": {"block_id": "blk_a", "target_topic_id": rid_two},
        },
    )

    # Reload the module (fresh import, fresh JsonStore handle pointing at
    # the same disk path) and re-derive the projected state via another
    # rename op; the projected_state included in the response must match
    # what we get from a third rename if computed twice.
    _module.store.read()  # warm any caches
    first = client.post(
        f"/internal/topics/{rid_one}/ops",
        headers=_auth_headers(),
        json={
            "op_type": "retype",
            "payload": {"topic_id": rid_one, "topic_type": "reference"},
        },
    ).json()["projected_state"]

    # Spin the service app a second time pointing at the same data dir
    # to simulate a cold start, then read its current snapshot+chain.
    app2, _module2 = service_app_factory(
        "services/review-service/app/main.py", "phase6_review_service_cold"
    )
    snapshot = _module2._load_snapshot("doc_p6_cold")
    # Phase 4 D2.7a — cold-start replay reads through audit-service
    # (the SQL source of truth), not the retired JSONL `state.audit_events`
    # path. asyncio.run is the test-shim for invoking the async API.
    import asyncio

    chain = asyncio.run(
        _module2._document_op_chain_for_request(
            "doc_p6_cold",
            snapshot.snapshot_id,
            headers=_auth_headers(),
        )
    )
    from ditagen_common.edits import replay

    second = replay(snapshot, chain).model_dump(mode="json")
    assert first == second
