"""Phase 4 D3.5.a — auto-seed lock.

`bu_db.ensure_sql_seeded()` bootstraps the BU service's SQL backend
from JsonStore's seed materialization when the SQL `tenants` table is
empty. It's called at `main.py` module-init time so both production
startup and test fixtures materialize seeds before the first request.

Invariants pinned here:

  1. After the BU service module loads against a fresh DITAGEN_DATA_DIR,
     SQL has the 3 seed BUs (`bu_docs_ops`, `bu_product_content`,
     `bu_compliance`) + their tenant + organization + memberships +
     favorites.
  2. `ensure_sql_seeded()` is idempotent: calling it twice (or even
     loading the service module twice in the same data dir) does not
     duplicate rows.
  3. If SQL is already non-empty when `ensure_sql_seeded()` runs, it's
     a no-op — does NOT re-import JsonStore state (so any divergence
     between SQL and JsonStore after the initial seed stays put).
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


@pytest.fixture
def bu_service_loaded(tmp_path, monkeypatch):
    """Load the BU service main.py against a fresh tmp_path data dir.

    Returns the module so tests can inspect post-load state via the
    production repositories (which read the same SQL the service
    seeded)."""
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv(
        "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
    )
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")

    from bu_db import reset_engine_cache

    reset_engine_cache()

    module_path = REPO_ROOT / "services" / "business-unit-service" / "app" / "main.py"
    full_module_name = f"bu_service_d3_5a_{abs(hash(str(tmp_path)))}"
    spec = importlib.util.spec_from_file_location(full_module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[full_module_name] = module
    spec.loader.exec_module(module)
    return module


def test_seed_business_units_appear_in_sql_after_service_loads(
    bu_service_loaded,
) -> None:
    """The 3 alpha-seed BUs are in SQL after the BU service module
    finishes initializing. This is the contract D3.5.b relies on when
    it switches `list_business_units` to read from SQL."""
    from bu_repositories import BusinessUnitRepository

    bus = BusinessUnitRepository().list_for_tenant("ten_local")
    bu_ids = {bu["business_unit_id"] for bu in bus}
    assert bu_ids == {"bu_docs_ops", "bu_product_content", "bu_compliance"}


def test_seed_memberships_and_favorites_present(bu_service_loaded) -> None:
    """Membership + favorite seeds round-trip so authorization checks
    (after D3.5.b switches them to repo-based) see the same access
    grants the JsonStore-based checks see today."""
    from bu_repositories import (
        BusinessUnitFavoriteRepository,
        BusinessUnitMembershipRepository,
    )

    admin_mems = BusinessUnitMembershipRepository().list_for_user("usr_admin")
    admin_bu_ids = {m["business_unit_id"] for m in admin_mems}
    assert admin_bu_ids == {"bu_docs_ops", "bu_product_content", "bu_compliance"}

    reviewer_mems = BusinessUnitMembershipRepository().list_for_user("usr_reviewer")
    assert {m["business_unit_id"] for m in reviewer_mems} == {"bu_docs_ops"}

    favorites = BusinessUnitFavoriteRepository().list_for_user("usr_admin")
    assert {f["business_unit_id"] for f in favorites} == {"bu_docs_ops"}


def test_seed_tenants_and_organizations_present(bu_service_loaded) -> None:
    from bu_repositories import OrganizationRepository, TenantRepository

    assert TenantRepository().list_all() == [
        {"tenant_id": "ten_local", "name": "Local Tenant"}
    ]
    orgs = OrganizationRepository().list_for_tenant("ten_local")
    assert len(orgs) == 1
    assert orgs[0]["organization_id"] == "org_local"


def test_auto_seed_is_idempotent_on_repeated_calls(
    bu_service_loaded, monkeypatch
) -> None:
    """Calling ensure_sql_seeded() a second time when SQL is already
    populated MUST be a no-op — no duplicate rows, no re-read of
    JsonStore. This is the property that lets production restart the
    BU service without thrashing the database."""
    from bu_db import ensure_sql_seeded
    from bu_repositories import (
        BusinessUnitMembershipRepository,
        BusinessUnitRepository,
    )

    bus_first = BusinessUnitRepository().list_for_tenant("ten_local")
    mems_first = BusinessUnitMembershipRepository().list_for_user("usr_admin")

    ensure_sql_seeded()
    ensure_sql_seeded()

    bus_after = BusinessUnitRepository().list_for_tenant("ten_local")
    mems_after = BusinessUnitMembershipRepository().list_for_user("usr_admin")

    assert len(bus_first) == len(bus_after) == 3
    assert len(mems_first) == len(mems_after) == 3


def test_auto_seed_no_op_does_not_re_read_jsonstore(
    bu_service_loaded, monkeypatch
) -> None:
    """If SQL is already populated, `ensure_sql_seeded()` MUST NOT
    re-read JsonStore. This protects against accidental overwrites if
    SQL has diverged from JsonStore after the initial seed (e.g.
    routes mutated state in SQL but not JsonStore — possible during
    D3.5.b's transitional window)."""
    from bu_db import ensure_sql_seeded
    from ditagen_common.store import JsonStore

    call_count = {"n": 0}
    original_read = JsonStore.read

    def counting_read(self):
        call_count["n"] += 1
        return original_read(self)

    monkeypatch.setattr(JsonStore, "read", counting_read)

    ensure_sql_seeded()

    assert call_count["n"] == 0, (
        "ensure_sql_seeded() must skip JsonStore.read() when SQL is "
        "already populated (tenants table non-empty)."
    )
