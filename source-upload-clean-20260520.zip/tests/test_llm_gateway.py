"""LLM Gateway service tests (Phase 4).

Coverage:
- Provider listing.
- Topic-plan and generate-topic round-trip via the FastAPI surface.
- Determinism: same request -> byte-identical response (fixture
  provider is deterministic).
- Chat completions returns 501 (no provider supports it in Phase 4;
  Phase 8 lands a real one).
- Unknown model returns 404.
- Schema compliance: topic_plan output validates against
  contracts/llm/topic-plan.schema.json.
"""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
from _docx_fixtures import build_block_payload
from ditagen_common.pipeline import build_structure_tree
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
TOPIC_PLAN_SCHEMA_PATH = REPO_ROOT / "contracts" / "llm" / "topic-plan.schema.json"


def _load_topic_plan_schema() -> dict:
    return json.loads(TOPIC_PLAN_SCHEMA_PATH.read_text(encoding="utf-8"))


def _structure_tree_for(blocks: list[dict]) -> dict:
    """Build a realistic structure_tree from the given blocks. The legacy
    pipeline expects `structure_tree['quality']['overall_confidence']`,
    so a hand-rolled minimal dict isn't enough."""
    return build_structure_tree(document_id="doc_gateway_test", source_blocks=blocks)


def _block_payload(*, block_id: str, text: str, block_type: str = "paragraph") -> dict:
    """Thin wrapper around `build_block_payload` for this test's defaults.

    Step D0b: delegates to the shared toolkit. `confidence.heading` is
    auto-populated for headings (matching the production producer); the
    earlier hand-built version had to keep this rule in sync manually,
    which surfaced as a real fixture-drift bug in Step C.
    """
    return build_block_payload(
        block_id=block_id,
        text=text,
        block_type=block_type,
        document_id="doc_gateway_test",
        page=1,
    )


def _gateway_client(service_app_factory) -> TestClient:
    app, _module = service_app_factory(
        "services/llm-gateway-service/app/main.py",
        "llm_gateway_test",
    )
    return TestClient(app)


def test_list_providers_returns_fixture_deterministic(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    response = client.get("/internal/llm/providers")
    assert response.status_code == 200, response.text
    body = response.json()
    names = [p["name"] for p in body["providers"]]
    assert "fixture-deterministic" in names
    fd = next(p for p in body["providers"] if p["name"] == "fixture-deterministic")
    caps = fd["capabilities"]
    assert caps["supports_topic_plan"] is True
    assert caps["supports_generate_topic"] is True
    assert caps["supports_chat_completions"] is False
    assert caps["deterministic"] is True


def test_topic_plan_returns_valid_plan_with_metadata(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    blocks = [
        _block_payload(block_id="blk_h1", text="Section A", block_type="heading"),
        _block_payload(block_id="blk_p1", text="The first paragraph."),
        _block_payload(block_id="blk_p2", text="The second paragraph."),
    ]
    request_body = {
        "document_id": "doc_gateway_test",
        "source_blocks": blocks,
        "structure_tree": _structure_tree_for(blocks),
        "model_name": "fixture-deterministic",
        "prompt_version": "v0",
    }
    response = client.post("/internal/llm/topic-plan", json=request_body)
    assert response.status_code == 200, response.text
    body = response.json()

    # Topic-plan output validates against the contract schema.
    schema = _load_topic_plan_schema()
    jsonschema.Draft202012Validator(schema).validate(body["topic_plan"])

    # Metadata records what we expect.
    meta = body["llm_metadata"]
    assert meta["model"] == "fixture-deterministic"
    assert meta["provider"] == "local-rule-based"
    assert meta["prompt_version"] == "v0"
    assert isinstance(meta["input_hash"], str) and len(meta["input_hash"]) == 64
    assert isinstance(meta["output_hash"], str) and len(meta["output_hash"]) == 64


def test_generate_topic_returns_typed_response(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    blocks = [
        _block_payload(block_id="blk_p1", text="The first paragraph."),
        _block_payload(block_id="blk_p2", text="The second paragraph."),
    ]
    plan_response = client.post(
        "/internal/llm/topic-plan",
        json={
            "document_id": "doc_gateway_test",
            "source_blocks": blocks,
            "structure_tree": _structure_tree_for(blocks),
        },
    )
    assert plan_response.status_code == 200, plan_response.text
    candidate = plan_response.json()["topic_plan"]["topic_candidates"][0]

    response = client.post(
        "/internal/llm/generate-topic",
        json={
            "candidate": candidate,
            "source_blocks": blocks,
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert "generated_topic" in body
    assert body["llm_metadata"]["model"] == "fixture-deterministic"


def test_fixture_provider_is_deterministic(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    blocks = [
        _block_payload(block_id="blk_h1", text="Section A", block_type="heading"),
        _block_payload(block_id="blk_p1", text="A paragraph."),
    ]
    request_body = {
        "document_id": "doc_det",
        "source_blocks": blocks,
        "structure_tree": _structure_tree_for(blocks),
    }
    first = client.post("/internal/llm/topic-plan", json=request_body).json()
    second = client.post("/internal/llm/topic-plan", json=request_body).json()
    # Same request -> identical output (including hashes).
    assert first == second


def test_chat_completions_returns_501_in_phase_4(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    response = client.post(
        "/internal/llm/chat/completions",
        json={
            "model": "fixture-deterministic",
            "messages": [
                {"role": "user", "content": "Hello"},
            ],
        },
    )
    assert response.status_code == 501
    assert "chat_completions" in response.json()["detail"]


def test_unknown_model_returns_404(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    blocks = [_block_payload(block_id="blk_p1", text="x")]
    response = client.post(
        "/internal/llm/topic-plan",
        json={
            "document_id": "d",
            "source_blocks": blocks,
            "structure_tree": _structure_tree_for(blocks),
            "model_name": "model-that-does-not-exist",
        },
    )
    assert response.status_code == 404
    assert "model-that-does-not-exist" in response.json()["detail"]


def test_topic_plan_rejects_empty_source_blocks(service_app_factory) -> None:
    """Per the contract, source_blocks must have at least one entry.

    Pydantic validation runs before the gateway dispatches to a
    provider, so structure_tree shape is irrelevant here.
    """
    client = _gateway_client(service_app_factory)
    response = client.post(
        "/internal/llm/topic-plan",
        json={
            "document_id": "d",
            "source_blocks": [],
            "structure_tree": {},
        },
    )
    # Pydantic validation -> 422.
    assert response.status_code == 422


def test_gateway_topic_planning_algorithm_matches_direct_pipeline(service_app_factory) -> None:
    """Phase 4 commit-message audit: the fixture provider's topic-planning
    *algorithm* produces byte-identical `topic_candidates` (and every
    other content field) compared to a direct `build_topic_plan` call.

    Known divergence: `input_artifact_hashes` differs between the two
    paths because the gateway runs blocks through Pydantic's
    `Block(**dict).model_dump(mode="json")` first, which adds explicit
    `null` for unset optional fields. The hash of that normalized blob
    differs from the hash of the raw legacy dict — by design (typed
    validation is the gateway's whole point). The test asserts the
    algorithm output is identical except for that one fingerprint
    field, and explicitly documents the known divergence in
    `_KNOWN_NORMALIZATION_DIVERGENCE_KEYS` so future readers can grep
    for it.
    """
    from ditagen_common.pipeline import build_topic_plan

    blocks = [
        _block_payload(block_id="blk_h1", text="Section A", block_type="heading"),
        _block_payload(block_id="blk_p1", text="The first paragraph."),
        _block_payload(block_id="blk_p2", text="The second paragraph."),
    ]
    structure_tree = _structure_tree_for(blocks)

    direct_plan = build_topic_plan(
        document_id="doc_drift_check",
        source_blocks=blocks,
        structure_tree=structure_tree,
        model_name="fixture-deterministic",
    )

    client = _gateway_client(service_app_factory)
    response = client.post(
        "/internal/llm/topic-plan",
        json={
            "document_id": "doc_drift_check",
            "source_blocks": blocks,
            "structure_tree": structure_tree,
            "model_name": "fixture-deterministic",
        },
    )
    assert response.status_code == 200, response.text
    gateway_plan = response.json()["topic_plan"]

    # Fields known to diverge because Pydantic normalizes block dicts
    # before computing fingerprints. Asserting they exist on both
    # sides AND that they hash to *some* sha256 catches structural
    # regressions while permitting the path-dependent normalization
    # shape divergence.
    _KNOWN_NORMALIZATION_DIVERGENCE_KEYS = ("input_artifact_hashes",)
    for key in _KNOWN_NORMALIZATION_DIVERGENCE_KEYS:
        assert key in direct_plan, f"direct path lost {key!r}"
        assert key in gateway_plan, f"gateway path lost {key!r}"

    # Algorithm output: every field other than the divergence keys
    # must be byte-identical.
    direct_logic = {k: v for k, v in direct_plan.items() if k not in _KNOWN_NORMALIZATION_DIVERGENCE_KEYS}
    gateway_logic = {k: v for k, v in gateway_plan.items() if k not in _KNOWN_NORMALIZATION_DIVERGENCE_KEYS}
    assert gateway_logic == direct_logic, (
        "fixture-deterministic provider drifted from legacy direct "
        "build_topic_plan call on a content field. Phase 4 invariant "
        "violated."
    )


def test_input_hash_changes_with_input(service_app_factory) -> None:
    client = _gateway_client(service_app_factory)
    blocks_a = [_block_payload(block_id="blk_p1", text="alpha")]
    blocks_b = [_block_payload(block_id="blk_p1", text="bravo")]
    a = client.post(
        "/internal/llm/topic-plan",
        json={"document_id": "d", "source_blocks": blocks_a, "structure_tree": _structure_tree_for(blocks_a)},
    ).json()
    b = client.post(
        "/internal/llm/topic-plan",
        json={"document_id": "d", "source_blocks": blocks_b, "structure_tree": _structure_tree_for(blocks_b)},
    ).json()
    assert a["llm_metadata"]["input_hash"] != b["llm_metadata"]["input_hash"]
    assert a["llm_metadata"]["output_hash"] != b["llm_metadata"]["output_hash"]
