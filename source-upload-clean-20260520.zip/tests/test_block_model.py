"""Tests for the typed `Block` Pydantic model.

Phase 2a of `plans/logical-whistling-widget.md` ships the model in
`ditagen_common.models.block`. The producer in `extractors.py` is not yet
flipped to construct `Block(...)` (that's Phase 2b). These tests lock the
model's contract independently of the producer.
"""

from __future__ import annotations

import pytest
from ditagen_common.models import Block, Confidence, InlineRun, SourceLocation
from pydantic import ValidationError


def _minimal_block_kwargs() -> dict:
    """The minimum-required-fields shape for a Block."""
    return {
        "block_id": "blk_test_001",
        "document_id": "doc_test",
        "block_type": "paragraph",
        "text": "Hello world.",
        "source_location": SourceLocation(page=1),
        "confidence": Confidence(extraction=0.9),
    }


def test_block_minimal_construction_has_default_lineage_and_review_flags() -> None:
    block = Block(**_minimal_block_kwargs())
    assert block.lineage == []
    assert block.review_flags == []
    assert block.heading_path_ids == []
    assert block.inline_runs == []
    assert block.asset_refs == []
    assert block.source_line_ids == []
    assert block.char_start is None
    assert block.char_end is None
    assert block.parent_block_id is None


def test_block_round_trip_preserves_all_fields() -> None:
    block = Block(
        **_minimal_block_kwargs(),
        char_start=10,
        char_end=22,
        parent_block_id="blk_parent",
        lineage=["blk_a", "blk_b"],
        inline_runs=[InlineRun(start=0, end=5, text="Hello", marks=["bold"])],
    )
    dumped = block.model_dump(mode="json")
    restored = Block.model_validate(dumped)
    assert restored == block


def test_block_rejects_invalid_block_type() -> None:
    kwargs = _minimal_block_kwargs()
    kwargs["block_type"] = "not_a_real_type"
    with pytest.raises(ValidationError):
        Block(**kwargs)


def test_confidence_unit_interval_enforced() -> None:
    Confidence(extraction=0.0)
    Confidence(extraction=1.0)
    with pytest.raises(ValidationError):
        Confidence(extraction=-0.01)
    with pytest.raises(ValidationError):
        Confidence(extraction=1.01)


def test_char_offsets_must_be_non_negative() -> None:
    with pytest.raises(ValidationError):
        Block(**_minimal_block_kwargs(), char_start=-1)
    with pytest.raises(ValidationError):
        Block(**_minimal_block_kwargs(), char_end=-1)


def test_block_now_rejects_legacy_duplicate_aliases() -> None:
    """Phase 2b posture: Block is `extra="forbid"`. The legacy duplicate
    aliases (`id`, `type`, `page`, top-level `bbox`) and any other
    unmapped key now raise ValidationError. The frontend already used
    canonical fields, so dropping the duplicates is a no-op for callers.
    """
    kwargs = _minimal_block_kwargs()
    # `table_id` and `row_index` are now first-class fields — these MUST
    # be accepted.
    Block(**kwargs, table_id="tbl_001", row_index=1)
    # The legacy aliases are now extras → ValidationError.
    with pytest.raises(ValidationError):
        Block.model_validate({**kwargs, "page": 1})
    with pytest.raises(ValidationError):
        Block.model_validate({**kwargs, "id": "blk_alias"})
    with pytest.raises(ValidationError):
        Block.model_validate({**kwargs, "type": "paragraph"})


def test_block_carries_table_row_fields() -> None:
    """table_id, row_index, and cells round-trip through model_dump."""
    from ditagen_common.models import TableCell

    kwargs = _minimal_block_kwargs()
    kwargs["block_type"] = "table_row"
    block = Block(
        **kwargs,
        table_id="tbl_007",
        row_index=3,
        cells=[
            TableCell(text="A", colspan=1, rowspan=1),
            TableCell(text="B", colspan=2, rowspan=1),
        ],
    )
    dumped = block.model_dump(mode="json")
    assert dumped["table_id"] == "tbl_007"
    assert dumped["row_index"] == 3
    assert dumped["cells"] == [
        {"text": "A", "colspan": 1, "rowspan": 1},
        {"text": "B", "colspan": 2, "rowspan": 1},
    ]


def test_block_carries_font_and_confidence_signals() -> None:
    from ditagen_common.models import ConfidenceSignals, Font

    kwargs = _minimal_block_kwargs()
    block = Block(
        **kwargs,
        font=Font(size=11.5, family="Arial", weight="regular"),
        confidence_signals=ConfidenceSignals(style="Heading 1", font_size=18.0),
        order_in_page=4,
        is_likely_heading=True,
    )
    dumped = block.model_dump(mode="json")
    assert dumped["font"] == {"size": 11.5, "family": "Arial", "weight": "regular"}
    assert dumped["confidence_signals"]["style"] == "Heading 1"
    assert dumped["order_in_page"] == 4
    assert dumped["is_likely_heading"] is True


def test_inline_run_marks_are_typed() -> None:
    InlineRun(start=0, end=5, text="hello", marks=["bold", "italic"])
    with pytest.raises(ValidationError):
        InlineRun(start=0, end=5, text="hello", marks=["not_a_mark"])  # type: ignore[list-item]


def test_inferred_level_bounds() -> None:
    # Schema range is 1..6.
    Block(**_minimal_block_kwargs(), inferred_level=1)
    Block(**_minimal_block_kwargs(), inferred_level=6)
    with pytest.raises(ValidationError):
        Block(**_minimal_block_kwargs(), inferred_level=0)
    with pytest.raises(ValidationError):
        Block(**_minimal_block_kwargs(), inferred_level=7)


def test_lineage_field_carries_source_ids_for_phase_6_replay() -> None:
    """Phase 6 will populate lineage when an edit-op (e.g. Merge) produces
    a derived block. This test locks the field's intended shape: a list
    of strings, default empty, accessible after model_dump().
    """
    block = Block(**_minimal_block_kwargs(), lineage=["blk_a", "blk_b", "blk_c"])
    assert block.lineage == ["blk_a", "blk_b", "blk_c"]
    dumped = block.model_dump(mode="json")
    assert dumped["lineage"] == ["blk_a", "blk_b", "blk_c"]
