from __future__ import annotations

import pytest
from ditagen_common.pipeline import build_structure_tree


def heading(block_id: str, level: int, text: str | None = None) -> dict:
    return {
        "block_id": block_id,
        "document_id": "doc_structure",
        "block_type": "heading",
        "text": text or block_id,
        "inferred_level": level,
        "confidence": {"heading": 0.9},
        "review_flags": [],
        "source_location": {"page": None, "section": f"docx:p:{level}"},
    }


def paragraph(block_id: str) -> dict:
    return {
        "block_id": block_id,
        "document_id": "doc_structure",
        "block_type": "paragraph",
        "text": block_id,
        "confidence": {"block_type": 0.9},
        "review_flags": [],
        "heading_path_ids": [],
        "source_location": {"page": None, "section": "docx:p:99"},
    }


def node_by_source(tree: dict, source_block_id: str) -> dict:
    return next(node for node in tree["nodes"] if node["source_block_id"] == source_block_id)


def test_structure_tree_nests_normal_heading_sequence() -> None:
    blocks = [heading("h1", 1), heading("h2", 2), heading("h3", 3), paragraph("p1")]
    tree = build_structure_tree(document_id="doc_structure", source_blocks=blocks)

    assert tree["schema_version"] == 2
    assert tree["root_nodes"] == [node_by_source(tree, "h1")["node_id"]]
    assert node_by_source(tree, "h2")["node_id"] in node_by_source(tree, "h1")["child_node_ids"]
    assert node_by_source(tree, "h3")["node_id"] in node_by_source(tree, "h2")["child_node_ids"]
    assert blocks[-1]["heading_path_ids"] == ["h1", "h2", "h3"]
    assert tree["quality"]["repaired_level_count"] == 0


def test_structure_tree_repairs_skipped_level() -> None:
    blocks = [heading("h1", 1), heading("h3", 3)]
    tree = build_structure_tree(document_id="doc_structure", source_blocks=blocks)

    assert node_by_source(tree, "h3")["node_id"] in node_by_source(tree, "h1")["child_node_ids"]
    assert tree["quality"]["repaired_level_count"] == 1


def test_structure_tree_creates_synthetic_root_for_orphan_heading() -> None:
    blocks = [heading("h3", 3), paragraph("p1")]
    tree = build_structure_tree(document_id="doc_structure", source_blocks=blocks)

    synthetic = tree["nodes"][0]
    assert synthetic["source_block_id"].startswith("synthetic_root_")
    assert node_by_source(tree, "h3")["node_id"] in synthetic["child_node_ids"]
    assert blocks[-1]["heading_path_ids"] == [synthetic["source_block_id"], "h3"]
    # Pin exact count: 1 for synthesizing the missing H1, 1 for the H1→H3
    # level skip beneath it. Permissive `>= 1` masks regressions where one
    # of the two repair branches stops counting.
    assert tree["quality"]["repaired_level_count"] == 2


def test_structure_tree_handles_no_headings() -> None:
    blocks = [paragraph("p1")]
    tree = build_structure_tree(document_id="doc_structure", source_blocks=blocks)

    assert tree["nodes"] == []
    assert tree["root_nodes"] == []
    assert tree["quality"]["review_required"] is True


# Parametrize sequences from the plan (§C) that exercise distinct
# heading-stack repair pathways. Each row pins:
#   - the heading levels in order
#   - expected number of root nodes (or root_kinds: "synthetic" / "real")
#   - expected repaired_level_count
#   - expected parent-child relationships
@pytest.mark.parametrize(
    "name, levels, expected_roots, expected_repairs, expected_children",
    [
        # H1 → H3 → H2: H3 attaches to H1 (skip repair); H2 closes H3 and
        # attaches to H1 (no repair, sibling of H3).
        ("inverted_then_flat", [1, 3, 2], ["h0"], 1, {"h0": ["h1", "h2"]}),
        # H2 → H3: synthesize H1 root; H2 attaches under synthetic; H3 attaches under H2.
        ("orphan_h2_then_h3", [2, 3], ["synthetic"], 1, {"synthetic": ["h0"], "h0": ["h1"]}),
        # H1, H1, H2, H1: three separate root H1s; middle H1 carries the H2.
        ("consecutive_h1s_with_h2", [1, 1, 2, 1], ["h0", "h1", "h3"], 0, {"h1": ["h2"]}),
        # H3 → H2 → H1: synthesize H1 first (for orphan H3 + skip), then H1 closes everything.
        # repaired_level_count: 1 for synthesis + 1 for the skipped level under it = 2.
        ("descending_with_orphan", [3, 2, 1], ["synthetic", "h2"], 2, {"synthetic": ["h0", "h1"]}),
    ],
)
def test_structure_tree_repair_state_machine(
    name: str,
    levels: list[int],
    expected_roots: list[str],
    expected_repairs: int,
    expected_children: dict[str, list[str]],
) -> None:
    """State-machine table for `build_structure_tree` heading-stack repair.

    `expected_roots`/`expected_children` use block_id strings (`h0`, `h1`,…)
    that correspond to positional order in `levels`. The literal string
    `"synthetic"` matches any synthetic root regardless of its generated id.
    """
    blocks = [heading(f"h{i}", level) for i, level in enumerate(levels)]
    tree = build_structure_tree(document_id="doc_structure", source_blocks=blocks)

    # Build lookup: a "synthetic" expectation matches any synthetic_root_NNN.
    def resolve(expected_id: str) -> str:
        if expected_id == "synthetic":
            synthetic_nodes = [n for n in tree["nodes"] if n["source_block_id"].startswith("synthetic_root_")]
            assert synthetic_nodes, f"[{name}] expected a synthetic root but none was created"
            return synthetic_nodes[0]["source_block_id"]
        return expected_id

    expected_root_ids = [resolve(rid) for rid in expected_roots]
    actual_root_block_ids = [
        node["source_block_id"]
        for node in tree["nodes"]
        if node["node_id"] in tree["root_nodes"]
    ]
    assert actual_root_block_ids == expected_root_ids, (
        f"[{name}] root mismatch: expected {expected_root_ids}, got {actual_root_block_ids}"
    )
    assert tree["quality"]["repaired_level_count"] == expected_repairs, (
        f"[{name}] repaired_level_count mismatch"
    )
    for parent_expected, children_expected in expected_children.items():
        parent_id = resolve(parent_expected)
        parent_node = node_by_source(tree, parent_id)
        actual_child_block_ids = [
            n["source_block_id"]
            for n in tree["nodes"]
            if n["node_id"] in parent_node["child_node_ids"]
        ]
        expected_child_ids = [resolve(c) for c in children_expected]
        assert actual_child_block_ids == expected_child_ids, (
            f"[{name}] children of {parent_expected} mismatch: expected "
            f"{expected_child_ids}, got {actual_child_block_ids}"
        )


def test_structure_tree_make_node_evidence_is_honest() -> None:
    """`make_node` no longer hard-codes evidence fields. When the block's
    style_summary lacks signals, the corresponding evidence fields surface
    as `null` rather than fake-true."""
    block = heading("h1", 1)
    # No style_summary → no font_size_rank, no bold_ratio.
    tree = build_structure_tree(document_id="doc_structure", source_blocks=[block])
    evidence = tree["nodes"][0]["evidence"]
    assert evidence["font_size_rank"] is None
    assert evidence["bold"] is None
    # `not_repeated_header_footer` is True by construction (headings can't
    # be running content) — that stays True.
    assert evidence["not_repeated_header_footer"] is True


def test_structure_tree_make_node_derives_evidence_from_style_summary() -> None:
    """When the block carries a style_summary, evidence fields derive
    from it instead of being hard-coded."""
    block = heading("h1", 1)
    block["style_summary"] = {
        "font_size_rank": 3,
        "bold_ratio": 0.75,
        "source_style_name": "Heading 1",
    }
    tree = build_structure_tree(document_id="doc_structure", source_blocks=[block])
    evidence = tree["nodes"][0]["evidence"]
    assert evidence["font_size_rank"] == 3
    assert evidence["bold"] is True
    assert evidence["docx_style_name"] == "Heading 1"
