"""Architecture lock — Phase 3 Step M2 of plans/architecture-hardening.md.

The pre-M2 monolith `services/extraction-service/app/extractors.py` was
2100 lines. Step M2 split it into a package under `extractors/` with
focused submodules:

  - `__init__.py`    — public API re-exports
  - `docx.py`        — DOCX entry point + DOCX-specific orchestration
  - `docx_helpers.py` — DOCX style/table/numbering helpers
  - `pdf.py`         — PDF extraction
  - `textual.py`     — plain-text + HTML extraction
  - `common.py`      — `_assemble_output`, `_source_line`, `_source_block`,
                       `_compute_review_signals`, `_extraction_quality`,
                       `_markdown`, `_style_profile`, `_asset_manifest`
  - `heading_classifier.py` — `_docx_block_type`, `_looks_like_heading`,
                              terminal-punctuation heuristics

Without this lock, a future commit can grow any single submodule past
~800 lines and the monolith pattern re-emerges silently. This test is
the regression guard for the split.

Two-part lock:

  (1) Per-file size cap — no `extractors/*.py` exceeds 800 lines.
      Threshold matches Phase 3 plan; it's not a magic number, just
      "small enough to read in one sitting."
  (2) Inventory pin — the set of submodules is fixed; adding a new one
      requires updating this test deliberately. Catches the case where
      a new submodule is added without thinking about whether it's the
      right home.

Out of scope for this test (deliberately):
  - Line count of `services/extraction-service/app/main.py` itself —
    that's the routing surface, not extraction logic.
  - Cross-submodule coupling — that's covered by per-function unit
    tests and the existing test suite's behavioural coverage.
"""

from __future__ import annotations

from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
EXTRACTORS_DIR = ROOT / "services" / "extraction-service" / "app" / "extractors"

# 800-line threshold per Phase 3 M2 of plans/architecture-hardening.md.
# If a real module is justifiably larger, bump this number DELIBERATELY
# with a comment explaining why — don't paper over the failure.
MAX_LINES = 800


def _submodule_paths() -> list[Path]:
    return sorted(p for p in EXTRACTORS_DIR.glob("*.py") if p.name != "__init__.py")


@pytest.mark.parametrize(
    "module_path",
    _submodule_paths(),
    ids=lambda p: p.name if isinstance(p, Path) else str(p),
)
def test_extractors_submodule_under_size_cap(module_path: Path) -> None:
    """Every submodule under `extractors/` is bounded.

    A failure here means the file grew past the readability threshold —
    a sign that a new responsibility is creeping in. Decide whether to
    split (preferred) or bump the cap (only when the file is legitimately
    cohesive and the line count is a cosmetic concern).
    """
    if not isinstance(module_path, Path):
        return
    line_count = sum(1 for _ in module_path.open("r", encoding="utf-8"))
    assert line_count <= MAX_LINES, (
        f"{module_path.relative_to(ROOT)} is {line_count} lines (cap: {MAX_LINES}). "
        f"M2's split keeps each extractor concern in a focused submodule; "
        f"this file is leaking past that ceiling. Either split a "
        f"responsibility out OR bump MAX_LINES with a deliberate comment "
        f"explaining why a larger file is acceptable here."
    )


def test_extractors_submodule_inventory_pinned() -> None:
    """Pin the submodule set so a new file can't slip past the size lock
    via a name the test doesn't know about."""
    actual = {p.name for p in _submodule_paths()}
    expected = {
        "common.py",
        "docx.py",
        "docx_helpers.py",
        "heading_classifier.py",
        "pdf.py",
        "textual.py",
    }
    assert actual == expected, (
        f"extractors/ submodule inventory drift. Expected {sorted(expected)}, "
        f"got {sorted(actual)}. Update this test deliberately when adding "
        f"or removing a submodule — and decide which existing test now "
        f"covers the new responsibility."
    )


def test_extractors_init_only_reexports() -> None:
    """`extractors/__init__.py` must stay a thin re-export shim, not
    grow into a fourth module by accident. The pre-split `extractors.py`
    was 2100 lines; the public-API surface here is small.

    50-line ceiling is generous for a re-export file. If `__init__.py`
    grows beyond that, the public API is probably leaking implementation
    detail.
    """
    init_py = EXTRACTORS_DIR / "__init__.py"
    line_count = sum(1 for _ in init_py.open("r", encoding="utf-8"))
    assert line_count <= 50, (
        f"extractors/__init__.py is {line_count} lines — expected a thin "
        f"re-export shim. Implementation should live in a submodule, not "
        f"in the package's __init__."
    )
