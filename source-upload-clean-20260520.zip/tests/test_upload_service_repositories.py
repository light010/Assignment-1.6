"""Repository contract tests for upload-service — Phase 4 D4.2.

These exercise the SQL-backed upload-service repositories directly
(no FastAPI, no service-app fixture). Endpoint-level tests live in
`test_week2_services.py` and `test_week3_extraction.py` and will
continue to exercise the production wire contract once D4.5 swaps the
storage backend.

Invariants pinned:

  1. `upsert` is idempotent on the natural key (document_id,
     upload_id, job_id, artifact_id, export_id) — a second upsert of
     the same id updates in place, never duplicates.
  2. Wire shape (`to_envelope()`) round-trips through SQL and back —
     JSON columns preserve dict/list shapes, optional fields appear
     only when set, the artifact-registry `id` alias is reconstructed
     at read time.
  3. List filters honour project/business-unit/tenant scope.
  4. `DocumentRepository.set_latest_artifact` re-assigns the JSON
     column (SQLAlchemy doesn't track in-place dict mutation) and
     leaves siblings untouched.
  5. Delete is idempotent — second delete returns False.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "upload-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


@pytest.fixture
def repos(tmp_path, monkeypatch):
    """Fresh SQLite-backed upload-service repositories per test."""
    from up_db import reset_engine_cache
    from up_repositories import (
        ArtifactRegistryRepository,
        DocumentRepository,
        ExportRepository,
        JobRepository,
        UploadSessionRepository,
    )

    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    reset_engine_cache()
    url = f"sqlite:///{tmp_path}/upload-service.sqlite3"
    yield {
        "documents": DocumentRepository(database_url=url),
        "sessions": UploadSessionRepository(database_url=url),
        "jobs": JobRepository(database_url=url),
        "artifacts": ArtifactRegistryRepository(database_url=url),
        "exports": ExportRepository(database_url=url),
    }
    reset_engine_cache()


def _doc_envelope(document_id: str = "doc_a", **overrides: Any) -> dict[str, Any]:
    base = {
        "document_id": document_id,
        "tenant_id": "ten_local",
        "business_unit_id": "bu_docs_ops",
        "project_id": "prj_p1",
        "filename": f"{document_id}.txt",
        "content_type": "text/plain",
        "source_hash": f"h_{document_id}",
        "status": "ready_for_review",
        "job_ids": ["job_a"],
        "topic_ids": [],
        "original_artifact": {"artifact_id": "art_orig"},
        "manifest": {"document_id": document_id},
        "manifest_artifact": None,
        "artifacts": {"original": {"artifact_id": "art_orig"}},
        "latest_artifacts": {},
        "source_quality": {"overall_confidence": 95},
        "extraction": {"stage": "markdown_complete"},
        "upload_id": None,
        "created_at": "2026-05-12T00:00:00Z",
    }
    base.update(overrides)
    return base


def _upload_envelope(upload_id: str = "upl_a", **overrides: Any) -> dict[str, Any]:
    base = {
        "upload_id": upload_id,
        "tenant_id": "ten_local",
        "organization_id": "org_local",
        "business_unit_id": "bu_docs_ops",
        "project_id": "prj_p1",
        "filename": "f.txt",
        "content_type": "text/plain",
        "size_bytes": 100,
        "status": "created",
        "parts": [],
        "received_bytes": 0,
        "created_by": "usr_admin",
        "created_at": "2026-05-12T00:00:00Z",
    }
    base.update(overrides)
    return base


def _job_envelope(job_id: str = "job_a", **overrides: Any) -> dict[str, Any]:
    base = {
        "job_id": job_id,
        "business_unit_id": "bu_docs_ops",
        "project_id": "prj_p1",
        "document_id": "doc_a",
        "stage": "pipeline",
        "status": "completed",
        "events": ["document.uploaded"],
        "created_at": "2026-05-12T00:00:00Z",
    }
    base.update(overrides)
    return base


def _artifact_envelope(artifact_id: str = "art_a", **overrides: Any) -> dict[str, Any]:
    base = {
        "artifact_id": artifact_id,
        "id": artifact_id,  # JsonStore wire shape duplicate
        "project_id": "prj_p1",
        "document_id": "doc_a",
        "name": "source-blocks.jsonl",
        "artifact_version": 1,
        "version": 1,
        "content_type": "application/x-jsonlines",
        "size_bytes": 120,
        "hash": f"h_{artifact_id}",
        "sha256": f"h_{artifact_id}",
        "path": f"/tmp/{artifact_id}",
        "producer": "extraction-service",
        "created_by": "usr_admin",
        "created_at": "2026-05-12T00:00:00Z",
        "previous_version_id": None,
    }
    base.update(overrides)
    return base


def _export_envelope(export_id: str = "exp_a", **overrides: Any) -> dict[str, Any]:
    base = {
        "export_id": export_id,
        "business_unit_id": "bu_docs_ops",
        "project_id": "prj_p1",
        "status": "completed",
        "topic_count": 3,
        "artifact": {"artifact_id": "art_zip"},
        "logs": ["Packaged 3 topic(s)"],
    }
    base.update(overrides)
    return base


# --- DocumentRepository -----------------------------------------------------


def test_document_upsert_idempotent_on_document_id(repos) -> None:
    """Two upserts with same document_id update in place; no duplicates."""
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_idem", status="ready_for_review"))
    docs.upsert(_doc_envelope("doc_idem", status="needs_review"))

    row = docs.get("doc_idem")
    assert row is not None
    assert row["status"] == "needs_review"
    # No duplicate: list-by-project sees only one row.
    assert len(docs.list_for_project("prj_p1")) == 1


def test_document_to_envelope_round_trips_json_columns(repos) -> None:
    """Dicts/lists in JSON columns preserve identity through SQL."""
    docs = repos["documents"]
    payload = _doc_envelope(
        "doc_json",
        artifacts={"original": {"name": "src.txt"}, "extra": {"name": "x.jsonl"}},
        latest_artifacts={"src.txt": "art_orig", "x.jsonl": "art_x"},
        source_quality={"overall_confidence": 88, "review_required": False},
        topic_ids=["t1", "t2", "t3"],
    )
    docs.upsert(payload)

    row = docs.get("doc_json")
    assert row is not None
    assert row["artifacts"] == payload["artifacts"]
    assert row["latest_artifacts"] == payload["latest_artifacts"]
    assert row["source_quality"] == payload["source_quality"]
    assert row["topic_ids"] == ["t1", "t2", "t3"]


def test_document_optional_fields_only_appear_when_set(repos) -> None:
    """extraction_failure_reason + topic_plan_approved are nullable —
    envelopes omit them when unset, include them when set."""
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_clean"))

    clean = docs.get("doc_clean")
    assert clean is not None
    assert "extraction_failure_reason" not in clean
    assert "topic_plan_approved" not in clean

    docs.upsert(
        _doc_envelope(
            "doc_failed",
            status="failed_extraction",
            extraction_failure_reason="ocr_timeout",
            topic_plan_approved=True,
        )
    )
    failed = docs.get("doc_failed")
    assert failed is not None
    assert failed["extraction_failure_reason"] == "ocr_timeout"
    assert failed["topic_plan_approved"] is True


def test_document_list_filters_honour_scope(repos) -> None:
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_p1_a", project_id="prj_p1", business_unit_id="bu_x"))
    docs.upsert(_doc_envelope("doc_p1_b", project_id="prj_p1", business_unit_id="bu_x"))
    docs.upsert(_doc_envelope("doc_p2", project_id="prj_p2", business_unit_id="bu_y"))

    p1 = {d["document_id"] for d in docs.list_for_project("prj_p1")}
    p2 = {d["document_id"] for d in docs.list_for_project("prj_p2")}
    bu_x = {d["document_id"] for d in docs.list_for_business_unit("bu_x")}
    tenant = {d["document_id"] for d in docs.list_for_tenant("ten_local")}

    assert p1 == {"doc_p1_a", "doc_p1_b"}
    assert p2 == {"doc_p2"}
    assert bu_x == {"doc_p1_a", "doc_p1_b"}
    assert tenant == {"doc_p1_a", "doc_p1_b", "doc_p2"}


def test_document_set_latest_artifact_mutates_only_named_key(repos) -> None:
    """The hot path: register_artifact mutates document.latest_artifacts.
    Setting one key must not clobber siblings."""
    docs = repos["documents"]
    docs.upsert(
        _doc_envelope(
            "doc_la",
            latest_artifacts={"a": "art_a_v1", "b": "art_b_v1"},
        )
    )

    updated = docs.set_latest_artifact("doc_la", "a", "art_a_v2")
    assert updated is not None
    assert updated["latest_artifacts"] == {"a": "art_a_v2", "b": "art_b_v1"}

    # New key — siblings untouched.
    updated = docs.set_latest_artifact("doc_la", "c", "art_c_v1")
    assert updated is not None
    assert updated["latest_artifacts"] == {
        "a": "art_a_v2",
        "b": "art_b_v1",
        "c": "art_c_v1",
    }


def test_document_set_latest_artifact_returns_none_for_missing(repos) -> None:
    assert repos["documents"].set_latest_artifact("ghost", "x", "y") is None


def test_document_delete_is_idempotent(repos) -> None:
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_del"))
    assert docs.delete("doc_del") is True
    assert docs.delete("doc_del") is False
    assert docs.get("doc_del") is None


def test_document_mark_topic_plan_approved_flips_atomically_and_skips_missing(
    repos,
) -> None:
    """Single-doc flip: returns the post-flip envelope when present,
    returns None when missing (matching the JsonStore-era guard)."""
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_tp", status="ready_for_review"))

    updated = docs.mark_topic_plan_approved("doc_tp")
    assert updated is not None
    assert updated["topic_plan_approved"] is True
    assert updated["status"] == "ready_for_review"  # other fields untouched

    # Second flip is idempotent — still True, still returns the envelope.
    second = docs.mark_topic_plan_approved("doc_tp")
    assert second is not None
    assert second["topic_plan_approved"] is True

    # Missing document — skip-on-missing semantics.
    assert docs.mark_topic_plan_approved("ghost") is None


def test_document_mark_topic_plan_approved_for_is_batch_atomic(repos) -> None:
    """Batch flip: every existing doc flips in one statement; missing ids
    are silently skipped. Replaces the project-wide approve loop."""
    docs = repos["documents"]
    docs.upsert(_doc_envelope("doc_a"))
    docs.upsert(_doc_envelope("doc_b"))
    docs.upsert(_doc_envelope("doc_c"))

    # Mixed list — one missing id slipped in.
    flipped = docs.mark_topic_plan_approved_for(["doc_a", "doc_b", "ghost"])
    assert flipped == 2

    assert docs.get("doc_a")["topic_plan_approved"] is True
    assert docs.get("doc_b")["topic_plan_approved"] is True
    # `doc_c` not in the call — untouched.
    doc_c = docs.get("doc_c")
    assert doc_c is not None
    assert "topic_plan_approved" not in doc_c

    # Empty list short-circuits — no statement, returns 0.
    assert docs.mark_topic_plan_approved_for([]) == 0


def test_document_with_atomic_update_runs_mutator_in_one_txn(repos) -> None:
    """The override-gate / reextract pattern: read envelope, mutate
    in place, write back — single SQL transaction."""
    docs = repos["documents"]
    docs.upsert(
        _doc_envelope(
            "doc_ov",
            status="extraction_needs_review",
            source_quality={"overall_confidence": 50, "review_required": False},
        )
    )

    def mutator(envelope: dict[str, Any]) -> None:
        envelope["status"] = "ready_for_review"
        envelope["source_quality"]["review_required"] = True
        envelope["source_quality"]["quality_gate"] = {"passed": True, "severity": "info"}

    updated = docs.with_atomic_update("doc_ov", mutator)
    assert updated is not None
    assert updated["status"] == "ready_for_review"
    assert updated["source_quality"]["review_required"] is True
    assert updated["source_quality"]["quality_gate"] == {
        "passed": True,
        "severity": "info",
    }
    # `overall_confidence` was not touched by the mutator — preserved.
    assert updated["source_quality"]["overall_confidence"] == 50


def test_document_with_atomic_update_returns_none_for_missing(repos) -> None:
    def mutator(envelope: dict[str, Any]) -> None:  # pragma: no cover — never called
        envelope["status"] = "should_not_fire"

    assert repos["documents"].with_atomic_update("ghost", mutator) is None


# --- UploadSessionRepository -----------------------------------------------


def test_upload_session_upsert_idempotent_with_growing_parts(repos) -> None:
    """The /parts route reads, appends to parts, upserts. Test this flow."""
    sessions = repos["sessions"]
    sessions.upsert(_upload_envelope("upl_g"))

    current = sessions.get("upl_g")
    assert current is not None
    assert current["parts"] == []
    assert current["received_bytes"] == 0

    # Simulate route: read, append, upsert.
    current["parts"] = [
        {"part_number": 1, "data_base64": "AAA", "size_bytes": 3}
    ]
    current["received_bytes"] = 3
    current["status"] = "receiving"
    sessions.upsert(current)

    after = sessions.get("upl_g")
    assert after is not None
    assert after["status"] == "receiving"
    assert len(after["parts"]) == 1
    assert after["received_bytes"] == 3


def test_upload_session_completion_fields_set_in_place(repos) -> None:
    """status=completed + document_id + completed_at written on /complete."""
    sessions = repos["sessions"]
    sessions.upsert(_upload_envelope("upl_c"))

    sessions.upsert(
        _upload_envelope(
            "upl_c",
            status="completed",
            document_id="doc_uplc",
            completed_at="2026-05-12T00:01:00Z",
        )
    )
    row = sessions.get("upl_c")
    assert row is not None
    assert row["status"] == "completed"
    assert row["document_id"] == "doc_uplc"
    assert row["completed_at"] == "2026-05-12T00:01:00Z"


# --- JobRepository ----------------------------------------------------------


def test_job_upsert_idempotent_and_lists_by_document(repos) -> None:
    jobs = repos["jobs"]
    jobs.upsert(_job_envelope("job_a", document_id="doc_x"))
    jobs.upsert(_job_envelope("job_b", document_id="doc_x"))
    jobs.upsert(_job_envelope("job_c", document_id="doc_y"))

    # Idempotent re-upsert preserves count.
    jobs.upsert(_job_envelope("job_a", document_id="doc_x", status="failed"))

    for_x = jobs.list_for_document("doc_x")
    assert {j["job_id"] for j in for_x} == {"job_a", "job_b"}
    # Status flip recorded.
    assert next(j for j in for_x if j["job_id"] == "job_a")["status"] == "failed"


# --- ArtifactRegistryRepository --------------------------------------------


def test_artifact_upsert_strips_id_alias_on_write_reconstructs_on_read(repos) -> None:
    """JsonStore wire shape carries `artifact_id` and a duplicate `id`.
    The typed model only has `artifact_id`; the alias is rebuilt on
    read so wire-shape consumers see both."""
    arts = repos["artifacts"]
    arts.upsert(_artifact_envelope("art_alias"))

    row = arts.get("art_alias")
    assert row is not None
    assert row["artifact_id"] == row["id"] == "art_alias"


def test_artifact_list_filters_by_document_and_project(repos) -> None:
    arts = repos["artifacts"]
    arts.upsert(_artifact_envelope("art_d1_a", document_id="doc_1", project_id="prj_p1"))
    arts.upsert(_artifact_envelope("art_d1_b", document_id="doc_1", project_id="prj_p1"))
    arts.upsert(_artifact_envelope("art_d2", document_id="doc_2", project_id="prj_p2"))

    for_d1 = {a["artifact_id"] for a in arts.list_for_document("doc_1")}
    for_p2 = {a["artifact_id"] for a in arts.list_for_project("prj_p2")}
    assert for_d1 == {"art_d1_a", "art_d1_b"}
    assert for_p2 == {"art_d2"}


# --- ExportRepository ------------------------------------------------------


def test_export_upsert_round_trips_topic_count_and_logs(repos) -> None:
    exports = repos["exports"]
    exports.upsert(_export_envelope("exp_rt", topic_count=5, logs=["a", "b"]))

    row = exports.get("exp_rt")
    assert row is not None
    assert row["topic_count"] == 5
    assert row["logs"] == ["a", "b"]


def test_export_upsert_idempotent_on_export_id(repos) -> None:
    exports = repos["exports"]
    exports.upsert(_export_envelope("exp_id", status="in_progress", topic_count=0))
    exports.upsert(_export_envelope("exp_id", status="completed", topic_count=4))
    row = exports.get("exp_id")
    assert row is not None
    assert row["status"] == "completed"
    assert row["topic_count"] == 4
