"""Phase 4 D4.3 — state.json → upload-service SQL migration lock.

These tests pin the migration script's contract that D4.5 will rely on
when it drops JsonStore reads from upload-service:

  1. Empty / missing state.json must not crash (idempotency edge case).
  2. Full roundtrip: every row written to state.json appears in SQL,
     queryable by the production repos with the matching envelope.
  3. Idempotency: running the migration twice is a no-op on the second
     run — every row is skipped, never duplicated.
  4. **Strict shape** (no backwards-compatibility coercion per D4
     invariant): envelopes missing required natural-key fields cause
     the script to exit non-zero rather than silently coerce. This is
     intentionally stricter than D3.4 — DITAgen has no production
     state.json files binding to ill-shaped envelopes.
  5. The script exits non-zero on malformed input (root-level type
     mismatch, missing required fields) — never silently migrates
     bad data.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "upload-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))

SCRIPT_PATH = REPO_ROOT / "scripts" / "migrate_upload_state.py"


def _run_migration(data_dir: Path) -> subprocess.CompletedProcess[str]:
    """Run the migration as a subprocess so the test exercises the same
    entry point an operator would use — including env-var resolution
    and the sys.path mutation the script does at import time."""
    return subprocess.run(
        [sys.executable, str(SCRIPT_PATH)],
        env={
            "DITAGEN_DATA_DIR": str(data_dir),
            "PATH": "/usr/bin:/bin",
        },
        capture_output=True,
        text=True,
        check=False,
    )


def _write_state(directory: Path, state: dict[str, Any]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "state.json").write_text(json.dumps(state), encoding="utf-8")


def _seed_state() -> dict[str, Any]:
    """Representative state.json covering all 5 upload-service-owned
    collections, with realistic field shapes for the typed model."""
    return {
        "documents": {
            "doc_a": {
                "document_id": "doc_a",
                "tenant_id": "ten_a",
                "business_unit_id": "bu_a",
                "project_id": "prj_a",
                "filename": "a.txt",
                "content_type": "text/plain",
                "source_hash": "h_a",
                "status": "ready_for_review",
                "job_ids": ["job_a"],
                "topic_ids": ["topic_a1"],
                "original_artifact": {"artifact_id": "art_orig_a"},
                "manifest": {"document_id": "doc_a"},
                "manifest_artifact": {"artifact_id": "art_manifest_a"},
                "artifacts": {"original": {"artifact_id": "art_orig_a"}},
                "latest_artifacts": {"source-blocks.jsonl": "art_blocks_a"},
                "source_quality": {"overall_confidence": 90},
                "extraction": {"stage": "markdown_complete"},
                "upload_id": "upl_a",
                "topic_plan_approved": True,
                "created_at": "2026-05-12T00:00:00Z",
            },
        },
        "upload_sessions": {
            "upl_a": {
                "upload_id": "upl_a",
                "tenant_id": "ten_a",
                "organization_id": "org_a",
                "business_unit_id": "bu_a",
                "project_id": "prj_a",
                "filename": "a.txt",
                "content_type": "text/plain",
                "size_bytes": 32,
                "status": "completed",
                "parts": [],
                "received_bytes": 32,
                "document_id": "doc_a",
                "completed_at": "2026-05-12T00:00:01Z",
                "created_by": "usr_admin",
                "created_at": "2026-05-12T00:00:00Z",
            },
        },
        "jobs": {
            "job_a": {
                "job_id": "job_a",
                "business_unit_id": "bu_a",
                "project_id": "prj_a",
                "document_id": "doc_a",
                "stage": "pipeline",
                "status": "completed",
                "events": ["document.uploaded", "extraction.completed"],
                "created_at": "2026-05-12T00:00:00Z",
            },
        },
        "artifact_registry": {
            "art_blocks_a": {
                "artifact_id": "art_blocks_a",
                "id": "art_blocks_a",
                "project_id": "prj_a",
                "document_id": "doc_a",
                "name": "source-blocks.jsonl",
                "artifact_version": 1,
                "version": 1,
                "content_type": "application/x-jsonlines",
                "size_bytes": 120,
                "hash": "h_blocks_a",
                "sha256": "h_blocks_a",
                "path": "/tmp/art_blocks_a",
                "producer": "extraction-service",
                "created_by": "usr_admin",
                "created_at": "2026-05-12T00:00:00Z",
                "previous_version_id": None,
            },
        },
        "exports": {
            "exp_a": {
                "export_id": "exp_a",
                "business_unit_id": "bu_a",
                "project_id": "prj_a",
                "status": "completed",
                "topic_count": 2,
                "artifact": {"artifact_id": "art_zip_a"},
                "logs": ["Packaged 2 topic(s)"],
            },
        },
    }


def test_missing_state_json_is_a_clean_noop(tmp_path) -> None:
    result = _run_migration(tmp_path)
    assert result.returncode == 0, result.stderr
    assert "nothing to migrate" in result.stderr


def test_full_roundtrip_writes_every_collection(tmp_path) -> None:
    """Every row in state.json appears in SQL with matching envelope."""
    from up_db import reset_engine_cache
    from up_repositories import (
        ArtifactRegistryRepository,
        DocumentRepository,
        ExportRepository,
        JobRepository,
        UploadSessionRepository,
    )

    _write_state(tmp_path, _seed_state())
    result = _run_migration(tmp_path)
    assert result.returncode == 0, result.stderr

    # Inspect SQL with the production repos. reset_engine_cache so the
    # in-test engine binds to the same DITAGEN_DATA_DIR the subprocess
    # used.
    import os

    os.environ["DITAGEN_DATA_DIR"] = str(tmp_path)
    reset_engine_cache()

    url = f"sqlite:///{tmp_path}/upload-service.sqlite3"
    doc = DocumentRepository(database_url=url).get("doc_a")
    assert doc is not None
    assert doc["filename"] == "a.txt"
    assert doc["topic_plan_approved"] is True
    assert doc["latest_artifacts"] == {"source-blocks.jsonl": "art_blocks_a"}

    upl = UploadSessionRepository(database_url=url).get("upl_a")
    assert upl is not None
    assert upl["completed_at"] == "2026-05-12T00:00:01Z"

    job = JobRepository(database_url=url).get("job_a")
    assert job is not None
    assert job["events"] == ["document.uploaded", "extraction.completed"]

    art = ArtifactRegistryRepository(database_url=url).get("art_blocks_a")
    assert art is not None
    # The wire-shape `id` alias is reconstructed at read time even
    # though the script stripped it on write.
    assert art["artifact_id"] == art["id"] == "art_blocks_a"

    exp = ExportRepository(database_url=url).get("exp_a")
    assert exp is not None
    assert exp["topic_count"] == 2


def test_running_migration_twice_is_a_noop_on_second_run(tmp_path) -> None:
    """Idempotency — natural-key upserts mean re-runs see all rows
    as skipped (already-present), never duplicate them."""
    _write_state(tmp_path, _seed_state())

    first = _run_migration(tmp_path)
    assert first.returncode == 0, first.stderr
    assert "1 inserted, 0 skipped" in first.stdout, first.stdout

    second = _run_migration(tmp_path)
    assert second.returncode == 0, second.stderr
    # Second run: every row already present → 0 inserted, 1 skipped.
    assert "0 inserted, 1 skipped" in second.stdout, second.stdout


def test_strict_shape_fails_loud_on_missing_required_field(tmp_path) -> None:
    """The D4 no-backcompat invariant: missing required fields are not
    silently coerced — the script exits 1 and prints which field is
    missing."""
    bad = _seed_state()
    del bad["documents"]["doc_a"]["business_unit_id"]
    _write_state(tmp_path, bad)

    result = _run_migration(tmp_path)
    assert result.returncode == 1
    assert "business_unit_id" in result.stderr
    assert "document envelope missing required fields" in result.stderr


def test_root_level_type_mismatch_fails_loud(tmp_path) -> None:
    """state.json's documents/upload_sessions/etc. must be dicts. A
    bad shape (list, string) exits 1 instead of crashing later."""
    bad: dict[str, Any] = {"documents": ["this should be a dict not a list"]}
    _write_state(tmp_path, bad)

    result = _run_migration(tmp_path)
    assert result.returncode == 1
    assert "state[documents] must be a dict" in result.stderr


def test_extra_keys_are_silently_dropped(tmp_path) -> None:
    """Workbench-only decorations on document envelopes (e.g. a future
    `pinned_by_user` field) have no column home and must be stripped
    on write rather than crashing the migration."""
    seed = _seed_state()
    seed["documents"]["doc_a"]["unknown_decoration"] = {"some": "thing"}
    _write_state(tmp_path, seed)

    result = _run_migration(tmp_path)
    assert result.returncode == 0, result.stderr

    # Verify the row was written without the extra column.
    import os

    from up_db import reset_engine_cache
    from up_repositories import DocumentRepository

    os.environ["DITAGEN_DATA_DIR"] = str(tmp_path)
    reset_engine_cache()
    url = f"sqlite:///{tmp_path}/upload-service.sqlite3"
    row = DocumentRepository(database_url=url).get("doc_a")
    assert row is not None
    assert "unknown_decoration" not in row


@pytest.fixture(autouse=True)
def _cleanup_engine_cache():
    """Reset the engine cache after each test so the subprocess-vs-
    in-process engine bindings don't leak across tests."""
    yield
    from up_db import reset_engine_cache

    reset_engine_cache()
