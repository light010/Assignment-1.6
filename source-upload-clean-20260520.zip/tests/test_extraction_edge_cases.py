"""Edge-case fixtures for the extraction quality gate.

Step A — Empty-paragraph rule canonicalization
==============================================

The canonical empty rule for body-index emission is:
    a paragraph is a body-index slot iff
        text.strip() != "" OR len(asset_refs) > 0.

This rule lives in two places that must agree byte-for-byte on every
document:
- `services/extraction-service/app/extractors/docx.py:_extract_docx`
  (`_docx_paragraph_image_asset_ids` resolves embedded media; the
  paragraph loop applies the predicate).
- `apps/web/src/SourceEvidenceViewer.tsx:collectDocxCandidates`
  (text-or-media check before advancing `bodyIndex`).

Any divergence shifts the locator index from that point forward,
breaking the locator-first match in the source viewer. Tests in this
module assert the producer side; the frontend side has parallel jsdom
coverage in `apps/web/src/SourceEvidenceViewer.test.tsx`.
"""

from __future__ import annotations

import io
import sys
from pathlib import Path
from typing import cast

# Add extraction-service to sys.path so we can import its extractors
# module without standing up the FastAPI app.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "extraction-service" / "app"))

from _docx_fixtures import (
    build_footnote_docx,
    build_header_footer_docx,
    build_hidden_text_paragraph_docx,
    build_hyperlink_paragraph_docx,
    build_image_only_paragraph_docx,
    build_nested_table_docx,
)
from ditagen_common.locator import parse_locator
from extractors import extract_document  # noqa: E402


def test_image_only_paragraph_consumes_body_index_slot() -> None:
    output = extract_document(
        document_id="doc_image_only",
        filename="image_only.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_image_only_paragraph_docx(),
    )

    paragraph_blocks = [
        block for block in output.source_blocks
        if block["block_type"] in {"paragraph", "heading", "figure"}
    ]
    assert len(paragraph_blocks) == 3, "Image-only paragraph must produce a block (not silently dropped)"

    sections = [block["source_location"]["section"] for block in paragraph_blocks]
    assert sections == ["docx:p:0", "docx:p:1", "docx:p:2"], (
        "Body-index must advance monotonically across the image-only slot"
    )

    figure_blocks = [block for block in paragraph_blocks if block["block_type"] == "figure"]
    assert len(figure_blocks) == 1, "The image-only paragraph must be classified as `figure`"
    figure_block = figure_blocks[0]
    assert figure_block["text"] == "", "A figure block carries no text payload"
    assert figure_block["asset_refs"], (
        "The figure block must reference at least one asset_id; otherwise the "
        "drawing data is lost downstream."
    )

    # The figure's asset_ref must be the same asset_id the manifest emits
    # for the same image bytes — otherwise downstream consumers can't
    # cross-link a block to its asset metadata.
    manifest_asset_ids = {asset["asset_id"] for asset in output.asset_manifest["assets"]}
    assert set(figure_block["asset_refs"]).issubset(manifest_asset_ids), (
        "Every asset_ref on a figure block must resolve in the asset manifest."
    )


def test_truly_empty_paragraph_does_not_consume_body_index_slot() -> None:
    """An empty `<w:p>` with no text and no drawing is still dropped.
    This is the second half of the canonical rule: only paragraphs with
    text *or* media may take a body-index slot.
    """
    from docx import Document

    document = Document()
    document.add_paragraph("First")
    document.add_paragraph("")  # truly empty
    document.add_paragraph("Second")
    buffer = io.BytesIO()
    document.save(buffer)

    output = extract_document(
        document_id="doc_empty_p",
        filename="empty_p.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=buffer.getvalue(),
    )
    body_blocks = [
        block for block in output.source_blocks
        if block["block_type"] in {"paragraph", "heading"}
    ]
    sections = [block["source_location"]["section"] for block in body_blocks]
    assert sections == ["docx:p:0", "docx:p:1"], (
        "Empty paragraph (no text, no media) must NOT consume a body-index slot."
    )


# --------------------------------------------------------------------------- #
# Step D1 — Heading inference cleanup
# --------------------------------------------------------------------------- #
#
# Two fixes locked here:
#   1. `_looks_like_heading(text, index)` no longer short-circuits on
#      `index == 1` when the text ends in terminal punctuation. The prior
#      behavior misclassified normal opening sentences ("This is a
#      sentence.") as headings whenever they happened to land at position 1.
#   2. `_docx_is_formatting_heading` gains an `in_table_cell` defensive guard
#      that always returns False when the paragraph is inside a cell —
#      preventing future Step E (nested-table walk) from promoting bold
#      cell paragraphs to top-level structure-tree headings.

import importlib.util  # noqa: E402


def _load_extractors():
    """Load the extractors module under a stable alias for D1 unit tests
    that exercise pure helper functions without standing up a service."""
    app_path = Path(__file__).resolve().parents[1] / "services" / "extraction-service" / "app"
    sys.path.insert(0, str(app_path))
    return importlib.import_module("extractors")


def test_looks_like_heading_rejects_terminal_punctuation_at_position_1() -> None:
    """Folds Finding A.1 from Step A. Prior behavior: any text ≤ 90 chars
    at index 1 returned True regardless of trailing `.`/`?`/`!`/etc.
    Fix: the terminal-punctuation guard runs FIRST so position-1 doesn't
    override it.
    """
    extractors = _load_extractors()
    # Sentences ending with terminal punctuation at position 1: not a heading.
    assert extractors._looks_like_heading("This is a sentence.", 1) is False
    assert extractors._looks_like_heading("Is this a heading?", 1) is False
    assert extractors._looks_like_heading("Step 1: do something,", 1) is False
    # Short clean text at position 1 still classifies as a heading
    # (preserves existing behavior for legitimate document titles).
    assert extractors._looks_like_heading("Apple CA Client Summary", 1) is True


def test_looks_like_heading_uses_unified_terminal_punctuation_set() -> None:
    """The same terminal-punctuation set must apply to position-1 and
    later positions — prior code had `.,:;` for `_looks_like_heading`
    and `.,:;!?` for the DOCX dotted-heading layer. Step D1 unifies via
    `_HEADING_TERMINAL_PUNCTUATION`.
    """
    extractors = _load_extractors()
    for terminator in extractors._HEADING_TERMINAL_PUNCTUATION:
        text = f"Some short text{terminator}"
        assert extractors._looks_like_heading(text, 1) is False, (
            f"Text ending in {terminator!r} must not classify as a heading at position 1"
        )
        assert extractors._looks_like_heading(text, 5) is False, (
            f"Text ending in {terminator!r} must not classify as a heading at later positions either"
        )


def test_docx_is_formatting_heading_in_cell_guard_returns_false() -> None:
    """Defensive guard: even when all formatting-heading criteria match,
    a paragraph inside a table cell must not be promoted. Step E will
    start classifying inner-cell paragraphs individually; this guard
    prevents that work from polluting the body-level structure tree.
    """
    extractors = _load_extractors()
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    document = Document()
    paragraph = document.add_paragraph("Heading-like text")
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in paragraph.runs:
        run.bold = True
        run.font.size = 200000  # Twips → very large; safely above any p90 threshold
    # Threshold of 11.0pt is well below the run's font size — formatting-only
    # signals would normally classify this as a heading.
    formatting_threshold = 11.0
    # Without the in-cell guard, the function classifies as a heading.
    assert extractors._docx_is_formatting_heading(
        paragraph, "Heading-like text", formatting_threshold
    ) is True
    # With `in_table_cell=True`, the guard short-circuits to False.
    assert extractors._docx_is_formatting_heading(
        paragraph, "Heading-like text", formatting_threshold, in_table_cell=True
    ) is False


# --------------------------------------------------------------------------- #
# Step D2 — Hidden text drop with HIDDEN_TEXT_DROPPED review_flag
# --------------------------------------------------------------------------- #

def test_hidden_text_is_dropped_from_block_text() -> None:
    """A paragraph mixing visible runs with a `<w:vanish/>` run must
    produce a block whose `text` field contains ONLY the visible runs.
    The dropped content stays in the source DOCX; the producer simply
    refuses to copy it into the extraction artifact.
    """
    output = extract_document(
        document_id="doc_hidden_text",
        filename="hidden_text.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_hidden_text_paragraph_docx(),
    )
    blocks = [block for block in output.source_blocks if block["block_type"] != "table_row"]
    assert len(blocks) == 1, "Exactly one paragraph block expected"
    block_text = blocks[0]["text"]
    assert "secret-internal-note" not in block_text, (
        "Hidden run text leaked into the block.text — the <w:vanish/> filter is not "
        "running."
    )
    assert "Visible" in block_text and "suffix" in block_text, (
        "Visible runs must remain in the block.text after filtering hidden ones."
    )


def test_hidden_text_emits_review_flag() -> None:
    """When hidden runs were filtered, the block carries the
    `HIDDEN_TEXT_DROPPED` review_flag with severity=warning so triage
    reviewers can confirm the drop was intentional."""
    output = extract_document(
        document_id="doc_hidden_text_flag",
        filename="hidden_text_flag.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_hidden_text_paragraph_docx(),
    )
    blocks = [block for block in output.source_blocks if block["block_type"] != "table_row"]
    flags = blocks[0].get("review_flags") or []
    flag_codes = [flag.get("code") for flag in flags if isinstance(flag, dict)]
    assert "HIDDEN_TEXT_DROPPED" in flag_codes, (
        f"Expected HIDDEN_TEXT_DROPPED review_flag; got {flag_codes!r}"
    )
    hidden_flag = next(f for f in flags if isinstance(f, dict) and f.get("code") == "HIDDEN_TEXT_DROPPED")
    assert hidden_flag["severity"] == "warning"


def test_visible_only_paragraph_does_not_emit_hidden_text_flag() -> None:
    """A paragraph with no `<w:vanish/>` runs must NOT carry the
    HIDDEN_TEXT_DROPPED flag — guards against false positives that
    would clutter the triage queue."""
    from docx import Document

    document = Document()
    document.add_paragraph("Just plain visible text.")
    buffer = io.BytesIO()
    document.save(buffer)
    output = extract_document(
        document_id="doc_no_hidden",
        filename="no_hidden.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=buffer.getvalue(),
    )
    blocks = [block for block in output.source_blocks if block["block_type"] != "table_row"]
    flag_codes = [
        flag.get("code")
        for block in blocks
        for flag in (block.get("review_flags") or [])
        if isinstance(flag, dict)
    ]
    assert "HIDDEN_TEXT_DROPPED" not in flag_codes


# --------------------------------------------------------------------------- #
# Step D3 — Hyperlinks captured into inline_runs[].href
# --------------------------------------------------------------------------- #

def test_hyperlink_paragraph_emits_inline_run_with_href() -> None:
    """A paragraph containing an external `<w:hyperlink>` must produce at
    least one `inline_runs` entry whose `href` matches the relationship
    target. The hyperlink run also carries a `"link"` mark.

    Before Step D3 the producer iterated `paragraph.runs` (which in
    python-docx 1.x excludes hyperlink runs entirely), leaving hyperlink
    text present in `block.text` but absent from `inline_runs` — an
    offset-alignment violation. Step D3 walks paragraph XML in document
    order so hyperlink runs are emitted alongside direct runs.
    """
    target_url = "https://example.com/help"
    output = extract_document(
        document_id="doc_hyperlink",
        filename="hyperlink.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_hyperlink_paragraph_docx(url=target_url),
    )
    blocks = [block for block in output.source_blocks if block["block_type"] != "table_row"]
    assert blocks, "Expected at least one paragraph block"
    block = blocks[0]
    hyperlinked = [
        run for run in (block.get("inline_runs") or [])
        if run.get("href")
    ]
    assert hyperlinked, (
        f"No inline_runs[].href entry found. inline_runs={block.get('inline_runs')!r}"
    )
    run = hyperlinked[0]
    assert run["href"] == target_url
    assert "link" in run["marks"], "Hyperlink runs must carry the 'link' mark"
    assert run["text"] == "example"


def test_hyperlink_run_offsets_align_with_block_text() -> None:
    """The inline_run start/end offsets for hyperlink runs must point to
    a valid substring of `block.text`. Before D3 the offsets were
    relative to a different stream (paragraph.runs only) — the hyperlink
    text was in block.text but missing from the inline_run cursor.
    """
    output = extract_document(
        document_id="doc_hyperlink_offsets",
        filename="hyperlink_offsets.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_hyperlink_paragraph_docx(url="https://example.com/help"),
    )
    blocks = [block for block in output.source_blocks if block["block_type"] != "table_row"]
    block = blocks[0]
    block_text = block["text"]
    for run in block.get("inline_runs") or []:
        start = run["start"]
        end = run["end"]
        if start < len(block_text) and end <= len(block_text):
            actual_slice = block_text[start:end]
            assert actual_slice == run["text"], (
                f"inline_run text {run['text']!r} doesn't match block.text[{start}:{end}]"
                f" = {actual_slice!r}"
            )


# --------------------------------------------------------------------------- #
# Step D4 — Footnotes/endnotes streams
# --------------------------------------------------------------------------- #

def test_footnote_emits_note_block_with_docx_footnote_locator() -> None:
    """A DOCX with one footnote produces an additional `block_type="note"`
    block whose locator is `docx:footnote:{id}`. The footnote text is
    extracted from `word/footnotes.xml`, NOT from the body paragraph
    that carries the `<w:footnoteReference>`.
    """
    footnote_text = "Customers in Quebec must use the French-language form."
    output = extract_document(
        document_id="doc_footnote",
        filename="footnote.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_footnote_docx(footnote_text=footnote_text),
    )

    note_blocks = [block for block in output.source_blocks if block["block_type"] == "note"]
    assert len(note_blocks) == 1, (
        f"Expected exactly one note block from one footnote; got {len(note_blocks)}: "
        f"{[(b['block_id'], b['text']) for b in note_blocks]}"
    )
    note = note_blocks[0]
    assert note["text"] == footnote_text
    assert note["source_location"]["section"] == "docx:footnote:1"
    # Locator must parse via the shared grammar — drift between producer
    # and locator module would surface here.
    parsed = parse_locator(note["source_location"]["section"])
    assert parsed.kind == "docx_footnote"
    assert parsed.values == (1,)
    # Confidence signals discriminate footnote vs endnote vs body content.
    assert (note.get("confidence_signals") or {}).get("source_kind") == "footnote"


def test_footnote_separators_are_not_emitted_as_blocks() -> None:
    """Word's `word/footnotes.xml` always contains two reserved entries:
    `w:id="-1"` (separator rule) and `w:id="0"` (continuation separator).
    Both must be filtered — they're rendering artifacts, not content.
    """
    output = extract_document(
        document_id="doc_footnote_sep",
        filename="footnote_sep.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_footnote_docx(footnote_text="Real footnote content."),
    )
    note_blocks = [block for block in output.source_blocks if block["block_type"] == "note"]
    # Exactly one — the separators (ids -1 and 0) must NOT appear.
    assert len(note_blocks) == 1
    for block in note_blocks:
        section = block["source_location"]["section"]
        parsed = parse_locator(section)
        assert parsed.kind == "docx_footnote"
        footnote_index = cast(int, parsed.values[0])
        assert footnote_index >= 1, (
            f"Reserved separator id leaked through: {section!r}"
        )


def test_footnote_block_heading_path_is_empty() -> None:
    """Footnote blocks are not part of the body structure — they don't
    inherit any heading_path_ids. Downstream consumers that group blocks
    by heading must not accidentally pull notes into the wrong section.
    """
    output = extract_document(
        document_id="doc_footnote_path",
        filename="footnote_path.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_footnote_docx(),
    )
    note_blocks = [block for block in output.source_blocks if block["block_type"] == "note"]
    assert note_blocks
    for block in note_blocks:
        assert block["heading_path_ids"] == [], (
            f"Footnote block must have empty heading_path_ids; got {block['heading_path_ids']!r}"
        )


# --------------------------------------------------------------------------- #
# Step D5 — Figure block downstream consumers (markdown, topic plan, DITA)
# --------------------------------------------------------------------------- #

def test_figure_block_renders_inline_in_extraction_service_markdown() -> None:
    """The extraction-service `_markdown` projector (python_v1 fallback)
    must render `figure` blocks at their body position as image markdown
    using the asset manifest's `dita_href`. Without this, image-only
    paragraphs leave a blank gap in `content.md` where they should
    surface the image inline.
    """
    output = extract_document(
        document_id="doc_figure_md",
        filename="figure_md.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_image_only_paragraph_docx(),
    )
    figure_blocks = [block for block in output.source_blocks if block["block_type"] == "figure"]
    assert figure_blocks, "Producer must emit a figure block for the image-only paragraph"
    asset_id = figure_blocks[0]["asset_refs"][0]
    manifest_asset = next(a for a in output.asset_manifest["assets"] if a["asset_id"] == asset_id)
    href = manifest_asset["dita_href"]

    # The markdown projector lives behind Pandoc OR the python_v1 fallback.
    # In the test environment without Pandoc, _project_markdown falls
    # back to _markdown which produces the assertion-friendly format.
    assert href in output.markdown, (
        f"Figure block's dita_href {href!r} was not inlined into markdown.\n"
        f"Markdown was:\n{output.markdown}"
    )
    # The figure's source sentinel must precede the image markdown so
    # downstream tooling can map back to the source block.
    assert f"<!-- source:{figure_blocks[0]['block_id']} -->" in output.markdown


def test_figure_block_renders_as_dita_image_element() -> None:
    """A topic generated from a candidate that includes a figure block
    must produce a DITA `<image>` element (not a `<p>` with empty text).
    The `href` attribute resolves to the asset manifest's `dita_href`.
    """
    from ditagen_common.pipeline import build_generated_topic, build_topic_plan

    output = extract_document(
        document_id="doc_figure_dita",
        filename="figure_dita.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_image_only_paragraph_docx(),
    )

    topic_plan = build_topic_plan(
        document_id="doc_figure_dita",
        source_blocks=output.source_blocks,
        structure_tree=output.structure_tree,
        model_name="fixture-deterministic",
    )
    # The figure block must appear in at least one topic candidate's
    # `source_block_ids` — build_topic_plan should not silently filter
    # figure content (Step D5 acceptance: include, do not exclude).
    all_topic_block_ids = {
        bid for tc in topic_plan["topic_candidates"] for bid in tc["source_block_ids"]
    }
    figure_block_ids = {b["block_id"] for b in output.source_blocks if b["block_type"] == "figure"}
    assert figure_block_ids & all_topic_block_ids, (
        f"Figure blocks {figure_block_ids} were not included in any topic candidate "
        f"({all_topic_block_ids})."
    )

    candidate_with_figure = next(
        tc for tc in topic_plan["topic_candidates"]
        if set(tc["source_block_ids"]) & figure_block_ids
    )
    generated = build_generated_topic(
        candidate=candidate_with_figure,
        source_blocks=output.source_blocks,
        model_name="fixture-deterministic",
        asset_manifest=output.asset_manifest,
    )
    # The concept body must contain an "image" content item whose href
    # came from the asset manifest.
    sections = generated["body"].get("sections", [])
    image_items = [
        item
        for section in sections
        for item in section.get("content", [])
        if item.get("kind") == "image"
    ]
    assert image_items, (
        f"Generated topic has no image content. Body: {generated['body']!r}"
    )
    expected_href = output.asset_manifest["assets"][0]["dita_href"]
    assert any(item["href"] == expected_href for item in image_items), (
        f"No image content item has the expected href {expected_href!r}; "
        f"got {[item['href'] for item in image_items]!r}"
    )


def test_image_only_paragraph_links_to_asset_manifest() -> None:
    """The figure block's asset_ref must resolve to the SAME asset_id the
    asset manifest emits for the same image bytes — otherwise downstream
    consumers cannot cross-link a block to its image metadata."""
    output = extract_document(
        document_id="doc_image_link",
        filename="image_link.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_image_only_paragraph_docx(),
    )
    figure_blocks = [block for block in output.source_blocks if block["block_type"] == "figure"]
    assert figure_blocks, "Image-only paragraph must produce a figure block"
    figure = figure_blocks[0]
    manifest_assets = {asset["asset_id"]: asset for asset in output.asset_manifest["assets"]}
    for asset_id in figure["asset_refs"]:
        assert asset_id in manifest_assets, (
            f"Figure block references asset_id {asset_id!r} but it's missing from "
            f"the asset manifest. Block-to-asset cross-links are broken."
        )


# --------------------------------------------------------------------------- #
# Step E — Nested-table walk + header/footer locators
# --------------------------------------------------------------------------- #
#
# Two surfaces close here:
#   - `format_docx_nested_table_row_locator` (D-audit-1): the helper has
#     been defined since Step D0 but had no producer caller. Step E wires
#     the producer to recurse one level into `cell.tables` and emit
#     `docx:tbl:{outer}:r:{row}:tbl:{N}:r:{M}` locators for every non-empty
#     inner row, tags the owning outer row with the `NESTED_TABLE` flag,
#     and emits `DEEP_NESTING_UNSUPPORTED` on inner rows that themselves
#     carry a further-nested table (bounded at one level).
#   - `format_docx_header_locator` / `format_docx_footer_locator`
#     (D-audit-2): same shape, dead since their introduction. Step E walks
#     `document.sections[i].header.paragraphs` and `.footer.paragraphs`,
#     emitting `running_header` / `running_footer` blocks with locators
#     `docx:hdr:section-{i}:p:{j}` / `docx:ftr:section-{i}:p:{j}`.
#
# These tests assert producer behavior. Frontend candidate emission for
# the new locator kinds has parallel jsdom coverage in
# `apps/web/src/SourceEvidenceViewer.test.tsx`.


def test_nested_table_emits_inner_row_locators() -> None:
    output = extract_document(
        document_id="doc_nested_tbl",
        filename="nested_table.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_nested_table_docx(),
    )

    table_rows = [block for block in output.source_blocks if block["block_type"] == "table_row"]
    sections = [block["source_location"]["section"] for block in table_rows]

    # Outer 2x2 → 2 outer rows; inner 2x1 nested into outer (r=1, cell-1) → 2 inner rows.
    expected_sections = [
        "docx:tbl:0:r:1",
        "docx:tbl:0:r:1:tbl:0:r:1",
        "docx:tbl:0:r:1:tbl:0:r:2",
        "docx:tbl:0:r:2",
    ]
    assert sections == expected_sections, (
        f"Step E nested-table locators are wrong. Want {expected_sections!r}, got {sections!r}"
    )

    parsed = [parse_locator(s) for s in sections]
    assert parsed[1].kind == "docx_nested_table_row"
    assert parsed[1].values == (0, 1, 0, 1)
    assert parsed[2].values == (0, 1, 0, 2)


def test_nested_table_outer_row_gets_nested_table_flag() -> None:
    output = extract_document(
        document_id="doc_nested_tbl_flag",
        filename="nested_table.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_nested_table_docx(),
    )

    outer_row_one = next(
        block for block in output.source_blocks
        if block["source_location"]["section"] == "docx:tbl:0:r:1"
    )
    codes = [flag["code"] for flag in outer_row_one["review_flags"]]
    assert "NESTED_TABLE" in codes, (
        "The outer row that owns nested tables must carry the NESTED_TABLE flag "
        f"so triage can route the row for review. Got codes: {codes!r}"
    )

    outer_row_two = next(
        block for block in output.source_blocks
        if block["source_location"]["section"] == "docx:tbl:0:r:2"
    )
    assert "NESTED_TABLE" not in [flag["code"] for flag in outer_row_two["review_flags"]], (
        "Outer rows without nested tables must NOT carry the flag."
    )


def test_nested_table_inner_rows_get_separate_table_id() -> None:
    """The inner table is its own logical row group — it must NOT share
    `table_id` with the outer table, otherwise `_compute_review_signals`'s
    sibling-row analysis (ORPHAN_TABLE_ROW) treats inner rows as missing
    outer-row peers (or vice versa).
    """
    output = extract_document(
        document_id="doc_nested_tbl_id",
        filename="nested_table.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_nested_table_docx(),
    )

    outer_row = next(
        block for block in output.source_blocks
        if block["source_location"]["section"] == "docx:tbl:0:r:1"
    )
    inner_row = next(
        block for block in output.source_blocks
        if block["source_location"]["section"] == "docx:tbl:0:r:1:tbl:0:r:1"
    )
    assert outer_row["table_id"] != inner_row["table_id"], (
        "Outer and inner tables must have distinct table_ids. "
        f"Outer={outer_row['table_id']!r}, inner={inner_row['table_id']!r}"
    )

    # No ORPHAN_TABLE_ROW false positives: each table sees row #1.
    for row in (outer_row, inner_row):
        assert "ORPHAN_TABLE_ROW" not in [flag["code"] for flag in row["review_flags"]], (
            f"Row at {row['source_location']['section']} should not be orphaned"
        )


def test_running_header_footer_emit_their_own_locator_namespaces() -> None:
    output = extract_document(
        document_id="doc_hdr_ftr",
        filename="header_footer.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_header_footer_docx(),
    )

    headers = [b for b in output.source_blocks if b["block_type"] == "running_header"]
    footers = [b for b in output.source_blocks if b["block_type"] == "running_footer"]

    assert len(headers) == 1, (
        f"Primary section header should produce one block; got {len(headers)}"
    )
    assert len(footers) == 1, (
        f"Primary section footer should produce one block; got {len(footers)}"
    )
    assert headers[0]["source_location"]["section"] == "docx:hdr:section-0:p:0"
    assert headers[0]["text"] == "Confidential — Draft"
    assert footers[0]["source_location"]["section"] == "docx:ftr:section-0:p:0"
    assert footers[0]["text"] == "Page 1 of N"

    # Header/footer blocks must NOT consume body-index slots: the single
    # body paragraph still owns docx:p:0.
    body_paragraphs = [
        b for b in output.source_blocks
        if b["block_type"] in {"paragraph", "heading", "figure"}
    ]
    body_sections = [b["source_location"]["section"] for b in body_paragraphs]
    assert body_sections == ["docx:p:0"], (
        f"Header/footer must not steal body-index slots. Body sections: {body_sections!r}"
    )


def test_running_header_footer_not_emitted_into_markdown() -> None:
    """The frontend triage panel reads `source_blocks.jsonl` and renders
    header/footer text on the side. `content.md` is the main reading flow
    and must NOT carry running header/footer text — otherwise every page's
    boilerplate ("Confidential — Draft", "Page N of M") leaks into the
    generated DITA topics.
    """
    output = extract_document(
        document_id="doc_hdr_ftr_md",
        filename="header_footer.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        data=build_header_footer_docx(),
    )
    assert "Confidential" not in output.markdown, (
        "Header text leaked into content.md — running_header was emitted "
        "as a markdown paragraph instead of being filtered."
    )
    assert "Page 1 of N" not in output.markdown, (
        "Footer text leaked into content.md — running_footer was emitted "
        "as a markdown paragraph instead of being filtered."
    )
