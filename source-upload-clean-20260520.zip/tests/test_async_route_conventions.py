"""Architecture lock — Phase 3 Step M3 of plans/architecture-hardening.md.

Convention (documented in `docs/async-conventions.md`):

  - Use `async def` for FastAPI routes that await service calls or
    `request_service`, since `request_service` is itself a coroutine.
  - Use sync `def` only for pure-computation or simple state-reads.
  - Never instantiate `httpx.AsyncClient` from a sync handler — its
    methods return coroutines that need a running event loop.

Static check (not perfect, but the right shape for catching the obvious
regressions):

  - AST-walk each `services/*/app/main.py`.
  - For each *sync* `def` (FunctionDef, not AsyncFunctionDef), inspect
    its body source for direct mentions of `request_service(` or
    `httpx.AsyncClient`. Both are async-only APIs; using them from a
    sync function is either a bug (calling without await — returns the
    coroutine object) or an event-loop-creation smell.
  - The check ignores async functions entirely (their use of these APIs
    is correct by definition).

False-negative cases (acceptable for this gate):
  - A sync helper that returns a coroutine for an async caller to await
    — legal but rare in this codebase; the test inspects route handlers
    and top-level service functions, not generic utilities.
  - A sync function that builds an `httpx.AsyncClient` for an async
    caller to use — also legal but rare.

False-positive cases:
  - Mentions inside comments or string literals would match the textual
    body scan but not the AST attribute scan; we use AST so this is not
    a problem.

If a legitimate sync function needs to mention these names (e.g., a
type annotation `httpx.AsyncClient` parameter), the test scopes its
scan to *call* expressions, not type hints.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SERVICES_DIR = ROOT / "services"

# Async-only APIs that must NEVER be called from a sync function body.
# Extend deliberately — each addition is a tightening of the contract.
_ASYNC_ONLY_CALLS: frozenset[str] = frozenset({
    "request_service",
    "request_internal",
})

# Async-only constructors. Direct instantiation from a sync function is
# a sign the function should be `async def`.
_ASYNC_ONLY_CONSTRUCTORS: frozenset[str] = frozenset({
    "AsyncClient",  # httpx.AsyncClient
})


def _service_main_paths() -> list[tuple[str, Path]]:
    pairs: list[tuple[str, Path]] = []
    for service_dir in sorted(SERVICES_DIR.iterdir()):
        if not service_dir.is_dir():
            continue
        main_py = service_dir / "app" / "main.py"
        if main_py.exists():
            pairs.append((service_dir.name, main_py))
    return pairs


def _call_target_name(node: ast.AST) -> str | None:
    """Return the rightmost name in a Call's function expression.

    `request_service(...)` → "request_service"
    `httpx.AsyncClient(...)` → "AsyncClient"
    `obj.method(...)` → "method"
    """
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _sync_function_call_names(func: ast.FunctionDef) -> set[str]:
    """Names of every callable invoked in `func`'s body. Excludes nested
    async function bodies (their calls are evaluated in their own
    context, which is the right one)."""
    calls: set[str] = set()
    for node in ast.walk(func):
        if isinstance(node, ast.AsyncFunctionDef) and node is not func:
            continue
        if isinstance(node, ast.Call):
            name = _call_target_name(node.func)
            if name is not None:
                calls.add(name)
    return calls


@pytest.mark.parametrize(
    "service_name,main_py",
    _service_main_paths(),
    ids=lambda value: value if isinstance(value, str) else "main.py",
)
def test_sync_handlers_do_not_call_async_only_apis(
    service_name: str, main_py: Path
) -> None:
    """No sync `def` in any service's main.py may call an async-only API.

    Failure mode this guards against: a copy-paste new route handler
    that's declared `def` (not `async def`) but calls
    `request_service(...)` — silently returns a coroutine object as the
    response body. The bug is invisible until a consumer tries to use
    the JSON.
    """
    if not isinstance(main_py, Path):
        return
    try:
        tree = ast.parse(main_py.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        pytest.fail(f"could not parse {main_py}: {exc}")
    violations: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        # AsyncFunctionDef is a separate AST class; FunctionDef ONLY
        # matches sync functions.
        calls = _sync_function_call_names(node)
        offending_calls = calls & _ASYNC_ONLY_CALLS
        offending_ctors = calls & _ASYNC_ONLY_CONSTRUCTORS
        if offending_calls or offending_ctors:
            offenders = sorted(offending_calls | offending_ctors)
            violations.append(
                f"sync def {node.name!r} (line {node.lineno}) calls async-only: "
                + ", ".join(offenders)
            )
    assert not violations, (
        f"services/{service_name}/app/main.py has sync handlers that call "
        f"async-only APIs:\n  "
        + "\n  ".join(violations)
        + "\n\nFix: change the function to `async def` and `await` the "
        "call. See docs/async-conventions.md."
    )


def test_async_conventions_doc_exists() -> None:
    """The architecture lint refers to `docs/async-conventions.md`; that
    doc must exist and contain the `request_service` rule. If a future
    cleanup deletes the doc, this test fails before the lint rule
    becomes orphaned guidance."""
    doc = ROOT / "docs" / "async-conventions.md"
    assert doc.exists(), (
        "docs/async-conventions.md is missing. The async lint test refers "
        "to this doc as the canonical convention; it must exist for the "
        "rule to be discoverable."
    )
    text = doc.read_text(encoding="utf-8")
    assert "request_service" in text, (
        "docs/async-conventions.md should explain why `request_service` "
        "callers must be `async def`. Update the doc."
    )
