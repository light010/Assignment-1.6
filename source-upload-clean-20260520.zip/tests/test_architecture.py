"""Architecture-level regression tests for the DITAgen backend.

Each test here locks an invariant about how the code is *shaped*, not just
what it does. Future phases of `plans/logical-whistling-widget.md` add
more — the goal is to make architectural drift fail loudly.
"""

from __future__ import annotations

import ast
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _enclosing_function_name(tree: ast.AST, target: ast.AST) -> str | None:
    """Walk back up the parent chain to find the enclosing FunctionDef name."""
    target_lineno = getattr(target, "lineno", None)
    if target_lineno is None:
        return None
    enclosing: ast.FunctionDef | ast.AsyncFunctionDef | None = None
    enclosing_lineno = -1
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            start = node.lineno
            end = getattr(node, "end_lineno", start)
            if start <= target_lineno <= end and start > enclosing_lineno:
                enclosing = node
                enclosing_lineno = start
    return enclosing.name if enclosing is not None else None


def test_docx_paragraphs_only_used_in_caption_candidates() -> None:
    """`document.paragraphs` is reserved for caption scanning.

    Phase 1 of the backend root-cause plan: DOCX block extraction must
    happen via the body walker (`_docx_body_items` over
    `document.element.body.iterchildren()`), preserving the interleaved
    order of `<w:p>` and `<w:tbl>`. The shortcut `document.paragraphs`
    skips tables entirely, so any new use of it for block extraction
    silently regresses body order.

    The single permitted use is inside `_docx_caption_candidates`, which
    scans paragraphs for Caption-style entries to attach to nearby
    images.
    """
    extractors_path = (
        REPO_ROOT / "services" / "extraction-service" / "app" / "extractors" / "docx_helpers.py"
    )
    tree = ast.parse(extractors_path.read_text(encoding="utf-8"))

    allowed_function = "_docx_caption_candidates"
    violations: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Attribute):
            continue
        if node.attr != "paragraphs":
            continue
        # Skip non-`document` attribute receivers — e.g. `cell.paragraphs`
        # is unrelated and is part of normal table-cell processing. We
        # specifically care about `document.paragraphs` (the bypass that
        # would skip tables).
        receiver = node.value
        if isinstance(receiver, ast.Name) and receiver.id != "document":
            continue
        enclosing = _enclosing_function_name(tree, node)
        if enclosing != allowed_function:
            violations.append((node.lineno, enclosing or "<module>"))

    assert not violations, (
        "document.paragraphs may only be used inside _docx_caption_candidates "
        "(Phase 1 invariant). Found uses in: "
        + ", ".join(f"line {ln} (in {fn})" for ln, fn in violations)
    )


def test_pipeline_topic_functions_only_imported_by_gateway() -> None:
    """`build_topic_plan` and `build_generated_topic` flow through the LLM Gateway.

    Phase 4 of the backend root-cause plan: every topic-planning and
    topic-generation call goes through `llm-gateway-service` per
    ADR-005:32. No service may bypass the gateway by importing the
    legacy pipeline functions directly. The gateway itself is the one
    permitted importer (Phase 8 retires the duplication when a real
    provider lands; Phase 11 may delete the pipeline.py duplicates).

    Allowed importers:
      - services/llm-gateway-service/** (the gateway itself)
      - packages/python/ditagen_common/ditagen_common/pipeline.py
        (the alpha-helper run_document_pipeline)
      - tests/** (white-box tests are allowed to inspect internals)
    """
    forbidden_symbols = {"build_topic_plan", "build_generated_topic"}
    pipeline_module_names = {
        "ditagen_common.pipeline",
        "ditagen_common",  # `import ditagen_common; ditagen_common.pipeline.build_topic_plan(...)`
    }
    allowed_path_prefixes = (
        "services/llm-gateway-service/",
        "packages/python/ditagen_common/ditagen_common/pipeline.py",
        "tests/",
    )

    violations: list[tuple[Path, int, str]] = []
    for py_file in REPO_ROOT.rglob("*.py"):
        rel = py_file.relative_to(REPO_ROOT).as_posix()
        if not (rel.startswith("services/") or rel.startswith("packages/")):
            continue
        if any(rel.startswith(allowed) for allowed in allowed_path_prefixes):
            continue
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue

        # Track aliases bound to the pipeline module so we can flag
        # attribute access through them.
        # `import ditagen_common.pipeline as p` -> alias 'p' = 'ditagen_common.pipeline'
        # `import ditagen_common.pipeline`      -> alias 'ditagen_common'
        pipeline_aliases: set[str] = set()

        for node in ast.walk(tree):
            # 1. Direct symbol import: `from ditagen_common.pipeline import build_topic_plan`
            if isinstance(node, ast.ImportFrom):
                imported_names = {alias.name for alias in node.names}
                hits = imported_names & forbidden_symbols
                for symbol in hits:
                    violations.append((py_file, node.lineno, f"from-import {symbol!r}"))

            # 2. Module import that binds an alias for later attribute access:
            #    `import ditagen_common.pipeline as p` or `import ditagen_common.pipeline`
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name in pipeline_module_names or alias.name == "ditagen_common.pipeline":
                        bound = alias.asname or alias.name.split(".", 1)[0]
                        pipeline_aliases.add(bound)

        # 3. Attribute access through any pipeline alias:
        #    `p.build_topic_plan(...)` or `ditagen_common.pipeline.build_topic_plan(...)`
        if pipeline_aliases:
            try:
                tree2 = ast.parse(py_file.read_text(encoding="utf-8"))
            except (OSError, SyntaxError):
                tree2 = None
            if tree2 is not None:
                for node in ast.walk(tree2):
                    if not isinstance(node, ast.Attribute):
                        continue
                    if node.attr not in forbidden_symbols:
                        continue
                    # Walk receiver chain to root Name. Match if root name
                    # is in pipeline_aliases.
                    receiver = node.value
                    while isinstance(receiver, ast.Attribute):
                        receiver = receiver.value
                    if isinstance(receiver, ast.Name) and receiver.id in pipeline_aliases:
                        violations.append(
                            (py_file, node.lineno, f"attr-access {receiver.id}.…{node.attr!r}")
                        )

        # 4. getattr-style escape: `getattr(pipeline, 'build_topic_plan')` —
        #    catch the literal-string form (the dynamic-string form is
        #    out of scope for static analysis but vanishingly rare).
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if not (isinstance(node.func, ast.Name) and node.func.id == "getattr"):
                continue
            if len(node.args) < 2:
                continue
            second = node.args[1]
            if isinstance(second, ast.Constant) and second.value in forbidden_symbols:
                violations.append(
                    (py_file, node.lineno, f"getattr(..., {second.value!r})")
                )

    assert not violations, (
        "Phase 4 invariant: build_topic_plan / build_generated_topic must "
        "flow through llm-gateway-service (ADR-005:32). Bypasses found:\n"
        + "\n".join(
            f"  {p.relative_to(REPO_ROOT)}:{ln} -> {kind}"
            for p, ln, kind in violations
        )
    )
