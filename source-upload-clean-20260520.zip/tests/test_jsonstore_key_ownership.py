"""Architecture lock — Phase 4 Step D0 of plans/architecture-hardening.md.

ADR-016 (`adr/016-service-owned-data-contracts.md`) defines the TARGET
per-service ownership of `JsonStore` state keys. This test pins the
CURRENT footprint — every service's set of state keys read or written
in its `main.py` — so:

  - A new cross-service read fails this test loudly (the gateway can't
    quietly start reading `topics` from a code path the audit didn't
    capture).
  - As Phase 4 D2-D6 migrate each service to its own database, the
    keys disappear from that service's allowed-set deliberately. Each
    removal is a green-bar moment.
  - The set of services that touch JsonStore at all is pinned; a new
    service that imports `JsonStore` must update this test.

Detection technique:

  - AST-walk each `services/*/app/main.py`.
  - Find every `Subscript` whose slice is a string literal that matches
    a known JsonStore top-level key.
  - The known-keys set is the union of every key any service touches
    today, pinned in `_KNOWN_KEYS` below. A new key (e.g., a future
    `notifications` table added to the JsonStore default state) must
    be added here deliberately — that's a state-shape change worth
    surfacing.

Why string-literal subscript scanning and not import scanning:

  - Several services have legitimate JsonStore imports for
    artifact-blob reads (validation-service does this) without
    touching any state key. The drift we care about is "which state
    keys does each service couple to," not "which services import
    JsonStore." Once D7 lands, the import lock takes over; until then,
    the key-level lock is the right granularity.

False-positive shape: a string literal `"projects"` used inside a
service for some unrelated purpose (e.g., a constant in an enum) would
match. We accept this as an acceptable scope of the test — the false
positive is loud and easy to whitelist; the alternative (full
dataflow analysis) is overengineered for a coverage gate.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SERVICES_DIR = ROOT / "services"

# Every top-level key the JsonStore state today exposes. Adding a new
# key here is a deliberate signal that the state shape changed.
_KNOWN_KEYS: frozenset[str] = frozenset({
    # Identity / session domain
    "users",
    "sessions",
    "revoked_tokens",
    # Tenancy / ownership domain
    "business_units",
    "projects",
    "business_unit_memberships",
    "business_unit_favorites",
    "project_memberships",
    # Document / artifact domain
    "documents",
    "upload_sessions",
    "artifact_registry",
    "exports",
    "jobs",
    # Topic / review domain
    "topics",
    "generated_topics",
    # Extraction domain
    "extractions",
    # Audit domain — already migrated to JSONL sink post-S6 but the
    # JsonStore key path may still exist transitionally.
    "audit_events",
})

# Empirical state captured at Phase 4 D0 baseline (2026-05-11). This is
# the floor: each service must touch AT MOST these keys. As Phase 4
# D2-D6 migrate a service, the keys disappear from its set (each
# removal is a deliberate green-bar moment).
#
# A service NOT listed here is asserted to touch ZERO keys — that's
# the goal state post-D7. Adding a new service to this map is a
# deliberate signal that microservice-boundary regression happened.
_EXPECTED_KEY_USAGE: dict[str, frozenset[str]] = {
    "api-gateway": frozenset({
        # `documents` removed in Phase 4 D4.4.d — api-gateway's
        # `quality_report` now delegates to upload-service via
        # `request_service`, and the dead `require_document` helper
        # (finding #64) was deleted. `projects` was removed earlier
        # in D3.6.
        "revoked_tokens",  # PAT revocation list (Phase 1 S3)
        "sessions",        # login/logout/refresh
        "topics",          # proxy convenience reads (target: review-service, D5)
        "users",           # auth + user CRUD
    }),
    "analysis-service": frozenset({
        "topics",            # writes topic plans (target: review-service, D5)
        # `generated_topics` was a false positive surfaced by the D4.4.c
        # walker tightening (per-receiver chain check). Analysis-service
        # never reads/writes `state["generated_topics"]` — the
        # references are payload keys + local variables.
    }),
    # Phase 4 D2 (D2.6) closed the last JsonStore reads from
    # audit-service. Tenant-isolation now goes through
    # `request_service("business-unit-service", GET /internal/business-units/{id})`
    # in `services/audit-service/app/main.py::_can_see_business_unit`
    # (and the project equivalent). Tightening to `frozenset()` is the
    # green-bar moment ADR-016 promised.
    "audit-service": frozenset(),
    "business-unit-service": frozenset({
        # Phase 4 D3.5.c retired the last 4 owned-collection JsonStore
        # subscripts: `business_units`, `business_unit_memberships`,
        # `projects`, `project_memberships` are now read+written only
        # via the typed SQL repos (bu_repositories.*). The
        # `business_unit_favorites` subscript fell in D3.5.b.3.
        #
        # Phase 4 D4.4.b + D4.4.c retired `documents`, `jobs`,
        # `artifact_registry`: `project_with_documents` and
        # `project_status_summary` now fetch upload-side data from
        # upload-service via `request_service` (D4.4.a endpoints).
        # Only `topics` remains — that's review-service-owned and
        # migrates in D5.
        "topics",                   # cross-service read (target: review-service)
    }),
    "extraction-service": frozenset({
        "extractions",                # writes its own status/events
        # `business_unit_memberships` removed in Phase 4 D3.5.c.0 — the
        # tenant-isolation read in `get_extraction_status` and
        # `_ensure_extraction_visible` now goes through BU service via
        # `request_service` (mirror of audit-service D2.6).
    }),
    "review-service": frozenset({
        "topics",          # aligned with target ownership
        # Surfaced by D3.5.b.1 `.get()` lock blind-spot fix (finding
        # #32): review-service reads extractions when persisting topic
        # edits. Eventually goes through extraction-service via
        # `request_service`.
        "extractions",     # cross-service read (target: extraction-service)
    }),
    "upload-service": frozenset({
        "artifact_registry",
        "exports",
        "jobs",
        # `project_memberships` removed in Phase 4 D3.7.b.
        # `projects` removed in Phase 4 D3.7.c — upload-service no longer
        # touches BU-owned state. All project lifecycle + document_ids
        # mutations delegate to BU service via request_service.
        # `upload_sessions` removed in Phase 4 D4.5.a — every read/write
        # now goes through UploadSessionRepository (SQL-authoritative).
        # `documents` removed in Phase 4 D4.5.b — every read/write now
        # goes through DocumentRepository (SQL-authoritative). The cascade
        # branches in delete_document still touch jobs/artifact_registry
        # (those collections migrate in D4.5.c/D4.5.d), and `topics` is
        # still a cross-service read.
        "topics",               # cross-service read (target: review-service)
    }),
    # validation-service imports JsonStore for artifact-blob reads only;
    # no state-key access. Tracked here as an explicit zero to lock the
    # boundary — any future state-key access fails the test.
    "validation-service": frozenset(),
}


def _service_main_paths() -> list[tuple[str, Path]]:
    pairs: list[tuple[str, Path]] = []
    for service_dir in sorted(SERVICES_DIR.iterdir()):
        if not service_dir.is_dir():
            continue
        main_py = service_dir / "app" / "main.py"
        if main_py.exists():
            pairs.append((service_dir.name, main_py))
    return pairs


def _string_subscripts_in_module(main_py: Path) -> set[str]:
    """Every JsonStore state key touched in `main_py`, via either:

      - `state["x"]` subscript form, OR
      - `state.get("x", ...)` method-call form

    The receiver chain must root at the name `state` — this excludes
    false positives like `response.json().get("documents")` or
    `project.get("document_ids")` where the literal key collides with
    a JsonStore collection name but the receiver is unrelated.

    Walker evolution (per finding history):
      - D3.5.b finding #32 closed the `.get()` blind spot — the
        original walker only caught subscript form.
      - D4.4.c (this iteration) closed the receiver-coarseness blind
        spot — the walker was conservatively flagging any
        `.get(literal)` call regardless of receiver, producing false
        positives that needed whitelisting. Now the receiver chain is
        walked back to its root Name; only `state`-rooted accesses
        count.

    The `.get` arm checks only the FIRST positional argument as the
    literal key — second arg is the default value and irrelevant
    for ownership."""
    try:
        tree = ast.parse(main_py.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return set()
    found: set[str] = set()
    for node in ast.walk(tree):
        # Subscript form: `state["x"]` — receiver chain must root at `state`.
        if isinstance(node, ast.Subscript):
            slice_node = node.slice
            if isinstance(slice_node, ast.Constant) and isinstance(
                slice_node.value, str
            ):
                value = slice_node.value
                if value in _KNOWN_KEYS and _receiver_root_is_state(node.value):
                    found.add(value)
            continue
        # .get(literal, ...) call form: `state.get("x", {})` — receiver
        # of `.get` must root at `state`.
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "get"
            and node.args
            and isinstance(node.args[0], ast.Constant)
            and isinstance(node.args[0].value, str)
        ):
            value = node.args[0].value
            if value in _KNOWN_KEYS and _receiver_root_is_state(node.func.value):
                found.add(value)
    return found


def _receiver_root_is_state(node: ast.expr) -> bool:
    """Walk an expression's receiver chain back to its root Name.

    Returns True if the root is the identifier `state` (the variable
    used by both JsonStore.read() callers and store.mutate(state→...)
    callbacks). Returns False for any other root (e.g. `response`,
    `project`, `document`, function-call results).

    Examples (True):
      state                         → Name("state")
      state["x"]                    → Subscript(Name("state"))
      state.get                     → Attribute(Name("state"))
      state["x"]["y"]               → Subscript(Subscript(Name("state")))

    Examples (False):
      response.json()               → Call(...) — Call short-circuits
      project.get                   → Attribute(Name("project"))
      response.json().get("doc")    → receiver of `.get` is Call(...)
    """
    cursor: ast.expr = node
    while True:
        if isinstance(cursor, ast.Name):
            return cursor.id == "state"
        if isinstance(cursor, ast.Subscript):
            cursor = cursor.value
            continue
        if isinstance(cursor, ast.Attribute):
            cursor = cursor.value
            continue
        # Call, BinOp, literal, anything else: not a state-rooted chain.
        return False


@pytest.mark.parametrize(
    "service_name,main_py",
    _service_main_paths(),
    ids=lambda value: value if isinstance(value, str) else "main.py",
)
def test_service_touches_only_expected_state_keys(
    service_name: str, main_py: Path
) -> None:
    """Each service's main.py reads/writes ONLY the JsonStore keys
    declared in `_EXPECTED_KEY_USAGE` for that service.

    Failure modes this guards against:
      (a) A new cross-service read appears that wasn't audited — the
          microservice boundary is silently weakening.
      (b) A service that should have completed its Phase 4 migration is
          still reading a JsonStore key — the cleanup is incomplete.
    """
    if not isinstance(main_py, Path):
        return
    actual = _string_subscripts_in_module(main_py)
    expected = _EXPECTED_KEY_USAGE.get(service_name, frozenset())

    # New cross-service access (regression):
    new_access = actual - expected
    # Keys declared expected but no longer touched (migration completed —
    # the lock should be tightened by removing the entry).
    stale_expected = expected - actual

    assert not new_access, (
        f"services/{service_name}/app/main.py touches JsonStore keys "
        f"NOT in _EXPECTED_KEY_USAGE[{service_name!r}]: {sorted(new_access)}. "
        f"This is either (a) a new cross-service read that weakens the "
        f"microservice boundary — fix the code, OR (b) a deliberate "
        f"expansion that should update this test AND ADR-016. "
        f"See adr/016-service-owned-data-contracts.md."
    )
    assert not stale_expected, (
        f"services/{service_name}/app/main.py NO LONGER touches keys "
        f"{sorted(stale_expected)} but they're still in "
        f"_EXPECTED_KEY_USAGE[{service_name!r}]. The migration progressed; "
        f"tighten the lock by removing these keys from the expected set. "
        f"This catches the floor relaxing without an explicit ADR-016 "
        f"update."
    )


def test_service_inventory_pinned() -> None:
    """Pin the set of services we track. A new service that imports
    `JsonStore` must be added to `_EXPECTED_KEY_USAGE` (or to an
    explicit `frozenset()` if it imports for artifact-blob reads only
    without touching state keys). Otherwise its cross-service reads slip
    past the per-service parametrize."""
    actual = {name for name, _ in _service_main_paths()}
    # Services with no JsonStore reference don't need to appear in the
    # expected map; the parametrize accepts them as zero-key by the
    # `_EXPECTED_KEY_USAGE.get(..., frozenset())` default. But we lock
    # the full inventory so a NEW service is a deliberate addition.
    expected = {
        "agent-runtime-service",
        "analysis-service",
        "api-gateway",
        "audit-service",
        "business-unit-service",
        "dita-service",
        "export-service",
        "extraction-service",
        "identity-service",
        "llm-gateway-service",
        "notification-service",
        "review-service",
        "upload-service",
        "validation-service",
    }
    assert actual == expected, (
        f"Service inventory drift. Expected {sorted(expected)}, got "
        f"{sorted(actual)}. Update this test deliberately and decide "
        f"the new service's JsonStore allowed-set in "
        f"_EXPECTED_KEY_USAGE (most likely frozenset() if the service "
        f"shouldn't touch shared state at all)."
    )


def test_known_keys_inventory_pinned() -> None:
    """Lock the set of JsonStore top-level keys we know about. A change
    to the state schema (new top-level table) must update this test
    AND ADR-016 deliberately — silent state-shape growth is exactly
    the failure mode Phase 4 is trying to eliminate."""
    # Every key declared as expected for at least one service must be a
    # known key. Catches typos in _EXPECTED_KEY_USAGE.
    declared_keys: set[str] = set()
    for keys in _EXPECTED_KEY_USAGE.values():
        declared_keys |= keys
    unknown_declared = declared_keys - _KNOWN_KEYS
    assert not unknown_declared, (
        f"Keys declared in _EXPECTED_KEY_USAGE but not in _KNOWN_KEYS: "
        f"{sorted(unknown_declared)}. Either add to _KNOWN_KEYS (deliberate "
        f"state-shape signal) or fix the typo."
    )
