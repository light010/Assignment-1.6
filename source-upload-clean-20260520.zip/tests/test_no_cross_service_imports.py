"""Architecture lock — Phase 2 B2 of plans/architecture-hardening.md.

A service's `app/main.py` may NOT directly import another service's
`app/` modules. Cross-service code reuse must flow through:

  (a) `ditagen_common` — the shared library kernel, OR
  (b) HTTP via `request_service(...)` — the proper RPC boundary.

A direct `from services.upload_service.app.main import X` (or any
similar shape) would:

  - Couple the importing service to the importee's source tree (the
    monorepo benefit becomes a code-share trap).
  - Bypass the network/auth/observability surface that
    `request_service` provides.
  - Make independent deployment impossible — service X cannot ship
    without service Y's source.

This test AST-walks every `services/*/app/main.py` and flags any
`import` / `from ... import` that resolves to a peer service's path.

Legitimate exceptions (none today; whitelist is empty by design):

  - A future "auth-library" cross-import would belong in
    `ditagen_common`, not in another service.
  - Test files in `tests/` legitimately load multiple services'
    `app/main.py` for cross-service integration coverage — those are
    `conftest.py` / `service_app_factory` patterns, NOT production
    code. This test only audits production `services/` source.

The pattern this test guards against: H0-class boundary leaks
(milestone Step H found three upload-service routes were never exposed
by the gateway). The same drift can happen in reverse — a service
quietly importing another's helpers — and the architecture invariant
that "services are independent processes" silently degrades.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SERVICES_DIR = ROOT / "services"

# Whitelist of (importing_service, imported_module_prefix) pairs that are
# legitimate cross-service imports. Empty today; future entries must
# include a documented reason in the comment above the entry.
_ALLOWED_CROSS_SERVICE_IMPORTS: frozenset[tuple[str, str]] = frozenset()


def _service_main_paths() -> list[tuple[str, Path]]:
    """Return (service_name, path-to-main.py) for every service with a
    populated app/main.py. Skips ghost services (their absence of
    routes is the concern of `test_no_ghost_services.py`)."""
    pairs: list[tuple[str, Path]] = []
    for service_dir in sorted(SERVICES_DIR.iterdir()):
        if not service_dir.is_dir():
            continue
        main_py = service_dir / "app" / "main.py"
        if not main_py.exists():
            continue
        pairs.append((service_dir.name, main_py))
    return pairs


def _collect_imports(main_py: Path) -> list[str]:
    """Return every dotted import target in `main_py` as a string.

    Examples:
      `import httpx` -> `"httpx"`
      `from fastapi import FastAPI` -> `"fastapi"`
      `from ditagen_common.auth import current_user` -> `"ditagen_common.auth"`
      `from services.upload_service.app.main import X` -> `"services.upload_service.app.main"`
    """
    try:
        tree = ast.parse(main_py.read_text())
    except (OSError, SyntaxError):
        return []
    targets: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                targets.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            # `from X import Y` — `node.module` is X
            if node.module:
                targets.append(node.module)
    return targets


def _peer_service_name(target: str, this_service: str) -> str | None:
    """Return the peer service name if `target` imports from a peer's
    `services/*/app/` tree, else None.

    Detection heuristic: any import that starts with `services.` (the
    monorepo's root) AND names a directory under `services/` that
    isn't the current service. We also catch the `app.main` /
    `app.foo` shapes that would arise if a service's tree were on
    sys.path under its own name (e.g., `extraction-service` puts its
    `app/` on the path so it imports `extractors`, `contracts`, etc.
    — those are fine because they're INTERNAL to that service).
    """
    if not target.startswith("services."):
        return None
    parts = target.split(".")
    if len(parts) < 2:
        return None
    # `services.foo-service` → `foo-service`
    peer_dir = parts[1].replace("_", "-")
    if peer_dir == this_service:
        return None
    if not (SERVICES_DIR / peer_dir).is_dir():
        # Reference to a non-existent service — flagged but not as a
        # cross-import (likely a typo or stale code).
        return None
    return peer_dir


@pytest.mark.parametrize(
    "service_name,main_py",
    _service_main_paths(),
    ids=lambda value: value if isinstance(value, str) else "main.py",
)
def test_service_main_has_no_cross_service_imports(service_name: str, main_py: Path) -> None:
    """Every service's main.py imports from `ditagen_common`, third-party
    libs, or its own internal modules — NEVER from a peer service's
    source tree."""
    if not isinstance(main_py, Path):
        # When the second parametrize id collapses to "main.py" via the
        # id callable, the actual Path comes through anyway via param
        # binding. Pytest passes both correctly; the lambda is just for
        # readable test names.
        return
    imports = _collect_imports(main_py)
    violations: list[tuple[str, str]] = []
    for target in imports:
        peer = _peer_service_name(target, service_name)
        if peer is None:
            continue
        if (service_name, peer) in _ALLOWED_CROSS_SERVICE_IMPORTS:
            continue
        violations.append((target, peer))

    assert not violations, (
        f"services/{service_name}/app/main.py imports from peer services: "
        + ", ".join(f"{target} (peer: {peer})" for target, peer in violations)
        + ". Cross-service code reuse must flow through `ditagen_common` "
        "(shared kernel) OR `request_service(...)` (HTTP). Direct source "
        "imports break the microservice boundary."
    )


def test_service_inventory_pinned() -> None:
    """Pin the set of services with populated main.py files so a silent
    addition can't slip past the cross-import check. When a new
    service is added, append it to the expected list in the same
    commit."""
    actual = {name for name, _ in _service_main_paths()}
    expected = {
        "agent-runtime-service",
        "analysis-service",
        "api-gateway",
        "audit-service",
        "business-unit-service",
        "dita-service",
        "export-service",
        "extraction-service",
        "identity-service",
        "llm-gateway-service",
        "notification-service",
        "review-service",
        "upload-service",
        "validation-service",
    }
    assert actual == expected, (
        f"Service inventory drift. Expected {sorted(expected)}, got "
        f"{sorted(actual)}. Update this test deliberately when adding "
        f"or removing services."
    )
