"""Regression: the extraction-service producer emits blocks that validate
against `contracts/artifacts/source-block.schema.json`.

Phase 2b of `plans/logical-whistling-widget.md`: with the producer
flipped to construct typed `Block` instances and the schema tightened to
`additionalProperties: false`, every block produced by the alpha
pipeline must validate. If a future producer change introduces an
unmapped field or violates the schema's constraints, this test catches
it at gate time.

Two fixtures cover the two real producers: a layered DOCX (3 tables
interleaved with paragraphs, plus a Heading-styled cell paragraph) and
a multi-page PDF.
"""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
from ditagen_common.artifacts import read_artifact_text
from fastapi.testclient import TestClient

# Reuse the helpers in test_week3_extraction so this test exercises the
# real producer, not a hand-built block sample. tests/ isn't a Python
# package (no __init__.py), so we go through sys.path: pytest collects
# from `testpaths = ["tests"]` which puts that directory on sys.path.
from test_week3_extraction import (  # noqa: E402 - depends on sys.path adjustment
    auth_headers,
    create_layered_docx_fixture,
    create_pdf_fixture,
    extraction_payload,
    load_app,
    refs_by_name,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = REPO_ROOT / "contracts" / "artifacts" / "source-block.schema.json"


def _load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _post_extraction_and_get_blocks(
    *, client: TestClient, document_id: str, filename: str, content_type: str, content: bytes
) -> list[dict]:
    payload = extraction_payload(
        document_id=document_id,
        filename=filename,
        content_type=content_type,
        content=content,
    )
    response = client.post("/internal/extractions", json=payload, headers=auth_headers())
    assert response.status_code == 200, response.text
    refs = refs_by_name(response.json())
    return [
        json.loads(line)
        for line in read_artifact_text(refs["source-blocks.jsonl"]).splitlines()
        if line.strip()
    ]


def test_layered_docx_blocks_validate_against_schema(tmp_path, monkeypatch) -> None:
    """Every block produced from the layered DOCX fixture validates."""
    app, _module = load_app(
        "services/extraction-service/app/main.py",
        "extraction_schema_compliance_docx",
        tmp_path,
        monkeypatch,
    )
    blocks = _post_extraction_and_get_blocks(
        client=TestClient(app),
        document_id="doc_schema_compliance_docx",
        filename="layered.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        content=create_layered_docx_fixture(tmp_path),
    )
    assert blocks, "extraction produced zero blocks — fixture or producer regression"

    schema = _load_schema()
    validator = jsonschema.Draft202012Validator(schema)
    failures: list[str] = []
    for block in blocks:
        errors = list(validator.iter_errors(block))
        if errors:
            failures.append(
                f"block {block.get('block_id')!r} ({block.get('block_type')}): "
                + "; ".join(f"{list(e.absolute_path)}: {e.message}" for e in errors)
            )
    assert not failures, "schema violations:\n" + "\n".join(failures)


def test_pdf_blocks_validate_against_schema(tmp_path, monkeypatch) -> None:
    """Every block produced from the PDF fixture validates."""
    app, _module = load_app(
        "services/extraction-service/app/main.py",
        "extraction_schema_compliance_pdf",
        tmp_path,
        monkeypatch,
    )
    blocks = _post_extraction_and_get_blocks(
        client=TestClient(app),
        document_id="doc_schema_compliance_pdf",
        filename="source.pdf",
        content_type="application/pdf",
        content=create_pdf_fixture(),
    )
    assert blocks, "extraction produced zero blocks — fixture or producer regression"

    schema = _load_schema()
    validator = jsonschema.Draft202012Validator(schema)
    failures: list[str] = []
    for block in blocks:
        errors = list(validator.iter_errors(block))
        if errors:
            failures.append(
                f"block {block.get('block_id')!r} ({block.get('block_type')}): "
                + "; ".join(f"{list(e.absolute_path)}: {e.message}" for e in errors)
            )
    assert not failures, "schema violations:\n" + "\n".join(failures)


def test_optional_object_fields_uniformly_accept_null() -> None:
    """Lock the uniform nullability invariant for every optional-object field.

    Phase 2b's insight claimed the schema is "uniformly nullable for
    optional objects." That claim was loose: at the time, `style_summary`
    and `confidence_signals` were still `"type": "object"` (non-null) even
    though their Pydantic counterparts default to None. The producer
    happened to always populate them, masking the latent bug — Phase 6's
    edit-op replay will produce derived blocks that legitimately can't
    inherit a single source paragraph's style or confidence signals.

    This test constructs a Block where every optional-object field is None,
    serializes it, and asserts the schema accepts it. If anyone re-tightens
    a field to `"type": "object"` (non-null) in the future, this fails.
    """
    from ditagen_common.models import Block, Confidence, SourceLocation

    block = Block(
        block_id="blk_uniform_null_test",
        document_id="doc_uniform",
        block_type="paragraph",
        text="Derived block with no inherited style.",
        source_location=SourceLocation(page=1),
        confidence=Confidence(extraction=0.85),
        # Every optional-object field explicitly None:
        style_summary=None,
        repetition=None,
        font=None,
        confidence_signals=None,
        numbering=None,
    )
    dumped = block.model_dump(mode="json")
    # Sanity: the fields are dumped as JSON null, not omitted.
    for field in ("style_summary", "repetition", "font", "confidence_signals", "numbering"):
        assert field in dumped and dumped[field] is None, (
            f"expected {field} dumped as JSON null; got {dumped.get(field)!r}"
        )

    schema = _load_schema()
    validator = jsonschema.Draft202012Validator(schema)
    errors = list(validator.iter_errors(dumped))
    assert not errors, (
        "Block with all-None optional objects must validate against schema. "
        "Violations: " + "; ".join(f"{list(e.absolute_path)}: {e.message}" for e in errors)
    )


def test_dropped_alias_fields_are_absent_from_blocks(tmp_path, monkeypatch) -> None:
    """Phase 2b drops `id`, `type`, `page`, top-level `bbox` aliases.

    Locks the absence: any future producer change that re-introduces them
    fails this test. Frontend uses canonical (`block_id`, `block_type`,
    `source_location.page`, `source_location.bbox`) so the alias drop is
    a true cleanup.
    """
    app, _module = load_app(
        "services/extraction-service/app/main.py",
        "extraction_alias_drop_check",
        tmp_path,
        monkeypatch,
    )
    blocks = _post_extraction_and_get_blocks(
        client=TestClient(app),
        document_id="doc_alias_drop_check",
        filename="layered.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        content=create_layered_docx_fixture(tmp_path),
    )
    for block in blocks:
        for dropped_alias in ("id", "type", "page", "bbox"):
            assert dropped_alias not in block, (
                f"block {block.get('block_id')!r} still carries dropped alias "
                f"{dropped_alias!r}; Phase 2b regression"
            )
