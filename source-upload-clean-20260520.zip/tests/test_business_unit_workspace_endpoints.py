"""Phase 4 D3.7.a — workspace-project + document_ids endpoint locks.

These exercise the 3 new BU service endpoints that absorb the
upload-service boundary leak (plan §D3 findings #1 + #2):

  1. POST /internal/business-units/{bu_id}/auto-provision-workspace-project
  2. POST /internal/projects/{project_id}/documents
  3. DELETE /internal/projects/{project_id}/documents/{document_id}

Invariants pinned:

  - auto-provision is idempotent: second call returns the same project
    (either the system-managed workspace, or any other accessible
    project in the BU).
  - auto-provision creates a `system_managed=True` project named
    "Documents" + a project_admin membership for the caller when no
    accessible project exists yet.
  - append is idempotent on document_id (no duplicates, no
    `updated_at` bump when already present).
  - remove is idempotent (no-op for absent document_id).
  - Both append + remove write directly to SQL via the production
    ProjectRepository (verified by reading the project back through the
    same repo). Pre-D3.5.c this went through the D3.3 dual-write helper;
    D3.5.c retired the bridge so writes now hit SQL only.
  - 404 for missing project on append/remove (via require_project).
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any

import pytest
from ditagen_common.security import issue_token
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_APP_DIR = REPO_ROOT / "services" / "business-unit-service" / "app"
if str(SERVICE_APP_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_APP_DIR))


def _auth_headers(user_id: str = "usr_admin") -> dict[str, str]:
    token = issue_token(
        {
            "sub": user_id,
            "tenant_id": "ten_local",
            "org_id": "org_local",
            "session_id": "sess_d3_7",
        }
    )
    return {"Authorization": f"Bearer {token}", "X-Request-ID": "req_d3_7"}


@pytest.fixture
def bu_service(tmp_path, monkeypatch):
    monkeypatch.setenv("DITAGEN_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("DITAGEN_INPROCESS_SERVICES", "1")
    monkeypatch.setenv(
        "DITAGEN_BUSINESS_UNIT_SERVICE_URL", "http://business-unit-service:8000"
    )
    monkeypatch.setenv("DITAGEN_AUDIT_SERVICE_URL", "http://audit-service:8000")

    from bu_db import reset_engine_cache

    reset_engine_cache()

    module_path = REPO_ROOT / "services" / "business-unit-service" / "app" / "main.py"
    full_module_name = f"bu_service_d3_7_{abs(hash(str(tmp_path)))}"
    spec = importlib.util.spec_from_file_location(full_module_name, module_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[full_module_name] = module
    spec.loader.exec_module(module)
    return TestClient(module.app)


def _sql_project(project_id: str) -> dict[str, Any] | None:
    from bu_repositories import ProjectRepository

    return ProjectRepository().get(project_id)


def test_auto_provision_creates_system_managed_workspace_on_empty_bu(
    bu_service,
) -> None:
    """First caller in a BU with no projects gets a fresh
    system_managed=True workspace, plus a project_admin membership."""
    response = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    project = response.json()
    assert project["business_unit_id"] == "bu_docs_ops"
    assert project["name"] == "Documents"
    assert project["system_managed"] is True
    assert project["status"] == "active"
    assert project["document_ids"] == []


def test_auto_provision_is_idempotent_for_same_caller(bu_service) -> None:
    """Second call from the same caller MUST return the same project
    id — upload-service relies on this when an upload retries after a
    transient failure."""
    first = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    second = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()["project_id"] == second.json()["project_id"]


def test_auto_provision_reuses_existing_accessible_project(bu_service) -> None:
    """If the caller already has access to a hand-created project in
    this BU, auto-provision returns it (preserves pre-D3.7 behavior
    where uploads land in the user's existing project, not a separate
    system workspace)."""
    hand_created = bu_service.post(
        "/internal/projects",
        json={"business_unit_id": "bu_docs_ops", "name": "Hand-Created"},
        headers=_auth_headers(),
    )
    assert hand_created.status_code == 200
    hand_project_id = hand_created.json()["project_id"]

    workspace = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    assert workspace.status_code == 200
    assert workspace.json()["project_id"] == hand_project_id
    # The hand-created project is NOT system_managed; the wire shape
    # must reflect that (no spurious `system_managed: False`).
    assert "system_managed" not in workspace.json()


def test_auto_provision_mirrors_to_sql(bu_service) -> None:
    response = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    project_id = response.json()["project_id"]
    sql_row = _sql_project(project_id)
    assert sql_row is not None
    assert sql_row["system_managed"] is True
    assert sql_row["business_unit_id"] == "bu_docs_ops"


def test_append_document_appends_and_mirrors(bu_service) -> None:
    workspace = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    project_id = workspace.json()["project_id"]

    response = bu_service.post(
        f"/internal/projects/{project_id}/documents",
        json={"document_id": "doc_alpha"},
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    assert response.json()["document_ids"] == ["doc_alpha"]
    sql_row = _sql_project(project_id)
    assert sql_row is not None
    assert sql_row["document_ids"] == ["doc_alpha"]


def test_append_document_is_idempotent(bu_service) -> None:
    workspace = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    project_id = workspace.json()["project_id"]

    for _ in range(3):
        response = bu_service.post(
            f"/internal/projects/{project_id}/documents",
            json={"document_id": "doc_same"},
            headers=_auth_headers(),
        )
        assert response.status_code == 200

    final = bu_service.post(
        f"/internal/projects/{project_id}/documents",
        json={"document_id": "doc_other"},
        headers=_auth_headers(),
    )
    assert final.json()["document_ids"] == ["doc_same", "doc_other"]


def test_append_document_returns_404_for_missing_project(bu_service) -> None:
    response = bu_service.post(
        "/internal/projects/prj_does_not_exist/documents",
        json={"document_id": "doc_x"},
        headers=_auth_headers(),
    )
    assert response.status_code == 404


def test_remove_document_removes_and_mirrors(bu_service) -> None:
    workspace = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    project_id = workspace.json()["project_id"]

    bu_service.post(
        f"/internal/projects/{project_id}/documents",
        json={"document_id": "doc_keep"},
        headers=_auth_headers(),
    )
    bu_service.post(
        f"/internal/projects/{project_id}/documents",
        json={"document_id": "doc_drop"},
        headers=_auth_headers(),
    )

    response = bu_service.delete(
        f"/internal/projects/{project_id}/documents/doc_drop",
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    assert response.json()["document_ids"] == ["doc_keep"]
    sql_row = _sql_project(project_id)
    assert sql_row is not None
    assert sql_row["document_ids"] == ["doc_keep"]


def test_remove_document_is_idempotent_when_absent(bu_service) -> None:
    workspace = bu_service.post(
        "/internal/business-units/bu_docs_ops/auto-provision-workspace-project",
        headers=_auth_headers(),
    )
    project_id = workspace.json()["project_id"]

    response = bu_service.delete(
        f"/internal/projects/{project_id}/documents/doc_was_never_added",
        headers=_auth_headers(),
    )
    assert response.status_code == 200
    assert response.json()["document_ids"] == []
