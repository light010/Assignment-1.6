import { WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";
import { EvidenceNumber, NextAction, TopicAttentionSummary } from "./workbenchSelectors";

export type ActionCopy = {
  label: string;
  detail: string;
  tone: "danger" | "warning" | "review" | "success" | "neutral";
};

export function nextActionCopy(action: NextAction): ActionCopy {
  if (action.kind === "review_validation") {
    return { label: "Review validation", detail: action.reason, tone: "danger" };
  }
  if (action.kind === "resolve_stale") {
    return { label: "Resolve stale validation", detail: action.reason, tone: "warning" };
  }
  if (action.kind === "review_attention") {
    return { label: "Review attention", detail: action.reason, tone: "review" };
  }
  if (action.kind === "mark_reviewed") {
    return { label: "Mark reviewed", detail: action.reason, tone: "success" };
  }
  if (action.kind === "advance_topic") {
    return { label: "Next topic", detail: action.reason, tone: "neutral" };
  }
  return { label: "No action", detail: action.reason, tone: "neutral" };
}

export function draftStateLabel(
  topic: WorkbenchTopic,
  hasLocalDraft: boolean,
  summary?: TopicAttentionSummary | null,
) {
  if (topic.validation_stale || summary?.staleCount) return "Validation stale";
  if (hasLocalDraft) return "Unsaved local draft";
  if (summary?.errorCount) return `${summary.errorCount} validation issue${summary.errorCount === 1 ? "" : "s"}`;
  return "Clean";
}

export function evidenceNumbersForUnit(unit: WorkbenchUnit, evidenceNumbers: EvidenceNumber[]) {
  const byBlock = new Map(evidenceNumbers.map((item) => [item.source_block_id, item.evidence_number] as const));
  return [...new Set(unit.source_block_ids.flatMap((blockId) => {
    const number = byBlock.get(blockId);
    return number ? [number] : [];
  }))].sort((left, right) => left - right);
}

export function topicChipLabel({
  title,
  index,
  total,
  severity,
  reviewed,
}: {
  title: string;
  index: number;
  total: number;
  severity: TopicAttentionSummary["severity"];
  reviewed: boolean;
}) {
  const status = severity === "clean" ? "clean" : `needs ${severity} attention`;
  return `Topic ${index} of ${total}: ${title}, ${status}${reviewed ? ", reviewed" : ""}`;
}
