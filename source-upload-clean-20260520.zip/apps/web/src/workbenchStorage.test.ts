import { describe, expect, it } from "vitest";
import {
  emptyWorkbenchStorageEnvelope,
  migrateWorkbenchStorageValue,
  parseWorkbenchStorageValue,
  serializeWorkbenchStorage,
} from "./workbenchStorage";
import { WorkbenchOp } from "./workbenchModel";

const op: WorkbenchOp = {
  kind: "rename_topic",
  op_id: "op_1",
  topic_id: "topic_1",
  title: "New title",
};

describe("workbenchStorage", () => {
  it("migrates legacy raw op arrays into a versioned envelope", () => {
    const envelope = parseWorkbenchStorageValue(JSON.stringify([op]));

    expect(envelope.version).toBe(1);
    expect(envelope.ops).toEqual([op]);
    expect(envelope.reviewed).toEqual({});
    expect(envelope.ui).toEqual({});
  });

  it("round-trips the versioned envelope", () => {
    const envelope = {
      ...emptyWorkbenchStorageEnvelope(),
      ops: [op],
      reviewed: { topic_1: { reviewed_at: "2026-05-09T12:00:00.000Z", hash: "abc" } },
      ui: { selected_topic_id: "topic_1", attention_filter: "stale" as const },
    };

    expect(parseWorkbenchStorageValue(serializeWorkbenchStorage(envelope))).toEqual(envelope);
  });

  it("falls back to an empty envelope for corrupt or unsupported data", () => {
    expect(parseWorkbenchStorageValue("{")).toEqual(emptyWorkbenchStorageEnvelope());
    expect(migrateWorkbenchStorageValue({ version: 999, ops: [op] })).toEqual(emptyWorkbenchStorageEnvelope());
  });

  it("writes only the versioned shape", () => {
    const serialized = serializeWorkbenchStorage({ ...emptyWorkbenchStorageEnvelope(), ops: [op] });

    expect(JSON.parse(serialized)).toEqual({
      version: 1,
      ops: [op],
      reviewed: {},
      ui: {},
    });
  });
});
