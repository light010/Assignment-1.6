import { MutableRefObject, RefObject, useCallback, useLayoutEffect, useRef, useState } from "react";
import { EvidenceNumber } from "./workbenchSelectors";
import {
  buildNumberedAnchors,
  GeometryRect,
  NumberedAnchor,
} from "./workbenchGeometry";

export function useNumberedAnchors({
  overlayRef,
  sourceRefs,
  unitRefs,
  unitSourceIds,
  evidenceNumbers,
  geometryVersion = 0,
}: {
  overlayRef: RefObject<HTMLElement | null>;
  sourceRefs: MutableRefObject<Map<string, HTMLElement>>;
  unitRefs: MutableRefObject<Map<string, HTMLElement>>;
  unitSourceIds: Map<string, string[]>;
  evidenceNumbers: EvidenceNumber[];
  geometryVersion?: number;
}) {
  const [anchors, setAnchors] = useState<NumberedAnchor[]>([]);
  const frameRef = useRef<number | null>(null);

  const recompute = useCallback(() => {
    const overlay = overlayRef.current;
    if (!overlay || evidenceNumbers.length === 0) {
      setAnchors((current) => (current.length ? [] : current));
      return;
    }
    const overlayRect = overlay.getBoundingClientRect();
    const sourceRects = new Map<string, GeometryRect>();
    const unitRects = new Map<string, GeometryRect>();
    sourceRefs.current.forEach((element, id) => sourceRects.set(id, element.getBoundingClientRect()));
    unitRefs.current.forEach((element, id) => unitRects.set(id, element.getBoundingClientRect()));
    const next = buildNumberedAnchors({ sourceRects, unitRects, unitSourceIds, evidenceNumbers, overlayRect });
    setAnchors((current) => (numberedAnchorsEqual(current, next) ? current : next));
  }, [evidenceNumbers, geometryVersion, overlayRef, sourceRefs, unitRefs, unitSourceIds]);

  const schedule = useCallback(() => {
    if (frameRef.current !== null) return;
    frameRef.current = window.requestAnimationFrame(() => {
      frameRef.current = null;
      recompute();
    });
  }, [recompute]);

  useLayoutEffect(() => {
    schedule();
    const observer = new ResizeObserver(schedule);
    if (overlayRef.current) observer.observe(overlayRef.current);
    window.addEventListener("resize", schedule);
    window.addEventListener("scroll", schedule, true);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", schedule);
      window.removeEventListener("scroll", schedule, true);
      if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    };
  }, [overlayRef, schedule]);

  return anchors;
}

function numberedAnchorsEqual(left: NumberedAnchor[], right: NumberedAnchor[]) {
  if (left.length !== right.length) return false;
  return left.every((item, index) => {
    const other = right[index];
    return other
      && item.id === other.id
      && item.evidenceNumber === other.evidenceNumber
      && item.side === other.side
      && item.point.x === other.point.x
      && item.point.y === other.point.y;
  });
}
