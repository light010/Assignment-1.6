import { describe, expect, it } from "vitest";
import cases from "../../../tests/golden/locator-cases.json";
import {
  LOCATOR_PATTERN_STRING,
  formatDocxEndnoteLocator,
  formatDocxFooterLocator,
  formatDocxFootnoteLocator,
  formatDocxHeaderLocator,
  formatDocxNestedTableRowLocator,
  formatDocxParagraphLocator,
  formatDocxTableRowLocator,
  formatPdfBboxLocator,
  parseLocator,
} from "./locator";

describe("locator grammar", () => {
  it("parses the shared locator fixture", () => {
    for (const item of cases) {
      const parsed = parseLocator(item.locator);
      expect(parsed?.kind).toBe(item.kind);
    }
  });

  it("formats common DOCX locators", () => {
    expect(formatDocxParagraphLocator(0)).toBe("docx:p:0");
    expect(formatDocxTableRowLocator(3, 1)).toBe("docx:tbl:3:r:1");
  });

  it("rejects malformed locators", () => {
    expect(parseLocator("docx:p:-1")).toBeNull();
    expect(parseLocator("docx:tbl:1")).toBeNull();
    expect(parseLocator("docx:hdr:bad section:p:0")).toBeNull();
  });
});

describe("locator unified pattern (I2)", () => {
  it("exports a shared pattern string consumable by RegExp", () => {
    const re = new RegExp(LOCATOR_PATTERN_STRING);
    expect(re.test("docx:p:0")).toBe(true);
    expect(re.test("docx:tbl:3:r:1")).toBe(true);
    expect(re.test("docx:tbl:0:r:1:tbl:0:r:1")).toBe(true);
    expect(re.test("docx:hdr:section-0:p:0")).toBe(true);
    expect(re.test("docx:ftr:section_a.1:p:7")).toBe(true);
    expect(re.test("docx:footnote:1")).toBe(true);
    expect(re.test("docx:endnote:1")).toBe(true);
    expect(re.test("pdf:p:1:bbox:0:0:0:0")).toBe(true);
  });

  it("rejects pdf:p:0 (audit I-audit-3 lock)", () => {
    expect(parseLocator("pdf:p:0:bbox:0:0:0:0")).toBeNull();
  });

  it("rejects scientific-notation bbox (audit I-audit-4 lock)", () => {
    expect(parseLocator("pdf:p:1:bbox:1e-06:0:0:0")).toBeNull();
  });
});

describe("locator TS formatter completeness (I5)", () => {
  // Each formatter MUST produce a string byte-identical to its Python
  // counterpart given the same inputs. The Python side has its own
  // round-trip tests; this suite locks the TS side's outputs against
  // the documented locator grammar.

  it("formatDocxNestedTableRowLocator", () => {
    expect(formatDocxNestedTableRowLocator(3, 1, 0, 2)).toBe("docx:tbl:3:r:1:tbl:0:r:2");
    expect(() => formatDocxNestedTableRowLocator(-1, 0, 0, 0)).toThrow();
  });

  it("formatDocxHeaderLocator", () => {
    expect(formatDocxHeaderLocator("section-0", 0)).toBe("docx:hdr:section-0:p:0");
    expect(formatDocxHeaderLocator("section_a.1", 7)).toBe("docx:hdr:section_a.1:p:7");
    expect(() => formatDocxHeaderLocator("bad section", 0)).toThrow();
    expect(() => formatDocxHeaderLocator("section-0", -1)).toThrow();
  });

  it("formatDocxFooterLocator", () => {
    expect(formatDocxFooterLocator("section_2", 4)).toBe("docx:ftr:section_2:p:4");
    expect(() => formatDocxFooterLocator("", 0)).toThrow();
  });

  it("formatDocxFootnoteLocator", () => {
    expect(formatDocxFootnoteLocator(1)).toBe("docx:footnote:1");
    expect(() => formatDocxFootnoteLocator(-1)).toThrow();
  });

  it("formatDocxEndnoteLocator", () => {
    expect(formatDocxEndnoteLocator(5)).toBe("docx:endnote:5");
  });

  it("formatPdfBboxLocator: never emits scientific notation", () => {
    expect(formatPdfBboxLocator(1, 0, 0, 0, 0)).toBe("pdf:p:1:bbox:0:0:0:0");
    expect(formatPdfBboxLocator(42, 12.5, 340.25, 200, 600)).toBe(
      "pdf:p:42:bbox:12.5:340.25:200:600",
    );
    // Audit I-audit-4: tiny floats would render as `1e-06` under naive
    // formatting; the helper strips to fixed-point.
    const tiny = formatPdfBboxLocator(1, 1e-6, 0, 0, 0);
    expect(tiny.toLowerCase()).not.toContain("e");
    // Must still round-trip through the regex.
    expect(parseLocator(tiny)).not.toBeNull();
  });

  it("formatPdfBboxLocator: rejects page < 1 (audit I-audit-3 lock)", () => {
    expect(() => formatPdfBboxLocator(0, 0, 0, 0, 0)).toThrow();
  });
});
