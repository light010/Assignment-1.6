import { describe, expect, it } from "vitest";
import schema from "../../../contracts/artifacts/source-block.schema.json";
import { REVIEW_FLAG_LABELS, reviewFlagLabel } from "./reviewFlagLabels";

describe("reviewFlagLabel", () => {
  it("returns catalog labels and actions for known review flags", () => {
    expect(reviewFlagLabel("LOW_BLOCK_TYPE_CONFIDENCE")?.label).toBe("Low block type confidence");
    expect(reviewFlagLabel("LOW_BLOCK_TYPE_CONFIDENCE")?.action).toContain("Compare the row");
    expect(reviewFlagLabel("ASSET_REF_UNRESOLVED")?.severity).toBe("error");
  });

  it("returns null for unknown review flags", () => {
    expect(reviewFlagLabel("LINK_HREF_MISSING")).toBeNull();
  });

  it("covers every enum value in the source-block schema", () => {
    const enumValues: string[] = (schema as {
      $defs: { reviewFlag: { properties: { code: { enum: string[] } } } };
    }).$defs.reviewFlag.properties.code.enum;
    const labeled = new Set(Object.keys(REVIEW_FLAG_LABELS));
    const missing = enumValues.filter((value) => !labeled.has(value));
    const extra = Object.keys(REVIEW_FLAG_LABELS).filter((value) => !enumValues.includes(value));
    expect(missing).toEqual([]);
    expect(extra).toEqual([]);
  });
});
