# Workbench Architecture

The Workbench is the primary human review surface for terminal reviewable
documents. It is frontend-only for this pass: local edits are replayed from
sessionStorage and are not submitted to backend services.

## Component Map

- `WorkbenchPanel.tsx`: orchestration, data loading, selected topic/unit state,
  op commit, undo/redo, keyboard routing, and storage sync.
- `SourceEvidenceViewer.tsx`: original-source rendering boundary for DOCX,
  PDF, text, markdown, HTML, and unsupported files. It overlays extraction
  anchors but never reconstructs missing source content.
- `WorkbenchExtractedPane.tsx`: right-pane composition.
- `Cockpit.tsx`: sticky current-topic guidance, rename/type controls,
  progress, next action, and topic navigation.
- `TopicFilmstrip.tsx`: horizontal topic navigation with severity and reviewed
  state.
- `EvidenceTimeline.tsx`: numbered extracted-unit rows and contextual edit
  actions.
- `SourceSpotlight.tsx`: SVG/overlay marker layer for source/extracted
  geometry. Source DOM anchors also receive classes for inline markers.
- `UnlocatedEvidenceStrip.tsx`: honest reporting for evidence anchors that
  cannot be located in the original viewer.

## Pure Model And Selectors

- `workbenchModel.ts`: immutable baseline state and replayable edit ops.
- `workbenchSelectors.ts`: severity, filtering, default topic selection,
  next-action policy, source-order evidence numbering, and reviewed-state
  invalidation.
- `workbenchViewModel.ts`: small display helpers for cockpit, filmstrip, and
  timeline copy.

## Geometry Hooks

- `useRefMap.ts`: tracked ref maps for rendered source and unit anchors.
- `useRelationshipConnectors.ts`: SVG connector path geometry.
- `useNumberedAnchors.ts`: numbered source/extracted anchor geometry.
- `useSpotlightGeometry.ts`: stacked source spotlight rectangles.
- `useEvidenceScroller.ts`: format-aware source scrolling; PDF targets route
  through page navigation before scrolling.

## Storage Envelope

`workbenchStorage.ts` owns all sessionStorage access.

Version 1:

- `version: 1`
- `ops: WorkbenchOp[]`
- `reviewed: Record<topicId, { reviewed_at: string; hash: string }>`
- `ui: { selected_topic_id?: string; attention_filter?: AttentionFilter }`

Legacy raw `WorkbenchOp[]` drafts are read and migrated in memory. Writes only
use the versioned envelope. Corrupt data and unknown versions fall back to an
empty draft.

## Known Boundaries

- Deterministic topic planning remains a fidelity ceiling.
- Source-file URLs still carry an `access_token`; this follows the current app
  pattern but should become cookie/header auth or short-lived signed URLs.
- Backend edit-op persistence and DITA regeneration are deferred.
