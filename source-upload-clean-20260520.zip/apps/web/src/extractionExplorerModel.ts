import { QualityGate, SourceBlock } from "./api";
import { plural } from "./formatters";
import { reviewFlagLabel } from "./reviewFlagLabels";
import { normalizeSourceText } from "./sourceViewerModel";

export type ExtractionNodeKind =
  | "document"
  | "heading"
  | "paragraph"
  | "note"
  | "list_item"
  | "procedure_step"
  | "table"
  | "table_row"
  | "resource"
  | "unlocated";

export type ExtractionAttentionSignal = {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
  label?: string;
  explanation?: string;
  action?: string;
};

export type ExtractionNode = {
  id: string;
  parentId?: string;
  kind: ExtractionNodeKind;
  label: string;
  sourceBlockIds: string[];
  locator?: string | null;
  blockType?: string;
  headingPath: string[];
  depth: number;
  children: ExtractionNode[];
  attentionSignals: ExtractionAttentionSignal[];
  confidence: number | null;
  isLocated: boolean;
  isActive: boolean;
  metadata: Record<string, string | number | boolean | null>;
  block?: SourceBlock;
  cells?: Array<{ text: string; colspan?: number; rowspan?: number }>;
};

export type ExtractionReviewChecklist = {
  id: string;
  label: string;
  status: "pass" | "warning" | "fail";
  detail: string;
  targetNodeId?: string;
  targetSourceBlockId?: string;
};

export type ExtractionExplorerModel = {
  roots: ExtractionNode[];
  allNodes: ExtractionNode[];
  nodeById: Map<string, ExtractionNode>;
  sourceBlockToNodeId: Map<string, string>;
  nodeSourceBlockIds: Map<string, string[]>;
  ancestorIds: Map<string, string[]>;
  attentionSourceIds: Set<string>;
  attentionBlockCount: number;
  attentionSignalCount: number;
  matchFailureSourceIds: Set<string>;
  matchFailureCount: number;
  sourceBlockCount: number;
  locatedBlockCount: number;
  tableCount: number;
  reviewFlagBlockCount: number;
  reviewFlagSignalCount: number;
  topReviewFlagCodes: string[];
  highestAttentionSeverity: ExtractionAttentionSignal["severity"] | null;
  firstAttentionNodeId: string | null;
  checklist: ExtractionReviewChecklist[];
};

export type ExtractionNavigationKey = "up" | "down" | "right" | "left";

export const LOW_CONFIDENCE_THRESHOLD = 0.72;

export function buildExtractionExplorer({
  documentLabel,
  blocks,
  locatedSourceIds,
  matchFailureSourceIds,
  sourceResolutionKnown,
  qualityGate,
  activeNodeId = "",
}: {
  documentLabel: string;
  blocks: SourceBlock[];
  locatedSourceIds: Set<string>;
  matchFailureSourceIds?: Set<string>;
  sourceResolutionKnown: boolean;
  qualityGate?: QualityGate | null;
  activeNodeId?: string;
}): ExtractionExplorerModel {
  const blockById = new Map(blocks.map((block) => [block.block_id, block] as const));
  const documentNode = makeNode({
    id: "document",
    kind: "document",
    label: documentLabel,
    sourceBlockIds: blocks.map((block) => block.block_id),
    headingPath: [],
    depth: 1,
    confidence: null,
    isLocated: locatedStatus(blocks.map((block) => block.block_id), locatedSourceIds, sourceResolutionKnown),
    activeNodeId,
  });
  const headingNodesByBlockId = new Map<string, ExtractionNode>();
  const blockNodesByBlockId = new Map<string, ExtractionNode>();
  const tableNodesByKey = new Map<string, ExtractionNode>();
  const numberingLabels = computeNumberingLabels(blocks);
  const resolvedMatchFailureSourceIds = matchFailureSourceIds || new Set<string>();

  for (const block of blocks) {
    if (block.block_type === "heading") {
      const parent = parentForHeading(block, documentNode, headingNodesByBlockId);
      const heading = nodeFromBlock({
        block,
        kind: "heading",
        parent,
        numberingLabel: numberingLabels.get(block.block_id) || null,
        locatedSourceIds,
        matchFailureSourceIds: resolvedMatchFailureSourceIds,
        sourceResolutionKnown,
        activeNodeId,
      });
      parent.children.push(heading);
      headingNodesByBlockId.set(block.block_id, heading);
      blockNodesByBlockId.set(block.block_id, heading);
      continue;
    }

    let parent = parentForBlock(block, documentNode, headingNodesByBlockId, blockNodesByBlockId);
    if (block.table_id) {
      const tableKey = `${parent.id}:table:${block.table_id}`;
      let tableNode = tableNodesByKey.get(tableKey);
      if (!tableNode) {
        const label = contextualTableLabel(block.table_id, parent);
        tableNode = makeNode({
          id: tableKey,
          parentId: parent.id,
          kind: "table",
          label,
          sourceBlockIds: [],
          headingPath: parent.kind === "heading" ? [...parent.headingPath, parent.label] : parent.headingPath,
          depth: parent.depth + 1,
          confidence: null,
          isLocated: true,
          metadata: {
            table_id: block.table_id,
            display_label: label,
            heading_context: tableHeadingContext(parent),
          },
          activeNodeId,
        });
        parent.children.push(tableNode);
        tableNodesByKey.set(tableKey, tableNode);
      }
      parent = tableNode;
    }

    const node = nodeFromBlock({
      block,
      kind: nodeKindForBlock(block, parent),
      parent,
      numberingLabel: numberingLabels.get(block.block_id) || null,
      locatedSourceIds,
      matchFailureSourceIds: resolvedMatchFailureSourceIds,
      sourceResolutionKnown,
      activeNodeId,
    });
    parent.children.push(node);
    blockNodesByBlockId.set(block.block_id, node);
  }

  rollUpSyntheticNodes(documentNode, locatedSourceIds, sourceResolutionKnown);
  const locatedBlockCount = blocks.filter((block) => locatedSourceIds.has(block.block_id)).length;
  documentNode.metadata = {
    ...documentNode.metadata,
    block_count: blocks.length,
    located_count: locatedBlockCount,
  };
  const roots = [documentNode];
  const allNodes = flattenAllExtractionNodes(roots);
  const nodeById = new Map(allNodes.map((node) => [node.id, node] as const));
  const nodeSourceBlockIds = new Map(allNodes.map((node) => [node.id, node.sourceBlockIds] as const));
  const sourceBlockToNodeId = new Map<string, string>();
  for (const node of allNodes) {
    if (node.kind === "document" || node.kind === "table") continue;
    for (const sourceBlockId of node.sourceBlockIds) sourceBlockToNodeId.set(sourceBlockId, node.id);
  }
  const ancestorIds = buildAncestorIds(roots);
  const attentionNodes = allNodes.filter((node) => node.block && node.attentionSignals.length > 0);
  const attentionSourceIds = new Set(attentionNodes.flatMap((node) => node.sourceBlockIds));
  const reviewFlagNodes = allNodes.filter((node) => node.block && (node.block.review_flags?.length || 0) > 0);
  const reviewFlagCounts = countReviewFlagCodes(reviewFlagNodes);
  const reviewFlagSignalCount = reviewFlagNodes.reduce((sum, node) => sum + (node.block?.review_flags?.length || 0), 0);
  const attentionSignalCount = attentionNodes.reduce((sum, node) => sum + node.attentionSignals.length, 0);
  const tableNodes = allNodes.filter((node) => node.kind === "table");
  const checklist = buildChecklist({
    blocks,
    locatedBlockCount,
    sourceResolutionKnown,
    matchFailureCount: resolvedMatchFailureSourceIds.size,
    attentionSignalCount,
    reviewFlagBlockCount: reviewFlagNodes.length,
    reviewFlagSignalCount,
    topReviewFlagCodes: topReviewFlagCodes(reviewFlagCounts),
    firstAttentionNodeId: attentionNodes[0]?.id || null,
    firstAttentionSourceBlockId: attentionNodes[0]?.sourceBlockIds[0] || null,
    tableNodes,
    qualityGate,
  });

  return {
    roots,
    allNodes,
    nodeById,
    sourceBlockToNodeId,
    nodeSourceBlockIds,
    ancestorIds,
    attentionSourceIds,
    attentionBlockCount: attentionNodes.length,
    attentionSignalCount,
    matchFailureSourceIds: resolvedMatchFailureSourceIds,
    matchFailureCount: resolvedMatchFailureSourceIds.size,
    sourceBlockCount: blocks.length,
    locatedBlockCount,
    tableCount: tableNodes.length,
    reviewFlagBlockCount: reviewFlagNodes.length,
    reviewFlagSignalCount,
    topReviewFlagCodes: topReviewFlagCodes(reviewFlagCounts),
    highestAttentionSeverity: highestSeverity(attentionNodes.flatMap((node) => node.attentionSignals)),
    firstAttentionNodeId: attentionNodes[0]?.id || null,
    checklist,
  };
}

export function defaultExpandedExtractionIds(roots: ExtractionNode[]) {
  return new Set(
    flattenAllExtractionNodes(roots)
      .filter((node) => node.children.length > 0)
      .map((node) => node.id),
  );
}

export function flattenVisibleExtractionNodes(
  roots: ExtractionNode[],
  expandedIds: Set<string>,
  options: { attentionOnly?: boolean; failureOnly?: boolean; query?: string } = {},
) {
  const visible: ExtractionNode[] = [];
  const query = normalizeSourceText(options.query || "");
  const matches = (node: ExtractionNode) => {
    if (!query) return true;
    return normalizeSourceText(searchTextForNode(node)).includes(query);
  };
  const includeByFilter = (node: ExtractionNode): boolean => {
    if (node.kind === "document") return true;
    const directMatch = matches(node);
    const attentionMatch = !options.attentionOnly || node.attentionSignals.length > 0;
    const failureMatch = !options.failureOnly || !node.isLocated;
    const childMatch = node.children.some(includeByFilter);
    return (directMatch && attentionMatch && failureMatch) || childMatch;
  };
  const visit = (node: ExtractionNode) => {
    if (!includeByFilter(node)) return;
    visible.push(node);
    if (!expandedIds.has(node.id)) return;
    node.children.forEach(visit);
  };
  roots.forEach(visit);
  return visible;
}

export function navigateExtractionTree({
  visibleNodes,
  nodeById,
  expandedIds,
  activeId,
  key,
}: {
  visibleNodes: ExtractionNode[];
  nodeById: Map<string, ExtractionNode>;
  expandedIds: Set<string>;
  activeId: string;
  key: ExtractionNavigationKey;
}) {
  const nextExpandedIds = new Set(expandedIds);
  const activeNode = nodeById.get(activeId) || visibleNodes[0];
  if (!activeNode) return { activeId, expandedIds: nextExpandedIds };
  if (key === "up" || key === "down") {
    const currentIndex = Math.max(0, visibleNodes.findIndex((node) => node.id === activeNode.id));
    const nextIndex = Math.min(visibleNodes.length - 1, Math.max(0, currentIndex + (key === "down" ? 1 : -1)));
    return { activeId: visibleNodes[nextIndex]?.id || activeNode.id, expandedIds: nextExpandedIds };
  }
  if (key === "right") {
    if (activeNode.children.length === 0) return { activeId: activeNode.id, expandedIds: nextExpandedIds };
    if (!nextExpandedIds.has(activeNode.id)) {
      nextExpandedIds.add(activeNode.id);
      return { activeId: activeNode.id, expandedIds: nextExpandedIds };
    }
    return { activeId: activeNode.children[0]?.id || activeNode.id, expandedIds: nextExpandedIds };
  }
  if (activeNode.children.length > 0 && nextExpandedIds.has(activeNode.id)) {
    nextExpandedIds.delete(activeNode.id);
    return { activeId: activeNode.id, expandedIds: nextExpandedIds };
  }
  return { activeId: activeNode.parentId || activeNode.id, expandedIds: nextExpandedIds };
}

export function extractionNodeBreadcrumb(node: ExtractionNode) {
  if (node.kind === "document") return node.label;
  const segments = [...node.headingPath, node.kind === "heading" ? node.label : ""]
    .filter(Boolean)
    .filter((segment, index, all) => index === 0 || normalizeSourceText(segment) !== normalizeSourceText(all[index - 1] || ""));
  return segments.join(" / ");
}

function nodeFromBlock({
  block,
  kind,
  parent,
  numberingLabel,
  locatedSourceIds,
  matchFailureSourceIds,
  sourceResolutionKnown,
  activeNodeId,
}: {
  block: SourceBlock;
  kind: ExtractionNodeKind;
  parent: ExtractionNode;
  numberingLabel: string | null;
  locatedSourceIds: Set<string>;
  matchFailureSourceIds: Set<string>;
  sourceResolutionKnown: boolean;
  activeNodeId: string;
}) {
  const id = `${parent.id}:block:${block.block_id}`;
  const confidence = confidenceForBlock(block);
  return makeNode({
    id,
    parentId: parent.id,
    kind,
    label: labelForBlock(block),
    sourceBlockIds: [block.block_id],
    locator: block.source_location?.section || null,
    blockType: block.block_type,
    headingPath: pathForChild(parent),
    depth: parent.depth + 1,
    attentionSignals: attentionSignalsForBlock(block, locatedSourceIds, matchFailureSourceIds, sourceResolutionKnown),
    confidence,
    isLocated: locatedStatus([block.block_id], locatedSourceIds, sourceResolutionKnown),
    metadata: metadataForBlock(block, numberingLabel),
    block,
    cells: block.cells,
    activeNodeId,
  });
}

function makeNode({
  id,
  parentId,
  kind,
  label,
  sourceBlockIds,
  locator = null,
  blockType,
  headingPath,
  depth,
  attentionSignals = [],
  confidence,
  isLocated,
  metadata = {},
  block,
  cells,
  activeNodeId,
}: {
  id: string;
  parentId?: string;
  kind: ExtractionNodeKind;
  label: string;
  sourceBlockIds: string[];
  locator?: string | null;
  blockType?: string;
  headingPath: string[];
  depth: number;
  attentionSignals?: ExtractionAttentionSignal[];
  confidence: number | null;
  isLocated: boolean;
  metadata?: ExtractionNode["metadata"];
  block?: SourceBlock;
  cells?: ExtractionNode["cells"];
  activeNodeId: string;
}) {
  return {
    id,
    parentId,
    kind,
    label,
    sourceBlockIds,
    locator,
    blockType,
    headingPath,
    depth,
    children: [],
    attentionSignals,
    confidence,
    isLocated,
    isActive: id === activeNodeId,
    metadata,
    block,
    cells,
  };
}

function parentForHeading(
  block: SourceBlock,
  documentNode: ExtractionNode,
  headingNodesByBlockId: Map<string, ExtractionNode>,
) {
  const ancestorIds = block.heading_path_ids || [];
  const nearest = ancestorIds.slice().reverse().map((id) => headingNodesByBlockId.get(id)).find(Boolean);
  return nearest || documentNode;
}

function parentForBlock(
  block: SourceBlock,
  documentNode: ExtractionNode,
  headingNodesByBlockId: Map<string, ExtractionNode>,
  blockNodesByBlockId: Map<string, ExtractionNode>,
) {
  if (block.parent_block_id) {
    const directParent = blockNodesByBlockId.get(block.parent_block_id);
    if (directParent && directParent.kind !== "table_row") return directParent;
  }
  const nearest = (block.heading_path_ids || []).slice().reverse().map((id) => headingNodesByBlockId.get(id)).find(Boolean);
  return nearest || documentNode;
}

function nodeKindForBlock(block: SourceBlock, parent?: ExtractionNode): ExtractionNodeKind {
  if (block.block_type === "note") return "note";
  if (block.block_type === "table_row") return "table_row";
  if (block.block_type === "procedure_step") {
    const text = block.text.trim();
    const parentPath = parent ? [...parent.headingPath, parent.label].join(" ").toLowerCase() : "";
    const resourceSection = /\b(resource|resources|portal|portals|links?)\b/.test(parentPath);
    if (/^(?:https?:\/\/|mailto:|[\w .-]+\.(?:docx?|pdf|xlsx?|pptx?)$)/i.test(text)) return "resource";
    if (resourceSection && text.length <= 80) return "resource";
    return "procedure_step";
  }
  if (block.block_type === "ordered_list" || block.block_type === "unordered_list") return "list_item";
  if (block.block_type === "heading") return "heading";
  return "paragraph";
}

function labelForBlock(block: SourceBlock) {
  if (block.block_type === "table_row" && block.cells?.length) return `Row ${block.row_index ?? "?"}`;
  return block.text || block.block_id;
}

function tableLabel(tableId: string) {
  const numeric = tableId.match(/(\d+)$/)?.[1];
  return numeric ? `Table ${numeric.padStart(3, "0")}` : `Table ${tableId}`;
}

function contextualTableLabel(tableId: string, parent: ExtractionNode) {
  const context = tableHeadingContext(parent);
  return context ? `${tableLabel(tableId)} · ${context}` : tableLabel(tableId);
}

function pathForChild(parent: ExtractionNode) {
  if (parent.kind === "document") return parent.headingPath;
  if (parent.kind === "heading") return [...parent.headingPath, parent.label];
  if (parent.kind === "table") return parent.headingPath;
  return [...parent.headingPath, breadcrumbLabel(parent)];
}

function breadcrumbLabel(node: ExtractionNode) {
  if (node.kind === "procedure_step" || node.kind === "list_item" || node.kind === "resource") {
    const marker = typeof node.metadata.list_marker === "string" ? node.metadata.list_marker : "";
    const label = node.label.length > 56 ? `${node.label.slice(0, 53)}...` : node.label;
    return marker ? `${marker} ${label}` : label;
  }
  return node.label;
}

function tableHeadingContext(parent: ExtractionNode) {
  if (parent.kind === "heading") return parent.label;
  return parent.headingPath[parent.headingPath.length - 1] || "";
}

function metadataForBlock(block: SourceBlock, numberingLabel: string | null) {
  const numbering = block.numbering;
  const listDepth = typeof numbering?.level === "number" ? numbering.level : 0;
  return {
    locator: block.source_location?.section || null,
    block_id: block.block_id,
    block_type: block.block_type,
    inferred_level: block.inferred_level ?? null,
    style_source: stringSignal(block.confidence_signals?.style_source),
    table_id: block.table_id || null,
    row_index: block.row_index ?? null,
    numbering_level: typeof numbering?.level === "number" ? numbering.level : null,
    list_depth: listDepth,
    numbering_label: numberingLabel,
    list_marker: numberingLabel,
    numbering_format: numbering?.format || null,
    parent_block_id: block.parent_block_id || null,
  };
}

function computeNumberingLabels(blocks: SourceBlock[]) {
  const countersByList = new Map<string, number[]>();
  const labels = new Map<string, string>();
  for (const block of blocks) {
    const numbering = block.numbering;
    if (!numbering) continue;
    if (numbering.label) {
      labels.set(block.block_id, numbering.label);
      continue;
    }
    const level = typeof numbering.level === "number" ? numbering.level : 0;
    const listKey = numbering.num_id || "__default__";
    const counters = countersByList.get(listKey) || [];
    while (counters.length <= level) counters.push(0);
    counters[level] = (counters[level] || 0) + 1;
    counters.length = level + 1;
    countersByList.set(listKey, counters);
    labels.set(block.block_id, fallbackNumberingLabel(counters[level]!, numbering.format || null, numbering.level_text || null, level));
  }
  return labels;
}

function fallbackNumberingLabel(value: number, format: string | null, levelText: string | null, level: number) {
  const inferredFormat = format || (level === 1 ? "lowerLetter" : "decimal");
  const marker = formatNumberingValue(value, inferredFormat);
  return levelText ? levelText.replace(`%${level + 1}`, marker) : marker;
}

function formatNumberingValue(value: number, format: string) {
  if (format === "bullet") return "•";
  if (format === "lowerLetter") return alphaCounter(value).toLowerCase();
  if (format === "upperLetter") return alphaCounter(value).toUpperCase();
  if (format === "lowerRoman") return romanCounter(value).toLowerCase();
  if (format === "upperRoman") return romanCounter(value).toUpperCase();
  return String(value);
}

function alphaCounter(value: number) {
  const chars: string[] = [];
  let current = Math.max(1, value);
  while (current > 0) {
    current -= 1;
    chars.unshift(String.fromCharCode(65 + (current % 26)));
    current = Math.floor(current / 26);
  }
  return chars.join("");
}

function romanCounter(value: number) {
  let current = Math.max(1, value);
  const numerals: Array<[number, string]> = [
    [1000, "M"],
    [900, "CM"],
    [500, "D"],
    [400, "CD"],
    [100, "C"],
    [90, "XC"],
    [50, "L"],
    [40, "XL"],
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"],
  ];
  const output: string[] = [];
  for (const [number, label] of numerals) {
    while (current >= number) {
      output.push(label);
      current -= number;
    }
  }
  return output.join("");
}

function confidenceForBlock(block: SourceBlock) {
  return block.confidence.extraction ?? block.confidence.block_type ?? block.confidence.heading ?? null;
}

function attentionSignalsForBlock(
  block: SourceBlock,
  locatedSourceIds: Set<string>,
  matchFailureSourceIds: Set<string>,
  sourceResolutionKnown: boolean,
): ExtractionAttentionSignal[] {
  const signals: ExtractionAttentionSignal[] = [];
  if (sourceResolutionKnown && !locatedSourceIds.has(block.block_id)) {
    const isKnownFailure = matchFailureSourceIds.size === 0 || matchFailureSourceIds.has(block.block_id);
    if (isKnownFailure) {
      signals.push({
        code: "SOURCE_HIGHLIGHT_UNMAPPED",
        severity: "error",
        label: "Source highlight unmapped",
        message: "Source block is not mapped to the rendered source.",
        explanation: "The source preview did not expose a highlight target for this extracted block.",
        action: "Open the source text and verify this block manually before approving.",
      });
    }
  }
  for (const flag of block.review_flags || []) {
    const normalized = normalizeReviewFlag(flag);
    if (normalized) signals.push(normalized);
  }
  const confidence = confidenceForBlock(block);
  const hasLowConfidenceFlag = signals.some((signal) => signal.code === "LOW_BLOCK_TYPE_CONFIDENCE");
  if (typeof confidence === "number" && confidence < LOW_CONFIDENCE_THRESHOLD && !hasLowConfidenceFlag) {
    signals.push({
      code: "LOW_CONFIDENCE",
      severity: "warning",
      label: "Low extraction confidence",
      message: "Extraction confidence is below the review threshold.",
      action: "Compare the extracted row with the source before approving.",
    });
  }
  return signals;
}

function normalizeReviewFlag(flag: unknown): ExtractionAttentionSignal | null {
  if (typeof flag === "string") {
    const catalog = reviewFlagLabel(flag);
    return catalog
      ? {
          code: flag,
          severity: catalog.severity,
          label: catalog.label,
          message: catalog.explanation,
          explanation: catalog.explanation,
          action: catalog.action,
        }
      : {
          code: flag,
          severity: "warning",
          label: flag,
          message: `Unknown review flag: ${flag}`,
          action: "Inspect this block before approving.",
        };
  }
  if (!flag || typeof flag !== "object") return null;
  const raw = flag as { code?: unknown; severity?: unknown; message?: unknown; action?: unknown; label?: unknown; explanation?: unknown };
  const code = typeof raw.code === "string" ? raw.code : "";
  if (!code) return null;
  const catalog = reviewFlagLabel(code);
  const severity = raw.severity === "error" || raw.severity === "info" || raw.severity === "warning"
    ? raw.severity
    : catalog?.severity || "warning";
  return {
    code,
    severity,
    label: typeof raw.label === "string" ? raw.label : catalog?.label,
    message: typeof raw.message === "string" ? raw.message : catalog?.explanation || `Unknown review flag: ${code}`,
    explanation: typeof raw.explanation === "string" ? raw.explanation : catalog?.explanation,
    action: typeof raw.action === "string" ? raw.action : catalog?.action || "Inspect this block before approving.",
  };
}

function stringSignal(value: unknown) {
  return typeof value === "string" ? value : null;
}

function locatedStatus(sourceBlockIds: string[], locatedSourceIds: Set<string>, sourceResolutionKnown: boolean) {
  if (!sourceResolutionKnown) return true;
  return sourceBlockIds.every((id) => locatedSourceIds.has(id));
}

function rollUpSyntheticNodes(
  node: ExtractionNode,
  locatedSourceIds: Set<string>,
  sourceResolutionKnown: boolean,
): string[] {
  if (node.block) {
    node.children.forEach((child) => rollUpSyntheticNodes(child, locatedSourceIds, sourceResolutionKnown));
    return node.sourceBlockIds;
  }
  const sourceBlockIds = node.children.flatMap((child) => rollUpSyntheticNodes(child, locatedSourceIds, sourceResolutionKnown));
  node.sourceBlockIds = sourceBlockIds;
  node.isLocated = locatedStatus(sourceBlockIds, locatedSourceIds, sourceResolutionKnown);
  node.confidence = minNumber(node.children.map((child) => child.confidence).filter((value): value is number => typeof value === "number"));
  node.attentionSignals = node.children.flatMap((child) => child.attentionSignals);
  if (node.kind === "table") {
    const columns = Math.max(0, ...node.children.map((child) => child.cells?.length || 0));
    const rows = node.children.length;
    node.metadata = {
      ...node.metadata,
      rows,
      row_count: rows,
      columns,
      column_count: columns,
    };
    node.children.forEach((child) => {
      const isHeaderRow = child === node.children[0] && looksLikeHeaderRow(child);
      child.metadata = {
        ...child.metadata,
        table_label: node.label,
        table_row_count: rows,
        table_column_count: columns,
        row_kind: isHeaderRow ? "header" : "body",
      };
    });
  }
  return sourceBlockIds;
}

function looksLikeHeaderRow(node: ExtractionNode) {
  if (!node.cells?.length || node.cells.length < 2) return false;
  const headerish = node.cells.filter((cell) => isHeaderishCell(cell.text)).length;
  return headerish === node.cells.length;
}

function isHeaderishCell(value: string) {
  const text = normalizeSourceText(value || "");
  if (!text || text.length > 48) return false;
  return /\b(name|contact|client contact|description|field|value|type|code|date|status|state|province|country|amount|rate|id|number)\b/.test(text);
}

function flattenAllExtractionNodes(roots: ExtractionNode[]) {
  const all: ExtractionNode[] = [];
  const visit = (node: ExtractionNode) => {
    all.push(node);
    node.children.forEach(visit);
  };
  roots.forEach(visit);
  return all;
}

function buildAncestorIds(roots: ExtractionNode[]) {
  const ancestors = new Map<string, string[]>();
  const visit = (node: ExtractionNode, parentIds: string[]) => {
    ancestors.set(node.id, parentIds);
    node.children.forEach((child) => visit(child, [...parentIds, node.id]));
  };
  roots.forEach((root) => visit(root, []));
  return ancestors;
}

function buildChecklist({
  blocks,
  locatedBlockCount,
  sourceResolutionKnown,
  matchFailureCount,
  attentionSignalCount,
  reviewFlagBlockCount,
  reviewFlagSignalCount,
  topReviewFlagCodes,
  firstAttentionNodeId,
  firstAttentionSourceBlockId,
  tableNodes,
  qualityGate,
}: {
  blocks: SourceBlock[];
  locatedBlockCount: number;
  sourceResolutionKnown: boolean;
  matchFailureCount: number;
  attentionSignalCount: number;
  reviewFlagBlockCount: number;
  reviewFlagSignalCount: number;
  topReviewFlagCodes: string[];
  firstAttentionNodeId: string | null;
  firstAttentionSourceBlockId: string | null;
  tableNodes: ExtractionNode[];
  qualityGate?: QualityGate | null;
}): ExtractionReviewChecklist[] {
  const tableRows = blocks.filter((block) => block.table_id);
  const rowsWithCells = tableRows.filter((block) => (block.cells?.length || 0) > 0);
  const inferredHeadings = blocks.filter((block) => stringSignal(block.confidence_signals?.style_source) === "formatting");
  const procedureSteps = blocks.filter((block) => block.block_type === "procedure_step");
  const linkLikeBlocks = blocks.filter(hasLinkLikeText);
  const linkBlocksMissingHref = linkLikeBlocks.filter((block) => !hasCapturedHref(block));
  return [
    {
      id: "located",
    label: "All blocks located",
    status: sourceResolutionKnown && locatedBlockCount === blocks.length ? "pass" : "fail",
      detail: `${locatedBlockCount}/${blocks.length} mapped`,
    },
    {
      id: "tables",
      label: "Tables preserved",
      status: tableRows.length === rowsWithCells.length ? "pass" : "warning",
      detail: `${tableNodes.length} tables, ${rowsWithCells.length} rows with cells`,
    },
    {
      id: "links",
      label: "Links captured",
      status: linkBlocksMissingHref.length > 0 ? "warning" : "pass",
      detail: linkBlocksMissingHref.length > 0
        ? `${linkBlocksMissingHref.length}/${linkLikeBlocks.length} link-like blocks need href metadata`
        : linkLikeBlocks.length > 0
          ? `${linkLikeBlocks.length} link-like blocks include href metadata`
          : "No link-like text detected",
    },
    {
      id: "lists",
      label: "Lists nested",
      status: procedureSteps.length > 0 ? "warning" : "pass",
      detail: procedureSteps.length > 0 ? `${procedureSteps.length} list/step blocks need hierarchy review` : "No list items detected",
    },
    {
      id: "headings",
      label: "Headings verified",
      status: inferredHeadings.length > 0 ? "warning" : "pass",
      detail: inferredHeadings.length > 0 ? `${inferredHeadings.length} inferred heading` : "Explicit heading styles",
    },
    {
      id: "review-flags",
      label: "Review flags",
      status: reviewFlagSignalCount > 0 ? "warning" : "pass",
      detail: reviewFlagSignalCount > 0
        ? `${reviewFlagBlockCount} blocks, ${reviewFlagSignalCount} flags: ${topReviewFlagCodes.join(", ")}`
        : "No review flags",
      targetNodeId: firstAttentionNodeId || undefined,
      targetSourceBlockId: firstAttentionSourceBlockId || undefined,
    },
    {
      id: "source-highlights",
      label: "Source highlights mapped",
      status: sourceResolutionKnown && matchFailureCount === 0 ? "pass" : matchFailureCount > 0 ? "fail" : "warning",
      detail: sourceResolutionKnown ? `${matchFailureCount} highlight mapping failures` : "Source preview not resolved yet",
    },
    {
      id: "warnings",
      label: "Warnings resolved",
      status: qualityGate?.passed === false ? "fail" : attentionSignalCount > 0 ? "warning" : "pass",
      detail: qualityGate?.passed === false ? qualityGate.blocking_reasons.join(", ") : `${attentionSignalCount} extraction signals`,
    },
  ];
}

function hasLinkLikeText(block: SourceBlock) {
  return /https?:\/\/|[\w.+-]+@[\w.-]+\.\w+/.test(block.text);
}

function hasCapturedHref(block: SourceBlock) {
  return Boolean(block.inline_runs?.some((run) => typeof run.href === "string" && run.href.trim()));
}

function countReviewFlagCodes(nodes: ExtractionNode[]) {
  const counts = new Map<string, number>();
  for (const node of nodes) {
    for (const flag of node.block?.review_flags || []) {
      const code = reviewFlagCode(flag);
      if (code) counts.set(code, (counts.get(code) || 0) + 1);
    }
  }
  return counts;
}

function topReviewFlagCodes(counts: Map<string, number>) {
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, 3)
    .map(([code]) => code);
}

function reviewFlagCode(flag: unknown) {
  if (typeof flag === "string") return flag;
  if (!flag || typeof flag !== "object") return "";
  const raw = flag as { code?: unknown };
  return typeof raw.code === "string" ? raw.code : "";
}

function highestSeverity(signals: ExtractionAttentionSignal[]) {
  if (signals.some((signal) => signal.severity === "error")) return "error";
  if (signals.some((signal) => signal.severity === "warning")) return "warning";
  if (signals.some((signal) => signal.severity === "info")) return "info";
  return null;
}

export function sourceBlockCountLabel(count: number) {
  return plural(count, "source block");
}

function minNumber(values: number[]) {
  return values.length ? Math.min(...values) : null;
}

function searchTextForNode(node: ExtractionNode) {
  return [
    node.label,
    node.locator || "",
    node.blockType || "",
    node.sourceBlockIds.join(" "),
    node.headingPath.join(" "),
    node.attentionSignals.map((signal) => `${signal.code} ${signal.message}`).join(" "),
    node.cells?.map((cell) => cell.text).join(" ") || "",
  ].join(" ");
}
