export function relativeTime(value: string | null | undefined) {
  if (!value) return "";
  const then = new Date(value).getTime();
  if (Number.isNaN(then)) return "";
  const diff = Date.now() - then;
  if (diff < 0) return "just now";
  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  if (diff < minute) return "just now";
  if (diff < hour) return `${Math.floor(diff / minute)}m ago`;
  if (diff < day) return `${Math.floor(diff / hour)}h ago`;
  if (diff < 30 * day) return `${Math.floor(diff / day)}d ago`;
  if (diff < 365 * day) return `${Math.floor(diff / (30 * day))}mo ago`;
  return `${Math.floor(diff / (365 * day))}y ago`;
}

export function formatConfidence(value: number | null) {
  return value === null ? "unknown" : `${Math.round(value * 100)}%`;
}

export function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function plural(count: number, singular: string, pluralForm = `${singular}s`) {
  return `${count} ${count === 1 ? singular : pluralForm}`;
}

export function qualityGateDisplayName(name: string | null | undefined) {
  if (!name) return "Quality gate";
  if (name === "legacy_pre_gate") return "Legacy quality gate";
  if (name === "docx_source_fidelity_v1") return "Source-fidelity quality gate";
  return humanizeStatus(name.replace(/_v\d+$/i, ""));
}

export function thresholdQualityLabel(value: number | null | undefined, threshold = 0.72) {
  if (typeof value !== "number") return "Quality unknown";
  const delta = Math.round((value - threshold) * 100);
  if (value >= threshold) return `Above gate (+${delta} pts)`;
  const gap = Math.abs(delta);
  return gap >= 30 ? `Below gate by ${gap} pts` : `Below gate (-${gap} pts)`;
}

export function stripTerminalMarker(value: string) {
  return value.replace(/[.)]\s*$/u, "");
}

export function humanizeStatus(status: string) {
  if (!status) return status;
  return status
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}
