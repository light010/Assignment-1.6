import { motion } from "framer-motion";
import { NumberedAnchor, SpotlightRect } from "./workbenchGeometry";

export function SourceSpotlight({
  anchors,
  spotlightRects,
  reducedMotion,
}: {
  anchors: NumberedAnchor[];
  spotlightRects: SpotlightRect[] | null;
  reducedMotion: boolean;
}) {
  return (
    <div className="source-spotlight-layer" aria-hidden={false}>
      {spotlightRects?.map((rect) => (
        <motion.span
          key={rect.id}
          className="source-spotlight-halo"
          style={{ left: rect.x, top: rect.y, width: rect.width, height: rect.height }}
          initial={reducedMotion ? false : { opacity: 0, scale: 0.98 }}
          animate={reducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1 }}
          transition={{ duration: reducedMotion ? 0 : 0.18 }}
        />
      ))}
      {anchors.map((anchor) => (
        <span
          key={anchor.id}
          className={`evidence-marker side-${anchor.side}`}
          style={{ left: anchor.point.x, top: anchor.point.y }}
          aria-label={`Evidence ${anchor.evidenceNumber}, ${anchor.side === "source" ? "source" : "extracted"}`}
        >
          {anchor.evidenceNumber}
        </span>
      ))}
    </div>
  );
}
