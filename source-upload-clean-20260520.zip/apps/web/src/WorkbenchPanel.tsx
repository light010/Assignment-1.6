import {
  Redo2,
  RotateCcw,
  Scissors,
  Undo2,
} from "lucide-react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  KeyboardEvent as ReactKeyboardEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  DocumentRecord,
  getAllDocumentBlocks,
  getDocumentTopicPlan,
  getTopicRecord,
  SourceBlock,
  TopicRecord,
} from "./api";
import { ExtractionExplorerPane } from "./ExtractionExplorerPane";
import { SourceEvidenceViewer } from "./SourceEvidenceViewer";
import { SourceSpotlight } from "./SourceSpotlight";
import {
  buildExtractionExplorer,
  defaultExpandedExtractionIds,
  ExtractionNavigationKey,
  ExtractionNode,
  flattenVisibleExtractionNodes,
  navigateExtractionTree,
} from "./extractionExplorerModel";
import {
  AttentionFilter,
  attentionCounts,
  defaultActiveTopicId,
  documentLevelIssues,
  nextActionForTopic,
  ReviewedTopicState,
  topicContentHash,
  topicAttentionSummary,
  topicAttentionSummaries,
  TopicAttentionSummary,
  topicProgress,
} from "./workbenchSelectors";
import { Connector } from "./useRelationshipConnectors";
import { useSpotlightGeometry } from "./useSpotlightGeometry";
import {
  applyWorkbenchOp,
  applyWorkbenchOps,
  buildWorkbenchState,
  canMergeUnits,
  canSplitUnit,
  computeCoverage,
  computeWorkbenchIssues,
  WorkbenchIssue,
  WorkbenchOp,
  WorkbenchState,
  WorkbenchTopic,
} from "./workbenchModel";
import { clearWorkbenchStorage, readWorkbenchStorage, writeWorkbenchStorage } from "./workbenchStorage";
import { useRefMap } from "./useRefMap";
import { NumberedAnchor, SpotlightRect } from "./workbenchGeometry";

export function WorkbenchPanel({ document }: { document: DocumentRecord }) {
  const prefersReducedMotion = useReducedMotion();
  const [blocks, setBlocks] = useState<SourceBlock[]>([]);
  const [topicRecords, setTopicRecords] = useState<TopicRecord[]>([]);
  const [plan, setPlan] = useState<Awaited<ReturnType<typeof getDocumentTopicPlan>> | null>(null);
  const [ops, setOps] = useState<WorkbenchOp[]>([]);
  const [undoneOps, setUndoneOps] = useState<WorkbenchOp[]>([]);
  const [selectedTopicId, setSelectedTopicId] = useState("");
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);
  const [activeSourceIds, setActiveSourceIds] = useState<string[]>([]);
  const [previewSourceIds, setPreviewSourceIds] = useState<string[]>([]);
  const [matchFailureSourceIds, setMatchFailureSourceIds] = useState<string[]>([]);
  const [matchFailuresOnly, setMatchFailuresOnly] = useState(false);
  const [activeExtractionNodeId, setActiveExtractionNodeId] = useState("");
  const [expandedExtractionIds, setExpandedExtractionIds] = useState<Set<string>>(() => new Set());
  const [sourceQuery, setSourceQuery] = useState("");
  const [syncScrolling, setSyncScrolling] = useState(true);
  const [attentionOnly, setAttentionOnly] = useState(false);
  const [attentionFilter, setAttentionFilter] = useState<AttentionFilter>("all");
  const [reviewed, setReviewed] = useState<Record<string, ReviewedTopicState>>({});
  const [splitUnitId, setSplitUnitId] = useState("");
  const [splitOffset, setSplitOffset] = useState(0);
  const [moveTargetTopicId, setMoveTargetTopicId] = useState("");
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [liveMessage, setLiveMessage] = useState("");
  const [toast, setToast] = useState("");
  const [loadError, setLoadError] = useState("");
  const [loading, setLoading] = useState(true);
  const [treeRevealNonce, setTreeRevealNonce] = useState(0);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const { refs: sourceRefs, setRef: setBlockRef, version: sourceRefVersion } = useRefMap<string>();
  const titleInputRef = useRef<HTMLInputElement | null>(null);
  const typeSelectRef = useRef<HTMLSelectElement | null>(null);
  const splitTextRef = useRef<HTMLTextAreaElement | null>(null);
  const expandedInitializedForDocument = useRef("");
  const topicIdsKey = useMemo(() => document.topic_ids.join("|"), [document.topic_ids]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError("");
    setSelectedUnitIds([]);
    setActiveSourceIds([]);
    setPreviewSourceIds([]);
    setMatchFailureSourceIds([]);
    setMatchFailuresOnly(false);
    setActiveExtractionNodeId("");
    setExpandedExtractionIds(new Set());
    expandedInitializedForDocument.current = "";
    Promise.all([
      getAllDocumentBlocks(document.document_id),
      getDocumentTopicPlan(document.document_id),
      Promise.all(
        document.topic_ids.map((topicId) =>
          getTopicRecord(topicId).catch(() => null),
        ),
      ),
    ])
      .then(([blockResult, planResult, topicResults]) => {
        if (cancelled) return;
        setBlocks(blockResult.items);
        setPlan(planResult);
        setTopicRecords(topicResults.filter(Boolean) as TopicRecord[]);
        const stored = readWorkbenchStorage(document.document_id);
        setOps(stored.ops);
        setReviewed(stored.reviewed);
        setSelectedTopicId(stored.ui.selected_topic_id || "");
        setAttentionFilter(stored.ui.attention_filter || "all");
        setUndoneOps([]);
      })
      .catch((err) => {
        if (!cancelled) setLoadError((err as Error).message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [document.document_id, topicIdsKey]);

  useEffect(() => {
    if (!plan) return;
    const current = readWorkbenchStorage(document.document_id);
    writeWorkbenchStorage(document.document_id, {
      ...current,
      ops,
      reviewed,
      ui: {
        ...current.ui,
        selected_topic_id: selectedTopicId || current.ui.selected_topic_id,
        attention_filter: attentionFilter,
      },
    });
  }, [attentionFilter, document.document_id, ops, plan, reviewed, selectedTopicId]);

  const baseState = useMemo(() => {
    if (!plan) return null;
    return buildWorkbenchState({
      documentId: document.document_id,
      blocks,
      candidates: plan.topic_plan.topic_candidates,
      topicRecords,
    });
  }, [blocks, document.document_id, plan, topicRecords]);

  const state = useMemo(() => {
    if (!baseState) return null;
    try {
      return applyWorkbenchOps(baseState, ops);
    } catch {
      return baseState;
    }
  }, [baseState, ops]);

  const coverage = useMemo(() => (state ? computeCoverage(state, blocks) : null), [blocks, state]);
  const issues = useMemo(() => (state ? computeWorkbenchIssues(state, blocks) : []), [blocks, state]);
  const topicSummaries = useMemo(
    () => (state ? topicAttentionSummaries(state.topics, issues) : new Map<string, TopicAttentionSummary>()),
    [issues, state],
  );
  const topicAttentionCounts = useMemo(
    () => (state ? attentionCounts(state.topics, topicSummaries) : { attention: 0, errors: 0, stale: 0, review: 0 }),
    [state, topicSummaries],
  );
  const documentIssues = useMemo(() => documentLevelIssues(issues), [issues]);
  const selectedTopic = useMemo(
    () => state?.topics.find((topic) => topic.topic_id === selectedTopicId) || state?.topics[0] || null,
    [selectedTopicId, state],
  );
  const selectedTopicIndex = useMemo(
    () => (selectedTopic && state ? state.topics.findIndex((topic) => topic.topic_id === selectedTopic.topic_id) : -1),
    [selectedTopic, state],
  );
  const selectedSummary = useMemo(
    () => (selectedTopic ? topicSummaries.get(selectedTopic.topic_id) || topicAttentionSummary(selectedTopic, issues) : null),
    [issues, selectedTopic, topicSummaries],
  );
  const selectedUnits = useMemo(
    () =>
      selectedTopic
        ? selectedTopic.units.filter((unit) => selectedUnitIds.includes(unit.unit_id))
        : [],
    [selectedTopic, selectedUnitIds],
  );
  const selectedSourceIds = useMemo(
    () => selectedUnits.flatMap((unit) => unit.source_block_ids),
    [selectedUnits],
  );
  const progress = useMemo(() => (state ? topicProgress(state.topics, reviewed) : { reviewed: 0, remaining: 0, total: 0 }), [reviewed, state]);
  const nextAction = useMemo(
    () => (selectedTopic && selectedSummary ? nextActionForTopic(selectedTopic, selectedSummary, reviewed[selectedTopic.topic_id]) : null),
    [reviewed, selectedSummary, selectedTopic],
  );
  const locatedSourceIds = useMemo(() => new Set(sourceRefs.current.keys()), [sourceRefVersion, sourceRefs]);
  const sourceResolutionKnown = sourceRefs.current.size > 0 || matchFailureSourceIds.length > 0;
  const extractionModel = useMemo(
    () =>
      buildExtractionExplorer({
        documentLabel: document.filename,
        blocks,
        locatedSourceIds,
        matchFailureSourceIds: new Set(matchFailureSourceIds),
        sourceResolutionKnown,
        qualityGate: document.source_quality?.quality_gate,
        activeNodeId: activeExtractionNodeId,
      }),
    [activeExtractionNodeId, blocks, document.filename, document.source_quality?.quality_gate, locatedSourceIds, matchFailureSourceIds, sourceResolutionKnown],
  );
  const visibleExtractionNodes = useMemo(
    () => flattenVisibleExtractionNodes(extractionModel.roots, expandedExtractionIds, { attentionOnly, failureOnly: matchFailuresOnly, query: sourceQuery }),
    [attentionOnly, expandedExtractionIds, extractionModel, matchFailuresOnly, sourceQuery],
  );
  const activeExtractionNode = activeExtractionNodeId ? extractionModel.nodeById.get(activeExtractionNodeId) || null : null;
  const selectedExtractionSourceIds = activeExtractionNode?.sourceBlockIds || activeSourceIds;
  const visibleSourceIds = selectedExtractionSourceIds;
  const spotlightSourceIds = selectedExtractionSourceIds;
  const attentionSourceIds = extractionModel.attentionSourceIds;
  const totalAttentionCount = extractionModel.attentionBlockCount;
  const connectors: Connector[] = [];
  const numberedAnchors: NumberedAnchor[] = [];
  const spotlightRects = useSpotlightGeometry({
    overlayRef,
    sourceRefs,
    sourceBlockIds: spotlightSourceIds,
    geometryVersion: sourceRefVersion,
  });

  useEffect(() => {
    if (!state || selectedTopicId) return;
    setSelectedTopicId(defaultActiveTopicId(state, topicSummaries));
  }, [selectedTopicId, state, topicSummaries]);

  useEffect(() => {
    if (!state || !selectedTopicId) return;
    const topic = state.topics.find((item) => item.topic_id === selectedTopicId);
    if (!topic) {
      setSelectedTopicId(state.topics[0]?.topic_id || "");
      setSelectedUnitIds([]);
    }
  }, [selectedTopicId, state]);

  useEffect(() => {
    if (blocks.length === 0) return;
    const expansionKey = `${document.document_id}:${blocks.length}`;
    if (expandedInitializedForDocument.current === expansionKey) return;
    setExpandedExtractionIds(defaultExpandedExtractionIds(extractionModel.roots));
    expandedInitializedForDocument.current = expansionKey;
  }, [blocks.length, document.document_id, extractionModel.roots]);

  useEffect(() => {
    if (activeExtractionNodeId && visibleExtractionNodes.some((node) => node.id === activeExtractionNodeId)) return;
    const nextNode = visibleExtractionNodes.find((node) => node.kind !== "document") || extractionModel.roots[0];
    if (nextNode) {
      setActiveExtractionNodeId(nextNode.id);
      setActiveSourceIds(nextNode.sourceBlockIds);
    }
  }, [activeExtractionNodeId, extractionModel, visibleExtractionNodes]);

  useEffect(() => {
    if (!activeExtractionNode) return;
    const signalCount = activeExtractionNode.attentionSignals.length;
    setLiveMessage(
      `Selected extraction row ${activeExtractionNode.label}. ${activeExtractionNode.isLocated ? "Source located" : "Source unlocated"}. ${signalCount} extraction signals.`,
    );
  }, [activeExtractionNode]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (isTypingTarget(event.target)) return;
      if (!state || !selectedTopic) return;
      const key = event.key.toLowerCase();
      if (key === "n") {
        event.preventDefault();
        selectNextAttentionTopic();
      } else if (event.key === "?") {
        event.preventDefault();
        setShortcutsOpen(true);
      } else if (key === "z" && event.shiftKey) {
        event.preventDefault();
        redo();
      } else if (key === "z") {
        event.preventDefault();
        undo();
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  });

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 1800);
  }

  function commitOp(op: WorkbenchOp, message: string) {
    if (!state) return;
    try {
      applyWorkbenchOp(state, op);
      setOps((current) => [...current, op]);
      setUndoneOps([]);
      showToast(message);
    } catch (err) {
      showToast((err as Error).message);
    }
  }

  function mergeSelected() {
    if (!selectedTopic || selectedUnitIds.length < 2) return;
    commitOp(
      {
        kind: "merge_units",
        op_id: newOpId(),
        topic_id: selectedTopic.topic_id,
        unit_ids: selectedUnitIds,
      },
      "Units merged",
    );
    setSelectedUnitIds([]);
  }

  function openSplit() {
    if (!selectedTopic || selectedUnitIds.length !== 1) return;
    const unit = selectedTopic.units.find((item) => item.unit_id === selectedUnitIds[0]);
    if (!unit) return;
    setSplitUnitId(unit.unit_id);
    setSplitOffset(Math.max(1, Math.floor(unit.text.length / 2)));
    window.requestAnimationFrame(() => splitTextRef.current?.focus());
  }

  function splitSelected() {
    if (!selectedTopic || !splitUnitId) return;
    commitOp(
      {
        kind: "split_unit",
        op_id: newOpId(),
        topic_id: selectedTopic.topic_id,
        unit_id: splitUnitId,
        offset: splitOffset,
      },
      "Unit split",
    );
    setSplitUnitId("");
    setSelectedUnitIds([]);
  }

  function moveSelected() {
    if (!selectedTopic || !moveTargetTopicId || selectedUnitIds.length === 0) return;
    commitOp(
      {
        kind: "move_units",
        op_id: newOpId(),
        from_topic_id: selectedTopic.topic_id,
        to_topic_id: moveTargetTopicId,
        unit_ids: selectedUnitIds,
      },
      "Units moved",
    );
    setSelectedTopicId(moveTargetTopicId);
    setSelectedUnitIds([]);
  }

  function undo() {
    setOps((current) => {
      if (current.length === 0) return current;
      const next = current.slice(0, -1);
      const last = current[current.length - 1]!;
      setUndoneOps((undone) => [last, ...undone]);
      showToast("Undo");
      return next;
    });
  }

  function redo() {
    setUndoneOps((current) => {
      if (current.length === 0) return current;
      const [first, ...rest] = current;
      setOps((applied) => [...applied, first!]);
      showToast("Redo");
      return rest;
    });
  }

  function resetDraft() {
    setOps([]);
    setUndoneOps([]);
    setReviewed({});
    setSelectedUnitIds([]);
    setAttentionFilter("all");
    clearWorkbenchStorage(document.document_id);
    showToast("Draft reset");
  }

  function activateExtractionNode(node: ExtractionNode, options: { revealSource?: boolean; revealTree?: boolean } = {}) {
    setActiveExtractionNodeId(node.id);
    setPreviewSourceIds([]);
    setMoveTargetTopicId("");
    const ancestors = extractionModel.ancestorIds.get(node.id) || [];
    if (ancestors.length > 0) {
      setExpandedExtractionIds((current) => new Set([...current, ...ancestors]));
    }
    setSelectedUnitIds([]);
    setActiveSourceIds(node.sourceBlockIds);
    if (options.revealTree) setTreeRevealNonce((value) => value + 1);
    if (options.revealSource !== false) revealSourceIds(node.sourceBlockIds);
  }

  function previewExtractionNode(node: ExtractionNode) {
    if (node.sourceBlockIds.length > 0) setPreviewSourceIds(node.sourceBlockIds);
  }

  function toggleExtractionExpanded(nodeId: string) {
    setExpandedExtractionIds((current) => {
      const next = new Set(current);
      if (next.has(nodeId)) next.delete(nodeId);
      else next.add(nodeId);
      return next;
    });
  }

  function navigateExtractionRows(key: ExtractionNavigationKey) {
    if (visibleExtractionNodes.length === 0) return;
    const result = navigateExtractionTree({
      visibleNodes: visibleExtractionNodes,
      nodeById: extractionModel.nodeById,
      expandedIds: expandedExtractionIds,
      activeId: activeExtractionNodeId,
      key,
    });
    setExpandedExtractionIds(result.expandedIds);
    const node = extractionModel.nodeById.get(result.activeId);
    if (node) activateExtractionNode(node, { revealTree: true });
  }

  function selectTopic(topicId: string, options: { focusTitle?: boolean } = {}) {
    setSelectedTopicId(topicId);
    setSelectedUnitIds([]);
    setMoveTargetTopicId("");
    const topic = state?.topics.find((item) => item.topic_id === topicId);
    if (topic) {
      setActiveSourceIds(topic.units[0]?.source_block_ids || topic.source_block_ids.slice(0, 1));
      revealSourceIds(topic.units[0]?.source_block_ids || topic.source_block_ids.slice(0, 1));
    }
    if (options.focusTitle) window.requestAnimationFrame(() => titleInputRef.current?.focus());
  }

  function selectAdjacentTopic(direction: 1 | -1) {
    if (!state || state.topics.length === 0) return;
    const currentIndex = Math.max(0, state.topics.findIndex((topic) => topic.topic_id === selectedTopic?.topic_id));
    const nextTopic = state.topics[(currentIndex + direction + state.topics.length) % state.topics.length];
    if (nextTopic) selectTopic(nextTopic.topic_id, { focusTitle: true });
  }

  function selectNextAttentionTopic() {
    const attentionNodes = visibleExtractionNodes.filter((node) => node.attentionSignals.length > 0);
    if (attentionNodes.length === 0) {
      showToast("No extraction attention items");
      return;
    }
    const currentIndex = attentionNodes.findIndex((node) => node.id === activeExtractionNodeId);
    const nextNode = attentionNodes[(currentIndex + 1 + attentionNodes.length) % attentionNodes.length]!;
    activateExtractionNode(nextNode, { revealTree: true });
  }

  function focusReviewFlags() {
    const node = (extractionModel.firstAttentionNodeId && extractionModel.nodeById.get(extractionModel.firstAttentionNodeId))
      || extractionModel.allNodes.find((item) => item.block && item.attentionSignals.length > 0);
    if (!node) {
      showToast("No extraction attention items");
      return;
    }
    setAttentionOnly(true);
    setMatchFailuresOnly(false);
    activateExtractionNode(node);
  }

  function markSelectedTopicReviewed() {
    if (!selectedTopic) return;
    setReviewed((current) => ({
      ...current,
      [selectedTopic.topic_id]: {
        reviewed_at: new Date().toISOString(),
        hash: topicContentHash(selectedTopic),
      },
    }));
    showToast("Topic marked reviewed");
  }

  function handlePrimaryAction() {
    if (!selectedTopic || !nextAction) return;
    if (nextAction.kind === "mark_reviewed") {
      markSelectedTopicReviewed();
      return;
    }
    if (nextAction.kind === "advance_topic") {
      selectAdjacentTopic(1);
      return;
    }
    const issue = selectedSummary?.issues[0];
    if (issue) {
      revealIssue(issue);
      return;
    }
    const firstUnit = selectedTopic.units[0];
    if (firstUnit) {
      setSelectedUnitIds([firstUnit.unit_id]);
      setActiveSourceIds(firstUnit.source_block_ids);
      revealSourceIds(firstUnit.source_block_ids);
    }
  }

  function revealIssue(issue: WorkbenchIssue) {
    setActiveSourceIds(issue.source_block_ids);
    if (issue.topic_id) setSelectedTopicId(issue.topic_id);
    if (state && issue.source_block_ids.length > 0) {
      const units = findUnitsForSourceIds(state, issue.source_block_ids);
      if (units.length > 0) setSelectedUnitIds([units[0]!.unit_id]);
      const nodeId = issue.source_block_ids.flatMap((sourceId) => {
        const id = extractionModel.sourceBlockToNodeId.get(sourceId);
        return id ? [id] : [];
      })[0];
      const node = nodeId ? extractionModel.nodeById.get(nodeId) : null;
      if (node) {
        setActiveExtractionNodeId(node.id);
        setExpandedExtractionIds((current) => new Set([...current, ...(extractionModel.ancestorIds.get(node.id) || [])]));
        if (syncScrolling) setTreeRevealNonce((value) => value + 1);
      }
    }
    revealSourceIds(issue.source_block_ids);
  }

  function selectSourceBlock(blockId: string) {
    const nodeId = extractionModel.sourceBlockToNodeId.get(blockId);
    const node = nodeId ? extractionModel.nodeById.get(nodeId) : null;
    if (node) {
      activateExtractionNode(node, { revealSource: false, revealTree: syncScrolling });
      return;
    }

    setActiveSourceIds([blockId]);
  }

  function revealSourceIds(sourceIds: string[]) {
    if (!syncScrolling) return;
    window.requestAnimationFrame(() => {
      const first = sourceIds.find((blockId) => sourceRefs.current.has(blockId));
      if (first) {
        sourceRefs.current.get(first)?.scrollIntoView({ block: "center", behavior: prefersReducedMotion ? "auto" : "smooth" });
      }
    });
  }

  if (loading) {
    return (
      <section className="workbench-shell">
        <div className="source-skeleton">
          <span />
          <span />
          <span />
          <span />
        </div>
      </section>
    );
  }

  if (loadError || !state || !plan || !coverage) {
    return <div className="error-banner">Could not load Workbench: {loadError || "missing extraction data"}</div>;
  }

  const selectedSplitUnit = selectedTopic?.units.find((unit) => unit.unit_id === splitUnitId) || null;
  const selectedSplitCandidate =
    selectedTopic && selectedUnitIds.length === 1
      ? selectedTopic.units.find((unit) => unit.unit_id === selectedUnitIds[0])
      : null;
  const canOpenSplit = Boolean(
    selectedSplitCandidate &&
      !selectedSplitCandidate.is_virtual &&
      selectedSplitCandidate.source_block_ids.length === 1 &&
      selectedSplitCandidate.text.trim().length > 1,
  );
  const mergeAllowed = selectedTopic ? canMergeUnits(state, selectedTopic.topic_id, selectedUnitIds) : false;
  const splitAllowed =
    selectedTopic && selectedUnitIds.length === 1
      ? canSplitUnit(state, selectedTopic.topic_id, selectedUnitIds[0]!, splitOffset)
      : false;

  return (
    <section
      className="workbench-shell"
      aria-label="Evidence Workbench"
      onKeyDown={(event) => handleWorkbenchKeyDown(event)}
    >
      {(ops.length > 0 || undoneOps.length > 0) && (
        <div className="workbench-draft-toolbar" aria-label="Draft changes">
          <span>{ops.length} draft {ops.length === 1 ? "operation" : "operations"}</span>
          <div className="workbench-actions">
            <button type="button" onClick={undo} disabled={ops.length === 0} title="Undo">
              <Undo2 size={14} /> Undo
            </button>
            <button type="button" onClick={redo} disabled={undoneOps.length === 0} title="Redo">
              <Redo2 size={14} /> Redo
            </button>
            <button type="button" onClick={resetDraft} disabled={ops.length === 0 && undoneOps.length === 0}>
              <RotateCcw size={14} /> Reset draft
            </button>
          </div>
        </div>
      )}
      <div className="sr-only" aria-live="polite">{liveMessage}</div>

      <div className="workbench-grid" ref={overlayRef}>
        <RelationshipOverlay
          connectors={connectors}
          anchors={numberedAnchors}
          spotlightRects={spotlightRects}
          reducedMotion={Boolean(prefersReducedMotion)}
        />
        <SourceEvidenceViewer
          document={document}
          blocks={blocks}
          query={sourceQuery}
          attentionOnly={attentionOnly}
          attentionSourceIds={attentionSourceIds}
          activeSourceIds={visibleSourceIds}
          selectedSourceIds={selectedExtractionSourceIds}
          previewSourceIds={previewSourceIds}
          spotlightSourceIds={spotlightSourceIds}
          evidenceNumbers={[]}
          onQueryChange={setSourceQuery}
          onAttentionOnlyChange={setAttentionOnly}
          syncScrolling={syncScrolling}
          onSyncScrollingChange={setSyncScrolling}
          onHoverBlock={(blockId) => setPreviewSourceIds([blockId])}
          onClearHover={() => setPreviewSourceIds([])}
          onSelectBlock={selectSourceBlock}
          onMatchFailuresChange={setMatchFailureSourceIds}
          setBlockRef={setBlockRef}
        />
        <ExtractionExplorerPane
          model={extractionModel}
          visibleNodes={visibleExtractionNodes}
          expandedNodeIds={expandedExtractionIds}
          activeNodeId={activeExtractionNodeId}
          onSelectNode={activateExtractionNode}
          onPreviewNode={previewExtractionNode}
          onClearPreview={() => setPreviewSourceIds([])}
          onToggleExpanded={toggleExtractionExpanded}
          onNavigate={navigateExtractionRows}
          revealNonce={treeRevealNonce}
          onOpenShortcuts={() => setShortcutsOpen(true)}
          attentionOnly={attentionOnly}
          matchFailuresOnly={matchFailuresOnly}
          onShowMatchFailuresOnly={() => setMatchFailuresOnly(true)}
          onClearMatchFailuresOnly={() => setMatchFailuresOnly(false)}
          query={sourceQuery}
          onClearQuery={() => setSourceQuery("")}
          onFocusReviewFlags={focusReviewFlags}
        />
      </div>

      <AnimatePresence>
        {selectedSplitUnit && selectedTopic && (
          <motion.div
            className="split-drawer"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.16 }}
          >
            <header>
              <div>
                <strong>Split unit</strong>
                <span>{selectedSplitUnit.source_block_ids.join(", ")}</span>
              </div>
              <button type="button" onClick={() => setSplitUnitId("")}>Cancel</button>
            </header>
            <textarea
              ref={splitTextRef}
              defaultValue={selectedSplitUnit.text}
              onClick={(event) => setSplitOffset(event.currentTarget.selectionStart)}
              onKeyUp={(event) => setSplitOffset(event.currentTarget.selectionStart)}
              spellCheck={false}
            />
            <footer>
              <span>Cursor offset {splitOffset}</span>
              <button type="button" className="btn-primary" disabled={!splitAllowed} onClick={splitSelected}>
                <Scissors size={14} /> Split at cursor
              </button>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {shortcutsOpen && (
          <motion.div
            className="shortcut-sheet"
            role="dialog"
            aria-modal="true"
            aria-label="Workbench keyboard shortcuts"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.16 }}
          >
            <header>
              <strong>Keyboard shortcuts</strong>
              <button type="button" onClick={() => setShortcutsOpen(false)}>Close</button>
            </header>
            <dl>
              <div><dt>Up / Down</dt><dd>Previous or next visible extraction row</dd></div>
              <div><dt>Right / Left</dt><dd>Enter or exit extraction groups</dd></div>
              <div><dt>N</dt><dd>Next extraction attention item</dd></div>
              <div><dt>Z / Shift Z</dt><dd>Undo or redo</dd></div>
            </dl>
          </motion.div>
        )}
      </AnimatePresence>

      {toast && <div className="source-toast" role="status">{toast}</div>}
    </section>
  );
}

function RelationshipOverlay({
  connectors,
  anchors,
  spotlightRects,
  reducedMotion,
}: {
  connectors: Connector[];
  anchors: NumberedAnchor[];
  spotlightRects: SpotlightRect[] | null;
  reducedMotion: boolean;
}) {
  return (
    <div className="relationship-overlay" aria-hidden>
      <SourceSpotlight anchors={anchors} spotlightRects={spotlightRects} reducedMotion={reducedMotion} />
      <svg className="relationship-svg">
        {connectors.map((connector) => (
          <motion.path
            key={connector.id}
            d={connector.d}
            className={`relationship-path ${connector.tone}`}
            initial={reducedMotion ? false : { pathLength: 0, opacity: 0 }}
            animate={reducedMotion ? { opacity: 1 } : { pathLength: 1, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.18 }}
          />
        ))}
      </svg>
    </div>
  );
}

function findUnitsForSourceIds(state: WorkbenchState, sourceIds: string[]) {
  if (sourceIds.length === 0) return [];
  return state.topics.flatMap((topic) =>
    topic.units.filter((unit) => unit.source_block_ids.some((blockId) => sourceIds.includes(blockId))),
  );
}

function newOpId() {
  return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function isTypingTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  return ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName) || target.isContentEditable;
}

function handleWorkbenchKeyDown(event: ReactKeyboardEvent<HTMLElement>) {
  if (event.key === "Enter" && event.target instanceof HTMLElement && event.target.classList.contains("source-viewer-anchor")) {
    event.preventDefault();
    event.target.click();
  }
}
