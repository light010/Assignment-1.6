import { describe, expect, it } from "vitest";
import {
  buildNumberedAnchors,
  buildSpotlightRects,
  pickEvidenceScrollTarget,
  unitSourceIdMap,
} from "./workbenchGeometry";

describe("workbenchGeometry", () => {
  it("emits numbered source and extracted anchors from evidence numbering", () => {
    const anchors = buildNumberedAnchors({
      overlayRect: rect(100, 20, 900, 800),
      sourceRects: new Map([
        ["block_a", rect(120, 30, 230, 40)],
        ["block_b", rect(200, 30, 260, 30)],
      ]),
      unitRects: new Map([
        ["unit_a", rect(140, 500, 780, 24)],
        ["unit_b", rect(220, 500, 780, 24)],
      ]),
      unitSourceIds: unitSourceIdMap([
        { unit_id: "unit_a", source_block_ids: ["block_a"] },
        { unit_id: "unit_b", source_block_ids: ["block_b"] },
      ]),
      evidenceNumbers: [
        { source_block_id: "block_b", evidence_number: 1 },
        { source_block_id: "block_a", evidence_number: 2 },
      ],
    });

    expect(anchors.map((anchor) => `${anchor.side}:${anchor.evidenceNumber}:${anchor.sourceBlockId}`)).toEqual([
      "extract:1:block_b",
      "source:1:block_b",
      "extract:2:block_a",
      "source:2:block_a",
    ]);
    expect(anchors.find((anchor) => anchor.id === "source:block_a")?.point).toEqual({ x: 210, y: 40 });
    expect(anchors.find((anchor) => anchor.id === "extract:unit_a:block_a")?.point).toEqual({ x: 480, y: 52 });
  });

  it("returns null spotlight geometry until source anchors are rendered", () => {
    expect(buildSpotlightRects({
      overlayRect: rect(0, 0, 1000, 800),
      sourceRects: new Map(),
      sourceBlockIds: ["block_missing"],
    })).toBeNull();
  });

  it("builds sorted spotlight rects for non-contiguous source evidence", () => {
    const spotlight = buildSpotlightRects({
      overlayRect: rect(100, 20, 1000, 800),
      sourceRects: new Map([
        ["block_b", rect(340, 50, 300, 28)],
        ["block_a", rect(140, 40, 260, 32)],
      ]),
      sourceBlockIds: ["block_b", "block_a"],
    });

    expect(spotlight).toEqual([
      { id: "spotlight:block_a", sourceBlockId: "block_a", x: 20, y: 40, width: 220, height: 32 },
      { id: "spotlight:block_b", sourceBlockId: "block_b", x: 30, y: 240, width: 250, height: 28 },
    ]);
  });

  it("routes DOCX/text/html scrolling to elements and PDF scrolling to pages", () => {
    const located = new Set(["block_a", "block_b"]);
    expect(pickEvidenceScrollTarget({
      format: "docx",
      sourceBlockIds: ["missing", "block_a"],
      locatedBlockIds: located,
    })).toEqual({ kind: "element", blockId: "block_a" });

    expect(pickEvidenceScrollTarget({
      format: "pdf",
      sourceBlockIds: ["block_b"],
      locatedBlockIds: located,
      blockPages: new Map([["block_b", 4]]),
    })).toEqual({ kind: "pdf_page", blockId: "block_b", page: 4 });

    expect(pickEvidenceScrollTarget({
      format: "pdf",
      sourceBlockIds: ["block_b"],
      locatedBlockIds: located,
      blockPages: new Map(),
    })).toEqual({ kind: "none" });
  });

  it("keeps synthetic 100-topic geometry recompute under the frame budget", () => {
    const sourceRects = new Map<string, ReturnType<typeof rect>>();
    const unitRects = new Map<string, ReturnType<typeof rect>>();
    const unitSourceIds = new Map<string, string[]>();
    const evidenceNumbers = [];
    for (let index = 0; index < 100; index += 1) {
      const blockId = `block_${index}`;
      const unitId = `unit_${index}`;
      sourceRects.set(blockId, rect(index * 12, 20, 360, 10));
      unitRects.set(unitId, rect(index * 12, 640, 920, 10));
      unitSourceIds.set(unitId, [blockId]);
      evidenceNumbers.push({ source_block_id: blockId, evidence_number: index + 1 });
    }

    const start = performance.now();
    const anchors = buildNumberedAnchors({
      overlayRect: rect(0, 0, 1000, 900),
      sourceRects,
      unitRects,
      unitSourceIds,
      evidenceNumbers,
    });
    const spotlight = buildSpotlightRects({
      overlayRect: rect(0, 0, 1000, 900),
      sourceRects,
      sourceBlockIds: evidenceNumbers.map((item) => item.source_block_id),
    });
    const elapsed = performance.now() - start;

    expect(anchors).toHaveLength(200);
    expect(spotlight).toHaveLength(100);
    expect(elapsed).toBeLessThan(16);
  });
});

function rect(top: number, left: number, right: number, height: number) {
  return { top, left, right, height, width: right - left };
}
