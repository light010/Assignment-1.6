import { Activity, AlertTriangle, CheckCircle2, Clipboard, Code2, Database, Download, MoreHorizontal } from "lucide-react";
import { LayoutGroup, motion } from "framer-motion";
import { ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { WorkbenchPanel } from "./WorkbenchPanel";
import { api, ArtifactEntry, DocumentRecord, exportDownloadUrl, ExtractionReviewSummary, getAllDocumentBlocks, getDocumentExtractionReviewSummary, JobRecord, SourceBlock, TopicRecord, User } from "./api";
import { type Panel } from "./appTypes";
import { ExtractionFailedPanel, ExtractionNeedsReviewPanel } from "./ExtractionReviewBanner";
import { formatBytes, humanizeStatus, plural, thresholdQualityLabel } from "./formatters";

type TopicCandidate = {
  topic_candidate_id: string;
  title: string;
  topic_type: string;
  boundary_confidence: number;
  reason: string;
};

type TopicPlanDocument = {
  document_id: string;
  filename: string;
  approved: boolean;
  topic_plan: { topic_candidates: TopicCandidate[] };
};

type ExportRecord = {
  export_id: string;
  topic_count: number;
  status: string;
};

export function DocumentDetail({
  document,
  user,
  activeTopicId,
  setActiveTopicId,
  activePanel,
  tabEnablement,
  setPanel,
  refreshDocuments,
  onDisabledTab,
}: {
  document: DocumentRecord;
  user: User;
  activeTopicId: string;
  setActiveTopicId: (topicId: string) => void;
  activePanel: Panel;
  tabEnablement: Record<Panel, boolean> | null;
  setPanel: (panel: Panel) => void;
  refreshDocuments: () => Promise<void>;
  onDisabledTab: (message: string) => void;
}) {
  const blockCount = document.extraction?.block_count
    || (document.source_quality as { block_count?: number } | undefined)?.block_count
    || 0;
  const gate = document.source_quality.quality_gate || null;
  const gateBlocked = Boolean(gate && gate.passed === false);
  const qualityText = gateBlocked
    ? `${plural(gate?.blocking_reasons.length || 1, "blocking reason")} · Re-extract or override required`
    : thresholdQualityLabel(document.source_quality.overall_confidence);
  return (
    <section className="document-detail" aria-label={`Document detail for ${document.filename}`}>
              {/*
                From-scratch header inspired by Linear's ticket detail and
                Stripe's payment view. Three pieces stacked tightly: H1
                filename, single meta line with status dot, and overflow
                chips for the demoted observability surfaces (Artifacts /
                Jobs). The chain-of-dots stepper is gone — the status dot
                in the meta already encodes the current stage and the
                lifecycle tabs below carry the progression. Two indicators
                for the same thing was visual noise.
              */}
              <header className="document-detail-head">
                <div className="document-detail-headline">
                  <h1 title={document.filename}>{document.filename}</h1>
                  <p className="document-detail-meta">
                    <span
                      className={`status-dot status-${stageGroupForStatus(document.status)}`}
                      aria-hidden
                    />
                    <span>{humanizeStatus(document.status)}</span>
                    <span className="meta-sep" aria-hidden>·</span>
                    <span>{blockCount > 0 ? plural(blockCount, "source block") : "Source blocks pending"}</span>
                    <span className="meta-sep" aria-hidden>·</span>
                    <span
                      className={`quality-gate-copy ${gateBlocked ? "is-blocked" : document.source_quality.overall_confidence >= 0.72 ? "is-ok" : "is-warn"}`}
                      title={`${Math.round(document.source_quality.overall_confidence * 100)}% quality`}
                    >
                      {qualityText}
                    </span>
                  </p>
                </div>
                <details className="document-detail-more">
                  <summary aria-label="More document tools" title="More document tools">
                    <MoreHorizontal size={16} aria-hidden />
                  </summary>
                  <div className="document-detail-menu">
                    <button
                      type="button"
                      className={activePanel === "jobs" ? "is-active" : ""}
                      onClick={() => setPanel("jobs")}
                    >
                      <Activity size={13} aria-hidden />
                      <span>Jobs</span>
                    </button>
                    <button
                      type="button"
                      className={activePanel === "artifacts" ? "is-active" : ""}
                      onClick={() => setPanel("artifacts")}
                    >
                      <Database size={13} aria-hidden />
                      <span>Artifacts</span>
                    </button>
                  </div>
                </details>
              </header>
    
              {/*
                Lifecycle tabs now start at Workbench because the source
                evidence viewer lives inside Workbench. Source is no longer
                a separate top-level destination.
              */}
              <div className="document-tab-row">
                <LayoutGroup id="lifecycle-tab-rail">
                  <nav className="lifecycle-tabs" role="tablist" aria-label="Document lifecycle">
                    {(
                      [
                        { key: "workbench" as Panel, label: "Workbench", number: 1 },
                        { key: "topic-plan" as Panel, label: "Plan", number: 2 },
                        { key: "review" as Panel, label: "Review", number: 3 },
                        { key: "export" as Panel, label: "Export", number: 4 },
                      ]
                    ).map((tab, index) => {
                      const isActive = activePanel === tab.key;
                      const isEnabled = tabEnablement?.[tab.key] ?? true;
                      const disabledReason = isEnabled || !document ? undefined : disabledTabReason(document);
                      const stepState = !isEnabled ? "blocked" : isActive ? "current" : index < selectedTabIndex(activePanel) ? "complete" : "pending";
                      return (
                        <button
                          key={tab.key}
                          role="tab"
                          type="button"
                          aria-selected={isActive}
                          aria-disabled={!isEnabled}
                          aria-current={isActive ? "step" : undefined}
                          title={disabledReason}
                          className={`lifecycle-tab state-${stepState}${isActive ? " is-active" : ""}${!isEnabled ? " is-disabled" : ""}`}
                          onClick={() => {
                            if (isEnabled) {
                              setPanel(tab.key);
                              return;
                            }
                            // H4: replace the silent ignore-click behavior
                            // (audit #617 finding) with a toast so the user
                            // knows the tab IS disabled and WHY. Without this
                            // a click on a disabled tab looked like a UI bug.
                            onDisabledTab(`${disabledReason || "Extraction needs review"} — resolve before opening ${tab.label}.`);
                          }}
                        >
                          <span className="tab-step-marker" aria-hidden>
                            {stepState === "complete" ? "✓" : tab.number}
                          </span>
                          <span>{tab.label}</span>
                          {!isEnabled && <small>Blocked</small>}
                          {isActive && (
                            <motion.span
                              className="lifecycle-tab-rail"
                              layoutId="lifecycle-tab-rail"
                              aria-hidden="true"
                              transition={{ type: "spring", stiffness: 520, damping: 38, mass: 0.7 }}
                            />
                          )}
                        </button>
                      );
                    })}
                  </nav>
                </LayoutGroup>
              </div>
              <PanelView
                panel={activePanel}
                document={document}
                user={user}
                activeTopicId={activeTopicId}
                setActiveTopicId={setActiveTopicId}
                refreshDocuments={refreshDocuments}
                onToast={onDisabledTab}
              />
            </section>
  );
}

function disabledTabReason(document: DocumentRecord): string {
  const status = (document.status || "").toLowerCase();
  if (status === "failed_extraction") {
    return "Extraction failed - re-extract before opening this tab";
  }
  return "Extraction gated - resolve blocking reasons before opening this tab";
}

function stageGroupForStatus(status: string): "ok" | "warn" | "fail" | "active" {
  const s = (status || "").toLowerCase();
  if (s.includes("fail") || s === "rejected") return "fail";
  if (s === "validation_warnings" || s === "extraction_needs_review") return "warn";
  if (s === "approved" || s === "export_ready" || s === "ready_for_review" || s === "review_ready") {
    return "ok";
  }
  return "active";
}

function selectedTabIndex(panel: Panel) {
  const order: Panel[] = ["workbench", "topic-plan", "review", "export"];
  const index = order.indexOf(panel);
  return index === -1 ? 0 : index;
}

function PanelView({
  panel,
  document,
  user,
  activeTopicId,
  setActiveTopicId,
  refreshDocuments,
  onToast,
}: {
  panel: Panel;
  document: DocumentRecord;
  user: User;
  activeTopicId: string;
  setActiveTopicId: (topicId: string) => void;
  refreshDocuments: () => Promise<void>;
  onToast: (message: string) => void;
}) {
  if (panel === "artifacts") return <ArtifactRegistryPanel document={document} />;
  if (panel === "jobs") return <JobTimelinePanel document={document} />;
  if (panel === "workbench" || panel === "source") {
    if (isExtractionBlocked(document) || isExtractionFailed(document)) {
      return (
        <WorkbenchUnavailablePanel
          document={document}
          user={user}
          refreshDocuments={refreshDocuments}
          onToast={onToast}
        />
      );
    }
    return <WorkbenchPanel document={document} />;
  }
  if (panel === "topic-plan") return <TopicPlanPanel document={document} />;
  if (panel === "review") {
    return (
      <ReviewPanel
        document={document}
        activeTopicId={activeTopicId}
        setActiveTopicId={setActiveTopicId}
        refreshDocuments={refreshDocuments}
      />
    );
  }
  if (panel === "export") return <ExportPanel document={document} />;
  return <WorkbenchPanel document={document} />;
}

function isExtractionFailed(document: DocumentRecord): boolean {
  return (document.status || "").toLowerCase() === "failed_extraction";
}

function isExtractionBlocked(document: DocumentRecord): boolean {
  const status = (document.status || "").toLowerCase();
  return status === "extraction_needs_review" || document.source_quality?.quality_gate?.passed === false;
}

function WorkbenchUnavailablePanel({
  document,
  user,
  refreshDocuments,
  onToast,
}: {
  document: DocumentRecord;
  user: User;
  refreshDocuments: () => Promise<void>;
  onToast: (message: string) => void;
}) {
  const [summary, setSummary] = useState<ExtractionReviewSummary | null>(null);
  const [sourceBlocks, setSourceBlocks] = useState<SourceBlock[]>([]);
  const [blockTextById, setBlockTextById] = useState<Map<string, string>>(new Map());

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      getDocumentExtractionReviewSummary(document.document_id).catch(() => null),
      getAllDocumentBlocks(document.document_id).catch(() => ({ items: [] as SourceBlock[] })),
    ])
      .then(([result, blockResult]) => {
        if (cancelled) return;
        setSummary(result);
        setSourceBlocks(blockResult.items);
        setBlockTextById(new Map(blockResult.items.map((block) => [block.block_id, block.text] as const)));
      })
      .catch(() => {
        if (!cancelled) {
          setSummary(null);
          setSourceBlocks([]);
          setBlockTextById(new Map());
        }
      });
    return () => {
      cancelled = true;
    };
  }, [document.document_id]);

  return (
    <section className="panel workbench-unavailable-panel" aria-label="Workbench unavailable">
      {isExtractionFailed(document) ? (
        <ExtractionFailedPanel
          document={document}
          summary={summary}
          user={user}
          refreshDocuments={refreshDocuments}
          onToast={onToast}
        />
      ) : (
        <ExtractionNeedsReviewPanel
          document={document}
          summary={summary}
          gate={summary?.gate || document.source_quality?.quality_gate || null}
          sourceBlocks={sourceBlocks}
          user={user}
          refreshDocuments={refreshDocuments}
          onToast={onToast}
          blockTextById={blockTextById}
        />
      )}
    </section>
  );
}

function ArtifactRegistryPanel({ document }: { document: DocumentRecord }) {
  const [registry, setRegistry] = useState<ArtifactEntry[]>([]);
  const [copiedHash, setCopiedHash] = useState("");

  useEffect(() => {
    api<{ artifacts?: ArtifactEntry[] | Record<string, ArtifactEntry>; registry?: ArtifactEntry[] }>(
      `/v1/documents/${document.document_id}/artifacts`,
    )
      .then((result) => {
        if (Array.isArray(result.registry)) {
          setRegistry(result.registry);
        } else if (Array.isArray(result.artifacts)) {
          setRegistry(result.artifacts);
        } else {
          setRegistry(Object.values(result.artifacts || {}));
        }
      })
      .catch(console.error);
  }, [document.document_id]);

  return (
    <section className="panel">
      <div className="panel-toolbar">
        <h2>Artifact Registry</h2>
        <Database size={18} />
      </div>
      {registry.length === 0 ? (
        <p className="empty">No artifact rows found.</p>
      ) : (
        <div className="artifact-table">
          <div className="artifact-header">
            <span>Name</span>
            <span>Version</span>
            <span>Producer</span>
            <span>Type</span>
            <span>Size</span>
            <span>Hash</span>
            <span>Path</span>
          </div>
          {registry.map((artifact) => (
            <div className="artifact-row" key={artifact.artifact_id}>
              <strong>{artifact.name}</strong>
              <code>{artifact.artifact_version}</code>
              <span>{artifact.producer || "unknown"}</span>
              <span>{artifact.content_type}</span>
              <span>{formatBytes(artifact.size_bytes)}</span>
              <span className="artifact-hash">
                <code>{artifact.hash}</code>
                <button
                  type="button"
                  aria-label={`Copy hash for ${artifact.name}`}
                  title={copiedHash === artifact.hash ? "Copied" : "Copy full hash"}
                  onClick={async () => {
                    await navigator.clipboard.writeText(artifact.hash);
                    setCopiedHash(artifact.hash);
                    window.setTimeout(() => setCopiedHash(""), 1600);
                  }}
                >
                  <Clipboard size={13} />
                </button>
              </span>
              <code>{artifact.path}</code>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function JobTimelinePanel({ document }: { document: DocumentRecord }) {
  const [jobs, setJobs] = useState<JobRecord[]>([]);

  useEffect(() => {
    api<{ jobs: JobRecord[] }>(`/v1/documents/${document.document_id}/jobs`)
      .then((result) => setJobs(result.jobs))
      .catch(console.error);
  }, [document.document_id]);

  return (
    <section className="panel">
      <div className="panel-toolbar">
        <h2>Job Timeline</h2>
        <Activity size={18} />
      </div>
      {jobs.length === 0 && <p className="empty">No jobs recorded for this document.</p>}
      {jobs.map((job) => (
        <article className="job-card" key={job.job_id}>
          <header>
            <strong>{job.stage}</strong>
            <span>{job.status}</span>
          </header>
          <ol>
            {job.events.map((event) => (
              <li key={event}>{event}</li>
            ))}
          </ol>
        </article>
      ))}
    </section>
  );
}

function TopicPlanPanel({ document }: { document: DocumentRecord }) {
  const [plan, setPlan] = useState<TopicPlanDocument | null>(null);

  useEffect(() => {
    api<TopicPlanDocument>(`/v1/documents/${document.document_id}/topic-plan`)
      .then((result) => setPlan(result))
      .catch(console.error);
  }, [document.document_id]);

  async function approve() {
    await api(`/v1/documents/${document.document_id}/topic-plan/approve`, { method: "POST" });
    const result = await api<TopicPlanDocument>(`/v1/documents/${document.document_id}/topic-plan`);
    setPlan(result);
  }

  return (
    <section className="panel">
      <div className="panel-toolbar">
        <h2>Topic Plan</h2>
        <span className="badge-count">{plural(document.topic_ids.length, "topic")}</span>
        <button onClick={approve}>
          <CheckCircle2 size={16} /> Approve Plan
        </button>
      </div>
      {plan && (
        <div key={plan.document_id} className="topic-plan">
          <h3>{plan.filename}</h3>
          <small>{plan.approved ? "approved" : "waiting for approval"}</small>
          {plan.topic_plan.topic_candidates.map((candidate) => (
            <article key={candidate.topic_candidate_id}>
              <strong>{candidate.title}</strong>
              <span>{candidate.topic_type}</span>
              <span>{Math.round(candidate.boundary_confidence * 100)}% boundary</span>
              <p>{candidate.reason}</p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function ReviewPanel({
  document,
  activeTopicId,
  setActiveTopicId,
  refreshDocuments,
}: {
  document: DocumentRecord;
  activeTopicId: string;
  setActiveTopicId: (topicId: string) => void;
  refreshDocuments: () => Promise<void>;
}) {
  const [topic, setTopic] = useState<TopicRecord | null>(null);
  const selectedTopicId = activeTopicId || document.topic_ids[0];

  useEffect(() => {
    if (!selectedTopicId) return;
    api<TopicRecord>(`/v1/topics/${selectedTopicId}`)
      .then((result) => {
        setTopic(result);
        setActiveTopicId(result.topic_record_id);
      })
      .catch(console.error);
  }, [selectedTopicId, setActiveTopicId]);

  async function save() {
    if (!topic) return;
    const updated = await api<TopicRecord>(`/v1/topics/${topic.topic_record_id}`, {
      method: "PATCH",
      body: JSON.stringify({ xml: topic.dita_xml, artifact_version: topic.artifact_version }),
    });
    setTopic(updated);
  }

  async function approve() {
    if (!topic) return;
    const updated = await api<TopicRecord>(`/v1/topics/${topic.topic_record_id}/approve`, { method: "POST" });
    setTopic(updated);
    await refreshDocuments();
  }

  if (!topic) {
    return <div className="empty-state compact">No generated topics are available for this document.</div>;
  }

  return (
    <div className="review-grid">
      <section className="panel topic-list-panel">
        <div className="panel-toolbar">
          <h2>Topics</h2>
          <span className="badge-count">{document.topic_ids.length}</span>
        </div>
        {document.topic_ids.map((topicId, index) => {
          const isActive = topicId === topic.topic_record_id;
          return (
            <button
              key={topicId}
              className={isActive ? "topic-button active" : "topic-button"}
              onClick={() => setActiveTopicId(topicId)}
              title={topicId}
            >
              <span className="topic-button-name">Topic {index + 1}</span>
              <code className="topic-button-id">{shortId(topicId)}</code>
            </button>
          );
        })}
      </section>
      <section className="panel editor-panel">
        <div className="panel-toolbar">
          <div>
            <h2>{topic.generated_topic.title}</h2>
            <small>
              {topic.generated_topic.topic_type} · {humanizeStatus(topic.status)}
            </small>
          </div>
          <div>
            <button onClick={save}>Save</button>
            <button className="btn-primary" onClick={approve}>
              <CheckCircle2 size={16} /> Approve
            </button>
          </div>
        </div>
        <TopicXmlEditor
          value={topic.dita_xml}
          issues={topic.validation_issues}
          onChange={(value) => setTopic({ ...topic, dita_xml: value })}
        />
      </section>
      <section className="panel review-side">
        <div className="review-side-section">
          <h3 className="section-heading">Validation</h3>
          {topic.validation_issues.length === 0 ? (
            <div className="ok">
              <CheckCircle2 size={18} /> No validation issues
            </div>
          ) : (
            topic.validation_issues.map((issue) => (
              <article className="issue" key={`${issue.code}-${issue.message}`}>
                <AlertTriangle size={16} />
                <div>
                  <strong>{issue.code}</strong>
                  <p>{issue.message}</p>
                </div>
              </article>
            ))
          )}
        </div>
        <div className="review-side-section">
          <h3 className="section-heading">Traceability</h3>
          {topic.traceability.map((link) => (
            <article className="trace" key={link.target_path}>
              <code className="trace-path">{link.target_path}</code>
              <span className="trace-blocks">{link.source_block_ids.join(", ")}</span>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

function TopicXmlEditor({
  value,
  issues,
  onChange,
}: {
  value: string;
  issues: TopicRecord["validation_issues"];
  onChange: (value: string) => void;
}) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const highlightRef = useRef<HTMLPreElement | null>(null);
  const gutterRef = useRef<HTMLDivElement | null>(null);
  const lines = value.split("\n");
  const lineIssues = useMemo(() => issueMapByLine(issues), [issues]);
  const issueLines = new Set(lineIssues.keys());

  function syncScroll() {
    const textarea = textareaRef.current;
    if (!textarea) return;
    const transform = `translate(${-textarea.scrollLeft}px, ${-textarea.scrollTop}px)`;
    if (highlightRef.current) highlightRef.current.style.transform = transform;
    if (gutterRef.current) gutterRef.current.style.transform = `translateY(${-textarea.scrollTop}px)`;
  }

  function focusLine(line: number) {
    const textarea = textareaRef.current;
    if (!textarea) return;
    const offsets = lineOffsets(value);
    const start = offsets[Math.max(0, line - 1)] || 0;
    const end = offsets[line] ? Math.max(start, offsets[line]! - 1) : value.length;
    textarea.focus();
    textarea.setSelectionRange(start, end);
    textarea.scrollTop = Math.max(0, (line - 1) * 20 - 48);
    syncScroll();
  }

  return (
    <div className="topic-code-editor" aria-label="DITA XML editor">
      <div className="topic-code-editor-head">
        <span><Code2 size={14} aria-hidden /> XML</span>
        <span>{plural(lines.length, "line")}</span>
      </div>
      {issues.length > 0 && (
        <div className="topic-code-issue-strip" aria-label="Inline validation markers">
          {issues.map((issue, index) => {
            const line = issueLine(issue);
            return (
              <button
                key={`${issue.code}-${issue.path || index}`}
                type="button"
                className={`severity-${issue.severity || "warning"}`}
                onClick={() => line && focusLine(line)}
                disabled={!line}
                title={issue.message}
              >
                {line ? `Line ${line}` : "Document"}
                <span>{issue.code}</span>
              </button>
            );
          })}
        </div>
      )}
      <div className="topic-code-editor-body">
        <div className="topic-code-gutter" ref={gutterRef} aria-hidden>
          {lines.map((_line, index) => (
            <span key={index} className={issueLines.has(index + 1) ? "has-issue" : ""}>
              {index + 1}
            </span>
          ))}
        </div>
        <div className="topic-code-stack">
          <pre ref={highlightRef} className="topic-code-highlight" aria-hidden>
            {highlightXml(value)}
          </pre>
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(event) => onChange(event.target.value)}
            onScroll={syncScroll}
            spellCheck={false}
            aria-label="DITA XML source"
          />
        </div>
      </div>
    </div>
  );
}

function issueMapByLine(issues: TopicRecord["validation_issues"]) {
  const byLine = new Map<number, TopicRecord["validation_issues"]>();
  issues.forEach((issue) => {
    const line = issueLine(issue);
    if (!line) return;
    byLine.set(line, [...(byLine.get(line) || []), issue]);
  });
  return byLine;
}

function issueLine(issue: TopicRecord["validation_issues"][number]) {
  const value = issue.path?.match(/:(\d+)(?::\d+)?$/)?.[1] || issue.message.match(/\bline\s+(\d+)\b/i)?.[1];
  return value ? Number(value) : null;
}

function lineOffsets(value: string) {
  const offsets = [0];
  for (let index = 0; index < value.length; index += 1) {
    if (value[index] === "\n") offsets.push(index + 1);
  }
  return offsets;
}

function highlightXml(value: string): ReactNode[] {
  const tokenPattern = /(<!\[CDATA\[[\s\S]*?\]\]>|<!--[\s\S]*?-->|<\/?[A-Za-z_][\w:.-]*(?:\s+[^<>]*?)?\/?>|&[A-Za-z0-9#]+;)/g;
  const parts: ReactNode[] = [];
  let cursor = 0;
  for (const match of value.matchAll(tokenPattern)) {
    const token = match[0];
    const index = match.index || 0;
    if (index > cursor) parts.push(value.slice(cursor, index));
    parts.push(<span key={`${index}-${token}`} className={xmlTokenClass(token)}>{token}</span>);
    cursor = index + token.length;
  }
  if (cursor < value.length) parts.push(value.slice(cursor));
  return parts;
}

function xmlTokenClass(token: string) {
  if (token.startsWith("<!--")) return "xml-token-comment";
  if (token.startsWith("<![CDATA[")) return "xml-token-cdata";
  if (token.startsWith("&")) return "xml-token-entity";
  if (token.startsWith("</")) return "xml-token-close";
  return "xml-token-tag";
}

function shortId(value: string) {
  if (!value) return value;
  if (value.length <= 14) return value;
  return `${value.slice(0, 6)}…${value.slice(-4)}`;
}

function ExportPanel({ document }: { document: DocumentRecord }) {
  const [exports, setExports] = useState<ExportRecord[]>([]);

  async function createExport() {
    const record = await api<ExportRecord>(`/v1/documents/${document.document_id}/exports`, {
      method: "POST",
      body: JSON.stringify({ include_unapproved: true }),
    });
    setExports([record, ...exports]);
  }

  return (
    <section className="panel">
      <div className="panel-toolbar">
        <h2>Export Center</h2>
        <button onClick={createExport}>
          <Download size={16} /> Build DITA ZIP
        </button>
      </div>
      {exports.length === 0 && <p className="empty">No exports created in this session.</p>}
      {exports.map((record) => (
        <article className="export-row" key={record.export_id}>
          <div>
            <strong>{record.export_id}</strong>
            <p>
              {record.topic_count} topics / {record.status}
            </p>
          </div>
          <a href={exportDownloadUrl(record.export_id)} target="_blank" rel="noreferrer">
            Download
          </a>
        </article>
      ))}
    </section>
  );
}
