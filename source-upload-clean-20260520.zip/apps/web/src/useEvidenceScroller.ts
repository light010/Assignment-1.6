import { MutableRefObject, useCallback } from "react";
import {
  EvidenceScrollTarget,
  EvidenceViewerFormat,
  pickEvidenceScrollTarget,
} from "./workbenchGeometry";

export function useEvidenceScroller({
  format,
  sourceRefs,
  locatedBlockIds,
  blockPages,
  navigateToPdfPage,
}: {
  format: EvidenceViewerFormat;
  sourceRefs: MutableRefObject<Map<string, HTMLElement>>;
  locatedBlockIds: Set<string>;
  blockPages?: Map<string, number>;
  navigateToPdfPage?: (page: number) => void;
}) {
  return useCallback(
    (sourceBlockIds: string[]) => {
      const target = pickEvidenceScrollTarget({ format, sourceBlockIds, locatedBlockIds, blockPages });
      scrollEvidenceTarget(target, sourceRefs.current, navigateToPdfPage);
      return target;
    },
    [blockPages, format, locatedBlockIds, navigateToPdfPage, sourceRefs],
  );
}

export function scrollEvidenceTarget(
  target: EvidenceScrollTarget,
  sourceRefs: Map<string, { scrollIntoView: (options?: ScrollIntoViewOptions) => void }>,
  navigateToPdfPage?: (page: number) => void,
) {
  if (target.kind === "none") return;
  const scroll = () => sourceRefs.get(target.blockId)?.scrollIntoView({ block: "center", behavior: "smooth" });
  if (target.kind === "pdf_page") {
    navigateToPdfPage?.(target.page);
    requestAnimationFrame(() => requestAnimationFrame(scroll));
    return;
  }
  scroll();
}
