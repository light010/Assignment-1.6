import {
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Crosshair,
  Keyboard,
} from "lucide-react";
import { MutableRefObject, useEffect, useState } from "react";
import { TopicType } from "./api";
import { normalizeTopicType, WorkbenchTopic } from "./workbenchModel";
import {
  commitTopicTitleDraft,
  NextAction,
  TopicAttentionSummary,
  TopicProgress,
} from "./workbenchSelectors";
import { draftStateLabel, nextActionCopy } from "./workbenchViewModel";

const TOPIC_TYPES: TopicType[] = ["concept", "task", "reference", "troubleshooting", "glossary"];

export function Cockpit({
  topic,
  topicIndex,
  totalTopics,
  summary,
  progress,
  nextAction,
  hasLocalDraft,
  titleInputRef,
  typeSelectRef,
  onRenameTopic,
  onRetypeTopic,
  onPrevTopic,
  onNextTopic,
  onNextAttention,
  onPrimaryAction,
  onOpenShortcuts,
}: {
  topic: WorkbenchTopic;
  topicIndex: number;
  totalTopics: number;
  summary: TopicAttentionSummary;
  progress: TopicProgress;
  nextAction: NextAction;
  hasLocalDraft: boolean;
  titleInputRef: MutableRefObject<HTMLInputElement | null>;
  typeSelectRef: MutableRefObject<HTMLSelectElement | null>;
  onRenameTopic: (topicId: string, title: string) => void;
  onRetypeTopic: (topicId: string, topicType: TopicType) => void;
  onPrevTopic: () => void;
  onNextTopic: () => void;
  onNextAttention: () => void;
  onPrimaryAction: () => void;
  onOpenShortcuts: () => void;
}) {
  const action = nextActionCopy(nextAction);
  const draftLabel = draftStateLabel(topic, hasLocalDraft, summary);

  return (
    <section className={`workbench-cockpit severity-${summary.severity}`} aria-label="Current topic review cockpit">
      <div className="cockpit-primary">
        <div className="cockpit-kicker">
          <span>Topic {topicIndex + 1} of {totalTopics}</span>
          <SeveritySignal summary={summary} />
          <span className={`draft-chip ${draftLabel === "Clean" ? "quiet" : ""}`}>{draftLabel}</span>
        </div>
        <TopicTitleEditor topic={topic} inputRef={titleInputRef} onCommit={onRenameTopic} />
        <div className="cockpit-meta">
          <label>
            <span>Type</span>
            <select
              ref={typeSelectRef}
              value={topic.topic_type}
              onChange={(event) => {
                const nextType = normalizeTopicType(event.target.value);
                if (nextType !== topic.topic_type) onRetypeTopic(topic.topic_id, nextType);
              }}
            >
              {TOPIC_TYPES.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </label>
          <span>{topic.units.length} evidence units</span>
          <span>{Math.round(topic.boundary_confidence * 100)}% boundary</span>
          <span>{Math.round(topic.type_confidence * 100)}% type</span>
        </div>
      </div>

      <div className="cockpit-guidance">
        <div className={`next-action-card tone-${action.tone}`}>
          <Crosshair size={16} />
          <div>
            <strong>{action.label}</strong>
            <span>{action.detail}</span>
          </div>
          <button type="button" onClick={onPrimaryAction} disabled={nextAction.kind === "none"}>
            {action.label}
          </button>
        </div>
        <div className="cockpit-progress" aria-label={`${progress.reviewed} of ${progress.total} topics reviewed`}>
          <span>{progress.reviewed}/{progress.total} reviewed</span>
          <div>
            <i style={{ width: `${progress.total ? (progress.reviewed / progress.total) * 100 : 0}%` }} />
          </div>
        </div>
      </div>

      <div className="cockpit-nav" aria-label="Topic navigation">
        <button type="button" onClick={onPrevTopic} title="Previous topic">
          <ChevronLeft size={16} /> Prev
        </button>
        <button type="button" onClick={onNextTopic} title="Next topic">
          Next <ChevronRight size={16} />
        </button>
        <button type="button" onClick={onNextAttention} title="Review next attention item">
          <AlertTriangle size={15} /> Attention
        </button>
        <button type="button" onClick={onOpenShortcuts} title="Keyboard shortcuts">
          <Keyboard size={15} />
        </button>
      </div>
    </section>
  );
}

function SeveritySignal({ summary }: { summary: TopicAttentionSummary }) {
  if (summary.severity === "clean") {
    return <span className="severity-signal quiet"><CheckCircle2 size={12} /> Quiet</span>;
  }
  return (
    <span className={`severity-signal severity-${summary.severity}`}>
      <AlertTriangle size={12} />
      {summary.severity}
    </span>
  );
}

function TopicTitleEditor({
  topic,
  inputRef,
  onCommit,
}: {
  topic: WorkbenchTopic;
  inputRef: MutableRefObject<HTMLInputElement | null>;
  onCommit: (topicId: string, title: string) => void;
}) {
  const [draft, setDraft] = useState(topic.title);

  useEffect(() => {
    setDraft(topic.title);
  }, [topic.title, topic.topic_id]);

  function commit() {
    const nextTitle = commitTopicTitleDraft(topic.title, draft);
    if (nextTitle) onCommit(topic.topic_id, nextTitle);
    else setDraft(topic.title);
  }

  return (
    <input
      ref={inputRef}
      className="cockpit-title-input"
      value={draft}
      aria-label="Topic title"
      onChange={(event) => setDraft(event.target.value)}
      onBlur={commit}
      onKeyDown={(event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          event.currentTarget.blur();
        }
        if (event.key === "Escape") {
          event.preventDefault();
          setDraft(topic.title);
          event.currentTarget.blur();
        }
      }}
    />
  );
}
