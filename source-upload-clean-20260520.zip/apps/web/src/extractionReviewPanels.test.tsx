// @vitest-environment jsdom

import "@testing-library/jest-dom/vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { DocumentRecord, ExtractionReviewSummary, SourceBlock, User } from "./api";
import { ExtractionFailedPanel, ExtractionNeedsReviewPanel } from "./AppCore";
import { REVIEW_FLAG_LABELS } from "./reviewFlagLabels";

describe("extraction review panels", () => {
  afterEach(() => cleanup());

  it("renders failed extraction as an explicit failure state", () => {
    render(
      <ExtractionFailedPanel
        document={documentRecord({ status: "failed_extraction", extraction_failure_reason: "input_corrupted" })}
        summary={summary({ status: "failed_extraction", extraction_failure_reason: "input_corrupted", block_count: 0 })}
        user={user([])}
        refreshDocuments={vi.fn()}
        onToast={vi.fn()}
      />,
    );

    expect(screen.getByText("Extraction failed")).toBeInTheDocument();
    expect(screen.getByText(/Reason: Input Corrupted\./)).toBeInTheDocument();
    expect(screen.getByText("View upload")).toBeInTheDocument();
    expect(screen.queryByText("Override gate")).not.toBeInTheDocument();
  });

  it("renders gated extraction with grouped reasons and review flag counts", () => {
    const flag = REVIEW_FLAG_LABELS.ASSET_REF_UNRESOLVED;
    render(
      <ExtractionNeedsReviewPanel
        document={documentRecord({ status: "extraction_needs_review" })}
        summary={summary({
          status: "extraction_needs_review",
          review_flag_counts: { ASSET_REF_UNRESOLVED: 1 },
          blocked_groups: [{
            code: "unlocated_source_blocks",
            label: "Unlocated source blocks",
            severity: "error",
            count: 2,
            sample_block_ids: ["b1", "b2"],
          }],
          unlocated_source_block_ids: ["b1", "b2"],
          gate: {
            name: "docx_source_fidelity_v1",
            passed: false,
            severity: "blocking",
            blocking_reasons: ["unlocated_source_blocks"],
          },
        })}
        gate={{
          name: "docx_source_fidelity_v1",
          passed: false,
          severity: "blocking",
          blocking_reasons: ["unlocated_source_blocks"],
        }}
        user={user([])}
        refreshDocuments={vi.fn()}
        onToast={vi.fn()}
        onSelectUnlocatedBlock={vi.fn()}
        sourceBlocks={[
          sourceBlock("b1", "FundDirect file created with error"),
          sourceBlock("b2", "Reprocess the failed file"),
        ]}
      />,
    );

    expect(screen.getByText("Extraction gated")).toBeInTheDocument();
    expect(screen.getByText("Workbench diagnostic mode")).toBeInTheDocument();
    expect(screen.getByText("Affected evidence")).toBeInTheDocument();
    expect(screen.getAllByText("Unlocated source blocks").length).toBeGreaterThan(0);
    expect(screen.getByText(flag.label)).toBeInTheDocument();
    expect(screen.getByText(/Source-fidelity quality gate blocked downstream planning/)).toBeInTheDocument();
    expect(screen.getAllByText("FundDirect file created with error").length).toBeGreaterThan(0);
    expect(screen.getAllByText("Reprocess the failed file").length).toBeGreaterThan(0);
  });

  it("lets reviewers jump to an unlocated block from the gated panel", () => {
    const onSelectUnlocatedBlock = vi.fn();
    render(
      <ExtractionNeedsReviewPanel
        document={documentRecord({ status: "extraction_needs_review" })}
        summary={summary({
          status: "extraction_needs_review",
          unlocated_source_block_ids: ["b1"],
          gate: {
            name: "docx_source_fidelity_v1",
            passed: false,
            severity: "blocking",
            blocking_reasons: ["unlocated_source_blocks"],
          },
        })}
        gate={{
          name: "docx_source_fidelity_v1",
          passed: false,
          severity: "blocking",
          blocking_reasons: ["unlocated_source_blocks"],
        }}
        user={user([])}
        refreshDocuments={vi.fn()}
        onToast={vi.fn()}
        onSelectUnlocatedBlock={onSelectUnlocatedBlock}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "b1" }));
    expect(onSelectUnlocatedBlock).toHaveBeenCalledWith("b1");
  });

  it("separates system blockers from document evidence and disables re-extract", () => {
    render(
      <ExtractionNeedsReviewPanel
        document={documentRecord({ status: "extraction_needs_review" })}
        summary={summary({
          status: "extraction_needs_review",
          block_count: 23,
          located_block_count: 21,
          blocked_groups: [{
            code: "pandoc_unavailable",
            label: "Pandoc Unavailable",
            severity: "error",
            count: 1,
            sample_block_ids: [],
          }],
          gate: {
            name: "docx_source_fidelity_v1",
            passed: false,
            severity: "blocking",
            blocking_reasons: ["pandoc_unavailable"],
          },
        })}
        gate={{
          name: "docx_source_fidelity_v1",
          passed: false,
          severity: "blocking",
          blocking_reasons: ["pandoc_unavailable"],
        }}
        sourceBlocks={[sourceBlock("b1", "Pandoc could not render this document")]}
        user={user(["project_admin"])}
        refreshDocuments={vi.fn()}
        onToast={vi.fn()}
      />,
    );

    expect(screen.getByText("System dependency")).toBeInTheDocument();
    expect(screen.getByText("Restore extraction dependency")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Re-extract unavailable/ })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Override gate" })).toBeInTheDocument();
  });
});

function user(roles: string[]): User {
  return {
    user_id: "u1",
    tenant_id: "tenant",
    organization_id: "org",
    email: "reviewer@example.com",
    name: "Reviewer",
    roles,
  };
}

function documentRecord(overrides: Partial<DocumentRecord> = {}): DocumentRecord {
  return {
    document_id: "doc_1",
    filename: "Customer Change Requests.docx",
    content_type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    status: "ready_for_review",
    topic_ids: [],
    job_ids: [],
    source_hash: "hash",
    source_quality: {
      overall_confidence: 0.9,
      review_required: false,
      validation_issue_count: 0,
      quality_gate: { name: "docx_source_fidelity_v1", passed: true, severity: "info", blocking_reasons: [] },
    },
    ...overrides,
  };
}

function summary(overrides: Partial<ExtractionReviewSummary> = {}): ExtractionReviewSummary {
  return {
    status: "ready_for_review",
    extraction_failure_reason: null,
    block_count: 2,
    located_block_count: 2,
    unlocated_source_block_ids: [],
    review_flag_counts: {},
    blocked_groups: [],
    gate: { name: "docx_source_fidelity_v1", passed: true, severity: "info", blocking_reasons: [] },
    catalog: REVIEW_FLAG_LABELS,
    ...overrides,
  };
}

function sourceBlock(block_id: string, text: string): SourceBlock {
  return {
    block_id,
    block_type: "paragraph",
    text,
    source_location: { section: `docx:p:${block_id}` },
    review_flags: [],
    confidence: { extraction: 0.9, block_type: 0.9, heading: null },
  };
}
