import { AlertTriangle, CornerDownRight, GitMerge, Scissors } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { EvidenceNumber, unitAttentionSummary } from "./workbenchSelectors";
import {
  WorkbenchIssue,
  WorkbenchTopic,
  WorkbenchUnit,
} from "./workbenchModel";
import { evidenceNumbersForUnit } from "./workbenchViewModel";

export function EvidenceTimeline({
  topic,
  topics,
  issues,
  evidenceNumbers,
  selectedUnitIds,
  activeSourceIds,
  mergeAllowed,
  splitAllowed,
  moveTargetTopicId,
  onToggleUnit,
  onHoverUnit,
  onMerge,
  onSplit,
  onMoveTargetChange,
  onMove,
  setUnitRef,
}: {
  topic: WorkbenchTopic;
  topics: WorkbenchTopic[];
  issues: WorkbenchIssue[];
  evidenceNumbers: EvidenceNumber[];
  selectedUnitIds: string[];
  activeSourceIds: string[];
  mergeAllowed: boolean;
  splitAllowed: boolean;
  moveTargetTopicId: string;
  onToggleUnit: (unit: WorkbenchUnit, additive: boolean) => void;
  onHoverUnit: (unit: WorkbenchUnit) => void;
  onMerge: () => void;
  onSplit: () => void;
  onMoveTargetChange: (topicId: string) => void;
  onMove: () => void;
  setUnitRef: (unitId: string, node: HTMLElement | null) => void;
}) {
  return (
    <section className="evidence-timeline" aria-label="Extracted evidence timeline">
      {selectedUnitIds.length > 0 && (
        <div className="timeline-toolbar" role="toolbar" aria-label="Selected evidence actions">
          <strong>{selectedUnitIds.length} selected</strong>
          <button type="button" disabled={!mergeAllowed} onClick={onMerge}>
            <GitMerge size={14} /> Merge
          </button>
          <button type="button" disabled={!splitAllowed && selectedUnitIds.length !== 1} onClick={onSplit}>
            <Scissors size={14} /> Split
          </button>
          <label>
            <span>Move to</span>
            <select value={moveTargetTopicId} onChange={(event) => onMoveTargetChange(event.target.value)}>
              <option value="">Select topic</option>
              {topics
                .filter((item) => item.topic_id !== topic.topic_id)
                .map((item) => (
                  <option key={item.topic_id} value={item.topic_id}>{item.title}</option>
                ))}
            </select>
          </label>
          <button type="button" disabled={!moveTargetTopicId || selectedUnitIds.length === 0} onClick={onMove}>
            <CornerDownRight size={14} /> Move
          </button>
        </div>
      )}

      <div className="timeline-rows">
        <AnimatePresence initial={false}>
          {topic.units.map((unit) => {
            const numbers = evidenceNumbersForUnit(unit, evidenceNumbers);
            const selected = selectedUnitIds.includes(unit.unit_id);
            const active = unit.source_block_ids.some((blockId) => activeSourceIds.includes(blockId));
            const unitSummary = unitAttentionSummary(unit, issues);
            return (
              <motion.button
                layout
                key={unit.unit_id}
                ref={(node) => setUnitRef(unit.unit_id, node)}
                type="button"
                className={`timeline-row severity-${unitSummary.severity}${selected ? " selected" : ""}${active ? " active" : ""}${unit.is_virtual ? " virtual" : ""}`}
                onClick={(event) => onToggleUnit(unit, event.metaKey || event.ctrlKey || event.shiftKey)}
                onMouseEnter={() => onHoverUnit(unit)}
              >
                <span className="timeline-index" aria-label={`Evidence ${numbers.join(", ") || "unlocated"}`}>
                  {numbers.length ? numbers.join(",") : "?"}
                </span>
                <span className="timeline-copy">
                  <span className="timeline-text">{unit.text}</span>
                  <span className="timeline-meta">
                    {unit.block_type} · {Math.round(unit.confidence * 100)}% · {unit.source_block_ids.join(", ")}
                  </span>
                </span>
                {unitSummary.hasAttention && (
                  <span className={`timeline-attention severity-${unitSummary.severity}`}>
                    <AlertTriangle size={13} />
                    {unitSummary.severity}
                  </span>
                )}
              </motion.button>
            );
          })}
        </AnimatePresence>
      </div>
    </section>
  );
}
