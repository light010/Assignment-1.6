import { AttentionFilter } from "./workbenchSelectors";
import { storageKeyForWorkbenchOps, WorkbenchOp } from "./workbenchModel";

export type ReviewedTopic = {
  reviewed_at: string;
  hash: string;
};

export type WorkbenchUiState = {
  selected_topic_id?: string;
  attention_filter?: AttentionFilter;
};

/**
 * Local-only Workbench draft storage.
 *
 * Version 1 fields:
 * - `ops`: replayable frontend edit operations. These mirror the future
 *   backend edit-op contract but are not submitted to the server.
 * - `reviewed`: topic review stamps keyed by topic id. Each stamp stores
 *   the topic content hash it was approved against; selectors invalidate
 *   the stamp when title/type/unit/source content changes.
 * - `ui`: recoverable view state that is safe to lose, currently selected
 *   topic and attention filter.
 *
 * Migration policy: read legacy raw `WorkbenchOp[]` drafts, write only this
 * envelope shape, and treat corrupt/unknown versions as an empty draft.
 */
export type WorkbenchStorageEnvelopeV1 = {
  version: 1;
  ops: WorkbenchOp[];
  reviewed: Record<string, ReviewedTopic>;
  ui: WorkbenchUiState;
};

export const WORKBENCH_STORAGE_VERSION = 1;

export function emptyWorkbenchStorageEnvelope(): WorkbenchStorageEnvelopeV1 {
  return {
    version: WORKBENCH_STORAGE_VERSION,
    ops: [],
    reviewed: {},
    ui: {},
  };
}

export function readWorkbenchStorage(documentId: string, storage: Storage = sessionStorage) {
  return parseWorkbenchStorageValue(storage.getItem(storageKeyForWorkbenchOps(documentId)));
}

export function writeWorkbenchStorage(
  documentId: string,
  envelope: WorkbenchStorageEnvelopeV1,
  storage: Storage = sessionStorage,
) {
  storage.setItem(storageKeyForWorkbenchOps(documentId), serializeWorkbenchStorage(envelope));
}

export function clearWorkbenchStorage(documentId: string, storage: Storage = sessionStorage) {
  storage.removeItem(storageKeyForWorkbenchOps(documentId));
}

export function parseWorkbenchStorageValue(value: string | null): WorkbenchStorageEnvelopeV1 {
  if (!value) return emptyWorkbenchStorageEnvelope();
  try {
    const parsed = JSON.parse(value) as unknown;
    return migrateWorkbenchStorageValue(parsed);
  } catch {
    return emptyWorkbenchStorageEnvelope();
  }
}

export function serializeWorkbenchStorage(envelope: WorkbenchStorageEnvelopeV1) {
  return JSON.stringify({
    version: WORKBENCH_STORAGE_VERSION,
    ops: Array.isArray(envelope.ops) ? envelope.ops : [],
    reviewed: envelope.reviewed && typeof envelope.reviewed === "object" ? envelope.reviewed : {},
    ui: envelope.ui && typeof envelope.ui === "object" ? envelope.ui : {},
  });
}

export function migrateWorkbenchStorageValue(value: unknown): WorkbenchStorageEnvelopeV1 {
  if (Array.isArray(value)) {
    return {
      ...emptyWorkbenchStorageEnvelope(),
      ops: value.filter(isWorkbenchOp),
    };
  }
  if (!value || typeof value !== "object") return emptyWorkbenchStorageEnvelope();
  const candidate = value as Partial<WorkbenchStorageEnvelopeV1>;
  if (candidate.version !== WORKBENCH_STORAGE_VERSION) return emptyWorkbenchStorageEnvelope();
  return {
    version: WORKBENCH_STORAGE_VERSION,
    ops: Array.isArray(candidate.ops) ? candidate.ops.filter(isWorkbenchOp) : [],
    reviewed: isRecord(candidate.reviewed) ? sanitizeReviewed(candidate.reviewed) : {},
    ui: isRecord(candidate.ui) ? sanitizeUi(candidate.ui) : {},
  };
}

function isWorkbenchOp(value: unknown): value is WorkbenchOp {
  if (!value || typeof value !== "object") return false;
  const kind = (value as { kind?: unknown }).kind;
  return (
    kind === "merge_units" ||
    kind === "split_unit" ||
    kind === "move_units" ||
    kind === "rename_topic" ||
    kind === "retype_topic"
  );
}

function sanitizeReviewed(value: Record<string, unknown>): Record<string, ReviewedTopic> {
  const reviewed: Record<string, ReviewedTopic> = {};
  Object.entries(value).forEach(([topicId, entry]) => {
    if (!entry || typeof entry !== "object") return;
    const reviewedAt = (entry as { reviewed_at?: unknown }).reviewed_at;
    const hash = (entry as { hash?: unknown }).hash;
    if (typeof reviewedAt === "string" && typeof hash === "string") {
      reviewed[topicId] = { reviewed_at: reviewedAt, hash };
    }
  });
  return reviewed;
}

function sanitizeUi(value: Record<string, unknown>): WorkbenchUiState {
  const ui: WorkbenchUiState = {};
  if (typeof value.selected_topic_id === "string") ui.selected_topic_id = value.selected_topic_id;
  if (isAttentionFilter(value.attention_filter)) ui.attention_filter = value.attention_filter;
  return ui;
}

function isAttentionFilter(value: unknown): value is AttentionFilter {
  return value === "all" || value === "attention" || value === "errors" || value === "stale" || value === "review";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
