import { AlertTriangle, CheckCircle2, Clipboard, Download, FileText, Image as ImageIcon, X } from "lucide-react";
import { AnimatePresence, LayoutGroup, motion, useReducedMotion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown, { Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import { useVirtualizer } from "@tanstack/react-virtual";
import { Document as PdfDocument, Page as PdfPage } from "react-pdf";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
import "react-pdf/dist/esm/Page/TextLayer.css";
import { AssetRecord, DocumentRecord, ExtractionReviewSummary, ExtractionWarning, getDocumentAssets, getDocumentBlocks, getDocumentExtractionReviewSummary, getDocumentMarkdown, getDocumentSourceQuality, SourceBlock, SourceQuality, sourceFileUrl, User, assetContentUrl } from "./api";
import { ExtractionFailedPanel, ExtractionNeedsReviewPanel } from "./ExtractionReviewBanner";
import { formatBytes, formatConfidence } from "./formatters";
import "./pdfWorker";

function isTerminalStatus(status: string): boolean {
  const s = (status || "").toLowerCase();
  return (
    s === "ready_for_review" ||
    s === "review_ready" ||
    s === "approved" ||
    s === "export_ready" ||
    s === "rejected" ||
    s.includes("fail")
  );
}

type SourceSubTab = "preview" | "blocks" | "markdown" | "warnings" | "assets";

const SOURCE_TABS: Array<{ key: SourceSubTab; label: string }> = [
  { key: "preview", label: "Preview" },
  { key: "blocks", label: "Blocks" },
  { key: "markdown", label: "Markdown" },
  { key: "warnings", label: "Warnings" },
  { key: "assets", label: "Assets" },
];

export function SourcePanel({
  document,
  user,
  refreshDocuments,
}: {
  document: DocumentRecord;
  user: User;
  refreshDocuments: () => Promise<void>;
}) {
  const isPdfDoc =
    (document.content_type || "").includes("pdf") ||
    document.filename.toLowerCase().endsWith(".pdf");
  const defaultTab: SourceSubTab = isTerminalStatus(document.status)
    ? isPdfDoc
      ? "preview"
      : "markdown"
    : "blocks";
  const initialTab = sourceTabFromHash() || defaultTab;
  const [activeTab, setActiveTab] = useState<SourceSubTab>(initialTab);
  const prefersReducedMotion = useReducedMotion();
  const [blocks, setBlocks] = useState<SourceBlock[]>([]);
  const [markdown, setMarkdown] = useState("");
  const [assets, setAssets] = useState<AssetRecord[]>([]);
  const [quality, setQuality] = useState<SourceQuality | null>(document.source_quality as SourceQuality);
  const [reviewSummary, setReviewSummary] = useState<ExtractionReviewSummary | null>(null);
  const [activeBlockId, setActiveBlockId] = useState("");
  const [selectedAsset, setSelectedAsset] = useState<AssetRecord | null>(null);
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError("");
    void (async () => {
      try {
        const summary = await getDocumentExtractionReviewSummary(document.document_id);
        if (cancelled) return null;
        setReviewSummary(summary);
        const gated = summary.status === "failed_extraction"
          || summary.status === "extraction_needs_review"
          || summary.gate?.passed === false
          || document.status === "failed_extraction"
          || document.status === "extraction_needs_review";
        const result = gated
          ? [
            { items: [] as SourceBlock[], next_cursor: null },
            { document_id: document.document_id, markdown: "" },
            { document_id: document.document_id, assets: [] as AssetRecord[] },
            document.source_quality as SourceQuality,
          ] as [
            { items: SourceBlock[]; next_cursor?: number | null },
            { document_id: string; markdown: string },
            { document_id: string; assets: AssetRecord[] },
            SourceQuality,
          ]
          : await Promise.all([
          getDocumentBlocks(document.document_id),
          getDocumentMarkdown(document.document_id),
          getDocumentAssets(document.document_id),
          getDocumentSourceQuality(document.document_id),
        ]);
        const [blockResult, markdownResult, assetResult, qualityResult] = result;
        if (cancelled) return;
        setBlocks(blockResult.items);
        setMarkdown(markdownResult.markdown);
        setAssets(assetResult.assets || []);
        setQuality(qualityResult);
      } catch (err) {
        if (!cancelled) setLoadError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [document.content_type, document.document_id, document.filename, document.source_quality, document.status, reloadKey]);

  useEffect(() => {
    const next = sourceTabFromHash();
    if (next) setActiveTab(next);
    function handleHashChange() {
      const tab = sourceTabFromHash();
      if (tab) setActiveTab(tab);
    }
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  useEffect(() => {
    if (!activeBlockId || activeTab !== "markdown") return;
    const target = window.document.getElementById(`md-${activeBlockId}`);
    if (!target) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({ block: "center", behavior: reduceMotion ? "auto" : "smooth" });
  }, [activeBlockId, activeTab]);

  useEffect(() => {
    if (!selectedAsset) return;
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setSelectedAsset(null);
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedAsset]);

  function selectTab(tab: SourceSubTab) {
    setActiveTab(tab);
    window.history.replaceState(null, "", `#${tab}`);
  }

  function handleTabKey(event: React.KeyboardEvent<HTMLButtonElement>, current: SourceSubTab) {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const index = SOURCE_TABS.findIndex((tab) => tab.key === current);
    const nextIndex =
      event.key === "Home"
        ? 0
        : event.key === "End"
          ? SOURCE_TABS.length - 1
          : event.key === "ArrowRight"
            ? (index + 1) % SOURCE_TABS.length
            : (index - 1 + SOURCE_TABS.length) % SOURCE_TABS.length;
    const next = SOURCE_TABS[nextIndex]!.key;
    selectTab(next);
    window.requestAnimationFrame(() => window.document.getElementById(`source-tab-${next}`)?.focus());
  }

  async function copyMarkdown() {
    await navigator.clipboard.writeText(markdown);
    setToast("Markdown copied");
    window.setTimeout(() => setToast(""), 1800);
  }

  const warnings = collectWarnings(quality, blocks);
  const activeBlock = blocks.find((block) => block.block_id === activeBlockId);
  const blockTextById = useMemo(() => new Map(blocks.map((block) => [block.block_id, block.text] as const)), [blocks]);
  const summaryBlockCount = reviewSummary?.block_count
    ?? (reviewSummary?.located_block_count || 0) + (reviewSummary?.unlocated_source_block_ids.length || 0);
  const extractionGated = reviewSummary?.status === "failed_extraction"
    || reviewSummary?.status === "extraction_needs_review"
    || reviewSummary?.gate?.passed === false
    || quality?.quality_gate?.passed === false
    || document.status === "failed_extraction"
    || document.status === "extraction_needs_review";

  // Counts per view-mode segment — null means "no count badge needed".
  const segmentCount: Record<SourceSubTab, number | null> = {
    preview: null,
    blocks: Math.max(blocks.length, summaryBlockCount || 0),
    markdown: null,
    warnings: warnings.length,
    assets: assets.length,
  };

  const segmentedControl = (
    <LayoutGroup id="source-segment-rail-group">
      <nav className="segmented-control" role="tablist" aria-label="Source preview view">
        {SOURCE_TABS.map((tab) => {
          const isActive = activeTab === tab.key;
          const count = segmentCount[tab.key];
          return (
            <button
              id={`source-tab-${tab.key}`}
              key={tab.key}
              role="tab"
              type="button"
              aria-selected={isActive}
              aria-controls={`source-panel-${tab.key}`}
              className={`segmented-control-item${isActive ? " is-active" : ""}`}
              tabIndex={isActive ? 0 : -1}
              onClick={() => selectTab(tab.key)}
              onKeyDown={(event) => handleTabKey(event, tab.key)}
            >
              {isActive && (
                <motion.span
                  className="segmented-control-pill"
                  layoutId="source-segment-pill"
                  aria-hidden="true"
                  transition={
                    prefersReducedMotion
                      ? { duration: 0 }
                      : { type: "spring", stiffness: 480, damping: 36, mass: 0.7 }
                  }
                />
              )}
              <span className="segmented-control-label">{tab.label}</span>
              {count !== null && (
                <span className="segmented-control-count" aria-hidden>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </LayoutGroup>
  );

  return (
    <section className="source-preview" aria-label="Source Preview">
      <div className="source-view-switcher">{segmentedControl}</div>

      {document.status !== "failed_extraction" && (reviewSummary?.gate?.passed === false || quality?.quality_gate?.passed === false) && (
        <ExtractionNeedsReviewPanel
          document={document}
          summary={reviewSummary}
          gate={reviewSummary?.gate || quality?.quality_gate || null}
          user={user}
          refreshDocuments={refreshDocuments}
          onToast={setToast}
          blockTextById={blockTextById}
          onSelectUnlocatedBlock={(blockId) => {
            setActiveBlockId(blockId);
            selectTab("blocks");
          }}
        />
      )}

      {loadError && (
        <div className="source-unavailable-state" role="alert">
          <FileText size={28} />
          <h3>Source preview unavailable for this document</h3>
          <p>{loadError}</p>
          <div>
            <button type="button" onClick={() => setReloadKey((value) => value + 1)}>
              Re-fetch
            </button>
            <a href={sourceFileUrl(document.document_id)} target="_blank" rel="noreferrer">
              View raw upload
            </a>
          </div>
        </div>
      )}

      {!loadError && <div className="source-tab-body" role="tabpanel" id={`source-panel-${activeTab}`} tabIndex={0}>
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={`${activeTab}-${loading ? "loading" : "ready"}`}
            initial={prefersReducedMotion ? false : { opacity: 0, y: 4 }}
            animate={prefersReducedMotion ? { opacity: 1, y: 0 } : { opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: -2 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.18, ease: [0.2, 0.8, 0.2, 1] }}
            className="source-tab-body-inner"
          >
            {document.status === "failed_extraction" ? (
              <ExtractionFailedPanel
                document={document}
                summary={reviewSummary}
                user={user}
                refreshDocuments={refreshDocuments}
                onToast={setToast}
              />
            ) : loading ? (
              <SourceSkeleton tab={activeTab} />
            ) : activeTab === "preview" ? (
              <PreviewPane document={document} activeBlock={activeBlock} onOpenBlocks={() => selectTab("blocks")} />
            ) : activeTab === "blocks" ? (
              <BlocksPane
                blocks={blocks}
                activeBlockId={activeBlockId}
                setActiveBlockId={setActiveBlockId}
                expectedBlockCount={summaryBlockCount || 0}
                extractionGated={extractionGated}
              />
            ) : activeTab === "markdown" ? (
              <MarkdownPane
                markdown={markdown}
                documentId={document.document_id}
                activeBlockId={activeBlockId}
                setActiveBlockId={setActiveBlockId}
                onCopy={copyMarkdown}
              />
            ) : activeTab === "warnings" ? (
              <WarningsPane warnings={warnings} />
            ) : (
              <AssetsPane
                documentId={document.document_id}
                assets={assets}
                onOpenAsset={setSelectedAsset}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>}

      <div className="source-live" aria-live="polite">
        {activeBlock
          ? `Showing ${activeBlock.block_id}${
            activeBlock.source_location.section
              ? ` at ${activeBlock.source_location.section}`
              : ` on page ${activeBlock.source_location.page || activeBlock.page || 1}`
          }.`
          : ""}
      </div>
      {toast && <div className="source-toast" role="status">{toast}</div>}
      {selectedAsset && (
        <AssetLightbox
          documentId={document.document_id}
          asset={selectedAsset}
          onClose={() => setSelectedAsset(null)}
        />
      )}
    </section>
  );
}

function sourceTabFromHash(): SourceSubTab | null {
  const raw = window.location.hash.replace("#", "");
  return SOURCE_TABS.some((tab) => tab.key === raw) ? (raw as SourceSubTab) : null;
}

function collectWarnings(quality: SourceQuality | null, blocks: SourceBlock[]): ExtractionWarning[] {
  const sourceWarnings = quality?.warnings || [];
  const blockWarnings = blocks.flatMap((block) =>
    (block.warnings || []).map((warning) => ({
      warning_id: `${block.block_id}-${warning}`,
      kind: warning,
      severity: "warning" as const,
      message: warning,
      source_block_ids: [block.block_id],
    })),
  );
  if (quality?.extraction_error) {
    return [
      ...sourceWarnings,
      {
        warning_id: `error-${quality.extraction_error.kind}`,
        kind: quality.extraction_error.kind,
        severity: "error",
        message: quality.extraction_error.message,
        source_block_ids: [],
      },
      ...blockWarnings,
    ];
  }
  return [...sourceWarnings, ...blockWarnings];
}

function SourceSkeleton({ tab }: { tab: SourceSubTab }) {
  return (
    <div className={`source-skeleton source-skeleton-${tab}`} aria-label={`Loading ${tab}`}>
      <span />
      <span />
      <span />
      <span />
    </div>
  );
}

function PreviewPane({
  document,
  activeBlock,
  onOpenBlocks,
}: {
  document: DocumentRecord;
  activeBlock?: SourceBlock;
  onOpenBlocks: () => void;
}) {
  const isPdf = (document.content_type || "").includes("pdf") || document.filename.toLowerCase().endsWith(".pdf");
  const showEvidenceRail = !!activeBlock;
  return (
    <section
      className={`source-preview-pane preview-pane${showEvidenceRail ? " has-evidence" : ""}`}
    >
      <div className="preview-frame">
        {isPdf ? (
          <PdfPreview documentId={document.document_id} activeBlock={activeBlock} />
        ) : (
          <div className="preview-unavailable">
            <FileText size={28} />
            <h3>This document type renders as Markdown</h3>
            <p>
              DOCX, TXT, MD, and HTML extract directly to Markdown. The Markdown
              tab shows the same content the converter sees, with anchors back
              to source blocks.
            </p>
            <button type="button" onClick={onOpenBlocks}>Open Blocks</button>
          </div>
        )}
      </div>
      {showEvidenceRail && (
        <aside className="preview-evidence" aria-label="Active source block">
          <header className="preview-evidence-head">
            <code className="preview-evidence-id">{activeBlock.block_id}</code>
            <span className="preview-evidence-type">{activeBlock.block_type}</span>
          </header>
          <p className="preview-evidence-text">{activeBlock.text}</p>
          {activeBlock.source_location.page && (
            <p className="preview-evidence-meta">
              Page {activeBlock.source_location.page}
            </p>
          )}
        </aside>
      )}
    </section>
  );
}

type PdfPageGeometry = {
  pdfWidth: number;
  pdfHeight: number;
  cssWidth: number;
  cssHeight: number;
};

function PdfPreview({
  documentId,
  activeBlock,
}: {
  documentId: string;
  activeBlock?: SourceBlock;
}) {
  const [numPages, setNumPages] = useState(0);
  const [pageGeometry, setPageGeometry] = useState<Map<number, PdfPageGeometry>>(
    () => new Map(),
  );
  const [containerWidth, setContainerWidth] = useState<number>(720);
  const [loadError, setLoadError] = useState<string>("");
  const containerRef = useRef<HTMLDivElement | null>(null);
  const pageRefs = useRef<Map<number, HTMLDivElement>>(new Map());

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const update = () => setContainerWidth(node.clientWidth || 720);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const activePage = activeBlock?.source_location.page || activeBlock?.page || null;
  useEffect(() => {
    if (!activePage) return;
    const wrapper = pageRefs.current.get(activePage);
    if (wrapper) wrapper.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [activePage, activeBlock?.block_id]);

  const fileProp = useMemo(() => ({ url: sourceFileUrl(documentId) }), [documentId]);

  if (loadError) {
    return (
      <div className="preview-unavailable">
        <FileText size={28} />
        <h3>Could not render this PDF</h3>
        <p>{loadError}</p>
        <a href={sourceFileUrl(documentId)} target="_blank" rel="noreferrer">
          Open original PDF
        </a>
      </div>
    );
  }

  return (
    <div className="pdf-preview" ref={containerRef}>
      <PdfDocument
        file={fileProp}
        onLoadSuccess={(pdf) => setNumPages(pdf.numPages)}
        onLoadError={(err) => setLoadError(err.message || "Failed to load PDF")}
        loading={<div className="pdf-loading">Loading PDF…</div>}
        error={<div className="pdf-loading">Could not load PDF.</div>}
      >
        {Array.from({ length: numPages }, (_, i) => i + 1).map((pageNum) => {
          const geometry = pageGeometry.get(pageNum);
          const matchesActiveBlock = activePage === pageNum && activeBlock?.source_location.bbox;
          return (
            <div
              key={pageNum}
              className="pdf-page-wrapper"
              ref={(el) => {
                if (el) pageRefs.current.set(pageNum, el);
                else pageRefs.current.delete(pageNum);
              }}
            >
              <PdfPage
                pageNumber={pageNum}
                width={containerWidth}
                renderTextLayer={false}
                renderAnnotationLayer={false}
                onRenderSuccess={(page) => {
                  const view = page.view as [number, number, number, number];
                  setPageGeometry((current) => {
                    const next = new Map(current);
                    next.set(pageNum, {
                      pdfWidth: view[2] - view[0],
                      pdfHeight: view[3] - view[1],
                      cssWidth: page.width,
                      cssHeight: page.height,
                    });
                    return next;
                  });
                }}
              />
              {matchesActiveBlock && geometry && (
                <BboxOverlay
                  bbox={
                    (activeBlock?.source_location.bbox || activeBlock?.bbox || null) as
                      | number[]
                      | null
                  }
                  geometry={geometry}
                />
              )}
            </div>
          );
        })}
      </PdfDocument>
    </div>
  );
}

function BboxOverlay({
  bbox,
  geometry,
}: {
  bbox: number[] | null;
  geometry: PdfPageGeometry;
}) {
  if (!bbox || bbox.length < 4) return null;
  const [x0, y0, x1, y1] = bbox as [number, number, number, number];
  const sx = geometry.cssWidth / geometry.pdfWidth;
  const sy = geometry.cssHeight / geometry.pdfHeight;
  const left = x0 * sx;
  const top = y0 * sy;
  const width = (x1 - x0) * sx;
  const height = (y1 - y0) * sy;
  return (
    <div
      className="pdf-bbox-overlay"
      style={{
        position: "absolute",
        left,
        top,
        width,
        height,
        pointerEvents: "none",
      }}
      aria-hidden="true"
    />
  );
}

function BlocksPane({
  blocks,
  activeBlockId,
  setActiveBlockId,
  expectedBlockCount,
  extractionGated,
}: {
  blocks: SourceBlock[];
  activeBlockId: string;
  setActiveBlockId: (blockId: string) => void;
  expectedBlockCount: number;
  extractionGated: boolean;
}) {
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const rowVirtualizer = useVirtualizer({
    count: blocks.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => 44,
    overscan: 8,
    getItemKey: (index) => blocks[index]?.block_id ?? index,
  });

  if (blocks.length === 0) {
    if (extractionGated && expectedBlockCount > 0) {
      return (
        <div className="empty-state compact">
          Source block details are unavailable while extraction is gated.
          <span>{expectedBlockCount} source blocks were counted by the review summary.</span>
        </div>
      );
    }
    return <div className="empty-state compact">No blocks were extracted.</div>;
  }

  const totalSize = rowVirtualizer.getTotalSize();
  const items = rowVirtualizer.getVirtualItems();

  return (
    <section className="source-preview-pane blocks-pane">
      <div
        className="source-block-table"
        role="table"
        aria-label="Extracted source blocks"
      >
        <div className="source-block-row source-block-head" role="row">
          <span role="columnheader">ID</span>
          <span role="columnheader">Type</span>
          <span role="columnheader">Page</span>
          <span role="columnheader">Text</span>
          <span role="columnheader">Confidence</span>
        </div>
        <div
          ref={scrollRef}
          className="source-block-scroll"
          role="rowgroup"
        >
          <div
            className="source-block-virtual-spacer"
            style={{ height: `${totalSize}px`, position: "relative" }}
          >
            {items.map((virtualRow) => {
              const block = blocks[virtualRow.index];
              if (!block) return null;
              return (
                <button
                  key={virtualRow.key}
                  type="button"
                  data-index={virtualRow.index}
                  ref={rowVirtualizer.measureElement}
                  className={`source-block-row${activeBlockId === block.block_id ? " active" : ""}`}
                  role="row"
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: 0,
                    transform: `translateY(${virtualRow.start}px)`,
                  }}
                  onMouseEnter={() => setActiveBlockId(block.block_id)}
                  onFocus={() => setActiveBlockId(block.block_id)}
                >
                  <code role="cell">{block.block_id}</code>
                  <span role="cell">{block.block_type}</span>
                  <span role="cell">{block.source_location.page || block.page || 1}</span>
                  <span role="cell">{block.text}</span>
                  <span role="cell">{formatConfidence(block.confidence.extraction || null)}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

function MarkdownPane({
  markdown,
  documentId,
  activeBlockId,
  setActiveBlockId,
  onCopy,
}: {
  markdown: string;
  documentId: string;
  activeBlockId: string;
  setActiveBlockId: (blockId: string) => void;
  onCopy: () => Promise<void>;
}) {
  const { frontmatter, blocks } = useMemo(() => parseMarkdownArtifact(markdown), [markdown]);
  const [showRaw, setShowRaw] = useState(false);

  const components: Components = useMemo(() => {
    return {
      img: ({ src, alt, title }) => {
        const resolved = typeof src === "string" ? resolveAssetUrl(documentId, src) : src;
        return (
          <figure className="md-figure">
            <img src={resolved as string | undefined} alt={alt || ""} loading="lazy" />
            {(alt || title) && <figcaption>{title || alt}</figcaption>}
          </figure>
        );
      },
      a: ({ href, children }) => (
        <a href={href} target="_blank" rel="noreferrer">
          {children}
        </a>
      ),
      table: ({ children }) => (
        <div className="md-table-scroll">
          <table>{children}</table>
        </div>
      ),
    };
  }, [documentId]);

  if (!markdown.trim()) {
    return <div className="empty-state compact">No content was projected.</div>;
  }

  return (
    <section className="source-preview-pane markdown-pane">
      <div className="markdown-actions">
        {frontmatter &&
        (frontmatter.extractor_version ||
          frontmatter.source_blocks_sha256 ||
          frontmatter.asset_manifest_sha256) ? (
          <ul className="markdown-frontmatter" aria-label="Projection metadata">
            {frontmatter.extractor_version && (
              <li>
                <span>Extractor</span>
                <code>{frontmatter.extractor_version}</code>
              </li>
            )}
            {frontmatter.source_blocks_sha256 && (
              <li title={`source-blocks.jsonl ${frontmatter.source_blocks_sha256}`}>
                <span>Source hash</span>
                <code>{frontmatter.source_blocks_sha256.slice(0, 10)}…</code>
              </li>
            )}
            {frontmatter.asset_manifest_sha256 && (
              <li title={`asset-manifest.json ${frontmatter.asset_manifest_sha256}`}>
                <span>Asset hash</span>
                <code>{frontmatter.asset_manifest_sha256.slice(0, 10)}…</code>
              </li>
            )}
          </ul>
        ) : (
          <span className="markdown-actions-spacer" aria-hidden />
        )}
        <div className="markdown-actions-buttons">
          <button
            type="button"
            className={showRaw ? "active" : ""}
            onClick={() => setShowRaw((value) => !value)}
            aria-pressed={showRaw}
            title={showRaw ? "Show rendered Markdown" : "Show raw Markdown"}
          >
            {showRaw ? "Rendered" : "Raw"}
          </button>
          <button type="button" onClick={onCopy}>
            <Clipboard size={14} /> Copy raw
          </button>
        </div>
      </div>
      {showRaw ? (
        <pre className="markdown-raw" aria-label="Raw Markdown source">
          {markdown}
        </pre>
      ) : (
        <div className="markdown-render" aria-label="Markdown projection">
          {blocks.length === 0 ? (
            <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>
              {stripFrontmatter(markdown)}
            </ReactMarkdown>
          ) : (
            blocks.map((section) => (
              <article
                key={section.key}
                id={section.blockId ? `md-${section.blockId}` : undefined}
                className={`md-block${section.blockId && activeBlockId === section.blockId ? " active" : ""}`}
                onMouseEnter={() => section.blockId && setActiveBlockId(section.blockId)}
                onFocus={() => section.blockId && setActiveBlockId(section.blockId)}
                tabIndex={section.blockId ? 0 : -1}
              >
                <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>
                  {section.text}
                </ReactMarkdown>
              </article>
            ))
          )}
        </div>
      )}
    </section>
  );
}

type MarkdownFrontmatter = {
  source_blocks_sha256?: string;
  asset_manifest_sha256?: string;
  extractor_version?: string;
  source_filename?: string;
};

type MarkdownBlock = { key: string; blockId: string; text: string };

function parseMarkdownArtifact(markdown: string): {
  frontmatter: MarkdownFrontmatter | null;
  blocks: MarkdownBlock[];
} {
  const blocks: MarkdownBlock[] = [];
  if (!markdown.trim()) return { frontmatter: null, blocks };

  const frontmatterMatch = markdown.match(/^<!--\s*([^>]+?)\s*-->\s*\n/);
  let frontmatter: MarkdownFrontmatter | null = null;
  let body = markdown;
  if (frontmatterMatch) {
    frontmatter = parseFrontmatter(frontmatterMatch[1] || "");
    body = markdown.slice(frontmatterMatch[0].length);
  }

  const pieces = body.split(/<!--\s*source:(blk_[A-Za-z0-9_]+)\s*-->/g);
  for (let index = 1; index < pieces.length; index += 2) {
    const blockId = pieces[index] || "";
    const text = (pieces[index + 1] || "").trim();
    if (text) blocks.push({ key: blockId, blockId, text });
  }
  if (blocks.length === 0 && body.trim()) {
    blocks.push({ key: "body", blockId: "", text: body.trim() });
  }
  return { frontmatter, blocks };
}

function parseFrontmatter(raw: string): MarkdownFrontmatter {
  const out: MarkdownFrontmatter = {};
  const tokens = raw.match(/(\w+)=([^\s]+)/g) || [];
  for (const token of tokens) {
    const [key, value] = token.split("=", 2);
    if (!key || value === undefined) continue;
    if (key === "source_blocks_sha256") out.source_blocks_sha256 = value;
    else if (key === "asset_manifest_sha256") out.asset_manifest_sha256 = value;
    else if (key === "extractor_version") out.extractor_version = value;
    else if (key === "source_filename") out.source_filename = value;
  }
  return out;
}

function stripFrontmatter(markdown: string): string {
  return markdown.replace(/^<!--\s*[^>]+?\s*-->\s*\n/, "").trim();
}

function resolveAssetUrl(documentId: string, src: string): string {
  if (!src.startsWith("asset:")) return src;
  const assetId = src.slice("asset:".length);
  return assetContentUrl(documentId, assetId);
}

function WarningsPane({ warnings }: { warnings: ExtractionWarning[] }) {
  if (warnings.length === 0) {
    return (
      <div className="ok source-ok">
        <CheckCircle2 size={18} /> No extraction warnings
      </div>
    );
  }
  return (
    <section className="source-preview-pane warnings-pane">
      {warnings.map((warning) => (
        <article className={`source-warning severity-${warning.severity}`} key={warning.warning_id}>
          <AlertTriangle size={16} />
          <div>
            <strong>{warning.kind}</strong>
            <p>{warning.message}</p>
            {warning.source_block_ids.length > 0 && <code>{warning.source_block_ids.join(", ")}</code>}
          </div>
        </article>
      ))}
    </section>
  );
}

function AssetsPane({
  documentId,
  assets,
  onOpenAsset,
}: {
  documentId: string;
  assets: AssetRecord[];
  onOpenAsset: (asset: AssetRecord) => void;
}) {
  if (assets.length === 0) {
    return (
      <div className="empty-state compact">
        <ImageIcon size={28} />
        <p>No assets were embedded in this document.</p>
      </div>
    );
  }
  return (
    <section className="source-preview-pane assets-pane">
      {assets.map((asset) => (
        <button
          type="button"
          className="asset-tile"
          key={asset.asset_id}
          onClick={() => onOpenAsset(asset)}
          aria-label={`Open asset ${asset.filename}`}
        >
          <img src={assetContentUrl(documentId, asset.asset_id)} alt={asset.caption || asset.filename} />
          <span>{asset.filename}</span>
          <small>
            {formatBytes(asset.size_bytes)}
            {asset.width && asset.height ? ` · ${asset.width}×${asset.height}` : ""}
          </small>
        </button>
      ))}
    </section>
  );
}

function AssetLightbox({
  documentId,
  asset,
  onClose,
}: {
  documentId: string;
  asset: AssetRecord;
  onClose: () => void;
}) {
  return (
    <div className="asset-lightbox" role="dialog" aria-modal="true" aria-label={asset.filename}>
      <button type="button" className="asset-lightbox-backdrop" onClick={onClose} aria-label="Close asset preview" />
      <div className="asset-lightbox-panel">
        <header>
          <div>
            <strong>{asset.filename}</strong>
            <span>{asset.content_type} · {formatBytes(asset.size_bytes)}</span>
          </div>
          <button type="button" onClick={onClose} aria-label="Close asset preview" autoFocus>
            <X size={16} />
          </button>
        </header>
        <img src={assetContentUrl(documentId, asset.asset_id)} alt={asset.caption || asset.filename} />
      </div>
    </div>
  );
}
