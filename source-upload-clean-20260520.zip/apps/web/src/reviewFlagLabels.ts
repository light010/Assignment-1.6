export type ReviewFlagSeverity = "info" | "warning" | "error";

export type ReviewFlagLabel = {
  label: string;
  severity: ReviewFlagSeverity;
  explanation: string;
  action: string;
};

export const REVIEW_FLAG_LABELS = {
  LOW_BLOCK_TYPE_CONFIDENCE: {
    label: "Low block type confidence",
    severity: "warning",
    explanation: "The classifier is not confident that the assigned source block type is correct.",
    action: "Compare the row with the source and confirm the block type before approving.",
  },
  ORPHAN_TABLE_ROW: {
    label: "Orphan table row",
    severity: "warning",
    explanation: "A table row appears without a first-row sibling in the same table, which can mean rows were dropped.",
    action: "Inspect the source table and verify that all expected rows are represented.",
  },
  MIXED_HEADING_STYLE: {
    label: "Mixed heading style",
    severity: "info",
    explanation: "The paragraph style is used for both headings and non-heading content, so heading intent is ambiguous.",
    action: "Check the source style and surrounding structure before relying on this heading.",
  },
  SUSPECTED_HEADING_FRAGMENT: {
    label: "Suspected heading fragment",
    severity: "info",
    explanation: "A heading ends with sentence punctuation, which can indicate a wrapped paragraph was promoted.",
    action: "Confirm whether the row is truly a heading or should remain body content.",
  },
  HEADING_BY_FORMATTING: {
    label: "Heading inferred by formatting",
    severity: "info",
    explanation: "The heading was inferred from formatting or numbering rather than an explicit heading style.",
    action: "Verify the visual source heading before accepting the inferred hierarchy.",
  },
  HEADING_IN_CELL: {
    label: "Heading inside table cell",
    severity: "warning",
    explanation: "A paragraph inside a table cell was promoted to a heading, which is usually a false positive.",
    action: "Check the table cell and demote the block if it is regular cell content.",
  },
  SYNTHETIC_ROOT_HEADING: {
    label: "Synthetic root heading",
    severity: "warning",
    explanation: "The structure tree created a root heading because body content had no real top-level heading.",
    action: "Review the document opening and confirm the synthetic container is acceptable.",
  },
  ASSET_REF_UNRESOLVED: {
    label: "Unresolved asset reference",
    severity: "error",
    explanation: "A source block references an extracted asset that is missing from the asset manifest.",
    action: "Open the source and asset list, then re-extract or repair the missing asset reference.",
  },
  NESTED_TABLE: {
    label: "Nested table",
    severity: "info",
    explanation: "A table row contains one or more nested tables emitted as separate source blocks.",
    action: "Verify the parent row and nested rows preserve the source table relationship.",
  },
  DEEP_NESTING_UNSUPPORTED: {
    label: "Deep nested table unsupported",
    severity: "error",
    explanation: "A nested table contains another nested table beyond the extractor's supported depth.",
    action: "Inspect the source table and manually account for content below the supported nesting level.",
  },
  FLOATING_TABLE: {
    label: "Floating table",
    severity: "warning",
    explanation: "A floating or text-wrapped table may not appear in the same reading order as the source.",
    action: "Compare the table position in the source with the extracted document order.",
  },
  POSSIBLY_CALLOUT: {
    label: "Possible callout",
    severity: "info",
    explanation: "A short formatted paragraph may be a callout or note instead of normal body text.",
    action: "Check the source styling and decide whether the block needs note/callout treatment.",
  },
  SUBDOC_UNSUPPORTED: {
    label: "Sub-document unsupported",
    severity: "error",
    explanation: "The DOCX references a linked sub-document that this extractor does not follow.",
    action: "Open the source package and process the linked sub-document separately if needed.",
  },
  MATH_CONTENT: {
    label: "Math content",
    severity: "warning",
    explanation: "The paragraph contains OOXML math and the extracted text may only be a placeholder.",
    action: "Compare the equation in the source and capture or repair the math content.",
  },
  HAS_INSERTIONS: {
    label: "Tracked insertions present",
    severity: "warning",
    explanation: "Tracked-change insertions are present in the source paragraph.",
    action: "Review the source changes and confirm whether inserted text should be kept.",
  },
  HAS_DELETIONS: {
    label: "Tracked deletions present",
    severity: "warning",
    explanation: "Tracked-change deletions are present; deleted text is not reflected as normal extracted content.",
    action: "Review the source changes and confirm the surviving text is correct.",
  },
  SMARTART_DROPPED: {
    label: "SmartArt dropped",
    severity: "error",
    explanation: "A SmartArt diagram was detected but not extracted.",
    action: "Inspect the source diagram and capture the missing content manually or re-extract with support.",
  },
  HIDDEN_TEXT_DROPPED: {
    label: "Hidden text dropped",
    severity: "warning",
    explanation: "Hidden text runs were filtered out of the extracted paragraph.",
    action: "Open the source paragraph and confirm the hidden content was intentionally excluded.",
  },
  MULTI_COLUMN: {
    label: "Multi-column layout",
    severity: "warning",
    explanation: "The section uses multi-column layout that may be flattened in a different reading order.",
    action: "Compare extracted order with the source columns before approving the section.",
  },
  NO_HEADINGS_FOUND: {
    label: "No headings found",
    severity: "warning",
    explanation: "No high-confidence heading styles were found in the document body.",
    action: "Review the structure tree and add or confirm section boundaries before downstream use.",
  },
} as const satisfies Record<string, ReviewFlagLabel>;

export type ReviewFlagCode = keyof typeof REVIEW_FLAG_LABELS;

export function reviewFlagLabel(code: string): ReviewFlagLabel | null {
  if (code in REVIEW_FLAG_LABELS) return REVIEW_FLAG_LABELS[code as ReviewFlagCode];
  return null;
}
