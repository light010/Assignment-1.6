export type Panel = "source" | "workbench" | "artifacts" | "jobs" | "topic-plan" | "review" | "export";
