import { describe, expect, it } from "vitest";
import { buildRelationshipConnectors } from "./useRelationshipConnectors";
import { WorkbenchState } from "./workbenchModel";

describe("buildRelationshipConnectors", () => {
  it("skips relationships when a source anchor is missing", () => {
    const connectors = buildRelationshipConnectors({
      state: makeState(),
      overlayRect: rect(0, 0, 0, 0),
      sourceRects: new Map([["block_a", rect(10, 80, 10, 20)]]),
      unitRects: new Map([["unit_a", rect(20, 300, 260, 24)]]),
      selectedSourceIds: ["block_a", "block_missing"],
      activeSourceIds: [],
      selectedUnitIds: ["unit_a"],
    });

    expect(connectors).toHaveLength(1);
    expect(connectors[0]?.id).toBe("block_a-unit_a");
  });

  it("does not draw connectors for missing unit anchors", () => {
    const connectors = buildRelationshipConnectors({
      state: makeState(),
      overlayRect: rect(0, 0, 0, 0),
      sourceRects: new Map([["block_a", rect(10, 80, 10, 20)]]),
      unitRects: new Map(),
      selectedSourceIds: ["block_a"],
      activeSourceIds: [],
      selectedUnitIds: ["unit_a"],
    });

    expect(connectors).toEqual([]);
  });
});

function makeState(): WorkbenchState {
  return {
    document_id: "doc",
    unassigned_units: [],
    topics: [
      {
        topic_id: "topic_a",
        title: "Topic A",
        topic_type: "concept",
        source_block_ids: ["block_a", "block_missing"],
        boundary_confidence: 0.9,
        type_confidence: 0.9,
        review_required: false,
        review_issues: [],
        validation_issues: [],
        validation_stale: false,
        units: [
          {
            unit_id: "unit_a",
            topic_id: "topic_a",
            source_block_ids: ["block_a", "block_missing"],
            text: "A",
            block_type: "paragraph",
            confidence: 0.9,
          },
        ],
      },
    ],
  };
}

function rect(top: number, right: number, left: number, height: number) {
  return { top, right, left, height };
}
