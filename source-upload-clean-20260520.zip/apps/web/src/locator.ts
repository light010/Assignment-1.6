export type ParsedLocator =
  | { kind: "docx_p"; index: number }
  | { kind: "docx_table_row"; tableIndex: number; rowIndex: number }
  | { kind: "docx_nested_table_row"; outerTableIndex: number; outerRowIndex: number; innerTableIndex: number; innerRowIndex: number }
  | { kind: "docx_header"; sectionId: string; index: number }
  | { kind: "docx_footer"; sectionId: string; index: number }
  | { kind: "docx_footnote"; id: number }
  | { kind: "docx_endnote"; id: number }
  | { kind: "pdf_bbox"; page: number; left: number; top: number; width: number; height: number };

/**
 * Step I2: locator regex pattern, EXPORTED as a string so the
 * architecture-lock test in `tests/test_locator_pattern_unified.py` can
 * compare it byte-for-byte against the Python `LOCATOR_PATTERN_STRING`
 * and `source-block.schema.json#section.pattern`.
 *
 * Notes on representation:
 *  - Python uses `\\d` inside JSON-escaped schema patterns; TS source
 *    uses bare `\d` in a `RegExp` literal. The comparison test
 *    accounts for this by reading both as their canonical string forms.
 *  - `pdf:p:[1-9]\d*` (≥1) fix for audit I-audit-3.
 */
export const LOCATOR_PATTERN_STRING =
  "^(?:docx:p:(\\d+)|docx:tbl:(\\d+):r:(\\d+)|docx:tbl:(\\d+):r:(\\d+):tbl:(\\d+):r:(\\d+)|docx:hdr:([A-Za-z0-9_.-]+):p:(\\d+)|docx:ftr:([A-Za-z0-9_.-]+):p:(\\d+)|docx:footnote:(\\d+)|docx:endnote:(\\d+)|pdf:p:([1-9]\\d*):bbox:(-?\\d+(?:\\.\\d+)?):(-?\\d+(?:\\.\\d+)?):(-?\\d+(?:\\.\\d+)?):(-?\\d+(?:\\.\\d+)?))$";

const LOCATOR_RE = new RegExp(LOCATOR_PATTERN_STRING);

export function parseLocator(value?: string | null): ParsedLocator | null {
  if (!value) return null;
  const match = LOCATOR_RE.exec(value);
  if (!match) return null;
  if (match[1] !== undefined) return { kind: "docx_p", index: Number(match[1]) };
  if (match[2] !== undefined) {
    return { kind: "docx_table_row", tableIndex: Number(match[2]), rowIndex: Number(match[3]) };
  }
  if (match[4] !== undefined) {
    return {
      kind: "docx_nested_table_row",
      outerTableIndex: Number(match[4]),
      outerRowIndex: Number(match[5]),
      innerTableIndex: Number(match[6]),
      innerRowIndex: Number(match[7]),
    };
  }
  if (match[8] !== undefined) return { kind: "docx_header", sectionId: match[8], index: Number(match[9]) };
  if (match[10] !== undefined) return { kind: "docx_footer", sectionId: match[10], index: Number(match[11]) };
  if (match[12] !== undefined) return { kind: "docx_footnote", id: Number(match[12]) };
  if (match[13] !== undefined) return { kind: "docx_endnote", id: Number(match[13]) };
  return {
    kind: "pdf_bbox",
    page: Number(match[14]),
    left: Number(match[15]),
    top: Number(match[16]),
    width: Number(match[17]),
    height: Number(match[18]),
  };
}

/**
 * Step I5: complete the TS formatter surface so every locator kind has
 * both a Python and a TS builder. Pre-Step-I the TS side only had
 * `formatDocxParagraphLocator` and `formatDocxTableRowLocator` — six
 * kinds were Python-only. Tests in `tests/test_locator_pattern_unified.py`
 * verify each TS formatter produces a string byte-identical to its
 * Python counterpart for the same inputs.
 *
 * Validation rules mirror the Python helpers in `locator.py`:
 *  - non-negative indices required (>= 0)
 *  - PDF page must be >= 1
 *  - section IDs must match `[A-Za-z0-9_.-]+`
 *  - bbox floats formatted with `_formatBboxComponent` (fixed-point,
 *    trailing zeros stripped, no scientific notation) — mirrors
 *    audit I-audit-4 fix on the Python side.
 */
const SECTION_ID_RE = /^[A-Za-z0-9_.-]+$/;

function requireNonNegative(name: string, value: number) {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`${name} must be a non-negative integer; got ${value}`);
  }
}

function _formatBboxComponent(value: number): string {
  if (!Number.isFinite(value)) {
    throw new Error(`bbox component must be finite; got ${value}`);
  }
  // Mirror Python `f"{value:.6f}".rstrip("0").rstrip(".")` exactly so
  // both sides produce byte-identical strings for the same input.
  const fixed = value.toFixed(6);
  const trimmed = fixed.replace(/0+$/, "").replace(/\.$/, "");
  if (trimmed === "" || trimmed === "-0") return "0";
  return trimmed;
}

export function formatDocxParagraphLocator(index: number) {
  requireNonNegative("paragraph index", index);
  return `docx:p:${index}`;
}

export function formatDocxTableRowLocator(tableIndex: number, rowIndex: number) {
  requireNonNegative("table index", tableIndex);
  requireNonNegative("row index", rowIndex);
  return `docx:tbl:${tableIndex}:r:${rowIndex}`;
}

export function formatDocxNestedTableRowLocator(
  outerTableIndex: number,
  outerRowIndex: number,
  innerTableIndex: number,
  innerRowIndex: number,
) {
  requireNonNegative("outer table index", outerTableIndex);
  requireNonNegative("outer row index", outerRowIndex);
  requireNonNegative("inner table index", innerTableIndex);
  requireNonNegative("inner row index", innerRowIndex);
  return `docx:tbl:${outerTableIndex}:r:${outerRowIndex}:tbl:${innerTableIndex}:r:${innerRowIndex}`;
}

export function formatDocxHeaderLocator(sectionId: string, index: number) {
  if (!SECTION_ID_RE.test(sectionId)) {
    throw new Error(`Invalid DOCX section id: ${JSON.stringify(sectionId)}`);
  }
  requireNonNegative("header paragraph index", index);
  return `docx:hdr:${sectionId}:p:${index}`;
}

export function formatDocxFooterLocator(sectionId: string, index: number) {
  if (!SECTION_ID_RE.test(sectionId)) {
    throw new Error(`Invalid DOCX section id: ${JSON.stringify(sectionId)}`);
  }
  requireNonNegative("footer paragraph index", index);
  return `docx:ftr:${sectionId}:p:${index}`;
}

export function formatDocxFootnoteLocator(noteId: number) {
  requireNonNegative("footnote id", noteId);
  return `docx:footnote:${noteId}`;
}

export function formatDocxEndnoteLocator(noteId: number) {
  requireNonNegative("endnote id", noteId);
  return `docx:endnote:${noteId}`;
}

export function formatPdfBboxLocator(
  page: number,
  left: number,
  top: number,
  width: number,
  height: number,
) {
  if (!Number.isInteger(page) || page < 1) {
    throw new Error(`PDF locator page must be >= 1; got ${page}`);
  }
  return (
    `pdf:p:${page}` +
    `:bbox:${_formatBboxComponent(left)}` +
    `:${_formatBboxComponent(top)}` +
    `:${_formatBboxComponent(width)}` +
    `:${_formatBboxComponent(height)}`
  );
}
