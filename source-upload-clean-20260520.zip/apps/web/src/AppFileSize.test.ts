import { describe, expect, it } from "vitest";

import fs from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

// Architecture lock — Phase 3 M1 of plans/architecture-hardening.md.
//
// The pre-Phase-3 `App.tsx` was 3200 lines. M1 split it into
// orchestration (AppCore) + chrome + feature components. Without
// per-module size locks the god-module pattern re-emerges silently as
// features land.
//
// Two-tier cap policy:
//   1000 lines — App.tsx (the shell), feature components
//   (SourcePanel, UploadHub, SourceEvidenceViewer, WorkbenchPanel,
//   extractionExplorerModel). These legitimately carry more content
//   than orchestration files and the cap leaves breathing room while
//   preventing unbounded growth.
//   800 lines — AppCore (the orchestrator). Tighter because
//   orchestration code is mostly wiring; growth above 800 signals a
//   responsibility leak.
//
// Per-module current sizes captured at 2026-05-11. Follow-up M1.2
// in the plan tracks the next-tier split for each module nearing its cap.

describe("App entrypoint size", () => {
  function lineCount(file: string) {
    const appPath = path.resolve(path.dirname(fileURLToPath(import.meta.url)), file);
    return fs.readFileSync(appPath, "utf8").split("\n").length;
  }

  it("keeps App.tsx as a small shell", () => {
    expect(lineCount("App.tsx")).toBeLessThanOrEqual(1000);
  });

  it("keeps AppCore focused on orchestration", () => {
    expect(lineCount("AppCore.tsx")).toBeLessThanOrEqual(800);
  });

  it("keeps extracted document modules present", () => {
    for (const file of [
      "BusinessUnitDashboard.tsx",
      "UploadHub.tsx",
      "DocumentDetail.tsx",
      "SourcePanel.tsx",
      "ExtractionReviewBanner.tsx",
    ]) {
      expect(lineCount(file)).toBeGreaterThan(0);
    }
  });

  // M1 follow-up locks: cap each large feature module at the 1000-line
  // threshold so it can't quietly grow into the next god-module. When a
  // module hits the cap, split it (see plan §M1.2) rather than bumping
  // the cap.
  const featureCaps: Array<[string, number]> = [
    ["SourcePanel.tsx", 1000],
    ["UploadHub.tsx", 1000],
    ["SourceEvidenceViewer.tsx", 1000],
    ["WorkbenchPanel.tsx", 1000],
    ["extractionExplorerModel.ts", 1000],
  ];

  for (const [file, cap] of featureCaps) {
    it(`caps ${file} at ${cap} lines`, () => {
      expect(lineCount(file)).toBeLessThanOrEqual(cap);
    });
  }
});
