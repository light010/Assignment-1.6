import { describe, expect, it } from "vitest";
import {
  applyWorkbenchOp,
  applyWorkbenchOps,
  buildWorkbenchState,
  computeCoverage,
  WorkbenchOp,
} from "./workbenchModel";
import { SourceBlock, TopicCandidate } from "./api";

const blocks: SourceBlock[] = [
  block("blk_h1", "heading", "Apple CA Running Garnishment"),
  block("blk_001", "procedure_step", "Pull Garnishment report."),
  block("blk_002", "procedure_step", "Create a ticket to T46."),
  block("blk_003", "procedure_step", "Send confirmation to client."),
  block("blk_ref", "paragraph", "Apple CA Blueprint"),
];

const candidates: TopicCandidate[] = [
  candidate("tc_garnishment", "Apple CA Running Garnishment", "task", ["blk_h1", "blk_001", "blk_002", "blk_003"]),
  candidate("tc_resources", "Apple CA Additional Resources", "reference", ["blk_ref"]),
];

describe("workbenchModel", () => {
  it("merges adjacent units", () => {
    const state = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    const next = applyWorkbenchOp(state, {
      kind: "merge_units",
      op_id: "op1",
      topic_id: "tc_garnishment",
      unit_ids: ["unit_blk_001", "unit_blk_002"],
    });

    const topic = next.topics[0]!;
    expect(topic.units.map((unit) => unit.unit_id)).toContain("unit_merge_op1");
    expect(topic.units.find((unit) => unit.unit_id === "unit_merge_op1")?.source_block_ids).toEqual([
      "blk_001",
      "blk_002",
    ]);
    expect(topic.validation_stale).toBe(true);
  });

  it("rejects merge across topics", () => {
    const state = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    expect(() =>
      applyWorkbenchOp(state, {
        kind: "merge_units",
        op_id: "op1",
        topic_id: "tc_garnishment",
        unit_ids: ["unit_blk_003", "unit_blk_ref"],
      }),
    ).toThrow(/same topic/);
  });

  it("splits a unit at a valid offset", () => {
    const state = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    const next = applyWorkbenchOp(state, {
      kind: "split_unit",
      op_id: "op2",
      topic_id: "tc_garnishment",
      unit_id: "unit_blk_002",
      offset: 8,
    });

    const topic = next.topics[0]!;
    expect(topic.units.some((unit) => unit.unit_id === "unit_blk_002_split_a_op2")).toBe(true);
    expect(topic.units.some((unit) => unit.unit_id === "unit_blk_002_split_b_op2")).toBe(true);
  });

  it("rejects split at boundaries and merged units", () => {
    const state = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    expect(() =>
      applyWorkbenchOp(state, {
        kind: "split_unit",
        op_id: "op2",
        topic_id: "tc_garnishment",
        unit_id: "unit_blk_002",
        offset: 0,
      }),
    ).toThrow(/cannot be split/i);

    const merged = applyWorkbenchOp(state, {
      kind: "merge_units",
      op_id: "op1",
      topic_id: "tc_garnishment",
      unit_ids: ["unit_blk_001", "unit_blk_002"],
    });
    expect(() =>
      applyWorkbenchOp(merged, {
        kind: "split_unit",
        op_id: "op3",
        topic_id: "tc_garnishment",
        unit_id: "unit_merge_op1",
        offset: 5,
      }),
    ).toThrow(/cannot be split/i);
  });

  it("moves units between topics", () => {
    const state = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    const next = applyWorkbenchOp(state, {
      kind: "move_units",
      op_id: "op4",
      from_topic_id: "tc_garnishment",
      to_topic_id: "tc_resources",
      unit_ids: ["unit_blk_003"],
    });

    expect(next.topics[0]!.units.some((unit) => unit.unit_id === "unit_blk_003")).toBe(false);
    expect(next.topics[1]!.units.some((unit) => unit.unit_id === "unit_blk_003")).toBe(true);
    expect(next.topics[0]!.validation_stale).toBe(true);
    expect(next.topics[1]!.validation_stale).toBe(true);
  });

  it("replays undo and redo stacks correctly", () => {
    const base = buildWorkbenchState({ documentId: "doc", blocks, candidates });
    const ops: WorkbenchOp[] = [
      {
        kind: "rename_topic",
        op_id: "op5",
        topic_id: "tc_resources",
        title: "Apple CA Resource Links",
      },
      {
        kind: "retype_topic",
        op_id: "op6",
        topic_id: "tc_resources",
        topic_type: "concept",
      },
    ];
    const applied = applyWorkbenchOps(base, ops);
    const undone = applyWorkbenchOps(base, ops.slice(0, 1));
    const redone = applyWorkbenchOps(base, ops);

    expect(applied.topics[1]!.title).toBe("Apple CA Resource Links");
    expect(undone.topics[1]!.topic_type).toBe("reference");
    expect(redone.topics[1]!.topic_type).toBe("concept");
  });

  it("detects unassigned coverage", () => {
    const partial = buildWorkbenchState({
      documentId: "doc",
      blocks,
      candidates: [candidate("tc_partial", "Partial", "concept", ["blk_h1"])],
    });
    const coverage = computeCoverage(partial, blocks);

    expect(coverage.unassigned).toEqual(["blk_001", "blk_002", "blk_003", "blk_ref"]);
    expect(coverage.assigned).toBe(1);
  });
});

function block(block_id: string, block_type: SourceBlock["block_type"], text: string): SourceBlock {
  return {
    block_id,
    block_type,
    text,
    source_location: { page: 1 },
    confidence: { extraction: 0.9, block_type: 0.9 },
  };
}

function candidate(
  topic_candidate_id: string,
  title: string,
  topic_type: TopicCandidate["topic_type"],
  source_block_ids: string[],
): TopicCandidate {
  return {
    topic_candidate_id,
    title,
    topic_type,
    source_block_ids,
    boundary_confidence: 0.84,
    type_confidence: 0.84,
    reason: "test",
  };
}
