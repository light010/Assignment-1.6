function defaultApiBaseUrl() {
  const { protocol, hostname } = window.location;
  if (hostname === "localhost" || hostname === "127.0.0.1") {
    return `${protocol}//${hostname}:8000`;
  }
  return "http://localhost:8000";
}

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || defaultApiBaseUrl();

export type User = {
  user_id: string;
  tenant_id: string;
  organization_id: string;
  email: string;
  name: string;
  roles: string[];
};

export type BusinessUnitDocumentsResponse = {
  business_unit_id: string;
  documents: DocumentRecord[];
};

export type BusinessUnitSummary = {
  document_count: number;
  processing_count: number;
  review_ready_count: number;
  validation_warning_count: number;
  failed_job_count: number;
  export_ready_count: number;
  avg_source_confidence: number | null;
  storage_bytes: number;
  last_activity_at: string | null;
  current_user_role: string | null;
  dominant_status_label: string;
  is_favorite?: boolean;
};

export type BusinessUnit = {
  business_unit_id: string;
  tenant_id: string;
  organization_id: string;
  name: string;
  description?: string | null;
  owner_team?: string | null;
  region?: string | null;
  status: string;
  policy: {
    target_dita_version: string;
    allowed_upload_extensions: string[];
    max_upload_bytes: number;
    review_policy: string;
  };
  summary: BusinessUnitSummary;
};

export type DocumentRecord = {
  document_id: string;
  filename: string;
  content_type?: string | null;
  status: string;
  extraction_failure_reason?: string | null;
  topic_ids: string[];
  job_ids: string[];
  source_hash: string;
  source_quality: {
    overall_confidence: number;
    review_required: boolean;
    validation_issue_count: number;
    quality_gate?: QualityGate | null;
  };
  created_at?: string;
  extraction?: ExtractionStatus;
};

export type ArtifactEntry = {
  artifact_id: string;
  document_id: string;
  name: string;
  artifact_version: string | number;
  version?: string | number;
  content_type: string;
  size_bytes: number;
  hash: string;
  sha256?: string;
  path: string;
  producer?: string;
  created_by?: string | null;
  created_at?: string;
  previous_version_id?: string | null;
};

export type JobRecord = {
  job_id: string;
  document_id: string;
  stage: string;
  status: string;
  events: string[];
  created_at?: string;
};

export type TopicRecord = {
  topic_record_id: string;
  topic_id: string;
  status: string;
  generated_topic: {
    title: string;
    topic_type: string;
    topic_candidate_id?: string;
    source_block_ids?: string[];
    confidence: Record<string, number>;
  };
  dita_xml: string;
  validation_issues: Array<{ severity: string; code: string; message: string; path?: string }>;
  traceability: Array<{ target_path: string; source_block_ids: string[] }>;
  artifact_version: string;
};

export type TopicType = "concept" | "task" | "reference" | "troubleshooting" | "glossary";

export type TopicCandidate = {
  topic_candidate_id: string;
  title: string;
  topic_type: TopicType | string;
  source_block_ids: string[];
  boundary_confidence: number;
  type_confidence?: number;
  review_required?: boolean;
  review_issues?: Array<{ code: string; severity: string; message: string; source_block_ids: string[] }>;
  reason: string;
};

export type TopicPlanDocument = {
  document_id: string;
  filename: string;
  approved: boolean;
  topic_plan: {
    topic_candidates: TopicCandidate[];
    confidence?: Record<string, number>;
    review_required?: boolean;
    review_issues?: Array<{ code: string; severity: string; message: string; source_block_ids: string[] }>;
  };
};

export type SourceBlock = {
  id?: string;
  type?: string;
  block_id: string;
  block_type: string;
  text: string;
  source_location: { page?: number | null; section?: string | null; bbox?: number[] | null };
  bbox?: number[] | null;
  page?: number | null;
  order_in_page?: number;
  inferred_level?: number | null;
  heading_path_ids?: string[];
  style_summary?: Record<string, unknown>;
  font?: { size?: number | null; family?: string | null; weight?: string | null };
  warnings?: string[];
  review_flags?: ReviewFlag[];
  numbering?: {
    level?: number | null;
    num_id?: string | null;
    format?: string | null;
    level_text?: string | null;
    label?: string | null;
  } | null;
  inline_runs?: Array<{
    text: string;
    start?: number;
    end?: number;
    href?: string | null;
    marks?: string[];
    semantic_hint?: string | null;
  }>;
  table_id?: string;
  row_index?: number;
  cells?: Array<{ text: string; colspan?: number; rowspan?: number }>;
  content_hash?: string | null;
  parent_block_id?: string | null;
  lineage?: string[];
  is_likely_heading?: boolean;
  confidence_signals?: Record<string, unknown>;
  confidence: Record<string, number | null>;
};

export type ReviewFlag = string | {
  code?: string;
  severity?: "info" | "warning" | "error" | string;
  message?: string;
  action?: string;
  label?: string;
  explanation?: string;
};

export type ExtractionWarning = {
  warning_id: string;
  kind: string;
  severity: "info" | "warning" | "error";
  message: string;
  source_block_ids: string[];
  metadata?: Record<string, unknown>;
};

export type ExtractionStatus = {
  extraction_id: string;
  document_id: string;
  stage: string;
  started_at?: string | null;
  finished_at?: string | null;
  error?: {
    kind: string;
    message: string;
    stage: string;
    retryable: boolean;
    metadata?: Record<string, unknown>;
  } | null;
  warnings: ExtractionWarning[];
  block_count: number;
  asset_count: number;
};

export type SourceQuality = {
  overall_confidence: number;
  review_required: boolean;
  validation_issue_count: number;
  quality_gate?: QualityGate | null;
  warnings?: ExtractionWarning[];
  block_count?: number;
  asset_count?: number;
  extraction_error?: ExtractionStatus["error"];
};

/**
 * Gate summary embedded in document records and source_quality. Mirrors
 * the schema's `gate` shape. For the full extraction-quality artifact
 * (with metrics + runtime), see `ExtractionQualityArtifact`.
 *
 * H-audit-3 (Step H): previously a single `QualityGate` type tried to
 * represent both the embedded summary and the full artifact. Splitting
 * the two keeps inline usages from accidentally requiring metrics/runtime
 * and gives the artifact endpoint its own typed shape.
 */
export type QualityGate = {
  name: "docx_source_fidelity_v1" | "legacy_pre_gate";
  passed: boolean;
  severity: "blocking" | "warning" | "info";
  blocking_reasons: string[];
  warnings?: Array<{ kind: string; message: string; source_block_ids?: string[] }>;
  override?: GateOverride | null;
  override_history?: GateOverride[];
};

export type GateOverride = {
  by: string;
  at: string;
  reason: string;
  // Step G2: snapshot of the pre-override gate state. Optional on
  // historical entries that pre-date G2.
  prior_gate?: {
    passed: boolean | null;
    severity: string | null;
    blocking_reasons: string[];
    warnings: Array<{ kind: string; message: string; source_block_ids?: string[] }>;
  } | null;
};

/**
 * Full `extraction-quality.json` artifact shape, mirroring
 * `contracts/artifacts/extraction-quality.schema.json`. Returned by
 * GET `/v1/documents/{id}/artifacts/extraction-quality.json`.
 */
export type ExtractionQualityArtifact = {
  schema_version: 1;
  document_id: string;
  gate: QualityGate;
  metrics: {
    total_source_blocks: number;
    located_source_blocks: number;
    unlocated_source_block_ids: string[];
    block_type_histogram: Record<string, number>;
    structure_confidence: number | null;
    repaired_level_count: number;
    review_flag_counts: Record<string, number>;
    asset_resolution_rate: number;
  };
  runtime: {
    extractor_version: string;
    pandoc_version: string | null;
    mdformat_version: string | null;
    duration_ms: number;
    pandoc_warnings: string[];
  };
};

export type ExtractionReviewSummary = {
  status: string;
  extraction_failure_reason?: string | null;
  block_count: number;
  located_block_count: number;
  unlocated_source_block_ids: string[];
  review_flag_counts: Record<string, number>;
  blocked_groups: Array<{
    code: string;
    label: string;
    severity: string;
    count: number;
    sample_block_ids: string[];
  }>;
  gate: QualityGate | null;
  catalog: Record<string, {
    label: string;
    severity: "info" | "warning" | "error";
    explanation: string;
    action: string;
  }>;
};

export type AssetRecord = {
  asset_id: string;
  document_id: string;
  filename: string;
  content_type: string;
  size_bytes: number;
  hash: string;
  sha256?: string;
  width?: number | null;
  height?: number | null;
  caption?: string | null;
  source_block_id?: string | null;
  dita_href: string;
  preview_url?: string;
};

function token() {
  if (typeof localStorage === "undefined" || typeof localStorage.getItem !== "function") return null;
  return localStorage.getItem("ditagen.access_token");
}

function refreshToken() {
  return localStorage.getItem("ditagen.refresh_token");
}

function expireSession() {
  logout();
  window.dispatchEvent(new Event("ditagen:session-expired"));
}

async function responseError(response: Response) {
  const text = await response.text();
  if (!text) return response.statusText;
  try {
    const parsed = JSON.parse(text);
    return typeof parsed.detail === "string" ? parsed.detail : text;
  } catch {
    return text;
  }
}

/**
 * Typed error thrown by `api<T>` for non-2xx responses. Carries the HTTP
 * status code so callers can branch on specific failure modes (the
 * Step H1 reextract throttle needs to detect 429 and surface
 * Retry-After). Stays an `Error` subclass so existing `catch (err)`
 * handlers that use `err.message` keep working.
 */
export class ApiError extends Error {
  status: number;
  retryAfterSeconds: number | null;

  constructor(status: number, message: string, retryAfterSeconds: number | null = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

async function refreshAccessToken() {
  const refresh = refreshToken();
  if (!refresh) {
    throw new Error("Session expired");
  }
  const response = await fetch(`${API_BASE_URL}/v1/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refresh }),
  });
  if (!response.ok) {
    throw new Error(await responseError(response));
  }
  const result = (await response.json()) as { access_token: string; user: User };
  localStorage.setItem("ditagen.access_token", result.access_token);
  localStorage.setItem("ditagen.user", JSON.stringify(result.user));
  return result.user;
}

export async function api<T>(path: string, init: RequestInit = {}, retryOnUnauthorized = true): Promise<T> {
  const headers = new Headers(init.headers);
  if (!(init.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (token()) {
    headers.set("Authorization", `Bearer ${token()}`);
  }
  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers });
  if (response.status === 401 && retryOnUnauthorized && path !== "/v1/auth/refresh") {
    try {
      await refreshAccessToken();
      return api<T>(path, init, false);
    } catch {
      expireSession();
      throw new Error("Session expired");
    }
  }
  if (!response.ok) {
    const message = await responseError(response);
    const retryAfterRaw = response.headers.get("Retry-After");
    const retryAfter = retryAfterRaw ? Number.parseInt(retryAfterRaw, 10) : Number.NaN;
    throw new ApiError(
      response.status,
      message,
      Number.isFinite(retryAfter) ? retryAfter : null,
    );
  }
  return response.json() as Promise<T>;
}

export async function login(email: string, password: string) {
  const result = await api<{ access_token: string; refresh_token: string; user: User }>(
    "/v1/auth/login",
    {
      method: "POST",
      body: JSON.stringify({ email, password }),
    },
    false,
  );
  localStorage.setItem("ditagen.access_token", result.access_token);
  localStorage.setItem("ditagen.refresh_token", result.refresh_token);
  localStorage.setItem("ditagen.user", JSON.stringify(result.user));
  return result.user;
}

export function logout() {
  localStorage.removeItem("ditagen.access_token");
  localStorage.removeItem("ditagen.refresh_token");
  localStorage.removeItem("ditagen.user");
  localStorage.removeItem("ditagen.business_unit_id");
}

export function storedUser(): User | null {
  const raw = localStorage.getItem("ditagen.user");
  return raw ? (JSON.parse(raw) as User) : null;
}

export async function deleteDocument(documentId: string) {
  return api<{ ok: true }>(`/v1/documents/${documentId}`, {
    method: "DELETE",
  });
}

export async function uploadBusinessUnitDocument(businessUnitId: string, file: File) {
  const form = new FormData();
  form.append("file", file);
  return api<{ document: DocumentRecord; job: JobRecord }>(
    `/v1/business-units/${businessUnitId}/documents/uploads`,
    {
      method: "POST",
      body: form,
    },
  );
}

export function storedBusinessUnitId() {
  return localStorage.getItem("ditagen.business_unit_id") || "";
}

export function storeBusinessUnitId(businessUnitId: string) {
  if (businessUnitId) {
    localStorage.setItem("ditagen.business_unit_id", businessUnitId);
  } else {
    localStorage.removeItem("ditagen.business_unit_id");
  }
}

export async function listBusinessUnits() {
  return api<{ business_units: BusinessUnit[] }>("/v1/business-units");
}

export async function createBusinessUnit(payload: {
  name: string;
  description?: string;
  owner_team?: string;
  region?: string;
}) {
  return api<BusinessUnit>("/v1/business-units", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function getBusinessUnit(businessUnitId: string) {
  return api<BusinessUnit>(`/v1/business-units/${businessUnitId}`);
}

export async function deleteBusinessUnit(businessUnitId: string) {
  return api<{ ok: true }>(`/v1/business-units/${businessUnitId}`, {
    method: "DELETE",
  });
}

export async function listBusinessUnitDocuments(businessUnitId: string) {
  return api<BusinessUnitDocumentsResponse>(`/v1/business-units/${businessUnitId}/documents`);
}

export async function getDocumentBlocks(documentId: string, cursor = 0, limit = 500) {
  return api<{ items: SourceBlock[]; next_cursor?: number | null }>(
    `/v1/documents/${documentId}/blocks?cursor=${cursor}&limit=${limit}`,
  );
}

export async function getAllDocumentBlocks(documentId: string) {
  const items: SourceBlock[] = [];
  let cursor: number | null | undefined = 0;
  while (cursor !== null && cursor !== undefined) {
    const result = await getDocumentBlocks(documentId, cursor, 500);
    items.push(...result.items);
    cursor = result.next_cursor;
  }
  return { items };
}

export async function getDocumentMarkdown(documentId: string) {
  return api<{ document_id: string; markdown: string }>(`/v1/documents/${documentId}/markdown`);
}

export async function getDocumentAssets(documentId: string) {
  return api<{ document_id: string; assets: AssetRecord[] }>(`/v1/documents/${documentId}/assets`);
}

export async function getDocumentSourceQuality(documentId: string) {
  return api<SourceQuality>(`/v1/documents/${documentId}/source-quality`);
}

export async function getDocumentExtractionQuality(documentId: string) {
  return api<ExtractionQualityArtifact>(
    `/v1/documents/${documentId}/artifacts/extraction-quality.json`,
  );
}

export async function getDocumentExtractionReviewSummary(documentId: string) {
  return api<ExtractionReviewSummary>(`/v1/documents/${documentId}/extraction-review-summary`);
}

/**
 * Step H1 — POST `/reextract`. The upload-service throttles to one
 * attempt per document per 600s (Step G1). Callers MUST handle 429:
 * inspect `error.status === 429` and read the `Retry-After` header.
 *
 * Returns the updated DocumentRecord on success. Throws `ApiError` with
 * `status` and (when 429) `retryAfterSeconds` on failure.
 */
export async function reextractDocument(documentId: string): Promise<DocumentRecord> {
  return api<DocumentRecord>(`/v1/documents/${documentId}/reextract`, { method: "POST" });
}

/**
 * Step H2 — POST `/override-gate`. The reason is server-validated
 * (minLength 1 at the schema level; H2's UI enforces minLength 5).
 */
export async function overrideDocumentGate(
  documentId: string,
  reason: string,
): Promise<DocumentRecord> {
  return api<DocumentRecord>(`/v1/documents/${documentId}/override-gate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ reason }),
  });
}

export async function getDocumentTopicPlan(documentId: string) {
  return api<TopicPlanDocument>(`/v1/documents/${documentId}/topic-plan`);
}

export async function getTopicRecord(topicId: string) {
  return api<TopicRecord>(`/v1/topics/${topicId}`);
}

export function exportDownloadUrl(exportId: string) {
  return `${API_BASE_URL}/v1/exports/${exportId}/download?access_token=${encodeURIComponent(token() || "")}`;
}

export function assetContentUrl(documentId: string, assetId: string) {
  return `${API_BASE_URL}/v1/documents/${documentId}/assets/${assetId}?access_token=${encodeURIComponent(token() || "")}`;
}

export function sourceFileUrl(documentId: string) {
  return `${API_BASE_URL}/v1/documents/${documentId}/source-file?access_token=${encodeURIComponent(token() || "")}`;
}
