import { describe, expect, it } from "vitest";
import { ExtractionReviewSummary, SourceBlock } from "./api";
import { buildExtractionExplorer } from "./extractionExplorerModel";
import { REVIEW_FLAG_LABELS } from "./reviewFlagLabels";

describe("attention selector parity", () => {
  it("keeps row badges, summary counts, and attention counts aligned", () => {
    const blocks = [
      block("h1", "heading", "Apple CA"),
      block("b1", "paragraph", "Missing asset", [{ code: "ASSET_REF_UNRESOLVED" }]),
      block("b2", "paragraph", "Nested table", [{ code: "NESTED_TABLE" }]),
      block("b3", "paragraph", "Normal row"),
    ];
    const summary: ExtractionReviewSummary = {
      status: "ready_for_review",
      extraction_failure_reason: null,
      block_count: blocks.length,
      located_block_count: blocks.length,
      unlocated_source_block_ids: [],
      review_flag_counts: { ASSET_REF_UNRESOLVED: 1, NESTED_TABLE: 1 },
      blocked_groups: [],
      gate: { name: "docx_source_fidelity_v1", passed: true, severity: "info", blocking_reasons: [] },
      catalog: REVIEW_FLAG_LABELS,
    };

    const model = buildExtractionExplorer({
      documentLabel: "Apple CA (PSC).docx",
      blocks,
      locatedSourceIds: new Set(blocks.map((item) => item.block_id)),
      sourceResolutionKnown: true,
      qualityGate: summary.gate,
    });

    const perRowBadgeSum = model.allNodes
      .filter((node) => node.block)
      .reduce((sum, node) => sum + node.attentionSignals.length, 0);
    const summaryFlagTotal = Object.values(summary.review_flag_counts).reduce((sum, count) => sum + count, 0);

    expect(model.attentionBlockCount).toBe(2);
    expect(model.attentionSourceIds.size).toBe(model.attentionBlockCount);
    expect(perRowBadgeSum).toBe(model.attentionSignalCount);
    expect(summaryFlagTotal).toBe(model.attentionSignalCount);
  });
});

function block(
  block_id: string,
  block_type: string,
  text: string,
  review_flags: SourceBlock["review_flags"] = [],
): SourceBlock {
  return {
    block_id,
    block_type,
    text,
    source_location: { page: null, section: `docx:p:${block_id}`, bbox: null },
    heading_path_ids: block_type === "heading" ? [] : ["h1"],
    confidence: { extraction: 0.92, block_type: 0.92, heading: 0.92, semantic_inline: 0.92 },
    review_flags,
    inferred_level: block_type === "heading" ? 1 : null,
  };
}
