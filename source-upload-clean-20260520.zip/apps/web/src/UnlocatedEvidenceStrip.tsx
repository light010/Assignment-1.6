import { MapPinOff } from "lucide-react";

export function UnlocatedEvidenceStrip({ blockIds }: { blockIds: string[] }) {
  if (blockIds.length === 0) return null;
  return (
    <div className="unlocated-evidence-strip" role="status">
      <MapPinOff size={15} />
      <span>{blockIds.length} evidence anchor{blockIds.length === 1 ? "" : "s"} not located in the original source viewer.</span>
      <code>{blockIds.slice(0, 3).join(", ")}</code>
      {blockIds.length > 3 && <small>+{blockIds.length - 3} more</small>}
      <button type="button" disabled>Pick source region</button>
    </div>
  );
}
