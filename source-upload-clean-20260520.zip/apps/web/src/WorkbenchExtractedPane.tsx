import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CornerDownRight,
  GitMerge,
  Keyboard,
  ListTree,
  MapPinOff,
  Scissors,
} from "lucide-react";
import { CSSProperties, KeyboardEvent, MutableRefObject, useEffect, useRef, useState } from "react";
import { TopicType } from "./api";
import { ChunkNavigationKey, ChunkNode, ChunkExplorerModel } from "./chunkExplorerModel";
import { normalizeTopicType, WorkbenchTopic } from "./workbenchModel";
import {
  commitTopicTitleDraft,
  NextAction,
  ReviewedTopicState,
  TopicProgress,
  isTopicReviewCurrent,
} from "./workbenchSelectors";
import { draftStateLabel, nextActionCopy } from "./workbenchViewModel";

const TOPIC_TYPES: TopicType[] = ["concept", "task", "reference", "troubleshooting", "glossary"];

export function ExtractedPane({
  model,
  visibleNodes,
  expandedChunkIds,
  activeChunkId,
  selectedTopic,
  topics,
  selectedUnitIds,
  progress,
  nextAction,
  reviewed,
  mergeAllowed,
  splitAllowed,
  hasLocalDraft,
  moveTargetTopicId,
  titleInputRef,
  typeSelectRef,
  onSelectChunk,
  onPreviewChunk,
  onToggleExpanded,
  onNavigate,
  onRenameTopic,
  onRetypeTopic,
  onMerge,
  onSplit,
  onMoveTargetChange,
  onMove,
  onPrimaryAction,
  onOpenShortcuts,
  setUnitRef,
}: {
  model: ChunkExplorerModel;
  visibleNodes: ChunkNode[];
  expandedChunkIds: Set<string>;
  activeChunkId: string;
  selectedTopic: WorkbenchTopic | null;
  topics: WorkbenchTopic[];
  selectedUnitIds: string[];
  progress: TopicProgress;
  nextAction: NextAction | null;
  reviewed: Record<string, ReviewedTopicState>;
  mergeAllowed: boolean;
  splitAllowed: boolean;
  hasLocalDraft: boolean;
  moveTargetTopicId: string;
  titleInputRef: MutableRefObject<HTMLInputElement | null>;
  typeSelectRef: MutableRefObject<HTMLSelectElement | null>;
  onSelectChunk: (node: ChunkNode, additive: boolean) => void;
  onPreviewChunk: (node: ChunkNode) => void;
  onToggleExpanded: (nodeId: string) => void;
  onNavigate: (key: ChunkNavigationKey) => void;
  onRenameTopic: (topicId: string, title: string) => void;
  onRetypeTopic: (topicId: string, topicType: TopicType) => void;
  onMerge: () => void;
  onSplit: () => void;
  onMoveTargetChange: (topicId: string) => void;
  onMove: () => void;
  onPrimaryAction: () => void;
  onOpenShortcuts: () => void;
  setUnitRef: (unitId: string, node: HTMLElement | null) => void;
}) {
  const activeNode = model.nodeById.get(activeChunkId) || visibleNodes[0] || null;
  const attentionCount = model.allNodes.filter((node) => node.severity !== "clean").length;
  const chunkCount = model.allNodes.filter((node) => node.kind === "chunk" || node.unitId).length;
  const action = nextAction ? nextActionCopy(nextAction) : null;
  const reviewedCurrent = selectedTopic ? isTopicReviewCurrent(selectedTopic, reviewed[selectedTopic.topic_id]) : false;

  return (
    <section className="workbench-extracted chunk-explorer-shell" aria-label="Extracted chunk explorer">
      <header className="chunk-explorer-header">
        <div>
          <span className="label-sm">Chunk Explorer</span>
          <h3><ListTree size={16} aria-hidden /> {chunkCount} chunks</h3>
        </div>
        <div className="chunk-explorer-stats" aria-label="Chunk explorer status">
          <span>{attentionCount} attention</span>
          <span>{progress.reviewed}/{progress.total} reviewed</span>
          {activeNode && <span>{activeNode.kind}</span>}
        </div>
        <div className="chunk-explorer-actions">
          {action && nextAction?.kind !== "none" && (
            <button type="button" className={`chunk-action tone-${action.tone}`} onClick={onPrimaryAction}>
              {action.label}
            </button>
          )}
          <button type="button" onClick={onOpenShortcuts} title="Keyboard shortcuts" aria-label="Keyboard shortcuts">
            <Keyboard size={15} />
          </button>
        </div>
      </header>

      {selectedTopic && (
        <section className="chunk-inspector" aria-label="Selected topic and chunk controls">
          <div className="chunk-inspector-main">
            <TopicTitleEditor topic={selectedTopic} inputRef={titleInputRef} onCommit={onRenameTopic} />
            <div className="chunk-inspector-meta">
              <label>
                <span>Type</span>
                <select
                  ref={typeSelectRef}
                  value={selectedTopic.topic_type}
                  onChange={(event) => {
                    const nextType = normalizeTopicType(event.target.value);
                    if (nextType !== selectedTopic.topic_type) onRetypeTopic(selectedTopic.topic_id, nextType);
                  }}
                >
                  {TOPIC_TYPES.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </label>
              <span className={`draft-chip ${draftStateLabel(selectedTopic, hasLocalDraft) === "Clean" ? "quiet" : ""}`}>
                {draftStateLabel(selectedTopic, hasLocalDraft)}
              </span>
              {reviewedCurrent && <span className="reviewed-chip"><CheckCircle2 size={13} /> Reviewed</span>}
            </div>
          </div>

          <details className="chunk-edit-details">
            <summary>Edit selected chunk</summary>
            <div className="chunk-edit-actions" role="toolbar" aria-label="Selected chunk actions">
              <strong>{selectedUnitIds.length} selected</strong>
              <button type="button" disabled={!mergeAllowed} onClick={onMerge}>
                <GitMerge size={14} /> Merge
              </button>
              <button type="button" disabled={!splitAllowed || selectedUnitIds.length !== 1} onClick={onSplit}>
                <Scissors size={14} /> Split
              </button>
              <label>
                <span>Move to</span>
                <select value={moveTargetTopicId} onChange={(event) => onMoveTargetChange(event.target.value)}>
                  <option value="">Select topic</option>
                  {topics
                    .filter((item) => item.topic_id !== selectedTopic.topic_id)
                    .map((item) => (
                      <option key={item.topic_id} value={item.topic_id}>{item.title}</option>
                    ))}
                </select>
              </label>
              <button type="button" disabled={!moveTargetTopicId || selectedUnitIds.length === 0} onClick={onMove}>
                <CornerDownRight size={14} /> Move
              </button>
            </div>
          </details>
        </section>
      )}

      <ChunkTree
        visibleNodes={visibleNodes}
        expandedChunkIds={expandedChunkIds}
        activeChunkId={activeChunkId}
        onSelectChunk={onSelectChunk}
        onPreviewChunk={onPreviewChunk}
        onToggleExpanded={onToggleExpanded}
        onNavigate={onNavigate}
        setUnitRef={setUnitRef}
      />
    </section>
  );
}

function ChunkTree({
  visibleNodes,
  expandedChunkIds,
  activeChunkId,
  onSelectChunk,
  onPreviewChunk,
  onToggleExpanded,
  onNavigate,
  setUnitRef,
}: {
  visibleNodes: ChunkNode[];
  expandedChunkIds: Set<string>;
  activeChunkId: string;
  onSelectChunk: (node: ChunkNode, additive: boolean) => void;
  onPreviewChunk: (node: ChunkNode) => void;
  onToggleExpanded: (nodeId: string) => void;
  onNavigate: (key: ChunkNavigationKey) => void;
  setUnitRef: (unitId: string, node: HTMLElement | null) => void;
}) {
  const rowRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const focusAfterKeyboard = useRef(false);

  useEffect(() => {
    const row = rowRefs.current.get(activeChunkId);
    if (!row) return;
    row.scrollIntoView({ block: "nearest" });
    if (focusAfterKeyboard.current) {
      row.focus();
      focusAfterKeyboard.current = false;
    }
  }, [activeChunkId]);

  return (
    <div className="chunk-tree" role="tree" aria-label="Document chunks">
      {visibleNodes.map((node, index) => {
        const expanded = expandedChunkIds.has(node.id);
        const hasChildren = node.children.length > 0;
        const active = node.id === activeChunkId || (!activeChunkId && index === 0);
        return (
          <div
            key={node.id}
            ref={(element) => {
              if (element) rowRefs.current.set(node.id, element);
              else rowRefs.current.delete(node.id);
              if (node.unitId) setUnitRef(node.unitId, element);
            }}
            role="treeitem"
            aria-level={node.depth}
            aria-selected={active}
            aria-expanded={hasChildren ? expanded : undefined}
            tabIndex={active ? 0 : -1}
            className={`chunk-row kind-${node.kind} severity-${node.severity} tone-${node.topicType || "neutral"}${active ? " active" : ""}${!node.isLocated ? " unlocated" : ""}`}
            style={{ "--chunk-depth": String(Math.max(0, node.depth - 1)) } as CSSProperties}
            onClick={(event) => onSelectChunk(node, event.metaKey || event.ctrlKey || event.shiftKey)}
            onMouseEnter={() => onPreviewChunk(node)}
            onKeyDown={(event) => {
              const key = navigationKey(event);
              if (key) {
                event.preventDefault();
                focusAfterKeyboard.current = true;
                onNavigate(key);
                return;
              }
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onSelectChunk(node, event.metaKey || event.ctrlKey || event.shiftKey);
              }
            }}
          >
            <button
              type="button"
              className="chunk-row-toggle"
              disabled={!hasChildren}
              aria-label={expanded ? `Collapse ${node.label}` : `Expand ${node.label}`}
              onClick={(event) => {
                event.stopPropagation();
                if (hasChildren) onToggleExpanded(node.id);
              }}
            >
              {hasChildren ? expanded ? <ChevronDown size={15} /> : <ChevronRight size={15} /> : <span aria-hidden />}
            </button>
            <span className="chunk-type-dot" aria-hidden />
            <span className="chunk-row-copy">
              <span className="chunk-row-title">{node.label}</span>
              <span className="chunk-row-meta">{node.meta}</span>
            </span>
            <span className="chunk-row-badges">
              {!node.isLocated && <span className="chunk-badge unlocated"><MapPinOff size={12} /> Unlocated</span>}
              {node.issueCount > 0 && <span className={`chunk-badge severity-${node.severity}`}><AlertTriangle size={12} /> {node.issueCount}</span>}
              {node.confidence !== null && <span className="chunk-confidence">{Math.round(node.confidence * 100)}%</span>}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function navigationKey(event: KeyboardEvent<HTMLElement>): ChunkNavigationKey | null {
  if (event.key === "ArrowUp") return "up";
  if (event.key === "ArrowDown") return "down";
  if (event.key === "ArrowRight") return "right";
  if (event.key === "ArrowLeft") return "left";
  return null;
}

function TopicTitleEditor({
  topic,
  inputRef,
  onCommit,
}: {
  topic: WorkbenchTopic;
  inputRef: MutableRefObject<HTMLInputElement | null>;
  onCommit: (topicId: string, title: string) => void;
}) {
  const [draft, setDraft] = useState(topic.title);

  useEffect(() => {
    setDraft(topic.title);
  }, [topic.title, topic.topic_id]);

  function commit() {
    const nextTitle = commitTopicTitleDraft(topic.title, draft);
    if (nextTitle) onCommit(topic.topic_id, nextTitle);
    else setDraft(topic.title);
  }

  return (
    <input
      ref={inputRef}
      className="chunk-title-input"
      value={draft}
      aria-label="Topic title"
      onChange={(event) => setDraft(event.target.value)}
      onBlur={commit}
      onKeyDown={(event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          event.currentTarget.blur();
        }
        if (event.key === "Escape") {
          event.preventDefault();
          setDraft(topic.title);
          event.currentTarget.blur();
        }
      }}
    />
  );
}
