import { ExternalLink, FileText, Link2, LocateFixed, Search, Unlink2, X } from "lucide-react";
import { Document as PdfDocument, Page as PdfPage } from "react-pdf";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { DocumentRecord, sourceFileUrl, SourceBlock } from "./api";
import "./pdfWorker";
import {
  blockSearchText,
  detectSourceViewerKind,
  matchBlocksToCandidates,
  normalizeSourceText,
  sourceMatchFailureIds,
  sourceMatchStats,
  SourceBlockMatch,
  SourceMatchCandidate,
  SourceViewerKind,
} from "./sourceViewerModel";
import { EvidenceNumber } from "./workbenchSelectors";

type SourceEvidenceViewerProps = {
  document: DocumentRecord;
  blocks: SourceBlock[];
  query: string;
  attentionOnly: boolean;
  attentionSourceIds: Set<string>;
  activeSourceIds: string[];
  selectedSourceIds: string[];
  previewSourceIds?: string[];
  spotlightSourceIds?: string[];
  evidenceNumbers?: EvidenceNumber[];
  onQueryChange: (query: string) => void;
  onAttentionOnlyChange: (value: boolean) => void;
  syncScrolling: boolean;
  onSyncScrollingChange: (value: boolean) => void;
  onHoverBlock: (blockId: string) => void;
  onClearHover?: () => void;
  onSelectBlock: (blockId: string) => void;
  onMatchFailuresChange?: (blockIds: string[]) => void;
  setBlockRef: (blockId: string, node: HTMLElement | null) => void;
};

type PdfPageGeometry = {
  pdfWidth: number;
  pdfHeight: number;
  cssWidth: number;
  cssHeight: number;
};

const DOCX_RENDER_OPTIONS = {
  breakPages: true,
  renderHeaders: true,
  renderFooters: true,
  renderFootnotes: true,
  renderEndnotes: true,
  ignoreWidth: false,
  ignoreHeight: false,
  ignoreFonts: false,
};

export function SourceEvidenceViewer({
  document,
  blocks,
  query,
  attentionOnly,
  attentionSourceIds,
  activeSourceIds,
  selectedSourceIds,
  previewSourceIds = [],
  spotlightSourceIds = [],
  evidenceNumbers = [],
  onQueryChange,
  onAttentionOnlyChange,
  syncScrolling,
  onSyncScrollingChange,
  onHoverBlock,
  onClearHover,
  onSelectBlock,
  onMatchFailuresChange,
  setBlockRef,
}: SourceEvidenceViewerProps) {
  const viewerKind = useMemo(
    () => detectSourceViewerKind(document.filename, document.content_type),
    [document.content_type, document.filename],
  );
  const [locatedBlockIds, setLocatedBlockIds] = useState<Set<string>>(() => new Set());
  const [matchSummary, setMatchSummary] = useState({ matched: 0, unmatched: blocks.length, total: blocks.length });
  const [hasHorizontalOverflow, setHasHorizontalOverflow] = useState(false);
  const [sourceScrolledX, setSourceScrolledX] = useState(false);
  const blockElementsRef = useRef<Map<string, HTMLElement>>(new Map());
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const filterIds = useMemo(() => {
    const normalized = normalizeSourceText(query);
    return new Set(
      blocks
        .filter((block) => {
          if (attentionOnly && !attentionSourceIds.has(block.block_id)) return false;
          if (!normalized) return attentionOnly;
          return normalizeSourceText(blockSearchText(block)).includes(normalized);
        })
        .map((block) => block.block_id),
    );
  }, [attentionOnly, attentionSourceIds, blocks, query]);
  const activeIdsKey = activeSourceIds.join("|");
  const selectedIdsKey = selectedSourceIds.join("|");
  const previewIdsKey = previewSourceIds.join("|");
  const spotlightIdsKey = spotlightSourceIds.join("|");
  const filterIdsKey = Array.from(filterIds).join("|");
  const evidenceNumberByBlock = useMemo(
    () => new Map(evidenceNumbers.map((item) => [item.source_block_id, item.evidence_number] as const)),
    [evidenceNumbers],
  );
  const evidenceNumbersKey = evidenceNumbers.map((item) => `${item.source_block_id}:${item.evidence_number}`).join("|");
  const activeUnlocatedIds = [...new Set([...selectedSourceIds, ...activeSourceIds])]
    .filter((blockId) => blockId && !locatedBlockIds.has(blockId));
  const blockById = useMemo(() => new Map(blocks.map((block) => [block.block_id, block] as const)), [blocks]);
  const sourceUrl = sourceFileUrl(document.document_id);

  const clearRegisteredRefs = useCallback(() => {
    blockElementsRef.current.forEach((_node, blockId) => setBlockRef(blockId, null));
    blockElementsRef.current.clear();
  }, [setBlockRef]);

  const registerBlockElement = useCallback(
    (blockId: string, node: HTMLElement | null) => {
      if (node) {
        blockElementsRef.current.set(blockId, node);
        setBlockRef(blockId, node);
      } else {
        blockElementsRef.current.delete(blockId);
        setBlockRef(blockId, null);
      }
    },
    [setBlockRef],
  );

  const updateMatches = useCallback(
    (matches: SourceBlockMatch[], candidateElements?: Map<string, HTMLElement>) => {
      clearRegisteredRefs();
      const located = new Set<string>();
      if (candidateElements) {
        for (const match of matches) {
          if (!match.candidateKey) continue;
          const element = candidateElements.get(match.candidateKey);
          if (!element) continue;
          element.dataset.sourceBlockId = match.blockId;
          element.classList.add("source-viewer-anchor");
          element.setAttribute("tabindex", "0");
          registerBlockElement(match.blockId, element);
          located.add(match.blockId);
        }
      } else {
        matches.forEach((match) => {
          if (match.candidateKey) located.add(match.blockId);
        });
      }
      setLocatedBlockIds(located);
      setMatchSummary(sourceMatchStats(matches));
      onMatchFailuresChange?.(sourceMatchFailureIds(matches));
    },
    [clearRegisteredRefs, onMatchFailuresChange, registerBlockElement],
  );

  useEffect(() => clearRegisteredRefs, [clearRegisteredRefs]);

  useEffect(() => {
    const activeSet = new Set(activeSourceIds);
    const selectedSet = new Set(selectedSourceIds);
    const previewSet = new Set(previewSourceIds);
    const spotlightSet = new Set(spotlightSourceIds);
    const hasFilter = query.trim().length > 0 || attentionOnly;
    blockElementsRef.current.forEach((element, blockId) => {
      const evidenceNumber = evidenceNumberByBlock.get(blockId);
      if (evidenceNumber) {
        element.dataset.evidenceNumber = String(evidenceNumber);
        element.setAttribute("aria-label", `Evidence ${evidenceNumber}, source block ${blockId}`);
      } else {
        delete element.dataset.evidenceNumber;
        element.removeAttribute("aria-label");
      }
      element.classList.toggle("source-viewer-active", activeSet.has(blockId));
      element.classList.toggle("source-viewer-selected", selectedSet.has(blockId));
      element.classList.toggle("source-viewer-preview", previewSet.has(blockId) && !activeSet.has(blockId) && !selectedSet.has(blockId));
      element.classList.toggle("source-viewer-spotlight", spotlightSet.has(blockId));
      element.classList.toggle("source-viewer-numbered", Boolean(evidenceNumber));
      element.classList.toggle("source-viewer-filter-match", hasFilter && filterIds.has(blockId));
    });
  }, [
    activeIdsKey,
    attentionOnly,
    evidenceNumberByBlock,
    evidenceNumbersKey,
    filterIds,
    filterIdsKey,
    matchSummary.matched,
    query,
    previewIdsKey,
    previewSourceIds,
    selectedIdsKey,
    spotlightIdsKey,
    spotlightSourceIds,
  ]);

  useEffect(() => {
    if (!query.trim() && !attentionOnly) return;
    const firstFiltered = Array.from(filterIds).find((blockId) => blockElementsRef.current.has(blockId));
    if (!firstFiltered) return;
    blockElementsRef.current.get(firstFiltered)?.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [attentionOnly, filterIds, filterIdsKey, query]);

  useEffect(() => {
    const node = scrollRef.current;
    if (!node) return;
    const updateOverflow = () => {
      setHasHorizontalOverflow(node.scrollWidth > node.clientWidth + 4);
      setSourceScrolledX(node.scrollLeft > 4);
    };
    updateOverflow();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(updateOverflow);
    observer.observe(node);
    return () => observer.disconnect();
  }, [viewerKind, blocks.length]);

  function handleDelegatedBlockEvent(target: EventTarget | null, handler: (blockId: string) => void) {
    const element = target instanceof HTMLElement
      ? target.closest<HTMLElement>("[data-source-block-id]")
      : null;
    const blockId = element?.dataset.sourceBlockId;
    if (blockId) handler(blockId);
  }

  return (
    <section
      className={`workbench-source source-evidence-viewer source-kind-${viewerKind}${attentionOnly ? " is-attention-only" : ""}${query.trim() ? " is-searching" : ""}${query.trim() || attentionOnly ? " is-filtering" : ""}`}
      aria-label="Original source document viewer"
      onMouseOver={(event) => handleDelegatedBlockEvent(event.target, onHoverBlock)}
      onMouseLeave={() => onClearHover?.()}
      onFocusCapture={(event) => handleDelegatedBlockEvent(event.target, onHoverBlock)}
      onClick={(event) => handleDelegatedBlockEvent(event.target, onSelectBlock)}
    >
      <div className="workbench-pane-toolbar source-viewer-toolbar">
        <label className="workbench-search">
          <Search size={14} aria-hidden />
          <input value={query} onChange={(event) => onQueryChange(event.target.value)} placeholder="Search extracted anchors" />
          {query && (
            <button type="button" className="search-clear" onClick={() => onQueryChange("")} aria-label="Clear source search">
              <X size={13} />
            </button>
          )}
        </label>
        <button
          type="button"
          className={attentionOnly ? "active" : ""}
          onClick={() => onAttentionOnlyChange(!attentionOnly)}
          aria-pressed={attentionOnly}
        >
          <LocateFixed size={14} /> Attention only
        </button>
        <button
          type="button"
          className={syncScrolling ? "active" : ""}
          onClick={() => onSyncScrollingChange(!syncScrolling)}
          aria-pressed={syncScrolling}
          title={syncScrolling ? "Selection jumps sync both panes" : "Panes scroll independently"}
        >
          {syncScrolling ? <Link2 size={14} /> : <Unlink2 size={14} />}
          Sync
        </button>
        <div className="source-viewer-status" aria-label="Source viewer status">
          <span>{matchSummary.matched}/{matchSummary.total} matched</span>
          {matchSummary.unmatched > 0 && <span>{matchSummary.unmatched} unlocated</span>}
          {attentionOnly && filterIds.size === 0 && <span>No extraction attention items</span>}
          <a href={sourceUrl} target="_blank" rel="noreferrer">
            <ExternalLink size={13} /> Open original
          </a>
        </div>
      </div>
      <div className="source-state-legend" aria-label="Source highlight legend">
        <span><i className="legend-active" aria-hidden /> Active</span>
        <span><i className="legend-hover" aria-hidden /> Hover</span>
        <span><i className="legend-match" aria-hidden /> Match</span>
        <span><i className="legend-attention" aria-hidden /> Attention</span>
      </div>
      {activeUnlocatedIds.length > 0 && (
        <div className="source-unlocated-callout" role="status">
          <strong>Unmapped block</strong>
          <span>Not located in source viewer: <code>{activeUnlocatedIds.slice(0, 4).join(", ")}</code></span>
          {activeUnlocatedIds.length > 4 ? ` +${activeUnlocatedIds.length - 4} more` : ""}
          <details>
            <summary>View raw text</summary>
            {activeUnlocatedIds.slice(0, 4).map((blockId) => (
              <p key={blockId}><code>{blockId}</code> {blockById.get(blockId)?.text || ""}</p>
            ))}
          </details>
        </div>
      )}
      {hasHorizontalOverflow && (
        <div className="source-scroll-hint" role="status">
          {sourceScrolledX ? "Line start is to the left" : "Scroll horizontally to inspect full source lines"}
        </div>
      )}
      <div
        className="source-original-scroll"
        ref={scrollRef}
        onScroll={(event) => {
          const node = event.currentTarget;
          setSourceScrolledX(node.scrollLeft > 4);
          setHasHorizontalOverflow(node.scrollWidth > node.clientWidth + 4);
        }}
      >
        {viewerKind === "docx" ? (
          <DocxOriginalViewer sourceUrl={sourceUrl} blocks={blocks} onMatches={updateMatches} />
        ) : viewerKind === "pdf" ? (
          <PdfOriginalViewer
            sourceUrl={sourceUrl}
            blocks={blocks}
            activeSourceIds={activeSourceIds}
            selectedSourceIds={selectedSourceIds}
            previewSourceIds={previewSourceIds}
            filterIds={filterIds}
            hasFilter={query.trim().length > 0 || attentionOnly}
            registerBlockElement={registerBlockElement}
            onMatches={updateMatches}
          />
        ) : viewerKind === "text" ? (
          <TextOriginalViewer
            sourceUrl={sourceUrl}
            blocks={blocks}
            activeSourceIds={activeSourceIds}
            selectedSourceIds={selectedSourceIds}
            previewSourceIds={previewSourceIds}
            filterIds={filterIds}
            hasFilter={query.trim().length > 0 || attentionOnly}
            registerBlockElement={registerBlockElement}
            onMatches={updateMatches}
          />
        ) : viewerKind === "html" ? (
          <HtmlOriginalViewer sourceUrl={sourceUrl} blocks={blocks} onMatches={updateMatches} />
        ) : (
          <UnsupportedOriginalViewer sourceUrl={sourceUrl} kind={viewerKind} blocks={blocks} onMatches={updateMatches} />
        )}
      </div>
    </section>
  );
}

function DocxOriginalViewer({
  sourceUrl,
  blocks,
  onMatches,
}: {
  sourceUrl: string;
  blocks: SourceBlock[];
  onMatches: (matches: SourceBlockMatch[], candidateElements?: Map<string, HTMLElement>) => void;
}) {
  const bodyRef = useRef<HTMLDivElement | null>(null);
  const styleRef = useRef<HTMLDivElement | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    const body = bodyRef.current;
    const style = styleRef.current;
    if (!body || !style) return;
    body.innerHTML = "";
    style.innerHTML = "";
    setError("");
    fetch(sourceUrl)
      .then((response) => {
        if (!response.ok) throw new Error(`Could not load DOCX source (${response.status})`);
        return response.blob();
      })
      .then(async (blob) => {
        const { renderAsync } = await import("docx-preview");
        return renderAsync(blob, body, style, DOCX_RENDER_OPTIONS);
      })
      .then(() => {
        if (cancelled) return;
        suppressRenderedDocxLinks(body);
        const { candidates, elements } = collectDocxCandidates(body);
        onMatches(matchBlocksToCandidates(blocks, candidates), elements);
      })
      .catch((err) => {
        if (cancelled) return;
        setError((err as Error).message);
        onMatches(blocks.map((block) => ({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" })));
      });
    return () => {
      cancelled = true;
      body.innerHTML = "";
      style.innerHTML = "";
    };
  }, [blocks, onMatches, sourceUrl]);

  if (error) return <ViewerError message={error} sourceUrl={sourceUrl} />;

  return (
    <div className="docx-original-viewer">
      <div ref={styleRef} className="docx-style-host" />
      <div ref={bodyRef} className="docx-render-host" />
    </div>
  );
}

function PdfOriginalViewer({
  sourceUrl,
  blocks,
  activeSourceIds,
  selectedSourceIds,
  previewSourceIds,
  filterIds,
  hasFilter,
  registerBlockElement,
  onMatches,
}: {
  sourceUrl: string;
  blocks: SourceBlock[];
  activeSourceIds: string[];
  selectedSourceIds: string[];
  previewSourceIds: string[];
  filterIds: Set<string>;
  hasFilter: boolean;
  registerBlockElement: (blockId: string, node: HTMLElement | null) => void;
  onMatches: (matches: SourceBlockMatch[]) => void;
}) {
  const [numPages, setNumPages] = useState(0);
  const [pageGeometry, setPageGeometry] = useState<Map<number, PdfPageGeometry>>(() => new Map());
  const [containerWidth, setContainerWidth] = useState(720);
  const [error, setError] = useState("");
  const containerRef = useRef<HTMLDivElement | null>(null);
  const activeSet = new Set(activeSourceIds);
  const selectedSet = new Set(selectedSourceIds);
  const previewSet = new Set(previewSourceIds);
  const pdfBlocks = useMemo(
    () =>
      blocks.filter((block) => {
        const bbox = block.source_location?.bbox || block.bbox;
        const page = block.source_location?.page || block.page;
        return page && bbox && bbox.length >= 4;
      }),
    [blocks],
  );
  const pdfBlockIdsKey = pdfBlocks.map((block) => block.block_id).join("|");

  useEffect(() => {
    const pdfBlockIds = new Set(pdfBlocks.map((block) => block.block_id));
    onMatches(
      blocks.map((block) => ({
        blockId: block.block_id,
        candidateKey: pdfBlockIds.has(block.block_id) ? block.block_id : null,
        matchType: pdfBlockIds.has(block.block_id) ? "exact" : "unmatched",
      })),
    );
  }, [blocks, onMatches, pdfBlockIdsKey, pdfBlocks]);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const update = () => setContainerWidth(Math.min(900, Math.max(420, node.clientWidth || 720)));
    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  if (error) return <ViewerError message={error} sourceUrl={sourceUrl} />;

  return (
    <div className="source-pdf-viewer" ref={containerRef}>
      <PdfDocument
        file={{ url: sourceUrl }}
        onLoadSuccess={(pdf) => setNumPages(pdf.numPages)}
        onLoadError={(err) => setError(err.message || "Could not render PDF source")}
        loading={<div className="pdf-loading">Loading original PDF...</div>}
        error={<div className="pdf-loading">Could not load original PDF.</div>}
      >
        {Array.from({ length: numPages }, (_, index) => index + 1).map((pageNum) => {
          const geometry = pageGeometry.get(pageNum);
          return (
            <div className="source-pdf-page" key={pageNum}>
              <PdfPage
                pageNumber={pageNum}
                width={containerWidth}
                renderTextLayer={false}
                renderAnnotationLayer={false}
                onRenderSuccess={(page) => {
                  const view = page.view as [number, number, number, number];
                  setPageGeometry((current) => {
                    const next = new Map(current);
                    next.set(pageNum, {
                      pdfWidth: view[2] - view[0],
                      pdfHeight: view[3] - view[1],
                      cssWidth: page.width,
                      cssHeight: page.height,
                    });
                    return next;
                  });
                }}
              />
              {geometry && (
                <div className="source-pdf-hit-layer" style={{ width: geometry.cssWidth, height: geometry.cssHeight }}>
                  {pdfBlocks
                    .filter((block) => (block.source_location?.page || block.page) === pageNum)
                    .map((block) => {
                      const rect = pdfOverlayRect(block, geometry);
                      if (!rect) return null;
                      return (
                        <button
                          key={block.block_id}
                          ref={(node) => registerBlockElement(block.block_id, node)}
                          type="button"
                          data-source-block-id={block.block_id}
                          className={sourceAnchorClass(block.block_id, activeSet, selectedSet, previewSet, filterIds, hasFilter)}
                          style={rect}
                          aria-label={`Source block ${block.block_id}`}
                        />
                      );
                    })}
                </div>
              )}
            </div>
          );
        })}
      </PdfDocument>
    </div>
  );
}

function TextOriginalViewer({
  sourceUrl,
  blocks,
  activeSourceIds,
  selectedSourceIds,
  previewSourceIds,
  filterIds,
  hasFilter,
  registerBlockElement,
  onMatches,
}: {
  sourceUrl: string;
  blocks: SourceBlock[];
  activeSourceIds: string[];
  selectedSourceIds: string[];
  previewSourceIds: string[];
  filterIds: Set<string>;
  hasFilter: boolean;
  registerBlockElement: (blockId: string, node: HTMLElement | null) => void;
  onMatches: (matches: SourceBlockMatch[]) => void;
}) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const lines = useMemo(() => splitOriginalText(text), [text]);
  const matches = useMemo(() => matchBlocksToCandidates(blocks, lines), [blocks, lines]);
  const candidateToBlock = useMemo(() => {
    const map = new Map<string, string>();
    matches.forEach((match) => {
      if (match.candidateKey) map.set(match.candidateKey, match.blockId);
    });
    return map;
  }, [matches]);
  const activeSet = new Set(activeSourceIds);
  const selectedSet = new Set(selectedSourceIds);
  const previewSet = new Set(previewSourceIds);

  useEffect(() => {
    let cancelled = false;
    setError("");
    fetch(sourceUrl)
      .then((response) => {
        if (!response.ok) throw new Error(`Could not load text source (${response.status})`);
        return response.text();
      })
      .then((value) => {
        if (!cancelled) setText(value);
      })
      .catch((err) => {
        if (!cancelled) setError((err as Error).message);
      });
    return () => {
      cancelled = true;
    };
  }, [sourceUrl]);

  useEffect(() => onMatches(matches), [matches, onMatches]);

  if (error) return <ViewerError message={error} sourceUrl={sourceUrl} />;

  return (
    <pre className="source-text-original">
      {lines.map((line) => {
        const blockId = candidateToBlock.get(line.key);
        return (
          <span
            key={line.key}
            ref={(node) => {
              if (blockId) registerBlockElement(blockId, node);
            }}
            data-source-block-id={blockId || undefined}
            className={blockId ? sourceAnchorClass(blockId, activeSet, selectedSet, previewSet, filterIds, hasFilter) : undefined}
          >
            {line.text || " "}
            {"\n"}
          </span>
        );
      })}
    </pre>
  );
}

function HtmlOriginalViewer({
  sourceUrl,
  blocks,
  onMatches,
}: {
  sourceUrl: string;
  blocks: SourceBlock[];
  onMatches: (matches: SourceBlockMatch[]) => void;
}) {
  const [html, setHtml] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    onMatches(blocks.map((block) => ({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" })));
  }, [blocks, onMatches]);

  useEffect(() => {
    let cancelled = false;
    setError("");
    fetch(sourceUrl)
      .then((response) => {
        if (!response.ok) throw new Error(`Could not load HTML source (${response.status})`);
        return response.text();
      })
      .then((value) => {
        if (!cancelled) setHtml(value);
      })
      .catch((err) => {
        if (!cancelled) setError((err as Error).message);
      });
    return () => {
      cancelled = true;
    };
  }, [sourceUrl]);

  if (error) {
    return (
      <pre className="source-text-original source-html-fallback">
        {html || `Could not render HTML source: ${error}`}
      </pre>
    );
  }

  return (
    <iframe
      className="source-html-frame"
      title="Original HTML source"
      sandbox=""
      srcDoc={html}
    />
  );
}

function UnsupportedOriginalViewer({
  sourceUrl,
  kind,
  blocks,
  onMatches,
}: {
  sourceUrl: string;
  kind: SourceViewerKind;
  blocks: SourceBlock[];
  onMatches: (matches: SourceBlockMatch[]) => void;
}) {
  useEffect(() => {
    onMatches(blocks.map((block) => ({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" })));
  }, [blocks, onMatches]);

  return (
    <div className="preview-unavailable source-original-unavailable">
      <FileText size={28} />
      <h3>Original source preview is not available</h3>
      <p>The {kind} source type can still be opened directly.</p>
      <a href={sourceUrl} target="_blank" rel="noreferrer">Open original</a>
    </div>
  );
}

function ViewerError({ message, sourceUrl }: { message: string; sourceUrl: string }) {
  return (
    <div className="preview-unavailable source-original-unavailable">
      <FileText size={28} />
      <h3>Could not render original source</h3>
      <p>{message}</p>
      <a href={sourceUrl} target="_blank" rel="noreferrer">Open original</a>
    </div>
  );
}

function collectDocxCandidates(root: HTMLElement): {
  candidates: SourceMatchCandidate[];
  elements: Map<string, HTMLElement>;
} {
  const elements = new Map<string, HTMLElement>();
  const candidates: SourceMatchCandidate[] = [];
  let bodyIndex = 0;

  // Step E: body selection now also excludes `<p>`/`<li>`/`<h*>` and inner
  // `<table>` elements that live inside an outer `<table>` — those are
  // either nested table content (handled below in the outer-table walk)
  // or table-cell paragraphs that the locator grammar does not address.
  const bodyNodes = Array.from(root.querySelectorAll<HTMLElement>("h1,h2,h3,h4,h5,h6,p,li,table"))
    .filter((element) => {
      if (element.closest("td,th,.docx-header,.docx-footer")) return false;
      // Inner `<table>` inside an outer `<table>` (the rendered DOM nests
      // a `<table>` directly inside `<td>`/`<th>` — caught by the closest()
      // check above — but also can render as a direct descendant of `<tr>`
      // in some docx-preview versions). Belt-and-suspenders:
      if (element.tagName === "TABLE" && element.parentElement?.closest("table")) return false;
      if (element.tagName === "TABLE") {
        return Array.from(element.querySelectorAll<HTMLElement>("tr")).some(
          (row) => normalizeSourceText(row.innerText || row.textContent || "").length > 0,
        );
      }
      // Canonical empty rule (mirrors `_docx_paragraph_image_asset_ids` in
      // extractors.py): a body element is non-empty if it has visible text
      // OR carries embedded media. Diverging here shifts every downstream
      // locator index relative to the producer.
      const hasText = normalizeSourceText(element.innerText || element.textContent || "").length > 0;
      const hasMedia = element.querySelector("img,svg,object,picture,canvas") !== null;
      return hasText || hasMedia;
    });

  bodyNodes.forEach((element) => {
    if (element.tagName === "TABLE") {
      const tableIndex = bodyIndex;
      element.setAttribute("data-docx-tbl", String(tableIndex));
      // Direct outer rows only — `<tr>` elements whose closest enclosing
      // `<table>` is THIS table (not a nested one).
      const outerRows = Array.from(element.querySelectorAll<HTMLElement>("tr")).filter(
        (row) => row.closest("table") === element,
      );
      let rowIndex = 0;
      outerRows.forEach((row) => {
        const text = row.innerText || row.textContent || "";
        if (!normalizeSourceText(text)) return;
        rowIndex += 1;
        const key = `docx-tbl-${tableIndex}-r-${rowIndex}`;
        row.setAttribute("data-docx-tbl", String(tableIndex));
        row.setAttribute("data-docx-row", String(rowIndex));
        elements.set(key, row);
        candidates.push({ key, text, docxTableIndex: tableIndex, docxRowIndex: rowIndex });

        // Step E: nested-table walk. Within THIS outer row, locate every
        // nested `<table>` (one level deep, ordered by document position
        // cumulatively across cells). Numbering matches the producer's
        // `inner_seq` (0-based, cumulative across `row.cells[*].tables`).
        const innerTables = Array.from(row.querySelectorAll<HTMLTableElement>("table")).filter(
          (t) => t.closest("td,th") && t.closest("td,th")!.closest("table") === element,
        );
        innerTables.forEach((innerTable, innerSeq) => {
          innerTable.setAttribute("data-docx-outer-tbl", String(tableIndex));
          innerTable.setAttribute("data-docx-outer-row", String(rowIndex));
          innerTable.setAttribute("data-docx-inner-tbl", String(innerSeq));
          const innerRows = Array.from(innerTable.querySelectorAll<HTMLElement>("tr")).filter(
            (ir) => ir.closest("table") === innerTable,
          );
          let innerRowIdx = 0;
          innerRows.forEach((innerRow) => {
            const innerText = innerRow.innerText || innerRow.textContent || "";
            if (!normalizeSourceText(innerText)) return;
            innerRowIdx += 1;
            const innerKey = `docx-tbl-${tableIndex}-r-${rowIndex}-tbl-${innerSeq}-r-${innerRowIdx}`;
            innerRow.setAttribute("data-docx-inner-row", String(innerRowIdx));
            elements.set(innerKey, innerRow);
            candidates.push({
              key: innerKey,
              text: innerText,
              docxOuterTableIndex: tableIndex,
              docxOuterRowIndex: rowIndex,
              docxInnerTableIndex: innerSeq,
              docxInnerRowIndex: innerRowIdx,
            });
          });
        });
      });
      bodyIndex += 1;
      return;
    }

    const key = `docx-p-${bodyIndex}`;
    element.setAttribute("data-docx-p", String(bodyIndex));
    elements.set(key, element);
    candidates.push({
      key,
      text: element.innerText || element.textContent || "",
      docxParagraphIndex: bodyIndex,
    });
    bodyIndex += 1;
  });

  // Step E: header/footer candidates. docx-preview renders each section's
  // header/footer in dedicated `.docx-header`/`.docx-footer` containers
  // and emits them in section order. We mirror python-docx's iteration
  // (`document.sections[i].header.paragraphs[j]`) by indexing the
  // container by its document-order position and the inner paragraphs by
  // their position within the container.
  collectDocxHeaderFooter(root, ".docx-header", "header", candidates, elements);
  collectDocxHeaderFooter(root, ".docx-footer", "footer", candidates, elements);

  return { candidates, elements };
}

function collectDocxHeaderFooter(
  root: HTMLElement,
  containerSelector: string,
  kind: "header" | "footer",
  candidates: SourceMatchCandidate[],
  elements: Map<string, HTMLElement>,
) {
  const containers = Array.from(root.querySelectorAll<HTMLElement>(containerSelector));
  containers.forEach((container, sectionIdx) => {
    const sectionId = `section-${sectionIdx}`;
    container.setAttribute("data-docx-section", sectionId);
    // Paragraph-like children. Walk only direct paragraph-shaped nodes so
    // we don't double-count text wrapped in `<span>`s. python-docx emits
    // empty placeholder paragraphs that we skip via the normalized-text
    // check below — same predicate as the body's canonical empty rule.
    const paragraphs = Array.from(container.querySelectorAll<HTMLElement>("p,h1,h2,h3,h4,h5,h6,li"));
    let paraIdx = 0;
    paragraphs.forEach((paragraph) => {
      const text = paragraph.innerText || paragraph.textContent || "";
      if (!normalizeSourceText(text)) return;
      const key = `docx-${kind}-${sectionId}-p-${paraIdx}`;
      paragraph.setAttribute("data-docx-section", sectionId);
      paragraph.setAttribute(`data-docx-${kind}-p`, String(paraIdx));
      elements.set(key, paragraph);
      candidates.push({
        key,
        text,
        ...(kind === "header"
          ? { docxHeaderSectionId: sectionId, docxHeaderParagraphIndex: paraIdx }
          : { docxFooterSectionId: sectionId, docxFooterParagraphIndex: paraIdx }),
      });
      paraIdx += 1;
    });
  });
}

function suppressRenderedDocxLinks(root: HTMLElement) {
  root.querySelectorAll<HTMLAnchorElement>("a").forEach((anchor) => {
    anchor.setAttribute("aria-disabled", "true");
    anchor.setAttribute("title", "Links in the source preview are disabled. Use Open original for the file.");
    anchor.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
    });
  });
}

function splitOriginalText(text: string): SourceMatchCandidate[] {
  const lines = text.split(/\r?\n/);
  return lines.map((line, index) => ({ key: `line-${index}`, text: line }));
}

function pdfOverlayRect(block: SourceBlock, geometry: PdfPageGeometry) {
  const bbox = block.source_location?.bbox || block.bbox;
  if (!bbox || bbox.length < 4) return null;
  const [x0, y0, x1, y1] = bbox as [number, number, number, number];
  const sx = geometry.cssWidth / geometry.pdfWidth;
  const sy = geometry.cssHeight / geometry.pdfHeight;
  return {
    left: x0 * sx,
    top: y0 * sy,
    width: Math.max(8, (x1 - x0) * sx),
    height: Math.max(8, (y1 - y0) * sy),
  };
}

function sourceAnchorClass(
  blockId: string,
  activeSet: Set<string>,
  selectedSet: Set<string>,
  previewSet: Set<string>,
  filterIds: Set<string>,
  hasFilter: boolean,
) {
  const selected = selectedSet.has(blockId) || activeSet.has(blockId);
  return [
    "source-viewer-anchor",
    activeSet.has(blockId) ? "source-viewer-active" : "",
    selectedSet.has(blockId) ? "source-viewer-selected" : "",
    previewSet.has(blockId) && !selected ? "source-viewer-preview" : "",
    hasFilter && filterIds.has(blockId) ? "source-viewer-filter-match" : "",
  ]
    .filter(Boolean)
    .join(" ");
}
