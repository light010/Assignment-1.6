import { WorkbenchIssue, WorkbenchState, WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";

export type AttentionFilter = "all" | "attention" | "errors" | "stale" | "review";
export type AttentionSeverity = "error" | "warning" | "stale" | "review" | "clean";

export type TopicAttentionSummary = {
  topicId: string;
  severity: AttentionSeverity;
  issues: WorkbenchIssue[];
  reviewMessages: string[];
  errorCount: number;
  warningCount: number;
  staleCount: number;
  reviewCount: number;
  hasAttention: boolean;
};

export type UnitAttentionSummary = {
  unitId: string;
  severity: AttentionSeverity;
  issues: WorkbenchIssue[];
  reviewMessages: string[];
  hasAttention: boolean;
};

export type ReviewedTopicState = {
  reviewed_at: string;
  hash: string;
};

export type TopicProgress = {
  reviewed: number;
  remaining: number;
  total: number;
};

export type NextAction =
  | { kind: "review_validation"; reason: string }
  | { kind: "resolve_stale"; reason: string }
  | { kind: "review_attention"; reason: string }
  | { kind: "mark_reviewed"; reason: string }
  | { kind: "advance_topic"; reason: string }
  | { kind: "none"; reason: string };

export type EvidenceNumber = {
  source_block_id: string;
  evidence_number: number;
};

const REVIEW_CONFIDENCE_THRESHOLD = 0.72;
const RANK: Record<AttentionSeverity, number> = {
  error: 5,
  warning: 4,
  stale: 3,
  review: 2,
  clean: 1,
};

export function issuesForTopic(issues: WorkbenchIssue[], topicId: string) {
  return issues.filter((issue) => issue.topic_id === topicId);
}

export function documentLevelIssues(issues: WorkbenchIssue[]) {
  return issues.filter((issue) => !issue.topic_id);
}

export function topicAttentionSummary(topic: WorkbenchTopic, issues: WorkbenchIssue[]): TopicAttentionSummary {
  const topicIssues = issuesForTopic(issues, topic.topic_id);
  const reviewMessages = topicReviewMessages(topic);
  const errorCount = topicIssues.filter((issue) => issue.severity === "error").length;
  const staleCount = topicIssues.filter((issue) => issue.code === "validation_stale").length || (topic.validation_stale ? 1 : 0);
  const warningCount = topicIssues.filter((issue) => issue.severity === "warning" && issue.code !== "validation_stale").length;
  const reviewCount = topicIssues.filter((issue) => issue.severity === "info").length + reviewMessages.length;
  const severity = strongestSeverity([
    errorCount > 0 ? "error" : "clean",
    warningCount > 0 ? "warning" : "clean",
    staleCount > 0 ? "stale" : "clean",
    reviewCount > 0 ? "review" : "clean",
  ]);

  return {
    topicId: topic.topic_id,
    severity,
    issues: topicIssues,
    reviewMessages,
    errorCount,
    warningCount,
    staleCount,
    reviewCount,
    hasAttention: severity !== "clean",
  };
}

export function topicAttentionSummaries(topics: WorkbenchTopic[], issues: WorkbenchIssue[]) {
  return new Map(topics.map((topic) => [topic.topic_id, topicAttentionSummary(topic, issues)] as const));
}

export function unitAttentionSummary(unit: WorkbenchUnit, issues: WorkbenchIssue[]): UnitAttentionSummary {
  const sourceIds = new Set(unit.source_block_ids);
  const unitIssues = issues.filter((issue) => {
    if (issue.unit_id === unit.unit_id) return true;
    return issue.source_block_ids.some((blockId) => sourceIds.has(blockId));
  });
  const reviewMessages = unit.confidence < REVIEW_CONFIDENCE_THRESHOLD
    ? [`Low extraction confidence (${Math.round(unit.confidence * 100)}%).`]
    : [];
  const severity = strongestSeverity([
    ...unitIssues.map(issueSeverity),
    reviewMessages.length > 0 ? "review" : "clean",
  ]);

  return {
    unitId: unit.unit_id,
    severity,
    issues: unitIssues,
    reviewMessages,
    hasAttention: severity !== "clean",
  };
}

export function topicMatchesAttentionFilter(summary: TopicAttentionSummary, filter: AttentionFilter) {
  if (filter === "all") return true;
  if (filter === "attention") return summary.hasAttention;
  if (filter === "errors") return summary.errorCount > 0;
  if (filter === "stale") return summary.staleCount > 0;
  return summary.reviewCount > 0;
}

export function filterAndSortTopics(
  topics: WorkbenchTopic[],
  summaries: Map<string, TopicAttentionSummary>,
  filter: AttentionFilter,
) {
  const filtered = topics.filter((topic) => {
    const summary = summaries.get(topic.topic_id) || topicAttentionSummary(topic, []);
    return topicMatchesAttentionFilter(summary, filter);
  });
  if (filter === "all") return filtered;
  return filtered.sort((left, right) => {
    const leftSummary = summaries.get(left.topic_id) || topicAttentionSummary(left, []);
    const rightSummary = summaries.get(right.topic_id) || topicAttentionSummary(right, []);
    return RANK[rightSummary.severity] - RANK[leftSummary.severity];
  });
}

export function attentionCounts(topics: WorkbenchTopic[], summaries: Map<string, TopicAttentionSummary>) {
  return topics.reduce(
    (counts, topic) => {
      const summary = summaries.get(topic.topic_id);
      if (!summary) return counts;
      counts.attention += summary.hasAttention ? 1 : 0;
      counts.errors += summary.errorCount > 0 ? 1 : 0;
      counts.stale += summary.staleCount > 0 ? 1 : 0;
      counts.review += summary.reviewCount > 0 ? 1 : 0;
      return counts;
    },
    { attention: 0, errors: 0, stale: 0, review: 0 },
  );
}

export function defaultActiveTopicId(
  state: WorkbenchState,
  summaries: Map<string, TopicAttentionSummary>,
) {
  const attentionTopic = [...state.topics]
    .filter((topic) => summaries.get(topic.topic_id)?.hasAttention)
    .sort((left, right) => {
      const leftSummary = summaries.get(left.topic_id) || topicAttentionSummary(left, []);
      const rightSummary = summaries.get(right.topic_id) || topicAttentionSummary(right, []);
      return RANK[rightSummary.severity] - RANK[leftSummary.severity];
    })[0];
  return attentionTopic?.topic_id || state.topics[0]?.topic_id || "";
}

export function topicContentHash(topic: WorkbenchTopic) {
  return hashString(stableStringify({
    topic_id: topic.topic_id,
    title: topic.title,
    topic_type: topic.topic_type,
    source_block_ids: topic.source_block_ids,
    validation_stale: topic.validation_stale,
    units: topic.units.map((unit) => ({
      unit_id: unit.unit_id,
      source_block_ids: unit.source_block_ids,
      text: unit.text,
      block_type: unit.block_type,
      confidence: unit.confidence,
      is_virtual: Boolean(unit.is_virtual),
      source_range: unit.source_range || null,
    })),
  }));
}

export function isTopicReviewCurrent(topic: WorkbenchTopic, reviewed?: ReviewedTopicState) {
  return Boolean(reviewed && reviewed.hash === topicContentHash(topic));
}

export function topicProgress(
  topics: WorkbenchTopic[],
  reviewed: Record<string, ReviewedTopicState>,
): TopicProgress {
  const reviewedCount = topics.filter((topic) => isTopicReviewCurrent(topic, reviewed[topic.topic_id])).length;
  return {
    reviewed: reviewedCount,
    remaining: Math.max(0, topics.length - reviewedCount),
    total: topics.length,
  };
}

export function nextActionForTopic(
  topic: WorkbenchTopic,
  summary: TopicAttentionSummary,
  reviewed?: ReviewedTopicState,
): NextAction {
  if (summary.errorCount > 0) return { kind: "review_validation", reason: "Review blocking validation issues first." };
  if (summary.staleCount > 0 || topic.validation_stale) return { kind: "resolve_stale", reason: "Local edits made validation stale." };
  if (summary.warningCount > 0 || summary.reviewCount > 0) {
    return { kind: "review_attention", reason: "Review highlighted confidence or structure concerns." };
  }
  if (!isTopicReviewCurrent(topic, reviewed)) return { kind: "mark_reviewed", reason: "Mark this clean topic reviewed." };
  return { kind: "advance_topic", reason: "Topic is reviewed. Move to the next topic." };
}

/**
 * Numbers evidence by source-block document order across the active topic.
 * Example: if topic units reference B, A, C but the document order is A, B, C,
 * numbering is A=1, B=2, C=3. Split units sharing the same source block share
 * the same evidence number.
 */
export function evidenceNumbering(state: WorkbenchState, topicId: string): EvidenceNumber[] {
  const topic = state.topics.find((item) => item.topic_id === topicId);
  if (!topic) return [];
  const topicSourceIds = new Set(topic.units.flatMap((unit) => unit.source_block_ids));
  const documentOrder = sourceBlockDocumentOrder(state);
  return documentOrder
    .filter((blockId) => topicSourceIds.has(blockId))
    .map((source_block_id, index) => ({ source_block_id, evidence_number: index + 1 }));
}

export function nextAttentionTopicId(
  topics: WorkbenchTopic[],
  summaries: Map<string, TopicAttentionSummary>,
  currentId: string,
) {
  const attentionTopics = topics.filter((topic) => summaries.get(topic.topic_id)?.hasAttention);
  if (attentionTopics.length === 0) return null;
  const currentIndex = attentionTopics.findIndex((topic) => topic.topic_id === currentId);
  return attentionTopics[(currentIndex + 1 + attentionTopics.length) % attentionTopics.length]?.topic_id || null;
}

export function commitTopicTitleDraft(currentTitle: string, draftTitle: string) {
  const nextTitle = draftTitle.trim();
  if (!nextTitle || nextTitle === currentTitle) return null;
  return nextTitle;
}

function sourceBlockDocumentOrder(state: WorkbenchState) {
  const seen = new Set<string>();
  const ordered: string[] = [];
  const add = (blockId: string) => {
    if (seen.has(blockId)) return;
    seen.add(blockId);
    ordered.push(blockId);
  };
  state.topics.forEach((topic) => {
    topic.source_block_ids.forEach(add);
    topic.units.forEach((unit) => unit.source_block_ids.forEach(add));
  });
  state.unassigned_units.forEach((unit) => unit.source_block_ids.forEach(add));
  return ordered;
}

function stableStringify(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, entry]) => `${JSON.stringify(key)}:${stableStringify(entry)}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

function hashString(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

function topicReviewMessages(topic: WorkbenchTopic) {
  const messages: string[] = [];
  if (topic.review_required) messages.push("Topic planner marked this topic for review.");
  if (topic.boundary_confidence > 0 && topic.boundary_confidence < REVIEW_CONFIDENCE_THRESHOLD) {
    messages.push(`Boundary confidence is ${Math.round(topic.boundary_confidence * 100)}%.`);
  }
  if (topic.type_confidence > 0 && topic.type_confidence < REVIEW_CONFIDENCE_THRESHOLD) {
    messages.push(`Type confidence is ${Math.round(topic.type_confidence * 100)}%.`);
  }
  return messages;
}

function issueSeverity(issue: WorkbenchIssue): AttentionSeverity {
  if (issue.severity === "error") return "error";
  if (issue.code === "validation_stale") return "stale";
  if (issue.severity === "warning") return "warning";
  return "review";
}

function strongestSeverity(severities: AttentionSeverity[]) {
  return severities.reduce<AttentionSeverity>(
    (strongest, severity) => (RANK[severity] > RANK[strongest] ? severity : strongest),
    "clean",
  );
}
