import { SourceBlock } from "./api";
import { AttentionSeverity } from "./workbenchSelectors";
import { WorkbenchIssue, WorkbenchState, WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";

export type ChunkNodeKind = "topic" | "unassigned" | "heading" | "table" | "chunk";

export type ChunkNode = {
  id: string;
  parentId?: string;
  kind: ChunkNodeKind;
  label: string;
  sourceBlockIds: string[];
  topicId?: string;
  topicType?: WorkbenchTopic["topic_type"];
  unitId?: string;
  blockType?: string;
  depth: number;
  children: ChunkNode[];
  severity: AttentionSeverity;
  confidence: number | null;
  isLocated: boolean;
  isActive: boolean;
  issueCount: number;
  meta: string;
};

export type ChunkExplorerModel = {
  roots: ChunkNode[];
  allNodes: ChunkNode[];
  nodeById: Map<string, ChunkNode>;
  sourceBlockToChunkId: Map<string, string>;
  chunkSourceBlockIds: Map<string, string[]>;
  ancestorIds: Map<string, string[]>;
};

export type ChunkNavigationKey = "up" | "down" | "right" | "left";

const SEVERITY_RANK: Record<AttentionSeverity, number> = {
  error: 5,
  warning: 4,
  stale: 3,
  review: 2,
  clean: 1,
};

const LOW_CONFIDENCE_THRESHOLD = 0.72;

export function buildChunkExplorer({
  state,
  blocks,
  issues,
  locatedSourceIds,
  sourceResolutionKnown,
  activeChunkId = "",
}: {
  state: WorkbenchState;
  blocks: SourceBlock[];
  issues: WorkbenchIssue[];
  locatedSourceIds: Set<string>;
  sourceResolutionKnown: boolean;
  activeChunkId?: string;
}): ChunkExplorerModel {
  const blockById = new Map(blocks.map((block) => [block.block_id, block] as const));
  const sourceOrder = new Map(blocks.map((block, index) => [block.block_id, index] as const));
  const roots: ChunkNode[] = [];

  sortedTopics(state.topics, sourceOrder).forEach((topic) => {
    const topicNode = makeNode({
      id: `topic:${topic.topic_id}`,
      kind: "topic",
      label: topic.title,
      sourceBlockIds: orderedSourceIds(topic.units.flatMap((unit) => unit.source_block_ids), sourceOrder),
      topicId: topic.topic_id,
      topicType: topic.topic_type,
      blockType: topic.topic_type,
      depth: 1,
      severity: severityForTopic(topic, issues),
      confidence: minNumber([topic.boundary_confidence, topic.type_confidence]),
      meta: `${topic.topic_type} · ${topic.units.length} chunks`,
      activeChunkId,
    });
    roots.push(topicNode);
    sortedUnits(topic.units, sourceOrder).forEach((unit) => {
      addUnitNode({
        root: topicNode,
        topic,
        unit,
        blockById,
        sourceOrder,
        issues,
        locatedSourceIds,
        sourceResolutionKnown,
        activeChunkId,
      });
    });
  });

  if (state.unassigned_units.length > 0) {
    const unassignedNode = makeNode({
      id: "unassigned",
      kind: "unassigned",
      label: "Unassigned chunks",
      sourceBlockIds: orderedSourceIds(state.unassigned_units.flatMap((unit) => unit.source_block_ids), sourceOrder),
      depth: 1,
      severity: "warning",
      confidence: minNumber(state.unassigned_units.map((unit) => unit.confidence)),
      meta: `${state.unassigned_units.length} chunks need a topic`,
      activeChunkId,
    });
    roots.push(unassignedNode);
    sortedUnits(state.unassigned_units, sourceOrder).forEach((unit) => {
      addUnitNode({
        root: unassignedNode,
        unit,
        blockById,
        sourceOrder,
        issues,
        locatedSourceIds,
        sourceResolutionKnown,
        activeChunkId,
      });
    });
  }

  rollUpNodes(roots, locatedSourceIds, sourceResolutionKnown, sourceOrder);
  const allNodes = flattenAllChunkNodes(roots);
  const nodeById = new Map(allNodes.map((node) => [node.id, node] as const));
  const chunkSourceBlockIds = new Map(allNodes.map((node) => [node.id, node.sourceBlockIds] as const));
  const ancestorIds = buildAncestorIds(roots);
  const sourceBlockToChunkId = buildSourceLookup(allNodes);

  return { roots, allNodes, nodeById, sourceBlockToChunkId, chunkSourceBlockIds, ancestorIds };
}

export function defaultExpandedChunkIds(roots: ChunkNode[]) {
  return new Set(flattenAllChunkNodes(roots).filter((node) => node.children.length > 0).map((node) => node.id));
}

export function flattenVisibleChunkNodes(roots: ChunkNode[], expandedIds: Set<string>) {
  const visible: ChunkNode[] = [];
  const visit = (node: ChunkNode) => {
    visible.push(node);
    if (!expandedIds.has(node.id)) return;
    node.children.forEach(visit);
  };
  roots.forEach(visit);
  return visible;
}

export function navigateChunkTree({
  visibleNodes,
  nodeById,
  expandedIds,
  activeId,
  key,
}: {
  visibleNodes: ChunkNode[];
  nodeById: Map<string, ChunkNode>;
  expandedIds: Set<string>;
  activeId: string;
  key: ChunkNavigationKey;
}) {
  const nextExpandedIds = new Set(expandedIds);
  const activeNode = nodeById.get(activeId) || visibleNodes[0];
  if (!activeNode) return { activeId, expandedIds: nextExpandedIds };

  if (key === "up" || key === "down") {
    const currentIndex = Math.max(0, visibleNodes.findIndex((node) => node.id === activeNode.id));
    const delta = key === "down" ? 1 : -1;
    const nextIndex = Math.min(visibleNodes.length - 1, Math.max(0, currentIndex + delta));
    return { activeId: visibleNodes[nextIndex]?.id || activeNode.id, expandedIds: nextExpandedIds };
  }

  if (key === "right") {
    if (activeNode.children.length === 0) return { activeId: activeNode.id, expandedIds: nextExpandedIds };
    if (!nextExpandedIds.has(activeNode.id)) {
      nextExpandedIds.add(activeNode.id);
      return { activeId: activeNode.id, expandedIds: nextExpandedIds };
    }
    return { activeId: activeNode.children[0]?.id || activeNode.id, expandedIds: nextExpandedIds };
  }

  if (activeNode.children.length > 0 && nextExpandedIds.has(activeNode.id)) {
    nextExpandedIds.delete(activeNode.id);
    return { activeId: activeNode.id, expandedIds: nextExpandedIds };
  }

  return { activeId: activeNode.parentId || activeNode.id, expandedIds: nextExpandedIds };
}

function addUnitNode({
  root,
  topic,
  unit,
  blockById,
  sourceOrder,
  issues,
  locatedSourceIds,
  sourceResolutionKnown,
  activeChunkId,
}: {
  root: ChunkNode;
  topic?: WorkbenchTopic;
  unit: WorkbenchUnit;
  blockById: Map<string, SourceBlock>;
  sourceOrder: Map<string, number>;
  issues: WorkbenchIssue[];
  locatedSourceIds: Set<string>;
  sourceResolutionKnown: boolean;
  activeChunkId: string;
}) {
  const primaryBlock = primaryBlockForUnit(unit, blockById, sourceOrder);
  if (primaryBlock?.block_type === "heading") {
    const heading = ensureHeadingNode(root, primaryBlock, topic, activeChunkId);
    hydrateStructuralNodeFromUnit(heading, unit, issues, sourceResolutionKnown, locatedSourceIds);
    return;
  }

  let parent = primaryBlock ? ensureHeadingPath(root, primaryBlock.heading_path_ids || [], blockById, topic, activeChunkId) : root;
  if (primaryBlock?.table_id) {
    parent = ensureTableNode(parent, primaryBlock, topic, activeChunkId);
  }

  parent.children.push(makeNode({
    id: `${parent.id}:unit:${unit.unit_id}`,
    parentId: parent.id,
    kind: "chunk",
    label: unit.text || primaryBlock?.text || "Untitled chunk",
    sourceBlockIds: orderedSourceIds(unit.source_block_ids, sourceOrder),
    topicId: topic?.topic_id,
    topicType: topic?.topic_type,
    unitId: unit.unit_id,
    blockType: unit.block_type,
    depth: parent.depth + 1,
    severity: strongestSeverity([
      severityForUnit(unit, issues, blockById),
      locatedStatus(unit.source_block_ids, locatedSourceIds, sourceResolutionKnown) ? "clean" : "review",
    ]),
    confidence: unit.confidence,
    isLocated: locatedStatus(unit.source_block_ids, locatedSourceIds, sourceResolutionKnown),
    issueCount: issueCountForSourceIds(unit.source_block_ids, issues),
    meta: unitMeta(unit, primaryBlock),
    activeChunkId,
  }));
}

function ensureHeadingPath(
  root: ChunkNode,
  headingIds: string[],
  blockById: Map<string, SourceBlock>,
  topic: WorkbenchTopic | undefined,
  activeChunkId: string,
) {
  let parent = root;
  headingIds.forEach((headingId) => {
    const block = blockById.get(headingId);
    if (!block) return;
    parent = ensureHeadingNode(parent, block, topic, activeChunkId);
  });
  return parent;
}

function ensureHeadingNode(parent: ChunkNode, block: SourceBlock, topic: WorkbenchTopic | undefined, activeChunkId: string) {
  const id = `${parent.id}:heading:${block.block_id}`;
  let node = parent.children.find((child) => child.id === id);
  if (node) return node;
  node = makeNode({
    id,
    parentId: parent.id,
    kind: "heading",
    label: block.text || "Untitled heading",
    sourceBlockIds: [block.block_id],
    topicId: topic?.topic_id,
    topicType: topic?.topic_type,
    blockType: "heading",
    depth: parent.depth + 1,
    severity: severityForBlock(block),
    confidence: block.confidence.heading ?? block.confidence.block_type ?? block.confidence.extraction ?? null,
    meta: `heading${block.inferred_level ? ` · level ${block.inferred_level}` : ""}`,
    activeChunkId,
  });
  parent.children.push(node);
  return node;
}

function ensureTableNode(parent: ChunkNode, block: SourceBlock, topic: WorkbenchTopic | undefined, activeChunkId: string) {
  const tableId = block.table_id || "table";
  const id = `${parent.id}:table:${tableId}`;
  let node = parent.children.find((child) => child.id === id);
  if (node) return node;
  node = makeNode({
    id,
    parentId: parent.id,
    kind: "table",
    label: `Table ${tableId.replace(/^tbl_/, "")}`,
    sourceBlockIds: [block.block_id],
    topicId: topic?.topic_id,
    topicType: topic?.topic_type,
    blockType: "table",
    depth: parent.depth + 1,
    severity: severityForBlock(block),
    confidence: block.confidence.extraction ?? block.confidence.block_type ?? null,
    meta: "table rows",
    activeChunkId,
  });
  parent.children.push(node);
  return node;
}

function hydrateStructuralNodeFromUnit(
  node: ChunkNode,
  unit: WorkbenchUnit,
  issues: WorkbenchIssue[],
  sourceResolutionKnown: boolean,
  locatedSourceIds: Set<string>,
) {
  node.unitId = unit.unit_id;
  node.label = unit.text || node.label;
  node.sourceBlockIds = unit.source_block_ids;
  node.severity = strongestSeverity([node.severity, severityForUnit(unit, issues, new Map())]);
  node.confidence = unit.confidence;
  node.isLocated = locatedStatus(unit.source_block_ids, locatedSourceIds, sourceResolutionKnown);
  node.issueCount = issueCountForSourceIds(unit.source_block_ids, issues);
  node.meta = unitMeta(unit);
}

function rollUpNodes(
  nodes: ChunkNode[],
  locatedSourceIds: Set<string>,
  sourceResolutionKnown: boolean,
  sourceOrder: Map<string, number>,
): void {
  nodes.forEach((node) => {
    rollUpNodes(node.children, locatedSourceIds, sourceResolutionKnown, sourceOrder);
    if (node.children.length === 0) return;
    node.severity = strongestSeverity([node.severity, ...node.children.map((child) => child.severity)]);
    node.issueCount += node.children.reduce((sum, child) => sum + child.issueCount, 0);
    node.confidence = minNumber([node.confidence, ...node.children.map((child) => child.confidence)]);
    node.sourceBlockIds = orderedSourceIds(
      [...node.sourceBlockIds, ...node.children.flatMap((child) => child.sourceBlockIds)],
      sourceOrder,
    );
    node.isLocated = locatedStatus(node.sourceBlockIds, locatedSourceIds, sourceResolutionKnown);
  });
}

type MakeNodeInput =
  & Omit<ChunkNode, "children" | "isActive" | "isLocated" | "issueCount" | "severity">
  & {
    activeChunkId: string;
    isLocated?: boolean;
    issueCount?: number;
    severity?: AttentionSeverity;
  };

function makeNode({
  id,
  parentId,
  kind,
  label,
  sourceBlockIds,
  topicId,
  topicType,
  unitId,
  blockType,
  depth,
  severity = "clean",
  confidence,
  isLocated = true,
  issueCount = 0,
  meta,
  activeChunkId,
}: MakeNodeInput) {
  return {
    id,
    parentId,
    kind,
    label,
    sourceBlockIds,
    topicId,
    topicType,
    unitId,
    blockType,
    depth,
    children: [],
    severity,
    confidence,
    isLocated,
    isActive: id === activeChunkId,
    issueCount,
    meta,
  };
}

function sortedTopics(topics: WorkbenchTopic[], sourceOrder: Map<string, number>) {
  return [...topics].sort((left, right) => topicOrder(left, sourceOrder) - topicOrder(right, sourceOrder));
}

function sortedUnits(units: WorkbenchUnit[], sourceOrder: Map<string, number>) {
  return [...units].sort((left, right) => unitOrder(left, sourceOrder) - unitOrder(right, sourceOrder));
}

function topicOrder(topic: WorkbenchTopic, sourceOrder: Map<string, number>) {
  return minOrder(topic.units.flatMap((unit) => unit.source_block_ids).concat(topic.source_block_ids), sourceOrder);
}

function unitOrder(unit: WorkbenchUnit, sourceOrder: Map<string, number>) {
  return minOrder(unit.source_block_ids, sourceOrder);
}

function minOrder(sourceIds: string[], sourceOrder: Map<string, number>) {
  return Math.min(...sourceIds.map((sourceId) => sourceOrder.get(sourceId) ?? Number.POSITIVE_INFINITY));
}

function primaryBlockForUnit(unit: WorkbenchUnit, blockById: Map<string, SourceBlock>, sourceOrder: Map<string, number>) {
  const blockId = [...unit.source_block_ids].sort((left, right) => (sourceOrder.get(left) ?? 0) - (sourceOrder.get(right) ?? 0))[0];
  return blockId ? blockById.get(blockId) : undefined;
}

function orderedSourceIds(sourceIds: string[], sourceOrder: Map<string, number>) {
  return [...new Set(sourceIds)].sort((left, right) => {
    const leftOrder = sourceOrder.get(left) ?? Number.POSITIVE_INFINITY;
    const rightOrder = sourceOrder.get(right) ?? Number.POSITIVE_INFINITY;
    return leftOrder - rightOrder || left.localeCompare(right);
  });
}

function severityForTopic(topic: WorkbenchTopic, issues: WorkbenchIssue[]) {
  const ownIssues = issues.filter((issue) => issue.topic_id === topic.topic_id);
  return strongestSeverity([
    ...ownIssues.map(severityForIssue),
    topic.review_required ? "review" : "clean",
    topic.validation_stale ? "stale" : "clean",
    topic.boundary_confidence < LOW_CONFIDENCE_THRESHOLD || topic.type_confidence < LOW_CONFIDENCE_THRESHOLD ? "review" : "clean",
  ]);
}

function severityForUnit(unit: WorkbenchUnit, issues: WorkbenchIssue[], blockById: Map<string, SourceBlock>) {
  const sourceIds = new Set(unit.source_block_ids);
  const unitIssues = issues.filter((issue) =>
    issue.unit_id === unit.unit_id || issue.source_block_ids.some((sourceId) => sourceIds.has(sourceId)),
  );
  const blockSeverities = unit.source_block_ids.flatMap((sourceId) => {
    const block = blockById.get(sourceId);
    return block ? [severityForBlock(block)] : [];
  });
  return strongestSeverity([
    ...unitIssues.map(severityForIssue),
    ...blockSeverities,
    unit.confidence < LOW_CONFIDENCE_THRESHOLD ? "review" : "clean",
  ]);
}

function severityForBlock(block: SourceBlock): AttentionSeverity {
  const flagSeverities = (block.review_flags || []).map((flag) => {
    if (flag === "LOW_BLOCK_TYPE_CONFIDENCE" || flag === "SUSPECTED_HEADING_FRAGMENT") return "review";
    return "warning";
  });
  return strongestSeverity(flagSeverities.length ? flagSeverities : ["clean"]);
}

function severityForIssue(issue: WorkbenchIssue): AttentionSeverity {
  if (issue.severity === "error") return "error";
  if (issue.code === "validation_stale") return "stale";
  if (issue.severity === "warning") return "warning";
  return "review";
}

function strongestSeverity(values: AttentionSeverity[]) {
  return values.reduce<AttentionSeverity>(
    (strongest, value) => (SEVERITY_RANK[value] > SEVERITY_RANK[strongest] ? value : strongest),
    "clean",
  );
}

function issueCountForSourceIds(sourceIds: string[], issues: WorkbenchIssue[]) {
  const sourceSet = new Set(sourceIds);
  return issues.filter((issue) => issue.source_block_ids.some((sourceId) => sourceSet.has(sourceId))).length;
}

function locatedStatus(sourceIds: string[], locatedSourceIds: Set<string>, sourceResolutionKnown: boolean) {
  if (!sourceResolutionKnown || sourceIds.length === 0) return true;
  return sourceIds.some((sourceId) => locatedSourceIds.has(sourceId));
}

function unitMeta(unit: WorkbenchUnit, block?: SourceBlock) {
  const location = block?.source_location?.page ? `p.${block.source_location.page}` : null;
  const confidence = `${Math.round(unit.confidence * 100)}%`;
  return [unit.block_type, confidence, location, unit.source_block_ids.join(", ")].filter(Boolean).join(" · ");
}

function minNumber(values: Array<number | null | undefined>) {
  const numbers = values.filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  return numbers.length ? Math.min(...numbers) : null;
}

function flattenAllChunkNodes(roots: ChunkNode[]) {
  const nodes: ChunkNode[] = [];
  const visit = (node: ChunkNode) => {
    nodes.push(node);
    node.children.forEach(visit);
  };
  roots.forEach(visit);
  return nodes;
}

function buildAncestorIds(roots: ChunkNode[]) {
  const ancestorIds = new Map<string, string[]>();
  const visit = (node: ChunkNode, ancestors: string[]) => {
    ancestorIds.set(node.id, ancestors);
    node.children.forEach((child) => visit(child, [...ancestors, node.id]));
  };
  roots.forEach((root) => visit(root, []));
  return ancestorIds;
}

function buildSourceLookup(nodes: ChunkNode[]) {
  const lookup = new Map<string, string>();
  nodes
    .filter((node) => node.kind === "chunk" || node.kind === "heading")
    .sort((left, right) => right.depth - left.depth)
    .forEach((node) => {
      node.sourceBlockIds.forEach((sourceId) => {
        if (!lookup.has(sourceId)) lookup.set(sourceId, node.id);
      });
    });
  return lookup;
}
