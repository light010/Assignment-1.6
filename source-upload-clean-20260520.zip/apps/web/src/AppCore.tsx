import { FormEvent, useEffect, useMemo, useState } from "react";
import { AppNav, LoginView, TopAppBar } from "./AppChrome";
import { BusinessUnitDashboard } from "./BusinessUnitDashboard";
import { UploadHub } from "./UploadHub";
import { type Panel } from "./appTypes";
import { BusinessUnit, DocumentRecord, User, createBusinessUnit, deleteBusinessUnit, deleteDocument, listBusinessUnitDocuments, listBusinessUnits, logout, storeBusinessUnitId, storedBusinessUnitId, storedUser } from "./api";

export { ExtractionFailedPanel, ExtractionNeedsReviewPanel } from "./ExtractionReviewBanner";

export function App() {

  const [user, setUser] = useState<User | null>(storedUser());
  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
  const [activeBusinessUnitId, setActiveBusinessUnitId] = useState<string>(storedBusinessUnitId());
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [activeDocumentId, setActiveDocumentId] = useState<string>("");
  const [activeTopicId, setActiveTopicId] = useState<string>("");
  const [panel, setPanel] = useState<Panel>("workbench");
  const [error, setError] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [loadingBusinessUnits, setLoadingBusinessUnits] = useState(false);

  useEffect(() => {
    function handleSessionExpired() {
      setUser(null);
      setBusinessUnits([]);
      setActiveBusinessUnitId("");
      setDocuments([]);
      setActiveDocumentId("");
      setActiveTopicId("");
      storeBusinessUnitId("");
      setError("Session expired. Sign in again.");
    }
    window.addEventListener("ditagen:session-expired", handleSessionExpired);
    return () => window.removeEventListener("ditagen:session-expired", handleSessionExpired);
  }, []);

  async function refreshBusinessUnits(preferredBusinessUnitId = activeBusinessUnitId) {
    if (!user) return;
    setLoadingBusinessUnits(true);
    try {
      const result = await listBusinessUnits();
      setBusinessUnits(result.business_units);
      if (
        preferredBusinessUnitId &&
        !result.business_units.some((businessUnit) => businessUnit.business_unit_id === preferredBusinessUnitId)
      ) {
        storeBusinessUnitId("");
        setActiveBusinessUnitId("");
        setDocuments([]);
      }
    } finally {
      setLoadingBusinessUnits(false);
    }
  }

  async function refreshDocuments(businessUnitId = activeBusinessUnitId) {
    if (!user || !businessUnitId) {
      setDocuments([]);
      return;
    }
    const result = await listBusinessUnitDocuments(businessUnitId);
    setDocuments(result.documents);
    if (activeDocumentId && !result.documents.some((doc) => doc.document_id === activeDocumentId)) {
      setActiveDocumentId("");
    }
  }

  useEffect(() => {
    refreshBusinessUnits().catch((err) => setError((err as Error).message));
  }, [user]);

  useEffect(() => {
    refreshDocuments(activeBusinessUnitId).catch((err) => setError((err as Error).message));
  }, [activeBusinessUnitId]);

  const activeBusinessUnit = useMemo(
    () => businessUnits.find((businessUnit) => businessUnit.business_unit_id === activeBusinessUnitId),
    [businessUnits, activeBusinessUnitId],
  );
  const activeDocument = documents.find((doc) => doc.document_id === activeDocumentId);

  useEffect(() => {
    // If the active document is no longer in the current BU, clear the
    // selection. We do NOT auto-select the first document any more — the
    // Upload Hub leaves detail collapsed until the user explicitly opens
    // a document, so the dropzone stays visually dominant on entry.
    if (activeDocumentId && !activeDocument) {
      setActiveDocumentId("");
    }
  }, [activeDocumentId, activeDocument]);

  if (!user) {
    return <LoginView onLogin={setUser} />;
  }

  async function selectBusinessUnit(businessUnitId: string) {
    storeBusinessUnitId(businessUnitId);
    setActiveBusinessUnitId(businessUnitId);
    setActiveDocumentId("");
    setActiveTopicId("");
    setPanel("workbench");
    setError("");
    await refreshDocuments(businessUnitId);
  }

  function returnToBusinessUnits() {
    storeBusinessUnitId("");
    setActiveBusinessUnitId("");
    setDocuments([]);
    setActiveDocumentId("");
    setActiveTopicId("");
    setPanel("workbench");
  }

  async function handleDeleteDocument(doc: DocumentRecord) {
    const confirmed = window.confirm(
      `Delete "${doc.filename}"? This will remove the document, its source blocks, generated topics, and artifacts. This cannot be undone.`,
    );
    if (!confirmed) return;
    setError("");
    try {
      await deleteDocument(doc.document_id);
      if (activeDocumentId === doc.document_id) {
        setActiveDocumentId("");
        setActiveTopicId("");
      }
      await refreshDocuments(activeBusinessUnitId);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleDeleteBusinessUnit(businessUnit: BusinessUnit) {
    const confirmed = window.confirm(
      `Delete the business unit "${businessUnit.name}"? This will remove its documents and history. This cannot be undone.`,
    );
    if (!confirmed) return;
    setBusy(true);
    setError("");
    try {
      await deleteBusinessUnit(businessUnit.business_unit_id);
      if (activeBusinessUnitId === businessUnit.business_unit_id) {
        returnToBusinessUnits();
      }
      await refreshBusinessUnits();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function handleCreateBusinessUnit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const name = String(form.get("name") || "").trim();
    if (!name) return;
    setBusy(true);
    setError("");
    try {
      const created = await createBusinessUnit({
        name,
        owner_team: String(form.get("owner_team") || "Unassigned").trim(),
        region: String(form.get("region") || "Global").trim(),
      });
      await refreshBusinessUnits(created.business_unit_id);
      formElement.reset();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    logout();
    setUser(null);
    setBusinessUnits([]);
    setActiveBusinessUnitId("");
    setDocuments([]);
    setActiveDocumentId("");
    setActiveTopicId("");
  }

  if (!activeBusinessUnitId || !activeBusinessUnit) {
    return (
      <div className="app-shell">
        <TopAppBar user={user} onSignOut={signOut} contextLabel="Business Units" />
        <AppNav active="home" canNavigateHome={false} />
        <BusinessUnitDashboard
          user={user}
          businessUnits={businessUnits}
          loading={loadingBusinessUnits}
          busy={busy}
          error={error}
          onSelectBusinessUnit={selectBusinessUnit}
          onRefresh={() => refreshBusinessUnits()}
          onCreateBusinessUnit={handleCreateBusinessUnit}
          onDeleteBusinessUnit={handleDeleteBusinessUnit}
        />
      </div>
    );
  }

  return (
    <div className="app-shell">
      <TopAppBar user={user} onSignOut={signOut} contextLabel={activeBusinessUnit.name} />
      <AppNav active="documents" canNavigateHome onNavigateHome={returnToBusinessUnits} />

      <main className="workspace">
        <UploadHub
          businessUnit={activeBusinessUnit}
          documents={documents}
          activeDocument={activeDocument}
          activeDocumentId={activeDocumentId}
          setActiveDocumentId={setActiveDocumentId}
          activeTopicId={activeTopicId}
          setActiveTopicId={setActiveTopicId}
          panel={panel}
          setPanel={setPanel}
          user={user}
          error={error}
          setError={setError}
          busy={busy}
          onBackToBusinessUnits={returnToBusinessUnits}
          onDeleteDocument={handleDeleteDocument}
          refreshDocuments={() => refreshDocuments(activeBusinessUnitId)}
        />
      </main>
    </div>
  );
}
