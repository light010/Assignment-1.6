import { SourceBlock, TopicCandidate, TopicRecord, TopicType } from "./api";

export type WorkbenchTopicType = TopicType;

export type WorkbenchOp =
  | { kind: "merge_units"; op_id: string; topic_id: string; unit_ids: string[] }
  | { kind: "split_unit"; op_id: string; topic_id: string; unit_id: string; offset: number }
  | {
      kind: "move_units";
      op_id: string;
      unit_ids: string[];
      from_topic_id: string;
      to_topic_id: string;
      before_unit_id?: string;
    }
  | { kind: "rename_topic"; op_id: string; topic_id: string; title: string }
  | { kind: "retype_topic"; op_id: string; topic_id: string; topic_type: WorkbenchTopicType };

export type WorkbenchUnit = {
  unit_id: string;
  topic_id: string;
  source_block_ids: string[];
  text: string;
  block_type: string;
  confidence: number;
  is_virtual?: boolean;
  source_range?: { start: number; end: number };
};

export type WorkbenchTopic = {
  topic_id: string;
  topic_record_id?: string;
  title: string;
  topic_type: WorkbenchTopicType;
  source_block_ids: string[];
  boundary_confidence: number;
  type_confidence: number;
  review_required: boolean;
  review_issues: WorkbenchIssue[];
  validation_issues: WorkbenchIssue[];
  validation_stale: boolean;
  units: WorkbenchUnit[];
};

export type WorkbenchIssue = {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
  topic_id?: string;
  unit_id?: string;
  source_block_ids: string[];
};

export type WorkbenchState = {
  document_id: string;
  topics: WorkbenchTopic[];
  unassigned_units: WorkbenchUnit[];
};

const TOPIC_TYPES: WorkbenchTopicType[] = ["concept", "task", "reference", "troubleshooting", "glossary"];

export function storageKeyForWorkbenchOps(documentId: string) {
  return `ditagen.workbench.ops.${documentId}`;
}

export function normalizeTopicType(value: string): WorkbenchTopicType {
  return TOPIC_TYPES.includes(value as WorkbenchTopicType) ? (value as WorkbenchTopicType) : "concept";
}

export function buildWorkbenchState({
  documentId,
  blocks,
  candidates,
  topicRecords = [],
}: {
  documentId: string;
  blocks: SourceBlock[];
  candidates: TopicCandidate[];
  topicRecords?: TopicRecord[];
}): WorkbenchState {
  const blocksById = new Map(blocks.map((block) => [block.block_id, block]));
  const recordsByCandidate = new Map(
    topicRecords
      .map((record) => [record.generated_topic.topic_candidate_id, record] as const)
      .filter(([candidateId]) => !!candidateId),
  );
  const assignedBlockIds = new Set<string>();
  const topics = candidates.map((candidate) => {
    const record = recordsByCandidate.get(candidate.topic_candidate_id);
    const units = candidate.source_block_ids.flatMap((blockId) => {
      const block = blocksById.get(blockId);
      if (!block) return [];
      assignedBlockIds.add(block.block_id);
      return [unitFromBlock(candidate.topic_candidate_id, block)];
    });
    return {
      topic_id: candidate.topic_candidate_id,
      topic_record_id: record?.topic_record_id,
      title: record?.generated_topic.title || candidate.title,
      topic_type: normalizeTopicType(record?.generated_topic.topic_type || candidate.topic_type),
      source_block_ids: candidate.source_block_ids,
      boundary_confidence: candidate.boundary_confidence ?? 0,
      type_confidence: candidate.type_confidence ?? 0,
      review_required: Boolean(candidate.review_required),
      review_issues: (candidate.review_issues || []).map((issue) => normalizeIssue(issue)),
      validation_issues: (record?.validation_issues || []).map((issue) => normalizeIssue(issue)),
      validation_stale: false,
      units,
    };
  });
  const unassigned_units = blocks
    .filter((block) => !assignedBlockIds.has(block.block_id))
    .map((block) => unitFromBlock("__unassigned__", block));
  return { document_id: documentId, topics, unassigned_units };
}

export function applyWorkbenchOps(base: WorkbenchState, ops: WorkbenchOp[]) {
  return ops.reduce((state, op) => applyWorkbenchOp(state, op), cloneState(base));
}

export function applyWorkbenchOp(state: WorkbenchState, op: WorkbenchOp): WorkbenchState {
  const next = cloneState(state);
  if (op.kind === "merge_units") return applyMerge(next, op);
  if (op.kind === "split_unit") return applySplit(next, op);
  if (op.kind === "move_units") return applyMove(next, op);
  if (op.kind === "rename_topic") return applyRename(next, op);
  return applyRetype(next, op);
}

export function computeCoverage(state: WorkbenchState, blocks: SourceBlock[]) {
  const assigned = new Set<string>();
  for (const topic of state.topics) {
    for (const unit of topic.units) {
      for (const blockId of unit.source_block_ids) assigned.add(blockId);
    }
  }
  const all = blocks.map((block) => block.block_id);
  const unassigned = all.filter((blockId) => !assigned.has(blockId));
  return {
    total: all.length,
    assigned: assigned.size,
    unassigned,
    percent: all.length ? assigned.size / all.length : 1,
  };
}

export function computeWorkbenchIssues(state: WorkbenchState, blocks: SourceBlock[]): WorkbenchIssue[] {
  const issues: WorkbenchIssue[] = [];
  const coverage = computeCoverage(state, blocks);
  if (coverage.unassigned.length > 0) {
    issues.push({
      code: "unassigned_source_blocks",
      severity: "warning",
      message: `${coverage.unassigned.length} source blocks are not assigned to a topic.`,
      source_block_ids: coverage.unassigned,
    });
  }
  for (const topic of state.topics) {
    if (topic.units.length === 0) {
      issues.push({
        code: "empty_topic",
        severity: "error",
        message: "Topic has no extracted units.",
        topic_id: topic.topic_id,
        source_block_ids: [],
      });
    }
    if (topic.topic_type === "task" && !topic.units.some((unit) => unit.block_type === "procedure_step")) {
      issues.push({
        code: "task_without_steps",
        severity: "warning",
        message: "Task topic has no procedure steps.",
        topic_id: topic.topic_id,
        source_block_ids: topic.units.flatMap((unit) => unit.source_block_ids),
      });
    }
    if (topic.topic_type === "concept" && hasConsecutiveProcedureSteps(topic.units)) {
      issues.push({
        code: "concept_contains_step_sequence",
        severity: "warning",
        message: "Concept topic contains consecutive procedure steps.",
        topic_id: topic.topic_id,
        source_block_ids: topic.units.flatMap((unit) => unit.source_block_ids),
      });
    }
    if (topic.validation_stale) {
      issues.push({
        code: "validation_stale",
        severity: "warning",
        message: "Local edits changed this topic after fetched DITA validation.",
        topic_id: topic.topic_id,
        source_block_ids: topic.units.flatMap((unit) => unit.source_block_ids),
      });
    }
    issues.push(...topic.review_issues.map((issue) => ({ ...issue, topic_id: topic.topic_id })));
    issues.push(...topic.validation_issues.map((issue) => ({ ...issue, topic_id: topic.topic_id })));
  }
  return issues.sort((left, right) => issueRank(right) - issueRank(left));
}

export function canMergeUnits(state: WorkbenchState, topicId: string, unitIds: string[]) {
  try {
    assertAdjacentUnits(state, topicId, unitIds);
    return true;
  } catch {
    return false;
  }
}

export function canSplitUnit(state: WorkbenchState, topicId: string, unitId: string, offset: number) {
  const { unit } = findUnit(state, topicId, unitId);
  if (unit.is_virtual || unit.source_block_ids.length !== 1) return false;
  if (offset <= 0 || offset >= unit.text.length) return false;
  return Boolean(unit.text.slice(0, offset).trim() && unit.text.slice(offset).trim());
}

function unitFromBlock(topicId: string, block: SourceBlock): WorkbenchUnit {
  return {
    unit_id: `unit_${block.block_id}`,
    topic_id: topicId,
    source_block_ids: [block.block_id],
    text: block.text,
    block_type: block.block_type,
    confidence: block.confidence.extraction ?? block.confidence.block_type ?? 0,
  };
}

function applyMerge(state: WorkbenchState, op: Extract<WorkbenchOp, { kind: "merge_units" }>) {
  const { topic, indexes } = assertAdjacentUnits(state, op.topic_id, op.unit_ids);
  const selected = indexes.map((index) => topic.units[index]!);
  const merged: WorkbenchUnit = {
    unit_id: `unit_merge_${op.op_id}`,
    topic_id: topic.topic_id,
    source_block_ids: selected.flatMap((unit) => unit.source_block_ids),
    text: selected.map((unit) => unit.text).join("\n"),
    block_type: selected.every((unit) => unit.block_type === selected[0]!.block_type) ? selected[0]!.block_type : "mixed",
    confidence: Math.min(...selected.map((unit) => unit.confidence)),
    is_virtual: true,
  };
  topic.units.splice(indexes[0]!, indexes.length, merged);
  topic.validation_stale = true;
  return state;
}

function applySplit(state: WorkbenchState, op: Extract<WorkbenchOp, { kind: "split_unit" }>) {
  if (!canSplitUnit(state, op.topic_id, op.unit_id, op.offset)) {
    throw new Error("Unit cannot be split at the requested offset.");
  }
  const { topic, unit, index } = findUnit(state, op.topic_id, op.unit_id);
  const leftText = unit.text.slice(0, op.offset).trim();
  const rightText = unit.text.slice(op.offset).trim();
  const first: WorkbenchUnit = {
    ...unit,
    unit_id: `${unit.unit_id}_split_a_${op.op_id}`,
    text: leftText,
    source_range: { start: 0, end: op.offset },
  };
  const second: WorkbenchUnit = {
    ...unit,
    unit_id: `${unit.unit_id}_split_b_${op.op_id}`,
    text: rightText,
    source_range: { start: op.offset, end: unit.text.length },
  };
  topic.units.splice(index, 1, first, second);
  topic.validation_stale = true;
  return state;
}

function applyMove(state: WorkbenchState, op: Extract<WorkbenchOp, { kind: "move_units" }>) {
  if (op.from_topic_id === op.to_topic_id) return state;
  const from = findTopic(state, op.from_topic_id);
  const to = findTopic(state, op.to_topic_id);
  const indexes = op.unit_ids.map((unitId) => from.units.findIndex((unit) => unit.unit_id === unitId));
  if (indexes.some((index) => index < 0)) throw new Error("Cannot move units that do not exist.");
  const moving = [...indexes]
    .sort((left, right) => left - right)
    .map((index) => ({ ...from.units[index]!, topic_id: to.topic_id }));
  [...indexes].sort((left, right) => right - left).forEach((index) => from.units.splice(index, 1));
  const beforeIndex = op.before_unit_id ? to.units.findIndex((unit) => unit.unit_id === op.before_unit_id) : -1;
  to.units.splice(beforeIndex >= 0 ? beforeIndex : to.units.length, 0, ...moving);
  from.validation_stale = true;
  to.validation_stale = true;
  return state;
}

function applyRename(state: WorkbenchState, op: Extract<WorkbenchOp, { kind: "rename_topic" }>) {
  const topic = findTopic(state, op.topic_id);
  if (!op.title.trim()) throw new Error("Topic title is required.");
  topic.title = op.title.trim();
  topic.validation_stale = true;
  return state;
}

function applyRetype(state: WorkbenchState, op: Extract<WorkbenchOp, { kind: "retype_topic" }>) {
  const topic = findTopic(state, op.topic_id);
  topic.topic_type = op.topic_type;
  topic.validation_stale = true;
  return state;
}

function assertAdjacentUnits(state: WorkbenchState, topicId: string, unitIds: string[]) {
  if (unitIds.length < 2) throw new Error("Select at least two units to merge.");
  const topic = findTopic(state, topicId);
  const indexes = unitIds.map((unitId) => topic.units.findIndex((unit) => unit.unit_id === unitId));
  if (indexes.some((index) => index < 0)) throw new Error("All merged units must belong to the same topic.");
  indexes.sort((left, right) => left - right);
  for (let i = 1; i < indexes.length; i += 1) {
    if (indexes[i] !== indexes[i - 1]! + 1) throw new Error("Merged units must be adjacent.");
  }
  return { topic, indexes };
}

function findTopic(state: WorkbenchState, topicId: string) {
  const topic = state.topics.find((item) => item.topic_id === topicId);
  if (!topic) throw new Error(`Topic not found: ${topicId}`);
  return topic;
}

function findUnit(state: WorkbenchState, topicId: string, unitId: string) {
  const topic = findTopic(state, topicId);
  const index = topic.units.findIndex((unit) => unit.unit_id === unitId);
  if (index < 0) throw new Error(`Unit not found: ${unitId}`);
  return { topic, unit: topic.units[index]!, index };
}

function cloneState(state: WorkbenchState): WorkbenchState {
  return {
    document_id: state.document_id,
    topics: state.topics.map((topic) => ({
      ...topic,
      source_block_ids: [...topic.source_block_ids],
      review_issues: topic.review_issues.map((issue) => ({ ...issue, source_block_ids: [...issue.source_block_ids] })),
      validation_issues: topic.validation_issues.map((issue) => ({
        ...issue,
        source_block_ids: [...issue.source_block_ids],
      })),
      units: topic.units.map((unit) => ({ ...unit, source_block_ids: [...unit.source_block_ids] })),
    })),
    unassigned_units: state.unassigned_units.map((unit) => ({ ...unit, source_block_ids: [...unit.source_block_ids] })),
  };
}

function normalizeIssue(issue: {
  code: string;
  severity: string;
  message: string;
  source_block_ids?: string[];
}): WorkbenchIssue {
  const severity = issue.severity === "error" ? "error" : issue.severity === "info" ? "info" : "warning";
  return {
    code: issue.code,
    severity,
    message: issue.message,
    source_block_ids: issue.source_block_ids || [],
  };
}

function hasConsecutiveProcedureSteps(units: WorkbenchUnit[]) {
  return units.some((unit, index) => unit.block_type === "procedure_step" && units[index + 1]?.block_type === "procedure_step");
}

function issueRank(issue: WorkbenchIssue) {
  if (issue.severity === "error") return 3;
  if (issue.severity === "warning") return 2;
  return 1;
}
