import { describe, expect, it } from "vitest";
// Vite's `resolveJsonModule` lets us import the schema directly. Using
// JSON import (vs. Node `fs.readFileSync`) keeps the test compatible
// with the production `tsc` compile step — Node-only imports would
// require a separate vitest-only tsconfig.
import schema from "../../../contracts/artifacts/extraction-quality.schema.json";
import { BLOCKING_REASON_LABELS, blockingReasonLabel } from "./qualityGateLabels";

describe("blockingReasonLabel", () => {
  it("returns a hand-tuned label for every known code", () => {
    expect(blockingReasonLabel("pandoc_unavailable")).toBe(
      "Pandoc is not available on the server",
    );
    expect(blockingReasonLabel("mdformat_plugin_missing")).toBe(
      "mdformat's gfm plugin is missing",
    );
    expect(blockingReasonLabel("missing_required_artifacts")).toBe(
      "Extraction service returned an incomplete artifact set",
    );
  });

  it("falls back to a clear 'Unknown reason: X' for codes not in the map", () => {
    // Unknown codes are surfaced verbatim — never silently dropped, never
    // run through generic case-conversion which would mis-render
    // mdformat_plugin_missing as 'Mdformat Plugin Missing'.
    expect(blockingReasonLabel("xyz_unrecognized")).toBe("Unknown reason: xyz_unrecognized");
  });

  it("covers every enum value in the extraction-quality schema", () => {
    // Architecture lock: if the schema introduces a new blocking_reason,
    // this test fails until qualityGateLabels.ts adds a label. Without
    // it, new enum values would fall through to the "Unknown reason"
    // fallback and the UI would show ugly debug-looking text.
    const enumValues: string[] = (schema as {
      properties: {
        gate: {
          properties: { blocking_reasons: { items: { enum: string[] } } };
        };
      };
    }).properties.gate.properties.blocking_reasons.items.enum;
    const labeled = new Set(Object.keys(BLOCKING_REASON_LABELS));
    const missing = enumValues.filter((value) => !labeled.has(value));
    expect(missing).toEqual([]);
  });
});
