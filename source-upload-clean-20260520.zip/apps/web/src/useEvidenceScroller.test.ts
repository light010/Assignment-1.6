import { afterEach, describe, expect, it, vi } from "vitest";
import { scrollEvidenceTarget } from "./useEvidenceScroller";

describe("scrollEvidenceTarget", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it("scrolls element targets directly", () => {
    const scrollIntoView = vi.fn();

    scrollEvidenceTarget(
      { kind: "element", blockId: "block_a" },
      new Map([["block_a", { scrollIntoView }]]),
    );

    expect(scrollIntoView).toHaveBeenCalledWith({ block: "center", behavior: "smooth" });
  });

  it("navigates PDF pages before scrolling the target anchor", () => {
    const scrollIntoView = vi.fn();
    const navigate = vi.fn();
    vi.stubGlobal("requestAnimationFrame", (callback: FrameRequestCallback) => {
      callback(0);
      return 1;
    });

    scrollEvidenceTarget(
      { kind: "pdf_page", blockId: "block_b", page: 3 },
      new Map([["block_b", { scrollIntoView }]]),
      navigate,
    );

    expect(navigate).toHaveBeenCalledWith(3);
    expect(scrollIntoView).toHaveBeenCalledWith({ block: "center", behavior: "smooth" });
  });
});
