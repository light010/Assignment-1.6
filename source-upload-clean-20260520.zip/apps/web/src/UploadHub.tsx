import { Activity, FileText, Home, Info, RefreshCw, Search, Trash2, Upload, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { BusinessUnit, DocumentRecord, User, uploadBusinessUnitDocument } from "./api";
import { type Panel } from "./appTypes";
import { DocumentDetail } from "./DocumentDetail";
import { formatBytes, humanizeStatus, relativeTime } from "./formatters";

const allowedExtensions = [".docx", ".pdf", ".txt", ".md", ".html", ".htm"];
const maxUploadBytes = 250 * 1024 * 1024;

type LocalUpload = {
  localId: string;
  file: File;
  state: "queued" | "uploading" | "done" | "failed";
  error?: string;
  documentId?: string;
};

type StageState = "complete" | "active" | "pending" | "failed" | "warning";

type StageInfo = {
  index: number;
  state: StageState;
  label: string;
};

const STAGE_LABELS = ["Upload", "Extract", "Plan", "Convert", "Review", "Export"] as const;

function mapStatusToStage(status: string): StageInfo {
  const s = (status || "").toLowerCase();
  if (s.includes("fail")) {
    return { index: stageIndexBeforeFailure(s), state: "failed", label: humanizeStatus(status) };
  }
  // STAGE_LABELS = [Upload(0), Extract(1), Plan(2), Convert(3), Review(4), Export(5)]
  if (s === "queued" || s === "uploading") return { index: 0, state: "active", label: "Uploading" };
  if (s === "upload_complete") return { index: 1, state: "active", label: "Starting extraction" };
  if (s === "extracting" || s === "extraction_in_progress") {
    return { index: 1, state: "active", label: "Extracting" };
  }
  if (s === "extraction_complete" || s === "markdown_normalized") {
    return { index: 2, state: "active", label: "Planning topics" };
  }
  if (s === "extraction_needs_review") {
    return { index: 1, state: "warning", label: "Extraction review required" };
  }
  if (s === "topic_plan_ready") {
    return { index: 3, state: "active", label: "Generating DITA" };
  }
  if (s === "dita_generated") {
    return { index: 3, state: "active", label: "Validating" };
  }
  if (s === "validation_passed") {
    return { index: 4, state: "active", label: "Awaiting review" };
  }
  if (s === "validation_warnings") {
    return { index: 4, state: "warning", label: "Validation warnings" };
  }
  if (s === "ready_for_review" || s === "review_ready") {
    return { index: 4, state: "active", label: "Ready for review" };
  }
  if (s === "approved") {
    return { index: 5, state: "active", label: "Awaiting export" };
  }
  if (s === "export_ready") {
    return { index: 5, state: "complete", label: "Export ready" };
  }
  return { index: 0, state: "active", label: humanizeStatus(status || "queued") };
}

function stageIndexBeforeFailure(status: string): number {
  if (status.includes("upload")) return 0;
  if (status.includes("extract") || status.includes("markdown")) return 1;
  if (status.includes("plan") || status.includes("topic")) return 2;
  if (status.includes("convert") || status.includes("dita") || status.includes("validation")) return 3;
  if (status.includes("review")) return 4;
  if (status.includes("export")) return 5;
  return 0;
}

function StageStepper({ status, compact = false }: { status: string; compact?: boolean }) {
  const info = mapStatusToStage(status);
  return (
    <ol
      className={`stage-stepper${compact ? " compact" : ""}`}
      aria-label={`Pipeline stage: ${info.label}`}
    >
      {STAGE_LABELS.map((label, index) => {
        const cls =
          index < info.index
            ? "complete"
            : index === info.index
              ? info.state === "complete"
                ? "complete"
                : info.state === "warning"
                  ? "warning"
                  : info.state === "failed"
                    ? "failed"
                    : "active"
              : "pending";
        return (
          <li key={label} className={`stage stage-${cls}`}>
            <span className="stage-dot" aria-hidden />
            <span className="stage-label">{label}</span>
          </li>
        );
      })}
    </ol>
  );
}

function BUInfoPopover({ businessUnit }: { businessUnit: BusinessUnit }) {
  const [open, setOpen] = useState(false);
  const role = businessUnit.summary.current_user_role || "restricted";
  return (
    <div className="info-popover" data-open={open ? "true" : "false"}>
      <button
        type="button"
        className="info-popover-trigger"
        aria-haspopup="dialog"
        aria-expanded={open}
        title="Workspace details"
        onClick={() => setOpen((value) => !value)}
        onBlur={(event) => {
          if (!event.currentTarget.parentElement?.contains(event.relatedTarget as Node | null)) {
            setOpen(false);
          }
        }}
      >
        <Info size={14} />
      </button>
      {open && (
        <div className="info-popover-panel" role="dialog" aria-label="Workspace details">
          <dl>
            <div>
              <dt>Your role</dt>
              <dd>{role}</dd>
            </div>
            <div>
              <dt>Conversion target</dt>
              <dd>DITA {businessUnit.policy.target_dita_version}</dd>
            </div>
            <div>
              <dt>Storage used</dt>
              <dd>{formatBytes(businessUnit.summary.storage_bytes)}</dd>
            </div>
          </dl>
        </div>
      )}
    </div>
  );
}

function MultiFileDropzone({
  onAdd,
  disabled,
}: {
  onAdd: (files: File[]) => void;
  disabled?: boolean;
}) {
  const [isDragging, setIsDragging] = useState(false);
  const dragCounter = useMemo(() => ({ count: 0 }), []);

  function handleDragEnter(event: React.DragEvent<HTMLLabelElement>) {
    event.preventDefault();
    if (disabled) return;
    dragCounter.count += 1;
    if (event.dataTransfer.types.includes("Files")) setIsDragging(true);
  }
  function handleDragOver(event: React.DragEvent<HTMLLabelElement>) {
    event.preventDefault();
  }
  function handleDragLeave(event: React.DragEvent<HTMLLabelElement>) {
    event.preventDefault();
    dragCounter.count = Math.max(0, dragCounter.count - 1);
    if (dragCounter.count === 0) setIsDragging(false);
  }
  function handleDrop(event: React.DragEvent<HTMLLabelElement>) {
    event.preventDefault();
    dragCounter.count = 0;
    setIsDragging(false);
    if (disabled) return;
    const files = Array.from(event.dataTransfer.files || []);
    if (files.length > 0) onAdd(files);
  }
  function handleSelect(event: React.ChangeEvent<HTMLInputElement>) {
    if (disabled) return;
    const files = Array.from(event.currentTarget.files || []);
    if (files.length > 0) onAdd(files);
    event.currentTarget.value = "";
  }

  return (
    <label
      className={`dropzone-large${isDragging ? " is-dragging" : ""}${disabled ? " is-disabled" : ""}`}
      onDragEnter={handleDragEnter}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <span className="dropzone-icon" aria-hidden>
        <Upload size={28} />
      </span>
      <span className="dropzone-text">
        <strong>{isDragging ? "Release to add to queue" : "Drop documents to convert"}</strong>
        <small>
          or <span className="dropzone-link">click to browse</span> · DOCX · PDF · TXT · MD ·
          HTML · up to 250&nbsp;MB · multi-file
        </small>
      </span>
      <input
        type="file"
        multiple
        accept={allowedExtensions.join(",")}
        onChange={handleSelect}
        disabled={disabled}
      />
    </label>
  );
}

export function UploadHub({
  businessUnit,
  documents,
  activeDocument,
  activeDocumentId,
  setActiveDocumentId,
  activeTopicId,
  setActiveTopicId,
  panel,
  setPanel,
  user,
  error,
  setError,
  busy,
  onBackToBusinessUnits,
  onDeleteDocument,
  refreshDocuments,
}: {
  businessUnit: BusinessUnit;
  documents: DocumentRecord[];
  activeDocument: DocumentRecord | undefined;
  activeDocumentId: string;
  setActiveDocumentId: (id: string) => void;
  activeTopicId: string;
  setActiveTopicId: (id: string) => void;
  panel: Panel;
  setPanel: (panel: Panel) => void;
  user: User;
  error: string;
  setError: (error: string) => void;
  busy: boolean;
  onBackToBusinessUnits: () => void;
  onDeleteDocument: (doc: DocumentRecord) => Promise<void>;
  refreshDocuments: () => Promise<void>;
}) {
  const [queue, setQueue] = useState<LocalUpload[]>([]);
  // Track which document IDs were uploaded or interacted with in the
  // current browser session. Drives the "This session" grouping below.
  const [sessionDocIds, setSessionDocIds] = useState<Set<string>>(() => new Set());
  // Earlier-section toolbar state.
  const [earlierQuery, setEarlierQuery] = useState("");
  const [earlierFilter, setEarlierFilter] = useState<
    "all" | "review" | "warnings" | "failed" | "approved"
  >("all");
  const [earlierSort, setEarlierSort] = useState<"recent" | "name" | "status" | "quality">(
    "recent",
  );

  // Auto-process the next queued upload, one at a time. Keeps the network
  // serialized so users see clear progress and we don't thrash the API.
  useEffect(() => {
    const isUploading = queue.some((q) => q.state === "uploading");
    if (isUploading) return;
    const next = queue.find((q) => q.state === "queued");
    if (!next) return;

    setQueue((prev) =>
      prev.map((q) => (q.localId === next.localId ? { ...q, state: "uploading" } : q)),
    );

    uploadBusinessUnitDocument(businessUnit.business_unit_id, next.file)
      .then((result) => {
        setQueue((prev) =>
          prev.map((q) =>
            q.localId === next.localId
              ? { ...q, state: "done", documentId: result.document.document_id }
              : q,
          ),
        );
        // Mark the resulting document as "this session" so it stays in
        // the Hub's session group with a full stepper.
        setSessionDocIds((prev) => {
          const next = new Set(prev);
          next.add(result.document.document_id);
          return next;
        });
        return refreshDocuments();
      })
      .catch((err) => {
        setQueue((prev) =>
          prev.map((q) =>
            q.localId === next.localId
              ? { ...q, state: "failed", error: (err as Error).message }
              : q,
          ),
        );
      });
  }, [queue, businessUnit.business_unit_id, refreshDocuments]);

  // Poll for document status updates while any document is still in a
  // non-terminal pipeline stage. The backend updates the status field as
  // jobs progress; we just need to re-fetch periodically.
  useEffect(() => {
    const hasInFlight = documents.some((doc) => !isTerminalStatus(doc.status));
    if (!hasInFlight) return;
    const interval = setInterval(() => {
      refreshDocuments().catch(() => undefined);
    }, 3000);
    return () => clearInterval(interval);
  }, [documents, refreshDocuments]);

  function handleAddFiles(files: File[]) {
    setError("");
    const next: LocalUpload[] = [];
    for (const file of files) {
      const validation = validateUpload(file);
      if (validation) {
        next.push({
          localId: `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          file,
          state: "failed",
          error: validation,
        });
      } else {
        next.push({
          localId: `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          file,
          state: "queued",
        });
      }
    }
    setQueue((prev) => [...prev, ...next]);
  }

  function handleDismissUpload(localId: string) {
    setQueue((prev) => prev.filter((q) => q.localId !== localId));
  }

  function handleRetryUpload(localId: string) {
    setQueue((prev) =>
      prev.map((q) =>
        q.localId === localId ? { ...q, state: "queued", error: undefined } : q,
      ),
    );
  }

  const inFlightUploads = queue.filter((q) => q.state !== "done");

  // Documents grouped by recency: anything touched in this session
  // (uploaded just now, or processing) goes in "This session"; everything
  // else goes in "Earlier".
  const sessionDocs = documents.filter(
    (doc) => sessionDocIds.has(doc.document_id) || !isTerminalStatus(doc.status),
  );
  const earlierDocs = documents.filter(
    (doc) => !sessionDocIds.has(doc.document_id) && isTerminalStatus(doc.status),
  );

  const normalizedQuery = earlierQuery.trim().toLowerCase();
  const filteredEarlier = earlierDocs
    .filter((doc) => {
      if (normalizedQuery && !doc.filename.toLowerCase().includes(normalizedQuery)) {
        return false;
      }
      if (earlierFilter === "review") {
        return doc.status === "ready_for_review" || doc.status === "review_ready";
      }
      if (earlierFilter === "warnings") {
        return doc.status === "validation_warnings";
      }
      if (earlierFilter === "failed") {
        return doc.status.toLowerCase().includes("fail");
      }
      if (earlierFilter === "approved") {
        return doc.status === "approved" || doc.status === "export_ready";
      }
      return true;
    })
    .sort((a, b) => {
      if (earlierSort === "name") return a.filename.localeCompare(b.filename);
      if (earlierSort === "status") {
        return humanizeStatus(a.status).localeCompare(humanizeStatus(b.status));
      }
      if (earlierSort === "quality") {
        return (b.source_quality?.overall_confidence ?? 0) -
          (a.source_quality?.overall_confidence ?? 0);
      }
      // "recent" — newest first
      return String(b.created_at || "").localeCompare(String(a.created_at || ""));
    });

  const EARLIER_PREVIEW = 8;
  const earlierPreview = filteredEarlier.slice(0, EARLIER_PREVIEW);
  const earlierMore = Math.max(0, filteredEarlier.length - EARLIER_PREVIEW);

  // Linear-style architecture: when a document is selected, the BU
  // dashboard chrome (heading, dropzone, document list) is hidden and
  // the doc detail fills the canvas. The breadcrumb is the way back —
  // clicking the BU name in the breadcrumb clears activeDocumentId and
  // restores the dashboard. This is the same pattern as Linear/Vercel
  // when drilling into a ticket or deployment.
  const inDocumentMode = !!activeDocument;
  // H-audit-4: memoize per-document. Without this, `computeTabEnablement`
  // returns a fresh object every render and any downstream effect that
  // keys off it re-fires. Deps are the only inputs the function reads.
  const activeTabEnablement = useMemo(
    () => (activeDocument ? computeTabEnablement(activeDocument) : null),
    [activeDocument?.status, activeDocument?.source_quality?.quality_gate?.passed],
  );
  const activePanel = panel === "source" || (activeTabEnablement && !activeTabEnablement[panel]) ? "workbench" : panel;
  // H4: toast when the user clicks a disabled tab. Lifted to UploadHub
  // so the SOURCE panel can dispatch the message without owning it.
  const [hubToast, setHubToast] = useState<string>("");
  useEffect(() => {
    if (!hubToast) return;
    const handle = window.setTimeout(() => setHubToast(""), 3200);
    return () => window.clearTimeout(handle);
  }, [hubToast]);

  return (
    <section
      className={`upload-hub${inDocumentMode ? " upload-hub--document-mode" : ""}`}
      aria-label="Documents"
    >
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <button onClick={onBackToBusinessUnits} className="breadcrumb-back">
          <Home size={14} /> Business Units
        </button>
        <span className="breadcrumb-sep" aria-hidden>
          /
        </span>
        {inDocumentMode ? (
          <>
            <button
              type="button"
              className="breadcrumb-back"
              onClick={() => setActiveDocumentId("")}
            >
              {businessUnit.name}
            </button>
            <span className="breadcrumb-sep" aria-hidden>
              /
            </span>
            <span className="breadcrumb-current">{activeDocument!.filename}</span>
          </>
        ) : (
          <span className="breadcrumb-current">{businessUnit.name}</span>
        )}
      </nav>

      {error && <div className="error-banner">{error}</div>}

      {!inDocumentMode && (
        <>
          <header className="upload-hub-header">
            <h1>{businessUnit.name}</h1>
          </header>

          <MultiFileDropzone onAdd={handleAddFiles} disabled={busy} />
        </>
      )}

      {!inDocumentMode && (inFlightUploads.length > 0 || sessionDocs.length > 0) && (
        <section className="hub-section" aria-label="This session">
          <div className="hub-section-head">
            <h2>This session</h2>
            <span className="hub-section-count">
              {inFlightUploads.length + sessionDocs.length}
            </span>
          </div>
          <div className="upload-list">
            {inFlightUploads.map((upload) => (
              <LocalUploadRow
                key={upload.localId}
                upload={upload}
                onDismiss={handleDismissUpload}
                onRetry={handleRetryUpload}
              />
            ))}
            {sessionDocs.map((doc) => (
              <DocumentStageRow
                key={doc.document_id}
                doc={doc}
                isActive={doc.document_id === activeDocumentId}
                onSelect={(id) => {
                  setActiveDocumentId(id);
                  setActiveTopicId("");
                  setPanel(defaultPanelForDocument(doc));
                  setSessionDocIds((prev) => {
                    const next = new Set(prev);
                    next.add(id);
                    return next;
                  });
                }}
                onDelete={onDeleteDocument}
                variant="full"
              />
            ))}
          </div>
        </section>
      )}

      {!inDocumentMode && earlierDocs.length > 0 && (
        <section className="hub-section" aria-label="Earlier documents">
          <div className="hub-section-head">
            <h2>Earlier</h2>
            <span className="hub-section-count">{earlierDocs.length}</span>
          </div>
          <div className="hub-toolbar" role="search">
            <label className="filter-search">
              <Search size={15} aria-hidden />
              <input
                value={earlierQuery}
                onChange={(event) => setEarlierQuery(event.target.value)}
                placeholder="Search documents by name"
              />
            </label>
            <div className="hub-toolbar-right">
              <div className="saved-filters" aria-label="Earlier filter">
                {(
                  [
                    ["all", "All"],
                    ["review", "Review ready"],
                    ["warnings", "Warnings"],
                    ["failed", "Failed"],
                    ["approved", "Approved"],
                  ] as const
                ).map(([key, label]) => (
                  <button
                    key={key}
                    className={earlierFilter === key ? "active" : ""}
                    onClick={() => setEarlierFilter(key)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <label className="hub-sort">
                <span>Sort</span>
                <select
                  value={earlierSort}
                  onChange={(event) => setEarlierSort(event.target.value as typeof earlierSort)}
                >
                  <option value="recent">Most recent</option>
                  <option value="name">Filename</option>
                  <option value="status">Status</option>
                  <option value="quality">Quality</option>
                </select>
              </label>
            </div>
          </div>

          {filteredEarlier.length === 0 ? (
            <div className="empty-card">
              <p>No documents match the current filters.</p>
            </div>
          ) : (
            <div className="upload-list">
              {earlierPreview.map((doc) => (
                <DocumentStageRow
                  key={doc.document_id}
                  doc={doc}
                  isActive={doc.document_id === activeDocumentId}
                  onSelect={(id) => {
                    setActiveDocumentId(id);
                    setActiveTopicId("");
                    setPanel(defaultPanelForDocument(doc));
                    setSessionDocIds((prev) => {
                      const next = new Set(prev);
                      next.add(id);
                      return next;
                    });
                  }}
                  onDelete={onDeleteDocument}
                  variant="compact"
                />
              ))}
            </div>
          )}

          {earlierMore > 0 && (
            <button
              type="button"
              className="hub-view-all"
              title="A dedicated Documents page is coming soon"
              onClick={() =>
                setError(
                  "A dedicated Documents page is coming soon. For now, use the search and filters above.",
                )
              }
            >
              View all {filteredEarlier.length} documents in {businessUnit.name} →
            </button>
          )}
        </section>
      )}

      {!inDocumentMode && documents.length === 0 && inFlightUploads.length === 0 && (
        <div className="empty-card">
          <FileText size={28} />
          <p>No documents yet. Drop files into the box above to get started.</p>
        </div>
      )}

      {activeDocument && (
        <DocumentDetail
          document={activeDocument}
          user={user}
          activeTopicId={activeTopicId}
          setActiveTopicId={setActiveTopicId}
          activePanel={activePanel}
          tabEnablement={activeTabEnablement}
          setPanel={setPanel}
          refreshDocuments={refreshDocuments}
          onDisabledTab={setHubToast}
        />
      )}
      {hubToast && (
        <div className="hub-toast" role="status" aria-live="polite">
          {hubToast}
        </div>
      )}
    </section>
  );
}

function isTerminalStatus(status: string): boolean {
  const s = (status || "").toLowerCase();
  return (
    s === "ready_for_review" ||
    s === "review_ready" ||
    s === "approved" ||
    s === "export_ready" ||
    s === "rejected" ||
    s.includes("fail")
  );
}

function defaultPanelForDocument(document: DocumentRecord): Panel {
  return "workbench";
}

function computeTabEnablement(document: DocumentRecord): Record<Panel, boolean> {
  const status = (document.status || "").toLowerCase();
  const gate = document.source_quality?.quality_gate;
  const extractionBlocked = status === "extraction_needs_review" || gate?.passed === false;
  const extractionFailed = status === "failed_extraction";
  if (extractionBlocked || extractionFailed) {
    return {
      source: false,
      workbench: true,
      artifacts: true,
      jobs: true,
      "topic-plan": false,
      review: false,
      export: false,
    };
  }
  return {
    source: false,
    workbench: true,
    artifacts: true,
    jobs: true,
    "topic-plan": true,
    review: true,
    export: true,
  };
}

function disabledTabReason(document: DocumentRecord): string {
  const status = (document.status || "").toLowerCase();
  if (status === "failed_extraction") {
    return "Extraction failed - re-extract before opening this tab";
  }
  return "Extraction gated - resolve blocking reasons before opening this tab";
}

// Maps an alpha-state status into a small group tag used to color the
// status dot in the document header. Keeps the dot meaningful (green =
// done, blue = in progress, amber = warnings, red = failed) without
// introducing a separate component.
function stageGroupForStatus(status: string): "ok" | "warn" | "fail" | "active" {
  const s = (status || "").toLowerCase();
  if (s.includes("fail") || s === "rejected") return "fail";
  if (s === "validation_warnings" || s === "extraction_needs_review") return "warn";
  if (s === "approved" || s === "export_ready" || s === "ready_for_review" || s === "review_ready") {
    return "ok";
  }
  return "active";
}

function LocalUploadRow({
  upload,
  onDismiss,
  onRetry,
}: {
  upload: LocalUpload;
  onDismiss: (id: string) => void;
  onRetry: (id: string) => void;
}) {
  const status =
    upload.state === "queued"
      ? "queued"
      : upload.state === "uploading"
        ? "uploading"
        : upload.state === "failed"
          ? "upload_failed"
          : "upload_complete";
  return (
    <article className={`upload-row state-${upload.state}`}>
      <header className="upload-row-head">
        <span className="upload-row-icon" aria-hidden>
          <FileText size={18} />
        </span>
        <div className="upload-row-meta">
          <strong>{upload.file.name}</strong>
          <span>
            {formatBytes(upload.file.size)}
            {upload.error ? ` · ${upload.error}` : ""}
          </span>
        </div>
        <div className="upload-row-actions">
          {upload.state === "failed" && (
            <button
              type="button"
              className="upload-row-retry"
              onClick={() => onRetry(upload.localId)}
            >
              <RefreshCw size={13} /> Retry
            </button>
          )}
          <button
            type="button"
            className="upload-row-dismiss"
            onClick={() => onDismiss(upload.localId)}
            aria-label="Dismiss"
            title="Dismiss"
          >
            <X size={14} />
          </button>
        </div>
      </header>
      <StageStepper status={status} />
    </article>
  );
}

function DocumentStageRow({
  doc,
  isActive,
  onSelect,
  onDelete,
  variant = "auto",
}: {
  doc: DocumentRecord;
  isActive: boolean;
  onSelect: (id: string) => void;
  onDelete?: (doc: DocumentRecord) => Promise<void>;
  /** "full" always shows the stepper, "compact" never does, "auto" picks
   *  based on terminality. */
  variant?: "auto" | "full" | "compact";
}) {
  const stage = mapStatusToStage(doc.status);
  const isProcessing = !isTerminalStatus(doc.status);
  const showStepper =
    variant === "full" ? true : variant === "compact" ? false : isProcessing;
  return (
    <article
      className={`upload-row${isActive ? " is-active" : ""} stage-${stage.state}${showStepper ? "" : " is-compact"}`}
      role="button"
      tabIndex={0}
      onClick={() => onSelect(doc.document_id)}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onSelect(doc.document_id);
        }
      }}
    >
      {onDelete && (
        <button
          type="button"
          className="upload-row-delete"
          aria-label={`Delete ${doc.filename}`}
          title={`Delete ${doc.filename}`}
          onClick={(event) => {
            event.stopPropagation();
            onDelete(doc);
          }}
        >
          <Trash2 size={13} />
        </button>
      )}
      <header className="upload-row-head">
        <span className="upload-row-icon" aria-hidden>
          <FileText size={18} />
        </span>
        <div className="upload-row-meta">
          <strong>{doc.filename}</strong>
          <span>
            <span className={`status-chip tone-${stage.state}`}>{humanizeStatus(doc.status)}</span>
            {doc.topic_ids.length > 0
              ? ` · ${doc.topic_ids.length} ${doc.topic_ids.length === 1 ? "topic" : "topics"}`
              : ""}
            {doc.source_quality
              ? ` · ${Math.round(doc.source_quality.overall_confidence * 100)}% quality`
              : ""}
            {doc.created_at ? ` · ${relativeTime(doc.created_at)}` : ""}
          </span>
        </div>
        <div className="upload-row-actions">
          {isProcessing && (
            <span className="upload-row-pulse" aria-hidden title="Processing">
              <RefreshCw size={13} className="spin" />
            </span>
          )}
        </div>
      </header>
      {showStepper && <StageStepper status={doc.status} />}
    </article>
  );
}

function validateUpload(file: File) {
  const filename = file.name.toLowerCase();
  const validExtension = allowedExtensions.some((extension) => filename.endsWith(extension));
  if (!validExtension) {
    return "Upload supports DOCX, PDF, TXT, MD, HTML, and HTM files.";
  }
  if (file.size > maxUploadBytes) {
    return "File exceeds the 250 MB alpha limit.";
  }
  return "";
}
