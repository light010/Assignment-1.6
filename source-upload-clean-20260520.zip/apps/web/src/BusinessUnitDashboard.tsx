import { Building2, Plus, RefreshCw, Search, Trash2, X } from "lucide-react";
import { FormEvent, useState } from "react";
import { BusinessUnit, User } from "./api";
import { formatBytes } from "./formatters";

export function BusinessUnitDashboard({
  user,
  businessUnits,
  loading,
  busy,
  error,
  onSelectBusinessUnit,
  onRefresh,
  onCreateBusinessUnit,
  onDeleteBusinessUnit,
}: {
  user: User;
  businessUnits: BusinessUnit[];
  loading: boolean;
  busy: boolean;
  error: string;
  onSelectBusinessUnit: (businessUnitId: string) => Promise<void>;
  onRefresh: () => Promise<void>;
  onCreateBusinessUnit: (event: FormEvent<HTMLFormElement>) => Promise<void>;
  onDeleteBusinessUnit: (businessUnit: BusinessUnit) => Promise<void>;
}) {
  const [query, setQuery] = useState("");
  const [savedFilter, setSavedFilter] = useState("All");
  const [createOpen, setCreateOpen] = useState(false);
  const isAdmin = user.roles.includes("org_admin");
  const normalizedQuery = query.trim().toLowerCase();
  const filteredBusinessUnits = businessUnits
    .filter((businessUnit) => {
      const matchesQuery =
        !normalizedQuery ||
        [businessUnit.name, businessUnit.owner_team, businessUnit.region, businessUnit.description]
          .filter(Boolean)
          .some((value) => String(value).toLowerCase().includes(normalizedQuery));
      const status = businessUnit.summary.dominant_status_label;
      if (!matchesQuery) return false;
      if (savedFilter === "Processing") return businessUnit.summary.processing_count > 0;
      if (savedFilter === "Failed") return businessUnit.summary.failed_job_count > 0;
      if (savedFilter === "Needs Attention") {
        return ["Failed", "Validation Warnings", "Needs Review"].includes(status);
      }
      if (savedFilter === "Review Ready") return businessUnit.summary.review_ready_count > 0;
      if (savedFilter === "Export Ready") return businessUnit.summary.export_ready_count > 0;
      if (savedFilter === "Admin") return businessUnit.summary.current_user_role === "org_admin";
      return true;
    })
    .sort(
      (left, right) =>
        businessUnitSeverity(right) - businessUnitSeverity(left) ||
        right.summary.document_count - left.summary.document_count ||
        left.name.localeCompare(right.name),
    );
  const statusTotals = businessUnits.reduce(
    (total, businessUnit) => ({
      processing: total.processing + businessUnit.summary.processing_count,
      review: total.review + businessUnit.summary.review_ready_count,
      warnings: total.warnings + businessUnit.summary.validation_warning_count,
      failed: total.failed + businessUnit.summary.failed_job_count,
      exportReady: total.exportReady + businessUnit.summary.export_ready_count,
      storage: total.storage + businessUnit.summary.storage_bytes,
    }),
    { processing: 0, review: 0, warnings: 0, failed: 0, exportReady: 0, storage: 0 },
  );

  return (
    <main className="minimal-workspace">
      <section className="minimal-header">
        <div>
          <span className="eyebrow">
            <span className="eyebrow-dot" aria-hidden /> DITAgen Local · {user.roles.includes("org_admin") ? "Admin" : "Reviewer"}
          </span>
          <h1>Business Units</h1>
          <p>{businessUnits.length} accessible portfolios for document conversion, review, and export.</p>
        </div>
        <div className="minimal-actions">
          {isAdmin && (
            <button
              className={createOpen ? "btn-primary active" : "btn-primary"}
              onClick={() => setCreateOpen((current) => !current)}
              aria-expanded={createOpen}
              aria-controls="create-bu-form"
            >
              {createOpen ? <X size={16} /> : <Plus size={16} />}
              {createOpen ? "Cancel" : "Add Business Unit"}
            </button>
          )}
          <button onClick={onRefresh} disabled={loading} title="Refresh business units">
            <RefreshCw size={16} className={loading ? "spin" : ""} /> Refresh
          </button>
        </div>
      </section>

      <section className="metrics-strip" aria-label="Portfolio summary">
        <PortfolioMetric label="Review ready" value={statusTotals.review} />
        <PortfolioMetric
          label="Warnings"
          value={statusTotals.warnings}
          tone={statusTotals.warnings ? "warning" : "neutral"}
        />
        <PortfolioMetric
          label="Failed jobs"
          value={statusTotals.failed}
          tone={statusTotals.failed ? "danger" : "neutral"}
        />
        <PortfolioMetric label="Export ready" value={statusTotals.exportReady} />
        <PortfolioMetric label="Storage" value={formatBytes(statusTotals.storage)} />
      </section>

      {isAdmin && createOpen && (
        <form
          id="create-bu-form"
          className="inline-create-panel"
          onSubmit={onCreateBusinessUnit}
          aria-label="Create new business unit"
        >
          <div className="inline-create-header">
            <div>
              <h2>New business unit</h2>
              <p>Define ownership and region. You can configure conversion policy later.</p>
            </div>
          </div>
          <div className="inline-create-fields">
            <label>
              <span>Name</span>
              <input name="name" placeholder="e.g. Customer Documentation" required />
            </label>
            <label>
              <span>Owner team</span>
              <input name="owner_team" placeholder="e.g. Documentation Engineering" />
            </label>
            <label>
              <span>Region</span>
              <input name="region" placeholder="e.g. North America" />
            </label>
          </div>
          <div className="inline-create-actions">
            <button type="button" onClick={() => setCreateOpen(false)} disabled={busy}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={busy}>
              <Building2 size={16} /> Create business unit
            </button>
          </div>
        </form>
      )}

      <section className="minimal-toolbar" aria-label="Business unit filters">
        <label className="filter-search">
          <Search size={17} aria-hidden />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search BU, document, owner, region"
          />
        </label>
        <div className="saved-filters" aria-label="Saved filters">
          {["All", "Needs Attention", "Review Ready", "Failed", "Admin"].map((filter) => (
            <button
              key={filter}
              className={savedFilter === filter ? "active" : ""}
              onClick={() => setSavedFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
      </section>

      {error && <div className="error-banner">{error}</div>}

      {loading ? (
        <div className="empty-card">Loading business units…</div>
      ) : filteredBusinessUnits.length === 0 ? (
        <div className="empty-card">
          <Building2 size={28} />
          <p>No business units match the current filters.</p>
          <button onClick={() => setSavedFilter("All")}>Reset filters</button>
        </div>
      ) : (
        <section className="bu-grid" aria-label="Business unit cards">
          {filteredBusinessUnits.map((businessUnit) => (
            <BusinessUnitCard
              key={businessUnit.business_unit_id}
              businessUnit={businessUnit}
              onOpen={onSelectBusinessUnit}
              onDelete={isAdmin ? onDeleteBusinessUnit : undefined}
            />
          ))}
        </section>
      )}
    </main>
  );
}

function PortfolioMetric({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string | number;
  tone?: "neutral" | "warning" | "danger";
}) {
  return (
    <article className={`metric-card ${tone}`} aria-label={`${label}: ${value}`}>
      <span className="metric-card-label">{label}</span>
      <strong className="metric-card-value">{value}</strong>
    </article>
  );
}

function BusinessUnitCard({
  businessUnit,
  onOpen,
  onDelete,
}: {
  businessUnit: BusinessUnit;
  onOpen: (businessUnitId: string) => Promise<void>;
  onDelete?: (businessUnit: BusinessUnit) => Promise<void>;
}) {
  const summary = businessUnit.summary;
  const status = summary.dominant_status_label;
  const statusKey = status.toLowerCase().replace(/\s+/g, "-");
  const tone = pickTone(status, summary);
  const isEmpty = summary.document_count === 0;
  const ownerInitials = initials(businessUnit.owner_team || "Unassigned");
  const pipeline = pipelineSegments(summary);
  const lastActivity = relativeTime(summary.last_activity_at);
  const metaText =
    summary.processing_count > 0
      ? `${summary.processing_count} processing`
      : summary.review_ready_count > 0
        ? `${summary.review_ready_count} ready for review`
        : summary.failed_job_count > 0
          ? `${summary.failed_job_count} failed`
          : summary.export_ready_count > 0
            ? `${summary.export_ready_count} export ready`
            : isEmpty
              ? "No documents yet"
              : "All quiet";

  return (
    <article
      className={`bu-card tone-${tone}${isEmpty ? " is-empty" : ""}`}
      role="button"
      tabIndex={0}
      aria-label={`${businessUnit.name}, ${summary.document_count} documents, status ${status}`}
      onClick={() => onOpen(businessUnit.business_unit_id)}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onOpen(businessUnit.business_unit_id);
        }
      }}
    >
      {onDelete && (
        <button
          type="button"
          className="bu-card-delete"
          aria-label={`Delete ${businessUnit.name}`}
          title={`Delete ${businessUnit.name}`}
          onClick={(event) => {
            event.stopPropagation();
            onDelete(businessUnit);
          }}
        >
          <Trash2 size={14} />
        </button>
      )}

      <header className="bu-card-head">
        <div className="bu-card-owner" title={businessUnit.owner_team || "Unassigned"}>
          <span className={`bu-avatar tone-${tone}`} aria-hidden>{ownerInitials}</span>
          <div className="bu-card-owner-text">
            <span className="bu-card-owner-team">{businessUnit.owner_team || "Unassigned"}</span>
            <span className="bu-card-owner-region">{businessUnit.region || "Global"}</span>
          </div>
        </div>
        <span className={`bu-card-status ${statusKey}`}>{status}</span>
      </header>

      <h2 className="bu-card-name">{businessUnit.name}</h2>
      {businessUnit.description && (
        <p className="bu-card-description">{businessUnit.description}</p>
      )}

      <dl className="bu-card-stats">
        <div>
          <dt>Documents</dt>
          <dd>{summary.document_count}</dd>
        </div>
        <div>
          <dt>Review</dt>
          <dd>{summary.review_ready_count}</dd>
        </div>
        <div>
          <dt>Quality</dt>
          <dd>{formatConfidence(summary.avg_source_confidence)}</dd>
        </div>
      </dl>

      {pipeline.total > 0 ? (
        <div className="bu-card-pipeline" aria-hidden>
          {pipeline.segments.map((segment) => (
            <span
              key={segment.label}
              className={`pipeline-seg ${segment.cls}`}
              style={{ flexGrow: segment.value }}
              title={`${segment.label}: ${segment.value}`}
            />
          ))}
        </div>
      ) : null}

      <footer className="bu-card-foot">
        <span className="bu-card-meta">{metaText}</span>
        {lastActivity && <span className="bu-card-time">{lastActivity}</span>}
      </footer>
    </article>
  );
}

function relativeTime(value: string | null | undefined) {
  if (!value) return "";
  const then = new Date(value).getTime();
  if (Number.isNaN(then)) return "";
  const diff = Date.now() - then;
  if (diff < 0) return "just now";
  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  if (diff < minute) return "just now";
  if (diff < hour) return `${Math.floor(diff / minute)}m ago`;
  if (diff < day) return `${Math.floor(diff / hour)}h ago`;
  if (diff < 30 * day) return `${Math.floor(diff / day)}d ago`;
  if (diff < 365 * day) return `${Math.floor(diff / (30 * day))}mo ago`;
  return `${Math.floor(diff / (365 * day))}y ago`;
}

function initials(name: string) {
  if (!name) return "—";
  const tokens = name.split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return "—";
  if (tokens.length === 1) return tokens[0]!.slice(0, 2).toUpperCase();
  return (tokens[0]![0] + tokens[1]![0]).toUpperCase();
}

function pickTone(status: string, summary: BusinessUnit["summary"]) {
  if (status === "Failed" || summary.failed_job_count > 0) return "danger";
  if (status === "Validation Warnings" || summary.validation_warning_count > 0) return "warning";
  if (status === "Review Ready" || status === "Needs Review" || summary.review_ready_count > 0) return "info";
  if (status === "Export Ready" || summary.export_ready_count > 0) return "success";
  if (summary.processing_count > 0) return "processing";
  return "neutral";
}

function pipelineSegments(summary: BusinessUnit["summary"]) {
  const segments = [
    { label: "Failed", value: summary.failed_job_count, cls: "failed" },
    { label: "Warnings", value: summary.validation_warning_count, cls: "warnings" },
    { label: "Review", value: summary.review_ready_count, cls: "review" },
    { label: "Processing", value: summary.processing_count, cls: "processing" },
    { label: "Export", value: summary.export_ready_count, cls: "export" },
  ].filter((segment) => segment.value > 0);
  const total = segments.reduce((sum, s) => sum + s.value, 0);
  return { segments, total };
}

function businessUnitSeverity(businessUnit: BusinessUnit) {
  const summary = businessUnit.summary;
  if (summary.failed_job_count > 0) return 5;
  if (summary.validation_warning_count > 0) return 4;
  if (summary.review_ready_count > 0) return 3;
  if (summary.export_ready_count > 0) return 2;
  if (summary.processing_count > 0) return 1;
  return 0;
}

function formatConfidence(value: number | null) {
  return value === null ? "unknown" : `${Math.round(value * 100)}%`;
}

// =============================================================================
// UPLOAD HUB — primary post-BU surface
// =============================================================================
