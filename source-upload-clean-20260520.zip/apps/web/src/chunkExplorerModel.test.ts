import { describe, expect, it } from "vitest";
import {
  buildChunkExplorer,
  defaultExpandedChunkIds,
  flattenVisibleChunkNodes,
  navigateChunkTree,
} from "./chunkExplorerModel";
import { SourceBlock } from "./api";
import { WorkbenchIssue, WorkbenchState, WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";

describe("chunkExplorerModel", () => {
  it("orders topics by source order and nests chunks under headings and tables", () => {
    const state = makeState([
      makeTopic("late", "Late Topic", [unit("unit_c", ["blk_c"], "paragraph")]),
      makeTopic("early", "Early Topic", [unit("unit_h", ["blk_h"], "heading"), unit("unit_a", ["blk_a"], "paragraph"), unit("unit_r", ["blk_r"], "table_row")]),
    ]);
    const model = buildChunkExplorer({
      state,
      blocks: [
        block("blk_h", "heading", "Heading"),
        block("blk_a", "paragraph", "Alpha", { heading_path_ids: ["blk_h"] }),
        block("blk_r", "table_row", "Row", { heading_path_ids: ["blk_h"], table_id: "tbl_001", row_index: 1 }),
        block("blk_c", "paragraph", "Charlie"),
      ],
      issues: [],
      locatedSourceIds: new Set(["blk_h", "blk_a", "blk_r", "blk_c"]),
      sourceResolutionKnown: true,
    });

    expect(model.roots.map((node) => node.id)).toEqual(["topic:early", "topic:late"]);
    expect(model.nodeById.get("topic:early:heading:blk_h")?.children.map((node) => node.kind)).toEqual(["chunk", "table"]);
    expect(model.sourceBlockToChunkId.get("blk_r")).toBe("topic:early:heading:blk_h:table:tbl_001:unit:unit_r");
  });

  it("includes unassigned chunks and flags unlocated chunks after source resolution", () => {
    const state = makeState([], [unit("unit_orphan", ["blk_orphan"], "paragraph")]);
    const model = buildChunkExplorer({
      state,
      blocks: [block("blk_orphan", "paragraph", "Lost")],
      issues: [],
      locatedSourceIds: new Set(),
      sourceResolutionKnown: true,
    });

    expect(model.roots[0]?.kind).toBe("unassigned");
    const orphan = model.nodeById.get("unassigned:unit:unit_orphan");
    expect(orphan?.isLocated).toBe(false);
    expect(orphan?.severity).toBe("review");
  });

  it("keeps merged units as one chunk mapped to every source block", () => {
    const merged = unit("unit_merge", ["blk_a", "blk_b"], "mixed");
    const model = buildChunkExplorer({
      state: makeState([makeTopic("topic", "Topic", [merged])]),
      blocks: [block("blk_a", "paragraph", "A"), block("blk_b", "paragraph", "B")],
      issues: [],
      locatedSourceIds: new Set(["blk_a", "blk_b"]),
      sourceResolutionKnown: true,
    });

    expect(model.sourceBlockToChunkId.get("blk_a")).toBe("topic:topic:unit:unit_merge");
    expect(model.sourceBlockToChunkId.get("blk_b")).toBe("topic:topic:unit:unit_merge");
    expect(model.chunkSourceBlockIds.get("topic:topic:unit:unit_merge")).toEqual(["blk_a", "blk_b"]);
  });

  it("rolls issue severity up to parent nodes", () => {
    const issues: WorkbenchIssue[] = [{
      code: "task_without_steps",
      severity: "warning",
      message: "Needs steps",
      topic_id: "topic",
      source_block_ids: ["blk_a"],
    }];
    const model = buildChunkExplorer({
      state: makeState([makeTopic("topic", "Topic", [unit("unit_a", ["blk_a"], "paragraph")])]),
      blocks: [block("blk_a", "paragraph", "A")],
      issues,
      locatedSourceIds: new Set(["blk_a"]),
      sourceResolutionKnown: true,
    });

    expect(model.nodeById.get("topic:topic")?.severity).toBe("warning");
    expect(model.nodeById.get("topic:topic:unit:unit_a")?.severity).toBe("warning");
  });

  it("navigates visible tree rows with expand, enter, collapse, and parent exit behavior", () => {
    const model = buildChunkExplorer({
      state: makeState([makeTopic("topic", "Topic", [unit("unit_h", ["blk_h"], "heading"), unit("unit_a", ["blk_a"], "paragraph")])]),
      blocks: [
        block("blk_h", "heading", "Heading"),
        block("blk_a", "paragraph", "A", { heading_path_ids: ["blk_h"] }),
      ],
      issues: [],
      locatedSourceIds: new Set(["blk_h", "blk_a"]),
      sourceResolutionKnown: true,
    });
    let expandedIds = new Set(["topic:topic"]);
    let visible = flattenVisibleChunkNodes(model.roots, expandedIds);

    let next = navigateChunkTree({ visibleNodes: visible, nodeById: model.nodeById, expandedIds, activeId: "topic:topic", key: "down" });
    expect(next.activeId).toBe("topic:topic:heading:blk_h");

    next = navigateChunkTree({ visibleNodes: visible, nodeById: model.nodeById, expandedIds, activeId: "topic:topic:heading:blk_h", key: "right" });
    expandedIds = next.expandedIds;
    expect(expandedIds.has("topic:topic:heading:blk_h")).toBe(true);

    visible = flattenVisibleChunkNodes(model.roots, expandedIds);
    next = navigateChunkTree({ visibleNodes: visible, nodeById: model.nodeById, expandedIds, activeId: "topic:topic:heading:blk_h", key: "right" });
    expect(next.activeId).toBe("topic:topic:heading:blk_h:unit:unit_a");

    next = navigateChunkTree({ visibleNodes: visible, nodeById: model.nodeById, expandedIds, activeId: "topic:topic:heading:blk_h:unit:unit_a", key: "left" });
    expect(next.activeId).toBe("topic:topic:heading:blk_h");
  });

  it("defaults to expanding all parent nodes so chunks are immediately visible", () => {
    const model = buildChunkExplorer({
      state: makeState([makeTopic("topic", "Topic", [unit("unit_h", ["blk_h"], "heading"), unit("unit_a", ["blk_a"], "paragraph")])]),
      blocks: [
        block("blk_h", "heading", "Heading"),
        block("blk_a", "paragraph", "A", { heading_path_ids: ["blk_h"] }),
      ],
      issues: [],
      locatedSourceIds: new Set(["blk_h", "blk_a"]),
      sourceResolutionKnown: true,
    });

    expect(flattenVisibleChunkNodes(model.roots, defaultExpandedChunkIds(model.roots)).map((node) => node.id)).toContain(
      "topic:topic:heading:blk_h:unit:unit_a",
    );
  });
});

function makeState(topics: WorkbenchTopic[], unassigned_units: WorkbenchUnit[] = []): WorkbenchState {
  return { document_id: "doc", topics, unassigned_units };
}

function makeTopic(topic_id: string, title: string, units: WorkbenchUnit[]): WorkbenchTopic {
  return {
    topic_id,
    title,
    topic_type: "concept",
    source_block_ids: units.flatMap((item) => item.source_block_ids),
    boundary_confidence: 0.9,
    type_confidence: 0.86,
    review_required: false,
    review_issues: [],
    validation_issues: [],
    validation_stale: false,
    units,
  };
}

function unit(unit_id: string, source_block_ids: string[], block_type: string): WorkbenchUnit {
  return {
    unit_id,
    topic_id: "topic",
    source_block_ids,
    text: `${unit_id} text`,
    block_type,
    confidence: 0.9,
  };
}

function block(
  block_id: string,
  block_type: string,
  text: string,
  overrides: Partial<SourceBlock> = {},
): SourceBlock {
  return {
    block_id,
    block_type,
    text,
    source_location: { page: 1, bbox: null },
    heading_path_ids: [],
    confidence: { extraction: 0.9, block_type: 0.9, heading: block_type === "heading" ? 0.9 : null, semantic_inline: 0.9 },
    review_flags: [],
    ...overrides,
  };
}
