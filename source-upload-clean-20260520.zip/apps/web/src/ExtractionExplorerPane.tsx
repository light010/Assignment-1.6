import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Keyboard,
  Link2,
  MapPin,
  MapPinOff,
  Table2,
  TableRowsSplit,
  X,
} from "lucide-react";
import { CSSProperties, KeyboardEvent, ReactNode, useEffect, useRef, useState } from "react";
import {
  ExtractionAttentionSignal,
  ExtractionExplorerModel,
  ExtractionNavigationKey,
  ExtractionNode,
  extractionNodeBreadcrumb,
  LOW_CONFIDENCE_THRESHOLD,
  sourceBlockCountLabel,
} from "./extractionExplorerModel";
import { plural, stripTerminalMarker } from "./formatters";

export function ExtractionExplorerPane({
  model,
  visibleNodes,
  expandedNodeIds,
  activeNodeId,
  onSelectNode,
  onPreviewNode,
  onClearPreview,
  onToggleExpanded,
  onNavigate,
  revealNonce,
  onOpenShortcuts,
  attentionOnly,
  matchFailuresOnly,
  onShowMatchFailuresOnly,
  onClearMatchFailuresOnly,
  query,
  onClearQuery,
  onFocusReviewFlags,
}: {
  model: ExtractionExplorerModel;
  visibleNodes: ExtractionNode[];
  expandedNodeIds: Set<string>;
  activeNodeId: string;
  onSelectNode: (node: ExtractionNode) => void;
  onPreviewNode: (node: ExtractionNode) => void;
  onClearPreview: () => void;
  onToggleExpanded: (nodeId: string) => void;
  onNavigate: (key: ExtractionNavigationKey) => void;
  revealNonce: number;
  onOpenShortcuts: () => void;
  attentionOnly: boolean;
  matchFailuresOnly: boolean;
  onShowMatchFailuresOnly: () => void;
  onClearMatchFailuresOnly: () => void;
  query: string;
  onClearQuery: () => void;
  onFocusReviewFlags: () => void;
}) {
  const activeNode = model.nodeById.get(activeNodeId) || visibleNodes[0] || model.roots[0];
  const onlyDocumentVisible = visibleNodes.length <= 1 && visibleNodes[0]?.kind === "document";
  const totalRows = model.allNodes.filter((node) => node.kind !== "document").length;
  const visibleRows = visibleNodes.filter((node) => node.kind !== "document").length;
  const queryActive = query.trim().length > 0;
  const headerSeverityCounts = attentionSeverityCounts(model.allNodes.flatMap((node) => node.block ? node.attentionSignals : []));
  const nonPassingCheckCount = model.checklist.filter((item) => item.status !== "pass").length;
  const hasReviewFindings = model.attentionBlockCount > 0 || model.attentionSignalCount > 0 || nonPassingCheckCount > 0;
  const reviewFindingLabel = model.attentionBlockCount > 0
    ? `${model.attentionBlockCount} need review`
    : `${nonPassingCheckCount} ${plural(nonPassingCheckCount, "check")} ${nonPassingCheckCount === 1 ? "needs" : "need"} review`;
  return (
    <section className="workbench-extracted extraction-explorer-shell" aria-label="Extraction Explorer">
      <header className="extraction-explorer-header">
        <div>
          <h3><MapPin size={16} aria-hidden /> Blocks</h3>
          {queryActive && (
            <small className="search-result-count">
              {visibleRows} of {totalRows} shown
              <button type="button" onClick={onClearQuery} aria-label="Clear extraction search">
                <X size={12} />
              </button>
            </small>
          )}
        </div>
        <div className="extraction-explorer-stats" aria-label="Extraction status">
          {!hasReviewFindings ? (
            <span className="status-ok">All checks clear</span>
          ) : (
            <>
              <span className="status-warn">{reviewFindingLabel}</span>
              {headerSeverityCounts.error + headerSeverityCounts.warning + headerSeverityCounts.info > 0 && (
                <span className="status-warn severity-summary"><AttentionSeverityChips counts={headerSeverityCounts} /></span>
              )}
            </>
          )}
          <span className={model.locatedBlockCount === model.sourceBlockCount ? "status-ok" : "status-warn"}>
            {model.locatedBlockCount}/{model.sourceBlockCount} located
          </span>
        </div>
        <button type="button" onClick={onOpenShortcuts} title="Keyboard shortcuts" aria-label="Keyboard shortcuts">
          <Keyboard size={15} />
        </button>
      </header>

      <ExtractionSectionOverview
        nodes={model.allNodes}
        activeNodeId={activeNode?.id || activeNodeId}
        onSelectNode={onSelectNode}
      />

      {model.matchFailureCount > 0 && (
        <div className="extraction-match-failure-banner" role="alert">
          <span>{model.matchFailureCount} source blocks could not be highlighted in source preview.</span>
          {matchFailuresOnly ? (
            <button type="button" onClick={onClearMatchFailuresOnly}>Show all</button>
          ) : (
            <button type="button" onClick={onShowMatchFailuresOnly}>Show failures only</button>
          )}
        </div>
      )}

      <ExtractionReviewChecklist model={model} onFocusReviewFlags={onFocusReviewFlags} />
      {activeNode && <ExtractionInspector node={activeNode} onOpenLocator={() => onSelectNode(activeNode)} />}

      {attentionOnly && model.attentionBlockCount === 0 ? (
        <div className="extraction-empty">No extraction attention items.</div>
      ) : query.trim() && onlyDocumentVisible ? (
        <div className="extraction-empty">No extraction rows match the current search.</div>
      ) : (
        <ExtractionTree
          visibleNodes={visibleNodes}
          expandedNodeIds={expandedNodeIds}
          activeNodeId={activeNode?.id || activeNodeId}
          onSelectNode={onSelectNode}
          onPreviewNode={onPreviewNode}
          onClearPreview={onClearPreview}
          onToggleExpanded={onToggleExpanded}
          onNavigate={onNavigate}
          revealNonce={revealNonce}
        />
      )}
    </section>
  );
}

function ExtractionReviewChecklist({ model, onFocusReviewFlags }: { model: ExtractionExplorerModel; onFocusReviewFlags: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const failing = model.checklist.filter((item) => item.status !== "pass");
  const passingCount = model.checklist.length - failing.length;
  const visibleItems = failing.length === 0
    ? []
    : expanded ? model.checklist : failing;
  if (failing.length === 0) {
    return (
      <section className="extraction-checklist" aria-label="Extraction review checklist">
        <span className="extraction-check status-pass">
          <CheckCircle2 size={13} />
          <span>All {model.checklist.length} checks passing</span>
        </span>
      </section>
    );
  }
  return (
    <section className="extraction-checklist" aria-label="Extraction review checklist">
      {visibleItems.map((item) => {
        const actionable = item.id === "review-flags" && item.status !== "pass" && model.firstAttentionNodeId;
        const content = (
          <>
            {item.status === "pass" ? <CheckCircle2 size={13} /> : <AlertTriangle size={13} />}
            <span>{item.label}</span>
          </>
        );
        return actionable ? (
          <button
            key={item.id}
            type="button"
            className={`extraction-check status-${item.status} is-actionable`}
            title={`${item.detail}. Show review flags.`}
            onClick={onFocusReviewFlags}
          >
            {content}
          </button>
        ) : (
          <span key={item.id} className={`extraction-check status-${item.status}`} title={item.detail}>
            {content}
          </span>
        );
      })}
      {passingCount > 0 && (
        <button type="button" className="extraction-check status-pass is-compact" onClick={() => setExpanded((value) => !value)}>
          {expanded ? "Collapse passing checks" : `${passingCount} other checks passing`}
        </button>
      )}
    </section>
  );
}

function ExtractionSectionOverview({
  nodes,
  activeNodeId,
  onSelectNode,
}: {
  nodes: ExtractionNode[];
  activeNodeId: string;
  onSelectNode: (node: ExtractionNode) => void;
}) {
  const nodeById = new Map(nodes.map((node) => [node.id, node]));
  const activeTrail = new Set<string>();
  let activeCursor = nodeById.get(activeNodeId);
  while (activeCursor) {
    activeTrail.add(activeCursor.id);
    activeCursor = activeCursor.parentId ? nodeById.get(activeCursor.parentId) : undefined;
  }
  const headings = nodes.filter((node) => node.kind === "heading" && headingLevel(node) <= 2);
  if (headings.length === 0) return null;
  return (
    <nav className="extraction-section-overview" aria-label="Document sections">
      {headings.map((node) => (
        <button
          key={node.id}
          type="button"
          className={activeTrail.has(node.id) ? "is-active" : ""}
          onClick={() => onSelectNode(node)}
          title={node.label}
        >
          <span>{provenanceLabel(node)}</span>
          {node.label}
        </button>
      ))}
    </nav>
  );
}

export function ExtractionInspector({ node, onOpenLocator }: { node: ExtractionNode; onOpenLocator?: () => void }) {
  const breadcrumb = extractionNodeBreadcrumb(node);
  const isDocument = node.kind === "document";
  const sortedSignals = sortedAttentionSignals(node.attentionSignals);
  return (
    <section className="extraction-inspector" aria-label="Selected extraction block">
      <div className="extraction-inspector-main">
        <div>
          <span className="label-sm">Selected block</span>
          <strong>{isDocument ? "Document container" : <RichText node={node} />}</strong>
        </div>
        <span className={`extraction-location ${node.isLocated ? "is-located" : "is-unlocated"}`}>
          {node.isLocated ? <MapPin size={13} /> : <MapPinOff size={13} />}
          {node.isLocated ? "Located" : "Unlocated"}
        </span>
      </div>
      {breadcrumb && <div className="extraction-breadcrumb">{breadcrumb}</div>}
      <div className="extraction-inspector-grid">
        <dl>
          <dt>Identity</dt>
          <dd>Type: {displayKind(node)}</dd>
          {node.kind === "heading" && <dd>Heading level: {headingLevel(node)}</dd>}
          {node.kind === "heading" && <dd><span className={`provenance-chip provenance-${provenanceTone(node)}`}>{provenanceLabel(node)}</span></dd>}
          {isDocument && <dd>{sourceBlockCountLabel(displaySourceBlockCount(node))}</dd>}
          {!isDocument && node.sourceBlockIds[0] && <dd title={node.sourceBlockIds[0]}>Block ID available on locator hover</dd>}
        </dl>
        <dl>
          <dt>Position</dt>
          {shouldShowMarker(node) && (
            <dd>Marker: {displayMarker(node) || <span className="muted-value">No marker found</span>}</dd>
          )}
          {isListLike(node) && listLevel(node) !== null && <dd>List level: {Number(listLevel(node)) + 1}</dd>}
          {shouldShowNumberingFormat(node) && <dd>Numbering: {numberingFormat(node)}</dd>}
          {!isDocument && node.locator && (
            <dd>
              Locator:{" "}
              <button type="button" className="locator-chip" onClick={onOpenLocator} title={node.sourceBlockIds[0]}>
                <code>{node.locator}</code>
                <ExternalLink size={12} aria-hidden />
              </button>
            </dd>
          )}
          {isDocument && typeof node.metadata.located_count === "number" && (
            <dd>Children: {node.metadata.located_count} of {displaySourceBlockCount(node)} located</dd>
          )}
          {node.kind === "table_row" && node.metadata.table_label && <dd>Table: {node.metadata.table_label}</dd>}
          {node.kind === "table_row" && node.metadata.row_index && node.metadata.table_row_count && (
            <dd>Row {node.metadata.row_index} of {node.metadata.table_row_count}</dd>
          )}
        </dl>
        <dl>
          <dt>Trust</dt>
          <dd>
            {node.block ? (
              <ConfidenceBreakdown node={node} />
            ) : node.confidence !== null ? (
              <span>Lowest descendant confidence: {Math.round(node.confidence * 100)}%</span>
            ) : (
              <span>No confidence score</span>
            )}
          </dd>
        </dl>
      </div>
      {isNestedListNode(node) && <p className="extraction-inspector-note">Nested under previous list item.</p>}
      {isDocument && <p className="extraction-inspector-note">Document container selected. Open a heading or row to inspect source locators and review signals.</p>}
      {node.cells?.length ? (
        <InspectorCellGrid node={node} />
      ) : null}
      {node.attentionSignals.length > 0 && (
        <div className="extraction-why-flagged">
          <span className="label-sm">Review signals</span>
          <ul className="extraction-signal-list">
            {sortedSignals.map((signal, index) => (
              <li key={`${node.id}-${signal.code}-${index}`} className={`severity-${signal.severity}`}>
                <AlertTriangle size={13} />
                <span>
                  <strong>{signal.label || signal.code} <small>{signal.severity}</small></strong>
                  {signal.explanation && <span>{signal.explanation}</span>}
                  {signal.message && signal.message !== signal.explanation && <span>Evidence: {signal.message}</span>}
                  {signal.action && <em>Action: {signal.action}</em>}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {node.block?.confidence_signals && (
        <details className="confidence-signal-details">
          <summary>Why we think this is a {displayKind(node).toLowerCase()}</summary>
          <dl>
            {Object.entries(node.block.confidence_signals).map(([key, value]) => (
              <div key={key}>
                <dt>{key.replace(/_/g, " ")}</dt>
                <dd>{String(value)}</dd>
              </div>
            ))}
          </dl>
        </details>
      )}
    </section>
  );
}

function ExtractionTree({
  visibleNodes,
  expandedNodeIds,
  activeNodeId,
  onSelectNode,
  onPreviewNode,
  onClearPreview,
  onToggleExpanded,
  onNavigate,
  revealNonce,
}: {
  visibleNodes: ExtractionNode[];
  expandedNodeIds: Set<string>;
  activeNodeId: string;
  onSelectNode: (node: ExtractionNode) => void;
  onPreviewNode: (node: ExtractionNode) => void;
  onClearPreview: () => void;
  onToggleExpanded: (nodeId: string) => void;
  onNavigate: (key: ExtractionNavigationKey) => void;
  revealNonce: number;
}) {
  const rowRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const focusAfterKeyboard = useRef(false);

  useEffect(() => {
    const row = rowRefs.current.get(activeNodeId);
    if (!row) return;
    row.scrollIntoView({ block: "nearest" });
    if (focusAfterKeyboard.current) {
      row.focus();
      focusAfterKeyboard.current = false;
    }
  }, [revealNonce]);

  if (visibleNodes.length === 0) {
    return <div className="extraction-empty">No extraction rows match the current filter.</div>;
  }

  return (
    <div className="extraction-tree" role="tree" aria-label="Extracted source blocks" onMouseLeave={onClearPreview}>
      {visibleNodes.map((node) => {
        const expanded = expandedNodeIds.has(node.id);
        const hasChildren = node.children.length > 0;
        const active = node.id === activeNodeId;
        const nestedList = isNestedListNode(node);
        const severityCounts = attentionSeverityCounts(node.attentionSignals);
        return (
          <div
            key={node.id}
            ref={(element) => {
              if (element) rowRefs.current.set(node.id, element);
              else rowRefs.current.delete(node.id);
            }}
            role="treeitem"
            aria-level={node.depth}
            aria-selected={active}
            aria-expanded={hasChildren ? expanded : undefined}
            tabIndex={active ? 0 : -1}
            data-extraction-node-id={node.id}
            data-extraction-kind={node.kind}
            data-source-block-id={rowSourceBlockId(node)}
            className={`extraction-row kind-${node.kind}${active ? " active" : ""}${!node.isLocated ? " unlocated" : ""}${node.attentionSignals.length ? " has-attention" : ""}${nestedList ? " is-nested-list" : ""}`}
            style={{
              "--extraction-depth": String(Math.max(0, node.depth - 1)),
              "--list-depth": String(listLevel(node) || 0),
              "--cell-count": String(Math.min(Math.max(node.cells?.length || 1, 1), 4)),
            } as CSSProperties}
            onClick={() => onSelectNode(node)}
            onMouseEnter={() => onPreviewNode(node)}
            onKeyDown={(event) => {
              const key = navigationKey(event);
              if (key) {
                event.preventDefault();
                focusAfterKeyboard.current = true;
                onNavigate(key);
                return;
              }
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onSelectNode(node);
              }
            }}
          >
            <button
              type="button"
              className="extraction-row-toggle"
              disabled={!hasChildren}
              aria-label={expanded ? `Collapse ${node.label}` : `Expand ${node.label}`}
              onClick={(event) => {
                event.stopPropagation();
                if (hasChildren) onToggleExpanded(node.id);
              }}
            >
              {hasChildren ? expanded ? <ChevronDown size={15} /> : <ChevronRight size={15} /> : <span aria-hidden />}
            </button>
            <span className="extraction-kind-icon" aria-hidden>{iconForNode(node)}</span>
            <span className="extraction-row-copy">
              <span className="extraction-row-title-line">
                {showNumberingMarker(node) && <span className="extraction-list-marker">{displayMarker(node)}</span>}
                {node.kind === "heading" && <span className={`provenance-chip provenance-${provenanceTone(node)}`}>{provenanceLabel(node)}</span>}
                <span className="extraction-row-title"><RichText node={node} /></span>
              </span>
              {node.kind === "table_row" && node.cells?.length ? (
                <TableCellPreview node={node} />
              ) : (
                <span className="extraction-row-meta">{rowMeta(node)}</span>
              )}
            </span>
            <span className="extraction-row-badges">
              {node.kind === "table" && <span>{node.metadata.row_count || node.metadata.rows || 0} rows · {node.metadata.column_count || node.metadata.columns || 0} cols</span>}
              {node.kind === "table_row" && node.metadata.row_kind === "header" && <span>header row</span>}
              <AttentionSeverityChips counts={severityCounts} />
              {!node.isLocated && <span className="unlocated"><MapPinOff size={12} /> Unlocated</span>}
              {showConfidence(node) && node.confidence !== null && <span>{Math.round(node.confidence * 100)}%</span>}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function navigationKey(event: KeyboardEvent<HTMLElement>): ExtractionNavigationKey | null {
  if (event.key === "ArrowUp") return "up";
  if (event.key === "ArrowDown") return "down";
  if (event.key === "ArrowRight") return "right";
  if (event.key === "ArrowLeft") return "left";
  return null;
}

function iconForNode(node: ExtractionNode) {
  if (node.kind === "table") return <Table2 size={14} />;
  if (node.kind === "table_row") return <TableRowsSplit size={13} />;
  if (node.kind === "resource") return <Link2 size={13} />;
  return "";
}

function rowMeta(node: ExtractionNode) {
  if (node.kind === "document") return sourceBlockCountLabel(displaySourceBlockCount(node));
  if (node.kind === "table") {
    const rows = Number(node.metadata.row_count || node.metadata.rows || 0);
    const columns = Number(node.metadata.column_count || node.metadata.columns || 0);
    return `${rows} ${rows === 1 ? "row" : "rows"} · ${columns} ${columns === 1 ? "column" : "columns"}`;
  }
  const parts = [displayKind(node)];
  if (node.kind === "heading" && node.metadata.inferred_level) parts.push(`level ${node.metadata.inferred_level}`);
  const numberingLevel = listLevel(node);
  if (numberingLevel !== null && numberingLevel > 0 && node.kind !== "resource") parts.push(`nested level ${numberingLevel + 1}`);
  return parts.join(" · ");
}

function displaySourceBlockCount(node: ExtractionNode) {
  const blockCount = node.metadata.block_count;
  if (typeof blockCount === "number") return blockCount;
  return node.sourceBlockIds.length;
}

function displayKind(node: ExtractionNode) {
  if (node.kind === "procedure_step") return "Step";
  if (node.kind === "list_item") return "List item";
  if (node.kind === "table_row") return "Table row";
  if (node.kind === "resource") return "Resource";
  return titleCase(node.blockType || node.kind);
}

function showConfidence(node: ExtractionNode) {
  if (node.confidence === null) return false;
  return node.attentionSignals.length > 0 || node.confidence < 0.86;
}

function numberingLabel(node: ExtractionNode) {
  const label = node.metadata.list_marker || node.metadata.numbering_label;
  return typeof label === "string" && label ? label : "";
}

function displayMarker(node: ExtractionNode) {
  const marker = numberingLabel(node);
  return marker === "•" ? marker : stripTerminalMarker(marker);
}

function showNumberingMarker(node: ExtractionNode) {
  return Boolean(numberingLabel(node)) && (node.kind === "procedure_step" || node.kind === "list_item" || node.kind === "resource");
}

function rowSourceBlockId(node: ExtractionNode) {
  return node.block ? node.sourceBlockIds[0] || undefined : undefined;
}

function listLevel(node: ExtractionNode) {
  const level = typeof node.metadata.list_depth === "number" ? node.metadata.list_depth : node.metadata.numbering_level;
  return typeof level === "number" ? level : null;
}

function numberingFormat(node: ExtractionNode) {
  const format = node.metadata.numbering_format;
  return typeof format === "string" && format ? format : "";
}

function isNestedListNode(node: ExtractionNode) {
  const level = listLevel(node);
  return (node.kind === "procedure_step" || node.kind === "list_item" || node.kind === "resource") && typeof level === "number" && level > 0;
}

function RichText({ node }: { node: ExtractionNode }) {
  const runs = node.block?.inline_runs || [];
  if (!runs.length) return <>{node.label}</>;
  return (
    <>
      {runs.map((run, index) => (
        <RichTextRun key={`${index}-${run.text}`} text={run.text} marks={run.marks || []} semanticHint={run.semantic_hint || null} />
      ))}
    </>
  );
}

function RichTextRun({ text, marks, semanticHint }: { text: string; marks: string[]; semanticHint: string | null }) {
  let content: ReactNode = text;
  if (marks.includes("code") || marks.includes("monospace")) content = <code>{content}</code>;
  if (marks.includes("italic")) content = <em>{content}</em>;
  if (marks.includes("bold")) content = <strong>{content}</strong>;
  return (
    <span className={semanticHint ? "rich-run has-semantic-hint" : "rich-run"} title={semanticHint || undefined}>
      {content}
      {semanticHint && <small aria-hidden>{semanticHint}</small>}
    </span>
  );
}

function TableCellPreview({ node }: { node: ExtractionNode }) {
  const cells = node.cells || [];
  return (
    <span
      className={`extraction-row-cells${node.metadata.row_kind === "header" ? " is-header-row" : ""}`}
      style={{ "--cell-count": String(Math.min(Math.max(cells.length, 1), 6)) } as CSSProperties}
    >
      {cells.map((cell, index) => (
        <span
          key={`${node.id}-cell-${index}`}
          style={{ gridColumn: cell.colspan && cell.colspan > 1 ? `span ${cell.colspan}` : undefined }}
          title={cell.colspan && cell.colspan > 1 ? `Spans ${cell.colspan} columns` : undefined}
        >
          {cell.text.trim() || "-"}
        </span>
      ))}
    </span>
  );
}

function InspectorCellGrid({ node }: { node: ExtractionNode }) {
  const cells = node.cells || [];
  const columns = Number(node.metadata.table_column_count || cells.length || 0);
  return (
    <table className="inspector-cell-grid" aria-label="Selected table row cells">
      <thead>
        <tr>
          {Array.from({ length: columns }, (_value, index) => <th key={index}>Col {index + 1}</th>)}
        </tr>
      </thead>
      <tbody>
        <tr>
          {cells.map((cell, index) => (
            <td key={`${node.id}-inspector-cell-${index}`} colSpan={cell.colspan || 1} rowSpan={cell.rowspan || 1}>
              {cell.text.trim() || "-"}
            </td>
          ))}
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td colSpan={Math.max(columns, 1)}>
            Row {node.metadata.row_index || "?"} of {node.metadata.table_row_count || "?"} · {columns} cols
          </td>
        </tr>
      </tfoot>
    </table>
  );
}

function ConfidenceBreakdown({ node }: { node: ExtractionNode }) {
  const confidence = node.block?.confidence || {};
  const axes = [
    { key: "extraction", label: "Extraction", value: confidence.extraction },
    { key: "block_type", label: "Type", value: confidence.block_type },
    { key: "heading", label: "Heading", value: confidence.heading },
  ];
  return (
    <div className="confidence-axis-list">
      {axes.map((axis) => {
        const value = typeof axis.value === "number" ? axis.value : null;
        const below = value !== null && value < LOW_CONFIDENCE_THRESHOLD;
        return (
          <span key={axis.key} className={value === null ? "is-na" : below ? "is-below" : "is-ok"}>
            <b>{axis.label}</b>
            <i aria-hidden style={{ "--confidence-value": String(Math.round((value ?? 0) * 100)) } as CSSProperties} />
            {value === null ? "n/a" : `${Math.round(value * 100)}%`}
            {below && <em>below {LOW_CONFIDENCE_THRESHOLD}</em>}
          </span>
        );
      })}
    </div>
  );
}

function AttentionSeverityChips({ counts }: { counts: ReturnType<typeof attentionSeverityCounts> }) {
  if (counts.error + counts.warning + counts.info === 0) return null;
  return (
    <>
      {counts.error > 0 && <span className="attention severity-error">!{counts.error}</span>}
      {counts.warning > 0 && <span className="attention severity-warning">W{counts.warning}</span>}
      {counts.info > 0 && <span className="attention severity-info">i{counts.info}</span>}
    </>
  );
}

function attentionSeverityCounts(signals: ExtractionAttentionSignal[]) {
  return signals.reduce(
    (counts, signal) => {
      counts[signal.severity] += 1;
      return counts;
    },
    { error: 0, warning: 0, info: 0 },
  );
}

function sortedAttentionSignals(signals: ExtractionAttentionSignal[]) {
  return [...signals].sort((a, b) => severityRank(b.severity) - severityRank(a.severity));
}

function severityRank(value: ExtractionAttentionSignal["severity"]) {
  if (value === "error") return 3;
  if (value === "warning") return 2;
  return 1;
}

function isListLike(node: ExtractionNode) {
  return node.kind === "procedure_step" || node.kind === "list_item" || node.kind === "resource";
}

function shouldShowMarker(node: ExtractionNode) {
  return isListLike(node);
}

function shouldShowNumberingFormat(node: ExtractionNode) {
  const format = numberingFormat(node);
  if (!format) return false;
  return !displayMarker(node) || format !== "decimal";
}

function headingLevel(node: ExtractionNode) {
  const level = node.metadata.inferred_level;
  return typeof level === "number" ? level : 1;
}

function provenanceLabel(node: ExtractionNode) {
  const level = headingLevel(node);
  const source = node.metadata.style_source;
  if (source === "formatting") return `H${level} Inferred`;
  if (source === "numbering") return `H${level} Num`;
  return `H${level} Style`;
}

function provenanceTone(node: ExtractionNode) {
  const source = node.metadata.style_source;
  if (source === "formatting") return "inferred";
  if (source === "numbering") return "numbering";
  return "style";
}

function titleCase(value: string) {
  return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}
