// @vitest-environment jsdom

import "@testing-library/jest-dom/vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { ExtractionInspector } from "./ExtractionExplorerPane";
import { ExtractionNode } from "./extractionExplorerModel";
import { REVIEW_FLAG_LABELS } from "./reviewFlagLabels";

describe("ExtractionInspector", () => {
  afterEach(() => cleanup());

  it("renders heading rows with locator and level context", () => {
    render(
      <ExtractionInspector
        node={node({
          kind: "heading",
          label: "Customer Change Requests",
          blockType: "heading",
          metadata: { inferred_level: 2 },
        })}
      />,
    );

    expect(screen.getByText("Customer Change Requests")).toBeInTheDocument();
    expect(screen.getByText("Block ID available on locator hover")).toBeInTheDocument();
    expect(screen.getAllByTitle("b1")).toHaveLength(2);
    expect(screen.getByText(/Locator:/)).toBeInTheDocument();
    expect(screen.getByText("docx:p:1")).toBeInTheDocument();
  });

  it("renders document roots as containers without locators", () => {
    render(
      <ExtractionInspector
        node={node({
          kind: "document",
          label: "Customer Change Requests.docx",
          sourceBlockIds: ["heading-only"],
          locator: null,
          metadata: { block_count: 72, located_count: 72 },
        })}
      />,
    );

    expect(screen.getByText("Document container")).toBeInTheDocument();
    expect(screen.getByText("72 source blocks")).toBeInTheDocument();
    expect(screen.getByText("Children: 72 of 72 located")).toBeInTheDocument();
    expect(screen.getByText("Document container selected. Open a heading or row to inspect source locators and review signals.")).toBeInTheDocument();
    expect(screen.queryByText(/Locator:/)).not.toBeInTheDocument();
  });

  it("renders table-row context from parent table metadata", () => {
    render(
      <ExtractionInspector
        node={node({
          kind: "table_row",
          label: "Row 2",
          metadata: {
            table_label: "Table 001",
            row_index: 2,
            table_row_count: 5,
            table_column_count: 3,
          },
          cells: [{ text: "Client" }, { text: "Apple CA" }, { text: "Active" }],
        })}
      />,
    );

    expect(screen.getByText("Table: Table 001")).toBeInTheDocument();
    expect(screen.getAllByText("Row 2 of 5")[0]).toBeInTheDocument();
    expect(screen.getByText("Col 1")).toBeInTheDocument();
    expect(screen.getByText("Col 2")).toBeInTheDocument();
  });

  it("renders nested list context from numbering metadata", () => {
    render(
      <ExtractionInspector
        node={node({
          kind: "procedure_step",
          label: "Nested step",
          metadata: {
            list_depth: 1,
            numbering_label: "a.",
            numbering_format: "lowerLetter",
          },
        })}
      />,
    );

    expect(screen.getByText("Marker: a")).toBeInTheDocument();
    expect(screen.getByText("List level: 2")).toBeInTheDocument();
    expect(screen.getByText("Numbering: lowerLetter")).toBeInTheDocument();
    expect(screen.getByText("Nested under previous list item.")).toBeInTheDocument();
  });

  it("shows reviewer action text for flagged rows", () => {
    const flag = REVIEW_FLAG_LABELS.ASSET_REF_UNRESOLVED;
    render(
      <ExtractionInspector
        node={node({
          attentionSignals: [{
            code: "ASSET_REF_UNRESOLVED",
            severity: flag.severity,
            label: flag.label,
            message: flag.explanation,
            explanation: flag.explanation,
            action: flag.action,
          }],
        })}
      />,
    );

    expect(screen.getByText("Review signals")).toBeInTheDocument();
    expect(screen.getByText(flag.label)).toBeInTheDocument();
    expect(screen.getByText(`Action: ${flag.action}`)).toBeInTheDocument();
  });
});

function node(overrides: Partial<ExtractionNode> = {}): ExtractionNode {
  return {
    id: "node-1",
    kind: "paragraph",
    label: "Selected block",
    sourceBlockIds: ["b1"],
    locator: "docx:p:1",
    blockType: "paragraph",
    headingPath: ["Section"],
    depth: 2,
    children: [],
    attentionSignals: [],
    confidence: 0.92,
    isLocated: true,
    isActive: true,
    metadata: {},
    ...overrides,
  };
}
