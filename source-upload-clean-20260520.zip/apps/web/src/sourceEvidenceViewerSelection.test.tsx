// @vitest-environment jsdom

import "@testing-library/jest-dom/vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { ComponentProps } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { DocumentRecord, SourceBlock } from "./api";
import { SourceEvidenceViewer } from "./SourceEvidenceViewer";

describe("SourceEvidenceViewer selection classes", () => {
  beforeEach(() => {
    Object.defineProperty(HTMLElement.prototype, "scrollIntoView", {
      configurable: true,
      value: vi.fn(),
    });
    vi.stubGlobal("fetch", vi.fn(async () => ({
      ok: true,
      text: async () => "Selected line\nPreview line",
    })));
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("keeps selected source ids selected when hover preview moves elsewhere", async () => {
    const props = defaultProps({
      selectedSourceIds: ["blk_selected"],
      previewSourceIds: ["blk_preview"],
    });
    const { rerender } = render(<SourceEvidenceViewer {...props} />);

    await screen.findByText(/Selected line/);
    await screen.findByText(/Preview line/);
    const selectedAnchor = await waitFor(() => {
      const element = document.querySelector<HTMLElement>('[data-source-block-id="blk_selected"]');
      expect(element).not.toBeNull();
      return element!;
    });
    const previewAnchor = await waitFor(() => {
      const element = document.querySelector<HTMLElement>('[data-source-block-id="blk_preview"]');
      expect(element).not.toBeNull();
      return element!;
    });
    await waitFor(() => expect(selectedAnchor).toHaveClass("source-viewer-selected"));
    expect(selectedAnchor).not.toHaveClass("source-viewer-preview");
    expect(previewAnchor).toHaveClass("source-viewer-preview");

    rerender(
      <SourceEvidenceViewer
        {...props}
        selectedSourceIds={["blk_selected"]}
        previewSourceIds={["blk_selected", "blk_preview"]}
      />,
    );

    await waitFor(() => expect(selectedAnchor).toHaveClass("source-viewer-selected"));
    expect(selectedAnchor).not.toHaveClass("source-viewer-preview");
    expect(previewAnchor).toHaveClass("source-viewer-preview");
  });
});

function defaultProps(overrides: Partial<ComponentProps<typeof SourceEvidenceViewer>> = {}) {
  const blocks = [
    block("blk_selected", "Selected line"),
    block("blk_preview", "Preview line"),
  ];
  return {
    document: documentRecord(),
    blocks,
    query: "",
    attentionOnly: false,
    attentionSourceIds: new Set<string>(),
    syncScrolling: true,
    activeSourceIds: [],
    selectedSourceIds: [],
    previewSourceIds: [],
    spotlightSourceIds: [],
    evidenceNumbers: [],
    onQueryChange: vi.fn(),
    onAttentionOnlyChange: vi.fn(),
    onSyncScrollingChange: vi.fn(),
    onHoverBlock: vi.fn(),
    onClearHover: vi.fn(),
    onSelectBlock: vi.fn(),
    onMatchFailuresChange: vi.fn(),
    setBlockRef: vi.fn(),
    ...overrides,
  };
}

function documentRecord(): DocumentRecord {
  return {
    document_id: "doc_1",
    filename: "source.txt",
    content_type: "text/plain",
    status: "ready_for_review",
    topic_ids: [],
    job_ids: [],
    source_hash: "hash",
    source_quality: {
      overall_confidence: 0.9,
      review_required: false,
      validation_issue_count: 0,
      quality_gate: { name: "docx_source_fidelity_v1", passed: true, severity: "info", blocking_reasons: [] },
    },
  };
}

function block(block_id: string, text: string): SourceBlock {
  return {
    block_id,
    block_type: "paragraph",
    text,
    source_location: { page: null, section: null, bbox: null },
    heading_path_ids: [],
    confidence: { extraction: 0.9, block_type: 0.9, heading: 0.9, semantic_inline: 0.9 },
    review_flags: [],
  };
}
