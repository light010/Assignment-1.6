import { describe, expect, it } from "vitest";
import { plural, qualityGateDisplayName, stripTerminalMarker, thresholdQualityLabel } from "./formatters";

describe("formatters", () => {
  it("formats review-facing count labels", () => {
    expect(plural(1, "source block")).toBe("1 source block");
    expect(plural(2, "source block")).toBe("2 source blocks");
  });

  it("uses review-facing gate labels and threshold-relative quality", () => {
    expect(qualityGateDisplayName("docx_source_fidelity_v1")).toBe("Source-fidelity quality gate");
    expect(thresholdQualityLabel(0.83, 0.72)).toBe("Above gate (+11 pts)");
    expect(thresholdQualityLabel(0.6, 0.72)).toBe("Below gate (-12 pts)");
  });

  it("normalizes list markers for chip display", () => {
    expect(stripTerminalMarker("17.")).toBe("17");
    expect(stripTerminalMarker("a)")).toBe("a");
  });
});
