import { EvidenceNumber } from "./workbenchSelectors";

export type GeometryRect = {
  top: number;
  left: number;
  right: number;
  bottom?: number;
  width?: number;
  height: number;
};

export type GeometryPoint = {
  x: number;
  y: number;
};

export type NumberedAnchor = {
  id: string;
  evidenceNumber: number;
  point: GeometryPoint;
  side: "source" | "extract";
  sourceBlockId: string;
  unitId?: string;
};

export type SpotlightRect = {
  id: string;
  sourceBlockId: string;
  x: number;
  y: number;
  width: number;
  height: number;
};

export type EvidenceScrollTarget =
  | { kind: "none" }
  | { kind: "element"; blockId: string }
  | { kind: "pdf_page"; blockId: string; page: number };

export type EvidenceViewerFormat = "docx" | "pdf" | "text" | "html" | "unsupported";

export function buildNumberedAnchors({
  sourceRects,
  unitRects,
  unitSourceIds,
  evidenceNumbers,
  overlayRect,
}: {
  sourceRects: Map<string, GeometryRect>;
  unitRects: Map<string, GeometryRect>;
  unitSourceIds: Map<string, string[]>;
  evidenceNumbers: EvidenceNumber[];
  overlayRect: GeometryRect;
}): NumberedAnchor[] {
  const evidenceByBlock = new Map(evidenceNumbers.map((item) => [item.source_block_id, item.evidence_number] as const));
  const anchors: NumberedAnchor[] = [];

  evidenceNumbers.forEach(({ source_block_id: blockId, evidence_number: evidenceNumber }) => {
    const rect = sourceRects.get(blockId);
    if (!rect) return;
    anchors.push({
      id: `source:${blockId}`,
      evidenceNumber,
      point: leadingEdgePoint(rect, overlayRect, "source"),
      side: "source",
      sourceBlockId: blockId,
    });
  });

  unitSourceIds.forEach((sourceIds, unitId) => {
    const rect = unitRects.get(unitId);
    if (!rect) return;
    const emitted = new Set<number>();
    sourceIds.forEach((blockId) => {
      const evidenceNumber = evidenceByBlock.get(blockId);
      if (!evidenceNumber || emitted.has(evidenceNumber)) return;
      emitted.add(evidenceNumber);
      anchors.push({
        id: `extract:${unitId}:${blockId}`,
        evidenceNumber,
        point: leadingEdgePoint(rect, overlayRect, "extract"),
        side: "extract",
        sourceBlockId: blockId,
        unitId,
      });
    });
  });

  return anchors.sort((left, right) => left.evidenceNumber - right.evidenceNumber || left.id.localeCompare(right.id));
}

export function buildSpotlightRects({
  sourceRects,
  sourceBlockIds,
  overlayRect,
}: {
  sourceRects: Map<string, GeometryRect>;
  sourceBlockIds: string[];
  overlayRect: GeometryRect;
}): SpotlightRect[] | null {
  const seen = new Set<string>();
  const rects = sourceBlockIds.flatMap((blockId) => {
    if (seen.has(blockId)) return [];
    seen.add(blockId);
    const rect = sourceRects.get(blockId);
    if (!rect) return [];
    return [{
      id: `spotlight:${blockId}`,
      sourceBlockId: blockId,
      x: rect.left - overlayRect.left,
      y: rect.top - overlayRect.top,
      width: rectWidth(rect),
      height: rect.height,
    }];
  });
  if (!rects.length) return null;
  return rects.sort((left, right) => left.y - right.y || left.x - right.x);
}

export function pickEvidenceScrollTarget({
  format,
  sourceBlockIds,
  locatedBlockIds,
  blockPages,
}: {
  format: EvidenceViewerFormat;
  sourceBlockIds: string[];
  locatedBlockIds: Set<string>;
  blockPages?: Map<string, number>;
}): EvidenceScrollTarget {
  const blockId = sourceBlockIds.find((id) => locatedBlockIds.has(id));
  if (!blockId) return { kind: "none" };
  if (format === "pdf") {
    const page = blockPages?.get(blockId);
    if (!page) return { kind: "none" };
    return { kind: "pdf_page", blockId, page };
  }
  return { kind: "element", blockId };
}

export function leadingEdgePoint(
  rect: GeometryRect,
  overlayRect: GeometryRect,
  side: "source" | "extract",
): GeometryPoint {
  const x = side === "source" ? rect.right : rect.left;
  return {
    x: x - overlayRect.left,
    y: rect.top + rect.height / 2 - overlayRect.top,
  };
}

export function unitSourceIdMap(units: { unit_id: string; source_block_ids: string[] }[]) {
  return new Map(units.map((unit) => [unit.unit_id, unit.source_block_ids] as const));
}

function rectWidth(rect: GeometryRect) {
  if (typeof rect.width === "number") return rect.width;
  return Math.max(0, rect.right - rect.left);
}
