import { describe, expect, it } from "vitest";
import {
  attentionCounts,
  commitTopicTitleDraft,
  defaultActiveTopicId,
  documentLevelIssues,
  evidenceNumbering,
  filterAndSortTopics,
  isTopicReviewCurrent,
  nextActionForTopic,
  nextAttentionTopicId,
  topicAttentionSummaries,
  topicAttentionSummary,
  topicContentHash,
  topicProgress,
  unitAttentionSummary,
} from "./workbenchSelectors";
import { WorkbenchIssue, WorkbenchState, WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";

describe("workbenchSelectors", () => {
  it("summarizes topic severity from errors, warnings, stale validation, and review signals", () => {
    const topic = makeTopic("topic_a", { review_required: true, boundary_confidence: 0.68 });
    const summary = topicAttentionSummary(topic, [
      issue("empty_topic", "error", "topic_a"),
      issue("validation_stale", "warning", "topic_a"),
    ]);

    expect(summary.severity).toBe("error");
    expect(summary.errorCount).toBe(1);
    expect(summary.staleCount).toBe(1);
    expect(summary.reviewCount).toBe(2);
    expect(summary.hasAttention).toBe(true);
  });

  it("filters and sorts topics by inline attention state", () => {
    const clean = makeTopic("clean");
    const stale = makeTopic("stale", { validation_stale: true });
    const review = makeTopic("review", { type_confidence: 0.6 });
    const error = makeTopic("error");
    const topics = [clean, stale, review, error];
    const summaries = topicAttentionSummaries(topics, [
      issue("validation_stale", "warning", "stale"),
      issue("empty_topic", "error", "error"),
    ]);

    expect(filterAndSortTopics(topics, summaries, "all").map((topic) => topic.topic_id)).toEqual([
      "clean",
      "stale",
      "review",
      "error",
    ]);
    expect(filterAndSortTopics(topics, summaries, "attention").map((topic) => topic.topic_id)).toEqual([
      "error",
      "stale",
      "review",
    ]);
    expect(filterAndSortTopics(topics, summaries, "errors").map((topic) => topic.topic_id)).toEqual(["error"]);
    expect(filterAndSortTopics(topics, summaries, "stale").map((topic) => topic.topic_id)).toEqual(["stale"]);
    expect(filterAndSortTopics(topics, summaries, "review").map((topic) => topic.topic_id)).toEqual(["review"]);
  });

  it("maps issues to topic and document scopes", () => {
    const topic = makeTopic("topic_a");
    const summaries = topicAttentionSummaries([topic], [
      issue("task_without_steps", "warning", "topic_a"),
      { code: "unassigned_source_blocks", severity: "warning", message: "Unassigned", source_block_ids: ["orphan"] },
    ]);

    expect(summaries.get("topic_a")?.warningCount).toBe(1);
    expect(documentLevelIssues([
      issue("task_without_steps", "warning", "topic_a"),
      { code: "unassigned_source_blocks", severity: "warning", message: "Unassigned", source_block_ids: ["orphan"] },
    ])).toHaveLength(1);
  });

  it("maps source-scoped issues to units", () => {
    const unit = makeUnit("unit_a", ["block_a"], 0.91);
    const summary = unitAttentionSummary(unit, [
      {
        code: "concept_contains_step_sequence",
        severity: "warning",
        message: "Concept contains steps.",
        topic_id: "topic_a",
        source_block_ids: ["block_a", "block_b"],
      },
    ]);

    expect(summary.severity).toBe("warning");
    expect(summary.issues).toHaveLength(1);
  });

  it("marks low-confidence units for review without inventing issues", () => {
    const summary = unitAttentionSummary(makeUnit("unit_a", ["block_a"], 0.54), []);

    expect(summary.severity).toBe("review");
    expect(summary.reviewMessages[0]).toContain("Low extraction confidence");
  });

  it("counts topic-level attention once per bucket", () => {
    const topics = [
      makeTopic("error"),
      makeTopic("stale", { validation_stale: true }),
      makeTopic("review", { review_required: true }),
    ];
    const summaries = topicAttentionSummaries(topics, [
      issue("empty_topic", "error", "error"),
      issue("validation_stale", "warning", "stale"),
    ]);

    expect(attentionCounts(topics, summaries)).toEqual({ attention: 3, errors: 1, stale: 1, review: 1 });
  });

  it("commits one normalized title on explicit rename commit", () => {
    expect(commitTopicTitleDraft("Old title", "  New title  ")).toBe("New title");
    expect(commitTopicTitleDraft("Old title", "Old title")).toBeNull();
    expect(commitTopicTitleDraft("Old title", "   ")).toBeNull();
  });

  it("defaults to the highest-priority attention topic, then the first topic", () => {
    const topics = [
      makeTopic("clean"),
      makeTopic("review", { review_required: true }),
      makeTopic("stale", { validation_stale: true }),
      makeTopic("warning", { topic_type: "task" }),
      makeTopic("error", { units: [] }),
    ];
    const summaries = topicAttentionSummaries(topics, [
      issue("validation_stale", "warning", "stale"),
      issue("task_without_steps", "warning", "warning"),
      issue("empty_topic", "error", "error"),
    ]);

    expect(defaultActiveTopicId(makeState(topics), summaries)).toBe("error");

    const cleanTopics = [makeTopic("first"), makeTopic("second")];
    expect(defaultActiveTopicId(makeState(cleanTopics), topicAttentionSummaries(cleanTopics, []))).toBe("first");
  });

  it("numbers evidence by source-block document order instead of unit order", () => {
    const topic = makeTopic("topic_a", {
      source_block_ids: ["block_a", "block_b", "block_c"],
      units: [
        makeUnit("unit_b", ["block_b"], 0.9),
        makeUnit("unit_a", ["block_a"], 0.9),
        makeUnit("unit_c", ["block_c"], 0.9),
      ],
    });

    expect(evidenceNumbering(makeState([topic]), "topic_a")).toEqual([
      { source_block_id: "block_a", evidence_number: 1 },
      { source_block_id: "block_b", evidence_number: 2 },
      { source_block_id: "block_c", evidence_number: 3 },
    ]);

    const reorderedTopic = { ...topic, units: [...topic.units].reverse() };
    expect(evidenceNumbering(makeState([reorderedTopic]), "topic_a")).toEqual([
      { source_block_id: "block_a", evidence_number: 1 },
      { source_block_id: "block_b", evidence_number: 2 },
      { source_block_id: "block_c", evidence_number: 3 },
    ]);
  });

  it("invalidates reviewed state when topic content changes", () => {
    const topic = makeTopic("topic_a");
    const reviewed = { reviewed_at: "2026-05-09T00:00:00.000Z", hash: topicContentHash(topic) };

    expect(isTopicReviewCurrent(topic, reviewed)).toBe(true);
    expect(topicProgress([topic], { topic_a: reviewed })).toEqual({ reviewed: 1, remaining: 0, total: 1 });

    const edited = { ...topic, title: "Edited topic" };
    expect(isTopicReviewCurrent(edited, reviewed)).toBe(false);
    expect(topicProgress([edited], { topic_a: reviewed })).toEqual({ reviewed: 0, remaining: 1, total: 1 });
  });

  it("returns the next guided action from severity and reviewed state", () => {
    const clean = makeTopic("clean");
    const reviewed = { reviewed_at: "2026-05-09T00:00:00.000Z", hash: topicContentHash(clean) };

    expect(nextActionForTopic(
      makeTopic("error"),
      topicAttentionSummary(makeTopic("error"), [issue("empty_topic", "error", "error")]),
    ).kind).toBe("review_validation");
    expect(nextActionForTopic(
      makeTopic("stale", { validation_stale: true }),
      topicAttentionSummary(makeTopic("stale", { validation_stale: true }), []),
    ).kind).toBe("resolve_stale");
    expect(nextActionForTopic(
      makeTopic("review", { review_required: true }),
      topicAttentionSummary(makeTopic("review", { review_required: true }), []),
    ).kind).toBe("review_attention");
    expect(nextActionForTopic(clean, topicAttentionSummary(clean, []), undefined).kind).toBe("mark_reviewed");
    expect(nextActionForTopic(clean, topicAttentionSummary(clean, []), reviewed).kind).toBe("advance_topic");
  });

  it("wraps next attention topic and returns null when no attention topics exist", () => {
    const topics = [
      makeTopic("clean"),
      makeTopic("stale", { validation_stale: true }),
      makeTopic("review", { review_required: true }),
    ];
    const summaries = topicAttentionSummaries(topics, [issue("validation_stale", "warning", "stale")]);

    expect(nextAttentionTopicId(topics, summaries, "stale")).toBe("review");
    expect(nextAttentionTopicId(topics, summaries, "review")).toBe("stale");
    expect(nextAttentionTopicId(topics, summaries, "clean")).toBe("stale");

    const cleanTopics = [makeTopic("one"), makeTopic("two")];
    expect(nextAttentionTopicId(cleanTopics, topicAttentionSummaries(cleanTopics, []), "one")).toBeNull();
  });
});

function makeTopic(topic_id: string, overrides: Partial<WorkbenchTopic> = {}): WorkbenchTopic {
  return {
    topic_id,
    title: topic_id,
    topic_type: "concept",
    source_block_ids: ["block_a"],
    boundary_confidence: 0.86,
    type_confidence: 0.87,
    review_required: false,
    review_issues: [],
    validation_issues: [],
    validation_stale: false,
    units: [makeUnit("unit_a", ["block_a"], 0.9)],
    ...overrides,
  };
}

function makeUnit(unit_id: string, source_block_ids: string[], confidence: number): WorkbenchUnit {
  return {
    unit_id,
    topic_id: "topic_a",
    source_block_ids,
    text: "Apple CA evidence",
    block_type: "paragraph",
    confidence,
  };
}

function issue(code: string, severity: WorkbenchIssue["severity"], topic_id: string): WorkbenchIssue {
  return {
    code,
    severity,
    message: code,
    topic_id,
    source_block_ids: ["block_a"],
  };
}

function makeState(topics: WorkbenchTopic[]): WorkbenchState {
  return {
    document_id: "doc_a",
    topics,
    unassigned_units: [],
  };
}
