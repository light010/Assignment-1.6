import { describe, expect, it } from "vitest";
import { SourceBlock } from "./api";
import {
  buildExtractionExplorer,
  defaultExpandedExtractionIds,
  flattenVisibleExtractionNodes,
  navigateExtractionTree,
} from "./extractionExplorerModel";

describe("extractionExplorerModel", () => {
  it("builds source-block rows in document order without duplicating ancestor headings", () => {
    const blocks = appleLikeBlocks();
    const model = buildModel(blocks);

    expect(model.sourceBlockCount).toBe(55);
    expect(model.allNodes.filter((node) => node.block).length).toBe(55);
    expect(model.allNodes.filter((node) => node.kind === "heading" && node.label === "Apple CA Summary")).toHaveLength(1);

    const summary = model.allNodes.find((node) => node.kind === "heading" && node.label === "Apple CA Summary");
    expect(summary?.children.map((node) => node.label)).not.toContain("Apple CA (PSC)");
    expect(summary?.children.map((node) => node.label)).not.toContain("Apple CA One Pager");
    expect(summary?.children.map((node) => node.label)).not.toContain("Apple CA Summary");
  });

  it("groups Apple CA tables as table nodes with row/cell children", () => {
    const model = buildModel(appleLikeBlocks());

    const summary = model.allNodes.find((node) => node.kind === "heading" && node.label === "Apple CA Summary");
    const summaryTable = summary?.children.find((node) => node.kind === "table");
    expect(summaryTable?.label).toBe("Table tbl_summary · Apple CA Summary");
    expect(summaryTable?.metadata).toMatchObject({ row_count: 5, column_count: 2, heading_context: "Apple CA Summary" });
    expect(summaryTable?.children).toHaveLength(5);
    expect(summaryTable?.children[0]?.cells?.map((cell) => cell.text)).toEqual(["Client Name", "Apple CA"]);
    expect(summaryTable?.children[0]?.metadata).toMatchObject({
      table_label: "Table tbl_summary · Apple CA Summary",
      table_row_count: 5,
      table_column_count: 2,
    });

    const contacts = model.allNodes.find((node) => node.kind === "heading" && node.label === "Apple CA Client Contacts");
    const contactsTable = contacts?.children.find((node) => node.kind === "table");
    expect(contactsTable?.children).toHaveLength(5);

    const portal = model.allNodes.find((node) => node.kind === "heading" && node.label === "Apple CA Portal Links");
    expect(portal?.children.some((node) => node.kind === "paragraph")).toBe(true);
    expect(portal?.children.some((node) => node.kind === "table")).toBe(true);
  });

  it("maps source clicks to the exact extraction row and breadcrumb", () => {
    const model = buildModel(appleLikeBlocks());
    const nodeId = model.sourceBlockToNodeId.get("row_summary_1");
    const node = nodeId ? model.nodeById.get(nodeId) : null;

    expect(node?.kind).toBe("table_row");
    expect(node?.label).toBe("Row 1");
    expect(node?.sourceBlockIds).toEqual(["row_summary_1"]);
    expect(node?.headingPath).toEqual(["Apple CA (PSC)", "Apple CA One Pager", "Apple CA Summary"]);
  });

  it("keeps document root synthetic and locator-free", () => {
    const model = buildModel(appleLikeBlocks());
    expect(model.roots[0]?.kind).toBe("document");
    expect(model.roots[0]?.label).toBe("Apple CA (PSC).docx");
    expect(model.roots[0]?.metadata.block_count).toBe(55);
    expect(model.roots[0]?.locator).toBeNull();
    expect(model.roots[0]?.metadata.locator).toBeUndefined();
  });

  it("uses the review flag dictionary for severity and action", () => {
    const model = buildModel([
      block("flagged", "paragraph", "Needs review", {
        review_flags: [{ code: "ASSET_REF_UNRESOLVED", message: "Asset missing.", action: "Open assets." }],
      }),
    ]);
    const node = model.allNodes.find((item) => item.sourceBlockIds[0] === "flagged");
    expect(node?.attentionSignals[0]).toMatchObject({
      code: "ASSET_REF_UNRESOLVED",
      severity: "error",
      action: "Open assets.",
    });
  });

  it("does not synthesize HEADING_BY_FORMATTING on the frontend", () => {
    const model = buildModel([
      block("heading", "heading", "Formatted heading", {
        confidence_signals: { style_source: "formatting" },
      }),
    ]);
    const node = model.allNodes.find((item) => item.sourceBlockIds[0] === "heading");
    expect(node?.attentionSignals.some((signal) => signal.code === "HEADING_BY_FORMATTING")).toBe(false);
  });

  it("respects DOCX numbering levels when building list review rows", () => {
    const blocks = [
      block("h_root", "heading", "Apple CA Running Garnishment", { inferred_level: 2 }),
      block("step_1", "procedure_step", "Apple CA will pull Garnishment report", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 0, format: "decimal", level_text: "%1." },
      }),
      block("step_1a", "procedure_step", "Apple will compile all information", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 1, format: "lowerLetter", level_text: "%2." },
      }),
      block("step_2", "procedure_step", "ADP GV will fill out Third Party Cheque Request", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 0, format: "decimal", level_text: "%1." },
      }),
      block("step_2a", "procedure_step", "When form is complete", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 1, format: "lowerLetter", level_text: "%2." },
      }),
      block("step_3", "procedure_step", "Processing by ADP CFS", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 0, format: "decimal", level_text: "%1." },
      }),
    ];
    const model = buildModel(blocks);

    expect(model.sourceBlockCount).toBe(6);
    expect(model.sourceBlockToNodeId.get("step_1")).toBeTruthy();
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_1")!)?.metadata.numbering_label).toBe("1.");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_1")!)?.metadata.list_depth).toBe(0);
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_1a")!)?.metadata.numbering_label).toBe("a.");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_1a")!)?.metadata.list_depth).toBe(1);
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_1a")!)?.metadata.numbering_format).toBe("lowerLetter");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_2")!)?.metadata.numbering_label).toBe("2.");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_2a")!)?.metadata.numbering_label).toBe("a.");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_3")!)?.kind).toBe("procedure_step");
    expect(model.nodeById.get(model.sourceBlockToNodeId.get("step_3")!)?.metadata.numbering_label).toBe("3.");
  });

  it("uses extraction signals for attention count and attention-only filtering", () => {
    const blocks = appleLikeBlocks([
      block("needs_flag", "paragraph", "Needs review", {
        heading_path_ids: ["h_root"],
        review_flags: ["LINK_HREF_MISSING"],
      }),
      block("needs_confidence", "paragraph", "Low confidence", {
        heading_path_ids: ["h_root"],
        confidence: confidence(0.6),
      }),
    ]);
    const model = buildModel(blocks);
    const expanded = new Set(model.allNodes.filter((node) => node.children.length > 0).map((node) => node.id));
    const visibleAttention = flattenVisibleExtractionNodes(model.roots, expanded, { attentionOnly: true });

    expect(model.attentionBlockCount).toBe(2);
    expect(model.attentionSignalCount).toBe(2);
    expect(model.reviewFlagBlockCount).toBe(1);
    expect(model.reviewFlagSignalCount).toBe(1);
    expect(model.topReviewFlagCodes).toEqual(["LINK_HREF_MISSING"]);
    expect(model.firstAttentionNodeId).toBeTruthy();
    expect(model.checklist.find((item) => item.id === "review-flags")).toMatchObject({
      status: "warning",
      targetSourceBlockId: "needs_flag",
    });
    expect(model.attentionSourceIds.has("needs_flag")).toBe(true);
    expect(visibleAttention.map((node) => node.label)).toContain("Apple CA (PSC)");
    expect(visibleAttention.map((node) => node.sourceBlockIds[0])).toContain("needs_flag");
    expect(visibleAttention.map((node) => node.sourceBlockIds[0])).not.toContain("filler_1");
  });

  it("warns for link-like blocks only when href metadata is missing", () => {
    const withHref = buildModel([
      block("link_ok", "paragraph", "Open https://example.com", {
        inline_runs: [{ text: "https://example.com", href: "https://example.com" }],
      }),
    ]);
    expect(withHref.checklist.find((item) => item.id === "links")).toMatchObject({
      status: "pass",
      detail: "1 link-like blocks include href metadata",
    });

    const missingHref = buildModel([
      block("link_missing", "paragraph", "Open https://example.com", {
        inline_runs: [{ text: "https://example.com" }],
      }),
    ]);
    expect(missingHref.checklist.find((item) => item.id === "links")).toMatchObject({
      status: "warning",
      detail: "1/1 link-like blocks need href metadata",
    });
  });

  it("does not promote ordinary bullets to resource rows", () => {
    const model = buildModel([
      block("h_root", "heading", "Updating the Payroll Schedule", { inferred_level: 1 }),
      block("step_parent", "procedure_step", "Make the appropriate changes to the baseline date fields:", {
        heading_path_ids: ["h_root"],
        numbering: { num_id: "1", level: 0, format: "decimal", level_text: "%1." },
      }),
      block("period_ending", "procedure_step", "Period Ending", {
        heading_path_ids: ["h_root"],
        parent_block_id: "step_parent",
        numbering: { num_id: "1", level: 1, format: "bullet", level_text: "•" },
      }),
    ]);

    const node = model.nodeById.get(model.sourceBlockToNodeId.get("period_ending")!);
    expect(node?.kind).toBe("procedure_step");
    expect(node?.headingPath).toEqual([
      "Updating the Payroll Schedule",
      "1. Make the appropriate changes to the baseline date fie...",
    ]);
  });

  it("navigates only visible rows through expand, enter, collapse, and parent exit", () => {
    const model = buildModel(appleLikeBlocks());
    let expanded = defaultExpandedExtractionIds(model.roots);
    let visible = flattenVisibleExtractionNodes(model.roots, expanded);
    const rootHeading = model.allNodes.find((node) => node.kind === "heading" && node.label === "Apple CA (PSC)")!;

    let next = navigateExtractionTree({
      visibleNodes: visible,
      nodeById: model.nodeById,
      expandedIds: expanded,
      activeId: "document",
      key: "down",
    });
    expect(next.activeId).toBe(rootHeading.id);

    next = navigateExtractionTree({
      visibleNodes: visible,
      nodeById: model.nodeById,
      expandedIds: new Set(),
      activeId: rootHeading.id,
      key: "right",
    });
    expanded = next.expandedIds;
    expect(expanded.has(rootHeading.id)).toBe(true);

    visible = flattenVisibleExtractionNodes(model.roots, expanded);
    next = navigateExtractionTree({
      visibleNodes: visible,
      nodeById: model.nodeById,
      expandedIds: expanded,
      activeId: rootHeading.id,
      key: "right",
    });
    expect(model.nodeById.get(next.activeId)?.parentId).toBe(rootHeading.id);

    next = navigateExtractionTree({
      visibleNodes: visible,
      nodeById: model.nodeById,
      expandedIds: expanded,
      activeId: next.activeId,
      key: "left",
    });
    expect(next.activeId).toBe(rootHeading.id);
  });
});

function buildModel(blocks: SourceBlock[]) {
  return buildExtractionExplorer({
    documentLabel: "Apple CA (PSC).docx",
    blocks,
    locatedSourceIds: new Set(blocks.map((item) => item.block_id)),
    sourceResolutionKnown: true,
    qualityGate: { name: "docx_source_fidelity_v1", passed: true, severity: "info", blocking_reasons: [] },
  });
}

function appleLikeBlocks(extra: SourceBlock[] = []) {
  const blocks: SourceBlock[] = [
    block("h_root", "heading", "Apple CA (PSC)", { inferred_level: 1, heading_path_ids: [] }),
    block("h_one", "heading", "Apple CA One Pager", { inferred_level: 2, heading_path_ids: ["h_root"] }),
    block("h_summary", "heading", "Apple CA Summary", { inferred_level: 3, heading_path_ids: ["h_root", "h_one"] }),
    ...tableRows("row_summary", "tbl_summary", ["h_root", "h_one", "h_summary"], [
      ["Client Name", "Apple CA"],
      ["Client Environment", "PP1 516"],
      ["Contact Number", "1-877-282-1644"],
      ["Hours of Operation", "9:00AM-6:30PM"],
      ["Payroll Areas", "KB"],
    ]),
    block("h_contacts", "heading", "Apple CA Client Contacts", { inferred_level: 3, heading_path_ids: ["h_root", "h_one"] }),
    ...tableRows("row_contacts", "tbl_contacts", ["h_root", "h_one", "h_contacts"], [
      ["Swati Tiwari", "swati_tiwari@apple.com"],
      ["Arnab Saha", "arnab_k_saha@apple.com"],
      ["Chariste Dimas", "512-674-2876"],
      ["Minda George", "512-674-8583"],
      ["Escalations", "ADP CFS"],
    ]),
    block("h_portal", "heading", "Apple CA Portal Links", { inferred_level: 3, heading_path_ids: ["h_root", "h_one"] }),
    block("portal_intro", "paragraph", "Apple CA uses SSO for all active employees.", { heading_path_ids: ["h_root", "h_one", "h_portal"] }),
    ...tableRows("row_portal", "tbl_portal", ["h_root", "h_one", "h_portal"], [
      ["ESS/MyView", "https://portal.globalview.adp.com/apple"],
    ]),
    ...extra,
  ];
  let index = 1;
  while (blocks.length < 55) {
    blocks.push(block(`filler_${index}`, "paragraph", `Filler paragraph ${index}`, { heading_path_ids: ["h_root"] }));
    index += 1;
  }
  return blocks;
}

function tableRows(prefix: string, tableId: string, headingPathIds: string[], rows: string[][]) {
  return rows.map((cells, rowIndex) =>
    block(`${prefix}_${rowIndex + 1}`, "table_row", cells.join(" | "), {
      heading_path_ids: headingPathIds,
      table_id: tableId,
      row_index: rowIndex + 1,
      cells: cells.map((text) => ({ text })),
    }),
  );
}

function block(
  block_id: string,
  block_type: string,
  text: string,
  overrides: Partial<SourceBlock> = {},
): SourceBlock {
  return {
    block_id,
    block_type,
    text,
    source_location: { page: null, section: `docx:p:${block_id}`, bbox: null },
    heading_path_ids: [],
    confidence: confidence(0.9),
    review_flags: [],
    ...overrides,
  };
}

function confidence(value: number) {
  return { extraction: value, block_type: value, heading: value, semantic_inline: value };
}
