import { Activity, Eye, EyeOff, FileText, HelpCircle, Home, Lock, LogOut, Mail, RefreshCw, Settings } from "lucide-react";
import { FormEvent, useState } from "react";
import ditagenLogo from "./assets/ditagen-logo.png";
import { login, User } from "./api";

type NavKey = "home" | "documents" | "activity" | "settings";

export function AppNav({
  active,
  onNavigateHome,
  canNavigateHome,
}: {
  active: NavKey;
  onNavigateHome?: () => void;
  canNavigateHome: boolean;
}) {
  const primaryItems: Array<{ key: NavKey; icon: JSX.Element; label: string; available: boolean; onClick?: () => void }> = [
    {
      key: "home",
      icon: <Home size={18} />,
      label: "Business Units",
      available: true,
      onClick: canNavigateHome ? onNavigateHome : undefined,
    },
    {
      key: "documents",
      icon: <FileText size={18} />,
      label: "Documents",
      available: active === "documents",
    },
    {
      key: "activity",
      icon: <Activity size={18} />,
      label: "Activity",
      available: false,
    },
  ];

  const footerItems: Array<{ key: NavKey | "help"; icon: JSX.Element; label: string }> = [
    { key: "settings", icon: <Settings size={18} />, label: "Settings" },
    { key: "help", icon: <HelpCircle size={18} />, label: "Help & Documentation" },
  ];

  return (
    <aside className="app-nav" aria-label="Primary navigation">
      <nav className="app-nav-group">
        {primaryItems.map((item) => {
          const isActive = item.key === active;
          return (
            <button
              key={item.key}
              type="button"
              className={`app-nav-item${isActive ? " active" : ""}${item.available ? "" : " muted"}`}
              title={item.available ? item.label : `${item.label} — coming soon`}
              aria-label={item.label}
              aria-current={isActive ? "page" : undefined}
              onClick={item.onClick}
              disabled={!item.available && !isActive}
            >
              {item.icon}
            </button>
          );
        })}
      </nav>
      <nav className="app-nav-group app-nav-footer">
        {footerItems.map((item) => (
          <button
            key={item.key}
            type="button"
            className="app-nav-item muted"
            title={`${item.label} — coming soon`}
            aria-label={item.label}
            disabled
          >
            {item.icon}
          </button>
        ))}
      </nav>
    </aside>
  );
}

export function TopAppBar({
  user,
  onSignOut,
  contextLabel,
}: {
  user: User;
  onSignOut: () => void;
  contextLabel: string;
}) {
  return (
    <header className="top-app-bar" aria-label="Application">
      <div className="topbar-brand">
        <img src={ditagenLogo} alt="" />
        <span>DITAgen</span>
      </div>
      <div className="topbar-context">{contextLabel}</div>
      <div className="topbar-actions">
        <div className="account-control">{user.name}</div>
        <button className="topbar-icon-button" onClick={onSignOut} title="Sign out" aria-label="Sign out">
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
}

export function LoginView({ onLogin }: { onLogin: (user: User) => void }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      const user = await login(String(form.get("email")), String(form.get("password")));
      onLogin(user);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-shell">
      <header className="auth-topbar" aria-label="DITAgen">
        <div className="auth-topbar-brand">
          <img src={ditagenLogo} alt="" />
          <span>DITAgen</span>
        </div>
      </header>

      <main className="auth-main">
        <section className="auth-card" aria-label="Sign in">
          <div className="auth-lock" aria-hidden>
            <Lock size={18} />
          </div>

          <div className="auth-logo">
            <img className="auth-logo-image" src={ditagenLogo} alt="" />
          </div>

          <h1 className="auth-title">Sign in to DITAgen</h1>

          <form className="auth-form" onSubmit={submit} aria-busy={busy}>
            <label className="auth-field">
              <span>User ID</span>
              <div className="auth-input">
                <Mail size={17} aria-hidden />
                <input
                  name="email"
                  type="email"
                  autoComplete="username"
                  defaultValue="admin@ditagen.local"
                  required
                />
              </div>
            </label>

            <label className="auth-field">
              <span>Password</span>
              <div className="auth-input">
                <Lock size={17} aria-hidden />
                <input
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  defaultValue="admin123"
                  required
                />
                <button
                  type="button"
                  className="auth-eye"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  onClick={() => setShowPassword((value) => !value)}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </label>

            <label className="auth-remember">
              <input type="checkbox" name="remember" />
              <span>Remember user ID</span>
            </label>

            {error && <div className="error-banner">{error}</div>}

            <div className="auth-actions">
              <button className="auth-submit" disabled={busy}>
                {busy ? (
                  <>
                    <RefreshCw size={16} className="spin" aria-hidden /> Signing in
                  </>
                ) : (
                  "Sign in"
                )}
              </button>
            </div>
          </form>

          <div className="auth-divider" />

          <div className="auth-secondary-links">
            <a href="#" onClick={(event) => event.preventDefault()}>
              Need help signing in?
            </a>
            <p className="auth-new-user">
              New user?{" "}
              <a href="#" onClick={(event) => event.preventDefault()}>
                Get started
              </a>
            </p>
          </div>
        </section>

        <footer className="auth-footer">
          <div className="auth-brand-lockup">
            <span>DITAgen alpha - v0.1</span>
          </div>
          <nav aria-label="Legal links">
            <a href="#" onClick={(event) => event.preventDefault()}>
              Privacy
            </a>
            <a href="#" onClick={(event) => event.preventDefault()}>
              Legal
            </a>
          </nav>
        </footer>
      </main>
    </div>
  );
}
