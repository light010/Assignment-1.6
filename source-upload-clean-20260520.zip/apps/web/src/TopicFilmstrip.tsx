import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { KeyboardEvent } from "react";
import { WorkbenchTopic } from "./workbenchModel";
import {
  isTopicReviewCurrent,
  ReviewedTopicState,
  topicAttentionSummary,
  TopicAttentionSummary,
} from "./workbenchSelectors";
import { topicChipLabel } from "./workbenchViewModel";

export function TopicFilmstrip({
  topics,
  summaries,
  reviewed,
  selectedTopicId,
  onSelectTopic,
}: {
  topics: WorkbenchTopic[];
  summaries: Map<string, TopicAttentionSummary>;
  reviewed: Record<string, ReviewedTopicState>;
  selectedTopicId: string;
  onSelectTopic: (topicId: string) => void;
}) {
  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    event.preventDefault();
    const currentIndex = topics.findIndex((topic) => topic.topic_id === selectedTopicId);
    const delta = event.key === "ArrowRight" ? 1 : -1;
    const nextIndex = currentIndex < 0 ? 0 : (currentIndex + delta + topics.length) % topics.length;
    const nextTopic = topics[nextIndex];
    if (nextTopic) onSelectTopic(nextTopic.topic_id);
  }

  return (
    <div className="topic-filmstrip" role="tablist" aria-label="Topics" onKeyDown={handleKeyDown}>
      {topics.map((topic, index) => {
        const summary = summaries.get(topic.topic_id) || topicAttentionSummary(topic, []);
        const selected = topic.topic_id === selectedTopicId;
        const reviewedCurrent = isTopicReviewCurrent(topic, reviewed[topic.topic_id]);
        return (
          <motion.button
            layout
            type="button"
            role="tab"
            key={topic.topic_id}
            aria-selected={selected}
            aria-label={topicChipLabel({
              title: topic.title,
              index: index + 1,
              total: topics.length,
              severity: summary.severity,
              reviewed: reviewedCurrent,
            })}
            className={`topic-filmstrip-chip severity-${summary.severity}${selected ? " active" : ""}${reviewedCurrent ? " reviewed" : ""}`}
            onClick={() => onSelectTopic(topic.topic_id)}
          >
            <span className="filmstrip-number">{index + 1}</span>
            <span className={`filmstrip-dot severity-${summary.severity}`} aria-hidden />
            <span className="filmstrip-title">{topic.title}</span>
            {summary.severity !== "clean" && <AlertTriangle size={13} aria-hidden />}
            {reviewedCurrent && <CheckCircle2 size={13} aria-hidden />}
          </motion.button>
        );
      })}
    </div>
  );
}
