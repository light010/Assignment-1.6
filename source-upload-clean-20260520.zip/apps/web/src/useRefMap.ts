import { useCallback, useRef, useState } from "react";

export function useRefMap<TKey extends string>() {
  const refs = useRef<Map<TKey, HTMLElement>>(new Map());
  const pendingDeletes = useRef<Map<TKey, number>>(new Map());
  const [version, setVersion] = useState(0);
  const setRef = useCallback((id: TKey, node: HTMLElement | null) => {
    const pending = pendingDeletes.current.get(id);
    if (pending !== undefined) {
      window.cancelAnimationFrame(pending);
      pendingDeletes.current.delete(id);
    }
    if (node) {
      if (refs.current.get(id) === node) return;
      refs.current.set(id, node);
      setVersion((current) => current + 1);
      return;
    }
    if (!refs.current.has(id)) return;
    const currentNode = refs.current.get(id);
    const frame = window.requestAnimationFrame(() => {
      pendingDeletes.current.delete(id);
      if (refs.current.get(id) !== currentNode) return;
      refs.current.delete(id);
      setVersion((current) => current + 1);
    });
    pendingDeletes.current.set(id, frame);
  }, []);
  return { refs, setRef, version };
}
