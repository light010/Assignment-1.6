import { describe, expect, it } from "vitest";
import { WorkbenchTopic, WorkbenchUnit } from "./workbenchModel";
import { topicAttentionSummary } from "./workbenchSelectors";
import {
  draftStateLabel,
  evidenceNumbersForUnit,
  nextActionCopy,
  topicChipLabel,
} from "./workbenchViewModel";

describe("workbenchViewModel", () => {
  it("maps next actions to cockpit CTA copy", () => {
    expect(nextActionCopy({ kind: "review_validation", reason: "bad" })).toMatchObject({
      label: "Review validation",
      tone: "danger",
    });
    expect(nextActionCopy({ kind: "mark_reviewed", reason: "clean" })).toMatchObject({
      label: "Mark reviewed",
      tone: "success",
    });
  });

  it("keeps clean state quiet unless draft or stale state exists", () => {
    const topic = makeTopic();
    expect(draftStateLabel(topic, false, topicAttentionSummary(topic, []))).toBe("Clean");
    expect(draftStateLabel(topic, true, topicAttentionSummary(topic, []))).toBe("Unsaved local draft");
    expect(draftStateLabel({ ...topic, validation_stale: true }, false, topicAttentionSummary(topic, []))).toBe("Validation stale");
  });

  it("maps timeline rows to source-order evidence numbers", () => {
    const unit = makeUnit(["block_c", "block_a", "block_c"]);

    expect(evidenceNumbersForUnit(unit, [
      { source_block_id: "block_a", evidence_number: 1 },
      { source_block_id: "block_b", evidence_number: 2 },
      { source_block_id: "block_c", evidence_number: 3 },
    ])).toEqual([1, 3]);
  });

  it("builds accessible filmstrip labels without repeated clean badges", () => {
    expect(topicChipLabel({
      title: "Apple CA Running Garnishment",
      index: 4,
      total: 15,
      severity: "review",
      reviewed: true,
    })).toBe("Topic 4 of 15: Apple CA Running Garnishment, needs review attention, reviewed");
  });
});

function makeTopic(): WorkbenchTopic {
  return {
    topic_id: "topic_a",
    title: "Topic A",
    topic_type: "concept",
    source_block_ids: ["block_a"],
    boundary_confidence: 0.9,
    type_confidence: 0.9,
    review_required: false,
    review_issues: [],
    validation_issues: [],
    validation_stale: false,
    units: [makeUnit(["block_a"])],
  };
}

function makeUnit(source_block_ids: string[]): WorkbenchUnit {
  return {
    unit_id: "unit_a",
    topic_id: "topic_a",
    source_block_ids,
    text: "Evidence",
    block_type: "paragraph",
    confidence: 0.9,
  };
}
