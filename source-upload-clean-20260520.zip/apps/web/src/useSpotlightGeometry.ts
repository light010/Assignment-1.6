import { MutableRefObject, RefObject, useCallback, useLayoutEffect, useRef, useState } from "react";
import { buildSpotlightRects, GeometryRect, SpotlightRect } from "./workbenchGeometry";

export function useSpotlightGeometry({
  overlayRef,
  sourceRefs,
  sourceBlockIds,
  geometryVersion = 0,
}: {
  overlayRef: RefObject<HTMLElement | null>;
  sourceRefs: MutableRefObject<Map<string, HTMLElement>>;
  sourceBlockIds: string[];
  geometryVersion?: number;
}) {
  const [rects, setRects] = useState<SpotlightRect[] | null>(null);
  const frameRef = useRef<number | null>(null);
  const sourceIdsKey = sourceBlockIds.join("|");

  const recompute = useCallback(() => {
    const overlay = overlayRef.current;
    if (!overlay || sourceBlockIds.length === 0) {
      setRects((current) => (current ? null : current));
      return;
    }
    const sourceRects = new Map<string, GeometryRect>();
    sourceRefs.current.forEach((element, id) => sourceRects.set(id, element.getBoundingClientRect()));
    const next = buildSpotlightRects({
      sourceRects,
      sourceBlockIds,
      overlayRect: overlay.getBoundingClientRect(),
    });
    setRects((current) => (spotlightRectsEqual(current, next) ? current : next));
  }, [geometryVersion, overlayRef, sourceBlockIds, sourceIdsKey, sourceRefs]);

  const schedule = useCallback(() => {
    if (frameRef.current !== null) return;
    frameRef.current = window.requestAnimationFrame(() => {
      frameRef.current = null;
      recompute();
    });
  }, [recompute]);

  useLayoutEffect(() => {
    schedule();
    const observer = new ResizeObserver(schedule);
    if (overlayRef.current) observer.observe(overlayRef.current);
    window.addEventListener("resize", schedule);
    window.addEventListener("scroll", schedule, true);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", schedule);
      window.removeEventListener("scroll", schedule, true);
      if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    };
  }, [overlayRef, schedule]);

  return rects;
}

function spotlightRectsEqual(left: SpotlightRect[] | null, right: SpotlightRect[] | null) {
  if (left === right) return true;
  if (!left || !right || left.length !== right.length) return false;
  return left.every((item, index) => {
    const other = right[index];
    return other
      && item.id === other.id
      && item.x === other.x
      && item.y === other.y
      && item.width === other.width
      && item.height === other.height;
  });
}
