import { describe, expect, it } from "vitest";
import {
  detectSourceViewerKind,
  matchBlocksToCandidates,
  normalizeSourceText,
  sourceMatchFailureIds,
  sourceMatchStats,
} from "./sourceViewerModel";

const block = (block_id: string, text: string, section?: string, extra: Record<string, unknown> = {}) => ({
  block_id,
  text,
  source_location: { section },
  ...extra,
});

describe("sourceViewerModel", () => {
  it("detects source viewer type from content type and filename", () => {
    expect(detectSourceViewerKind("source.docx", null)).toBe("docx");
    expect(detectSourceViewerKind("source.bin", "application/pdf")).toBe("pdf");
    expect(detectSourceViewerKind("source.txt", "text/plain")).toBe("text");
    expect(detectSourceViewerKind("source.md", "text/markdown")).toBe("text");
    expect(detectSourceViewerKind("source.html", "text/html")).toBe("html");
    expect(detectSourceViewerKind("source.zip", "application/zip")).toBe("unsupported");
  });

  it("normalizes whitespace and punctuation for matching", () => {
    expect(normalizeSourceText("Client Name |  Apple CA")).toBe("client name apple ca");
    expect(normalizeSourceText("The “Manual”  Request")).toBe("the \"manual\" request");
    expect(normalizeSourceText("A\u00a0soft\u00adhyphen — ﬁle")).toBe("a softhyphen - file");
  });

  it("uses locator matches before duplicate text fallback", () => {
    const matches = matchBlocksToCandidates(
      [
        block("blk_1", "Repeat", "docx:p:1"),
        block("blk_2", "Repeat", "docx:p:0"),
      ],
      [
        { key: "candidate-0", text: "Repeat", docxParagraphIndex: 0 },
        { key: "candidate-1", text: "Repeat", docxParagraphIndex: 1 },
      ],
    );

    expect(matches).toEqual([
      { blockId: "blk_1", candidateKey: "candidate-1", matchType: "locator" },
      { blockId: "blk_2", candidateKey: "candidate-0", matchType: "locator" },
    ]);
  });

  it("matches DOCX table-row locators", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_row", "Field Value", "docx:tbl:3:r:1")],
      [{ key: "candidate-row", text: "Field Value", docxTableIndex: 3, docxRowIndex: 1 }],
    );

    expect(matches[0]).toEqual({ blockId: "blk_row", candidateKey: "candidate-row", matchType: "locator" });
  });

  it("does not text-fallback when a parsed DOCX locator misses", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_missing", "Repeat", "docx:p:35")],
      [{ key: "candidate-other", text: "Repeat", docxParagraphIndex: 12 }],
    );

    expect(matches).toEqual([
      { blockId: "blk_missing", candidateKey: null, matchType: "unmatched" },
    ]);
    expect(sourceMatchFailureIds(matches)).toEqual(["blk_missing"]);
  });

  it("maps Apple CA-style DOCX paragraph locators at 100 percent", () => {
    const blocks = Array.from({ length: 8 }, (_, index) =>
      block(`apple_${index}`, `Apple CA source paragraph ${index}`, `docx:p:${index}`),
    );
    const candidates = blocks.map((item, index) => ({
      key: `candidate-${index}`,
      text: item.text,
      docxParagraphIndex: index,
    }));

    const matches = matchBlocksToCandidates(blocks, candidates);

    expect(sourceMatchFailureIds(matches)).toEqual([]);
    expect(sourceMatchStats(matches)).toEqual({ matched: 8, unmatched: 0, total: 8 });
  });

  it("maps Customer Change Requests docx:p:35 by locator", () => {
    const matches = matchBlocksToCandidates(
      [block("customer_change_requests_p35", "Customer Change Request review row", "docx:p:35")],
      [
        { key: "candidate-12", text: "Customer Change Request review row", docxParagraphIndex: 12 },
        { key: "candidate-35", text: "Customer Change Request review row", docxParagraphIndex: 35 },
      ],
    );

    expect(matches).toEqual([
      { blockId: "customer_change_requests_p35", candidateKey: "candidate-35", matchType: "locator" },
    ]);
    expect(sourceMatchFailureIds(matches)).toEqual([]);
  });

  it("corrects DOCX body-index drift caused by rendered empty media paragraphs", () => {
    const matches = matchBlocksToCandidates(
      [
        block("before_image", "Open the quote details.", "docx:p:17"),
        block("after_image", "Fill out the form.", "docx:p:18"),
        block("note_after_image", "Note: enter discounts as an amount.", "docx:p:19"),
        block("shifted_table_row", "If | Then", "docx:tbl:20:r:1"),
      ],
      [
        { key: "candidate-17", text: "Open the quote details.", docxParagraphIndex: 17 },
        { key: "candidate-18-empty-media", text: "", docxParagraphIndex: 18 },
        { key: "candidate-19", text: "Fill out the form.", docxParagraphIndex: 19 },
        { key: "candidate-20", text: "Note: enter discounts as an amount.", docxParagraphIndex: 20 },
        { key: "candidate-table-21-r1", text: "IfThen", docxTableIndex: 21, docxRowIndex: 1 },
      ],
    );

    expect(matches).toEqual([
      { blockId: "before_image", candidateKey: "candidate-17", matchType: "locator" },
      { blockId: "after_image", candidateKey: "candidate-19", matchType: "locator" },
      { blockId: "note_after_image", candidateKey: "candidate-20", matchType: "locator" },
      { blockId: "shifted_table_row", candidateKey: "candidate-table-21-r1", matchType: "locator" },
    ]);
    expect(sourceMatchFailureIds(matches)).toEqual([]);
  });

  it("disambiguates two tables at different body indices by locator (regression for off-axis table_id fallback)", () => {
    // Two tables, each with one row at row_index=1, same text. The
    // backend emits distinct locators (`docx:tbl:4:r:1` vs `docx:tbl:9:r:1`)
    // using each table's body-index. The frontend candidates carry the
    // same body-index in `docxTableIndex`. Pre-Step-B, an off-axis
    // fallback parsed `tbl_001`/`tbl_002` (sequence numbers) and looked
    // up `1:1`/`2:1` — never `4:1` or `9:1` — silently mismatching.
    const matches = matchBlocksToCandidates(
      [
        block("blk_t1_r1", "Field Value", "docx:tbl:4:r:1", { table_id: "tbl_001", row_index: 1 }),
        block("blk_t2_r1", "Field Value", "docx:tbl:9:r:1", { table_id: "tbl_002", row_index: 1 }),
      ],
      [
        { key: "candidate-t4-r1", text: "Field Value", docxTableIndex: 4, docxRowIndex: 1 },
        { key: "candidate-t9-r1", text: "Field Value", docxTableIndex: 9, docxRowIndex: 1 },
      ],
    );

    expect(matches).toEqual([
      { blockId: "blk_t1_r1", candidateKey: "candidate-t4-r1", matchType: "locator" },
      { blockId: "blk_t2_r1", candidateKey: "candidate-t9-r1", matchType: "locator" },
    ]);
  });

  it("matches blocks to candidates in source order", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_1", "Apple CA Summary"), block("blk_2", "Apple CA uses SSO")],
      [
        { key: "candidate-1", text: "Apple CA Summary" },
        { key: "candidate-2", text: "Apple CA uses SSO" },
      ],
    );

    expect(matches).toEqual([
      { blockId: "blk_1", candidateKey: "candidate-1", matchType: "exact" },
      { blockId: "blk_2", candidateKey: "candidate-2", matchType: "exact" },
    ]);
  });

  it("resolves duplicate text by consuming candidates in order", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_1", "Repeat"), block("blk_2", "Repeat")],
      [
        { key: "candidate-1", text: "Repeat" },
        { key: "candidate-2", text: "Repeat" },
      ],
    );

    expect(matches.map((match) => match.candidateKey)).toEqual(["candidate-1", "candidate-2"]);
  });

  it("uses unique contained-text matches for long blocks", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_1", "Manual Third Party Cheque Request")],
      [{ key: "candidate-1", text: "Apple will compile and ask for Manual Third Party Cheque Request approval." }],
    );

    expect(matches[0]).toEqual({
      blockId: "blk_1",
      candidateKey: "candidate-1",
      matchType: "contains",
    });
  });

  it("matches DOCX nested-table-row locators against inner-row candidates", () => {
    // Step E: nested-table row locator `docx:tbl:O:r:R:tbl:I:r:M` routes
    // to the candidate whose four-tuple key (outer_tbl, outer_row,
    // inner_tbl, inner_row) matches. The cell axis is intentionally
    // absent from the locator — inner tables are numbered cumulatively
    // across all cells of the outer row.
    const matches = matchBlocksToCandidates(
      [block("blk_inner", "Inner cell 1", "docx:tbl:3:r:1:tbl:0:r:2")],
      [
        {
          key: "candidate-inner",
          text: "Inner cell 1",
          docxOuterTableIndex: 3,
          docxOuterRowIndex: 1,
          docxInnerTableIndex: 0,
          docxInnerRowIndex: 2,
        },
      ],
    );

    expect(matches[0]).toEqual({
      blockId: "blk_inner",
      candidateKey: "candidate-inner",
      matchType: "locator",
    });
  });

  it("matches DOCX header/footer locators to their section-paragraph anchors", () => {
    const matches = matchBlocksToCandidates(
      [
        block("blk_hdr", "Confidential", "docx:hdr:section-0:p:0"),
        block("blk_ftr", "Page 1 of N", "docx:ftr:section-0:p:0"),
      ],
      [
        {
          key: "candidate-hdr",
          text: "Confidential",
          docxHeaderSectionId: "section-0",
          docxHeaderParagraphIndex: 0,
        },
        {
          key: "candidate-ftr",
          text: "Page 1 of N",
          docxFooterSectionId: "section-0",
          docxFooterParagraphIndex: 0,
        },
      ],
    );

    expect(matches).toEqual([
      { blockId: "blk_hdr", candidateKey: "candidate-hdr", matchType: "locator" },
      { blockId: "blk_ftr", candidateKey: "candidate-ftr", matchType: "locator" },
    ]);
  });

  it("reports ambiguous or missing matches as unmatched", () => {
    const matches = matchBlocksToCandidates(
      [block("blk_1", "Manual Third Party Cheque Request")],
      [
        { key: "candidate-1", text: "Manual Third Party Cheque Request approval." },
        { key: "candidate-2", text: "Manual Third Party Cheque Request form." },
      ],
    );

    expect(matches[0]).toEqual({ blockId: "blk_1", candidateKey: null, matchType: "unmatched" });
    expect(sourceMatchStats(matches)).toEqual({ matched: 0, unmatched: 1, total: 1 });
  });
});
