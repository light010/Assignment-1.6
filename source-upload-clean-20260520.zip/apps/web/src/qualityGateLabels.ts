/**
 * Step H-audit-2: typed mapper from `gate.blocking_reasons` enum tokens
 * to user-facing labels.
 *
 * `humanizeStatus` does generic snake_case→Title Case conversion, which
 * works for some of these but produces awkward output for others
 * (e.g. `mdformat_plugin_missing` → "Mdformat Plugin Missing" — bad
 * casing). The labels here are hand-tuned, and any new enum value the
 * schema introduces must add a label here or fall back to a clear
 * "Unknown reason: <code>" rather than silently passing through.
 *
 * The enum list MUST stay in sync with
 * `contracts/artifacts/extraction-quality.schema.json` blocking_reasons.
 * The architecture lock test in `qualityGateLabels.test.ts` enforces
 * this.
 */
export const BLOCKING_REASON_LABELS = {
  locator_missing: "Some source blocks are missing locators",
  locator_duplicate: "Two or more source blocks share the same locator",
  structure_tree_flat: "Structure tree has no hierarchy",
  structure_tree_review_required: "Structure tree quality is below threshold",
  pandoc_unavailable: "Pandoc is not available on the server",
  pandoc_failed: "Pandoc projection failed",
  pandoc_reordered: "Pandoc emitted blocks in a different order than expected",
  mdformat_unavailable: "mdformat is not installed on the server",
  mdformat_plugin_missing: "mdformat's gfm plugin is missing",
  missing_required_artifacts: "Extraction service returned an incomplete artifact set",
  asset_unresolved: "An asset reference could not be resolved",
  review_flag_threshold_exceeded: "Review flag threshold exceeded",
  empty_document: "Document had no extractable content",
  input_too_large: "Input file exceeded the size limit",
  input_unsafe: "Input file failed safety checks",
  input_encrypted: "Input file is encrypted",
  input_format_legacy: "Input file is in a legacy format",
  input_corrupted: "Input file is corrupted",
} as const;

export type BlockingReasonCode = keyof typeof BLOCKING_REASON_LABELS;

/**
 * Map a blocking-reason code to a user-facing label. Unknown codes fall
 * back to a clear "Unknown reason: <code>" message — never silently
 * dropped, never humanized via generic case conversion (which produces
 * misleading output for codes like `mdformat_plugin_missing`).
 */
export function blockingReasonLabel(code: string): string {
  if (code in BLOCKING_REASON_LABELS) {
    return BLOCKING_REASON_LABELS[code as BlockingReasonCode];
  }
  return `Unknown reason: ${code}`;
}
