import { SourceBlock } from "./api";
import { parseLocator } from "./locator";

export type SourceViewerKind = "pdf" | "docx" | "text" | "html" | "unsupported";

export type SourceMatchCandidate = {
  key: string;
  text: string;
  docxParagraphIndex?: number;
  docxTableIndex?: number;
  docxRowIndex?: number;
  // Step E: nested-table row anchors carry the outer + inner indices so
  // the locator-first match can route `docx:tbl:O:r:R:tbl:I:r:M` to the
  // exact `<tr>` inside the nested `<table>`. The cell axis is not part
  // of the locator (inner tables are numbered cumulatively across all
  // cells of the outer row).
  docxOuterTableIndex?: number;
  docxOuterRowIndex?: number;
  docxInnerTableIndex?: number;
  docxInnerRowIndex?: number;
  // Step E: header/footer anchors carry their (section_id, paragraph_idx)
  // address. Section id charset is `[A-Za-z0-9_.-]+`, mirroring the Python
  // `_validate_section_id` rule.
  docxHeaderSectionId?: string;
  docxHeaderParagraphIndex?: number;
  docxFooterSectionId?: string;
  docxFooterParagraphIndex?: number;
};

export type SourceBlockMatch = {
  blockId: string;
  candidateKey: string | null;
  matchType: "locator" | "exact" | "contains" | "unmatched";
};

export function detectSourceViewerKind(filename: string, contentType?: string | null): SourceViewerKind {
  const lowerName = filename.toLowerCase();
  const lowerType = (contentType || "").toLowerCase();
  if (lowerType.includes("pdf") || lowerName.endsWith(".pdf")) return "pdf";
  if (
    lowerType.includes("wordprocessingml") ||
    lowerType.includes("msword") ||
    lowerName.endsWith(".docx")
  ) {
    return "docx";
  }
  if (
    lowerType.includes("html") ||
    lowerName.endsWith(".html") ||
    lowerName.endsWith(".htm")
  ) {
    return "html";
  }
  if (
    lowerType.startsWith("text/") ||
    lowerType.includes("markdown") ||
    lowerName.endsWith(".txt") ||
    lowerName.endsWith(".md")
  ) {
    return "text";
  }
  return "unsupported";
}

export function normalizeSourceText(value: string) {
  return value
    .normalize("NFKC")
    .toLowerCase()
    .replace(/\u00a0/g, " ")
    .replace(/[\u00ad\u200b]/g, "")
    .replace(/[\u202a-\u202e\u2066-\u2069]/g, "")
    .replace(/[–—]/g, "-")
    .replace(/…/g, "...")
    .replace(/[|•·]/g, " ")
    .replace(/[“”]/g, "\"")
    .replace(/[‘’]/g, "'")
    // H-audit-1 (Step H): NFKC at line 67 already decomposes these
    // presentation-form ligatures into their component letters (fi → f+i,
    // etc.). This replacement is defense-in-depth: kept for environments
    // where the input never went through a NFKC pass (rare, but possible
    // for text pasted out of clipboard before normalization). Cheap to
    // run, no behavior change vs. NFKC-normalized inputs.
    .replace(/[ﬁﬂﬀﬃﬄ]/g, (match) => {
      const replacements: Record<string, string> = { ﬁ: "fi", ﬂ: "fl", ﬀ: "ff", ﬃ: "ffi", ﬄ: "ffl" };
      return replacements[match] || match;
    })
    .replace(/\s+/g, " ")
    .trim();
}

export function blockSearchText(block: Pick<SourceBlock, "block_id" | "text" | "cells" | "block_type" | "source_location" | "review_flags">) {
  const cellText = block.cells?.map((cell) => cell.text).join(" ");
  const reviewText = block.review_flags
    ?.map((flag) => (typeof flag === "string" ? flag : [flag.code, flag.message, flag.severity].filter(Boolean).join(" ")))
    .join(" ");
  return [
    block.block_id,
    block.text,
    cellText,
    block.block_type,
    block.source_location?.section,
    reviewText,
  ].filter(Boolean).join(" ");
}

export function matchBlocksToCandidates(
  blocks: Array<Pick<SourceBlock, "block_id" | "text" | "cells" | "source_location" | "table_id" | "row_index">>,
  candidates: SourceMatchCandidate[],
): SourceBlockMatch[] {
  const normalizedCandidates = candidates.map((candidate) => ({
    ...candidate,
    normalized: normalizeSourceText(candidate.text),
  }));
  const results: SourceBlockMatch[] = [];
  let cursor = 0;
  const candidatesByDocxParagraph = new Map<number, SourceMatchCandidate>();
  const candidatesByDocxTableRow = new Map<string, SourceMatchCandidate>();
  const candidatesByDocxNestedRow = new Map<string, SourceMatchCandidate>();
  const candidatesByDocxHeader = new Map<string, SourceMatchCandidate>();
  const candidatesByDocxFooter = new Map<string, SourceMatchCandidate>();
  const normalizedByKey = new Map(normalizedCandidates.map((candidate) => [candidate.key, candidate] as const));
  let docxBodyIndexShift = 0;
  for (const candidate of candidates) {
    if (candidate.docxParagraphIndex !== undefined) {
      candidatesByDocxParagraph.set(candidate.docxParagraphIndex, candidate);
    }
    if (candidate.docxTableIndex !== undefined && candidate.docxRowIndex !== undefined) {
      candidatesByDocxTableRow.set(`${candidate.docxTableIndex}:${candidate.docxRowIndex}`, candidate);
    }
    if (
      candidate.docxOuterTableIndex !== undefined &&
      candidate.docxOuterRowIndex !== undefined &&
      candidate.docxInnerTableIndex !== undefined &&
      candidate.docxInnerRowIndex !== undefined
    ) {
      candidatesByDocxNestedRow.set(
        `${candidate.docxOuterTableIndex}:${candidate.docxOuterRowIndex}:${candidate.docxInnerTableIndex}:${candidate.docxInnerRowIndex}`,
        candidate,
      );
    }
    if (candidate.docxHeaderSectionId !== undefined && candidate.docxHeaderParagraphIndex !== undefined) {
      candidatesByDocxHeader.set(
        `${candidate.docxHeaderSectionId}:${candidate.docxHeaderParagraphIndex}`,
        candidate,
      );
    }
    if (candidate.docxFooterSectionId !== undefined && candidate.docxFooterParagraphIndex !== undefined) {
      candidatesByDocxFooter.set(
        `${candidate.docxFooterSectionId}:${candidate.docxFooterParagraphIndex}`,
        candidate,
      );
    }
  }

  for (const block of blocks) {
    const locator = parseLocator(block.source_location?.section);
    const blockText = blockComparableText(block);
    if (locator?.kind === "docx_p") {
      const shiftedCandidate = candidatesByDocxParagraph.get(locator.index + docxBodyIndexShift);
      if (shiftedCandidate && compatibleLocatorText(shiftedCandidate, normalizedByKey, blockText)) {
        results.push({ blockId: block.block_id, candidateKey: shiftedCandidate.key, matchType: "locator" });
        continue;
      }
      const candidate = candidatesByDocxParagraph.get(locator.index);
      if (candidate) {
        if (compatibleLocatorText(candidate, normalizedByKey, blockText)) {
          results.push({ blockId: block.block_id, candidateKey: candidate.key, matchType: "locator" });
          continue;
        }
        const recovered = recoverForwardDocxParagraphMatch(locator.index, blockText, candidatesByDocxParagraph, normalizedByKey);
        if (recovered) {
          docxBodyIndexShift = recovered.index - locator.index;
          results.push({ blockId: block.block_id, candidateKey: recovered.candidate.key, matchType: "locator" });
          continue;
        }
      }
    }
    if (locator?.kind === "docx_table_row") {
      const candidate =
        candidatesByDocxTableRow.get(`${locator.tableIndex + docxBodyIndexShift}:${locator.rowIndex}`) ||
        candidatesByDocxTableRow.get(`${locator.tableIndex}:${locator.rowIndex}`);
      if (candidate) {
        results.push({ blockId: block.block_id, candidateKey: candidate.key, matchType: "locator" });
        continue;
      }
    }
    if (locator?.kind === "docx_nested_table_row") {
      const candidate = candidatesByDocxNestedRow.get(
        `${locator.outerTableIndex}:${locator.outerRowIndex}:${locator.innerTableIndex}:${locator.innerRowIndex}`,
      );
      if (candidate) {
        results.push({ blockId: block.block_id, candidateKey: candidate.key, matchType: "locator" });
        continue;
      }
    }
    if (locator?.kind === "docx_header") {
      const candidate = candidatesByDocxHeader.get(`${locator.sectionId}:${locator.index}`);
      if (candidate) {
        results.push({ blockId: block.block_id, candidateKey: candidate.key, matchType: "locator" });
        continue;
      }
    }
    if (locator?.kind === "docx_footer") {
      const candidate = candidatesByDocxFooter.get(`${locator.sectionId}:${locator.index}`);
      if (candidate) {
        results.push({ blockId: block.block_id, candidateKey: candidate.key, matchType: "locator" });
        continue;
      }
    }
    if (locator && locator.kind.startsWith("docx_")) {
      results.push({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" });
      continue;
    }
    // Note: previously a `table_id`/`row_index` fallback existed here that
    // parsed `tbl_NNN` as a number and looked up the candidate by that
    // value. That value is the 1-based table SEQUENCE number, but the
    // candidate map keys on the table's BODY-INDEX (position among all
    // body elements). The two axes diverge for any document where the
    // first table isn't at body-position 1 — producing silent false
    // matches. The locator (`docx:tbl:{body_idx}:r:{row}`) is the canonical
    // bridge and was already emitted in Step 2 of the milestone, so the
    // off-axis fallback is dead weight that masks bugs. Removed in Step B.

    if (!blockText) {
      results.push({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" });
      continue;
    }

    const exactIndex = normalizedCandidates.findIndex(
      (candidate, index) => index >= cursor && candidate.normalized === blockText,
    );
    if (exactIndex >= 0) {
      cursor = exactIndex + 1;
      results.push({
        blockId: block.block_id,
        candidateKey: normalizedCandidates[exactIndex]!.key,
        matchType: "exact",
      });
      continue;
    }

    if (blockText.length >= 24) {
      const containing = normalizedCandidates
        .map((candidate, index) => ({ candidate, index }))
        .filter(({ candidate, index }) =>
          index >= cursor &&
          candidate.normalized.length > 0 &&
          (candidate.normalized.includes(blockText) || blockText.includes(candidate.normalized)),
        );
      if (containing.length === 1) {
        const match = containing[0]!;
        cursor = match.index + 1;
        results.push({
          blockId: block.block_id,
          candidateKey: match.candidate.key,
          matchType: "contains",
        });
        continue;
      }
    }

    results.push({ blockId: block.block_id, candidateKey: null, matchType: "unmatched" });
  }

  return results;
}

function blockComparableText(block: Pick<SourceBlock, "text" | "cells">) {
  return normalizeSourceText(
    block.cells?.length ? block.cells.map((cell) => cell.text).join(" ") : block.text,
  );
}

function compatibleLocatorText(
  candidate: SourceMatchCandidate,
  normalizedByKey: Map<string, SourceMatchCandidate & { normalized: string }>,
  blockText: string,
) {
  if (!blockText) return true;
  const candidateText = normalizedByKey.get(candidate.key)?.normalized || "";
  if (!candidateText) return false;
  return candidateText === blockText ||
    (blockText.length >= 24 && (candidateText.includes(blockText) || blockText.includes(candidateText)));
}

function recoverForwardDocxParagraphMatch(
  locatorIndex: number,
  blockText: string,
  candidatesByDocxParagraph: Map<number, SourceMatchCandidate>,
  normalizedByKey: Map<string, SourceMatchCandidate & { normalized: string }>,
) {
  if (!blockText) return null;
  for (let index = locatorIndex + 1; index <= locatorIndex + 3; index += 1) {
    const skipped = candidatesByDocxParagraph.get(index - 1);
    if (skipped && (normalizedByKey.get(skipped.key)?.normalized || "")) return null;
    const candidate = candidatesByDocxParagraph.get(index);
    if (!candidate) continue;
    if (compatibleLocatorText(candidate, normalizedByKey, blockText)) return { index, candidate };
  }
  return null;
}

export function sourceMatchStats(matches: SourceBlockMatch[]) {
  const matched = matches.filter((match) => match.candidateKey).length;
  return {
    matched,
    unmatched: matches.length - matched,
    total: matches.length,
  };
}

export function sourceMatchFailureIds(matches: SourceBlockMatch[]) {
  return matches
    .filter((match) => !match.candidateKey)
    .map((match) => match.blockId);
}
