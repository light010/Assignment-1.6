import {
  AlertTriangle,
  ExternalLink,
  FileText,
  RefreshCcw,
  ServerCog,
  ShieldAlert,
} from "lucide-react";
import { useMemo, useState } from "react";
import { ApiError, DocumentRecord, ExtractionReviewSummary, overrideDocumentGate, reextractDocument, SourceBlock, SourceQuality, sourceFileUrl, User } from "./api";
import { humanizeStatus, qualityGateDisplayName } from "./formatters";
import { blockingReasonLabel } from "./qualityGateLabels";

export function ExtractionFailedPanel({
  document,
  summary,
  user,
  refreshDocuments,
  onToast,
}: {
  document: DocumentRecord;
  summary: ExtractionReviewSummary | null;
  user: User;
  refreshDocuments: () => Promise<void>;
  onToast: (msg: string) => void;
}) {
  const isAdmin =
    user.roles.includes("org_admin") || user.roles.includes("project_admin");
  const [reextracting, setReextracting] = useState(false);
  const reason = summary?.extraction_failure_reason || document.extraction_failure_reason || "unknown";
  const stage = (document.source_quality as SourceQuality | undefined)?.extraction_error?.stage || document.extraction?.error?.stage || "extracting";

  async function handleReextract() {
    if (reextracting) return;
    setReextracting(true);
    try {
      await reextractDocument(document.document_id);
      await refreshDocuments();
      onToast("Re-extraction started.");
    } catch (err) {
      if (err instanceof ApiError && err.status === 429) {
        const retry = err.retryAfterSeconds ?? null;
        const window = retry !== null ? ` Retry in ${retry}s.` : "";
        onToast(`Re-extraction is throttled.${window}`);
      } else {
        onToast(`Re-extraction failed: ${(err as Error).message}`);
      }
    } finally {
      setReextracting(false);
    }
  }

  return (
    <div className="extraction-review-banner extraction-review-banner--failed" role="status">
      <div className="extraction-review-banner__head">
        <div>
          <strong>Extraction failed</strong>
          <p>Stage: {stage}. Reason: {humanizeStatus(reason)}.</p>
        </div>
        <div className="extraction-review-banner__actions">
          <a className="banner-action" href={sourceFileUrl(document.document_id)} target="_blank" rel="noreferrer">
            View upload
          </a>
          {isAdmin && (
            <button
              type="button"
              className="banner-action"
              onClick={handleReextract}
              disabled={reextracting}
              aria-busy={reextracting}
            >
              {reextracting ? "Re-extracting..." : "Re-extract"}
            </button>
          )}
        </div>
      </div>
      <p>Workbench review is unavailable until extraction succeeds. This panel surfaces the failure instead of an empty block tree.</p>
    </div>
  );
}

export function ExtractionNeedsReviewPanel({
  document,
  summary,
  gate,
  sourceBlocks = [],
  user,
  refreshDocuments,
  onToast,
  onSelectUnlocatedBlock,
  blockTextById,
}: {
  document: DocumentRecord;
  summary: ExtractionReviewSummary | null;
  gate: SourceQuality["quality_gate"] | null;
  sourceBlocks?: SourceBlock[];
  user: User;
  refreshDocuments: () => Promise<void>;
  onToast: (msg: string) => void;
  onSelectUnlocatedBlock?: (blockId: string) => void;
  blockTextById?: Map<string, string>;
}) {
  const isAdmin =
    user.roles.includes("org_admin") || user.roles.includes("project_admin");
  const [reextracting, setReextracting] = useState(false);
  const [showOverride, setShowOverride] = useState(false);
  const unlocated = summary?.unlocated_source_block_ids || [];
  const blockedGroups = summary?.blocked_groups || [];
  const reviewFlagCounts = summary?.review_flag_counts || {};
  const diagnosisGroups = useMemo(
    () => buildDiagnosisGroups({ blockedGroups, reviewFlagCounts, summary, gate, sourceBlocks }),
    [blockedGroups, gate, reviewFlagCounts, sourceBlocks, summary],
  );
  const [activeGroupCode, setActiveGroupCode] = useState("");
  const [activeBlockId, setActiveBlockId] = useState("");
  const activeGroup = diagnosisGroups.find((group) => group.code === activeGroupCode) || diagnosisGroups[0] || null;
  const selectedBlock = selectedDiagnosticBlock(sourceBlocks, activeBlockId, activeGroup);
  const hasSystemBlocker = diagnosisGroups.some((group) => group.kind === "system");
  const documentIssueCount = diagnosisGroups.filter((group) => group.kind === "document").length;
  const systemIssueCount = diagnosisGroups.filter((group) => group.kind === "system").length;
  const sourceBlockCount = summary?.block_count
    || document.extraction?.block_count
    || (document.source_quality as SourceQuality | undefined)?.block_count
    || sourceBlocks.length;
  const locatedBlockCount = summary?.located_block_count ?? Math.max(0, sourceBlockCount - unlocated.length);
  const blockingReasonCount = gate?.blocking_reasons.length || blockedGroups.length || diagnosisGroups.length || 1;
  const canReextractNow = !hasSystemBlocker;

  async function handleReextract() {
    if (reextracting || !canReextractNow) return;
    setReextracting(true);
    try {
      await reextractDocument(document.document_id);
      await refreshDocuments();
      onToast("Re-extraction started.");
    } catch (err) {
      if (err instanceof ApiError && err.status === 429) {
        // H1: explicit 429 path. The Retry-After header is captured by
        // the typed ApiError; surface it so the user knows how long to
        // wait rather than a generic "failed" toast.
        const retry = err.retryAfterSeconds ?? null;
        const window = retry !== null ? ` Retry in ${retry}s.` : "";
        onToast(`Re-extraction is throttled.${window}`);
      } else {
        onToast(`Re-extraction failed: ${(err as Error).message}`);
      }
    } finally {
      setReextracting(false);
    }
  }

  async function handleOverride(reason: string) {
    await overrideDocumentGate(document.document_id, reason);
    await refreshDocuments();
    onToast("Quality gate overridden.");
    setShowOverride(false);
  }

  function selectDiagnosisGroup(group: DiagnosisGroup) {
    setActiveGroupCode(group.code);
    setActiveBlockId(group.sampleBlockIds[0] || "");
  }

  function selectDiagnosticBlock(blockId: string) {
    setActiveBlockId(blockId);
    const owningGroup = diagnosisGroups.find((group) => group.sampleBlockIds.includes(blockId));
    if (owningGroup) setActiveGroupCode(owningGroup.code);
    onSelectUnlocatedBlock?.(blockId);
  }

  return (
    <section className="gated-workbench" aria-label="Extraction diagnostics">
      <div className="gated-workbench-summary" role="status">
        <div className="gated-workbench-summary__copy">
          <span className="label-sm">Workbench diagnostic mode</span>
          <strong>Extraction gated</strong>
          <p>
            {qualityGateDisplayName(gate?.name)} blocked downstream planning.
            Review the extracted evidence below before re-extracting or overriding the gate.
          </p>
        </div>
        <dl className="gated-workbench-metrics" aria-label="Gated extraction summary">
          <div>
            <dt>Source blocks</dt>
            <dd>{sourceBlockCount}</dd>
          </div>
          <div>
            <dt>Located</dt>
            <dd>{locatedBlockCount}/{sourceBlockCount}</dd>
          </div>
          <div>
            <dt>Blocking reasons</dt>
            <dd>{blockingReasonCount}</dd>
          </div>
        </dl>
      </div>

      <div className="gated-diagnostic-grid">
        <section className="gated-diagnostic-card" aria-label="Affected evidence groups">
          <header>
            <div>
              <span className="label-sm">Affected evidence</span>
              <strong>{diagnosisGroups.length || 0} review groups</strong>
            </div>
            <span>{documentIssueCount} document · {systemIssueCount} system</span>
          </header>
          <div className="gated-group-list">
            {diagnosisGroups.map((group) => (
              <button
                key={group.code}
                type="button"
                className={`gated-group-card severity-${group.severity}${activeGroup?.code === group.code ? " is-active" : ""}`}
                onClick={() => selectDiagnosisGroup(group)}
              >
                <span className={`gated-group-kind kind-${group.kind}`}>
                  {group.kind === "system" ? <ServerCog size={13} /> : <ShieldAlert size={13} />}
                  {group.kind === "system" ? "System dependency" : "Document evidence"}
                </span>
                <strong>{group.label}</strong>
                <small>{group.explanation}</small>
                <span className="gated-group-count">{group.count}</span>
              </button>
            ))}
            {diagnosisGroups.length === 0 && (
              <div className="gated-empty-state">No review groups were returned. Use the source block list and gate reasons to diagnose this document.</div>
            )}
          </div>
        </section>

        <section className="gated-diagnostic-card gated-block-detail" aria-label="Selected evidence detail">
          <header>
            <div>
              <span className="label-sm">Selected evidence</span>
              <strong>{activeGroup?.label || "Source block"}</strong>
            </div>
            {selectedBlock && <span>{blockTypeLabel(selectedBlock)}</span>}
          </header>
          {activeGroup?.kind === "system" && activeGroup.sampleBlockIds.length === 0 ? (
            <div className="gated-system-detail">
              <ServerCog size={18} aria-hidden />
              <div>
                <strong>{activeGroup.label}</strong>
                <p>{activeGroup.explanation}</p>
                <em>{activeGroup.action}</em>
              </div>
            </div>
          ) : selectedBlock ? (
            <>
              <div className="gated-block-copy">
                <FileText size={16} aria-hidden />
                <p>{blockDisplayText(selectedBlock)}</p>
              </div>
              <dl className="gated-block-meta">
                <div>
                  <dt>Type</dt>
                  <dd>{blockTypeLabel(selectedBlock)}</dd>
                </div>
                <div>
                  <dt>Source location</dt>
                  <dd>{sourceLocationLabel(selectedBlock)}</dd>
                </div>
                <div>
                  <dt>Review flags</dt>
                  <dd>{blockReviewFlagLabels(selectedBlock, summary).join(", ") || "No block flags"}</dd>
                </div>
              </dl>
              {activeGroup?.sampleBlockIds.length ? (
                <div className="gated-sample-list" aria-label="Sample affected source blocks">
                  <span className="label-sm">Sample blocks</span>
                  {activeGroup.sampleBlockIds.map((blockId) => {
                    const block = sourceBlocks.find((item) => item.block_id === blockId);
                    const label = block ? blockDisplayText(block) : chipLabel(blockTextById?.get(blockId), blockId);
                    return (
                      <button
                        key={blockId}
                        type="button"
                        className={blockId === selectedBlock.block_id ? "is-active" : ""}
                        onClick={() => selectDiagnosticBlock(blockId)}
                        title={label}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              ) : null}
            </>
          ) : (
            <div className="gated-empty-state">No block sample is available for this group.</div>
          )}
        </section>

        <aside className="gated-diagnostic-card gated-remediation" aria-label="Remediation actions">
          <header>
            <div>
              <span className="label-sm">Recommended action</span>
              <strong>{hasSystemBlocker ? "Restore extraction dependency" : "Re-extract after reviewing evidence"}</strong>
            </div>
          </header>
          <p>
            {hasSystemBlocker
              ? "A server-side extraction dependency is blocking reliable analysis. Re-extraction should wait until the dependency is restored."
              : "The blocker is document-evidence related. Review the affected blocks, then re-extract to rebuild the plan."}
          </p>
          <div className="gated-action-stack">
            <a className="banner-action" href={sourceFileUrl(document.document_id)} target="_blank" rel="noreferrer">
              View upload
            </a>
            {isAdmin && canReextractNow && (
              <button
                type="button"
                className="banner-action banner-action--primary"
                onClick={handleReextract}
                disabled={reextracting}
                aria-busy={reextracting}
              >
                <RefreshCcw size={13} aria-hidden />
                {reextracting ? "Re-extracting…" : "Re-extract"}
              </button>
            )}
            {isAdmin && !canReextractNow && (
              <button type="button" className="banner-action" disabled title="Resolve server dependency before re-extracting">
                <RefreshCcw size={13} aria-hidden />
                Re-extract unavailable
              </button>
            )}
            {isAdmin && (
              <button
                type="button"
                className="banner-action banner-action--override"
                onClick={() => setShowOverride(true)}
              >
                Override gate
              </button>
            )}
          </div>
          {gate && gate.blocking_reasons.length > 0 && (
            <div className="gated-rule-list">
              <span className="label-sm">Blocking rules</span>
              {gate.blocking_reasons.map((reason) => (
                <span key={reason}>
                  <AlertTriangle size={13} aria-hidden />
                  {blockingReasonDisplay(reason)}
                </span>
              ))}
            </div>
          )}
        </aside>
      </div>

      {unlocated.length > 0 && (
        <UnlocatedChips blockIds={unlocated} blockTextById={blockTextById} onSelectBlock={selectDiagnosticBlock} />
      )}
      {showOverride && (
        <OverrideGateDialog
          onCancel={() => setShowOverride(false)}
          onSubmit={handleOverride}
        />
      )}
    </section>
  );
}

const UNLOCATED_CHIP_CAP = 20;

type DiagnosisGroup = {
  code: string;
  label: string;
  severity: "info" | "warning" | "error";
  count: number;
  explanation: string;
  action: string;
  sampleBlockIds: string[];
  kind: "system" | "document";
};

function UnlocatedChips({
  blockIds,
  blockTextById,
  onSelectBlock,
}: {
  blockIds: string[];
  blockTextById?: Map<string, string>;
  onSelectBlock?: (blockId: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const shown = expanded ? blockIds : blockIds.slice(0, UNLOCATED_CHIP_CAP);
  const remainder = blockIds.length - shown.length;
  return (
    <div className="extraction-review-banner__chips" aria-label="Unlocated source blocks">
      <span className="chip-list-label">Unlocated:</span>
      {shown.map((blockId) => {
        const label = chipLabel(blockTextById?.get(blockId), blockId);
        if (!onSelectBlock) {
          return (
            <span
              key={blockId}
              className="chip-unlocated is-static"
              title={`Source block ${blockId}`}
              data-source-block-id={blockId}
            >
              <span>{label}</span>
            </span>
          );
        }
        return (
          <button
            key={blockId}
            type="button"
            className="chip-unlocated"
            onClick={() => onSelectBlock(blockId)}
            title={`Show ${blockId} in the Blocks view`}
            data-source-block-id={blockId}
          >
            <span>{label}</span>
            <ExternalLink size={12} aria-hidden />
          </button>
        );
      })}
      {(remainder > 0 || expanded) && (
        <button
          type="button"
          className="chip-show-more"
          onClick={() => setExpanded((value) => !value)}
        >
          {expanded ? "Show fewer" : `Show ${remainder} more`}
        </button>
      )}
    </div>
  );
}

function chipLabel(text: string | undefined, blockId: string) {
  const trimmed = (text || "").trim();
  if (!trimmed) return shortBlockId(blockId);
  return trimmed.length > 30 ? `${trimmed.slice(0, 27)}...` : trimmed;
}

function shortBlockId(blockId: string) {
  return blockId.length > 16 ? `Block ${blockId.slice(0, 8)}...${blockId.slice(-4)}` : blockId;
}

function buildDiagnosisGroups({
  blockedGroups,
  reviewFlagCounts,
  summary,
  gate,
  sourceBlocks,
}: {
  blockedGroups: ExtractionReviewSummary["blocked_groups"];
  reviewFlagCounts: Record<string, number>;
  summary: ExtractionReviewSummary | null;
  gate: SourceQuality["quality_gate"] | null;
  sourceBlocks: SourceBlock[];
}) {
  const groups = new Map<string, DiagnosisGroup>();
  blockedGroups.forEach((group) => {
    if (!group.label.trim() || group.count <= 0) return;
    const severity = normalizedSeverity(group.severity);
    const label = groupDisplayLabel(group.code, group.label);
    const kind = issueKind(group.code, label);
    groups.set(group.code, {
      code: group.code,
      label,
      severity,
      count: group.count,
      explanation: kind === "system" ? defaultGroupExplanation(label, group.code) : summary?.catalog[group.code]?.explanation || defaultGroupExplanation(label, group.code),
      action: kind === "system" ? defaultGroupAction(group.code) : summary?.catalog[group.code]?.action || defaultGroupAction(group.code),
      sampleBlockIds: group.sample_block_ids.slice(0, 8),
      kind,
    });
  });
  Object.entries(reviewFlagCounts).forEach(([code, count]) => {
    if (count <= 0 || groups.has(code)) return;
    const catalog = summary?.catalog[code];
    const label = catalog?.label || code;
    if (!label.trim()) return;
    const severity = normalizedSeverity(catalog?.severity || "warning");
    groups.set(code, {
      code,
      label,
      severity,
      count,
      explanation: catalog?.explanation || defaultGroupExplanation(label, code),
      action: catalog?.action || defaultGroupAction(code),
      sampleBlockIds: sourceBlocks.filter((block) => blockHasReviewFlag(block, code)).map((block) => block.block_id).slice(0, 8),
      kind: issueKind(code, label),
    });
  });
  for (const reason of gate?.blocking_reasons || []) {
    if (groups.has(reason)) continue;
    const label = blockingReasonDisplay(reason);
    groups.set(reason, {
      code: reason,
      label,
      severity: "error",
      count: 1,
      explanation: defaultGroupExplanation(label, reason),
      action: defaultGroupAction(reason),
      sampleBlockIds: [],
      kind: issueKind(reason, label),
    });
  }
  if (groups.size === 0 && sourceBlocks.length > 0) {
    groups.set("available-source-blocks", {
      code: "available-source-blocks",
      label: "Available source blocks",
      severity: "info",
      count: sourceBlocks.length,
      explanation: "Extraction returned source blocks, but no grouped diagnostic was provided.",
      action: "Inspect the extracted blocks and retry extraction when the blocker is resolved.",
      sampleBlockIds: sourceBlocks.slice(0, 8).map((block) => block.block_id),
      kind: "document",
    });
  }
  return Array.from(groups.values()).sort((a, b) => {
    const systemOrder = Number(b.kind === "system") - Number(a.kind === "system");
    return systemOrder || severityRank(b.severity) - severityRank(a.severity) || b.count - a.count || a.label.localeCompare(b.label);
  });
}

function normalizedSeverity(value: string): DiagnosisGroup["severity"] {
  return value === "error" || value === "warning" || value === "info" ? value : "warning";
}

function severityRank(value: string) {
  if (value === "error") return 3;
  if (value === "warning") return 2;
  return 1;
}

function issueKind(code: string, label: string): DiagnosisGroup["kind"] {
  return /(pandoc|server|runtime|dependency|unavailable|extractor|service)/i.test(`${code} ${label}`)
    ? "system"
    : "document";
}

function groupDisplayLabel(code: string, label: string) {
  const text = `${code} ${label}`;
  if (/pandoc.*unavailable|unavailable.*pandoc/i.test(text)) return "Pandoc is not available on the server";
  if (/structure.*tree.*flat|no.*hierarchy/i.test(text)) return "Structure tree has no hierarchy";
  return label;
}

function defaultGroupExplanation(label: string, code: string) {
  if (issueKind(code, label) === "system") {
    return "A server-side extraction dependency prevented reliable source analysis.";
  }
  return "This document evidence needs review before downstream planning can proceed.";
}

function defaultGroupAction(code: string) {
  return issueKind(code, code) === "system"
    ? "Restore the dependency, then re-run extraction."
    : "Inspect the affected source blocks, then re-run extraction.";
}

function blockHasReviewFlag(block: SourceBlock, code: string) {
  return (block.review_flags || []).some((flag) => reviewFlagCode(flag) === code);
}

function reviewFlagCode(flag: unknown) {
  if (typeof flag === "string") return flag;
  if (!flag || typeof flag !== "object") return "";
  const raw = flag as { code?: unknown };
  return typeof raw.code === "string" ? raw.code : "";
}

function selectedDiagnosticBlock(blocks: SourceBlock[], activeBlockId: string, group: DiagnosisGroup | null) {
  const explicit = blocks.find((block) => block.block_id === activeBlockId);
  if (explicit) return explicit;
  if (group && group.sampleBlockIds.length > 0) {
    return blocks.find((block) => group.sampleBlockIds.includes(block.block_id)) || null;
  }
  if (group?.kind === "system") return null;
  return blocks[0] || null;
}

function blockDisplayText(block: SourceBlock) {
  const text = (block.text || block.cells?.map((cell) => cell.text).join(" | ") || "").trim();
  if (!text) return "Blank source block";
  if (text.length <= 160) return text;
  const boundary = text.slice(0, 157).replace(/\s+\S*$/, "");
  return `${boundary || text.slice(0, 157)}...`;
}

function blockTypeLabel(block: SourceBlock) {
  return humanizeStatus(block.block_type || block.type || "source_block");
}

function sourceLocationLabel(block: SourceBlock) {
  const page = typeof block.source_location?.page === "number" ? `Page ${block.source_location.page}` : "";
  const section = block.source_location?.section || "";
  return [page, section].filter(Boolean).join(" · ") || "Source location unavailable";
}

function blockReviewFlagLabels(block: SourceBlock, summary: ExtractionReviewSummary | null) {
  return (block.review_flags || []).map((flag) => {
    const code = reviewFlagCode(flag);
    if (!code) return "";
    return summary?.catalog[code]?.label || code;
  }).filter(Boolean);
}

function blockingReasonDisplay(reason: string) {
  const label = blockingReasonLabel(reason);
  return label.startsWith("Unknown reason:") ? humanizeStatus(reason) : label;
}

function OverrideGateDialog({
  onCancel,
  onSubmit,
}: {
  onCancel: () => void;
  onSubmit: (reason: string) => Promise<void>;
}) {
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  // H2: server schema enforces minLength 1; the UI uses 5 to encourage
  // a meaningful audit trail. Without this the override_history entries
  // would be useless (every reviewer typing "ok" leaves no actionable
  // record).
  const MIN_REASON_LEN = 5;
  const valid = reason.trim().length >= MIN_REASON_LEN;

  async function handleSubmit() {
    if (!valid || submitting) return;
    setSubmitting(true);
    setError("");
    try {
      await onSubmit(reason.trim());
    } catch (err) {
      setError((err as Error).message);
      setSubmitting(false);
    }
  }

  return (
    <div className="override-dialog" role="dialog" aria-modal="true" aria-label="Override quality gate">
      <div className="override-dialog__body">
        <h3>Override quality gate</h3>
        <p>
          Overriding the gate releases this document for review even though
          extraction signals say it needs attention. Your reason is
          captured in the gate's override history (including the
          pre-override blocking reasons) so reviewers can audit later.
        </p>
        <label htmlFor="override-reason">Reason (min {MIN_REASON_LEN} chars)</label>
        <textarea
          id="override-reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={4}
          aria-invalid={reason.length > 0 && !valid}
          autoFocus
        />
        {error && <p className="override-dialog__error">{error}</p>}
        <div className="override-dialog__actions">
          <button type="button" onClick={onCancel} disabled={submitting}>
            Cancel
          </button>
          <button
            type="button"
            className="banner-action banner-action--override"
            onClick={handleSubmit}
            disabled={!valid || submitting}
            aria-busy={submitting}
          >
            {submitting ? "Overriding…" : "Override"}
          </button>
        </div>
      </div>
    </div>
  );
}
