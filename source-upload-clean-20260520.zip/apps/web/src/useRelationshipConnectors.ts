import { MutableRefObject, RefObject, useCallback, useLayoutEffect, useRef, useState } from "react";
import { WorkbenchState } from "./workbenchModel";

export type Connector = {
  id: string;
  d: string;
  tone: "active" | "selected";
};

type RectLike = {
  top: number;
  right: number;
  left: number;
  height: number;
};

export function useConnectorPaths({
  state,
  overlayRef,
  sourceRefs,
  unitRefs,
  selectedSourceIds,
  activeSourceIds,
  selectedUnitIds,
  geometryVersion = 0,
}: {
  state: WorkbenchState | null;
  overlayRef: RefObject<HTMLDivElement | null>;
  sourceRefs: MutableRefObject<Map<string, HTMLElement>>;
  unitRefs: MutableRefObject<Map<string, HTMLElement>>;
  selectedSourceIds: string[];
  activeSourceIds: string[];
  selectedUnitIds: string[];
  geometryVersion?: number;
}) {
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const frameRef = useRef<number | null>(null);

  const recomputeConnectors = useCallback(() => {
    const overlay = overlayRef.current;
    if (!overlay || !state) {
      setConnectors((current) => (current.length ? [] : current));
      return;
    }
    const overlayRect = overlay.getBoundingClientRect();
    const sourceRects = new Map<string, RectLike>();
    const unitRects = new Map<string, RectLike>();
    sourceRefs.current.forEach((element, blockId) => sourceRects.set(blockId, element.getBoundingClientRect()));
    unitRefs.current.forEach((element, unitId) => unitRects.set(unitId, element.getBoundingClientRect()));
    const next = buildRelationshipConnectors({
      state,
      overlayRect,
      sourceRects,
      unitRects,
      selectedSourceIds,
      activeSourceIds,
      selectedUnitIds,
    });
    setConnectors((current) => (connectorsEqual(current, next) ? current : next));
  }, [activeSourceIds, geometryVersion, overlayRef, selectedSourceIds, selectedUnitIds, sourceRefs, state, unitRefs]);

  const scheduleRecompute = useCallback(() => {
    if (frameRef.current !== null) return;
    frameRef.current = window.requestAnimationFrame(() => {
      frameRef.current = null;
      recomputeConnectors();
    });
  }, [recomputeConnectors]);

  useLayoutEffect(() => {
    scheduleRecompute();
    const observer = new ResizeObserver(scheduleRecompute);
    if (overlayRef.current) observer.observe(overlayRef.current);
    window.addEventListener("resize", scheduleRecompute);
    window.addEventListener("scroll", scheduleRecompute, true);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", scheduleRecompute);
      window.removeEventListener("scroll", scheduleRecompute, true);
      if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    };
  }, [overlayRef, scheduleRecompute]);

  return connectors;
}

export const useRelationshipConnectors = useConnectorPaths;

export function buildRelationshipConnectors({
  state,
  overlayRect,
  sourceRects,
  unitRects,
  selectedSourceIds,
  activeSourceIds,
  selectedUnitIds,
}: {
  state: WorkbenchState;
  overlayRect: RectLike;
  sourceRects: Map<string, RectLike>;
  unitRects: Map<string, RectLike>;
  selectedSourceIds: string[];
  activeSourceIds: string[];
  selectedUnitIds: string[];
}) {
  const next: Connector[] = [];
  const sourceIds = selectedSourceIds.length ? selectedSourceIds : activeSourceIds;
  const unitIds = selectedUnitIds.length
    ? selectedUnitIds
    : findUnitsForSourceIds(state, sourceIds).map((unit) => unit.unit_id);
  for (const unitId of unitIds) {
    const unit = findUnitById(state, unitId);
    const unitRect = unitRects.get(unitId);
    if (!unit || !unitRect) continue;
    for (const blockId of unit.source_block_ids) {
      if (sourceIds.length && !sourceIds.includes(blockId)) continue;
      const sourceRect = sourceRects.get(blockId);
      if (!sourceRect) continue;
      const startX = sourceRect.right - overlayRect.left;
      const startY = sourceRect.top + sourceRect.height / 2 - overlayRect.top;
      const endX = unitRect.left - overlayRect.left;
      const endY = unitRect.top + unitRect.height / 2 - overlayRect.top;
      const mid = Math.max(42, Math.abs(endX - startX) * 0.42);
      next.push({
        id: `${blockId}-${unitId}`,
        tone: selectedUnitIds.includes(unitId) ? "selected" : "active",
        d: `M ${startX} ${startY} C ${startX + mid} ${startY}, ${endX - mid} ${endY}, ${endX} ${endY}`,
      });
    }
  }
  return next;
}

function findUnitsForSourceIds(state: WorkbenchState, sourceIds: string[]) {
  if (sourceIds.length === 0) return [];
  return state.topics.flatMap((topic) =>
    topic.units.filter((unit) => unit.source_block_ids.some((blockId) => sourceIds.includes(blockId))),
  );
}

function findUnitById(state: WorkbenchState, unitId: string) {
  for (const topic of state.topics) {
    const unit = topic.units.find((item) => item.unit_id === unitId);
    if (unit) return unit;
  }
  return null;
}

function connectorsEqual(left: Connector[], right: Connector[]) {
  if (left.length !== right.length) return false;
  return left.every((connector, index) => {
    const other = right[index];
    return other && connector.id === other.id && connector.d === other.d && connector.tone === other.tone;
  });
}
