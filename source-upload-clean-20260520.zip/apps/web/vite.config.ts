import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Centralised dev config so port semantics aren't an implicit npm-script
// detail. `strictPort: true` turns the "port already in use" case from
// a silent fallback (5173 → 5174) into a hard error — preventing the
// situation where a stale Vite keeps serving the old bundle on 5173
// while the "fresh" one quietly lives on 5174.
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: true,
  },
});
