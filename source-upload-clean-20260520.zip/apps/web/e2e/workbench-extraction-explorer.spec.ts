import { expect, Page, test } from "@playwright/test";

const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const apiUrl = process.env.DITAGEN_API_BASE_URL || process.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";
const documentName = process.env.DITAGEN_E2E_DOCUMENT || "Apple CA (PSC).docx";
const customerChangeRequestsName = process.env.DITAGEN_E2E_CUSTOMER_CHANGE_REQUESTS || "Customer Change Requests.docx";
const blockedDocumentName = process.env.DITAGEN_E2E_BLOCKED_DOCUMENT || "Reprocessing FundDirect File Created with Error.docx";

test("Apple CA Workbench extraction explorer syncs source blocks, source anchors, and keyboard navigation", async ({ page }) => {
  const pageErrors: string[] = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));

  await openAppleWorkbench(page);

  await expect(page.getByRole("tab", { name: "Source" })).toHaveCount(0);
  await expect(page.getByRole("tab", { name: "Workbench" })).toHaveAttribute("aria-selected", "true");
  await expect(page.locator(".extraction-explorer-shell")).toBeVisible();
  await expect(page.getByRole("heading", { name: "Blocks" })).toBeVisible();
  await expect(page.getByRole("tree", { name: "Extracted source blocks" })).toBeVisible();
  await expect.poll(async () => {
    const [sourceBox, explorerBox] = await Promise.all([
      page.locator(".source-evidence-viewer").boundingBox(),
      page.locator(".extraction-explorer-shell").boundingBox(),
    ]);
    if (!sourceBox || !explorerBox) return Number.POSITIVE_INFINITY;
    return Math.abs(sourceBox.height - explorerBox.height);
  }).toBeLessThanOrEqual(1);
  await expect(page.locator(".cockpit, .topic-filmstrip")).toHaveCount(0);
  await expect(page.locator("select[aria-label='Topic type']")).toHaveCount(0);

  await expect.poll(() => page.getByRole("treeitem").count()).toBeGreaterThan(40);
  await expect.poll(() => page.locator("[data-source-block-id]").count()).toBeGreaterThan(20);

  const tableGroup = page.locator(".extraction-row.kind-table").first();
  await tableGroup.click();
  await expect(page.locator(".extraction-row.active")).toHaveClass(/kind-table/);

  await page.keyboard.press("ArrowLeft");
  await expect(page.locator(".extraction-row.active")).toHaveClass(/kind-table/);
  await page.keyboard.press("ArrowRight");
  await expect(page.locator(".extraction-row.active")).toHaveClass(/kind-table/);
  await page.keyboard.press("ArrowRight");
  await expect(page.locator(".extraction-row.active")).toHaveClass(/kind-table_row/);

  await page.keyboard.press("ArrowLeft");
  await expect(page.locator(".extraction-row.active")).toHaveClass(/kind-table/);

  const sourceRow = page.locator(".extraction-row.kind-table_row, .extraction-row.kind-paragraph").first();
  await sourceRow.scrollIntoViewIfNeeded();
  await sourceRow.click();
  await expect(page.locator(".extraction-row.active")).not.toHaveClass(/kind-document/);
  await expect.poll(() => page.locator(".source-viewer-active").count()).toBeGreaterThan(0);

  const sourceAnchor = page.locator("[data-source-block-id]").nth(5);
  await sourceAnchor.scrollIntoViewIfNeeded();
  const sourceBlockId = await sourceAnchor.getAttribute("data-source-block-id");
  expect(sourceBlockId).toBeTruthy();
  await sourceAnchor.click();

  await expect(page.locator(".extraction-row.active")).toHaveCount(1);
  await expect(page.locator(`.source-viewer-active[data-source-block-id="${sourceBlockId}"]`)).toHaveCount(1);
  await expect(page.locator(".extraction-row.active")).toBeInViewport();

  expect(pageErrors).toEqual([]);
});

test("Customer Change Requests docx:p:35 maps to source highlight", async ({ page }) => {
  await openWorkbenchDocument(page, customerChangeRequestsName);
  await expect(page.locator(".extraction-explorer-shell")).toBeVisible();
  await waitForSourceAnchors(page);

  const document = await findDocument(page, customerChangeRequestsName);
  const blocks = await fetchBlocks(page, document.document_id);
  const canary = blocks.find((block) => block.source_location?.section === "docx:p:35");
  expect(canary, "expected Customer Change Requests fixture to include docx:p:35").toBeTruthy();

  const row = page.locator(`.extraction-row[data-source-block-id="${cssAttr(canary!.block_id)}"]`).first();
  await row.scrollIntoViewIfNeeded();
  await row.click();

  await expect(page.locator(`.source-viewer-active[data-source-block-id="${cssAttr(canary!.block_id)}"]`)).toHaveCount(1);
  await expect(page.locator(".extraction-match-failure-banner")).toHaveCount(0);
});

test("ready document does not show match-failure banner", async ({ page }) => {
  await openWorkbenchDocument(page, documentName);
  await waitForSourceAnchors(page);

  await expect(page.locator(".extraction-match-failure-banner")).toHaveCount(0);
});

test("ready Workbench stacks into equal-height readable panes at tablet width", async ({ page }) => {
  await page.setViewportSize({ width: 900, height: 900 });
  await openWorkbenchDocument(page, "Updating the Payroll Schedule.docx");
  await waitForSourceAnchors(page);

  await expect(page.getByRole("tab", { name: "Source" })).toHaveCount(0);
  await expect(page.getByRole("tab", { name: "Workbench" })).toHaveAttribute("aria-selected", "true");
  await expect(page.locator(".source-original-scroll")).toBeVisible();
  await expect(page.locator(".extraction-section-overview")).toBeVisible();
  await expect.poll(async () => {
    const [sourceBox, explorerBox] = await Promise.all([
      page.locator(".source-evidence-viewer").boundingBox(),
      page.locator(".extraction-explorer-shell").boundingBox(),
    ]);
    if (!sourceBox || !explorerBox) return Number.POSITIVE_INFINITY;
    return Math.abs(sourceBox.height - explorerBox.height);
  }).toBeLessThanOrEqual(1);
  await expect.poll(async () => {
    const sourceBox = await page.locator(".source-evidence-viewer").boundingBox();
    return sourceBox?.width || 0;
  }).toBeGreaterThan(700);
});

test("blocked document lands on Workbench with extraction-needs-review panel", async ({ page }) => {
  const consoleErrors: string[] = [];
  page.on("console", (message) => {
    if (message.type() === "error") consoleErrors.push(message.text());
  });
  page.on("pageerror", (error) => consoleErrors.push(error.message));

  await openDocumentDetails(page, blockedDocumentName);
  const document = await findDocument(page, blockedDocumentName);
  const summary = await apiGet(page, `/v1/documents/${document.document_id}/extraction-review-summary`);

  await expect(page.getByRole("tab", { name: "Source" })).toHaveCount(0);
  const workbenchTab = page.getByRole("tab", { name: "Workbench" });
  await expect(workbenchTab).toHaveAttribute("aria-selected", "true");
  await expect(workbenchTab).toHaveAttribute("aria-disabled", "false");
  await expect(page.getByRole("tab", { name: "Plan Blocked" })).toHaveAttribute("aria-disabled", "true");
  await expect(page.getByText("Extraction gated")).toBeVisible();
  await expect(page.getByText("Workbench diagnostic mode")).toBeVisible();
  await expect(page.getByLabel("Gated extraction summary")).toContainText(String(summary.block_count));
  await expect(page.getByLabel("Affected evidence groups")).toBeVisible();
  await expect(page.getByLabel("Selected evidence detail")).toBeVisible();
  await expect(page.getByLabel("Remediation actions")).toBeVisible();
  expect(summary.block_count).toBeGreaterThan(0);
  expect(consoleErrors).toEqual([]);
});

async function openAppleWorkbench(page: Page) {
  await openWorkbenchDocument(page, documentName);
}

async function openWorkbenchDocument(page: Page, filename: string) {
  await openDocumentDetails(page, filename);
  await page.getByRole("heading", { name: "Blocks" }).waitFor();
}

async function openDocumentDetails(page: Page, filename: string) {
  await page.goto("/");
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }

  await page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") }).click();
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor();
  await search.fill(filename);
  await page.getByText(filename).waitFor();
  await page.locator(".upload-row").filter({ hasText: filename }).click();

  await page.getByRole("heading", { name: filename, exact: true }).waitFor();
}

async function waitForSourceAnchors(page: Page) {
  await expect.poll(() => page.locator("[data-source-block-id]").count()).toBeGreaterThan(0);
}

async function findDocument(page: Page, filename: string): Promise<{ document_id: string; filename: string }> {
  const businessUnits = await apiGet(page, "/v1/business-units");
  const businessUnit = businessUnits.business_units.find((unit: { name: string }) => unit.name === businessUnitName);
  expect(businessUnit, `business unit ${businessUnitName} exists`).toBeTruthy();
  const payload = await apiGet(page, `/v1/business-units/${businessUnit.business_unit_id}/documents`);
  const document = payload.documents.find((item: { filename: string }) => item.filename === filename);
  expect(document, `document ${filename} exists`).toBeTruthy();
  return document;
}

async function fetchBlocks(page: Page, documentId: string): Promise<Array<{
  block_id: string;
  source_location?: { section?: string | null };
}>> {
  const blocks = [];
  let cursor = "";
  do {
    const suffix = cursor ? `&cursor=${encodeURIComponent(cursor)}` : "";
    const payload = await apiGet(page, `/v1/documents/${documentId}/blocks?limit=100${suffix}`);
    blocks.push(...payload.items);
    cursor = payload.next_cursor || "";
  } while (cursor);
  return blocks;
}

async function apiGet(page: Page, apiPath: string) {
  const token = await page.evaluate(() => localStorage.getItem("ditagen.access_token") || "");
  const response = await page.request.get(`${apiUrl}${apiPath}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  expect(response.ok(), `GET ${apiPath} returned ${response.status()}`).toBeTruthy();
  return response.json();
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function cssAttr(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
