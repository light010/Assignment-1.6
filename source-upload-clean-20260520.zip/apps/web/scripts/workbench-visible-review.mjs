import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const appUrl = process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173";
const apiUrl = process.env.DITAGEN_API_BASE_URL || "http://127.0.0.1:8000";
const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const outDir = process.env.WORKBENCH_REVIEW_OUT || "/private/tmp/workbench-visible-review";
const slowMo = Number(process.env.PW_SLOWMO || 250);
const includeApple = process.env.INCLUDE_APPLE === "1";
const maxDocs = Number(process.env.MAX_DOCS || 0);

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../../..");
const feedbackDir = path.join(root, "docs/product/workbench-feedback");
const resultsPath = path.join(feedbackDir, "_visual-results.json");

await fs.mkdir(outDir, { recursive: true });

const token = await apiLogin();
const businessUnit = await apiGet(token, "/v1/business-units").then((payload) =>
  payload.business_units.find((unit) => unit.name === businessUnitName),
);
if (!businessUnit) {
  throw new Error(`Could not find business unit ${businessUnitName}`);
}
const documentsPayload = await apiGet(token, `/v1/business-units/${businessUnit.business_unit_id}/documents`);
let documents = documentsPayload.documents
  .filter((document) => includeApple || document.filename !== "Apple CA (PSC).docx")
  .sort((a, b) => a.filename.localeCompare(b.filename));
if (maxDocs > 0) documents = documents.slice(0, maxDocs);

const browser = await chromium.launch({
  headless: false,
  slowMo,
});
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const results = [];

try {
  await signIn(page);
  for (const document of documents) {
    const result = await reviewDocument(page, token, document);
    results.push(result);
    await fs.writeFile(resultsPath, JSON.stringify(results, null, 2));
    console.log(JSON.stringify({
      document: document.filename,
      status: document.status,
      visual_status: result.visual_status,
      screenshot: result.screenshot,
      checks: result.checks,
      error: result.error || null,
    }));
  }
} finally {
  await browser.close();
}

async function reviewDocument(page, token, document) {
  const slug = slugify(document.filename.replace(/\.docx$/i, ""));
  const result = {
    document_id: document.document_id,
    filename: document.filename,
    status: document.status,
    slug,
    visual_status: "pending",
    screenshot: "",
    checks: {},
    errors: [],
  };

  try {
    await openBusinessUnit(page);
    await openDocument(page, document.filename);
    await page.getByRole("heading", { name: document.filename }).waitFor({ timeout: 20_000 });

    if (document.status !== "ready_for_review") {
      result.visual_status = "blocked_by_document_status";
      result.checks.sourceAvailable = await page.getByRole("tab", { name: "Source" }).isVisible();
      result.checks.workbenchAvailable = await page.getByRole("tab", { name: "Workbench" }).isEnabled().catch(() => false);
      result.screenshot = await screenshot(page, `${slug}-blocked.png`);
      return result;
    }

    await page.getByRole("tab", { name: "Workbench" }).click();
    await page.locator(".extraction-explorer-shell").waitFor({ timeout: 30_000 });
    await waitForSourcePreview(page);

    const blocks = await fetchBlocks(token, document.document_id);
    const nonHeadingBlock = blocks.find((block) => block.block_type !== "heading" && block.text?.trim());
    const searchText = searchablePhrase(nonHeadingBlock?.text || document.filename);

    result.checks.explorerVisible = await page.locator(".extraction-explorer-shell").isVisible();
    result.checks.heading = await page.getByRole("heading", { name: /\d+\s+source blocks/i }).first().innerText();
    result.checks.matchedText = await sourceStatusText(page);
    result.checks.topicControlsAbsent = (await page.locator("select[aria-label='Topic type'], .cockpit, .topic-filmstrip").count()) === 0;
    result.checks.sourceAnchorCount = await page.locator("[data-source-block-id]").count();
    result.checks.treeItemCount = await page.getByRole("treeitem").count();

    await clickFirstReviewableRow(page);
    result.checks.rowClickActiveSourceCount = await page.locator(".source-viewer-active").count();
    result.checks.activeRowAfterRowClick = await activeRowText(page);

    const sourceAnchor = page.locator("[data-source-block-id]").nth(Math.min(4, Math.max(0, result.checks.sourceAnchorCount - 1)));
    if (await sourceAnchor.count()) {
      await sourceAnchor.scrollIntoViewIfNeeded();
      const sourceBlockId = await sourceAnchor.getAttribute("data-source-block-id");
      await sourceAnchor.click();
      result.checks.sourceClickSelectedBlockId = sourceBlockId;
      result.checks.sourceClickActiveRows = await page.locator(".extraction-row.active").count();
      result.checks.sourceClickActiveSourceCount = await page.locator(`.source-viewer-active[data-source-block-id="${sourceBlockId}"]`).count();
    }

    const attentionToggle = page.getByRole("button", { name: /Attention only/i });
    await attentionToggle.click();
    result.checks.attentionTreeItemCount = await page.getByRole("treeitem").count();
    result.checks.attentionEmptyVisible = await page.getByText("No extraction attention items.").isVisible().catch(() => false);
    await attentionToggle.click();

    const searchInput = page.getByPlaceholder("Search extracted anchors");
    await searchInput.fill(searchText);
    await page.waitForTimeout(600);
    result.checks.searchText = searchText;
    result.checks.searchTreeItemCount = await page.getByRole("treeitem").count();
    await searchInput.fill("");

    await clickFirstReviewableRow(page);
    const beforeKeyboard = await activeRowText(page);
    await page.keyboard.press("ArrowDown");
    await page.waitForTimeout(250);
    result.checks.keyboardBefore = beforeKeyboard;
    result.checks.keyboardAfter = await activeRowText(page);
    result.checks.keyboardActiveSourceCount = await page.locator(".source-viewer-active").count();

    result.screenshot = await screenshot(page, `${slug}.png`);
    result.visual_status = "complete";
  } catch (error) {
    result.visual_status = "failed";
    result.error = error instanceof Error ? error.message : String(error);
    result.screenshot = await screenshot(page, `${slug}-failed.png`).catch(() => "");
  }
  return result;
}

async function signIn(page) {
  await page.goto(appUrl);
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }
  await page.getByRole("heading", { name: "Business Units" }).waitFor({ timeout: 30_000 });
}

async function openBusinessUnit(page) {
  await page.goto(appUrl);
  const signInButton = page.getByRole("button", { name: /^Sign in$/ });
  if (await signInButton.isVisible().catch(() => false)) {
    await signIn(page);
  }
  const documentSearch = page.locator("input[placeholder='Search documents by name']").first();
  const breadcrumbButton = page.getByRole("button", { name: businessUnitName }).first();
  const card = page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") });
  const route = await Promise.race([
    documentSearch.waitFor({ state: "visible", timeout: 30_000 }).then(() => "document-list"),
    breadcrumbButton.waitFor({ state: "visible", timeout: 30_000 }).then(() => "breadcrumb"),
    card.waitFor({ state: "visible", timeout: 30_000 }).then(() => "business-units"),
  ]).catch(() => null);
  if (route === "document-list") {
    return;
  }
  if (route === "breadcrumb") {
    await breadcrumbButton.click();
    await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
    return;
  }
  if (route !== "business-units") {
    throw new Error(`Could not reach ${businessUnitName} document list`);
  }
  await card.click();
  await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
}

async function openDocument(page, filename) {
  await page.getByText("Earlier").waitFor({ timeout: 30_000 }).catch(async () => {});
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor({ state: "visible", timeout: 30_000 });
  await search.click();
  await search.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await search.fill(filename);
  await page.waitForTimeout(800);
  const row = page.locator(".upload-row").filter({ hasText: filename }).first();
  await row.waitFor({ state: "visible", timeout: 30_000 });
  await row.click({ position: { x: 80, y: 24 } });
}

async function clickFirstReviewableRow(page) {
  const row = page.locator(
    ".extraction-row.kind-table_row, .extraction-row.kind-paragraph, .extraction-row.kind-list_item, .extraction-row.kind-procedure_step, .extraction-row.kind-note, .extraction-row.kind-resource",
  ).first();
  await row.waitFor({ state: "visible", timeout: 20_000 });
  await row.scrollIntoViewIfNeeded();
  await row.click();
}

async function sourceStatusText(page) {
  return page.locator(".source-viewer-status, [aria-label='Source viewer status']").first().innerText().catch(async () => "");
}

async function waitForSourcePreview(page) {
  await page
    .waitForFunction(() => {
      const text = document.body.innerText;
      const hasStatus = /\d+\s*\/\s*\d+\s*matched/i.test(text);
      const hasAnchor = document.querySelectorAll("[data-source-block-id]").length > 0;
      return hasStatus && hasAnchor;
    }, { timeout: 30_000 })
    .catch(async () => {
      await page.waitForTimeout(2_000);
    });
}

async function activeRowText(page) {
  return page.locator(".extraction-row.active").first().innerText().catch(async () => "");
}

async function screenshot(page, name) {
  const file = path.join(outDir, name);
  await page.screenshot({ path: file, fullPage: false });
  return file;
}

async function fetchBlocks(token, documentId) {
  const blocks = [];
  let cursor = "";
  do {
    const suffix = cursor ? `&cursor=${encodeURIComponent(cursor)}` : "";
    const payload = await apiGet(token, `/v1/documents/${documentId}/blocks?limit=100${suffix}`);
    blocks.push(...payload.items);
    cursor = payload.next_cursor || "";
  } while (cursor);
  return blocks;
}

async function apiLogin() {
  const response = await fetch(`${apiUrl}/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!response.ok) throw new Error(`API login failed: ${response.status} ${await response.text()}`);
  const payload = await response.json();
  return payload.access_token;
}

async function apiGet(token, apiPath) {
  const response = await fetch(`${apiUrl}${apiPath}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error(`API GET ${apiPath} failed: ${response.status} ${await response.text()}`);
  return response.json();
}

function searchablePhrase(text) {
  return text.replace(/\s+/g, " ").trim().slice(0, 32);
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
