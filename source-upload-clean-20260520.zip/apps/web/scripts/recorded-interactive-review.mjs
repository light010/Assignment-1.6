// Recorded interactive review harness — simulates a real reviewer's session
// across N documents and captures (a) per-step screenshots, (b) console errors,
// (c) invariant assertions that single-shot tests cannot catch.
//
// CI gate: exits non-zero when any invariant fails. Emits JUnit XML for CI
// integration.
//
// Output: /private/tmp/workbench-interactive-review/
//   index.md                 — aggregate findings table
//   summary.json             — machine-readable summary
//   junit.xml                — JUnit-format test report (CI integration)
//   <slug>/screenshots/*.png — per-step captures
//   <slug>/findings.md       — per-document narrative + invariant pass/fail
//   <slug>/console.json      — captured console messages
//
// Usage:
//   node apps/web/scripts/recorded-interactive-review.mjs        # all docs
//   ONLY_DOC=apple node apps/web/scripts/recorded-interactive-review.mjs
//   SKIP_DOCS=apple,sap node apps/web/scripts/recorded-interactive-review.mjs
//   MAX_DOCS=5 node apps/web/scripts/recorded-interactive-review.mjs
//
// Exit codes:
//   0 = all invariants passed
//   1 = at least one invariant failed
//   2 = harness setup error (auth, BU not found, etc.)

import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const appUrl = process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173";
const apiUrl = process.env.DITAGEN_API_BASE_URL || "http://127.0.0.1:8000";
const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const outDir = process.env.OUT_DIR || "/private/tmp/workbench-interactive-review";
const onlyDoc = (process.env.ONLY_DOC || "").toLowerCase();
const skipDocs = (process.env.SKIP_DOCS || "")
  .toLowerCase()
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
const maxDocs = Number(process.env.MAX_DOCS || 0);
const includeApple = process.env.INCLUDE_APPLE !== "0";

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function slugFor(filename) {
  return filename
    .replace(/\.(docx?|pdf|xlsx?|pptx?)$/i, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function xmlEscape(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

async function apiLogin() {
  const res = await fetch(`${apiUrl}/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error(`login failed: ${res.status}`);
  const json = await res.json();
  return json.access_token;
}

async function apiGet(token, route) {
  const res = await fetch(`${apiUrl}${route}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`GET ${route} -> ${res.status}`);
  return res.json();
}

async function signIn(page) {
  await page.goto(appUrl);
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }
  await page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") }).waitFor();
}

async function openDocument(page, filename) {
  await page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") }).click();
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor();
  await search.fill(filename);
  await page.getByText(filename).first().waitFor();
  await page.locator(".upload-row").filter({ hasText: filename }).click();
  await page.getByRole("heading", { name: filename }).waitFor();
}

class Recorder {
  constructor(slug, dir) {
    this.slug = slug;
    this.dir = dir;
    this.shots = [];
    this.findings = [];
    this.invariants = [];
    this.consoleMessages = [];
    this.startTime = Date.now();
  }
  attachConsole(page) {
    page.on("console", (msg) => {
      this.consoleMessages.push({ type: msg.type(), text: msg.text() });
    });
    page.on("pageerror", (err) => {
      this.consoleMessages.push({ type: "pageerror", text: err.message });
    });
  }
  async shot(page, label) {
    const filename = `${String(this.shots.length).padStart(2, "0")}-${label}.png`;
    const filepath = path.join(this.dir, "screenshots", filename);
    try {
      await page.screenshot({ path: filepath, fullPage: false });
      this.shots.push({ label, filename });
    } catch (err) {
      this.findings.push(`Screenshot capture failed for "${label}": ${err.message}`);
    }
    return filepath;
  }
  invariant(name, passed, detail) {
    this.invariants.push({ name, passed, detail });
  }
  finding(text) {
    this.findings.push(text);
  }
  durationMs() {
    return Date.now() - this.startTime;
  }
  consoleErrorCount() {
    return this.consoleMessages.filter((m) => m.type === "error" || m.type === "pageerror").length;
  }
  async writeNarrative() {
    const lines = [];
    lines.push(`# Interactive review session — ${this.slug}`);
    lines.push("");
    lines.push(`Generated: ${new Date().toISOString()}`);
    lines.push("");
    lines.push("## Invariants");
    lines.push("");
    lines.push("| Invariant | Passed | Detail |");
    lines.push("|---|---|---|");
    for (const inv of this.invariants) {
      lines.push(`| ${inv.name} | ${inv.passed ? "✅" : "❌"} | ${(inv.detail || "").replace(/\n/g, " ⏎ ")} |`);
    }
    lines.push("");
    lines.push("## Findings");
    lines.push("");
    for (const f of this.findings) {
      lines.push(`- ${f}`);
    }
    lines.push("");
    lines.push("## Captured steps");
    lines.push("");
    for (const s of this.shots) {
      lines.push(`- \`${s.filename}\` — ${s.label}`);
    }
    lines.push("");
    lines.push(`## Console messages (${this.consoleMessages.length})`);
    lines.push("");
    const errors = this.consoleMessages.filter((m) => m.type === "error" || m.type === "pageerror");
    if (errors.length === 0) {
      lines.push("- No errors or pageerrors captured during this session.");
    } else {
      for (const m of errors.slice(0, 25)) {
        lines.push(`- [${m.type}] ${m.text}`);
      }
    }
    await fs.writeFile(path.join(this.dir, "findings.md"), lines.join("\n"));
    await fs.writeFile(path.join(this.dir, "console.json"), JSON.stringify(this.consoleMessages, null, 2));
  }
}

async function reviewReadyDocument(page, target, recorder) {
  await recorder.shot(page, "00-document-detail-default");
  await page.getByRole("tab", { name: "Workbench" }).click().catch(() => {});
  await page.waitForTimeout(800);
  await recorder.shot(page, "01-workbench-initial");

  const rows = page.locator("[role=treeitem]");
  await rows.first().waitFor({ timeout: 8000 }).catch(() => {});
  const rowCount = await rows.count();
  recorder.invariant("tree has >0 rows", rowCount > 0, `count=${rowCount}`);
  if (rowCount === 0) return;

  const targetRowIndex = Math.min(2, rowCount - 1);
  const targetRow = rows.nth(targetRowIndex);
  await targetRow.click({ timeout: 3000 }).catch(() => {});
  await page.waitForTimeout(600);
  await recorder.shot(page, "02-row-selected");

  const selectedSource = page.locator(".source-viewer-selected, .source-viewer-active").first();
  const selectedExists = await selectedSource.count().catch(() => 0);
  recorder.invariant("selected source highlight present", selectedExists > 0, `count=${selectedExists}`);

  // P-56 / P-57: scroll-trap detection.
  const scrollMeta = await page.evaluate(() => {
    const candidates = [
      ".source-evidence-viewer",
      ".source-viewer-shell",
      ".source-pane",
      ".source-panel",
      ".source-preview",
      ".docx-preview",
      ".docx-wrapper",
      ".source-content",
      ".source-original-scroll",
    ];
    const seen = new Set();
    for (const sel of candidates) {
      document.querySelectorAll(sel).forEach((el) => seen.add(el));
    }
    const roots = Array.from(seen);
    for (const root of roots) {
      root.querySelectorAll("*").forEach((el) => seen.add(el));
    }
    let best = null;
    for (const el of seen) {
      if (!(el instanceof HTMLElement)) continue;
      if (el.scrollHeight > el.clientHeight + 8) {
        if (!best || el.scrollHeight > best.scrollHeight) best = el;
      }
    }
    if (!best) return null;
    best.setAttribute("data-harness-scroll-target", "source");
    return {
      tag: best.tagName,
      className: best.className,
      scrollHeight: best.scrollHeight,
      clientHeight: best.clientHeight,
    };
  });
  if (!scrollMeta) {
    recorder.invariant("source pane has a scrollable element", false, "no descendant has scrollHeight > clientHeight");
  } else {
    const scrollHandle = page.locator("[data-harness-scroll-target=source]").first();
    await scrollHandle.evaluate((el) => el.scrollTo({ top: 400, behavior: "instant" }));
    await page.waitForTimeout(800);
    const scrollAfterPriming = await scrollHandle.evaluate((el) => el.scrollTop);
    recorder.invariant(
      "P-57: programmatic scrollTo(400) holds (no snap-back)",
      scrollAfterPriming > 200,
      `target=400 actual=${scrollAfterPriming}`,
    );

    const otherRowIndex = Math.min(8, rowCount - 1);
    if (otherRowIndex !== targetRowIndex) {
      await rows.nth(otherRowIndex).click({ timeout: 3000 }).catch(() => {});
      await page.waitForTimeout(800);
    }
    const scrollAfterSelect = await scrollHandle.evaluate((el) => el.scrollTop);
    await scrollHandle.evaluate((el) => el.scrollBy({ top: -250, behavior: "instant" }));
    const scrollAfterManual = await scrollHandle.evaluate((el) => el.scrollTop);
    await page.waitForTimeout(1500);
    const scrollAfterWait = await scrollHandle.evaluate((el) => el.scrollTop);
    const moved = Math.abs(scrollAfterManual - scrollAfterSelect) > 30;
    const snappedBack = moved && Math.abs(scrollAfterWait - scrollAfterSelect) < 30;
    recorder.invariant(
      "P-56: source pane does NOT auto-revert after manual scroll",
      !snappedBack,
      `afterSelect=${scrollAfterSelect} afterManual=${scrollAfterManual} afterWait=${scrollAfterWait}`,
    );
    await recorder.shot(page, "03-after-source-scroll");
  }

  // Hover + keyboard navigation.
  if (rowCount > 4) {
    await rows.nth(4).hover().catch(() => {});
    await page.waitForTimeout(300);
  }
  await targetRow.focus().catch(() => {});
  await page.keyboard.press("ArrowDown").catch(() => {});
  await page.keyboard.press("ArrowDown").catch(() => {});
  await page.waitForTimeout(300);
  await recorder.shot(page, "04-keyboard-arrowdown");

  // Search.
  const searchInput = page.locator("input[placeholder*='Search extracted']").first();
  if (await searchInput.isVisible().catch(() => false)) {
    await searchInput.fill("the");
    await page.waitForTimeout(400);
    const visibleAfterSearch = await rows.count();
    recorder.invariant("search filters tree rows", visibleAfterSearch >= 0, `rows visible: ${visibleAfterSearch}`);
    await searchInput.fill("");
  }
}

async function reviewBlockedDocument(page, target, recorder) {
  await recorder.shot(page, "00-document-detail-blocked");
  const workbenchTab = page.getByRole("tab", { name: "Workbench" });
  const disabled = await workbenchTab.getAttribute("aria-disabled").catch(() => null);
  const selected = await workbenchTab.getAttribute("aria-selected").catch(() => null);
  recorder.invariant("Workbench tab enabled on blocked document", disabled !== "true", `aria-disabled=${disabled}`);
  recorder.invariant("Workbench selected by default on blocked document", selected === "true", `aria-selected=${selected}`);

  const diagnosticMode = page.getByText("Workbench diagnostic mode").first();
  recorder.invariant("Blocked document renders diagnostic Workbench", await diagnosticMode.isVisible().catch(() => false), "");

  const summaryRegion = page.getByLabel("Gated extraction summary").first();
  const summaryText = await summaryRegion.innerText().catch(() => "");
  recorder.invariant("Gated extraction summary visible", summaryText.trim().length > 0, summaryText);
  recorder.invariant(
    "P-46: blocked document summary shows non-zero source block count",
    /Source blocks\s+[1-9]\d*/i.test(summaryText),
    `summary="${summaryText.replace(/\n/g, " | ")}"`,
  );

  const evidenceGroups = page.getByLabel("Affected evidence groups").first();
  const selectedEvidence = page.getByLabel("Selected evidence detail").first();
  const remediation = page.getByLabel("Remediation actions").first();
  recorder.invariant("Blocked document shows affected evidence groups", await evidenceGroups.isVisible().catch(() => false), "");
  recorder.invariant("Blocked document shows selected evidence detail", await selectedEvidence.isVisible().catch(() => false), "");
  recorder.invariant("Blocked document shows remediation actions", await remediation.isVisible().catch(() => false), "");

  // P-47: no skeleton placeholders when "Not Found" error shown.
  const notFound = page.getByText(/Could not load source preview/i).first();
  if (await notFound.isVisible().catch(() => false)) {
    const placeholderCount = await page.evaluate(() => {
      let n = 0;
      document.querySelectorAll("*").forEach((el) => {
        if (!(el instanceof HTMLElement)) return;
        const cls = el.className?.toString().toLowerCase() || "";
        if (/skeleton|placeholder|shimmer|loading-bar/.test(cls) && el.offsetHeight > 8) n++;
      });
      return n;
    });
    recorder.invariant("P-47: no skeleton placeholders when explicit error shown", placeholderCount === 0, `count=${placeholderCount}`);
  } else {
    recorder.invariant("P-47: blocked diagnostic does not show source preview Not Found", true, "");
  }
  await recorder.shot(page, "01-diagnostic-workbench");
}

async function reviewFailedDocument(page, target, recorder) {
  await recorder.shot(page, "00-document-detail-failed");
  // Failed extraction: Workbench still lands by default, but renders the
  // typed failed-extraction panel instead of a ready review workspace.
  const workbenchTab = page.getByRole("tab", { name: "Workbench" });
  const disabled = await workbenchTab.getAttribute("aria-disabled").catch(() => null);
  const selected = await workbenchTab.getAttribute("aria-selected").catch(() => null);
  recorder.invariant("Workbench tab enabled on failed document", disabled !== "true", `aria-disabled=${disabled}`);
  recorder.invariant("Workbench selected by default on failed document", selected === "true", `aria-selected=${selected}`);
  const failedPanel = page.locator(".extraction-review-banner--failed").first();
  recorder.invariant("ExtractionFailedPanel rendered", await failedPanel.isVisible().catch(() => false), "");
  await recorder.shot(page, "01-failed-panel");
}

function writeJunit(summary, outDir) {
  const lines = [];
  const totalInvariants = summary.reduce((a, s) => a + s.invariants.length, 0);
  const failedInvariants = summary.reduce((a, s) => a + s.invariants.filter((i) => !i.passed).length, 0);
  lines.push('<?xml version="1.0" encoding="UTF-8"?>');
  lines.push(`<testsuites name="workbench-interactive-review" tests="${totalInvariants}" failures="${failedInvariants}">`);
  for (const s of summary) {
    const tests = s.invariants.length;
    const failures = s.invariants.filter((i) => !i.passed).length;
    const errors = s.consoleErrorCount > 0 ? 1 : 0;
    lines.push(`  <testsuite name="${xmlEscape(s.slug)}" tests="${tests}" failures="${failures}" errors="${errors}" time="${(s.durationMs / 1000).toFixed(2)}">`);
    for (const inv of s.invariants) {
      lines.push(`    <testcase classname="${xmlEscape(s.slug)}" name="${xmlEscape(inv.name)}">`);
      if (!inv.passed) {
        lines.push(`      <failure message="${xmlEscape(inv.detail || "invariant failed")}">${xmlEscape(inv.detail || "")}</failure>`);
      }
      lines.push("    </testcase>");
    }
    if (errors > 0) {
      lines.push(`    <system-err>${xmlEscape(`${s.consoleErrorCount} console error(s) captured`)}</system-err>`);
    }
    lines.push("  </testsuite>");
  }
  lines.push("</testsuites>");
  return fs.writeFile(path.join(outDir, "junit.xml"), lines.join("\n"));
}

async function main() {
  await fs.mkdir(outDir, { recursive: true });
  let token;
  try {
    token = await apiLogin();
  } catch (err) {
    console.error(`[setup-error] auth failed: ${err.message}`);
    process.exit(2);
  }
  let businessUnit, documents;
  try {
    const businessUnitsPayload = await apiGet(token, "/v1/business-units");
    businessUnit = businessUnitsPayload.business_units.find((u) => u.name === businessUnitName);
    if (!businessUnit) throw new Error(`BU not found: ${businessUnitName}`);
    const docsPayload = await apiGet(token, `/v1/business-units/${businessUnit.business_unit_id}/documents`);
    documents = docsPayload.documents
      .filter((d) => includeApple || !/^Apple CA/i.test(d.filename))
      .filter((d) => !onlyDoc || d.filename.toLowerCase().includes(onlyDoc))
      .filter((d) => !skipDocs.some((s) => d.filename.toLowerCase().includes(s)))
      .sort((a, b) => a.filename.localeCompare(b.filename));
    if (maxDocs > 0) documents = documents.slice(0, maxDocs);
  } catch (err) {
    console.error(`[setup-error] document discovery failed: ${err.message}`);
    process.exit(2);
  }

  console.error(`[discovered] ${documents.length} document(s) to review`);

  const browser = await chromium.launch({ headless: true });
  const summary = [];

  for (const doc of documents) {
    const slug = slugFor(doc.filename);
    const state =
      doc.status === "failed_extraction" ? "failed" :
      doc.status === "extraction_needs_review" ? "blocked" :
      "ready";
    console.error(`[start] ${slug} (${state}) — ${doc.filename}`);
    const dir = path.join(outDir, slug);
    await fs.mkdir(path.join(dir, "screenshots"), { recursive: true });
    const recorder = new Recorder(slug, dir);

    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await ctx.newPage();
    recorder.attachConsole(page);

    try {
      await signIn(page);
      await openDocument(page, doc.filename);
      if (state === "blocked") {
        await reviewBlockedDocument(page, doc, recorder);
      } else if (state === "failed") {
        await reviewFailedDocument(page, doc, recorder);
      } else {
        await reviewReadyDocument(page, doc, recorder);
      }
    } catch (err) {
      recorder.finding(`Session error: ${err.message}`);
      recorder.invariant("session completed without throwing", false, err.message);
      console.error(`[error] ${slug}: ${err.message}`);
    }

    await recorder.writeNarrative();
    const pass = recorder.invariants.filter((i) => i.passed).length;
    const fail = recorder.invariants.length - pass;
    summary.push({
      slug,
      filename: doc.filename,
      state,
      invariants: recorder.invariants,
      findings: recorder.findings,
      shotCount: recorder.shots.length,
      consoleErrorCount: recorder.consoleErrorCount(),
      durationMs: recorder.durationMs(),
    });
    console.error(`[done] ${slug} — ${recorder.shots.length} shots, ${pass}/${recorder.invariants.length} pass, ${recorder.consoleErrorCount()} console errors (${(recorder.durationMs() / 1000).toFixed(1)}s)`);
    await ctx.close();
  }

  // Aggregate index.
  const indexLines = [];
  indexLines.push("# Workbench interactive review — aggregate findings");
  indexLines.push("");
  indexLines.push(`Generated: ${new Date().toISOString()}`);
  indexLines.push(`Documents reviewed: ${summary.length}`);
  indexLines.push("");
  indexLines.push("| Document | State | Steps | Pass | Fail | Console errors | Duration |");
  indexLines.push("|---|---|---:|---:|---:|---:|---:|");
  for (const s of summary) {
    const pass = s.invariants.filter((i) => i.passed).length;
    const fail = s.invariants.length - pass;
    indexLines.push(`| [${s.slug}](${s.slug}/findings.md) | ${s.state} | ${s.shotCount} | ${pass} | ${fail} | ${s.consoleErrorCount} | ${(s.durationMs / 1000).toFixed(1)}s |`);
  }
  indexLines.push("");

  const totalInv = summary.reduce((a, s) => a + s.invariants.length, 0);
  const totalPass = summary.reduce((a, s) => a + s.invariants.filter((i) => i.passed).length, 0);
  const totalFail = totalInv - totalPass;
  const totalErrors = summary.reduce((a, s) => a + s.consoleErrorCount, 0);
  indexLines.push(`**Totals**: ${totalInv} invariants, ${totalPass} pass, ${totalFail} fail, ${totalErrors} console errors across ${summary.length} documents.`);
  indexLines.push("");

  indexLines.push("## All failed invariants");
  indexLines.push("");
  let failuresRendered = 0;
  for (const s of summary) {
    for (const inv of s.invariants.filter((i) => !i.passed)) {
      indexLines.push(`- **${s.slug}** (${s.state}) — ${inv.name} — ${inv.detail || ""}`);
      failuresRendered++;
    }
  }
  if (failuresRendered === 0) indexLines.push("- (none)");
  indexLines.push("");

  indexLines.push("## Documents with console errors");
  indexLines.push("");
  let errorDocsRendered = 0;
  for (const s of summary.filter((s) => s.consoleErrorCount > 0)) {
    indexLines.push(`- **${s.slug}** — ${s.consoleErrorCount} error(s) (see \`${s.slug}/console.json\`)`);
    errorDocsRendered++;
  }
  if (errorDocsRendered === 0) indexLines.push("- (none)");

  await fs.writeFile(path.join(outDir, "index.md"), indexLines.join("\n"));
  await fs.writeFile(
    path.join(outDir, "summary.json"),
    JSON.stringify(
      {
        generated_at: new Date().toISOString(),
        total_documents: summary.length,
        total_invariants: totalInv,
        total_pass: totalPass,
        total_fail: totalFail,
        total_console_errors: totalErrors,
        documents: summary,
      },
      null,
      2,
    ),
  );
  await writeJunit(summary, outDir);

  await browser.close();

  console.error("");
  console.error(`[summary] ${summary.length} documents, ${totalInv} invariants, ${totalPass} pass, ${totalFail} fail, ${totalErrors} console errors`);
  console.error(`[summary] index: ${path.join(outDir, "index.md")}`);
  console.error(`[summary] junit: ${path.join(outDir, "junit.xml")}`);

  // CI gate: exit non-zero if any invariant failed.
  process.exit(totalFail > 0 ? 1 : 0);
}

await main().catch((err) => {
  console.error(err);
  process.exit(2);
});
