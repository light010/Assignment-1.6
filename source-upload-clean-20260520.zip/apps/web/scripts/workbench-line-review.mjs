import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const appUrl = process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173";
const apiUrl = process.env.DITAGEN_API_BASE_URL || "http://127.0.0.1:8000";
const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const outDir = process.env.WORKBENCH_REVIEW_OUT || "/private/tmp/workbench-line-review";
const slowMo = Number(process.env.PW_SLOWMO || 20);
const lineDelayMs = Number(process.env.LINE_DELAY_MS || 60);
const includeApple = process.env.INCLUDE_APPLE === "1";
const onlyDocument = process.env.ONLY_DOCUMENT || "";
const maxDocs = Number(process.env.MAX_DOCS || 0);

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../../..");
const feedbackDir = path.join(root, "docs/product/workbench-feedback");
const resultsPath = path.join(feedbackDir, "_line-review-results.json");

await fs.mkdir(outDir, { recursive: true });

const token = await apiLogin();
const businessUnit = await apiGet(token, "/v1/business-units").then((payload) =>
  payload.business_units.find((unit) => unit.name === businessUnitName),
);
if (!businessUnit) throw new Error(`Could not find business unit ${businessUnitName}`);

const documentsPayload = await apiGet(token, `/v1/business-units/${businessUnit.business_unit_id}/documents`);
let documents = documentsPayload.documents
  .filter((document) => includeApple || document.filename !== "Apple CA (PSC).docx")
  .filter((document) => !onlyDocument || document.filename === onlyDocument)
  .sort((a, b) => a.filename.localeCompare(b.filename));
if (maxDocs > 0) documents = documents.slice(0, maxDocs);

const browser = await chromium.launch({ headless: false, slowMo });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const results = [];

try {
  await signIn(page);
  for (const document of documents) {
    const result = await reviewDocumentLineByLine(page, token, document);
    results.push(result);
    await fs.writeFile(resultsPath, JSON.stringify(results, null, 2));
    console.log(JSON.stringify({
      document: document.filename,
      status: document.status,
      visual_status: result.visual_status,
      reviewed_lines: result.lines.length,
      missing_rows: result.summary.missingRows,
      source_mismatches: result.summary.sourceMismatches,
      screenshot: result.screenshot,
      error: result.error || null,
    }));
  }
} finally {
  await browser.close();
}

async function reviewDocumentLineByLine(page, token, document) {
  const slug = slugify(document.filename.replace(/\.docx$/i, ""));
  const result = {
    document_id: document.document_id,
    filename: document.filename,
    status: document.status,
    slug,
    visual_status: "pending",
    screenshot: "",
    source_status_text: "",
    heading_text: "",
    lines: [],
    summary: {
      totalBlocks: 0,
      reviewedLines: 0,
      missingRows: 0,
      sourceMismatches: 0,
      inspectorMismatches: 0,
      attentionRows: 0,
    },
  };

  try {
    await openBusinessUnit(page);
    await openDocument(page, document.filename);
    await page.getByRole("heading", { name: document.filename }).waitFor({ timeout: 20_000 });

    const blocks = await fetchBlocks(token, document.document_id);
    result.summary.totalBlocks = blocks.length;

    if (document.status !== "ready_for_review") {
      result.visual_status = "blocked_by_document_status";
      result.screenshot = await screenshot(page, `${slug}-blocked.png`);
      return result;
    }

    await page.getByRole("tab", { name: "Workbench" }).click();
    await page.locator(".extraction-explorer-shell").waitFor({ timeout: 30_000 });
    await waitForSourcePreview(page);
    result.heading_text = await page.getByRole("heading", { name: /\d+\s+source blocks/i }).first().innerText();
    result.source_status_text = await sourceStatusText(page);

    for (let index = 0; index < blocks.length; index += 1) {
      const block = blocks[index];
      const line = await reviewBlockRow(page, block, index + 1);
      result.lines.push(line);
      await page.waitForTimeout(lineDelayMs);
    }

    result.summary.reviewedLines = result.lines.length;
    result.summary.missingRows = result.lines.filter((line) => !line.row_found).length;
    result.summary.sourceMismatches = result.lines.filter((line) => !line.source_highlight_exact).length;
    result.summary.inspectorMismatches = result.lines.filter((line) => !line.inspector_mentions_block).length;
    result.summary.attentionRows = result.lines.filter((line) => line.attention_signals > 0).length;
    result.screenshot = await screenshot(page, `${slug}-line-review.png`);
    result.visual_status = "line_by_line_complete";
  } catch (error) {
    result.visual_status = "failed";
    result.error = error instanceof Error ? error.message : String(error);
    result.screenshot = await screenshot(page, `${slug}-line-review-failed.png`).catch(() => "");
  }
  return result;
}

async function reviewBlockRow(page, block, lineNumber) {
  const blockId = block.block_id;
  const selector = `.extraction-row[data-source-block-id="${cssEscape(blockId)}"]`;
  const row = page.locator(selector).first();
  const line = {
    line: lineNumber,
    block_id: blockId,
    text: block.text || "",
    block_type: block.block_type || "",
    locator: block.source_location?.section || "",
    row_found: false,
    row_text: "",
    inspector_text: "",
    source_highlight_exact: false,
    source_highlight_count: 0,
    active_row_exact: false,
    inspector_mentions_block: false,
    attention_signals: 0,
    visual_status: "pending",
  };

  if (!(await row.count())) {
    line.visual_status = "missing_extraction_row";
    return line;
  }

  line.row_found = true;
  await row.scrollIntoViewIfNeeded();
  await row.click();
  await page.waitForFunction((id) => {
    const active = document.querySelector(".extraction-row.active");
    return active?.getAttribute("data-source-block-id") === id;
  }, blockId, { timeout: 3_000 }).catch(() => {});

  const activeRow = page.locator(".extraction-row.active").first();
  line.row_text = await activeRow.innerText().catch(async () => "");
  line.inspector_text = await page.locator(".extraction-inspector").first().innerText().catch(async () => "");
  line.source_highlight_count = await page.locator(`.source-viewer-active[data-source-block-id="${cssEscape(blockId)}"]`).count();
  line.source_highlight_exact = line.source_highlight_count > 0;
  line.active_row_exact = (await activeRow.getAttribute("data-source-block-id").catch(async () => "")) === blockId;
  line.inspector_mentions_block = inspectorMatchesBlock(line.inspector_text, block);
  line.attention_signals = await activeRow.locator(".attention").count().catch(async () => 0);
  line.visual_status = line.row_found && line.active_row_exact && line.source_highlight_exact ? "pass" : "needs_review";
  return line;
}

function inspectorMatchesBlock(inspectorText, block) {
  const locator = block.source_location?.section;
  if (locator && inspectorText.includes(locator)) return true;
  const text = (block.text || "").replace(/\s+/g, " ").trim();
  if (!text) return true;
  return inspectorText.replace(/\s+/g, " ").includes(text.slice(0, Math.min(40, text.length)));
}

async function signIn(page) {
  await page.goto(appUrl);
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }
  await page.getByRole("heading", { name: "Business Units" }).waitFor({ timeout: 30_000 });
}

async function openBusinessUnit(page) {
  await page.goto(appUrl);
  const signInButton = page.getByRole("button", { name: /^Sign in$/ });
  if (await signInButton.isVisible().catch(() => false)) await signIn(page);

  const documentSearch = page.locator("input[placeholder='Search documents by name']").first();
  const breadcrumbButton = page.getByRole("button", { name: businessUnitName }).first();
  const card = page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") });
  const route = await Promise.race([
    documentSearch.waitFor({ state: "visible", timeout: 30_000 }).then(() => "document-list"),
    breadcrumbButton.waitFor({ state: "visible", timeout: 30_000 }).then(() => "breadcrumb"),
    card.waitFor({ state: "visible", timeout: 30_000 }).then(() => "business-units"),
  ]).catch(() => null);
  if (route === "document-list") return;
  if (route === "breadcrumb") {
    await breadcrumbButton.click();
    await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
    return;
  }
  if (route !== "business-units") throw new Error(`Could not reach ${businessUnitName} document list`);
  await card.click();
  await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
}

async function openDocument(page, filename) {
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor({ state: "visible", timeout: 30_000 });
  await search.click();
  await search.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await search.fill(filename);
  await page.waitForTimeout(500);
  const row = page.locator(".upload-row").filter({ hasText: filename }).first();
  await row.waitFor({ state: "visible", timeout: 30_000 });
  await row.click({ position: { x: 80, y: 24 } });
}

async function waitForSourcePreview(page) {
  await page.waitForFunction(() => {
    const text = document.body.innerText;
    const hasStatus = /\d+\s*\/\s*\d+\s*matched/i.test(text);
    const hasAnchor = document.querySelectorAll("[data-source-block-id]").length > 0;
    return hasStatus && hasAnchor;
  }, { timeout: 30_000 }).catch(async () => {
    await page.waitForTimeout(2_000);
  });
}

async function sourceStatusText(page) {
  return page.locator(".source-viewer-status, [aria-label='Source viewer status']").first().innerText().catch(async () => "");
}

async function screenshot(page, name) {
  const file = path.join(outDir, name);
  await page.screenshot({ path: file, fullPage: false });
  return file;
}

async function fetchBlocks(token, documentId) {
  const blocks = [];
  let cursor = "";
  do {
    const suffix = cursor ? `&cursor=${encodeURIComponent(cursor)}` : "";
    const payload = await apiGet(token, `/v1/documents/${documentId}/blocks?limit=100${suffix}`);
    blocks.push(...payload.items);
    cursor = payload.next_cursor || "";
  } while (cursor);
  return blocks;
}

async function apiLogin() {
  const response = await fetch(`${apiUrl}/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!response.ok) throw new Error(`API login failed: ${response.status} ${await response.text()}`);
  const payload = await response.json();
  return payload.access_token;
}

async function apiGet(token, apiPath) {
  const response = await fetch(`${apiUrl}${apiPath}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error(`API GET ${apiPath} failed: ${response.status} ${await response.text()}`);
  return response.json();
}

function slugify(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function cssEscape(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
