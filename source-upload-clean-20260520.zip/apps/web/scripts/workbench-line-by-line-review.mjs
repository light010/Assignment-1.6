import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const appUrl = process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173";
const apiUrl = process.env.DITAGEN_API_BASE_URL || "http://127.0.0.1:8000";
const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const outDir = process.env.WORKBENCH_LINE_REVIEW_OUT || "/private/tmp/workbench-line-review";
const slowMo = Number(process.env.PW_SLOWMO || 30);
const lineDelayMs = Number(process.env.LINE_DELAY_MS || 40);
const includeApple = process.env.INCLUDE_APPLE === "1";
const maxDocs = Number(process.env.MAX_DOCS || 0);
const onlyDoc = process.env.ONLY_DOC || "";
const updateReports = process.env.UPDATE_REPORTS !== "0";
const resume = process.env.RESUME === "1";
const reportOnly = process.env.REPORT_ONLY === "1";
const REVIEW_FLAG_CATALOG = {
  LOW_BLOCK_TYPE_CONFIDENCE: "Low block type confidence",
  ORPHAN_TABLE_ROW: "Orphan table row",
  MIXED_HEADING_STYLE: "Mixed heading style",
  SUSPECTED_HEADING_FRAGMENT: "Suspected heading fragment",
  HEADING_BY_FORMATTING: "Heading inferred by formatting",
  HEADING_IN_CELL: "Heading inside table cell",
  SYNTHETIC_ROOT_HEADING: "Synthetic root heading",
  ASSET_REF_UNRESOLVED: "Unresolved asset reference",
  NESTED_TABLE: "Nested table",
  DEEP_NESTING_UNSUPPORTED: "Deep nested table unsupported",
  FLOATING_TABLE: "Floating table",
  POSSIBLY_CALLOUT: "Possible callout",
  SUBDOC_UNSUPPORTED: "Sub-document unsupported",
  MATH_CONTENT: "Math content",
  HAS_INSERTIONS: "Tracked insertions present",
  HAS_DELETIONS: "Tracked deletions present",
  SMARTART_DROPPED: "SmartArt dropped",
  HIDDEN_TEXT_DROPPED: "Hidden text dropped",
  MULTI_COLUMN: "Multi-column layout",
  NO_HEADINGS_FOUND: "No headings found",
};

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../../..");
const feedbackDir = path.join(root, "docs/product/workbench-feedback");
const resultsPath = path.join(feedbackDir, "_line-review-results.json");

await fs.mkdir(outDir, { recursive: true });
await fs.mkdir(feedbackDir, { recursive: true });

const previousResults = resume || reportOnly ? await readJson(resultsPath, []) : [];
const previousByFilename = new Map(previousResults.map((result) => [result.filename, result]));

const token = await apiLogin();
const businessUnit = await apiGet(token, "/v1/business-units").then((payload) =>
  payload.business_units.find((unit) => unit.name === businessUnitName),
);
if (!businessUnit) {
  throw new Error(`Could not find business unit ${businessUnitName}`);
}

const documentsPayload = await apiGet(token, `/v1/business-units/${businessUnit.business_unit_id}/documents`);
let documents = documentsPayload.documents
  .filter((document) => includeApple || document.filename !== "Apple CA (PSC).docx")
  .filter((document) => !onlyDoc || document.filename.toLowerCase().includes(onlyDoc.toLowerCase()))
  .filter((document) => !resume || !previousByFilename.has(document.filename))
  .sort((a, b) => a.filename.localeCompare(b.filename));
if (maxDocs > 0) documents = documents.slice(0, maxDocs);

if (reportOnly) {
  const refreshed = [];
  for (const document of documents) {
    const previous = previousByFilename.get(document.filename);
    if (!previous) continue;
    const result = await rebuildFromPrevious(token, document, previous);
    refreshed.push(result);
    if (updateReports) await writeReport(result);
  }
  await fs.writeFile(resultsPath, JSON.stringify(refreshed, null, 2));
  if (updateReports) await writeIndex(refreshed);
  process.exit(0);
}

const browser = await chromium.launch({ headless: false, slowMo });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const results = [...previousResults];

try {
  await signIn(page);
  for (const document of documents) {
    const result = await reviewDocument(page, token, document);
    results.push(result);
    await fs.writeFile(resultsPath, JSON.stringify(results, null, 2));
    if (updateReports) await writeReport(result);
    console.log(
      JSON.stringify({
        document: document.filename,
        status: document.status,
        review_status: result.review_status,
        reviewed_lines: result.lines.filter((line) => line.visual_status === "verified").length,
        total_lines: result.lines.length,
        mismatches: visualMismatchCount(result),
        screenshot: result.screenshot,
        error: result.error || null,
      }),
    );
  }
} finally {
  await browser.close();
}

if (updateReports) await writeIndex(results);

async function reviewDocument(page, token, document) {
  const slug = slugify(document.filename.replace(/\.docx$/i, ""));
  const result = {
    document_id: document.document_id,
    filename: document.filename,
    status: document.status,
    slug,
    review_status: "pending",
    screenshot: "",
    summary: {},
    lines: [],
    error: "",
  };

    let blocks = [];
    try {
      blocks = await fetchBlocks(token, document.document_id);
    } catch (error) {
      result.summary.block_fetch_error = error instanceof Error ? error.message : String(error);
      if (document.status === "ready_for_review") throw error;
    }
    result.summary.total_source_blocks = blocks.length;
    result.summary.located_source_blocks = blocks.filter((block) => block.source_location?.section).length;
  result.summary.review_flag_count = blocks.reduce((total, block) => total + (block.review_flags?.length || 0), 0);
  result.summary.histogram = histogram(blocks.map((block) => block.block_type || "unknown"));

  try {
    await openBusinessUnit(page);
    await openDocument(page, document.filename);
    await page.getByRole("heading", { name: document.filename }).waitFor({ timeout: 20_000 });

    if (document.status !== "ready_for_review") {
      result.review_status = "blocked_by_document_status";
      result.summary.source_available = await page.getByRole("tab", { name: "Source" }).isVisible().catch(() => false);
      result.summary.workbench_enabled = await page.getByRole("tab", { name: "Workbench" }).isEnabled().catch(() => false);
      result.screenshot = await screenshot(page, `${slug}-blocked.png`);
      result.lines = blocks.map((block, index) => lineFromBlock(block, blocks, index, {
        visual_status: "not_reviewed_status_blocked",
        source_highlight: "not tested",
        row_selected: "not tested",
        inspector_aligned: "not tested",
        visual_finding: `Workbench line review was blocked by document status ${document.status}.`,
      }));
      return result;
    }

    await page.getByRole("tab", { name: "Workbench" }).click();
    await page.locator(".extraction-explorer-shell").waitFor({ timeout: 30_000 });
    await waitForSourcePreview(page);
    await resetExplorerFilters(page);
    await expandAllRows(page);

    result.summary.matched_text = await sourceStatusText(page);
    result.summary.explorer_heading = await page.locator(".extraction-explorer-summary h3").first().innerText().catch(() => "");
    result.summary.source_anchor_count = await page.locator("[data-source-block-id]").count();
    result.summary.extraction_row_count = await page.locator(".extraction-row[data-source-block-id]").count();
    result.summary.topic_controls_absent = (await page.locator("select[aria-label='Topic type'], .cockpit, .topic-filmstrip").count()) === 0;

    for (let index = 0; index < blocks.length; index += 1) {
      const block = blocks[index];
      const visual = await clickAndVerifyLine(page, block, index);
      result.lines.push(lineFromBlock(block, blocks, index, visual));
      if (lineDelayMs > 0) await page.waitForTimeout(lineDelayMs);
    }

    result.screenshot = await screenshot(page, `${slug}-line-review.png`);
    const mismatches = result.lines.filter((line) => line.visual_status !== "verified");
    result.review_status = mismatches.length ? "complete_with_findings" : "complete";
  } catch (error) {
    result.review_status = "failed";
    result.error = error instanceof Error ? error.message : String(error);
    result.screenshot = await screenshot(page, `${slug}-failed.png`).catch(() => "");
  }

  return result;
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}

async function rebuildFromPrevious(token, document, previous) {
  let blocks = [];
  try {
    blocks = await fetchBlocks(token, document.document_id);
  } catch {
    blocks = [];
  }
  const byBlockId = new Map((previous.lines || []).map((line) => [line.block_id, line]));
  const result = {
    ...previous,
    document_id: document.document_id,
    filename: document.filename,
    status: document.status,
    lines: [],
    summary: {
      ...(previous.summary || {}),
      total_source_blocks: blocks.length || previous.summary?.total_source_blocks || previous.lines?.length || 0,
      located_source_blocks: blocks.length
        ? blocks.filter((block) => block.source_location?.section).length
        : previous.summary?.located_source_blocks || 0,
      review_flag_count: blocks.length
        ? blocks.reduce((total, block) => total + (block.review_flags?.length || 0), 0)
        : previous.summary?.review_flag_count || 0,
      histogram: blocks.length ? histogram(blocks.map((block) => block.block_type || "unknown")) : previous.summary?.histogram || {},
    },
  };
  if (!blocks.length) {
    result.lines = previous.lines || [];
    return result;
  }
  result.lines = blocks.map((block, index) => {
    const previousLine = byBlockId.get(block.block_id) || previous.lines?.[index] || {};
    if (previousLine.block_id === block.block_id) {
      return {
        ...previousLine,
        line: index + 1,
        extracted_source_block: preview(block.text || cellText(block) || block.block_id, 180),
        type: displayType(block),
        raw_type: block.block_type || "",
        locator: block.source_location?.section || "",
        parent_path: parentPath(block, blocks),
        structure: structureDetails(block),
      };
    }
    return lineFromBlock(block, blocks, index, {
      visual_status: "not_reviewed_status_blocked",
      source_highlight: "not tested",
      row_selected: "not tested",
      inspector_aligned: "not tested",
      row_kind: "",
      visual_finding: "No saved visible line-review evidence was available for this source block.",
      active_source_count: 0,
      matching_active_source_count: 0,
      active_row_source_block_id: "",
      row_text: "",
      inspector_text: "",
    });
  });
  return result;
}

async function clickAndVerifyLine(page, block, index) {
  const selector = `.extraction-row[data-source-block-id="${cssAttr(block.block_id)}"]`;
  const row = page.locator(selector).first();
  const visual = {
    visual_status: "verified",
    source_highlight: "exact",
    row_selected: "yes",
    inspector_aligned: "yes",
    active_source_count: 0,
    matching_active_source_count: 0,
    active_row_source_block_id: "",
    row_kind: "",
    row_text: "",
    inspector_text: "",
    visual_finding: "Visible Chromium pass clicked this extraction row and confirmed the matching source highlight.",
  };

  if ((await row.count()) === 0) {
    return {
      ...visual,
      visual_status: "missing_extraction_row",
      source_highlight: "not tested",
      row_selected: "no",
      inspector_aligned: "not tested",
      visual_finding: "No rendered Extraction Explorer row was found for this source block.",
    };
  }

  await row.scrollIntoViewIfNeeded();
  await row.click();
  await page.waitForTimeout(40);

  const activeRow = page.locator(".extraction-row.active").first();
  visual.active_row_source_block_id = await activeRow.getAttribute("data-source-block-id").catch(() => "") || "";
  visual.row_kind = await row.getAttribute("data-extraction-kind").catch(() => "") || "";
  visual.row_text = oneLine(await row.innerText().catch(() => ""));
  visual.inspector_text = oneLine(await page.locator(".extraction-inspector").first().innerText().catch(() => ""));
  visual.active_source_count = await page.locator(".source-viewer-active").count();
  visual.matching_active_source_count = await page.locator(`.source-viewer-active[data-source-block-id="${cssAttr(block.block_id)}"]`).count();

  const inspectorMentionsBlock =
    visual.inspector_text.includes(block.block_id) ||
    visual.inspector_text.includes(block.source_location?.section || "___no_locator___") ||
    normalizedContains(visual.inspector_text, block.text || "");

  if (visual.active_row_source_block_id !== block.block_id) {
    return {
      ...visual,
      visual_status: "active_row_mismatch",
      row_selected: "no",
      visual_finding: `Clicked line ${index + 1}, but the active row moved to ${visual.active_row_source_block_id || "none"}.`,
    };
  }
  if (visual.matching_active_source_count === 0) {
    return {
      ...visual,
      visual_status: "source_highlight_missing",
      source_highlight: "missing",
      visual_finding: "The extraction row selected, but the left source pane did not show an active highlight for the same source block.",
    };
  }
  if (!inspectorMentionsBlock) {
    return {
      ...visual,
      visual_status: "inspector_unclear",
      inspector_aligned: "unclear",
      visual_finding: "The row and source highlight aligned, but the inspector did not clearly expose the selected block text, locator, or block id.",
    };
  }
  return visual;
}

function lineFromBlock(block, blocks, index, visual) {
  const structure = structureDetails(block);
  const issue = deriveIssue(block, visual);
  const ux = evaluateUx(block, visual, issue);
  return {
    line: index + 1,
    block_id: block.block_id,
    extracted_source_block: preview(block.text || cellText(block) || block.block_id, 180),
    type: displayType(block),
    raw_type: block.block_type || "",
    locator: block.source_location?.section || "",
    parent_path: parentPath(block, blocks),
    structure,
    visual_status: visual.visual_status,
    source_highlight: visual.source_highlight,
    row_selected: visual.row_selected,
    inspector_aligned: visual.inspector_aligned,
    row_kind: visual.row_kind || "",
    why_right: whyRight(block, visual),
    what_wrong: issue.what_wrong,
    improvement: issue.improvement,
    information_economy: ux.information_economy,
    placement: ux.placement,
    representation: ux.representation,
    row_label_quality: ux.row_label_quality,
    visual_hierarchy: ux.visual_hierarchy,
    selection_state: ux.selection_state,
    reviewer_action_clarity: ux.reviewer_action_clarity,
    inspector_usefulness: ux.inspector_usefulness,
    terminology_issue: ux.terminology_issue,
    accessibility_concern: ux.accessibility_concern,
    fix_scope: issue.fix_scope,
    priority: issue.priority,
    acceptance_test: ux.acceptance_test,
    visual_finding: visual.visual_finding,
  };
}

function evaluateUx(block, visual, issue) {
  const isTableRow = block.block_type === "table_row";
  const isHeading = block.block_type === "heading";
  const numbering = block.numbering || block.confidence_signals?.numbering;
  const hasIssue = issue.priority === "P0" || issue.priority === "P1" || issue.priority === "P2";
  const isNestedList = Boolean(numbering && numbering.level > 0);

  return {
    information_economy: isTableRow
      ? "combine duplicated cell-title content; keep cells primary and move row/table context to inspector"
      : hasIssue
        ? "keep the risk signal visible, demote secondary confidence/details until selected"
        : "keep row readable; demote low-value metadata and classifier controls",
    placement: isTableRow
      ? "row for cells, group header for table summary, inspector for row/column context"
      : isHeading
        ? "row for heading text, inspector for style provenance and child summary"
        : "row for content preview, inspector for locator/path/metadata, toolbar only for document-level counts",
    representation: isTableRow
      ? "table cells plus compact row label"
      : isNestedList
        ? "indented list marker plus parent/child grouping"
        : hasIssue
          ? "compact badge plus actionable inspector detail"
          : "plain text with contextual metadata on selection",
    row_label_quality: isTableRow
      ? "content-based and partly redundant; prefer structural Row N label"
      : displayType(block) === "resource/list candidate"
        ? "potentially misleading if it reads as a task; prefer resource/list wording"
        : "clear enough for review",
    visual_hierarchy: isTableRow
      ? "table grouping needs to remain visually stronger than row text"
      : isNestedList
        ? "nested list level should be visibly grouped under the parent item"
        : "none",
    selection_state: visual.visual_status === "verified" ? "correct" : visual.visual_status,
    reviewer_action_clarity: hasIssue ? "review action should be explicit in the inspector" : "no action needed",
    inspector_usefulness: visual.inspector_aligned === "yes"
      ? "complete enough for source mapping; improve structure-specific context where noted"
      : "missing context",
    terminology_issue: "extraction-focused",
    accessibility_concern: visual.visual_status === "verified"
      ? "none observed in this row-click pass; keyboard/full screen-reader pass still separate"
      : "source/selection state must be programmatically and visually unambiguous",
    acceptance_test: acceptanceTest(block, visual, issue),
  };
}

function acceptanceTest(block, visual, issue) {
  if (issue.priority === "P0") {
    return "Clicking the extraction row always activates exactly the same source block id in the source pane and inspector.";
  }
  if (visual.visual_status === "inspector_unclear") {
    return "Inspector shows selected text, locator, block id, parent path, and source mapping for this row.";
  }
  if (block.block_type === "table_row") {
    return "Table row displays as Row N with visible cells and inspector table context; source row highlights exactly.";
  }
  const numbering = block.numbering || block.confidence_signals?.numbering;
  if (numbering && numbering.level > 0) {
    return "Nested list row is visually grouped under its parent and preserves marker/level metadata.";
  }
  if (block.block_type === "heading") {
    return "Heading row shows level/style provenance without duplicating ancestor rows.";
  }
  if ((block.review_flags || []).length) {
    return "Review flag has an explanation and next action in row or inspector.";
  }
  return "Row remains readable and source highlight stays synchronized.";
}

function deriveIssue(block, visual) {
  if (visual.visual_status === "missing_extraction_row") {
    return {
      what_wrong: "The source block exists in the extraction artifact but is not reviewable as a row in the right pane.",
      improvement: "Guarantee one visible, selectable Extraction Explorer row per source block, with required ancestors expanded by source-block lookup.",
      fix_scope: "Frontend mapping/model",
      priority: "P0",
    };
  }
  if (visual.visual_status === "active_row_mismatch" || visual.visual_status === "source_highlight_missing") {
    return {
      what_wrong: "The visual source-to-extraction sync is unreliable for this block.",
      improvement: "Make source-block id the canonical active state and ensure row click, inspector, and source highlight derive from the same id.",
      fix_scope: "Frontend state/sync",
      priority: "P0",
    };
  }
  if (visual.visual_status === "inspector_unclear") {
    return {
      what_wrong: "The selected block is technically mapped, but the inspector does not make that mapping obvious enough for a reviewer.",
      improvement: "Show selected text, locator, block id, parent path, and table/list details in the inspector for every active row.",
      fix_scope: "Frontend UX",
      priority: "P1",
    };
  }
  if ((block.review_flags || []).length > 0) {
    if (!reviewFlagContextComplete(block, visual)) {
      return {
        what_wrong: `Extraction review flags require attention: ${reviewFlagText(block)}.`,
        improvement: "Surface the exact review flag meaning and a reviewer action on the selected row and in the attention checklist.",
        fix_scope: "Backend artifact semantics + frontend UX",
        priority: "P1",
      };
    }
  }
  if (block.block_type === "table_row") {
    if (!tableRowContextComplete(block, visual)) {
      return {
        what_wrong: "The extraction is structurally accurate, but table rows still need table context to reduce reviewer mental work.",
        improvement: "Use structural row labels, cell grid display, and inspector context such as table name, row position, and column count.",
        fix_scope: "Frontend UX/model",
        priority: "P2",
      };
    }
  }
  const numbering = block.numbering || block.confidence_signals?.numbering;
  if ((block.block_type === "procedure_step" || block.block_type === "ordered_list" || block.block_type === "unordered_list") && numbering?.level > 0) {
    if (!nestedListContextComplete(block, visual)) {
      return {
        what_wrong: "The nested list/procedure item maps correctly, but hierarchy can still be hard to scan if visual nesting is too subtle.",
        improvement: "Render list level and parent/child continuation more explicitly while preserving the source numbering marker.",
        fix_scope: "Frontend UX/model",
        priority: "P2",
      };
    }
  }
  if (block.block_type === "heading") {
    return {
      what_wrong: "No mapping issue found. Heading review would benefit from compact provenance details.",
      improvement: "Show heading level, style source, inferred/explicit state, and child count without adding noisy badges.",
      fix_scope: "Frontend UX",
      priority: "P3",
    };
  }
  return {
    what_wrong: "No extraction or mapping issue found in the visible line review.",
    improvement: "No immediate change required beyond global information-economy cleanup.",
    fix_scope: "No issue",
    priority: "P3",
  };
}

function tableRowContextComplete(block, visual) {
  const rowIndex = block.row_index ?? "";
  const rowHasStructuralLabel = rowIndex === "" || normalizedContains(visual.row_text, `Row ${rowIndex}`);
  const rowShowsCells = (block.cells || []).every((cell) => normalizedContains(visual.row_text, cell.text || ""));
  const inspectorShowsTable = normalizedContains(visual.inspector_text, "Table")
    && normalizedContains(visual.inspector_text, "Position")
    && normalizedContains(visual.inspector_text, "Columns")
    && normalizedContains(visual.inspector_text, block.block_id);
  return rowHasStructuralLabel && rowShowsCells && inspectorShowsTable;
}

function nestedListContextComplete(block, visual) {
  const numbering = block.numbering || block.confidence_signals?.numbering || {};
  const marker = numbering.label || numbering.marker || "";
  const hasMarker = !marker || normalizedContains(visual.row_text, marker) || normalizedContains(visual.inspector_text, marker);
  const level = typeof numbering.level === "number" ? numbering.level + 1 : null;
  const hasLevel = level === null || normalizedContains(visual.inspector_text, `List level ${level}`) || normalizedContains(visual.row_text, `level ${level}`);
  const hasNestedHint = !level || level <= 1 || normalizedContains(visual.inspector_text, "Nested under previous list item");
  return hasMarker && hasLevel && hasNestedHint;
}

function reviewFlagContextComplete(block, visual) {
  const flags = block.review_flags || [];
  if (!flags.length) return true;
  if (!normalizedContains(visual.inspector_text, "Review signal") || !normalizedContains(visual.inspector_text, "Action:")) return false;
  return flags.every((flag) => {
    const code = reviewFlagCode(flag);
    const label = REVIEW_FLAG_CATALOG[code];
    if (!label) return false;
    return normalizedContains(visual.row_text, label) || normalizedContains(visual.inspector_text, label);
  });
}

function whyRight(block, visual) {
  const parts = [];
  if (block.source_location?.section) parts.push("stable locator is present");
  if (visual.visual_status === "verified") parts.push("visible row click selected the matching source highlight");
  if (block.block_type === "table_row" && block.cells?.length) parts.push("cell boundaries are preserved");
  if (block.block_type === "heading") parts.push("heading appears once as structure, not duplicated topic context");
  if (block.numbering || block.confidence_signals?.numbering) parts.push("numbering metadata is available");
  if (!parts.length) parts.push("source text is preserved in document order");
  return sentence(parts.join("; "));
}

function displayType(block) {
  if (block.block_type === "table_row") return "table_row";
  if (block.block_type === "heading") return "heading";
  if (block.block_type === "note") return "note";
  if (block.block_type === "procedure_step" || block.block_type === "ordered_list" || block.block_type === "unordered_list") {
    const text = (block.text || "").trim();
    const numbering = block.numbering || block.confidence_signals?.numbering;
    if (numbering?.format === "bullet" && text.length <= 80) return "resource/list candidate";
    return "step/list item";
  }
  return block.block_type || "unknown";
}

function structureDetails(block) {
  if (block.block_type === "table_row") {
    return `Cells: ${(block.cells || []).map((cell) => `\`${safeCell(cell.text)}\``).join("; ") || "none"}`;
  }
  const numbering = block.numbering || block.confidence_signals?.numbering;
  if (numbering) {
    const bits = [];
    if (numbering.marker) bits.push(`Marker \`${numbering.marker}\``);
    if (numbering.level !== undefined && numbering.level !== null) bits.push(`list level ${numbering.level}`);
    if (numbering.format) bits.push(`format \`${numbering.format}\``);
    return bits.join("; ");
  }
  if (block.block_type === "heading") {
    const signals = block.confidence_signals || {};
    const level = block.inferred_level || signals.inferred_level || "";
    const source = signals.style_source || "unknown";
    return `Heading level ${level || "unknown"}; style source \`${source}\``;
  }
  if ((block.review_flags || []).length) return `Review flags: ${reviewFlagText(block)}`;
  return `${block.block_type || "source"} block`;
}

function reviewFlagText(block) {
  const flags = block.review_flags || [];
  return flags.map((flag) => {
    if (typeof flag === "string") return flag;
    if (!flag || typeof flag !== "object") return String(flag);
    return flag.code || flag.type || flag.name || flag.reason || flag.message || JSON.stringify(flag);
  }).join(", ");
}

function reviewFlagCode(flag) {
  if (typeof flag === "string") return flag;
  if (!flag || typeof flag !== "object") return "";
  return flag.code || flag.type || flag.name || flag.reason || "";
}

function parentPath(block, blocks) {
  const byId = new Map(blocks.map((candidate) => [candidate.block_id, candidate]));
  const pathIds = block.heading_path_ids || [];
  const labels = pathIds.map((id) => byId.get(id)?.text).filter(Boolean);
  return labels.length ? labels.join(" / ") : "Document root";
}

async function writeReport(result) {
  const reportPath = path.join(feedbackDir, `${result.slug}.md`);
  const lineRows = result.lines.map((line) => [
    String(line.line),
    md(line.extracted_source_block),
    md(line.type),
    md(line.locator || "missing"),
    md(line.parent_path),
    md(line.structure),
    md(line.visual_status),
    md(line.source_highlight),
    md(line.why_right),
    md(line.what_wrong),
    md(line.improvement),
    md(line.information_economy),
    md(line.placement),
    md(line.representation),
    md(line.row_label_quality),
    md(line.visual_hierarchy),
    md(line.selection_state),
    md(line.reviewer_action_clarity),
    md(line.inspector_usefulness),
    md(line.terminology_issue),
    md(line.accessibility_concern),
    md(line.fix_scope),
    md(line.priority),
    md(line.acceptance_test),
  ]);
  const mismatchCount = visualMismatchCount(result);
  const p0Count = result.lines.filter((line) => line.priority === "P0").length;
  const p1Count = result.lines.filter((line) => line.priority === "P1").length;
  const p2Count = result.lines.filter((line) => line.priority === "P2").length;
  const histogramText = Object.entries(result.summary.histogram || {})
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, count]) => `\`${key}\`=${count}`)
    .join(", ") || "none";

  const content = `# Workbench Extraction Feedback: ${result.filename}

## Metadata

| Field | Value |
|---|---|
| Document | \`${result.filename}\` |
| Document ID | \`${result.document_id}\` |
| Review date | \`2026-05-11\` |
| App status | \`${result.status}\` |
| Review scope | Visible Chromium line-by-line extraction review |
| Browser UX pass | \`${result.review_status}\` |
| Out of scope | DITA topic classification, generated topic quality, classifier tuning |
| Source blocks | \`${result.summary.total_source_blocks}\` |
| Locator coverage | \`${result.summary.located_source_blocks}/${result.summary.total_source_blocks}\` |
| Block histogram | ${histogramText} |
| Visual mismatches | \`${mismatchCount}\` |
| Evidence screenshot | \`${result.screenshot || "none"}\` |

## Executive Summary

| Category | Summary |
|---|---|
| Extraction correctness | ${summaryExtraction(result)} |
| Source mapping | ${summaryMapping(result)} |
| Table/list/heading representation | ${summaryStructure(result)} |
| UI clutter/information economy | Every visible parameter, badge, count, and control should earn its place; classification controls stay out of the extraction-review viewport. |
| Attention/review workflow | Counts should come from extraction review signals only and remain consistent between source pane, explorer, and checklist. |
| Accessibility/keyboard review | Row click and source highlight were checked for every source block in visible Chromium; keyboard spot checks remain a separate pass unless noted. |
| Highest-priority fixes | P0=${p0Count}; P1=${p1Count}; P2=${p2Count}. |

## Document-Specific Backlog

| Area | Finding | Recommended fix | Fix scope | Priority |
|---|---|---|---|---|
${backlogRows(result)}

## Visible Chromium Line-by-Line Verification

This table is generated from the visible Workbench pass. Each ready-for-review source block was clicked in the Extraction Explorer, then the active source highlight and inspector were checked against the same source block id.

| Line | Extracted source block | Type | Locator | Parent path | Structure details | Visual status | Source highlight | Why it is right | What is wrong | Improvement | Information economy | Placement | Representation | Row label quality | Visual hierarchy | Selection state | Reviewer action clarity | Inspector usefulness | Terminology | Accessibility | Root cause | Priority | Acceptance test |
|---:|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
${lineRows.map((row) => `| ${row.join(" | ")} |`).join("\n") || "| - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - | - |"}

## Final Notes

This report judges extraction completeness, source mapping, structure representation, and reviewer UX only. DITA topic classification is intentionally excluded.
`;

  assertReportContent(result, content);
  await fs.writeFile(reportPath, content);
}

async function writeIndex(results) {
  const existing = await fs.readFile(resultsPath, "utf8").then(JSON.parse).catch(() => results);
  const rows = existing.map((result) => {
    const total = result.summary?.total_source_blocks || result.lines?.length || 0;
    const located = result.summary?.located_source_blocks || 0;
    const mismatches = visualMismatchCount(result);
    const p0 = indexPriorityCount(result, "P0");
    const p1 = indexPriorityCount(result, "P1");
    const p2 = indexPriorityCount(result, "P2");
    return `| [${result.slug}](${result.slug}.md) | ${result.status} | ${result.review_status} | ${total} | ${located}/${total} | ${mismatches} | ${p0} | ${p1} | ${p2} |`;
  });
  const repeatedRows = topRepeatedIssues(existing).map((issue) =>
    `| ${md(issue.what_wrong)} | ${issue.count} | ${md(issue.firstDocs.join(", "))} | ${md(issue.priority)} | ${md(issue.fix_scope)} |`,
  );
  const content = `# Workbench Feedback Batch Index

Generated: \`2026-05-11\`

Scope: uploaded app documents in \`Documentation Operations\`, sourced from DOCX files under \`DATA/dita_source_docs/DOC\`. This index tracks visible Chromium line-by-line extraction review, not DITA topic-classification quality.

| Report | App status | Browser line review | Source blocks | Locator coverage | Visual mismatches | P0 count | P1 count | P2 count |
|---|---|---|---:|---:|---:|---:|---:|---:|
${rows.join("\n")}

## Top Repeated Issues

| Issue | Count | First affected docs | Priority | Fix scope |
|---|---:|---|---|---|
${repeatedRows.join("\n") || "| No repeated P0/P1/P2 issue | 0 | - | - | - |"}
`;
  if (content.includes("[object Object]")) {
    throw new Error("Generated feedback index contains [object Object]");
  }
  await fs.writeFile(path.join(feedbackDir, "index.md"), content);
}

function assertReportContent(result, content) {
  if (content.includes("[object Object]")) {
    throw new Error(`Generated report for ${result.filename} contains [object Object]`);
  }
  for (const heading of [
    "## Metadata",
    "## Document-Specific Backlog",
    "## Visible Chromium Line-by-Line Verification",
    "## Final Notes",
  ]) {
    if (!content.includes(heading)) {
      throw new Error(`Generated report for ${result.filename} is missing ${heading}`);
    }
  }
  if (result.status !== "ready_for_review" && !content.includes("Line-by-line review blocked by status")) {
    throw new Error(`Blocked-status report for ${result.filename} does not state the review was blocked`);
  }
}

function topRepeatedIssues(results) {
  const grouped = new Map();
  for (const result of results) {
    if (result.status !== "ready_for_review") continue;
    for (const line of result.lines || []) {
      if (!["P0", "P1", "P2"].includes(line.priority)) continue;
      const key = `${line.priority}::${line.fix_scope}::${line.what_wrong}`;
      const current = grouped.get(key) || {
        what_wrong: line.what_wrong,
        priority: line.priority,
        fix_scope: line.fix_scope,
        count: 0,
        docs: new Set(),
      };
      current.count += 1;
      current.docs.add(result.slug || result.filename);
      grouped.set(key, current);
    }
  }
  return Array.from(grouped.values())
    .map((issue) => ({
      ...issue,
      firstDocs: Array.from(issue.docs).slice(0, 3),
    }))
    .sort((a, b) => b.count - a.count || String(a.what_wrong).localeCompare(String(b.what_wrong)))
    .slice(0, 12);
}

function indexPriorityCount(result, priority) {
  if (result.status !== "ready_for_review") return 0;
  return (result.lines || []).filter((line) => line.priority === priority).length;
}

function backlogRows(result) {
  const grouped = new Map();
  for (const line of result.lines) {
    if (line.priority === "P3") continue;
    const key = `${line.fix_scope}::${line.what_wrong}::${line.improvement}::${line.priority}`;
    const current = grouped.get(key) || { count: 0, line };
    current.count += 1;
    grouped.set(key, current);
  }
  if (!grouped.size) {
    return "| No blocking document-specific issue | No extraction or mapping issue found in visible line review. | Continue applying global information-economy cleanup. | No issue | P3 |";
  }
  return Array.from(grouped.values())
    .map(({ count, line }) => `| ${md(line.fix_scope)} | ${md(`${line.what_wrong} (${count} line${count === 1 ? "" : "s"})`)} | ${md(line.improvement)} | ${md(line.fix_scope)} | ${md(line.priority)} |`)
    .join("\n");
}

function summaryExtraction(result) {
  if (result.status !== "ready_for_review") return `Line-by-line review blocked by status \`${result.status}\`; Source remains the only reliable inspection surface.`;
  return `Visible pass reviewed \`${result.lines.length}\` source blocks; locator coverage is \`${result.summary.located_source_blocks}/${result.summary.total_source_blocks}\`.`;
}

function summaryMapping(result) {
  const mismatches = result.status === "ready_for_review" ? result.lines.filter((line) => line.visual_status !== "verified") : [];
  if (!mismatches.length) return "Every clicked extraction row selected an exact matching source highlight.";
  return `${mismatches.length} line(s) had row/source/inspector alignment findings.`;
}

function visualMismatchCount(result) {
  if (result.status !== "ready_for_review") return 0;
  return (result.lines || []).filter((line) => line.visual_status !== "verified").length;
}

function summaryStructure(result) {
  const tableRows = result.lines.filter((line) => line.raw_type === "table_row").length;
  const listRows = result.lines.filter((line) => line.raw_type === "procedure_step" || line.raw_type === "ordered_list" || line.raw_type === "unordered_list").length;
  const headings = result.lines.filter((line) => line.raw_type === "heading").length;
  return `Headings=${headings}; table rows=${tableRows}; list/procedure rows=${listRows}. Table and list rows should keep structural context visible without classification clutter.`;
}

async function signIn(page) {
  await page.goto(appUrl);
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }
  await page.getByRole("heading", { name: "Business Units" }).waitFor({ timeout: 30_000 });
}

async function openBusinessUnit(page) {
  await page.goto(appUrl);
  const signInButton = page.getByRole("button", { name: /^Sign in$/ });
  if (await signInButton.isVisible().catch(() => false)) {
    await signIn(page);
  }
  const documentSearch = page.locator("input[placeholder='Search documents by name']").first();
  const breadcrumbButton = page.getByRole("button", { name: businessUnitName }).first();
  const card = page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") });
  const route = await Promise.race([
    documentSearch.waitFor({ state: "visible", timeout: 30_000 }).then(() => "document-list"),
    breadcrumbButton.waitFor({ state: "visible", timeout: 30_000 }).then(() => "breadcrumb"),
    card.waitFor({ state: "visible", timeout: 30_000 }).then(() => "business-units"),
  ]).catch(() => null);
  if (route === "document-list") return;
  if (route === "breadcrumb") {
    await breadcrumbButton.click();
    await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
    return;
  }
  if (route !== "business-units") {
    throw new Error(`Could not reach ${businessUnitName} document list`);
  }
  await card.click();
  await documentSearch.waitFor({ state: "visible", timeout: 30_000 });
}

async function openDocument(page, filename) {
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor({ state: "visible", timeout: 30_000 });
  await search.click();
  await search.press(process.platform === "darwin" ? "Meta+A" : "Control+A");
  await search.fill(filename);
  await page.waitForTimeout(500);
  const row = page.locator(".upload-row").filter({ hasText: filename }).first();
  await row.waitFor({ state: "visible", timeout: 30_000 });
  await row.click({ position: { x: 80, y: 24 } });
}

async function resetExplorerFilters(page) {
  const searchInput = page.getByPlaceholder("Search extracted anchors");
  if (await searchInput.isVisible().catch(() => false)) {
    await searchInput.fill("");
  }
  const attentionToggle = page.getByRole("button", { name: /Attention only/i });
  if (await attentionToggle.isVisible().catch(() => false)) {
    const pressed = await attentionToggle.getAttribute("aria-pressed").catch(() => null);
    if (pressed === "true") await attentionToggle.click();
  }
}

async function expandAllRows(page) {
  for (let i = 0; i < 300; i += 1) {
    const expandButton = page.locator(".extraction-row-toggle[aria-label^='Expand']:not([disabled])").first();
    if ((await expandButton.count()) === 0) break;
    await expandButton.click();
    await page.waitForTimeout(10);
  }
}

async function sourceStatusText(page) {
  return page.locator(".source-viewer-status, [aria-label='Source viewer status']").first().innerText().catch(() => "");
}

async function waitForSourcePreview(page) {
  await page.waitForFunction(
    () => {
      const text = document.body.innerText;
      const hasStatus = /\d+\s*\/\s*\d+\s*matched/i.test(text);
      const hasAnchor = document.querySelectorAll("[data-source-block-id]").length > 0;
      return hasStatus && hasAnchor;
    },
    { timeout: 30_000 },
  );
}

async function screenshot(page, name) {
  const file = path.join(outDir, name);
  await page.screenshot({ path: file, fullPage: false });
  return file;
}

async function fetchBlocks(token, documentId) {
  const blocks = [];
  let cursor = "";
  do {
    const suffix = cursor ? `&cursor=${encodeURIComponent(cursor)}` : "";
    const payload = await apiGet(token, `/v1/documents/${documentId}/blocks?limit=100${suffix}`);
    blocks.push(...payload.items);
    cursor = payload.next_cursor || "";
  } while (cursor);
  return blocks;
}

async function apiLogin() {
  const response = await fetch(`${apiUrl}/v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!response.ok) throw new Error(`API login failed: ${response.status} ${await response.text()}`);
  const payload = await response.json();
  return payload.access_token;
}

async function apiGet(token, apiPath) {
  const response = await fetch(`${apiUrl}${apiPath}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error(`API GET ${apiPath} failed: ${response.status} ${await response.text()}`);
  return response.json();
}

function histogram(values) {
  return values.reduce((acc, value) => {
    acc[value] = (acc[value] || 0) + 1;
    return acc;
  }, {});
}

function cellText(block) {
  return (block.cells || []).map((cell) => cell.text || "").join(" | ");
}

function preview(value, length) {
  const text = oneLine(value);
  return text.length > length ? `${text.slice(0, length - 1)}...` : text;
}

function oneLine(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function safeCell(value) {
  return preview(value || " ", 70).replace(/`/g, "'");
}

function sentence(value) {
  return value.charAt(0).toUpperCase() + value.slice(1) + ".";
}

function normalizedContains(haystack, needle) {
  const normalizedNeedle = normalizeText(needle).slice(0, 80);
  return Boolean(normalizedNeedle) && normalizeText(haystack).includes(normalizedNeedle);
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function cssAttr(value) {
  return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function md(value) {
  return String(value ?? "")
    .replace(/\r?\n/g, "<br>")
    .replace(/\|/g, "\\|")
    .replace(/\`/g, "\\`")
    .trim() || "-";
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
