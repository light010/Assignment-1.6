// One-off capture script: opens 5 representative documents in the Workbench,
// clicks a representative block in each, and captures full-page screenshots at
// a standardised 1440x900 viewport. Used for chip-by-chip UX audit.
//
// Output: /private/tmp/workbench-chip-audit/<slug>.png

import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const appUrl = process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173";
const email = process.env.DITAGEN_E2E_EMAIL || "admin@ditagen.local";
const password = process.env.DITAGEN_E2E_PASSWORD || "admin123";
const businessUnitName = process.env.DITAGEN_E2E_BUSINESS_UNIT || "Documentation Operations";
const outDir = "/private/tmp/workbench-chip-audit";

const TARGETS = [
  { slug: "01-apple-ca-psc", filename: "Apple CA (PSC).docx" },
  { slug: "02-sap-garnishment", filename: "SAP Garnishment Processing Overview.docx" },
  { slug: "03-customer-change-requests", filename: "Customer Change Requests.docx" },
  { slug: "04-ppp-clean", filename: "Running the Paycheck Protection Program (PPP) Loan Forgiveness Application.docx" },
  { slug: "05-reprocessing-funddirect", filename: "Reprocessing FundDirect File Created with Error.docx" },
];

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function signIn(page) {
  await page.goto(appUrl);
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }
  await page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") }).waitFor();
}

async function openDocumentDetails(page, filename) {
  // Always start fresh from "/" so we don't depend on prior nav state.
  await page.goto(appUrl);
  await page.waitForLoadState("networkidle");

  // If still on a doc detail page from a prior iteration, the BU button may
  // not be at root scope. Skip login if not visible, then click BU.
  const userId = page.getByRole("textbox", { name: "User ID" });
  if (await userId.isVisible().catch(() => false)) {
    await userId.fill(email);
    await page.locator("input[name=password]").fill(password);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
  }

  await page.getByRole("button", { name: new RegExp(`^${escapeRegExp(businessUnitName)},`, "i") }).click();
  const search = page.locator("input[placeholder='Search documents by name']").first();
  await search.waitFor();
  await search.fill(filename);
  await page.getByText(filename).first().waitFor();
  await page.locator(".upload-row").filter({ hasText: filename }).click();
  await page.getByRole("heading", { name: filename }).waitFor();
}

async function main() {
  await fs.mkdir(outDir, { recursive: true });
  const browser = await chromium.launch({ headless: true });

  for (const target of TARGETS) {
    console.error(`[capture] ${target.slug} — ${target.filename}`);
    // Fresh context per document so localStorage / sessionStorage / nav state don't leak.
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await ctx.newPage();
    try {
      await openDocumentDetails(page, target.filename);
      // Try to click Workbench tab; tolerate disabled state.
      const workbenchTab = page.getByRole("tab", { name: "Workbench" });
      const disabled = await workbenchTab.getAttribute("aria-disabled").catch(() => null);
      if (disabled !== "true") {
        await workbenchTab.click().catch(() => {});
        // Wait for the tree to render, then click the 3rd visible row (skip document container + maybe heading).
        await page.locator("[role=treeitem]").first().waitFor({ timeout: 8000 }).catch(() => {});
        const rows = page.locator("[role=treeitem]");
        const count = await rows.count();
        if (count >= 3) {
          await rows.nth(Math.min(2, count - 1)).click({ timeout: 3000 }).catch(() => {});
        }
        await page.waitForTimeout(600);
      }
      const screenshotPath = path.join(outDir, `${target.slug}.png`);
      await page.screenshot({ path: screenshotPath, fullPage: false });
      console.error(`[saved] ${screenshotPath}`);
    } catch (err) {
      console.error(`[error] ${target.slug}: ${err.message}`);
      // Best-effort screenshot of current state
      const screenshotPath = path.join(outDir, `${target.slug}-error.png`);
      await page.screenshot({ path: screenshotPath, fullPage: false }).catch(() => {});
    }
    await ctx.close();
  }

  await browser.close();
  console.error(`[done] ${TARGETS.length} captures written to ${outDir}`);
}

await main().catch((err) => {
  console.error(err);
  process.exit(1);
});
